/*    */ package com.alibaba.com.caucho.hessian;
/*    */ 
/*    */ public class HessianException extends RuntimeException
/*    */ {
/*    */   public HessianException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public HessianException(String message)
/*    */   {
/* 67 */     super(message);
/*    */   }
/*    */ 
/*    */   public HessianException(String message, Throwable rootCause)
/*    */   {
/* 75 */     super(message, rootCause);
/*    */   }
/*    */ 
/*    */   public HessianException(Throwable rootCause)
/*    */   {
/* 83 */     super(rootCause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.HessianException
 * JD-Core Version:    0.6.2
 */