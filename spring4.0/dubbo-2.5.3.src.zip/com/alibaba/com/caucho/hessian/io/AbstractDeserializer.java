/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ public abstract class AbstractDeserializer
/*     */   implements Deserializer
/*     */ {
/*     */   public Class getType()
/*     */   {
/*  59 */     return Object.class;
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in)
/*     */     throws IOException
/*     */   {
/*  65 */     Object obj = in.readObject();
/*     */ 
/*  67 */     String className = getClass().getName();
/*     */ 
/*  69 */     if (obj != null) {
/*  70 */       throw error(className + ": unexpected object " + obj.getClass().getName() + " (" + obj + ")");
/*     */     }
/*  72 */     throw error(className + ": unexpected null value");
/*     */   }
/*     */ 
/*     */   public Object readList(AbstractHessianInput in, int length)
/*     */     throws IOException
/*     */   {
/*  78 */     throw new UnsupportedOperationException(String.valueOf(this));
/*     */   }
/*     */ 
/*     */   public Object readLengthList(AbstractHessianInput in, int length)
/*     */     throws IOException
/*     */   {
/*  84 */     throw new UnsupportedOperationException(String.valueOf(this));
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in)
/*     */     throws IOException
/*     */   {
/*  90 */     Object obj = in.readObject();
/*     */ 
/*  92 */     String className = getClass().getName();
/*     */ 
/*  94 */     if (obj != null) {
/*  95 */       throw error(className + ": unexpected object " + obj.getClass().getName() + " (" + obj + ")");
/*     */     }
/*  97 */     throw error(className + ": unexpected null value");
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, String[] fieldNames)
/*     */     throws IOException
/*     */   {
/* 103 */     throw new UnsupportedOperationException(String.valueOf(this));
/*     */   }
/*     */ 
/*     */   protected HessianProtocolException error(String msg)
/*     */   {
/* 108 */     return new HessianProtocolException(msg);
/*     */   }
/*     */ 
/*     */   protected String codeName(int ch)
/*     */   {
/* 113 */     if (ch < 0) {
/* 114 */       return "end of file";
/*     */     }
/* 116 */     return "0x" + Integer.toHexString(ch & 0xFF);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.AbstractDeserializer
 * JD-Core Version:    0.6.2
 */