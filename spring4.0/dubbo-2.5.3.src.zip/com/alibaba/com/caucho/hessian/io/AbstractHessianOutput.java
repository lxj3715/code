/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public abstract class AbstractHessianOutput
/*     */ {
/*     */   protected SerializerFactory _serializerFactory;
/*     */ 
/*     */   public void setSerializerFactory(SerializerFactory factory)
/*     */   {
/*  76 */     this._serializerFactory = factory;
/*     */   }
/*     */ 
/*     */   public SerializerFactory getSerializerFactory()
/*     */   {
/*  84 */     return this._serializerFactory;
/*     */   }
/*     */ 
/*     */   public final SerializerFactory findSerializerFactory()
/*     */   {
/*  92 */     SerializerFactory factory = this._serializerFactory;
/*     */ 
/*  94 */     if (factory == null) {
/*  95 */       this._serializerFactory = (factory = new SerializerFactory());
/*     */     }
/*  97 */     return factory;
/*     */   }
/*     */ 
/*     */   public void init(OutputStream os)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void call(String method, Object[] args)
/*     */     throws IOException
/*     */   {
/* 113 */     int length = args != null ? args.length : 0;
/*     */ 
/* 115 */     startCall(method, length);
/*     */ 
/* 117 */     for (int i = 0; i < length; i++) {
/* 118 */       writeObject(args[i]);
/*     */     }
/* 120 */     completeCall();
/*     */   }
/*     */ 
/*     */   public abstract void startCall()
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void startCall(String paramString, int paramInt)
/*     */     throws IOException;
/*     */ 
/*     */   /** @deprecated */
/*     */   public void writeHeader(String name)
/*     */     throws IOException
/*     */   {
/* 155 */     throw new UnsupportedOperationException(getClass().getSimpleName());
/*     */   }
/*     */ 
/*     */   public abstract void writeMethod(String paramString)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void completeCall()
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeBoolean(boolean paramBoolean)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeInt(int paramInt)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeLong(long paramLong)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeDouble(double paramDouble)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeUTCDate(long paramLong)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeNull()
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeString(String paramString)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeString(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeBytes(byte[] paramArrayOfByte)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeByteBufferStart()
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeByteBufferPart(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeByteBufferEnd(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException;
/*     */ 
/*     */   protected abstract void writeRef(int paramInt)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract boolean removeRef(Object paramObject)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract boolean replaceRef(Object paramObject1, Object paramObject2)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract boolean addRef(Object paramObject)
/*     */     throws IOException;
/*     */ 
/*     */   public void resetReferences()
/*     */   {
/*     */   }
/*     */ 
/*     */   public abstract void writeObject(Object paramObject)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract boolean writeListBegin(int paramInt, String paramString)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeListEnd()
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeMapBegin(String paramString)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void writeMapEnd()
/*     */     throws IOException;
/*     */ 
/*     */   public int writeObjectBegin(String type)
/*     */     throws IOException
/*     */   {
/* 477 */     writeMapBegin(type);
/*     */ 
/* 479 */     return -2;
/*     */   }
/*     */ 
/*     */   public void writeClassFieldLength(int len)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void writeObjectEnd()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void writeReply(Object o)
/*     */     throws IOException
/*     */   {
/* 501 */     startReply();
/* 502 */     writeObject(o);
/* 503 */     completeReply();
/*     */   }
/*     */ 
/*     */   public void startReply()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void completeReply()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void writeFault(String code, String message, Object detail)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.AbstractHessianOutput
 * JD-Core Version:    0.6.2
 */