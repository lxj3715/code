/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class AbstractHessianResolver
/*    */   implements HessianRemoteResolver
/*    */ {
/*    */   public Object lookup(String type, String url)
/*    */     throws IOException
/*    */   {
/* 63 */     return new HessianRemote(type, url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.AbstractHessianResolver
 * JD-Core Version:    0.6.2
 */