/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class AbstractListDeserializer extends AbstractDeserializer
/*    */ {
/*    */   public Object readObject(AbstractHessianInput in)
/*    */     throws IOException
/*    */   {
/* 60 */     Object obj = in.readObject();
/*    */ 
/* 62 */     if (obj != null) {
/* 63 */       throw error("expected list at " + obj.getClass().getName() + " (" + obj + ")");
/*    */     }
/* 65 */     throw error("expected list at null");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.AbstractListDeserializer
 * JD-Core Version:    0.6.2
 */