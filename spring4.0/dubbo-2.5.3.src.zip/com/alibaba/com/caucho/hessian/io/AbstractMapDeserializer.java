/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class AbstractMapDeserializer extends AbstractDeserializer
/*    */ {
/*    */   public Class getType()
/*    */   {
/* 61 */     return HashMap.class;
/*    */   }
/*    */ 
/*    */   public Object readObject(AbstractHessianInput in)
/*    */     throws IOException
/*    */   {
/* 67 */     Object obj = in.readObject();
/*    */ 
/* 69 */     if (obj != null) {
/* 70 */       throw error("expected map/object at " + obj.getClass().getName() + " (" + obj + ")");
/*    */     }
/* 72 */     throw error("expected map/object at null");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.AbstractMapDeserializer
 * JD-Core Version:    0.6.2
 */