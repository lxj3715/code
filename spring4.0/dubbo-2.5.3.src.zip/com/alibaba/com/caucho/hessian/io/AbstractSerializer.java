/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public abstract class AbstractSerializer
/*    */   implements Serializer
/*    */ {
/* 58 */   protected static final Logger log = Logger.getLogger(AbstractSerializer.class.getName());
/*    */ 
/*    */   public abstract void writeObject(Object paramObject, AbstractHessianOutput paramAbstractHessianOutput)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.AbstractSerializer
 * JD-Core Version:    0.6.2
 */