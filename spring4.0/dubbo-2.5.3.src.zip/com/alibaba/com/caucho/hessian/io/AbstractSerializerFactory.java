package com.alibaba.com.caucho.hessian.io;

public abstract class AbstractSerializerFactory
{
  public abstract Serializer getSerializer(Class paramClass)
    throws HessianProtocolException;

  public abstract Deserializer getDeserializer(Class paramClass)
    throws HessianProtocolException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.AbstractSerializerFactory
 * JD-Core Version:    0.6.2
 */