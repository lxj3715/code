/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class ArrayDeserializer extends AbstractListDeserializer
/*     */ {
/*     */   private Class _componentType;
/*     */   private Class _type;
/*     */ 
/*     */   public ArrayDeserializer(Class componentType)
/*     */   {
/*  64 */     this._componentType = componentType;
/*     */ 
/*  66 */     if (this._componentType != null)
/*     */       try {
/*  68 */         this._type = Array.newInstance(this._componentType, 0).getClass();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*  73 */     if (this._type == null)
/*  74 */       this._type = [Ljava.lang.Object.class;
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  79 */     return this._type;
/*     */   }
/*     */ 
/*     */   public Object readList(AbstractHessianInput in, int length)
/*     */     throws IOException
/*     */   {
/*  88 */     if (length >= 0) {
/*  89 */       Object[] data = createArray(length);
/*     */ 
/*  91 */       in.addRef(data);
/*     */ 
/*  93 */       if (this._componentType != null) {
/*  94 */         for (int i = 0; i < data.length; i++)
/*  95 */           data[i] = in.readObject(this._componentType);
/*     */       }
/*     */       else {
/*  98 */         for (int i = 0; i < data.length; i++) {
/*  99 */           data[i] = in.readObject();
/*     */         }
/*     */       }
/* 102 */       in.readListEnd();
/*     */ 
/* 104 */       return data;
/*     */     }
/*     */ 
/* 107 */     ArrayList list = new ArrayList();
/*     */ 
/* 109 */     in.addRef(list);
/*     */ 
/* 111 */     if (this._componentType != null) {
/* 112 */       while (!in.isEnd()) {
/* 113 */         list.add(in.readObject(this._componentType));
/*     */       }
/*     */     }
/* 116 */     while (!in.isEnd()) {
/* 117 */       list.add(in.readObject());
/*     */     }
/*     */ 
/* 120 */     in.readListEnd();
/*     */ 
/* 122 */     Object[] data = createArray(list.size());
/* 123 */     for (int i = 0; i < data.length; i++) {
/* 124 */       data[i] = list.get(i);
/*     */     }
/* 126 */     return data;
/*     */   }
/*     */ 
/*     */   public Object readLengthList(AbstractHessianInput in, int length)
/*     */     throws IOException
/*     */   {
/* 136 */     Object[] data = createArray(length);
/*     */ 
/* 138 */     in.addRef(data);
/*     */ 
/* 140 */     if (this._componentType != null) {
/* 141 */       for (int i = 0; i < data.length; i++)
/* 142 */         data[i] = in.readObject(this._componentType);
/*     */     }
/*     */     else {
/* 145 */       for (int i = 0; i < data.length; i++) {
/* 146 */         data[i] = in.readObject();
/*     */       }
/*     */     }
/* 149 */     return data;
/*     */   }
/*     */ 
/*     */   protected Object[] createArray(int length)
/*     */   {
/* 154 */     if (this._componentType != null) {
/* 155 */       return (Object[])Array.newInstance(this._componentType, length);
/*     */     }
/* 157 */     return new Object[length];
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 162 */     return "ArrayDeserializer[" + this._componentType + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.ArrayDeserializer
 * JD-Core Version:    0.6.2
 */