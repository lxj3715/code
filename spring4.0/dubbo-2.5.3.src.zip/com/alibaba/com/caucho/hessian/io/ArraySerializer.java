/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class ArraySerializer extends AbstractSerializer
/*    */ {
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 60 */     if (out.addRef(obj)) {
/* 61 */       return;
/*    */     }
/* 63 */     Object[] array = (Object[])obj;
/*    */ 
/* 65 */     boolean hasEnd = out.writeListBegin(array.length, getArrayType(obj.getClass()));
/*    */ 
/* 68 */     for (int i = 0; i < array.length; i++) {
/* 69 */       out.writeObject(array[i]);
/*    */     }
/* 71 */     if (hasEnd)
/* 72 */       out.writeListEnd();
/*    */   }
/*    */ 
/*    */   private String getArrayType(Class cl)
/*    */   {
/* 80 */     if (cl.isArray()) {
/* 81 */       return '[' + getArrayType(cl.getComponentType());
/*    */     }
/* 83 */     String name = cl.getName();
/*    */ 
/* 85 */     if (name.equals("java.lang.String"))
/* 86 */       return "string";
/* 87 */     if (name.equals("java.lang.Object"))
/* 88 */       return "object";
/* 89 */     if (name.equals("java.util.Date")) {
/* 90 */       return "date";
/*    */     }
/* 92 */     return name;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.ArraySerializer
 * JD-Core Version:    0.6.2
 */