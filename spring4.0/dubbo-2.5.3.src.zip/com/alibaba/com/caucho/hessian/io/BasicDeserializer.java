/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class BasicDeserializer extends AbstractDeserializer
/*     */ {
/*     */   public static final int NULL = 0;
/*     */   public static final int BOOLEAN = 1;
/*     */   public static final int BYTE = 2;
/*     */   public static final int SHORT = 3;
/*     */   public static final int INTEGER = 4;
/*     */   public static final int LONG = 5;
/*     */   public static final int FLOAT = 6;
/*     */   public static final int DOUBLE = 7;
/*     */   public static final int CHARACTER = 8;
/*     */   public static final int CHARACTER_OBJECT = 9;
/*     */   public static final int STRING = 10;
/*     */   public static final int DATE = 11;
/*     */   public static final int NUMBER = 12;
/*     */   public static final int OBJECT = 13;
/*     */   public static final int BOOLEAN_ARRAY = 14;
/*     */   public static final int BYTE_ARRAY = 15;
/*     */   public static final int SHORT_ARRAY = 16;
/*     */   public static final int INTEGER_ARRAY = 17;
/*     */   public static final int LONG_ARRAY = 18;
/*     */   public static final int FLOAT_ARRAY = 19;
/*     */   public static final int DOUBLE_ARRAY = 20;
/*     */   public static final int CHARACTER_ARRAY = 21;
/*     */   public static final int STRING_ARRAY = 22;
/*     */   public static final int OBJECT_ARRAY = 23;
/*     */   private int _code;
/*     */ 
/*     */   public BasicDeserializer(int code)
/*     */   {
/*  89 */     this._code = code;
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  94 */     switch (this._code) {
/*     */     case 0:
/*  96 */       return Void.TYPE;
/*     */     case 1:
/*  98 */       return Boolean.class;
/*     */     case 2:
/* 100 */       return Byte.class;
/*     */     case 3:
/* 102 */       return Short.class;
/*     */     case 4:
/* 104 */       return Integer.class;
/*     */     case 5:
/* 106 */       return Long.class;
/*     */     case 6:
/* 108 */       return Float.class;
/*     */     case 7:
/* 110 */       return Double.class;
/*     */     case 8:
/* 112 */       return Character.class;
/*     */     case 9:
/* 114 */       return Character.class;
/*     */     case 10:
/* 116 */       return String.class;
/*     */     case 11:
/* 118 */       return Date.class;
/*     */     case 12:
/* 120 */       return Number.class;
/*     */     case 13:
/* 122 */       return Object.class;
/*     */     case 14:
/* 125 */       return [Z.class;
/*     */     case 15:
/* 127 */       return [B.class;
/*     */     case 16:
/* 129 */       return [S.class;
/*     */     case 17:
/* 131 */       return [I.class;
/*     */     case 18:
/* 133 */       return [J.class;
/*     */     case 19:
/* 135 */       return [F.class;
/*     */     case 20:
/* 137 */       return [D.class;
/*     */     case 21:
/* 139 */       return [C.class;
/*     */     case 22:
/* 141 */       return [Ljava.lang.String.class;
/*     */     case 23:
/* 143 */       return [Ljava.lang.Object.class;
/*     */     }
/* 145 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in)
/*     */     throws IOException
/*     */   {
/* 152 */     switch (this._code)
/*     */     {
/*     */     case 0:
/* 155 */       in.readObject();
/*     */ 
/* 157 */       return null;
/*     */     case 1:
/* 160 */       return Boolean.valueOf(in.readBoolean());
/*     */     case 2:
/* 163 */       return Byte.valueOf((byte)in.readInt());
/*     */     case 3:
/* 166 */       return Short.valueOf((short)in.readInt());
/*     */     case 4:
/* 169 */       return Integer.valueOf(in.readInt());
/*     */     case 5:
/* 172 */       return Long.valueOf(in.readLong());
/*     */     case 6:
/* 175 */       return Float.valueOf((float)in.readDouble());
/*     */     case 7:
/* 178 */       return Double.valueOf(in.readDouble());
/*     */     case 10:
/* 181 */       return in.readString();
/*     */     case 13:
/* 184 */       return in.readObject();
/*     */     case 8:
/* 188 */       String s = in.readString();
/* 189 */       if ((s == null) || (s.equals(""))) {
/* 190 */         return Character.valueOf('\000');
/*     */       }
/* 192 */       return Character.valueOf(s.charAt(0));
/*     */     case 9:
/* 197 */       String s = in.readString();
/* 198 */       if ((s == null) || (s.equals(""))) {
/* 199 */         return null;
/*     */       }
/* 201 */       return Character.valueOf(s.charAt(0));
/*     */     case 11:
/* 205 */       return new Date(in.readUTCDate());
/*     */     case 12:
/* 208 */       return in.readObject();
/*     */     case 15:
/* 211 */       return in.readBytes();
/*     */     case 21:
/* 215 */       String s = in.readString();
/*     */ 
/* 217 */       if (s == null) {
/* 218 */         return null;
/*     */       }
/* 220 */       int len = s.length();
/* 221 */       char[] chars = new char[len];
/* 222 */       s.getChars(0, len, chars, 0);
/* 223 */       return chars;
/*     */     case 14:
/*     */     case 16:
/*     */     case 17:
/*     */     case 18:
/*     */     case 19:
/*     */     case 20:
/*     */     case 22:
/* 235 */       int code = in.readListStart();
/*     */ 
/* 237 */       switch (code) {
/*     */       case 78:
/* 239 */         return null;
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/*     */       case 22:
/*     */       case 23:
/*     */       case 24:
/*     */       case 25:
/*     */       case 26:
/*     */       case 27:
/*     */       case 28:
/*     */       case 29:
/*     */       case 30:
/*     */       case 31:
/* 245 */         length = code - 16;
/* 246 */         in.readInt();
/*     */ 
/* 248 */         return readLengthList(in, length);
/*     */       case 32:
/*     */       case 33:
/*     */       case 34:
/*     */       case 35:
/*     */       case 36:
/*     */       case 37:
/*     */       case 38:
/*     */       case 39:
/*     */       case 40:
/*     */       case 41:
/*     */       case 42:
/*     */       case 43:
/*     */       case 44:
/*     */       case 45:
/*     */       case 46:
/*     */       case 47:
/*     */       case 48:
/*     */       case 49:
/*     */       case 50:
/*     */       case 51:
/*     */       case 52:
/*     */       case 53:
/*     */       case 54:
/*     */       case 55:
/*     */       case 56:
/*     */       case 57:
/*     */       case 58:
/*     */       case 59:
/*     */       case 60:
/*     */       case 61:
/*     */       case 62:
/*     */       case 63:
/*     */       case 64:
/*     */       case 65:
/*     */       case 66:
/*     */       case 67:
/*     */       case 68:
/*     */       case 69:
/*     */       case 70:
/*     */       case 71:
/*     */       case 72:
/*     */       case 73:
/*     */       case 74:
/*     */       case 75:
/*     */       case 76:
/* 251 */       case 77: } String type = in.readType();
/* 252 */       int length = in.readLength();
/*     */ 
/* 254 */       return readList(in, length);
/*     */     }
/*     */ 
/* 259 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object readList(AbstractHessianInput in, int length)
/*     */     throws IOException
/*     */   {
/* 266 */     switch (this._code) {
/*     */     case 14:
/* 268 */       if (length >= 0) {
/* 269 */         boolean[] data = new boolean[length];
/*     */ 
/* 271 */         in.addRef(data);
/*     */ 
/* 273 */         for (int i = 0; i < data.length; i++) {
/* 274 */           data[i] = in.readBoolean();
/*     */         }
/* 276 */         in.readEnd();
/*     */ 
/* 278 */         return data;
/*     */       }
/*     */ 
/* 281 */       ArrayList list = new ArrayList();
/*     */ 
/* 283 */       while (!in.isEnd()) {
/* 284 */         list.add(Boolean.valueOf(in.readBoolean()));
/*     */       }
/* 286 */       in.readEnd();
/*     */ 
/* 288 */       boolean[] data = new boolean[list.size()];
/*     */ 
/* 290 */       in.addRef(data);
/*     */ 
/* 292 */       for (int i = 0; i < data.length; i++) {
/* 293 */         data[i] = ((Boolean)list.get(i)).booleanValue();
/*     */       }
/* 295 */       return data;
/*     */     case 16:
/* 300 */       if (length >= 0) {
/* 301 */         short[] data = new short[length];
/*     */ 
/* 303 */         in.addRef(data);
/*     */ 
/* 305 */         for (int i = 0; i < data.length; i++) {
/* 306 */           data[i] = ((short)in.readInt());
/*     */         }
/* 308 */         in.readEnd();
/*     */ 
/* 310 */         return data;
/*     */       }
/*     */ 
/* 313 */       ArrayList list = new ArrayList();
/*     */ 
/* 315 */       while (!in.isEnd()) {
/* 316 */         list.add(Short.valueOf((short)in.readInt()));
/*     */       }
/* 318 */       in.readEnd();
/*     */ 
/* 320 */       short[] data = new short[list.size()];
/* 321 */       for (int i = 0; i < data.length; i++) {
/* 322 */         data[i] = ((Short)list.get(i)).shortValue();
/*     */       }
/* 324 */       in.addRef(data);
/*     */ 
/* 326 */       return data;
/*     */     case 17:
/* 331 */       if (length >= 0) {
/* 332 */         int[] data = new int[length];
/*     */ 
/* 334 */         in.addRef(data);
/*     */ 
/* 336 */         for (int i = 0; i < data.length; i++) {
/* 337 */           data[i] = in.readInt();
/*     */         }
/* 339 */         in.readEnd();
/*     */ 
/* 341 */         return data;
/*     */       }
/*     */ 
/* 344 */       ArrayList list = new ArrayList();
/*     */ 
/* 346 */       while (!in.isEnd()) {
/* 347 */         list.add(Integer.valueOf(in.readInt()));
/*     */       }
/*     */ 
/* 350 */       in.readEnd();
/*     */ 
/* 352 */       int[] data = new int[list.size()];
/* 353 */       for (int i = 0; i < data.length; i++) {
/* 354 */         data[i] = ((Integer)list.get(i)).intValue();
/*     */       }
/* 356 */       in.addRef(data);
/*     */ 
/* 358 */       return data;
/*     */     case 18:
/* 363 */       if (length >= 0) {
/* 364 */         long[] data = new long[length];
/*     */ 
/* 366 */         in.addRef(data);
/*     */ 
/* 368 */         for (int i = 0; i < data.length; i++) {
/* 369 */           data[i] = in.readLong();
/*     */         }
/* 371 */         in.readEnd();
/*     */ 
/* 373 */         return data;
/*     */       }
/*     */ 
/* 376 */       ArrayList list = new ArrayList();
/*     */ 
/* 378 */       while (!in.isEnd()) {
/* 379 */         list.add(Long.valueOf(in.readLong()));
/*     */       }
/* 381 */       in.readEnd();
/*     */ 
/* 383 */       long[] data = new long[list.size()];
/* 384 */       for (int i = 0; i < data.length; i++) {
/* 385 */         data[i] = ((Long)list.get(i)).longValue();
/*     */       }
/* 387 */       in.addRef(data);
/*     */ 
/* 389 */       return data;
/*     */     case 19:
/* 394 */       if (length >= 0) {
/* 395 */         float[] data = new float[length];
/* 396 */         in.addRef(data);
/*     */ 
/* 398 */         for (int i = 0; i < data.length; i++) {
/* 399 */           data[i] = ((float)in.readDouble());
/*     */         }
/* 401 */         in.readEnd();
/*     */ 
/* 403 */         return data;
/*     */       }
/*     */ 
/* 406 */       ArrayList list = new ArrayList();
/*     */ 
/* 408 */       while (!in.isEnd()) {
/* 409 */         list.add(new Float(in.readDouble()));
/*     */       }
/* 411 */       in.readEnd();
/*     */ 
/* 413 */       float[] data = new float[list.size()];
/* 414 */       for (int i = 0; i < data.length; i++) {
/* 415 */         data[i] = ((Float)list.get(i)).floatValue();
/*     */       }
/* 417 */       in.addRef(data);
/*     */ 
/* 419 */       return data;
/*     */     case 20:
/* 424 */       if (length >= 0) {
/* 425 */         double[] data = new double[length];
/* 426 */         in.addRef(data);
/*     */ 
/* 428 */         for (int i = 0; i < data.length; i++) {
/* 429 */           data[i] = in.readDouble();
/*     */         }
/* 431 */         in.readEnd();
/*     */ 
/* 433 */         return data;
/*     */       }
/*     */ 
/* 436 */       ArrayList list = new ArrayList();
/*     */ 
/* 438 */       while (!in.isEnd()) {
/* 439 */         list.add(new Double(in.readDouble()));
/*     */       }
/* 441 */       in.readEnd();
/*     */ 
/* 443 */       double[] data = new double[list.size()];
/* 444 */       in.addRef(data);
/* 445 */       for (int i = 0; i < data.length; i++) {
/* 446 */         data[i] = ((Double)list.get(i)).doubleValue();
/*     */       }
/* 448 */       return data;
/*     */     case 22:
/* 453 */       if (length >= 0) {
/* 454 */         String[] data = new String[length];
/* 455 */         in.addRef(data);
/*     */ 
/* 457 */         for (int i = 0; i < data.length; i++) {
/* 458 */           data[i] = in.readString();
/*     */         }
/* 460 */         in.readEnd();
/*     */ 
/* 462 */         return data;
/*     */       }
/*     */ 
/* 465 */       ArrayList list = new ArrayList();
/*     */ 
/* 467 */       while (!in.isEnd()) {
/* 468 */         list.add(in.readString());
/*     */       }
/* 470 */       in.readEnd();
/*     */ 
/* 472 */       String[] data = new String[list.size()];
/* 473 */       in.addRef(data);
/* 474 */       for (int i = 0; i < data.length; i++) {
/* 475 */         data[i] = ((String)list.get(i));
/*     */       }
/* 477 */       return data;
/*     */     case 23:
/* 482 */       if (length >= 0) {
/* 483 */         Object[] data = new Object[length];
/* 484 */         in.addRef(data);
/*     */ 
/* 486 */         for (int i = 0; i < data.length; i++) {
/* 487 */           data[i] = in.readObject();
/*     */         }
/* 489 */         in.readEnd();
/*     */ 
/* 491 */         return data;
/*     */       }
/*     */ 
/* 494 */       ArrayList list = new ArrayList();
/*     */ 
/* 496 */       in.addRef(list);
/*     */ 
/* 498 */       while (!in.isEnd()) {
/* 499 */         list.add(in.readObject());
/*     */       }
/* 501 */       in.readEnd();
/*     */ 
/* 503 */       Object[] data = new Object[list.size()];
/* 504 */       for (int i = 0; i < data.length; i++) {
/* 505 */         data[i] = list.get(i);
/*     */       }
/* 507 */       return data;
/*     */     case 15:
/*     */     case 21:
/*     */     }
/*     */ 
/* 512 */     throw new UnsupportedOperationException(String.valueOf(this));
/*     */   }
/*     */ 
/*     */   public Object readLengthList(AbstractHessianInput in, int length)
/*     */     throws IOException
/*     */   {
/* 519 */     switch (this._code) {
/*     */     case 14:
/* 521 */       boolean[] data = new boolean[length];
/*     */ 
/* 523 */       in.addRef(data);
/*     */ 
/* 525 */       for (int i = 0; i < data.length; i++) {
/* 526 */         data[i] = in.readBoolean();
/*     */       }
/* 528 */       return data;
/*     */     case 16:
/* 532 */       short[] data = new short[length];
/*     */ 
/* 534 */       in.addRef(data);
/*     */ 
/* 536 */       for (int i = 0; i < data.length; i++) {
/* 537 */         data[i] = ((short)in.readInt());
/*     */       }
/* 539 */       return data;
/*     */     case 17:
/* 543 */       int[] data = new int[length];
/*     */ 
/* 545 */       in.addRef(data);
/*     */ 
/* 547 */       for (int i = 0; i < data.length; i++) {
/* 548 */         data[i] = in.readInt();
/*     */       }
/* 550 */       return data;
/*     */     case 18:
/* 554 */       long[] data = new long[length];
/*     */ 
/* 556 */       in.addRef(data);
/*     */ 
/* 558 */       for (int i = 0; i < data.length; i++) {
/* 559 */         data[i] = in.readLong();
/*     */       }
/* 561 */       return data;
/*     */     case 19:
/* 565 */       float[] data = new float[length];
/* 566 */       in.addRef(data);
/*     */ 
/* 568 */       for (int i = 0; i < data.length; i++) {
/* 569 */         data[i] = ((float)in.readDouble());
/*     */       }
/* 571 */       return data;
/*     */     case 20:
/* 575 */       double[] data = new double[length];
/* 576 */       in.addRef(data);
/*     */ 
/* 578 */       for (int i = 0; i < data.length; i++) {
/* 579 */         data[i] = in.readDouble();
/*     */       }
/* 581 */       return data;
/*     */     case 22:
/* 585 */       String[] data = new String[length];
/* 586 */       in.addRef(data);
/*     */ 
/* 588 */       for (int i = 0; i < data.length; i++) {
/* 589 */         data[i] = in.readString();
/*     */       }
/* 591 */       return data;
/*     */     case 23:
/* 595 */       Object[] data = new Object[length];
/* 596 */       in.addRef(data);
/*     */ 
/* 598 */       for (int i = 0; i < data.length; i++) {
/* 599 */         data[i] = in.readObject();
/*     */       }
/* 601 */       return data;
/*     */     case 15:
/*     */     case 21:
/*     */     }
/* 605 */     throw new UnsupportedOperationException(String.valueOf(this));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.BasicDeserializer
 * JD-Core Version:    0.6.2
 */