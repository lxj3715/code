/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class BasicSerializer extends AbstractSerializer
/*    */ {
/*    */   public static final int NULL = 0;
/*    */   public static final int BOOLEAN = 1;
/*    */   public static final int BYTE = 2;
/*    */   public static final int SHORT = 3;
/*    */   public static final int INTEGER = 4;
/*    */   public static final int LONG = 5;
/*    */   public static final int FLOAT = 6;
/*    */   public static final int DOUBLE = 7;
/*    */   public static final int CHARACTER = 8;
/*    */   public static final int CHARACTER_OBJECT = 9;
/*    */   public static final int STRING = 10;
/*    */   public static final int DATE = 11;
/*    */   public static final int NUMBER = 12;
/*    */   public static final int OBJECT = 13;
/*    */   public static final int BOOLEAN_ARRAY = 14;
/*    */   public static final int BYTE_ARRAY = 15;
/*    */   public static final int SHORT_ARRAY = 16;
/*    */   public static final int INTEGER_ARRAY = 17;
/*    */   public static final int LONG_ARRAY = 18;
/*    */   public static final int FLOAT_ARRAY = 19;
/*    */   public static final int DOUBLE_ARRAY = 20;
/*    */   public static final int CHARACTER_ARRAY = 21;
/*    */   public static final int STRING_ARRAY = 22;
/*    */   public static final int OBJECT_ARRAY = 23;
/*    */   private int code;
/*    */ 
/*    */   public BasicSerializer(int code)
/*    */   {
/* 88 */     this.code = code;
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 94 */     switch (this.code) {
/*    */     case 1:
/* 96 */       out.writeBoolean(((Boolean)obj).booleanValue());
/* 97 */       break;
/*    */     case 2:
/*    */     case 3:
/*    */     case 4:
/* 102 */       out.writeInt(((Number)obj).intValue());
/* 103 */       break;
/*    */     case 5:
/* 106 */       out.writeLong(((Number)obj).longValue());
/* 107 */       break;
/*    */     case 6:
/*    */     case 7:
/* 111 */       out.writeDouble(((Number)obj).doubleValue());
/* 112 */       break;
/*    */     case 8:
/*    */     case 9:
/* 116 */       out.writeString(String.valueOf(obj));
/* 117 */       break;
/*    */     case 10:
/* 120 */       out.writeString((String)obj);
/* 121 */       break;
/*    */     case 11:
/* 124 */       out.writeUTCDate(((Date)obj).getTime());
/* 125 */       break;
/*    */     case 14:
/* 129 */       if (out.addRef(obj)) {
/* 130 */         return;
/*    */       }
/* 132 */       boolean[] data = (boolean[])obj;
/* 133 */       boolean hasEnd = out.writeListBegin(data.length, "[boolean");
/* 134 */       for (int i = 0; i < data.length; i++) {
/* 135 */         out.writeBoolean(data[i]);
/*    */       }
/* 137 */       if (hasEnd)
/* 138 */         out.writeListEnd(); break;
/*    */     case 15:
/* 145 */       byte[] data = (byte[])obj;
/* 146 */       out.writeBytes(data, 0, data.length);
/* 147 */       break;
/*    */     case 16:
/* 152 */       if (out.addRef(obj)) {
/* 153 */         return;
/*    */       }
/* 155 */       short[] data = (short[])obj;
/* 156 */       boolean hasEnd = out.writeListBegin(data.length, "[short");
/*    */ 
/* 158 */       for (int i = 0; i < data.length; i++) {
/* 159 */         out.writeInt(data[i]);
/*    */       }
/* 161 */       if (hasEnd)
/* 162 */         out.writeListEnd(); break;
/*    */     case 17:
/* 168 */       if (out.addRef(obj)) {
/* 169 */         return;
/*    */       }
/* 171 */       int[] data = (int[])obj;
/*    */ 
/* 173 */       boolean hasEnd = out.writeListBegin(data.length, "[int");
/*    */ 
/* 175 */       for (int i = 0; i < data.length; i++) {
/* 176 */         out.writeInt(data[i]);
/*    */       }
/* 178 */       if (hasEnd)
/* 179 */         out.writeListEnd(); break;
/*    */     case 18:
/* 186 */       if (out.addRef(obj)) {
/* 187 */         return;
/*    */       }
/* 189 */       long[] data = (long[])obj;
/*    */ 
/* 191 */       boolean hasEnd = out.writeListBegin(data.length, "[long");
/*    */ 
/* 193 */       for (int i = 0; i < data.length; i++) {
/* 194 */         out.writeLong(data[i]);
/*    */       }
/* 196 */       if (hasEnd)
/* 197 */         out.writeListEnd(); break;
/*    */     case 19:
/* 203 */       if (out.addRef(obj)) {
/* 204 */         return;
/*    */       }
/* 206 */       float[] data = (float[])obj;
/*    */ 
/* 208 */       boolean hasEnd = out.writeListBegin(data.length, "[float");
/*    */ 
/* 210 */       for (int i = 0; i < data.length; i++) {
/* 211 */         out.writeDouble(data[i]);
/*    */       }
/* 213 */       if (hasEnd)
/* 214 */         out.writeListEnd(); break;
/*    */     case 20:
/* 220 */       if (out.addRef(obj)) {
/* 221 */         return;
/*    */       }
/* 223 */       double[] data = (double[])obj;
/* 224 */       boolean hasEnd = out.writeListBegin(data.length, "[double");
/*    */ 
/* 226 */       for (int i = 0; i < data.length; i++) {
/* 227 */         out.writeDouble(data[i]);
/*    */       }
/* 229 */       if (hasEnd)
/* 230 */         out.writeListEnd(); break;
/*    */     case 22:
/* 236 */       if (out.addRef(obj)) {
/* 237 */         return;
/*    */       }
/* 239 */       String[] data = (String[])obj;
/*    */ 
/* 241 */       boolean hasEnd = out.writeListBegin(data.length, "[string");
/*    */ 
/* 243 */       for (int i = 0; i < data.length; i++) {
/* 244 */         out.writeString(data[i]);
/*    */       }
/*    */ 
/* 247 */       if (hasEnd)
/* 248 */         out.writeListEnd(); break;
/*    */     case 21:
/* 254 */       char[] data = (char[])obj;
/* 255 */       out.writeString(data, 0, data.length);
/* 256 */       break;
/*    */     case 23:
/* 261 */       if (out.addRef(obj)) {
/* 262 */         return;
/*    */       }
/* 264 */       Object[] data = (Object[])obj;
/*    */ 
/* 266 */       boolean hasEnd = out.writeListBegin(data.length, "[object");
/*    */ 
/* 268 */       for (int i = 0; i < data.length; i++) {
/* 269 */         out.writeObject(data[i]);
/*    */       }
/*    */ 
/* 272 */       if (hasEnd)
/* 273 */         out.writeListEnd(); break;
/*    */     case 0:
/* 278 */       out.writeNull();
/* 279 */       break;
/*    */     case 12:
/*    */     case 13:
/*    */     default:
/* 282 */       throw new RuntimeException(this.code + " " + String.valueOf(obj.getClass()));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.BasicSerializer
 * JD-Core Version:    0.6.2
 */