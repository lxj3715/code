/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class BeanDeserializer extends AbstractMapDeserializer
/*     */ {
/*     */   private Class _type;
/*     */   private HashMap _methodMap;
/*     */   private Method _readResolve;
/*     */   private Constructor _constructor;
/*     */   private Object[] _constructorArgs;
/*     */ 
/*     */   public BeanDeserializer(Class cl)
/*     */   {
/*  69 */     this._type = cl;
/*  70 */     this._methodMap = getMethodMap(cl);
/*     */ 
/*  72 */     this._readResolve = getReadResolve(cl);
/*     */ 
/*  74 */     Constructor[] constructors = cl.getConstructors();
/*  75 */     int bestLength = 2147483647;
/*     */ 
/*  77 */     for (int i = 0; i < constructors.length; i++) {
/*  78 */       if (constructors[i].getParameterTypes().length < bestLength) {
/*  79 */         this._constructor = constructors[i];
/*  80 */         bestLength = this._constructor.getParameterTypes().length;
/*     */       }
/*     */     }
/*     */ 
/*  84 */     if (this._constructor != null) {
/*  85 */       this._constructor.setAccessible(true);
/*  86 */       Class[] params = this._constructor.getParameterTypes();
/*  87 */       this._constructorArgs = new Object[params.length];
/*  88 */       for (int i = 0; i < params.length; i++)
/*  89 */         this._constructorArgs[i] = getParamArg(params[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  96 */     return this._type;
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 103 */       Object obj = instantiate();
/*     */ 
/* 105 */       return readMap(in, obj);
/*     */     } catch (IOException e) {
/* 107 */       throw e;
/*     */     } catch (Exception e) {
/* 109 */       throw new IOExceptionWrapper(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in, Object obj) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       int ref = in.addRef(obj);
/*     */       Object value;
/* 119 */       while (!in.isEnd()) {
/* 120 */         Object key = in.readObject();
/*     */ 
/* 122 */         Method method = (Method)this._methodMap.get(key);
/*     */ 
/* 124 */         if (method != null) {
/* 125 */           Object value = in.readObject(method.getParameterTypes()[0]);
/*     */ 
/* 127 */           method.invoke(obj, new Object[] { value });
/*     */         }
/*     */         else {
/* 130 */           value = in.readObject();
/*     */         }
/*     */       }
/*     */ 
/* 134 */       in.readMapEnd();
/*     */ 
/* 136 */       Object resolve = resolve(obj);
/*     */ 
/* 138 */       if (obj != resolve) {
/* 139 */         in.setRef(ref, resolve);
/*     */       }
/* 141 */       return resolve;
/*     */     } catch (IOException e) {
/* 143 */       throw e;
/*     */     } catch (Exception e) {
/* 145 */       throw new IOExceptionWrapper(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object resolve(Object obj)
/*     */   {
/*     */     try
/*     */     {
/* 153 */       if (this._readResolve != null)
/* 154 */         return this._readResolve.invoke(obj, new Object[0]);
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 158 */     return obj;
/*     */   }
/*     */ 
/*     */   protected Object instantiate()
/*     */     throws Exception
/*     */   {
/* 164 */     return this._constructor.newInstance(this._constructorArgs);
/*     */   }
/*     */ 
/*     */   protected Method getReadResolve(Class cl)
/*     */   {
/* 172 */     for (; cl != null; cl = cl.getSuperclass()) {
/* 173 */       Method[] methods = cl.getDeclaredMethods();
/*     */ 
/* 175 */       for (int i = 0; i < methods.length; i++) {
/* 176 */         Method method = methods[i];
/*     */ 
/* 178 */         if ((method.getName().equals("readResolve")) && (method.getParameterTypes().length == 0))
/*     */         {
/* 180 */           return method;
/*     */         }
/*     */       }
/*     */     }
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */   protected HashMap getMethodMap(Class cl)
/*     */   {
/* 192 */     HashMap methodMap = new HashMap();
/*     */ 
/* 194 */     for (; cl != null; cl = cl.getSuperclass()) {
/* 195 */       Method[] methods = cl.getDeclaredMethods();
/*     */ 
/* 197 */       for (int i = 0; i < methods.length; i++) {
/* 198 */         Method method = methods[i];
/*     */ 
/* 200 */         if (!Modifier.isStatic(method.getModifiers()))
/*     */         {
/* 203 */           String name = method.getName();
/*     */ 
/* 205 */           if (name.startsWith("set"))
/*     */           {
/* 208 */             Class[] paramTypes = method.getParameterTypes();
/* 209 */             if (paramTypes.length == 1)
/*     */             {
/* 212 */               if (method.getReturnType().equals(Void.TYPE))
/*     */               {
/* 215 */                 if (findGetter(methods, name, paramTypes[0]) != null)
/*     */                 {
/*     */                   try
/*     */                   {
/* 220 */                     method.setAccessible(true);
/*     */                   } catch (Throwable e) {
/* 222 */                     e.printStackTrace();
/*     */                   }
/*     */ 
/* 225 */                   name = name.substring(3);
/*     */ 
/* 227 */                   int j = 0;
/* 228 */                   while ((j < name.length()) && (Character.isUpperCase(name.charAt(j)))) j++;
/*     */ 
/* 231 */                   if (j == 1)
/* 232 */                     name = name.substring(0, j).toLowerCase() + name.substring(j);
/* 233 */                   else if (j > 1) {
/* 234 */                     name = name.substring(0, j - 1).toLowerCase() + name.substring(j - 1);
/*     */                   }
/*     */ 
/* 237 */                   methodMap.put(name, method);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 241 */     return methodMap;
/*     */   }
/*     */ 
/*     */   private Method findGetter(Method[] methods, String setterName, Class arg)
/*     */   {
/* 249 */     String getterName = "get" + setterName.substring(3);
/*     */ 
/* 251 */     for (int i = 0; i < methods.length; i++) {
/* 252 */       Method method = methods[i];
/*     */ 
/* 254 */       if (method.getName().equals(getterName))
/*     */       {
/* 257 */         if (method.getReturnType().equals(arg))
/*     */         {
/* 260 */           Class[] params = method.getParameterTypes();
/*     */ 
/* 262 */           if (params.length == 0)
/* 263 */             return method; 
/*     */         }
/*     */       }
/*     */     }
/* 266 */     return null;
/*     */   }
/*     */ 
/*     */   protected static Object getParamArg(Class cl)
/*     */   {
/* 274 */     if (!cl.isPrimitive())
/* 275 */       return null;
/* 276 */     if (Boolean.TYPE.equals(cl))
/* 277 */       return Boolean.FALSE;
/* 278 */     if (Byte.TYPE.equals(cl))
/* 279 */       return Byte.valueOf((byte)0);
/* 280 */     if (Short.TYPE.equals(cl))
/* 281 */       return Short.valueOf((short)0);
/* 282 */     if (Character.TYPE.equals(cl))
/* 283 */       return Character.valueOf('\000');
/* 284 */     if (Integer.TYPE.equals(cl))
/* 285 */       return Integer.valueOf(0);
/* 286 */     if (Long.TYPE.equals(cl))
/* 287 */       return Long.valueOf(0L);
/* 288 */     if (Float.TYPE.equals(cl))
/* 289 */       return Double.valueOf(0.0D);
/* 290 */     if (Double.TYPE.equals(cl)) {
/* 291 */       return Double.valueOf(0.0D);
/*     */     }
/* 293 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.BeanDeserializer
 * JD-Core Version:    0.6.2
 */