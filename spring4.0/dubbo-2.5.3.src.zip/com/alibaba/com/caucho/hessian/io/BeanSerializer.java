/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class BeanSerializer extends AbstractSerializer
/*     */ {
/*  63 */   private static final Logger log = Logger.getLogger(BeanSerializer.class.getName());
/*     */ 
/*  66 */   private static final Object[] NULL_ARGS = new Object[0];
/*     */   private Method[] _methods;
/*     */   private String[] _names;
/*     */   private Object _writeReplaceFactory;
/*     */   private Method _writeReplace;
/*     */ 
/*     */   public BeanSerializer(Class cl, ClassLoader loader)
/*     */   {
/*  75 */     introspectWriteReplace(cl, loader);
/*     */ 
/*  77 */     ArrayList primitiveMethods = new ArrayList();
/*  78 */     ArrayList compoundMethods = new ArrayList();
/*     */ 
/*  80 */     for (; cl != null; cl = cl.getSuperclass()) {
/*  81 */       Method[] methods = cl.getDeclaredMethods();
/*     */ 
/*  83 */       for (int i = 0; i < methods.length; i++) {
/*  84 */         Method method = methods[i];
/*     */ 
/*  86 */         if (!Modifier.isStatic(method.getModifiers()))
/*     */         {
/*  89 */           if (method.getParameterTypes().length == 0)
/*     */           {
/*  92 */             String name = method.getName();
/*     */ 
/*  94 */             if (name.startsWith("get"))
/*     */             {
/*  97 */               Class type = method.getReturnType();
/*     */ 
/*  99 */               if (!type.equals(Void.TYPE))
/*     */               {
/* 102 */                 if (findSetter(methods, name, type) != null)
/*     */                 {
/* 106 */                   method.setAccessible(true);
/*     */ 
/* 108 */                   if ((type.isPrimitive()) || ((type.getName().startsWith("java.lang.")) && (!type.equals(Object.class))))
/*     */                   {
/* 111 */                     primitiveMethods.add(method);
/*     */                   }
/* 113 */                   else compoundMethods.add(method); 
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 117 */     ArrayList methodList = new ArrayList();
/* 118 */     methodList.addAll(primitiveMethods);
/* 119 */     methodList.addAll(compoundMethods);
/*     */ 
/* 121 */     Collections.sort(methodList, new MethodNameCmp());
/*     */ 
/* 123 */     this._methods = new Method[methodList.size()];
/* 124 */     methodList.toArray(this._methods);
/*     */ 
/* 126 */     this._names = new String[this._methods.length];
/*     */ 
/* 128 */     for (int i = 0; i < this._methods.length; i++) {
/* 129 */       String name = this._methods[i].getName();
/*     */ 
/* 131 */       name = name.substring(3);
/*     */ 
/* 133 */       int j = 0;
/* 134 */       while ((j < name.length()) && (Character.isUpperCase(name.charAt(j)))) j++;
/*     */ 
/* 137 */       if (j == 1)
/* 138 */         name = name.substring(0, j).toLowerCase() + name.substring(j);
/* 139 */       else if (j > 1) {
/* 140 */         name = name.substring(0, j - 1).toLowerCase() + name.substring(j - 1);
/*     */       }
/* 142 */       this._names[i] = name;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void introspectWriteReplace(Class cl, ClassLoader loader)
/*     */   {
/*     */     try {
/* 149 */       String className = cl.getName() + "HessianSerializer";
/*     */ 
/* 151 */       Class serializerClass = Class.forName(className, false, loader);
/*     */ 
/* 153 */       Object serializerObject = serializerClass.newInstance();
/*     */ 
/* 155 */       Method writeReplace = getWriteReplace(serializerClass, cl);
/*     */ 
/* 157 */       if (writeReplace != null) {
/* 158 */         this._writeReplaceFactory = serializerObject;
/* 159 */         this._writeReplace = writeReplace;
/*     */ 
/* 161 */         return;
/*     */       }
/*     */     } catch (ClassNotFoundException e) {
/*     */     } catch (Exception e) {
/* 165 */       log.log(Level.FINER, e.toString(), e);
/*     */     }
/*     */ 
/* 168 */     this._writeReplace = getWriteReplace(cl);
/*     */   }
/*     */ 
/*     */   protected Method getWriteReplace(Class cl)
/*     */   {
/* 176 */     for (; cl != null; cl = cl.getSuperclass()) {
/* 177 */       Method[] methods = cl.getDeclaredMethods();
/*     */ 
/* 179 */       for (int i = 0; i < methods.length; i++) {
/* 180 */         Method method = methods[i];
/*     */ 
/* 182 */         if ((method.getName().equals("writeReplace")) && (method.getParameterTypes().length == 0))
/*     */         {
/* 184 */           return method;
/*     */         }
/*     */       }
/*     */     }
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */   protected Method getWriteReplace(Class cl, Class param)
/*     */   {
/* 196 */     for (; cl != null; cl = cl.getSuperclass()) {
/* 197 */       for (Method method : cl.getDeclaredMethods()) {
/* 198 */         if ((method.getName().equals("writeReplace")) && (method.getParameterTypes().length == 1) && (param.equals(method.getParameterTypes()[0])))
/*     */         {
/* 201 */           return method;
/*     */         }
/*     */       }
/*     */     }
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   public void writeObject(Object obj, AbstractHessianOutput out)
/*     */     throws IOException
/*     */   {
/* 211 */     if (out.addRef(obj)) {
/* 212 */       return;
/*     */     }
/* 214 */     Class cl = obj.getClass();
/*     */     try
/*     */     {
/* 217 */       if (this._writeReplace != null)
/*     */       {
/*     */         Object repl;
/*     */         Object repl;
/* 220 */         if (this._writeReplaceFactory != null)
/* 221 */           repl = this._writeReplace.invoke(this._writeReplaceFactory, new Object[] { obj });
/*     */         else {
/* 223 */           repl = this._writeReplace.invoke(obj, new Object[0]);
/*     */         }
/* 225 */         out.removeRef(obj);
/*     */ 
/* 227 */         out.writeObject(repl);
/*     */ 
/* 229 */         out.replaceRef(repl, obj);
/*     */ 
/* 231 */         return;
/*     */       }
/*     */     } catch (Exception e) {
/* 234 */       log.log(Level.FINER, e.toString(), e);
/*     */     }
/*     */ 
/* 237 */     int ref = out.writeObjectBegin(cl.getName());
/*     */ 
/* 239 */     if (ref < -1)
/*     */     {
/* 242 */       for (int i = 0; i < this._methods.length; i++) {
/* 243 */         Method method = this._methods[i];
/* 244 */         Object value = null;
/*     */         try
/*     */         {
/* 247 */           value = this._methods[i].invoke(obj, (Object[])null);
/*     */         } catch (Exception e) {
/* 249 */           log.log(Level.FINE, e.toString(), e);
/*     */         }
/*     */ 
/* 252 */         out.writeString(this._names[i]);
/*     */ 
/* 254 */         out.writeObject(value);
/*     */       }
/*     */ 
/* 257 */       out.writeMapEnd();
/*     */     }
/*     */     else {
/* 260 */       if (ref == -1) {
/* 261 */         out.writeInt(this._names.length);
/*     */ 
/* 263 */         for (int i = 0; i < this._names.length; i++) {
/* 264 */           out.writeString(this._names[i]);
/*     */         }
/* 266 */         out.writeObjectBegin(cl.getName());
/*     */       }
/*     */ 
/* 269 */       for (int i = 0; i < this._methods.length; i++) {
/* 270 */         Method method = this._methods[i];
/* 271 */         Object value = null;
/*     */         try
/*     */         {
/* 274 */           value = this._methods[i].invoke(obj, (Object[])null);
/*     */         } catch (Exception e) {
/* 276 */           log.log(Level.FINER, e.toString(), e);
/*     */         }
/*     */ 
/* 279 */         out.writeObject(value);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Method findSetter(Method[] methods, String getterName, Class arg)
/*     */   {
/* 289 */     String setterName = "set" + getterName.substring(3);
/*     */ 
/* 291 */     for (int i = 0; i < methods.length; i++) {
/* 292 */       Method method = methods[i];
/*     */ 
/* 294 */       if (method.getName().equals(setterName))
/*     */       {
/* 297 */         if (method.getReturnType().equals(Void.TYPE))
/*     */         {
/* 300 */           Class[] params = method.getParameterTypes();
/*     */ 
/* 302 */           if ((params.length == 1) && (params[0].equals(arg)))
/* 303 */             return method; 
/*     */         }
/*     */       }
/*     */     }
/* 306 */     return null;
/*     */   }
/*     */ 
/*     */   static class MethodNameCmp implements Comparator<Method>
/*     */   {
/*     */     public int compare(Method a, Method b) {
/* 312 */       return a.getName().compareTo(b.getName());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.BeanSerializer
 * JD-Core Version:    0.6.2
 */