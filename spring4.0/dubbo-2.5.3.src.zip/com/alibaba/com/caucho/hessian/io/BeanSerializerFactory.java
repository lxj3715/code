/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ public class BeanSerializerFactory extends SerializerFactory
/*    */ {
/*    */   protected Serializer getDefaultSerializer(Class cl)
/*    */   {
/* 66 */     return new BeanSerializer(cl, getClassLoader());
/*    */   }
/*    */ 
/*    */   protected Deserializer getDefaultDeserializer(Class cl)
/*    */   {
/* 80 */     return new BeanDeserializer(cl);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.BeanSerializerFactory
 * JD-Core Version:    0.6.2
 */