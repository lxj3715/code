/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class BigIntegerDeserializer extends JavaDeserializer
/*    */ {
/*    */   public BigIntegerDeserializer()
/*    */   {
/* 11 */     super(BigInteger.class);
/*    */   }
/*    */ 
/*    */   protected Object instantiate() throws Exception
/*    */   {
/* 16 */     return new BigInteger("0");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.BigIntegerDeserializer
 * JD-Core Version:    0.6.2
 */