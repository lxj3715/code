/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.GregorianCalendar;
/*    */ 
/*    */ public class CalendarHandle
/*    */   implements Serializable, HessianHandle
/*    */ {
/*    */   private Class type;
/*    */   private Date date;
/*    */ 
/*    */   public CalendarHandle()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CalendarHandle(Class type, long time)
/*    */   {
/* 68 */     if (!GregorianCalendar.class.equals(type)) {
/* 69 */       this.type = type;
/*    */     }
/* 71 */     this.date = new Date(time);
/*    */   }
/*    */ 
/*    */   private Object readResolve()
/*    */   {
/*    */     try
/*    */     {
/*    */       Calendar cal;
/*    */       Calendar cal;
/* 79 */       if (this.type != null)
/* 80 */         cal = (Calendar)this.type.newInstance();
/*    */       else {
/* 82 */         cal = new GregorianCalendar();
/*    */       }
/* 84 */       cal.setTimeInMillis(this.date.getTime());
/*    */ 
/* 86 */       return cal;
/*    */     } catch (RuntimeException e) {
/* 88 */       throw e;
/*    */     } catch (Exception e) {
/* 90 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.CalendarHandle
 * JD-Core Version:    0.6.2
 */