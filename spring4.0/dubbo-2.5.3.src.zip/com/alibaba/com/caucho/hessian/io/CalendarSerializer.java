/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class CalendarSerializer extends AbstractSerializer
/*    */ {
/* 58 */   private static CalendarSerializer SERIALIZER = new CalendarSerializer();
/*    */ 
/*    */   public static CalendarSerializer create()
/*    */   {
/* 62 */     return SERIALIZER;
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 68 */     if (obj == null) {
/* 69 */       out.writeNull();
/*    */     } else {
/* 71 */       Calendar cal = (Calendar)obj;
/*    */ 
/* 73 */       out.writeObject(new CalendarHandle(cal.getClass(), cal.getTimeInMillis()));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.CalendarSerializer
 * JD-Core Version:    0.6.2
 */