/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class ClassDeserializer extends AbstractMapDeserializer
/*     */ {
/*  58 */   private static final HashMap<String, Class> _primClasses = new HashMap();
/*     */   private ClassLoader _loader;
/*     */ 
/*     */   public ClassDeserializer(ClassLoader loader)
/*     */   {
/*  65 */     this._loader = loader;
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  70 */     return Class.class;
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in)
/*     */     throws IOException
/*     */   {
/*  76 */     int ref = in.addRef(null);
/*     */ 
/*  78 */     String name = null;
/*     */ 
/*  80 */     while (!in.isEnd()) {
/*  81 */       String key = in.readString();
/*     */ 
/*  83 */       if (key.equals("name"))
/*  84 */         name = in.readString();
/*     */       else {
/*  86 */         in.readObject();
/*     */       }
/*     */     }
/*  89 */     in.readMapEnd();
/*     */ 
/*  91 */     Object value = create(name);
/*     */ 
/*  93 */     in.setRef(ref, value);
/*     */ 
/*  95 */     return value;
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, String[] fieldNames)
/*     */     throws IOException
/*     */   {
/* 101 */     int ref = in.addRef(null);
/*     */ 
/* 103 */     String name = null;
/*     */ 
/* 105 */     for (int i = 0; i < fieldNames.length; i++) {
/* 106 */       if ("name".equals(fieldNames[i]))
/* 107 */         name = in.readString();
/*     */       else {
/* 109 */         in.readObject();
/*     */       }
/*     */     }
/* 112 */     Object value = create(name);
/*     */ 
/* 114 */     in.setRef(ref, value);
/*     */ 
/* 116 */     return value;
/*     */   }
/*     */ 
/*     */   Object create(String name)
/*     */     throws IOException
/*     */   {
/* 122 */     if (name == null) {
/* 123 */       throw new IOException("Serialized Class expects name.");
/*     */     }
/* 125 */     Class cl = (Class)_primClasses.get(name);
/*     */ 
/* 127 */     if (cl != null)
/* 128 */       return cl;
/*     */     try
/*     */     {
/* 131 */       if (this._loader != null) {
/* 132 */         return Class.forName(name, false, this._loader);
/*     */       }
/* 134 */       return Class.forName(name);
/*     */     } catch (Exception e) {
/* 136 */       throw new IOExceptionWrapper(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   static {
/* 141 */     _primClasses.put("void", Void.TYPE);
/* 142 */     _primClasses.put("boolean", Boolean.TYPE);
/* 143 */     _primClasses.put("java.lang.Boolean", Boolean.class);
/* 144 */     _primClasses.put("byte", Byte.TYPE);
/* 145 */     _primClasses.put("java.lang.Byte", Byte.class);
/* 146 */     _primClasses.put("char", Character.TYPE);
/* 147 */     _primClasses.put("java.lang.Character", Character.class);
/* 148 */     _primClasses.put("short", Short.TYPE);
/* 149 */     _primClasses.put("java.lang.Short", Short.class);
/* 150 */     _primClasses.put("int", Integer.TYPE);
/* 151 */     _primClasses.put("java.lang.Integer", Integer.class);
/* 152 */     _primClasses.put("long", Long.TYPE);
/* 153 */     _primClasses.put("java.lang.Long", Long.class);
/* 154 */     _primClasses.put("float", Float.TYPE);
/* 155 */     _primClasses.put("java.lang.Float", Float.class);
/* 156 */     _primClasses.put("double", Double.TYPE);
/* 157 */     _primClasses.put("java.lang.Double", Double.class);
/* 158 */     _primClasses.put("java.lang.String", String.class);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.ClassDeserializer
 * JD-Core Version:    0.6.2
 */