/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class ClassSerializer extends AbstractSerializer
/*    */ {
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 60 */     Class cl = (Class)obj;
/*    */ 
/* 62 */     if (cl == null) {
/* 63 */       out.writeNull();
/*    */     } else {
/* 65 */       if (out.addRef(obj)) {
/* 66 */         return;
/*    */       }
/*    */ 
/* 69 */       int ref = out.writeObjectBegin("java.lang.Class");
/*    */ 
/* 71 */       if (ref < -1) {
/* 72 */         out.writeString("name");
/* 73 */         out.writeString(cl.getName());
/* 74 */         out.writeMapEnd();
/*    */       }
/*    */       else {
/* 77 */         if (ref == -1) {
/* 78 */           out.writeInt(1);
/* 79 */           out.writeString("name");
/* 80 */           out.writeObjectBegin("java.lang.Class");
/*    */         }
/*    */ 
/* 83 */         out.writeString(cl.getName());
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.ClassSerializer
 * JD-Core Version:    0.6.2
 */