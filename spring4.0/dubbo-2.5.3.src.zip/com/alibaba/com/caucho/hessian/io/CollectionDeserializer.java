/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ public class CollectionDeserializer extends AbstractListDeserializer
/*     */ {
/*     */   private Class _type;
/*     */ 
/*     */   public CollectionDeserializer(Class type)
/*     */   {
/*  62 */     this._type = type;
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  67 */     return this._type;
/*     */   }
/*     */ 
/*     */   public Object readList(AbstractHessianInput in, int length)
/*     */     throws IOException
/*     */   {
/*  73 */     Collection list = createList();
/*     */ 
/*  75 */     in.addRef(list);
/*     */ 
/*  77 */     while (!in.isEnd()) {
/*  78 */       list.add(in.readObject());
/*     */     }
/*  80 */     in.readEnd();
/*     */ 
/*  82 */     return list;
/*     */   }
/*     */ 
/*     */   public Object readLengthList(AbstractHessianInput in, int length)
/*     */     throws IOException
/*     */   {
/*  88 */     Collection list = createList();
/*     */ 
/*  90 */     in.addRef(list);
/*     */ 
/*  92 */     for (; length > 0; length--) {
/*  93 */       list.add(in.readObject());
/*     */     }
/*  95 */     return list;
/*     */   }
/*     */ 
/*     */   private Collection createList()
/*     */     throws IOException
/*     */   {
/* 101 */     Collection list = null;
/*     */ 
/* 103 */     if (this._type == null)
/* 104 */       list = new ArrayList();
/* 105 */     else if (!this._type.isInterface())
/*     */       try {
/* 107 */         list = (Collection)this._type.newInstance();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/* 112 */     if (list == null)
/*     */     {
/* 114 */       if (SortedSet.class.isAssignableFrom(this._type))
/* 115 */         list = new TreeSet();
/* 116 */       else if (Set.class.isAssignableFrom(this._type))
/* 117 */         list = new HashSet();
/* 118 */       else if (List.class.isAssignableFrom(this._type))
/* 119 */         list = new ArrayList();
/* 120 */       else if (Collection.class.isAssignableFrom(this._type))
/* 121 */         list = new ArrayList();
/*     */       else {
/*     */         try {
/* 124 */           list = (Collection)this._type.newInstance();
/*     */         } catch (Exception e) {
/* 126 */           throw new IOExceptionWrapper(e);
/*     */         }
/*     */       }
/*     */     }
/* 130 */     return list;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.CollectionDeserializer
 * JD-Core Version:    0.6.2
 */