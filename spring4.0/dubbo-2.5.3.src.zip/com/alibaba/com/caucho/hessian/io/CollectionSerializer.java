/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class CollectionSerializer extends AbstractSerializer
/*     */ {
/*  62 */   private boolean _sendJavaType = true;
/*     */ 
/*     */   public void setSendJavaType(boolean sendJavaType)
/*     */   {
/*  69 */     this._sendJavaType = sendJavaType;
/*     */   }
/*     */ 
/*     */   public boolean getSendJavaType()
/*     */   {
/*  77 */     return this._sendJavaType;
/*     */   }
/*     */ 
/*     */   public void writeObject(Object obj, AbstractHessianOutput out)
/*     */     throws IOException
/*     */   {
/*  83 */     if (out.addRef(obj)) {
/*  84 */       return;
/*     */     }
/*  86 */     Collection list = (Collection)obj;
/*     */ 
/*  88 */     Class cl = obj.getClass();
/*     */     boolean hasEnd;
/*     */     boolean hasEnd;
/*  91 */     if ((cl.equals(ArrayList.class)) || (!this._sendJavaType) || (!Serializable.class.isAssignableFrom(cl)))
/*     */     {
/*  94 */       hasEnd = out.writeListBegin(list.size(), null);
/*     */     }
/*  96 */     else hasEnd = out.writeListBegin(list.size(), obj.getClass().getName());
/*     */ 
/*  98 */     Iterator iter = list.iterator();
/*  99 */     while (iter.hasNext()) {
/* 100 */       Object value = iter.next();
/*     */ 
/* 102 */       out.writeObject(value);
/*     */     }
/*     */ 
/* 105 */     if (hasEnd)
/* 106 */       out.writeListEnd();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.CollectionSerializer
 * JD-Core Version:    0.6.2
 */