/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.DeflaterOutputStream;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ 
/*     */ public class Deflation extends HessianEnvelope
/*     */ {
/*     */   public Hessian2Output wrap(Hessian2Output out)
/*     */     throws IOException
/*     */   {
/*  66 */     OutputStream os = new DeflateOutputStream(out);
/*     */ 
/*  68 */     Hessian2Output filterOut = new Hessian2Output(os);
/*     */ 
/*  70 */     filterOut.setCloseStreamOnClose(true);
/*     */ 
/*  72 */     return filterOut;
/*     */   }
/*     */ 
/*     */   public Hessian2Input unwrap(Hessian2Input in)
/*     */     throws IOException
/*     */   {
/*  78 */     int version = in.readEnvelope();
/*     */ 
/*  80 */     String method = in.readMethod();
/*     */ 
/*  82 */     if (!method.equals(getClass().getName())) {
/*  83 */       throw new IOException("expected hessian Envelope method '" + getClass().getName() + "' at '" + method + "'");
/*     */     }
/*     */ 
/*  86 */     return unwrapHeaders(in);
/*     */   }
/*     */ 
/*     */   public Hessian2Input unwrapHeaders(Hessian2Input in)
/*     */     throws IOException
/*     */   {
/*  92 */     InputStream is = new DeflateInputStream(in);
/*     */ 
/*  94 */     Hessian2Input filter = new Hessian2Input(is);
/*     */ 
/*  96 */     filter.setCloseStreamOnClose(true);
/*     */ 
/*  98 */     return filter;
/*     */   }
/*     */ 
/*     */   static class DeflateInputStream extends InputStream
/*     */   {
/*     */     private Hessian2Input _in;
/*     */     private InputStream _bodyIn;
/*     */     private InflaterInputStream _inflateIn;
/*     */ 
/*     */     DeflateInputStream(Hessian2Input in)
/*     */       throws IOException
/*     */     {
/* 160 */       this._in = in;
/*     */ 
/* 162 */       int len = in.readInt();
/*     */ 
/* 164 */       if (len != 0) {
/* 165 */         throw new IOException("expected no headers");
/*     */       }
/* 167 */       this._bodyIn = this._in.readInputStream();
/*     */ 
/* 169 */       this._inflateIn = new InflaterInputStream(this._bodyIn);
/*     */     }
/*     */ 
/*     */     public int read()
/*     */       throws IOException
/*     */     {
/* 175 */       return this._inflateIn.read();
/*     */     }
/*     */ 
/*     */     public int read(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 181 */       return this._inflateIn.read(buffer, offset, length);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 187 */       Hessian2Input in = this._in;
/* 188 */       this._in = null;
/*     */ 
/* 190 */       if (in != null) {
/* 191 */         this._inflateIn.close();
/* 192 */         this._bodyIn.close();
/*     */ 
/* 194 */         int len = in.readInt();
/*     */ 
/* 196 */         if (len != 0) {
/* 197 */           throw new IOException("Unexpected footer");
/*     */         }
/* 199 */         in.completeEnvelope();
/*     */ 
/* 201 */         in.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class DeflateOutputStream extends OutputStream
/*     */   {
/*     */     private Hessian2Output _out;
/*     */     private OutputStream _bodyOut;
/*     */     private DeflaterOutputStream _deflateOut;
/*     */ 
/*     */     DeflateOutputStream(Hessian2Output out)
/*     */       throws IOException
/*     */     {
/* 109 */       this._out = out;
/*     */ 
/* 111 */       this._out.startEnvelope(Deflation.class.getName());
/*     */ 
/* 113 */       this._out.writeInt(0);
/*     */ 
/* 115 */       this._bodyOut = this._out.getBytesOutputStream();
/*     */ 
/* 117 */       this._deflateOut = new DeflaterOutputStream(this._bodyOut);
/*     */     }
/*     */ 
/*     */     public void write(int ch)
/*     */       throws IOException
/*     */     {
/* 123 */       this._deflateOut.write(ch);
/*     */     }
/*     */ 
/*     */     public void write(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 129 */       this._deflateOut.write(buffer, offset, length);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 135 */       Hessian2Output out = this._out;
/* 136 */       this._out = null;
/*     */ 
/* 138 */       if (out != null) {
/* 139 */         this._deflateOut.close();
/* 140 */         this._bodyOut.close();
/*     */ 
/* 142 */         out.writeInt(0);
/*     */ 
/* 144 */         out.completeEnvelope();
/*     */ 
/* 146 */         out.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.Deflation
 * JD-Core Version:    0.6.2
 */