package com.alibaba.com.caucho.hessian.io;

import java.io.IOException;

public abstract interface Deserializer
{
  public abstract Class getType();

  public abstract Object readObject(AbstractHessianInput paramAbstractHessianInput)
    throws IOException;

  public abstract Object readList(AbstractHessianInput paramAbstractHessianInput, int paramInt)
    throws IOException;

  public abstract Object readLengthList(AbstractHessianInput paramAbstractHessianInput, int paramInt)
    throws IOException;

  public abstract Object readMap(AbstractHessianInput paramAbstractHessianInput)
    throws IOException;

  public abstract Object readObject(AbstractHessianInput paramAbstractHessianInput, String[] paramArrayOfString)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.Deserializer
 * JD-Core Version:    0.6.2
 */