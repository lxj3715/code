/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ public class EnumDeserializer extends AbstractDeserializer
/*     */ {
/*     */   private Class _enumType;
/*     */   private Method _valueOf;
/*     */ 
/*     */   public EnumDeserializer(Class cl)
/*     */   {
/*  64 */     if (cl.isEnum())
/*  65 */       this._enumType = cl;
/*  66 */     else if (cl.getSuperclass().isEnum())
/*  67 */       this._enumType = cl.getSuperclass();
/*     */     else
/*  69 */       throw new RuntimeException("Class " + cl.getName() + " is not an enum");
/*     */     try
/*     */     {
/*  72 */       this._valueOf = this._enumType.getMethod("valueOf", new Class[] { Class.class, String.class });
/*     */     }
/*     */     catch (Exception e) {
/*  75 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  81 */     return this._enumType;
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in)
/*     */     throws IOException
/*     */   {
/*  87 */     String name = null;
/*     */ 
/*  89 */     while (!in.isEnd()) {
/*  90 */       String key = in.readString();
/*     */ 
/*  92 */       if (key.equals("name"))
/*  93 */         name = in.readString();
/*     */       else {
/*  95 */         in.readObject();
/*     */       }
/*     */     }
/*  98 */     in.readMapEnd();
/*     */ 
/* 100 */     Object obj = create(name);
/*     */ 
/* 102 */     in.addRef(obj);
/*     */ 
/* 104 */     return obj;
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, String[] fieldNames)
/*     */     throws IOException
/*     */   {
/* 110 */     String name = null;
/*     */ 
/* 112 */     for (int i = 0; i < fieldNames.length; i++) {
/* 113 */       if ("name".equals(fieldNames[i]))
/* 114 */         name = in.readString();
/*     */       else {
/* 116 */         in.readObject();
/*     */       }
/*     */     }
/* 119 */     Object obj = create(name);
/*     */ 
/* 121 */     in.addRef(obj);
/*     */ 
/* 123 */     return obj;
/*     */   }
/*     */ 
/*     */   private Object create(String name)
/*     */     throws IOException
/*     */   {
/* 129 */     if (name == null)
/* 130 */       throw new IOException(this._enumType.getName() + " expects name.");
/*     */     try
/*     */     {
/* 133 */       return this._valueOf.invoke(null, new Object[] { this._enumType, name });
/*     */     } catch (Exception e) {
/* 135 */       throw new IOExceptionWrapper(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.EnumDeserializer
 * JD-Core Version:    0.6.2
 */