/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class EnumSerializer extends AbstractSerializer
/*    */ {
/*    */   private Method _name;
/*    */ 
/*    */   public EnumSerializer(Class cl)
/*    */   {
/* 63 */     if ((!cl.isEnum()) && (cl.getSuperclass().isEnum()))
/* 64 */       cl = cl.getSuperclass();
/*    */     try
/*    */     {
/* 67 */       this._name = cl.getMethod("name", new Class[0]);
/*    */     } catch (Exception e) {
/* 69 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 76 */     if (out.addRef(obj)) {
/* 77 */       return;
/*    */     }
/* 79 */     Class cl = obj.getClass();
/*    */ 
/* 81 */     if ((!cl.isEnum()) && (cl.getSuperclass().isEnum())) {
/* 82 */       cl = cl.getSuperclass();
/*    */     }
/* 84 */     String name = null;
/*    */     try {
/* 86 */       name = (String)this._name.invoke(obj, (Object[])null);
/*    */     } catch (Exception e) {
/* 88 */       throw new RuntimeException(e);
/*    */     }
/*    */ 
/* 91 */     int ref = out.writeObjectBegin(cl.getName());
/*    */ 
/* 93 */     if (ref < -1) {
/* 94 */       out.writeString("name");
/* 95 */       out.writeString(name);
/* 96 */       out.writeMapEnd();
/*    */     }
/*    */     else {
/* 99 */       if (ref == -1) {
/* 100 */         out.writeClassFieldLength(1);
/* 101 */         out.writeString("name");
/* 102 */         out.writeObjectBegin(cl.getName());
/*    */       }
/*    */ 
/* 105 */       out.writeString(name);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.EnumSerializer
 * JD-Core Version:    0.6.2
 */