/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class EnumerationDeserializer extends AbstractListDeserializer
/*    */ {
/*    */   private static EnumerationDeserializer _deserializer;
/*    */ 
/*    */   public static EnumerationDeserializer create()
/*    */   {
/* 62 */     if (_deserializer == null) {
/* 63 */       _deserializer = new EnumerationDeserializer();
/*    */     }
/* 65 */     return _deserializer;
/*    */   }
/*    */ 
/*    */   public Object readList(AbstractHessianInput in, int length)
/*    */     throws IOException
/*    */   {
/* 71 */     Vector list = new Vector();
/*    */ 
/* 73 */     in.addRef(list);
/*    */ 
/* 75 */     while (!in.isEnd()) {
/* 76 */       list.add(in.readObject());
/*    */     }
/* 78 */     in.readEnd();
/*    */ 
/* 80 */     return list.elements();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.EnumerationDeserializer
 * JD-Core Version:    0.6.2
 */