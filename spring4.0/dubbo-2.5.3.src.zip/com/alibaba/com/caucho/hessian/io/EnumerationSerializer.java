/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ public class EnumerationSerializer extends AbstractSerializer
/*    */ {
/*    */   private static EnumerationSerializer _serializer;
/*    */ 
/*    */   public static EnumerationSerializer create()
/*    */   {
/* 62 */     if (_serializer == null) {
/* 63 */       _serializer = new EnumerationSerializer();
/*    */     }
/* 65 */     return _serializer;
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 71 */     Enumeration iter = (Enumeration)obj;
/*    */ 
/* 73 */     boolean hasEnd = out.writeListBegin(-1, null);
/*    */ 
/* 75 */     while (iter.hasMoreElements()) {
/* 76 */       Object value = iter.nextElement();
/*    */ 
/* 78 */       out.writeObject(value);
/*    */     }
/*    */ 
/* 81 */     if (hasEnd)
/* 82 */       out.writeListEnd();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.EnumerationSerializer
 * JD-Core Version:    0.6.2
 */