/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class EnvelopeFactory
/*    */ {
/* 55 */   private static final Logger log = Logger.getLogger(EnvelopeFactory.class.getName());
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.EnvelopeFactory
 * JD-Core Version:    0.6.2
 */