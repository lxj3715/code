/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class ExtSerializerFactory extends AbstractSerializerFactory
/*     */ {
/*  57 */   private HashMap _serializerMap = new HashMap();
/*  58 */   private HashMap _deserializerMap = new HashMap();
/*     */ 
/*     */   public void addSerializer(Class cl, Serializer serializer)
/*     */   {
/*  68 */     this._serializerMap.put(cl, serializer);
/*     */   }
/*     */ 
/*     */   public void addDeserializer(Class cl, Deserializer deserializer)
/*     */   {
/*  79 */     this._deserializerMap.put(cl, deserializer);
/*     */   }
/*     */ 
/*     */   public Serializer getSerializer(Class cl)
/*     */     throws HessianProtocolException
/*     */   {
/*  92 */     return (Serializer)this._serializerMap.get(cl);
/*     */   }
/*     */ 
/*     */   public Deserializer getDeserializer(Class cl)
/*     */     throws HessianProtocolException
/*     */   {
/* 105 */     return (Deserializer)this._deserializerMap.get(cl);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.ExtSerializerFactory
 * JD-Core Version:    0.6.2
 */