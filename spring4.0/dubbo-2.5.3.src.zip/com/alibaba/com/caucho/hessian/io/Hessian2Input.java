/*      */ package com.alibaba.com.caucho.hessian.io;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ public class Hessian2Input extends AbstractHessianInput
/*      */   implements Hessian2Constants
/*      */ {
/*   78 */   private static final Logger log = Logger.getLogger(Hessian2Input.class.getName());
/*      */   private static final double D_256 = 0.00390625D;
/*      */   private static final int END_OF_DATA = -2;
/*      */   private static Field _detailMessageField;
/*      */   private static final int SIZE = 256;
/*      */   private static final int GAP = 16;
/*      */   protected SerializerFactory _serializerFactory;
/*      */   private static boolean _isCloseStreamOnClose;
/*      */   protected ArrayList _refs;
/*      */   protected ArrayList _classDefs;
/*      */   protected ArrayList _types;
/*      */   private InputStream _is;
/*  100 */   private final byte[] _buffer = new byte[256];
/*      */   private int _offset;
/*      */   private int _length;
/*      */   private boolean _isStreaming;
/*      */   private String _method;
/*      */   private int _argLength;
/*      */   private Reader _chunkReader;
/*      */   private InputStream _chunkInputStream;
/*      */   private Throwable _replyFault;
/*  118 */   private StringBuffer _sbuf = new StringBuffer();
/*      */   private boolean _isLastChunk;
/*      */   private int _chunkLength;
/*      */ 
/*      */   public Hessian2Input(InputStream is)
/*      */   {
/*  133 */     this._is = is;
/*      */   }
/*      */ 
/*      */   public void setSerializerFactory(SerializerFactory factory)
/*      */   {
/*  141 */     this._serializerFactory = factory;
/*      */   }
/*      */ 
/*      */   public SerializerFactory getSerializerFactory()
/*      */   {
/*  149 */     return this._serializerFactory;
/*      */   }
/*      */ 
/*      */   public final SerializerFactory findSerializerFactory()
/*      */   {
/*  157 */     SerializerFactory factory = this._serializerFactory;
/*      */ 
/*  159 */     if (factory == null) {
/*  160 */       this._serializerFactory = (factory = new SerializerFactory());
/*      */     }
/*  162 */     return factory;
/*      */   }
/*      */ 
/*      */   public void setCloseStreamOnClose(boolean isClose)
/*      */   {
/*  167 */     _isCloseStreamOnClose = isClose;
/*      */   }
/*      */ 
/*      */   public boolean isCloseStreamOnClose()
/*      */   {
/*  172 */     return _isCloseStreamOnClose;
/*      */   }
/*      */ 
/*      */   public String getMethod()
/*      */   {
/*  180 */     return this._method;
/*      */   }
/*      */ 
/*      */   public Throwable getReplyFault()
/*      */   {
/*  188 */     return this._replyFault;
/*      */   }
/*      */ 
/*      */   public int readCall()
/*      */     throws IOException
/*      */   {
/*  201 */     int tag = read();
/*      */ 
/*  203 */     if (tag != 67) {
/*  204 */       throw error("expected hessian call ('C') at " + codeName(tag));
/*      */     }
/*  206 */     return 0;
/*      */   }
/*      */ 
/*      */   public int readEnvelope()
/*      */     throws IOException
/*      */   {
/*  219 */     int tag = read();
/*  220 */     int version = 0;
/*      */ 
/*  222 */     if (tag == 72) {
/*  223 */       int major = read();
/*  224 */       int minor = read();
/*      */ 
/*  226 */       version = (major << 16) + minor;
/*      */ 
/*  228 */       tag = read();
/*      */     }
/*      */ 
/*  231 */     if (tag != 69) {
/*  232 */       throw error("expected hessian Envelope ('E') at " + codeName(tag));
/*      */     }
/*  234 */     return version;
/*      */   }
/*      */ 
/*      */   public void completeEnvelope()
/*      */     throws IOException
/*      */   {
/*  249 */     int tag = read();
/*      */ 
/*  251 */     if (tag != 90)
/*  252 */       error("expected end of envelope at " + codeName(tag));
/*      */   }
/*      */ 
/*      */   public String readMethod()
/*      */     throws IOException
/*      */   {
/*  267 */     this._method = readString();
/*      */ 
/*  269 */     return this._method;
/*      */   }
/*      */ 
/*      */   public int readMethodArgLength()
/*      */     throws IOException
/*      */   {
/*  283 */     return readInt();
/*      */   }
/*      */ 
/*      */   public void startCall()
/*      */     throws IOException
/*      */   {
/*  299 */     readCall();
/*      */ 
/*  301 */     readMethod();
/*      */   }
/*      */ 
/*      */   public void completeCall()
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   public Object readReply(Class expectedClass)
/*      */     throws Throwable
/*      */   {
/*  325 */     int tag = read();
/*      */ 
/*  327 */     if (tag == 82)
/*  328 */       return readObject(expectedClass);
/*  329 */     if (tag == 70) {
/*  330 */       HashMap map = (HashMap)readObject(HashMap.class);
/*      */ 
/*  332 */       throw prepareFault(map);
/*      */     }
/*      */ 
/*  335 */     StringBuilder sb = new StringBuilder();
/*  336 */     sb.append((char)tag);
/*      */     try
/*      */     {
/*      */       int ch;
/*  341 */       while ((ch = read()) >= 0)
/*  342 */         sb.append((char)ch);
/*      */     }
/*      */     catch (IOException e) {
/*  345 */       log.log(Level.FINE, e.toString(), e);
/*      */     }
/*      */ 
/*  348 */     throw error("expected hessian reply at " + codeName(tag) + "\n" + sb);
/*      */   }
/*      */ 
/*      */   public void startReply()
/*      */     throws Throwable
/*      */   {
/*  367 */     readReply(Object.class);
/*      */   }
/*      */ 
/*      */   private Throwable prepareFault(HashMap fault)
/*      */     throws IOException
/*      */   {
/*  376 */     Object detail = fault.get("detail");
/*  377 */     String message = (String)fault.get("message");
/*      */ 
/*  379 */     if ((detail instanceof Throwable)) {
/*  380 */       this._replyFault = ((Throwable)detail);
/*      */ 
/*  382 */       if ((message != null) && (_detailMessageField != null))
/*      */         try {
/*  384 */           _detailMessageField.set(this._replyFault, message);
/*      */         }
/*      */         catch (Throwable e)
/*      */         {
/*      */         }
/*  389 */       return this._replyFault;
/*      */     }
/*      */ 
/*  393 */     String code = (String)fault.get("code");
/*      */ 
/*  395 */     this._replyFault = new HessianServiceException(message, code, detail);
/*      */ 
/*  397 */     return this._replyFault;
/*      */   }
/*      */ 
/*      */   public void completeReply()
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void completeValueReply()
/*      */     throws IOException
/*      */   {
/*  427 */     int tag = read();
/*      */ 
/*  429 */     if (tag != 90)
/*  430 */       error("expected end of reply at " + codeName(tag));
/*      */   }
/*      */ 
/*      */   public String readHeader()
/*      */     throws IOException
/*      */   {
/*  443 */     return null;
/*      */   }
/*      */ 
/*      */   public int startMessage()
/*      */     throws IOException
/*      */   {
/*  456 */     int tag = read();
/*      */ 
/*  458 */     if (tag == 112)
/*  459 */       this._isStreaming = false;
/*  460 */     else if (tag == 80)
/*  461 */       this._isStreaming = true;
/*      */     else {
/*  463 */       throw error("expected Hessian message ('p') at " + codeName(tag));
/*      */     }
/*  465 */     int major = read();
/*  466 */     int minor = read();
/*      */ 
/*  468 */     return (major << 16) + minor;
/*      */   }
/*      */ 
/*      */   public void completeMessage()
/*      */     throws IOException
/*      */   {
/*  483 */     int tag = read();
/*      */ 
/*  485 */     if (tag != 90)
/*  486 */       error("expected end of message at " + codeName(tag));
/*      */   }
/*      */ 
/*      */   public void readNull()
/*      */     throws IOException
/*      */   {
/*  499 */     int tag = read();
/*      */ 
/*  501 */     switch (tag) { case 78:
/*  502 */       return;
/*      */     }
/*      */ 
/*  505 */     throw expect("null", tag);
/*      */   }
/*      */ 
/*      */   public boolean readBoolean()
/*      */     throws IOException
/*      */   {
/*  520 */     int tag = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/*      */ 
/*  522 */     switch (tag) { case 84:
/*  523 */       return true;
/*      */     case 70:
/*  524 */       return false;
/*      */     case 128:
/*      */     case 129:
/*      */     case 130:
/*      */     case 131:
/*      */     case 132:
/*      */     case 133:
/*      */     case 134:
/*      */     case 135:
/*      */     case 136:
/*      */     case 137:
/*      */     case 138:
/*      */     case 139:
/*      */     case 140:
/*      */     case 141:
/*      */     case 142:
/*      */     case 143:
/*      */     case 144:
/*      */     case 145:
/*      */     case 146:
/*      */     case 147:
/*      */     case 148:
/*      */     case 149:
/*      */     case 150:
/*      */     case 151:
/*      */     case 152:
/*      */     case 153:
/*      */     case 154:
/*      */     case 155:
/*      */     case 156:
/*      */     case 157:
/*      */     case 158:
/*      */     case 159:
/*      */     case 160:
/*      */     case 161:
/*      */     case 162:
/*      */     case 163:
/*      */     case 164:
/*      */     case 165:
/*      */     case 166:
/*      */     case 167:
/*      */     case 168:
/*      */     case 169:
/*      */     case 170:
/*      */     case 171:
/*      */     case 172:
/*      */     case 173:
/*      */     case 174:
/*      */     case 175:
/*      */     case 176:
/*      */     case 177:
/*      */     case 178:
/*      */     case 179:
/*      */     case 180:
/*      */     case 181:
/*      */     case 182:
/*      */     case 183:
/*      */     case 184:
/*      */     case 185:
/*      */     case 186:
/*      */     case 187:
/*      */     case 188:
/*      */     case 189:
/*      */     case 190:
/*      */     case 191:
/*  546 */       return tag != 144;
/*      */     case 200:
/*  550 */       return read() != 0;
/*      */     case 192:
/*      */     case 193:
/*      */     case 194:
/*      */     case 195:
/*      */     case 196:
/*      */     case 197:
/*      */     case 198:
/*      */     case 199:
/*      */     case 201:
/*      */     case 202:
/*      */     case 203:
/*      */     case 204:
/*      */     case 205:
/*      */     case 206:
/*      */     case 207:
/*  557 */       read();
/*  558 */       return true;
/*      */     case 212:
/*  562 */       return 256 * read() + read() != 0;
/*      */     case 208:
/*      */     case 209:
/*      */     case 210:
/*      */     case 211:
/*      */     case 213:
/*      */     case 214:
/*      */     case 215:
/*  567 */       read();
/*  568 */       read();
/*  569 */       return true;
/*      */     case 73:
/*  571 */       return parseInt() != 0;
/*      */     case 216:
/*      */     case 217:
/*      */     case 218:
/*      */     case 219:
/*      */     case 220:
/*      */     case 221:
/*      */     case 222:
/*      */     case 223:
/*      */     case 224:
/*      */     case 225:
/*      */     case 226:
/*      */     case 227:
/*      */     case 228:
/*      */     case 229:
/*      */     case 230:
/*      */     case 231:
/*      */     case 232:
/*      */     case 233:
/*      */     case 234:
/*      */     case 235:
/*      */     case 236:
/*      */     case 237:
/*      */     case 238:
/*      */     case 239:
/*  581 */       return tag != 224;
/*      */     case 248:
/*  585 */       return read() != 0;
/*      */     case 240:
/*      */     case 241:
/*      */     case 242:
/*      */     case 243:
/*      */     case 244:
/*      */     case 245:
/*      */     case 246:
/*      */     case 247:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/*      */     case 253:
/*      */     case 254:
/*      */     case 255:
/*  592 */       read();
/*  593 */       return true;
/*      */     case 60:
/*  597 */       return 256 * read() + read() != 0;
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/*  602 */       read();
/*  603 */       read();
/*  604 */       return true;
/*      */     case 89:
/*  607 */       return 16777216L * read() + 65536L * read() + 256 * read() + read() != 0L;
/*      */     case 76:
/*  613 */       return parseLong() != 0L;
/*      */     case 91:
/*  616 */       return false;
/*      */     case 92:
/*  619 */       return true;
/*      */     case 93:
/*  622 */       return read() != 0;
/*      */     case 94:
/*  625 */       return 256 * read() + read() != 0;
/*      */     case 95:
/*  629 */       int mills = parseInt();
/*      */ 
/*  631 */       return mills != 0;
/*      */     case 68:
/*  635 */       return parseDouble() != 0.0D;
/*      */     case 78:
/*  638 */       return false;
/*      */     case 64:
/*      */     case 65:
/*      */     case 66:
/*      */     case 67:
/*      */     case 69:
/*      */     case 71:
/*      */     case 72:
/*      */     case 74:
/*      */     case 75:
/*      */     case 77:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 82:
/*      */     case 83:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 90:
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 99:
/*      */     case 100:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/*      */     case 112:
/*      */     case 113:
/*      */     case 114:
/*      */     case 115:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/*      */     case 119:
/*      */     case 120:
/*      */     case 121:
/*      */     case 122:
/*      */     case 123:
/*      */     case 124:
/*      */     case 125:
/*      */     case 126:
/*  641 */     case 127: } throw expect("boolean", tag);
/*      */   }
/*      */ 
/*      */   public short readShort()
/*      */     throws IOException
/*      */   {
/*  655 */     return (short)readInt();
/*      */   }
/*      */ 
/*      */   public final int readInt()
/*      */     throws IOException
/*      */   {
/*  669 */     int tag = read();
/*      */ 
/*  671 */     switch (tag) {
/*      */     case 78:
/*  673 */       return 0;
/*      */     case 70:
/*  676 */       return 0;
/*      */     case 84:
/*  679 */       return 1;
/*      */     case 128:
/*      */     case 129:
/*      */     case 130:
/*      */     case 131:
/*      */     case 132:
/*      */     case 133:
/*      */     case 134:
/*      */     case 135:
/*      */     case 136:
/*      */     case 137:
/*      */     case 138:
/*      */     case 139:
/*      */     case 140:
/*      */     case 141:
/*      */     case 142:
/*      */     case 143:
/*      */     case 144:
/*      */     case 145:
/*      */     case 146:
/*      */     case 147:
/*      */     case 148:
/*      */     case 149:
/*      */     case 150:
/*      */     case 151:
/*      */     case 152:
/*      */     case 153:
/*      */     case 154:
/*      */     case 155:
/*      */     case 156:
/*      */     case 157:
/*      */     case 158:
/*      */     case 159:
/*      */     case 160:
/*      */     case 161:
/*      */     case 162:
/*      */     case 163:
/*      */     case 164:
/*      */     case 165:
/*      */     case 166:
/*      */     case 167:
/*      */     case 168:
/*      */     case 169:
/*      */     case 170:
/*      */     case 171:
/*      */     case 172:
/*      */     case 173:
/*      */     case 174:
/*      */     case 175:
/*      */     case 176:
/*      */     case 177:
/*      */     case 178:
/*      */     case 179:
/*      */     case 180:
/*      */     case 181:
/*      */     case 182:
/*      */     case 183:
/*      */     case 184:
/*      */     case 185:
/*      */     case 186:
/*      */     case 187:
/*      */     case 188:
/*      */     case 189:
/*      */     case 190:
/*      */     case 191:
/*  701 */       return tag - 144;
/*      */     case 192:
/*      */     case 193:
/*      */     case 194:
/*      */     case 195:
/*      */     case 196:
/*      */     case 197:
/*      */     case 198:
/*      */     case 199:
/*      */     case 200:
/*      */     case 201:
/*      */     case 202:
/*      */     case 203:
/*      */     case 204:
/*      */     case 205:
/*      */     case 206:
/*      */     case 207:
/*  708 */       return (tag - 200 << 8) + read();
/*      */     case 208:
/*      */     case 209:
/*      */     case 210:
/*      */     case 211:
/*      */     case 212:
/*      */     case 213:
/*      */     case 214:
/*      */     case 215:
/*  713 */       return (tag - 212 << 16) + 256 * read() + read();
/*      */     case 73:
/*      */     case 89:
/*  717 */       return (read() << 24) + (read() << 16) + (read() << 8) + read();
/*      */     case 216:
/*      */     case 217:
/*      */     case 218:
/*      */     case 219:
/*      */     case 220:
/*      */     case 221:
/*      */     case 222:
/*      */     case 223:
/*      */     case 224:
/*      */     case 225:
/*      */     case 226:
/*      */     case 227:
/*      */     case 228:
/*      */     case 229:
/*      */     case 230:
/*      */     case 231:
/*      */     case 232:
/*      */     case 233:
/*      */     case 234:
/*      */     case 235:
/*      */     case 236:
/*      */     case 237:
/*      */     case 238:
/*      */     case 239:
/*  730 */       return tag - 224;
/*      */     case 240:
/*      */     case 241:
/*      */     case 242:
/*      */     case 243:
/*      */     case 244:
/*      */     case 245:
/*      */     case 246:
/*      */     case 247:
/*      */     case 248:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/*      */     case 253:
/*      */     case 254:
/*      */     case 255:
/*  737 */       return (tag - 248 << 8) + read();
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/*  742 */       return (tag - 60 << 16) + 256 * read() + read();
/*      */     case 76:
/*  745 */       return (int)parseLong();
/*      */     case 91:
/*  748 */       return 0;
/*      */     case 92:
/*  751 */       return 1;
/*      */     case 93:
/*  755 */       return (byte)(this._offset < this._length ? this._buffer[(this._offset++)] : read());
/*      */     case 94:
/*  760 */       return (short)(256 * read() + read());
/*      */     case 95:
/*  764 */       int mills = parseInt();
/*      */ 
/*  766 */       return (int)(0.001D * mills);
/*      */     case 68:
/*  770 */       return (int)parseDouble();
/*      */     case 64:
/*      */     case 65:
/*      */     case 66:
/*      */     case 67:
/*      */     case 69:
/*      */     case 71:
/*      */     case 72:
/*      */     case 74:
/*      */     case 75:
/*      */     case 77:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 82:
/*      */     case 83:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 90:
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 99:
/*      */     case 100:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/*      */     case 112:
/*      */     case 113:
/*      */     case 114:
/*      */     case 115:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/*      */     case 119:
/*      */     case 120:
/*      */     case 121:
/*      */     case 122:
/*      */     case 123:
/*      */     case 124:
/*      */     case 125:
/*      */     case 126:
/*  773 */     case 127: } throw expect("integer", tag);
/*      */   }
/*      */ 
/*      */   public long readLong()
/*      */     throws IOException
/*      */   {
/*  787 */     int tag = read();
/*      */ 
/*  789 */     switch (tag) {
/*      */     case 78:
/*  791 */       return 0L;
/*      */     case 70:
/*  794 */       return 0L;
/*      */     case 84:
/*  797 */       return 1L;
/*      */     case 128:
/*      */     case 129:
/*      */     case 130:
/*      */     case 131:
/*      */     case 132:
/*      */     case 133:
/*      */     case 134:
/*      */     case 135:
/*      */     case 136:
/*      */     case 137:
/*      */     case 138:
/*      */     case 139:
/*      */     case 140:
/*      */     case 141:
/*      */     case 142:
/*      */     case 143:
/*      */     case 144:
/*      */     case 145:
/*      */     case 146:
/*      */     case 147:
/*      */     case 148:
/*      */     case 149:
/*      */     case 150:
/*      */     case 151:
/*      */     case 152:
/*      */     case 153:
/*      */     case 154:
/*      */     case 155:
/*      */     case 156:
/*      */     case 157:
/*      */     case 158:
/*      */     case 159:
/*      */     case 160:
/*      */     case 161:
/*      */     case 162:
/*      */     case 163:
/*      */     case 164:
/*      */     case 165:
/*      */     case 166:
/*      */     case 167:
/*      */     case 168:
/*      */     case 169:
/*      */     case 170:
/*      */     case 171:
/*      */     case 172:
/*      */     case 173:
/*      */     case 174:
/*      */     case 175:
/*      */     case 176:
/*      */     case 177:
/*      */     case 178:
/*      */     case 179:
/*      */     case 180:
/*      */     case 181:
/*      */     case 182:
/*      */     case 183:
/*      */     case 184:
/*      */     case 185:
/*      */     case 186:
/*      */     case 187:
/*      */     case 188:
/*      */     case 189:
/*      */     case 190:
/*      */     case 191:
/*  819 */       return tag - 144;
/*      */     case 192:
/*      */     case 193:
/*      */     case 194:
/*      */     case 195:
/*      */     case 196:
/*      */     case 197:
/*      */     case 198:
/*      */     case 199:
/*      */     case 200:
/*      */     case 201:
/*      */     case 202:
/*      */     case 203:
/*      */     case 204:
/*      */     case 205:
/*      */     case 206:
/*      */     case 207:
/*  826 */       return (tag - 200 << 8) + read();
/*      */     case 208:
/*      */     case 209:
/*      */     case 210:
/*      */     case 211:
/*      */     case 212:
/*      */     case 213:
/*      */     case 214:
/*      */     case 215:
/*  831 */       return (tag - 212 << 16) + 256 * read() + read();
/*      */     case 93:
/*  835 */       return (byte)(this._offset < this._length ? this._buffer[(this._offset++)] : read());
/*      */     case 94:
/*  840 */       return (short)(256 * read() + read());
/*      */     case 73:
/*      */     case 89:
/*  844 */       return parseInt();
/*      */     case 216:
/*      */     case 217:
/*      */     case 218:
/*      */     case 219:
/*      */     case 220:
/*      */     case 221:
/*      */     case 222:
/*      */     case 223:
/*      */     case 224:
/*      */     case 225:
/*      */     case 226:
/*      */     case 227:
/*      */     case 228:
/*      */     case 229:
/*      */     case 230:
/*      */     case 231:
/*      */     case 232:
/*      */     case 233:
/*      */     case 234:
/*      */     case 235:
/*      */     case 236:
/*      */     case 237:
/*      */     case 238:
/*      */     case 239:
/*  854 */       return tag - 224;
/*      */     case 240:
/*      */     case 241:
/*      */     case 242:
/*      */     case 243:
/*      */     case 244:
/*      */     case 245:
/*      */     case 246:
/*      */     case 247:
/*      */     case 248:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/*      */     case 253:
/*      */     case 254:
/*      */     case 255:
/*  861 */       return (tag - 248 << 8) + read();
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/*  866 */       return (tag - 60 << 16) + 256 * read() + read();
/*      */     case 76:
/*  869 */       return parseLong();
/*      */     case 91:
/*  872 */       return 0L;
/*      */     case 92:
/*  875 */       return 1L;
/*      */     case 95:
/*  879 */       int mills = parseInt();
/*      */ 
/*  881 */       return ()(0.001D * mills);
/*      */     case 68:
/*  885 */       return ()parseDouble();
/*      */     case 64:
/*      */     case 65:
/*      */     case 66:
/*      */     case 67:
/*      */     case 69:
/*      */     case 71:
/*      */     case 72:
/*      */     case 74:
/*      */     case 75:
/*      */     case 77:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 82:
/*      */     case 83:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 90:
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 99:
/*      */     case 100:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/*      */     case 112:
/*      */     case 113:
/*      */     case 114:
/*      */     case 115:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/*      */     case 119:
/*      */     case 120:
/*      */     case 121:
/*      */     case 122:
/*      */     case 123:
/*      */     case 124:
/*      */     case 125:
/*      */     case 126:
/*  888 */     case 127: } throw expect("long", tag);
/*      */   }
/*      */ 
/*      */   public float readFloat()
/*      */     throws IOException
/*      */   {
/*  902 */     return (float)readDouble();
/*      */   }
/*      */ 
/*      */   public double readDouble()
/*      */     throws IOException
/*      */   {
/*  915 */     int tag = read();
/*      */ 
/*  917 */     switch (tag) {
/*      */     case 78:
/*  919 */       return 0.0D;
/*      */     case 70:
/*  922 */       return 0.0D;
/*      */     case 84:
/*  925 */       return 1.0D;
/*      */     case 128:
/*      */     case 129:
/*      */     case 130:
/*      */     case 131:
/*      */     case 132:
/*      */     case 133:
/*      */     case 134:
/*      */     case 135:
/*      */     case 136:
/*      */     case 137:
/*      */     case 138:
/*      */     case 139:
/*      */     case 140:
/*      */     case 141:
/*      */     case 142:
/*      */     case 143:
/*      */     case 144:
/*      */     case 145:
/*      */     case 146:
/*      */     case 147:
/*      */     case 148:
/*      */     case 149:
/*      */     case 150:
/*      */     case 151:
/*      */     case 152:
/*      */     case 153:
/*      */     case 154:
/*      */     case 155:
/*      */     case 156:
/*      */     case 157:
/*      */     case 158:
/*      */     case 159:
/*      */     case 160:
/*      */     case 161:
/*      */     case 162:
/*      */     case 163:
/*      */     case 164:
/*      */     case 165:
/*      */     case 166:
/*      */     case 167:
/*      */     case 168:
/*      */     case 169:
/*      */     case 170:
/*      */     case 171:
/*      */     case 172:
/*      */     case 173:
/*      */     case 174:
/*      */     case 175:
/*      */     case 176:
/*      */     case 177:
/*      */     case 178:
/*      */     case 179:
/*      */     case 180:
/*      */     case 181:
/*      */     case 182:
/*      */     case 183:
/*      */     case 184:
/*      */     case 185:
/*      */     case 186:
/*      */     case 187:
/*      */     case 188:
/*      */     case 189:
/*      */     case 190:
/*      */     case 191:
/*  947 */       return tag - 144;
/*      */     case 192:
/*      */     case 193:
/*      */     case 194:
/*      */     case 195:
/*      */     case 196:
/*      */     case 197:
/*      */     case 198:
/*      */     case 199:
/*      */     case 200:
/*      */     case 201:
/*      */     case 202:
/*      */     case 203:
/*      */     case 204:
/*      */     case 205:
/*      */     case 206:
/*      */     case 207:
/*  954 */       return (tag - 200 << 8) + read();
/*      */     case 208:
/*      */     case 209:
/*      */     case 210:
/*      */     case 211:
/*      */     case 212:
/*      */     case 213:
/*      */     case 214:
/*      */     case 215:
/*  959 */       return (tag - 212 << 16) + 256 * read() + read();
/*      */     case 73:
/*      */     case 89:
/*  963 */       return parseInt();
/*      */     case 216:
/*      */     case 217:
/*      */     case 218:
/*      */     case 219:
/*      */     case 220:
/*      */     case 221:
/*      */     case 222:
/*      */     case 223:
/*      */     case 224:
/*      */     case 225:
/*      */     case 226:
/*      */     case 227:
/*      */     case 228:
/*      */     case 229:
/*      */     case 230:
/*      */     case 231:
/*      */     case 232:
/*      */     case 233:
/*      */     case 234:
/*      */     case 235:
/*      */     case 236:
/*      */     case 237:
/*      */     case 238:
/*      */     case 239:
/*  973 */       return tag - 224;
/*      */     case 240:
/*      */     case 241:
/*      */     case 242:
/*      */     case 243:
/*      */     case 244:
/*      */     case 245:
/*      */     case 246:
/*      */     case 247:
/*      */     case 248:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/*      */     case 253:
/*      */     case 254:
/*      */     case 255:
/*  980 */       return (tag - 248 << 8) + read();
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/*  985 */       return (tag - 60 << 16) + 256 * read() + read();
/*      */     case 76:
/*  988 */       return parseLong();
/*      */     case 91:
/*  991 */       return 0.0D;
/*      */     case 92:
/*  994 */       return 1.0D;
/*      */     case 93:
/*  997 */       return (byte)(this._offset < this._length ? this._buffer[(this._offset++)] : read());
/*      */     case 94:
/* 1000 */       return (short)(256 * read() + read());
/*      */     case 95:
/* 1004 */       int mills = parseInt();
/*      */ 
/* 1006 */       return 0.001D * mills;
/*      */     case 68:
/* 1010 */       return parseDouble();
/*      */     case 64:
/*      */     case 65:
/*      */     case 66:
/*      */     case 67:
/*      */     case 69:
/*      */     case 71:
/*      */     case 72:
/*      */     case 74:
/*      */     case 75:
/*      */     case 77:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 82:
/*      */     case 83:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 90:
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 99:
/*      */     case 100:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/*      */     case 112:
/*      */     case 113:
/*      */     case 114:
/*      */     case 115:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/*      */     case 119:
/*      */     case 120:
/*      */     case 121:
/*      */     case 122:
/*      */     case 123:
/*      */     case 124:
/*      */     case 125:
/*      */     case 126:
/* 1013 */     case 127: } throw expect("double", tag);
/*      */   }
/*      */ 
/*      */   public long readUTCDate()
/*      */     throws IOException
/*      */   {
/* 1027 */     int tag = read();
/*      */ 
/* 1029 */     if (tag == 74) {
/* 1030 */       return parseLong();
/*      */     }
/* 1032 */     if (tag == 75) {
/* 1033 */       return parseInt() * 60000L;
/*      */     }
/*      */ 
/* 1036 */     throw expect("date", tag);
/*      */   }
/*      */ 
/*      */   public int readChar()
/*      */     throws IOException
/*      */   {
/* 1045 */     if (this._chunkLength > 0) {
/* 1046 */       this._chunkLength -= 1;
/* 1047 */       if ((this._chunkLength == 0) && (this._isLastChunk)) {
/* 1048 */         this._chunkLength = -2;
/*      */       }
/* 1050 */       int ch = parseUTF8Char();
/* 1051 */       return ch;
/*      */     }
/* 1053 */     if (this._chunkLength == -2) {
/* 1054 */       this._chunkLength = 0;
/* 1055 */       return -1;
/*      */     }
/*      */ 
/* 1058 */     int tag = read();
/*      */ 
/* 1060 */     switch (tag) {
/*      */     case 78:
/* 1062 */       return -1;
/*      */     case 82:
/*      */     case 83:
/* 1066 */       this._isLastChunk = (tag == 83);
/* 1067 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1069 */       this._chunkLength -= 1;
/* 1070 */       int value = parseUTF8Char();
/*      */ 
/* 1074 */       if ((this._chunkLength == 0) && (this._isLastChunk)) {
/* 1075 */         this._chunkLength = -2;
/*      */       }
/* 1077 */       return value;
/*      */     }
/*      */ 
/* 1080 */     throw expect("char", tag);
/*      */   }
/*      */ 
/*      */   public int readString(char[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1090 */     int readLength = 0;
/*      */ 
/* 1092 */     if (this._chunkLength == -2) {
/* 1093 */       this._chunkLength = 0;
/* 1094 */       return -1;
/*      */     }
/* 1096 */     if (this._chunkLength == 0) {
/* 1097 */       int tag = read();
/*      */ 
/* 1099 */       switch (tag) {
/*      */       case 78:
/* 1101 */         return -1;
/*      */       case 82:
/*      */       case 83:
/* 1105 */         this._isLastChunk = (tag == 83);
/* 1106 */         this._chunkLength = ((read() << 8) + read());
/* 1107 */         break;
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 28:
/*      */       case 29:
/*      */       case 30:
/*      */       case 31:
/* 1118 */         this._isLastChunk = true;
/* 1119 */         this._chunkLength = (tag - 0);
/* 1120 */         break;
/*      */       case 32:
/*      */       case 33:
/*      */       case 34:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 45:
/*      */       case 46:
/*      */       case 47:
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 64:
/*      */       case 65:
/*      */       case 66:
/*      */       case 67:
/*      */       case 68:
/*      */       case 69:
/*      */       case 70:
/*      */       case 71:
/*      */       case 72:
/*      */       case 73:
/*      */       case 74:
/*      */       case 75:
/*      */       case 76:
/*      */       case 77:
/*      */       case 79:
/*      */       case 80:
/*      */       case 81:
/*      */       default:
/* 1123 */         throw expect("string", tag);
/*      */       }
/*      */     }
/*      */ 
/* 1127 */     while (length > 0) {
/* 1128 */       if (this._chunkLength > 0) {
/* 1129 */         buffer[(offset++)] = ((char)parseUTF8Char());
/* 1130 */         this._chunkLength -= 1;
/* 1131 */         length--;
/* 1132 */         readLength++;
/*      */       } else {
/* 1134 */         if (this._isLastChunk) {
/* 1135 */           if (readLength == 0) {
/* 1136 */             return -1;
/*      */           }
/* 1138 */           this._chunkLength = -2;
/* 1139 */           return readLength;
/*      */         }
/*      */ 
/* 1143 */         int tag = read();
/*      */ 
/* 1145 */         switch (tag) {
/*      */         case 82:
/*      */         case 83:
/* 1148 */           this._isLastChunk = (tag == 83);
/* 1149 */           this._chunkLength = ((read() << 8) + read());
/* 1150 */           break;
/*      */         default:
/* 1153 */           throw expect("string", tag);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1158 */     if (readLength == 0)
/* 1159 */       return -1;
/* 1160 */     if ((this._chunkLength > 0) || (!this._isLastChunk)) {
/* 1161 */       return readLength;
/*      */     }
/* 1163 */     this._chunkLength = -2;
/* 1164 */     return readLength;
/*      */   }
/*      */ 
/*      */   public String readString()
/*      */     throws IOException
/*      */   {
/* 1178 */     int tag = read();
/*      */     int ch;
/* 1180 */     switch (tag) {
/*      */     case 78:
/* 1182 */       return null;
/*      */     case 84:
/* 1184 */       return "true";
/*      */     case 70:
/* 1186 */       return "false";
/*      */     case 128:
/*      */     case 129:
/*      */     case 130:
/*      */     case 131:
/*      */     case 132:
/*      */     case 133:
/*      */     case 134:
/*      */     case 135:
/*      */     case 136:
/*      */     case 137:
/*      */     case 138:
/*      */     case 139:
/*      */     case 140:
/*      */     case 141:
/*      */     case 142:
/*      */     case 143:
/*      */     case 144:
/*      */     case 145:
/*      */     case 146:
/*      */     case 147:
/*      */     case 148:
/*      */     case 149:
/*      */     case 150:
/*      */     case 151:
/*      */     case 152:
/*      */     case 153:
/*      */     case 154:
/*      */     case 155:
/*      */     case 156:
/*      */     case 157:
/*      */     case 158:
/*      */     case 159:
/*      */     case 160:
/*      */     case 161:
/*      */     case 162:
/*      */     case 163:
/*      */     case 164:
/*      */     case 165:
/*      */     case 166:
/*      */     case 167:
/*      */     case 168:
/*      */     case 169:
/*      */     case 170:
/*      */     case 171:
/*      */     case 172:
/*      */     case 173:
/*      */     case 174:
/*      */     case 175:
/*      */     case 176:
/*      */     case 177:
/*      */     case 178:
/*      */     case 179:
/*      */     case 180:
/*      */     case 181:
/*      */     case 182:
/*      */     case 183:
/*      */     case 184:
/*      */     case 185:
/*      */     case 186:
/*      */     case 187:
/*      */     case 188:
/*      */     case 189:
/*      */     case 190:
/*      */     case 191:
/* 1208 */       return String.valueOf(tag - 144);
/*      */     case 192:
/*      */     case 193:
/*      */     case 194:
/*      */     case 195:
/*      */     case 196:
/*      */     case 197:
/*      */     case 198:
/*      */     case 199:
/*      */     case 200:
/*      */     case 201:
/*      */     case 202:
/*      */     case 203:
/*      */     case 204:
/*      */     case 205:
/*      */     case 206:
/*      */     case 207:
/* 1215 */       return String.valueOf((tag - 200 << 8) + read());
/*      */     case 208:
/*      */     case 209:
/*      */     case 210:
/*      */     case 211:
/*      */     case 212:
/*      */     case 213:
/*      */     case 214:
/*      */     case 215:
/* 1220 */       return String.valueOf((tag - 212 << 16) + 256 * read() + read());
/*      */     case 73:
/*      */     case 89:
/* 1225 */       return String.valueOf(parseInt());
/*      */     case 216:
/*      */     case 217:
/*      */     case 218:
/*      */     case 219:
/*      */     case 220:
/*      */     case 221:
/*      */     case 222:
/*      */     case 223:
/*      */     case 224:
/*      */     case 225:
/*      */     case 226:
/*      */     case 227:
/*      */     case 228:
/*      */     case 229:
/*      */     case 230:
/*      */     case 231:
/*      */     case 232:
/*      */     case 233:
/*      */     case 234:
/*      */     case 235:
/*      */     case 236:
/*      */     case 237:
/*      */     case 238:
/*      */     case 239:
/* 1235 */       return String.valueOf(tag - 224);
/*      */     case 240:
/*      */     case 241:
/*      */     case 242:
/*      */     case 243:
/*      */     case 244:
/*      */     case 245:
/*      */     case 246:
/*      */     case 247:
/*      */     case 248:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/*      */     case 253:
/*      */     case 254:
/*      */     case 255:
/* 1242 */       return String.valueOf((tag - 248 << 8) + read());
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/* 1247 */       return String.valueOf((tag - 60 << 16) + 256 * read() + read());
/*      */     case 76:
/* 1251 */       return String.valueOf(parseLong());
/*      */     case 91:
/* 1254 */       return "0.0";
/*      */     case 92:
/* 1257 */       return "1.0";
/*      */     case 93:
/* 1260 */       return String.valueOf((byte)(this._offset < this._length ? this._buffer[(this._offset++)] : read()));
/*      */     case 94:
/* 1265 */       return String.valueOf((short)(256 * read() + read()));
/*      */     case 95:
/* 1269 */       int mills = parseInt();
/*      */ 
/* 1271 */       return String.valueOf(0.001D * mills);
/*      */     case 68:
/* 1275 */       return String.valueOf(parseDouble());
/*      */     case 82:
/*      */     case 83:
/* 1279 */       this._isLastChunk = (tag == 83);
/* 1280 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1282 */       this._sbuf.setLength(0);
/*      */ 
/* 1285 */       while ((ch = parseChar()) >= 0) {
/* 1286 */         this._sbuf.append((char)ch);
/*      */       }
/* 1288 */       return this._sbuf.toString();
/*      */     case 0:
/*      */     case 1:
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/*      */     case 15:
/*      */     case 16:
/*      */     case 17:
/*      */     case 18:
/*      */     case 19:
/*      */     case 20:
/*      */     case 21:
/*      */     case 22:
/*      */     case 23:
/*      */     case 24:
/*      */     case 25:
/*      */     case 26:
/*      */     case 27:
/*      */     case 28:
/*      */     case 29:
/*      */     case 30:
/*      */     case 31:
/* 1300 */       this._isLastChunk = true;
/* 1301 */       this._chunkLength = (tag - 0);
/*      */ 
/* 1303 */       this._sbuf.setLength(0);
/*      */ 
/* 1305 */       while ((ch = parseChar()) >= 0) {
/* 1306 */         this._sbuf.append((char)ch);
/*      */       }
/* 1308 */       return this._sbuf.toString();
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/* 1311 */       this._isLastChunk = true;
/* 1312 */       this._chunkLength = ((tag - 48) * 256 + read());
/*      */ 
/* 1314 */       this._sbuf.setLength(0);
/*      */ 
/* 1316 */       while ((ch = parseChar()) >= 0) {
/* 1317 */         this._sbuf.append((char)ch);
/*      */       }
/* 1319 */       return this._sbuf.toString();
/*      */     case 32:
/*      */     case 33:
/*      */     case 34:
/*      */     case 35:
/*      */     case 36:
/*      */     case 37:
/*      */     case 38:
/*      */     case 39:
/*      */     case 40:
/*      */     case 41:
/*      */     case 42:
/*      */     case 43:
/*      */     case 44:
/*      */     case 45:
/*      */     case 46:
/*      */     case 47:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 64:
/*      */     case 65:
/*      */     case 66:
/*      */     case 67:
/*      */     case 69:
/*      */     case 71:
/*      */     case 72:
/*      */     case 74:
/*      */     case 75:
/*      */     case 77:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 90:
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 99:
/*      */     case 100:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/*      */     case 112:
/*      */     case 113:
/*      */     case 114:
/*      */     case 115:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/*      */     case 119:
/*      */     case 120:
/*      */     case 121:
/*      */     case 122:
/*      */     case 123:
/*      */     case 124:
/*      */     case 125:
/*      */     case 126:
/* 1322 */     case 127: } throw expect("string", tag);
/*      */   }
/*      */ 
/*      */   public byte[] readBytes()
/*      */     throws IOException
/*      */   {
/* 1336 */     int tag = read();
/*      */     int data;
/* 1338 */     switch (tag) {
/*      */     case 78:
/* 1340 */       return null;
/*      */     case 65:
/*      */     case 66:
/* 1344 */       this._isLastChunk = (tag == 66);
/* 1345 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1347 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*      */ 
/* 1350 */       while ((data = parseByte()) >= 0) {
/* 1351 */         bos.write(data);
/*      */       }
/* 1353 */       return bos.toByteArray();
/*      */     case 32:
/*      */     case 33:
/*      */     case 34:
/*      */     case 35:
/*      */     case 36:
/*      */     case 37:
/*      */     case 38:
/*      */     case 39:
/*      */     case 40:
/*      */     case 41:
/*      */     case 42:
/*      */     case 43:
/*      */     case 44:
/*      */     case 45:
/*      */     case 46:
/*      */     case 47:
/* 1360 */       this._isLastChunk = true;
/* 1361 */       this._chunkLength = (tag - 32);
/*      */ 
/* 1363 */       byte[] buffer = new byte[this._chunkLength];
/*      */ 
/* 1365 */       int k = 0;
/* 1366 */       while ((data = parseByte()) >= 0) {
/* 1367 */         buffer[(k++)] = ((byte)data);
/*      */       }
/* 1369 */       return buffer;
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/* 1374 */       this._isLastChunk = true;
/* 1375 */       this._chunkLength = ((tag - 52) * 256 + read());
/*      */ 
/* 1377 */       byte[] buffer = new byte[this._chunkLength];
/* 1378 */       int k = 0;
/*      */ 
/* 1380 */       while ((data = parseByte()) >= 0) {
/* 1381 */         buffer[(k++)] = ((byte)data);
/*      */       }
/*      */ 
/* 1384 */       return buffer;
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/*      */     case 64:
/*      */     case 67:
/*      */     case 68:
/*      */     case 69:
/*      */     case 70:
/*      */     case 71:
/*      */     case 72:
/*      */     case 73:
/*      */     case 74:
/*      */     case 75:
/*      */     case 76:
/* 1388 */     case 77: } throw expect("bytes", tag);
/*      */   }
/*      */ 
/*      */   public int readByte()
/*      */     throws IOException
/*      */   {
/* 1398 */     if (this._chunkLength > 0) {
/* 1399 */       this._chunkLength -= 1;
/* 1400 */       if ((this._chunkLength == 0) && (this._isLastChunk)) {
/* 1401 */         this._chunkLength = -2;
/*      */       }
/* 1403 */       return read();
/*      */     }
/* 1405 */     if (this._chunkLength == -2) {
/* 1406 */       this._chunkLength = 0;
/* 1407 */       return -1;
/*      */     }
/*      */ 
/* 1410 */     int tag = read();
/*      */ 
/* 1412 */     switch (tag) {
/*      */     case 78:
/* 1414 */       return -1;
/*      */     case 65:
/*      */     case 66:
/* 1418 */       this._isLastChunk = (tag == 66);
/* 1419 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1421 */       int value = parseByte();
/*      */ 
/* 1425 */       if ((this._chunkLength == 0) && (this._isLastChunk)) {
/* 1426 */         this._chunkLength = -2;
/*      */       }
/* 1428 */       return value;
/*      */     }
/*      */ 
/* 1431 */     throw expect("binary", tag);
/*      */   }
/*      */ 
/*      */   public int readBytes(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1441 */     int readLength = 0;
/*      */ 
/* 1443 */     if (this._chunkLength == -2) {
/* 1444 */       this._chunkLength = 0;
/* 1445 */       return -1;
/*      */     }
/* 1447 */     if (this._chunkLength == 0) {
/* 1448 */       int tag = read();
/*      */ 
/* 1450 */       switch (tag) {
/*      */       case 78:
/* 1452 */         return -1;
/*      */       case 65:
/*      */       case 66:
/* 1456 */         this._isLastChunk = (tag == 66);
/* 1457 */         this._chunkLength = ((read() << 8) + read());
/* 1458 */         break;
/*      */       default:
/* 1461 */         throw expect("binary", tag);
/*      */       }
/*      */     }
/*      */ 
/* 1465 */     while (length > 0) {
/* 1466 */       if (this._chunkLength > 0) {
/* 1467 */         buffer[(offset++)] = ((byte)read());
/* 1468 */         this._chunkLength -= 1;
/* 1469 */         length--;
/* 1470 */         readLength++;
/*      */       } else {
/* 1472 */         if (this._isLastChunk) {
/* 1473 */           if (readLength == 0) {
/* 1474 */             return -1;
/*      */           }
/* 1476 */           this._chunkLength = -2;
/* 1477 */           return readLength;
/*      */         }
/*      */ 
/* 1481 */         int tag = read();
/*      */ 
/* 1483 */         switch (tag) {
/*      */         case 65:
/*      */         case 66:
/* 1486 */           this._isLastChunk = (tag == 66);
/* 1487 */           this._chunkLength = ((read() << 8) + read());
/* 1488 */           break;
/*      */         default:
/* 1491 */           throw expect("binary", tag);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1496 */     if (readLength == 0)
/* 1497 */       return -1;
/* 1498 */     if ((this._chunkLength > 0) || (!this._isLastChunk)) {
/* 1499 */       return readLength;
/*      */     }
/* 1501 */     this._chunkLength = -2;
/* 1502 */     return readLength;
/*      */   }
/*      */ 
/*      */   private HashMap readFault()
/*      */     throws IOException
/*      */   {
/* 1512 */     HashMap map = new HashMap();
/*      */ 
/* 1514 */     for (int code = read(); 
/* 1515 */       (code > 0) && (code != 90); code = read()) {
/* 1516 */       this._offset -= 1;
/*      */ 
/* 1518 */       Object key = readObject();
/* 1519 */       Object value = readObject();
/*      */ 
/* 1521 */       if ((key != null) && (value != null)) {
/* 1522 */         map.put(key, value);
/*      */       }
/*      */     }
/* 1525 */     if (code != 90) {
/* 1526 */       throw expect("fault", code);
/*      */     }
/* 1528 */     return map;
/*      */   }
/*      */ 
/*      */   public Object readObject(Class cl)
/*      */     throws IOException
/*      */   {
/* 1537 */     if ((cl == null) || (cl == Object.class)) {
/* 1538 */       return readObject();
/*      */     }
/* 1540 */     int tag = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/*      */ 
/* 1542 */     switch (tag) {
/*      */     case 78:
/* 1544 */       return null;
/*      */     case 72:
/* 1548 */       Deserializer reader = findSerializerFactory().getDeserializer(cl);
/*      */ 
/* 1550 */       return reader.readMap(this);
/*      */     case 77:
/* 1555 */       String type = readType();
/*      */ 
/* 1558 */       if ("".equals(type))
/*      */       {
/* 1560 */         Deserializer reader = findSerializerFactory().getDeserializer(cl);
/*      */ 
/* 1562 */         return reader.readMap(this);
/*      */       }
/*      */ 
/* 1566 */       Deserializer reader = findSerializerFactory().getObjectDeserializer(type, cl);
/*      */ 
/* 1568 */       return reader.readMap(this);
/*      */     case 67:
/* 1574 */       readObjectDefinition(cl);
/*      */ 
/* 1576 */       return readObject(cl);
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 99:
/*      */     case 100:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/* 1584 */       int ref = tag - 96;
/* 1585 */       int size = this._classDefs.size();
/*      */ 
/* 1587 */       if ((ref < 0) || (size <= ref)) {
/* 1588 */         throw new HessianProtocolException("'" + ref + "' is an unknown class definition");
/*      */       }
/* 1590 */       ObjectDefinition def = (ObjectDefinition)this._classDefs.get(ref);
/*      */ 
/* 1592 */       return readObjectInstance(cl, def);
/*      */     case 79:
/* 1597 */       int ref = readInt();
/* 1598 */       int size = this._classDefs.size();
/*      */ 
/* 1600 */       if ((ref < 0) || (size <= ref)) {
/* 1601 */         throw new HessianProtocolException("'" + ref + "' is an unknown class definition");
/*      */       }
/* 1603 */       ObjectDefinition def = (ObjectDefinition)this._classDefs.get(ref);
/*      */ 
/* 1605 */       return readObjectInstance(cl, def);
/*      */     case 85:
/* 1610 */       String type = readType();
/*      */ 
/* 1613 */       Deserializer reader = findSerializerFactory().getListDeserializer(type, cl);
/*      */ 
/* 1615 */       Object v = reader.readList(this, -1);
/*      */ 
/* 1617 */       return v;
/*      */     case 86:
/* 1622 */       String type = readType();
/* 1623 */       int length = readInt();
/*      */ 
/* 1626 */       Deserializer reader = findSerializerFactory().getListDeserializer(type, cl);
/*      */ 
/* 1628 */       Object v = reader.readLengthList(this, length);
/*      */ 
/* 1630 */       return v;
/*      */     case 112:
/*      */     case 113:
/*      */     case 114:
/*      */     case 115:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/*      */     case 119:
/* 1636 */       int length = tag - 112;
/*      */ 
/* 1638 */       String type = readType();
/*      */ 
/* 1641 */       Deserializer reader = findSerializerFactory().getListDeserializer(null, cl);
/*      */ 
/* 1643 */       Object v = reader.readLengthList(this, length);
/*      */ 
/* 1645 */       return v;
/*      */     case 87:
/* 1651 */       Deserializer reader = findSerializerFactory().getListDeserializer(null, cl);
/*      */ 
/* 1653 */       Object v = reader.readList(this, -1);
/*      */ 
/* 1655 */       return v;
/*      */     case 88:
/* 1660 */       int length = readInt();
/*      */ 
/* 1663 */       Deserializer reader = findSerializerFactory().getListDeserializer(null, cl);
/*      */ 
/* 1665 */       Object v = reader.readLengthList(this, length);
/*      */ 
/* 1667 */       return v;
/*      */     case 120:
/*      */     case 121:
/*      */     case 122:
/*      */     case 123:
/*      */     case 124:
/*      */     case 125:
/*      */     case 126:
/*      */     case 127:
/* 1673 */       int length = tag - 120;
/*      */ 
/* 1676 */       Deserializer reader = findSerializerFactory().getListDeserializer(null, cl);
/*      */ 
/* 1678 */       Object v = reader.readLengthList(this, length);
/*      */ 
/* 1680 */       return v;
/*      */     case 81:
/* 1685 */       int ref = readInt();
/*      */ 
/* 1687 */       return this._refs.get(ref);
/*      */     case 68:
/*      */     case 69:
/*      */     case 70:
/*      */     case 71:
/*      */     case 73:
/*      */     case 74:
/*      */     case 75:
/*      */     case 76:
/*      */     case 80:
/*      */     case 82:
/*      */     case 83:
/*      */     case 84:
/*      */     case 89:
/*      */     case 90:
/*      */     case 91:
/*      */     case 92:
/*      */     case 93:
/*      */     case 94:
/* 1691 */     case 95: } if (tag >= 0) {
/* 1692 */       this._offset -= 1;
/*      */     }
/*      */ 
/* 1696 */     Object value = findSerializerFactory().getDeserializer(cl).readObject(this);
/* 1697 */     return value;
/*      */   }
/*      */ 
/*      */   public Object readObject()
/*      */     throws IOException
/*      */   {
/* 1707 */     int tag = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/*      */ 
/* 1709 */     switch (tag) {
/*      */     case 78:
/* 1711 */       return null;
/*      */     case 84:
/* 1714 */       return Boolean.valueOf(true);
/*      */     case 70:
/* 1717 */       return Boolean.valueOf(false);
/*      */     case 128:
/*      */     case 129:
/*      */     case 130:
/*      */     case 131:
/*      */     case 132:
/*      */     case 133:
/*      */     case 134:
/*      */     case 135:
/*      */     case 136:
/*      */     case 137:
/*      */     case 138:
/*      */     case 139:
/*      */     case 140:
/*      */     case 141:
/*      */     case 142:
/*      */     case 143:
/*      */     case 144:
/*      */     case 145:
/*      */     case 146:
/*      */     case 147:
/*      */     case 148:
/*      */     case 149:
/*      */     case 150:
/*      */     case 151:
/*      */     case 152:
/*      */     case 153:
/*      */     case 154:
/*      */     case 155:
/*      */     case 156:
/*      */     case 157:
/*      */     case 158:
/*      */     case 159:
/*      */     case 160:
/*      */     case 161:
/*      */     case 162:
/*      */     case 163:
/*      */     case 164:
/*      */     case 165:
/*      */     case 166:
/*      */     case 167:
/*      */     case 168:
/*      */     case 169:
/*      */     case 170:
/*      */     case 171:
/*      */     case 172:
/*      */     case 173:
/*      */     case 174:
/*      */     case 175:
/*      */     case 176:
/*      */     case 177:
/*      */     case 178:
/*      */     case 179:
/*      */     case 180:
/*      */     case 181:
/*      */     case 182:
/*      */     case 183:
/*      */     case 184:
/*      */     case 185:
/*      */     case 186:
/*      */     case 187:
/*      */     case 188:
/*      */     case 189:
/*      */     case 190:
/*      */     case 191:
/* 1739 */       return Integer.valueOf(tag - 144);
/*      */     case 192:
/*      */     case 193:
/*      */     case 194:
/*      */     case 195:
/*      */     case 196:
/*      */     case 197:
/*      */     case 198:
/*      */     case 199:
/*      */     case 200:
/*      */     case 201:
/*      */     case 202:
/*      */     case 203:
/*      */     case 204:
/*      */     case 205:
/*      */     case 206:
/*      */     case 207:
/* 1746 */       return Integer.valueOf((tag - 200 << 8) + read());
/*      */     case 208:
/*      */     case 209:
/*      */     case 210:
/*      */     case 211:
/*      */     case 212:
/*      */     case 213:
/*      */     case 214:
/*      */     case 215:
/* 1751 */       return Integer.valueOf((tag - 212 << 16) + 256 * read() + read());
/*      */     case 73:
/* 1755 */       return Integer.valueOf(parseInt());
/*      */     case 216:
/*      */     case 217:
/*      */     case 218:
/*      */     case 219:
/*      */     case 220:
/*      */     case 221:
/*      */     case 222:
/*      */     case 223:
/*      */     case 224:
/*      */     case 225:
/*      */     case 226:
/*      */     case 227:
/*      */     case 228:
/*      */     case 229:
/*      */     case 230:
/*      */     case 231:
/*      */     case 232:
/*      */     case 233:
/*      */     case 234:
/*      */     case 235:
/*      */     case 236:
/*      */     case 237:
/*      */     case 238:
/*      */     case 239:
/* 1765 */       return Long.valueOf(tag - 224);
/*      */     case 240:
/*      */     case 241:
/*      */     case 242:
/*      */     case 243:
/*      */     case 244:
/*      */     case 245:
/*      */     case 246:
/*      */     case 247:
/*      */     case 248:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/*      */     case 253:
/*      */     case 254:
/*      */     case 255:
/* 1772 */       return Long.valueOf((tag - 248 << 8) + read());
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/* 1777 */       return Long.valueOf((tag - 60 << 16) + 256 * read() + read());
/*      */     case 89:
/* 1780 */       return Long.valueOf(parseInt());
/*      */     case 76:
/* 1783 */       return Long.valueOf(parseLong());
/*      */     case 91:
/* 1786 */       return Double.valueOf(0.0D);
/*      */     case 92:
/* 1789 */       return Double.valueOf(1.0D);
/*      */     case 93:
/* 1792 */       return Double.valueOf((byte)read());
/*      */     case 94:
/* 1795 */       return Double.valueOf((short)(256 * read() + read()));
/*      */     case 95:
/* 1799 */       int mills = parseInt();
/*      */ 
/* 1801 */       return Double.valueOf(0.001D * mills);
/*      */     case 68:
/* 1805 */       return Double.valueOf(parseDouble());
/*      */     case 74:
/* 1808 */       return new Date(parseLong());
/*      */     case 75:
/* 1811 */       return new Date(parseInt() * 60000L);
/*      */     case 82:
/*      */     case 83:
/* 1816 */       this._isLastChunk = (tag == 83);
/* 1817 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1820 */       this._sbuf.setLength(0);
/*      */       int data;
/* 1822 */       while ((data = parseChar()) >= 0) {
/* 1823 */         this._sbuf.append((char)data);
/*      */       }
/* 1825 */       return this._sbuf.toString();
/*      */     case 0:
/*      */     case 1:
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/*      */     case 15:
/*      */     case 16:
/*      */     case 17:
/*      */     case 18:
/*      */     case 19:
/*      */     case 20:
/*      */     case 21:
/*      */     case 22:
/*      */     case 23:
/*      */     case 24:
/*      */     case 25:
/*      */     case 26:
/*      */     case 27:
/*      */     case 28:
/*      */     case 29:
/*      */     case 30:
/*      */     case 31:
/* 1838 */       this._isLastChunk = true;
/* 1839 */       this._chunkLength = (tag - 0);
/*      */ 
/* 1842 */       this._sbuf.setLength(0);
/*      */       int data;
/* 1844 */       while ((data = parseChar()) >= 0) {
/* 1845 */         this._sbuf.append((char)data);
/*      */       }
/* 1847 */       return this._sbuf.toString();
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/* 1852 */       this._isLastChunk = true;
/* 1853 */       this._chunkLength = ((tag - 48) * 256 + read());
/*      */ 
/* 1855 */       this._sbuf.setLength(0);
/*      */       int ch;
/* 1858 */       while ((ch = parseChar()) >= 0) {
/* 1859 */         this._sbuf.append((char)ch);
/*      */       }
/* 1861 */       return this._sbuf.toString();
/*      */     case 65:
/*      */     case 66:
/* 1867 */       this._isLastChunk = (tag == 66);
/* 1868 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1871 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*      */       int data;
/* 1873 */       while ((data = parseByte()) >= 0) {
/* 1874 */         bos.write(data);
/*      */       }
/* 1876 */       return bos.toByteArray();
/*      */     case 32:
/*      */     case 33:
/*      */     case 34:
/*      */     case 35:
/*      */     case 36:
/*      */     case 37:
/*      */     case 38:
/*      */     case 39:
/*      */     case 40:
/*      */     case 41:
/*      */     case 42:
/*      */     case 43:
/*      */     case 44:
/*      */     case 45:
/*      */     case 46:
/*      */     case 47:
/* 1884 */       this._isLastChunk = true;
/* 1885 */       int len = tag - 32;
/* 1886 */       this._chunkLength = 0;
/*      */ 
/* 1888 */       byte[] data = new byte[len];
/*      */ 
/* 1890 */       for (int i = 0; i < len; i++) {
/* 1891 */         data[i] = ((byte)read());
/*      */       }
/* 1893 */       return data;
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/* 1898 */       this._isLastChunk = true;
/* 1899 */       int len = (tag - 52) * 256 + read();
/* 1900 */       this._chunkLength = 0;
/*      */ 
/* 1902 */       byte[] buffer = new byte[len];
/*      */ 
/* 1904 */       for (int i = 0; i < len; i++) {
/* 1905 */         buffer[i] = ((byte)read());
/*      */       }
/*      */ 
/* 1908 */       return buffer;
/*      */     case 85:
/* 1914 */       String type = readType();
/*      */ 
/* 1916 */       return findSerializerFactory().readList(this, -1, type);
/*      */     case 87:
/* 1921 */       return findSerializerFactory().readList(this, -1, null);
/*      */     case 86:
/* 1927 */       String type = readType();
/* 1928 */       int length = readInt();
/*      */ 
/* 1931 */       Deserializer reader = findSerializerFactory().getListDeserializer(type, null);
/*      */ 
/* 1933 */       return reader.readLengthList(this, length);
/*      */     case 88:
/* 1939 */       int length = readInt();
/*      */ 
/* 1942 */       Deserializer reader = findSerializerFactory().getListDeserializer(null, null);
/*      */ 
/* 1944 */       return reader.readLengthList(this, length);
/*      */     case 112:
/*      */     case 113:
/*      */     case 114:
/*      */     case 115:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/*      */     case 119:
/* 1952 */       String type = readType();
/* 1953 */       int length = tag - 112;
/*      */ 
/* 1956 */       Deserializer reader = findSerializerFactory().getListDeserializer(type, null);
/*      */ 
/* 1958 */       return reader.readLengthList(this, length);
/*      */     case 120:
/*      */     case 121:
/*      */     case 122:
/*      */     case 123:
/*      */     case 124:
/*      */     case 125:
/*      */     case 126:
/*      */     case 127:
/* 1966 */       int length = tag - 120;
/*      */ 
/* 1969 */       Deserializer reader = findSerializerFactory().getListDeserializer(null, null);
/*      */ 
/* 1971 */       return reader.readLengthList(this, length);
/*      */     case 72:
/* 1976 */       return findSerializerFactory().readMap(this, null);
/*      */     case 77:
/* 1981 */       String type = readType();
/*      */ 
/* 1983 */       return findSerializerFactory().readMap(this, type);
/*      */     case 67:
/* 1988 */       readObjectDefinition(null);
/*      */ 
/* 1990 */       return readObject();
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 99:
/*      */     case 100:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/* 1998 */       int ref = tag - 96;
/*      */ 
/* 2000 */       if (this._classDefs == null) {
/* 2001 */         throw error("No classes defined at reference '{0}'" + tag);
/*      */       }
/* 2003 */       ObjectDefinition def = (ObjectDefinition)this._classDefs.get(ref);
/*      */ 
/* 2005 */       return readObjectInstance(null, def);
/*      */     case 79:
/* 2010 */       int ref = readInt();
/*      */ 
/* 2012 */       ObjectDefinition def = (ObjectDefinition)this._classDefs.get(ref);
/*      */ 
/* 2014 */       return readObjectInstance(null, def);
/*      */     case 81:
/* 2019 */       int ref = readInt();
/*      */ 
/* 2021 */       return this._refs.get(ref);
/*      */     case 64:
/*      */     case 69:
/*      */     case 71:
/*      */     case 80:
/* 2025 */     case 90: } if (tag < 0) {
/* 2026 */       throw new EOFException("readObject: unexpected end of file");
/*      */     }
/* 2028 */     throw error("readObject: unknown code " + codeName(tag));
/*      */   }
/*      */ 
/*      */   private void readObjectDefinition(Class cl)
/*      */     throws IOException
/*      */   {
/* 2042 */     String type = readString();
/* 2043 */     int len = readInt();
/*      */ 
/* 2045 */     String[] fieldNames = new String[len];
/* 2046 */     for (int i = 0; i < len; i++) {
/* 2047 */       fieldNames[i] = readString();
/*      */     }
/* 2049 */     ObjectDefinition def = new ObjectDefinition(type, fieldNames);
/*      */ 
/* 2051 */     if (this._classDefs == null) {
/* 2052 */       this._classDefs = new ArrayList();
/*      */     }
/* 2054 */     this._classDefs.add(def);
/*      */   }
/*      */ 
/*      */   private Object readObjectInstance(Class cl, ObjectDefinition def)
/*      */     throws IOException
/*      */   {
/* 2060 */     String type = def.getType();
/* 2061 */     String[] fieldNames = def.getFieldNames();
/*      */ 
/* 2063 */     if (cl != null)
/*      */     {
/* 2065 */       Deserializer reader = findSerializerFactory().getObjectDeserializer(type, cl);
/*      */ 
/* 2067 */       return reader.readObject(this, fieldNames);
/*      */     }
/*      */ 
/* 2070 */     return findSerializerFactory().readObject(this, type, fieldNames);
/*      */   }
/*      */ 
/*      */   private String readLenString()
/*      */     throws IOException
/*      */   {
/* 2077 */     int len = readInt();
/*      */ 
/* 2079 */     this._isLastChunk = true;
/* 2080 */     this._chunkLength = len;
/*      */ 
/* 2082 */     this._sbuf.setLength(0);
/*      */     int ch;
/* 2084 */     while ((ch = parseChar()) >= 0) {
/* 2085 */       this._sbuf.append((char)ch);
/*      */     }
/* 2087 */     return this._sbuf.toString();
/*      */   }
/*      */ 
/*      */   private String readLenString(int len)
/*      */     throws IOException
/*      */   {
/* 2093 */     this._isLastChunk = true;
/* 2094 */     this._chunkLength = len;
/*      */ 
/* 2096 */     this._sbuf.setLength(0);
/*      */     int ch;
/* 2098 */     while ((ch = parseChar()) >= 0) {
/* 2099 */       this._sbuf.append((char)ch);
/*      */     }
/* 2101 */     return this._sbuf.toString();
/*      */   }
/*      */ 
/*      */   public Object readRemote()
/*      */     throws IOException
/*      */   {
/* 2110 */     String type = readType();
/* 2111 */     String url = readString();
/*      */ 
/* 2113 */     return resolveRemote(type, url);
/*      */   }
/*      */ 
/*      */   public Object readRef()
/*      */     throws IOException
/*      */   {
/* 2122 */     return this._refs.get(parseInt());
/*      */   }
/*      */ 
/*      */   public int readListStart()
/*      */     throws IOException
/*      */   {
/* 2131 */     return read();
/*      */   }
/*      */ 
/*      */   public int readMapStart()
/*      */     throws IOException
/*      */   {
/* 2140 */     return read();
/*      */   }
/*      */ 
/*      */   public boolean isEnd()
/*      */     throws IOException
/*      */   {
/*      */     int code;
/*      */     int code;
/* 2151 */     if (this._offset < this._length) {
/* 2152 */       code = this._buffer[this._offset] & 0xFF;
/*      */     } else {
/* 2154 */       code = read();
/*      */ 
/* 2156 */       if (code >= 0) {
/* 2157 */         this._offset -= 1;
/*      */       }
/*      */     }
/* 2160 */     return (code < 0) || (code == 90);
/*      */   }
/*      */ 
/*      */   public void readEnd()
/*      */     throws IOException
/*      */   {
/* 2169 */     int code = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/*      */ 
/* 2171 */     if (code == 90)
/* 2172 */       return;
/* 2173 */     if (code < 0) {
/* 2174 */       throw error("unexpected end of file");
/*      */     }
/* 2176 */     throw error("unknown code:" + codeName(code));
/*      */   }
/*      */ 
/*      */   public void readMapEnd()
/*      */     throws IOException
/*      */   {
/* 2185 */     int code = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/*      */ 
/* 2187 */     if (code != 90)
/* 2188 */       throw error("expected end of map ('Z') at '" + codeName(code) + "'");
/*      */   }
/*      */ 
/*      */   public void readListEnd()
/*      */     throws IOException
/*      */   {
/* 2197 */     int code = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/*      */ 
/* 2199 */     if (code != 90)
/* 2200 */       throw error("expected end of list ('Z') at '" + codeName(code) + "'");
/*      */   }
/*      */ 
/*      */   public int addRef(Object ref)
/*      */   {
/* 2208 */     if (this._refs == null) {
/* 2209 */       this._refs = new ArrayList();
/*      */     }
/* 2211 */     this._refs.add(ref);
/*      */ 
/* 2213 */     return this._refs.size() - 1;
/*      */   }
/*      */ 
/*      */   public void setRef(int i, Object ref)
/*      */   {
/* 2221 */     this._refs.set(i, ref);
/*      */   }
/*      */ 
/*      */   public void resetReferences()
/*      */   {
/* 2229 */     if (this._refs != null)
/* 2230 */       this._refs.clear();
/*      */   }
/*      */ 
/*      */   public Object readStreamingObject()
/*      */     throws IOException
/*      */   {
/* 2236 */     if (this._refs != null) {
/* 2237 */       this._refs.clear();
/*      */     }
/* 2239 */     return readObject();
/*      */   }
/*      */ 
/*      */   public Object resolveRemote(String type, String url)
/*      */     throws IOException
/*      */   {
/* 2248 */     HessianRemoteResolver resolver = getRemoteResolver();
/*      */ 
/* 2250 */     if (resolver != null) {
/* 2251 */       return resolver.lookup(type, url);
/*      */     }
/* 2253 */     return new HessianRemote(type, url);
/*      */   }
/*      */ 
/*      */   public String readType()
/*      */     throws IOException
/*      */   {
/* 2267 */     int code = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/* 2268 */     this._offset -= 1;
/*      */ 
/* 2270 */     switch (code) { case 0:
/*      */     case 1:
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/*      */     case 15:
/*      */     case 16:
/*      */     case 17:
/*      */     case 18:
/*      */     case 19:
/*      */     case 20:
/*      */     case 21:
/*      */     case 22:
/*      */     case 23:
/*      */     case 24:
/*      */     case 25:
/*      */     case 26:
/*      */     case 27:
/*      */     case 28:
/*      */     case 29:
/*      */     case 30:
/*      */     case 31:
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 82:
/*      */     case 83:
/* 2284 */       String type = readString();
/*      */ 
/* 2286 */       if (this._types == null) {
/* 2287 */         this._types = new ArrayList();
/*      */       }
/* 2289 */       this._types.add(type);
/*      */ 
/* 2291 */       return type;
/*      */     case 32:
/*      */     case 33:
/*      */     case 34:
/*      */     case 35:
/*      */     case 36:
/*      */     case 37:
/*      */     case 38:
/*      */     case 39:
/*      */     case 40:
/*      */     case 41:
/*      */     case 42:
/*      */     case 43:
/*      */     case 44:
/*      */     case 45:
/*      */     case 46:
/*      */     case 47:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/*      */     case 64:
/*      */     case 65:
/*      */     case 66:
/*      */     case 67:
/*      */     case 68:
/*      */     case 69:
/*      */     case 70:
/*      */     case 71:
/*      */     case 72:
/*      */     case 73:
/*      */     case 74:
/*      */     case 75:
/*      */     case 76:
/*      */     case 77:
/*      */     case 78:
/*      */     case 79:
/*      */     case 80:
/* 2296 */     case 81: } int ref = readInt();
/*      */ 
/* 2298 */     if (this._types.size() <= ref) {
/* 2299 */       throw new IndexOutOfBoundsException("type ref #" + ref + " is greater than the number of valid types (" + this._types.size() + ")");
/*      */     }
/* 2301 */     return (String)this._types.get(ref);
/*      */   }
/*      */ 
/*      */   public int readLength()
/*      */     throws IOException
/*      */   {
/* 2316 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   private int parseInt()
/*      */     throws IOException
/*      */   {
/* 2329 */     int offset = this._offset;
/*      */ 
/* 2331 */     if (offset + 3 < this._length) {
/* 2332 */       byte[] buffer = this._buffer;
/*      */ 
/* 2334 */       int b32 = buffer[(offset + 0)] & 0xFF;
/* 2335 */       int b24 = buffer[(offset + 1)] & 0xFF;
/* 2336 */       int b16 = buffer[(offset + 2)] & 0xFF;
/* 2337 */       int b8 = buffer[(offset + 3)] & 0xFF;
/*      */ 
/* 2339 */       this._offset = (offset + 4);
/*      */ 
/* 2341 */       return (b32 << 24) + (b24 << 16) + (b16 << 8) + b8;
/*      */     }
/*      */ 
/* 2344 */     int b32 = read();
/* 2345 */     int b24 = read();
/* 2346 */     int b16 = read();
/* 2347 */     int b8 = read();
/*      */ 
/* 2349 */     return (b32 << 24) + (b24 << 16) + (b16 << 8) + b8;
/*      */   }
/*      */ 
/*      */   private long parseLong()
/*      */     throws IOException
/*      */   {
/* 2363 */     long b64 = read();
/* 2364 */     long b56 = read();
/* 2365 */     long b48 = read();
/* 2366 */     long b40 = read();
/* 2367 */     long b32 = read();
/* 2368 */     long b24 = read();
/* 2369 */     long b16 = read();
/* 2370 */     long b8 = read();
/*      */ 
/* 2372 */     return (b64 << 56) + (b56 << 48) + (b48 << 40) + (b40 << 32) + (b32 << 24) + (b24 << 16) + (b16 << 8) + b8;
/*      */   }
/*      */ 
/*      */   private double parseDouble()
/*      */     throws IOException
/*      */   {
/* 2392 */     long bits = parseLong();
/*      */ 
/* 2394 */     return Double.longBitsToDouble(bits);
/*      */   }
/*      */ 
/*      */   Node parseXML()
/*      */     throws IOException
/*      */   {
/* 2400 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   private int parseChar()
/*      */     throws IOException
/*      */   {
/* 2409 */     while (this._chunkLength <= 0) {
/* 2410 */       if (this._isLastChunk) {
/* 2411 */         return -1;
/*      */       }
/* 2413 */       int code = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/*      */ 
/* 2415 */       switch (code) {
/*      */       case 82:
/* 2417 */         this._isLastChunk = false;
/*      */ 
/* 2419 */         this._chunkLength = ((read() << 8) + read());
/* 2420 */         break;
/*      */       case 83:
/* 2423 */         this._isLastChunk = true;
/*      */ 
/* 2425 */         this._chunkLength = ((read() << 8) + read());
/* 2426 */         break;
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 28:
/*      */       case 29:
/*      */       case 30:
/*      */       case 31:
/* 2437 */         this._isLastChunk = true;
/* 2438 */         this._chunkLength = (code - 0);
/* 2439 */         break;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/* 2443 */         this._isLastChunk = true;
/* 2444 */         this._chunkLength = ((code - 48 << 8) + read());
/* 2445 */         break;
/*      */       case 32:
/*      */       case 33:
/*      */       case 34:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 45:
/*      */       case 46:
/*      */       case 47:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 64:
/*      */       case 65:
/*      */       case 66:
/*      */       case 67:
/*      */       case 68:
/*      */       case 69:
/*      */       case 70:
/*      */       case 71:
/*      */       case 72:
/*      */       case 73:
/*      */       case 74:
/*      */       case 75:
/*      */       case 76:
/*      */       case 77:
/*      */       case 78:
/*      */       case 79:
/*      */       case 80:
/*      */       case 81:
/*      */       default:
/* 2448 */         throw expect("string", code);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2453 */     this._chunkLength -= 1;
/*      */ 
/* 2455 */     return parseUTF8Char();
/*      */   }
/*      */ 
/*      */   private int parseUTF8Char()
/*      */     throws IOException
/*      */   {
/* 2464 */     int ch = this._offset < this._length ? this._buffer[(this._offset++)] & 0xFF : read();
/*      */ 
/* 2466 */     if (ch < 128)
/* 2467 */       return ch;
/* 2468 */     if ((ch & 0xE0) == 192) {
/* 2469 */       int ch1 = read();
/* 2470 */       int v = ((ch & 0x1F) << 6) + (ch1 & 0x3F);
/*      */ 
/* 2472 */       return v;
/*      */     }
/* 2474 */     if ((ch & 0xF0) == 224) {
/* 2475 */       int ch1 = read();
/* 2476 */       int ch2 = read();
/* 2477 */       int v = ((ch & 0xF) << 12) + ((ch1 & 0x3F) << 6) + (ch2 & 0x3F);
/*      */ 
/* 2479 */       return v;
/*      */     }
/*      */ 
/* 2482 */     throw error("bad utf-8 encoding at " + codeName(ch));
/*      */   }
/*      */ 
/*      */   private int parseByte()
/*      */     throws IOException
/*      */   {
/* 2491 */     while (this._chunkLength <= 0) {
/* 2492 */       if (this._isLastChunk) {
/* 2493 */         return -1;
/*      */       }
/*      */ 
/* 2496 */       int code = read();
/*      */ 
/* 2498 */       switch (code) {
/*      */       case 65:
/* 2500 */         this._isLastChunk = false;
/*      */ 
/* 2502 */         this._chunkLength = ((read() << 8) + read());
/* 2503 */         break;
/*      */       case 66:
/* 2506 */         this._isLastChunk = true;
/*      */ 
/* 2508 */         this._chunkLength = ((read() << 8) + read());
/* 2509 */         break;
/*      */       case 32:
/*      */       case 33:
/*      */       case 34:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 45:
/*      */       case 46:
/*      */       case 47:
/* 2515 */         this._isLastChunk = true;
/*      */ 
/* 2517 */         this._chunkLength = (code - 32);
/* 2518 */         break;
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/* 2521 */         this._isLastChunk = true;
/* 2522 */         this._chunkLength = ((code - 52) * 256 + read());
/* 2523 */         break;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*      */       case 64:
/*      */       default:
/* 2526 */         throw expect("byte[]", code);
/*      */       }
/*      */     }
/*      */ 
/* 2530 */     this._chunkLength -= 1;
/*      */ 
/* 2532 */     return read();
/*      */   }
/*      */ 
/*      */   public InputStream readInputStream()
/*      */     throws IOException
/*      */   {
/* 2541 */     int tag = read();
/*      */ 
/* 2543 */     switch (tag) {
/*      */     case 78:
/* 2545 */       return null;
/*      */     case 66:
/*      */     case 98:
/* 2549 */       this._isLastChunk = (tag == 66);
/* 2550 */       this._chunkLength = ((read() << 8) + read());
/* 2551 */       break;
/*      */     case 32:
/*      */     case 33:
/*      */     case 34:
/*      */     case 35:
/*      */     case 36:
/*      */     case 37:
/*      */     case 38:
/*      */     case 39:
/*      */     case 40:
/*      */     case 41:
/*      */     case 42:
/*      */     case 43:
/*      */     case 44:
/*      */     case 45:
/*      */     case 46:
/*      */     case 47:
/* 2557 */       this._isLastChunk = true;
/* 2558 */       this._chunkLength = (tag - 32);
/* 2559 */       break;
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/*      */     case 64:
/*      */     case 65:
/*      */     case 67:
/*      */     case 68:
/*      */     case 69:
/*      */     case 70:
/*      */     case 71:
/*      */     case 72:
/*      */     case 73:
/*      */     case 74:
/*      */     case 75:
/*      */     case 76:
/*      */     case 77:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 82:
/*      */     case 83:
/*      */     case 84:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 89:
/*      */     case 90:
/*      */     case 91:
/*      */     case 92:
/*      */     case 93:
/*      */     case 94:
/*      */     case 95:
/*      */     case 96:
/*      */     case 97:
/*      */     default:
/* 2562 */       throw expect("binary", tag);
/*      */     }
/*      */ 
/* 2565 */     return new ReadInputStream();
/*      */   }
/*      */ 
/*      */   int read(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 2574 */     int readLength = 0;
/*      */ 
/* 2576 */     while (length > 0) {
/* 2577 */       while (this._chunkLength <= 0) {
/* 2578 */         if (this._isLastChunk) {
/* 2579 */           return readLength == 0 ? -1 : readLength;
/*      */         }
/* 2581 */         int code = read();
/*      */ 
/* 2583 */         switch (code) {
/*      */         case 98:
/* 2585 */           this._isLastChunk = false;
/*      */ 
/* 2587 */           this._chunkLength = ((read() << 8) + read());
/* 2588 */           break;
/*      */         case 66:
/* 2591 */           this._isLastChunk = true;
/*      */ 
/* 2593 */           this._chunkLength = ((read() << 8) + read());
/* 2594 */           break;
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */         case 42:
/*      */         case 43:
/*      */         case 44:
/*      */         case 45:
/*      */         case 46:
/*      */         case 47:
/* 2600 */           this._isLastChunk = true;
/* 2601 */           this._chunkLength = (code - 32);
/* 2602 */           break;
/*      */         case 48:
/*      */         case 49:
/*      */         case 50:
/*      */         case 51:
/*      */         case 52:
/*      */         case 53:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 58:
/*      */         case 59:
/*      */         case 60:
/*      */         case 61:
/*      */         case 62:
/*      */         case 63:
/*      */         case 64:
/*      */         case 65:
/*      */         case 67:
/*      */         case 68:
/*      */         case 69:
/*      */         case 70:
/*      */         case 71:
/*      */         case 72:
/*      */         case 73:
/*      */         case 74:
/*      */         case 75:
/*      */         case 76:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/*      */         case 82:
/*      */         case 83:
/*      */         case 84:
/*      */         case 85:
/*      */         case 86:
/*      */         case 87:
/*      */         case 88:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/*      */         case 94:
/*      */         case 95:
/*      */         case 96:
/*      */         case 97:
/*      */         default:
/* 2605 */           throw expect("byte[]", code);
/*      */         }
/*      */       }
/*      */ 
/* 2609 */       int sublen = this._chunkLength;
/* 2610 */       if (length < sublen) {
/* 2611 */         sublen = length;
/*      */       }
/* 2613 */       if ((this._length <= this._offset) && (!readBuffer())) {
/* 2614 */         return -1;
/*      */       }
/* 2616 */       if (this._length - this._offset < sublen) {
/* 2617 */         sublen = this._length - this._offset;
/*      */       }
/* 2619 */       System.arraycopy(this._buffer, this._offset, buffer, offset, sublen);
/*      */ 
/* 2621 */       this._offset += sublen;
/*      */ 
/* 2623 */       offset += sublen;
/* 2624 */       readLength += sublen;
/* 2625 */       length -= sublen;
/* 2626 */       this._chunkLength -= sublen;
/*      */     }
/*      */ 
/* 2629 */     return readLength;
/*      */   }
/*      */ 
/*      */   public final int read()
/*      */     throws IOException
/*      */   {
/* 2639 */     if ((this._length <= this._offset) && (!readBuffer())) {
/* 2640 */       return -1;
/*      */     }
/* 2642 */     return this._buffer[(this._offset++)] & 0xFF;
/*      */   }
/*      */ 
/*      */   private final boolean readBuffer()
/*      */     throws IOException
/*      */   {
/* 2648 */     byte[] buffer = this._buffer;
/* 2649 */     int offset = this._offset;
/* 2650 */     int length = this._length;
/*      */ 
/* 2652 */     if (offset < length) {
/* 2653 */       System.arraycopy(buffer, offset, buffer, 0, length - offset);
/* 2654 */       offset = length - offset;
/*      */     }
/*      */     else {
/* 2657 */       offset = 0;
/*      */     }
/* 2659 */     int len = this._is.read(buffer, offset, 256 - offset);
/*      */ 
/* 2661 */     if (len <= 0) {
/* 2662 */       this._length = offset;
/* 2663 */       this._offset = 0;
/*      */ 
/* 2665 */       return offset > 0;
/*      */     }
/*      */ 
/* 2668 */     this._length = (offset + len);
/* 2669 */     this._offset = 0;
/*      */ 
/* 2671 */     return true;
/*      */   }
/*      */ 
/*      */   public Reader getReader()
/*      */   {
/* 2676 */     return null;
/*      */   }
/*      */ 
/*      */   protected IOException expect(String expect, int ch)
/*      */     throws IOException
/*      */   {
/* 2682 */     if (ch < 0) {
/* 2683 */       return error("expected " + expect + " at end of file");
/*      */     }
/* 2685 */     this._offset -= 1;
/*      */     try
/*      */     {
/* 2688 */       Object obj = readObject();
/*      */ 
/* 2690 */       if (obj != null) {
/* 2691 */         return error("expected " + expect + " at 0x" + Integer.toHexString(ch & 0xFF) + " " + obj.getClass().getName() + " (" + obj + ")");
/*      */       }
/*      */ 
/* 2696 */       return error("expected " + expect + " at 0x" + Integer.toHexString(ch & 0xFF) + " null");
/*      */     }
/*      */     catch (IOException e) {
/* 2699 */       log.log(Level.FINE, e.toString(), e);
/*      */     }
/* 2701 */     return error("expected " + expect + " at 0x" + Integer.toHexString(ch & 0xFF));
/*      */   }
/*      */ 
/*      */   protected String codeName(int ch)
/*      */   {
/* 2709 */     if (ch < 0) {
/* 2710 */       return "end of file";
/*      */     }
/* 2712 */     return "0x" + Integer.toHexString(ch & 0xFF) + " (" + (char)ch + ")";
/*      */   }
/*      */ 
/*      */   protected IOException error(String message)
/*      */   {
/* 2717 */     if (this._method != null) {
/* 2718 */       return new HessianProtocolException(this._method + ": " + message);
/*      */     }
/* 2720 */     return new HessianProtocolException(message);
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/* 2726 */     InputStream is = this._is;
/* 2727 */     this._is = null;
/*      */ 
/* 2729 */     if ((_isCloseStreamOnClose) && (is != null))
/* 2730 */       is.close();
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/* 2793 */       _detailMessageField = Throwable.class.getDeclaredField("detailMessage");
/* 2794 */       _detailMessageField.setAccessible(true);
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   static final class ObjectDefinition
/*      */   {
/*      */     private final String _type;
/*      */     private final String[] _fields;
/*      */ 
/*      */     ObjectDefinition(String type, String[] fields)
/*      */     {
/* 2776 */       this._type = type;
/* 2777 */       this._fields = fields;
/*      */     }
/*      */ 
/*      */     String getType()
/*      */     {
/* 2782 */       return this._type;
/*      */     }
/*      */ 
/*      */     String[] getFieldNames()
/*      */     {
/* 2787 */       return this._fields;
/*      */     }
/*      */   }
/*      */ 
/*      */   class ReadInputStream extends InputStream
/*      */   {
/* 2734 */     boolean _isClosed = false;
/*      */ 
/*      */     ReadInputStream() {
/*      */     }
/*      */     public int read() throws IOException {
/* 2739 */       if (this._isClosed) {
/* 2740 */         return -1;
/*      */       }
/* 2742 */       int ch = Hessian2Input.this.parseByte();
/* 2743 */       if (ch < 0) {
/* 2744 */         this._isClosed = true;
/*      */       }
/* 2746 */       return ch;
/*      */     }
/*      */ 
/*      */     public int read(byte[] buffer, int offset, int length)
/*      */       throws IOException
/*      */     {
/* 2752 */       if (this._isClosed) {
/* 2753 */         return -1;
/*      */       }
/* 2755 */       int len = Hessian2Input.this.read(buffer, offset, length);
/* 2756 */       if (len < 0) {
/* 2757 */         this._isClosed = true;
/*      */       }
/* 2759 */       return len;
/*      */     }
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 2765 */       while (read() >= 0);
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.Hessian2Input
 * JD-Core Version:    0.6.2
 */