/*      */ package com.alibaba.com.caucho.hessian.io;
/*      */ 
/*      */ import com.alibaba.com.caucho.hessian.util.IdentityIntMap;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.HashMap;
/*      */ 
/*      */ public class Hessian2Output extends AbstractHessianOutput
/*      */   implements Hessian2Constants
/*      */ {
/*      */   protected OutputStream _os;
/*   84 */   private IdentityIntMap _refs = new IdentityIntMap();
/*      */   private boolean _isCloseStreamOnClose;
/*      */   private HashMap _classRefs;
/*      */   private HashMap _typeRefs;
/*      */   public static final int SIZE = 4096;
/*   96 */   private final byte[] _buffer = new byte[4096];
/*      */   private int _offset;
/*      */   private boolean _isStreaming;
/*      */ 
/*      */   public Hessian2Output(OutputStream os)
/*      */   {
/*  109 */     this._os = os;
/*      */   }
/*      */ 
/*      */   public void setCloseStreamOnClose(boolean isClose)
/*      */   {
/*  114 */     this._isCloseStreamOnClose = isClose;
/*      */   }
/*      */ 
/*      */   public boolean isCloseStreamOnClose()
/*      */   {
/*  119 */     return this._isCloseStreamOnClose;
/*      */   }
/*      */ 
/*      */   public void call(String method, Object[] args)
/*      */     throws IOException
/*      */   {
/*  130 */     int length = args != null ? args.length : 0;
/*      */ 
/*  132 */     startCall(method, length);
/*      */ 
/*  134 */     for (int i = 0; i < args.length; i++) {
/*  135 */       writeObject(args[i]);
/*      */     }
/*  137 */     completeCall();
/*      */   }
/*      */ 
/*      */   public void startCall(String method, int length)
/*      */     throws IOException
/*      */   {
/*  156 */     int offset = this._offset;
/*      */ 
/*  158 */     if (4096 < offset + 32) {
/*  159 */       flush();
/*  160 */       offset = this._offset;
/*      */     }
/*      */ 
/*  163 */     byte[] buffer = this._buffer;
/*      */ 
/*  165 */     buffer[(this._offset++)] = 67;
/*      */ 
/*  167 */     writeString(method);
/*  168 */     writeInt(length);
/*      */   }
/*      */ 
/*      */   public void startCall()
/*      */     throws IOException
/*      */   {
/*  184 */     flushIfFull();
/*      */ 
/*  186 */     this._buffer[(this._offset++)] = 67;
/*      */   }
/*      */ 
/*      */   public void startEnvelope(String method)
/*      */     throws IOException
/*      */   {
/*  202 */     int offset = this._offset;
/*      */ 
/*  204 */     if (4096 < offset + 32) {
/*  205 */       flush();
/*  206 */       offset = this._offset;
/*      */     }
/*      */ 
/*  209 */     this._buffer[(this._offset++)] = 69;
/*      */ 
/*  211 */     writeString(method);
/*      */   }
/*      */ 
/*      */   public void completeEnvelope()
/*      */     throws IOException
/*      */   {
/*  226 */     flushIfFull();
/*      */ 
/*  228 */     this._buffer[(this._offset++)] = 90;
/*      */   }
/*      */ 
/*      */   public void writeMethod(String method)
/*      */     throws IOException
/*      */   {
/*  243 */     writeString(method);
/*      */   }
/*      */ 
/*      */   public void completeCall()
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void startReply()
/*      */     throws IOException
/*      */   {
/*  275 */     writeVersion();
/*      */ 
/*  277 */     flushIfFull();
/*      */ 
/*  279 */     this._buffer[(this._offset++)] = 82;
/*      */   }
/*      */ 
/*      */   public void writeVersion()
/*      */     throws IOException
/*      */   {
/*  285 */     flushIfFull();
/*  286 */     this._buffer[(this._offset++)] = 72;
/*  287 */     this._buffer[(this._offset++)] = 2;
/*  288 */     this._buffer[(this._offset++)] = 0;
/*      */   }
/*      */ 
/*      */   public void completeReply()
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void startMessage()
/*      */     throws IOException
/*      */   {
/*  317 */     flushIfFull();
/*      */ 
/*  319 */     this._buffer[(this._offset++)] = 112;
/*  320 */     this._buffer[(this._offset++)] = 2;
/*  321 */     this._buffer[(this._offset++)] = 0;
/*      */   }
/*      */ 
/*      */   public void completeMessage()
/*      */     throws IOException
/*      */   {
/*  336 */     flushIfFull();
/*      */ 
/*  338 */     this._buffer[(this._offset++)] = 122;
/*      */   }
/*      */ 
/*      */   public void writeFault(String code, String message, Object detail)
/*      */     throws IOException
/*      */   {
/*  369 */     flushIfFull();
/*      */ 
/*  371 */     writeVersion();
/*      */ 
/*  373 */     this._buffer[(this._offset++)] = 70;
/*  374 */     this._buffer[(this._offset++)] = 72;
/*      */ 
/*  376 */     this._refs.put(new HashMap(), this._refs.size());
/*      */ 
/*  378 */     writeString("code");
/*  379 */     writeString(code);
/*      */ 
/*  381 */     writeString("message");
/*  382 */     writeString(message);
/*      */ 
/*  384 */     if (detail != null) {
/*  385 */       writeString("detail");
/*  386 */       writeObject(detail);
/*      */     }
/*      */ 
/*  389 */     flushIfFull();
/*  390 */     this._buffer[(this._offset++)] = 90;
/*      */   }
/*      */ 
/*      */   public void writeObject(Object object)
/*      */     throws IOException
/*      */   {
/*  399 */     if (object == null) {
/*  400 */       writeNull();
/*  401 */       return;
/*      */     }
/*      */ 
/*  406 */     Serializer serializer = findSerializerFactory().getSerializer(object.getClass());
/*      */ 
/*  408 */     serializer.writeObject(object, this);
/*      */   }
/*      */ 
/*      */   public boolean writeListBegin(int length, String type)
/*      */     throws IOException
/*      */   {
/*  426 */     flushIfFull();
/*      */ 
/*  428 */     if (length < 0) {
/*  429 */       if (type != null) {
/*  430 */         this._buffer[(this._offset++)] = 85;
/*  431 */         writeType(type);
/*      */       }
/*      */       else {
/*  434 */         this._buffer[(this._offset++)] = 87;
/*      */       }
/*  436 */       return true;
/*      */     }
/*  438 */     if (length <= 7) {
/*  439 */       if (type != null) {
/*  440 */         this._buffer[(this._offset++)] = ((byte)(112 + length));
/*  441 */         writeType(type);
/*      */       }
/*      */       else {
/*  444 */         this._buffer[(this._offset++)] = ((byte)(120 + length));
/*      */       }
/*      */ 
/*  447 */       return false;
/*      */     }
/*      */ 
/*  450 */     if (type != null) {
/*  451 */       this._buffer[(this._offset++)] = 86;
/*  452 */       writeType(type);
/*      */     }
/*      */     else {
/*  455 */       this._buffer[(this._offset++)] = 88;
/*      */     }
/*      */ 
/*  458 */     writeInt(length);
/*      */ 
/*  460 */     return false;
/*      */   }
/*      */ 
/*      */   public void writeListEnd()
/*      */     throws IOException
/*      */   {
/*  470 */     flushIfFull();
/*      */ 
/*  472 */     this._buffer[(this._offset++)] = 90;
/*      */   }
/*      */ 
/*      */   public void writeMapBegin(String type)
/*      */     throws IOException
/*      */   {
/*  488 */     if (4096 < this._offset + 32) {
/*  489 */       flush();
/*      */     }
/*  491 */     if (type != null) {
/*  492 */       this._buffer[(this._offset++)] = 77;
/*      */ 
/*  494 */       writeType(type);
/*      */     }
/*      */     else {
/*  497 */       this._buffer[(this._offset++)] = 72;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeMapEnd()
/*      */     throws IOException
/*      */   {
/*  506 */     if (4096 < this._offset + 32) {
/*  507 */       flush();
/*      */     }
/*  509 */     this._buffer[(this._offset++)] = 90;
/*      */   }
/*      */ 
/*      */   public int writeObjectBegin(String type)
/*      */     throws IOException
/*      */   {
/*  522 */     if (this._classRefs == null) {
/*  523 */       this._classRefs = new HashMap();
/*      */     }
/*  525 */     Integer refV = (Integer)this._classRefs.get(type);
/*      */ 
/*  527 */     if (refV != null) {
/*  528 */       int ref = refV.intValue();
/*      */ 
/*  530 */       if (4096 < this._offset + 32) {
/*  531 */         flush();
/*      */       }
/*  533 */       if (ref <= 15) {
/*  534 */         this._buffer[(this._offset++)] = ((byte)(96 + ref));
/*      */       }
/*      */       else {
/*  537 */         this._buffer[(this._offset++)] = 79;
/*  538 */         writeInt(ref);
/*      */       }
/*      */ 
/*  541 */       return ref;
/*      */     }
/*      */ 
/*  544 */     int ref = this._classRefs.size();
/*      */ 
/*  546 */     this._classRefs.put(type, Integer.valueOf(ref));
/*      */ 
/*  548 */     if (4096 < this._offset + 32) {
/*  549 */       flush();
/*      */     }
/*  551 */     this._buffer[(this._offset++)] = 67;
/*      */ 
/*  553 */     writeString(type);
/*      */ 
/*  555 */     return -1;
/*      */   }
/*      */ 
/*      */   public void writeClassFieldLength(int len)
/*      */     throws IOException
/*      */   {
/*  565 */     writeInt(len);
/*      */   }
/*      */ 
/*      */   public void writeObjectEnd()
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   private void writeType(String type)
/*      */     throws IOException
/*      */   {
/*  585 */     flushIfFull();
/*      */ 
/*  587 */     int len = type.length();
/*  588 */     if (len == 0) {
/*  589 */       throw new IllegalArgumentException("empty type is not allowed");
/*      */     }
/*      */ 
/*  592 */     if (this._typeRefs == null) {
/*  593 */       this._typeRefs = new HashMap();
/*      */     }
/*  595 */     Integer typeRefV = (Integer)this._typeRefs.get(type);
/*      */ 
/*  597 */     if (typeRefV != null) {
/*  598 */       int typeRef = typeRefV.intValue();
/*      */ 
/*  600 */       writeInt(typeRef);
/*      */     }
/*      */     else {
/*  603 */       this._typeRefs.put(type, Integer.valueOf(this._typeRefs.size()));
/*      */ 
/*  605 */       writeString(type);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeBoolean(boolean value)
/*      */     throws IOException
/*      */   {
/*  623 */     if (4096 < this._offset + 16) {
/*  624 */       flush();
/*      */     }
/*  626 */     if (value)
/*  627 */       this._buffer[(this._offset++)] = 84;
/*      */     else
/*  629 */       this._buffer[(this._offset++)] = 70;
/*      */   }
/*      */ 
/*      */   public void writeInt(int value)
/*      */     throws IOException
/*      */   {
/*  645 */     int offset = this._offset;
/*  646 */     byte[] buffer = this._buffer;
/*      */ 
/*  648 */     if (4096 <= offset + 16) {
/*  649 */       flush();
/*  650 */       offset = this._offset;
/*      */     }
/*      */ 
/*  653 */     if ((-16 <= value) && (value <= 47)) {
/*  654 */       buffer[(offset++)] = ((byte)(value + 144));
/*  655 */     } else if ((-2048 <= value) && (value <= 2047)) {
/*  656 */       buffer[(offset++)] = ((byte)(200 + (value >> 8)));
/*  657 */       buffer[(offset++)] = ((byte)value);
/*      */     }
/*  659 */     else if ((-262144 <= value) && (value <= 262143)) {
/*  660 */       buffer[(offset++)] = ((byte)(212 + (value >> 16)));
/*  661 */       buffer[(offset++)] = ((byte)(value >> 8));
/*  662 */       buffer[(offset++)] = ((byte)value);
/*      */     }
/*      */     else {
/*  665 */       buffer[(offset++)] = 73;
/*  666 */       buffer[(offset++)] = ((byte)(value >> 24));
/*  667 */       buffer[(offset++)] = ((byte)(value >> 16));
/*  668 */       buffer[(offset++)] = ((byte)(value >> 8));
/*  669 */       buffer[(offset++)] = ((byte)value);
/*      */     }
/*      */ 
/*  672 */     this._offset = offset;
/*      */   }
/*      */ 
/*      */   public void writeLong(long value)
/*      */     throws IOException
/*      */   {
/*  688 */     int offset = this._offset;
/*  689 */     byte[] buffer = this._buffer;
/*      */ 
/*  691 */     if (4096 <= offset + 16) {
/*  692 */       flush();
/*  693 */       offset = this._offset;
/*      */     }
/*      */ 
/*  696 */     if ((-8L <= value) && (value <= 15L)) {
/*  697 */       buffer[(offset++)] = ((byte)(int)(value + 224L));
/*      */     }
/*  699 */     else if ((-2048L <= value) && (value <= 2047L)) {
/*  700 */       buffer[(offset++)] = ((byte)(int)(248L + (value >> 8)));
/*  701 */       buffer[(offset++)] = ((byte)(int)value);
/*      */     }
/*  703 */     else if ((-262144L <= value) && (value <= 262143L)) {
/*  704 */       buffer[(offset++)] = ((byte)(int)(60L + (value >> 16)));
/*  705 */       buffer[(offset++)] = ((byte)(int)(value >> 8));
/*  706 */       buffer[(offset++)] = ((byte)(int)value);
/*      */     }
/*  708 */     else if ((-2147483648L <= value) && (value <= 2147483647L)) {
/*  709 */       buffer[(offset + 0)] = 89;
/*  710 */       buffer[(offset + 1)] = ((byte)(int)(value >> 24));
/*  711 */       buffer[(offset + 2)] = ((byte)(int)(value >> 16));
/*  712 */       buffer[(offset + 3)] = ((byte)(int)(value >> 8));
/*  713 */       buffer[(offset + 4)] = ((byte)(int)value);
/*      */ 
/*  715 */       offset += 5;
/*      */     }
/*      */     else {
/*  718 */       buffer[(offset + 0)] = 76;
/*  719 */       buffer[(offset + 1)] = ((byte)(int)(value >> 56));
/*  720 */       buffer[(offset + 2)] = ((byte)(int)(value >> 48));
/*  721 */       buffer[(offset + 3)] = ((byte)(int)(value >> 40));
/*  722 */       buffer[(offset + 4)] = ((byte)(int)(value >> 32));
/*  723 */       buffer[(offset + 5)] = ((byte)(int)(value >> 24));
/*  724 */       buffer[(offset + 6)] = ((byte)(int)(value >> 16));
/*  725 */       buffer[(offset + 7)] = ((byte)(int)(value >> 8));
/*  726 */       buffer[(offset + 8)] = ((byte)(int)value);
/*      */ 
/*  728 */       offset += 9;
/*      */     }
/*      */ 
/*  731 */     this._offset = offset;
/*      */   }
/*      */ 
/*      */   public void writeDouble(double value)
/*      */     throws IOException
/*      */   {
/*  747 */     int offset = this._offset;
/*  748 */     byte[] buffer = this._buffer;
/*      */ 
/*  750 */     if (4096 <= offset + 16) {
/*  751 */       flush();
/*  752 */       offset = this._offset;
/*      */     }
/*      */ 
/*  755 */     int intValue = (int)value;
/*      */ 
/*  757 */     if (intValue == value) {
/*  758 */       if (intValue == 0) {
/*  759 */         buffer[(offset++)] = 91;
/*      */ 
/*  761 */         this._offset = offset;
/*      */ 
/*  763 */         return;
/*      */       }
/*  765 */       if (intValue == 1) {
/*  766 */         buffer[(offset++)] = 92;
/*      */ 
/*  768 */         this._offset = offset;
/*      */ 
/*  770 */         return;
/*      */       }
/*  772 */       if ((-128 <= intValue) && (intValue < 128)) {
/*  773 */         buffer[(offset++)] = 93;
/*  774 */         buffer[(offset++)] = ((byte)intValue);
/*      */ 
/*  776 */         this._offset = offset;
/*      */ 
/*  778 */         return;
/*      */       }
/*  780 */       if ((-32768 <= intValue) && (intValue < 32768)) {
/*  781 */         buffer[(offset + 0)] = 94;
/*  782 */         buffer[(offset + 1)] = ((byte)(intValue >> 8));
/*  783 */         buffer[(offset + 2)] = ((byte)intValue);
/*      */ 
/*  785 */         this._offset = (offset + 3);
/*      */ 
/*  787 */         return;
/*      */       }
/*      */     }
/*      */ 
/*  791 */     int mills = (int)(value * 1000.0D);
/*      */ 
/*  793 */     if (0.001D * mills == value) {
/*  794 */       buffer[(offset + 0)] = 95;
/*  795 */       buffer[(offset + 1)] = ((byte)(mills >> 24));
/*  796 */       buffer[(offset + 2)] = ((byte)(mills >> 16));
/*  797 */       buffer[(offset + 3)] = ((byte)(mills >> 8));
/*  798 */       buffer[(offset + 4)] = ((byte)mills);
/*      */ 
/*  800 */       this._offset = (offset + 5);
/*      */ 
/*  802 */       return;
/*      */     }
/*      */ 
/*  805 */     long bits = Double.doubleToLongBits(value);
/*      */ 
/*  807 */     buffer[(offset + 0)] = 68;
/*  808 */     buffer[(offset + 1)] = ((byte)(int)(bits >> 56));
/*  809 */     buffer[(offset + 2)] = ((byte)(int)(bits >> 48));
/*  810 */     buffer[(offset + 3)] = ((byte)(int)(bits >> 40));
/*  811 */     buffer[(offset + 4)] = ((byte)(int)(bits >> 32));
/*  812 */     buffer[(offset + 5)] = ((byte)(int)(bits >> 24));
/*  813 */     buffer[(offset + 6)] = ((byte)(int)(bits >> 16));
/*  814 */     buffer[(offset + 7)] = ((byte)(int)(bits >> 8));
/*  815 */     buffer[(offset + 8)] = ((byte)(int)bits);
/*      */ 
/*  817 */     this._offset = (offset + 9);
/*      */   }
/*      */ 
/*      */   public void writeUTCDate(long time)
/*      */     throws IOException
/*      */   {
/*  833 */     if (4096 < this._offset + 32) {
/*  834 */       flush();
/*      */     }
/*  836 */     int offset = this._offset;
/*  837 */     byte[] buffer = this._buffer;
/*      */ 
/*  839 */     if (time % 60000L == 0L)
/*      */     {
/*  842 */       long minutes = time / 60000L;
/*      */ 
/*  844 */       if ((minutes >> 31 == 0L) || (minutes >> 31 == -1L)) {
/*  845 */         buffer[(offset++)] = 75;
/*  846 */         buffer[(offset++)] = ((byte)(int)(minutes >> 24));
/*  847 */         buffer[(offset++)] = ((byte)(int)(minutes >> 16));
/*  848 */         buffer[(offset++)] = ((byte)(int)(minutes >> 8));
/*  849 */         buffer[(offset++)] = ((byte)(int)(minutes >> 0));
/*      */ 
/*  851 */         this._offset = offset;
/*  852 */         return;
/*      */       }
/*      */     }
/*      */ 
/*  856 */     buffer[(offset++)] = 74;
/*  857 */     buffer[(offset++)] = ((byte)(int)(time >> 56));
/*  858 */     buffer[(offset++)] = ((byte)(int)(time >> 48));
/*  859 */     buffer[(offset++)] = ((byte)(int)(time >> 40));
/*  860 */     buffer[(offset++)] = ((byte)(int)(time >> 32));
/*  861 */     buffer[(offset++)] = ((byte)(int)(time >> 24));
/*  862 */     buffer[(offset++)] = ((byte)(int)(time >> 16));
/*  863 */     buffer[(offset++)] = ((byte)(int)(time >> 8));
/*  864 */     buffer[(offset++)] = ((byte)(int)time);
/*      */ 
/*  866 */     this._offset = offset;
/*      */   }
/*      */ 
/*      */   public void writeNull()
/*      */     throws IOException
/*      */   {
/*  882 */     int offset = this._offset;
/*  883 */     byte[] buffer = this._buffer;
/*      */ 
/*  885 */     if (4096 <= offset + 16) {
/*  886 */       flush();
/*  887 */       offset = this._offset;
/*      */     }
/*      */ 
/*  890 */     buffer[(offset++)] = 78;
/*      */ 
/*  892 */     this._offset = offset;
/*      */   }
/*      */ 
/*      */   public void writeString(String value)
/*      */     throws IOException
/*      */   {
/*  914 */     int offset = this._offset;
/*  915 */     byte[] buffer = this._buffer;
/*      */ 
/*  917 */     if (4096 <= offset + 16) {
/*  918 */       flush();
/*  919 */       offset = this._offset;
/*      */     }
/*      */ 
/*  922 */     if (value == null) {
/*  923 */       buffer[(offset++)] = 78;
/*      */ 
/*  925 */       this._offset = offset;
/*      */     }
/*      */     else {
/*  928 */       int length = value.length();
/*  929 */       int strOffset = 0;
/*      */ 
/*  931 */       while (length > 32768) {
/*  932 */         int sublen = 32768;
/*      */ 
/*  934 */         offset = this._offset;
/*      */ 
/*  936 */         if (4096 <= offset + 16) {
/*  937 */           flush();
/*  938 */           offset = this._offset;
/*      */         }
/*      */ 
/*  942 */         char tail = value.charAt(strOffset + sublen - 1);
/*      */ 
/*  944 */         if ((55296 <= tail) && (tail <= 56319)) {
/*  945 */           sublen--;
/*      */         }
/*  947 */         buffer[(offset + 0)] = 82;
/*  948 */         buffer[(offset + 1)] = ((byte)(sublen >> 8));
/*  949 */         buffer[(offset + 2)] = ((byte)sublen);
/*      */ 
/*  951 */         this._offset = (offset + 3);
/*      */ 
/*  953 */         printString(value, strOffset, sublen);
/*      */ 
/*  955 */         length -= sublen;
/*  956 */         strOffset += sublen;
/*      */       }
/*      */ 
/*  959 */       offset = this._offset;
/*      */ 
/*  961 */       if (4096 <= offset + 16) {
/*  962 */         flush();
/*  963 */         offset = this._offset;
/*      */       }
/*      */ 
/*  966 */       if (length <= 31) {
/*  967 */         buffer[(offset++)] = ((byte)(0 + length));
/*      */       }
/*  969 */       else if (length <= 1023) {
/*  970 */         buffer[(offset++)] = ((byte)(48 + (length >> 8)));
/*  971 */         buffer[(offset++)] = ((byte)length);
/*      */       }
/*      */       else {
/*  974 */         buffer[(offset++)] = 83;
/*  975 */         buffer[(offset++)] = ((byte)(length >> 8));
/*  976 */         buffer[(offset++)] = ((byte)length);
/*      */       }
/*      */ 
/*  979 */       this._offset = offset;
/*      */ 
/*  981 */       printString(value, strOffset, length);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeString(char[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1004 */     if (buffer == null) {
/* 1005 */       if (4096 < this._offset + 16) {
/* 1006 */         flush();
/*      */       }
/* 1008 */       this._buffer[(this._offset++)] = 78;
/*      */     }
/*      */     else {
/* 1011 */       while (length > 32768) {
/* 1012 */         int sublen = 32768;
/*      */ 
/* 1014 */         if (4096 < this._offset + 16) {
/* 1015 */           flush();
/*      */         }
/*      */ 
/* 1018 */         char tail = buffer[(offset + sublen - 1)];
/*      */ 
/* 1020 */         if ((55296 <= tail) && (tail <= 56319)) {
/* 1021 */           sublen--;
/*      */         }
/* 1023 */         this._buffer[(this._offset++)] = 82;
/* 1024 */         this._buffer[(this._offset++)] = ((byte)(sublen >> 8));
/* 1025 */         this._buffer[(this._offset++)] = ((byte)sublen);
/*      */ 
/* 1027 */         printString(buffer, offset, sublen);
/*      */ 
/* 1029 */         length -= sublen;
/* 1030 */         offset += sublen;
/*      */       }
/*      */ 
/* 1033 */       if (4096 < this._offset + 16) {
/* 1034 */         flush();
/*      */       }
/* 1036 */       if (length <= 31) {
/* 1037 */         this._buffer[(this._offset++)] = ((byte)(0 + length));
/*      */       }
/* 1039 */       else if (length <= 1023) {
/* 1040 */         this._buffer[(this._offset++)] = ((byte)(48 + (length >> 8)));
/* 1041 */         this._buffer[(this._offset++)] = ((byte)length);
/*      */       }
/*      */       else {
/* 1044 */         this._buffer[(this._offset++)] = 83;
/* 1045 */         this._buffer[(this._offset++)] = ((byte)(length >> 8));
/* 1046 */         this._buffer[(this._offset++)] = ((byte)length);
/*      */       }
/*      */ 
/* 1049 */       printString(buffer, offset, length);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeBytes(byte[] buffer)
/*      */     throws IOException
/*      */   {
/* 1072 */     if (buffer == null) {
/* 1073 */       if (4096 < this._offset + 16) {
/* 1074 */         flush();
/*      */       }
/* 1076 */       this._buffer[(this._offset++)] = 78;
/*      */     }
/*      */     else {
/* 1079 */       writeBytes(buffer, 0, buffer.length);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeBytes(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1101 */     if (buffer == null) {
/* 1102 */       if (4096 < this._offset + 16) {
/* 1103 */         flushBuffer();
/*      */       }
/* 1105 */       this._buffer[(this._offset++)] = 78;
/*      */     }
/*      */     else {
/* 1108 */       flush();
/*      */ 
/* 1110 */       while (4096 - this._offset - 3 < length) {
/* 1111 */         int sublen = 4096 - this._offset - 3;
/*      */ 
/* 1113 */         if (sublen < 16) {
/* 1114 */           flushBuffer();
/*      */ 
/* 1116 */           sublen = 4096 - this._offset - 3;
/*      */ 
/* 1118 */           if (length < sublen) {
/* 1119 */             sublen = length;
/*      */           }
/*      */         }
/* 1122 */         this._buffer[(this._offset++)] = 65;
/* 1123 */         this._buffer[(this._offset++)] = ((byte)(sublen >> 8));
/* 1124 */         this._buffer[(this._offset++)] = ((byte)sublen);
/*      */ 
/* 1126 */         System.arraycopy(buffer, offset, this._buffer, this._offset, sublen);
/* 1127 */         this._offset += sublen;
/*      */ 
/* 1129 */         length -= sublen;
/* 1130 */         offset += sublen;
/*      */ 
/* 1132 */         flushBuffer();
/*      */       }
/*      */ 
/* 1135 */       if (4096 < this._offset + 16) {
/* 1136 */         flushBuffer();
/*      */       }
/* 1138 */       if (length <= 15) {
/* 1139 */         this._buffer[(this._offset++)] = ((byte)(32 + length));
/*      */       }
/* 1141 */       else if (length <= 1023) {
/* 1142 */         this._buffer[(this._offset++)] = ((byte)(52 + (length >> 8)));
/* 1143 */         this._buffer[(this._offset++)] = ((byte)length);
/*      */       }
/*      */       else {
/* 1146 */         this._buffer[(this._offset++)] = 66;
/* 1147 */         this._buffer[(this._offset++)] = ((byte)(length >> 8));
/* 1148 */         this._buffer[(this._offset++)] = ((byte)length);
/*      */       }
/*      */ 
/* 1151 */       System.arraycopy(buffer, offset, this._buffer, this._offset, length);
/*      */ 
/* 1153 */       this._offset += length;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeByteBufferStart()
/*      */     throws IOException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void writeByteBufferPart(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1178 */     while (length > 0) {
/* 1179 */       int sublen = length;
/*      */ 
/* 1181 */       if (32768 < sublen) {
/* 1182 */         sublen = 32768;
/*      */       }
/* 1184 */       flush();
/*      */ 
/* 1186 */       this._os.write(65);
/* 1187 */       this._os.write(sublen >> 8);
/* 1188 */       this._os.write(sublen);
/*      */ 
/* 1190 */       this._os.write(buffer, offset, sublen);
/*      */ 
/* 1192 */       length -= sublen;
/* 1193 */       offset += sublen;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeByteBufferEnd(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1207 */     writeBytes(buffer, offset, length);
/*      */   }
/*      */ 
/*      */   public OutputStream getBytesOutputStream()
/*      */     throws IOException
/*      */   {
/* 1216 */     return new BytesOutputStream();
/*      */   }
/*      */ 
/*      */   protected void writeRef(int value)
/*      */     throws IOException
/*      */   {
/* 1232 */     if (4096 < this._offset + 16) {
/* 1233 */       flush();
/*      */     }
/* 1235 */     this._buffer[(this._offset++)] = 81;
/*      */ 
/* 1237 */     writeInt(value);
/*      */   }
/*      */ 
/*      */   public boolean addRef(Object object)
/*      */     throws IOException
/*      */   {
/* 1248 */     int ref = this._refs.get(object);
/*      */ 
/* 1250 */     if (ref >= 0) {
/* 1251 */       writeRef(ref);
/*      */ 
/* 1253 */       return true;
/*      */     }
/*      */ 
/* 1256 */     this._refs.put(object, this._refs.size());
/*      */ 
/* 1258 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean removeRef(Object obj)
/*      */     throws IOException
/*      */   {
/* 1268 */     if (this._refs != null) {
/* 1269 */       this._refs.remove(obj);
/*      */ 
/* 1271 */       return true;
/*      */     }
/*      */ 
/* 1274 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean replaceRef(Object oldRef, Object newRef)
/*      */     throws IOException
/*      */   {
/* 1283 */     Integer value = Integer.valueOf(this._refs.remove(oldRef));
/*      */ 
/* 1285 */     if (value != null) {
/* 1286 */       this._refs.put(newRef, value.intValue());
/* 1287 */       return true;
/*      */     }
/*      */ 
/* 1290 */     return false;
/*      */   }
/*      */ 
/*      */   public void resetReferences()
/*      */   {
/* 1298 */     if (this._refs != null)
/* 1299 */       this._refs.clear();
/*      */   }
/*      */ 
/*      */   public void writeStreamingObject(Object obj)
/*      */     throws IOException
/*      */   {
/* 1314 */     startStreamingPacket();
/*      */ 
/* 1316 */     writeObject(obj);
/*      */ 
/* 1318 */     endStreamingPacket();
/*      */   }
/*      */ 
/*      */   public void startStreamingPacket()
/*      */     throws IOException
/*      */   {
/* 1333 */     if (this._refs != null) {
/* 1334 */       this._refs.clear();
/*      */     }
/* 1336 */     flush();
/*      */ 
/* 1338 */     this._isStreaming = true;
/* 1339 */     this._offset = 3;
/*      */   }
/*      */ 
/*      */   public void endStreamingPacket()
/*      */     throws IOException
/*      */   {
/* 1345 */     int len = this._offset - 3;
/*      */ 
/* 1347 */     this._buffer[0] = 80;
/* 1348 */     this._buffer[1] = ((byte)(len >> 8));
/* 1349 */     this._buffer[2] = ((byte)len);
/*      */ 
/* 1351 */     this._isStreaming = false;
/*      */ 
/* 1353 */     flush();
/*      */   }
/*      */ 
/*      */   public void printLenString(String v)
/*      */     throws IOException
/*      */   {
/* 1364 */     if (4096 < this._offset + 16) {
/* 1365 */       flush();
/*      */     }
/* 1367 */     if (v == null) {
/* 1368 */       this._buffer[(this._offset++)] = 0;
/* 1369 */       this._buffer[(this._offset++)] = 0;
/*      */     }
/*      */     else {
/* 1372 */       int len = v.length();
/* 1373 */       this._buffer[(this._offset++)] = ((byte)(len >> 8));
/* 1374 */       this._buffer[(this._offset++)] = ((byte)len);
/*      */ 
/* 1376 */       printString(v, 0, len);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void printString(String v)
/*      */     throws IOException
/*      */   {
/* 1388 */     printString(v, 0, v.length());
/*      */   }
/*      */ 
/*      */   public void printString(String v, int strOffset, int length)
/*      */     throws IOException
/*      */   {
/* 1399 */     int offset = this._offset;
/* 1400 */     byte[] buffer = this._buffer;
/*      */ 
/* 1402 */     for (int i = 0; i < length; i++) {
/* 1403 */       if (4096 <= offset + 16) {
/* 1404 */         this._offset = offset;
/* 1405 */         flush();
/* 1406 */         offset = this._offset;
/*      */       }
/*      */ 
/* 1409 */       char ch = v.charAt(i + strOffset);
/*      */ 
/* 1411 */       if (ch < '') {
/* 1412 */         buffer[(offset++)] = ((byte)ch);
/* 1413 */       } else if (ch < 'ࠀ') {
/* 1414 */         buffer[(offset++)] = ((byte)(192 + (ch >> '\006' & 0x1F)));
/* 1415 */         buffer[(offset++)] = ((byte)('' + (ch & 0x3F)));
/*      */       }
/*      */       else {
/* 1418 */         buffer[(offset++)] = ((byte)(224 + (ch >> '\f' & 0xF)));
/* 1419 */         buffer[(offset++)] = ((byte)(128 + (ch >> '\006' & 0x3F)));
/* 1420 */         buffer[(offset++)] = ((byte)('' + (ch & 0x3F)));
/*      */       }
/*      */     }
/*      */ 
/* 1424 */     this._offset = offset;
/*      */   }
/*      */ 
/*      */   public void printString(char[] v, int strOffset, int length)
/*      */     throws IOException
/*      */   {
/* 1435 */     int offset = this._offset;
/* 1436 */     byte[] buffer = this._buffer;
/*      */ 
/* 1438 */     for (int i = 0; i < length; i++) {
/* 1439 */       if (4096 <= offset + 16) {
/* 1440 */         this._offset = offset;
/* 1441 */         flush();
/* 1442 */         offset = this._offset;
/*      */       }
/*      */ 
/* 1445 */       char ch = v[(i + strOffset)];
/*      */ 
/* 1447 */       if (ch < '') {
/* 1448 */         buffer[(offset++)] = ((byte)ch);
/* 1449 */       } else if (ch < 'ࠀ') {
/* 1450 */         buffer[(offset++)] = ((byte)(192 + (ch >> '\006' & 0x1F)));
/* 1451 */         buffer[(offset++)] = ((byte)('' + (ch & 0x3F)));
/*      */       }
/*      */       else {
/* 1454 */         buffer[(offset++)] = ((byte)(224 + (ch >> '\f' & 0xF)));
/* 1455 */         buffer[(offset++)] = ((byte)(128 + (ch >> '\006' & 0x3F)));
/* 1456 */         buffer[(offset++)] = ((byte)('' + (ch & 0x3F)));
/*      */       }
/*      */     }
/*      */ 
/* 1460 */     this._offset = offset;
/*      */   }
/*      */ 
/*      */   private final void flushIfFull()
/*      */     throws IOException
/*      */   {
/* 1466 */     int offset = this._offset;
/*      */ 
/* 1468 */     if (4096 < offset + 32) {
/* 1469 */       this._offset = 0;
/* 1470 */       this._os.write(this._buffer, 0, offset);
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void flush()
/*      */     throws IOException
/*      */   {
/* 1477 */     flushBuffer();
/*      */ 
/* 1479 */     if (this._os != null)
/* 1480 */       this._os.flush();
/*      */   }
/*      */ 
/*      */   public final void flushBuffer()
/*      */     throws IOException
/*      */   {
/* 1486 */     int offset = this._offset;
/*      */ 
/* 1488 */     if ((!this._isStreaming) && (offset > 0)) {
/* 1489 */       this._offset = 0;
/*      */ 
/* 1491 */       this._os.write(this._buffer, 0, offset);
/*      */     }
/* 1493 */     else if ((this._isStreaming) && (offset > 3)) {
/* 1494 */       int len = offset - 3;
/* 1495 */       this._buffer[0] = 112;
/* 1496 */       this._buffer[1] = ((byte)(len >> 8));
/* 1497 */       this._buffer[2] = ((byte)len);
/* 1498 */       this._offset = 3;
/*      */ 
/* 1500 */       this._os.write(this._buffer, 0, offset);
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void close()
/*      */     throws IOException
/*      */   {
/* 1508 */     flush();
/*      */ 
/* 1510 */     OutputStream os = this._os;
/* 1511 */     this._os = null;
/*      */ 
/* 1513 */     if ((os != null) && 
/* 1514 */       (this._isCloseStreamOnClose))
/* 1515 */       os.close();
/*      */   }
/*      */ 
/*      */   class BytesOutputStream extends OutputStream
/*      */   {
/*      */     private int _startOffset;
/*      */ 
/*      */     BytesOutputStream()
/*      */       throws IOException
/*      */     {
/* 1525 */       if (4096 < Hessian2Output.this._offset + 16) {
/* 1526 */         Hessian2Output.this.flush();
/*      */       }
/*      */ 
/* 1529 */       this._startOffset = Hessian2Output.this._offset;
/* 1530 */       Hessian2Output.access$012(Hessian2Output.this, 3);
/*      */     }
/*      */ 
/*      */     public void write(int ch)
/*      */       throws IOException
/*      */     {
/* 1537 */       if (4096 <= Hessian2Output.this._offset) {
/* 1538 */         int length = Hessian2Output.this._offset - this._startOffset - 3;
/*      */ 
/* 1540 */         Hessian2Output.this._buffer[this._startOffset] = 65;
/* 1541 */         Hessian2Output.this._buffer[(this._startOffset + 1)] = ((byte)(length >> 8));
/* 1542 */         Hessian2Output.this._buffer[(this._startOffset + 2)] = ((byte)length);
/*      */ 
/* 1544 */         Hessian2Output.this.flush();
/*      */ 
/* 1546 */         this._startOffset = Hessian2Output.this._offset;
/* 1547 */         Hessian2Output.access$012(Hessian2Output.this, 3);
/*      */       }
/*      */ 
/* 1550 */       Hessian2Output.this._buffer[Hessian2Output.access$008(Hessian2Output.this)] = ((byte)ch);
/*      */     }
/*      */ 
/*      */     public void write(byte[] buffer, int offset, int length)
/*      */       throws IOException
/*      */     {
/* 1557 */       while (length > 0) {
/* 1558 */         int sublen = 4096 - Hessian2Output.this._offset;
/*      */ 
/* 1560 */         if (length < sublen) {
/* 1561 */           sublen = length;
/*      */         }
/* 1563 */         if (sublen > 0) {
/* 1564 */           System.arraycopy(buffer, offset, Hessian2Output.this._buffer, Hessian2Output.this._offset, sublen);
/* 1565 */           Hessian2Output.access$012(Hessian2Output.this, sublen);
/*      */         }
/*      */ 
/* 1568 */         length -= sublen;
/* 1569 */         offset += sublen;
/*      */ 
/* 1571 */         if (4096 <= Hessian2Output.this._offset) {
/* 1572 */           int chunkLength = Hessian2Output.this._offset - this._startOffset - 3;
/*      */ 
/* 1574 */           Hessian2Output.this._buffer[this._startOffset] = 65;
/* 1575 */           Hessian2Output.this._buffer[(this._startOffset + 1)] = ((byte)(chunkLength >> 8));
/* 1576 */           Hessian2Output.this._buffer[(this._startOffset + 2)] = ((byte)chunkLength);
/*      */ 
/* 1578 */           Hessian2Output.this.flush();
/*      */ 
/* 1580 */           this._startOffset = Hessian2Output.this._offset;
/* 1581 */           Hessian2Output.access$012(Hessian2Output.this, 3);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 1590 */       int startOffset = this._startOffset;
/* 1591 */       this._startOffset = -1;
/*      */ 
/* 1593 */       if (startOffset < 0) {
/* 1594 */         return;
/*      */       }
/* 1596 */       int length = Hessian2Output.this._offset - startOffset - 3;
/*      */ 
/* 1598 */       Hessian2Output.this._buffer[startOffset] = 66;
/* 1599 */       Hessian2Output.this._buffer[(startOffset + 1)] = ((byte)(length >> 8));
/* 1600 */       Hessian2Output.this._buffer[(startOffset + 2)] = ((byte)length);
/*      */ 
/* 1602 */       Hessian2Output.this.flush();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.Hessian2Output
 * JD-Core Version:    0.6.2
 */