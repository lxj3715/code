/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class Hessian2StreamingInput
/*     */ {
/*     */   private Hessian2Input _in;
/*     */ 
/*     */   public Hessian2StreamingInput(InputStream is)
/*     */   {
/*  69 */     this._in = new Hessian2Input(new StreamingInputStream(is));
/*     */   }
/*     */ 
/*     */   public Object readObject()
/*     */     throws IOException
/*     */   {
/*  78 */     return this._in.readStreamingObject();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  87 */     this._in.close();
/*     */   }
/*     */ 
/*     */   static class StreamingInputStream extends InputStream {
/*     */     private InputStream _is;
/*     */     private int _length;
/*     */ 
/*     */     StreamingInputStream(InputStream is) {
/*  96 */       this._is = is;
/*     */     }
/*     */ 
/*     */     public int read()
/*     */       throws IOException
/*     */     {
/* 102 */       InputStream is = this._is;
/*     */ 
/* 104 */       while (this._length == 0) {
/* 105 */         int code = is.read();
/*     */ 
/* 107 */         if (code < 0)
/* 108 */           return -1;
/* 109 */         if ((code != 112) && (code != 80)) {
/* 110 */           throw new HessianProtocolException("expected streaming packet at 0x" + Integer.toHexString(code & 0xFF));
/*     */         }
/*     */ 
/* 113 */         int d1 = is.read();
/* 114 */         int d2 = is.read();
/*     */ 
/* 116 */         if (d2 < 0) {
/* 117 */           return -1;
/*     */         }
/* 119 */         this._length = ((d1 << 8) + d2);
/*     */       }
/*     */ 
/* 122 */       this._length -= 1;
/* 123 */       return is.read();
/*     */     }
/*     */ 
/*     */     public int read(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 129 */       InputStream is = this._is;
/*     */ 
/* 131 */       while (this._length == 0) {
/* 132 */         int code = is.read();
/*     */ 
/* 134 */         if (code < 0)
/* 135 */           return -1;
/* 136 */         if ((code != 112) && (code != 80)) {
/* 137 */           throw new HessianProtocolException("expected streaming packet at 0x" + Integer.toHexString(code & 0xFF) + " (" + (char)code + ")");
/*     */         }
/*     */ 
/* 142 */         int d1 = is.read();
/* 143 */         int d2 = is.read();
/*     */ 
/* 145 */         if (d2 < 0) {
/* 146 */           return -1;
/*     */         }
/* 148 */         this._length = ((d1 << 8) + d2);
/*     */       }
/*     */ 
/* 151 */       int sublen = this._length;
/* 152 */       if (length < sublen) {
/* 153 */         sublen = length;
/*     */       }
/* 155 */       sublen = is.read(buffer, offset, sublen);
/*     */ 
/* 157 */       if (sublen < 0) {
/* 158 */         return -1;
/*     */       }
/* 160 */       this._length -= sublen;
/*     */ 
/* 162 */       return sublen;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.Hessian2StreamingInput
 * JD-Core Version:    0.6.2
 */