/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class Hessian2StreamingOutput
/*     */ {
/*     */   private Hessian2Output _out;
/*     */ 
/*     */   public Hessian2StreamingOutput(OutputStream os)
/*     */   {
/*  70 */     this._out = new Hessian2Output(os);
/*     */   }
/*     */ 
/*     */   public void setCloseStreamOnClose(boolean isClose)
/*     */   {
/*  75 */     this._out.setCloseStreamOnClose(isClose);
/*     */   }
/*     */ 
/*     */   public boolean isCloseStreamOnClose()
/*     */   {
/*  80 */     return this._out.isCloseStreamOnClose();
/*     */   }
/*     */ 
/*     */   public void writeObject(Object object)
/*     */     throws IOException
/*     */   {
/*  89 */     this._out.writeStreamingObject(object);
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/*  98 */     this._out.flush();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 107 */     this._out.close();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.Hessian2StreamingOutput
 * JD-Core Version:    0.6.2
 */