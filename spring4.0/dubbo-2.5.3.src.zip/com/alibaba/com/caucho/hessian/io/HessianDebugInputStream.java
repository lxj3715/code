/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class HessianDebugInputStream extends InputStream
/*     */ {
/*     */   private InputStream _is;
/*     */   private HessianDebugState _state;
/*     */ 
/*     */   public HessianDebugInputStream(InputStream is, PrintWriter dbg)
/*     */   {
/*  74 */     this._is = is;
/*     */ 
/*  76 */     if (dbg == null) {
/*  77 */       dbg = new PrintWriter(System.out);
/*     */     }
/*  79 */     this._state = new HessianDebugState(dbg);
/*     */   }
/*     */ 
/*     */   public HessianDebugInputStream(InputStream is, Logger log, Level level)
/*     */   {
/*  87 */     this(is, new PrintWriter(new LogWriter(log, level)));
/*     */   }
/*     */ 
/*     */   public void startTop2()
/*     */   {
/*  92 */     this._state.startTop2();
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 103 */     InputStream is = this._is;
/*     */ 
/* 105 */     if (is == null) {
/* 106 */       return -1;
/*     */     }
/* 108 */     int ch = is.read();
/*     */ 
/* 111 */     this._state.next(ch);
/*     */ 
/* 113 */     return ch;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 122 */     InputStream is = this._is;
/* 123 */     this._is = null;
/*     */ 
/* 125 */     if (is != null) {
/* 126 */       is.close();
/*     */     }
/* 128 */     this._state.println();
/*     */   }
/*     */ 
/*     */   static class LogWriter extends Writer
/*     */   {
/*     */     private Logger _log;
/*     */     private Level _level;
/* 134 */     private StringBuilder _sb = new StringBuilder();
/*     */ 
/*     */     LogWriter(Logger log, Level level)
/*     */     {
/* 138 */       this._log = log;
/* 139 */       this._level = level;
/*     */     }
/*     */ 
/*     */     public void write(char ch)
/*     */     {
/* 144 */       if ((ch == '\n') && (this._sb.length() > 0)) {
/* 145 */         this._log.log(this._level, this._sb.toString());
/* 146 */         this._sb.setLength(0);
/*     */       }
/*     */       else {
/* 149 */         this._sb.append(ch);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(char[] buffer, int offset, int length) {
/* 154 */       for (int i = 0; i < length; i++) {
/* 155 */         char ch = buffer[(offset + i)];
/*     */ 
/* 157 */         if ((ch == '\n') && (this._sb.length() > 0)) {
/* 158 */           this._log.log(this._level, this._sb.toString());
/* 159 */           this._sb.setLength(0);
/*     */         }
/*     */         else {
/* 162 */           this._sb.append(ch);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void flush()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianDebugInputStream
 * JD-Core Version:    0.6.2
 */