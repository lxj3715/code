/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class HessianDebugOutputStream extends OutputStream
/*     */ {
/*     */   private OutputStream _os;
/*     */   private HessianDebugState _state;
/*     */ 
/*     */   public HessianDebugOutputStream(OutputStream os, PrintWriter dbg)
/*     */   {
/*  73 */     this._os = os;
/*     */ 
/*  75 */     this._state = new HessianDebugState(dbg);
/*     */   }
/*     */ 
/*     */   public HessianDebugOutputStream(OutputStream os, Logger log, Level level)
/*     */   {
/*  83 */     this(os, new PrintWriter(new LogWriter(log, level)));
/*     */   }
/*     */ 
/*     */   public void startTop2()
/*     */   {
/*  88 */     this._state.startTop2();
/*     */   }
/*     */ 
/*     */   public void write(int ch)
/*     */     throws IOException
/*     */   {
/*  97 */     ch &= 255;
/*     */ 
/*  99 */     this._os.write(ch);
/*     */ 
/* 101 */     this._state.next(ch);
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 107 */     this._os.flush();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 116 */     OutputStream os = this._os;
/* 117 */     this._os = null;
/*     */ 
/* 119 */     if (os != null) {
/* 120 */       os.close();
/*     */     }
/* 122 */     this._state.println();
/*     */   }
/*     */ 
/*     */   static class LogWriter extends Writer
/*     */   {
/*     */     private Logger _log;
/*     */     private Level _level;
/* 128 */     private StringBuilder _sb = new StringBuilder();
/*     */ 
/*     */     LogWriter(Logger log, Level level)
/*     */     {
/* 132 */       this._log = log;
/* 133 */       this._level = level;
/*     */     }
/*     */ 
/*     */     public void write(char ch)
/*     */     {
/* 138 */       if ((ch == '\n') && (this._sb.length() > 0)) {
/* 139 */         this._log.log(this._level, this._sb.toString());
/* 140 */         this._sb.setLength(0);
/*     */       }
/*     */       else {
/* 143 */         this._sb.append(ch);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(char[] buffer, int offset, int length) {
/* 148 */       for (int i = 0; i < length; i++) {
/* 149 */         char ch = buffer[(offset + i)];
/*     */ 
/* 151 */         if ((ch == '\n') && (this._sb.length() > 0)) {
/* 152 */           this._log.log(this._level, this._sb.toString());
/* 153 */           this._sb.setLength(0);
/*     */         }
/*     */         else {
/* 156 */           this._sb.append(ch);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void flush()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianDebugOutputStream
 * JD-Core Version:    0.6.2
 */