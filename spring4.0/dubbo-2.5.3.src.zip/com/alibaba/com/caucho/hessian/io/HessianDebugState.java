/*      */ package com.alibaba.com.caucho.hessian.io;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ 
/*      */ public class HessianDebugState
/*      */   implements Hessian2Constants
/*      */ {
/*      */   private PrintWriter _dbg;
/*      */   private State _state;
/*   64 */   private ArrayList<State> _stateStack = new ArrayList();
/*      */ 
/*   66 */   private ArrayList<ObjectDef> _objectDefList = new ArrayList();
/*      */ 
/*   69 */   private ArrayList<String> _typeDefList = new ArrayList();
/*      */   private int _refId;
/*   73 */   private boolean _isNewline = true;
/*   74 */   private boolean _isObject = false;
/*      */   private int _column;
/*      */ 
/*      */   public HessianDebugState(PrintWriter dbg)
/*      */   {
/*   82 */     this._dbg = dbg;
/*      */ 
/*   84 */     this._state = new InitialState();
/*      */   }
/*      */ 
/*      */   public void startTop2()
/*      */   {
/*   89 */     this._state = new Top2State();
/*      */   }
/*      */ 
/*      */   public void next(int ch)
/*      */     throws IOException
/*      */   {
/*   98 */     this._state = this._state.next(ch);
/*      */   }
/*      */ 
/*      */   void pushStack(State state)
/*      */   {
/*  103 */     this._stateStack.add(state);
/*      */   }
/*      */ 
/*      */   State popStack()
/*      */   {
/*  108 */     return (State)this._stateStack.remove(this._stateStack.size() - 1);
/*      */   }
/*      */ 
/*      */   void println()
/*      */   {
/*  113 */     if (!this._isNewline) {
/*  114 */       this._dbg.println();
/*  115 */       this._dbg.flush();
/*      */     }
/*      */ 
/*  118 */     this._isNewline = true;
/*  119 */     this._column = 0;
/*      */   }
/*      */ 
/*      */   static boolean isString(int ch)
/*      */   {
/*  124 */     switch (ch) { case 0:
/*      */     case 1:
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/*      */     case 15:
/*      */     case 16:
/*      */     case 17:
/*      */     case 18:
/*      */     case 19:
/*      */     case 20:
/*      */     case 21:
/*      */     case 22:
/*      */     case 23:
/*      */     case 24:
/*      */     case 25:
/*      */     case 26:
/*      */     case 27:
/*      */     case 28:
/*      */     case 29:
/*      */     case 30:
/*      */     case 31:
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 82:
/*      */     case 83:
/*  139 */       return true;
/*      */     case 32:
/*      */     case 33:
/*      */     case 34:
/*      */     case 35:
/*      */     case 36:
/*      */     case 37:
/*      */     case 38:
/*      */     case 39:
/*      */     case 40:
/*      */     case 41:
/*      */     case 42:
/*      */     case 43:
/*      */     case 44:
/*      */     case 45:
/*      */     case 46:
/*      */     case 47:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 56:
/*      */     case 57:
/*      */     case 58:
/*      */     case 59:
/*      */     case 60:
/*      */     case 61:
/*      */     case 62:
/*      */     case 63:
/*      */     case 64:
/*      */     case 65:
/*      */     case 66:
/*      */     case 67:
/*      */     case 68:
/*      */     case 69:
/*      */     case 70:
/*      */     case 71:
/*      */     case 72:
/*      */     case 73:
/*      */     case 74:
/*      */     case 75:
/*      */     case 76:
/*      */     case 77:
/*      */     case 78:
/*      */     case 79:
/*      */     case 80:
/*  142 */     case 81: } return false;
/*      */   }
/*      */ 
/*      */   static boolean isInteger(int ch)
/*      */   {
/*  148 */     switch (ch) { case 73:
/*      */     case 128:
/*      */     case 129:
/*      */     case 130:
/*      */     case 131:
/*      */     case 132:
/*      */     case 133:
/*      */     case 134:
/*      */     case 135:
/*      */     case 136:
/*      */     case 137:
/*      */     case 138:
/*      */     case 139:
/*      */     case 140:
/*      */     case 141:
/*      */     case 142:
/*      */     case 143:
/*      */     case 144:
/*      */     case 145:
/*      */     case 146:
/*      */     case 147:
/*      */     case 148:
/*      */     case 149:
/*      */     case 150:
/*      */     case 151:
/*      */     case 152:
/*      */     case 153:
/*      */     case 154:
/*      */     case 155:
/*      */     case 156:
/*      */     case 157:
/*      */     case 158:
/*      */     case 159:
/*      */     case 160:
/*      */     case 161:
/*      */     case 162:
/*      */     case 163:
/*      */     case 164:
/*      */     case 165:
/*      */     case 166:
/*      */     case 167:
/*      */     case 168:
/*      */     case 169:
/*      */     case 170:
/*      */     case 171:
/*      */     case 172:
/*      */     case 173:
/*      */     case 174:
/*      */     case 175:
/*      */     case 176:
/*      */     case 177:
/*      */     case 178:
/*      */     case 179:
/*      */     case 180:
/*      */     case 181:
/*      */     case 182:
/*      */     case 183:
/*      */     case 184:
/*      */     case 185:
/*      */     case 186:
/*      */     case 187:
/*      */     case 188:
/*      */     case 189:
/*      */     case 190:
/*      */     case 191:
/*      */     case 192:
/*      */     case 193:
/*      */     case 194:
/*      */     case 195:
/*      */     case 196:
/*      */     case 197:
/*      */     case 198:
/*      */     case 199:
/*      */     case 200:
/*      */     case 201:
/*      */     case 202:
/*      */     case 203:
/*      */     case 204:
/*      */     case 205:
/*      */     case 206:
/*      */     case 207:
/*      */     case 208:
/*      */     case 209:
/*      */     case 210:
/*      */     case 211:
/*      */     case 212:
/*      */     case 213:
/*      */     case 214:
/*      */     case 215:
/*  178 */       return true;
/*      */     case 74:
/*      */     case 75:
/*      */     case 76:
/*      */     case 77:
/*      */     case 78:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 82:
/*      */     case 83:
/*      */     case 84:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 89:
/*      */     case 90:
/*      */     case 91:
/*      */     case 92:
/*      */     case 93:
/*      */     case 94:
/*      */     case 95:
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 99:
/*      */     case 100:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/*      */     case 112:
/*      */     case 113:
/*      */     case 114:
/*      */     case 115:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/*      */     case 119:
/*      */     case 120:
/*      */     case 121:
/*      */     case 122:
/*      */     case 123:
/*      */     case 124:
/*      */     case 125:
/*      */     case 126:
/*  181 */     case 127: } return false;
/*      */   }
/*      */ 
/*      */   static class ObjectDef
/*      */   {
/*      */     private String _type;
/*      */     private ArrayList<String> _fields;
/*      */ 
/*      */     ObjectDef(String type, ArrayList<String> fields)
/*      */     {
/* 2076 */       this._type = type;
/* 2077 */       this._fields = fields;
/*      */     }
/*      */ 
/*      */     String getType()
/*      */     {
/* 2082 */       return this._type;
/*      */     }
/*      */ 
/*      */     ArrayList<String> getFields()
/*      */     {
/* 2087 */       return this._fields;
/*      */     }
/*      */   }
/*      */ 
/*      */   class StreamingState extends HessianDebugState.State
/*      */   {
/*      */     private int _digit;
/*      */     private int _length;
/*      */     private boolean _isLast;
/* 2019 */     private boolean _isFirst = true;
/*      */     private HessianDebugState.State _childState;
/*      */ 
/*      */     StreamingState(HessianDebugState.State next, boolean isLast)
/*      */     {
/* 2025 */       super(next);
/*      */ 
/* 2027 */       this._isLast = isLast;
/* 2028 */       this._childState = new HessianDebugState.InitialState(HessianDebugState.this);
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 2033 */       if (this._digit < 2) {
/* 2034 */         this._length = (256 * this._length + ch);
/* 2035 */         this._digit += 1;
/*      */ 
/* 2037 */         if ((this._digit == 2) && (this._length == 0) && (this._isLast)) {
/* 2038 */           HessianDebugState.this._refId = 0;
/* 2039 */           return this._next;
/*      */         }
/*      */ 
/* 2042 */         if (this._digit == 2) {
/* 2043 */           println(-1, "packet-start(" + this._length + ")");
/*      */         }
/* 2045 */         return this;
/*      */       }
/*      */ 
/* 2048 */       if (this._length == 0) {
/* 2049 */         this._isLast = (ch == 80);
/* 2050 */         this._digit = 0;
/*      */ 
/* 2052 */         return this;
/*      */       }
/*      */ 
/* 2055 */       this._childState = this._childState.next(ch);
/*      */ 
/* 2057 */       this._length -= 1;
/*      */ 
/* 2059 */       if ((this._length == 0) && (this._isLast)) {
/* 2060 */         println(-1, "");
/* 2061 */         println(-1, "packet-end");
/* 2062 */         HessianDebugState.this._refId = 0;
/* 2063 */         return this._next;
/*      */       }
/*      */ 
/* 2066 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class RemoteState extends HessianDebugState.State
/*      */   {
/*      */     private static final int TYPE = 0;
/*      */     private static final int VALUE = 1;
/*      */     private static final int END = 2;
/*      */     private int _state;
/*      */     private int _major;
/*      */     private int _minor;
/*      */ 
/*      */     RemoteState(HessianDebugState.State next)
/*      */     {
/* 1985 */       super(next);
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1990 */       switch (this._state) {
/*      */       case 0:
/* 1992 */         println(-1, "remote");
/* 1993 */         if (ch == 116) {
/* 1994 */           this._state = 1;
/* 1995 */           return new HessianDebugState.StringState(HessianDebugState.this, this, 't', false);
/*      */         }
/*      */ 
/* 1998 */         this._state = 2;
/* 1999 */         return nextObject(ch);
/*      */       case 1:
/* 2003 */         this._state = 2;
/* 2004 */         return this._next.nextObject(ch);
/*      */       case 2:
/* 2007 */         return this._next.next(ch);
/*      */       }
/*      */ 
/* 2010 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class IndirectState extends HessianDebugState.State
/*      */   {
/*      */     IndirectState(HessianDebugState.State next)
/*      */     {
/* 1955 */       super(next);
/*      */     }
/*      */ 
/*      */     boolean isShift(Object object)
/*      */     {
/* 1960 */       return this._next.isShift(object);
/*      */     }
/*      */ 
/*      */     HessianDebugState.State shift(Object object)
/*      */     {
/* 1965 */       return this._next.shift(object);
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1970 */       return nextObject(ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   class Fault2State extends HessianDebugState.State
/*      */   {
/*      */     Fault2State(HessianDebugState.State next)
/*      */     {
/* 1935 */       super(next);
/*      */ 
/* 1937 */       println(-2, "Fault");
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1942 */       return this._next.depth() + 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1948 */       return nextObject(ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   class Reply2State extends HessianDebugState.State
/*      */   {
/*      */     Reply2State(HessianDebugState.State next)
/*      */     {
/* 1915 */       super(next);
/*      */ 
/* 1917 */       println(-2, "Reply");
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1922 */       return this._next.depth() + 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1928 */       return nextObject(ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   class ReplyState extends HessianDebugState.State
/*      */   {
/*      */     private static final int MAJOR = 0;
/*      */     private static final int MINOR = 1;
/*      */     private static final int HEADER = 2;
/*      */     private static final int VALUE = 3;
/*      */     private static final int END = 4;
/*      */     private int _state;
/*      */     private int _major;
/*      */     private int _minor;
/*      */ 
/*      */     ReplyState(HessianDebugState.State next)
/*      */     {
/* 1852 */       super();
/* 1853 */       this._next = next;
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1858 */       return this._next.depth() + 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1863 */       switch (this._state) {
/*      */       case 0:
/* 1865 */         if ((ch == 116) || (ch == 83)) {
/* 1866 */           return new HessianDebugState.RemoteState(HessianDebugState.this, this).next(ch);
/*      */         }
/* 1868 */         this._major = ch;
/* 1869 */         this._state = 1;
/* 1870 */         return this;
/*      */       case 1:
/* 1873 */         this._minor = ch;
/* 1874 */         this._state = 2;
/* 1875 */         println(-2, "reply " + this._major + "." + this._minor);
/* 1876 */         return this;
/*      */       case 2:
/* 1879 */         if (ch == 72) {
/* 1880 */           this._state = 3;
/* 1881 */           return new HessianDebugState.StringState(HessianDebugState.this, this, 'H', true);
/*      */         }
/* 1883 */         if (ch == 102) {
/* 1884 */           print("fault ");
/* 1885 */           HessianDebugState.this._isObject = false;
/* 1886 */           this._state = 4;
/* 1887 */           return new HessianDebugState.MapState(HessianDebugState.this, this, 0);
/*      */         }
/*      */ 
/* 1890 */         this._state = 4;
/* 1891 */         return nextObject(ch);
/*      */       case 3:
/* 1895 */         this._state = 2;
/* 1896 */         return nextObject(ch);
/*      */       case 4:
/* 1899 */         println();
/* 1900 */         if (ch == 90) {
/* 1901 */           return this._next;
/*      */         }
/*      */ 
/* 1904 */         return this._next.next(ch);
/*      */       }
/*      */ 
/* 1907 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class Call2State extends HessianDebugState.State
/*      */   {
/*      */     private static final int METHOD = 0;
/*      */     private static final int COUNT = 1;
/*      */     private static final int ARG = 2;
/* 1769 */     private int _state = 0;
/*      */     private int _i;
/*      */     private int _count;
/*      */ 
/*      */     Call2State(HessianDebugState.State next)
/*      */     {
/* 1775 */       super(next);
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1780 */       return this._next.depth() + 5;
/*      */     }
/*      */ 
/*      */     boolean isShift(Object value)
/*      */     {
/* 1786 */       return this._state != 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State shift(Object object)
/*      */     {
/* 1792 */       if (this._state == 0) {
/* 1793 */         println(-5, "Call " + object);
/*      */ 
/* 1795 */         this._state = 1;
/* 1796 */         return this;
/*      */       }
/* 1798 */       if (this._state == 1) {
/* 1799 */         Integer count = (Integer)object;
/*      */ 
/* 1801 */         this._count = count.intValue();
/*      */ 
/* 1803 */         this._state = 2;
/*      */ 
/* 1805 */         if (this._count == 0) {
/* 1806 */           return this._next;
/*      */         }
/* 1808 */         return this;
/*      */       }
/*      */ 
/* 1811 */       return this;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1817 */       switch (this._state) {
/*      */       case 1:
/* 1819 */         return nextObject(ch);
/*      */       case 0:
/* 1822 */         return nextObject(ch);
/*      */       case 2:
/* 1825 */         if (this._count <= this._i) {
/* 1826 */           return this._next.next(ch);
/*      */         }
/* 1828 */         println();
/* 1829 */         print(-3, this._i++ + ": ");
/*      */ 
/* 1831 */         return nextObject(ch);
/*      */       }
/*      */ 
/* 1835 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class CallState extends HessianDebugState.State
/*      */   {
/*      */     private static final int MAJOR = 0;
/*      */     private static final int MINOR = 1;
/*      */     private static final int HEADER = 2;
/*      */     private static final int METHOD = 3;
/*      */     private static final int VALUE = 4;
/*      */     private static final int ARG = 5;
/*      */     private int _state;
/*      */     private int _major;
/*      */     private int _minor;
/*      */ 
/*      */     CallState(HessianDebugState.State next)
/*      */     {
/* 1704 */       super(next);
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1709 */       return this._next.depth() + 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1714 */       switch (this._state) {
/*      */       case 0:
/* 1716 */         this._major = ch;
/* 1717 */         this._state = 1;
/* 1718 */         return this;
/*      */       case 1:
/* 1721 */         this._minor = ch;
/* 1722 */         this._state = 2;
/* 1723 */         println(-2, "call " + this._major + "." + this._minor);
/* 1724 */         return this;
/*      */       case 2:
/* 1727 */         if (ch == 72) {
/* 1728 */           println();
/* 1729 */           print("header ");
/* 1730 */           HessianDebugState.this._isObject = false;
/* 1731 */           this._state = 4;
/* 1732 */           return new HessianDebugState.StringState(HessianDebugState.this, this, 'H', true);
/*      */         }
/* 1734 */         if (ch == 109) {
/* 1735 */           println();
/* 1736 */           print("method ");
/* 1737 */           HessianDebugState.this._isObject = false;
/* 1738 */           this._state = 5;
/* 1739 */           return new HessianDebugState.StringState(HessianDebugState.this, this, 'm', true);
/*      */         }
/*      */ 
/* 1742 */         println((char)ch + ": unexpected char");
/* 1743 */         return HessianDebugState.this.popStack();
/*      */       case 4:
/* 1747 */         print(" => ");
/* 1748 */         HessianDebugState.this._isObject = false;
/* 1749 */         this._state = 2;
/* 1750 */         return nextObject(ch);
/*      */       case 5:
/* 1753 */         if (ch == 90) {
/* 1754 */           return this._next;
/*      */         }
/* 1756 */         return nextObject(ch);
/*      */       case 3:
/*      */       }
/* 1759 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class Hessian2State extends HessianDebugState.State
/*      */   {
/*      */     private static final int MAJOR = 0;
/*      */     private static final int MINOR = 1;
/*      */     private int _state;
/*      */     private int _major;
/*      */     private int _minor;
/*      */ 
/*      */     Hessian2State(HessianDebugState.State next)
/*      */     {
/* 1663 */       super(next);
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1668 */       return this._next.depth() + 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1673 */       switch (this._state) {
/*      */       case 0:
/* 1675 */         this._major = ch;
/* 1676 */         this._state = 1;
/* 1677 */         return this;
/*      */       case 1:
/* 1680 */         this._minor = ch;
/* 1681 */         println(-2, "hessian " + this._major + "." + this._minor);
/* 1682 */         return this._next;
/*      */       }
/*      */ 
/* 1685 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class CompactListState extends HessianDebugState.State
/*      */   {
/*      */     private static final int TYPE = 0;
/*      */     private static final int LENGTH = 1;
/*      */     private static final int VALUE = 2;
/*      */     private int _refId;
/*      */     private boolean _isTyped;
/*      */     private boolean _isLength;
/*      */     private int _state;
/*      */     private boolean _hasData;
/*      */     private int _length;
/*      */     private int _count;
/*      */     private int _valueDepth;
/*      */ 
/*      */     CompactListState(HessianDebugState.State next, int refId, boolean isTyped)
/*      */     {
/* 1531 */       super(next);
/*      */ 
/* 1533 */       this._isTyped = isTyped;
/* 1534 */       this._refId = refId;
/*      */ 
/* 1536 */       if (isTyped)
/* 1537 */         this._state = 0;
/*      */       else
/* 1539 */         this._state = 1;
/*      */     }
/*      */ 
/*      */     CompactListState(HessianDebugState.State next, int refId, boolean isTyped, int length)
/*      */     {
/* 1544 */       super(next);
/*      */ 
/* 1546 */       this._isTyped = isTyped;
/* 1547 */       this._refId = refId;
/* 1548 */       this._length = length;
/*      */ 
/* 1550 */       this._isLength = true;
/*      */ 
/* 1552 */       if (isTyped) {
/* 1553 */         this._state = 0;
/*      */       } else {
/* 1555 */         printObject("list (#" + this._refId + ")");
/*      */ 
/* 1557 */         this._state = 2;
/*      */       }
/*      */     }
/*      */ 
/*      */     boolean isShift(Object value)
/*      */     {
/* 1564 */       return (this._state == 0) || (this._state == 1);
/*      */     }
/*      */ 
/*      */     HessianDebugState.State shift(Object object)
/*      */     {
/* 1570 */       if (this._state == 0) {
/* 1571 */         Object type = object;
/*      */ 
/* 1573 */         if ((object instanceof Integer)) {
/* 1574 */           int index = ((Integer)object).intValue();
/*      */ 
/* 1576 */           if ((index >= 0) && (index < HessianDebugState.this._typeDefList.size()))
/* 1577 */             type = HessianDebugState.this._typeDefList.get(index);
/*      */           else
/* 1579 */             type = "type-unknown(" + index + ")";
/*      */         }
/* 1581 */         else if ((object instanceof String)) {
/* 1582 */           HessianDebugState.this._typeDefList.add((String)object);
/*      */         }
/* 1584 */         printObject("list " + type + " (#" + this._refId + ")");
/*      */ 
/* 1586 */         if (this._isLength) {
/* 1587 */           this._state = 2;
/*      */ 
/* 1589 */           if (this._length == 0)
/* 1590 */             return this._next;
/*      */         }
/*      */         else {
/* 1593 */           this._state = 1;
/*      */         }
/* 1595 */         return this;
/*      */       }
/* 1597 */       if (this._state == 1) {
/* 1598 */         this._length = ((Integer)object).intValue();
/*      */ 
/* 1600 */         if (!this._isTyped) {
/* 1601 */           printObject("list (#" + this._refId + ")");
/*      */         }
/* 1603 */         this._state = 2;
/*      */ 
/* 1605 */         if (this._length == 0) {
/* 1606 */           return this._next;
/*      */         }
/* 1608 */         return this;
/*      */       }
/*      */ 
/* 1611 */       return this;
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1617 */       if (this._state <= 1)
/* 1618 */         return this._next.depth();
/* 1619 */       if (this._state == 2) {
/* 1620 */         return this._valueDepth;
/*      */       }
/* 1622 */       return this._next.depth() + 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1627 */       switch (this._state) {
/*      */       case 0:
/* 1629 */         return nextObject(ch);
/*      */       case 1:
/* 1632 */         return nextObject(ch);
/*      */       case 2:
/* 1635 */         if (this._length <= this._count) {
/* 1636 */           return this._next.next(ch);
/*      */         }
/* 1638 */         this._valueDepth = (this._next.depth() + 2);
/* 1639 */         println();
/* 1640 */         printObject(this._count++ + ": ");
/* 1641 */         this._valueDepth = HessianDebugState.this._column;
/* 1642 */         HessianDebugState.this._isObject = false;
/*      */ 
/* 1644 */         return nextObject(ch);
/*      */       }
/*      */ 
/* 1648 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class ListState extends HessianDebugState.State
/*      */   {
/*      */     private static final int TYPE = 0;
/*      */     private static final int LENGTH = 1;
/*      */     private static final int VALUE = 2;
/*      */     private int _refId;
/*      */     private int _state;
/*      */     private boolean _hasData;
/*      */     private int _count;
/*      */     private int _valueDepth;
/*      */ 
/*      */     ListState(HessianDebugState.State next, int refId, boolean isType)
/*      */     {
/* 1422 */       super(next);
/*      */ 
/* 1424 */       this._refId = refId;
/*      */ 
/* 1426 */       if (isType) {
/* 1427 */         this._state = 0;
/*      */       } else {
/* 1429 */         printObject("list (#" + this._refId + ")");
/* 1430 */         this._state = 2;
/*      */       }
/*      */     }
/*      */ 
/*      */     boolean isShift(Object value)
/*      */     {
/* 1437 */       return (this._state == 0) || (this._state == 1);
/*      */     }
/*      */ 
/*      */     HessianDebugState.State shift(Object object)
/*      */     {
/* 1443 */       if (this._state == 0) {
/* 1444 */         Object type = object;
/*      */ 
/* 1446 */         if ((type instanceof String)) {
/* 1447 */           HessianDebugState.this._typeDefList.add((String)type);
/*      */         }
/* 1449 */         else if ((object instanceof Integer)) {
/* 1450 */           int index = ((Integer)object).intValue();
/*      */ 
/* 1452 */           if ((index >= 0) && (index < HessianDebugState.this._typeDefList.size()))
/* 1453 */             type = HessianDebugState.this._typeDefList.get(index);
/*      */           else {
/* 1455 */             type = "type-unknown(" + index + ")";
/*      */           }
/*      */         }
/* 1458 */         printObject("list " + type + "(#" + this._refId + ")");
/*      */ 
/* 1460 */         this._state = 2;
/*      */ 
/* 1462 */         return this;
/*      */       }
/* 1464 */       if (this._state == 1) {
/* 1465 */         this._state = 2;
/*      */ 
/* 1467 */         return this;
/*      */       }
/*      */ 
/* 1470 */       return this;
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1476 */       if (this._state <= 1)
/* 1477 */         return this._next.depth();
/* 1478 */       if (this._state == 2) {
/* 1479 */         return this._valueDepth;
/*      */       }
/* 1481 */       return this._next.depth() + 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1486 */       switch (this._state) {
/*      */       case 0:
/* 1488 */         return nextObject(ch);
/*      */       case 2:
/* 1491 */         if (ch == 90) {
/* 1492 */           if (this._count > 0) {
/* 1493 */             println();
/*      */           }
/* 1495 */           return this._next;
/*      */         }
/*      */ 
/* 1498 */         this._valueDepth = (this._next.depth() + 2);
/* 1499 */         println();
/* 1500 */         printObject(this._count++ + ": ");
/* 1501 */         this._valueDepth = HessianDebugState.this._column;
/* 1502 */         HessianDebugState.this._isObject = false;
/*      */ 
/* 1504 */         return nextObject(ch);
/*      */       }
/*      */ 
/* 1508 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class ObjectState extends HessianDebugState.State
/*      */   {
/*      */     private static final int TYPE = 0;
/*      */     private static final int FIELD = 1;
/*      */     private int _refId;
/*      */     private int _state;
/*      */     private HessianDebugState.ObjectDef _def;
/*      */     private int _count;
/*      */     private int _fieldDepth;
/*      */ 
/*      */     ObjectState(HessianDebugState.State next, int refId)
/*      */     {
/* 1324 */       super(next);
/*      */ 
/* 1326 */       this._refId = refId;
/* 1327 */       this._state = 0;
/*      */     }
/*      */ 
/*      */     ObjectState(HessianDebugState.State next, int refId, int def)
/*      */     {
/* 1332 */       super(next);
/*      */ 
/* 1334 */       this._refId = refId;
/* 1335 */       this._state = 1;
/*      */ 
/* 1337 */       if ((def < 0) || (HessianDebugState.this._objectDefList.size() <= def)) {
/* 1338 */         throw new IllegalStateException(def + " is an unknown object type");
/*      */       }
/*      */ 
/* 1341 */       this._def = ((HessianDebugState.ObjectDef)HessianDebugState.this._objectDefList.get(def));
/*      */ 
/* 1343 */       println("object " + this._def.getType() + " (#" + this._refId + ")");
/*      */     }
/*      */ 
/*      */     boolean isShift(Object value)
/*      */     {
/* 1349 */       if (this._state == 0) {
/* 1350 */         return true;
/*      */       }
/* 1352 */       return false;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State shift(Object object)
/*      */     {
/* 1358 */       if (this._state == 0) {
/* 1359 */         int def = ((Integer)object).intValue();
/*      */ 
/* 1361 */         this._def = ((HessianDebugState.ObjectDef)HessianDebugState.this._objectDefList.get(def));
/*      */ 
/* 1363 */         println("object " + this._def.getType() + " (#" + this._refId + ")");
/*      */ 
/* 1365 */         this._state = 1;
/*      */ 
/* 1367 */         if (this._def.getFields().size() == 0) {
/* 1368 */           return this._next;
/*      */         }
/*      */       }
/* 1371 */       return this;
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1377 */       if (this._state <= 0) {
/* 1378 */         return this._next.depth();
/*      */       }
/* 1380 */       return this._fieldDepth;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1385 */       switch (this._state) {
/*      */       case 0:
/* 1387 */         return nextObject(ch);
/*      */       case 1:
/* 1390 */         if (this._def.getFields().size() <= this._count) {
/* 1391 */           return this._next.next(ch);
/*      */         }
/* 1393 */         this._fieldDepth = (this._next.depth() + 2);
/* 1394 */         println();
/* 1395 */         print((String)this._def.getFields().get(this._count++) + ": ");
/*      */ 
/* 1397 */         this._fieldDepth = HessianDebugState.this._column;
/*      */ 
/* 1399 */         HessianDebugState.this._isObject = false;
/* 1400 */         return nextObject(ch);
/*      */       }
/*      */ 
/* 1403 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class ObjectDefState extends HessianDebugState.State
/*      */   {
/*      */     private static final int TYPE = 1;
/*      */     private static final int COUNT = 2;
/*      */     private static final int FIELD = 3;
/*      */     private static final int COMPLETE = 4;
/*      */     private int _refId;
/*      */     private int _state;
/*      */     private boolean _hasData;
/*      */     private int _count;
/*      */     private String _type;
/* 1226 */     private ArrayList<String> _fields = new ArrayList();
/*      */ 
/*      */     ObjectDefState(HessianDebugState.State next)
/*      */     {
/* 1230 */       super(next);
/*      */ 
/* 1232 */       this._state = 1;
/*      */     }
/*      */ 
/*      */     boolean isShift(Object value)
/*      */     {
/* 1238 */       return true;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State shift(Object object)
/*      */     {
/* 1244 */       if (this._state == 1) {
/* 1245 */         this._type = ((String)object);
/*      */ 
/* 1247 */         print("/* defun " + this._type + " [");
/*      */ 
/* 1249 */         HessianDebugState.this._objectDefList.add(new HessianDebugState.ObjectDef(this._type, this._fields));
/*      */ 
/* 1251 */         this._state = 2;
/*      */       }
/* 1253 */       else if (this._state == 2) {
/* 1254 */         this._count = ((Integer)object).intValue();
/*      */ 
/* 1256 */         this._state = 3;
/*      */       }
/* 1258 */       else if (this._state == 3) {
/* 1259 */         String field = (String)object;
/*      */ 
/* 1261 */         this._count -= 1;
/*      */ 
/* 1263 */         this._fields.add(field);
/*      */ 
/* 1265 */         if (this._fields.size() == 1)
/* 1266 */           print(field);
/*      */         else
/* 1268 */           print(", " + field);
/*      */       }
/*      */       else {
/* 1271 */         throw new UnsupportedOperationException();
/*      */       }
/*      */ 
/* 1274 */       return this;
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1280 */       if (this._state <= 1) {
/* 1281 */         return this._next.depth();
/*      */       }
/* 1283 */       return this._next.depth() + 2;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1288 */       switch (this._state) {
/*      */       case 1:
/* 1290 */         return nextObject(ch);
/*      */       case 2:
/* 1293 */         return nextObject(ch);
/*      */       case 3:
/* 1296 */         if (this._count == 0) {
/* 1297 */           println("] */");
/* 1298 */           this._next.printIndent(0);
/*      */ 
/* 1300 */           return this._next.nextObject(ch);
/*      */         }
/*      */ 
/* 1303 */         return nextObject(ch);
/*      */       }
/*      */ 
/* 1306 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class MapState extends HessianDebugState.State
/*      */   {
/*      */     private static final int TYPE = 0;
/*      */     private static final int KEY = 1;
/*      */     private static final int VALUE = 2;
/*      */     private int _refId;
/*      */     private int _state;
/*      */     private int _valueDepth;
/*      */     private boolean _hasData;
/*      */ 
/*      */     MapState(HessianDebugState.State next, int refId)
/*      */     {
/* 1114 */       super(next);
/*      */ 
/* 1116 */       this._refId = refId;
/* 1117 */       this._state = 0;
/*      */     }
/*      */ 
/*      */     MapState(HessianDebugState.State next, int refId, boolean isType)
/*      */     {
/* 1122 */       super(next);
/*      */ 
/* 1124 */       this._refId = refId;
/*      */ 
/* 1126 */       if (isType) {
/* 1127 */         this._state = 0;
/*      */       } else {
/* 1129 */         printObject("map (#" + this._refId + ")");
/* 1130 */         this._state = 2;
/*      */       }
/*      */     }
/*      */ 
/*      */     boolean isShift(Object value)
/*      */     {
/* 1137 */       return this._state == 0;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State shift(Object type)
/*      */     {
/* 1143 */       if (this._state == 0) {
/* 1144 */         if ((type instanceof String)) {
/* 1145 */           HessianDebugState.this._typeDefList.add((String)type);
/*      */         }
/* 1147 */         else if ((type instanceof Integer)) {
/* 1148 */           int iValue = ((Integer)type).intValue();
/*      */ 
/* 1150 */           if ((iValue >= 0) && (iValue < HessianDebugState.this._typeDefList.size())) {
/* 1151 */             type = HessianDebugState.this._typeDefList.get(iValue);
/*      */           }
/*      */         }
/* 1154 */         printObject("map " + type + " (#" + this._refId + ")");
/*      */ 
/* 1156 */         this._state = 2;
/*      */ 
/* 1158 */         return this;
/*      */       }
/*      */ 
/* 1161 */       throw new IllegalStateException();
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/* 1167 */       if (this._state == 0)
/* 1168 */         return this._next.depth();
/* 1169 */       if (this._state == 1) {
/* 1170 */         return this._next.depth() + 2;
/*      */       }
/* 1172 */       return this._valueDepth;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1177 */       switch (this._state) {
/*      */       case 0:
/* 1179 */         return nextObject(ch);
/*      */       case 2:
/* 1182 */         if (ch == 90) {
/* 1183 */           if (this._hasData) {
/* 1184 */             println();
/*      */           }
/* 1186 */           return this._next;
/*      */         }
/*      */ 
/* 1189 */         if (this._hasData) {
/* 1190 */           println();
/*      */         }
/* 1192 */         this._hasData = true;
/* 1193 */         this._state = 1;
/*      */ 
/* 1195 */         return nextObject(ch);
/*      */       case 1:
/* 1199 */         print(" => ");
/* 1200 */         HessianDebugState.this._isObject = false;
/* 1201 */         this._valueDepth = HessianDebugState.this._column;
/*      */ 
/* 1203 */         this._state = 2;
/*      */ 
/* 1205 */         return nextObject(ch);
/*      */       }
/*      */ 
/* 1208 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   class BinaryState extends HessianDebugState.State
/*      */   {
/*      */     char _typeCode;
/*      */     int _totalLength;
/*      */     int _lengthIndex;
/*      */     int _length;
/*      */     boolean _isLastChunk;
/*      */ 
/*      */     BinaryState(HessianDebugState.State next, char typeCode, boolean isLastChunk)
/*      */     {
/* 1005 */       super(next);
/*      */ 
/* 1007 */       this._typeCode = typeCode;
/* 1008 */       this._isLastChunk = isLastChunk;
/*      */     }
/*      */ 
/*      */     BinaryState(HessianDebugState.State next, char typeCode, int length)
/*      */     {
/* 1013 */       super(next);
/*      */ 
/* 1015 */       this._typeCode = typeCode;
/* 1016 */       this._isLastChunk = true;
/* 1017 */       this._length = length;
/* 1018 */       this._lengthIndex = 2;
/*      */     }
/*      */ 
/*      */     BinaryState(HessianDebugState.State next, char typeCode, int length, boolean isLastChunk)
/*      */     {
/* 1023 */       super(next);
/*      */ 
/* 1025 */       this._typeCode = typeCode;
/* 1026 */       this._isLastChunk = isLastChunk;
/* 1027 */       this._length = length;
/* 1028 */       this._lengthIndex = 1;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/* 1033 */       if (this._lengthIndex < 2) {
/* 1034 */         this._length = (256 * this._length + (ch & 0xFF));
/*      */ 
/* 1036 */         if ((++this._lengthIndex == 2) && (this._length == 0) && (this._isLastChunk)) {
/* 1037 */           String value = "binary(" + this._totalLength + ")";
/*      */ 
/* 1039 */           if (this._next.isShift(value)) {
/* 1040 */             return this._next.shift(value);
/*      */           }
/* 1042 */           printObject(value);
/* 1043 */           return this._next;
/*      */         }
/*      */ 
/* 1047 */         return this;
/*      */       }
/* 1049 */       if (this._length == 0) {
/* 1050 */         if (ch == 98) {
/* 1051 */           this._isLastChunk = false;
/* 1052 */           this._lengthIndex = 0;
/* 1053 */           return this;
/*      */         }
/* 1055 */         if (ch == 66) {
/* 1056 */           this._isLastChunk = true;
/* 1057 */           this._lengthIndex = 0;
/* 1058 */           return this;
/*      */         }
/* 1060 */         if (ch == 32) {
/* 1061 */           String value = "binary(" + this._totalLength + ")";
/*      */ 
/* 1063 */           if (this._next.isShift(value)) {
/* 1064 */             return this._next.shift(value);
/*      */           }
/* 1066 */           printObject(value);
/* 1067 */           return this._next;
/*      */         }
/*      */ 
/* 1070 */         if ((32 <= ch) && (ch < 48)) {
/* 1071 */           this._isLastChunk = true;
/* 1072 */           this._lengthIndex = 2;
/* 1073 */           this._length = ((ch & 0xFF) - 32);
/* 1074 */           return this;
/*      */         }
/*      */ 
/* 1077 */         println(String.valueOf((char)ch) + ": unexpected character");
/* 1078 */         return this._next;
/*      */       }
/*      */ 
/* 1082 */       this._length -= 1;
/* 1083 */       this._totalLength += 1;
/*      */ 
/* 1085 */       if ((this._length == 0) && (this._isLastChunk)) {
/* 1086 */         String value = "binary(" + this._totalLength + ")";
/*      */ 
/* 1088 */         if (this._next.isShift(value)) {
/* 1089 */           return this._next.shift(value);
/*      */         }
/* 1091 */         printObject(value);
/*      */ 
/* 1093 */         return this._next;
/*      */       }
/*      */ 
/* 1097 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class StringState extends HessianDebugState.State
/*      */   {
/*      */     private static final int TOP = 0;
/*      */     private static final int UTF_2_1 = 1;
/*      */     private static final int UTF_3_1 = 2;
/*      */     private static final int UTF_3_2 = 3;
/*      */     char _typeCode;
/*  860 */     StringBuilder _value = new StringBuilder();
/*      */     int _lengthIndex;
/*      */     int _length;
/*      */     boolean _isLastChunk;
/*      */     int _utfState;
/*      */     char _ch;
/*      */ 
/*      */     StringState(HessianDebugState.State next, char typeCode, boolean isLastChunk)
/*      */     {
/*  870 */       super(next);
/*      */ 
/*  872 */       this._typeCode = typeCode;
/*  873 */       this._isLastChunk = isLastChunk;
/*      */     }
/*      */ 
/*      */     StringState(HessianDebugState.State next, char typeCode, int length)
/*      */     {
/*  878 */       super(next);
/*      */ 
/*  880 */       this._typeCode = typeCode;
/*  881 */       this._isLastChunk = true;
/*  882 */       this._length = length;
/*  883 */       this._lengthIndex = 2;
/*      */     }
/*      */ 
/*      */     StringState(HessianDebugState.State next, char typeCode, int length, boolean isLastChunk)
/*      */     {
/*  888 */       super(next);
/*      */ 
/*  890 */       this._typeCode = typeCode;
/*  891 */       this._isLastChunk = isLastChunk;
/*  892 */       this._length = length;
/*  893 */       this._lengthIndex = 1;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/*  898 */       if (this._lengthIndex < 2) {
/*  899 */         this._length = (256 * this._length + (ch & 0xFF));
/*      */ 
/*  901 */         if ((++this._lengthIndex == 2) && (this._length == 0) && (this._isLastChunk)) {
/*  902 */           if (this._next.isShift(this._value.toString())) {
/*  903 */             return this._next.shift(this._value.toString());
/*      */           }
/*  905 */           printObject("\"" + this._value + "\"");
/*  906 */           return this._next;
/*      */         }
/*      */ 
/*  910 */         return this;
/*      */       }
/*  912 */       if (this._length == 0) {
/*  913 */         if ((ch == 115) || (ch == 120)) {
/*  914 */           this._isLastChunk = false;
/*  915 */           this._lengthIndex = 0;
/*  916 */           return this;
/*      */         }
/*  918 */         if ((ch == 83) || (ch == 88)) {
/*  919 */           this._isLastChunk = true;
/*  920 */           this._lengthIndex = 0;
/*  921 */           return this;
/*      */         }
/*  923 */         if (ch == 0) {
/*  924 */           if (this._next.isShift(this._value.toString())) {
/*  925 */             return this._next.shift(this._value.toString());
/*      */           }
/*  927 */           printObject("\"" + this._value + "\"");
/*  928 */           return this._next;
/*      */         }
/*      */ 
/*  931 */         if ((0 <= ch) && (ch < 32)) {
/*  932 */           this._isLastChunk = true;
/*  933 */           this._lengthIndex = 2;
/*  934 */           this._length = (ch & 0xFF);
/*  935 */           return this;
/*      */         }
/*  937 */         if ((48 <= ch) && (ch < 52)) {
/*  938 */           this._isLastChunk = true;
/*  939 */           this._lengthIndex = 1;
/*  940 */           this._length = (ch - 48);
/*  941 */           return this;
/*      */         }
/*      */ 
/*  944 */         println(String.valueOf((char)ch) + ": unexpected character");
/*  945 */         return this._next;
/*      */       }
/*      */ 
/*  949 */       switch (this._utfState) {
/*      */       case 0:
/*  951 */         if (ch < 128) {
/*  952 */           this._length -= 1;
/*      */ 
/*  954 */           this._value.append((char)ch);
/*      */         }
/*  956 */         else if (ch < 224) {
/*  957 */           this._ch = ((char)((ch & 0x1F) << 6));
/*  958 */           this._utfState = 1;
/*      */         }
/*      */         else {
/*  961 */           this._ch = ((char)((ch & 0xF) << 12));
/*  962 */           this._utfState = 2;
/*      */         }
/*  964 */         break;
/*      */       case 1:
/*      */       case 3:
/*  968 */         this._ch = ((char)(this._ch + (ch & 0x3F)));
/*  969 */         this._value.append(this._ch);
/*  970 */         this._length -= 1;
/*  971 */         this._utfState = 0;
/*  972 */         break;
/*      */       case 2:
/*  975 */         this._ch = ((char)(this._ch + (char)((ch & 0x3F) << 6)));
/*  976 */         this._utfState = 3;
/*      */       }
/*      */ 
/*  980 */       if ((this._length == 0) && (this._isLastChunk)) {
/*  981 */         if (this._next.isShift(this._value.toString())) {
/*  982 */           return this._next.shift(this._value.toString());
/*      */         }
/*  984 */         printObject("\"" + this._value + "\"");
/*      */ 
/*  986 */         return this._next;
/*      */       }
/*      */ 
/*  990 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class MillsState extends HessianDebugState.State
/*      */   {
/*      */     int _length;
/*      */     int _value;
/*      */ 
/*      */     MillsState(HessianDebugState.State next)
/*      */     {
/*  829 */       super(next);
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/*  834 */       this._value = (256 * this._value + (ch & 0xFF));
/*      */ 
/*  836 */       if (++this._length == 4) {
/*  837 */         Double value = Double.valueOf(0.001D * this._value);
/*      */ 
/*  839 */         if (this._next.isShift(value)) {
/*  840 */           return this._next.shift(value);
/*      */         }
/*  842 */         printObject(value.toString());
/*      */ 
/*  844 */         return this._next;
/*      */       }
/*      */ 
/*  848 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class DoubleState extends HessianDebugState.State
/*      */   {
/*      */     int _length;
/*      */     long _value;
/*      */ 
/*      */     DoubleState(HessianDebugState.State next)
/*      */     {
/*  800 */       super(next);
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/*  805 */       this._value = (256L * this._value + (ch & 0xFF));
/*      */ 
/*  807 */       if (++this._length == 8) {
/*  808 */         Double value = Double.valueOf(Double.longBitsToDouble(this._value));
/*      */ 
/*  810 */         if (this._next.isShift(value)) {
/*  811 */           return this._next.shift(value);
/*      */         }
/*  813 */         printObject(value.toString());
/*      */ 
/*  815 */         return this._next;
/*      */       }
/*      */ 
/*  819 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class DateState extends HessianDebugState.State
/*      */   {
/*      */     int _length;
/*      */     long _value;
/*      */     boolean _isMinute;
/*      */ 
/*      */     DateState(HessianDebugState.State next)
/*      */     {
/*  757 */       super(next);
/*      */     }
/*      */ 
/*      */     DateState(HessianDebugState.State next, boolean isMinute)
/*      */     {
/*  762 */       super(next);
/*      */ 
/*  764 */       this._length = 4;
/*  765 */       this._isMinute = isMinute;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/*  771 */       this._value = (256L * this._value + (ch & 0xFF));
/*      */ 
/*  773 */       if (++this._length == 8)
/*      */       {
/*      */         Date value;
/*      */         Date value;
/*  776 */         if (this._isMinute)
/*  777 */           value = new Date(this._value * 60000L);
/*      */         else {
/*  779 */           value = new Date(this._value);
/*      */         }
/*  781 */         if (this._next.isShift(value)) {
/*  782 */           return this._next.shift(value);
/*      */         }
/*  784 */         printObject(value.toString());
/*      */ 
/*  786 */         return this._next;
/*      */       }
/*      */ 
/*  790 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class RefState extends HessianDebugState.State
/*      */   {
/*      */     String _typeCode;
/*      */     int _length;
/*      */     int _value;
/*      */ 
/*      */     RefState(HessianDebugState.State next)
/*      */     {
/*  709 */       super(next);
/*      */     }
/*      */ 
/*      */     RefState(HessianDebugState.State next, String typeCode)
/*      */     {
/*  714 */       super(next);
/*      */ 
/*  716 */       this._typeCode = typeCode;
/*      */     }
/*      */ 
/*      */     RefState(HessianDebugState.State next, String typeCode, int value, int length)
/*      */     {
/*  721 */       super(next);
/*      */ 
/*  723 */       this._typeCode = typeCode;
/*      */ 
/*  725 */       this._value = value;
/*  726 */       this._length = length;
/*      */     }
/*      */ 
/*      */     boolean isShift(Object o)
/*      */     {
/*  732 */       return true;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State shift(Object o)
/*      */     {
/*  738 */       println("ref #" + o);
/*      */ 
/*  740 */       return this._next;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/*  746 */       return nextObject(ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   class DoubleIntegerState extends HessianDebugState.State
/*      */   {
/*      */     int _length;
/*      */     int _value;
/*  667 */     boolean _isFirst = true;
/*      */ 
/*      */     DoubleIntegerState(HessianDebugState.State next, int length)
/*      */     {
/*  671 */       super(next);
/*      */ 
/*  673 */       this._length = length;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/*  678 */       if (this._isFirst)
/*  679 */         this._value = ((byte)ch);
/*      */       else {
/*  681 */         this._value = (256 * this._value + (ch & 0xFF));
/*      */       }
/*  683 */       this._isFirst = false;
/*      */ 
/*  685 */       if (++this._length == 4) {
/*  686 */         Double value = new Double(this._value);
/*      */ 
/*  688 */         if (this._next.isShift(value)) {
/*  689 */           return this._next.shift(value);
/*      */         }
/*  691 */         printObject(value.toString());
/*      */ 
/*  693 */         return this._next;
/*      */       }
/*      */ 
/*  697 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class LongState extends HessianDebugState.State
/*      */   {
/*      */     String _typeCode;
/*      */     int _length;
/*      */     long _value;
/*      */ 
/*      */     LongState(HessianDebugState.State next, String typeCode)
/*      */     {
/*  629 */       super(next);
/*      */ 
/*  631 */       this._typeCode = typeCode;
/*      */     }
/*      */ 
/*      */     LongState(HessianDebugState.State next, String typeCode, long value, int length)
/*      */     {
/*  636 */       super(next);
/*      */ 
/*  638 */       this._typeCode = typeCode;
/*      */ 
/*  640 */       this._value = value;
/*  641 */       this._length = length;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/*  646 */       this._value = (256L * this._value + (ch & 0xFF));
/*      */ 
/*  648 */       if (++this._length == 8) {
/*  649 */         Long value = new Long(this._value);
/*      */ 
/*  651 */         if (this._next.isShift(value)) {
/*  652 */           return this._next.shift(value);
/*      */         }
/*  654 */         printObject(value.toString() + "L");
/*      */ 
/*  656 */         return this._next;
/*      */       }
/*      */ 
/*  660 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class IntegerState extends HessianDebugState.State
/*      */   {
/*      */     String _typeCode;
/*      */     int _length;
/*      */     int _value;
/*      */ 
/*      */     IntegerState(HessianDebugState.State next, String typeCode)
/*      */     {
/*  586 */       super(next);
/*      */ 
/*  588 */       this._typeCode = typeCode;
/*      */     }
/*      */ 
/*      */     IntegerState(HessianDebugState.State next, String typeCode, int value, int length)
/*      */     {
/*  593 */       super(next);
/*      */ 
/*  595 */       this._typeCode = typeCode;
/*      */ 
/*  597 */       this._value = value;
/*  598 */       this._length = length;
/*      */     }
/*      */ 
/*      */     HessianDebugState.State next(int ch)
/*      */     {
/*  603 */       this._value = (256 * this._value + (ch & 0xFF));
/*      */ 
/*  605 */       if (++this._length == 4) {
/*  606 */         Integer value = new Integer(this._value);
/*      */ 
/*  608 */         if (this._next.isShift(value)) {
/*  609 */           return this._next.shift(value);
/*      */         }
/*  611 */         printObject(value.toString());
/*      */ 
/*  613 */         return this._next;
/*      */       }
/*      */ 
/*  617 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   class Top2State extends HessianDebugState.State
/*      */   {
/*      */     Top2State()
/*      */     {
/*  550 */       super();
/*      */     }
/*      */     HessianDebugState.State next(int ch) {
/*  553 */       println();
/*      */ 
/*  555 */       if (ch == 82) {
/*  556 */         return new HessianDebugState.Reply2State(HessianDebugState.this, this);
/*      */       }
/*  558 */       if (ch == 70) {
/*  559 */         return new HessianDebugState.Fault2State(HessianDebugState.this, this);
/*      */       }
/*  561 */       if (ch == 67) {
/*  562 */         return new HessianDebugState.Call2State(HessianDebugState.this, this);
/*      */       }
/*  564 */       if (ch == 72) {
/*  565 */         return new HessianDebugState.Hessian2State(HessianDebugState.this, this);
/*      */       }
/*  567 */       if (ch == 114) {
/*  568 */         return new HessianDebugState.ReplyState(HessianDebugState.this, this);
/*      */       }
/*  570 */       if (ch == 99) {
/*  571 */         return new HessianDebugState.CallState(HessianDebugState.this, this);
/*      */       }
/*      */ 
/*  574 */       return nextObject(ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   class InitialState extends HessianDebugState.State
/*      */   {
/*      */     InitialState()
/*      */     {
/*  534 */       super();
/*      */     }
/*      */     HessianDebugState.State next(int ch) {
/*  537 */       println();
/*      */ 
/*  539 */       if (ch == 114) {
/*  540 */         return new HessianDebugState.ReplyState(HessianDebugState.this, this);
/*      */       }
/*  542 */       if (ch == 99) {
/*  543 */         return new HessianDebugState.CallState(HessianDebugState.this, this);
/*      */       }
/*      */ 
/*  546 */       return nextObject(ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   abstract class State
/*      */   {
/*      */     State _next;
/*      */ 
/*      */     State()
/*      */     {
/*      */     }
/*      */ 
/*      */     State(State next)
/*      */     {
/*  194 */       this._next = next;
/*      */     }
/*      */ 
/*      */     abstract State next(int paramInt);
/*      */ 
/*      */     boolean isShift(Object value)
/*      */     {
/*  201 */       return false;
/*      */     }
/*      */ 
/*      */     State shift(Object value)
/*      */     {
/*  206 */       return this;
/*      */     }
/*      */ 
/*      */     int depth()
/*      */     {
/*  211 */       if (this._next != null) {
/*  212 */         return this._next.depth();
/*      */       }
/*  214 */       return 0;
/*      */     }
/*      */ 
/*      */     void printIndent(int depth)
/*      */     {
/*  219 */       if (HessianDebugState.this._isNewline)
/*  220 */         for (int i = HessianDebugState.this._column; i < depth() + depth; i++) {
/*  221 */           HessianDebugState.this._dbg.print(" ");
/*  222 */           HessianDebugState.access$108(HessianDebugState.this);
/*      */         }
/*      */     }
/*      */ 
/*      */     void print(String string)
/*      */     {
/*  229 */       print(0, string);
/*      */     }
/*      */ 
/*      */     void print(int depth, String string)
/*      */     {
/*  234 */       printIndent(depth);
/*      */ 
/*  236 */       HessianDebugState.this._dbg.print(string);
/*  237 */       HessianDebugState.this._isNewline = false;
/*  238 */       HessianDebugState.this._isObject = false;
/*      */ 
/*  240 */       int p = string.lastIndexOf('\n');
/*  241 */       if (p > 0)
/*  242 */         HessianDebugState.this._column = (string.length() - p - 1);
/*      */       else
/*  244 */         HessianDebugState.access$112(HessianDebugState.this, string.length());
/*      */     }
/*      */ 
/*      */     void println(String string)
/*      */     {
/*  249 */       println(0, string);
/*      */     }
/*      */ 
/*      */     void println(int depth, String string)
/*      */     {
/*  254 */       printIndent(depth);
/*      */ 
/*  256 */       HessianDebugState.this._dbg.println(string);
/*  257 */       HessianDebugState.this._dbg.flush();
/*  258 */       HessianDebugState.this._isNewline = true;
/*  259 */       HessianDebugState.this._isObject = false;
/*  260 */       HessianDebugState.this._column = 0;
/*      */     }
/*      */ 
/*      */     void println()
/*      */     {
/*  265 */       if (!HessianDebugState.this._isNewline) {
/*  266 */         HessianDebugState.this._dbg.println();
/*  267 */         HessianDebugState.this._dbg.flush();
/*      */       }
/*      */ 
/*  270 */       HessianDebugState.this._isNewline = true;
/*  271 */       HessianDebugState.this._isObject = false;
/*  272 */       HessianDebugState.this._column = 0;
/*      */     }
/*      */ 
/*      */     void printObject(String string)
/*      */     {
/*  277 */       if (HessianDebugState.this._isObject) {
/*  278 */         println();
/*      */       }
/*  280 */       printIndent(0);
/*      */ 
/*  282 */       HessianDebugState.this._dbg.print(string);
/*  283 */       HessianDebugState.this._dbg.flush();
/*      */ 
/*  285 */       HessianDebugState.access$112(HessianDebugState.this, string.length());
/*      */ 
/*  287 */       HessianDebugState.this._isNewline = false;
/*  288 */       HessianDebugState.this._isObject = true;
/*      */     }
/*      */ 
/*      */     protected State nextObject(int ch)
/*      */     {
/*  293 */       switch (ch) {
/*      */       case -1:
/*  295 */         println();
/*  296 */         return this;
/*      */       case 78:
/*  299 */         if (isShift(null)) {
/*  300 */           return shift(null);
/*      */         }
/*  302 */         printObject("null");
/*  303 */         return this;
/*      */       case 84:
/*  307 */         if (isShift(Boolean.TRUE)) {
/*  308 */           return shift(Boolean.TRUE);
/*      */         }
/*  310 */         printObject("true");
/*  311 */         return this;
/*      */       case 70:
/*  315 */         if (isShift(Boolean.FALSE)) {
/*  316 */           return shift(Boolean.FALSE);
/*      */         }
/*  318 */         printObject("false");
/*  319 */         return this;
/*      */       case 128:
/*      */       case 129:
/*      */       case 130:
/*      */       case 131:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 135:
/*      */       case 136:
/*      */       case 137:
/*      */       case 138:
/*      */       case 139:
/*      */       case 140:
/*      */       case 141:
/*      */       case 142:
/*      */       case 143:
/*      */       case 144:
/*      */       case 145:
/*      */       case 146:
/*      */       case 147:
/*      */       case 148:
/*      */       case 149:
/*      */       case 150:
/*      */       case 151:
/*      */       case 152:
/*      */       case 153:
/*      */       case 154:
/*      */       case 155:
/*      */       case 156:
/*      */       case 157:
/*      */       case 158:
/*      */       case 159:
/*      */       case 160:
/*      */       case 161:
/*      */       case 162:
/*      */       case 163:
/*      */       case 164:
/*      */       case 165:
/*      */       case 166:
/*      */       case 167:
/*      */       case 168:
/*      */       case 169:
/*      */       case 170:
/*      */       case 171:
/*      */       case 172:
/*      */       case 173:
/*      */       case 174:
/*      */       case 175:
/*      */       case 176:
/*      */       case 177:
/*      */       case 178:
/*      */       case 179:
/*      */       case 180:
/*      */       case 181:
/*      */       case 182:
/*      */       case 183:
/*      */       case 184:
/*      */       case 185:
/*      */       case 186:
/*      */       case 187:
/*      */       case 188:
/*      */       case 189:
/*      */       case 190:
/*      */       case 191:
/*  342 */         Integer value = new Integer(ch - 144);
/*      */ 
/*  344 */         if (isShift(value)) {
/*  345 */           return shift(value);
/*      */         }
/*  347 */         printObject(value.toString());
/*  348 */         return this;
/*      */       case 192:
/*      */       case 193:
/*      */       case 194:
/*      */       case 195:
/*      */       case 196:
/*      */       case 197:
/*      */       case 198:
/*      */       case 199:
/*      */       case 200:
/*      */       case 201:
/*      */       case 202:
/*      */       case 203:
/*      */       case 204:
/*      */       case 205:
/*      */       case 206:
/*      */       case 207:
/*  356 */         return new HessianDebugState.IntegerState(HessianDebugState.this, this, "int", ch - 200, 3);
/*      */       case 208:
/*      */       case 209:
/*      */       case 210:
/*      */       case 211:
/*      */       case 212:
/*      */       case 213:
/*      */       case 214:
/*      */       case 215:
/*  360 */         return new HessianDebugState.IntegerState(HessianDebugState.this, this, "int", ch - 212, 2);
/*      */       case 73:
/*  363 */         return new HessianDebugState.IntegerState(HessianDebugState.this, this, "int");
/*      */       case 216:
/*      */       case 217:
/*      */       case 218:
/*      */       case 219:
/*      */       case 220:
/*      */       case 221:
/*      */       case 222:
/*      */       case 223:
/*      */       case 224:
/*      */       case 225:
/*      */       case 226:
/*      */       case 227:
/*      */       case 228:
/*      */       case 229:
/*      */       case 230:
/*      */       case 231:
/*      */       case 232:
/*      */       case 233:
/*      */       case 234:
/*      */       case 235:
/*      */       case 236:
/*      */       case 237:
/*      */       case 238:
/*      */       case 239:
/*  372 */         Long value = new Long(ch - 224);
/*      */ 
/*  374 */         if (isShift(value)) {
/*  375 */           return shift(value);
/*      */         }
/*  377 */         printObject(value.toString() + "L");
/*  378 */         return this;
/*      */       case 240:
/*      */       case 241:
/*      */       case 242:
/*      */       case 243:
/*      */       case 244:
/*      */       case 245:
/*      */       case 246:
/*      */       case 247:
/*      */       case 248:
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/*      */       case 253:
/*      */       case 254:
/*      */       case 255:
/*  386 */         return new HessianDebugState.LongState(HessianDebugState.this, this, "long", ch - 248, 7);
/*      */       case 56:
/*      */       case 57:
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*      */       case 62:
/*      */       case 63:
/*  390 */         return new HessianDebugState.LongState(HessianDebugState.this, this, "long", ch - 60, 6);
/*      */       case 89:
/*  393 */         return new HessianDebugState.LongState(HessianDebugState.this, this, "long", 0L, 4);
/*      */       case 76:
/*  396 */         return new HessianDebugState.LongState(HessianDebugState.this, this, "long");
/*      */       case 91:
/*      */       case 92:
/*  400 */         Double value = new Double(ch - 91);
/*      */ 
/*  402 */         if (isShift(value)) {
/*  403 */           return shift(value);
/*      */         }
/*  405 */         printObject(value.toString());
/*  406 */         return this;
/*      */       case 93:
/*  411 */         return new HessianDebugState.DoubleIntegerState(HessianDebugState.this, this, 3);
/*      */       case 94:
/*  414 */         return new HessianDebugState.DoubleIntegerState(HessianDebugState.this, this, 2);
/*      */       case 95:
/*  417 */         return new HessianDebugState.MillsState(HessianDebugState.this, this);
/*      */       case 68:
/*  420 */         return new HessianDebugState.DoubleState(HessianDebugState.this, this);
/*      */       case 81:
/*  423 */         return new HessianDebugState.RefState(HessianDebugState.this, this);
/*      */       case 74:
/*  426 */         return new HessianDebugState.DateState(HessianDebugState.this, this);
/*      */       case 75:
/*  429 */         return new HessianDebugState.DateState(HessianDebugState.this, this, true);
/*      */       case 0:
/*  433 */         String value = "\"\"";
/*      */ 
/*  435 */         if (isShift(value)) {
/*  436 */           return shift(value);
/*      */         }
/*  438 */         printObject(value.toString());
/*  439 */         return this;
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 28:
/*      */       case 29:
/*      */       case 30:
/*      */       case 31:
/*  452 */         return new HessianDebugState.StringState(HessianDebugState.this, this, 'S', ch);
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*  455 */         return new HessianDebugState.StringState(HessianDebugState.this, this, 'S', ch - 48, true);
/*      */       case 82:
/*  458 */         return new HessianDebugState.StringState(HessianDebugState.this, this, 'S', false);
/*      */       case 83:
/*  461 */         return new HessianDebugState.StringState(HessianDebugState.this, this, 'S', true);
/*      */       case 32:
/*  465 */         String value = "binary(0)";
/*      */ 
/*  467 */         if (isShift(value)) {
/*  468 */           return shift(value);
/*      */         }
/*  470 */         printObject(value.toString());
/*  471 */         return this;
/*      */       case 33:
/*      */       case 34:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 45:
/*      */       case 46:
/*      */       case 47:
/*  479 */         return new HessianDebugState.BinaryState(HessianDebugState.this, this, 'B', ch - 32);
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*  482 */         return new HessianDebugState.BinaryState(HessianDebugState.this, this, 'B', ch - 52, true);
/*      */       case 65:
/*  485 */         return new HessianDebugState.BinaryState(HessianDebugState.this, this, 'B', false);
/*      */       case 66:
/*  488 */         return new HessianDebugState.BinaryState(HessianDebugState.this, this, 'B', true);
/*      */       case 77:
/*  491 */         return new HessianDebugState.MapState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this));
/*      */       case 72:
/*  494 */         return new HessianDebugState.MapState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this), false);
/*      */       case 85:
/*  497 */         return new HessianDebugState.ListState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this), true);
/*      */       case 87:
/*  500 */         return new HessianDebugState.ListState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this), false);
/*      */       case 86:
/*  503 */         return new HessianDebugState.CompactListState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this), true);
/*      */       case 88:
/*  506 */         return new HessianDebugState.CompactListState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this), false);
/*      */       case 112:
/*      */       case 113:
/*      */       case 114:
/*      */       case 115:
/*      */       case 116:
/*      */       case 117:
/*      */       case 118:
/*      */       case 119:
/*  510 */         return new HessianDebugState.CompactListState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this), true, ch - 112);
/*      */       case 120:
/*      */       case 121:
/*      */       case 122:
/*      */       case 123:
/*      */       case 124:
/*      */       case 125:
/*      */       case 126:
/*      */       case 127:
/*  514 */         return new HessianDebugState.CompactListState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this), false, ch - 120);
/*      */       case 67:
/*  517 */         return new HessianDebugState.ObjectDefState(HessianDebugState.this, this);
/*      */       case 96:
/*      */       case 97:
/*      */       case 98:
/*      */       case 99:
/*      */       case 100:
/*      */       case 101:
/*      */       case 102:
/*      */       case 103:
/*      */       case 104:
/*      */       case 105:
/*      */       case 106:
/*      */       case 107:
/*      */       case 108:
/*      */       case 109:
/*      */       case 110:
/*      */       case 111:
/*  523 */         return new HessianDebugState.ObjectState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this), ch - 96);
/*      */       case 79:
/*  526 */         return new HessianDebugState.ObjectState(HessianDebugState.this, this, HessianDebugState.access$408(HessianDebugState.this));
/*      */       case 64:
/*      */       case 69:
/*      */       case 71:
/*      */       case 80:
/*  529 */       case 90: } return this;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianDebugState
 * JD-Core Version:    0.6.2
 */