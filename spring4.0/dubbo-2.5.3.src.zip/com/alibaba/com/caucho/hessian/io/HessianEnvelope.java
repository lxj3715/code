package com.alibaba.com.caucho.hessian.io;

import java.io.IOException;

public abstract class HessianEnvelope
{
  public abstract Hessian2Output wrap(Hessian2Output paramHessian2Output)
    throws IOException;

  public abstract Hessian2Input unwrap(Hessian2Input paramHessian2Input)
    throws IOException;

  public abstract Hessian2Input unwrapHeaders(Hessian2Input paramHessian2Input)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianEnvelope
 * JD-Core Version:    0.6.2
 */