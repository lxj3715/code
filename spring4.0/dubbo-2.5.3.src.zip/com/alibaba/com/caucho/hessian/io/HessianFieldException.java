/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ public class HessianFieldException extends HessianProtocolException
/*    */ {
/*    */   public HessianFieldException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public HessianFieldException(String message)
/*    */   {
/* 69 */     super(message);
/*    */   }
/*    */ 
/*    */   public HessianFieldException(String message, Throwable cause)
/*    */   {
/* 77 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public HessianFieldException(Throwable cause)
/*    */   {
/* 85 */     super(cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianFieldException
 * JD-Core Version:    0.6.2
 */