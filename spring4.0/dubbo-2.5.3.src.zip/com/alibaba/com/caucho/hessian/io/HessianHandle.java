package com.alibaba.com.caucho.hessian.io;

public abstract interface HessianHandle
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianHandle
 * JD-Core Version:    0.6.2
 */