/*      */ package com.alibaba.com.caucho.hessian.io;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ public class HessianInput extends AbstractHessianInput
/*      */ {
/*   77 */   private static int END_OF_DATA = -2;
/*      */   private static Field _detailMessageField;
/*      */   protected SerializerFactory _serializerFactory;
/*      */   protected ArrayList _refs;
/*      */   private InputStream _is;
/*   89 */   protected int _peek = -1;
/*      */   private String _method;
/*      */   private Reader _chunkReader;
/*      */   private InputStream _chunkInputStream;
/*      */   private Throwable _replyFault;
/*   99 */   private StringBuffer _sbuf = new StringBuffer();
/*      */   private boolean _isLastChunk;
/*      */   private int _chunkLength;
/*      */ 
/*      */   public HessianInput()
/*      */   {
/*      */   }
/*      */ 
/*      */   public HessianInput(InputStream is)
/*      */   {
/*  121 */     init(is);
/*      */   }
/*      */ 
/*      */   public void setSerializerFactory(SerializerFactory factory)
/*      */   {
/*  129 */     this._serializerFactory = factory;
/*      */   }
/*      */ 
/*      */   public SerializerFactory getSerializerFactory()
/*      */   {
/*  137 */     return this._serializerFactory;
/*      */   }
/*      */ 
/*      */   public void init(InputStream is)
/*      */   {
/*  145 */     this._is = is;
/*  146 */     this._method = null;
/*  147 */     this._isLastChunk = true;
/*  148 */     this._chunkLength = 0;
/*  149 */     this._peek = -1;
/*  150 */     this._refs = null;
/*  151 */     this._replyFault = null;
/*      */ 
/*  153 */     if (this._serializerFactory == null)
/*  154 */       this._serializerFactory = new SerializerFactory();
/*      */   }
/*      */ 
/*      */   public String getMethod()
/*      */   {
/*  162 */     return this._method;
/*      */   }
/*      */ 
/*      */   public Throwable getReplyFault()
/*      */   {
/*  170 */     return this._replyFault;
/*      */   }
/*      */ 
/*      */   public int readCall()
/*      */     throws IOException
/*      */   {
/*  183 */     int tag = read();
/*      */ 
/*  185 */     if (tag != 99) {
/*  186 */       throw error("expected hessian call ('c') at " + codeName(tag));
/*      */     }
/*  188 */     int major = read();
/*  189 */     int minor = read();
/*      */ 
/*  191 */     return (major << 16) + minor;
/*      */   }
/*      */ 
/*      */   public void skipOptionalCall()
/*      */     throws IOException
/*      */   {
/*  200 */     int tag = read();
/*      */ 
/*  202 */     if (tag == 99) {
/*  203 */       read();
/*  204 */       read();
/*      */     }
/*      */     else {
/*  207 */       this._peek = tag;
/*      */     }
/*      */   }
/*      */ 
/*      */   public String readMethod()
/*      */     throws IOException
/*      */   {
/*  222 */     int tag = read();
/*      */ 
/*  224 */     if (tag != 109)
/*  225 */       throw error("expected hessian method ('m') at " + codeName(tag));
/*  226 */     int d1 = read();
/*  227 */     int d2 = read();
/*      */ 
/*  229 */     this._isLastChunk = true;
/*  230 */     this._chunkLength = (d1 * 256 + d2);
/*  231 */     this._sbuf.setLength(0);
/*      */     int ch;
/*  233 */     while ((ch = parseChar()) >= 0) {
/*  234 */       this._sbuf.append((char)ch);
/*      */     }
/*  236 */     this._method = this._sbuf.toString();
/*      */ 
/*  238 */     return this._method;
/*      */   }
/*      */ 
/*      */   public void startCall()
/*      */     throws IOException
/*      */   {
/*  254 */     readCall();
/*      */ 
/*  256 */     while (readHeader() != null) {
/*  257 */       readObject();
/*      */     }
/*      */ 
/*  260 */     readMethod();
/*      */   }
/*      */ 
/*      */   public void completeCall()
/*      */     throws IOException
/*      */   {
/*  275 */     int tag = read();
/*      */ 
/*  277 */     if (tag != 122)
/*      */     {
/*  280 */       throw error("expected end of call ('z') at " + codeName(tag) + ".  Check method arguments and ensure method overloading is enabled if necessary");
/*      */     }
/*      */   }
/*      */ 
/*      */   public Object readReply(Class expectedClass)
/*      */     throws Throwable
/*      */   {
/*  290 */     int tag = read();
/*      */ 
/*  292 */     if (tag != 114) {
/*  293 */       error("expected hessian reply at " + codeName(tag));
/*      */     }
/*  295 */     int major = read();
/*  296 */     int minor = read();
/*      */ 
/*  298 */     tag = read();
/*  299 */     if (tag == 102) {
/*  300 */       throw prepareFault();
/*      */     }
/*  302 */     this._peek = tag;
/*      */ 
/*  304 */     Object value = readObject(expectedClass);
/*      */ 
/*  306 */     completeValueReply();
/*      */ 
/*  308 */     return value;
/*      */   }
/*      */ 
/*      */   public void startReply()
/*      */     throws Throwable
/*      */   {
/*  324 */     int tag = read();
/*      */ 
/*  326 */     if (tag != 114) {
/*  327 */       error("expected hessian reply at " + codeName(tag));
/*      */     }
/*  329 */     int major = read();
/*  330 */     int minor = read();
/*      */ 
/*  332 */     tag = read();
/*  333 */     if (tag == 102) {
/*  334 */       throw prepareFault();
/*      */     }
/*  336 */     this._peek = tag;
/*      */   }
/*      */ 
/*      */   private Throwable prepareFault()
/*      */     throws IOException
/*      */   {
/*  345 */     HashMap fault = readFault();
/*      */ 
/*  347 */     Object detail = fault.get("detail");
/*  348 */     String message = (String)fault.get("message");
/*      */ 
/*  350 */     if ((detail instanceof Throwable)) {
/*  351 */       this._replyFault = ((Throwable)detail);
/*      */ 
/*  353 */       if ((message != null) && (_detailMessageField != null))
/*      */         try {
/*  355 */           _detailMessageField.set(this._replyFault, message);
/*      */         }
/*      */         catch (Throwable e)
/*      */         {
/*      */         }
/*  360 */       return this._replyFault;
/*      */     }
/*      */ 
/*  364 */     String code = (String)fault.get("code");
/*      */ 
/*  366 */     this._replyFault = new HessianServiceException(message, code, detail);
/*      */ 
/*  368 */     return this._replyFault;
/*      */   }
/*      */ 
/*      */   public void completeReply()
/*      */     throws IOException
/*      */   {
/*  384 */     int tag = read();
/*      */ 
/*  386 */     if (tag != 122)
/*  387 */       error("expected end of reply at " + codeName(tag));
/*      */   }
/*      */ 
/*      */   public void completeValueReply()
/*      */     throws IOException
/*      */   {
/*  402 */     int tag = read();
/*      */ 
/*  404 */     if (tag != 122)
/*  405 */       error("expected end of reply at " + codeName(tag));
/*      */   }
/*      */ 
/*      */   public String readHeader()
/*      */     throws IOException
/*      */   {
/*  418 */     int tag = read();
/*      */ 
/*  420 */     if (tag == 72) {
/*  421 */       this._isLastChunk = true;
/*  422 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/*  424 */       this._sbuf.setLength(0);
/*      */       int ch;
/*  426 */       while ((ch = parseChar()) >= 0) {
/*  427 */         this._sbuf.append((char)ch);
/*      */       }
/*  429 */       return this._sbuf.toString();
/*      */     }
/*      */ 
/*  432 */     this._peek = tag;
/*      */ 
/*  434 */     return null;
/*      */   }
/*      */ 
/*      */   public void readNull()
/*      */     throws IOException
/*      */   {
/*  447 */     int tag = read();
/*      */ 
/*  449 */     switch (tag) { case 78:
/*  450 */       return;
/*      */     }
/*      */ 
/*  453 */     throw expect("null", tag);
/*      */   }
/*      */ 
/*      */   public boolean readBoolean()
/*      */     throws IOException
/*      */   {
/*  468 */     int tag = read();
/*      */ 
/*  470 */     switch (tag) { case 84:
/*  471 */       return true;
/*      */     case 70:
/*  472 */       return false;
/*      */     case 73:
/*  473 */       return parseInt() == 0;
/*      */     case 76:
/*  474 */       return parseLong() == 0L;
/*      */     case 68:
/*  475 */       return parseDouble() == 0.0D;
/*      */     case 78:
/*  476 */       return false;
/*      */     case 69:
/*      */     case 71:
/*      */     case 72:
/*      */     case 74:
/*      */     case 75:
/*      */     case 77:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 82:
/*  479 */     case 83: } throw expect("boolean", tag);
/*      */   }
/*      */ 
/*      */   public short readShort()
/*      */     throws IOException
/*      */   {
/*  508 */     return (short)readInt();
/*      */   }
/*      */ 
/*      */   public int readInt()
/*      */     throws IOException
/*      */   {
/*  521 */     int tag = read();
/*      */ 
/*  523 */     switch (tag) { case 84:
/*  524 */       return 1;
/*      */     case 70:
/*  525 */       return 0;
/*      */     case 73:
/*  526 */       return parseInt();
/*      */     case 76:
/*  527 */       return (int)parseLong();
/*      */     case 68:
/*  528 */       return (int)parseDouble();
/*      */     }
/*      */ 
/*  531 */     throw expect("int", tag);
/*      */   }
/*      */ 
/*      */   public long readLong()
/*      */     throws IOException
/*      */   {
/*  545 */     int tag = read();
/*      */ 
/*  547 */     switch (tag) { case 84:
/*  548 */       return 1L;
/*      */     case 70:
/*  549 */       return 0L;
/*      */     case 73:
/*  550 */       return parseInt();
/*      */     case 76:
/*  551 */       return parseLong();
/*      */     case 68:
/*  552 */       return ()parseDouble();
/*      */     }
/*      */ 
/*  555 */     throw expect("long", tag);
/*      */   }
/*      */ 
/*      */   public float readFloat()
/*      */     throws IOException
/*      */   {
/*  569 */     return (float)readDouble();
/*      */   }
/*      */ 
/*      */   public double readDouble()
/*      */     throws IOException
/*      */   {
/*  582 */     int tag = read();
/*      */ 
/*  584 */     switch (tag) { case 84:
/*  585 */       return 1.0D;
/*      */     case 70:
/*  586 */       return 0.0D;
/*      */     case 73:
/*  587 */       return parseInt();
/*      */     case 76:
/*  588 */       return parseLong();
/*      */     case 68:
/*  589 */       return parseDouble();
/*      */     }
/*      */ 
/*  592 */     throw expect("long", tag);
/*      */   }
/*      */ 
/*      */   public long readUTCDate()
/*      */     throws IOException
/*      */   {
/*  606 */     int tag = read();
/*      */ 
/*  608 */     if (tag != 100) {
/*  609 */       throw error("expected date at " + codeName(tag));
/*      */     }
/*  611 */     long b64 = read();
/*  612 */     long b56 = read();
/*  613 */     long b48 = read();
/*  614 */     long b40 = read();
/*  615 */     long b32 = read();
/*  616 */     long b24 = read();
/*  617 */     long b16 = read();
/*  618 */     long b8 = read();
/*      */ 
/*  620 */     return (b64 << 56) + (b56 << 48) + (b48 << 40) + (b40 << 32) + (b32 << 24) + (b24 << 16) + (b16 << 8) + b8;
/*      */   }
/*      */ 
/*      */   public int readChar()
/*      */     throws IOException
/*      */   {
/*  636 */     if (this._chunkLength > 0) {
/*  637 */       this._chunkLength -= 1;
/*  638 */       if ((this._chunkLength == 0) && (this._isLastChunk)) {
/*  639 */         this._chunkLength = END_OF_DATA;
/*      */       }
/*  641 */       int ch = parseUTF8Char();
/*  642 */       return ch;
/*      */     }
/*  644 */     if (this._chunkLength == END_OF_DATA) {
/*  645 */       this._chunkLength = 0;
/*  646 */       return -1;
/*      */     }
/*      */ 
/*  649 */     int tag = read();
/*      */ 
/*  651 */     switch (tag) {
/*      */     case 78:
/*  653 */       return -1;
/*      */     case 83:
/*      */     case 88:
/*      */     case 115:
/*      */     case 120:
/*  659 */       this._isLastChunk = ((tag == 83) || (tag == 88));
/*  660 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/*  662 */       this._chunkLength -= 1;
/*  663 */       int value = parseUTF8Char();
/*      */ 
/*  667 */       if ((this._chunkLength == 0) && (this._isLastChunk)) {
/*  668 */         this._chunkLength = END_OF_DATA;
/*      */       }
/*  670 */       return value;
/*      */     }
/*      */ 
/*  673 */     throw new IOException("expected 'S' at " + (char)tag);
/*      */   }
/*      */ 
/*      */   public int readString(char[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  683 */     int readLength = 0;
/*      */ 
/*  685 */     if (this._chunkLength == END_OF_DATA) {
/*  686 */       this._chunkLength = 0;
/*  687 */       return -1;
/*      */     }
/*  689 */     if (this._chunkLength == 0) {
/*  690 */       int tag = read();
/*      */ 
/*  692 */       switch (tag) {
/*      */       case 78:
/*  694 */         return -1;
/*      */       case 83:
/*      */       case 88:
/*      */       case 115:
/*      */       case 120:
/*  700 */         this._isLastChunk = ((tag == 83) || (tag == 88));
/*  701 */         this._chunkLength = ((read() << 8) + read());
/*  702 */         break;
/*      */       default:
/*  705 */         throw new IOException("expected 'S' at " + (char)tag);
/*      */       }
/*      */     }
/*      */ 
/*  709 */     while (length > 0) {
/*  710 */       if (this._chunkLength > 0) {
/*  711 */         buffer[(offset++)] = ((char)parseUTF8Char());
/*  712 */         this._chunkLength -= 1;
/*  713 */         length--;
/*  714 */         readLength++;
/*      */       } else {
/*  716 */         if (this._isLastChunk) {
/*  717 */           if (readLength == 0) {
/*  718 */             return -1;
/*      */           }
/*  720 */           this._chunkLength = END_OF_DATA;
/*  721 */           return readLength;
/*      */         }
/*      */ 
/*  725 */         int tag = read();
/*      */ 
/*  727 */         switch (tag) {
/*      */         case 83:
/*      */         case 88:
/*      */         case 115:
/*      */         case 120:
/*  732 */           this._isLastChunk = ((tag == 83) || (tag == 88));
/*  733 */           this._chunkLength = ((read() << 8) + read());
/*  734 */           break;
/*      */         default:
/*  737 */           throw new IOException("expected 'S' at " + (char)tag);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  742 */     if (readLength == 0)
/*  743 */       return -1;
/*  744 */     if ((this._chunkLength > 0) || (!this._isLastChunk)) {
/*  745 */       return readLength;
/*      */     }
/*  747 */     this._chunkLength = END_OF_DATA;
/*  748 */     return readLength;
/*      */   }
/*      */ 
/*      */   public String readString()
/*      */     throws IOException
/*      */   {
/*  762 */     int tag = read();
/*      */ 
/*  764 */     switch (tag) {
/*      */     case 78:
/*  766 */       return null;
/*      */     case 73:
/*  769 */       return String.valueOf(parseInt());
/*      */     case 76:
/*  771 */       return String.valueOf(parseLong());
/*      */     case 68:
/*  773 */       return String.valueOf(parseDouble());
/*      */     case 83:
/*      */     case 88:
/*      */     case 115:
/*      */     case 120:
/*  779 */       this._isLastChunk = ((tag == 83) || (tag == 88));
/*  780 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/*  782 */       this._sbuf.setLength(0);
/*      */       int ch;
/*  785 */       while ((ch = parseChar()) >= 0) {
/*  786 */         this._sbuf.append((char)ch);
/*      */       }
/*  788 */       return this._sbuf.toString();
/*      */     }
/*      */ 
/*  791 */     throw expect("string", tag);
/*      */   }
/*      */ 
/*      */   public Node readNode()
/*      */     throws IOException
/*      */   {
/*  805 */     int tag = read();
/*      */ 
/*  807 */     switch (tag) {
/*      */     case 78:
/*  809 */       return null;
/*      */     case 83:
/*      */     case 88:
/*      */     case 115:
/*      */     case 120:
/*  815 */       this._isLastChunk = ((tag == 83) || (tag == 88));
/*  816 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/*  818 */       throw error("Can't handle string in this context");
/*      */     }
/*      */ 
/*  821 */     throw expect("string", tag);
/*      */   }
/*      */ 
/*      */   public byte[] readBytes()
/*      */     throws IOException
/*      */   {
/*  835 */     int tag = read();
/*      */ 
/*  837 */     switch (tag) {
/*      */     case 78:
/*  839 */       return null;
/*      */     case 66:
/*      */     case 98:
/*  843 */       this._isLastChunk = (tag == 66);
/*  844 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/*  846 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*      */       int data;
/*  849 */       while ((data = parseByte()) >= 0) {
/*  850 */         bos.write(data);
/*      */       }
/*  852 */       return bos.toByteArray();
/*      */     }
/*      */ 
/*  855 */     throw expect("bytes", tag);
/*      */   }
/*      */ 
/*      */   public int readByte()
/*      */     throws IOException
/*      */   {
/*  865 */     if (this._chunkLength > 0) {
/*  866 */       this._chunkLength -= 1;
/*  867 */       if ((this._chunkLength == 0) && (this._isLastChunk)) {
/*  868 */         this._chunkLength = END_OF_DATA;
/*      */       }
/*  870 */       return read();
/*      */     }
/*  872 */     if (this._chunkLength == END_OF_DATA) {
/*  873 */       this._chunkLength = 0;
/*  874 */       return -1;
/*      */     }
/*      */ 
/*  877 */     int tag = read();
/*      */ 
/*  879 */     switch (tag) {
/*      */     case 78:
/*  881 */       return -1;
/*      */     case 66:
/*      */     case 98:
/*  885 */       this._isLastChunk = (tag == 66);
/*  886 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/*  888 */       int value = parseByte();
/*      */ 
/*  892 */       if ((this._chunkLength == 0) && (this._isLastChunk)) {
/*  893 */         this._chunkLength = END_OF_DATA;
/*      */       }
/*  895 */       return value;
/*      */     }
/*      */ 
/*  898 */     throw new IOException("expected 'B' at " + (char)tag);
/*      */   }
/*      */ 
/*      */   public int readBytes(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  908 */     int readLength = 0;
/*      */ 
/*  910 */     if (this._chunkLength == END_OF_DATA) {
/*  911 */       this._chunkLength = 0;
/*  912 */       return -1;
/*      */     }
/*  914 */     if (this._chunkLength == 0) {
/*  915 */       int tag = read();
/*      */ 
/*  917 */       switch (tag) {
/*      */       case 78:
/*  919 */         return -1;
/*      */       case 66:
/*      */       case 98:
/*  923 */         this._isLastChunk = (tag == 66);
/*  924 */         this._chunkLength = ((read() << 8) + read());
/*  925 */         break;
/*      */       default:
/*  928 */         throw new IOException("expected 'B' at " + (char)tag);
/*      */       }
/*      */     }
/*      */ 
/*  932 */     while (length > 0) {
/*  933 */       if (this._chunkLength > 0) {
/*  934 */         buffer[(offset++)] = ((byte)read());
/*  935 */         this._chunkLength -= 1;
/*  936 */         length--;
/*  937 */         readLength++;
/*      */       } else {
/*  939 */         if (this._isLastChunk) {
/*  940 */           if (readLength == 0) {
/*  941 */             return -1;
/*      */           }
/*  943 */           this._chunkLength = END_OF_DATA;
/*  944 */           return readLength;
/*      */         }
/*      */ 
/*  948 */         int tag = read();
/*      */ 
/*  950 */         switch (tag) {
/*      */         case 66:
/*      */         case 98:
/*  953 */           this._isLastChunk = (tag == 66);
/*  954 */           this._chunkLength = ((read() << 8) + read());
/*  955 */           break;
/*      */         default:
/*  958 */           throw new IOException("expected 'B' at " + (char)tag);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  963 */     if (readLength == 0)
/*  964 */       return -1;
/*  965 */     if ((this._chunkLength > 0) || (!this._isLastChunk)) {
/*  966 */       return readLength;
/*      */     }
/*  968 */     this._chunkLength = END_OF_DATA;
/*  969 */     return readLength;
/*      */   }
/*      */ 
/*      */   private HashMap readFault()
/*      */     throws IOException
/*      */   {
/*  979 */     HashMap map = new HashMap();
/*      */ 
/*  981 */     for (int code = read(); 
/*  982 */       (code > 0) && (code != 122); code = read()) {
/*  983 */       this._peek = code;
/*      */ 
/*  985 */       Object key = readObject();
/*  986 */       Object value = readObject();
/*      */ 
/*  988 */       if ((key != null) && (value != null)) {
/*  989 */         map.put(key, value);
/*      */       }
/*      */     }
/*  992 */     if (code != 122) {
/*  993 */       throw expect("fault", code);
/*      */     }
/*  995 */     return map;
/*      */   }
/*      */ 
/*      */   public Object readObject(Class cl)
/*      */     throws IOException
/*      */   {
/* 1004 */     if ((cl == null) || (cl == Object.class)) {
/* 1005 */       return readObject();
/*      */     }
/* 1007 */     int tag = read();
/*      */ 
/* 1009 */     switch (tag) {
/*      */     case 78:
/* 1011 */       return null;
/*      */     case 77:
/* 1015 */       String type = readType();
/*      */ 
/* 1018 */       if ("".equals(type))
/*      */       {
/* 1020 */         Deserializer reader = this._serializerFactory.getDeserializer(cl);
/*      */ 
/* 1022 */         return reader.readMap(this);
/*      */       }
/*      */ 
/* 1026 */       Deserializer reader = this._serializerFactory.getObjectDeserializer(type, cl);
/*      */ 
/* 1028 */       return reader.readMap(this);
/*      */     case 86:
/* 1034 */       String type = readType();
/* 1035 */       int length = readLength();
/*      */ 
/* 1038 */       Deserializer reader = this._serializerFactory.getObjectDeserializer(type);
/*      */ 
/* 1040 */       if ((cl != reader.getType()) && (cl.isAssignableFrom(reader.getType()))) {
/* 1041 */         return reader.readList(this, length);
/*      */       }
/* 1043 */       reader = this._serializerFactory.getDeserializer(cl);
/*      */ 
/* 1045 */       Object v = reader.readList(this, length);
/*      */ 
/* 1047 */       return v;
/*      */     case 82:
/* 1052 */       int ref = parseInt();
/*      */ 
/* 1054 */       return this._refs.get(ref);
/*      */     case 114:
/* 1059 */       String type = readType();
/* 1060 */       String url = readString();
/*      */ 
/* 1062 */       return resolveRemote(type, url);
/*      */     }
/*      */ 
/* 1066 */     this._peek = tag;
/*      */ 
/* 1071 */     Object value = this._serializerFactory.getDeserializer(cl).readObject(this);
/*      */ 
/* 1073 */     return value;
/*      */   }
/*      */ 
/*      */   public Object readObject()
/*      */     throws IOException
/*      */   {
/* 1083 */     int tag = read();
/*      */ 
/* 1085 */     switch (tag) {
/*      */     case 78:
/* 1087 */       return null;
/*      */     case 84:
/* 1090 */       return Boolean.valueOf(true);
/*      */     case 70:
/* 1093 */       return Boolean.valueOf(false);
/*      */     case 73:
/* 1096 */       return Integer.valueOf(parseInt());
/*      */     case 76:
/* 1099 */       return Long.valueOf(parseLong());
/*      */     case 68:
/* 1102 */       return Double.valueOf(parseDouble());
/*      */     case 100:
/* 1105 */       return new Date(parseLong());
/*      */     case 88:
/*      */     case 120:
/* 1109 */       this._isLastChunk = (tag == 88);
/* 1110 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1112 */       return parseXML();
/*      */     case 83:
/*      */     case 115:
/* 1117 */       this._isLastChunk = (tag == 83);
/* 1118 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1121 */       this._sbuf.setLength(0);
/*      */       int data;
/* 1123 */       while ((data = parseChar()) >= 0) {
/* 1124 */         this._sbuf.append((char)data);
/*      */       }
/* 1126 */       return this._sbuf.toString();
/*      */     case 66:
/*      */     case 98:
/* 1131 */       this._isLastChunk = (tag == 66);
/* 1132 */       this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1135 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*      */       int data;
/* 1137 */       while ((data = parseByte()) >= 0) {
/* 1138 */         bos.write(data);
/*      */       }
/* 1140 */       return bos.toByteArray();
/*      */     case 86:
/* 1144 */       String type = readType();
/* 1145 */       int length = readLength();
/*      */ 
/* 1147 */       return this._serializerFactory.readList(this, length, type);
/*      */     case 77:
/* 1151 */       String type = readType();
/*      */ 
/* 1153 */       return this._serializerFactory.readMap(this, type);
/*      */     case 82:
/* 1157 */       int ref = parseInt();
/*      */ 
/* 1159 */       return this._refs.get(ref);
/*      */     case 114:
/* 1163 */       String type = readType();
/* 1164 */       String url = readString();
/*      */ 
/* 1166 */       return resolveRemote(type, url);
/*      */     case 67:
/*      */     case 69:
/*      */     case 71:
/*      */     case 72:
/*      */     case 74:
/*      */     case 75:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 85:
/*      */     case 87:
/*      */     case 89:
/*      */     case 90:
/*      */     case 91:
/*      */     case 92:
/*      */     case 93:
/*      */     case 94:
/*      */     case 95:
/*      */     case 96:
/*      */     case 97:
/*      */     case 99:
/*      */     case 101:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/*      */     case 112:
/*      */     case 113:
/*      */     case 116:
/*      */     case 117:
/*      */     case 118:
/* 1170 */     case 119: } throw error("unknown code for readObject at " + codeName(tag));
/*      */   }
/*      */ 
/*      */   public Object readRemote()
/*      */     throws IOException
/*      */   {
/* 1180 */     String type = readType();
/* 1181 */     String url = readString();
/*      */ 
/* 1183 */     return resolveRemote(type, url);
/*      */   }
/*      */ 
/*      */   public Object readRef()
/*      */     throws IOException
/*      */   {
/* 1192 */     return this._refs.get(parseInt());
/*      */   }
/*      */ 
/*      */   public int readListStart()
/*      */     throws IOException
/*      */   {
/* 1201 */     return read();
/*      */   }
/*      */ 
/*      */   public int readMapStart()
/*      */     throws IOException
/*      */   {
/* 1210 */     return read();
/*      */   }
/*      */ 
/*      */   public boolean isEnd()
/*      */     throws IOException
/*      */   {
/* 1219 */     int code = read();
/*      */ 
/* 1221 */     this._peek = code;
/*      */ 
/* 1223 */     return (code < 0) || (code == 122);
/*      */   }
/*      */ 
/*      */   public void readEnd()
/*      */     throws IOException
/*      */   {
/* 1232 */     int code = read();
/*      */ 
/* 1234 */     if (code != 122)
/* 1235 */       throw error("unknown code at " + codeName(code));
/*      */   }
/*      */ 
/*      */   public void readMapEnd()
/*      */     throws IOException
/*      */   {
/* 1244 */     int code = read();
/*      */ 
/* 1246 */     if (code != 122)
/* 1247 */       throw error("expected end of map ('z') at " + codeName(code));
/*      */   }
/*      */ 
/*      */   public void readListEnd()
/*      */     throws IOException
/*      */   {
/* 1256 */     int code = read();
/*      */ 
/* 1258 */     if (code != 122)
/* 1259 */       throw error("expected end of list ('z') at " + codeName(code));
/*      */   }
/*      */ 
/*      */   public int addRef(Object ref)
/*      */   {
/* 1267 */     if (this._refs == null) {
/* 1268 */       this._refs = new ArrayList();
/*      */     }
/* 1270 */     this._refs.add(ref);
/*      */ 
/* 1272 */     return this._refs.size() - 1;
/*      */   }
/*      */ 
/*      */   public void setRef(int i, Object ref)
/*      */   {
/* 1280 */     this._refs.set(i, ref);
/*      */   }
/*      */ 
/*      */   public void resetReferences()
/*      */   {
/* 1288 */     if (this._refs != null)
/* 1289 */       this._refs.clear();
/*      */   }
/*      */ 
/*      */   public Object resolveRemote(String type, String url)
/*      */     throws IOException
/*      */   {
/* 1298 */     HessianRemoteResolver resolver = getRemoteResolver();
/*      */ 
/* 1300 */     if (resolver != null) {
/* 1301 */       return resolver.lookup(type, url);
/*      */     }
/* 1303 */     return new HessianRemote(type, url);
/*      */   }
/*      */ 
/*      */   public String readType()
/*      */     throws IOException
/*      */   {
/* 1316 */     int code = read();
/*      */ 
/* 1318 */     if (code != 116) {
/* 1319 */       this._peek = code;
/* 1320 */       return "";
/*      */     }
/*      */ 
/* 1323 */     this._isLastChunk = true;
/* 1324 */     this._chunkLength = ((read() << 8) + read());
/*      */ 
/* 1326 */     this._sbuf.setLength(0);
/*      */     int ch;
/* 1328 */     while ((ch = parseChar()) >= 0) {
/* 1329 */       this._sbuf.append((char)ch);
/*      */     }
/* 1331 */     return this._sbuf.toString();
/*      */   }
/*      */ 
/*      */   public int readLength()
/*      */     throws IOException
/*      */   {
/* 1344 */     int code = read();
/*      */ 
/* 1346 */     if (code != 108) {
/* 1347 */       this._peek = code;
/* 1348 */       return -1;
/*      */     }
/*      */ 
/* 1351 */     return parseInt();
/*      */   }
/*      */ 
/*      */   private int parseInt()
/*      */     throws IOException
/*      */   {
/* 1364 */     int b32 = read();
/* 1365 */     int b24 = read();
/* 1366 */     int b16 = read();
/* 1367 */     int b8 = read();
/*      */ 
/* 1369 */     return (b32 << 24) + (b24 << 16) + (b16 << 8) + b8;
/*      */   }
/*      */ 
/*      */   private long parseLong()
/*      */     throws IOException
/*      */   {
/* 1382 */     long b64 = read();
/* 1383 */     long b56 = read();
/* 1384 */     long b48 = read();
/* 1385 */     long b40 = read();
/* 1386 */     long b32 = read();
/* 1387 */     long b24 = read();
/* 1388 */     long b16 = read();
/* 1389 */     long b8 = read();
/*      */ 
/* 1391 */     return (b64 << 56) + (b56 << 48) + (b48 << 40) + (b40 << 32) + (b32 << 24) + (b24 << 16) + (b16 << 8) + b8;
/*      */   }
/*      */ 
/*      */   private double parseDouble()
/*      */     throws IOException
/*      */   {
/* 1411 */     long b64 = read();
/* 1412 */     long b56 = read();
/* 1413 */     long b48 = read();
/* 1414 */     long b40 = read();
/* 1415 */     long b32 = read();
/* 1416 */     long b24 = read();
/* 1417 */     long b16 = read();
/* 1418 */     long b8 = read();
/*      */ 
/* 1420 */     long bits = (b64 << 56) + (b56 << 48) + (b48 << 40) + (b40 << 32) + (b32 << 24) + (b24 << 16) + (b16 << 8) + b8;
/*      */ 
/* 1429 */     return Double.longBitsToDouble(bits);
/*      */   }
/*      */ 
/*      */   Node parseXML()
/*      */     throws IOException
/*      */   {
/* 1435 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   private int parseChar()
/*      */     throws IOException
/*      */   {
/* 1444 */     while (this._chunkLength <= 0) {
/* 1445 */       if (this._isLastChunk) {
/* 1446 */         return -1;
/*      */       }
/* 1448 */       int code = read();
/*      */ 
/* 1450 */       switch (code) {
/*      */       case 115:
/*      */       case 120:
/* 1453 */         this._isLastChunk = false;
/*      */ 
/* 1455 */         this._chunkLength = ((read() << 8) + read());
/* 1456 */         break;
/*      */       case 83:
/*      */       case 88:
/* 1460 */         this._isLastChunk = true;
/*      */ 
/* 1462 */         this._chunkLength = ((read() << 8) + read());
/* 1463 */         break;
/*      */       default:
/* 1466 */         throw expect("string", code);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1471 */     this._chunkLength -= 1;
/*      */ 
/* 1473 */     return parseUTF8Char();
/*      */   }
/*      */ 
/*      */   private int parseUTF8Char()
/*      */     throws IOException
/*      */   {
/* 1482 */     int ch = read();
/*      */ 
/* 1484 */     if (ch < 128)
/* 1485 */       return ch;
/* 1486 */     if ((ch & 0xE0) == 192) {
/* 1487 */       int ch1 = read();
/* 1488 */       int v = ((ch & 0x1F) << 6) + (ch1 & 0x3F);
/*      */ 
/* 1490 */       return v;
/*      */     }
/* 1492 */     if ((ch & 0xF0) == 224) {
/* 1493 */       int ch1 = read();
/* 1494 */       int ch2 = read();
/* 1495 */       int v = ((ch & 0xF) << 12) + ((ch1 & 0x3F) << 6) + (ch2 & 0x3F);
/*      */ 
/* 1497 */       return v;
/*      */     }
/*      */ 
/* 1500 */     throw error("bad utf-8 encoding at " + codeName(ch));
/*      */   }
/*      */ 
/*      */   private int parseByte()
/*      */     throws IOException
/*      */   {
/* 1509 */     while (this._chunkLength <= 0) {
/* 1510 */       if (this._isLastChunk) {
/* 1511 */         return -1;
/*      */       }
/*      */ 
/* 1514 */       int code = read();
/*      */ 
/* 1516 */       switch (code) {
/*      */       case 98:
/* 1518 */         this._isLastChunk = false;
/*      */ 
/* 1520 */         this._chunkLength = ((read() << 8) + read());
/* 1521 */         break;
/*      */       case 66:
/* 1524 */         this._isLastChunk = true;
/*      */ 
/* 1526 */         this._chunkLength = ((read() << 8) + read());
/* 1527 */         break;
/*      */       default:
/* 1530 */         throw expect("byte[]", code);
/*      */       }
/*      */     }
/*      */ 
/* 1534 */     this._chunkLength -= 1;
/*      */ 
/* 1536 */     return read();
/*      */   }
/*      */ 
/*      */   public InputStream readInputStream()
/*      */     throws IOException
/*      */   {
/* 1545 */     int tag = read();
/*      */ 
/* 1547 */     switch (tag) {
/*      */     case 78:
/* 1549 */       return null;
/*      */     case 66:
/*      */     case 98:
/* 1553 */       this._isLastChunk = (tag == 66);
/* 1554 */       this._chunkLength = ((read() << 8) + read());
/* 1555 */       break;
/*      */     default:
/* 1558 */       throw expect("inputStream", tag);
/*      */     }
/*      */ 
/* 1561 */     return new InputStream() {
/* 1562 */       boolean _isClosed = false;
/*      */ 
/*      */       public int read()
/*      */         throws IOException
/*      */       {
/* 1567 */         if ((this._isClosed) || (HessianInput.this._is == null)) {
/* 1568 */           return -1;
/*      */         }
/* 1570 */         int ch = HessianInput.this.parseByte();
/* 1571 */         if (ch < 0) {
/* 1572 */           this._isClosed = true;
/*      */         }
/* 1574 */         return ch;
/*      */       }
/*      */ 
/*      */       public int read(byte[] buffer, int offset, int length)
/*      */         throws IOException
/*      */       {
/* 1580 */         if ((this._isClosed) || (HessianInput.this._is == null)) {
/* 1581 */           return -1;
/*      */         }
/* 1583 */         int len = HessianInput.this.read(buffer, offset, length);
/* 1584 */         if (len < 0) {
/* 1585 */           this._isClosed = true;
/*      */         }
/* 1587 */         return len;
/*      */       }
/*      */ 
/*      */       public void close()
/*      */         throws IOException
/*      */       {
/* 1593 */         while (read() >= 0);
/* 1596 */         this._isClosed = true;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   int read(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1607 */     int readLength = 0;
/*      */ 
/* 1609 */     while (length > 0) {
/* 1610 */       while (this._chunkLength <= 0) {
/* 1611 */         if (this._isLastChunk) {
/* 1612 */           return readLength == 0 ? -1 : readLength;
/*      */         }
/* 1614 */         int code = read();
/*      */ 
/* 1616 */         switch (code) {
/*      */         case 98:
/* 1618 */           this._isLastChunk = false;
/*      */ 
/* 1620 */           this._chunkLength = ((read() << 8) + read());
/* 1621 */           break;
/*      */         case 66:
/* 1624 */           this._isLastChunk = true;
/*      */ 
/* 1626 */           this._chunkLength = ((read() << 8) + read());
/* 1627 */           break;
/*      */         default:
/* 1630 */           throw expect("byte[]", code);
/*      */         }
/*      */       }
/*      */ 
/* 1634 */       int sublen = this._chunkLength;
/* 1635 */       if (length < sublen) {
/* 1636 */         sublen = length;
/*      */       }
/* 1638 */       sublen = this._is.read(buffer, offset, sublen);
/* 1639 */       offset += sublen;
/* 1640 */       readLength += sublen;
/* 1641 */       length -= sublen;
/* 1642 */       this._chunkLength -= sublen;
/*      */     }
/*      */ 
/* 1645 */     return readLength;
/*      */   }
/*      */ 
/*      */   final int read()
/*      */     throws IOException
/*      */   {
/* 1651 */     if (this._peek >= 0) {
/* 1652 */       int value = this._peek;
/* 1653 */       this._peek = -1;
/* 1654 */       return value;
/*      */     }
/*      */ 
/* 1657 */     int ch = this._is.read();
/*      */ 
/* 1659 */     return ch;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/* 1664 */     this._is = null;
/*      */   }
/*      */ 
/*      */   public Reader getReader()
/*      */   {
/* 1669 */     return null;
/*      */   }
/*      */ 
/*      */   protected IOException expect(String expect, int ch)
/*      */   {
/* 1674 */     return error("expected " + expect + " at " + codeName(ch));
/*      */   }
/*      */ 
/*      */   protected String codeName(int ch)
/*      */   {
/* 1679 */     if (ch < 0) {
/* 1680 */       return "end of file";
/*      */     }
/* 1682 */     return "0x" + Integer.toHexString(ch & 0xFF) + " (" + (char)ch + ")";
/*      */   }
/*      */ 
/*      */   protected IOException error(String message)
/*      */   {
/* 1687 */     if (this._method != null) {
/* 1688 */       return new HessianProtocolException(this._method + ": " + message);
/*      */     }
/* 1690 */     return new HessianProtocolException(message);
/*      */   }
/*      */ 
/*      */   static {
/*      */     try {
/* 1695 */       _detailMessageField = Throwable.class.getDeclaredField("detailMessage");
/* 1696 */       _detailMessageField.setAccessible(true);
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianInput
 * JD-Core Version:    0.6.2
 */