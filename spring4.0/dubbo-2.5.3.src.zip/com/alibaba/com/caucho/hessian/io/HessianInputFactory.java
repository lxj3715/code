/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class HessianInputFactory
/*    */ {
/* 56 */   public static final Logger log = Logger.getLogger(HessianInputFactory.class.getName());
/*    */   private SerializerFactory _serializerFactory;
/*    */ 
/*    */   public void setSerializerFactory(SerializerFactory factory)
/*    */   {
/* 63 */     this._serializerFactory = factory;
/*    */   }
/*    */ 
/*    */   public SerializerFactory getSerializerFactory()
/*    */   {
/* 68 */     return this._serializerFactory;
/*    */   }
/*    */ 
/*    */   public AbstractHessianInput open(InputStream is)
/*    */     throws IOException
/*    */   {
/* 74 */     int code = is.read();
/*    */ 
/* 76 */     int major = is.read();
/* 77 */     int minor = is.read();
/*    */ 
/* 79 */     switch (code) {
/*    */     case 67:
/*    */     case 82:
/*    */     case 99:
/*    */     case 114:
/* 84 */       if (major >= 2) {
/* 85 */         AbstractHessianInput in = new Hessian2Input(is);
/* 86 */         in.setSerializerFactory(this._serializerFactory);
/* 87 */         return in;
/*    */       }
/*    */ 
/* 90 */       AbstractHessianInput in = new HessianInput(is);
/* 91 */       in.setSerializerFactory(this._serializerFactory);
/* 92 */       return in;
/*    */     }
/*    */ 
/* 96 */     throw new IOException((char)code + " is an unknown Hessian message code.");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianInputFactory
 * JD-Core Version:    0.6.2
 */