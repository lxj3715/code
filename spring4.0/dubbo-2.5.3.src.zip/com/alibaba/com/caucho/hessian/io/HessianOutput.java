/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.IdentityHashMap;
/*     */ 
/*     */ public class HessianOutput extends AbstractHessianOutput
/*     */ {
/*     */   protected OutputStream os;
/*     */   private IdentityHashMap _refs;
/*  80 */   private int _version = 1;
/*     */ 
/*     */   public HessianOutput(OutputStream os)
/*     */   {
/*  90 */     init(os);
/*     */   }
/*     */ 
/*     */   public HessianOutput()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void init(OutputStream os)
/*     */   {
/* 105 */     this.os = os;
/*     */ 
/* 107 */     this._refs = null;
/*     */ 
/* 109 */     if (this._serializerFactory == null)
/* 110 */       this._serializerFactory = new SerializerFactory();
/*     */   }
/*     */ 
/*     */   public void setVersion(int version)
/*     */   {
/* 118 */     this._version = version;
/*     */   }
/*     */ 
/*     */   public void call(String method, Object[] args)
/*     */     throws IOException
/*     */   {
/* 127 */     int length = args != null ? args.length : 0;
/*     */ 
/* 129 */     startCall(method, length);
/*     */ 
/* 131 */     for (int i = 0; i < length; i++) {
/* 132 */       writeObject(args[i]);
/*     */     }
/* 134 */     completeCall();
/*     */   }
/*     */ 
/*     */   public void startCall(String method, int length)
/*     */     throws IOException
/*     */   {
/* 152 */     this.os.write(99);
/* 153 */     this.os.write(this._version);
/* 154 */     this.os.write(0);
/*     */ 
/* 156 */     this.os.write(109);
/* 157 */     int len = method.length();
/* 158 */     this.os.write(len >> 8);
/* 159 */     this.os.write(len);
/* 160 */     printString(method, 0, len);
/*     */   }
/*     */ 
/*     */   public void startCall()
/*     */     throws IOException
/*     */   {
/* 176 */     this.os.write(99);
/* 177 */     this.os.write(0);
/* 178 */     this.os.write(1);
/*     */   }
/*     */ 
/*     */   public void writeMethod(String method)
/*     */     throws IOException
/*     */   {
/* 193 */     this.os.write(109);
/* 194 */     int len = method.length();
/* 195 */     this.os.write(len >> 8);
/* 196 */     this.os.write(len);
/* 197 */     printString(method, 0, len);
/*     */   }
/*     */ 
/*     */   public void completeCall()
/*     */     throws IOException
/*     */   {
/* 210 */     this.os.write(122);
/*     */   }
/*     */ 
/*     */   public void startReply()
/*     */     throws IOException
/*     */   {
/* 225 */     this.os.write(114);
/* 226 */     this.os.write(1);
/* 227 */     this.os.write(0);
/*     */   }
/*     */ 
/*     */   public void completeReply()
/*     */     throws IOException
/*     */   {
/* 242 */     this.os.write(122);
/*     */   }
/*     */ 
/*     */   public void writeHeader(String name)
/*     */     throws IOException
/*     */   {
/* 255 */     int len = name.length();
/*     */ 
/* 257 */     this.os.write(72);
/* 258 */     this.os.write(len >> 8);
/* 259 */     this.os.write(len);
/*     */ 
/* 261 */     printString(name);
/*     */   }
/*     */ 
/*     */   public void writeFault(String code, String message, Object detail)
/*     */     throws IOException
/*     */   {
/* 288 */     this.os.write(102);
/* 289 */     writeString("code");
/* 290 */     writeString(code);
/*     */ 
/* 292 */     writeString("message");
/* 293 */     writeString(message);
/*     */ 
/* 295 */     if (detail != null) {
/* 296 */       writeString("detail");
/* 297 */       writeObject(detail);
/*     */     }
/* 299 */     this.os.write(122);
/*     */   }
/*     */ 
/*     */   public void writeObject(Object object)
/*     */     throws IOException
/*     */   {
/* 308 */     if (object == null) {
/* 309 */       writeNull();
/* 310 */       return;
/*     */     }
/*     */ 
/* 315 */     Serializer serializer = this._serializerFactory.getSerializer(object.getClass());
/*     */ 
/* 317 */     serializer.writeObject(object, this);
/*     */   }
/*     */ 
/*     */   public boolean writeListBegin(int length, String type)
/*     */     throws IOException
/*     */   {
/* 334 */     this.os.write(86);
/*     */ 
/* 336 */     if (type != null) {
/* 337 */       this.os.write(116);
/* 338 */       printLenString(type);
/*     */     }
/*     */ 
/* 341 */     if (length >= 0) {
/* 342 */       this.os.write(108);
/* 343 */       this.os.write(length >> 24);
/* 344 */       this.os.write(length >> 16);
/* 345 */       this.os.write(length >> 8);
/* 346 */       this.os.write(length);
/*     */     }
/*     */ 
/* 349 */     return true;
/*     */   }
/*     */ 
/*     */   public void writeListEnd()
/*     */     throws IOException
/*     */   {
/* 358 */     this.os.write(122);
/*     */   }
/*     */ 
/*     */   public void writeMapBegin(String type)
/*     */     throws IOException
/*     */   {
/* 373 */     this.os.write(77);
/* 374 */     this.os.write(116);
/* 375 */     printLenString(type);
/*     */   }
/*     */ 
/*     */   public void writeMapEnd()
/*     */     throws IOException
/*     */   {
/* 384 */     this.os.write(122);
/*     */   }
/*     */ 
/*     */   public void writeRemote(String type, String url)
/*     */     throws IOException
/*     */   {
/* 398 */     this.os.write(114);
/* 399 */     this.os.write(116);
/* 400 */     printLenString(type);
/* 401 */     this.os.write(83);
/* 402 */     printLenString(url);
/*     */   }
/*     */ 
/*     */   public void writeBoolean(boolean value)
/*     */     throws IOException
/*     */   {
/* 419 */     if (value)
/* 420 */       this.os.write(84);
/*     */     else
/* 422 */       this.os.write(70);
/*     */   }
/*     */ 
/*     */   public void writeInt(int value)
/*     */     throws IOException
/*     */   {
/* 438 */     this.os.write(73);
/* 439 */     this.os.write(value >> 24);
/* 440 */     this.os.write(value >> 16);
/* 441 */     this.os.write(value >> 8);
/* 442 */     this.os.write(value);
/*     */   }
/*     */ 
/*     */   public void writeLong(long value)
/*     */     throws IOException
/*     */   {
/* 458 */     this.os.write(76);
/* 459 */     this.os.write((byte)(int)(value >> 56));
/* 460 */     this.os.write((byte)(int)(value >> 48));
/* 461 */     this.os.write((byte)(int)(value >> 40));
/* 462 */     this.os.write((byte)(int)(value >> 32));
/* 463 */     this.os.write((byte)(int)(value >> 24));
/* 464 */     this.os.write((byte)(int)(value >> 16));
/* 465 */     this.os.write((byte)(int)(value >> 8));
/* 466 */     this.os.write((byte)(int)value);
/*     */   }
/*     */ 
/*     */   public void writeDouble(double value)
/*     */     throws IOException
/*     */   {
/* 482 */     long bits = Double.doubleToLongBits(value);
/*     */ 
/* 484 */     this.os.write(68);
/* 485 */     this.os.write((byte)(int)(bits >> 56));
/* 486 */     this.os.write((byte)(int)(bits >> 48));
/* 487 */     this.os.write((byte)(int)(bits >> 40));
/* 488 */     this.os.write((byte)(int)(bits >> 32));
/* 489 */     this.os.write((byte)(int)(bits >> 24));
/* 490 */     this.os.write((byte)(int)(bits >> 16));
/* 491 */     this.os.write((byte)(int)(bits >> 8));
/* 492 */     this.os.write((byte)(int)bits);
/*     */   }
/*     */ 
/*     */   public void writeUTCDate(long time)
/*     */     throws IOException
/*     */   {
/* 507 */     this.os.write(100);
/* 508 */     this.os.write((byte)(int)(time >> 56));
/* 509 */     this.os.write((byte)(int)(time >> 48));
/* 510 */     this.os.write((byte)(int)(time >> 40));
/* 511 */     this.os.write((byte)(int)(time >> 32));
/* 512 */     this.os.write((byte)(int)(time >> 24));
/* 513 */     this.os.write((byte)(int)(time >> 16));
/* 514 */     this.os.write((byte)(int)(time >> 8));
/* 515 */     this.os.write((byte)(int)time);
/*     */   }
/*     */ 
/*     */   public void writeNull()
/*     */     throws IOException
/*     */   {
/* 531 */     this.os.write(78);
/*     */   }
/*     */ 
/*     */   public void writeString(String value)
/*     */     throws IOException
/*     */   {
/* 553 */     if (value == null) {
/* 554 */       this.os.write(78);
/*     */     }
/*     */     else {
/* 557 */       int length = value.length();
/* 558 */       int offset = 0;
/*     */ 
/* 560 */       while (length > 32768) {
/* 561 */         int sublen = 32768;
/*     */ 
/* 564 */         char tail = value.charAt(offset + sublen - 1);
/*     */ 
/* 566 */         if ((55296 <= tail) && (tail <= 56319)) {
/* 567 */           sublen--;
/*     */         }
/* 569 */         this.os.write(115);
/* 570 */         this.os.write(sublen >> 8);
/* 571 */         this.os.write(sublen);
/*     */ 
/* 573 */         printString(value, offset, sublen);
/*     */ 
/* 575 */         length -= sublen;
/* 576 */         offset += sublen;
/*     */       }
/*     */ 
/* 579 */       this.os.write(83);
/* 580 */       this.os.write(length >> 8);
/* 581 */       this.os.write(length);
/*     */ 
/* 583 */       printString(value, offset, length);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeString(char[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 606 */     if (buffer == null) {
/* 607 */       this.os.write(78);
/*     */     }
/*     */     else {
/* 610 */       while (length > 32768) {
/* 611 */         int sublen = 32768;
/*     */ 
/* 614 */         char tail = buffer[(offset + sublen - 1)];
/*     */ 
/* 616 */         if ((55296 <= tail) && (tail <= 56319)) {
/* 617 */           sublen--;
/*     */         }
/* 619 */         this.os.write(115);
/* 620 */         this.os.write(sublen >> 8);
/* 621 */         this.os.write(sublen);
/*     */ 
/* 623 */         printString(buffer, offset, sublen);
/*     */ 
/* 625 */         length -= sublen;
/* 626 */         offset += sublen;
/*     */       }
/*     */ 
/* 629 */       this.os.write(83);
/* 630 */       this.os.write(length >> 8);
/* 631 */       this.os.write(length);
/*     */ 
/* 633 */       printString(buffer, offset, length);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] buffer)
/*     */     throws IOException
/*     */   {
/* 656 */     if (buffer == null)
/* 657 */       this.os.write(78);
/*     */     else
/* 659 */       writeBytes(buffer, 0, buffer.length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 681 */     if (buffer == null) {
/* 682 */       this.os.write(78);
/*     */     }
/*     */     else {
/* 685 */       while (length > 32768) {
/* 686 */         int sublen = 32768;
/*     */ 
/* 688 */         this.os.write(98);
/* 689 */         this.os.write(sublen >> 8);
/* 690 */         this.os.write(sublen);
/*     */ 
/* 692 */         this.os.write(buffer, offset, sublen);
/*     */ 
/* 694 */         length -= sublen;
/* 695 */         offset += sublen;
/*     */       }
/*     */ 
/* 698 */       this.os.write(66);
/* 699 */       this.os.write(length >> 8);
/* 700 */       this.os.write(length);
/* 701 */       this.os.write(buffer, offset, length);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeByteBufferStart()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void writeByteBufferPart(byte[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 726 */     while (length > 0) {
/* 727 */       int sublen = length;
/*     */ 
/* 729 */       if (32768 < sublen) {
/* 730 */         sublen = 32768;
/*     */       }
/* 732 */       this.os.write(98);
/* 733 */       this.os.write(sublen >> 8);
/* 734 */       this.os.write(sublen);
/*     */ 
/* 736 */       this.os.write(buffer, offset, sublen);
/*     */ 
/* 738 */       length -= sublen;
/* 739 */       offset += sublen;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeByteBufferEnd(byte[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 753 */     writeBytes(buffer, offset, length);
/*     */   }
/*     */ 
/*     */   public void writeRef(int value)
/*     */     throws IOException
/*     */   {
/* 768 */     this.os.write(82);
/* 769 */     this.os.write(value >> 24);
/* 770 */     this.os.write(value >> 16);
/* 771 */     this.os.write(value >> 8);
/* 772 */     this.os.write(value);
/*     */   }
/*     */ 
/*     */   public void writePlaceholder()
/*     */     throws IOException
/*     */   {
/* 785 */     this.os.write(80);
/*     */   }
/*     */ 
/*     */   public boolean addRef(Object object)
/*     */     throws IOException
/*     */   {
/* 796 */     if (this._refs == null) {
/* 797 */       this._refs = new IdentityHashMap();
/*     */     }
/* 799 */     Integer ref = (Integer)this._refs.get(object);
/*     */ 
/* 801 */     if (ref != null) {
/* 802 */       int value = ref.intValue();
/*     */ 
/* 804 */       writeRef(value);
/* 805 */       return true;
/*     */     }
/*     */ 
/* 808 */     this._refs.put(object, new Integer(this._refs.size()));
/*     */ 
/* 810 */     return false;
/*     */   }
/*     */ 
/*     */   public void resetReferences()
/*     */   {
/* 819 */     if (this._refs != null)
/* 820 */       this._refs.clear();
/*     */   }
/*     */ 
/*     */   public boolean removeRef(Object obj)
/*     */     throws IOException
/*     */   {
/* 829 */     if (this._refs != null) {
/* 830 */       this._refs.remove(obj);
/*     */ 
/* 832 */       return true;
/*     */     }
/*     */ 
/* 835 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean replaceRef(Object oldRef, Object newRef)
/*     */     throws IOException
/*     */   {
/* 844 */     Integer value = (Integer)this._refs.remove(oldRef);
/*     */ 
/* 846 */     if (value != null) {
/* 847 */       this._refs.put(newRef, value);
/* 848 */       return true;
/*     */     }
/*     */ 
/* 851 */     return false;
/*     */   }
/*     */ 
/*     */   public void printLenString(String v)
/*     */     throws IOException
/*     */   {
/* 862 */     if (v == null) {
/* 863 */       this.os.write(0);
/* 864 */       this.os.write(0);
/*     */     }
/*     */     else {
/* 867 */       int len = v.length();
/* 868 */       this.os.write(len >> 8);
/* 869 */       this.os.write(len);
/*     */ 
/* 871 */       printString(v, 0, len);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void printString(String v)
/*     */     throws IOException
/*     */   {
/* 883 */     printString(v, 0, v.length());
/*     */   }
/*     */ 
/*     */   public void printString(String v, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 894 */     for (int i = 0; i < length; i++) {
/* 895 */       char ch = v.charAt(i + offset);
/*     */ 
/* 897 */       if (ch < '') {
/* 898 */         this.os.write(ch);
/* 899 */       } else if (ch < 'ࠀ') {
/* 900 */         this.os.write(192 + (ch >> '\006' & 0x1F));
/* 901 */         this.os.write('' + (ch & 0x3F));
/*     */       }
/*     */       else {
/* 904 */         this.os.write(224 + (ch >> '\f' & 0xF));
/* 905 */         this.os.write(128 + (ch >> '\006' & 0x3F));
/* 906 */         this.os.write('' + (ch & 0x3F));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void printString(char[] v, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 919 */     for (int i = 0; i < length; i++) {
/* 920 */       char ch = v[(i + offset)];
/*     */ 
/* 922 */       if (ch < '') {
/* 923 */         this.os.write(ch);
/* 924 */       } else if (ch < 'ࠀ') {
/* 925 */         this.os.write(192 + (ch >> '\006' & 0x1F));
/* 926 */         this.os.write('' + (ch & 0x3F));
/*     */       }
/*     */       else {
/* 929 */         this.os.write(224 + (ch >> '\f' & 0xF));
/* 930 */         this.os.write(128 + (ch >> '\006' & 0x3F));
/* 931 */         this.os.write('' + (ch & 0x3F));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 939 */     if (this.os != null)
/* 940 */       this.os.flush();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 946 */     if (this.os != null)
/* 947 */       this.os.flush();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianOutput
 * JD-Core Version:    0.6.2
 */