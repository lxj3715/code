/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class HessianProtocolException extends IOException
/*     */ {
/*     */   private Throwable rootCause;
/*     */ 
/*     */   public HessianProtocolException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public HessianProtocolException(String message)
/*     */   {
/*  72 */     super(message);
/*     */   }
/*     */ 
/*     */   public HessianProtocolException(String message, Throwable rootCause)
/*     */   {
/*  80 */     super(message);
/*     */ 
/*  82 */     this.rootCause = rootCause;
/*     */   }
/*     */ 
/*     */   public HessianProtocolException(Throwable rootCause)
/*     */   {
/*  90 */     super(String.valueOf(rootCause));
/*     */ 
/*  92 */     this.rootCause = rootCause;
/*     */   }
/*     */ 
/*     */   public Throwable getRootCause()
/*     */   {
/* 100 */     return this.rootCause;
/*     */   }
/*     */ 
/*     */   public Throwable getCause()
/*     */   {
/* 108 */     return getRootCause();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianProtocolException
 * JD-Core Version:    0.6.2
 */