/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ public class HessianRemote
/*     */ {
/*     */   private String type;
/*     */   private String url;
/*     */ 
/*     */   public HessianRemote(String type, String url)
/*     */   {
/*  67 */     this.type = type;
/*  68 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public HessianRemote()
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  83 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getURL()
/*     */   {
/*  91 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setURL(String url)
/*     */   {
/*  99 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 107 */     return this.url.hashCode();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 115 */     if (!(obj instanceof HessianRemote)) {
/* 116 */       return false;
/*     */     }
/* 118 */     HessianRemote remote = (HessianRemote)obj;
/*     */ 
/* 120 */     return this.url.equals(remote.url);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 128 */     return "[HessianRemote " + this.url + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianRemote
 * JD-Core Version:    0.6.2
 */