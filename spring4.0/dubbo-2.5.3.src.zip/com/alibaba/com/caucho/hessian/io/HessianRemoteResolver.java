package com.alibaba.com.caucho.hessian.io;

import java.io.IOException;

public abstract interface HessianRemoteResolver
{
  public abstract Object lookup(String paramString1, String paramString2)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianRemoteResolver
 * JD-Core Version:    0.6.2
 */