/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ public class HessianSerializerOutput extends HessianOutput
/*     */ {
/*     */   public HessianSerializerOutput(OutputStream os)
/*     */   {
/*  94 */     super(os);
/*     */   }
/*     */ 
/*     */   public HessianSerializerOutput()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void writeObjectImpl(Object obj)
/*     */     throws IOException
/*     */   {
/* 112 */     Class cl = obj.getClass();
/*     */     try
/*     */     {
/* 115 */       Method method = cl.getMethod("writeReplace", new Class[0]);
/* 116 */       Object repl = method.invoke(obj, new Object[0]);
/*     */ 
/* 118 */       writeObject(repl);
/* 119 */       return;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       try {
/* 124 */         writeMapBegin(cl.getName());
/* 125 */         for (; cl != null; cl = cl.getSuperclass()) {
/* 126 */           Field[] fields = cl.getDeclaredFields();
/* 127 */           for (int i = 0; i < fields.length; i++) {
/* 128 */             Field field = fields[i];
/*     */ 
/* 130 */             if ((!Modifier.isTransient(field.getModifiers())) && (!Modifier.isStatic(field.getModifiers())))
/*     */             {
/* 135 */               field.setAccessible(true);
/*     */ 
/* 137 */               writeString(field.getName());
/* 138 */               writeObject(field.get(obj));
/*     */             }
/*     */           }
/*     */         }
/* 141 */         writeMapEnd();
/*     */       } catch (IllegalAccessException e) {
/* 143 */         throw new IOExceptionWrapper(e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianSerializerOutput
 * JD-Core Version:    0.6.2
 */