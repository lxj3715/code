/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ public class HessianServiceException extends Exception
/*    */ {
/*    */   private String code;
/*    */   private Object detail;
/*    */ 
/*    */   public HessianServiceException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public HessianServiceException(String message, String code, Object detail)
/*    */   {
/* 71 */     super(message);
/* 72 */     this.code = code;
/* 73 */     this.detail = detail;
/*    */   }
/*    */ 
/*    */   public String getCode()
/*    */   {
/* 81 */     return this.code;
/*    */   }
/*    */ 
/*    */   public Object getDetail()
/*    */   {
/* 89 */     return this.detail;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.HessianServiceException
 * JD-Core Version:    0.6.2
 */