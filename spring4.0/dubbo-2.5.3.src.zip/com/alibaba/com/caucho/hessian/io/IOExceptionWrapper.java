/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class IOExceptionWrapper extends IOException
/*    */ {
/*    */   private Throwable _cause;
/*    */ 
/*    */   public IOExceptionWrapper(Throwable cause)
/*    */   {
/* 61 */     super(cause.toString());
/*    */ 
/* 63 */     this._cause = cause;
/*    */   }
/*    */ 
/*    */   public IOExceptionWrapper(String msg, Throwable cause)
/*    */   {
/* 68 */     super(msg);
/*    */ 
/* 70 */     this._cause = cause;
/*    */   }
/*    */ 
/*    */   public Throwable getCause()
/*    */   {
/* 75 */     return this._cause;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.IOExceptionWrapper
 * JD-Core Version:    0.6.2
 */