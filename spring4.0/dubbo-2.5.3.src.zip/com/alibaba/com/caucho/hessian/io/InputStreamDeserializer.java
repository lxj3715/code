/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class InputStreamDeserializer extends AbstractDeserializer
/*    */ {
/*    */   public Object readObject(AbstractHessianInput in)
/*    */     throws IOException
/*    */   {
/* 65 */     return in.readInputStream();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.InputStreamDeserializer
 * JD-Core Version:    0.6.2
 */