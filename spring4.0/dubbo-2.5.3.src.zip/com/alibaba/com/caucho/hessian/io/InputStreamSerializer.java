/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class InputStreamSerializer extends AbstractSerializer
/*    */ {
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 65 */     InputStream is = (InputStream)obj;
/*    */ 
/* 67 */     if (is == null) {
/* 68 */       out.writeNull();
/*    */     } else {
/* 70 */       byte[] buf = new byte[1024];
/*    */       int len;
/* 73 */       while ((len = is.read(buf, 0, buf.length)) > 0) {
/* 74 */         out.writeByteBufferPart(buf, 0, len);
/*    */       }
/*    */ 
/* 77 */       out.writeByteBufferEnd(buf, 0, 0);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.InputStreamSerializer
 * JD-Core Version:    0.6.2
 */