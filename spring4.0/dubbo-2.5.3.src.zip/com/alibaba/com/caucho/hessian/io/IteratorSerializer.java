/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class IteratorSerializer extends AbstractSerializer
/*    */ {
/*    */   private static IteratorSerializer _serializer;
/*    */ 
/*    */   public static IteratorSerializer create()
/*    */   {
/* 62 */     if (_serializer == null) {
/* 63 */       _serializer = new IteratorSerializer();
/*    */     }
/* 65 */     return _serializer;
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 71 */     Iterator iter = (Iterator)obj;
/*    */ 
/* 73 */     boolean hasEnd = out.writeListBegin(-1, null);
/*    */ 
/* 75 */     while (iter.hasNext()) {
/* 76 */       Object value = iter.next();
/*    */ 
/* 78 */       out.writeObject(value);
/*    */     }
/*    */ 
/* 81 */     if (hasEnd)
/* 82 */       out.writeListEnd();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.IteratorSerializer
 * JD-Core Version:    0.6.2
 */