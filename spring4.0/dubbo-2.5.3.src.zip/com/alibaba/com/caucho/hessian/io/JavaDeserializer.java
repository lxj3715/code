/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class JavaDeserializer extends AbstractMapDeserializer
/*     */ {
/*  65 */   private static final Logger log = Logger.getLogger(JavaDeserializer.class.getName());
/*     */   private Class _type;
/*     */   private HashMap _fieldMap;
/*     */   private Method _readResolve;
/*     */   private Constructor _constructor;
/*     */   private Object[] _constructorArgs;
/*     */ 
/*     */   public JavaDeserializer(Class cl)
/*     */   {
/*  76 */     this._type = cl;
/*  77 */     this._fieldMap = getFieldMap(cl);
/*     */ 
/*  79 */     this._readResolve = getReadResolve(cl);
/*     */ 
/*  81 */     if (this._readResolve != null) {
/*  82 */       this._readResolve.setAccessible(true);
/*     */     }
/*     */ 
/*  85 */     Constructor[] constructors = cl.getDeclaredConstructors();
/*  86 */     long bestCost = 9223372036854775807L;
/*     */ 
/*  88 */     for (int i = 0; i < constructors.length; i++) {
/*  89 */       Class[] param = constructors[i].getParameterTypes();
/*  90 */       long cost = 0L;
/*     */ 
/*  92 */       for (int j = 0; j < param.length; j++) {
/*  93 */         cost = 4L * cost;
/*     */ 
/*  95 */         if (Object.class.equals(param[j]))
/*  96 */           cost += 1L;
/*  97 */         else if (String.class.equals(param[j]))
/*  98 */           cost += 2L;
/*  99 */         else if (Integer.TYPE.equals(param[j]))
/* 100 */           cost += 3L;
/* 101 */         else if (Long.TYPE.equals(param[j]))
/* 102 */           cost += 4L;
/* 103 */         else if (param[j].isPrimitive())
/* 104 */           cost += 5L;
/*     */         else {
/* 106 */           cost += 6L;
/*     */         }
/*     */       }
/* 109 */       if ((cost < 0L) || (cost > 65536L)) {
/* 110 */         cost = 65536L;
/*     */       }
/* 112 */       cost += (param.length << 48);
/*     */ 
/* 114 */       if (cost < bestCost) {
/* 115 */         this._constructor = constructors[i];
/* 116 */         bestCost = cost;
/*     */       }
/*     */     }
/*     */ 
/* 120 */     if (this._constructor != null) {
/* 121 */       this._constructor.setAccessible(true);
/* 122 */       Class[] params = this._constructor.getParameterTypes();
/* 123 */       this._constructorArgs = new Object[params.length];
/* 124 */       for (int i = 0; i < params.length; i++)
/* 125 */         this._constructorArgs[i] = getParamArg(params[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/* 132 */     return this._type;
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 139 */       Object obj = instantiate();
/*     */ 
/* 141 */       return readMap(in, obj);
/*     */     } catch (IOException e) {
/* 143 */       throw e;
/*     */     } catch (RuntimeException e) {
/* 145 */       throw e;
/*     */     } catch (Exception e) {
/* 147 */       throw new IOExceptionWrapper(this._type.getName() + ":" + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, String[] fieldNames) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 155 */       Object obj = instantiate();
/*     */ 
/* 157 */       return readObject(in, obj, fieldNames);
/*     */     } catch (IOException e) {
/* 159 */       throw e;
/*     */     } catch (RuntimeException e) {
/* 161 */       throw e;
/*     */     } catch (Exception e) {
/* 163 */       throw new IOExceptionWrapper(this._type.getName() + ":" + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Method getReadResolve(Class cl)
/*     */   {
/* 172 */     for (; cl != null; cl = cl.getSuperclass()) {
/* 173 */       Method[] methods = cl.getDeclaredMethods();
/*     */ 
/* 175 */       for (int i = 0; i < methods.length; i++) {
/* 176 */         Method method = methods[i];
/*     */ 
/* 178 */         if ((method.getName().equals("readResolve")) && (method.getParameterTypes().length == 0))
/*     */         {
/* 180 */           return method;
/*     */         }
/*     */       }
/*     */     }
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in, Object obj) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 191 */       int ref = in.addRef(obj);
/*     */ 
/* 193 */       while (!in.isEnd()) {
/* 194 */         Object key = in.readObject();
/*     */ 
/* 196 */         FieldDeserializer deser = (FieldDeserializer)this._fieldMap.get(key);
/*     */ 
/* 198 */         if (deser != null)
/* 199 */           deser.deserialize(in, obj);
/*     */         else {
/* 201 */           in.readObject();
/*     */         }
/*     */       }
/* 204 */       in.readMapEnd();
/*     */ 
/* 206 */       Object resolve = resolve(obj);
/*     */ 
/* 208 */       if (obj != resolve) {
/* 209 */         in.setRef(ref, resolve);
/*     */       }
/* 211 */       return resolve;
/*     */     } catch (IOException e) {
/* 213 */       throw e;
/*     */     } catch (Exception e) {
/* 215 */       throw new IOExceptionWrapper(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, Object obj, String[] fieldNames)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 225 */       int ref = in.addRef(obj);
/*     */ 
/* 227 */       for (int i = 0; i < fieldNames.length; i++) {
/* 228 */         String name = fieldNames[i];
/*     */ 
/* 230 */         FieldDeserializer deser = (FieldDeserializer)this._fieldMap.get(name);
/*     */ 
/* 232 */         if (deser != null)
/* 233 */           deser.deserialize(in, obj);
/*     */         else {
/* 235 */           in.readObject();
/*     */         }
/*     */       }
/* 238 */       Object resolve = resolve(obj);
/*     */ 
/* 240 */       if (obj != resolve) {
/* 241 */         in.setRef(ref, resolve);
/*     */       }
/* 243 */       return resolve;
/*     */     } catch (IOException e) {
/* 245 */       throw e;
/*     */     } catch (Exception e) {
/* 247 */       throw new IOExceptionWrapper(obj.getClass().getName() + ":" + e, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object resolve(Object obj)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 256 */       if (this._readResolve != null)
/* 257 */         return this._readResolve.invoke(obj, new Object[0]);
/*     */     } catch (InvocationTargetException e) {
/* 259 */       if (e.getTargetException() != null) {
/* 260 */         throw e;
/*     */       }
/*     */     }
/* 263 */     return obj;
/*     */   }
/*     */ 
/*     */   protected Object instantiate() throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 270 */       if (this._constructor != null) {
/* 271 */         return this._constructor.newInstance(this._constructorArgs);
/*     */       }
/* 273 */       return this._type.newInstance();
/*     */     } catch (Exception e) {
/* 275 */       throw new HessianProtocolException("'" + this._type.getName() + "' could not be instantiated", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected HashMap getFieldMap(Class cl)
/*     */   {
/* 284 */     HashMap fieldMap = new HashMap();
/*     */ 
/* 286 */     for (; cl != null; cl = cl.getSuperclass()) {
/* 287 */       Field[] fields = cl.getDeclaredFields();
/* 288 */       for (int i = 0; i < fields.length; i++) {
/* 289 */         Field field = fields[i];
/*     */ 
/* 291 */         if ((!Modifier.isTransient(field.getModifiers())) && (!Modifier.isStatic(field.getModifiers())))
/*     */         {
/* 294 */           if (fieldMap.get(field.getName()) == null)
/*     */           {
/*     */             try
/*     */             {
/* 299 */               field.setAccessible(true);
/*     */             } catch (Throwable e) {
/* 301 */               e.printStackTrace();
/*     */             }
/*     */ 
/* 304 */             Class type = field.getType();
/*     */             FieldDeserializer deser;
/*     */             FieldDeserializer deser;
/* 307 */             if (String.class.equals(type)) {
/* 308 */               deser = new StringFieldDeserializer(field);
/*     */             }
/*     */             else
/*     */             {
/*     */               FieldDeserializer deser;
/* 309 */               if (Byte.TYPE.equals(type)) {
/* 310 */                 deser = new ByteFieldDeserializer(field);
/*     */               }
/*     */               else
/*     */               {
/*     */                 FieldDeserializer deser;
/* 312 */                 if (Short.TYPE.equals(type)) {
/* 313 */                   deser = new ShortFieldDeserializer(field);
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   FieldDeserializer deser;
/* 315 */                   if (Integer.TYPE.equals(type)) {
/* 316 */                     deser = new IntFieldDeserializer(field);
/*     */                   }
/*     */                   else
/*     */                   {
/*     */                     FieldDeserializer deser;
/* 318 */                     if (Long.TYPE.equals(type)) {
/* 319 */                       deser = new LongFieldDeserializer(field);
/*     */                     }
/*     */                     else
/*     */                     {
/*     */                       FieldDeserializer deser;
/* 321 */                       if (Float.TYPE.equals(type)) {
/* 322 */                         deser = new FloatFieldDeserializer(field);
/*     */                       }
/*     */                       else
/*     */                       {
/*     */                         FieldDeserializer deser;
/* 324 */                         if (Double.TYPE.equals(type)) {
/* 325 */                           deser = new DoubleFieldDeserializer(field);
/*     */                         }
/*     */                         else
/*     */                         {
/*     */                           FieldDeserializer deser;
/* 327 */                           if (Boolean.TYPE.equals(type)) {
/* 328 */                             deser = new BooleanFieldDeserializer(field);
/*     */                           }
/*     */                           else
/*     */                           {
/*     */                             FieldDeserializer deser;
/* 330 */                             if (java.sql.Date.class.equals(type)) {
/* 331 */                               deser = new SqlDateFieldDeserializer(field);
/*     */                             }
/*     */                             else
/*     */                             {
/*     */                               FieldDeserializer deser;
/* 333 */                               if (Timestamp.class.equals(type)) {
/* 334 */                                 deser = new SqlTimestampFieldDeserializer(field);
/*     */                               }
/*     */                               else
/*     */                               {
/*     */                                 FieldDeserializer deser;
/* 336 */                                 if (Time.class.equals(type)) {
/* 337 */                                   deser = new SqlTimeFieldDeserializer(field);
/*     */                                 }
/*     */                                 else
/* 340 */                                   deser = new ObjectFieldDeserializer(field); 
/*     */                               }
/*     */                             }
/*     */                           }
/*     */                         }
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/* 343 */             fieldMap.put(field.getName(), deser);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 347 */     return fieldMap;
/*     */   }
/*     */ 
/*     */   protected static Object getParamArg(Class cl)
/*     */   {
/* 355 */     if (!cl.isPrimitive())
/* 356 */       return null;
/* 357 */     if (Boolean.TYPE.equals(cl))
/* 358 */       return Boolean.FALSE;
/* 359 */     if (Byte.TYPE.equals(cl))
/* 360 */       return new Byte((byte)0);
/* 361 */     if (Short.TYPE.equals(cl))
/* 362 */       return new Short((short)0);
/* 363 */     if (Character.TYPE.equals(cl))
/* 364 */       return new Character('\000');
/* 365 */     if (Integer.TYPE.equals(cl))
/* 366 */       return Integer.valueOf(0);
/* 367 */     if (Long.TYPE.equals(cl))
/* 368 */       return Long.valueOf(0L);
/* 369 */     if (Float.TYPE.equals(cl))
/* 370 */       return Float.valueOf(0.0F);
/* 371 */     if (Double.TYPE.equals(cl)) {
/* 372 */       return Double.valueOf(0.0D);
/*     */     }
/* 374 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   static void logDeserializeError(Field field, Object obj, Object value, Throwable e)
/*     */     throws IOException
/*     */   {
/* 665 */     String fieldName = field.getDeclaringClass().getName() + "." + field.getName();
/*     */ 
/* 668 */     if ((e instanceof HessianFieldException))
/* 669 */       throw ((HessianFieldException)e);
/* 670 */     if ((e instanceof IOException)) {
/* 671 */       throw new HessianFieldException(fieldName + ": " + e.getMessage(), e);
/*     */     }
/* 673 */     if (value != null) {
/* 674 */       throw new HessianFieldException(fieldName + ": " + value.getClass().getName() + " (" + value + ")" + " cannot be assigned to '" + field.getType().getName() + "'", e);
/*     */     }
/*     */ 
/* 677 */     throw new HessianFieldException(fieldName + ": " + field.getType().getName() + " cannot be assigned from null", e);
/*     */   }
/*     */ 
/*     */   static class SqlTimeFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     SqlTimeFieldDeserializer(Field field)
/*     */     {
/* 642 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 648 */       Time value = null;
/*     */       try
/*     */       {
/* 651 */         java.util.Date date = (java.util.Date)in.readObject();
/* 652 */         value = new Time(date.getTime());
/*     */ 
/* 654 */         this._field.set(obj, value);
/*     */       } catch (Exception e) {
/* 656 */         JavaDeserializer.logDeserializeError(this._field, obj, value, e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class SqlTimestampFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     SqlTimestampFieldDeserializer(Field field)
/*     */     {
/* 618 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 624 */       Timestamp value = null;
/*     */       try
/*     */       {
/* 627 */         java.util.Date date = (java.util.Date)in.readObject();
/* 628 */         if (date != null) value = new Timestamp(date.getTime());
/*     */ 
/* 630 */         this._field.set(obj, value);
/*     */       } catch (Exception e) {
/* 632 */         JavaDeserializer.logDeserializeError(this._field, obj, value, e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class SqlDateFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     SqlDateFieldDeserializer(Field field)
/*     */     {
/* 594 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 600 */       java.sql.Date value = null;
/*     */       try
/*     */       {
/* 603 */         java.util.Date date = (java.util.Date)in.readObject();
/* 604 */         value = new java.sql.Date(date.getTime());
/*     */ 
/* 606 */         this._field.set(obj, value);
/*     */       } catch (Exception e) {
/* 608 */         JavaDeserializer.logDeserializeError(this._field, obj, value, e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class StringFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     StringFieldDeserializer(Field field)
/*     */     {
/* 571 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 577 */       String value = null;
/*     */       try
/*     */       {
/* 580 */         value = in.readString();
/*     */ 
/* 582 */         this._field.set(obj, value);
/*     */       } catch (Exception e) {
/* 584 */         JavaDeserializer.logDeserializeError(this._field, obj, value, e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class DoubleFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     DoubleFieldDeserializer(Field field)
/*     */     {
/* 548 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 554 */       double value = 0.0D;
/*     */       try
/*     */       {
/* 557 */         value = in.readDouble();
/*     */ 
/* 559 */         this._field.setDouble(obj, value);
/*     */       } catch (Exception e) {
/* 561 */         JavaDeserializer.logDeserializeError(this._field, obj, Double.valueOf(value), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class FloatFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     FloatFieldDeserializer(Field field)
/*     */     {
/* 525 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 531 */       double value = 0.0D;
/*     */       try
/*     */       {
/* 534 */         value = in.readDouble();
/*     */ 
/* 536 */         this._field.setFloat(obj, (float)value);
/*     */       } catch (Exception e) {
/* 538 */         JavaDeserializer.logDeserializeError(this._field, obj, Double.valueOf(value), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class LongFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     LongFieldDeserializer(Field field)
/*     */     {
/* 502 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 508 */       long value = 0L;
/*     */       try
/*     */       {
/* 511 */         value = in.readLong();
/*     */ 
/* 513 */         this._field.setLong(obj, value);
/*     */       } catch (Exception e) {
/* 515 */         JavaDeserializer.logDeserializeError(this._field, obj, Long.valueOf(value), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class IntFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     IntFieldDeserializer(Field field)
/*     */     {
/* 479 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 485 */       int value = 0;
/*     */       try
/*     */       {
/* 488 */         value = in.readInt();
/*     */ 
/* 490 */         this._field.setInt(obj, value);
/*     */       } catch (Exception e) {
/* 492 */         JavaDeserializer.logDeserializeError(this._field, obj, Integer.valueOf(value), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ShortFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     ShortFieldDeserializer(Field field)
/*     */     {
/* 456 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 462 */       int value = 0;
/*     */       try
/*     */       {
/* 465 */         value = in.readInt();
/*     */ 
/* 467 */         this._field.setShort(obj, (short)value);
/*     */       } catch (Exception e) {
/* 469 */         JavaDeserializer.logDeserializeError(this._field, obj, Integer.valueOf(value), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ByteFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     ByteFieldDeserializer(Field field)
/*     */     {
/* 433 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 439 */       int value = 0;
/*     */       try
/*     */       {
/* 442 */         value = in.readInt();
/*     */ 
/* 444 */         this._field.setByte(obj, (byte)value);
/*     */       } catch (Exception e) {
/* 446 */         JavaDeserializer.logDeserializeError(this._field, obj, Integer.valueOf(value), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class BooleanFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     BooleanFieldDeserializer(Field field)
/*     */     {
/* 410 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 416 */       boolean value = false;
/*     */       try
/*     */       {
/* 419 */         value = in.readBoolean();
/*     */ 
/* 421 */         this._field.setBoolean(obj, value);
/*     */       } catch (Exception e) {
/* 423 */         JavaDeserializer.logDeserializeError(this._field, obj, Boolean.valueOf(value), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ObjectFieldDeserializer extends JavaDeserializer.FieldDeserializer
/*     */   {
/*     */     private final Field _field;
/*     */ 
/*     */     ObjectFieldDeserializer(Field field)
/*     */     {
/* 387 */       this._field = field;
/*     */     }
/*     */ 
/*     */     void deserialize(AbstractHessianInput in, Object obj)
/*     */       throws IOException
/*     */     {
/* 393 */       Object value = null;
/*     */       try
/*     */       {
/* 396 */         value = in.readObject(this._field.getType());
/*     */ 
/* 398 */         this._field.set(obj, value);
/*     */       } catch (Exception e) {
/* 400 */         JavaDeserializer.logDeserializeError(this._field, obj, value, e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract class FieldDeserializer
/*     */   {
/*     */     abstract void deserialize(AbstractHessianInput paramAbstractHessianInput, Object paramObject)
/*     */       throws IOException;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.JavaDeserializer
 * JD-Core Version:    0.6.2
 */