/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class JavaSerializer extends AbstractSerializer
/*     */ {
/*  65 */   private static final Logger log = Logger.getLogger(JavaSerializer.class.getName());
/*     */ 
/*  68 */   private static Object[] NULL_ARGS = new Object[0];
/*     */   private Field[] _fields;
/*     */   private FieldSerializer[] _fieldSerializers;
/*     */   private Object _writeReplaceFactory;
/*     */   private Method _writeReplace;
/*     */ 
/*     */   public JavaSerializer(Class cl, ClassLoader loader)
/*     */   {
/*  78 */     introspectWriteReplace(cl, loader);
/*     */ 
/*  80 */     if (this._writeReplace != null) {
/*  81 */       this._writeReplace.setAccessible(true);
/*     */     }
/*  83 */     ArrayList primitiveFields = new ArrayList();
/*  84 */     ArrayList compoundFields = new ArrayList();
/*     */ 
/*  86 */     for (; cl != null; cl = cl.getSuperclass()) {
/*  87 */       Field[] fields = cl.getDeclaredFields();
/*  88 */       for (int i = 0; i < fields.length; i++) {
/*  89 */         Field field = fields[i];
/*     */ 
/*  91 */         if ((!Modifier.isTransient(field.getModifiers())) && (!Modifier.isStatic(field.getModifiers())))
/*     */         {
/*  96 */           field.setAccessible(true);
/*     */ 
/*  98 */           if ((field.getType().isPrimitive()) || ((field.getType().getName().startsWith("java.lang.")) && (!field.getType().equals(Object.class))))
/*     */           {
/* 101 */             primitiveFields.add(field);
/*     */           }
/* 103 */           else compoundFields.add(field);
/*     */         }
/*     */       }
/*     */     }
/* 107 */     ArrayList fields = new ArrayList();
/* 108 */     fields.addAll(primitiveFields);
/* 109 */     fields.addAll(compoundFields);
/*     */ 
/* 111 */     this._fields = new Field[fields.size()];
/* 112 */     fields.toArray(this._fields);
/*     */ 
/* 114 */     this._fieldSerializers = new FieldSerializer[this._fields.length];
/*     */ 
/* 116 */     for (int i = 0; i < this._fields.length; i++)
/* 117 */       this._fieldSerializers[i] = getFieldSerializer(this._fields[i].getType());
/*     */   }
/*     */ 
/*     */   private void introspectWriteReplace(Class cl, ClassLoader loader)
/*     */   {
/*     */     try
/*     */     {
/* 124 */       String className = cl.getName() + "HessianSerializer";
/*     */ 
/* 126 */       Class serializerClass = Class.forName(className, false, loader);
/*     */ 
/* 128 */       Object serializerObject = serializerClass.newInstance();
/*     */ 
/* 130 */       Method writeReplace = getWriteReplace(serializerClass, cl);
/*     */ 
/* 132 */       if (writeReplace != null) {
/* 133 */         this._writeReplaceFactory = serializerObject;
/* 134 */         this._writeReplace = writeReplace;
/*     */ 
/* 136 */         return;
/*     */       }
/*     */     } catch (ClassNotFoundException e) {
/*     */     } catch (Exception e) {
/* 140 */       log.log(Level.FINER, e.toString(), e);
/*     */     }
/*     */ 
/* 143 */     this._writeReplace = getWriteReplace(cl);
/*     */   }
/*     */ 
/*     */   protected static Method getWriteReplace(Class cl)
/*     */   {
/* 151 */     for (; cl != null; cl = cl.getSuperclass()) {
/* 152 */       Method[] methods = cl.getDeclaredMethods();
/*     */ 
/* 154 */       for (int i = 0; i < methods.length; i++) {
/* 155 */         Method method = methods[i];
/*     */ 
/* 157 */         if ((method.getName().equals("writeReplace")) && (method.getParameterTypes().length == 0))
/*     */         {
/* 159 */           return method;
/*     */         }
/*     */       }
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   protected Method getWriteReplace(Class cl, Class param)
/*     */   {
/* 171 */     for (; cl != null; cl = cl.getSuperclass()) {
/* 172 */       for (Method method : cl.getDeclaredMethods()) {
/* 173 */         if ((method.getName().equals("writeReplace")) && (method.getParameterTypes().length == 1) && (param.equals(method.getParameterTypes()[0])))
/*     */         {
/* 176 */           return method;
/*     */         }
/*     */       }
/*     */     }
/* 180 */     return null;
/*     */   }
/*     */ 
/*     */   public void writeObject(Object obj, AbstractHessianOutput out)
/*     */     throws IOException
/*     */   {
/* 186 */     if (out.addRef(obj)) {
/* 187 */       return;
/*     */     }
/*     */ 
/* 190 */     Class cl = obj.getClass();
/*     */     try
/*     */     {
/* 193 */       if (this._writeReplace != null)
/*     */       {
/*     */         Object repl;
/*     */         Object repl;
/* 196 */         if (this._writeReplaceFactory != null)
/* 197 */           repl = this._writeReplace.invoke(this._writeReplaceFactory, new Object[] { obj });
/*     */         else {
/* 199 */           repl = this._writeReplace.invoke(obj, new Object[0]);
/*     */         }
/* 201 */         out.removeRef(obj);
/*     */ 
/* 203 */         out.writeObject(repl);
/*     */ 
/* 205 */         out.replaceRef(repl, obj);
/*     */ 
/* 207 */         return;
/*     */       }
/*     */     } catch (RuntimeException e) {
/* 210 */       throw e;
/*     */     }
/*     */     catch (Exception e) {
/* 213 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/* 216 */     int ref = out.writeObjectBegin(cl.getName());
/*     */ 
/* 218 */     if (ref < -1) {
/* 219 */       writeObject10(obj, out);
/*     */     }
/*     */     else {
/* 222 */       if (ref == -1) {
/* 223 */         writeDefinition20(out);
/* 224 */         out.writeObjectBegin(cl.getName());
/*     */       }
/*     */ 
/* 227 */       writeInstance(obj, out);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeObject10(Object obj, AbstractHessianOutput out)
/*     */     throws IOException
/*     */   {
/* 234 */     for (int i = 0; i < this._fields.length; i++) {
/* 235 */       Field field = this._fields[i];
/*     */ 
/* 237 */       out.writeString(field.getName());
/*     */ 
/* 239 */       this._fieldSerializers[i].serialize(out, obj, field);
/*     */     }
/*     */ 
/* 242 */     out.writeMapEnd();
/*     */   }
/*     */ 
/*     */   private void writeDefinition20(AbstractHessianOutput out)
/*     */     throws IOException
/*     */   {
/* 248 */     out.writeClassFieldLength(this._fields.length);
/*     */ 
/* 250 */     for (int i = 0; i < this._fields.length; i++) {
/* 251 */       Field field = this._fields[i];
/*     */ 
/* 253 */       out.writeString(field.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeInstance(Object obj, AbstractHessianOutput out)
/*     */     throws IOException
/*     */   {
/* 260 */     for (int i = 0; i < this._fields.length; i++) {
/* 261 */       Field field = this._fields[i];
/*     */ 
/* 263 */       this._fieldSerializers[i].serialize(out, obj, field);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static FieldSerializer getFieldSerializer(Class type)
/*     */   {
/* 269 */     if ((Integer.TYPE.equals(type)) || (Byte.TYPE.equals(type)) || (Short.TYPE.equals(type)) || (Integer.TYPE.equals(type)))
/*     */     {
/* 273 */       return IntFieldSerializer.SER;
/*     */     }
/* 275 */     if (Long.TYPE.equals(type)) {
/* 276 */       return LongFieldSerializer.SER;
/*     */     }
/* 278 */     if ((Double.TYPE.equals(type)) || (Float.TYPE.equals(type)))
/*     */     {
/* 280 */       return DoubleFieldSerializer.SER;
/*     */     }
/* 282 */     if (Boolean.TYPE.equals(type)) {
/* 283 */       return BooleanFieldSerializer.SER;
/*     */     }
/* 285 */     if (String.class.equals(type)) {
/* 286 */       return StringFieldSerializer.SER;
/*     */     }
/* 288 */     if ((java.util.Date.class.equals(type)) || (java.sql.Date.class.equals(type)) || (Timestamp.class.equals(type)) || (Time.class.equals(type)))
/*     */     {
/* 292 */       return DateFieldSerializer.SER;
/*     */     }
/*     */ 
/* 295 */     return FieldSerializer.SER;
/*     */   }
/*     */ 
/*     */   static class DateFieldSerializer extends JavaSerializer.FieldSerializer
/*     */   {
/* 415 */     static final JavaSerializer.FieldSerializer SER = new DateFieldSerializer();
/*     */ 
/*     */     void serialize(AbstractHessianOutput out, Object obj, Field field)
/*     */       throws IOException
/*     */     {
/* 420 */       java.util.Date value = null;
/*     */       try
/*     */       {
/* 423 */         value = (java.util.Date)field.get(obj);
/*     */       } catch (IllegalAccessException e) {
/* 425 */         JavaSerializer.log.log(Level.FINE, e.toString(), e);
/*     */       }
/*     */ 
/* 428 */       if (value == null)
/* 429 */         out.writeNull();
/*     */       else
/* 431 */         out.writeUTCDate(value.getTime());
/*     */     }
/*     */   }
/*     */ 
/*     */   static class StringFieldSerializer extends JavaSerializer.FieldSerializer
/*     */   {
/* 397 */     static final JavaSerializer.FieldSerializer SER = new StringFieldSerializer();
/*     */ 
/*     */     void serialize(AbstractHessianOutput out, Object obj, Field field)
/*     */       throws IOException
/*     */     {
/* 402 */       String value = null;
/*     */       try
/*     */       {
/* 405 */         value = (String)field.get(obj);
/*     */       } catch (IllegalAccessException e) {
/* 407 */         JavaSerializer.log.log(Level.FINE, e.toString(), e);
/*     */       }
/*     */ 
/* 410 */       out.writeString(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class DoubleFieldSerializer extends JavaSerializer.FieldSerializer
/*     */   {
/* 379 */     static final JavaSerializer.FieldSerializer SER = new DoubleFieldSerializer();
/*     */ 
/*     */     void serialize(AbstractHessianOutput out, Object obj, Field field)
/*     */       throws IOException
/*     */     {
/* 384 */       double value = 0.0D;
/*     */       try
/*     */       {
/* 387 */         value = field.getDouble(obj);
/*     */       } catch (IllegalAccessException e) {
/* 389 */         JavaSerializer.log.log(Level.FINE, e.toString(), e);
/*     */       }
/*     */ 
/* 392 */       out.writeDouble(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class LongFieldSerializer extends JavaSerializer.FieldSerializer
/*     */   {
/* 361 */     static final JavaSerializer.FieldSerializer SER = new LongFieldSerializer();
/*     */ 
/*     */     void serialize(AbstractHessianOutput out, Object obj, Field field)
/*     */       throws IOException
/*     */     {
/* 366 */       long value = 0L;
/*     */       try
/*     */       {
/* 369 */         value = field.getLong(obj);
/*     */       } catch (IllegalAccessException e) {
/* 371 */         JavaSerializer.log.log(Level.FINE, e.toString(), e);
/*     */       }
/*     */ 
/* 374 */       out.writeLong(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class IntFieldSerializer extends JavaSerializer.FieldSerializer
/*     */   {
/* 343 */     static final JavaSerializer.FieldSerializer SER = new IntFieldSerializer();
/*     */ 
/*     */     void serialize(AbstractHessianOutput out, Object obj, Field field)
/*     */       throws IOException
/*     */     {
/* 348 */       int value = 0;
/*     */       try
/*     */       {
/* 351 */         value = field.getInt(obj);
/*     */       } catch (IllegalAccessException e) {
/* 353 */         JavaSerializer.log.log(Level.FINE, e.toString(), e);
/*     */       }
/*     */ 
/* 356 */       out.writeInt(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class BooleanFieldSerializer extends JavaSerializer.FieldSerializer
/*     */   {
/* 325 */     static final JavaSerializer.FieldSerializer SER = new BooleanFieldSerializer();
/*     */ 
/*     */     void serialize(AbstractHessianOutput out, Object obj, Field field)
/*     */       throws IOException
/*     */     {
/* 330 */       boolean value = false;
/*     */       try
/*     */       {
/* 333 */         value = field.getBoolean(obj);
/*     */       } catch (IllegalAccessException e) {
/* 335 */         JavaSerializer.log.log(Level.FINE, e.toString(), e);
/*     */       }
/*     */ 
/* 338 */       out.writeBoolean(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class FieldSerializer
/*     */   {
/* 299 */     static final FieldSerializer SER = new FieldSerializer();
/*     */ 
/*     */     void serialize(AbstractHessianOutput out, Object obj, Field field)
/*     */       throws IOException
/*     */     {
/* 304 */       Object value = null;
/*     */       try
/*     */       {
/* 307 */         value = field.get(obj);
/*     */       } catch (IllegalAccessException e) {
/* 309 */         JavaSerializer.log.log(Level.FINE, e.toString(), e);
/*     */       }
/*     */       try
/*     */       {
/* 313 */         out.writeObject(value);
/*     */       } catch (RuntimeException e) {
/* 315 */         throw new RuntimeException(e.getMessage() + "\n Java field: " + field, e);
/*     */       }
/*     */       catch (IOException e) {
/* 318 */         throw new IOExceptionWrapper(e.getMessage() + "\n Java field: " + field, e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.JavaSerializer
 * JD-Core Version:    0.6.2
 */