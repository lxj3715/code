/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class LocaleHandle
/*     */   implements Serializable, HessianHandle
/*     */ {
/*     */   private String value;
/*     */ 
/*     */   public LocaleHandle(String locale)
/*     */   {
/*  61 */     this.value = locale;
/*     */   }
/*     */ 
/*     */   private Object readResolve()
/*     */   {
/*  66 */     String s = this.value;
/*     */ 
/*  68 */     if (s == null) {
/*  69 */       return null;
/*     */     }
/*  71 */     int len = s.length();
/*  72 */     char ch = ' ';
/*     */ 
/*  74 */     int i = 0;
/*     */ 
/*  76 */     while ((i < len) && ((('a' <= (ch = s.charAt(i))) && (ch <= 'z')) || (('A' <= ch) && (ch <= 'Z')) || (('0' <= ch) && (ch <= '9'))))
/*     */     {
/*  79 */       i++;
/*     */     }
/*     */ 
/*  82 */     String language = s.substring(0, i);
/*  83 */     String country = null;
/*  84 */     String var = null;
/*     */ 
/*  86 */     if ((ch == '-') || (ch == '_')) {
/*  87 */       i++; int head = i;
/*     */ 
/*  90 */       while ((i < len) && ((('a' <= (ch = s.charAt(i))) && (ch <= 'z')) || (('A' <= ch) && (ch <= 'Z')) || (('0' <= ch) && (ch <= '9'))))
/*     */       {
/*  93 */         i++;
/*     */       }
/*     */ 
/*  96 */       country = s.substring(head, i);
/*     */     }
/*     */ 
/*  99 */     if ((ch == '-') || (ch == '_')) {
/* 100 */       i++; int head = i;
/*     */ 
/* 103 */       while ((i < len) && ((('a' <= (ch = s.charAt(i))) && (ch <= 'z')) || (('A' <= ch) && (ch <= 'Z')) || (('0' <= ch) && (ch <= '9'))))
/*     */       {
/* 106 */         i++;
/*     */       }
/*     */ 
/* 109 */       var = s.substring(head, i);
/*     */     }
/*     */ 
/* 112 */     if (var != null)
/* 113 */       return new Locale(language, country, var);
/* 114 */     if (country != null) {
/* 115 */       return new Locale(language, country);
/*     */     }
/* 117 */     return new Locale(language);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.LocaleHandle
 * JD-Core Version:    0.6.2
 */