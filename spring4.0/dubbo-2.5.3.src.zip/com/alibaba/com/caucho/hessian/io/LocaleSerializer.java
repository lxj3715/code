/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class LocaleSerializer extends AbstractSerializer
/*    */ {
/* 58 */   private static LocaleSerializer SERIALIZER = new LocaleSerializer();
/*    */ 
/*    */   public static LocaleSerializer create()
/*    */   {
/* 62 */     return SERIALIZER;
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 68 */     if (obj == null) {
/* 69 */       out.writeNull();
/*    */     } else {
/* 71 */       Locale locale = (Locale)obj;
/*    */ 
/* 73 */       out.writeObject(new LocaleHandle(locale.toString()));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.LocaleSerializer
 * JD-Core Version:    0.6.2
 */