/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class MapDeserializer extends AbstractMapDeserializer
/*     */ {
/*     */   private Class _type;
/*     */   private Constructor _ctor;
/*     */ 
/*     */   public MapDeserializer(Class type)
/*     */   {
/*  64 */     if (type == null) {
/*  65 */       type = HashMap.class;
/*     */     }
/*  67 */     this._type = type;
/*     */ 
/*  69 */     Constructor[] ctors = type.getConstructors();
/*  70 */     for (int i = 0; i < ctors.length; i++) {
/*  71 */       if (ctors[i].getParameterTypes().length == 0) {
/*  72 */         this._ctor = ctors[i];
/*     */       }
/*     */     }
/*  75 */     if (this._ctor == null)
/*     */       try {
/*  77 */         this._ctor = HashMap.class.getConstructor(new Class[0]);
/*     */       } catch (Exception e) {
/*  79 */         throw new IllegalStateException(e);
/*     */       }
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  86 */     if (this._type != null) {
/*  87 */       return this._type;
/*     */     }
/*  89 */     return HashMap.class;
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in)
/*     */     throws IOException
/*     */   {
/*     */     Map map;
/*     */     Map map;
/*  97 */     if (this._type == null) {
/*  98 */       map = new HashMap();
/*     */     }
/*     */     else
/*     */     {
/*     */       Map map;
/*  99 */       if (this._type.equals(Map.class)) {
/* 100 */         map = new HashMap();
/*     */       }
/*     */       else
/*     */       {
/*     */         Map map;
/* 101 */         if (this._type.equals(SortedMap.class))
/* 102 */           map = new TreeMap();
/*     */         else
/*     */           try {
/* 105 */             map = (Map)this._ctor.newInstance(new Object[0]);
/*     */           } catch (Exception e) {
/* 107 */             throw new IOExceptionWrapper(e);
/*     */           }
/*     */       }
/*     */     }
/* 111 */     in.addRef(map);
/*     */ 
/* 113 */     while (!in.isEnd()) {
/* 114 */       map.put(in.readObject(), in.readObject());
/*     */     }
/*     */ 
/* 117 */     in.readEnd();
/*     */ 
/* 119 */     return map;
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, String[] fieldNames)
/*     */     throws IOException
/*     */   {
/* 127 */     Map map = createMap();
/*     */ 
/* 129 */     int ref = in.addRef(map);
/*     */ 
/* 131 */     for (int i = 0; i < fieldNames.length; i++) {
/* 132 */       String name = fieldNames[i];
/*     */ 
/* 134 */       map.put(name, in.readObject());
/*     */     }
/*     */ 
/* 137 */     return map;
/*     */   }
/*     */ 
/*     */   private Map createMap()
/*     */     throws IOException
/*     */   {
/* 144 */     if (this._type == null)
/* 145 */       return new HashMap();
/* 146 */     if (this._type.equals(Map.class))
/* 147 */       return new HashMap();
/* 148 */     if (this._type.equals(SortedMap.class))
/* 149 */       return new TreeMap();
/*     */     try
/*     */     {
/* 152 */       return (Map)this._ctor.newInstance(new Object[0]);
/*     */     } catch (Exception e) {
/* 154 */       throw new IOExceptionWrapper(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.MapDeserializer
 * JD-Core Version:    0.6.2
 */