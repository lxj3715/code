/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MapSerializer extends AbstractSerializer
/*     */ {
/*  60 */   private boolean _isSendJavaType = true;
/*     */ 
/*     */   public void setSendJavaType(boolean sendJavaType)
/*     */   {
/*  67 */     this._isSendJavaType = sendJavaType;
/*     */   }
/*     */ 
/*     */   public boolean getSendJavaType()
/*     */   {
/*  75 */     return this._isSendJavaType;
/*     */   }
/*     */ 
/*     */   public void writeObject(Object obj, AbstractHessianOutput out)
/*     */     throws IOException
/*     */   {
/*  81 */     if (out.addRef(obj)) {
/*  82 */       return;
/*     */     }
/*  84 */     Map map = (Map)obj;
/*     */ 
/*  86 */     Class cl = obj.getClass();
/*     */ 
/*  88 */     if ((cl.equals(HashMap.class)) || (!this._isSendJavaType) || (!(obj instanceof Serializable)))
/*     */     {
/*  91 */       out.writeMapBegin(null);
/*     */     }
/*  93 */     else out.writeMapBegin(obj.getClass().getName());
/*     */ 
/*  95 */     Iterator iter = map.entrySet().iterator();
/*  96 */     while (iter.hasNext()) {
/*  97 */       Map.Entry entry = (Map.Entry)iter.next();
/*     */ 
/*  99 */       out.writeObject(entry.getKey());
/* 100 */       out.writeObject(entry.getValue());
/*     */     }
/* 102 */     out.writeMapEnd();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.MapSerializer
 * JD-Core Version:    0.6.2
 */