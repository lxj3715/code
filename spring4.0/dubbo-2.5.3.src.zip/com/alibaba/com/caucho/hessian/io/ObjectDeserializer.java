/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class ObjectDeserializer extends AbstractDeserializer
/*    */ {
/*    */   private Class _cl;
/*    */ 
/*    */   public ObjectDeserializer(Class cl)
/*    */   {
/* 63 */     this._cl = cl;
/*    */   }
/*    */ 
/*    */   public Class getType()
/*    */   {
/* 68 */     return this._cl;
/*    */   }
/*    */ 
/*    */   public Object readObject(AbstractHessianInput in)
/*    */     throws IOException
/*    */   {
/* 74 */     return in.readObject();
/*    */   }
/*    */ 
/*    */   public Object readObject(AbstractHessianInput in, String[] fieldNames)
/*    */     throws IOException
/*    */   {
/* 80 */     throw new UnsupportedOperationException(String.valueOf(this));
/*    */   }
/*    */ 
/*    */   public Object readList(AbstractHessianInput in, int length)
/*    */     throws IOException
/*    */   {
/* 86 */     throw new UnsupportedOperationException(String.valueOf(this));
/*    */   }
/*    */ 
/*    */   public Object readLengthList(AbstractHessianInput in, int length)
/*    */     throws IOException
/*    */   {
/* 92 */     throw new UnsupportedOperationException(String.valueOf(this));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 98 */     return getClass().getSimpleName() + "[" + this._cl + "]";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.ObjectDeserializer
 * JD-Core Version:    0.6.2
 */