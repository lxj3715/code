package com.alibaba.com.caucho.hessian.io;

import java.io.IOException;

public abstract interface Serializer
{
  public abstract void writeObject(Object paramObject, AbstractHessianOutput paramAbstractHessianOutput)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.Serializer
 * JD-Core Version:    0.6.2
 */