/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ public class SerializerFactory extends AbstractSerializerFactory
/*     */ {
/*  64 */   private static final Logger log = Logger.getLogger(SerializerFactory.class.getName());
/*     */ 
/*  67 */   private static Deserializer OBJECT_DESERIALIZER = new BasicDeserializer(13);
/*     */ 
/* 556 */   private static HashMap _staticSerializerMap = new HashMap();
/* 557 */   private static HashMap _staticDeserializerMap = new HashMap();
/* 558 */   private static HashMap _staticTypeMap = new HashMap();
/*     */   private ClassLoader _loader;
/*     */   protected Serializer _defaultSerializer;
/*  79 */   protected ArrayList _factories = new ArrayList();
/*     */   protected CollectionSerializer _collectionSerializer;
/*     */   protected MapSerializer _mapSerializer;
/*     */   private Deserializer _hashMapDeserializer;
/*     */   private Deserializer _arrayListDeserializer;
/*     */   private HashMap _cachedSerializerMap;
/*     */   private HashMap _cachedDeserializerMap;
/*     */   private HashMap _cachedTypeDeserializerMap;
/*     */   private boolean _isAllowNonSerializable;
/*     */ 
/*     */   public SerializerFactory()
/*     */   {
/*  94 */     this(Thread.currentThread().getContextClassLoader());
/*     */   }
/*     */ 
/*     */   public SerializerFactory(ClassLoader loader)
/*     */   {
/*  99 */     this._loader = loader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 104 */     return this._loader;
/*     */   }
/*     */ 
/*     */   public void setSendCollectionType(boolean isSendType)
/*     */   {
/* 112 */     if (this._collectionSerializer == null) {
/* 113 */       this._collectionSerializer = new CollectionSerializer();
/*     */     }
/* 115 */     this._collectionSerializer.setSendJavaType(isSendType);
/*     */ 
/* 117 */     if (this._mapSerializer == null) {
/* 118 */       this._mapSerializer = new MapSerializer();
/*     */     }
/* 120 */     this._mapSerializer.setSendJavaType(isSendType);
/*     */   }
/*     */ 
/*     */   public void addFactory(AbstractSerializerFactory factory)
/*     */   {
/* 128 */     this._factories.add(factory);
/*     */   }
/*     */ 
/*     */   public void setAllowNonSerializable(boolean allow)
/*     */   {
/* 136 */     this._isAllowNonSerializable = allow;
/*     */   }
/*     */ 
/*     */   public boolean isAllowNonSerializable()
/*     */   {
/* 144 */     return this._isAllowNonSerializable;
/*     */   }
/*     */ 
/*     */   public Serializer getSerializer(Class cl)
/*     */     throws HessianProtocolException
/*     */   {
/* 159 */     Serializer serializer = (Serializer)_staticSerializerMap.get(cl);
/* 160 */     if (serializer != null) {
/* 161 */       return serializer;
/*     */     }
/* 163 */     if (this._cachedSerializerMap != null) {
/* 164 */       synchronized (this._cachedSerializerMap) {
/* 165 */         serializer = (Serializer)this._cachedSerializerMap.get(cl);
/*     */       }
/*     */ 
/* 168 */       if (serializer != null) {
/* 169 */         return serializer;
/*     */       }
/*     */     }
/* 172 */     for (int i = 0; 
/* 173 */       (serializer == null) && (this._factories != null) && (i < this._factories.size()); 
/* 174 */       i++)
/*     */     {
/* 177 */       AbstractSerializerFactory factory = (AbstractSerializerFactory)this._factories.get(i);
/*     */ 
/* 179 */       serializer = factory.getSerializer(cl);
/*     */     }
/*     */ 
/* 182 */     if (serializer == null)
/*     */     {
/* 185 */       if (JavaSerializer.getWriteReplace(cl) != null) {
/* 186 */         serializer = new JavaSerializer(cl, this._loader);
/*     */       }
/* 188 */       else if (HessianRemoteObject.class.isAssignableFrom(cl)) {
/* 189 */         serializer = new RemoteSerializer();
/*     */       }
/* 194 */       else if (Map.class.isAssignableFrom(cl)) {
/* 195 */         if (this._mapSerializer == null) {
/* 196 */           this._mapSerializer = new MapSerializer();
/*     */         }
/* 198 */         serializer = this._mapSerializer;
/*     */       }
/* 200 */       else if (Collection.class.isAssignableFrom(cl)) {
/* 201 */         if (this._collectionSerializer == null) {
/* 202 */           this._collectionSerializer = new CollectionSerializer();
/*     */         }
/*     */ 
/* 205 */         serializer = this._collectionSerializer;
/*     */       }
/* 208 */       else if (cl.isArray()) {
/* 209 */         serializer = new ArraySerializer();
/*     */       }
/* 211 */       else if (Throwable.class.isAssignableFrom(cl)) {
/* 212 */         serializer = new ThrowableSerializer(cl, getClassLoader());
/*     */       }
/* 214 */       else if (InputStream.class.isAssignableFrom(cl)) {
/* 215 */         serializer = new InputStreamSerializer();
/*     */       }
/* 217 */       else if (Iterator.class.isAssignableFrom(cl)) {
/* 218 */         serializer = IteratorSerializer.create();
/*     */       }
/* 220 */       else if (Enumeration.class.isAssignableFrom(cl)) {
/* 221 */         serializer = EnumerationSerializer.create();
/*     */       }
/* 223 */       else if (Calendar.class.isAssignableFrom(cl)) {
/* 224 */         serializer = CalendarSerializer.create();
/*     */       }
/* 226 */       else if (Locale.class.isAssignableFrom(cl)) {
/* 227 */         serializer = LocaleSerializer.create();
/*     */       }
/* 229 */       else if (Enum.class.isAssignableFrom(cl)) {
/* 230 */         serializer = new EnumSerializer(cl);
/*     */       }
/*     */     }
/* 232 */     if (serializer == null) {
/* 233 */       serializer = getDefaultSerializer(cl);
/*     */     }
/* 235 */     if (this._cachedSerializerMap == null) {
/* 236 */       this._cachedSerializerMap = new HashMap(8);
/*     */     }
/* 238 */     synchronized (this._cachedSerializerMap) {
/* 239 */       this._cachedSerializerMap.put(cl, serializer);
/*     */     }
/*     */ 
/* 242 */     return serializer;
/*     */   }
/*     */ 
/*     */   protected Serializer getDefaultSerializer(Class cl)
/*     */   {
/* 256 */     if (this._defaultSerializer != null) {
/* 257 */       return this._defaultSerializer;
/*     */     }
/* 259 */     if ((!Serializable.class.isAssignableFrom(cl)) && (!this._isAllowNonSerializable))
/*     */     {
/* 261 */       throw new IllegalStateException("Serialized class " + cl.getName() + " must implement java.io.Serializable");
/*     */     }
/*     */ 
/* 264 */     return new JavaSerializer(cl, this._loader);
/*     */   }
/*     */ 
/*     */   public Deserializer getDeserializer(Class cl)
/*     */     throws HessianProtocolException
/*     */   {
/* 279 */     Deserializer deserializer = (Deserializer)_staticDeserializerMap.get(cl);
/* 280 */     if (deserializer != null) {
/* 281 */       return deserializer;
/*     */     }
/* 283 */     if (this._cachedDeserializerMap != null) {
/* 284 */       synchronized (this._cachedDeserializerMap) {
/* 285 */         deserializer = (Deserializer)this._cachedDeserializerMap.get(cl);
/*     */       }
/*     */ 
/* 288 */       if (deserializer != null) {
/* 289 */         return deserializer;
/*     */       }
/*     */     }
/*     */ 
/* 293 */     for (int i = 0; 
/* 294 */       (deserializer == null) && (this._factories != null) && (i < this._factories.size()); 
/* 295 */       i++)
/*     */     {
/* 297 */       AbstractSerializerFactory factory = (AbstractSerializerFactory)this._factories.get(i);
/*     */ 
/* 299 */       deserializer = factory.getDeserializer(cl);
/*     */     }
/*     */ 
/* 302 */     if (deserializer == null)
/*     */     {
/* 305 */       if (Collection.class.isAssignableFrom(cl)) {
/* 306 */         deserializer = new CollectionDeserializer(cl);
/*     */       }
/* 308 */       else if (Map.class.isAssignableFrom(cl)) {
/* 309 */         deserializer = new MapDeserializer(cl);
/*     */       }
/* 311 */       else if (cl.isInterface()) {
/* 312 */         deserializer = new ObjectDeserializer(cl);
/*     */       }
/* 314 */       else if (cl.isArray()) {
/* 315 */         deserializer = new ArrayDeserializer(cl.getComponentType());
/*     */       }
/* 317 */       else if (Enumeration.class.isAssignableFrom(cl)) {
/* 318 */         deserializer = EnumerationDeserializer.create();
/*     */       }
/* 320 */       else if (Enum.class.isAssignableFrom(cl)) {
/* 321 */         deserializer = new EnumDeserializer(cl);
/*     */       }
/* 323 */       else if (Class.class.equals(cl)) {
/* 324 */         deserializer = new ClassDeserializer(this._loader);
/*     */       }
/*     */       else
/* 327 */         deserializer = getDefaultDeserializer(cl);
/*     */     }
/* 329 */     if (this._cachedDeserializerMap == null) {
/* 330 */       this._cachedDeserializerMap = new HashMap(8);
/*     */     }
/* 332 */     synchronized (this._cachedDeserializerMap) {
/* 333 */       this._cachedDeserializerMap.put(cl, deserializer);
/*     */     }
/*     */ 
/* 336 */     return deserializer;
/*     */   }
/*     */ 
/*     */   protected Deserializer getDefaultDeserializer(Class cl)
/*     */   {
/* 350 */     return new JavaDeserializer(cl);
/*     */   }
/*     */ 
/*     */   public Object readList(AbstractHessianInput in, int length, String type)
/*     */     throws HessianProtocolException, IOException
/*     */   {
/* 359 */     Deserializer deserializer = getDeserializer(type);
/*     */ 
/* 361 */     if (deserializer != null) {
/* 362 */       return deserializer.readList(in, length);
/*     */     }
/* 364 */     return new CollectionDeserializer(ArrayList.class).readList(in, length);
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in, String type)
/*     */     throws HessianProtocolException, IOException
/*     */   {
/* 373 */     Deserializer deserializer = getDeserializer(type);
/*     */ 
/* 375 */     if (deserializer != null)
/* 376 */       return deserializer.readMap(in);
/* 377 */     if (this._hashMapDeserializer != null) {
/* 378 */       return this._hashMapDeserializer.readMap(in);
/*     */     }
/* 380 */     this._hashMapDeserializer = new MapDeserializer(HashMap.class);
/*     */ 
/* 382 */     return this._hashMapDeserializer.readMap(in);
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, String type, String[] fieldNames)
/*     */     throws HessianProtocolException, IOException
/*     */   {
/* 394 */     Deserializer deserializer = getDeserializer(type);
/*     */ 
/* 396 */     if (deserializer != null)
/* 397 */       return deserializer.readObject(in, fieldNames);
/* 398 */     if (this._hashMapDeserializer != null) {
/* 399 */       return this._hashMapDeserializer.readObject(in, fieldNames);
/*     */     }
/* 401 */     this._hashMapDeserializer = new MapDeserializer(HashMap.class);
/*     */ 
/* 403 */     return this._hashMapDeserializer.readObject(in, fieldNames);
/*     */   }
/*     */ 
/*     */   public Deserializer getObjectDeserializer(String type, Class cl)
/*     */     throws HessianProtocolException
/*     */   {
/* 413 */     Deserializer reader = getObjectDeserializer(type);
/*     */ 
/* 415 */     if ((cl == null) || (cl.equals(reader.getType())) || (cl.isAssignableFrom(reader.getType())) || (HessianHandle.class.isAssignableFrom(reader.getType())))
/*     */     {
/* 419 */       return reader;
/*     */     }
/*     */ 
/* 422 */     if (log.isLoggable(Level.FINE)) {
/* 423 */       log.fine("hessian: expected '" + cl.getName() + "' at '" + type + "' (" + reader.getType().getName() + ")");
/*     */     }
/*     */ 
/* 427 */     return getDeserializer(cl);
/*     */   }
/*     */ 
/*     */   public Deserializer getObjectDeserializer(String type)
/*     */     throws HessianProtocolException
/*     */   {
/* 436 */     Deserializer deserializer = getDeserializer(type);
/*     */ 
/* 438 */     if (deserializer != null)
/* 439 */       return deserializer;
/* 440 */     if (this._hashMapDeserializer != null) {
/* 441 */       return this._hashMapDeserializer;
/*     */     }
/* 443 */     this._hashMapDeserializer = new MapDeserializer(HashMap.class);
/*     */ 
/* 445 */     return this._hashMapDeserializer;
/*     */   }
/*     */ 
/*     */   public Deserializer getListDeserializer(String type, Class cl)
/*     */     throws HessianProtocolException
/*     */   {
/* 455 */     Deserializer reader = getListDeserializer(type);
/*     */ 
/* 457 */     if ((cl == null) || (cl.equals(reader.getType())) || (cl.isAssignableFrom(reader.getType())))
/*     */     {
/* 460 */       return reader;
/*     */     }
/*     */ 
/* 463 */     if (log.isLoggable(Level.FINE)) {
/* 464 */       log.fine("hessian: expected '" + cl.getName() + "' at '" + type + "' (" + reader.getType().getName() + ")");
/*     */     }
/*     */ 
/* 468 */     return getDeserializer(cl);
/*     */   }
/*     */ 
/*     */   public Deserializer getListDeserializer(String type)
/*     */     throws HessianProtocolException
/*     */   {
/* 477 */     Deserializer deserializer = getDeserializer(type);
/*     */ 
/* 479 */     if (deserializer != null)
/* 480 */       return deserializer;
/* 481 */     if (this._arrayListDeserializer != null) {
/* 482 */       return this._arrayListDeserializer;
/*     */     }
/* 484 */     this._arrayListDeserializer = new CollectionDeserializer(ArrayList.class);
/*     */ 
/* 486 */     return this._arrayListDeserializer;
/*     */   }
/*     */ 
/*     */   public Deserializer getDeserializer(String type)
/*     */     throws HessianProtocolException
/*     */   {
/* 496 */     if ((type == null) || (type.equals(""))) {
/* 497 */       return null;
/*     */     }
/*     */ 
/* 501 */     if (this._cachedTypeDeserializerMap != null)
/*     */     {
/*     */       Deserializer deserializer;
/* 502 */       synchronized (this._cachedTypeDeserializerMap) {
/* 503 */         deserializer = (Deserializer)this._cachedTypeDeserializerMap.get(type);
/*     */       }
/*     */ 
/* 506 */       if (deserializer != null) {
/* 507 */         return deserializer;
/*     */       }
/*     */     }
/*     */ 
/* 511 */     Deserializer deserializer = (Deserializer)_staticTypeMap.get(type);
/* 512 */     if (deserializer != null) {
/* 513 */       return deserializer;
/*     */     }
/* 515 */     if (type.startsWith("[")) {
/* 516 */       Deserializer subDeserializer = getDeserializer(type.substring(1));
/*     */ 
/* 518 */       if (subDeserializer != null)
/* 519 */         deserializer = new ArrayDeserializer(subDeserializer.getType());
/*     */       else
/* 521 */         deserializer = new ArrayDeserializer(Object.class);
/*     */     }
/*     */     else {
/*     */       try {
/* 525 */         Class cl = Class.forName(type, false, this._loader);
/* 526 */         deserializer = getDeserializer(cl);
/*     */       } catch (Exception e) {
/* 528 */         log.warning("Hessian/Burlap: '" + type + "' is an unknown class in " + this._loader + ":\n" + e);
/*     */ 
/* 530 */         log.log(Level.FINER, e.toString(), e);
/*     */       }
/*     */     }
/*     */ 
/* 534 */     if (deserializer != null) {
/* 535 */       if (this._cachedTypeDeserializerMap == null) {
/* 536 */         this._cachedTypeDeserializerMap = new HashMap(8);
/*     */       }
/* 538 */       synchronized (this._cachedTypeDeserializerMap) {
/* 539 */         this._cachedTypeDeserializerMap.put(type, deserializer);
/*     */       }
/*     */     }
/*     */ 
/* 543 */     return deserializer;
/*     */   }
/*     */ 
/*     */   private static void addBasic(Class cl, String typeName, int type)
/*     */   {
/* 548 */     _staticSerializerMap.put(cl, new BasicSerializer(type));
/*     */ 
/* 550 */     Deserializer deserializer = new BasicDeserializer(type);
/* 551 */     _staticDeserializerMap.put(cl, deserializer);
/* 552 */     _staticTypeMap.put(typeName, deserializer);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 560 */     addBasic(Void.TYPE, "void", 0);
/*     */ 
/* 562 */     addBasic(Boolean.class, "boolean", 1);
/* 563 */     addBasic(Byte.class, "byte", 2);
/* 564 */     addBasic(Short.class, "short", 3);
/* 565 */     addBasic(Integer.class, "int", 4);
/* 566 */     addBasic(Long.class, "long", 5);
/* 567 */     addBasic(Float.class, "float", 6);
/* 568 */     addBasic(Double.class, "double", 7);
/* 569 */     addBasic(Character.class, "char", 9);
/* 570 */     addBasic(String.class, "string", 10);
/* 571 */     addBasic(Object.class, "object", 13);
/* 572 */     addBasic(java.util.Date.class, "date", 11);
/*     */ 
/* 574 */     addBasic(Boolean.TYPE, "boolean", 1);
/* 575 */     addBasic(Byte.TYPE, "byte", 2);
/* 576 */     addBasic(Short.TYPE, "short", 3);
/* 577 */     addBasic(Integer.TYPE, "int", 4);
/* 578 */     addBasic(Long.TYPE, "long", 5);
/* 579 */     addBasic(Float.TYPE, "float", 6);
/* 580 */     addBasic(Double.TYPE, "double", 7);
/* 581 */     addBasic(Character.TYPE, "char", 8);
/*     */ 
/* 583 */     addBasic([Z.class, "[boolean", 14);
/* 584 */     addBasic([B.class, "[byte", 15);
/* 585 */     addBasic([S.class, "[short", 16);
/* 586 */     addBasic([I.class, "[int", 17);
/* 587 */     addBasic([J.class, "[long", 18);
/* 588 */     addBasic([F.class, "[float", 19);
/* 589 */     addBasic([D.class, "[double", 20);
/* 590 */     addBasic([C.class, "[char", 21);
/* 591 */     addBasic([Ljava.lang.String.class, "[string", 22);
/* 592 */     addBasic([Ljava.lang.Object.class, "[object", 23);
/*     */ 
/* 594 */     _staticSerializerMap.put(Class.class, new ClassSerializer());
/*     */ 
/* 596 */     _staticDeserializerMap.put(Number.class, new BasicDeserializer(12));
/*     */ 
/* 598 */     _staticSerializerMap.put(BigDecimal.class, new StringValueSerializer());
/*     */     try {
/* 600 */       _staticDeserializerMap.put(BigDecimal.class, new StringValueDeserializer(BigDecimal.class));
/*     */ 
/* 602 */       _staticDeserializerMap.put(BigInteger.class, new BigIntegerDeserializer());
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*     */     }
/* 607 */     _staticSerializerMap.put(File.class, new StringValueSerializer());
/*     */     try {
/* 609 */       _staticDeserializerMap.put(File.class, new StringValueDeserializer(File.class));
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*     */     }
/* 614 */     _staticSerializerMap.put(ObjectName.class, new StringValueSerializer());
/*     */     try {
/* 616 */       _staticDeserializerMap.put(ObjectName.class, new StringValueDeserializer(ObjectName.class));
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*     */     }
/* 621 */     _staticSerializerMap.put(java.sql.Date.class, new SqlDateSerializer());
/* 622 */     _staticSerializerMap.put(Time.class, new SqlDateSerializer());
/* 623 */     _staticSerializerMap.put(Timestamp.class, new SqlDateSerializer());
/*     */ 
/* 625 */     _staticSerializerMap.put(InputStream.class, new InputStreamSerializer());
/*     */ 
/* 627 */     _staticDeserializerMap.put(InputStream.class, new InputStreamDeserializer());
/*     */     try
/*     */     {
/* 631 */       _staticDeserializerMap.put(java.sql.Date.class, new SqlDateDeserializer(java.sql.Date.class));
/*     */ 
/* 633 */       _staticDeserializerMap.put(Time.class, new SqlDateDeserializer(Time.class));
/*     */ 
/* 635 */       _staticDeserializerMap.put(Timestamp.class, new SqlDateDeserializer(Timestamp.class));
/*     */     }
/*     */     catch (Throwable e) {
/* 638 */       e.printStackTrace();
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 643 */       Class stackTrace = StackTraceElement.class;
/*     */ 
/* 645 */       _staticDeserializerMap.put(stackTrace, new StackTraceElementDeserializer());
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.SerializerFactory
 * JD-Core Version:    0.6.2
 */