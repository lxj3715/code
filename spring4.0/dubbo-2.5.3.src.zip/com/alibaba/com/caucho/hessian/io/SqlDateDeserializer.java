/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ 
/*     */ public class SqlDateDeserializer extends AbstractDeserializer
/*     */ {
/*     */   private Class _cl;
/*     */   private Constructor _constructor;
/*     */ 
/*     */   public SqlDateDeserializer(Class cl)
/*     */     throws NoSuchMethodException
/*     */   {
/*  64 */     this._cl = cl;
/*  65 */     this._constructor = cl.getConstructor(new Class[] { Long.TYPE });
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  70 */     return this._cl;
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in)
/*     */     throws IOException
/*     */   {
/*  76 */     int ref = in.addRef(null);
/*     */ 
/*  78 */     long initValue = -9223372036854775808L;
/*     */ 
/*  80 */     while (!in.isEnd()) {
/*  81 */       String key = in.readString();
/*     */ 
/*  83 */       if (key.equals("value"))
/*  84 */         initValue = in.readUTCDate();
/*     */       else {
/*  86 */         in.readString();
/*     */       }
/*     */     }
/*  89 */     in.readMapEnd();
/*     */ 
/*  91 */     Object value = create(initValue);
/*     */ 
/*  93 */     in.setRef(ref, value);
/*     */ 
/*  95 */     return value;
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, String[] fieldNames)
/*     */     throws IOException
/*     */   {
/* 101 */     int ref = in.addRef(null);
/*     */ 
/* 103 */     long initValue = -9223372036854775808L;
/*     */ 
/* 105 */     for (int i = 0; i < fieldNames.length; i++) {
/* 106 */       String key = fieldNames[i];
/*     */ 
/* 108 */       if (key.equals("value"))
/* 109 */         initValue = in.readUTCDate();
/*     */       else {
/* 111 */         in.readObject();
/*     */       }
/*     */     }
/* 114 */     Object value = create(initValue);
/*     */ 
/* 116 */     in.setRef(ref, value);
/*     */ 
/* 118 */     return value;
/*     */   }
/*     */ 
/*     */   private Object create(long initValue)
/*     */     throws IOException
/*     */   {
/* 124 */     if (initValue == -9223372036854775808L)
/* 125 */       throw new IOException(this._cl.getName() + " expects name.");
/*     */     try
/*     */     {
/* 128 */       return this._constructor.newInstance(new Object[] { new Long(initValue) });
/*     */     } catch (Exception e) {
/* 130 */       throw new IOExceptionWrapper(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.SqlDateDeserializer
 * JD-Core Version:    0.6.2
 */