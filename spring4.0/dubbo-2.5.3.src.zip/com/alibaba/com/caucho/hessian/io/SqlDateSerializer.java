/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class SqlDateSerializer extends AbstractSerializer
/*    */ {
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 62 */     if (obj == null) {
/* 63 */       out.writeNull();
/*    */     } else {
/* 65 */       Class cl = obj.getClass();
/*    */ 
/* 67 */       if (out.addRef(obj)) {
/* 68 */         return;
/*    */       }
/* 70 */       int ref = out.writeObjectBegin(cl.getName());
/*    */ 
/* 72 */       if (ref < -1) {
/* 73 */         out.writeString("value");
/* 74 */         out.writeUTCDate(((Date)obj).getTime());
/* 75 */         out.writeMapEnd();
/*    */       }
/*    */       else {
/* 78 */         if (ref == -1) {
/* 79 */           out.writeInt(1);
/* 80 */           out.writeString("value");
/* 81 */           out.writeObjectBegin(cl.getName());
/*    */         }
/*    */ 
/* 84 */         out.writeUTCDate(((Date)obj).getTime());
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.SqlDateSerializer
 * JD-Core Version:    0.6.2
 */