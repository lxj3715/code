/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ public class StackTraceElementDeserializer extends JavaDeserializer
/*    */ {
/*    */   public StackTraceElementDeserializer()
/*    */   {
/* 60 */     super(StackTraceElement.class);
/*    */   }
/*    */ 
/*    */   protected Object instantiate()
/*    */     throws Exception
/*    */   {
/* 67 */     return new StackTraceElement("", "", "", 0);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.StackTraceElementDeserializer
 * JD-Core Version:    0.6.2
 */