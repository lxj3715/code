/*     */ package com.alibaba.com.caucho.hessian.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ 
/*     */ public class StringValueDeserializer extends AbstractDeserializer
/*     */ {
/*     */   private Class _cl;
/*     */   private Constructor _constructor;
/*     */ 
/*     */   public StringValueDeserializer(Class cl)
/*     */   {
/*     */     try
/*     */     {
/*  64 */       this._cl = cl;
/*  65 */       this._constructor = cl.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception e) {
/*  67 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/*  73 */     return this._cl;
/*     */   }
/*     */ 
/*     */   public Object readMap(AbstractHessianInput in)
/*     */     throws IOException
/*     */   {
/*  79 */     String value = null;
/*     */ 
/*  81 */     while (!in.isEnd()) {
/*  82 */       String key = in.readString();
/*     */ 
/*  84 */       if (key.equals("value"))
/*  85 */         value = in.readString();
/*     */       else {
/*  87 */         in.readObject();
/*     */       }
/*     */     }
/*  90 */     in.readMapEnd();
/*     */ 
/*  92 */     Object object = create(value);
/*     */ 
/*  94 */     in.addRef(object);
/*     */ 
/*  96 */     return object;
/*     */   }
/*     */ 
/*     */   public Object readObject(AbstractHessianInput in, String[] fieldNames)
/*     */     throws IOException
/*     */   {
/* 102 */     String value = null;
/*     */ 
/* 104 */     for (int i = 0; i < fieldNames.length; i++) {
/* 105 */       if ("value".equals(fieldNames[i]))
/* 106 */         value = in.readString();
/*     */       else {
/* 108 */         in.readObject();
/*     */       }
/*     */     }
/* 111 */     Object object = create(value);
/*     */ 
/* 113 */     in.addRef(object);
/*     */ 
/* 115 */     return object;
/*     */   }
/*     */ 
/*     */   private Object create(String value)
/*     */     throws IOException
/*     */   {
/* 121 */     if (value == null)
/* 122 */       throw new IOException(this._cl.getName() + " expects name.");
/*     */     try
/*     */     {
/* 125 */       return this._constructor.newInstance(new Object[] { value });
/*     */     } catch (Exception e) {
/* 127 */       throw new IOExceptionWrapper(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.StringValueDeserializer
 * JD-Core Version:    0.6.2
 */