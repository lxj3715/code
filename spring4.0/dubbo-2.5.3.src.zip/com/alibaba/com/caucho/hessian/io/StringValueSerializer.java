/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class StringValueSerializer extends AbstractSerializer
/*    */ {
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 60 */     if (obj == null) {
/* 61 */       out.writeNull();
/*    */     } else {
/* 63 */       if (out.addRef(obj)) {
/* 64 */         return;
/*    */       }
/* 66 */       Class cl = obj.getClass();
/*    */ 
/* 68 */       int ref = out.writeObjectBegin(cl.getName());
/*    */ 
/* 70 */       if (ref < -1) {
/* 71 */         out.writeString("value");
/* 72 */         out.writeString(obj.toString());
/* 73 */         out.writeMapEnd();
/*    */       }
/*    */       else {
/* 76 */         if (ref == -1) {
/* 77 */           out.writeInt(1);
/* 78 */           out.writeString("value");
/* 79 */           out.writeObjectBegin(cl.getName());
/*    */         }
/*    */ 
/* 82 */         out.writeString(obj.toString());
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.StringValueSerializer
 * JD-Core Version:    0.6.2
 */