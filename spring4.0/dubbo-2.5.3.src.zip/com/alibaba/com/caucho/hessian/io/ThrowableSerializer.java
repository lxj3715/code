/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class ThrowableSerializer extends JavaSerializer
/*    */ {
/*    */   public ThrowableSerializer(Class cl, ClassLoader loader)
/*    */   {
/* 59 */     super(cl, loader);
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 65 */     Throwable e = (Throwable)obj;
/*    */ 
/* 67 */     e.getStackTrace();
/*    */ 
/* 69 */     super.writeObject(obj, out);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.ThrowableSerializer
 * JD-Core Version:    0.6.2
 */