/*    */ package com.alibaba.com.caucho.hessian.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public abstract class ValueDeserializer extends AbstractDeserializer
/*    */ {
/*    */   public Object readMap(AbstractHessianInput in)
/*    */     throws IOException
/*    */   {
/* 60 */     String initValue = null;
/*    */ 
/* 62 */     while (!in.isEnd()) {
/* 63 */       String key = in.readString();
/*    */ 
/* 65 */       if (key.equals("value"))
/* 66 */         initValue = in.readString();
/*    */       else {
/* 68 */         in.readObject();
/*    */       }
/*    */     }
/* 71 */     in.readMapEnd();
/*    */ 
/* 73 */     return create(initValue);
/*    */   }
/*    */ 
/*    */   public Object readObject(AbstractHessianInput in, String[] fieldNames)
/*    */     throws IOException
/*    */   {
/* 79 */     String initValue = null;
/*    */ 
/* 81 */     for (int i = 0; i < fieldNames.length; i++) {
/* 82 */       if ("value".equals(fieldNames[i]))
/* 83 */         initValue = in.readString();
/*    */       else {
/* 85 */         in.readObject();
/*    */       }
/*    */     }
/* 88 */     return create(initValue);
/*    */   }
/*    */ 
/*    */   abstract Object create(String paramString)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.io.ValueDeserializer
 * JD-Core Version:    0.6.2
 */