/*     */ package com.alibaba.com.caucho.hessian.security;
/*     */ 
/*     */ import com.alibaba.com.caucho.hessian.io.Hessian2Input;
/*     */ import com.alibaba.com.caucho.hessian.io.Hessian2Output;
/*     */ import com.alibaba.com.caucho.hessian.io.HessianEnvelope;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.Key;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.CipherInputStream;
/*     */ import javax.crypto.CipherOutputStream;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.SecretKey;
/*     */ 
/*     */ public class X509Encryption extends HessianEnvelope
/*     */ {
/*  61 */   private String _algorithm = "AES";
/*     */   private X509Certificate _cert;
/*     */   private PrivateKey _privateKey;
/*     */   private SecureRandom _secureRandom;
/*     */ 
/*     */   public void setAlgorithm(String algorithm)
/*     */   {
/*  80 */     if (algorithm == null) {
/*  81 */       throw new NullPointerException();
/*     */     }
/*  83 */     this._algorithm = algorithm;
/*     */   }
/*     */ 
/*     */   public String getAlgorithm()
/*     */   {
/*  91 */     return this._algorithm;
/*     */   }
/*     */ 
/*     */   public X509Certificate getCertificate()
/*     */   {
/*  99 */     return this._cert;
/*     */   }
/*     */ 
/*     */   public void setCertificate(X509Certificate cert)
/*     */   {
/* 107 */     this._cert = cert;
/*     */   }
/*     */ 
/*     */   public PrivateKey getPrivateKey()
/*     */   {
/* 115 */     return this._privateKey;
/*     */   }
/*     */ 
/*     */   public void setPrivateKey(PrivateKey privateKey)
/*     */   {
/* 123 */     this._privateKey = privateKey;
/*     */   }
/*     */ 
/*     */   public SecureRandom getSecureRandom()
/*     */   {
/* 131 */     return this._secureRandom;
/*     */   }
/*     */ 
/*     */   public void setSecureRandom(SecureRandom random)
/*     */   {
/* 139 */     this._secureRandom = random;
/*     */   }
/*     */ 
/*     */   public Hessian2Output wrap(Hessian2Output out)
/*     */     throws IOException
/*     */   {
/* 145 */     if (this._cert == null) {
/* 146 */       throw new IOException("X509Encryption.wrap requires a certificate");
/*     */     }
/* 148 */     OutputStream os = new EncryptOutputStream(out);
/*     */ 
/* 150 */     Hessian2Output filterOut = new Hessian2Output(os);
/*     */ 
/* 152 */     filterOut.setCloseStreamOnClose(true);
/*     */ 
/* 154 */     return filterOut;
/*     */   }
/*     */ 
/*     */   public Hessian2Input unwrap(Hessian2Input in)
/*     */     throws IOException
/*     */   {
/* 160 */     if (this._privateKey == null) {
/* 161 */       throw new IOException("X509Encryption.unwrap requires a private key");
/*     */     }
/* 163 */     if (this._cert == null) {
/* 164 */       throw new IOException("X509Encryption.unwrap requires a certificate");
/*     */     }
/* 166 */     int version = in.readEnvelope();
/*     */ 
/* 168 */     String method = in.readMethod();
/*     */ 
/* 170 */     if (!method.equals(getClass().getName())) {
/* 171 */       throw new IOException("expected hessian Envelope method '" + getClass().getName() + "' at '" + method + "'");
/*     */     }
/*     */ 
/* 174 */     return unwrapHeaders(in);
/*     */   }
/*     */ 
/*     */   public Hessian2Input unwrapHeaders(Hessian2Input in)
/*     */     throws IOException
/*     */   {
/* 180 */     if (this._privateKey == null) {
/* 181 */       throw new IOException("X509Encryption.unwrap requires a private key");
/*     */     }
/* 183 */     if (this._cert == null) {
/* 184 */       throw new IOException("X509Encryption.unwrap requires a certificate");
/*     */     }
/* 186 */     InputStream is = new EncryptInputStream(in);
/*     */ 
/* 188 */     Hessian2Input filter = new Hessian2Input(is);
/*     */ 
/* 190 */     filter.setCloseStreamOnClose(true);
/*     */ 
/* 192 */     return filter;
/*     */   }
/*     */ 
/*     */   class EncryptInputStream extends InputStream
/*     */   {
/*     */     private Hessian2Input _in;
/*     */     private Cipher _cipher;
/*     */     private InputStream _bodyIn;
/*     */     private CipherInputStream _cipherIn;
/*     */ 
/*     */     EncryptInputStream(Hessian2Input in)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 304 */         this._in = in;
/*     */ 
/* 306 */         fingerprint = null;
/* 307 */         String keyAlgorithm = null;
/* 308 */         String algorithm = null;
/* 309 */         byte[] encKey = null;
/*     */ 
/* 311 */         int len = in.readInt();
/*     */ 
/* 313 */         for (int i = 0; i < len; i++) {
/* 314 */           String header = in.readString();
/*     */ 
/* 316 */           if ("fingerprint".equals(header))
/* 317 */             fingerprint = in.readBytes();
/* 318 */           else if ("key-algorithm".equals(header))
/* 319 */             keyAlgorithm = in.readString();
/* 320 */           else if ("algorithm".equals(header))
/* 321 */             algorithm = in.readString();
/* 322 */           else if ("key".equals(header))
/* 323 */             encKey = in.readBytes();
/*     */           else {
/* 325 */             throw new IOException("'" + header + "' is an unexpected header");
/*     */           }
/*     */         }
/* 328 */         Cipher keyCipher = Cipher.getInstance(keyAlgorithm);
/* 329 */         keyCipher.init(4, X509Encryption.this._privateKey);
/*     */ 
/* 331 */         Key key = keyCipher.unwrap(encKey, algorithm, 3);
/* 332 */         this._bodyIn = this._in.readInputStream();
/*     */ 
/* 334 */         this._cipher = Cipher.getInstance(algorithm);
/* 335 */         this._cipher.init(2, key);
/*     */ 
/* 337 */         this._cipherIn = new CipherInputStream(this._bodyIn, this._cipher);
/*     */       }
/*     */       catch (RuntimeException e)
/*     */       {
/*     */         byte[] fingerprint;
/* 339 */         throw e;
/*     */       } catch (IOException e) {
/* 341 */         throw e;
/*     */       } catch (Exception e) {
/* 343 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public int read()
/*     */       throws IOException
/*     */     {
/* 350 */       return this._cipherIn.read();
/*     */     }
/*     */ 
/*     */     public int read(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 356 */       return this._cipherIn.read(buffer, offset, length);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 362 */       Hessian2Input in = this._in;
/* 363 */       this._in = null;
/*     */ 
/* 365 */       if (in != null) {
/* 366 */         this._cipherIn.close();
/* 367 */         this._bodyIn.close();
/*     */ 
/* 369 */         int len = in.readInt();
/*     */ 
/* 371 */         if (len != 0) {
/* 372 */           throw new IOException("Unexpected footer");
/*     */         }
/* 374 */         in.completeEnvelope();
/*     */ 
/* 376 */         in.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class EncryptOutputStream extends OutputStream
/*     */   {
/*     */     private Hessian2Output _out;
/*     */     private Cipher _cipher;
/*     */     private OutputStream _bodyOut;
/*     */     private CipherOutputStream _cipherOut;
/*     */ 
/*     */     EncryptOutputStream(Hessian2Output out)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 206 */         this._out = out;
/*     */ 
/* 208 */         keyGen = KeyGenerator.getInstance(X509Encryption.this._algorithm);
/*     */ 
/* 210 */         if (X509Encryption.this._secureRandom != null) {
/* 211 */           keyGen.init(X509Encryption.this._secureRandom);
/*     */         }
/* 213 */         SecretKey sharedKey = keyGen.generateKey();
/*     */ 
/* 215 */         this._out = out;
/*     */ 
/* 217 */         this._out.startEnvelope(X509Encryption.class.getName());
/*     */ 
/* 219 */         PublicKey publicKey = X509Encryption.this._cert.getPublicKey();
/*     */ 
/* 221 */         byte[] encoded = publicKey.getEncoded();
/* 222 */         MessageDigest md = MessageDigest.getInstance("SHA1");
/* 223 */         md.update(encoded);
/* 224 */         byte[] fingerprint = md.digest();
/*     */ 
/* 226 */         String keyAlgorithm = publicKey.getAlgorithm();
/* 227 */         Cipher keyCipher = Cipher.getInstance(keyAlgorithm);
/* 228 */         if (X509Encryption.this._secureRandom != null)
/* 229 */           keyCipher.init(3, X509Encryption.this._cert, X509Encryption.this._secureRandom);
/*     */         else {
/* 231 */           keyCipher.init(3, X509Encryption.this._cert);
/*     */         }
/* 233 */         byte[] encKey = keyCipher.wrap(sharedKey);
/*     */ 
/* 235 */         this._out.writeInt(4);
/*     */ 
/* 237 */         this._out.writeString("algorithm");
/* 238 */         this._out.writeString(X509Encryption.this._algorithm);
/* 239 */         this._out.writeString("fingerprint");
/* 240 */         this._out.writeBytes(fingerprint);
/* 241 */         this._out.writeString("key-algorithm");
/* 242 */         this._out.writeString(keyAlgorithm);
/* 243 */         this._out.writeString("key");
/* 244 */         this._out.writeBytes(encKey);
/*     */ 
/* 246 */         this._bodyOut = this._out.getBytesOutputStream();
/*     */ 
/* 248 */         this._cipher = Cipher.getInstance(X509Encryption.this._algorithm);
/* 249 */         if (X509Encryption.this._secureRandom != null)
/* 250 */           this._cipher.init(1, sharedKey, X509Encryption.this._secureRandom);
/*     */         else {
/* 252 */           this._cipher.init(1, sharedKey);
/*     */         }
/* 254 */         this._cipherOut = new CipherOutputStream(this._bodyOut, this._cipher);
/*     */       }
/*     */       catch (RuntimeException e)
/*     */       {
/*     */         KeyGenerator keyGen;
/* 256 */         throw e;
/*     */       } catch (IOException e) {
/* 258 */         throw e;
/*     */       } catch (Exception e) {
/* 260 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(int ch)
/*     */       throws IOException
/*     */     {
/* 267 */       this._cipherOut.write(ch);
/*     */     }
/*     */ 
/*     */     public void write(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 273 */       this._cipherOut.write(buffer, offset, length);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 279 */       Hessian2Output out = this._out;
/* 280 */       this._out = null;
/*     */ 
/* 282 */       if (out != null) {
/* 283 */         this._cipherOut.close();
/* 284 */         this._bodyOut.close();
/*     */ 
/* 286 */         out.writeInt(0);
/* 287 */         out.completeEnvelope();
/* 288 */         out.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.security.X509Encryption
 * JD-Core Version:    0.6.2
 */