/*     */ package com.alibaba.com.caucho.hessian.security;
/*     */ 
/*     */ import com.alibaba.com.caucho.hessian.io.Hessian2Input;
/*     */ import com.alibaba.com.caucho.hessian.io.Hessian2Output;
/*     */ import com.alibaba.com.caucho.hessian.io.HessianEnvelope;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.Key;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.CipherInputStream;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.SecretKey;
/*     */ 
/*     */ public class X509Signature extends HessianEnvelope
/*     */ {
/*  61 */   private String _algorithm = "HmacSHA256";
/*     */   private X509Certificate _cert;
/*     */   private PrivateKey _privateKey;
/*     */   private SecureRandom _secureRandom;
/*     */ 
/*     */   public void setAlgorithm(String algorithm)
/*     */   {
/*  75 */     if (algorithm == null) {
/*  76 */       throw new NullPointerException();
/*     */     }
/*  78 */     this._algorithm = algorithm;
/*     */   }
/*     */ 
/*     */   public String getAlgorithm()
/*     */   {
/*  86 */     return this._algorithm;
/*     */   }
/*     */ 
/*     */   public X509Certificate getCertificate()
/*     */   {
/*  94 */     return this._cert;
/*     */   }
/*     */ 
/*     */   public void setCertificate(X509Certificate cert)
/*     */   {
/* 102 */     this._cert = cert;
/*     */   }
/*     */ 
/*     */   public PrivateKey getPrivateKey()
/*     */   {
/* 110 */     return this._privateKey;
/*     */   }
/*     */ 
/*     */   public void setPrivateKey(PrivateKey key)
/*     */   {
/* 118 */     this._privateKey = key;
/*     */   }
/*     */ 
/*     */   public SecureRandom getSecureRandom()
/*     */   {
/* 126 */     return this._secureRandom;
/*     */   }
/*     */ 
/*     */   public void setSecureRandom(SecureRandom random)
/*     */   {
/* 134 */     this._secureRandom = random;
/*     */   }
/*     */ 
/*     */   public Hessian2Output wrap(Hessian2Output out)
/*     */     throws IOException
/*     */   {
/* 140 */     if (this._privateKey == null) {
/* 141 */       throw new IOException("X509Signature.wrap requires a private key");
/*     */     }
/* 143 */     if (this._cert == null) {
/* 144 */       throw new IOException("X509Signature.wrap requires a certificate");
/*     */     }
/* 146 */     OutputStream os = new SignatureOutputStream(out);
/*     */ 
/* 148 */     Hessian2Output filterOut = new Hessian2Output(os);
/*     */ 
/* 150 */     filterOut.setCloseStreamOnClose(true);
/*     */ 
/* 152 */     return filterOut;
/*     */   }
/*     */ 
/*     */   public Hessian2Input unwrap(Hessian2Input in)
/*     */     throws IOException
/*     */   {
/* 158 */     if (this._cert == null) {
/* 159 */       throw new IOException("X509Signature.unwrap requires a certificate");
/*     */     }
/* 161 */     int version = in.readEnvelope();
/*     */ 
/* 163 */     String method = in.readMethod();
/*     */ 
/* 165 */     if (!method.equals(getClass().getName())) {
/* 166 */       throw new IOException("expected hessian Envelope method '" + getClass().getName() + "' at '" + method + "'");
/*     */     }
/*     */ 
/* 169 */     return unwrapHeaders(in);
/*     */   }
/*     */ 
/*     */   public Hessian2Input unwrapHeaders(Hessian2Input in)
/*     */     throws IOException
/*     */   {
/* 175 */     if (this._cert == null) {
/* 176 */       throw new IOException("X509Signature.unwrap requires a certificate");
/*     */     }
/* 178 */     InputStream is = new SignatureInputStream(in);
/*     */ 
/* 180 */     Hessian2Input filter = new Hessian2Input(is);
/*     */ 
/* 182 */     filter.setCloseStreamOnClose(true);
/*     */ 
/* 184 */     return filter;
/*     */   }
/*     */ 
/*     */   class SignatureInputStream extends InputStream
/*     */   {
/*     */     private Hessian2Input _in;
/*     */     private Mac _mac;
/*     */     private InputStream _bodyIn;
/*     */     private CipherInputStream _cipherIn;
/*     */ 
/*     */     SignatureInputStream(Hessian2Input in)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 290 */         this._in = in;
/*     */ 
/* 292 */         fingerprint = null;
/* 293 */         String keyAlgorithm = null;
/* 294 */         String algorithm = null;
/* 295 */         byte[] encKey = null;
/*     */ 
/* 297 */         int len = in.readInt();
/*     */ 
/* 299 */         for (int i = 0; i < len; i++) {
/* 300 */           String header = in.readString();
/*     */ 
/* 302 */           if ("fingerprint".equals(header))
/* 303 */             fingerprint = in.readBytes();
/* 304 */           else if ("key-algorithm".equals(header))
/* 305 */             keyAlgorithm = in.readString();
/* 306 */           else if ("algorithm".equals(header))
/* 307 */             algorithm = in.readString();
/* 308 */           else if ("key".equals(header))
/* 309 */             encKey = in.readBytes();
/*     */           else {
/* 311 */             throw new IOException("'" + header + "' is an unexpected header");
/*     */           }
/*     */         }
/* 314 */         Cipher keyCipher = Cipher.getInstance(keyAlgorithm);
/* 315 */         keyCipher.init(4, X509Signature.this._cert);
/*     */ 
/* 317 */         Key key = keyCipher.unwrap(encKey, algorithm, 3);
/* 318 */         this._bodyIn = this._in.readInputStream();
/*     */ 
/* 320 */         this._mac = Mac.getInstance(algorithm);
/* 321 */         this._mac.init(key);
/*     */       }
/*     */       catch (RuntimeException e)
/*     */       {
/*     */         byte[] fingerprint;
/* 323 */         throw e;
/*     */       } catch (IOException e) {
/* 325 */         throw e;
/*     */       } catch (Exception e) {
/* 327 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public int read()
/*     */       throws IOException
/*     */     {
/* 334 */       int ch = this._bodyIn.read();
/*     */ 
/* 336 */       if (ch < 0) {
/* 337 */         return ch;
/*     */       }
/* 339 */       this._mac.update((byte)ch);
/*     */ 
/* 341 */       return ch;
/*     */     }
/*     */ 
/*     */     public int read(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 347 */       int len = this._bodyIn.read(buffer, offset, length);
/*     */ 
/* 349 */       if (len < 0) {
/* 350 */         return len;
/*     */       }
/* 352 */       this._mac.update(buffer, offset, len);
/*     */ 
/* 354 */       return len;
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 360 */       Hessian2Input in = this._in;
/* 361 */       this._in = null;
/*     */ 
/* 363 */       if (in != null) {
/* 364 */         this._bodyIn.close();
/*     */ 
/* 366 */         int len = in.readInt();
/* 367 */         byte[] signature = null;
/*     */ 
/* 369 */         for (int i = 0; i < len; i++) {
/* 370 */           String header = in.readString();
/*     */ 
/* 372 */           if ("signature".equals(header)) {
/* 373 */             signature = in.readBytes();
/*     */           }
/*     */         }
/* 376 */         in.completeEnvelope();
/* 377 */         in.close();
/*     */ 
/* 380 */         if (signature == null) {
/* 381 */           throw new IOException("Expected signature");
/*     */         }
/* 383 */         byte[] sig = this._mac.doFinal();
/*     */ 
/* 385 */         if (sig.length != signature.length) {
/* 386 */           throw new IOException("mismatched signature");
/*     */         }
/* 388 */         for (int i = 0; i < sig.length; i++)
/* 389 */           if (signature[i] != sig[i])
/* 390 */             throw new IOException("mismatched signature");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   class SignatureOutputStream extends OutputStream
/*     */   {
/*     */     private Hessian2Output _out;
/*     */     private OutputStream _bodyOut;
/*     */     private Mac _mac;
/*     */ 
/*     */     SignatureOutputStream(Hessian2Output out)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 196 */         keyGen = KeyGenerator.getInstance(X509Signature.this._algorithm);
/*     */ 
/* 198 */         if (X509Signature.this._secureRandom != null) {
/* 199 */           keyGen.init(X509Signature.this._secureRandom);
/*     */         }
/* 201 */         SecretKey sharedKey = keyGen.generateKey();
/*     */ 
/* 203 */         this._out = out;
/*     */ 
/* 205 */         this._out.startEnvelope(X509Signature.class.getName());
/*     */ 
/* 207 */         PublicKey publicKey = X509Signature.this._cert.getPublicKey();
/*     */ 
/* 209 */         byte[] encoded = publicKey.getEncoded();
/* 210 */         MessageDigest md = MessageDigest.getInstance("SHA1");
/* 211 */         md.update(encoded);
/* 212 */         byte[] fingerprint = md.digest();
/*     */ 
/* 214 */         String keyAlgorithm = X509Signature.this._privateKey.getAlgorithm();
/* 215 */         Cipher keyCipher = Cipher.getInstance(keyAlgorithm);
/* 216 */         keyCipher.init(3, X509Signature.this._privateKey);
/*     */ 
/* 218 */         byte[] encKey = keyCipher.wrap(sharedKey);
/*     */ 
/* 220 */         this._out.writeInt(4);
/* 221 */         this._out.writeString("algorithm");
/* 222 */         this._out.writeString(X509Signature.this._algorithm);
/* 223 */         this._out.writeString("fingerprint");
/* 224 */         this._out.writeBytes(fingerprint);
/* 225 */         this._out.writeString("key-algorithm");
/* 226 */         this._out.writeString(keyAlgorithm);
/* 227 */         this._out.writeString("key");
/* 228 */         this._out.writeBytes(encKey);
/*     */ 
/* 230 */         this._mac = Mac.getInstance(X509Signature.this._algorithm);
/* 231 */         this._mac.init(sharedKey);
/*     */ 
/* 233 */         this._bodyOut = this._out.getBytesOutputStream();
/*     */       }
/*     */       catch (RuntimeException e)
/*     */       {
/*     */         KeyGenerator keyGen;
/* 235 */         throw e;
/*     */       } catch (IOException e) {
/* 237 */         throw e;
/*     */       } catch (Exception e) {
/* 239 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(int ch)
/*     */       throws IOException
/*     */     {
/* 246 */       this._bodyOut.write(ch);
/* 247 */       this._mac.update((byte)ch);
/*     */     }
/*     */ 
/*     */     public void write(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 253 */       this._bodyOut.write(buffer, offset, length);
/* 254 */       this._mac.update(buffer, offset, length);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 260 */       Hessian2Output out = this._out;
/* 261 */       this._out = null;
/*     */ 
/* 263 */       if (out == null) {
/* 264 */         return;
/*     */       }
/* 266 */       this._bodyOut.close();
/*     */ 
/* 268 */       byte[] sig = this._mac.doFinal();
/*     */ 
/* 270 */       out.writeInt(1);
/* 271 */       out.writeString("signature");
/* 272 */       out.writeBytes(sig);
/*     */ 
/* 274 */       out.completeEnvelope();
/* 275 */       out.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.security.X509Signature
 * JD-Core Version:    0.6.2
 */