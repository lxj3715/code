/*     */ package com.alibaba.com.caucho.hessian.util;
/*     */ 
/*     */ public class IdentityIntMap
/*     */ {
/*     */   public static final int NULL = -559038737;
/*  65 */   private static final Object DELETED = new Object();
/*     */   private Object[] _keys;
/*     */   private int[] _values;
/*     */   private int _size;
/*     */   private int _mask;
/*     */ 
/*     */   public IdentityIntMap()
/*     */   {
/*  78 */     this._keys = new Object[256];
/*  79 */     this._values = new int[256];
/*     */ 
/*  81 */     this._mask = (this._keys.length - 1);
/*  82 */     this._size = 0;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  90 */     Object[] keys = this._keys;
/*  91 */     int[] values = this._values;
/*     */ 
/*  93 */     for (int i = keys.length - 1; i >= 0; i--) {
/*  94 */       keys[i] = null;
/*  95 */       values[i] = 0;
/*     */     }
/*     */ 
/*  98 */     this._size = 0;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 105 */     return this._size;
/*     */   }
/*     */ 
/*     */   public int get(Object key)
/*     */   {
/* 113 */     int mask = this._mask;
/* 114 */     int hash = System.identityHashCode(key) % mask & mask;
/*     */ 
/* 116 */     Object[] keys = this._keys;
/*     */     while (true)
/*     */     {
/* 119 */       Object mapKey = keys[hash];
/*     */ 
/* 121 */       if (mapKey == null)
/* 122 */         return -559038737;
/* 123 */       if (mapKey == key) {
/* 124 */         return this._values[hash];
/*     */       }
/* 126 */       hash = (hash + 1) % mask;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void resize(int newSize)
/*     */   {
/* 135 */     Object[] newKeys = new Object[newSize];
/* 136 */     int[] newValues = new int[newSize];
/*     */ 
/* 138 */     int mask = this._mask = newKeys.length - 1;
/*     */ 
/* 140 */     Object[] keys = this._keys;
/* 141 */     int[] values = this._values;
/*     */ 
/* 143 */     for (int i = keys.length - 1; i >= 0; i--) {
/* 144 */       Object key = keys[i];
/*     */ 
/* 146 */       if ((key != null) && (key != DELETED))
/*     */       {
/* 149 */         int hash = System.identityHashCode(key) % mask & mask;
/*     */         while (true)
/*     */         {
/* 152 */           if (newKeys[hash] == null) {
/* 153 */             newKeys[hash] = key;
/* 154 */             newValues[hash] = values[i];
/* 155 */             break;
/*     */           }
/*     */ 
/* 158 */           hash = (hash + 1) % mask;
/*     */         }
/*     */       }
/*     */     }
/* 162 */     this._keys = newKeys;
/* 163 */     this._values = newValues;
/*     */   }
/*     */ 
/*     */   public int put(Object key, int value)
/*     */   {
/* 171 */     int mask = this._mask;
/* 172 */     int hash = System.identityHashCode(key) % mask & mask;
/*     */ 
/* 174 */     Object[] keys = this._keys;
/*     */     while (true)
/*     */     {
/* 177 */       Object testKey = keys[hash];
/*     */ 
/* 179 */       if ((testKey == null) || (testKey == DELETED)) {
/* 180 */         keys[hash] = key;
/* 181 */         this._values[hash] = value;
/*     */ 
/* 183 */         this._size += 1;
/*     */ 
/* 185 */         if (keys.length <= 4 * this._size) {
/* 186 */           resize(4 * keys.length);
/*     */         }
/* 188 */         return -559038737;
/*     */       }
/* 190 */       if (key == testKey) break;
/* 191 */       hash = (hash + 1) % mask;
/*     */     }
/*     */ 
/* 196 */     int old = this._values[hash];
/*     */ 
/* 198 */     this._values[hash] = value;
/*     */ 
/* 200 */     return old;
/*     */   }
/*     */ 
/*     */   public int remove(Object key)
/*     */   {
/* 210 */     int mask = this._mask;
/* 211 */     int hash = System.identityHashCode(key) % mask & mask;
/*     */     while (true)
/*     */     {
/* 214 */       Object mapKey = this._keys[hash];
/*     */ 
/* 216 */       if (mapKey == null)
/* 217 */         return -559038737;
/* 218 */       if (mapKey == key) {
/* 219 */         this._keys[hash] = DELETED;
/*     */ 
/* 221 */         this._size -= 1;
/*     */ 
/* 223 */         return this._values[hash];
/*     */       }
/*     */ 
/* 226 */       hash = (hash + 1) % mask;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 232 */     StringBuffer sbuf = new StringBuffer();
/*     */ 
/* 234 */     sbuf.append("IntMap[");
/* 235 */     boolean isFirst = true;
/*     */ 
/* 237 */     for (int i = 0; i <= this._mask; i++) {
/* 238 */       if ((this._keys[i] != null) && (this._keys[i] != DELETED)) {
/* 239 */         if (!isFirst) {
/* 240 */           sbuf.append(", ");
/*     */         }
/* 242 */         isFirst = false;
/* 243 */         sbuf.append(this._keys[i]);
/* 244 */         sbuf.append(":");
/* 245 */         sbuf.append(this._values[i]);
/*     */       }
/*     */     }
/* 248 */     sbuf.append("]");
/*     */ 
/* 250 */     return sbuf.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.com.caucho.hessian.util.IdentityIntMap
 * JD-Core Version:    0.6.2
 */