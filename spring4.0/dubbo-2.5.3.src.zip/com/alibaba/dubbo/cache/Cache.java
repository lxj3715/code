package com.alibaba.dubbo.cache;

public abstract interface Cache
{
  public abstract void put(Object paramObject1, Object paramObject2);

  public abstract Object get(Object paramObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.cache.Cache
 * JD-Core Version:    0.6.2
 */