package com.alibaba.dubbo.cache;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;

@SPI("lru")
public abstract interface CacheFactory
{
  @Adaptive({"cache"})
  public abstract Cache getCache(URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.cache.CacheFactory
 * JD-Core Version:    0.6.2
 */