/*    */ package com.alibaba.dubbo.cache.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.cache.Cache;
/*    */ import com.alibaba.dubbo.cache.CacheFactory;
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*    */ import com.alibaba.dubbo.common.utils.StringUtils;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.RpcResult;
/*    */ 
/*    */ @Activate(group={"consumer", "provider"}, value={"cache"})
/*    */ public class CacheFilter
/*    */   implements Filter
/*    */ {
/*    */   private CacheFactory cacheFactory;
/*    */ 
/*    */   public void setCacheFactory(CacheFactory cacheFactory)
/*    */   {
/* 42 */     this.cacheFactory = cacheFactory;
/*    */   }
/*    */ 
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
/* 46 */     if ((this.cacheFactory != null) && (ConfigUtils.isNotEmpty(invoker.getUrl().getMethodParameter(invocation.getMethodName(), "cache")))) {
/* 47 */       Cache cache = this.cacheFactory.getCache(invoker.getUrl().addParameter("method", invocation.getMethodName()));
/* 48 */       if (cache != null) {
/* 49 */         String key = StringUtils.toArgumentString(invocation.getArguments());
/* 50 */         if ((cache != null) && (key != null)) {
/* 51 */           Object value = cache.get(key);
/* 52 */           if (value != null) {
/* 53 */             return new RpcResult(value);
/*    */           }
/* 55 */           Result result = invoker.invoke(invocation);
/* 56 */           if (!result.hasException()) {
/* 57 */             cache.put(key, result.getValue());
/*    */           }
/* 59 */           return result;
/*    */         }
/*    */       }
/*    */     }
/* 63 */     return invoker.invoke(invocation);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.cache.filter.CacheFilter
 * JD-Core Version:    0.6.2
 */