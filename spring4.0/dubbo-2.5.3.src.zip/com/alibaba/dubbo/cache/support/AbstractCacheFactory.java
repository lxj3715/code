/*    */ package com.alibaba.dubbo.cache.support;
/*    */ 
/*    */ import com.alibaba.dubbo.cache.Cache;
/*    */ import com.alibaba.dubbo.cache.CacheFactory;
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ public abstract class AbstractCacheFactory
/*    */   implements CacheFactory
/*    */ {
/* 32 */   private final ConcurrentMap<String, Cache> caches = new ConcurrentHashMap();
/*    */ 
/*    */   public Cache getCache(URL url) {
/* 35 */     String key = url.toFullString();
/* 36 */     Cache cache = (Cache)this.caches.get(key);
/* 37 */     if (cache == null) {
/* 38 */       this.caches.put(key, createCache(url));
/* 39 */       cache = (Cache)this.caches.get(key);
/*    */     }
/* 41 */     return cache;
/*    */   }
/*    */ 
/*    */   protected abstract Cache createCache(URL paramURL);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.cache.support.AbstractCacheFactory
 * JD-Core Version:    0.6.2
 */