/*    */ package com.alibaba.dubbo.cache.support.jcache;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import javax.cache.CacheBuilder;
/*    */ import javax.cache.CacheManager;
/*    */ import javax.cache.Caching;
/*    */ 
/*    */ public class JCache
/*    */   implements com.alibaba.dubbo.cache.Cache
/*    */ {
/*    */   private final javax.cache.Cache<Object, Object> store;
/*    */ 
/*    */   public JCache(URL url)
/*    */   {
/* 35 */     String type = url.getParameter("jcache");
/* 36 */     CacheManager cacheManager = (type == null) || (type.length() == 0) ? Caching.getCacheManager() : Caching.getCacheManager(type);
/* 37 */     CacheBuilder cacheBuilder = cacheManager.createCacheBuilder(url.getServiceKey());
/* 38 */     this.store = cacheBuilder.build();
/*    */   }
/*    */ 
/*    */   public void put(Object key, Object value) {
/* 42 */     this.store.put(key, value);
/*    */   }
/*    */ 
/*    */   public Object get(Object key) {
/* 46 */     return this.store.get(key);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.cache.support.jcache.JCache
 * JD-Core Version:    0.6.2
 */