/*    */ package com.alibaba.dubbo.cache.support.threadlocal;
/*    */ 
/*    */ import com.alibaba.dubbo.cache.Cache;
/*    */ import com.alibaba.dubbo.cache.support.AbstractCacheFactory;
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ 
/*    */ public class ThreadLocalCacheFactory extends AbstractCacheFactory
/*    */ {
/*    */   protected Cache createCache(URL url)
/*    */   {
/* 30 */     return new ThreadLocalCache(url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.cache.support.threadlocal.ThreadLocalCacheFactory
 * JD-Core Version:    0.6.2
 */