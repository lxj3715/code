/*     */ package com.alibaba.dubbo.common;
/*     */ 
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ @Deprecated
/*     */ public class Parameters
/*     */ {
/*     */   private final Map<String, String> parameters;
/*  38 */   protected static final Logger logger = LoggerFactory.getLogger(Parameters.class);
/*     */ 
/*     */   public Parameters(String[] pairs) {
/*  41 */     this(toMap(pairs));
/*     */   }
/*     */ 
/*     */   public Parameters(Map<String, String> parameters) {
/*  45 */     this.parameters = Collections.unmodifiableMap(parameters != null ? new HashMap(parameters) : new HashMap(0));
/*     */   }
/*     */ 
/*     */   private static Map<String, String> toMap(String[] pairs) {
/*  49 */     Map parameters = new HashMap();
/*  50 */     if (pairs.length > 0) {
/*  51 */       if (pairs.length % 2 != 0) {
/*  52 */         throw new IllegalArgumentException("pairs must be even.");
/*     */       }
/*  54 */       for (int i = 0; i < pairs.length; i += 2) {
/*  55 */         parameters.put(pairs[i], pairs[(i + 1)]);
/*     */       }
/*     */     }
/*  58 */     return parameters;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParameters() {
/*  62 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public <T> T getExtension(Class<T> type, String key) {
/*  66 */     String name = getParameter(key);
/*  67 */     return ExtensionLoader.getExtensionLoader(type).getExtension(name);
/*     */   }
/*     */ 
/*     */   public <T> T getExtension(Class<T> type, String key, String defaultValue) {
/*  71 */     String name = getParameter(key, defaultValue);
/*  72 */     return ExtensionLoader.getExtensionLoader(type).getExtension(name);
/*     */   }
/*     */ 
/*     */   public <T> T getMethodExtension(Class<T> type, String method, String key) {
/*  76 */     String name = getMethodParameter(method, key);
/*  77 */     return ExtensionLoader.getExtensionLoader(type).getExtension(name);
/*     */   }
/*     */ 
/*     */   public <T> T getMethodExtension(Class<T> type, String method, String key, String defaultValue) {
/*  81 */     String name = getMethodParameter(method, key, defaultValue);
/*  82 */     return ExtensionLoader.getExtensionLoader(type).getExtension(name);
/*     */   }
/*     */ 
/*     */   public String getDecodedParameter(String key) {
/*  86 */     return getDecodedParameter(key, null);
/*     */   }
/*     */ 
/*     */   public String getDecodedParameter(String key, String defaultValue) {
/*  90 */     String value = getParameter(key, defaultValue);
/*  91 */     if ((value != null) && (value.length() > 0)) {
/*     */       try {
/*  93 */         value = URLDecoder.decode(value, "UTF-8");
/*     */       } catch (UnsupportedEncodingException e) {
/*  95 */         logger.error(e.getMessage(), e);
/*     */       }
/*     */     }
/*  98 */     return value;
/*     */   }
/*     */ 
/*     */   public String getParameter(String key) {
/* 102 */     String value = (String)this.parameters.get(key);
/* 103 */     if ((value == null) || (value.length() == 0)) {
/* 104 */       value = (String)this.parameters.get("." + key);
/*     */     }
/* 106 */     if ((value == null) || (value.length() == 0)) {
/* 107 */       value = (String)this.parameters.get("default." + key);
/*     */     }
/* 109 */     if ((value == null) || (value.length() == 0)) {
/* 110 */       value = (String)this.parameters.get(".default." + key);
/*     */     }
/* 112 */     return value;
/*     */   }
/*     */ 
/*     */   public String getParameter(String key, String defaultValue) {
/* 116 */     String value = getParameter(key);
/* 117 */     if ((value == null) || (value.length() == 0)) {
/* 118 */       return defaultValue;
/*     */     }
/* 120 */     return value;
/*     */   }
/*     */ 
/*     */   public int getIntParameter(String key) {
/* 124 */     String value = getParameter(key);
/* 125 */     if ((value == null) || (value.length() == 0)) {
/* 126 */       return 0;
/*     */     }
/* 128 */     return Integer.parseInt(value);
/*     */   }
/*     */ 
/*     */   public int getIntParameter(String key, int defaultValue) {
/* 132 */     String value = getParameter(key);
/* 133 */     if ((value == null) || (value.length() == 0)) {
/* 134 */       return defaultValue;
/*     */     }
/* 136 */     return Integer.parseInt(value);
/*     */   }
/*     */ 
/*     */   public int getPositiveIntParameter(String key, int defaultValue) {
/* 140 */     if (defaultValue <= 0) {
/* 141 */       throw new IllegalArgumentException("defaultValue <= 0");
/*     */     }
/* 143 */     String value = getParameter(key);
/* 144 */     if ((value == null) || (value.length() == 0)) {
/* 145 */       return defaultValue;
/*     */     }
/* 147 */     int i = Integer.parseInt(value);
/* 148 */     if (i > 0) {
/* 149 */       return i;
/*     */     }
/* 151 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   public boolean getBooleanParameter(String key) {
/* 155 */     String value = getParameter(key);
/* 156 */     if ((value == null) || (value.length() == 0)) {
/* 157 */       return false;
/*     */     }
/* 159 */     return Boolean.parseBoolean(value);
/*     */   }
/*     */ 
/*     */   public boolean getBooleanParameter(String key, boolean defaultValue) {
/* 163 */     String value = getParameter(key);
/* 164 */     if ((value == null) || (value.length() == 0)) {
/* 165 */       return defaultValue;
/*     */     }
/* 167 */     return Boolean.parseBoolean(value);
/*     */   }
/*     */ 
/*     */   public boolean hasParamter(String key) {
/* 171 */     String value = getParameter(key);
/* 172 */     return (value != null) && (value.length() > 0);
/*     */   }
/*     */ 
/*     */   public String getMethodParameter(String method, String key) {
/* 176 */     String value = (String)this.parameters.get(method + "." + key);
/* 177 */     if ((value == null) || (value.length() == 0)) {
/* 178 */       value = (String)this.parameters.get("." + method + "." + key);
/*     */     }
/* 180 */     if ((value == null) || (value.length() == 0)) {
/* 181 */       return getParameter(key);
/*     */     }
/* 183 */     return value;
/*     */   }
/*     */ 
/*     */   public String getMethodParameter(String method, String key, String defaultValue) {
/* 187 */     String value = getMethodParameter(method, key);
/* 188 */     if ((value == null) || (value.length() == 0)) {
/* 189 */       return defaultValue;
/*     */     }
/* 191 */     return value;
/*     */   }
/*     */ 
/*     */   public int getMethodIntParameter(String method, String key) {
/* 195 */     String value = getMethodParameter(method, key);
/* 196 */     if ((value == null) || (value.length() == 0)) {
/* 197 */       return 0;
/*     */     }
/* 199 */     return Integer.parseInt(value);
/*     */   }
/*     */ 
/*     */   public int getMethodIntParameter(String method, String key, int defaultValue) {
/* 203 */     String value = getMethodParameter(method, key);
/* 204 */     if ((value == null) || (value.length() == 0)) {
/* 205 */       return defaultValue;
/*     */     }
/* 207 */     return Integer.parseInt(value);
/*     */   }
/*     */ 
/*     */   public int getMethodPositiveIntParameter(String method, String key, int defaultValue) {
/* 211 */     if (defaultValue <= 0) {
/* 212 */       throw new IllegalArgumentException("defaultValue <= 0");
/*     */     }
/* 214 */     String value = getMethodParameter(method, key);
/* 215 */     if ((value == null) || (value.length() == 0)) {
/* 216 */       return defaultValue;
/*     */     }
/* 218 */     int i = Integer.parseInt(value);
/* 219 */     if (i > 0) {
/* 220 */       return i;
/*     */     }
/* 222 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   public boolean getMethodBooleanParameter(String method, String key) {
/* 226 */     String value = getMethodParameter(method, key);
/* 227 */     if ((value == null) || (value.length() == 0)) {
/* 228 */       return false;
/*     */     }
/* 230 */     return Boolean.parseBoolean(value);
/*     */   }
/*     */ 
/*     */   public boolean getMethodBooleanParameter(String method, String key, boolean defaultValue) {
/* 234 */     String value = getMethodParameter(method, key);
/* 235 */     if ((value == null) || (value.length() == 0)) {
/* 236 */       return defaultValue;
/*     */     }
/* 238 */     return Boolean.parseBoolean(value);
/*     */   }
/*     */ 
/*     */   public boolean hasMethodParamter(String method, String key) {
/* 242 */     String value = getMethodParameter(method, key);
/* 243 */     return (value != null) && (value.length() > 0);
/*     */   }
/*     */ 
/*     */   public static Parameters parseParameters(String query) {
/* 247 */     return new Parameters(StringUtils.parseQueryString(query));
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o) {
/* 251 */     return this.parameters.equals(o);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 255 */     return this.parameters.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 260 */     return StringUtils.toQueryString(getParameters());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.Parameters
 * JD-Core Version:    0.6.2
 */