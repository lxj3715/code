/*      */ package com.alibaba.dubbo.common;
/*      */ 
/*      */ import com.alibaba.dubbo.common.utils.CollectionUtils;
/*      */ import com.alibaba.dubbo.common.utils.NetUtils;
/*      */ import com.alibaba.dubbo.common.utils.StringUtils;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URLDecoder;
/*      */ import java.net.URLEncoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ public final class URL
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = -1985165475234910535L;
/*      */   private final String protocol;
/*      */   private final String username;
/*      */   private final String password;
/*      */   private final String host;
/*      */   private final int port;
/*      */   private final String path;
/*      */   private final Map<String, String> parameters;
/*      */   private volatile transient Map<String, Number> numbers;
/*      */   private volatile transient Map<String, URL> urls;
/*      */   private volatile transient String ip;
/*      */   private volatile transient String full;
/*      */   private volatile transient String identity;
/*      */   private volatile transient String parameter;
/*      */   private volatile transient String string;
/*      */ 
/*      */   protected URL()
/*      */   {
/*  107 */     this.protocol = null;
/*  108 */     this.username = null;
/*  109 */     this.password = null;
/*  110 */     this.host = null;
/*  111 */     this.port = 0;
/*  112 */     this.path = null;
/*  113 */     this.parameters = null;
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String host, int port) {
/*  117 */     this(protocol, null, null, host, port, null, (Map)null);
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String host, int port, String[] pairs) {
/*  121 */     this(protocol, null, null, host, port, null, CollectionUtils.toStringMap(pairs));
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String host, int port, Map<String, String> parameters) {
/*  125 */     this(protocol, null, null, host, port, null, parameters);
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String host, int port, String path) {
/*  129 */     this(protocol, null, null, host, port, path, (Map)null);
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String host, int port, String path, String[] pairs) {
/*  133 */     this(protocol, null, null, host, port, path, CollectionUtils.toStringMap(pairs));
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String host, int port, String path, Map<String, String> parameters) {
/*  137 */     this(protocol, null, null, host, port, path, parameters);
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String username, String password, String host, int port, String path) {
/*  141 */     this(protocol, username, password, host, port, path, (Map)null);
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String username, String password, String host, int port, String path, String[] pairs) {
/*  145 */     this(protocol, username, password, host, port, path, CollectionUtils.toStringMap(pairs));
/*      */   }
/*      */ 
/*      */   public URL(String protocol, String username, String password, String host, int port, String path, Map<String, String> parameters) {
/*  149 */     if (((username == null) || (username.length() == 0)) && (password != null) && (password.length() > 0))
/*      */     {
/*  151 */       throw new IllegalArgumentException("Invalid url, password without username!");
/*      */     }
/*  153 */     this.protocol = protocol;
/*  154 */     this.username = username;
/*  155 */     this.password = password;
/*  156 */     this.host = host;
/*  157 */     this.port = (port < 0 ? 0 : port);
/*  158 */     this.path = path;
/*      */ 
/*  160 */     while ((path != null) && (path.startsWith("/"))) {
/*  161 */       path = path.substring(1);
/*      */     }
/*  163 */     if (parameters == null)
/*  164 */       parameters = new HashMap();
/*      */     else {
/*  166 */       parameters = new HashMap(parameters);
/*      */     }
/*  168 */     this.parameters = Collections.unmodifiableMap(parameters);
/*      */   }
/*      */ 
/*      */   public static URL valueOf(String url)
/*      */   {
/*  179 */     if ((url == null) || ((url = url.trim()).length() == 0)) {
/*  180 */       throw new IllegalArgumentException("url == null");
/*      */     }
/*  182 */     String protocol = null;
/*  183 */     String username = null;
/*  184 */     String password = null;
/*  185 */     String host = null;
/*  186 */     int port = 0;
/*  187 */     String path = null;
/*  188 */     Map parameters = null;
/*  189 */     int i = url.indexOf("?");
/*  190 */     if (i >= 0) {
/*  191 */       String[] parts = url.substring(i + 1).split("\\&");
/*  192 */       parameters = new HashMap();
/*  193 */       for (String part : parts) {
/*  194 */         part = part.trim();
/*  195 */         if (part.length() > 0) {
/*  196 */           int j = part.indexOf('=');
/*  197 */           if (j >= 0)
/*  198 */             parameters.put(part.substring(0, j), part.substring(j + 1));
/*      */           else {
/*  200 */             parameters.put(part, part);
/*      */           }
/*      */         }
/*      */       }
/*  204 */       url = url.substring(0, i);
/*      */     }
/*  206 */     i = url.indexOf("://");
/*  207 */     if (i >= 0) {
/*  208 */       if (i == 0) throw new IllegalStateException("url missing protocol: \"" + url + "\"");
/*  209 */       protocol = url.substring(0, i);
/*  210 */       url = url.substring(i + 3);
/*      */     }
/*      */     else
/*      */     {
/*  214 */       i = url.indexOf(":/");
/*  215 */       if (i >= 0) {
/*  216 */         if (i == 0) throw new IllegalStateException("url missing protocol: \"" + url + "\"");
/*  217 */         protocol = url.substring(0, i);
/*  218 */         url = url.substring(i + 1);
/*      */       }
/*      */     }
/*      */ 
/*  222 */     i = url.indexOf("/");
/*  223 */     if (i >= 0) {
/*  224 */       path = url.substring(i + 1);
/*  225 */       url = url.substring(0, i);
/*      */     }
/*  227 */     i = url.indexOf("@");
/*  228 */     if (i >= 0) {
/*  229 */       username = url.substring(0, i);
/*  230 */       int j = username.indexOf(":");
/*  231 */       if (j >= 0) {
/*  232 */         password = username.substring(j + 1);
/*  233 */         username = username.substring(0, j);
/*      */       }
/*  235 */       url = url.substring(i + 1);
/*      */     }
/*  237 */     i = url.indexOf(":");
/*  238 */     if ((i >= 0) && (i < url.length() - 1)) {
/*  239 */       port = Integer.parseInt(url.substring(i + 1));
/*  240 */       url = url.substring(0, i);
/*      */     }
/*  242 */     if (url.length() > 0) host = url;
/*  243 */     return new URL(protocol, username, password, host, port, path, parameters);
/*      */   }
/*      */ 
/*      */   public String getProtocol() {
/*  247 */     return this.protocol;
/*      */   }
/*      */ 
/*      */   public String getUsername() {
/*  251 */     return this.username;
/*      */   }
/*      */ 
/*      */   public String getPassword() {
/*  255 */     return this.password;
/*      */   }
/*      */ 
/*      */   public String getAuthority() {
/*  259 */     if (((this.username == null) || (this.username.length() == 0)) && ((this.password == null) || (this.password.length() == 0)))
/*      */     {
/*  261 */       return null;
/*      */     }
/*  263 */     return (this.username == null ? "" : this.username) + ":" + (this.password == null ? "" : this.password);
/*      */   }
/*      */ 
/*      */   public String getHost()
/*      */   {
/*  268 */     return this.host;
/*      */   }
/*      */ 
/*      */   public String getIp()
/*      */   {
/*  283 */     if (this.ip == null) {
/*  284 */       this.ip = NetUtils.getIpByHost(this.host);
/*      */     }
/*  286 */     return this.ip;
/*      */   }
/*      */ 
/*      */   public int getPort() {
/*  290 */     return this.port;
/*      */   }
/*      */ 
/*      */   public int getPort(int defaultPort) {
/*  294 */     return this.port <= 0 ? defaultPort : this.port;
/*      */   }
/*      */ 
/*      */   public String getAddress() {
/*  298 */     return this.host + ":" + this.port;
/*      */   }
/*      */ 
/*      */   public String getBackupAddress() {
/*  302 */     return getBackupAddress(0);
/*      */   }
/*      */ 
/*      */   public String getBackupAddress(int defaultPort) {
/*  306 */     StringBuilder address = new StringBuilder(appendDefaultPort(getAddress(), defaultPort));
/*  307 */     String[] backups = getParameter("backup", new String[0]);
/*  308 */     if ((backups != null) && (backups.length > 0)) {
/*  309 */       for (String backup : backups) {
/*  310 */         address.append(",");
/*  311 */         address.append(appendDefaultPort(backup, defaultPort));
/*      */       }
/*      */     }
/*  314 */     return address.toString();
/*      */   }
/*      */ 
/*      */   public List<URL> getBackupUrls() {
/*  318 */     List urls = new ArrayList();
/*  319 */     urls.add(this);
/*  320 */     String[] backups = getParameter("backup", new String[0]);
/*  321 */     if ((backups != null) && (backups.length > 0)) {
/*  322 */       for (String backup : backups) {
/*  323 */         urls.add(setAddress(backup));
/*      */       }
/*      */     }
/*  326 */     return urls;
/*      */   }
/*      */ 
/*      */   private String appendDefaultPort(String address, int defaultPort) {
/*  330 */     if ((address != null) && (address.length() > 0) && (defaultPort > 0))
/*      */     {
/*  332 */       int i = address.indexOf(':');
/*  333 */       if (i < 0)
/*  334 */         return address + ":" + defaultPort;
/*  335 */       if (Integer.parseInt(address.substring(i + 1)) == 0) {
/*  336 */         return address.substring(0, i + 1) + defaultPort;
/*      */       }
/*      */     }
/*  339 */     return address;
/*      */   }
/*      */ 
/*      */   public String getPath() {
/*  343 */     return this.path;
/*      */   }
/*      */ 
/*      */   public String getAbsolutePath() {
/*  347 */     if ((this.path != null) && (!this.path.startsWith("/"))) {
/*  348 */       return "/" + this.path;
/*      */     }
/*  350 */     return this.path;
/*      */   }
/*      */ 
/*      */   public URL setProtocol(String protocol) {
/*  354 */     return new URL(protocol, this.username, this.password, this.host, this.port, this.path, getParameters());
/*      */   }
/*      */ 
/*      */   public URL setUsername(String username) {
/*  358 */     return new URL(this.protocol, username, this.password, this.host, this.port, this.path, getParameters());
/*      */   }
/*      */ 
/*      */   public URL setPassword(String password) {
/*  362 */     return new URL(this.protocol, this.username, password, this.host, this.port, this.path, getParameters());
/*      */   }
/*      */ 
/*      */   public URL setAddress(String address) {
/*  366 */     int i = address.lastIndexOf(':');
/*      */ 
/*  368 */     int port = this.port;
/*      */     String host;
/*  369 */     if (i >= 0) {
/*  370 */       String host = address.substring(0, i);
/*  371 */       port = Integer.parseInt(address.substring(i + 1));
/*      */     } else {
/*  373 */       host = address;
/*      */     }
/*  375 */     return new URL(this.protocol, this.username, this.password, host, port, this.path, getParameters());
/*      */   }
/*      */ 
/*      */   public URL setHost(String host) {
/*  379 */     return new URL(this.protocol, this.username, this.password, host, this.port, this.path, getParameters());
/*      */   }
/*      */ 
/*      */   public URL setPort(int port) {
/*  383 */     return new URL(this.protocol, this.username, this.password, this.host, port, this.path, getParameters());
/*      */   }
/*      */ 
/*      */   public URL setPath(String path) {
/*  387 */     return new URL(this.protocol, this.username, this.password, this.host, this.port, path, getParameters());
/*      */   }
/*      */ 
/*      */   public Map<String, String> getParameters() {
/*  391 */     return this.parameters;
/*      */   }
/*      */ 
/*      */   public String getParameterAndDecoded(String key) {
/*  395 */     return getParameterAndDecoded(key, null);
/*      */   }
/*      */ 
/*      */   public String getParameterAndDecoded(String key, String defaultValue) {
/*  399 */     return decode(getParameter(key, defaultValue));
/*      */   }
/*      */ 
/*      */   public String getParameter(String key) {
/*  403 */     String value = (String)this.parameters.get(key);
/*  404 */     if ((value == null) || (value.length() == 0)) {
/*  405 */       value = (String)this.parameters.get("default." + key);
/*      */     }
/*  407 */     return value;
/*      */   }
/*      */ 
/*      */   public String getParameter(String key, String defaultValue) {
/*  411 */     String value = getParameter(key);
/*  412 */     if ((value == null) || (value.length() == 0)) {
/*  413 */       return defaultValue;
/*      */     }
/*  415 */     return value;
/*      */   }
/*      */ 
/*      */   public String[] getParameter(String key, String[] defaultValue) {
/*  419 */     String value = getParameter(key);
/*  420 */     if ((value == null) || (value.length() == 0)) {
/*  421 */       return defaultValue;
/*      */     }
/*  423 */     return Constants.COMMA_SPLIT_PATTERN.split(value);
/*      */   }
/*      */ 
/*      */   private Map<String, Number> getNumbers() {
/*  427 */     if (this.numbers == null) {
/*  428 */       this.numbers = new ConcurrentHashMap();
/*      */     }
/*  430 */     return this.numbers;
/*      */   }
/*      */ 
/*      */   private Map<String, URL> getUrls() {
/*  434 */     if (this.urls == null) {
/*  435 */       this.urls = new ConcurrentHashMap();
/*      */     }
/*  437 */     return this.urls;
/*      */   }
/*      */ 
/*      */   public URL getUrlParameter(String key) {
/*  441 */     URL u = (URL)getUrls().get(key);
/*  442 */     if (u != null) {
/*  443 */       return u;
/*      */     }
/*  445 */     String value = getParameterAndDecoded(key);
/*  446 */     if ((value == null) || (value.length() == 0)) {
/*  447 */       return null;
/*      */     }
/*  449 */     u = valueOf(value);
/*  450 */     getUrls().put(key, u);
/*  451 */     return u;
/*      */   }
/*      */ 
/*      */   public double getParameter(String key, double defaultValue) {
/*  455 */     Number n = (Number)getNumbers().get(key);
/*  456 */     if (n != null) {
/*  457 */       return n.doubleValue();
/*      */     }
/*  459 */     String value = getParameter(key);
/*  460 */     if ((value == null) || (value.length() == 0)) {
/*  461 */       return defaultValue;
/*      */     }
/*  463 */     double d = Double.parseDouble(value);
/*  464 */     getNumbers().put(key, Double.valueOf(d));
/*  465 */     return d;
/*      */   }
/*      */ 
/*      */   public float getParameter(String key, float defaultValue) {
/*  469 */     Number n = (Number)getNumbers().get(key);
/*  470 */     if (n != null) {
/*  471 */       return n.floatValue();
/*      */     }
/*  473 */     String value = getParameter(key);
/*  474 */     if ((value == null) || (value.length() == 0)) {
/*  475 */       return defaultValue;
/*      */     }
/*  477 */     float f = Float.parseFloat(value);
/*  478 */     getNumbers().put(key, Float.valueOf(f));
/*  479 */     return f;
/*      */   }
/*      */ 
/*      */   public long getParameter(String key, long defaultValue) {
/*  483 */     Number n = (Number)getNumbers().get(key);
/*  484 */     if (n != null) {
/*  485 */       return n.longValue();
/*      */     }
/*  487 */     String value = getParameter(key);
/*  488 */     if ((value == null) || (value.length() == 0)) {
/*  489 */       return defaultValue;
/*      */     }
/*  491 */     long l = Long.parseLong(value);
/*  492 */     getNumbers().put(key, Long.valueOf(l));
/*  493 */     return l;
/*      */   }
/*      */ 
/*      */   public int getParameter(String key, int defaultValue) {
/*  497 */     Number n = (Number)getNumbers().get(key);
/*  498 */     if (n != null) {
/*  499 */       return n.intValue();
/*      */     }
/*  501 */     String value = getParameter(key);
/*  502 */     if ((value == null) || (value.length() == 0)) {
/*  503 */       return defaultValue;
/*      */     }
/*  505 */     int i = Integer.parseInt(value);
/*  506 */     getNumbers().put(key, Integer.valueOf(i));
/*  507 */     return i;
/*      */   }
/*      */ 
/*      */   public short getParameter(String key, short defaultValue) {
/*  511 */     Number n = (Number)getNumbers().get(key);
/*  512 */     if (n != null) {
/*  513 */       return n.shortValue();
/*      */     }
/*  515 */     String value = getParameter(key);
/*  516 */     if ((value == null) || (value.length() == 0)) {
/*  517 */       return defaultValue;
/*      */     }
/*  519 */     short s = Short.parseShort(value);
/*  520 */     getNumbers().put(key, Short.valueOf(s));
/*  521 */     return s;
/*      */   }
/*      */ 
/*      */   public byte getParameter(String key, byte defaultValue) {
/*  525 */     Number n = (Number)getNumbers().get(key);
/*  526 */     if (n != null) {
/*  527 */       return n.byteValue();
/*      */     }
/*  529 */     String value = getParameter(key);
/*  530 */     if ((value == null) || (value.length() == 0)) {
/*  531 */       return defaultValue;
/*      */     }
/*  533 */     byte b = Byte.parseByte(value);
/*  534 */     getNumbers().put(key, Byte.valueOf(b));
/*  535 */     return b;
/*      */   }
/*      */ 
/*      */   public float getPositiveParameter(String key, float defaultValue) {
/*  539 */     if (defaultValue <= 0.0F) {
/*  540 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  542 */     float value = getParameter(key, defaultValue);
/*  543 */     if (value <= 0.0F) {
/*  544 */       return defaultValue;
/*      */     }
/*  546 */     return value;
/*      */   }
/*      */ 
/*      */   public double getPositiveParameter(String key, double defaultValue) {
/*  550 */     if (defaultValue <= 0.0D) {
/*  551 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  553 */     double value = getParameter(key, defaultValue);
/*  554 */     if (value <= 0.0D) {
/*  555 */       return defaultValue;
/*      */     }
/*  557 */     return value;
/*      */   }
/*      */ 
/*      */   public long getPositiveParameter(String key, long defaultValue) {
/*  561 */     if (defaultValue <= 0L) {
/*  562 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  564 */     long value = getParameter(key, defaultValue);
/*  565 */     if (value <= 0L) {
/*  566 */       return defaultValue;
/*      */     }
/*  568 */     return value;
/*      */   }
/*      */ 
/*      */   public int getPositiveParameter(String key, int defaultValue) {
/*  572 */     if (defaultValue <= 0) {
/*  573 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  575 */     int value = getParameter(key, defaultValue);
/*  576 */     if (value <= 0) {
/*  577 */       return defaultValue;
/*      */     }
/*  579 */     return value;
/*      */   }
/*      */ 
/*      */   public short getPositiveParameter(String key, short defaultValue) {
/*  583 */     if (defaultValue <= 0) {
/*  584 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  586 */     short value = getParameter(key, defaultValue);
/*  587 */     if (value <= 0) {
/*  588 */       return defaultValue;
/*      */     }
/*  590 */     return value;
/*      */   }
/*      */ 
/*      */   public byte getPositiveParameter(String key, byte defaultValue) {
/*  594 */     if (defaultValue <= 0) {
/*  595 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  597 */     byte value = getParameter(key, defaultValue);
/*  598 */     if (value <= 0) {
/*  599 */       return defaultValue;
/*      */     }
/*  601 */     return value;
/*      */   }
/*      */ 
/*      */   public char getParameter(String key, char defaultValue) {
/*  605 */     String value = getParameter(key);
/*  606 */     if ((value == null) || (value.length() == 0)) {
/*  607 */       return defaultValue;
/*      */     }
/*  609 */     return value.charAt(0);
/*      */   }
/*      */ 
/*      */   public boolean getParameter(String key, boolean defaultValue) {
/*  613 */     String value = getParameter(key);
/*  614 */     if ((value == null) || (value.length() == 0)) {
/*  615 */       return defaultValue;
/*      */     }
/*  617 */     return Boolean.parseBoolean(value);
/*      */   }
/*      */ 
/*      */   public boolean hasParameter(String key) {
/*  621 */     String value = getParameter(key);
/*  622 */     return (value != null) && (value.length() > 0);
/*      */   }
/*      */ 
/*      */   public String getMethodParameterAndDecoded(String method, String key) {
/*  626 */     return decode(getMethodParameter(method, key));
/*      */   }
/*      */ 
/*      */   public String getMethodParameterAndDecoded(String method, String key, String defaultValue) {
/*  630 */     return decode(getMethodParameter(method, key, defaultValue));
/*      */   }
/*      */ 
/*      */   public String getMethodParameter(String method, String key) {
/*  634 */     String value = (String)this.parameters.get(method + "." + key);
/*  635 */     if ((value == null) || (value.length() == 0)) {
/*  636 */       return getParameter(key);
/*      */     }
/*  638 */     return value;
/*      */   }
/*      */ 
/*      */   public String getMethodParameter(String method, String key, String defaultValue) {
/*  642 */     String value = getMethodParameter(method, key);
/*  643 */     if ((value == null) || (value.length() == 0)) {
/*  644 */       return defaultValue;
/*      */     }
/*  646 */     return value;
/*      */   }
/*      */ 
/*      */   public double getMethodParameter(String method, String key, double defaultValue) {
/*  650 */     String methodKey = method + "." + key;
/*  651 */     Number n = (Number)getNumbers().get(methodKey);
/*  652 */     if (n != null) {
/*  653 */       return n.intValue();
/*      */     }
/*  655 */     String value = getMethodParameter(method, key);
/*  656 */     if ((value == null) || (value.length() == 0)) {
/*  657 */       return defaultValue;
/*      */     }
/*  659 */     double d = Double.parseDouble(value);
/*  660 */     getNumbers().put(methodKey, Double.valueOf(d));
/*  661 */     return d;
/*      */   }
/*      */ 
/*      */   public float getMethodParameter(String method, String key, float defaultValue) {
/*  665 */     String methodKey = method + "." + key;
/*  666 */     Number n = (Number)getNumbers().get(methodKey);
/*  667 */     if (n != null) {
/*  668 */       return n.intValue();
/*      */     }
/*  670 */     String value = getMethodParameter(method, key);
/*  671 */     if ((value == null) || (value.length() == 0)) {
/*  672 */       return defaultValue;
/*      */     }
/*  674 */     float f = Float.parseFloat(value);
/*  675 */     getNumbers().put(methodKey, Float.valueOf(f));
/*  676 */     return f;
/*      */   }
/*      */ 
/*      */   public long getMethodParameter(String method, String key, long defaultValue) {
/*  680 */     String methodKey = method + "." + key;
/*  681 */     Number n = (Number)getNumbers().get(methodKey);
/*  682 */     if (n != null) {
/*  683 */       return n.intValue();
/*      */     }
/*  685 */     String value = getMethodParameter(method, key);
/*  686 */     if ((value == null) || (value.length() == 0)) {
/*  687 */       return defaultValue;
/*      */     }
/*  689 */     long l = Long.parseLong(value);
/*  690 */     getNumbers().put(methodKey, Long.valueOf(l));
/*  691 */     return l;
/*      */   }
/*      */ 
/*      */   public int getMethodParameter(String method, String key, int defaultValue) {
/*  695 */     String methodKey = method + "." + key;
/*  696 */     Number n = (Number)getNumbers().get(methodKey);
/*  697 */     if (n != null) {
/*  698 */       return n.intValue();
/*      */     }
/*  700 */     String value = getMethodParameter(method, key);
/*  701 */     if ((value == null) || (value.length() == 0)) {
/*  702 */       return defaultValue;
/*      */     }
/*  704 */     int i = Integer.parseInt(value);
/*  705 */     getNumbers().put(methodKey, Integer.valueOf(i));
/*  706 */     return i;
/*      */   }
/*      */ 
/*      */   public short getMethodParameter(String method, String key, short defaultValue) {
/*  710 */     String methodKey = method + "." + key;
/*  711 */     Number n = (Number)getNumbers().get(methodKey);
/*  712 */     if (n != null) {
/*  713 */       return n.shortValue();
/*      */     }
/*  715 */     String value = getMethodParameter(method, key);
/*  716 */     if ((value == null) || (value.length() == 0)) {
/*  717 */       return defaultValue;
/*      */     }
/*  719 */     short s = Short.parseShort(value);
/*  720 */     getNumbers().put(methodKey, Short.valueOf(s));
/*  721 */     return s;
/*      */   }
/*      */ 
/*      */   public byte getMethodParameter(String method, String key, byte defaultValue) {
/*  725 */     String methodKey = method + "." + key;
/*  726 */     Number n = (Number)getNumbers().get(methodKey);
/*  727 */     if (n != null) {
/*  728 */       return n.byteValue();
/*      */     }
/*  730 */     String value = getMethodParameter(method, key);
/*  731 */     if ((value == null) || (value.length() == 0)) {
/*  732 */       return defaultValue;
/*      */     }
/*  734 */     byte b = Byte.parseByte(value);
/*  735 */     getNumbers().put(methodKey, Byte.valueOf(b));
/*  736 */     return b;
/*      */   }
/*      */ 
/*      */   public double getMethodPositiveParameter(String method, String key, double defaultValue) {
/*  740 */     if (defaultValue <= 0.0D) {
/*  741 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  743 */     double value = getMethodParameter(method, key, defaultValue);
/*  744 */     if (value <= 0.0D) {
/*  745 */       return defaultValue;
/*      */     }
/*  747 */     return value;
/*      */   }
/*      */ 
/*      */   public float getMethodPositiveParameter(String method, String key, float defaultValue) {
/*  751 */     if (defaultValue <= 0.0F) {
/*  752 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  754 */     float value = getMethodParameter(method, key, defaultValue);
/*  755 */     if (value <= 0.0F) {
/*  756 */       return defaultValue;
/*      */     }
/*  758 */     return value;
/*      */   }
/*      */ 
/*      */   public long getMethodPositiveParameter(String method, String key, long defaultValue) {
/*  762 */     if (defaultValue <= 0L) {
/*  763 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  765 */     long value = getMethodParameter(method, key, defaultValue);
/*  766 */     if (value <= 0L) {
/*  767 */       return defaultValue;
/*      */     }
/*  769 */     return value;
/*      */   }
/*      */ 
/*      */   public int getMethodPositiveParameter(String method, String key, int defaultValue) {
/*  773 */     if (defaultValue <= 0) {
/*  774 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  776 */     int value = getMethodParameter(method, key, defaultValue);
/*  777 */     if (value <= 0) {
/*  778 */       return defaultValue;
/*      */     }
/*  780 */     return value;
/*      */   }
/*      */ 
/*      */   public short getMethodPositiveParameter(String method, String key, short defaultValue) {
/*  784 */     if (defaultValue <= 0) {
/*  785 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  787 */     short value = getMethodParameter(method, key, defaultValue);
/*  788 */     if (value <= 0) {
/*  789 */       return defaultValue;
/*      */     }
/*  791 */     return value;
/*      */   }
/*      */ 
/*      */   public byte getMethodPositiveParameter(String method, String key, byte defaultValue) {
/*  795 */     if (defaultValue <= 0) {
/*  796 */       throw new IllegalArgumentException("defaultValue <= 0");
/*      */     }
/*  798 */     byte value = getMethodParameter(method, key, defaultValue);
/*  799 */     if (value <= 0) {
/*  800 */       return defaultValue;
/*      */     }
/*  802 */     return value;
/*      */   }
/*      */ 
/*      */   public char getMethodParameter(String method, String key, char defaultValue) {
/*  806 */     String value = getMethodParameter(method, key);
/*  807 */     if ((value == null) || (value.length() == 0)) {
/*  808 */       return defaultValue;
/*      */     }
/*  810 */     return value.charAt(0);
/*      */   }
/*      */ 
/*      */   public boolean getMethodParameter(String method, String key, boolean defaultValue) {
/*  814 */     String value = getMethodParameter(method, key);
/*  815 */     if ((value == null) || (value.length() == 0)) {
/*  816 */       return defaultValue;
/*      */     }
/*  818 */     return Boolean.parseBoolean(value);
/*      */   }
/*      */ 
/*      */   public boolean hasMethodParameter(String method, String key) {
/*  822 */     if (method == null) {
/*  823 */       String suffix = "." + key;
/*  824 */       for (String fullKey : this.parameters.keySet()) {
/*  825 */         if (fullKey.endsWith(suffix)) {
/*  826 */           return true;
/*      */         }
/*      */       }
/*  829 */       return false;
/*      */     }
/*  831 */     if (key == null) {
/*  832 */       String prefix = method + ".";
/*  833 */       for (String fullKey : this.parameters.keySet()) {
/*  834 */         if (fullKey.startsWith(prefix)) {
/*  835 */           return true;
/*      */         }
/*      */       }
/*  838 */       return false;
/*      */     }
/*  840 */     String value = getMethodParameter(method, key);
/*  841 */     return (value != null) && (value.length() > 0);
/*      */   }
/*      */ 
/*      */   public boolean isLocalHost() {
/*  845 */     return (NetUtils.isLocalHost(this.host)) || (getParameter("localhost", false));
/*      */   }
/*      */ 
/*      */   public boolean isAnyHost() {
/*  849 */     return ("0.0.0.0".equals(this.host)) || (getParameter("anyhost", false));
/*      */   }
/*      */ 
/*      */   public URL addParameterAndEncoded(String key, String value) {
/*  853 */     if ((value == null) || (value.length() == 0)) {
/*  854 */       return this;
/*      */     }
/*  856 */     return addParameter(key, encode(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, boolean value) {
/*  860 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, char value) {
/*  864 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, byte value) {
/*  868 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, short value) {
/*  872 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, int value) {
/*  876 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, long value) {
/*  880 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, float value) {
/*  884 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, double value) {
/*  888 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, Enum<?> value) {
/*  892 */     if (value == null) return this;
/*  893 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, Number value) {
/*  897 */     if (value == null) return this;
/*  898 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, CharSequence value) {
/*  902 */     if ((value == null) || (value.length() == 0)) return this;
/*  903 */     return addParameter(key, String.valueOf(value));
/*      */   }
/*      */ 
/*      */   public URL addParameter(String key, String value) {
/*  907 */     if ((key == null) || (key.length() == 0) || (value == null) || (value.length() == 0))
/*      */     {
/*  909 */       return this;
/*      */     }
/*      */ 
/*  912 */     if (value.equals(getParameters().get(key))) {
/*  913 */       return this;
/*      */     }
/*      */ 
/*  916 */     Map map = new HashMap(getParameters());
/*  917 */     map.put(key, value);
/*  918 */     return new URL(this.protocol, this.username, this.password, this.host, this.port, this.path, map);
/*      */   }
/*      */ 
/*      */   public URL addParameterIfAbsent(String key, String value) {
/*  922 */     if ((key == null) || (key.length() == 0) || (value == null) || (value.length() == 0))
/*      */     {
/*  924 */       return this;
/*      */     }
/*  926 */     if (hasParameter(key)) {
/*  927 */       return this;
/*      */     }
/*  929 */     Map map = new HashMap(getParameters());
/*  930 */     map.put(key, value);
/*  931 */     return new URL(this.protocol, this.username, this.password, this.host, this.port, this.path, map);
/*      */   }
/*      */ 
/*      */   public URL addParameters(Map<String, String> parameters)
/*      */   {
/*  941 */     if ((parameters == null) || (parameters.size() == 0)) {
/*  942 */       return this;
/*      */     }
/*      */ 
/*  945 */     boolean hasAndEqual = true;
/*  946 */     for (Map.Entry entry : parameters.entrySet()) {
/*  947 */       String value = (String)getParameters().get(entry.getKey());
/*  948 */       if (((value == null) && (entry.getValue() != null)) || (!value.equals(entry.getValue()))) {
/*  949 */         hasAndEqual = false;
/*  950 */         break;
/*      */       }
/*      */     }
/*      */ 
/*  954 */     if (hasAndEqual) return this;
/*      */ 
/*  956 */     Map map = new HashMap(getParameters());
/*  957 */     map.putAll(parameters);
/*  958 */     return new URL(this.protocol, this.username, this.password, this.host, this.port, this.path, map);
/*      */   }
/*      */ 
/*      */   public URL addParametersIfAbsent(Map<String, String> parameters) {
/*  962 */     if ((parameters == null) || (parameters.size() == 0)) {
/*  963 */       return this;
/*      */     }
/*  965 */     Map map = new HashMap(parameters);
/*  966 */     map.putAll(getParameters());
/*  967 */     return new URL(this.protocol, this.username, this.password, this.host, this.port, this.path, map);
/*      */   }
/*      */ 
/*      */   public URL addParameters(String[] pairs) {
/*  971 */     if ((pairs == null) || (pairs.length == 0)) {
/*  972 */       return this;
/*      */     }
/*  974 */     if (pairs.length % 2 != 0) {
/*  975 */       throw new IllegalArgumentException("Map pairs can not be odd number.");
/*      */     }
/*  977 */     Map map = new HashMap();
/*  978 */     int len = pairs.length / 2;
/*  979 */     for (int i = 0; i < len; i++) {
/*  980 */       map.put(pairs[(2 * i)], pairs[(2 * i + 1)]);
/*      */     }
/*  982 */     return addParameters(map);
/*      */   }
/*      */ 
/*      */   public URL addParameterString(String query) {
/*  986 */     if ((query == null) || (query.length() == 0)) {
/*  987 */       return this;
/*      */     }
/*  989 */     return addParameters(StringUtils.parseQueryString(query));
/*      */   }
/*      */ 
/*      */   public URL removeParameter(String key) {
/*  993 */     if ((key == null) || (key.length() == 0)) {
/*  994 */       return this;
/*      */     }
/*  996 */     return removeParameters(new String[] { key });
/*      */   }
/*      */ 
/*      */   public URL removeParameters(Collection<String> keys) {
/* 1000 */     if ((keys == null) || (keys.size() == 0)) {
/* 1001 */       return this;
/*      */     }
/* 1003 */     return removeParameters((String[])keys.toArray(new String[0]));
/*      */   }
/*      */ 
/*      */   public URL removeParameters(String[] keys) {
/* 1007 */     if ((keys == null) || (keys.length == 0)) {
/* 1008 */       return this;
/*      */     }
/* 1010 */     Map map = new HashMap(getParameters());
/* 1011 */     for (String key : keys) {
/* 1012 */       map.remove(key);
/*      */     }
/* 1014 */     if (map.size() == getParameters().size()) {
/* 1015 */       return this;
/*      */     }
/* 1017 */     return new URL(this.protocol, this.username, this.password, this.host, this.port, this.path, map);
/*      */   }
/*      */ 
/*      */   public URL clearParameters() {
/* 1021 */     return new URL(this.protocol, this.username, this.password, this.host, this.port, this.path, new HashMap());
/*      */   }
/*      */ 
/*      */   public String getRawParameter(String key) {
/* 1025 */     if ("protocol".equals(key))
/* 1026 */       return this.protocol;
/* 1027 */     if ("username".equals(key))
/* 1028 */       return this.username;
/* 1029 */     if ("password".equals(key))
/* 1030 */       return this.password;
/* 1031 */     if ("host".equals(key))
/* 1032 */       return this.host;
/* 1033 */     if ("port".equals(key))
/* 1034 */       return String.valueOf(this.port);
/* 1035 */     if ("path".equals(key))
/* 1036 */       return this.path;
/* 1037 */     return getParameter(key);
/*      */   }
/*      */ 
/*      */   public Map<String, String> toMap() {
/* 1041 */     Map map = new HashMap(this.parameters);
/* 1042 */     if (this.protocol != null)
/* 1043 */       map.put("protocol", this.protocol);
/* 1044 */     if (this.username != null)
/* 1045 */       map.put("username", this.username);
/* 1046 */     if (this.password != null)
/* 1047 */       map.put("password", this.password);
/* 1048 */     if (this.host != null)
/* 1049 */       map.put("host", this.host);
/* 1050 */     if (this.port > 0)
/* 1051 */       map.put("port", String.valueOf(this.port));
/* 1052 */     if (this.path != null)
/* 1053 */       map.put("path", this.path);
/* 1054 */     return map;
/*      */   }
/*      */ 
/*      */   public String toString() {
/* 1058 */     if (this.string != null) {
/* 1059 */       return this.string;
/*      */     }
/* 1061 */     return this.string = buildString(false, true, new String[0]);
/*      */   }
/*      */ 
/*      */   public String toString(String[] parameters) {
/* 1065 */     return buildString(false, true, parameters);
/*      */   }
/*      */ 
/*      */   public String toIdentityString() {
/* 1069 */     if (this.identity != null) {
/* 1070 */       return this.identity;
/*      */     }
/* 1072 */     return this.identity = buildString(true, false, new String[0]);
/*      */   }
/*      */ 
/*      */   public String toIdentityString(String[] parameters) {
/* 1076 */     return buildString(true, false, parameters);
/*      */   }
/*      */ 
/*      */   public String toFullString() {
/* 1080 */     if (this.full != null) {
/* 1081 */       return this.full;
/*      */     }
/* 1083 */     return this.full = buildString(true, true, new String[0]);
/*      */   }
/*      */ 
/*      */   public String toFullString(String[] parameters) {
/* 1087 */     return buildString(true, true, parameters);
/*      */   }
/*      */ 
/*      */   public String toParameterString() {
/* 1091 */     if (this.parameter != null) {
/* 1092 */       return this.parameter;
/*      */     }
/* 1094 */     return this.parameter = toParameterString(new String[0]);
/*      */   }
/*      */ 
/*      */   public String toParameterString(String[] parameters) {
/* 1098 */     StringBuilder buf = new StringBuilder();
/* 1099 */     buildParameters(buf, false, parameters);
/* 1100 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   private void buildParameters(StringBuilder buf, boolean concat, String[] parameters)
/*      */   {
/*      */     List includes;
/*      */     boolean first;
/* 1104 */     if ((getParameters() != null) && (getParameters().size() > 0)) {
/* 1105 */       includes = (parameters == null) || (parameters.length == 0) ? null : Arrays.asList(parameters);
/* 1106 */       first = true;
/* 1107 */       for (Map.Entry entry : new TreeMap(getParameters()).entrySet())
/* 1108 */         if ((entry.getKey() != null) && (((String)entry.getKey()).length() > 0) && ((includes == null) || (includes.contains(entry.getKey()))))
/*      */         {
/* 1110 */           if (first) {
/* 1111 */             if (concat) {
/* 1112 */               buf.append("?");
/*      */             }
/* 1114 */             first = false;
/*      */           } else {
/* 1116 */             buf.append("&");
/*      */           }
/* 1118 */           buf.append((String)entry.getKey());
/* 1119 */           buf.append("=");
/* 1120 */           buf.append(entry.getValue() == null ? "" : ((String)entry.getValue()).trim());
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   private String buildString(boolean appendUser, boolean appendParameter, String[] parameters)
/*      */   {
/* 1127 */     return buildString(appendUser, appendParameter, false, false, parameters);
/*      */   }
/*      */ 
/*      */   private String buildString(boolean appendUser, boolean appendParameter, boolean useIP, boolean useService, String[] parameters) {
/* 1131 */     StringBuilder buf = new StringBuilder();
/* 1132 */     if ((this.protocol != null) && (this.protocol.length() > 0)) {
/* 1133 */       buf.append(this.protocol);
/* 1134 */       buf.append("://");
/*      */     }
/* 1136 */     if ((appendUser) && (this.username != null) && (this.username.length() > 0)) {
/* 1137 */       buf.append(this.username);
/* 1138 */       if ((this.password != null) && (this.password.length() > 0)) {
/* 1139 */         buf.append(":");
/* 1140 */         buf.append(this.password);
/*      */       }
/* 1142 */       buf.append("@");
/*      */     }
/*      */     String host;
/*      */     String host;
/* 1145 */     if (useIP)
/* 1146 */       host = getIp();
/*      */     else {
/* 1148 */       host = getHost();
/*      */     }
/* 1150 */     if ((host != null) && (host.length() > 0)) {
/* 1151 */       buf.append(host);
/* 1152 */       if (this.port > 0) {
/* 1153 */         buf.append(":");
/* 1154 */         buf.append(this.port);
/*      */       }
/*      */     }
/*      */     String path;
/*      */     String path;
/* 1158 */     if (useService)
/* 1159 */       path = getServiceKey();
/*      */     else {
/* 1161 */       path = getPath();
/*      */     }
/* 1163 */     if ((path != null) && (path.length() > 0)) {
/* 1164 */       buf.append("/");
/* 1165 */       buf.append(path);
/*      */     }
/* 1167 */     if (appendParameter) {
/* 1168 */       buildParameters(buf, true, parameters);
/*      */     }
/* 1170 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   public java.net.URL toJavaURL() {
/*      */     try {
/* 1175 */       return new java.net.URL(toString());
/*      */     } catch (MalformedURLException e) {
/* 1177 */       throw new IllegalStateException(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public InetSocketAddress toInetSocketAddress() {
/* 1182 */     return new InetSocketAddress(this.host, this.port);
/*      */   }
/*      */ 
/*      */   public String getServiceKey() {
/* 1186 */     String inf = getServiceInterface();
/* 1187 */     if (inf == null) return null;
/* 1188 */     StringBuilder buf = new StringBuilder();
/* 1189 */     String group = getParameter("group");
/* 1190 */     if ((group != null) && (group.length() > 0)) {
/* 1191 */       buf.append(group).append("/");
/*      */     }
/* 1193 */     buf.append(inf);
/* 1194 */     String version = getParameter("version");
/* 1195 */     if ((version != null) && (version.length() > 0)) {
/* 1196 */       buf.append(":").append(version);
/*      */     }
/* 1198 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   public String toServiceString() {
/* 1202 */     return buildString(true, false, true, true, new String[0]);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public String getServiceName() {
/* 1207 */     return getServiceInterface();
/*      */   }
/*      */ 
/*      */   public String getServiceInterface() {
/* 1211 */     return getParameter("interface", this.path);
/*      */   }
/*      */ 
/*      */   public URL setServiceInterface(String service) {
/* 1215 */     return addParameter("interface", service);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int getIntParameter(String key)
/*      */   {
/* 1224 */     return getParameter(key, 0);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int getIntParameter(String key, int defaultValue)
/*      */   {
/* 1233 */     return getParameter(key, defaultValue);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int getPositiveIntParameter(String key, int defaultValue)
/*      */   {
/* 1242 */     return getPositiveParameter(key, defaultValue);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean getBooleanParameter(String key)
/*      */   {
/* 1251 */     return getParameter(key, false);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean getBooleanParameter(String key, boolean defaultValue)
/*      */   {
/* 1260 */     return getParameter(key, defaultValue);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int getMethodIntParameter(String method, String key)
/*      */   {
/* 1269 */     return getMethodParameter(method, key, 0);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int getMethodIntParameter(String method, String key, int defaultValue)
/*      */   {
/* 1278 */     return getMethodParameter(method, key, defaultValue);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int getMethodPositiveIntParameter(String method, String key, int defaultValue)
/*      */   {
/* 1287 */     return getMethodPositiveParameter(method, key, defaultValue);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean getMethodBooleanParameter(String method, String key)
/*      */   {
/* 1296 */     return getMethodParameter(method, key, false);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean getMethodBooleanParameter(String method, String key, boolean defaultValue)
/*      */   {
/* 1305 */     return getMethodParameter(method, key, defaultValue);
/*      */   }
/*      */ 
/*      */   public static String encode(String value) {
/* 1309 */     if ((value == null) || (value.length() == 0))
/* 1310 */       return "";
/*      */     try
/*      */     {
/* 1313 */       return URLEncoder.encode(value, "UTF-8");
/*      */     } catch (UnsupportedEncodingException e) {
/* 1315 */       throw new RuntimeException(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String decode(String value) {
/* 1320 */     if ((value == null) || (value.length() == 0))
/* 1321 */       return "";
/*      */     try
/*      */     {
/* 1324 */       return URLDecoder.decode(value, "UTF-8");
/*      */     } catch (UnsupportedEncodingException e) {
/* 1326 */       throw new RuntimeException(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1332 */     int prime = 31;
/* 1333 */     int result = 1;
/* 1334 */     result = 31 * result + (this.host == null ? 0 : this.host.hashCode());
/* 1335 */     result = 31 * result + (this.parameters == null ? 0 : this.parameters.hashCode());
/* 1336 */     result = 31 * result + (this.password == null ? 0 : this.password.hashCode());
/* 1337 */     result = 31 * result + (this.path == null ? 0 : this.path.hashCode());
/* 1338 */     result = 31 * result + this.port;
/* 1339 */     result = 31 * result + (this.protocol == null ? 0 : this.protocol.hashCode());
/* 1340 */     result = 31 * result + (this.username == null ? 0 : this.username.hashCode());
/* 1341 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object obj)
/*      */   {
/* 1346 */     if (this == obj)
/* 1347 */       return true;
/* 1348 */     if (obj == null)
/* 1349 */       return false;
/* 1350 */     if (getClass() != obj.getClass())
/* 1351 */       return false;
/* 1352 */     URL other = (URL)obj;
/* 1353 */     if (this.host == null) {
/* 1354 */       if (other.host != null)
/* 1355 */         return false;
/* 1356 */     } else if (!this.host.equals(other.host))
/* 1357 */       return false;
/* 1358 */     if (this.parameters == null) {
/* 1359 */       if (other.parameters != null)
/* 1360 */         return false;
/* 1361 */     } else if (!this.parameters.equals(other.parameters))
/* 1362 */       return false;
/* 1363 */     if (this.password == null) {
/* 1364 */       if (other.password != null)
/* 1365 */         return false;
/* 1366 */     } else if (!this.password.equals(other.password))
/* 1367 */       return false;
/* 1368 */     if (this.path == null) {
/* 1369 */       if (other.path != null)
/* 1370 */         return false;
/* 1371 */     } else if (!this.path.equals(other.path))
/* 1372 */       return false;
/* 1373 */     if (this.port != other.port)
/* 1374 */       return false;
/* 1375 */     if (this.protocol == null) {
/* 1376 */       if (other.protocol != null)
/* 1377 */         return false;
/* 1378 */     } else if (!this.protocol.equals(other.protocol))
/* 1379 */       return false;
/* 1380 */     if (this.username == null) {
/* 1381 */       if (other.username != null)
/* 1382 */         return false;
/* 1383 */     } else if (!this.username.equals(other.username))
/* 1384 */       return false;
/* 1385 */     return true;
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.URL
 * JD-Core Version:    0.6.2
 */