/*     */ package com.alibaba.dubbo.common;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*     */ import java.net.URL;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ public final class Version
/*     */ {
/*  37 */   private static final Logger logger = LoggerFactory.getLogger(Version.class);
/*     */ 
/*  39 */   private static final String VERSION = getVersion(Version.class, "2.0.0");
/*     */ 
/*  41 */   private static final boolean INTERNAL = hasResource("com/alibaba/dubbo/registry/internal/RemoteRegistry.class");
/*     */ 
/*  43 */   private static final boolean COMPATIBLE = hasResource("com/taobao/remoting/impl/ConnectionRequest.class");
/*     */ 
/*     */   public static String getVersion()
/*     */   {
/*  51 */     return VERSION;
/*     */   }
/*     */ 
/*     */   public static boolean isInternalVersion() {
/*  55 */     return INTERNAL;
/*     */   }
/*     */ 
/*     */   public static boolean isCompatibleVersion() {
/*  59 */     return COMPATIBLE;
/*     */   }
/*     */ 
/*     */   private static boolean hasResource(String path) {
/*     */     try {
/*  64 */       return Version.class.getClassLoader().getResource(path) != null; } catch (Throwable t) {
/*     */     }
/*  66 */     return false;
/*     */   }
/*     */ 
/*     */   public static String getVersion(Class<?> cls, String defaultVersion)
/*     */   {
/*     */     try
/*     */     {
/*  73 */       String version = cls.getPackage().getImplementationVersion();
/*  74 */       if ((version == null) || (version.length() == 0)) {
/*  75 */         version = cls.getPackage().getSpecificationVersion();
/*     */       }
/*  77 */       if ((version == null) || (version.length() == 0))
/*     */       {
/*  79 */         CodeSource codeSource = cls.getProtectionDomain().getCodeSource();
/*  80 */         if (codeSource == null) {
/*  81 */           logger.info("No codeSource for class " + cls.getName() + " when getVersion, use default version " + defaultVersion);
/*     */         }
/*     */         else {
/*  84 */           String file = codeSource.getLocation().getFile();
/*  85 */           if ((file != null) && (file.length() > 0) && (file.endsWith(".jar"))) {
/*  86 */             file = file.substring(0, file.length() - 4);
/*  87 */             int i = file.lastIndexOf('/');
/*  88 */             if (i >= 0) {
/*  89 */               file = file.substring(i + 1);
/*     */             }
/*  91 */             i = file.indexOf("-");
/*  92 */             if (i >= 0) {
/*  93 */               file = file.substring(i + 1);
/*     */             }
/*  95 */             while ((file.length() > 0) && (!Character.isDigit(file.charAt(0)))) {
/*  96 */               i = file.indexOf("-");
/*  97 */               if (i < 0) break;
/*  98 */               file = file.substring(i + 1);
/*     */             }
/*     */ 
/* 103 */             version = file;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 108 */       return (version == null) || (version.length() == 0) ? defaultVersion : version;
/*     */     }
/*     */     catch (Throwable e) {
/* 111 */       logger.error("return default version, ignore exception " + e.getMessage(), e);
/* 112 */     }return defaultVersion;
/*     */   }
/*     */ 
/*     */   public static void checkDuplicate(Class<?> cls, boolean failOnError)
/*     */   {
/* 117 */     checkDuplicate(cls.getName().replace('.', '/') + ".class", failOnError);
/*     */   }
/*     */ 
/*     */   public static void checkDuplicate(Class<?> cls) {
/* 121 */     checkDuplicate(cls, false);
/*     */   }
/*     */ 
/*     */   public static void checkDuplicate(String path, boolean failOnError)
/*     */   {
/*     */     try {
/* 127 */       Enumeration urls = ClassHelper.getCallerClassLoader(Version.class).getResources(path);
/* 128 */       Set files = new HashSet();
/* 129 */       while (urls.hasMoreElements()) {
/* 130 */         URL url = (URL)urls.nextElement();
/* 131 */         if (url != null) {
/* 132 */           String file = url.getFile();
/* 133 */           if ((file != null) && (file.length() > 0)) {
/* 134 */             files.add(file);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 139 */       if (files.size() > 1) {
/* 140 */         String error = "Duplicate class " + path + " in " + files.size() + " jar " + files;
/* 141 */         if (failOnError) {
/* 142 */           throw new IllegalStateException(error);
/*     */         }
/* 144 */         logger.error(error);
/*     */       }
/*     */     }
/*     */     catch (Throwable e) {
/* 148 */       logger.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  47 */     checkDuplicate(Version.class);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.Version
 * JD-Core Version:    0.6.2
 */