/*     */ package com.alibaba.dubbo.common.bytecode;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import javassist.CannotCompileException;
/*     */ import javassist.ClassPool;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtConstructor;
/*     */ import javassist.CtField;
/*     */ import javassist.CtMethod;
/*     */ import javassist.CtNewConstructor;
/*     */ import javassist.CtNewMethod;
/*     */ import javassist.LoaderClassPath;
/*     */ import javassist.NotFoundException;
/*     */ 
/*     */ public final class ClassGenerator
/*     */ {
/*  54 */   private static final AtomicLong CLASS_NAME_COUNTER = new AtomicLong(0L);
/*     */   private static final String SIMPLE_NAME_TAG = "<init>";
/*  58 */   private static final Map<ClassLoader, ClassPool> POOL_MAP = new ConcurrentHashMap();
/*     */   private ClassPool mPool;
/*     */   private CtClass mCtc;
/*     */   private String mClassName;
/*     */   private String mSuperClass;
/*     */   private Set<String> mInterfaces;
/*     */   private List<String> mFields;
/*     */   private List<String> mConstructors;
/*     */   private List<String> mMethods;
/*     */   private Map<String, Method> mCopyMethods;
/*     */   private Map<String, Constructor<?>> mCopyConstructors;
/* 104 */   private boolean mDefaultConstructor = false;
/*     */ 
/*     */   public static ClassGenerator newInstance()
/*     */   {
/*  62 */     return new ClassGenerator(getClassPool(ClassHelper.getCallerClassLoader(ClassGenerator.class)));
/*     */   }
/*     */ 
/*     */   public static ClassGenerator newInstance(ClassLoader loader)
/*     */   {
/*  67 */     return new ClassGenerator(getClassPool(loader));
/*     */   }
/*     */ 
/*     */   public static boolean isDynamicClass(Class<?> cl)
/*     */   {
/*  72 */     return DC.class.isAssignableFrom(cl);
/*     */   }
/*     */ 
/*     */   public static ClassPool getClassPool(ClassLoader loader)
/*     */   {
/*  77 */     if (loader == null) {
/*  78 */       return ClassPool.getDefault();
/*     */     }
/*  80 */     ClassPool pool = (ClassPool)POOL_MAP.get(loader);
/*  81 */     if (pool == null)
/*     */     {
/*  83 */       pool = new ClassPool(true);
/*  84 */       pool.appendClassPath(new LoaderClassPath(loader));
/*  85 */       POOL_MAP.put(loader, pool);
/*     */     }
/*  87 */     return pool;
/*     */   }
/*     */ 
/*     */   private ClassGenerator()
/*     */   {
/*     */   }
/*     */ 
/*     */   private ClassGenerator(ClassPool pool)
/*     */   {
/* 110 */     this.mPool = pool;
/*     */   }
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 115 */     return this.mClassName;
/*     */   }
/*     */ 
/*     */   public ClassGenerator setClassName(String name)
/*     */   {
/* 120 */     this.mClassName = name;
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addInterface(String cn)
/*     */   {
/* 126 */     if (this.mInterfaces == null)
/* 127 */       this.mInterfaces = new HashSet();
/* 128 */     this.mInterfaces.add(cn);
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addInterface(Class<?> cl)
/*     */   {
/* 134 */     return addInterface(cl.getName());
/*     */   }
/*     */ 
/*     */   public ClassGenerator setSuperClass(String cn)
/*     */   {
/* 139 */     this.mSuperClass = cn;
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator setSuperClass(Class<?> cl)
/*     */   {
/* 145 */     this.mSuperClass = cl.getName();
/* 146 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addField(String code)
/*     */   {
/* 151 */     if (this.mFields == null)
/* 152 */       this.mFields = new ArrayList();
/* 153 */     this.mFields.add(code);
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addField(String name, int mod, Class<?> type)
/*     */   {
/* 159 */     return addField(name, mod, type, null);
/*     */   }
/*     */ 
/*     */   public ClassGenerator addField(String name, int mod, Class<?> type, String def)
/*     */   {
/* 164 */     StringBuilder sb = new StringBuilder();
/* 165 */     sb.append(modifier(mod)).append(' ').append(ReflectUtils.getName(type)).append(' ');
/* 166 */     sb.append(name);
/* 167 */     if ((def != null) && (def.length() > 0))
/*     */     {
/* 169 */       sb.append('=');
/* 170 */       sb.append(def);
/*     */     }
/* 172 */     sb.append(';');
/* 173 */     return addField(sb.toString());
/*     */   }
/*     */ 
/*     */   public ClassGenerator addMethod(String code)
/*     */   {
/* 178 */     if (this.mMethods == null)
/* 179 */       this.mMethods = new ArrayList();
/* 180 */     this.mMethods.add(code);
/* 181 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addMethod(String name, int mod, Class<?> rt, Class<?>[] pts, String body)
/*     */   {
/* 186 */     return addMethod(name, mod, rt, pts, null, body);
/*     */   }
/*     */ 
/*     */   public ClassGenerator addMethod(String name, int mod, Class<?> rt, Class<?>[] pts, Class<?>[] ets, String body)
/*     */   {
/* 191 */     StringBuilder sb = new StringBuilder();
/* 192 */     sb.append(modifier(mod)).append(' ').append(ReflectUtils.getName(rt)).append(' ').append(name);
/* 193 */     sb.append('(');
/* 194 */     for (int i = 0; i < pts.length; i++)
/*     */     {
/* 196 */       if (i > 0)
/* 197 */         sb.append(',');
/* 198 */       sb.append(ReflectUtils.getName(pts[i]));
/* 199 */       sb.append(" arg").append(i);
/*     */     }
/* 201 */     sb.append(')');
/* 202 */     if ((ets != null) && (ets.length > 0))
/*     */     {
/* 204 */       sb.append(" throws ");
/* 205 */       for (int i = 0; i < ets.length; i++)
/*     */       {
/* 207 */         if (i > 0)
/* 208 */           sb.append(',');
/* 209 */         sb.append(ReflectUtils.getName(ets[i]));
/*     */       }
/*     */     }
/* 212 */     sb.append('{').append(body).append('}');
/* 213 */     return addMethod(sb.toString());
/*     */   }
/*     */ 
/*     */   public ClassGenerator addMethod(Method m)
/*     */   {
/* 218 */     addMethod(m.getName(), m);
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addMethod(String name, Method m)
/*     */   {
/* 224 */     String desc = name + ReflectUtils.getDescWithoutMethodName(m);
/* 225 */     addMethod(':' + desc);
/* 226 */     if (this.mCopyMethods == null)
/* 227 */       this.mCopyMethods = new ConcurrentHashMap(8);
/* 228 */     this.mCopyMethods.put(desc, m);
/* 229 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addConstructor(String code)
/*     */   {
/* 234 */     if (this.mConstructors == null)
/* 235 */       this.mConstructors = new LinkedList();
/* 236 */     this.mConstructors.add(code);
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addConstructor(int mod, Class<?>[] pts, String body)
/*     */   {
/* 242 */     return addConstructor(mod, pts, null, body);
/*     */   }
/*     */ 
/*     */   public ClassGenerator addConstructor(int mod, Class<?>[] pts, Class<?>[] ets, String body)
/*     */   {
/* 247 */     StringBuilder sb = new StringBuilder();
/* 248 */     sb.append(modifier(mod)).append(' ').append("<init>");
/* 249 */     sb.append('(');
/* 250 */     for (int i = 0; i < pts.length; i++)
/*     */     {
/* 252 */       if (i > 0)
/* 253 */         sb.append(',');
/* 254 */       sb.append(ReflectUtils.getName(pts[i]));
/* 255 */       sb.append(" arg").append(i);
/*     */     }
/* 257 */     sb.append(')');
/* 258 */     if ((ets != null) && (ets.length > 0))
/*     */     {
/* 260 */       sb.append(" throws ");
/* 261 */       for (int i = 0; i < ets.length; i++)
/*     */       {
/* 263 */         if (i > 0)
/* 264 */           sb.append(',');
/* 265 */         sb.append(ReflectUtils.getName(ets[i]));
/*     */       }
/*     */     }
/* 268 */     sb.append('{').append(body).append('}');
/* 269 */     return addConstructor(sb.toString());
/*     */   }
/*     */ 
/*     */   public ClassGenerator addConstructor(Constructor<?> c)
/*     */   {
/* 274 */     String desc = ReflectUtils.getDesc(c);
/* 275 */     addConstructor(":" + desc);
/* 276 */     if (this.mCopyConstructors == null)
/* 277 */       this.mCopyConstructors = new ConcurrentHashMap(4);
/* 278 */     this.mCopyConstructors.put(desc, c);
/* 279 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassGenerator addDefaultConstructor()
/*     */   {
/* 284 */     this.mDefaultConstructor = true;
/* 285 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassPool getClassPool() {
/* 289 */     return this.mPool;
/*     */   }
/*     */ 
/*     */   public Class<?> toClass()
/*     */   {
/* 294 */     if (this.mCtc != null)
/* 295 */       this.mCtc.detach();
/* 296 */     long id = CLASS_NAME_COUNTER.getAndIncrement();
/*     */     try
/*     */     {
/* 299 */       CtClass ctcs = this.mSuperClass == null ? null : this.mPool.get(this.mSuperClass);
/* 300 */       if (this.mClassName == null) {
/* 301 */         this.mClassName = (((this.mSuperClass == null) || (javassist.Modifier.isPublic(ctcs.getModifiers())) ? ClassGenerator.class.getName() : new StringBuilder().append(this.mSuperClass).append("$sc").toString()) + id);
/*     */       }
/* 303 */       this.mCtc = this.mPool.makeClass(this.mClassName);
/* 304 */       if (this.mSuperClass != null)
/* 305 */         this.mCtc.setSuperclass(ctcs);
/* 306 */       this.mCtc.addInterface(this.mPool.get(DC.class.getName()));
/* 307 */       if (this.mInterfaces != null)
/*     */       {
/* 308 */         String cl;
/* 308 */         for (Iterator i$ = this.mInterfaces.iterator(); i$.hasNext(); this.mCtc.addInterface(this.mPool.get(cl))) cl = (String)i$.next(); 
/*     */       }
/* 309 */       if (this.mFields != null)
/*     */       {
/* 310 */         String code;
/* 310 */         for (Iterator i$ = this.mFields.iterator(); i$.hasNext(); this.mCtc.addField(CtField.make(code, this.mCtc))) code = (String)i$.next(); 
/*     */       }
/* 311 */       if (this.mMethods != null)
/*     */       {
/* 313 */         for (String code : this.mMethods)
/*     */         {
/* 315 */           if (code.charAt(0) == ':')
/* 316 */             this.mCtc.addMethod(CtNewMethod.copy(getCtMethod((Method)this.mCopyMethods.get(code.substring(1))), code.substring(1, code.indexOf('(')), this.mCtc, null));
/*     */           else
/* 318 */             this.mCtc.addMethod(CtNewMethod.make(code, this.mCtc));
/*     */         }
/*     */       }
/* 321 */       if (this.mDefaultConstructor)
/* 322 */         this.mCtc.addConstructor(CtNewConstructor.defaultConstructor(this.mCtc));
/* 323 */       if (this.mConstructors != null)
/*     */       {
/* 325 */         for (String code : this.mConstructors)
/*     */         {
/* 327 */           if (code.charAt(0) == ':')
/*     */           {
/* 329 */             this.mCtc.addConstructor(CtNewConstructor.copy(getCtConstructor((Constructor)this.mCopyConstructors.get(code.substring(1))), this.mCtc, null));
/*     */           }
/*     */           else
/*     */           {
/* 333 */             String[] sn = this.mCtc.getSimpleName().split("\\$+");
/* 334 */             this.mCtc.addConstructor(CtNewConstructor.make(code.replaceFirst("<init>", sn[(sn.length - 1)]), this.mCtc));
/*     */           }
/*     */         }
/*     */       }
/* 338 */       return this.mCtc.toClass(ClassHelper.getCallerClassLoader(getClass()), null);
/*     */     }
/*     */     catch (RuntimeException e)
/*     */     {
/* 342 */       throw e;
/*     */     }
/*     */     catch (NotFoundException e)
/*     */     {
/* 346 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */     catch (CannotCompileException e)
/*     */     {
/* 350 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void release()
/*     */   {
/* 356 */     if (this.mCtc != null) this.mCtc.detach();
/* 357 */     if (this.mInterfaces != null) this.mInterfaces.clear();
/* 358 */     if (this.mFields != null) this.mFields.clear();
/* 359 */     if (this.mMethods != null) this.mMethods.clear();
/* 360 */     if (this.mConstructors != null) this.mConstructors.clear();
/* 361 */     if (this.mCopyMethods != null) this.mCopyMethods.clear();
/* 362 */     if (this.mCopyConstructors != null) this.mCopyConstructors.clear(); 
/*     */   }
/*     */ 
/*     */   private CtClass getCtClass(Class<?> c)
/*     */     throws NotFoundException
/*     */   {
/* 367 */     return this.mPool.get(c.getName());
/*     */   }
/*     */ 
/*     */   private CtMethod getCtMethod(Method m) throws NotFoundException
/*     */   {
/* 372 */     return getCtClass(m.getDeclaringClass()).getMethod(m.getName(), ReflectUtils.getDescWithoutMethodName(m));
/*     */   }
/*     */ 
/*     */   private CtConstructor getCtConstructor(Constructor<?> c) throws NotFoundException
/*     */   {
/* 377 */     return getCtClass(c.getDeclaringClass()).getConstructor(ReflectUtils.getDesc(c));
/*     */   }
/*     */ 
/*     */   private static String modifier(int mod)
/*     */   {
/* 382 */     if (java.lang.reflect.Modifier.isPublic(mod)) return "public";
/* 383 */     if (java.lang.reflect.Modifier.isProtected(mod)) return "protected";
/* 384 */     if (java.lang.reflect.Modifier.isPrivate(mod)) return "private";
/* 385 */     return "";
/*     */   }
/*     */ 
/*     */   public static abstract interface DC
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.bytecode.ClassGenerator
 * JD-Core Version:    0.6.2
 */