/*     */ package com.alibaba.dubbo.common.bytecode;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ public abstract class Mixin
/*     */ {
/*  35 */   private static AtomicLong MIXIN_CLASS_COUNTER = new AtomicLong(0L);
/*     */ 
/*  37 */   private static final String PACKAGE_NAME = Mixin.class.getPackage().getName();
/*     */ 
/*     */   public static Mixin mixin(Class<?>[] ics, Class<?> dc)
/*     */   {
/*  51 */     return mixin(ics, new Class[] { dc });
/*     */   }
/*     */ 
/*     */   public static Mixin mixin(Class<?>[] ics, Class<?> dc, ClassLoader cl)
/*     */   {
/*  65 */     return mixin(ics, new Class[] { dc }, cl);
/*     */   }
/*     */ 
/*     */   public static Mixin mixin(Class<?>[] ics, Class<?>[] dcs)
/*     */   {
/*  78 */     return mixin(ics, dcs, ClassHelper.getCallerClassLoader(Mixin.class));
/*     */   }
/*     */ 
/*     */   public static Mixin mixin(Class<?>[] ics, Class<?>[] dcs, ClassLoader cl)
/*     */   {
/*  92 */     assertInterfaceArray(ics);
/*     */ 
/*  94 */     long id = MIXIN_CLASS_COUNTER.getAndIncrement();
/*  95 */     String pkg = null;
/*  96 */     ClassGenerator ccp = null; ClassGenerator ccm = null;
/*     */     try
/*     */     {
/*  99 */       ccp = ClassGenerator.newInstance(cl);
/*     */ 
/* 102 */       StringBuilder code = new StringBuilder();
/* 103 */       for (int i = 0; i < dcs.length; i++)
/*     */       {
/* 105 */         if (!Modifier.isPublic(dcs[i].getModifiers()))
/*     */         {
/* 107 */           String npkg = dcs[i].getPackage().getName();
/* 108 */           if (pkg == null)
/*     */           {
/* 110 */             pkg = npkg;
/*     */           }
/* 114 */           else if (!pkg.equals(npkg)) {
/* 115 */             throw new IllegalArgumentException("non-public interfaces class from different packages");
/*     */           }
/*     */         }
/*     */ 
/* 119 */         ccp.addField("private " + dcs[i].getName() + " d" + i + ";");
/*     */ 
/* 121 */         code.append("d").append(i).append(" = (").append(dcs[i].getName()).append(")$1[").append(i).append("];\n");
/* 122 */         if (MixinAware.class.isAssignableFrom(dcs[i]))
/* 123 */           code.append("d").append(i).append(".setMixinInstance(this);\n");
/*     */       }
/* 125 */       ccp.addConstructor(1, new Class[] { [Ljava.lang.Object.class }, code.toString());
/*     */ 
/* 128 */       Set worked = new HashSet();
/* 129 */       for (int i = 0; i < ics.length; i++)
/*     */       {
/* 131 */         if (!Modifier.isPublic(ics[i].getModifiers()))
/*     */         {
/* 133 */           String npkg = ics[i].getPackage().getName();
/* 134 */           if (pkg == null)
/*     */           {
/* 136 */             pkg = npkg;
/*     */           }
/* 140 */           else if (!pkg.equals(npkg)) {
/* 141 */             throw new IllegalArgumentException("non-public delegate class from different packages");
/*     */           }
/*     */         }
/*     */ 
/* 145 */         ccp.addInterface(ics[i]);
/*     */ 
/* 147 */         for (Method method : ics[i].getMethods())
/*     */         {
/* 149 */           if (!"java.lang.Object".equals(method.getDeclaringClass().getName()))
/*     */           {
/* 152 */             String desc = ReflectUtils.getDesc(method);
/* 153 */             if (!worked.contains(desc))
/*     */             {
/* 155 */               worked.add(desc);
/*     */ 
/* 157 */               int ix = findMethod(dcs, desc);
/* 158 */               if (ix < 0) {
/* 159 */                 throw new RuntimeException("Missing method [" + desc + "] implement.");
/*     */               }
/* 161 */               Class rt = method.getReturnType();
/* 162 */               String mn = method.getName();
/* 163 */               if (Void.TYPE.equals(rt)) {
/* 164 */                 ccp.addMethod(mn, method.getModifiers(), rt, method.getParameterTypes(), method.getExceptionTypes(), "d" + ix + "." + mn + "($$);");
/*     */               }
/*     */               else
/* 167 */                 ccp.addMethod(mn, method.getModifiers(), rt, method.getParameterTypes(), method.getExceptionTypes(), "return ($r)d" + ix + "." + mn + "($$);");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 172 */       if (pkg == null) {
/* 173 */         pkg = PACKAGE_NAME;
/*     */       }
/*     */ 
/* 176 */       String micn = pkg + ".mixin" + id;
/* 177 */       ccp.setClassName(micn);
/* 178 */       ccp.toClass();
/*     */ 
/* 181 */       String fcn = Mixin.class.getName() + id;
/* 182 */       ccm = ClassGenerator.newInstance(cl);
/* 183 */       ccm.setClassName(fcn);
/* 184 */       ccm.addDefaultConstructor();
/* 185 */       ccm.setSuperClass(Mixin.class.getName());
/* 186 */       ccm.addMethod("public Object newInstance(Object[] delegates){ return new " + micn + "($1); }");
/* 187 */       Class mixin = ccm.toClass();
/* 188 */       return (Mixin)mixin.newInstance();
/*     */     }
/*     */     catch (RuntimeException e)
/*     */     {
/* 192 */       throw e;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 196 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */     finally
/*     */     {
/* 201 */       if (ccp != null)
/* 202 */         ccp.release();
/* 203 */       if (ccm != null)
/* 204 */         ccm.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public abstract Object newInstance(Object[] paramArrayOfObject);
/*     */ 
/*     */   private static int findMethod(Class<?>[] dcs, String desc)
/*     */   {
/* 222 */     for (int i = 0; i < dcs.length; i++)
/*     */     {
/* 224 */       Class cl = dcs[i];
/* 225 */       Method[] methods = cl.getMethods();
/* 226 */       for (Method method : methods)
/*     */       {
/* 228 */         if (desc.equals(ReflectUtils.getDesc(method)))
/* 229 */           return i;
/*     */       }
/*     */     }
/* 232 */     return -1;
/*     */   }
/*     */ 
/*     */   private static void assertInterfaceArray(Class<?>[] ics)
/*     */   {
/* 237 */     for (int i = 0; i < ics.length; i++)
/* 238 */       if (!ics[i].isInterface())
/* 239 */         throw new RuntimeException("Class " + ics[i].getName() + " is not a interface.");
/*     */   }
/*     */ 
/*     */   public static abstract interface MixinAware
/*     */   {
/*     */     public abstract void setMixinInstance(Object paramObject);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.bytecode.Mixin
 * JD-Core Version:    0.6.2
 */