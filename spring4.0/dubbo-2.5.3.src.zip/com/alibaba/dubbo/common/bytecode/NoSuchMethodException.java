/*    */ package com.alibaba.dubbo.common.bytecode;
/*    */ 
/*    */ public class NoSuchMethodException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -2725364246023268766L;
/*    */ 
/*    */   public NoSuchMethodException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NoSuchMethodException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.bytecode.NoSuchMethodException
 * JD-Core Version:    0.6.2
 */