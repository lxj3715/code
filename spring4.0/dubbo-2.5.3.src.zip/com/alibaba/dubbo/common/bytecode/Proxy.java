/*     */ package com.alibaba.dubbo.common.bytecode;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ public abstract class Proxy
/*     */ {
/*  43 */   private static final AtomicLong PROXY_CLASS_COUNTER = new AtomicLong(0L);
/*     */ 
/*  45 */   private static final String PACKAGE_NAME = Proxy.class.getPackage().getName();
/*     */ 
/*  47 */   public static final InvocationHandler RETURN_NULL_INVOKER = new InvocationHandler() {
/*  48 */     public Object invoke(Object proxy, Method method, Object[] args) { return null; }
/*     */ 
/*  47 */   };
/*     */ 
/*  51 */   public static final InvocationHandler THROW_UNSUPPORTED_INVOKER = new InvocationHandler() {
/*  52 */     public Object invoke(Object proxy, Method method, Object[] args) { throw new UnsupportedOperationException("Method [" + ReflectUtils.getName(method) + "] unimplemented."); }
/*     */ 
/*  51 */   };
/*     */ 
/*  55 */   private static final Map<ClassLoader, Map<String, Object>> ProxyCacheMap = new WeakHashMap();
/*     */ 
/*  57 */   private static final Object PendingGenerationMarker = new Object();
/*     */ 
/*     */   public static Proxy getProxy(Class<?>[] ics)
/*     */   {
/*  67 */     return getProxy(ClassHelper.getCallerClassLoader(Proxy.class), ics);
/*     */   }
/*     */ 
/*     */   public static Proxy getProxy(ClassLoader cl, Class<?>[] ics)
/*     */   {
/*  79 */     if (ics.length > 65535) {
/*  80 */       throw new IllegalArgumentException("interface limit exceeded");
/*     */     }
/*  82 */     StringBuilder sb = new StringBuilder();
/*  83 */     for (int i = 0; i < ics.length; i++)
/*     */     {
/*  85 */       String itf = ics[i].getName();
/*  86 */       if (!ics[i].isInterface()) {
/*  87 */         throw new RuntimeException(itf + " is not a interface.");
/*     */       }
/*  89 */       Class tmp = null;
/*     */       try
/*     */       {
/*  92 */         tmp = Class.forName(itf, false, cl);
/*     */       }
/*     */       catch (ClassNotFoundException e)
/*     */       {
/*     */       }
/*  97 */       if (tmp != ics[i]) {
/*  98 */         throw new IllegalArgumentException(ics[i] + " is not visible from class loader");
/*     */       }
/* 100 */       sb.append(itf).append(';');
/*     */     }
/*     */ 
/* 104 */     String key = sb.toString();
/*     */     Map cache;
/* 108 */     synchronized (ProxyCacheMap)
/*     */     {
/* 110 */       cache = (Map)ProxyCacheMap.get(cl);
/* 111 */       if (cache == null)
/*     */       {
/* 113 */         cache = new HashMap();
/* 114 */         ProxyCacheMap.put(cl, cache);
/*     */       }
/*     */     }
/*     */ 
/* 118 */     Proxy proxy = null;
/* 119 */     synchronized (cache)
/*     */     {
/*     */       while (true)
/*     */       {
/* 123 */         Object value = cache.get(key);
/* 124 */         if ((value instanceof Reference))
/*     */         {
/* 126 */           proxy = (Proxy)((Reference)value).get();
/* 127 */           if (proxy != null) {
/* 128 */             return proxy;
/*     */           }
/*     */         }
/* 131 */         if (value == PendingGenerationMarker) {
/*     */           try {
/* 133 */             cache.wait();
/*     */           } catch (InterruptedException e) {
/*     */           }
/*     */         } else {
/* 137 */           cache.put(key, PendingGenerationMarker);
/* 138 */           break;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 144 */     long id = PROXY_CLASS_COUNTER.getAndIncrement();
/* 145 */     String pkg = null;
/* 146 */     ClassGenerator ccp = null; ClassGenerator ccm = null;
/*     */     try
/*     */     {
/* 149 */       ccp = ClassGenerator.newInstance(cl);
/*     */ 
/* 151 */       Set worked = new HashSet();
/* 152 */       List methods = new ArrayList();
/*     */ 
/* 154 */       for (int i = 0; i < ics.length; i++)
/*     */       {
/* 156 */         if (!Modifier.isPublic(ics[i].getModifiers()))
/*     */         {
/* 158 */           String npkg = ics[i].getPackage().getName();
/* 159 */           if (pkg == null)
/*     */           {
/* 161 */             pkg = npkg;
/*     */           }
/* 165 */           else if (!pkg.equals(npkg)) {
/* 166 */             throw new IllegalArgumentException("non-public interfaces from different packages");
/*     */           }
/*     */         }
/* 169 */         ccp.addInterface(ics[i]);
/*     */ 
/* 171 */         for (Method method : ics[i].getMethods())
/*     */         {
/* 173 */           String desc = ReflectUtils.getDesc(method);
/* 174 */           if (!worked.contains(desc))
/*     */           {
/* 176 */             worked.add(desc);
/*     */ 
/* 178 */             int ix = methods.size();
/* 179 */             Class rt = method.getReturnType();
/* 180 */             Class[] pts = method.getParameterTypes();
/*     */ 
/* 182 */             StringBuilder code = new StringBuilder("Object[] args = new Object[").append(pts.length).append("];");
/* 183 */             for (int j = 0; j < pts.length; j++)
/* 184 */               code.append(" args[").append(j).append("] = ($w)$").append(j + 1).append(";");
/* 185 */             code.append(" Object ret = handler.invoke(this, methods[" + ix + "], args);");
/* 186 */             if (!Void.TYPE.equals(rt)) {
/* 187 */               code.append(" return ").append(asArgument(rt, "ret")).append(";");
/*     */             }
/* 189 */             methods.add(method);
/* 190 */             ccp.addMethod(method.getName(), method.getModifiers(), rt, pts, method.getExceptionTypes(), code.toString());
/*     */           }
/*     */         }
/*     */       }
/* 194 */       if (pkg == null) {
/* 195 */         pkg = PACKAGE_NAME;
/*     */       }
/*     */ 
/* 198 */       String pcn = pkg + ".proxy" + id;
/* 199 */       ccp.setClassName(pcn);
/* 200 */       ccp.addField("public static java.lang.reflect.Method[] methods;");
/* 201 */       ccp.addField("private " + InvocationHandler.class.getName() + " handler;");
/* 202 */       ccp.addConstructor(1, new Class[] { InvocationHandler.class }, new Class[0], "handler=$1;");
/* 203 */       ccp.addDefaultConstructor();
/* 204 */       Class clazz = ccp.toClass();
/* 205 */       clazz.getField("methods").set(null, methods.toArray(new Method[0]));
/*     */ 
/* 208 */       String fcn = Proxy.class.getName() + id;
/* 209 */       ccm = ClassGenerator.newInstance(cl);
/* 210 */       ccm.setClassName(fcn);
/* 211 */       ccm.addDefaultConstructor();
/* 212 */       ccm.setSuperClass(Proxy.class);
/* 213 */       ccm.addMethod("public Object newInstance(" + InvocationHandler.class.getName() + " h){ return new " + pcn + "($1); }");
/* 214 */       Class pc = ccm.toClass();
/* 215 */       proxy = (Proxy)pc.newInstance();
/*     */     }
/*     */     catch (RuntimeException e)
/*     */     {
/* 219 */       throw e;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 223 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */     finally
/*     */     {
/* 228 */       if (ccp != null)
/* 229 */         ccp.release();
/* 230 */       if (ccm != null)
/* 231 */         ccm.release();
/* 232 */       synchronized (cache)
/*     */       {
/* 234 */         if (proxy == null)
/* 235 */           cache.remove(key);
/*     */         else
/* 237 */           cache.put(key, new WeakReference(proxy));
/* 238 */         cache.notifyAll();
/*     */       }
/*     */     }
/* 241 */     return proxy;
/*     */   }
/*     */ 
/*     */   public Object newInstance()
/*     */   {
/* 251 */     return newInstance(THROW_UNSUPPORTED_INVOKER);
/*     */   }
/*     */ 
/*     */   public abstract Object newInstance(InvocationHandler paramInvocationHandler);
/*     */ 
/*     */   private static String asArgument(Class<?> cl, String name)
/*     */   {
/* 265 */     if (cl.isPrimitive())
/*     */     {
/* 267 */       if (Boolean.TYPE == cl)
/* 268 */         return name + "==null?false:((Boolean)" + name + ").booleanValue()";
/* 269 */       if (Byte.TYPE == cl)
/* 270 */         return name + "==null?(byte)0:((Byte)" + name + ").byteValue()";
/* 271 */       if (Character.TYPE == cl)
/* 272 */         return name + "==null?(char)0:((Character)" + name + ").charValue()";
/* 273 */       if (Double.TYPE == cl)
/* 274 */         return name + "==null?(double)0:((Double)" + name + ").doubleValue()";
/* 275 */       if (Float.TYPE == cl)
/* 276 */         return name + "==null?(float)0:((Float)" + name + ").floatValue()";
/* 277 */       if (Integer.TYPE == cl)
/* 278 */         return name + "==null?(int)0:((Integer)" + name + ").intValue()";
/* 279 */       if (Long.TYPE == cl)
/* 280 */         return name + "==null?(long)0:((Long)" + name + ").longValue()";
/* 281 */       if (Short.TYPE == cl)
/* 282 */         return name + "==null?(short)0:((Short)" + name + ").shortValue()";
/* 283 */       throw new RuntimeException(name + " is unknown primitive type.");
/*     */     }
/* 285 */     return "(" + ReflectUtils.getName(cl) + ")" + name;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.bytecode.Proxy
 * JD-Core Version:    0.6.2
 */