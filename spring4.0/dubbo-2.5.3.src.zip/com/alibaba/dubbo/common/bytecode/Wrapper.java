/*     */ package com.alibaba.dubbo.common.bytecode;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public abstract class Wrapper
/*     */ {
/*  42 */   private static AtomicLong WRAPPER_CLASS_COUNTER = new AtomicLong(0L);
/*     */ 
/*  44 */   private static final Map<Class<?>, Wrapper> WRAPPER_MAP = new ConcurrentHashMap();
/*     */ 
/*  46 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */ 
/*  48 */   private static final String[] OBJECT_METHODS = { "getClass", "hashCode", "toString", "equals" };
/*     */ 
/*  50 */   private static final Wrapper OBJECT_WRAPPER = new Wrapper() {
/*  51 */     public String[] getMethodNames() { return Wrapper.OBJECT_METHODS; } 
/*  52 */     public String[] getDeclaredMethodNames() { return Wrapper.OBJECT_METHODS; } 
/*  53 */     public String[] getPropertyNames() { return Wrapper.EMPTY_STRING_ARRAY; } 
/*  54 */     public Class<?> getPropertyType(String pn) { return null; } 
/*  55 */     public Object getPropertyValue(Object instance, String pn) throws NoSuchPropertyException { throw new NoSuchPropertyException("Property [" + pn + "] not found."); } 
/*  56 */     public void setPropertyValue(Object instance, String pn, Object pv) throws NoSuchPropertyException { throw new NoSuchPropertyException("Property [" + pn + "] not found."); } 
/*  57 */     public boolean hasProperty(String name) { return false; }
/*     */ 
/*     */     public Object invokeMethod(Object instance, String mn, Class<?>[] types, Object[] args) throws NoSuchMethodException {
/*  60 */       if ("getClass".equals(mn)) return instance.getClass();
/*  61 */       if ("hashCode".equals(mn)) return Integer.valueOf(instance.hashCode());
/*  62 */       if ("toString".equals(mn)) return instance.toString();
/*  63 */       if ("equals".equals(mn))
/*     */       {
/*  65 */         if (args.length == 1) return Boolean.valueOf(instance.equals(args[0]));
/*  66 */         throw new IllegalArgumentException("Invoke method [" + mn + "] argument number error.");
/*     */       }
/*  68 */       throw new NoSuchMethodException("Method [" + mn + "] not found.");
/*     */     }
/*  50 */   };
/*     */ 
/*     */   public static Wrapper getWrapper(Class<?> c)
/*     */   {
/*  80 */     while (ClassGenerator.isDynamicClass(c)) {
/*  81 */       c = c.getSuperclass();
/*     */     }
/*  83 */     if (c == Object.class) {
/*  84 */       return OBJECT_WRAPPER;
/*     */     }
/*  86 */     Wrapper ret = (Wrapper)WRAPPER_MAP.get(c);
/*  87 */     if (ret == null)
/*     */     {
/*  89 */       ret = makeWrapper(c);
/*  90 */       WRAPPER_MAP.put(c, ret);
/*     */     }
/*  92 */     return ret;
/*     */   }
/*     */ 
/*     */   public abstract String[] getPropertyNames();
/*     */ 
/*     */   public abstract Class<?> getPropertyType(String paramString);
/*     */ 
/*     */   public abstract boolean hasProperty(String paramString);
/*     */ 
/*     */   public abstract Object getPropertyValue(Object paramObject, String paramString)
/*     */     throws NoSuchPropertyException, IllegalArgumentException;
/*     */ 
/*     */   public abstract void setPropertyValue(Object paramObject1, String paramString, Object paramObject2)
/*     */     throws NoSuchPropertyException, IllegalArgumentException;
/*     */ 
/*     */   public Object[] getPropertyValues(Object instance, String[] pns)
/*     */     throws NoSuchPropertyException, IllegalArgumentException
/*     */   {
/* 144 */     Object[] ret = new Object[pns.length];
/* 145 */     for (int i = 0; i < ret.length; i++)
/* 146 */       ret[i] = getPropertyValue(instance, pns[i]);
/* 147 */     return ret;
/*     */   }
/*     */ 
/*     */   public void setPropertyValues(Object instance, String[] pns, Object[] pvs)
/*     */     throws NoSuchPropertyException, IllegalArgumentException
/*     */   {
/* 159 */     if (pns.length != pvs.length) {
/* 160 */       throw new IllegalArgumentException("pns.length != pvs.length");
/*     */     }
/* 162 */     for (int i = 0; i < pns.length; i++)
/* 163 */       setPropertyValue(instance, pns[i], pvs[i]);
/*     */   }
/*     */ 
/*     */   public abstract String[] getMethodNames();
/*     */ 
/*     */   public abstract String[] getDeclaredMethodNames();
/*     */ 
/*     */   public boolean hasMethod(String name)
/*     */   {
/* 188 */     for (String mn : getMethodNames())
/* 189 */       if (mn.equals(name)) return true;
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */   public abstract Object invokeMethod(Object paramObject, String paramString, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject)
/*     */     throws NoSuchMethodException, InvocationTargetException;
/*     */ 
/*     */   private static Wrapper makeWrapper(Class<?> c)
/*     */   {
/* 206 */     if (c.isPrimitive()) {
/* 207 */       throw new IllegalArgumentException("Can not create wrapper for primitive type: " + c);
/*     */     }
/* 209 */     String name = c.getName();
/* 210 */     ClassLoader cl = ClassHelper.getCallerClassLoader(Wrapper.class);
/*     */ 
/* 212 */     StringBuilder c1 = new StringBuilder("public void setPropertyValue(Object o, String n, Object v){ ");
/* 213 */     StringBuilder c2 = new StringBuilder("public Object getPropertyValue(Object o, String n){ ");
/* 214 */     StringBuilder c3 = new StringBuilder("public Object invokeMethod(Object o, String n, Class[] p, Object[] v) throws " + InvocationTargetException.class.getName() + "{ ");
/*     */ 
/* 216 */     c1.append(name).append(" w; try{ w = ((").append(name).append(")$1); }catch(Throwable e){ throw new IllegalArgumentException(e); }");
/* 217 */     c2.append(name).append(" w; try{ w = ((").append(name).append(")$1); }catch(Throwable e){ throw new IllegalArgumentException(e); }");
/* 218 */     c3.append(name).append(" w; try{ w = ((").append(name).append(")$1); }catch(Throwable e){ throw new IllegalArgumentException(e); }");
/*     */ 
/* 220 */     Map pts = new HashMap();
/* 221 */     Map ms = new LinkedHashMap();
/* 222 */     List mns = new ArrayList();
/* 223 */     List dmns = new ArrayList();
/*     */ 
/* 226 */     for (Field f : c.getFields())
/*     */     {
/* 228 */       String fn = f.getName();
/* 229 */       Class ft = f.getType();
/* 230 */       if ((!Modifier.isStatic(f.getModifiers())) && (!Modifier.isTransient(f.getModifiers())))
/*     */       {
/* 233 */         c1.append(" if( $2.equals(\"").append(fn).append("\") ){ w.").append(fn).append("=").append(arg(ft, "$3")).append("; return; }");
/* 234 */         c2.append(" if( $2.equals(\"").append(fn).append("\") ){ return ($w)w.").append(fn).append("; }");
/* 235 */         pts.put(fn, ft);
/*     */       }
/*     */     }
/* 238 */     Method[] methods = c.getMethods();
/*     */ 
/* 240 */     boolean hasMethod = hasMethods(methods);
/* 241 */     if (hasMethod) {
/* 242 */       c3.append(" try{");
/*     */     }
/* 244 */     for (Method m : methods)
/*     */     {
/* 246 */       if (m.getDeclaringClass() != Object.class)
/*     */       {
/* 249 */         String mn = m.getName();
/* 250 */         c3.append(" if( \"").append(mn).append("\".equals( $2 ) ");
/* 251 */         int len = m.getParameterTypes().length;
/* 252 */         c3.append(" && ").append(" $3.length == ").append(len);
/*     */ 
/* 254 */         boolean override = false;
/* 255 */         for (Method m2 : methods) {
/* 256 */           if ((m != m2) && (m.getName().equals(m2.getName()))) {
/* 257 */             override = true;
/* 258 */             break;
/*     */           }
/*     */         }
/* 261 */         if ((override) && 
/* 262 */           (len > 0)) {
/* 263 */           for (int l = 0; l < len; l++) {
/* 264 */             c3.append(" && ").append(" $3[").append(l).append("].getName().equals(\"").append(m.getParameterTypes()[l].getName()).append("\")");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 270 */         c3.append(" ) { ");
/*     */ 
/* 272 */         if (m.getReturnType() == Void.TYPE)
/* 273 */           c3.append(" w.").append(mn).append('(').append(args(m.getParameterTypes(), "$4")).append(");").append(" return null;");
/*     */         else {
/* 275 */           c3.append(" return ($w)w.").append(mn).append('(').append(args(m.getParameterTypes(), "$4")).append(");");
/*     */         }
/* 277 */         c3.append(" }");
/*     */ 
/* 279 */         mns.add(mn);
/* 280 */         if (m.getDeclaringClass() == c)
/* 281 */           dmns.add(mn);
/* 282 */         ms.put(ReflectUtils.getDesc(m), m);
/*     */       }
/*     */     }
/* 284 */     if (hasMethod) {
/* 285 */       c3.append(" } catch(Throwable e) { ");
/* 286 */       c3.append("     throw new java.lang.reflect.InvocationTargetException(e); ");
/* 287 */       c3.append(" }");
/*     */     }
/*     */ 
/* 290 */     c3.append(" throw new " + NoSuchMethodException.class.getName() + "(\"Not found method \\\"\"+$2+\"\\\" in class " + c.getName() + ".\"); }");
/*     */ 
/* 294 */     for (Map.Entry entry : ms.entrySet())
/*     */     {
/* 296 */       String md = (String)entry.getKey();
/* 297 */       Method method = (Method)entry.getValue();
/*     */       Matcher matcher;
/* 298 */       if ((matcher = ReflectUtils.GETTER_METHOD_DESC_PATTERN.matcher(md)).matches())
/*     */       {
/* 300 */         String pn = propertyName(matcher.group(1));
/* 301 */         c2.append(" if( $2.equals(\"").append(pn).append("\") ){ return ($w)w.").append(method.getName()).append("(); }");
/* 302 */         pts.put(pn, method.getReturnType());
/*     */       }
/* 304 */       else if ((matcher = ReflectUtils.IS_HAS_CAN_METHOD_DESC_PATTERN.matcher(md)).matches())
/*     */       {
/* 306 */         String pn = propertyName(matcher.group(1));
/* 307 */         c2.append(" if( $2.equals(\"").append(pn).append("\") ){ return ($w)w.").append(method.getName()).append("(); }");
/* 308 */         pts.put(pn, method.getReturnType());
/*     */       }
/* 310 */       else if ((matcher = ReflectUtils.SETTER_METHOD_DESC_PATTERN.matcher(md)).matches())
/*     */       {
/* 312 */         Class pt = method.getParameterTypes()[0];
/* 313 */         String pn = propertyName(matcher.group(1));
/* 314 */         c1.append(" if( $2.equals(\"").append(pn).append("\") ){ w.").append(method.getName()).append("(").append(arg(pt, "$3")).append("); return; }");
/* 315 */         pts.put(pn, pt);
/*     */       }
/*     */     }
/* 318 */     c1.append(" throw new " + NoSuchPropertyException.class.getName() + "(\"Not found property \\\"\"+$2+\"\\\" filed or setter method in class " + c.getName() + ".\"); }");
/* 319 */     c2.append(" throw new " + NoSuchPropertyException.class.getName() + "(\"Not found property \\\"\"+$2+\"\\\" filed or setter method in class " + c.getName() + ".\"); }");
/*     */ 
/* 322 */     long id = WRAPPER_CLASS_COUNTER.getAndIncrement();
/* 323 */     ClassGenerator cc = ClassGenerator.newInstance(cl);
/* 324 */     cc.setClassName((Modifier.isPublic(c.getModifiers()) ? Wrapper.class.getName() : new StringBuilder().append(c.getName()).append("$sw").toString()) + id);
/* 325 */     cc.setSuperClass(Wrapper.class);
/*     */ 
/* 327 */     cc.addDefaultConstructor();
/* 328 */     cc.addField("public static String[] pns;");
/* 329 */     cc.addField("public static " + Map.class.getName() + " pts;");
/* 330 */     cc.addField("public static String[] mns;");
/* 331 */     cc.addField("public static String[] dmns;");
/* 332 */     int i = 0; for (int len = ms.size(); i < len; i++) {
/* 333 */       cc.addField("public static Class[] mts" + i + ";");
/*     */     }
/* 335 */     cc.addMethod("public String[] getPropertyNames(){ return pns; }");
/* 336 */     cc.addMethod("public boolean hasProperty(String n){ return pts.containsKey($1); }");
/* 337 */     cc.addMethod("public Class getPropertyType(String n){ return (Class)pts.get($1); }");
/* 338 */     cc.addMethod("public String[] getMethodNames(){ return mns; }");
/* 339 */     cc.addMethod("public String[] getDeclaredMethodNames(){ return dmns; }");
/* 340 */     cc.addMethod(c1.toString());
/* 341 */     cc.addMethod(c2.toString());
/* 342 */     cc.addMethod(c3.toString());
/*     */     try
/*     */     {
/* 346 */       Class wc = cc.toClass();
/*     */ 
/* 348 */       wc.getField("pts").set(null, pts);
/* 349 */       wc.getField("pns").set(null, pts.keySet().toArray(new String[0]));
/* 350 */       wc.getField("mns").set(null, mns.toArray(new String[0]));
/* 351 */       wc.getField("dmns").set(null, dmns.toArray(new String[0]));
/* 352 */       int ix = 0;
/* 353 */       for (Method m : ms.values())
/* 354 */         wc.getField("mts" + ix++).set(null, m.getParameterTypes());
/* 355 */       return (Wrapper)wc.newInstance();
/*     */     }
/*     */     catch (RuntimeException e)
/*     */     {
/* 359 */       throw e;
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 363 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */     finally
/*     */     {
/* 367 */       cc.release();
/* 368 */       ms.clear();
/* 369 */       mns.clear();
/* 370 */       dmns.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String arg(Class<?> cl, String name)
/*     */   {
/* 376 */     if (cl.isPrimitive())
/*     */     {
/* 378 */       if (cl == Boolean.TYPE)
/* 379 */         return "((Boolean)" + name + ").booleanValue()";
/* 380 */       if (cl == Byte.TYPE)
/* 381 */         return "((Byte)" + name + ").byteValue()";
/* 382 */       if (cl == Character.TYPE)
/* 383 */         return "((Character)" + name + ").charValue()";
/* 384 */       if (cl == Double.TYPE)
/* 385 */         return "((Number)" + name + ").doubleValue()";
/* 386 */       if (cl == Float.TYPE)
/* 387 */         return "((Number)" + name + ").floatValue()";
/* 388 */       if (cl == Integer.TYPE)
/* 389 */         return "((Number)" + name + ").intValue()";
/* 390 */       if (cl == Long.TYPE)
/* 391 */         return "((Number)" + name + ").longValue()";
/* 392 */       if (cl == Short.TYPE)
/* 393 */         return "((Number)" + name + ").shortValue()";
/* 394 */       throw new RuntimeException("Unknown primitive type: " + cl.getName());
/*     */     }
/* 396 */     return "(" + ReflectUtils.getName(cl) + ")" + name;
/*     */   }
/*     */ 
/*     */   private static String args(Class<?>[] cs, String name)
/*     */   {
/* 401 */     int len = cs.length;
/* 402 */     if (len == 0) return "";
/* 403 */     StringBuilder sb = new StringBuilder();
/* 404 */     for (int i = 0; i < len; i++)
/*     */     {
/* 406 */       if (i > 0)
/* 407 */         sb.append(',');
/* 408 */       sb.append(arg(cs[i], name + "[" + i + "]"));
/*     */     }
/* 410 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static String propertyName(String pn)
/*     */   {
/* 415 */     return (pn.length() == 1) || (Character.isLowerCase(pn.charAt(1))) ? Character.toLowerCase(pn.charAt(0)) + pn.substring(1) : pn;
/*     */   }
/*     */ 
/*     */   private static boolean hasMethods(Method[] methods) {
/* 419 */     if ((methods == null) || (methods.length == 0)) {
/* 420 */       return false;
/*     */     }
/* 422 */     for (Method m : methods) {
/* 423 */       if (m.getDeclaringClass() != Object.class) {
/* 424 */         return true;
/*     */       }
/*     */     }
/* 427 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.bytecode.Wrapper
 * JD-Core Version:    0.6.2
 */