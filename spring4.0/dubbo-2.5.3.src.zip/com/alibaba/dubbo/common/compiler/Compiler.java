package com.alibaba.dubbo.common.compiler;

import com.alibaba.dubbo.common.extension.SPI;

@SPI("javassist")
public abstract interface Compiler
{
  public abstract Class<?> compile(String paramString, ClassLoader paramClassLoader);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.compiler.Compiler
 * JD-Core Version:    0.6.2
 */