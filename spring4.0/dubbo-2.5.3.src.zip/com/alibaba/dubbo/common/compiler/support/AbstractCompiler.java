/*    */ package com.alibaba.dubbo.common.compiler.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.compiler.Compiler;
/*    */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public abstract class AbstractCompiler
/*    */   implements Compiler
/*    */ {
/* 31 */   private static final Pattern PACKAGE_PATTERN = Pattern.compile("package\\s+([$_a-zA-Z][$_a-zA-Z0-9\\.]*);");
/*    */ 
/* 33 */   private static final Pattern CLASS_PATTERN = Pattern.compile("class\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)\\s+");
/*    */ 
/*    */   public Class<?> compile(String code, ClassLoader classLoader) {
/* 36 */     code = code.trim();
/* 37 */     Matcher matcher = PACKAGE_PATTERN.matcher(code);
/*    */     String pkg;
/*    */     String pkg;
/* 39 */     if (matcher.find())
/* 40 */       pkg = matcher.group(1);
/*    */     else {
/* 42 */       pkg = "";
/*    */     }
/* 44 */     matcher = CLASS_PATTERN.matcher(code);
/*    */     String cls;
/* 46 */     if (matcher.find())
/* 47 */       cls = matcher.group(1);
/*    */     else
/* 49 */       throw new IllegalArgumentException("No such class name in " + code);
/*    */     String cls;
/* 51 */     String className = (pkg != null) && (pkg.length() > 0) ? pkg + "." + cls : cls;
/*    */     try {
/* 53 */       return Class.forName(className, true, ClassHelper.getCallerClassLoader(getClass()));
/*    */     } catch (ClassNotFoundException e) {
/* 55 */       if (!code.endsWith("}"))
/* 56 */         throw new IllegalStateException("The java code not endsWith \"}\", code: \n" + code + "\n");
/*    */       try
/*    */       {
/* 59 */         return doCompile(className, code);
/*    */       } catch (RuntimeException t) {
/* 61 */         throw t;
/*    */       } catch (Throwable t) {
/* 63 */         throw new IllegalStateException("Failed to compile class, cause: " + t.getMessage() + ", class: " + className + ", code: \n" + code + "\n, stack: " + ClassUtils.toString(t));
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract Class<?> doCompile(String paramString1, String paramString2)
/*    */     throws Throwable;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.compiler.support.AbstractCompiler
 * JD-Core Version:    0.6.2
 */