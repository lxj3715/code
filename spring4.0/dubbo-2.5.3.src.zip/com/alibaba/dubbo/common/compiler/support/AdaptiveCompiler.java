/*    */ package com.alibaba.dubbo.common.compiler.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.compiler.Compiler;
/*    */ import com.alibaba.dubbo.common.extension.Adaptive;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ 
/*    */ @Adaptive
/*    */ public class AdaptiveCompiler
/*    */   implements Compiler
/*    */ {
/*    */   private static volatile String DEFAULT_COMPILER;
/*    */ 
/*    */   public static void setDefaultCompiler(String compiler)
/*    */   {
/* 34 */     DEFAULT_COMPILER = compiler;
/*    */   }
/*    */ 
/*    */   public Class<?> compile(String code, ClassLoader classLoader)
/*    */   {
/* 39 */     ExtensionLoader loader = ExtensionLoader.getExtensionLoader(Compiler.class);
/* 40 */     String name = DEFAULT_COMPILER;
/*    */     Compiler compiler;
/*    */     Compiler compiler;
/* 41 */     if ((name != null) && (name.length() > 0))
/* 42 */       compiler = (Compiler)loader.getExtension(name);
/*    */     else {
/* 44 */       compiler = (Compiler)loader.getDefaultExtension();
/*    */     }
/* 46 */     return compiler.compile(code, classLoader);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.compiler.support.AdaptiveCompiler
 * JD-Core Version:    0.6.2
 */