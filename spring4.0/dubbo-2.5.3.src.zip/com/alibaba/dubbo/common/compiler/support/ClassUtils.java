/*     */ package com.alibaba.dubbo.common.compiler.support;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class ClassUtils
/*     */ {
/*     */   public static final String CLASS_EXTENSION = ".class";
/*     */   public static final String JAVA_EXTENSION = ".java";
/*     */   private static final int JIT_LIMIT = 5120;
/*     */ 
/*     */   public static Object newInstance(String name)
/*     */   {
/*     */     try
/*     */     {
/*  44 */       return forName(name).newInstance();
/*     */     } catch (InstantiationException e) {
/*  46 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     } catch (IllegalAccessException e) {
/*  48 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Class<?> forName(String[] packages, String className) {
/*     */     try {
/*  54 */       return _forName(className);
/*     */     } catch (ClassNotFoundException e) {
/*  56 */       if ((packages != null) && (packages.length > 0))
/*  57 */         for (String pkg : packages)
/*     */           try {
/*  59 */             return _forName(pkg + "." + className);
/*     */           }
/*     */           catch (ClassNotFoundException e2)
/*     */           {
/*     */           }
/*  64 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Class<?> forName(String className) {
/*     */     try {
/*  70 */       return _forName(className);
/*     */     } catch (ClassNotFoundException e) {
/*  72 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Class<?> _forName(String className) throws ClassNotFoundException {
/*  77 */     if ("boolean".equals(className))
/*  78 */       return Boolean.TYPE;
/*  79 */     if ("byte".equals(className))
/*  80 */       return Byte.TYPE;
/*  81 */     if ("char".equals(className))
/*  82 */       return Character.TYPE;
/*  83 */     if ("short".equals(className))
/*  84 */       return Short.TYPE;
/*  85 */     if ("int".equals(className))
/*  86 */       return Integer.TYPE;
/*  87 */     if ("long".equals(className))
/*  88 */       return Long.TYPE;
/*  89 */     if ("float".equals(className))
/*  90 */       return Float.TYPE;
/*  91 */     if ("double".equals(className))
/*  92 */       return Double.TYPE;
/*  93 */     if ("boolean[]".equals(className))
/*  94 */       return [Z.class;
/*  95 */     if ("byte[]".equals(className))
/*  96 */       return [B.class;
/*  97 */     if ("char[]".equals(className))
/*  98 */       return [C.class;
/*  99 */     if ("short[]".equals(className))
/* 100 */       return [S.class;
/* 101 */     if ("int[]".equals(className))
/* 102 */       return [I.class;
/* 103 */     if ("long[]".equals(className))
/* 104 */       return [J.class;
/* 105 */     if ("float[]".equals(className))
/* 106 */       return [F.class;
/* 107 */     if ("double[]".equals(className))
/* 108 */       return [D.class;
/*     */     try {
/* 110 */       return arrayForName(className);
/*     */     } catch (ClassNotFoundException e) {
/* 112 */       if (className.indexOf('.') == -1)
/*     */         try {
/* 114 */           return arrayForName("java.lang." + className);
/*     */         }
/*     */         catch (ClassNotFoundException e2)
/*     */         {
/*     */         }
/* 119 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Class<?> arrayForName(String className) throws ClassNotFoundException {
/* 124 */     return Class.forName(className.endsWith("[]") ? "[L" + className.substring(0, className.length() - 2) + ";" : className, true, Thread.currentThread().getContextClassLoader());
/*     */   }
/*     */ 
/*     */   public static Class<?> getBoxedClass(Class<?> type)
/*     */   {
/* 130 */     if (type == Boolean.TYPE)
/* 131 */       return Boolean.class;
/* 132 */     if (type == Character.TYPE)
/* 133 */       return Character.class;
/* 134 */     if (type == Byte.TYPE)
/* 135 */       return Byte.class;
/* 136 */     if (type == Short.TYPE)
/* 137 */       return Short.class;
/* 138 */     if (type == Integer.TYPE)
/* 139 */       return Integer.class;
/* 140 */     if (type == Long.TYPE)
/* 141 */       return Long.class;
/* 142 */     if (type == Float.TYPE)
/* 143 */       return Float.class;
/* 144 */     if (type == Double.TYPE) {
/* 145 */       return Double.class;
/*     */     }
/* 147 */     return type;
/*     */   }
/*     */ 
/*     */   public static Boolean boxed(boolean v)
/*     */   {
/* 152 */     return Boolean.valueOf(v);
/*     */   }
/*     */ 
/*     */   public static Character boxed(char v) {
/* 156 */     return Character.valueOf(v);
/*     */   }
/*     */ 
/*     */   public static Byte boxed(byte v) {
/* 160 */     return Byte.valueOf(v);
/*     */   }
/*     */ 
/*     */   public static Short boxed(short v) {
/* 164 */     return Short.valueOf(v);
/*     */   }
/*     */ 
/*     */   public static Integer boxed(int v) {
/* 168 */     return Integer.valueOf(v);
/*     */   }
/*     */ 
/*     */   public static Long boxed(long v) {
/* 172 */     return Long.valueOf(v);
/*     */   }
/*     */ 
/*     */   public static Float boxed(float v) {
/* 176 */     return Float.valueOf(v);
/*     */   }
/*     */ 
/*     */   public static Double boxed(double v) {
/* 180 */     return Double.valueOf(v);
/*     */   }
/*     */ 
/*     */   public static Object boxed(Object v) {
/* 184 */     return v;
/*     */   }
/*     */ 
/*     */   public static boolean unboxed(Boolean v) {
/* 188 */     return v == null ? false : v.booleanValue();
/*     */   }
/*     */ 
/*     */   public static char unboxed(Character v) {
/* 192 */     return v == null ? '\000' : v.charValue();
/*     */   }
/*     */ 
/*     */   public static byte unboxed(Byte v) {
/* 196 */     return v == null ? 0 : v.byteValue();
/*     */   }
/*     */ 
/*     */   public static short unboxed(Short v) {
/* 200 */     return v == null ? 0 : v.shortValue();
/*     */   }
/*     */ 
/*     */   public static int unboxed(Integer v) {
/* 204 */     return v == null ? 0 : v.intValue();
/*     */   }
/*     */ 
/*     */   public static long unboxed(Long v) {
/* 208 */     return v == null ? 0L : v.longValue();
/*     */   }
/*     */ 
/*     */   public static float unboxed(Float v) {
/* 212 */     return v == null ? 0.0F : v.floatValue();
/*     */   }
/*     */ 
/*     */   public static double unboxed(Double v) {
/* 216 */     return v == null ? 0.0D : v.doubleValue();
/*     */   }
/*     */ 
/*     */   public static Object unboxed(Object v) {
/* 220 */     return v;
/*     */   }
/*     */ 
/*     */   public static boolean isNotEmpty(Object object) {
/* 224 */     return getSize(object) > 0;
/*     */   }
/*     */ 
/*     */   public static int getSize(Object object) {
/* 228 */     if (object == null)
/* 229 */       return 0;
/* 230 */     if ((object instanceof Collection))
/* 231 */       return ((Collection)object).size();
/* 232 */     if ((object instanceof Map))
/* 233 */       return ((Map)object).size();
/* 234 */     if (object.getClass().isArray()) {
/* 235 */       return Array.getLength(object);
/*     */     }
/* 237 */     return -1;
/*     */   }
/*     */ 
/*     */   public static URI toURI(String name)
/*     */   {
/*     */     try {
/* 243 */       return new URI(name);
/*     */     } catch (URISyntaxException e) {
/* 245 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Class<?> getGenericClass(Class<?> cls) {
/* 250 */     return getGenericClass(cls, 0);
/*     */   }
/*     */ 
/*     */   public static Class<?> getGenericClass(Class<?> cls, int i) {
/*     */     try {
/* 255 */       ParameterizedType parameterizedType = (ParameterizedType)cls.getGenericInterfaces()[0];
/* 256 */       Object genericClass = parameterizedType.getActualTypeArguments()[i];
/* 257 */       if ((genericClass instanceof ParameterizedType))
/* 258 */         return (Class)((ParameterizedType)genericClass).getRawType();
/* 259 */       if ((genericClass instanceof GenericArrayType))
/* 260 */         return (Class)((GenericArrayType)genericClass).getGenericComponentType();
/* 261 */       if (genericClass != null)
/* 262 */         return (Class)genericClass;
/*     */     }
/*     */     catch (Throwable e) {
/*     */     }
/* 266 */     if (cls.getSuperclass() != null) {
/* 267 */       return getGenericClass(cls.getSuperclass(), i);
/*     */     }
/* 269 */     throw new IllegalArgumentException(cls.getName() + " generic type undefined!");
/*     */   }
/*     */ 
/*     */   public static boolean isBeforeJava5(String javaVersion)
/*     */   {
/* 274 */     return (javaVersion == null) || (javaVersion.length() == 0) || ("1.0".equals(javaVersion)) || ("1.1".equals(javaVersion)) || ("1.2".equals(javaVersion)) || ("1.3".equals(javaVersion)) || ("1.4".equals(javaVersion));
/*     */   }
/*     */ 
/*     */   public static boolean isBeforeJava6(String javaVersion)
/*     */   {
/* 280 */     return (isBeforeJava5(javaVersion)) || ("1.5".equals(javaVersion));
/*     */   }
/*     */ 
/*     */   public static String toString(Throwable e) {
/* 284 */     StringWriter w = new StringWriter();
/* 285 */     PrintWriter p = new PrintWriter(w);
/* 286 */     p.print(e.getClass().getName() + ": ");
/* 287 */     if (e.getMessage() != null) {
/* 288 */       p.print(e.getMessage() + "\n");
/*     */     }
/* 290 */     p.println();
/*     */     try {
/* 292 */       e.printStackTrace(p);
/* 293 */       return w.toString();
/*     */     } finally {
/* 295 */       p.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void checkBytecode(String name, byte[] bytecode)
/*     */   {
/* 302 */     if (bytecode.length > 5120)
/* 303 */       System.err.println("The template bytecode too long, may be affect the JIT compiler. template class: " + name);
/*     */   }
/*     */ 
/*     */   public static String getSizeMethod(Class<?> cls)
/*     */   {
/*     */     try {
/* 309 */       return cls.getMethod("size", new Class[0]).getName() + "()";
/*     */     } catch (NoSuchMethodException e) {
/*     */       try {
/* 312 */         return cls.getMethod("length", new Class[0]).getName() + "()";
/*     */       } catch (NoSuchMethodException e2) {
/*     */         try {
/* 315 */           return cls.getMethod("getSize", new Class[0]).getName() + "()";
/*     */         } catch (NoSuchMethodException e3) {
/*     */           try {
/* 318 */             return cls.getMethod("getLength", new Class[0]).getName() + "()"; } catch (NoSuchMethodException e4) {  }  } 
/*     */       }
/*     */     }
/* 320 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getMethodName(Method method, Class<?>[] parameterClasses, String rightCode)
/*     */   {
/* 328 */     if (method.getParameterTypes().length > parameterClasses.length) {
/* 329 */       Class[] types = method.getParameterTypes();
/* 330 */       StringBuilder buf = new StringBuilder(rightCode);
/* 331 */       for (int i = parameterClasses.length; i < types.length; i++) {
/* 332 */         if (buf.length() > 0) {
/* 333 */           buf.append(",");
/*     */         }
/* 335 */         Class type = types[i];
/*     */         String def;
/*     */         String def;
/* 337 */         if (type == Boolean.TYPE) {
/* 338 */           def = "false";
/*     */         }
/*     */         else
/*     */         {
/*     */           String def;
/* 339 */           if (type == Character.TYPE) {
/* 340 */             def = "'\\0'";
/*     */           }
/*     */           else
/*     */           {
/*     */             String def;
/* 341 */             if ((type == Byte.TYPE) || (type == Short.TYPE) || (type == Integer.TYPE) || (type == Long.TYPE) || (type == Float.TYPE) || (type == Double.TYPE))
/*     */             {
/* 347 */               def = "0";
/*     */             }
/* 349 */             else def = "null"; 
/*     */           }
/*     */         }
/* 351 */         buf.append(def);
/*     */       }
/*     */     }
/* 354 */     return method.getName() + "(" + rightCode + ")";
/*     */   }
/*     */ 
/*     */   public static Method searchMethod(Class<?> currentClass, String name, Class<?>[] parameterTypes) throws NoSuchMethodException {
/* 358 */     if (currentClass == null)
/* 359 */       throw new NoSuchMethodException("class == null");
/*     */     try
/*     */     {
/* 362 */       return currentClass.getMethod(name, parameterTypes);
/*     */     } catch (NoSuchMethodException e) {
/* 364 */       for (Method method : currentClass.getMethods())
/* 365 */         if ((method.getName().equals(name)) && (parameterTypes.length == method.getParameterTypes().length) && (Modifier.isPublic(method.getModifiers())))
/*     */         {
/* 368 */           if (parameterTypes.length > 0) {
/* 369 */             Class[] types = method.getParameterTypes();
/* 370 */             boolean match = true;
/* 371 */             for (int i = 0; i < parameterTypes.length; i++) {
/* 372 */               if (!types[i].isAssignableFrom(parameterTypes[i])) {
/* 373 */                 match = false;
/* 374 */                 break;
/*     */               }
/*     */             }
/* 377 */             if (!match);
/*     */           }
/*     */           else
/*     */           {
/* 381 */             return method;
/*     */           }
/*     */         }
/* 384 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getInitCode(Class<?> type) {
/* 389 */     if ((Byte.TYPE.equals(type)) || (Short.TYPE.equals(type)) || (Integer.TYPE.equals(type)) || (Long.TYPE.equals(type)) || (Float.TYPE.equals(type)) || (Double.TYPE.equals(type)))
/*     */     {
/* 395 */       return "0";
/* 396 */     }if (Character.TYPE.equals(type))
/* 397 */       return "'\\0'";
/* 398 */     if (Boolean.TYPE.equals(type)) {
/* 399 */       return "false";
/*     */     }
/* 401 */     return "null";
/*     */   }
/*     */ 
/*     */   public static <K, V> Map<K, V> toMap(Map.Entry<K, V>[] entries)
/*     */   {
/* 406 */     Map map = new HashMap();
/* 407 */     if ((entries != null) && (entries.length > 0)) {
/* 408 */       for (Map.Entry enrty : entries) {
/* 409 */         map.put(enrty.getKey(), enrty.getValue());
/*     */       }
/*     */     }
/* 412 */     return map;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.compiler.support.ClassUtils
 * JD-Core Version:    0.6.2
 */