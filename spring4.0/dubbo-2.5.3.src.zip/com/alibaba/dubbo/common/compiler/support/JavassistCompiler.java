/*     */ package com.alibaba.dubbo.common.compiler.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javassist.ClassPool;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtField;
/*     */ import javassist.CtNewConstructor;
/*     */ import javassist.CtNewMethod;
/*     */ import javassist.LoaderClassPath;
/*     */ 
/*     */ public class JavassistCompiler extends AbstractCompiler
/*     */ {
/*  41 */   private static final Pattern IMPORT_PATTERN = Pattern.compile("import\\s+([\\w\\.\\*]+);\n");
/*     */ 
/*  43 */   private static final Pattern EXTENDS_PATTERN = Pattern.compile("\\s+extends\\s+([\\w\\.]+)[^\\{]*\\{\n");
/*     */ 
/*  45 */   private static final Pattern IMPLEMENTS_PATTERN = Pattern.compile("\\s+implements\\s+([\\w\\.]+)\\s*\\{\n");
/*     */ 
/*  47 */   private static final Pattern METHODS_PATTERN = Pattern.compile("\n(private|public|protected)\\s+");
/*     */ 
/*  49 */   private static final Pattern FIELD_PATTERN = Pattern.compile("[^\n]+=[^\n]+;");
/*     */ 
/*     */   public Class<?> doCompile(String name, String source) throws Throwable
/*     */   {
/*  53 */     int i = name.lastIndexOf('.');
/*  54 */     String className = i < 0 ? name : name.substring(i + 1);
/*  55 */     ClassPool pool = new ClassPool(true);
/*  56 */     pool.appendClassPath(new LoaderClassPath(ClassHelper.getCallerClassLoader(getClass())));
/*  57 */     Matcher matcher = IMPORT_PATTERN.matcher(source);
/*  58 */     List importPackages = new ArrayList();
/*  59 */     Map fullNames = new HashMap();
/*  60 */     while (matcher.find()) {
/*  61 */       String pkg = matcher.group(1);
/*  62 */       if (pkg.endsWith(".*")) {
/*  63 */         String pkgName = pkg.substring(0, pkg.length() - 2);
/*  64 */         pool.importPackage(pkgName);
/*  65 */         importPackages.add(pkgName);
/*     */       } else {
/*  67 */         int pi = pkg.lastIndexOf('.');
/*  68 */         if (pi > 0) {
/*  69 */           String pkgName = pkg.substring(0, pi);
/*  70 */           pool.importPackage(pkgName);
/*  71 */           importPackages.add(pkgName);
/*  72 */           fullNames.put(pkg.substring(pi + 1), pkg);
/*     */         }
/*     */       }
/*     */     }
/*  76 */     String[] packages = (String[])importPackages.toArray(new String[0]);
/*  77 */     matcher = EXTENDS_PATTERN.matcher(source);
/*     */     CtClass cls;
/*     */     CtClass cls;
/*  79 */     if (matcher.find()) {
/*  80 */       String extend = matcher.group(1).trim();
/*     */       String extendClass;
/*     */       String extendClass;
/*  82 */       if (extend.contains(".")) {
/*  83 */         extendClass = extend;
/*     */       }
/*     */       else
/*     */       {
/*     */         String extendClass;
/*  84 */         if (fullNames.containsKey(extend))
/*  85 */           extendClass = (String)fullNames.get(extend);
/*     */         else
/*  87 */           extendClass = ClassUtils.forName(packages, extend).getName();
/*     */       }
/*  89 */       cls = pool.makeClass(name, pool.get(extendClass));
/*     */     } else {
/*  91 */       cls = pool.makeClass(name);
/*     */     }
/*  93 */     matcher = IMPLEMENTS_PATTERN.matcher(source);
/*  94 */     if (matcher.find()) {
/*  95 */       String[] ifaces = matcher.group(1).trim().split("\\,");
/*  96 */       for (String iface : ifaces) {
/*  97 */         iface = iface.trim();
/*     */         String ifaceClass;
/*     */         String ifaceClass;
/*  99 */         if (iface.contains(".")) {
/* 100 */           ifaceClass = iface;
/*     */         }
/*     */         else
/*     */         {
/*     */           String ifaceClass;
/* 101 */           if (fullNames.containsKey(iface))
/* 102 */             ifaceClass = (String)fullNames.get(iface);
/*     */           else
/* 104 */             ifaceClass = ClassUtils.forName(packages, iface).getName();
/*     */         }
/* 106 */         cls.addInterface(pool.get(ifaceClass));
/*     */       }
/*     */     }
/* 109 */     String body = source.substring(source.indexOf("{") + 1, source.length() - 1);
/* 110 */     String[] methods = METHODS_PATTERN.split(body);
/* 111 */     for (String method : methods) {
/* 112 */       method = method.trim();
/* 113 */       if (method.length() > 0) {
/* 114 */         if (method.startsWith(className))
/* 115 */           cls.addConstructor(CtNewConstructor.make("public " + method, cls));
/* 116 */         else if (FIELD_PATTERN.matcher(method).matches())
/* 117 */           cls.addField(CtField.make("private " + method, cls));
/*     */         else {
/* 119 */           cls.addMethod(CtNewMethod.make("public " + method, cls));
/*     */         }
/*     */       }
/*     */     }
/* 123 */     return cls.toClass(ClassHelper.getCallerClassLoader(getClass()), null);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.compiler.support.JavassistCompiler
 * JD-Core Version:    0.6.2
 */