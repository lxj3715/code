/*     */ package com.alibaba.dubbo.common.compiler.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.tools.DiagnosticCollector;
/*     */ import javax.tools.FileObject;
/*     */ import javax.tools.ForwardingJavaFileManager;
/*     */ import javax.tools.JavaCompiler;
/*     */ import javax.tools.JavaCompiler.CompilationTask;
/*     */ import javax.tools.JavaFileManager;
/*     */ import javax.tools.JavaFileManager.Location;
/*     */ import javax.tools.JavaFileObject;
/*     */ import javax.tools.JavaFileObject.Kind;
/*     */ import javax.tools.SimpleJavaFileObject;
/*     */ import javax.tools.StandardJavaFileManager;
/*     */ import javax.tools.StandardLocation;
/*     */ import javax.tools.ToolProvider;
/*     */ 
/*     */ public class JdkCompiler extends AbstractCompiler
/*     */ {
/*  60 */   private final JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
/*     */ 
/*  62 */   private final DiagnosticCollector<JavaFileObject> diagnosticCollector = new DiagnosticCollector();
/*     */   private final ClassLoaderImpl classLoader;
/*     */   private final JavaFileManagerImpl javaFileManager;
/*     */   private volatile List<String> options;
/*     */ 
/*     */   public JdkCompiler()
/*     */   {
/*  71 */     this.options = new ArrayList();
/*  72 */     this.options.add("-target");
/*  73 */     this.options.add("1.6");
/*  74 */     StandardJavaFileManager manager = this.compiler.getStandardFileManager(this.diagnosticCollector, null, null);
/*  75 */     final ClassLoader loader = Thread.currentThread().getContextClassLoader();
/*  76 */     if (((loader instanceof URLClassLoader)) && (!loader.getClass().getName().equals("sun.misc.Launcher$AppClassLoader"))) {
/*     */       try
/*     */       {
/*  79 */         URLClassLoader urlClassLoader = (URLClassLoader)loader;
/*  80 */         List files = new ArrayList();
/*  81 */         for (URL url : urlClassLoader.getURLs()) {
/*  82 */           files.add(new File(url.getFile()));
/*     */         }
/*  84 */         manager.setLocation(StandardLocation.CLASS_PATH, files);
/*     */       } catch (IOException e) {
/*  86 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/*     */     }
/*  89 */     this.classLoader = ((ClassLoaderImpl)AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public JdkCompiler.ClassLoaderImpl run() {
/*  91 */         return new JdkCompiler.ClassLoaderImpl(JdkCompiler.this, loader);
/*     */       }
/*     */     }));
/*  94 */     this.javaFileManager = new JavaFileManagerImpl(manager, this.classLoader);
/*     */   }
/*     */ 
/*     */   public Class<?> doCompile(String name, String sourceCode) throws Throwable
/*     */   {
/*  99 */     int i = name.lastIndexOf('.');
/* 100 */     String packageName = i < 0 ? "" : name.substring(0, i);
/* 101 */     String className = i < 0 ? name : name.substring(i + 1);
/* 102 */     JavaFileObjectImpl javaFileObject = new JavaFileObjectImpl(className, sourceCode);
/* 103 */     this.javaFileManager.putFileForInput(StandardLocation.SOURCE_PATH, packageName, className + ".java", javaFileObject);
/*     */ 
/* 105 */     Boolean result = this.compiler.getTask(null, this.javaFileManager, this.diagnosticCollector, this.options, null, Arrays.asList(new JavaFileObject[] { javaFileObject })).call();
/*     */ 
/* 107 */     if ((result == null) || (!result.booleanValue())) {
/* 108 */       throw new IllegalStateException("Compilation failed. class: " + name + ", diagnostics: " + this.diagnosticCollector);
/*     */     }
/* 110 */     return this.classLoader.loadClass(name);
/*     */   }
/*     */ 
/*     */   private static final class JavaFileManagerImpl extends ForwardingJavaFileManager<JavaFileManager>
/*     */   {
/*     */     private final JdkCompiler.ClassLoaderImpl classLoader;
/* 209 */     private final Map<URI, JavaFileObject> fileObjects = new HashMap();
/*     */ 
/*     */     public JavaFileManagerImpl(JavaFileManager fileManager, JdkCompiler.ClassLoaderImpl classLoader) {
/* 212 */       super();
/* 213 */       this.classLoader = classLoader;
/*     */     }
/*     */ 
/*     */     public FileObject getFileForInput(JavaFileManager.Location location, String packageName, String relativeName) throws IOException
/*     */     {
/* 218 */       FileObject o = (FileObject)this.fileObjects.get(uri(location, packageName, relativeName));
/* 219 */       if (o != null)
/* 220 */         return o;
/* 221 */       return super.getFileForInput(location, packageName, relativeName);
/*     */     }
/*     */ 
/*     */     public void putFileForInput(StandardLocation location, String packageName, String relativeName, JavaFileObject file) {
/* 225 */       this.fileObjects.put(uri(location, packageName, relativeName), file);
/*     */     }
/*     */ 
/*     */     private URI uri(JavaFileManager.Location location, String packageName, String relativeName) {
/* 229 */       return ClassUtils.toURI(location.getName() + '/' + packageName + '/' + relativeName);
/*     */     }
/*     */ 
/*     */     public JavaFileObject getJavaFileForOutput(JavaFileManager.Location location, String qualifiedName, JavaFileObject.Kind kind, FileObject outputFile)
/*     */       throws IOException
/*     */     {
/* 235 */       JavaFileObject file = new JdkCompiler.JavaFileObjectImpl(qualifiedName, kind);
/* 236 */       this.classLoader.add(qualifiedName, file);
/* 237 */       return file;
/*     */     }
/*     */ 
/*     */     public ClassLoader getClassLoader(JavaFileManager.Location location)
/*     */     {
/* 242 */       return this.classLoader;
/*     */     }
/*     */ 
/*     */     public String inferBinaryName(JavaFileManager.Location loc, JavaFileObject file)
/*     */     {
/* 247 */       if ((file instanceof JdkCompiler.JavaFileObjectImpl))
/* 248 */         return file.getName();
/* 249 */       return super.inferBinaryName(loc, file);
/*     */     }
/*     */ 
/*     */     public Iterable<JavaFileObject> list(JavaFileManager.Location location, String packageName, Set<JavaFileObject.Kind> kinds, boolean recurse)
/*     */       throws IOException
/*     */     {
/* 255 */       Iterable result = super.list(location, packageName, kinds, recurse);
/*     */ 
/* 257 */       ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/* 258 */       List urlList = new ArrayList();
/* 259 */       Enumeration e = contextClassLoader.getResources("com");
/* 260 */       while (e.hasMoreElements()) {
/* 261 */         urlList.add(e.nextElement());
/*     */       }
/*     */ 
/* 264 */       ArrayList files = new ArrayList();
/*     */ 
/* 266 */       if ((location == StandardLocation.CLASS_PATH) && (kinds.contains(JavaFileObject.Kind.CLASS))) {
/* 267 */         for (JavaFileObject file : this.fileObjects.values()) {
/* 268 */           if ((file.getKind() == JavaFileObject.Kind.CLASS) && (file.getName().startsWith(packageName))) {
/* 269 */             files.add(file);
/*     */           }
/*     */         }
/*     */ 
/* 273 */         files.addAll(this.classLoader.files());
/* 274 */       } else if ((location == StandardLocation.SOURCE_PATH) && (kinds.contains(JavaFileObject.Kind.SOURCE))) {
/* 275 */         for (JavaFileObject file : this.fileObjects.values()) {
/* 276 */           if ((file.getKind() == JavaFileObject.Kind.SOURCE) && (file.getName().startsWith(packageName))) {
/* 277 */             files.add(file);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 282 */       for (JavaFileObject file : result) {
/* 283 */         files.add(file);
/*     */       }
/*     */ 
/* 286 */       return files;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class JavaFileObjectImpl extends SimpleJavaFileObject
/*     */   {
/*     */     private ByteArrayOutputStream bytecode;
/*     */     private final CharSequence source;
/*     */ 
/*     */     public JavaFileObjectImpl(String baseName, CharSequence source)
/*     */     {
/* 168 */       super(JavaFileObject.Kind.SOURCE);
/* 169 */       this.source = source;
/*     */     }
/*     */ 
/*     */     JavaFileObjectImpl(String name, JavaFileObject.Kind kind) {
/* 173 */       super(kind);
/* 174 */       this.source = null;
/*     */     }
/*     */ 
/*     */     public JavaFileObjectImpl(URI uri, JavaFileObject.Kind kind) {
/* 178 */       super(kind);
/* 179 */       this.source = null;
/*     */     }
/*     */ 
/*     */     public CharSequence getCharContent(boolean ignoreEncodingErrors) throws UnsupportedOperationException
/*     */     {
/* 184 */       if (this.source == null) {
/* 185 */         throw new UnsupportedOperationException("source == null");
/*     */       }
/* 187 */       return this.source;
/*     */     }
/*     */ 
/*     */     public InputStream openInputStream()
/*     */     {
/* 192 */       return new ByteArrayInputStream(getByteCode());
/*     */     }
/*     */ 
/*     */     public OutputStream openOutputStream()
/*     */     {
/* 197 */       return this.bytecode = new ByteArrayOutputStream();
/*     */     }
/*     */ 
/*     */     public byte[] getByteCode() {
/* 201 */       return this.bytecode.toByteArray();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class ClassLoaderImpl extends ClassLoader
/*     */   {
/* 115 */     private final Map<String, JavaFileObject> classes = new HashMap();
/*     */ 
/*     */     ClassLoaderImpl(ClassLoader parentClassLoader) {
/* 118 */       super();
/*     */     }
/*     */ 
/*     */     Collection<JavaFileObject> files() {
/* 122 */       return Collections.unmodifiableCollection(this.classes.values());
/*     */     }
/*     */ 
/*     */     protected Class<?> findClass(String qualifiedClassName) throws ClassNotFoundException
/*     */     {
/* 127 */       JavaFileObject file = (JavaFileObject)this.classes.get(qualifiedClassName);
/* 128 */       if (file != null) {
/* 129 */         byte[] bytes = ((JdkCompiler.JavaFileObjectImpl)file).getByteCode();
/* 130 */         return defineClass(qualifiedClassName, bytes, 0, bytes.length);
/*     */       }
/*     */       try {
/* 133 */         return ClassHelper.forNameWithCallerClassLoader(qualifiedClassName, getClass()); } catch (ClassNotFoundException nf) {
/*     */       }
/* 135 */       return super.findClass(qualifiedClassName);
/*     */     }
/*     */ 
/*     */     void add(String qualifiedClassName, JavaFileObject javaFile)
/*     */     {
/* 140 */       this.classes.put(qualifiedClassName, javaFile);
/*     */     }
/*     */ 
/*     */     protected synchronized Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException
/*     */     {
/* 145 */       return super.loadClass(name, resolve);
/*     */     }
/*     */ 
/*     */     public InputStream getResourceAsStream(String name)
/*     */     {
/* 150 */       if (name.endsWith(".class")) {
/* 151 */         String qualifiedClassName = name.substring(0, name.length() - ".class".length()).replace('/', '.');
/* 152 */         JdkCompiler.JavaFileObjectImpl file = (JdkCompiler.JavaFileObjectImpl)this.classes.get(qualifiedClassName);
/* 153 */         if (file != null) {
/* 154 */           return new ByteArrayInputStream(file.getByteCode());
/*     */         }
/*     */       }
/* 157 */       return super.getResourceAsStream(name);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.compiler.support.JdkCompiler
 * JD-Core Version:    0.6.2
 */