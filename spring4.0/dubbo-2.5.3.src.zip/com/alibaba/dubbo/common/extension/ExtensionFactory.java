package com.alibaba.dubbo.common.extension;

@SPI
public abstract interface ExtensionFactory
{
  public abstract <T> T getExtension(Class<T> paramClass, String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.extension.ExtensionFactory
 * JD-Core Version:    0.6.2
 */