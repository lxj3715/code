/*     */ package com.alibaba.dubbo.common.extension;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.Extension;
/*     */ import com.alibaba.dubbo.common.compiler.Compiler;
/*     */ import com.alibaba.dubbo.common.extension.support.ActivateComparator;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ConcurrentHashSet;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.Holder;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class ExtensionLoader<T>
/*     */ {
/*  64 */   private static final Logger logger = LoggerFactory.getLogger(ExtensionLoader.class);
/*     */   private static final String SERVICES_DIRECTORY = "META-INF/services/";
/*     */   private static final String DUBBO_DIRECTORY = "META-INF/dubbo/";
/*     */   private static final String DUBBO_INTERNAL_DIRECTORY = "META-INF/dubbo/internal/";
/*  72 */   private static final Pattern NAME_SEPARATOR = Pattern.compile("\\s*[,]+\\s*");
/*     */ 
/*  74 */   private static final ConcurrentMap<Class<?>, ExtensionLoader<?>> EXTENSION_LOADERS = new ConcurrentHashMap();
/*     */ 
/*  76 */   private static final ConcurrentMap<Class<?>, Object> EXTENSION_INSTANCES = new ConcurrentHashMap();
/*     */   private final Class<?> type;
/*     */   private final ExtensionFactory objectFactory;
/*  84 */   private final ConcurrentMap<Class<?>, String> cachedNames = new ConcurrentHashMap();
/*     */ 
/*  86 */   private final Holder<Map<String, Class<?>>> cachedClasses = new Holder();
/*     */ 
/*  88 */   private final Map<String, Activate> cachedActivates = new ConcurrentHashMap();
/*     */ 
/*  90 */   private volatile Class<?> cachedAdaptiveClass = null;
/*     */ 
/*  92 */   private final ConcurrentMap<String, Holder<Object>> cachedInstances = new ConcurrentHashMap();
/*     */   private String cachedDefaultName;
/*  96 */   private final Holder<Object> cachedAdaptiveInstance = new Holder();
/*     */   private volatile Throwable createAdaptiveInstanceError;
/*     */   private Set<Class<?>> cachedWrapperClasses;
/* 101 */   private Map<String, IllegalStateException> exceptions = new ConcurrentHashMap();
/*     */ 
/*     */   private static <T> boolean withExtensionAnnotation(Class<T> type) {
/* 104 */     return type.isAnnotationPresent(SPI.class);
/*     */   }
/*     */ 
/*     */   public static <T> ExtensionLoader<T> getExtensionLoader(Class<T> type)
/*     */   {
/* 109 */     if (type == null)
/* 110 */       throw new IllegalArgumentException("Extension type == null");
/* 111 */     if (!type.isInterface()) {
/* 112 */       throw new IllegalArgumentException("Extension type(" + type + ") is not interface!");
/*     */     }
/* 114 */     if (!withExtensionAnnotation(type)) {
/* 115 */       throw new IllegalArgumentException("Extension type(" + type + ") is not extension, because WITHOUT @" + SPI.class.getSimpleName() + " Annotation!");
/*     */     }
/*     */ 
/* 119 */     ExtensionLoader loader = (ExtensionLoader)EXTENSION_LOADERS.get(type);
/* 120 */     if (loader == null) {
/* 121 */       EXTENSION_LOADERS.putIfAbsent(type, new ExtensionLoader(type));
/* 122 */       loader = (ExtensionLoader)EXTENSION_LOADERS.get(type);
/*     */     }
/* 124 */     return loader;
/*     */   }
/*     */ 
/*     */   private ExtensionLoader(Class<?> type) {
/* 128 */     this.type = type;
/* 129 */     this.objectFactory = (type == ExtensionFactory.class ? null : (ExtensionFactory)getExtensionLoader(ExtensionFactory.class).getAdaptiveExtension());
/*     */   }
/*     */ 
/*     */   public String getExtensionName(T extensionInstance) {
/* 133 */     return getExtensionName(extensionInstance.getClass());
/*     */   }
/*     */ 
/*     */   public String getExtensionName(Class<?> extensionClass) {
/* 137 */     return (String)this.cachedNames.get(extensionClass);
/*     */   }
/*     */ 
/*     */   public List<T> getActivateExtension(com.alibaba.dubbo.common.URL url, String key)
/*     */   {
/* 151 */     return getActivateExtension(url, key, null);
/*     */   }
/*     */ 
/*     */   public List<T> getActivateExtension(com.alibaba.dubbo.common.URL url, String[] values)
/*     */   {
/* 165 */     return getActivateExtension(url, values, null);
/*     */   }
/*     */ 
/*     */   public List<T> getActivateExtension(com.alibaba.dubbo.common.URL url, String key, String group)
/*     */   {
/* 180 */     String value = url.getParameter(key);
/* 181 */     return getActivateExtension(url, (value == null) || (value.length() == 0) ? null : Constants.COMMA_SPLIT_PATTERN.split(value), group);
/*     */   }
/*     */ 
/*     */   public List<T> getActivateExtension(com.alibaba.dubbo.common.URL url, String[] values, String group)
/*     */   {
/* 194 */     List exts = new ArrayList();
/* 195 */     List names = values == null ? new ArrayList(0) : Arrays.asList(values);
/* 196 */     if (!names.contains("-default")) {
/* 197 */       getExtensionClasses();
/* 198 */       for (Map.Entry entry : this.cachedActivates.entrySet()) {
/* 199 */         String name = (String)entry.getKey();
/* 200 */         Activate activate = (Activate)entry.getValue();
/* 201 */         if (isMatchGroup(group, activate.group())) {
/* 202 */           Object ext = getExtension(name);
/* 203 */           if ((!names.contains(name)) && (!names.contains("-" + name)) && (isActive(activate, url)))
/*     */           {
/* 206 */             exts.add(ext);
/*     */           }
/*     */         }
/*     */       }
/* 210 */       Collections.sort(exts, ActivateComparator.COMPARATOR);
/*     */     }
/* 212 */     List usrs = new ArrayList();
/* 213 */     for (int i = 0; i < names.size(); i++) {
/* 214 */       String name = (String)names.get(i);
/* 215 */       if ((!name.startsWith("-")) && (!names.contains("-" + name)))
/*     */       {
/* 217 */         if ("default".equals(name)) {
/* 218 */           if (usrs.size() > 0) {
/* 219 */             exts.addAll(0, usrs);
/* 220 */             usrs.clear();
/*     */           }
/*     */         } else {
/* 223 */           Object ext = getExtension(name);
/* 224 */           usrs.add(ext);
/*     */         }
/*     */       }
/*     */     }
/* 228 */     if (usrs.size() > 0) {
/* 229 */       exts.addAll(usrs);
/*     */     }
/* 231 */     return exts;
/*     */   }
/*     */ 
/*     */   private boolean isMatchGroup(String group, String[] groups) {
/* 235 */     if ((group == null) || (group.length() == 0)) {
/* 236 */       return true;
/*     */     }
/* 238 */     if ((groups != null) && (groups.length > 0)) {
/* 239 */       for (String g : groups) {
/* 240 */         if (group.equals(g)) {
/* 241 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 245 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean isActive(Activate activate, com.alibaba.dubbo.common.URL url) {
/* 249 */     String[] keys = activate.value();
/* 250 */     if ((keys == null) || (keys.length == 0))
/* 251 */       return true;
/*     */     String key;
/* 253 */     for (key : keys) {
/* 254 */       for (Map.Entry entry : url.getParameters().entrySet()) {
/* 255 */         String k = (String)entry.getKey();
/* 256 */         String v = (String)entry.getValue();
/* 257 */         if (((k.equals(key)) || (k.endsWith("." + key))) && (ConfigUtils.isNotEmpty(v)))
/*     */         {
/* 259 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 263 */     return false;
/*     */   }
/*     */ 
/*     */   public T getLoadedExtension(String name)
/*     */   {
/* 275 */     if ((name == null) || (name.length() == 0))
/* 276 */       throw new IllegalArgumentException("Extension name == null");
/* 277 */     Holder holder = (Holder)this.cachedInstances.get(name);
/* 278 */     if (holder == null) {
/* 279 */       this.cachedInstances.putIfAbsent(name, new Holder());
/* 280 */       holder = (Holder)this.cachedInstances.get(name);
/*     */     }
/* 282 */     return holder.get();
/*     */   }
/*     */ 
/*     */   public Set<String> getLoadedExtensions()
/*     */   {
/* 293 */     return Collections.unmodifiableSet(new TreeSet(this.cachedInstances.keySet()));
/*     */   }
/*     */ 
/*     */   public T getExtension(String name)
/*     */   {
/* 304 */     if ((name == null) || (name.length() == 0))
/* 305 */       throw new IllegalArgumentException("Extension name == null");
/* 306 */     if ("true".equals(name)) {
/* 307 */       return getDefaultExtension();
/*     */     }
/* 309 */     Holder holder = (Holder)this.cachedInstances.get(name);
/* 310 */     if (holder == null) {
/* 311 */       this.cachedInstances.putIfAbsent(name, new Holder());
/* 312 */       holder = (Holder)this.cachedInstances.get(name);
/*     */     }
/* 314 */     Object instance = holder.get();
/* 315 */     if (instance == null) {
/* 316 */       synchronized (holder) {
/* 317 */         instance = holder.get();
/* 318 */         if (instance == null) {
/* 319 */           instance = createExtension(name);
/* 320 */           holder.set(instance);
/*     */         }
/*     */       }
/*     */     }
/* 324 */     return instance;
/*     */   }
/*     */ 
/*     */   public T getDefaultExtension()
/*     */   {
/* 331 */     getExtensionClasses();
/* 332 */     if ((null == this.cachedDefaultName) || (this.cachedDefaultName.length() == 0) || ("true".equals(this.cachedDefaultName)))
/*     */     {
/* 334 */       return null;
/*     */     }
/* 336 */     return getExtension(this.cachedDefaultName);
/*     */   }
/*     */ 
/*     */   public boolean hasExtension(String name) {
/* 340 */     if ((name == null) || (name.length() == 0))
/* 341 */       throw new IllegalArgumentException("Extension name == null");
/*     */     try {
/* 343 */       return getExtensionClass(name) != null; } catch (Throwable t) {
/*     */     }
/* 345 */     return false;
/*     */   }
/*     */ 
/*     */   public Set<String> getSupportedExtensions()
/*     */   {
/* 350 */     Map clazzes = getExtensionClasses();
/* 351 */     return Collections.unmodifiableSet(new TreeSet(clazzes.keySet()));
/*     */   }
/*     */ 
/*     */   public String getDefaultExtensionName()
/*     */   {
/* 358 */     getExtensionClasses();
/* 359 */     return this.cachedDefaultName;
/*     */   }
/*     */ 
/*     */   public void addExtension(String name, Class<?> clazz)
/*     */   {
/* 370 */     getExtensionClasses();
/*     */ 
/* 372 */     if (!this.type.isAssignableFrom(clazz)) {
/* 373 */       throw new IllegalStateException("Input type " + clazz + "not implement Extension " + this.type);
/*     */     }
/*     */ 
/* 376 */     if (clazz.isInterface()) {
/* 377 */       throw new IllegalStateException("Input type " + clazz + "can not be interface!");
/*     */     }
/*     */ 
/* 381 */     if (!clazz.isAnnotationPresent(Adaptive.class)) {
/* 382 */       if (StringUtils.isBlank(name)) {
/* 383 */         throw new IllegalStateException("Extension name is blank (Extension " + this.type + ")!");
/*     */       }
/* 385 */       if (((Map)this.cachedClasses.get()).containsKey(name)) {
/* 386 */         throw new IllegalStateException("Extension name " + name + " already existed(Extension " + this.type + ")!");
/*     */       }
/*     */ 
/* 390 */       this.cachedNames.put(clazz, name);
/* 391 */       ((Map)this.cachedClasses.get()).put(name, clazz);
/*     */     }
/*     */     else {
/* 394 */       if (this.cachedAdaptiveClass != null) {
/* 395 */         throw new IllegalStateException("Adaptive Extension already existed(Extension " + this.type + ")!");
/*     */       }
/*     */ 
/* 398 */       this.cachedAdaptiveClass = clazz;
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void replaceExtension(String name, Class<?> clazz)
/*     */   {
/* 412 */     getExtensionClasses();
/*     */ 
/* 414 */     if (!this.type.isAssignableFrom(clazz)) {
/* 415 */       throw new IllegalStateException("Input type " + clazz + "not implement Extension " + this.type);
/*     */     }
/*     */ 
/* 418 */     if (clazz.isInterface()) {
/* 419 */       throw new IllegalStateException("Input type " + clazz + "can not be interface!");
/*     */     }
/*     */ 
/* 423 */     if (!clazz.isAnnotationPresent(Adaptive.class)) {
/* 424 */       if (StringUtils.isBlank(name)) {
/* 425 */         throw new IllegalStateException("Extension name is blank (Extension " + this.type + ")!");
/*     */       }
/* 427 */       if (!((Map)this.cachedClasses.get()).containsKey(name)) {
/* 428 */         throw new IllegalStateException("Extension name " + name + " not existed(Extension " + this.type + ")!");
/*     */       }
/*     */ 
/* 432 */       this.cachedNames.put(clazz, name);
/* 433 */       ((Map)this.cachedClasses.get()).put(name, clazz);
/* 434 */       this.cachedInstances.remove(name);
/*     */     }
/*     */     else {
/* 437 */       if (this.cachedAdaptiveClass == null) {
/* 438 */         throw new IllegalStateException("Adaptive Extension not existed(Extension " + this.type + ")!");
/*     */       }
/*     */ 
/* 441 */       this.cachedAdaptiveClass = clazz;
/* 442 */       this.cachedAdaptiveInstance.set(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public T getAdaptiveExtension()
/*     */   {
/* 448 */     Object instance = this.cachedAdaptiveInstance.get();
/* 449 */     if (instance == null) {
/* 450 */       if (this.createAdaptiveInstanceError == null) {
/* 451 */         synchronized (this.cachedAdaptiveInstance) {
/* 452 */           instance = this.cachedAdaptiveInstance.get();
/* 453 */           if (instance == null) {
/*     */             try {
/* 455 */               instance = createAdaptiveExtension();
/* 456 */               this.cachedAdaptiveInstance.set(instance);
/*     */             } catch (Throwable t) {
/* 458 */               this.createAdaptiveInstanceError = t;
/* 459 */               throw new IllegalStateException("fail to create adaptive instance: " + t.toString(), t);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 465 */         throw new IllegalStateException("fail to create adaptive instance: " + this.createAdaptiveInstanceError.toString(), this.createAdaptiveInstanceError);
/*     */       }
/*     */     }
/*     */ 
/* 469 */     return instance;
/*     */   }
/*     */ 
/*     */   private IllegalStateException findException(String name) {
/* 473 */     for (Map.Entry entry : this.exceptions.entrySet()) {
/* 474 */       if (((String)entry.getKey()).toLowerCase().contains(name.toLowerCase())) {
/* 475 */         return (IllegalStateException)entry.getValue();
/*     */       }
/*     */     }
/* 478 */     StringBuilder buf = new StringBuilder("No such extension " + this.type.getName() + " by name " + name);
/*     */ 
/* 481 */     int i = 1;
/* 482 */     for (Map.Entry entry : this.exceptions.entrySet()) {
/* 483 */       if (i == 1) {
/* 484 */         buf.append(", possible causes: ");
/*     */       }
/*     */ 
/* 487 */       buf.append("\r\n(");
/* 488 */       buf.append(i++);
/* 489 */       buf.append(") ");
/* 490 */       buf.append((String)entry.getKey());
/* 491 */       buf.append(":\r\n");
/* 492 */       buf.append(StringUtils.toString((Throwable)entry.getValue()));
/*     */     }
/* 494 */     return new IllegalStateException(buf.toString());
/*     */   }
/*     */ 
/*     */   private T createExtension(String name)
/*     */   {
/* 499 */     Class clazz = (Class)getExtensionClasses().get(name);
/* 500 */     if (clazz == null)
/* 501 */       throw findException(name);
/*     */     try
/*     */     {
/* 504 */       Object instance = EXTENSION_INSTANCES.get(clazz);
/* 505 */       if (instance == null) {
/* 506 */         EXTENSION_INSTANCES.putIfAbsent(clazz, clazz.newInstance());
/* 507 */         instance = EXTENSION_INSTANCES.get(clazz);
/*     */       }
/* 509 */       injectExtension(instance);
/* 510 */       Set wrapperClasses = this.cachedWrapperClasses;
/* 511 */       if ((wrapperClasses != null) && (wrapperClasses.size() > 0)) {
/* 512 */         for (Class wrapperClass : wrapperClasses) {
/* 513 */           instance = injectExtension(wrapperClass.getConstructor(new Class[] { this.type }).newInstance(new Object[] { instance }));
/*     */         }
/*     */       }
/* 516 */       return instance;
/*     */     } catch (Throwable t) {
/* 518 */       throw new IllegalStateException("Extension instance(name: " + name + ", class: " + this.type + ")  could not be instantiated: " + t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private T injectExtension(T instance)
/*     */   {
/*     */     try {
/* 525 */       if (this.objectFactory != null) {
/* 526 */         for (Method method : instance.getClass().getMethods())
/* 527 */           if ((method.getName().startsWith("set")) && (method.getParameterTypes().length == 1) && (Modifier.isPublic(method.getModifiers())))
/*     */           {
/* 530 */             Class pt = method.getParameterTypes()[0];
/*     */             try {
/* 532 */               String property = method.getName().length() > 3 ? method.getName().substring(3, 4).toLowerCase() + method.getName().substring(4) : "";
/* 533 */               Object object = this.objectFactory.getExtension(pt, property);
/* 534 */               if (object != null)
/* 535 */                 method.invoke(instance, new Object[] { object });
/*     */             }
/*     */             catch (Exception e) {
/* 538 */               logger.error("fail to inject via method " + method.getName() + " of interface " + this.type.getName() + ": " + e.getMessage(), e);
/*     */             }
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 545 */       logger.error(e.getMessage(), e);
/*     */     }
/* 547 */     return instance;
/*     */   }
/*     */ 
/*     */   private Class<?> getExtensionClass(String name) {
/* 551 */     if (this.type == null)
/* 552 */       throw new IllegalArgumentException("Extension type == null");
/* 553 */     if (name == null)
/* 554 */       throw new IllegalArgumentException("Extension name == null");
/* 555 */     Class clazz = (Class)getExtensionClasses().get(name);
/* 556 */     if (clazz == null)
/* 557 */       throw new IllegalStateException("No such extension \"" + name + "\" for " + this.type.getName() + "!");
/* 558 */     return clazz;
/*     */   }
/*     */ 
/*     */   private Map<String, Class<?>> getExtensionClasses() {
/* 562 */     Map classes = (Map)this.cachedClasses.get();
/* 563 */     if (classes == null) {
/* 564 */       synchronized (this.cachedClasses) {
/* 565 */         classes = (Map)this.cachedClasses.get();
/* 566 */         if (classes == null) {
/* 567 */           classes = loadExtensionClasses();
/* 568 */           this.cachedClasses.set(classes);
/*     */         }
/*     */       }
/*     */     }
/* 572 */     return classes;
/*     */   }
/*     */ 
/*     */   private Map<String, Class<?>> loadExtensionClasses()
/*     */   {
/* 577 */     SPI defaultAnnotation = (SPI)this.type.getAnnotation(SPI.class);
/* 578 */     if (defaultAnnotation != null) {
/* 579 */       String value = defaultAnnotation.value();
/* 580 */       if ((value != null) && ((value = value.trim()).length() > 0)) {
/* 581 */         String[] names = NAME_SEPARATOR.split(value);
/* 582 */         if (names.length > 1) {
/* 583 */           throw new IllegalStateException("more than 1 default extension name on extension " + this.type.getName() + ": " + Arrays.toString(names));
/*     */         }
/*     */ 
/* 586 */         if (names.length == 1) this.cachedDefaultName = names[0];
/*     */       }
/*     */     }
/*     */ 
/* 590 */     Map extensionClasses = new HashMap();
/* 591 */     loadFile(extensionClasses, "META-INF/dubbo/internal/");
/* 592 */     loadFile(extensionClasses, "META-INF/dubbo/");
/* 593 */     loadFile(extensionClasses, "META-INF/services/");
/* 594 */     return extensionClasses;
/*     */   }
/*     */ 
/*     */   private void loadFile(Map<String, Class<?>> extensionClasses, String dir) {
/* 598 */     String fileName = dir + this.type.getName();
/*     */     try
/*     */     {
/* 601 */       ClassLoader classLoader = findClassLoader();
/*     */       Enumeration urls;
/*     */       Enumeration urls;
/* 602 */       if (classLoader != null)
/* 603 */         urls = classLoader.getResources(fileName);
/*     */       else {
/* 605 */         urls = ClassLoader.getSystemResources(fileName);
/*     */       }
/* 607 */       if (urls != null)
/* 608 */         while (urls.hasMoreElements()) {
/* 609 */           java.net.URL url = (java.net.URL)urls.nextElement();
/*     */           try {
/* 611 */             BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream(), "utf-8"));
/*     */             try {
/* 613 */               String line = null;
/* 614 */               while ((line = reader.readLine()) != null) {
/* 615 */                 int ci = line.indexOf('#');
/* 616 */                 if (ci >= 0) line = line.substring(0, ci);
/* 617 */                 line = line.trim();
/* 618 */                 if (line.length() > 0)
/*     */                   try {
/* 620 */                     String name = null;
/* 621 */                     int i = line.indexOf('=');
/* 622 */                     if (i > 0) {
/* 623 */                       name = line.substring(0, i).trim();
/* 624 */                       line = line.substring(i + 1).trim();
/*     */                     }
/* 626 */                     if (line.length() > 0) {
/* 627 */                       Class clazz = Class.forName(line, true, classLoader);
/* 628 */                       if (!this.type.isAssignableFrom(clazz)) {
/* 629 */                         throw new IllegalStateException("Error when load extension class(interface: " + this.type + ", class line: " + clazz.getName() + "), class " + clazz.getName() + "is not subtype of interface.");
/*     */                       }
/*     */ 
/* 633 */                       if (clazz.isAnnotationPresent(Adaptive.class)) {
/* 634 */                         if (this.cachedAdaptiveClass == null)
/* 635 */                           this.cachedAdaptiveClass = clazz;
/* 636 */                         else if (!this.cachedAdaptiveClass.equals(clazz)) {
/* 637 */                           throw new IllegalStateException("More than 1 adaptive class found: " + this.cachedAdaptiveClass.getClass().getName() + ", " + clazz.getClass().getName());
/*     */                         }
/*     */                       }
/*     */                       else
/*     */                         try
/*     */                         {
/* 643 */                           clazz.getConstructor(new Class[] { this.type });
/* 644 */                           Set wrappers = this.cachedWrapperClasses;
/* 645 */                           if (wrappers == null) {
/* 646 */                             this.cachedWrapperClasses = new ConcurrentHashSet();
/* 647 */                             wrappers = this.cachedWrapperClasses;
/*     */                           }
/* 649 */                           wrappers.add(clazz);
/*     */                         } catch (NoSuchMethodException e) {
/* 651 */                           clazz.getConstructor(new Class[0]);
/* 652 */                           if ((name == null) || (name.length() == 0)) {
/* 653 */                             name = findAnnotationName(clazz);
/* 654 */                             if ((name == null) || (name.length() == 0)) {
/* 655 */                               if ((clazz.getSimpleName().length() > this.type.getSimpleName().length()) && (clazz.getSimpleName().endsWith(this.type.getSimpleName())))
/*     */                               {
/* 657 */                                 name = clazz.getSimpleName().substring(0, clazz.getSimpleName().length() - this.type.getSimpleName().length()).toLowerCase();
/*     */                               }
/* 659 */                               else throw new IllegalStateException("No such extension name for the class " + clazz.getName() + " in the config " + url);
/*     */                             }
/*     */                           }
/*     */ 
/* 663 */                           String[] names = NAME_SEPARATOR.split(name);
/* 664 */                           if ((names != null) && (names.length > 0)) {
/* 665 */                             Activate activate = (Activate)clazz.getAnnotation(Activate.class);
/* 666 */                             if (activate != null) {
/* 667 */                               this.cachedActivates.put(names[0], activate);
/*     */                             }
/* 669 */                             for (String n : names) {
/* 670 */                               if (!this.cachedNames.containsKey(clazz)) {
/* 671 */                                 this.cachedNames.put(clazz, n);
/*     */                               }
/* 673 */                               Class c = (Class)extensionClasses.get(n);
/* 674 */                               if (c == null)
/* 675 */                                 extensionClasses.put(n, clazz);
/* 676 */                               else if (c != clazz)
/* 677 */                                 throw new IllegalStateException("Duplicate extension " + this.type.getName() + " name " + n + " on " + c.getName() + " and " + clazz.getName());
/*     */                             }
/*     */                           }
/*     */                         }
/*     */                     }
/*     */                   }
/*     */                   catch (Throwable t)
/*     */                   {
/* 685 */                     IllegalStateException e = new IllegalStateException("Failed to load extension class(interface: " + this.type + ", class line: " + line + ") in " + url + ", cause: " + t.getMessage(), t);
/* 686 */                     this.exceptions.put(line, e);
/*     */                   }
/*     */               }
/*     */             }
/*     */             finally {
/* 691 */               reader.close();
/*     */             }
/*     */           } catch (Throwable t) {
/* 694 */             logger.error("Exception when load extension class(interface: " + this.type + ", class file: " + url + ") in " + url, t);
/*     */           }
/*     */         }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 700 */       logger.error("Exception when load extension class(interface: " + this.type + ", description file: " + fileName + ").", t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String findAnnotationName(Class<?> clazz)
/*     */   {
/* 707 */     Extension extension = (Extension)clazz.getAnnotation(Extension.class);
/* 708 */     if (extension == null) {
/* 709 */       String name = clazz.getSimpleName();
/* 710 */       if (name.endsWith(this.type.getSimpleName())) {
/* 711 */         name = name.substring(0, name.length() - this.type.getSimpleName().length());
/*     */       }
/* 713 */       return name.toLowerCase();
/*     */     }
/* 715 */     return extension.value();
/*     */   }
/*     */ 
/*     */   private T createAdaptiveExtension()
/*     */   {
/*     */     try {
/* 721 */       return injectExtension(getAdaptiveExtensionClass().newInstance());
/*     */     } catch (Exception e) {
/* 723 */       throw new IllegalStateException("Can not create adaptive extenstion " + this.type + ", cause: " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Class<?> getAdaptiveExtensionClass() {
/* 728 */     getExtensionClasses();
/* 729 */     if (this.cachedAdaptiveClass != null) {
/* 730 */       return this.cachedAdaptiveClass;
/*     */     }
/* 732 */     return this.cachedAdaptiveClass = createAdaptiveExtensionClass();
/*     */   }
/*     */ 
/*     */   private Class<?> createAdaptiveExtensionClass() {
/* 736 */     String code = createAdaptiveExtensionClassCode();
/* 737 */     ClassLoader classLoader = findClassLoader();
/* 738 */     Compiler compiler = (Compiler)getExtensionLoader(Compiler.class).getAdaptiveExtension();
/* 739 */     return compiler.compile(code, classLoader);
/*     */   }
/*     */ 
/*     */   private String createAdaptiveExtensionClassCode() {
/* 743 */     StringBuilder codeBuidler = new StringBuilder();
/* 744 */     Method[] methods = this.type.getMethods();
/* 745 */     boolean hasAdaptiveAnnotation = false;
/* 746 */     for (Method m : methods) {
/* 747 */       if (m.isAnnotationPresent(Adaptive.class)) {
/* 748 */         hasAdaptiveAnnotation = true;
/* 749 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 753 */     if (!hasAdaptiveAnnotation) {
/* 754 */       throw new IllegalStateException("No adaptive method on extension " + this.type.getName() + ", refuse to create the adaptive class!");
/*     */     }
/* 756 */     codeBuidler.append("package " + this.type.getPackage().getName() + ";");
/* 757 */     codeBuidler.append("\nimport " + ExtensionLoader.class.getName() + ";");
/* 758 */     codeBuidler.append("\npublic class " + this.type.getSimpleName() + "$Adpative" + " implements " + this.type.getCanonicalName() + " {");
/*     */ 
/* 760 */     label606: for (Method method : methods) {
/* 761 */       Class rt = method.getReturnType();
/* 762 */       Class[] pts = method.getParameterTypes();
/* 763 */       Class[] ets = method.getExceptionTypes();
/*     */ 
/* 765 */       Adaptive adaptiveAnnotation = (Adaptive)method.getAnnotation(Adaptive.class);
/* 766 */       StringBuilder code = new StringBuilder(512);
/* 767 */       if (adaptiveAnnotation == null) {
/* 768 */         code.append("throw new UnsupportedOperationException(\"method ").append(method.toString()).append(" of interface ").append(this.type.getName()).append(" is not adaptive method!\");");
/*     */       }
/*     */       else
/*     */       {
/* 772 */         int urlTypeIndex = -1;
/* 773 */         for (int i = 0; i < pts.length; i++) {
/* 774 */           if (pts[i].equals(com.alibaba.dubbo.common.URL.class)) {
/* 775 */             urlTypeIndex = i;
/* 776 */             break;
/*     */           }
/*     */         }
/*     */ 
/* 780 */         if (urlTypeIndex != -1)
/*     */         {
/* 782 */           String s = String.format("\nif (arg%d == null) throw new IllegalArgumentException(\"url == null\");", new Object[] { Integer.valueOf(urlTypeIndex) });
/*     */ 
/* 784 */           code.append(s);
/*     */ 
/* 786 */           s = String.format("\n%s url = arg%d;", new Object[] { com.alibaba.dubbo.common.URL.class.getName(), Integer.valueOf(urlTypeIndex) });
/* 787 */           code.append(s);
/*     */         }
/*     */         else
/*     */         {
/* 791 */           String attribMethod = null;
/*     */ 
/* 795 */           for (int i = 0; i < pts.length; i++) {
/* 796 */             Method[] ms = pts[i].getMethods();
/* 797 */             for (Method m : ms) {
/* 798 */               String name = m.getName();
/* 799 */               if (((name.startsWith("get")) || (name.length() > 3)) && (Modifier.isPublic(m.getModifiers())) && (!Modifier.isStatic(m.getModifiers())) && (m.getParameterTypes().length == 0) && (m.getReturnType() == com.alibaba.dubbo.common.URL.class))
/*     */               {
/* 804 */                 urlTypeIndex = i;
/* 805 */                 attribMethod = name;
/* 806 */                 break label606;
/*     */               }
/*     */             }
/*     */           }
/* 810 */           if (attribMethod == null) {
/* 811 */             throw new IllegalStateException("fail to create adative class for interface " + this.type.getName() + ": not found url parameter or url attribute in parameters of method " + method.getName());
/*     */           }
/*     */ 
/* 816 */           String s = String.format("\nif (arg%d == null) throw new IllegalArgumentException(\"%s argument == null\");", new Object[] { Integer.valueOf(urlTypeIndex), pts[urlTypeIndex].getName() });
/*     */ 
/* 818 */           code.append(s);
/* 819 */           s = String.format("\nif (arg%d.%s() == null) throw new IllegalArgumentException(\"%s argument %s() == null\");", new Object[] { Integer.valueOf(urlTypeIndex), attribMethod, pts[urlTypeIndex].getName(), attribMethod });
/*     */ 
/* 821 */           code.append(s);
/*     */ 
/* 823 */           s = String.format("%s url = arg%d.%s();", new Object[] { com.alibaba.dubbo.common.URL.class.getName(), Integer.valueOf(urlTypeIndex), attribMethod });
/* 824 */           code.append(s);
/*     */         }
/*     */ 
/* 827 */         String[] value = adaptiveAnnotation.value();
/*     */ 
/* 829 */         if (value.length == 0) {
/* 830 */           char[] charArray = this.type.getSimpleName().toCharArray();
/* 831 */           StringBuilder sb = new StringBuilder(128);
/* 832 */           for (int i = 0; i < charArray.length; i++) {
/* 833 */             if (Character.isUpperCase(charArray[i])) {
/* 834 */               if (i != 0) {
/* 835 */                 sb.append(".");
/*     */               }
/* 837 */               sb.append(Character.toLowerCase(charArray[i]));
/*     */             }
/*     */             else {
/* 840 */               sb.append(charArray[i]);
/*     */             }
/*     */           }
/* 843 */           value = new String[] { sb.toString() };
/*     */         }
/*     */ 
/* 846 */         boolean hasInvocation = false;
/* 847 */         for (int i = 0; i < pts.length; i++) {
/* 848 */           if (pts[i].getName().equals("com.alibaba.dubbo.rpc.Invocation"))
/*     */           {
/* 850 */             String s = String.format("\nif (arg%d == null) throw new IllegalArgumentException(\"invocation == null\");", new Object[] { Integer.valueOf(i) });
/* 851 */             code.append(s);
/* 852 */             s = String.format("\nString methodName = arg%d.getMethodName();", new Object[] { Integer.valueOf(i) });
/* 853 */             code.append(s);
/* 854 */             hasInvocation = true;
/* 855 */             break;
/*     */           }
/*     */         }
/*     */ 
/* 859 */         String defaultExtName = this.cachedDefaultName;
/* 860 */         String getNameCode = null;
/* 861 */         for (int i = value.length - 1; i >= 0; i--) {
/* 862 */           if (i == value.length - 1) {
/* 863 */             if (null != defaultExtName) {
/* 864 */               if (!"protocol".equals(value[i])) {
/* 865 */                 if (hasInvocation)
/* 866 */                   getNameCode = String.format("url.getMethodParameter(methodName, \"%s\", \"%s\")", new Object[] { value[i], defaultExtName });
/*     */                 else
/* 868 */                   getNameCode = String.format("url.getParameter(\"%s\", \"%s\")", new Object[] { value[i], defaultExtName });
/*     */               }
/* 870 */               else getNameCode = String.format("( url.getProtocol() == null ? \"%s\" : url.getProtocol() )", new Object[] { defaultExtName });
/*     */ 
/*     */             }
/* 873 */             else if (!"protocol".equals(value[i])) {
/* 874 */               if (hasInvocation)
/* 875 */                 getNameCode = String.format("url.getMethodParameter(methodName, \"%s\", \"%s\")", new Object[] { value[i], defaultExtName });
/*     */               else
/* 877 */                 getNameCode = String.format("url.getParameter(\"%s\")", new Object[] { value[i] });
/*     */             }
/* 879 */             else getNameCode = "url.getProtocol()";
/*     */ 
/*     */           }
/* 883 */           else if (!"protocol".equals(value[i])) {
/* 884 */             if (hasInvocation)
/* 885 */               getNameCode = String.format("url.getMethodParameter(methodName, \"%s\", \"%s\")", new Object[] { value[i], defaultExtName });
/*     */             else
/* 887 */               getNameCode = String.format("url.getParameter(\"%s\", %s)", new Object[] { value[i], getNameCode });
/*     */           }
/* 889 */           else getNameCode = String.format("url.getProtocol() == null ? (%s) : url.getProtocol()", new Object[] { getNameCode });
/*     */         }
/*     */ 
/* 892 */         code.append("\nString extName = ").append(getNameCode).append(";");
/*     */ 
/* 894 */         String s = String.format("\nif(extName == null) throw new IllegalStateException(\"Fail to get extension(%s) name from url(\" + url.toString() + \") use keys(%s)\");", new Object[] { this.type.getName(), Arrays.toString(value) });
/*     */ 
/* 897 */         code.append(s);
/*     */ 
/* 899 */         s = String.format("\n%s extension = (%<s)%s.getExtensionLoader(%s.class).getExtension(extName);", new Object[] { this.type.getName(), ExtensionLoader.class.getSimpleName(), this.type.getName() });
/*     */ 
/* 901 */         code.append(s);
/*     */ 
/* 904 */         if (!rt.equals(Void.TYPE)) {
/* 905 */           code.append("\nreturn ");
/*     */         }
/*     */ 
/* 908 */         s = String.format("extension.%s(", new Object[] { method.getName() });
/* 909 */         code.append(s);
/* 910 */         for (int i = 0; i < pts.length; i++) {
/* 911 */           if (i != 0)
/* 912 */             code.append(", ");
/* 913 */           code.append("arg").append(i);
/*     */         }
/* 915 */         code.append(");");
/*     */       }
/*     */ 
/* 918 */       codeBuidler.append("\npublic " + rt.getCanonicalName() + " " + method.getName() + "(");
/* 919 */       for (int i = 0; i < pts.length; i++) {
/* 920 */         if (i > 0) {
/* 921 */           codeBuidler.append(", ");
/*     */         }
/* 923 */         codeBuidler.append(pts[i].getCanonicalName());
/* 924 */         codeBuidler.append(" ");
/* 925 */         codeBuidler.append("arg" + i);
/*     */       }
/* 927 */       codeBuidler.append(")");
/* 928 */       if (ets.length > 0) {
/* 929 */         codeBuidler.append(" throws ");
/* 930 */         for (int i = 0; i < ets.length; i++) {
/* 931 */           if (i > 0) {
/* 932 */             codeBuidler.append(", ");
/*     */           }
/* 934 */           codeBuidler.append(pts[i].getCanonicalName());
/*     */         }
/*     */       }
/* 937 */       codeBuidler.append(" {");
/* 938 */       codeBuidler.append(code.toString());
/* 939 */       codeBuidler.append("\n}");
/*     */     }
/* 941 */     codeBuidler.append("\n}");
/* 942 */     if (logger.isDebugEnabled()) {
/* 943 */       logger.debug(codeBuidler.toString());
/*     */     }
/* 945 */     return codeBuidler.toString();
/*     */   }
/*     */ 
/*     */   private static ClassLoader findClassLoader() {
/* 949 */     return ExtensionLoader.class.getClassLoader();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 954 */     return getClass().getName() + "[" + this.type.getName() + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.extension.ExtensionLoader
 * JD-Core Version:    0.6.2
 */