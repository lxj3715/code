/*    */ package com.alibaba.dubbo.common.extension.factory;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Adaptive;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionFactory;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ @Adaptive
/*    */ public class AdaptiveExtensionFactory
/*    */   implements ExtensionFactory
/*    */ {
/*    */   private final List<ExtensionFactory> factories;
/*    */ 
/*    */   public AdaptiveExtensionFactory()
/*    */   {
/* 37 */     ExtensionLoader loader = ExtensionLoader.getExtensionLoader(ExtensionFactory.class);
/* 38 */     List list = new ArrayList();
/* 39 */     for (String name : loader.getSupportedExtensions()) {
/* 40 */       list.add(loader.getExtension(name));
/*    */     }
/* 42 */     this.factories = Collections.unmodifiableList(list);
/*    */   }
/*    */ 
/*    */   public <T> T getExtension(Class<T> type, String name) {
/* 46 */     for (ExtensionFactory factory : this.factories) {
/* 47 */       Object extension = factory.getExtension(type, name);
/* 48 */       if (extension != null) {
/* 49 */         return extension;
/*    */       }
/*    */     }
/* 52 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.extension.factory.AdaptiveExtensionFactory
 * JD-Core Version:    0.6.2
 */