/*    */ package com.alibaba.dubbo.common.extension.factory;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.ExtensionFactory;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.common.extension.SPI;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class SpiExtensionFactory
/*    */   implements ExtensionFactory
/*    */ {
/*    */   public <T> T getExtension(Class<T> type, String name)
/*    */   {
/* 30 */     if ((type.isInterface()) && (type.isAnnotationPresent(SPI.class))) {
/* 31 */       ExtensionLoader loader = ExtensionLoader.getExtensionLoader(type);
/* 32 */       if (loader.getSupportedExtensions().size() > 0) {
/* 33 */         return loader.getAdaptiveExtension();
/*    */       }
/*    */     }
/* 36 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.extension.factory.SpiExtensionFactory
 * JD-Core Version:    0.6.2
 */