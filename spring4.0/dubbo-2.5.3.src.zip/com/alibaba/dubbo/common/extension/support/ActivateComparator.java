/*    */ package com.alibaba.dubbo.common.extension.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.common.extension.SPI;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class ActivateComparator
/*    */   implements Comparator<Object>
/*    */ {
/* 31 */   public static final Comparator<Object> COMPARATOR = new ActivateComparator();
/*    */ 
/*    */   public int compare(Object o1, Object o2) {
/* 34 */     if ((o1 == null) && (o2 == null)) {
/* 35 */       return 0;
/*    */     }
/* 37 */     if (o1 == null) {
/* 38 */       return -1;
/*    */     }
/* 40 */     if (o2 == null) {
/* 41 */       return 1;
/*    */     }
/* 43 */     if (o1.equals(o2)) {
/* 44 */       return 0;
/*    */     }
/* 46 */     Activate a1 = (Activate)o1.getClass().getAnnotation(Activate.class);
/* 47 */     Activate a2 = (Activate)o2.getClass().getAnnotation(Activate.class);
/* 48 */     if (((a1.before().length > 0) || (a1.after().length > 0) || (a2.before().length > 0) || (a2.after().length > 0)) && (o1.getClass().getInterfaces().length > 0) && (o1.getClass().getInterfaces()[0].isAnnotationPresent(SPI.class)))
/*    */     {
/* 52 */       ExtensionLoader extensionLoader = ExtensionLoader.getExtensionLoader(o1.getClass().getInterfaces()[0]);
/* 53 */       if ((a1.before().length > 0) || (a1.after().length > 0)) {
/* 54 */         String n2 = extensionLoader.getExtensionName(o2.getClass());
/* 55 */         for (String before : a1.before()) {
/* 56 */           if (before.equals(n2)) {
/* 57 */             return -1;
/*    */           }
/*    */         }
/* 60 */         for (String after : a1.after()) {
/* 61 */           if (after.equals(n2)) {
/* 62 */             return 1;
/*    */           }
/*    */         }
/*    */       }
/* 66 */       if ((a2.before().length > 0) || (a2.after().length > 0)) {
/* 67 */         String n1 = extensionLoader.getExtensionName(o1.getClass());
/* 68 */         for (String before : a2.before()) {
/* 69 */           if (before.equals(n1)) {
/* 70 */             return 1;
/*    */           }
/*    */         }
/* 73 */         for (String after : a2.after()) {
/* 74 */           if (after.equals(n1)) {
/* 75 */             return -1;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 80 */     int n1 = a1 == null ? 0 : a1.order();
/* 81 */     int n2 = a2 == null ? 0 : a2.order();
/* 82 */     return n1 > n2 ? 1 : -1;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.extension.support.ActivateComparator
 * JD-Core Version:    0.6.2
 */