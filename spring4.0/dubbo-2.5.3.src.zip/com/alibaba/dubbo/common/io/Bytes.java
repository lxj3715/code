/*     */ package com.alibaba.dubbo.common.io;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.IOUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.zip.DeflaterOutputStream;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ 
/*     */ public class Bytes
/*     */ {
/*     */   private static final String C64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
/*  42 */   private static final char[] BASE16 = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' }; private static final char[] BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".toCharArray();
/*     */   private static final int MASK4 = 15;
/*     */   private static final int MASK6 = 63;
/*     */   private static final int MASK8 = 255;
/*  46 */   private static final Map<Integer, byte[]> DECODE_TABLE_MAP = new ConcurrentHashMap();
/*     */ 
/*  48 */   private static ThreadLocal<MessageDigest> MD = new ThreadLocal();
/*     */ 
/*     */   public static byte[] copyOf(byte[] src, int length)
/*     */   {
/*  59 */     byte[] dest = new byte[length];
/*  60 */     System.arraycopy(src, 0, dest, 0, Math.min(src.length, length));
/*  61 */     return dest;
/*     */   }
/*     */ 
/*     */   public static byte[] short2bytes(short v)
/*     */   {
/*  72 */     byte[] ret = { 0, 0 };
/*  73 */     short2bytes(v, ret);
/*  74 */     return ret;
/*     */   }
/*     */ 
/*     */   public static void short2bytes(short v, byte[] b)
/*     */   {
/*  85 */     short2bytes(v, b, 0);
/*     */   }
/*     */ 
/*     */   public static void short2bytes(short v, byte[] b, int off)
/*     */   {
/*  96 */     b[(off + 1)] = ((byte)v);
/*  97 */     b[(off + 0)] = ((byte)(v >>> 8));
/*     */   }
/*     */ 
/*     */   public static byte[] int2bytes(int v)
/*     */   {
/* 108 */     byte[] ret = { 0, 0, 0, 0 };
/* 109 */     int2bytes(v, ret);
/* 110 */     return ret;
/*     */   }
/*     */ 
/*     */   public static void int2bytes(int v, byte[] b)
/*     */   {
/* 121 */     int2bytes(v, b, 0);
/*     */   }
/*     */ 
/*     */   public static void int2bytes(int v, byte[] b, int off)
/*     */   {
/* 133 */     b[(off + 3)] = ((byte)v);
/* 134 */     b[(off + 2)] = ((byte)(v >>> 8));
/* 135 */     b[(off + 1)] = ((byte)(v >>> 16));
/* 136 */     b[(off + 0)] = ((byte)(v >>> 24));
/*     */   }
/*     */ 
/*     */   public static byte[] float2bytes(float v)
/*     */   {
/* 147 */     byte[] ret = { 0, 0, 0, 0 };
/* 148 */     float2bytes(v, ret);
/* 149 */     return ret;
/*     */   }
/*     */ 
/*     */   public static void float2bytes(float v, byte[] b)
/*     */   {
/* 160 */     float2bytes(v, b, 0);
/*     */   }
/*     */ 
/*     */   public static void float2bytes(float v, byte[] b, int off)
/*     */   {
/* 172 */     int i = Float.floatToIntBits(v);
/* 173 */     b[(off + 3)] = ((byte)i);
/* 174 */     b[(off + 2)] = ((byte)(i >>> 8));
/* 175 */     b[(off + 1)] = ((byte)(i >>> 16));
/* 176 */     b[(off + 0)] = ((byte)(i >>> 24));
/*     */   }
/*     */ 
/*     */   public static byte[] long2bytes(long v)
/*     */   {
/* 187 */     byte[] ret = { 0, 0, 0, 0, 0, 0, 0, 0 };
/* 188 */     long2bytes(v, ret);
/* 189 */     return ret;
/*     */   }
/*     */ 
/*     */   public static void long2bytes(long v, byte[] b)
/*     */   {
/* 200 */     long2bytes(v, b, 0);
/*     */   }
/*     */ 
/*     */   public static void long2bytes(long v, byte[] b, int off)
/*     */   {
/* 212 */     b[(off + 7)] = ((byte)(int)v);
/* 213 */     b[(off + 6)] = ((byte)(int)(v >>> 8));
/* 214 */     b[(off + 5)] = ((byte)(int)(v >>> 16));
/* 215 */     b[(off + 4)] = ((byte)(int)(v >>> 24));
/* 216 */     b[(off + 3)] = ((byte)(int)(v >>> 32));
/* 217 */     b[(off + 2)] = ((byte)(int)(v >>> 40));
/* 218 */     b[(off + 1)] = ((byte)(int)(v >>> 48));
/* 219 */     b[(off + 0)] = ((byte)(int)(v >>> 56));
/*     */   }
/*     */ 
/*     */   public static byte[] double2bytes(double v)
/*     */   {
/* 230 */     byte[] ret = { 0, 0, 0, 0, 0, 0, 0, 0 };
/* 231 */     double2bytes(v, ret);
/* 232 */     return ret;
/*     */   }
/*     */ 
/*     */   public static void double2bytes(double v, byte[] b)
/*     */   {
/* 243 */     double2bytes(v, b, 0);
/*     */   }
/*     */ 
/*     */   public static void double2bytes(double v, byte[] b, int off)
/*     */   {
/* 255 */     long j = Double.doubleToLongBits(v);
/* 256 */     b[(off + 7)] = ((byte)(int)j);
/* 257 */     b[(off + 6)] = ((byte)(int)(j >>> 8));
/* 258 */     b[(off + 5)] = ((byte)(int)(j >>> 16));
/* 259 */     b[(off + 4)] = ((byte)(int)(j >>> 24));
/* 260 */     b[(off + 3)] = ((byte)(int)(j >>> 32));
/* 261 */     b[(off + 2)] = ((byte)(int)(j >>> 40));
/* 262 */     b[(off + 1)] = ((byte)(int)(j >>> 48));
/* 263 */     b[(off + 0)] = ((byte)(int)(j >>> 56));
/*     */   }
/*     */ 
/*     */   public static short bytes2short(byte[] b)
/*     */   {
/* 274 */     return bytes2short(b, 0);
/*     */   }
/*     */ 
/*     */   public static short bytes2short(byte[] b, int off)
/*     */   {
/* 286 */     return (short)(((b[(off + 1)] & 0xFF) << 0) + (b[(off + 0)] << 8));
/*     */   }
/*     */ 
/*     */   public static int bytes2int(byte[] b)
/*     */   {
/* 298 */     return bytes2int(b, 0);
/*     */   }
/*     */ 
/*     */   public static int bytes2int(byte[] b, int off)
/*     */   {
/* 310 */     return ((b[(off + 3)] & 0xFF) << 0) + ((b[(off + 2)] & 0xFF) << 8) + ((b[(off + 1)] & 0xFF) << 16) + (b[(off + 0)] << 24);
/*     */   }
/*     */ 
/*     */   public static float bytes2float(byte[] b)
/*     */   {
/* 324 */     return bytes2float(b, 0);
/*     */   }
/*     */ 
/*     */   public static float bytes2float(byte[] b, int off)
/*     */   {
/* 336 */     int i = ((b[(off + 3)] & 0xFF) << 0) + ((b[(off + 2)] & 0xFF) << 8) + ((b[(off + 1)] & 0xFF) << 16) + (b[(off + 0)] << 24);
/*     */ 
/* 340 */     return Float.intBitsToFloat(i);
/*     */   }
/*     */ 
/*     */   public static long bytes2long(byte[] b)
/*     */   {
/* 351 */     return bytes2long(b, 0);
/*     */   }
/*     */ 
/*     */   public static long bytes2long(byte[] b, int off)
/*     */   {
/* 363 */     return ((b[(off + 7)] & 0xFF) << 0) + ((b[(off + 6)] & 0xFF) << 8) + ((b[(off + 5)] & 0xFF) << 16) + ((b[(off + 4)] & 0xFF) << 24) + ((b[(off + 3)] & 0xFF) << 32) + ((b[(off + 2)] & 0xFF) << 40) + ((b[(off + 1)] & 0xFF) << 48) + (b[(off + 0)] << 56);
/*     */   }
/*     */ 
/*     */   public static double bytes2double(byte[] b)
/*     */   {
/* 381 */     return bytes2double(b, 0);
/*     */   }
/*     */ 
/*     */   public static double bytes2double(byte[] b, int off)
/*     */   {
/* 393 */     long j = ((b[(off + 7)] & 0xFF) << 0) + ((b[(off + 6)] & 0xFF) << 8) + ((b[(off + 5)] & 0xFF) << 16) + ((b[(off + 4)] & 0xFF) << 24) + ((b[(off + 3)] & 0xFF) << 32) + ((b[(off + 2)] & 0xFF) << 40) + ((b[(off + 1)] & 0xFF) << 48) + (b[(off + 0)] << 56);
/*     */ 
/* 401 */     return Double.longBitsToDouble(j);
/*     */   }
/*     */ 
/*     */   public static String bytes2hex(byte[] bs)
/*     */   {
/* 412 */     return bytes2hex(bs, 0, bs.length);
/*     */   }
/*     */ 
/*     */   public static String bytes2hex(byte[] bs, int off, int len)
/*     */   {
/* 425 */     if (off < 0)
/* 426 */       throw new IndexOutOfBoundsException("bytes2hex: offset < 0, offset is " + off);
/* 427 */     if (len < 0)
/* 428 */       throw new IndexOutOfBoundsException("bytes2hex: length < 0, length is " + len);
/* 429 */     if (off + len > bs.length) {
/* 430 */       throw new IndexOutOfBoundsException("bytes2hex: offset + length > array length.");
/*     */     }
/*     */ 
/* 433 */     int r = off; int w = 0;
/* 434 */     char[] cs = new char[len * 2];
/* 435 */     for (int i = 0; i < len; i++)
/*     */     {
/* 437 */       byte b = bs[(r++)];
/* 438 */       cs[(w++)] = BASE16[(b >> 4 & 0xF)];
/* 439 */       cs[(w++)] = BASE16[(b & 0xF)];
/*     */     }
/* 441 */     return new String(cs);
/*     */   }
/*     */ 
/*     */   public static byte[] hex2bytes(String str)
/*     */   {
/* 452 */     return hex2bytes(str, 0, str.length());
/*     */   }
/*     */ 
/*     */   public static byte[] hex2bytes(String str, int off, int len)
/*     */   {
/* 465 */     if ((len & 0x1) == 1) {
/* 466 */       throw new IllegalArgumentException("hex2bytes: ( len & 1 ) == 1.");
/*     */     }
/* 468 */     if (off < 0)
/* 469 */       throw new IndexOutOfBoundsException("hex2bytes: offset < 0, offset is " + off);
/* 470 */     if (len < 0)
/* 471 */       throw new IndexOutOfBoundsException("hex2bytes: length < 0, length is " + len);
/* 472 */     if (off + len > str.length()) {
/* 473 */       throw new IndexOutOfBoundsException("hex2bytes: offset + length > array length.");
/*     */     }
/* 475 */     int num = len / 2; int r = off; int w = 0;
/* 476 */     byte[] b = new byte[num];
/* 477 */     for (int i = 0; i < num; i++)
/* 478 */       b[(w++)] = ((byte)(hex(str.charAt(r++)) << 4 | hex(str.charAt(r++))));
/* 479 */     return b;
/*     */   }
/*     */ 
/*     */   public static String bytes2base64(byte[] b)
/*     */   {
/* 490 */     return bytes2base64(b, 0, b.length, BASE64);
/*     */   }
/*     */ 
/*     */   public static String bytes2base64(byte[] b, int offset, int length)
/*     */   {
/* 501 */     return bytes2base64(b, offset, length, BASE64);
/*     */   }
/*     */ 
/*     */   public static String bytes2base64(byte[] b, String code)
/*     */   {
/* 513 */     return bytes2base64(b, 0, b.length, code);
/*     */   }
/*     */ 
/*     */   public static String bytes2base64(byte[] b, int offset, int length, String code)
/*     */   {
/* 525 */     if (code.length() < 64) {
/* 526 */       throw new IllegalArgumentException("Base64 code length < 64.");
/*     */     }
/* 528 */     return bytes2base64(b, offset, length, code.toCharArray());
/*     */   }
/*     */ 
/*     */   public static String bytes2base64(byte[] b, char[] code)
/*     */   {
/* 540 */     return bytes2base64(b, 0, b.length, code);
/*     */   }
/*     */ 
/*     */   public static String bytes2base64(byte[] bs, int off, int len, char[] code)
/*     */   {
/* 554 */     if (off < 0)
/* 555 */       throw new IndexOutOfBoundsException("bytes2base64: offset < 0, offset is " + off);
/* 556 */     if (len < 0)
/* 557 */       throw new IndexOutOfBoundsException("bytes2base64: length < 0, length is " + len);
/* 558 */     if (off + len > bs.length) {
/* 559 */       throw new IndexOutOfBoundsException("bytes2base64: offset + length > array length.");
/*     */     }
/* 561 */     if (code.length < 64) {
/* 562 */       throw new IllegalArgumentException("Base64 code length < 64.");
/*     */     }
/* 564 */     boolean pad = code.length > 64;
/* 565 */     int num = len / 3; int rem = len % 3; int r = off; int w = 0;
/* 566 */     char[] cs = new char[num * 4 + (pad ? 4 : rem == 0 ? 0 : rem + 1)];
/*     */ 
/* 568 */     for (int i = 0; i < num; i++)
/*     */     {
/* 570 */       int b1 = bs[(r++)] & 0xFF; int b2 = bs[(r++)] & 0xFF; int b3 = bs[(r++)] & 0xFF;
/*     */ 
/* 572 */       cs[(w++)] = code[(b1 >> 2)];
/* 573 */       cs[(w++)] = code[(b1 << 4 & 0x3F | b2 >> 4)];
/* 574 */       cs[(w++)] = code[(b2 << 2 & 0x3F | b3 >> 6)];
/* 575 */       cs[(w++)] = code[(b3 & 0x3F)];
/*     */     }
/*     */ 
/* 578 */     if (rem == 1)
/*     */     {
/* 580 */       int b1 = bs[(r++)] & 0xFF;
/* 581 */       cs[(w++)] = code[(b1 >> 2)];
/* 582 */       cs[(w++)] = code[(b1 << 4 & 0x3F)];
/* 583 */       if (pad)
/*     */       {
/* 585 */         cs[(w++)] = code[64];
/* 586 */         cs[(w++)] = code[64];
/*     */       }
/*     */     }
/* 589 */     else if (rem == 2)
/*     */     {
/* 591 */       int b1 = bs[(r++)] & 0xFF; int b2 = bs[(r++)] & 0xFF;
/* 592 */       cs[(w++)] = code[(b1 >> 2)];
/* 593 */       cs[(w++)] = code[(b1 << 4 & 0x3F | b2 >> 4)];
/* 594 */       cs[(w++)] = code[(b2 << 2 & 0x3F)];
/* 595 */       if (pad)
/* 596 */         cs[(w++)] = code[64];
/*     */     }
/* 598 */     return new String(cs);
/*     */   }
/*     */ 
/*     */   public static byte[] base642bytes(String str)
/*     */   {
/* 609 */     return base642bytes(str, 0, str.length());
/*     */   }
/*     */ 
/*     */   public static byte[] base642bytes(String str, int offset, int length)
/*     */   {
/* 622 */     return base642bytes(str, offset, length, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=");
/*     */   }
/*     */ 
/*     */   public static byte[] base642bytes(String str, String code)
/*     */   {
/* 634 */     return base642bytes(str, 0, str.length(), code);
/*     */   }
/*     */ 
/*     */   public static byte[] base642bytes(String str, int off, int len, String code)
/*     */   {
/* 648 */     if (off < 0)
/* 649 */       throw new IndexOutOfBoundsException("base642bytes: offset < 0, offset is " + off);
/* 650 */     if (len < 0)
/* 651 */       throw new IndexOutOfBoundsException("base642bytes: length < 0, length is " + len);
/* 652 */     if (off + len > str.length()) {
/* 653 */       throw new IndexOutOfBoundsException("base642bytes: offset + length > string length.");
/*     */     }
/* 655 */     if (code.length() < 64) {
/* 656 */       throw new IllegalArgumentException("Base64 code length < 64.");
/*     */     }
/* 658 */     int rem = len % 4;
/* 659 */     if (rem == 1) {
/* 660 */       throw new IllegalArgumentException("base642bytes: base64 string length % 4 == 1.");
/*     */     }
/* 662 */     int num = len / 4; int size = num * 3;
/* 663 */     if (code.length() > 64)
/*     */     {
/* 665 */       if (rem != 0) {
/* 666 */         throw new IllegalArgumentException("base642bytes: base64 string length error.");
/*     */       }
/* 668 */       char pc = code.charAt(64);
/* 669 */       if (str.charAt(off + len - 2) == pc)
/*     */       {
/* 671 */         size -= 2;
/* 672 */         num--;
/* 673 */         rem = 2;
/*     */       }
/* 675 */       else if (str.charAt(off + len - 1) == pc)
/*     */       {
/* 677 */         size--;
/* 678 */         num--;
/* 679 */         rem = 3;
/*     */       }
/*     */ 
/*     */     }
/* 684 */     else if (rem == 2) {
/* 685 */       size++;
/* 686 */     } else if (rem == 3) {
/* 687 */       size += 2;
/*     */     }
/*     */ 
/* 690 */     int r = off; int w = 0;
/* 691 */     byte[] b = new byte[size]; byte[] t = decodeTable(code);
/* 692 */     for (int i = 0; i < num; i++)
/*     */     {
/* 694 */       int c1 = t[str.charAt(r++)]; int c2 = t[str.charAt(r++)];
/* 695 */       int c3 = t[str.charAt(r++)]; int c4 = t[str.charAt(r++)];
/*     */ 
/* 697 */       b[(w++)] = ((byte)(c1 << 2 | c2 >> 4));
/* 698 */       b[(w++)] = ((byte)(c2 << 4 | c3 >> 2));
/* 699 */       b[(w++)] = ((byte)(c3 << 6 | c4));
/*     */     }
/*     */ 
/* 702 */     if (rem == 2)
/*     */     {
/* 704 */       int c1 = t[str.charAt(r++)]; int c2 = t[str.charAt(r++)];
/*     */ 
/* 706 */       b[(w++)] = ((byte)(c1 << 2 | c2 >> 4));
/*     */     }
/* 708 */     else if (rem == 3)
/*     */     {
/* 710 */       int c1 = t[str.charAt(r++)]; int c2 = t[str.charAt(r++)]; int c3 = t[str.charAt(r++)];
/*     */ 
/* 712 */       b[(w++)] = ((byte)(c1 << 2 | c2 >> 4));
/* 713 */       b[(w++)] = ((byte)(c2 << 4 | c3 >> 2));
/*     */     }
/* 715 */     return b;
/*     */   }
/*     */ 
/*     */   public static byte[] base642bytes(String str, char[] code)
/*     */   {
/* 727 */     return base642bytes(str, 0, str.length(), code);
/*     */   }
/*     */ 
/*     */   public static byte[] base642bytes(String str, int off, int len, char[] code)
/*     */   {
/* 741 */     if (off < 0)
/* 742 */       throw new IndexOutOfBoundsException("base642bytes: offset < 0, offset is " + off);
/* 743 */     if (len < 0)
/* 744 */       throw new IndexOutOfBoundsException("base642bytes: length < 0, length is " + len);
/* 745 */     if (off + len > str.length()) {
/* 746 */       throw new IndexOutOfBoundsException("base642bytes: offset + length > string length.");
/*     */     }
/* 748 */     if (code.length < 64) {
/* 749 */       throw new IllegalArgumentException("Base64 code length < 64.");
/*     */     }
/* 751 */     int rem = len % 4;
/* 752 */     if (rem == 1) {
/* 753 */       throw new IllegalArgumentException("base642bytes: base64 string length % 4 == 1.");
/*     */     }
/* 755 */     int num = len / 4; int size = num * 3;
/* 756 */     if (code.length > 64)
/*     */     {
/* 758 */       if (rem != 0) {
/* 759 */         throw new IllegalArgumentException("base642bytes: base64 string length error.");
/*     */       }
/* 761 */       char pc = code[64];
/* 762 */       if (str.charAt(off + len - 2) == pc)
/* 763 */         size -= 2;
/* 764 */       else if (str.charAt(off + len - 1) == pc) {
/* 765 */         size--;
/*     */       }
/*     */ 
/*     */     }
/* 769 */     else if (rem == 2) {
/* 770 */       size++;
/* 771 */     } else if (rem == 3) {
/* 772 */       size += 2;
/*     */     }
/*     */ 
/* 775 */     int r = off; int w = 0;
/* 776 */     byte[] b = new byte[size];
/* 777 */     for (int i = 0; i < num; i++)
/*     */     {
/* 779 */       int c1 = indexOf(code, str.charAt(r++)); int c2 = indexOf(code, str.charAt(r++));
/* 780 */       int c3 = indexOf(code, str.charAt(r++)); int c4 = indexOf(code, str.charAt(r++));
/*     */ 
/* 782 */       b[(w++)] = ((byte)(c1 << 2 | c2 >> 4));
/* 783 */       b[(w++)] = ((byte)(c2 << 4 | c3 >> 2));
/* 784 */       b[(w++)] = ((byte)(c3 << 6 | c4));
/*     */     }
/*     */ 
/* 787 */     if (rem == 2)
/*     */     {
/* 789 */       int c1 = indexOf(code, str.charAt(r++)); int c2 = indexOf(code, str.charAt(r++));
/*     */ 
/* 791 */       b[(w++)] = ((byte)(c1 << 2 | c2 >> 4));
/*     */     }
/* 793 */     else if (rem == 3)
/*     */     {
/* 795 */       int c1 = indexOf(code, str.charAt(r++)); int c2 = indexOf(code, str.charAt(r++)); int c3 = indexOf(code, str.charAt(r++));
/*     */ 
/* 797 */       b[(w++)] = ((byte)(c1 << 2 | c2 >> 4));
/* 798 */       b[(w++)] = ((byte)(c2 << 4 | c3 >> 2));
/*     */     }
/* 800 */     return b;
/*     */   }
/*     */ 
/*     */   public static byte[] zip(byte[] bytes)
/*     */     throws IOException
/*     */   {
/* 812 */     UnsafeByteArrayOutputStream bos = new UnsafeByteArrayOutputStream();
/* 813 */     OutputStream os = new DeflaterOutputStream(bos);
/*     */     try
/*     */     {
/* 816 */       os.write(bytes);
/*     */     }
/*     */     finally
/*     */     {
/* 820 */       os.close();
/* 821 */       bos.close();
/*     */     }
/* 823 */     return bos.toByteArray();
/*     */   }
/*     */ 
/*     */   public static byte[] unzip(byte[] bytes)
/*     */     throws IOException
/*     */   {
/* 835 */     UnsafeByteArrayInputStream bis = new UnsafeByteArrayInputStream(bytes);
/* 836 */     UnsafeByteArrayOutputStream bos = new UnsafeByteArrayOutputStream();
/* 837 */     InputStream is = new InflaterInputStream(bis);
/*     */     try
/*     */     {
/* 840 */       IOUtils.write(is, bos);
/* 841 */       return bos.toByteArray();
/*     */     }
/*     */     finally
/*     */     {
/* 845 */       is.close();
/* 846 */       bis.close();
/* 847 */       bos.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] getMD5(String str)
/*     */   {
/* 859 */     return getMD5(str.getBytes());
/*     */   }
/*     */ 
/*     */   public static byte[] getMD5(byte[] source)
/*     */   {
/* 870 */     MessageDigest md = getMessageDigest();
/* 871 */     return md.digest(source);
/*     */   }
/*     */ 
/*     */   public static byte[] getMD5(File file)
/*     */     throws IOException
/*     */   {
/* 882 */     InputStream is = new FileInputStream(file);
/*     */     try { return getMD5(is); } finally {
/* 884 */       is.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] getMD5(InputStream is)
/*     */     throws IOException
/*     */   {
/* 895 */     return getMD5(is, 8192);
/*     */   }
/*     */ 
/*     */   private static byte hex(char c)
/*     */   {
/* 900 */     if (c <= '9') return (byte)(c - '0');
/* 901 */     if ((c >= 'a') && (c <= 'f')) return (byte)(c - 'a' + 10);
/* 902 */     if ((c >= 'A') && (c <= 'F')) return (byte)(c - 'A' + 10);
/* 903 */     throw new IllegalArgumentException("hex string format error [" + c + "].");
/*     */   }
/*     */ 
/*     */   private static int indexOf(char[] cs, char c)
/*     */   {
/* 908 */     int i = 0; for (int len = cs.length; i < len; i++)
/* 909 */       if (cs[i] == c) return i;
/* 910 */     return -1;
/*     */   }
/*     */ 
/*     */   private static byte[] decodeTable(String code)
/*     */   {
/* 915 */     int hash = code.hashCode();
/* 916 */     byte[] ret = (byte[])DECODE_TABLE_MAP.get(Integer.valueOf(hash));
/* 917 */     if (ret == null)
/*     */     {
/* 919 */       if (code.length() < 64) {
/* 920 */         throw new IllegalArgumentException("Base64 code length < 64.");
/*     */       }
/* 922 */       ret = new byte[''];
/* 923 */       for (int i = 0; i < 128; i++)
/* 924 */         ret[i] = -1;
/* 925 */       for (int i = 0; i < 64; i++)
/* 926 */         ret[code.charAt(i)] = ((byte)i);
/* 927 */       DECODE_TABLE_MAP.put(Integer.valueOf(hash), ret);
/*     */     }
/* 929 */     return ret;
/*     */   }
/*     */ 
/*     */   private static byte[] getMD5(InputStream is, int bs) throws IOException
/*     */   {
/* 934 */     MessageDigest md = getMessageDigest();
/* 935 */     byte[] buf = new byte[bs];
/* 936 */     while (is.available() > 0)
/*     */     {
/* 938 */       int total = 0;
/*     */       do
/*     */       {
/*     */         int read;
/* 941 */         if ((read = is.read(buf, total, bs - total)) <= 0)
/*     */           break;
/* 943 */         total += read;
/*     */       }
/* 945 */       while (total < bs);
/* 946 */       md.update(buf);
/*     */     }
/* 948 */     return md.digest();
/*     */   }
/*     */ 
/*     */   private static MessageDigest getMessageDigest()
/*     */   {
/* 953 */     MessageDigest ret = (MessageDigest)MD.get();
/* 954 */     if (ret == null)
/*     */     {
/*     */       try
/*     */       {
/* 958 */         ret = MessageDigest.getInstance("MD5");
/* 959 */         MD.set(ret);
/*     */       }
/*     */       catch (NoSuchAlgorithmException e)
/*     */       {
/* 963 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/* 966 */     return ret;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.io.Bytes
 * JD-Core Version:    0.6.2
 */