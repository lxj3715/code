/*     */ package com.alibaba.dubbo.common.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class StreamUtils
/*     */ {
/*     */   public static InputStream limitedInputStream(final InputStream is, int limit)
/*     */     throws IOException
/*     */   {
/*  34 */     return new InputStream() {
/*  35 */       private int mPosition = 0; private int mMark = 0; private int mLimit = Math.min(this.val$limit, is.available());
/*     */ 
/*     */       public int read() throws IOException
/*     */       {
/*  39 */         if (this.mPosition < this.mLimit)
/*     */         {
/*  41 */           this.mPosition += 1;
/*  42 */           return is.read();
/*     */         }
/*  44 */         return -1;
/*     */       }
/*     */ 
/*     */       public int read(byte[] b, int off, int len) throws IOException
/*     */       {
/*  49 */         if (b == null) {
/*  50 */           throw new NullPointerException();
/*     */         }
/*  52 */         if ((off < 0) || (len < 0) || (len > b.length - off)) {
/*  53 */           throw new IndexOutOfBoundsException();
/*     */         }
/*  55 */         if (this.mPosition >= this.mLimit) {
/*  56 */           return -1;
/*     */         }
/*  58 */         if (this.mPosition + len > this.mLimit) {
/*  59 */           len = this.mLimit - this.mPosition;
/*     */         }
/*  61 */         if (len <= 0) {
/*  62 */           return 0;
/*     */         }
/*  64 */         is.read(b, off, len);
/*  65 */         this.mPosition += len;
/*  66 */         return len;
/*     */       }
/*     */ 
/*     */       public long skip(long len) throws IOException
/*     */       {
/*  71 */         if (this.mPosition + len > this.mLimit) {
/*  72 */           len = this.mLimit - this.mPosition;
/*     */         }
/*  74 */         if (len <= 0L) {
/*  75 */           return 0L;
/*     */         }
/*  77 */         is.skip(len);
/*  78 */         this.mPosition = ((int)(this.mPosition + len));
/*  79 */         return len;
/*     */       }
/*     */ 
/*     */       public int available()
/*     */       {
/*  84 */         return this.mLimit - this.mPosition;
/*     */       }
/*     */ 
/*     */       public boolean markSupported()
/*     */       {
/*  89 */         return is.markSupported();
/*     */       }
/*     */ 
/*     */       public void mark(int readlimit)
/*     */       {
/*  94 */         is.mark(readlimit);
/*  95 */         this.mMark = this.mPosition;
/*     */       }
/*     */ 
/*     */       public void reset() throws IOException
/*     */       {
/* 100 */         is.reset();
/* 101 */         this.mPosition = this.mMark;
/*     */       }
/*     */ 
/*     */       public void close() throws IOException {
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static InputStream markSupportedInputStream(InputStream is, final int markBufferSize) {
/* 110 */     if (is.markSupported()) {
/* 111 */       return is;
/*     */     }
/*     */ 
/* 114 */     return new InputStream()
/*     */     {
/*     */       byte[] mMarkBuffer;
/* 117 */       boolean mInMarked = false;
/* 118 */       boolean mInReset = false;
/* 119 */       private int mPosition = 0;
/* 120 */       private int mCount = 0;
/*     */ 
/* 122 */       boolean mDry = false;
/*     */ 
/*     */       public int read() throws IOException
/*     */       {
/* 126 */         if (!this.mInMarked) {
/* 127 */           return this.val$is.read();
/*     */         }
/*     */ 
/* 130 */         if (this.mPosition < this.mCount) {
/* 131 */           byte b = this.mMarkBuffer[(this.mPosition++)];
/* 132 */           return b & 0xFF;
/*     */         }
/*     */ 
/* 135 */         if (!this.mInReset) {
/* 136 */           if (this.mDry) return -1;
/*     */ 
/* 138 */           if (null == this.mMarkBuffer) {
/* 139 */             this.mMarkBuffer = new byte[markBufferSize];
/*     */           }
/* 141 */           if (this.mPosition >= markBufferSize) {
/* 142 */             throw new IOException("Mark buffer is full!");
/*     */           }
/*     */ 
/* 145 */           int read = this.val$is.read();
/* 146 */           if (-1 == read) {
/* 147 */             this.mDry = true;
/* 148 */             return -1;
/*     */           }
/*     */ 
/* 151 */           this.mMarkBuffer[(this.mPosition++)] = ((byte)read);
/* 152 */           this.mCount += 1;
/*     */ 
/* 154 */           return read;
/*     */         }
/*     */ 
/* 158 */         this.mInMarked = false;
/* 159 */         this.mInReset = false;
/* 160 */         this.mPosition = 0;
/* 161 */         this.mCount = 0;
/*     */ 
/* 163 */         return this.val$is.read();
/*     */       }
/*     */ 
/*     */       public synchronized void mark(int readlimit)
/*     */       {
/* 174 */         this.mInMarked = true;
/* 175 */         this.mInReset = false;
/*     */ 
/* 178 */         int count = this.mCount - this.mPosition;
/* 179 */         if (count > 0) {
/* 180 */           System.arraycopy(this.mMarkBuffer, this.mPosition, this.mMarkBuffer, 0, count);
/* 181 */           this.mCount = count;
/* 182 */           this.mPosition = 0;
/*     */         }
/*     */       }
/*     */ 
/*     */       public synchronized void reset() throws IOException
/*     */       {
/* 188 */         if (!this.mInMarked) {
/* 189 */           throw new IOException("should mark befor reset!");
/*     */         }
/*     */ 
/* 192 */         this.mInReset = true;
/* 193 */         this.mPosition = 0;
/*     */       }
/*     */ 
/*     */       public boolean markSupported()
/*     */       {
/* 198 */         return true;
/*     */       }
/*     */ 
/*     */       public int available() throws IOException
/*     */       {
/* 203 */         int available = this.val$is.available();
/*     */ 
/* 205 */         if ((this.mInMarked) && (this.mInReset)) available += this.mCount - this.mPosition;
/*     */ 
/* 207 */         return available;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static InputStream markSupportedInputStream(InputStream is) {
/* 213 */     return markSupportedInputStream(is, 1024);
/*     */   }
/*     */ 
/*     */   public static void skipUnusedStream(InputStream is) throws IOException {
/* 217 */     if (is.available() > 0)
/* 218 */       is.skip(is.available());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.io.StreamUtils
 * JD-Core Version:    0.6.2
 */