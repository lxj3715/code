/*     */ package com.alibaba.dubbo.common.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class UnsafeByteArrayInputStream extends InputStream
/*     */ {
/*     */   protected byte[] mData;
/*     */   protected int mPosition;
/*     */   protected int mLimit;
/*  31 */   protected int mMark = 0;
/*     */ 
/*     */   public UnsafeByteArrayInputStream(byte[] buf)
/*     */   {
/*  35 */     this(buf, 0, buf.length);
/*     */   }
/*     */ 
/*     */   public UnsafeByteArrayInputStream(byte[] buf, int offset)
/*     */   {
/*  40 */     this(buf, offset, buf.length - offset);
/*     */   }
/*     */ 
/*     */   public UnsafeByteArrayInputStream(byte[] buf, int offset, int length)
/*     */   {
/*  45 */     this.mData = buf;
/*  46 */     this.mPosition = (this.mMark = offset);
/*  47 */     this.mLimit = Math.min(offset + length, buf.length);
/*     */   }
/*     */ 
/*     */   public int read()
/*     */   {
/*  52 */     return this.mPosition < this.mLimit ? this.mData[(this.mPosition++)] & 0xFF : -1;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */   {
/*  57 */     if (b == null)
/*  58 */       throw new NullPointerException();
/*  59 */     if ((off < 0) || (len < 0) || (len > b.length - off))
/*  60 */       throw new IndexOutOfBoundsException();
/*  61 */     if (this.mPosition >= this.mLimit)
/*  62 */       return -1;
/*  63 */     if (this.mPosition + len > this.mLimit)
/*  64 */       len = this.mLimit - this.mPosition;
/*  65 */     if (len <= 0)
/*  66 */       return 0;
/*  67 */     System.arraycopy(this.mData, this.mPosition, b, off, len);
/*  68 */     this.mPosition += len;
/*  69 */     return len;
/*     */   }
/*     */ 
/*     */   public long skip(long len)
/*     */   {
/*  74 */     if (this.mPosition + len > this.mLimit)
/*  75 */       len = this.mLimit - this.mPosition;
/*  76 */     if (len <= 0L)
/*  77 */       return 0L;
/*  78 */     this.mPosition = ((int)(this.mPosition + len));
/*  79 */     return len;
/*     */   }
/*     */ 
/*     */   public int available()
/*     */   {
/*  84 */     return this.mLimit - this.mPosition;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */   public void mark(int readAheadLimit)
/*     */   {
/*  94 */     this.mMark = this.mPosition;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/*  99 */     this.mPosition = this.mMark;
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public int position() {
/* 107 */     return this.mPosition;
/*     */   }
/*     */ 
/*     */   public void position(int newPosition)
/*     */   {
/* 112 */     this.mPosition = newPosition;
/*     */   }
/*     */ 
/*     */   public int size() {
/* 116 */     return this.mData == null ? 0 : this.mData.length;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.io.UnsafeByteArrayInputStream
 * JD-Core Version:    0.6.2
 */