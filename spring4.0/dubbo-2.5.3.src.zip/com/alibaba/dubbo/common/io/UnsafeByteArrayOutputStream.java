/*     */ package com.alibaba.dubbo.common.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public class UnsafeByteArrayOutputStream extends OutputStream
/*     */ {
/*     */   protected byte[] mBuffer;
/*     */   protected int mCount;
/*     */ 
/*     */   public UnsafeByteArrayOutputStream()
/*     */   {
/*  37 */     this(32);
/*     */   }
/*     */ 
/*     */   public UnsafeByteArrayOutputStream(int size)
/*     */   {
/*  42 */     if (size < 0)
/*  43 */       throw new IllegalArgumentException("Negative initial size: " + size);
/*  44 */     this.mBuffer = new byte[size];
/*     */   }
/*     */ 
/*     */   public void write(int b)
/*     */   {
/*  49 */     int newcount = this.mCount + 1;
/*  50 */     if (newcount > this.mBuffer.length)
/*  51 */       this.mBuffer = Bytes.copyOf(this.mBuffer, Math.max(this.mBuffer.length << 1, newcount));
/*  52 */     this.mBuffer[this.mCount] = ((byte)b);
/*  53 */     this.mCount = newcount;
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */   {
/*  58 */     if ((off < 0) || (off > b.length) || (len < 0) || (off + len > b.length) || (off + len < 0))
/*  59 */       throw new IndexOutOfBoundsException();
/*  60 */     if (len == 0)
/*  61 */       return;
/*  62 */     int newcount = this.mCount + len;
/*  63 */     if (newcount > this.mBuffer.length)
/*  64 */       this.mBuffer = Bytes.copyOf(this.mBuffer, Math.max(this.mBuffer.length << 1, newcount));
/*  65 */     System.arraycopy(b, off, this.mBuffer, this.mCount, len);
/*  66 */     this.mCount = newcount;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*  71 */     return this.mCount;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/*  76 */     this.mCount = 0;
/*     */   }
/*     */ 
/*     */   public byte[] toByteArray()
/*     */   {
/*  81 */     return Bytes.copyOf(this.mBuffer, this.mCount);
/*     */   }
/*     */ 
/*     */   public ByteBuffer toByteBuffer()
/*     */   {
/*  86 */     return ByteBuffer.wrap(this.mBuffer, 0, this.mCount);
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream out) throws IOException
/*     */   {
/*  91 */     out.write(this.mBuffer, 0, this.mCount);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  96 */     return new String(this.mBuffer, 0, this.mCount);
/*     */   }
/*     */ 
/*     */   public String toString(String charset) throws UnsupportedEncodingException
/*     */   {
/* 101 */     return new String(this.mBuffer, 0, this.mCount, charset);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.io.UnsafeByteArrayOutputStream
 * JD-Core Version:    0.6.2
 */