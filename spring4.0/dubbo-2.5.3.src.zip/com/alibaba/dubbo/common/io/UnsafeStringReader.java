/*     */ package com.alibaba.dubbo.common.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ 
/*     */ public class UnsafeStringReader extends Reader
/*     */ {
/*     */   private String mString;
/*     */   private int mPosition;
/*     */   private int mLimit;
/*     */   private int mMark;
/*     */ 
/*     */   public UnsafeStringReader(String str)
/*     */   {
/*  35 */     this.mString = str;
/*  36 */     this.mLimit = str.length();
/*  37 */     this.mPosition = (this.mMark = 0);
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  43 */     ensureOpen();
/*  44 */     if (this.mPosition >= this.mLimit) {
/*  45 */       return -1;
/*     */     }
/*  47 */     return this.mString.charAt(this.mPosition++);
/*     */   }
/*     */ 
/*     */   public int read(char[] cs, int off, int len)
/*     */     throws IOException
/*     */   {
/*  53 */     ensureOpen();
/*  54 */     if ((off < 0) || (off > cs.length) || (len < 0) || (off + len > cs.length) || (off + len < 0))
/*     */     {
/*  56 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  58 */     if (len == 0) {
/*  59 */       return 0;
/*     */     }
/*  61 */     if (this.mPosition >= this.mLimit) {
/*  62 */       return -1;
/*     */     }
/*  64 */     int n = Math.min(this.mLimit - this.mPosition, len);
/*  65 */     this.mString.getChars(this.mPosition, this.mPosition + n, cs, off);
/*  66 */     this.mPosition += n;
/*  67 */     return n;
/*     */   }
/*     */ 
/*     */   public long skip(long ns) throws IOException
/*     */   {
/*  72 */     ensureOpen();
/*  73 */     if (this.mPosition >= this.mLimit) {
/*  74 */       return 0L;
/*     */     }
/*  76 */     long n = Math.min(this.mLimit - this.mPosition, ns);
/*  77 */     n = Math.max(-this.mPosition, n);
/*  78 */     this.mPosition = ((int)(this.mPosition + n));
/*  79 */     return n;
/*     */   }
/*     */ 
/*     */   public boolean ready() throws IOException
/*     */   {
/*  84 */     ensureOpen();
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   public void mark(int readAheadLimit) throws IOException
/*     */   {
/*  96 */     if (readAheadLimit < 0) {
/*  97 */       throw new IllegalArgumentException("Read-ahead limit < 0");
/*     */     }
/*  99 */     ensureOpen();
/* 100 */     this.mMark = this.mPosition;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/* 105 */     ensureOpen();
/* 106 */     this.mPosition = this.mMark;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 112 */     this.mString = null;
/*     */   }
/*     */ 
/*     */   private void ensureOpen() throws IOException
/*     */   {
/* 117 */     if (this.mString == null)
/* 118 */       throw new IOException("Stream closed");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.io.UnsafeStringReader
 * JD-Core Version:    0.6.2
 */