/*     */ package com.alibaba.dubbo.common.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class UnsafeStringWriter extends Writer
/*     */ {
/*     */   private StringBuilder mBuffer;
/*     */ 
/*     */   public UnsafeStringWriter()
/*     */   {
/*  33 */     this.lock = (this.mBuffer = new StringBuilder());
/*     */   }
/*     */ 
/*     */   public UnsafeStringWriter(int size)
/*     */   {
/*  38 */     if (size < 0) {
/*  39 */       throw new IllegalArgumentException("Negative buffer size");
/*     */     }
/*  41 */     this.lock = (this.mBuffer = new StringBuilder());
/*     */   }
/*     */ 
/*     */   public void write(int c)
/*     */   {
/*  47 */     this.mBuffer.append((char)c);
/*     */   }
/*     */ 
/*     */   public void write(char[] cs)
/*     */     throws IOException
/*     */   {
/*  53 */     this.mBuffer.append(cs, 0, cs.length);
/*     */   }
/*     */ 
/*     */   public void write(char[] cs, int off, int len)
/*     */     throws IOException
/*     */   {
/*  59 */     if ((off < 0) || (off > cs.length) || (len < 0) || (off + len > cs.length) || (off + len < 0))
/*     */     {
/*  61 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  63 */     if (len > 0)
/*  64 */       this.mBuffer.append(cs, off, len);
/*     */   }
/*     */ 
/*     */   public void write(String str)
/*     */   {
/*  70 */     this.mBuffer.append(str);
/*     */   }
/*     */ 
/*     */   public void write(String str, int off, int len)
/*     */   {
/*  76 */     this.mBuffer.append(str.substring(off, off + len));
/*     */   }
/*     */ 
/*     */   public Writer append(CharSequence csq)
/*     */   {
/*  82 */     if (csq == null)
/*  83 */       write("null");
/*     */     else
/*  85 */       write(csq.toString());
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */   public Writer append(CharSequence csq, int start, int end)
/*     */   {
/*  92 */     CharSequence cs = csq == null ? "null" : csq;
/*  93 */     write(cs.subSequence(start, end).toString());
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */   public Writer append(char c)
/*     */   {
/* 100 */     this.mBuffer.append(c);
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 113 */     return this.mBuffer.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.io.UnsafeStringWriter
 * JD-Core Version:    0.6.2
 */