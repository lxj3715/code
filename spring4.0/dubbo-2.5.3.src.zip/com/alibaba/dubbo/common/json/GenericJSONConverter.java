/*     */ package com.alibaba.dubbo.common.json;
/*     */ 
/*     */ import com.alibaba.dubbo.common.bytecode.Wrapper;
/*     */ import com.alibaba.dubbo.common.io.Bytes;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ public class GenericJSONConverter
/*     */   implements JSONConverter
/*     */ {
/*     */   private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
/*  42 */   private static final Map<Class<?>, Encoder> GlobalEncoderMap = new HashMap();
/*     */ 
/*  44 */   private static final Map<Class<?>, Decoder> GlobalDecoderMap = new HashMap();
/*     */ 
/*     */   public void writeValue(Object obj, JSONWriter jb, boolean writeClass)
/*     */     throws IOException
/*     */   {
/*  49 */     if (obj == null) {
/*  50 */       jb.valueNull();
/*  51 */       return;
/*     */     }
/*  53 */     Class c = obj.getClass();
/*  54 */     Encoder encoder = (Encoder)GlobalEncoderMap.get(c);
/*     */ 
/*  56 */     if (encoder != null)
/*     */     {
/*  58 */       encoder.encode(obj, jb);
/*     */     }
/*  60 */     else if ((obj instanceof JSONNode))
/*     */     {
/*  62 */       ((JSONNode)obj).writeJSON(this, jb, writeClass);
/*     */     }
/*  64 */     else if (c.isEnum())
/*     */     {
/*  66 */       jb.valueString(((Enum)obj).name());
/*     */     }
/*  68 */     else if (c.isArray())
/*     */     {
/*  70 */       int len = Array.getLength(obj);
/*  71 */       jb.arrayBegin();
/*  72 */       for (int i = 0; i < len; i++)
/*  73 */         writeValue(Array.get(obj, i), jb, writeClass);
/*  74 */       jb.arrayEnd();
/*     */     }
/*  76 */     else if (Map.class.isAssignableFrom(c))
/*     */     {
/*  79 */       jb.objectBegin();
/*  80 */       for (Map.Entry entry : ((Map)obj).entrySet())
/*     */       {
/*  82 */         Object key = entry.getKey();
/*  83 */         if (key != null)
/*     */         {
/*  85 */           jb.objectItem(key.toString());
/*     */ 
/*  87 */           Object value = entry.getValue();
/*  88 */           if (value == null)
/*  89 */             jb.valueNull();
/*     */           else
/*  91 */             writeValue(value, jb, writeClass); 
/*     */         }
/*     */       }
/*  93 */       jb.objectEnd();
/*     */     }
/*  95 */     else if (Collection.class.isAssignableFrom(c))
/*     */     {
/*  97 */       jb.arrayBegin();
/*  98 */       for (Iterator i$ = ((Collection)obj).iterator(); i$.hasNext(); ) { Object item = i$.next();
/*     */ 
/* 100 */         if (item == null)
/* 101 */           jb.valueNull();
/*     */         else
/* 103 */           writeValue(item, jb, writeClass);
/*     */       }
/* 105 */       jb.arrayEnd();
/*     */     }
/*     */     else
/*     */     {
/* 109 */       jb.objectBegin();
/*     */ 
/* 111 */       Wrapper w = Wrapper.getWrapper(c);
/* 112 */       String[] pns = w.getPropertyNames();
/*     */ 
/* 114 */       for (String pn : pns)
/*     */       {
/* 116 */         if ((!(obj instanceof Throwable)) || ((!"localizedMessage".equals(pn)) && (!"cause".equals(pn)) && (!"stackTrace".equals(pn))))
/*     */         {
/* 123 */           jb.objectItem(pn);
/*     */ 
/* 125 */           Object value = w.getPropertyValue(obj, pn);
/* 126 */           if ((value == null) || (value == obj))
/* 127 */             jb.valueNull();
/*     */           else
/* 129 */             writeValue(value, jb, writeClass); 
/*     */         }
/*     */       }
/* 131 */       if (writeClass) {
/* 132 */         jb.objectItem("class");
/* 133 */         writeValue(obj.getClass().getName(), jb, writeClass);
/*     */       }
/* 135 */       jb.objectEnd();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object readValue(Class<?> c, Object jv)
/*     */     throws IOException
/*     */   {
/* 142 */     if (jv == null) {
/* 143 */       return null;
/*     */     }
/* 145 */     Decoder decoder = (Decoder)GlobalDecoderMap.get(c);
/* 146 */     if (decoder != null) {
/* 147 */       return decoder.decode(jv);
/*     */     }
/* 149 */     if (c.isEnum()) {
/* 150 */       return Enum.valueOf(c, String.valueOf(jv));
/*     */     }
/* 152 */     return jv;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 158 */     Encoder e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 161 */         jb.valueBoolean(((Boolean)obj).booleanValue());
/*     */       }
/*     */     };
/* 164 */     GlobalEncoderMap.put(Boolean.TYPE, e);
/* 165 */     GlobalEncoderMap.put(Boolean.class, e);
/*     */ 
/* 167 */     e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 170 */         jb.valueInt(((Number)obj).intValue());
/*     */       }
/*     */     };
/* 173 */     GlobalEncoderMap.put(Integer.TYPE, e);
/* 174 */     GlobalEncoderMap.put(Integer.class, e);
/* 175 */     GlobalEncoderMap.put(Short.TYPE, e);
/* 176 */     GlobalEncoderMap.put(Short.class, e);
/* 177 */     GlobalEncoderMap.put(Byte.TYPE, e);
/* 178 */     GlobalEncoderMap.put(Byte.class, e);
/* 179 */     GlobalEncoderMap.put(AtomicInteger.class, e);
/*     */ 
/* 181 */     e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 184 */         jb.valueString(Character.toString(((Character)obj).charValue()));
/*     */       }
/*     */     };
/* 187 */     GlobalEncoderMap.put(Character.TYPE, e);
/* 188 */     GlobalEncoderMap.put(Character.class, e);
/*     */ 
/* 190 */     e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 193 */         jb.valueLong(((Number)obj).longValue());
/*     */       }
/*     */     };
/* 196 */     GlobalEncoderMap.put(Long.TYPE, e);
/* 197 */     GlobalEncoderMap.put(Long.class, e);
/* 198 */     GlobalEncoderMap.put(AtomicLong.class, e);
/* 199 */     GlobalEncoderMap.put(BigInteger.class, e);
/*     */ 
/* 201 */     e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 204 */         jb.valueFloat(((Number)obj).floatValue());
/*     */       }
/*     */     };
/* 207 */     GlobalEncoderMap.put(Float.TYPE, e);
/* 208 */     GlobalEncoderMap.put(Float.class, e);
/*     */ 
/* 210 */     e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 213 */         jb.valueDouble(((Number)obj).doubleValue());
/*     */       }
/*     */     };
/* 216 */     GlobalEncoderMap.put(Double.TYPE, e);
/* 217 */     GlobalEncoderMap.put(Double.class, e);
/* 218 */     GlobalEncoderMap.put(BigDecimal.class, e);
/*     */ 
/* 220 */     e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 223 */         jb.valueString(obj.toString());
/*     */       }
/*     */     };
/* 226 */     GlobalEncoderMap.put(String.class, e);
/* 227 */     GlobalEncoderMap.put(StringBuilder.class, e);
/* 228 */     GlobalEncoderMap.put(StringBuffer.class, e);
/*     */ 
/* 230 */     e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 233 */         jb.valueString(Bytes.bytes2base64((byte[])obj));
/*     */       }
/*     */     };
/* 236 */     GlobalEncoderMap.put([B.class, e);
/*     */ 
/* 238 */     e = new Encoder()
/*     */     {
/*     */       public void encode(Object obj, JSONWriter jb) throws IOException {
/* 241 */         jb.valueString(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format((Date)obj));
/*     */       }
/*     */     };
/* 244 */     GlobalEncoderMap.put(Date.class, e);
/*     */ 
/* 247 */     Decoder d = new Decoder() {
/*     */       public Object decode(Object jv) {
/* 249 */         return jv.toString();
/*     */       }
/*     */     };
/* 252 */     GlobalDecoderMap.put(String.class, d);
/*     */ 
/* 254 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 257 */         if ((jv instanceof Boolean)) return Boolean.valueOf(((Boolean)jv).booleanValue());
/* 258 */         return Boolean.valueOf(false);
/*     */       }
/*     */     };
/* 261 */     GlobalDecoderMap.put(Boolean.TYPE, d);
/*     */ 
/* 263 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 266 */         if ((jv instanceof Boolean)) return (Boolean)jv;
/* 267 */         return (Boolean)null;
/*     */       }
/*     */     };
/* 270 */     GlobalDecoderMap.put(Boolean.class, d);
/*     */ 
/* 272 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 275 */         if (((jv instanceof String)) && (((String)jv).length() > 0)) return Character.valueOf(((String)jv).charAt(0));
/* 276 */         return Character.valueOf('\000');
/*     */       }
/*     */     };
/* 279 */     GlobalDecoderMap.put(Character.TYPE, d);
/*     */ 
/* 281 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 284 */         if (((jv instanceof String)) && (((String)jv).length() > 0)) return Character.valueOf(((String)jv).charAt(0));
/* 285 */         return (Character)null;
/*     */       }
/*     */     };
/* 288 */     GlobalDecoderMap.put(Character.class, d);
/*     */ 
/* 290 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 293 */         if ((jv instanceof Number)) return Integer.valueOf(((Number)jv).intValue());
/* 294 */         return Integer.valueOf(0);
/*     */       }
/*     */     };
/* 297 */     GlobalDecoderMap.put(Integer.TYPE, d);
/*     */ 
/* 299 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 302 */         if ((jv instanceof Number)) return Integer.valueOf(((Number)jv).intValue());
/* 303 */         return (Integer)null;
/*     */       }
/*     */     };
/* 306 */     GlobalDecoderMap.put(Integer.class, d);
/*     */ 
/* 308 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 311 */         if ((jv instanceof Number)) return Short.valueOf(((Number)jv).shortValue());
/* 312 */         return Short.valueOf((short)0);
/*     */       }
/*     */     };
/* 315 */     GlobalDecoderMap.put(Short.TYPE, d);
/*     */ 
/* 317 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 320 */         if ((jv instanceof Number)) return Short.valueOf(((Number)jv).shortValue());
/* 321 */         return (Short)null;
/*     */       }
/*     */     };
/* 324 */     GlobalDecoderMap.put(Short.class, d);
/*     */ 
/* 326 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 329 */         if ((jv instanceof Number)) return Long.valueOf(((Number)jv).longValue());
/* 330 */         return Long.valueOf(0L);
/*     */       }
/*     */     };
/* 333 */     GlobalDecoderMap.put(Long.TYPE, d);
/*     */ 
/* 335 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 338 */         if ((jv instanceof Number)) return Long.valueOf(((Number)jv).longValue());
/* 339 */         return (Long)null;
/*     */       }
/*     */     };
/* 342 */     GlobalDecoderMap.put(Long.class, d);
/*     */ 
/* 344 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 347 */         if ((jv instanceof Number)) return Float.valueOf(((Number)jv).floatValue());
/* 348 */         return Float.valueOf(0.0F);
/*     */       }
/*     */     };
/* 351 */     GlobalDecoderMap.put(Float.TYPE, d);
/*     */ 
/* 353 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 356 */         if ((jv instanceof Number)) return new Float(((Number)jv).floatValue());
/* 357 */         return (Float)null;
/*     */       }
/*     */     };
/* 360 */     GlobalDecoderMap.put(Float.class, d);
/*     */ 
/* 362 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 365 */         if ((jv instanceof Number)) return Double.valueOf(((Number)jv).doubleValue());
/* 366 */         return Double.valueOf(0.0D);
/*     */       }
/*     */     };
/* 369 */     GlobalDecoderMap.put(Double.TYPE, d);
/*     */ 
/* 371 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 374 */         if ((jv instanceof Number)) return new Double(((Number)jv).doubleValue());
/* 375 */         return (Double)null;
/*     */       }
/*     */     };
/* 378 */     GlobalDecoderMap.put(Double.class, d);
/*     */ 
/* 380 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 383 */         if ((jv instanceof Number)) return Byte.valueOf(((Number)jv).byteValue());
/* 384 */         return Byte.valueOf((byte)0);
/*     */       }
/*     */     };
/* 387 */     GlobalDecoderMap.put(Byte.TYPE, d);
/*     */ 
/* 389 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) {
/* 392 */         if ((jv instanceof Number)) return Byte.valueOf(((Number)jv).byteValue());
/* 393 */         return (Byte)null;
/*     */       }
/*     */     };
/* 396 */     GlobalDecoderMap.put(Byte.class, d);
/*     */ 
/* 398 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) throws IOException {
/* 401 */         if ((jv instanceof String)) return Bytes.base642bytes((String)jv);
/* 402 */         return (byte[])null;
/*     */       }
/*     */     };
/* 405 */     GlobalDecoderMap.put([B.class, d);
/*     */ 
/* 407 */     d = new Decoder() {
/* 408 */       public Object decode(Object jv) throws IOException { return new StringBuilder(jv.toString()); }
/*     */ 
/*     */     };
/* 410 */     GlobalDecoderMap.put(StringBuilder.class, d);
/*     */ 
/* 412 */     d = new Decoder() {
/* 413 */       public Object decode(Object jv) throws IOException { return new StringBuffer(jv.toString()); }
/*     */ 
/*     */     };
/* 415 */     GlobalDecoderMap.put(StringBuffer.class, d);
/*     */ 
/* 417 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) throws IOException {
/* 420 */         if ((jv instanceof Number)) return BigInteger.valueOf(((Number)jv).longValue());
/* 421 */         return (BigInteger)null;
/*     */       }
/*     */     };
/* 424 */     GlobalDecoderMap.put(BigInteger.class, d);
/*     */ 
/* 426 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) throws IOException {
/* 429 */         if ((jv instanceof Number)) return BigDecimal.valueOf(((Number)jv).doubleValue());
/* 430 */         return (BigDecimal)null;
/*     */       }
/*     */     };
/* 433 */     GlobalDecoderMap.put(BigDecimal.class, d);
/*     */ 
/* 435 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) throws IOException {
/* 438 */         if ((jv instanceof Number)) return new AtomicInteger(((Number)jv).intValue());
/* 439 */         return (AtomicInteger)null;
/*     */       }
/*     */     };
/* 442 */     GlobalDecoderMap.put(AtomicInteger.class, d);
/*     */ 
/* 444 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) throws IOException {
/* 447 */         if ((jv instanceof Number)) return new AtomicLong(((Number)jv).longValue());
/* 448 */         return (AtomicLong)null;
/*     */       }
/*     */     };
/* 451 */     GlobalDecoderMap.put(AtomicLong.class, d);
/*     */ 
/* 453 */     d = new Decoder()
/*     */     {
/*     */       public Object decode(Object jv) throws IOException {
/* 456 */         if ((jv instanceof String)) {
/*     */           try {
/* 458 */             return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse((String)jv);
/*     */           } catch (ParseException e) {
/* 460 */             throw new IllegalArgumentException(e.getMessage(), e);
/*     */           }
/*     */         }
/* 463 */         if ((jv instanceof Number))
/* 464 */           return new Date(((Number)jv).longValue());
/* 465 */         return (Date)null;
/*     */       }
/*     */     };
/* 468 */     GlobalDecoderMap.put(Date.class, d);
/*     */   }
/*     */ 
/*     */   protected static abstract interface Decoder
/*     */   {
/*     */     public abstract Object decode(Object paramObject)
/*     */       throws IOException;
/*     */   }
/*     */ 
/*     */   protected static abstract interface Encoder
/*     */   {
/*     */     public abstract void encode(Object paramObject, JSONWriter paramJSONWriter)
/*     */       throws IOException;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.GenericJSONConverter
 * JD-Core Version:    0.6.2
 */