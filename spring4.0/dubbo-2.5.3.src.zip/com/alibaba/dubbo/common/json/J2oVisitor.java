/*     */ package com.alibaba.dubbo.common.json;
/*     */ 
/*     */ import com.alibaba.dubbo.common.bytecode.Wrapper;
/*     */ import com.alibaba.dubbo.common.utils.Stack;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ class J2oVisitor
/*     */   implements JSONVisitor
/*     */ {
/*  42 */   public static final boolean[] EMPTY_BOOL_ARRAY = new boolean[0];
/*     */ 
/*  44 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */ 
/*  46 */   public static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*     */ 
/*  48 */   public static final short[] EMPTY_SHORT_ARRAY = new short[0];
/*     */ 
/*  50 */   public static final int[] EMPTY_INT_ARRAY = new int[0];
/*     */ 
/*  52 */   public static final long[] EMPTY_LONG_ARRAY = new long[0];
/*     */ 
/*  54 */   public static final float[] EMPTY_FLOAT_ARRAY = new float[0];
/*     */ 
/*  56 */   public static final double[] EMPTY_DOUBLE_ARRAY = new double[0];
/*     */ 
/*  58 */   public static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   private Class<?>[] mTypes;
/*  62 */   private Class<?> mType = [Ljava.lang.Object.class;
/*     */   private Object mValue;
/*     */   private Wrapper mWrapper;
/*     */   private JSONConverter mConverter;
/*  70 */   private Stack<Object> mStack = new Stack();
/*     */ 
/*     */   J2oVisitor(Class<?> type, JSONConverter jc)
/*     */   {
/*  74 */     this.mType = type;
/*  75 */     this.mConverter = jc;
/*     */   }
/*     */ 
/*     */   J2oVisitor(Class<?>[] types, JSONConverter jc)
/*     */   {
/*  80 */     this.mTypes = types;
/*  81 */     this.mConverter = jc;
/*     */   }
/*     */ 
/*     */   public void begin()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Object end(Object obj, boolean isValue) throws ParseException {
/*  89 */     this.mStack.clear();
/*     */     try {
/*  91 */       return this.mConverter.readValue(this.mType, obj);
/*     */     } catch (IOException e) {
/*  93 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void objectBegin() throws ParseException
/*     */   {
/*  99 */     this.mStack.push(this.mValue);
/* 100 */     this.mStack.push(this.mType);
/* 101 */     this.mStack.push(this.mWrapper);
/*     */ 
/* 103 */     if ((this.mType == Object.class) || (Map.class.isAssignableFrom(this.mType)))
/*     */     {
/* 105 */       if ((!this.mType.isInterface()) && (this.mType != Object.class))
/*     */         try {
/* 107 */           this.mValue = this.mType.newInstance();
/*     */         } catch (Exception e) {
/* 109 */           throw new IllegalStateException(e.getMessage(), e);
/*     */         }
/* 111 */       else if (this.mType == ConcurrentMap.class)
/* 112 */         this.mValue = new ConcurrentHashMap();
/*     */       else {
/* 114 */         this.mValue = new HashMap();
/*     */       }
/* 116 */       this.mWrapper = null;
/*     */     } else {
/*     */       try {
/* 119 */         this.mValue = this.mType.newInstance();
/* 120 */         this.mWrapper = Wrapper.getWrapper(this.mType);
/*     */       } catch (IllegalAccessException e) {
/* 122 */         throw new ParseException(StringUtils.toString(e));
/*     */       } catch (InstantiationException e) {
/* 124 */         throw new ParseException(StringUtils.toString(e));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object objectEnd(int count)
/*     */   {
/* 131 */     Object ret = this.mValue;
/* 132 */     this.mWrapper = ((Wrapper)this.mStack.pop());
/* 133 */     this.mType = ((Class)this.mStack.pop());
/* 134 */     this.mValue = this.mStack.pop();
/* 135 */     return ret;
/*     */   }
/*     */ 
/*     */   public void objectItem(String name)
/*     */   {
/* 140 */     this.mStack.push(name);
/* 141 */     this.mType = (this.mWrapper == null ? Object.class : this.mWrapper.getPropertyType(name));
/*     */   }
/*     */ 
/*     */   public void objectItemValue(Object obj, boolean isValue)
/*     */     throws ParseException
/*     */   {
/* 147 */     String name = (String)this.mStack.pop();
/* 148 */     if (this.mWrapper == null)
/*     */     {
/* 150 */       ((Map)this.mValue).put(name, obj);
/*     */     }
/* 154 */     else if (this.mType != null)
/*     */     {
/* 156 */       if ((isValue) && (obj != null))
/*     */       {
/*     */         try
/*     */         {
/* 160 */           obj = this.mConverter.readValue(this.mType, obj);
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 164 */           throw new ParseException(StringUtils.toString(e));
/*     */         }
/*     */       }
/* 167 */       if (((this.mValue instanceof Throwable)) && ("message".equals(name)))
/*     */         try {
/* 169 */           Field field = Throwable.class.getDeclaredField("detailMessage");
/* 170 */           if (!field.isAccessible()) {
/* 171 */             field.setAccessible(true);
/*     */           }
/* 173 */           field.set(this.mValue, obj);
/*     */         } catch (NoSuchFieldException e) {
/* 175 */           throw new ParseException(StringUtils.toString(e));
/*     */         } catch (IllegalAccessException e) {
/* 177 */           throw new ParseException(StringUtils.toString(e));
/*     */         }
/* 179 */       else if (!"class".equals(name))
/* 180 */         this.mWrapper.setPropertyValue(this.mValue, name, obj);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void arrayBegin()
/*     */     throws ParseException
/*     */   {
/* 188 */     this.mStack.push(this.mType);
/*     */ 
/* 190 */     if (this.mType.isArray())
/* 191 */       this.mType = this.mType.getComponentType();
/* 192 */     else if ((this.mType == Object.class) || (Collection.class.isAssignableFrom(this.mType)))
/* 193 */       this.mType = Object.class;
/*     */     else
/* 195 */       throw new ParseException("Convert error, can not load json array data into class [" + this.mType.getName() + "].");
/*     */   }
/*     */ 
/*     */   public Object arrayEnd(int count)
/*     */     throws ParseException
/*     */   {
/* 202 */     this.mType = ((Class)this.mStack.get(-1 - count));
/*     */     Object ret;
/*     */     Object ret;
/* 204 */     if (this.mType.isArray())
/*     */     {
/* 206 */       ret = toArray(this.mType.getComponentType(), this.mStack, count);
/*     */     }
/*     */     else
/*     */     {
/*     */       Collection items;
/* 211 */       if ((this.mType == Object.class) || (Collection.class.isAssignableFrom(this.mType)))
/*     */       {
/*     */         Collection items;
/* 212 */         if ((!this.mType.isInterface()) && (this.mType != Object.class)) {
/*     */           try {
/* 214 */             items = (Collection)this.mType.newInstance();
/*     */           } catch (Exception e) {
/* 216 */             throw new IllegalStateException(e.getMessage(), e);
/*     */           }
/* 218 */         } else if (this.mType.isAssignableFrom(ArrayList.class)) {
/* 219 */           items = new ArrayList(count);
/*     */         }
/*     */         else
/*     */         {
/*     */           Collection items;
/* 220 */           if (this.mType.isAssignableFrom(HashSet.class)) {
/* 221 */             items = new HashSet(count);
/*     */           }
/*     */           else
/*     */           {
/*     */             Collection items;
/* 222 */             if (this.mType.isAssignableFrom(LinkedList.class))
/* 223 */               items = new LinkedList();
/*     */             else
/* 225 */               items = new ArrayList(count); 
/*     */           }
/*     */         }
/*     */       } else { throw new ParseException("Convert error, can not load json array data into class [" + this.mType.getName() + "]."); }
/*     */ 
/*     */       Collection items;
/* 230 */       for (int i = 0; i < count; i++)
/* 231 */         items.add(this.mStack.remove(i - count));
/* 232 */       ret = items;
/*     */     }
/* 234 */     this.mStack.pop();
/* 235 */     return ret;
/*     */   }
/*     */ 
/*     */   public void arrayItem(int index) throws ParseException
/*     */   {
/* 240 */     if ((this.mTypes != null) && (this.mStack.size() == index + 1))
/*     */     {
/* 242 */       if (index < this.mTypes.length)
/* 243 */         this.mType = this.mTypes[index];
/*     */       else
/* 245 */         throw new ParseException("Can not load json array data into [" + name(this.mTypes) + "].");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void arrayItemValue(int index, Object obj, boolean isValue) throws ParseException
/*     */   {
/* 251 */     if ((isValue) && (obj != null))
/*     */     {
/*     */       try
/*     */       {
/* 255 */         obj = this.mConverter.readValue(this.mType, obj);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 259 */         throw new ParseException(e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/* 263 */     this.mStack.push(obj);
/*     */   }
/*     */ 
/*     */   private static Object toArray(Class<?> c, Stack<Object> list, int len) throws ParseException
/*     */   {
/* 268 */     if (c == String.class)
/*     */     {
/* 270 */       if (len == 0)
/*     */       {
/* 272 */         return EMPTY_STRING_ARRAY;
/*     */       }
/*     */ 
/* 277 */       String[] ss = new String[len];
/* 278 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 280 */         Object o = list.pop();
/* 281 */         ss[i] = (o == null ? null : o.toString());
/*     */       }
/* 283 */       return ss;
/*     */     }
/*     */ 
/* 286 */     if (c == Boolean.TYPE)
/*     */     {
/* 288 */       if (len == 0) return EMPTY_BOOL_ARRAY;
/*     */ 
/* 290 */       boolean[] ret = new boolean[len];
/* 291 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 293 */         Object o = list.pop();
/* 294 */         if ((o instanceof Boolean))
/* 295 */           ret[i] = ((Boolean)o).booleanValue();
/*     */       }
/* 297 */       return ret;
/*     */     }
/* 299 */     if (c == Integer.TYPE)
/*     */     {
/* 301 */       if (len == 0) return EMPTY_INT_ARRAY;
/*     */ 
/* 303 */       int[] ret = new int[len];
/* 304 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 306 */         Object o = list.pop();
/* 307 */         if ((o instanceof Number))
/* 308 */           ret[i] = ((Number)o).intValue();
/*     */       }
/* 310 */       return ret;
/*     */     }
/* 312 */     if (c == Long.TYPE)
/*     */     {
/* 314 */       if (len == 0) return EMPTY_LONG_ARRAY;
/*     */ 
/* 316 */       long[] ret = new long[len];
/* 317 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 319 */         Object o = list.pop();
/* 320 */         if ((o instanceof Number))
/* 321 */           ret[i] = ((Number)o).longValue();
/*     */       }
/* 323 */       return ret;
/*     */     }
/* 325 */     if (c == Float.TYPE)
/*     */     {
/* 327 */       if (len == 0) return EMPTY_FLOAT_ARRAY;
/*     */ 
/* 329 */       float[] ret = new float[len];
/* 330 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 332 */         Object o = list.pop();
/* 333 */         if ((o instanceof Number))
/* 334 */           ret[i] = ((Number)o).floatValue();
/*     */       }
/* 336 */       return ret;
/*     */     }
/* 338 */     if (c == Double.TYPE)
/*     */     {
/* 340 */       if (len == 0) return EMPTY_DOUBLE_ARRAY;
/*     */ 
/* 342 */       double[] ret = new double[len];
/* 343 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 345 */         Object o = list.pop();
/* 346 */         if ((o instanceof Number))
/* 347 */           ret[i] = ((Number)o).doubleValue();
/*     */       }
/* 349 */       return ret;
/*     */     }
/* 351 */     if (c == Byte.TYPE)
/*     */     {
/* 353 */       if (len == 0) return EMPTY_BYTE_ARRAY;
/*     */ 
/* 355 */       byte[] ret = new byte[len];
/* 356 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 358 */         Object o = list.pop();
/* 359 */         if ((o instanceof Number))
/* 360 */           ret[i] = ((Number)o).byteValue();
/*     */       }
/* 362 */       return ret;
/*     */     }
/* 364 */     if (c == Character.TYPE)
/*     */     {
/* 366 */       if (len == 0) return EMPTY_CHAR_ARRAY;
/*     */ 
/* 368 */       char[] ret = new char[len];
/* 369 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 371 */         Object o = list.pop();
/* 372 */         if ((o instanceof Character))
/* 373 */           ret[i] = ((Character)o).charValue();
/*     */       }
/* 375 */       return ret;
/*     */     }
/* 377 */     if (c == Short.TYPE)
/*     */     {
/* 379 */       if (len == 0) return EMPTY_SHORT_ARRAY;
/*     */ 
/* 381 */       short[] ret = new short[len];
/* 382 */       for (int i = len - 1; i >= 0; i--)
/*     */       {
/* 384 */         Object o = list.pop();
/* 385 */         if ((o instanceof Number))
/* 386 */           ret[i] = ((Number)o).shortValue();
/*     */       }
/* 388 */       return ret;
/*     */     }
/*     */ 
/* 391 */     Object ret = Array.newInstance(c, len);
/* 392 */     for (int i = len - 1; i >= 0; i--)
/* 393 */       Array.set(ret, i, list.pop());
/* 394 */     return ret;
/*     */   }
/*     */ 
/*     */   private static String name(Class<?>[] types)
/*     */   {
/* 399 */     StringBuilder sb = new StringBuilder();
/* 400 */     for (int i = 0; i < types.length; i++)
/*     */     {
/* 402 */       if (i > 0)
/* 403 */         sb.append(", ");
/* 404 */       sb.append(types[i].getName());
/*     */     }
/* 406 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.J2oVisitor
 * JD-Core Version:    0.6.2
 */