/*     */ package com.alibaba.dubbo.common.json;
/*     */ 
/*     */ import com.alibaba.dubbo.common.bytecode.Wrapper;
/*     */ import com.alibaba.dubbo.common.utils.Stack;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class JSON
/*     */ {
/*     */   public static final char LBRACE = '{';
/*     */   public static final char RBRACE = '}';
/*     */   public static final char LSQUARE = '[';
/*     */   public static final char RSQUARE = ']';
/*     */   public static final char COMMA = ',';
/*     */   public static final char COLON = ':';
/*     */   public static final char QUOTE = '"';
/*     */   public static final String NULL = "null";
/*  44 */   static final JSONConverter DEFAULT_CONVERTER = new GenericJSONConverter();
/*     */   public static final byte END = 0;
/*     */   public static final byte START = 1;
/*     */   public static final byte OBJECT_ITEM = 2;
/*     */   public static final byte OBJECT_VALUE = 3;
/*     */   public static final byte ARRAY_ITEM = 4;
/*     */ 
/*     */   public static String json(Object obj)
/*     */     throws IOException
/*     */   {
/*  67 */     if (obj == null) return "null";
/*  68 */     StringWriter sw = new StringWriter();
/*     */     try
/*     */     {
/*  71 */       json(obj, sw);
/*  72 */       return sw.getBuffer().toString();
/*     */     } finally {
/*  74 */       sw.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void json(Object obj, Writer writer)
/*     */     throws IOException
/*     */   {
/*  86 */     json(obj, writer, false);
/*     */   }
/*     */ 
/*     */   public static void json(Object obj, Writer writer, boolean writeClass) throws IOException
/*     */   {
/*  91 */     if (obj == null)
/*  92 */       writer.write("null");
/*     */     else
/*  94 */       json(obj, new JSONWriter(writer), writeClass);
/*     */   }
/*     */ 
/*     */   public static String json(Object obj, String[] properties)
/*     */     throws IOException
/*     */   {
/* 107 */     if (obj == null) return "null";
/* 108 */     StringWriter sw = new StringWriter();
/*     */     try
/*     */     {
/* 111 */       json(obj, properties, sw);
/* 112 */       return sw.getBuffer().toString();
/*     */     } finally {
/* 114 */       sw.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void json(Object obj, String[] properties, Writer writer) throws IOException {
/* 119 */     json(obj, properties, writer, false);
/*     */   }
/*     */ 
/*     */   public static void json(Object obj, String[] properties, Writer writer, boolean writeClass)
/*     */     throws IOException
/*     */   {
/* 132 */     if (obj == null)
/* 133 */       writer.write("null");
/*     */     else
/* 135 */       json(obj, properties, new JSONWriter(writer), writeClass);
/*     */   }
/*     */ 
/*     */   private static void json(Object obj, JSONWriter jb, boolean writeClass) throws IOException
/*     */   {
/* 140 */     if (obj == null)
/* 141 */       jb.valueNull();
/*     */     else
/* 143 */       DEFAULT_CONVERTER.writeValue(obj, jb, writeClass);
/*     */   }
/*     */ 
/*     */   private static void json(Object obj, String[] properties, JSONWriter jb, boolean writeClass) throws IOException
/*     */   {
/* 148 */     if (obj == null)
/*     */     {
/* 150 */       jb.valueNull();
/*     */     }
/*     */     else
/*     */     {
/* 154 */       Wrapper wrapper = Wrapper.getWrapper(obj.getClass());
/*     */ 
/* 157 */       jb.objectBegin();
/* 158 */       for (String prop : properties)
/*     */       {
/* 160 */         jb.objectItem(prop);
/* 161 */         Object value = wrapper.getPropertyValue(obj, prop);
/* 162 */         if (value == null)
/* 163 */           jb.valueNull();
/*     */         else
/* 165 */           DEFAULT_CONVERTER.writeValue(value, jb, writeClass);
/*     */       }
/* 167 */       jb.objectEnd();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object parse(String json)
/*     */     throws ParseException
/*     */   {
/* 180 */     StringReader reader = new StringReader(json);
/*     */     try { return parse(reader); } catch (IOException e) {
/* 182 */       throw new ParseException(e.getMessage()); } finally {
/* 183 */       reader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object parse(Reader reader)
/*     */     throws IOException, ParseException
/*     */   {
/* 196 */     return parse(reader, 0);
/*     */   }
/*     */ 
/*     */   public static <T> T parse(String json, Class<T> type)
/*     */     throws ParseException
/*     */   {
/* 209 */     StringReader reader = new StringReader(json);
/*     */     try { return parse(reader, type); } catch (IOException e) {
/* 211 */       throw new ParseException(e.getMessage()); } finally {
/* 212 */       reader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <T> T parse(Reader reader, Class<T> type)
/*     */     throws IOException, ParseException
/*     */   {
/* 227 */     return parse(reader, new J2oVisitor(type, DEFAULT_CONVERTER), 0);
/*     */   }
/*     */ 
/*     */   public static Object[] parse(String json, Class<?>[] types)
/*     */     throws ParseException
/*     */   {
/* 240 */     StringReader reader = new StringReader(json);
/*     */     try { return (Object[])parse(reader, types); } catch (IOException e) {
/* 242 */       throw new ParseException(e.getMessage()); } finally {
/* 243 */       reader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object[] parse(Reader reader, Class<?>[] types)
/*     */     throws IOException, ParseException
/*     */   {
/* 257 */     return (Object[])parse(reader, new J2oVisitor(types, DEFAULT_CONVERTER), 3);
/*     */   }
/*     */ 
/*     */   public static Object parse(String json, JSONVisitor handler)
/*     */     throws ParseException
/*     */   {
/* 270 */     StringReader reader = new StringReader(json);
/*     */     try { return parse(reader, handler); } catch (IOException e) {
/* 272 */       throw new ParseException(e.getMessage()); } finally {
/* 273 */       reader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object parse(Reader reader, JSONVisitor handler)
/*     */     throws IOException, ParseException
/*     */   {
/* 287 */     return parse(reader, handler, 0);
/*     */   }
/*     */ 
/*     */   private static Object parse(Reader reader, int expect) throws IOException, ParseException
/*     */   {
/* 292 */     JSONReader jr = new JSONReader(reader);
/* 293 */     JSONToken token = jr.nextToken(expect);
/*     */ 
/* 295 */     byte state = 1;
/* 296 */     Object value = null;
/* 297 */     Stack stack = new Stack();
/*     */     do
/*     */     {
/*     */       Object tmp;
/* 301 */       switch (state)
/*     */       {
/*     */       case 0:
/* 304 */         throw new ParseException("JSON source format error.");
/*     */       case 1:
/* 307 */         switch (token.type) { case 16:
/*     */         case 17:
/*     */         case 18:
/*     */         case 19:
/*     */         case 20:
/* 311 */           state = 0;
/* 312 */           value = token.value;
/* 313 */           break;
/*     */         case 3:
/* 317 */           state = 4;
/* 318 */           value = new JSONArray();
/* 319 */           break;
/*     */         case 2:
/* 323 */           state = 2;
/* 324 */           value = new JSONObject();
/* 325 */           break;
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 14:
/*     */         case 15:
/*     */         default:
/* 328 */           throw new ParseException("Unexcepted token expect [ VALUE or '[' or '{' ] get '" + JSONToken.token2string(token.type) + "'");
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 4:
/* 334 */         switch (token.type)
/*     */         {
/*     */         case 6:
/* 337 */           break;
/*     */         case 16:
/*     */         case 17:
/*     */         case 18:
/*     */         case 19:
/*     */         case 20:
/* 340 */           ((JSONArray)value).add(token.value);
/* 341 */           break;
/*     */         case 5:
/* 345 */           if (stack.isEmpty())
/*     */           {
/* 347 */             state = 0;
/*     */           }
/*     */           else
/*     */           {
/* 351 */             Entry entry = (Entry)stack.pop();
/* 352 */             state = entry.state;
/* 353 */             value = entry.value;
/*     */           }
/* 355 */           break;
/*     */         case 3:
/* 359 */           tmp = new JSONArray();
/* 360 */           ((JSONArray)value).add(tmp);
/* 361 */           stack.push(new Entry(state, value));
/*     */ 
/* 363 */           state = 4;
/* 364 */           value = tmp;
/* 365 */           break;
/*     */         case 2:
/* 369 */           tmp = new JSONObject();
/* 370 */           ((JSONArray)value).add(tmp);
/* 371 */           stack.push(new Entry(state, value));
/*     */ 
/* 373 */           state = 2;
/* 374 */           value = tmp;
/* 375 */           break;
/*     */         case 4:
/*     */         case 7:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 14:
/*     */         case 15:
/*     */         default:
/* 378 */           throw new ParseException("Unexcepted token expect [ VALUE or ',' or ']' or '[' or '{' ] get '" + JSONToken.token2string(token.type) + "'");
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 2:
/* 384 */         switch (token.type)
/*     */         {
/*     */         case 6:
/* 387 */           break;
/*     */         case 1:
/* 390 */           stack.push(new Entry((byte)2, (String)token.value));
/* 391 */           state = 3;
/* 392 */           break;
/*     */         case 16:
/* 396 */           stack.push(new Entry((byte)2, "null"));
/* 397 */           state = 3;
/* 398 */           break;
/*     */         case 17:
/*     */         case 18:
/*     */         case 19:
/*     */         case 20:
/* 402 */           stack.push(new Entry((byte)2, token.value.toString()));
/* 403 */           state = 3;
/* 404 */           break;
/*     */         case 4:
/* 408 */           if (stack.isEmpty())
/*     */           {
/* 410 */             state = 0;
/*     */           }
/*     */           else
/*     */           {
/* 414 */             Entry entry = (Entry)stack.pop();
/* 415 */             state = entry.state;
/* 416 */             value = entry.value;
/*     */           }
/* 418 */           break;
/*     */         case 2:
/*     */         case 3:
/*     */         case 5:
/*     */         case 7:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 14:
/*     */         case 15:
/*     */         default:
/* 421 */           throw new ParseException("Unexcepted token expect [ IDENT or VALUE or ',' or '}' ] get '" + JSONToken.token2string(token.type) + "'");
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 3:
/* 427 */         switch (token.type)
/*     */         {
/*     */         case 7:
/* 430 */           break;
/*     */         case 16:
/*     */         case 17:
/*     */         case 18:
/*     */         case 19:
/*     */         case 20:
/* 433 */           ((JSONObject)value).put((String)((Entry)stack.pop()).value, token.value);
/* 434 */           state = 2;
/* 435 */           break;
/*     */         case 3:
/* 439 */           tmp = new JSONArray();
/* 440 */           ((JSONObject)value).put((String)((Entry)stack.pop()).value, tmp);
/* 441 */           stack.push(new Entry((byte)2, value));
/*     */ 
/* 443 */           state = 4;
/* 444 */           value = tmp;
/* 445 */           break;
/*     */         case 2:
/* 449 */           tmp = new JSONObject();
/* 450 */           ((JSONObject)value).put((String)((Entry)stack.pop()).value, tmp);
/* 451 */           stack.push(new Entry((byte)2, value));
/*     */ 
/* 453 */           state = 2;
/* 454 */           value = tmp;
/* 455 */           break;
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 14:
/*     */         case 15:
/*     */         default:
/* 458 */           throw new ParseException("Unexcepted token expect [ VALUE or '[' or '{' ] get '" + JSONToken.token2string(token.type) + "'");
/*     */         }
/*     */ 
/*     */         break;
/*     */       default:
/* 463 */         throw new ParseException("Unexcepted state.");
/*     */       }
/*     */     }
/* 466 */     while ((token = jr.nextToken()) != null);
/* 467 */     stack.clear();
/* 468 */     return value;
/*     */   }
/*     */ 
/*     */   private static Object parse(Reader reader, JSONVisitor handler, int expect) throws IOException, ParseException
/*     */   {
/* 473 */     JSONReader jr = new JSONReader(reader);
/* 474 */     JSONToken token = jr.nextToken(expect);
/*     */ 
/* 476 */     Object value = null;
/* 477 */     int state = 1; int index = 0;
/* 478 */     Stack states = new Stack();
/* 479 */     boolean pv = false;
/*     */ 
/* 481 */     handler.begin();
/*     */     do
/*     */     {
/* 484 */       switch (state)
/*     */       {
/*     */       case 0:
/* 487 */         throw new ParseException("JSON source format error.");
/*     */       case 1:
/* 490 */         switch (token.type)
/*     */         {
/*     */         case 16:
/* 494 */           value = token.value;
/* 495 */           state = 0;
/* 496 */           pv = true;
/* 497 */           break;
/*     */         case 17:
/* 501 */           value = token.value;
/* 502 */           state = 0;
/* 503 */           pv = true;
/* 504 */           break;
/*     */         case 18:
/* 508 */           value = token.value;
/* 509 */           state = 0;
/* 510 */           pv = true;
/* 511 */           break;
/*     */         case 19:
/* 515 */           value = token.value;
/* 516 */           state = 0;
/* 517 */           pv = true;
/* 518 */           break;
/*     */         case 20:
/* 522 */           value = token.value;
/* 523 */           state = 0;
/* 524 */           pv = true;
/* 525 */           break;
/*     */         case 3:
/* 529 */           handler.arrayBegin();
/* 530 */           state = 4;
/* 531 */           break;
/*     */         case 2:
/* 535 */           handler.objectBegin();
/* 536 */           state = 2;
/* 537 */           break;
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 14:
/*     */         case 15:
/*     */         default:
/* 540 */           throw new ParseException("Unexcepted token expect [ VALUE or '[' or '{' ] get '" + JSONToken.token2string(token.type) + "'");
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 4:
/* 546 */         switch (token.type)
/*     */         {
/*     */         case 6:
/* 549 */           break;
/*     */         case 16:
/* 552 */           handler.arrayItem(index++);
/* 553 */           handler.arrayItemValue(index, token.value, true);
/* 554 */           break;
/*     */         case 17:
/* 558 */           handler.arrayItem(index++);
/* 559 */           handler.arrayItemValue(index, token.value, true);
/* 560 */           break;
/*     */         case 18:
/* 564 */           handler.arrayItem(index++);
/* 565 */           handler.arrayItemValue(index, token.value, true);
/* 566 */           break;
/*     */         case 19:
/* 570 */           handler.arrayItem(index++);
/* 571 */           handler.arrayItemValue(index, token.value, true);
/* 572 */           break;
/*     */         case 20:
/* 576 */           handler.arrayItem(index++);
/* 577 */           handler.arrayItemValue(index, token.value, true);
/* 578 */           break;
/*     */         case 3:
/* 582 */           handler.arrayItem(index++);
/* 583 */           states.push(new int[] { state, index });
/*     */ 
/* 585 */           index = 0;
/* 586 */           state = 4;
/* 587 */           handler.arrayBegin();
/* 588 */           break;
/*     */         case 2:
/* 592 */           handler.arrayItem(index++);
/* 593 */           states.push(new int[] { state, index });
/*     */ 
/* 595 */           index = 0;
/* 596 */           state = 2;
/* 597 */           handler.objectBegin();
/* 598 */           break;
/*     */         case 5:
/* 602 */           if (states.isEmpty())
/*     */           {
/* 604 */             value = handler.arrayEnd(index);
/* 605 */             state = 0;
/*     */           }
/*     */           else
/*     */           {
/* 609 */             value = handler.arrayEnd(index);
/* 610 */             int[] tmp = (int[])states.pop();
/* 611 */             state = tmp[0];
/* 612 */             index = tmp[1];
/*     */ 
/* 614 */             switch (state)
/*     */             {
/*     */             case 4:
/* 618 */               handler.arrayItemValue(index, value, false);
/* 619 */               break;
/*     */             case 2:
/* 623 */               handler.objectItemValue(value, false);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 628 */           break;
/*     */         case 4:
/*     */         case 7:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 14:
/*     */         case 15:
/*     */         default:
/* 631 */           throw new ParseException("Unexcepted token expect [ VALUE or ',' or ']' or '[' or '{' ] get '" + JSONToken.token2string(token.type) + "'");
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 2:
/* 637 */         switch (token.type)
/*     */         {
/*     */         case 6:
/* 640 */           break;
/*     */         case 1:
/* 643 */           handler.objectItem((String)token.value);
/* 644 */           state = 3;
/* 645 */           break;
/*     */         case 16:
/* 649 */           handler.objectItem("null");
/* 650 */           state = 3;
/* 651 */           break;
/*     */         case 17:
/*     */         case 18:
/*     */         case 19:
/*     */         case 20:
/* 655 */           handler.objectItem(token.value.toString());
/* 656 */           state = 3;
/* 657 */           break;
/*     */         case 4:
/* 661 */           if (states.isEmpty())
/*     */           {
/* 663 */             value = handler.objectEnd(index);
/* 664 */             state = 0;
/*     */           }
/*     */           else
/*     */           {
/* 668 */             value = handler.objectEnd(index);
/* 669 */             int[] tmp = (int[])states.pop();
/* 670 */             state = tmp[0];
/* 671 */             index = tmp[1];
/*     */ 
/* 673 */             switch (state)
/*     */             {
/*     */             case 4:
/* 677 */               handler.arrayItemValue(index, value, false);
/* 678 */               break;
/*     */             case 2:
/* 682 */               handler.objectItemValue(value, false);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 687 */           break;
/*     */         case 2:
/*     */         case 3:
/*     */         case 5:
/*     */         case 7:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 14:
/*     */         case 15:
/*     */         default:
/* 690 */           throw new ParseException("Unexcepted token expect [ IDENT or VALUE or ',' or '}' ] get '" + JSONToken.token2string(token.type) + "'");
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 3:
/* 696 */         switch (token.type)
/*     */         {
/*     */         case 7:
/* 699 */           break;
/*     */         case 16:
/* 702 */           handler.objectItemValue(token.value, true);
/* 703 */           state = 2;
/* 704 */           break;
/*     */         case 17:
/* 708 */           handler.objectItemValue(token.value, true);
/* 709 */           state = 2;
/* 710 */           break;
/*     */         case 18:
/* 714 */           handler.objectItemValue(token.value, true);
/* 715 */           state = 2;
/* 716 */           break;
/*     */         case 19:
/* 720 */           handler.objectItemValue(token.value, true);
/* 721 */           state = 2;
/* 722 */           break;
/*     */         case 20:
/* 726 */           handler.objectItemValue(token.value, true);
/* 727 */           state = 2;
/* 728 */           break;
/*     */         case 3:
/* 732 */           states.push(new int[] { 2, index });
/*     */ 
/* 734 */           index = 0;
/* 735 */           state = 4;
/* 736 */           handler.arrayBegin();
/* 737 */           break;
/*     */         case 2:
/* 741 */           states.push(new int[] { 2, index });
/*     */ 
/* 743 */           index = 0;
/* 744 */           state = 2;
/* 745 */           handler.objectBegin();
/* 746 */           break;
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/*     */         case 13:
/*     */         case 14:
/*     */         case 15:
/*     */         default:
/* 749 */           throw new ParseException("Unexcepted token expect [ VALUE or '[' or '{' ] get '" + JSONToken.token2string(token.type) + "'");
/*     */         }
/*     */ 
/*     */         break;
/*     */       default:
/* 754 */         throw new ParseException("Unexcepted state.");
/*     */       }
/*     */     }
/* 757 */     while ((token = jr.nextToken()) != null);
/* 758 */     states.clear();
/* 759 */     return handler.end(value, pv);
/*     */   }
/*     */ 
/*     */   private static class Entry
/*     */   {
/*     */     byte state;
/*     */     Object value;
/*     */ 
/*     */     Entry(byte s, Object v)
/*     */     {
/*  53 */       this.state = s; this.value = v;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSON
 * JD-Core Version:    0.6.2
 */