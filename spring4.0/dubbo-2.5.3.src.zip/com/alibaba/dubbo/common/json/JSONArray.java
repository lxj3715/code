/*     */ package com.alibaba.dubbo.common.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class JSONArray
/*     */   implements JSONNode
/*     */ {
/*  31 */   private List<Object> mArray = new ArrayList();
/*     */ 
/*     */   public Object get(int index)
/*     */   {
/*  41 */     return this.mArray.get(index);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(int index, boolean def)
/*     */   {
/*  53 */     Object tmp = this.mArray.get(index);
/*  54 */     return (tmp != null) && ((tmp instanceof Boolean)) ? ((Boolean)tmp).booleanValue() : def;
/*     */   }
/*     */ 
/*     */   public int getInt(int index, int def)
/*     */   {
/*  66 */     Object tmp = this.mArray.get(index);
/*  67 */     return (tmp != null) && ((tmp instanceof Number)) ? ((Number)tmp).intValue() : def;
/*     */   }
/*     */ 
/*     */   public long getLong(int index, long def)
/*     */   {
/*  79 */     Object tmp = this.mArray.get(index);
/*  80 */     return (tmp != null) && ((tmp instanceof Number)) ? ((Number)tmp).longValue() : def;
/*     */   }
/*     */ 
/*     */   public float getFloat(int index, float def)
/*     */   {
/*  92 */     Object tmp = this.mArray.get(index);
/*  93 */     return (tmp != null) && ((tmp instanceof Number)) ? ((Number)tmp).floatValue() : def;
/*     */   }
/*     */ 
/*     */   public double getDouble(int index, double def)
/*     */   {
/* 105 */     Object tmp = this.mArray.get(index);
/* 106 */     return (tmp != null) && ((tmp instanceof Number)) ? ((Number)tmp).doubleValue() : def;
/*     */   }
/*     */ 
/*     */   public String getString(int index)
/*     */   {
/* 117 */     Object tmp = this.mArray.get(index);
/* 118 */     return tmp == null ? null : tmp.toString();
/*     */   }
/*     */ 
/*     */   public JSONArray getArray(int index)
/*     */   {
/* 129 */     Object tmp = this.mArray.get(index);
/* 130 */     return (tmp instanceof JSONArray) ? (JSONArray)tmp : tmp == null ? null : null;
/*     */   }
/*     */ 
/*     */   public JSONObject getObject(int index)
/*     */   {
/* 141 */     Object tmp = this.mArray.get(index);
/* 142 */     return (tmp instanceof JSONObject) ? (JSONObject)tmp : tmp == null ? null : null;
/*     */   }
/*     */ 
/*     */   public int length()
/*     */   {
/* 152 */     return this.mArray.size();
/*     */   }
/*     */ 
/*     */   public void add(Object ele)
/*     */   {
/* 160 */     this.mArray.add(ele);
/*     */   }
/*     */ 
/*     */   public void addAll(Object[] eles)
/*     */   {
/* 168 */     for (Object ele : eles)
/* 169 */       this.mArray.add(ele);
/*     */   }
/*     */ 
/*     */   public void addAll(Collection<?> c)
/*     */   {
/* 177 */     this.mArray.addAll(c);
/*     */   }
/*     */ 
/*     */   public void writeJSON(JSONConverter jc, JSONWriter jb, boolean writeClass)
/*     */     throws IOException
/*     */   {
/* 188 */     jb.arrayBegin();
/* 189 */     for (Iterator i$ = this.mArray.iterator(); i$.hasNext(); ) { Object item = i$.next();
/*     */ 
/* 191 */       if (item == null)
/* 192 */         jb.valueNull();
/*     */       else
/* 194 */         jc.writeValue(item, jb, writeClass);
/*     */     }
/* 196 */     jb.arrayEnd();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSONArray
 * JD-Core Version:    0.6.2
 */