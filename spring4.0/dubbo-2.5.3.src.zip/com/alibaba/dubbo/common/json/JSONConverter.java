package com.alibaba.dubbo.common.json;

import java.io.IOException;

public abstract interface JSONConverter
{
  public abstract void writeValue(Object paramObject, JSONWriter paramJSONWriter, boolean paramBoolean)
    throws IOException;

  public abstract Object readValue(Class<?> paramClass, Object paramObject)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSONConverter
 * JD-Core Version:    0.6.2
 */