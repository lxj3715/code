package com.alibaba.dubbo.common.json;

import java.io.IOException;

abstract interface JSONNode
{
  public abstract void writeJSON(JSONConverter paramJSONConverter, JSONWriter paramJSONWriter, boolean paramBoolean)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSONNode
 * JD-Core Version:    0.6.2
 */