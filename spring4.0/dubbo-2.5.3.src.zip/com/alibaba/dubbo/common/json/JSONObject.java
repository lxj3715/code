/*     */ package com.alibaba.dubbo.common.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class JSONObject
/*     */   implements JSONNode
/*     */ {
/*  31 */   private Map<String, Object> mMap = new HashMap();
/*     */ 
/*     */   public Object get(String key)
/*     */   {
/*  41 */     return this.mMap.get(key);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String key, boolean def)
/*     */   {
/*  53 */     Object tmp = this.mMap.get(key);
/*  54 */     return (tmp != null) && ((tmp instanceof Boolean)) ? ((Boolean)tmp).booleanValue() : def;
/*     */   }
/*     */ 
/*     */   public int getInt(String key, int def)
/*     */   {
/*  66 */     Object tmp = this.mMap.get(key);
/*  67 */     return (tmp != null) && ((tmp instanceof Number)) ? ((Number)tmp).intValue() : def;
/*     */   }
/*     */ 
/*     */   public long getLong(String key, long def)
/*     */   {
/*  79 */     Object tmp = this.mMap.get(key);
/*  80 */     return (tmp != null) && ((tmp instanceof Number)) ? ((Number)tmp).longValue() : def;
/*     */   }
/*     */ 
/*     */   public float getFloat(String key, float def)
/*     */   {
/*  92 */     Object tmp = this.mMap.get(key);
/*  93 */     return (tmp != null) && ((tmp instanceof Number)) ? ((Number)tmp).floatValue() : def;
/*     */   }
/*     */ 
/*     */   public double getDouble(String key, double def)
/*     */   {
/* 105 */     Object tmp = this.mMap.get(key);
/* 106 */     return (tmp != null) && ((tmp instanceof Number)) ? ((Number)tmp).doubleValue() : def;
/*     */   }
/*     */ 
/*     */   public String getString(String key)
/*     */   {
/* 117 */     Object tmp = this.mMap.get(key);
/* 118 */     return tmp == null ? null : tmp.toString();
/*     */   }
/*     */ 
/*     */   public JSONArray getArray(String key)
/*     */   {
/* 129 */     Object tmp = this.mMap.get(key);
/* 130 */     return (tmp instanceof JSONArray) ? (JSONArray)tmp : tmp == null ? null : null;
/*     */   }
/*     */ 
/*     */   public JSONObject getObject(String key)
/*     */   {
/* 141 */     Object tmp = this.mMap.get(key);
/* 142 */     return (tmp instanceof JSONObject) ? (JSONObject)tmp : tmp == null ? null : null;
/*     */   }
/*     */ 
/*     */   public Iterator<String> keys()
/*     */   {
/* 152 */     return this.mMap.keySet().iterator();
/*     */   }
/*     */ 
/*     */   public boolean contains(String key)
/*     */   {
/* 163 */     return this.mMap.containsKey(key);
/*     */   }
/*     */ 
/*     */   public void put(String name, Object value)
/*     */   {
/* 174 */     this.mMap.put(name, value);
/*     */   }
/*     */ 
/*     */   public void putAll(String[] names, Object[] values)
/*     */   {
/* 185 */     int i = 0; for (int len = Math.min(names.length, values.length); i < len; i++)
/* 186 */       this.mMap.put(names[i], values[i]);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<String, Object> map)
/*     */   {
/* 196 */     for (Map.Entry entry : map.entrySet())
/* 197 */       this.mMap.put(entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public void writeJSON(JSONConverter jc, JSONWriter jb, boolean writeClass)
/*     */     throws IOException
/*     */   {
/* 210 */     jb.objectBegin();
/* 211 */     for (Map.Entry entry : this.mMap.entrySet())
/*     */     {
/* 213 */       String key = (String)entry.getKey();
/* 214 */       jb.objectItem(key);
/* 215 */       Object value = entry.getValue();
/* 216 */       if (value == null)
/* 217 */         jb.valueNull();
/*     */       else
/* 219 */         jc.writeValue(value, jb, writeClass);
/*     */     }
/* 221 */     jb.objectEnd();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSONObject
 * JD-Core Version:    0.6.2
 */