/*    */ package com.alibaba.dubbo.common.json;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ public class JSONReader
/*    */ {
/* 32 */   private static ThreadLocal<Yylex> LOCAL_LEXER = new ThreadLocal() { } ;
/*    */   private Yylex mLex;
/*    */ 
/*    */   public JSONReader(InputStream is, String charset) throws UnsupportedEncodingException
/*    */   {
/* 38 */     this(new InputStreamReader(is, charset));
/*    */   }
/*    */ 
/*    */   public JSONReader(Reader reader)
/*    */   {
/* 43 */     this.mLex = getLexer(reader);
/*    */   }
/*    */ 
/*    */   public JSONToken nextToken() throws IOException, ParseException
/*    */   {
/* 48 */     return this.mLex.yylex();
/*    */   }
/*    */ 
/*    */   public JSONToken nextToken(int expect) throws IOException, ParseException
/*    */   {
/* 53 */     JSONToken ret = this.mLex.yylex();
/* 54 */     if (ret == null)
/* 55 */       throw new ParseException("EOF error.");
/* 56 */     if ((expect != 0) && (expect != ret.type))
/* 57 */       throw new ParseException("Unexcepted token.");
/* 58 */     return ret;
/*    */   }
/*    */ 
/*    */   private static Yylex getLexer(Reader reader)
/*    */   {
/* 63 */     Yylex ret = (Yylex)LOCAL_LEXER.get();
/* 64 */     if (ret == null)
/*    */     {
/* 66 */       ret = new Yylex(reader);
/* 67 */       LOCAL_LEXER.set(ret);
/*    */     }
/*    */     else
/*    */     {
/* 71 */       ret.yyreset(reader);
/*    */     }
/* 73 */     return ret;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSONReader
 * JD-Core Version:    0.6.2
 */