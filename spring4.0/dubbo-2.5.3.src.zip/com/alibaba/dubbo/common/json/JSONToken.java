/*    */ package com.alibaba.dubbo.common.json;
/*    */ 
/*    */ public class JSONToken
/*    */ {
/*    */   public static final int ANY = 0;
/*    */   public static final int IDENT = 1;
/*    */   public static final int LBRACE = 2;
/*    */   public static final int LSQUARE = 3;
/*    */   public static final int RBRACE = 4;
/*    */   public static final int RSQUARE = 5;
/*    */   public static final int COMMA = 6;
/*    */   public static final int COLON = 7;
/*    */   public static final int NULL = 16;
/*    */   public static final int BOOL = 17;
/*    */   public static final int INT = 18;
/*    */   public static final int FLOAT = 19;
/*    */   public static final int STRING = 20;
/*    */   public static final int ARRAY = 21;
/*    */   public static final int OBJECT = 22;
/*    */   public final int type;
/*    */   public final Object value;
/*    */ 
/*    */   JSONToken(int t)
/*    */   {
/* 37 */     this(t, null);
/*    */   }
/*    */ 
/*    */   JSONToken(int t, Object v)
/*    */   {
/* 42 */     this.type = t;
/* 43 */     this.value = v;
/*    */   }
/*    */ 
/*    */   static String token2string(int t)
/*    */   {
/* 48 */     switch (t) {
/*    */     case 2:
/* 50 */       return "{";
/*    */     case 4:
/* 51 */       return "}";
/*    */     case 3:
/* 52 */       return "[";
/*    */     case 5:
/* 53 */       return "]";
/*    */     case 6:
/* 54 */       return ",";
/*    */     case 7:
/* 55 */       return ":";
/*    */     case 1:
/* 56 */       return "IDENT";
/*    */     case 16:
/* 57 */       return "NULL";
/*    */     case 17:
/* 58 */       return "BOOL VALUE";
/*    */     case 18:
/* 59 */       return "INT VALUE";
/*    */     case 19:
/* 60 */       return "FLOAT VALUE";
/*    */     case 20:
/* 61 */       return "STRING VALUE";
/*    */     case 8:
/*    */     case 9:
/*    */     case 10:
/*    */     case 11:
/*    */     case 12:
/*    */     case 13:
/*    */     case 14:
/* 62 */     case 15: } return "ANY";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSONToken
 * JD-Core Version:    0.6.2
 */