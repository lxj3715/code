package com.alibaba.dubbo.common.json;

public abstract interface JSONVisitor
{
  public static final String CLASS_PROPERTY = "class";

  public abstract void begin();

  public abstract Object end(Object paramObject, boolean paramBoolean)
    throws ParseException;

  public abstract void objectBegin()
    throws ParseException;

  public abstract Object objectEnd(int paramInt)
    throws ParseException;

  public abstract void objectItem(String paramString)
    throws ParseException;

  public abstract void objectItemValue(Object paramObject, boolean paramBoolean)
    throws ParseException;

  public abstract void arrayBegin()
    throws ParseException;

  public abstract Object arrayEnd(int paramInt)
    throws ParseException;

  public abstract void arrayItem(int paramInt)
    throws ParseException;

  public abstract void arrayItemValue(int paramInt, Object paramObject, boolean paramBoolean)
    throws ParseException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSONVisitor
 * JD-Core Version:    0.6.2
 */