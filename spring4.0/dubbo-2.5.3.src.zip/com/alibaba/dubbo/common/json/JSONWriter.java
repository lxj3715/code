/*     */ package com.alibaba.dubbo.common.json;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.Stack;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class JSONWriter
/*     */ {
/*     */   private static final byte UNKNOWN = 0;
/*     */   private static final byte ARRAY = 1;
/*     */   private static final byte OBJECT = 2;
/*     */   private static final byte OBJECT_VALUE = 3;
/*     */   private Writer mWriter;
/*  48 */   private State mState = new State((byte)0);
/*     */ 
/*  50 */   private Stack<State> mStack = new Stack();
/*     */ 
/* 276 */   private static final String[] CONTROL_CHAR_MAP = { "\\u0000", "\\u0001", "\\u0002", "\\u0003", "\\u0004", "\\u0005", "\\u0006", "\\u0007", "\\b", "\\t", "\\n", "\\u000b", "\\f", "\\r", "\\u000e", "\\u000f", "\\u0010", "\\u0011", "\\u0012", "\\u0013", "\\u0014", "\\u0015", "\\u0016", "\\u0017", "\\u0018", "\\u0019", "\\u001a", "\\u001b", "\\u001c", "\\u001d", "\\u001e", "\\u001f" };
/*     */ 
/*     */   public JSONWriter(Writer writer)
/*     */   {
/*  54 */     this.mWriter = writer;
/*     */   }
/*     */ 
/*     */   public JSONWriter(OutputStream is, String charset) throws UnsupportedEncodingException
/*     */   {
/*  59 */     this.mWriter = new OutputStreamWriter(is, charset);
/*     */   }
/*     */ 
/*     */   public JSONWriter objectBegin()
/*     */     throws IOException
/*     */   {
/*  70 */     beforeValue();
/*     */ 
/*  72 */     this.mWriter.write(123);
/*  73 */     this.mStack.push(this.mState);
/*  74 */     this.mState = new State((byte)2);
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter objectEnd()
/*     */     throws IOException
/*     */   {
/*  86 */     this.mWriter.write(125);
/*  87 */     this.mState = ((State)this.mStack.pop());
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter objectItem(String name)
/*     */     throws IOException
/*     */   {
/* 100 */     beforeObjectItem();
/*     */ 
/* 102 */     this.mWriter.write(34);
/* 103 */     this.mWriter.write(escape(name));
/* 104 */     this.mWriter.write(34);
/* 105 */     this.mWriter.write(58);
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter arrayBegin()
/*     */     throws IOException
/*     */   {
/* 117 */     beforeValue();
/*     */ 
/* 119 */     this.mWriter.write(91);
/* 120 */     this.mStack.push(this.mState);
/* 121 */     this.mState = new State((byte)1);
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter arrayEnd()
/*     */     throws IOException
/*     */   {
/* 133 */     this.mWriter.write(93);
/* 134 */     this.mState = ((State)this.mStack.pop());
/* 135 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter valueNull()
/*     */     throws IOException
/*     */   {
/* 146 */     beforeValue();
/*     */ 
/* 148 */     this.mWriter.write("null");
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter valueString(String value)
/*     */     throws IOException
/*     */   {
/* 161 */     beforeValue();
/*     */ 
/* 163 */     this.mWriter.write(34);
/* 164 */     this.mWriter.write(escape(value));
/* 165 */     this.mWriter.write(34);
/* 166 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter valueBoolean(boolean value)
/*     */     throws IOException
/*     */   {
/* 178 */     beforeValue();
/*     */ 
/* 180 */     this.mWriter.write(value ? "true" : "false");
/* 181 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter valueInt(int value)
/*     */     throws IOException
/*     */   {
/* 193 */     beforeValue();
/*     */ 
/* 195 */     this.mWriter.write(String.valueOf(value));
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter valueLong(long value)
/*     */     throws IOException
/*     */   {
/* 208 */     beforeValue();
/*     */ 
/* 210 */     this.mWriter.write(String.valueOf(value));
/* 211 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter valueFloat(float value)
/*     */     throws IOException
/*     */   {
/* 223 */     beforeValue();
/*     */ 
/* 225 */     this.mWriter.write(String.valueOf(value));
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */   public JSONWriter valueDouble(double value)
/*     */     throws IOException
/*     */   {
/* 238 */     beforeValue();
/*     */ 
/* 240 */     this.mWriter.write(String.valueOf(value));
/* 241 */     return this;
/*     */   }
/*     */ 
/*     */   private void beforeValue() throws IOException
/*     */   {
/* 246 */     switch (this.mState.type)
/*     */     {
/*     */     case 1:
/* 249 */       if (State.access$108(this.mState) > 0)
/* 250 */         this.mWriter.write(44);
/* 251 */       return;
/*     */     case 2:
/* 253 */       throw new IOException("Must call objectItem first.");
/*     */     case 3:
/* 255 */       this.mState.type = 2;
/* 256 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void beforeObjectItem() throws IOException
/*     */   {
/* 262 */     switch (this.mState.type)
/*     */     {
/*     */     case 3:
/* 265 */       this.mWriter.write("null");
/*     */     case 2:
/* 267 */       this.mState.type = 3;
/* 268 */       if (State.access$108(this.mState) > 0)
/* 269 */         this.mWriter.write(44);
/* 270 */       return;
/*     */     }
/* 272 */     throw new IOException("Must call objectBegin first.");
/*     */   }
/*     */ 
/*     */   private static String escape(String str)
/*     */   {
/* 285 */     if (str == null)
/* 286 */       return str;
/* 287 */     int len = str.length();
/* 288 */     if (len == 0) {
/* 289 */       return str;
/*     */     }
/*     */ 
/* 292 */     StringBuilder sb = null;
/* 293 */     for (int i = 0; i < len; i++)
/*     */     {
/* 295 */       char c = str.charAt(i);
/* 296 */       if (c < ' ')
/*     */       {
/* 298 */         if (sb == null)
/*     */         {
/* 300 */           sb = new StringBuilder(len << 1);
/* 301 */           sb.append(str, 0, i);
/*     */         }
/* 303 */         sb.append(CONTROL_CHAR_MAP[c]);
/*     */       }
/*     */       else
/*     */       {
/* 307 */         switch (c) { case '"':
/*     */         case '/':
/*     */         case '\\':
/* 310 */           if (sb == null)
/*     */           {
/* 312 */             sb = new StringBuilder(len << 1);
/* 313 */             sb.append(str, 0, i);
/*     */           }
/* 315 */           sb.append('\\').append(c);
/* 316 */           break;
/*     */         default:
/* 318 */           if (sb != null)
/* 319 */             sb.append(c);
/*     */           break; }
/*     */       }
/*     */     }
/* 323 */     return sb == null ? str : sb.toString();
/*     */   }
/*     */ 
/*     */   private static class State
/*     */   {
/*     */     private byte type;
/*  41 */     private int itemCount = 0;
/*     */ 
/*  43 */     State(byte t) { this.type = t; }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.JSONWriter
 * JD-Core Version:    0.6.2
 */