/*    */ package com.alibaba.dubbo.common.json;
/*    */ 
/*    */ public class ParseException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 8611884051738966316L;
/*    */ 
/*    */   public ParseException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ParseException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.ParseException
 * JD-Core Version:    0.6.2
 */