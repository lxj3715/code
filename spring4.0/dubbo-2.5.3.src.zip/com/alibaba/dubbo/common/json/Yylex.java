/*     */ package com.alibaba.dubbo.common.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ public class Yylex
/*     */ {
/*     */   public static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 16384;
/*     */   public static final int STR2 = 4;
/*     */   public static final int STR1 = 2;
/*     */   public static final int YYINITIAL = 0;
/*  43 */   private static final int[] ZZ_LEXSTATE = { 0, 0, 1, 1, 2, 2 };
/*     */   private static final String ZZ_CMAP_PACKED = "";
/*  62 */   private static final char[] ZZ_CMAP = zzUnpackCMap("");
/*     */ 
/*  67 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */   private static final String ZZ_ACTION_PACKED_0 = "";
/* 100 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "";
/* 133 */   private static final int[] ZZ_TRANS = { 3, 4, 5, 5, 6, 3, 5, 3, 7, 8, 3, 9, 3, 5, 10, 11, 5, 12, 5, 5, 13, 5, 5, 5, 5, 5, 14, 5, 5, 5, 15, 16, 17, 18, 19, 20, 21, 22, 22, 22, 22, 22, 22, 22, 22, 23, 22, 24, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 25, 25, 25, 25, 25, 25, 25, 25, 25, 23, 26, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4, -1, -1, -1, 27, 28, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 28, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 4, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 29, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 30, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 31, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 32, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 33, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 34, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, 22, 22, 22, 22, 22, 22, 22, 22, -1, 22, -1, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, -1, -1, -1, -1, -1, -1, -1, -1, 35, -1, 36, -1, 37, 38, 39, 40, 41, 42, 43, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 25, 25, 25, 25, 25, 25, 25, 25, 25, -1, -1, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, -1, -1, -1, -1, -1, -1, -1, -1, -1, 44, 36, -1, 37, 38, 39, 40, 41, 42, 43, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 45, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 46, -1, -1, 47, -1, -1, 47, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 48, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 49, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 50, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 51, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 52, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 53, 5, 5, -1, -1, -1, -1, -1, -1, -1, 54, -1, 54, -1, -1, 54, -1, -1, -1, -1, -1, -1, 54, 54, -1, -1, -1, -1, 54, -1, -1, -1, 54, -1, -1, 54, 54, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 45, -1, -1, -1, -1, 28, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 28, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 46, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 55, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 56, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 57, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 57, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 58, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 56, 5, 5, -1, -1, -1, -1, -1, -1, -1, 59, -1, 59, -1, -1, 59, -1, -1, -1, -1, -1, -1, 59, 59, -1, -1, -1, -1, 59, -1, -1, -1, 59, -1, -1, 59, 59, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 5, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 60, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 5, 5, 5, -1, -1, 60, -1, -1, -1, -1, -1, -1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, -1, -1, -1, -1, -1, -1, -1, 61, -1, 61, -1, -1, 61, -1, -1, -1, -1, -1, -1, 61, 61, -1, -1, -1, -1, 61, -1, -1, -1, 61, -1, -1, 61, 61, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, 62, -1, -1, 62, -1, -1, -1, -1, -1, -1, 62, 62, -1, -1, -1, -1, 62, -1, -1, -1, 62, -1, -1, 62, 62, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/* 290 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*     */ 
/* 299 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/* 332 */   private int zzLexicalState = 0;
/*     */ 
/* 336 */   private char[] zzBuffer = new char[16384];
/*     */   private int zzMarkedPos;
/*     */   private int zzCurrentPos;
/*     */   private int zzStartRead;
/*     */   private int zzEndRead;
/*     */   private boolean zzAtEOF;
/*     */   private StringBuffer sb;
/*     */ 
/*     */   private static int[] zzUnpackAction()
/*     */   {
/*  78 */     int[] result = new int[63];
/*  79 */     int offset = 0;
/*  80 */     offset = zzUnpackAction("", offset, result);
/*  81 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  85 */     int i = 0;
/*  86 */     int j = offset;
/*  87 */     int l = packed.length();
/*     */     int count;
/*  91 */     for (; i < l; 
/*  91 */       count > 0)
/*     */     {
/*  89 */       count = packed.charAt(i++);
/*  90 */       int value = packed.charAt(i++);
/*  91 */       result[(j++)] = value; count--;
/*     */     }
/*  93 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackRowMap()
/*     */   {
/* 113 */     int[] result = new int[63];
/* 114 */     int offset = 0;
/* 115 */     offset = zzUnpackRowMap("", offset, result);
/* 116 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 120 */     int i = 0;
/* 121 */     int j = offset;
/* 122 */     int l = packed.length();
/* 123 */     while (i < l) {
/* 124 */       int high = packed.charAt(i++) << '\020';
/* 125 */       result[(j++)] = (high | packed.charAt(i++));
/*     */     }
/* 127 */     return j;
/*     */   }
/*     */ 
/*     */   private static int[] zzUnpackAttribute()
/*     */   {
/* 307 */     int[] result = new int[63];
/* 308 */     int offset = 0;
/* 309 */     offset = zzUnpackAttribute("", offset, result);
/* 310 */     return result;
/*     */   }
/*     */ 
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 314 */     int i = 0;
/* 315 */     int j = offset;
/* 316 */     int l = packed.length();
/*     */     int count;
/* 320 */     for (; i < l; 
/* 320 */       count > 0)
/*     */     {
/* 318 */       count = packed.charAt(i++);
/* 319 */       int value = packed.charAt(i++);
/* 320 */       result[(j++)] = value; count--;
/*     */     }
/* 322 */     return j;
/*     */   }
/*     */ 
/*     */   Yylex(Reader in)
/*     */   {
/* 385 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */   Yylex(InputStream in)
/*     */   {
/* 395 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */   private static char[] zzUnpackCMap(String packed)
/*     */   {
/* 405 */     char[] map = new char[65536];
/* 406 */     int i = 0;
/* 407 */     int j = 0;
/*     */     int count;
/* 411 */     for (; i < 122; 
/* 411 */       count > 0)
/*     */     {
/* 409 */       count = packed.charAt(i++);
/* 410 */       char value = packed.charAt(i++);
/* 411 */       map[(j++)] = value; count--;
/*     */     }
/* 413 */     return map;
/*     */   }
/*     */ 
/*     */   private boolean zzRefill()
/*     */     throws IOException
/*     */   {
/* 427 */     if (this.zzStartRead > 0) {
/* 428 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*     */ 
/* 433 */       this.zzEndRead -= this.zzStartRead;
/* 434 */       this.zzCurrentPos -= this.zzStartRead;
/* 435 */       this.zzMarkedPos -= this.zzStartRead;
/* 436 */       this.zzStartRead = 0;
/*     */     }
/*     */ 
/* 440 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*     */     {
/* 442 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 443 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 444 */       this.zzBuffer = newBuffer;
/*     */     }
/*     */ 
/* 448 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*     */ 
/* 451 */     if (numRead > 0) {
/* 452 */       this.zzEndRead += numRead;
/* 453 */       return false;
/*     */     }
/*     */ 
/* 456 */     if (numRead == 0) {
/* 457 */       int c = this.zzReader.read();
/* 458 */       if (c == -1) {
/* 459 */         return true;
/*     */       }
/* 461 */       this.zzBuffer[(this.zzEndRead++)] = ((char)c);
/* 462 */       return false;
/*     */     }
/*     */ 
/* 467 */     return true;
/*     */   }
/*     */ 
/*     */   public final void yyclose()
/*     */     throws IOException
/*     */   {
/* 475 */     this.zzAtEOF = true;
/* 476 */     this.zzEndRead = this.zzStartRead;
/*     */ 
/* 478 */     if (this.zzReader != null)
/* 479 */       this.zzReader.close();
/*     */   }
/*     */ 
/*     */   public final void yyreset(Reader reader)
/*     */   {
/* 494 */     this.zzReader = reader;
/*     */ 
/* 496 */     this.zzAtEOF = false;
/*     */ 
/* 498 */     this.zzEndRead = (this.zzStartRead = 0);
/* 499 */     this.zzCurrentPos = (this.zzMarkedPos = 0);
/*     */ 
/* 501 */     this.zzLexicalState = 0;
/*     */   }
/*     */ 
/*     */   public final int yystate()
/*     */   {
/* 509 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */   public final void yybegin(int newState)
/*     */   {
/* 519 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */   public final String yytext()
/*     */   {
/* 527 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */   public final char yycharat(int pos)
/*     */   {
/* 543 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*     */   }
/*     */ 
/*     */   public final int yylength()
/*     */   {
/* 551 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */   private void zzScanError(int errorCode)
/*     */   {
/*     */     String message;
/*     */     try
/*     */     {
/* 572 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 575 */       message = ZZ_ERROR_MSG[0];
/*     */     }
/*     */ 
/* 578 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */   public void yypushback(int number)
/*     */   {
/* 591 */     if (number > yylength()) {
/* 592 */       zzScanError(2);
/*     */     }
/* 594 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */   public JSONToken yylex()
/*     */     throws IOException, ParseException
/*     */   {
/* 612 */     int zzEndReadL = this.zzEndRead;
/* 613 */     char[] zzBufferL = this.zzBuffer;
/* 614 */     char[] zzCMapL = ZZ_CMAP;
/*     */ 
/* 616 */     int[] zzTransL = ZZ_TRANS;
/* 617 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 618 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     while (true)
/*     */     {
/* 621 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */ 
/* 623 */       int zzAction = -1;
/*     */ 
/* 625 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */ 
/* 627 */       this.zzState = ZZ_LEXSTATE[this.zzLexicalState];
/*     */       int zzInput;
/*     */       while (true)
/*     */       {
/*     */         int zzInput;
/* 633 */         if (zzCurrentPosL < zzEndReadL) {
/* 634 */           zzInput = zzBufferL[(zzCurrentPosL++)]; } else {
/* 635 */           if (this.zzAtEOF) {
/* 636 */             int zzInput = -1;
/* 637 */             break;
/*     */           }
/*     */ 
/* 641 */           this.zzCurrentPos = zzCurrentPosL;
/* 642 */           this.zzMarkedPos = zzMarkedPosL;
/* 643 */           boolean eof = zzRefill();
/*     */ 
/* 645 */           zzCurrentPosL = this.zzCurrentPos;
/* 646 */           zzMarkedPosL = this.zzMarkedPos;
/* 647 */           zzBufferL = this.zzBuffer;
/* 648 */           zzEndReadL = this.zzEndRead;
/* 649 */           if (eof) {
/* 650 */             int zzInput = -1;
/* 651 */             break;
/*     */           }
/*     */ 
/* 654 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*     */         }
/*     */ 
/* 657 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 658 */         if (zzNext == -1) break;
/* 659 */         this.zzState = zzNext;
/*     */ 
/* 661 */         int zzAttributes = zzAttrL[this.zzState];
/* 662 */         if ((zzAttributes & 0x1) == 1) {
/* 663 */           zzAction = this.zzState;
/* 664 */           zzMarkedPosL = zzCurrentPosL;
/* 665 */           if ((zzAttributes & 0x8) == 8)
/*     */           {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 672 */       this.zzMarkedPos = zzMarkedPosL;
/*     */ 
/* 674 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*     */       case 25:
/* 676 */         return new JSONToken(16, null);
/*     */       case 29:
/* 678 */         break;
/*     */       case 13:
/* 680 */         this.sb.append(yytext());
/*     */       case 30:
/* 682 */         break;
/*     */       case 18:
/* 684 */         this.sb.append('\b');
/*     */       case 31:
/* 686 */         break;
/*     */       case 9:
/* 688 */         return new JSONToken(3);
/*     */       case 32:
/* 690 */         break;
/*     */       case 2:
/* 692 */         Long val = Long.valueOf(yytext()); return new JSONToken(18, val);
/*     */       case 33:
/* 694 */         break;
/*     */       case 16:
/* 696 */         this.sb.append('\\');
/*     */       case 34:
/* 698 */         break;
/*     */       case 8:
/* 700 */         return new JSONToken(4);
/*     */       case 35:
/* 702 */         break;
/*     */       case 26:
/* 704 */         return new JSONToken(17, Boolean.TRUE);
/*     */       case 36:
/* 706 */         break;
/*     */       case 23:
/* 708 */         this.sb.append('\'');
/*     */       case 37:
/* 710 */         break;
/*     */       case 5:
/* 712 */         this.sb = new StringBuffer(); yybegin(4);
/*     */       case 38:
/* 714 */         break;
/*     */       case 27:
/* 716 */         return new JSONToken(17, Boolean.FALSE);
/*     */       case 39:
/* 718 */         break;
/*     */       case 12:
/* 720 */         return new JSONToken(7);
/*     */       case 40:
/* 722 */         break;
/*     */       case 21:
/* 724 */         this.sb.append('\r');
/*     */       case 41:
/* 726 */         break;
/*     */       case 3:
/* 728 */         return new JSONToken(1, yytext());
/*     */       case 42:
/* 730 */         break;
/*     */       case 28:
/*     */         try { this.sb.append((char)Integer.parseInt(yytext().substring(2), 16)); } catch (Exception e) { throw new ParseException(e.getMessage()); }
/*     */       case 43:
/* 734 */         break;
/*     */       case 10:
/* 736 */         return new JSONToken(5);
/*     */       case 44:
/* 738 */         break;
/*     */       case 17:
/* 740 */         this.sb.append('/');
/*     */       case 45:
/* 742 */         break;
/*     */       case 11:
/* 744 */         return new JSONToken(6);
/*     */       case 46:
/* 746 */         break;
/*     */       case 15:
/* 748 */         this.sb.append('"');
/*     */       case 47:
/* 750 */         break;
/*     */       case 24:
/* 752 */         Double val = Double.valueOf(yytext()); return new JSONToken(19, val);
/*     */       case 48:
/* 754 */         break;
/*     */       case 1:
/* 756 */         throw new ParseException("Unexpected char [" + yytext() + "]");
/*     */       case 49:
/* 758 */         break;
/*     */       case 19:
/* 760 */         this.sb.append('\f');
/*     */       case 50:
/* 762 */         break;
/*     */       case 7:
/* 764 */         return new JSONToken(2);
/*     */       case 51:
/* 766 */         break;
/*     */       case 14:
/* 768 */         yybegin(0); return new JSONToken(20, this.sb.toString());
/*     */       case 52:
/* 770 */         break;
/*     */       case 22:
/* 772 */         this.sb.append('\t');
/*     */       case 53:
/* 774 */         break;
/*     */       case 4:
/* 776 */         this.sb = new StringBuffer(); yybegin(2);
/*     */       case 54:
/* 778 */         break;
/*     */       case 20:
/* 780 */         this.sb.append('\n');
/*     */       case 55:
/* 782 */         break;
/*     */       case 6:
/*     */       case 56:
/* 786 */         break;
/*     */       default:
/* 788 */         if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 789 */           this.zzAtEOF = true;
/* 790 */           return null;
/*     */         }
/*     */ 
/* 793 */         zzScanError(1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.json.Yylex
 * JD-Core Version:    0.6.2
 */