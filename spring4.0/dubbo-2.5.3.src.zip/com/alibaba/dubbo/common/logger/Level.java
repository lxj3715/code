/*    */ package com.alibaba.dubbo.common.logger;
/*    */ 
/*    */ public enum Level
/*    */ {
/* 28 */   ALL, 
/*    */ 
/* 33 */   TRACE, 
/*    */ 
/* 38 */   DEBUG, 
/*    */ 
/* 43 */   INFO, 
/*    */ 
/* 48 */   WARN, 
/*    */ 
/* 53 */   ERROR, 
/*    */ 
/* 58 */   OFF;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.Level
 * JD-Core Version:    0.6.2
 */