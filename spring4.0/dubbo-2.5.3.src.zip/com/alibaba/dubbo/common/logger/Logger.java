package com.alibaba.dubbo.common.logger;

public abstract interface Logger
{
  public abstract void trace(String paramString);

  public abstract void trace(Throwable paramThrowable);

  public abstract void trace(String paramString, Throwable paramThrowable);

  public abstract void debug(String paramString);

  public abstract void debug(Throwable paramThrowable);

  public abstract void debug(String paramString, Throwable paramThrowable);

  public abstract void info(String paramString);

  public abstract void info(Throwable paramThrowable);

  public abstract void info(String paramString, Throwable paramThrowable);

  public abstract void warn(String paramString);

  public abstract void warn(Throwable paramThrowable);

  public abstract void warn(String paramString, Throwable paramThrowable);

  public abstract void error(String paramString);

  public abstract void error(Throwable paramThrowable);

  public abstract void error(String paramString, Throwable paramThrowable);

  public abstract boolean isTraceEnabled();

  public abstract boolean isDebugEnabled();

  public abstract boolean isInfoEnabled();

  public abstract boolean isWarnEnabled();

  public abstract boolean isErrorEnabled();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.Logger
 * JD-Core Version:    0.6.2
 */