package com.alibaba.dubbo.common.logger;

import com.alibaba.dubbo.common.extension.SPI;
import java.io.File;

@SPI
public abstract interface LoggerAdapter
{
  public abstract Logger getLogger(Class<?> paramClass);

  public abstract Logger getLogger(String paramString);

  public abstract void setLevel(Level paramLevel);

  public abstract Level getLevel();

  public abstract File getFile();

  public abstract void setFile(File paramFile);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.LoggerAdapter
 * JD-Core Version:    0.6.2
 */