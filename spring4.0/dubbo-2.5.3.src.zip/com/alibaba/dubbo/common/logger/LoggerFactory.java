/*     */ package com.alibaba.dubbo.common.logger;
/*     */ 
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.jcl.JclLoggerAdapter;
/*     */ import com.alibaba.dubbo.common.logger.jdk.JdkLoggerAdapter;
/*     */ import com.alibaba.dubbo.common.logger.log4j.Log4jLoggerAdapter;
/*     */ import com.alibaba.dubbo.common.logger.slf4j.Slf4jLoggerAdapter;
/*     */ import com.alibaba.dubbo.common.logger.support.FailsafeLogger;
/*     */ import java.io.File;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ public class LoggerFactory
/*     */ {
/*     */   private static volatile LoggerAdapter LOGGER_ADAPTER;
/*  42 */   private static final ConcurrentMap<String, FailsafeLogger> LOGGERS = new ConcurrentHashMap();
/*     */ 
/*     */   public static void setLoggerAdapter(String loggerAdapter)
/*     */   {
/*  73 */     if ((loggerAdapter != null) && (loggerAdapter.length() > 0))
/*  74 */       setLoggerAdapter((LoggerAdapter)ExtensionLoader.getExtensionLoader(LoggerAdapter.class).getExtension(loggerAdapter));
/*     */   }
/*     */ 
/*     */   public static void setLoggerAdapter(LoggerAdapter loggerAdapter)
/*     */   {
/*  85 */     if (loggerAdapter != null) {
/*  86 */       Logger logger = loggerAdapter.getLogger(LoggerFactory.class.getName());
/*  87 */       logger.info("using logger: " + loggerAdapter.getClass().getName());
/*  88 */       LOGGER_ADAPTER = loggerAdapter;
/*  89 */       for (Map.Entry entry : LOGGERS.entrySet())
/*  90 */         ((FailsafeLogger)entry.getValue()).setLogger(LOGGER_ADAPTER.getLogger((String)entry.getKey()));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Logger getLogger(Class<?> key)
/*     */   {
/* 103 */     FailsafeLogger logger = (FailsafeLogger)LOGGERS.get(key.getName());
/* 104 */     if (logger == null) {
/* 105 */       LOGGERS.putIfAbsent(key.getName(), new FailsafeLogger(LOGGER_ADAPTER.getLogger(key)));
/* 106 */       logger = (FailsafeLogger)LOGGERS.get(key.getName());
/*     */     }
/* 108 */     return logger;
/*     */   }
/*     */ 
/*     */   public static Logger getLogger(String key)
/*     */   {
/* 119 */     FailsafeLogger logger = (FailsafeLogger)LOGGERS.get(key);
/* 120 */     if (logger == null) {
/* 121 */       LOGGERS.putIfAbsent(key, new FailsafeLogger(LOGGER_ADAPTER.getLogger(key)));
/* 122 */       logger = (FailsafeLogger)LOGGERS.get(key);
/*     */     }
/* 124 */     return logger;
/*     */   }
/*     */ 
/*     */   public static void setLevel(Level level)
/*     */   {
/* 133 */     LOGGER_ADAPTER.setLevel(level);
/*     */   }
/*     */ 
/*     */   public static Level getLevel()
/*     */   {
/* 142 */     return LOGGER_ADAPTER.getLevel();
/*     */   }
/*     */ 
/*     */   public static File getFile()
/*     */   {
/* 151 */     return LOGGER_ADAPTER.getFile();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  46 */     String logger = System.getProperty("dubbo.application.logger");
/*  47 */     if ("slf4j".equals(logger))
/*  48 */       setLoggerAdapter(new Slf4jLoggerAdapter());
/*  49 */     else if ("jcl".equals(logger))
/*  50 */       setLoggerAdapter(new JclLoggerAdapter());
/*  51 */     else if ("log4j".equals(logger))
/*  52 */       setLoggerAdapter(new Log4jLoggerAdapter());
/*  53 */     else if ("jdk".equals(logger))
/*  54 */       setLoggerAdapter(new JdkLoggerAdapter());
/*     */     else
/*     */       try {
/*  57 */         setLoggerAdapter(new Log4jLoggerAdapter());
/*     */       } catch (Throwable e1) {
/*     */         try {
/*  60 */           setLoggerAdapter(new Slf4jLoggerAdapter());
/*     */         } catch (Throwable e2) {
/*     */           try {
/*  63 */             setLoggerAdapter(new JclLoggerAdapter());
/*     */           } catch (Throwable e3) {
/*  65 */             setLoggerAdapter(new JdkLoggerAdapter());
/*     */           }
/*     */         }
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.LoggerFactory
 * JD-Core Version:    0.6.2
 */