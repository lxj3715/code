/*     */ package com.alibaba.dubbo.common.logger.jcl;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class JclLogger
/*     */   implements Logger, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Log logger;
/*     */ 
/*     */   public JclLogger(Log logger)
/*     */   {
/*  24 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   public void trace(String msg) {
/*  28 */     this.logger.trace(msg);
/*     */   }
/*     */ 
/*     */   public void trace(Throwable e) {
/*  32 */     this.logger.trace(e);
/*     */   }
/*     */ 
/*     */   public void trace(String msg, Throwable e) {
/*  36 */     this.logger.trace(msg, e);
/*     */   }
/*     */ 
/*     */   public void debug(String msg) {
/*  40 */     this.logger.debug(msg);
/*     */   }
/*     */ 
/*     */   public void debug(Throwable e) {
/*  44 */     this.logger.debug(e);
/*     */   }
/*     */ 
/*     */   public void debug(String msg, Throwable e) {
/*  48 */     this.logger.debug(msg, e);
/*     */   }
/*     */ 
/*     */   public void info(String msg) {
/*  52 */     this.logger.info(msg);
/*     */   }
/*     */ 
/*     */   public void info(Throwable e) {
/*  56 */     this.logger.info(e);
/*     */   }
/*     */ 
/*     */   public void info(String msg, Throwable e) {
/*  60 */     this.logger.info(msg, e);
/*     */   }
/*     */ 
/*     */   public void warn(String msg) {
/*  64 */     this.logger.warn(msg);
/*     */   }
/*     */ 
/*     */   public void warn(Throwable e) {
/*  68 */     this.logger.warn(e);
/*     */   }
/*     */ 
/*     */   public void warn(String msg, Throwable e) {
/*  72 */     this.logger.warn(msg, e);
/*     */   }
/*     */ 
/*     */   public void error(String msg) {
/*  76 */     this.logger.error(msg);
/*     */   }
/*     */ 
/*     */   public void error(Throwable e) {
/*  80 */     this.logger.error(e);
/*     */   }
/*     */ 
/*     */   public void error(String msg, Throwable e) {
/*  84 */     this.logger.error(msg, e);
/*     */   }
/*     */ 
/*     */   public boolean isTraceEnabled() {
/*  88 */     return this.logger.isTraceEnabled();
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled() {
/*  92 */     return this.logger.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   public boolean isInfoEnabled() {
/*  96 */     return this.logger.isInfoEnabled();
/*     */   }
/*     */ 
/*     */   public boolean isWarnEnabled() {
/* 100 */     return this.logger.isWarnEnabled();
/*     */   }
/*     */ 
/*     */   public boolean isErrorEnabled() {
/* 104 */     return this.logger.isErrorEnabled();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.jcl.JclLogger
 * JD-Core Version:    0.6.2
 */