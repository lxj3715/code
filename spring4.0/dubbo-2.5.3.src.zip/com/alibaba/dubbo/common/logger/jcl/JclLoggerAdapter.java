/*    */ package com.alibaba.dubbo.common.logger.jcl;
/*    */ 
/*    */ import com.alibaba.dubbo.common.logger.Level;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerAdapter;
/*    */ import java.io.File;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class JclLoggerAdapter
/*    */   implements LoggerAdapter
/*    */ {
/*    */   private Level level;
/*    */   private File file;
/*    */ 
/*    */   public Logger getLogger(String key)
/*    */   {
/* 14 */     return new JclLogger(LogFactory.getLog(key));
/*    */   }
/*    */ 
/*    */   public Logger getLogger(Class<?> key) {
/* 18 */     return new JclLogger(LogFactory.getLog(key));
/*    */   }
/*    */ 
/*    */   public void setLevel(Level level)
/*    */   {
/* 26 */     this.level = level;
/*    */   }
/*    */ 
/*    */   public Level getLevel() {
/* 30 */     return this.level;
/*    */   }
/*    */ 
/*    */   public File getFile() {
/* 34 */     return this.file;
/*    */   }
/*    */ 
/*    */   public void setFile(File file) {
/* 38 */     this.file = file;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.jcl.JclLoggerAdapter
 * JD-Core Version:    0.6.2
 */