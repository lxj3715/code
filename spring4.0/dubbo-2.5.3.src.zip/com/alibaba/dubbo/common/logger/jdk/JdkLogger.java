/*     */ package com.alibaba.dubbo.common.logger.jdk;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ public class JdkLogger
/*     */   implements com.alibaba.dubbo.common.logger.Logger
/*     */ {
/*     */   private final java.util.logging.Logger logger;
/*     */ 
/*     */   public JdkLogger(java.util.logging.Logger logger)
/*     */   {
/*  27 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   public void trace(String msg) {
/*  31 */     this.logger.log(Level.FINER, msg);
/*     */   }
/*     */ 
/*     */   public void trace(Throwable e) {
/*  35 */     this.logger.log(Level.FINER, e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void trace(String msg, Throwable e) {
/*  39 */     this.logger.log(Level.FINER, msg, e);
/*     */   }
/*     */ 
/*     */   public void debug(String msg) {
/*  43 */     this.logger.log(Level.FINE, msg);
/*     */   }
/*     */ 
/*     */   public void debug(Throwable e) {
/*  47 */     this.logger.log(Level.FINE, e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void debug(String msg, Throwable e) {
/*  51 */     this.logger.log(Level.FINE, msg, e);
/*     */   }
/*     */ 
/*     */   public void info(String msg) {
/*  55 */     this.logger.log(Level.INFO, msg);
/*     */   }
/*     */ 
/*     */   public void info(String msg, Throwable e) {
/*  59 */     this.logger.log(Level.INFO, msg, e);
/*     */   }
/*     */ 
/*     */   public void warn(String msg) {
/*  63 */     this.logger.log(Level.WARNING, msg);
/*     */   }
/*     */ 
/*     */   public void warn(String msg, Throwable e) {
/*  67 */     this.logger.log(Level.WARNING, msg, e);
/*     */   }
/*     */ 
/*     */   public void error(String msg) {
/*  71 */     this.logger.log(Level.SEVERE, msg);
/*     */   }
/*     */ 
/*     */   public void error(String msg, Throwable e) {
/*  75 */     this.logger.log(Level.SEVERE, msg, e);
/*     */   }
/*     */ 
/*     */   public void error(Throwable e) {
/*  79 */     this.logger.log(Level.SEVERE, e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void info(Throwable e) {
/*  83 */     this.logger.log(Level.INFO, e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void warn(Throwable e) {
/*  87 */     this.logger.log(Level.WARNING, e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public boolean isTraceEnabled() {
/*  91 */     return this.logger.isLoggable(Level.FINER);
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled() {
/*  95 */     return this.logger.isLoggable(Level.FINE);
/*     */   }
/*     */ 
/*     */   public boolean isInfoEnabled() {
/*  99 */     return this.logger.isLoggable(Level.INFO);
/*     */   }
/*     */ 
/*     */   public boolean isWarnEnabled() {
/* 103 */     return this.logger.isLoggable(Level.WARNING);
/*     */   }
/*     */ 
/*     */   public boolean isErrorEnabled() {
/* 107 */     return this.logger.isLoggable(Level.SEVERE);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.jdk.JdkLogger
 * JD-Core Version:    0.6.2
 */