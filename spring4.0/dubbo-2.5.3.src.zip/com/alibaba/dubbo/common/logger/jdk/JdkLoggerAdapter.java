/*     */ package com.alibaba.dubbo.common.logger.jdk;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.LoggerAdapter;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.logging.FileHandler;
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.LogManager;
/*     */ 
/*     */ public class JdkLoggerAdapter
/*     */   implements LoggerAdapter
/*     */ {
/*     */   private static final String GLOBAL_LOGGER_NAME = "global";
/*     */   private File file;
/*     */ 
/*     */   public JdkLoggerAdapter()
/*     */   {
/*     */     try
/*     */     {
/*  37 */       InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("logging.properties");
/*  38 */       if (in != null)
/*  39 */         LogManager.getLogManager().readConfiguration(in);
/*     */       else
/*  41 */         System.err.println("No such logging.properties in classpath for jdk logging config!");
/*     */     }
/*     */     catch (Throwable t) {
/*  44 */       System.err.println("Failed to load logging.properties in classpath for jdk logging config, cause: " + t.getMessage());
/*     */     }
/*     */     try {
/*  47 */       Handler[] handlers = java.util.logging.Logger.getLogger("global").getHandlers();
/*  48 */       for (Handler handler : handlers)
/*  49 */         if ((handler instanceof FileHandler)) {
/*  50 */           FileHandler fileHandler = (FileHandler)handler;
/*  51 */           Field field = fileHandler.getClass().getField("files");
/*  52 */           File[] files = (File[])field.get(fileHandler);
/*  53 */           if ((files != null) && (files.length > 0))
/*  54 */             this.file = files[0];
/*     */         }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public com.alibaba.dubbo.common.logger.Logger getLogger(Class<?> key) {
/*  63 */     return new JdkLogger(java.util.logging.Logger.getLogger(key == null ? "" : key.getName()));
/*     */   }
/*     */ 
/*     */   public com.alibaba.dubbo.common.logger.Logger getLogger(String key) {
/*  67 */     return new JdkLogger(java.util.logging.Logger.getLogger(key));
/*     */   }
/*     */ 
/*     */   public void setLevel(com.alibaba.dubbo.common.logger.Level level) {
/*  71 */     java.util.logging.Logger.getLogger("global").setLevel(toJdkLevel(level));
/*     */   }
/*     */ 
/*     */   public com.alibaba.dubbo.common.logger.Level getLevel() {
/*  75 */     return fromJdkLevel(java.util.logging.Logger.getLogger("global").getLevel());
/*     */   }
/*     */ 
/*     */   public File getFile() {
/*  79 */     return this.file;
/*     */   }
/*     */ 
/*     */   private static java.util.logging.Level toJdkLevel(com.alibaba.dubbo.common.logger.Level level) {
/*  83 */     if (level == com.alibaba.dubbo.common.logger.Level.ALL)
/*  84 */       return java.util.logging.Level.ALL;
/*  85 */     if (level == com.alibaba.dubbo.common.logger.Level.TRACE)
/*  86 */       return java.util.logging.Level.FINER;
/*  87 */     if (level == com.alibaba.dubbo.common.logger.Level.DEBUG)
/*  88 */       return java.util.logging.Level.FINE;
/*  89 */     if (level == com.alibaba.dubbo.common.logger.Level.INFO)
/*  90 */       return java.util.logging.Level.INFO;
/*  91 */     if (level == com.alibaba.dubbo.common.logger.Level.WARN)
/*  92 */       return java.util.logging.Level.WARNING;
/*  93 */     if (level == com.alibaba.dubbo.common.logger.Level.ERROR) {
/*  94 */       return java.util.logging.Level.SEVERE;
/*     */     }
/*  96 */     return java.util.logging.Level.OFF;
/*     */   }
/*     */ 
/*     */   private static com.alibaba.dubbo.common.logger.Level fromJdkLevel(java.util.logging.Level level) {
/* 100 */     if (level == java.util.logging.Level.ALL)
/* 101 */       return com.alibaba.dubbo.common.logger.Level.ALL;
/* 102 */     if (level == java.util.logging.Level.FINER)
/* 103 */       return com.alibaba.dubbo.common.logger.Level.TRACE;
/* 104 */     if (level == java.util.logging.Level.FINE)
/* 105 */       return com.alibaba.dubbo.common.logger.Level.DEBUG;
/* 106 */     if (level == java.util.logging.Level.INFO)
/* 107 */       return com.alibaba.dubbo.common.logger.Level.INFO;
/* 108 */     if (level == java.util.logging.Level.WARNING)
/* 109 */       return com.alibaba.dubbo.common.logger.Level.WARN;
/* 110 */     if (level == java.util.logging.Level.SEVERE) {
/* 111 */       return com.alibaba.dubbo.common.logger.Level.ERROR;
/*     */     }
/* 113 */     return com.alibaba.dubbo.common.logger.Level.OFF;
/*     */   }
/*     */ 
/*     */   public void setFile(File file)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.jdk.JdkLoggerAdapter
 * JD-Core Version:    0.6.2
 */