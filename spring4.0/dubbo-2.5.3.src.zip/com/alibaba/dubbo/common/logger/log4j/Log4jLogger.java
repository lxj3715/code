/*     */ package com.alibaba.dubbo.common.logger.log4j;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.support.FailsafeLogger;
/*     */ import org.apache.log4j.Level;
/*     */ 
/*     */ public class Log4jLogger
/*     */   implements com.alibaba.dubbo.common.logger.Logger
/*     */ {
/*  25 */   private static final String FQCN = FailsafeLogger.class.getName();
/*     */   private final org.apache.log4j.Logger logger;
/*     */ 
/*     */   public Log4jLogger(org.apache.log4j.Logger logger)
/*     */   {
/*  30 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   public void trace(String msg) {
/*  34 */     this.logger.log(FQCN, Level.TRACE, msg, null);
/*     */   }
/*     */ 
/*     */   public void trace(Throwable e) {
/*  38 */     this.logger.log(FQCN, Level.TRACE, e == null ? null : e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void trace(String msg, Throwable e) {
/*  42 */     this.logger.log(FQCN, Level.TRACE, msg, e);
/*     */   }
/*     */ 
/*     */   public void debug(String msg) {
/*  46 */     this.logger.log(FQCN, Level.DEBUG, msg, null);
/*     */   }
/*     */ 
/*     */   public void debug(Throwable e) {
/*  50 */     this.logger.log(FQCN, Level.DEBUG, e == null ? null : e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void debug(String msg, Throwable e) {
/*  54 */     this.logger.log(FQCN, Level.DEBUG, msg, e);
/*     */   }
/*     */ 
/*     */   public void info(String msg) {
/*  58 */     this.logger.log(FQCN, Level.INFO, msg, null);
/*     */   }
/*     */ 
/*     */   public void info(Throwable e) {
/*  62 */     this.logger.log(FQCN, Level.INFO, e == null ? null : e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void info(String msg, Throwable e) {
/*  66 */     this.logger.log(FQCN, Level.INFO, msg, e);
/*     */   }
/*     */ 
/*     */   public void warn(String msg) {
/*  70 */     this.logger.log(FQCN, Level.WARN, msg, null);
/*     */   }
/*     */ 
/*     */   public void warn(Throwable e) {
/*  74 */     this.logger.log(FQCN, Level.WARN, e == null ? null : e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void warn(String msg, Throwable e) {
/*  78 */     this.logger.log(FQCN, Level.WARN, msg, e);
/*     */   }
/*     */ 
/*     */   public void error(String msg) {
/*  82 */     this.logger.log(FQCN, Level.ERROR, msg, null);
/*     */   }
/*     */ 
/*     */   public void error(Throwable e) {
/*  86 */     this.logger.log(FQCN, Level.ERROR, e == null ? null : e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public void error(String msg, Throwable e) {
/*  90 */     this.logger.log(FQCN, Level.ERROR, msg, e);
/*     */   }
/*     */ 
/*     */   public boolean isTraceEnabled() {
/*  94 */     return this.logger.isTraceEnabled();
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled() {
/*  98 */     return this.logger.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   public boolean isInfoEnabled() {
/* 102 */     return this.logger.isInfoEnabled();
/*     */   }
/*     */ 
/*     */   public boolean isWarnEnabled() {
/* 106 */     return this.logger.isEnabledFor(Level.WARN);
/*     */   }
/*     */ 
/*     */   public boolean isErrorEnabled() {
/* 110 */     return this.logger.isEnabledFor(Level.ERROR);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.log4j.Log4jLogger
 * JD-Core Version:    0.6.2
 */