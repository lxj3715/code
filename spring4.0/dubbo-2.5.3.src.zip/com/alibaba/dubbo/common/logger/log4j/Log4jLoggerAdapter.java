/*     */ package com.alibaba.dubbo.common.logger.log4j;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.LoggerAdapter;
/*     */ import java.io.File;
/*     */ import java.util.Enumeration;
/*     */ import org.apache.log4j.Appender;
/*     */ import org.apache.log4j.FileAppender;
/*     */ import org.apache.log4j.LogManager;
/*     */ 
/*     */ public class Log4jLoggerAdapter
/*     */   implements LoggerAdapter
/*     */ {
/*     */   private File file;
/*     */ 
/*     */   public Log4jLoggerAdapter()
/*     */   {
/*     */     try
/*     */     {
/*  36 */       org.apache.log4j.Logger logger = LogManager.getRootLogger();
/*  37 */       if (logger != null) {
/*  38 */         Enumeration appenders = logger.getAllAppenders();
/*  39 */         if (appenders != null)
/*  40 */           while (appenders.hasMoreElements()) {
/*  41 */             Appender appender = (Appender)appenders.nextElement();
/*  42 */             if ((appender instanceof FileAppender)) {
/*  43 */               FileAppender fileAppender = (FileAppender)appender;
/*  44 */               String filename = fileAppender.getFile();
/*  45 */               this.file = new File(filename);
/*  46 */               break;
/*     */             }
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public com.alibaba.dubbo.common.logger.Logger getLogger(Class<?> key) {
/*  56 */     return new Log4jLogger(LogManager.getLogger(key));
/*     */   }
/*     */ 
/*     */   public com.alibaba.dubbo.common.logger.Logger getLogger(String key) {
/*  60 */     return new Log4jLogger(LogManager.getLogger(key));
/*     */   }
/*     */ 
/*     */   public void setLevel(com.alibaba.dubbo.common.logger.Level level) {
/*  64 */     LogManager.getRootLogger().setLevel(toLog4jLevel(level));
/*     */   }
/*     */ 
/*     */   public com.alibaba.dubbo.common.logger.Level getLevel() {
/*  68 */     return fromLog4jLevel(LogManager.getRootLogger().getLevel());
/*     */   }
/*     */ 
/*     */   public File getFile() {
/*  72 */     return this.file;
/*     */   }
/*     */ 
/*     */   private static org.apache.log4j.Level toLog4jLevel(com.alibaba.dubbo.common.logger.Level level) {
/*  76 */     if (level == com.alibaba.dubbo.common.logger.Level.ALL)
/*  77 */       return org.apache.log4j.Level.ALL;
/*  78 */     if (level == com.alibaba.dubbo.common.logger.Level.TRACE)
/*  79 */       return org.apache.log4j.Level.TRACE;
/*  80 */     if (level == com.alibaba.dubbo.common.logger.Level.DEBUG)
/*  81 */       return org.apache.log4j.Level.DEBUG;
/*  82 */     if (level == com.alibaba.dubbo.common.logger.Level.INFO)
/*  83 */       return org.apache.log4j.Level.INFO;
/*  84 */     if (level == com.alibaba.dubbo.common.logger.Level.WARN)
/*  85 */       return org.apache.log4j.Level.WARN;
/*  86 */     if (level == com.alibaba.dubbo.common.logger.Level.ERROR) {
/*  87 */       return org.apache.log4j.Level.ERROR;
/*     */     }
/*  89 */     return org.apache.log4j.Level.OFF;
/*     */   }
/*     */ 
/*     */   private static com.alibaba.dubbo.common.logger.Level fromLog4jLevel(org.apache.log4j.Level level) {
/*  93 */     if (level == org.apache.log4j.Level.ALL)
/*  94 */       return com.alibaba.dubbo.common.logger.Level.ALL;
/*  95 */     if (level == org.apache.log4j.Level.TRACE)
/*  96 */       return com.alibaba.dubbo.common.logger.Level.TRACE;
/*  97 */     if (level == org.apache.log4j.Level.DEBUG)
/*  98 */       return com.alibaba.dubbo.common.logger.Level.DEBUG;
/*  99 */     if (level == org.apache.log4j.Level.INFO)
/* 100 */       return com.alibaba.dubbo.common.logger.Level.INFO;
/* 101 */     if (level == org.apache.log4j.Level.WARN)
/* 102 */       return com.alibaba.dubbo.common.logger.Level.WARN;
/* 103 */     if (level == org.apache.log4j.Level.ERROR) {
/* 104 */       return com.alibaba.dubbo.common.logger.Level.ERROR;
/*     */     }
/* 106 */     return com.alibaba.dubbo.common.logger.Level.OFF;
/*     */   }
/*     */ 
/*     */   public void setFile(File file)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.log4j.Log4jLoggerAdapter
 * JD-Core Version:    0.6.2
 */