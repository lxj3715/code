/*    */ package com.alibaba.dubbo.common.logger.slf4j;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Slf4jLogger
/*    */   implements com.alibaba.dubbo.common.logger.Logger, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final org.slf4j.Logger logger;
/*    */ 
/*    */   public Slf4jLogger(org.slf4j.Logger logger)
/*    */   {
/* 14 */     this.logger = logger;
/*    */   }
/*    */ 
/*    */   public void trace(String msg) {
/* 18 */     this.logger.trace(msg);
/*    */   }
/*    */ 
/*    */   public void trace(Throwable e) {
/* 22 */     this.logger.trace(e.getMessage(), e);
/*    */   }
/*    */ 
/*    */   public void trace(String msg, Throwable e) {
/* 26 */     this.logger.trace(msg, e);
/*    */   }
/*    */ 
/*    */   public void debug(String msg) {
/* 30 */     this.logger.debug(msg);
/*    */   }
/*    */ 
/*    */   public void debug(Throwable e) {
/* 34 */     this.logger.debug(e.getMessage(), e);
/*    */   }
/*    */ 
/*    */   public void debug(String msg, Throwable e) {
/* 38 */     this.logger.debug(msg, e);
/*    */   }
/*    */ 
/*    */   public void info(String msg) {
/* 42 */     this.logger.info(msg);
/*    */   }
/*    */ 
/*    */   public void info(Throwable e) {
/* 46 */     this.logger.info(e.getMessage(), e);
/*    */   }
/*    */ 
/*    */   public void info(String msg, Throwable e) {
/* 50 */     this.logger.info(msg, e);
/*    */   }
/*    */ 
/*    */   public void warn(String msg) {
/* 54 */     this.logger.warn(msg);
/*    */   }
/*    */ 
/*    */   public void warn(Throwable e) {
/* 58 */     this.logger.warn(e.getMessage(), e);
/*    */   }
/*    */ 
/*    */   public void warn(String msg, Throwable e) {
/* 62 */     this.logger.warn(msg, e);
/*    */   }
/*    */ 
/*    */   public void error(String msg) {
/* 66 */     this.logger.error(msg);
/*    */   }
/*    */ 
/*    */   public void error(Throwable e) {
/* 70 */     this.logger.error(e.getMessage(), e);
/*    */   }
/*    */ 
/*    */   public void error(String msg, Throwable e) {
/* 74 */     this.logger.error(msg, e);
/*    */   }
/*    */ 
/*    */   public boolean isTraceEnabled() {
/* 78 */     return this.logger.isTraceEnabled();
/*    */   }
/*    */ 
/*    */   public boolean isDebugEnabled() {
/* 82 */     return this.logger.isDebugEnabled();
/*    */   }
/*    */ 
/*    */   public boolean isInfoEnabled() {
/* 86 */     return this.logger.isInfoEnabled();
/*    */   }
/*    */ 
/*    */   public boolean isWarnEnabled() {
/* 90 */     return this.logger.isWarnEnabled();
/*    */   }
/*    */ 
/*    */   public boolean isErrorEnabled() {
/* 94 */     return this.logger.isErrorEnabled();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.slf4j.Slf4jLogger
 * JD-Core Version:    0.6.2
 */