/*    */ package com.alibaba.dubbo.common.logger.slf4j;
/*    */ 
/*    */ import com.alibaba.dubbo.common.logger.Level;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerAdapter;
/*    */ import java.io.File;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class Slf4jLoggerAdapter
/*    */   implements LoggerAdapter
/*    */ {
/*    */   private Level level;
/*    */   private File file;
/*    */ 
/*    */   public Logger getLogger(String key)
/*    */   {
/* 12 */     return new Slf4jLogger(LoggerFactory.getLogger(key));
/*    */   }
/*    */ 
/*    */   public Logger getLogger(Class<?> key) {
/* 16 */     return new Slf4jLogger(LoggerFactory.getLogger(key));
/*    */   }
/*    */ 
/*    */   public void setLevel(Level level)
/*    */   {
/* 24 */     this.level = level;
/*    */   }
/*    */ 
/*    */   public Level getLevel() {
/* 28 */     return this.level;
/*    */   }
/*    */ 
/*    */   public File getFile() {
/* 32 */     return this.file;
/*    */   }
/*    */ 
/*    */   public void setFile(File file) {
/* 36 */     this.file = file;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.logger.slf4j.Slf4jLoggerAdapter
 * JD-Core Version:    0.6.2
 */