package com.alibaba.dubbo.common.serialize;

import java.io.IOException;

public abstract interface DataInput
{
  public abstract boolean readBool()
    throws IOException;

  public abstract byte readByte()
    throws IOException;

  public abstract short readShort()
    throws IOException;

  public abstract int readInt()
    throws IOException;

  public abstract long readLong()
    throws IOException;

  public abstract float readFloat()
    throws IOException;

  public abstract double readDouble()
    throws IOException;

  public abstract String readUTF()
    throws IOException;

  public abstract byte[] readBytes()
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.DataInput
 * JD-Core Version:    0.6.2
 */