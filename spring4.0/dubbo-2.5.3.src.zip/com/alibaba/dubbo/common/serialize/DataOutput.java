package com.alibaba.dubbo.common.serialize;

import java.io.IOException;

public abstract interface DataOutput
{
  public abstract void writeBool(boolean paramBoolean)
    throws IOException;

  public abstract void writeByte(byte paramByte)
    throws IOException;

  public abstract void writeShort(short paramShort)
    throws IOException;

  public abstract void writeInt(int paramInt)
    throws IOException;

  public abstract void writeLong(long paramLong)
    throws IOException;

  public abstract void writeFloat(float paramFloat)
    throws IOException;

  public abstract void writeDouble(double paramDouble)
    throws IOException;

  public abstract void writeUTF(String paramString)
    throws IOException;

  public abstract void writeBytes(byte[] paramArrayOfByte)
    throws IOException;

  public abstract void writeBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract void flushBuffer()
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.DataOutput
 * JD-Core Version:    0.6.2
 */