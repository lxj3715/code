package com.alibaba.dubbo.common.serialize;

import java.io.IOException;
import java.lang.reflect.Type;

public abstract interface ObjectInput extends DataInput
{
  public abstract Object readObject()
    throws IOException, ClassNotFoundException;

  public abstract <T> T readObject(Class<T> paramClass)
    throws IOException, ClassNotFoundException;

  public abstract <T> T readObject(Class<T> paramClass, Type paramType)
    throws IOException, ClassNotFoundException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.ObjectInput
 * JD-Core Version:    0.6.2
 */