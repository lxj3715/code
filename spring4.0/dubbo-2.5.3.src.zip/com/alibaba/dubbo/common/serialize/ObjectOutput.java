package com.alibaba.dubbo.common.serialize;

import java.io.IOException;

public abstract interface ObjectOutput extends DataOutput
{
  public abstract void writeObject(Object paramObject)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.ObjectOutput
 * JD-Core Version:    0.6.2
 */