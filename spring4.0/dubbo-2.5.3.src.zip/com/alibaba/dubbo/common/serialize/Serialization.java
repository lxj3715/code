package com.alibaba.dubbo.common.serialize;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

@SPI("hessian2")
public abstract interface Serialization
{
  public abstract byte getContentTypeId();

  public abstract String getContentType();

  @Adaptive
  public abstract ObjectOutput serialize(URL paramURL, OutputStream paramOutputStream)
    throws IOException;

  @Adaptive
  public abstract ObjectInput deserialize(URL paramURL, InputStream paramInputStream)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.Serialization
 * JD-Core Version:    0.6.2
 */