/*      */ package com.alibaba.dubbo.common.serialize.support.dubbo;
/*      */ 
/*      */ import com.alibaba.dubbo.common.bytecode.ClassGenerator;
/*      */ import com.alibaba.dubbo.common.io.UnsafeByteArrayInputStream;
/*      */ import com.alibaba.dubbo.common.io.UnsafeByteArrayOutputStream;
/*      */ import com.alibaba.dubbo.common.logger.Logger;
/*      */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*      */ import com.alibaba.dubbo.common.serialize.support.java.CompactedObjectInputStream;
/*      */ import com.alibaba.dubbo.common.serialize.support.java.CompactedObjectOutputStream;
/*      */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*      */ import com.alibaba.dubbo.common.utils.IOUtils;
/*      */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*      */ import com.alibaba.dubbo.common.utils.StringUtils;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ public abstract class Builder<T>
/*      */   implements GenericDataFlags
/*      */ {
/*   64 */   protected static Logger logger = LoggerFactory.getLogger(Builder.class);
/*      */ 
/*   66 */   private static final AtomicLong BUILDER_CLASS_COUNTER = new AtomicLong(0L);
/*      */ 
/*   68 */   private static final String BUILDER_CLASS_NAME = Builder.class.getName();
/*      */ 
/*   70 */   private static final Map<Class<?>, Builder<?>> BuilderMap = new ConcurrentHashMap();
/*   71 */   private static final Map<Class<?>, Builder<?>> nonSerializableBuilderMap = new ConcurrentHashMap();
/*      */   private static final String FIELD_CONFIG_SUFFIX = ".fc";
/*      */   private static final int MAX_FIELD_CONFIG_FILE_SIZE = 16384;
/*   77 */   private static final Comparator<String> FNC = new Comparator() {
/*   78 */     public int compare(String n1, String n2) { return Builder.compareFieldName(n1, n2); }
/*      */ 
/*   77 */   };
/*      */ 
/*   81 */   private static final Comparator<Field> FC = new Comparator() {
/*   82 */     public int compare(Field f1, Field f2) { return Builder.compareFieldName(f1.getName(), f2.getName()); }
/*      */ 
/*   81 */   };
/*      */ 
/*   85 */   private static final Comparator<Constructor> CC = new Comparator() {
/*   86 */     public int compare(Constructor o1, Constructor o2) { return o1.getParameterTypes().length - o2.getParameterTypes().length; }
/*      */ 
/*   85 */   };
/*      */ 
/*   90 */   private static final List<String> mDescList = new ArrayList();
/*      */ 
/*   92 */   private static final Map<String, Integer> mDescMap = new ConcurrentHashMap();
/*      */ 
/*   94 */   public static ClassDescriptorMapper DEFAULT_CLASS_DESCRIPTOR_MAPPER = new ClassDescriptorMapper()
/*      */   {
/*      */     public String getDescriptor(int index) {
/*   97 */       if ((index < 0) || (index >= Builder.mDescList.size()))
/*   98 */         return null;
/*   99 */       return (String)Builder.mDescList.get(index);
/*      */     }
/*      */ 
/*      */     public int getDescriptorIndex(String desc)
/*      */     {
/*  104 */       Integer ret = (Integer)Builder.mDescMap.get(desc);
/*  105 */       return ret == null ? -1 : ret.intValue();
/*      */     }
/*   94 */   };
/*      */ 
/*  983 */   static final Builder<Object> GenericBuilder = new Builder() {
/*      */     public Class<Object> getType() {
/*  985 */       return Object.class;
/*      */     }
/*  987 */     public void writeTo(Object obj, GenericObjectOutput out) throws IOException { out.writeObject(obj); } 
/*      */     public Object parseFrom(GenericObjectInput in) throws IOException {
/*  989 */       return in.readObject();
/*      */     }
/*  983 */   };
/*      */ 
/*  992 */   static final Builder<Object[]> GenericArrayBuilder = new AbstractObjectBuilder() {
/*      */     public Class<Object[]> getType() {
/*  994 */       return [Ljava.lang.Object.class;
/*      */     }
/*      */ 
/*      */     protected Object[] newInstance(GenericObjectInput in) throws IOException {
/*  998 */       return new Object[in.readUInt()];
/*      */     }
/*      */ 
/*      */     protected void readObject(Object[] ret, GenericObjectInput in) throws IOException
/*      */     {
/* 1003 */       for (int i = 0; i < ret.length; i++)
/* 1004 */         ret[i] = in.readObject();
/*      */     }
/*      */ 
/*      */     protected void writeObject(Object[] obj, GenericObjectOutput out) throws IOException
/*      */     {
/* 1009 */       out.writeUInt(obj.length);
/* 1010 */       for (Object item : obj)
/* 1011 */         out.writeObject(item);
/*      */     }
/*  992 */   };
/*      */ 
/* 1015 */   static final Builder<Serializable> SerializableBuilder = new Builder()
/*      */   {
/*      */     public Class<Serializable> getType()
/*      */     {
/* 1019 */       return Serializable.class;
/*      */     }
/*      */ 
/*      */     public void writeTo(Serializable obj, GenericObjectOutput out) throws IOException
/*      */     {
/* 1024 */       if (obj == null)
/*      */       {
/* 1026 */         out.write0((byte)-108);
/*      */       }
/*      */       else
/*      */       {
/* 1030 */         out.write0((byte)-126);
/* 1031 */         UnsafeByteArrayOutputStream bos = new UnsafeByteArrayOutputStream();
/* 1032 */         CompactedObjectOutputStream oos = new CompactedObjectOutputStream(bos);
/* 1033 */         oos.writeObject(obj);
/* 1034 */         oos.flush();
/* 1035 */         bos.close();
/* 1036 */         byte[] b = bos.toByteArray();
/* 1037 */         out.writeUInt(b.length);
/* 1038 */         out.write0(b, 0, b.length);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Serializable parseFrom(GenericObjectInput in) throws IOException
/*      */     {
/* 1044 */       byte b = in.read0();
/* 1045 */       if (b == -108)
/* 1046 */         return null;
/* 1047 */       if (b != -126) {
/* 1048 */         throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_STREAM, get " + b + ".");
/*      */       }
/* 1050 */       UnsafeByteArrayInputStream bis = new UnsafeByteArrayInputStream(in.read0(in.readUInt()));
/* 1051 */       CompactedObjectInputStream ois = new CompactedObjectInputStream(bis);
/*      */       try { return (Serializable)ois.readObject(); } catch (ClassNotFoundException e) {
/* 1053 */         throw new IOException(StringUtils.toString(e));
/*      */       }
/*      */     }
/* 1015 */   };
/*      */ 
/*      */   public abstract Class<T> getType();
/*      */ 
/*      */   public void writeTo(T obj, OutputStream os)
/*      */     throws IOException
/*      */   {
/*  115 */     GenericObjectOutput out = new GenericObjectOutput(os);
/*  116 */     writeTo(obj, out);
/*  117 */     out.flushBuffer();
/*      */   }
/*      */ 
/*      */   public T parseFrom(byte[] b) throws IOException
/*      */   {
/*  122 */     return parseFrom(new UnsafeByteArrayInputStream(b));
/*      */   }
/*      */ 
/*      */   public T parseFrom(InputStream is) throws IOException
/*      */   {
/*  127 */     return parseFrom(new GenericObjectInput(is));
/*      */   }
/*      */ 
/*      */   public abstract void writeTo(T paramT, GenericObjectOutput paramGenericObjectOutput) throws IOException;
/*      */ 
/*      */   public abstract T parseFrom(GenericObjectInput paramGenericObjectInput) throws IOException;
/*      */ 
/*      */   public static <T> Builder<T> register(Class<T> c, boolean isAllowNonSerializable)
/*      */   {
/*  136 */     if ((c == Object.class) || (c.isInterface()))
/*  137 */       return GenericBuilder;
/*  138 */     if (c == [Ljava.lang.Object.class) {
/*  139 */       return GenericArrayBuilder;
/*      */     }
/*  141 */     Builder b = (Builder)BuilderMap.get(c);
/*  142 */     if (null != b) return b;
/*      */ 
/*  144 */     boolean isSerializable = Serializable.class.isAssignableFrom(c);
/*  145 */     if ((!isAllowNonSerializable) && (!isSerializable)) {
/*  146 */       throw new IllegalStateException("Serialized class " + c.getName() + " must implement java.io.Serializable (dubbo codec setting: isAllowNonSerializable = false)");
/*      */     }
/*      */ 
/*  150 */     b = (Builder)nonSerializableBuilderMap.get(c);
/*  151 */     if (null != b) return b;
/*      */ 
/*  153 */     b = newBuilder(c);
/*  154 */     if (isSerializable)
/*  155 */       BuilderMap.put(c, b);
/*      */     else {
/*  157 */       nonSerializableBuilderMap.put(c, b);
/*      */     }
/*  159 */     return b;
/*      */   }
/*      */ 
/*      */   public static <T> Builder<T> register(Class<T> c)
/*      */   {
/*  164 */     return register(c, false);
/*      */   }
/*      */ 
/*      */   public static <T> void register(Class<T> c, Builder<T> b)
/*      */   {
/*  169 */     if (Serializable.class.isAssignableFrom(c))
/*  170 */       BuilderMap.put(c, b);
/*      */     else
/*  172 */       nonSerializableBuilderMap.put(c, b);
/*      */   }
/*      */ 
/*      */   private static <T> Builder<T> newBuilder(Class<T> c)
/*      */   {
/*  177 */     if (c.isPrimitive()) {
/*  178 */       throw new RuntimeException("Can not create builder for primitive type: " + c);
/*      */     }
/*  180 */     if (logger.isInfoEnabled())
/*  181 */       logger.info("create Builder for class: " + c);
/*      */     Builder builder;
/*      */     Builder builder;
/*  184 */     if (c.isArray())
/*  185 */       builder = newArrayBuilder(c);
/*      */     else
/*  187 */       builder = newObjectBuilder(c);
/*  188 */     return builder;
/*      */   }
/*      */ 
/*      */   private static Builder<?> newArrayBuilder(Class<?> c)
/*      */   {
/*  193 */     Class cc = c.getComponentType();
/*  194 */     if (cc.isInterface()) {
/*  195 */       return GenericArrayBuilder;
/*      */     }
/*  197 */     ClassLoader cl = ClassHelper.getCallerClassLoader(Builder.class);
/*      */ 
/*  199 */     String cn = ReflectUtils.getName(c); String ccn = ReflectUtils.getName(cc);
/*  200 */     String bcn = BUILDER_CLASS_NAME + "$bc" + BUILDER_CLASS_COUNTER.getAndIncrement();
/*      */ 
/*  202 */     int ix = cn.indexOf(']');
/*  203 */     String s1 = cn.substring(0, ix); String s2 = cn.substring(ix);
/*      */ 
/*  205 */     StringBuilder cwt = new StringBuilder("public void writeTo(Object obj, ").append(GenericObjectOutput.class.getName()).append(" out) throws java.io.IOException{");
/*  206 */     StringBuilder cpf = new StringBuilder("public Object parseFrom(").append(GenericObjectInput.class.getName()).append(" in) throws java.io.IOException{");
/*      */ 
/*  208 */     cwt.append("if( $1 == null ){ $2.write0(OBJECT_NULL); return; }");
/*  209 */     cwt.append(cn).append(" v = (").append(cn).append(")$1; int len = v.length; $2.write0(OBJECT_VALUES); $2.writeUInt(len); for(int i=0;i<len;i++){ ");
/*      */ 
/*  211 */     cpf.append("byte b = $1.read0(); if( b == OBJECT_NULL ) return null; if( b != OBJECT_VALUES ) throw new java.io.IOException(\"Input format error, expect OBJECT_NULL|OBJECT_VALUES, get \" + b + \".\");");
/*  212 */     cpf.append("int len = $1.readUInt(); if( len == 0 ) return new ").append(s1).append('0').append(s2).append("; ");
/*  213 */     cpf.append(cn).append(" ret = new ").append(s1).append("len").append(s2).append("; for(int i=0;i<len;i++){ ");
/*      */ 
/*  215 */     Builder builder = null;
/*  216 */     if (cc.isPrimitive())
/*      */     {
/*  218 */       if (cc == Boolean.TYPE)
/*      */       {
/*  220 */         cwt.append("$2.writeBool(v[i]);");
/*  221 */         cpf.append("ret[i] = $1.readBool();");
/*      */       }
/*  223 */       else if (cc == Byte.TYPE)
/*      */       {
/*  225 */         cwt.append("$2.writeByte(v[i]);");
/*  226 */         cpf.append("ret[i] = $1.readByte();");
/*      */       }
/*  228 */       else if (cc == Character.TYPE)
/*      */       {
/*  230 */         cwt.append("$2.writeShort((short)v[i]);");
/*  231 */         cpf.append("ret[i] = (char)$1.readShort();");
/*      */       }
/*  233 */       else if (cc == Short.TYPE)
/*      */       {
/*  235 */         cwt.append("$2.writeShort(v[i]);");
/*  236 */         cpf.append("ret[i] = $1.readShort();");
/*      */       }
/*  238 */       else if (cc == Integer.TYPE)
/*      */       {
/*  240 */         cwt.append("$2.writeInt(v[i]);");
/*  241 */         cpf.append("ret[i] = $1.readInt();");
/*      */       }
/*  243 */       else if (cc == Long.TYPE)
/*      */       {
/*  245 */         cwt.append("$2.writeLong(v[i]);");
/*  246 */         cpf.append("ret[i] = $1.readLong();");
/*      */       }
/*  248 */       else if (cc == Float.TYPE)
/*      */       {
/*  250 */         cwt.append("$2.writeFloat(v[i]);");
/*  251 */         cpf.append("ret[i] = $1.readFloat();");
/*      */       }
/*  253 */       else if (cc == Double.TYPE)
/*      */       {
/*  255 */         cwt.append("$2.writeDouble(v[i]);");
/*  256 */         cpf.append("ret[i] = $1.readDouble();");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  261 */       builder = register(cc);
/*      */ 
/*  263 */       cwt.append("builder.writeTo(v[i], $2);");
/*  264 */       cpf.append("ret[i] = (").append(ccn).append(")builder.parseFrom($1);");
/*      */     }
/*  266 */     cwt.append(" } }");
/*  267 */     cpf.append(" } return ret; }");
/*      */ 
/*  269 */     ClassGenerator cg = ClassGenerator.newInstance(cl);
/*  270 */     cg.setClassName(bcn);
/*  271 */     cg.setSuperClass(Builder.class);
/*  272 */     cg.addDefaultConstructor();
/*  273 */     if (builder != null)
/*  274 */       cg.addField("public static " + BUILDER_CLASS_NAME + " builder;");
/*  275 */     cg.addMethod("public Class getType(){ return " + cn + ".class; }");
/*  276 */     cg.addMethod(cwt.toString());
/*  277 */     cg.addMethod(cpf.toString());
/*      */     try
/*      */     {
/*  280 */       Class wc = cg.toClass();
/*      */ 
/*  282 */       if (builder != null)
/*  283 */         wc.getField("builder").set(null, builder);
/*  284 */       return (Builder)wc.newInstance();
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/*  288 */       throw e;
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*  292 */       throw new RuntimeException(e.getMessage());
/*      */     }
/*      */     finally
/*      */     {
/*  296 */       cg.release();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Builder<?> newObjectBuilder(Class<?> c)
/*      */   {
/*  302 */     if (c.isEnum()) {
/*  303 */       return newEnumBuilder(c);
/*      */     }
/*  305 */     if (c.isAnonymousClass()) {
/*  306 */       throw new RuntimeException("Can not instantiation anonymous class: " + c);
/*      */     }
/*  308 */     if ((c.getEnclosingClass() != null) && (!Modifier.isStatic(c.getModifiers()))) {
/*  309 */       throw new RuntimeException("Can not instantiation inner and non-static class: " + c);
/*      */     }
/*  311 */     if (Throwable.class.isAssignableFrom(c)) {
/*  312 */       return SerializableBuilder;
/*      */     }
/*  314 */     ClassLoader cl = ClassHelper.getCallerClassLoader(Builder.class);
/*      */ 
/*  318 */     String cn = c.getName();
/*      */     String bcn;
/*      */     boolean isp;
/*      */     String bcn;
/*  319 */     if (c.getClassLoader() == null)
/*      */     {
/*  321 */       boolean isp = false;
/*  322 */       bcn = BUILDER_CLASS_NAME + "$bc" + BUILDER_CLASS_COUNTER.getAndIncrement();
/*      */     }
/*      */     else
/*      */     {
/*  326 */       isp = true;
/*  327 */       bcn = cn + "$bc" + BUILDER_CLASS_COUNTER.getAndIncrement();
/*      */     }
/*      */ 
/*  331 */     boolean isc = Collection.class.isAssignableFrom(c);
/*  332 */     boolean ism = (!isc) && (Map.class.isAssignableFrom(c));
/*  333 */     boolean iss = (!isc) && (!ism) && (Serializable.class.isAssignableFrom(c));
/*      */ 
/*  336 */     String[] fns = null;
/*  337 */     InputStream is = c.getResourceAsStream(c.getSimpleName() + ".fc");
/*  338 */     if (is != null)
/*      */     {
/*      */       try
/*      */       {
/*  342 */         int len = is.available();
/*  343 */         if (len > 0)
/*      */         {
/*  345 */           if (len > 16384) {
/*  346 */             throw new RuntimeException("Load [" + c.getName() + "] field-config file error: File-size too larger");
/*      */           }
/*  348 */           String[] lines = IOUtils.readLines(is);
/*  349 */           if ((lines != null) && (lines.length > 0))
/*      */           {
/*  351 */             List list = new ArrayList();
/*  352 */             for (int i = 0; i < lines.length; i++)
/*      */             {
/*  354 */               fns = lines[i].split(",");
/*  355 */               Arrays.sort(fns, FNC);
/*  356 */               for (int j = 0; j < fns.length; j++)
/*  357 */                 list.add(fns[j]);
/*      */             }
/*  359 */             fns = (String[])list.toArray(new String[0]);
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  365 */         throw new RuntimeException("Load [" + c.getName() + "] field-config file error: " + e.getMessage());
/*      */       }
/*      */       finally {
/*      */         try {
/*  369 */           is.close();
/*      */         }
/*      */         catch (IOException e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */     Field[] fs;
/*  375 */     if (fns != null)
/*      */     {
/*  377 */       Field[] fs = new Field[fns.length];
/*  378 */       for (int i = 0; i < fns.length; i++)
/*      */       {
/*  380 */         String fn = fns[i];
/*      */         try
/*      */         {
/*  383 */           Field f = c.getDeclaredField(fn);
/*  384 */           int mod = f.getModifiers();
/*  385 */           if ((Modifier.isStatic(mod)) || ((serializeIgnoreFinalModifier(c)) && (Modifier.isFinal(mod))))
/*  386 */             throw new RuntimeException("Field [" + c.getName() + "." + fn + "] is static/final field.");
/*  387 */           if (Modifier.isTransient(mod))
/*      */           {
/*  389 */             if (iss)
/*  390 */               return SerializableBuilder;
/*  391 */             throw new RuntimeException("Field [" + c.getName() + "." + fn + "] is transient field.");
/*      */           }
/*  393 */           f.setAccessible(true);
/*  394 */           fs[i] = f;
/*      */         }
/*      */         catch (SecurityException e)
/*      */         {
/*  398 */           throw new RuntimeException(e.getMessage());
/*      */         }
/*      */         catch (NoSuchFieldException e)
/*      */         {
/*  402 */           throw new RuntimeException("Field [" + c.getName() + "." + fn + "] not found.");
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  408 */       Class t = c;
/*  409 */       List fl = new ArrayList();
/*      */       do
/*      */       {
/*  412 */         fs = t.getDeclaredFields();
/*  413 */         for (Field tf : fs)
/*      */         {
/*  415 */           int mod = tf.getModifiers();
/*  416 */           if ((!Modifier.isStatic(mod)) && ((!serializeIgnoreFinalModifier(c)) || (!Modifier.isFinal(mod))) && (!tf.getName().equals("this$0")) && (Modifier.isPublic(tf.getType().getModifiers())))
/*      */           {
/*  421 */             if (Modifier.isTransient(mod))
/*      */             {
/*  423 */               if (iss)
/*  424 */                 return SerializableBuilder;
/*      */             }
/*      */             else {
/*  427 */               tf.setAccessible(true);
/*  428 */               fl.add(tf);
/*      */             }
/*      */           }
/*      */         }
/*  430 */         t = t.getSuperclass();
/*      */       }
/*  432 */       while (t != Object.class);
/*      */ 
/*  434 */       fs = (Field[])fl.toArray(new Field[0]);
/*  435 */       if (fs.length > 1) {
/*  436 */         Arrays.sort(fs, FC);
/*      */       }
/*      */     }
/*      */ 
/*  440 */     Constructor[] cs = c.getDeclaredConstructors();
/*  441 */     if (cs.length == 0)
/*      */     {
/*  443 */       Class t = c;
/*      */       do
/*      */       {
/*  446 */         t = t.getSuperclass();
/*  447 */         if (t == null)
/*  448 */           throw new RuntimeException("Can not found Constructor?");
/*  449 */         cs = c.getDeclaredConstructors();
/*      */       }
/*  451 */       while (cs.length == 0);
/*      */     }
/*  453 */     if (cs.length > 1) {
/*  454 */       Arrays.sort(cs, CC);
/*      */     }
/*      */ 
/*  457 */     StringBuilder cwf = new StringBuilder("protected void writeObject(Object obj, ").append(GenericObjectOutput.class.getName()).append(" out) throws java.io.IOException{");
/*  458 */     cwf.append(cn).append(" v = (").append(cn).append(")$1; ");
/*  459 */     cwf.append("$2.writeInt(fields.length);");
/*      */ 
/*  462 */     StringBuilder crf = new StringBuilder("protected void readObject(Object ret, ").append(GenericObjectInput.class.getName()).append(" in) throws java.io.IOException{");
/*  463 */     crf.append("int fc = $2.readInt();");
/*  464 */     crf.append("if( fc != ").append(fs.length).append(" ) throw new IllegalStateException(\"Deserialize Class [").append(cn).append("], field count not matched. Expect ").append(fs.length).append(" but get \" + fc +\".\");");
/*  465 */     crf.append(cn).append(" ret = (").append(cn).append(")$1;");
/*      */ 
/*  468 */     StringBuilder cni = new StringBuilder("protected Object newInstance(").append(GenericObjectInput.class.getName()).append(" in){ return ");
/*  469 */     Constructor con = cs[0];
/*  470 */     int mod = con.getModifiers();
/*  471 */     boolean dn = (Modifier.isPublic(mod)) || ((isp) && (!Modifier.isPrivate(mod)));
/*  472 */     if (dn)
/*      */     {
/*  474 */       cni.append("new ").append(cn).append("(");
/*      */     }
/*      */     else
/*      */     {
/*  478 */       con.setAccessible(true);
/*  479 */       cni.append("constructor.newInstance(new Object[]{");
/*      */     }
/*  481 */     Class[] pts = con.getParameterTypes();
/*  482 */     for (int i = 0; i < pts.length; i++)
/*      */     {
/*  484 */       if (i > 0)
/*  485 */         cni.append(',');
/*  486 */       cni.append(defaultArg(pts[i]));
/*      */     }
/*  488 */     if (!dn)
/*  489 */       cni.append("}");
/*  490 */     cni.append("); }");
/*      */ 
/*  493 */     Map pms = propertyMetadatas(c);
/*  494 */     List builders = new ArrayList(fs.length);
/*      */ 
/*  499 */     for (int i = 0; i < fs.length; i++)
/*      */     {
/*  501 */       Field f = fs[i];
/*  502 */       String fn = f.getName();
/*  503 */       Class ft = f.getType();
/*  504 */       String ftn = ReflectUtils.getName(ft);
/*  505 */       boolean da = (isp) && (f.getDeclaringClass() == c) && (!Modifier.isPrivate(f.getModifiers()));
/*      */       PropertyMetadata pm;
/*      */       PropertyMetadata pm;
/*  506 */       if (da)
/*      */       {
/*  508 */         pm = null;
/*      */       }
/*      */       else
/*      */       {
/*  512 */         pm = (PropertyMetadata)pms.get(fn);
/*  513 */         if ((pm != null) && ((pm.type != ft) || (pm.setter == null) || (pm.getter == null))) {
/*  514 */           pm = null;
/*      */         }
/*      */       }
/*  517 */       crf.append("if( fc == ").append(i).append(" ) return;");
/*  518 */       if (ft.isPrimitive())
/*      */       {
/*  520 */         if (ft == Boolean.TYPE)
/*      */         {
/*  522 */           if (da)
/*      */           {
/*  524 */             cwf.append("$2.writeBool(v.").append(fn).append(");");
/*  525 */             crf.append("ret.").append(fn).append(" = $2.readBool();");
/*      */           }
/*  527 */           else if (pm != null)
/*      */           {
/*  529 */             cwf.append("$2.writeBool(v.").append(pm.getter).append("());");
/*  530 */             crf.append("ret.").append(pm.setter).append("($2.readBool());");
/*      */           }
/*      */           else
/*      */           {
/*  534 */             cwf.append("$2.writeBool(((Boolean)fields[").append(i).append("].get($1)).booleanValue());");
/*  535 */             crf.append("fields[").append(i).append("].set(ret, ($w)$2.readBool());");
/*      */           }
/*      */         }
/*  538 */         else if (ft == Byte.TYPE)
/*      */         {
/*  540 */           if (da)
/*      */           {
/*  542 */             cwf.append("$2.writeByte(v.").append(fn).append(");");
/*  543 */             crf.append("ret.").append(fn).append(" = $2.readByte();");
/*      */           }
/*  545 */           else if (pm != null)
/*      */           {
/*  547 */             cwf.append("$2.writeByte(v.").append(pm.getter).append("());");
/*  548 */             crf.append("ret.").append(pm.setter).append("($2.readByte());");
/*      */           }
/*      */           else
/*      */           {
/*  552 */             cwf.append("$2.writeByte(((Byte)fields[").append(i).append("].get($1)).byteValue());");
/*  553 */             crf.append("fields[").append(i).append("].set(ret, ($w)$2.readByte());");
/*      */           }
/*      */         }
/*  556 */         else if (ft == Character.TYPE)
/*      */         {
/*  558 */           if (da)
/*      */           {
/*  560 */             cwf.append("$2.writeShort((short)v.").append(fn).append(");");
/*  561 */             crf.append("ret.").append(fn).append(" = (char)$2.readShort();");
/*      */           }
/*  563 */           else if (pm != null)
/*      */           {
/*  565 */             cwf.append("$2.writeShort((short)v.").append(pm.getter).append("());");
/*  566 */             crf.append("ret.").append(pm.setter).append("((char)$2.readShort());");
/*      */           }
/*      */           else
/*      */           {
/*  570 */             cwf.append("$2.writeShort((short)((Character)fields[").append(i).append("].get($1)).charValue());");
/*  571 */             crf.append("fields[").append(i).append("].set(ret, ($w)((char)$2.readShort()));");
/*      */           }
/*      */         }
/*  574 */         else if (ft == Short.TYPE)
/*      */         {
/*  576 */           if (da)
/*      */           {
/*  578 */             cwf.append("$2.writeShort(v.").append(fn).append(");");
/*  579 */             crf.append("ret.").append(fn).append(" = $2.readShort();");
/*      */           }
/*  581 */           else if (pm != null)
/*      */           {
/*  583 */             cwf.append("$2.writeShort(v.").append(pm.getter).append("());");
/*  584 */             crf.append("ret.").append(pm.setter).append("($2.readShort());");
/*      */           }
/*      */           else
/*      */           {
/*  588 */             cwf.append("$2.writeShort(((Short)fields[").append(i).append("].get($1)).shortValue());");
/*  589 */             crf.append("fields[").append(i).append("].set(ret, ($w)$2.readShort());");
/*      */           }
/*      */         }
/*  592 */         else if (ft == Integer.TYPE)
/*      */         {
/*  594 */           if (da)
/*      */           {
/*  596 */             cwf.append("$2.writeInt(v.").append(fn).append(");");
/*  597 */             crf.append("ret.").append(fn).append(" = $2.readInt();");
/*      */           }
/*  599 */           else if (pm != null)
/*      */           {
/*  601 */             cwf.append("$2.writeInt(v.").append(pm.getter).append("());");
/*  602 */             crf.append("ret.").append(pm.setter).append("($2.readInt());");
/*      */           }
/*      */           else
/*      */           {
/*  606 */             cwf.append("$2.writeInt(((Integer)fields[").append(i).append("].get($1)).intValue());");
/*  607 */             crf.append("fields[").append(i).append("].set(ret, ($w)$2.readInt());");
/*      */           }
/*      */         }
/*  610 */         else if (ft == Long.TYPE)
/*      */         {
/*  612 */           if (da)
/*      */           {
/*  614 */             cwf.append("$2.writeLong(v.").append(fn).append(");");
/*  615 */             crf.append("ret.").append(fn).append(" = $2.readLong();");
/*      */           }
/*  617 */           else if (pm != null)
/*      */           {
/*  619 */             cwf.append("$2.writeLong(v.").append(pm.getter).append("());");
/*  620 */             crf.append("ret.").append(pm.setter).append("($2.readLong());");
/*      */           }
/*      */           else
/*      */           {
/*  624 */             cwf.append("$2.writeLong(((Long)fields[").append(i).append("].get($1)).longValue());");
/*  625 */             crf.append("fields[").append(i).append("].set(ret, ($w)$2.readLong());");
/*      */           }
/*      */         }
/*  628 */         else if (ft == Float.TYPE)
/*      */         {
/*  630 */           if (da)
/*      */           {
/*  632 */             cwf.append("$2.writeFloat(v.").append(fn).append(");");
/*  633 */             crf.append("ret.").append(fn).append(" = $2.readFloat();");
/*      */           }
/*  635 */           else if (pm != null)
/*      */           {
/*  637 */             cwf.append("$2.writeFloat(v.").append(pm.getter).append("());");
/*  638 */             crf.append("ret.").append(pm.setter).append("($2.readFloat());");
/*      */           }
/*      */           else
/*      */           {
/*  642 */             cwf.append("$2.writeFloat(((Float)fields[").append(i).append("].get($1)).floatValue());");
/*  643 */             crf.append("fields[").append(i).append("].set(ret, ($w)$2.readFloat());");
/*      */           }
/*      */         }
/*  646 */         else if (ft == Double.TYPE)
/*      */         {
/*  648 */           if (da)
/*      */           {
/*  650 */             cwf.append("$2.writeDouble(v.").append(fn).append(");");
/*  651 */             crf.append("ret.").append(fn).append(" = $2.readDouble();");
/*      */           }
/*  653 */           else if (pm != null)
/*      */           {
/*  655 */             cwf.append("$2.writeDouble(v.").append(pm.getter).append("());");
/*  656 */             crf.append("ret.").append(pm.setter).append("($2.readDouble());");
/*      */           }
/*      */           else
/*      */           {
/*  660 */             cwf.append("$2.writeDouble(((Double)fields[").append(i).append("].get($1)).doubleValue());");
/*  661 */             crf.append("fields[").append(i).append("].set(ret, ($w)$2.readDouble());");
/*      */           }
/*      */         }
/*      */       }
/*  665 */       else if (ft == c)
/*      */       {
/*  667 */         if (da)
/*      */         {
/*  669 */           cwf.append("this.writeTo(v.").append(fn).append(", $2);");
/*  670 */           crf.append("ret.").append(fn).append(" = (").append(ftn).append(")this.parseFrom($2);");
/*      */         }
/*  672 */         else if (pm != null)
/*      */         {
/*  674 */           cwf.append("this.writeTo(v.").append(pm.getter).append("(), $2);");
/*  675 */           crf.append("ret.").append(pm.setter).append("((").append(ftn).append(")this.parseFrom($2));");
/*      */         }
/*      */         else
/*      */         {
/*  679 */           cwf.append("this.writeTo((").append(ftn).append(")fields[").append(i).append("].get($1), $2);");
/*  680 */           crf.append("fields[").append(i).append("].set(ret, this.parseFrom($2));");
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  685 */         int bc = builders.size();
/*  686 */         builders.add(register(ft));
/*      */ 
/*  688 */         if (da)
/*      */         {
/*  690 */           cwf.append("builders[").append(bc).append("].writeTo(v.").append(fn).append(", $2);");
/*  691 */           crf.append("ret.").append(fn).append(" = (").append(ftn).append(")builders[").append(bc).append("].parseFrom($2);");
/*      */         }
/*  693 */         else if (pm != null)
/*      */         {
/*  695 */           cwf.append("builders[").append(bc).append("].writeTo(v.").append(pm.getter).append("(), $2);");
/*  696 */           crf.append("ret.").append(pm.setter).append("((").append(ftn).append(")builders[").append(bc).append("].parseFrom($2));");
/*      */         }
/*      */         else
/*      */         {
/*  700 */           cwf.append("builders[").append(bc).append("].writeTo((").append(ftn).append(")fields[").append(i).append("].get($1), $2);");
/*  701 */           crf.append("fields[").append(i).append("].set(ret, builders[").append(bc).append("].parseFrom($2));");
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  707 */     crf.append("for(int i=").append(fs.length).append(";i<fc;i++) $2.skipAny();");
/*      */ 
/*  710 */     if (isc)
/*      */     {
/*  712 */       cwf.append("$2.writeInt(v.size()); for(java.util.Iterator it=v.iterator();it.hasNext();){ $2.writeObject(it.next()); }");
/*  713 */       crf.append("int len = $2.readInt(); for(int i=0;i<len;i++) ret.add($2.readObject());");
/*      */     }
/*  715 */     else if (ism)
/*      */     {
/*  717 */       cwf.append("$2.writeInt(v.size()); for(java.util.Iterator it=v.entrySet().iterator();it.hasNext();){ java.util.Map.Entry entry = (java.util.Map.Entry)it.next(); $2.writeObject(entry.getKey()); $2.writeObject(entry.getValue()); }");
/*  718 */       crf.append("int len = $2.readInt(); for(int i=0;i<len;i++) ret.put($2.readObject(), $2.readObject());");
/*      */     }
/*  720 */     cwf.append(" }");
/*  721 */     crf.append(" }");
/*      */ 
/*  723 */     ClassGenerator cg = ClassGenerator.newInstance(cl);
/*  724 */     cg.setClassName(bcn);
/*  725 */     cg.setSuperClass(AbstractObjectBuilder.class);
/*  726 */     cg.addDefaultConstructor();
/*  727 */     cg.addField("public static java.lang.reflect.Field[] fields;");
/*  728 */     cg.addField("public static " + BUILDER_CLASS_NAME + "[] builders;");
/*  729 */     if (!dn)
/*  730 */       cg.addField("public static java.lang.reflect.Constructor constructor;");
/*  731 */     cg.addMethod("public Class getType(){ return " + cn + ".class; }");
/*  732 */     cg.addMethod(cwf.toString());
/*  733 */     cg.addMethod(crf.toString());
/*  734 */     cg.addMethod(cni.toString());
/*      */     try
/*      */     {
/*  737 */       Class wc = cg.toClass();
/*      */ 
/*  739 */       wc.getField("fields").set(null, fs);
/*  740 */       wc.getField("builders").set(null, builders.toArray(new Builder[0]));
/*  741 */       if (!dn)
/*  742 */         wc.getField("constructor").set(null, con);
/*  743 */       return (Builder)wc.newInstance();
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/*  747 */       throw e;
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*  751 */       throw new RuntimeException(e.getMessage(), e);
/*      */     }
/*      */     finally
/*      */     {
/*  755 */       cg.release();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Builder<?> newEnumBuilder(Class<?> c)
/*      */   {
/*  761 */     ClassLoader cl = ClassHelper.getCallerClassLoader(Builder.class);
/*      */ 
/*  763 */     String cn = c.getName();
/*  764 */     String bcn = BUILDER_CLASS_NAME + "$bc" + BUILDER_CLASS_COUNTER.getAndIncrement();
/*      */ 
/*  766 */     StringBuilder cwt = new StringBuilder("public void writeTo(Object obj, ").append(GenericObjectOutput.class.getName()).append(" out) throws java.io.IOException{");
/*  767 */     cwt.append(cn).append(" v = (").append(cn).append(")$1;");
/*  768 */     cwt.append("if( $1 == null ){ $2.writeUTF(null); }else{ $2.writeUTF(v.name()); } }");
/*      */ 
/*  770 */     StringBuilder cpf = new StringBuilder("public Object parseFrom(").append(GenericObjectInput.class.getName()).append(" in) throws java.io.IOException{");
/*  771 */     cpf.append("String name = $1.readUTF(); if( name == null ) return null; return (").append(cn).append(")Enum.valueOf(").append(cn).append(".class, name); }");
/*      */ 
/*  773 */     ClassGenerator cg = ClassGenerator.newInstance(cl);
/*  774 */     cg.setClassName(bcn);
/*  775 */     cg.setSuperClass(Builder.class);
/*  776 */     cg.addDefaultConstructor();
/*  777 */     cg.addMethod("public Class getType(){ return " + cn + ".class; }");
/*  778 */     cg.addMethod(cwt.toString());
/*  779 */     cg.addMethod(cpf.toString());
/*      */     try
/*      */     {
/*  782 */       Class wc = cg.toClass();
/*  783 */       return (Builder)wc.newInstance();
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/*  787 */       throw e;
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*  791 */       throw new RuntimeException(e.getMessage(), e);
/*      */     }
/*      */     finally
/*      */     {
/*  795 */       cg.release();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Map<String, PropertyMetadata> propertyMetadatas(Class<?> c)
/*      */   {
/*  801 */     Map mm = new HashMap();
/*  802 */     Map ret = new HashMap();
/*      */ 
/*  805 */     for (Method m : c.getMethods())
/*      */     {
/*  807 */       if (m.getDeclaringClass() != Object.class)
/*      */       {
/*  809 */         mm.put(ReflectUtils.getDesc(m), m);
/*      */       }
/*      */     }
/*      */ 
/*  813 */     for (Map.Entry entry : mm.entrySet())
/*      */     {
/*  815 */       String desc = (String)entry.getKey();
/*  816 */       Method method = (Method)entry.getValue();
/*      */       Matcher matcher;
/*  817 */       if (((matcher = ReflectUtils.GETTER_METHOD_DESC_PATTERN.matcher(desc)).matches()) || ((matcher = ReflectUtils.IS_HAS_CAN_METHOD_DESC_PATTERN.matcher(desc)).matches()))
/*      */       {
/*  820 */         String pn = propertyName(matcher.group(1));
/*  821 */         Class pt = method.getReturnType();
/*  822 */         PropertyMetadata pm = (PropertyMetadata)ret.get(pn);
/*  823 */         if (pm == null)
/*      */         {
/*  825 */           pm = new PropertyMetadata();
/*  826 */           pm.type = pt;
/*  827 */           ret.put(pn, pm);
/*      */         }
/*      */         else
/*      */         {
/*  831 */           if (pm.type != pt)
/*      */             continue;
/*      */         }
/*  834 */         pm.getter = method.getName();
/*      */       }
/*  836 */       else if ((matcher = ReflectUtils.SETTER_METHOD_DESC_PATTERN.matcher(desc)).matches())
/*      */       {
/*  838 */         String pn = propertyName(matcher.group(1));
/*  839 */         Class pt = method.getParameterTypes()[0];
/*  840 */         PropertyMetadata pm = (PropertyMetadata)ret.get(pn);
/*  841 */         if (pm == null)
/*      */         {
/*  843 */           pm = new PropertyMetadata();
/*  844 */           pm.type = pt;
/*  845 */           ret.put(pn, pm);
/*      */         }
/*      */         else
/*      */         {
/*  849 */           if (pm.type != pt)
/*      */             continue;
/*      */         }
/*  852 */         pm.setter = method.getName();
/*      */       }
/*      */     }
/*  855 */     return ret;
/*      */   }
/*      */ 
/*      */   private static String propertyName(String s)
/*      */   {
/*  860 */     return (s.length() == 1) || (Character.isLowerCase(s.charAt(1))) ? Character.toLowerCase(s.charAt(0)) + s.substring(1) : s;
/*      */   }
/*      */ 
/*      */   private static boolean serializeIgnoreFinalModifier(Class cl)
/*      */   {
/*  870 */     return false;
/*      */   }
/*      */ 
/*      */   private static boolean isPrimitiveOrPrimitiveArray1(Class<?> cl)
/*      */   {
/*  876 */     if (cl.isPrimitive()) {
/*  877 */       return true;
/*      */     }
/*  879 */     Class clazz = cl.getClass().getComponentType();
/*  880 */     if ((clazz != null) && (clazz.isPrimitive())) {
/*  881 */       return true;
/*      */     }
/*      */ 
/*  884 */     return false;
/*      */   }
/*      */ 
/*      */   private static String defaultArg(Class<?> cl)
/*      */   {
/*  889 */     if (Boolean.TYPE == cl) return "false";
/*  890 */     if (Integer.TYPE == cl) return "0";
/*  891 */     if (Long.TYPE == cl) return "0l";
/*  892 */     if (Double.TYPE == cl) return "(double)0";
/*  893 */     if (Float.TYPE == cl) return "(float)0";
/*  894 */     if (Short.TYPE == cl) return "(short)0";
/*  895 */     if (Character.TYPE == cl) return "(char)0";
/*  896 */     if (Byte.TYPE == cl) return "(byte)0";
/*  897 */     if ([B.class == cl) return "new byte[]{0}";
/*  898 */     if (!cl.isPrimitive()) return "null";
/*  899 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   private static int compareFieldName(String n1, String n2)
/*      */   {
/*  904 */     int l = Math.min(n1.length(), n2.length());
/*  905 */     for (int i = 0; i < l; i++)
/*      */     {
/*  907 */       int t = n1.charAt(i) - n2.charAt(i);
/*  908 */       if (t != 0)
/*  909 */         return t;
/*      */     }
/*  911 */     return n1.length() - n2.length();
/*      */   }
/*      */ 
/*      */   private static void addDesc(Class<?> c)
/*      */   {
/*  916 */     String desc = ReflectUtils.getDesc(c);
/*  917 */     int index = mDescList.size();
/*  918 */     mDescList.add(desc);
/*  919 */     mDescMap.put(desc, Integer.valueOf(index));
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 1059 */     addDesc([Z.class);
/* 1060 */     addDesc([B.class);
/* 1061 */     addDesc([C.class);
/* 1062 */     addDesc([S.class);
/* 1063 */     addDesc([I.class);
/* 1064 */     addDesc([J.class);
/* 1065 */     addDesc([F.class);
/* 1066 */     addDesc([D.class);
/*      */ 
/* 1068 */     addDesc(Boolean.class);
/* 1069 */     addDesc(Byte.class);
/* 1070 */     addDesc(Character.class);
/* 1071 */     addDesc(Short.class);
/* 1072 */     addDesc(Integer.class);
/* 1073 */     addDesc(Long.class);
/* 1074 */     addDesc(Float.class);
/* 1075 */     addDesc(Double.class);
/*      */ 
/* 1077 */     addDesc(String.class);
/* 1078 */     addDesc([Ljava.lang.String.class);
/*      */ 
/* 1080 */     addDesc(ArrayList.class);
/* 1081 */     addDesc(HashMap.class);
/* 1082 */     addDesc(HashSet.class);
/* 1083 */     addDesc(java.util.Date.class);
/* 1084 */     addDesc(java.sql.Date.class);
/* 1085 */     addDesc(Time.class);
/* 1086 */     addDesc(Timestamp.class);
/* 1087 */     addDesc(LinkedList.class);
/* 1088 */     addDesc(LinkedHashMap.class);
/* 1089 */     addDesc(LinkedHashSet.class);
/*      */ 
/* 1091 */     register([B.class, new Builder() {
/*      */       public Class<byte[]> getType() {
/* 1093 */         return [B.class;
/*      */       }
/* 1095 */       public void writeTo(byte[] obj, GenericObjectOutput out) throws IOException { out.writeBytes(obj); } 
/*      */       public byte[] parseFrom(GenericObjectInput in) throws IOException {
/* 1097 */         return in.readBytes();
/*      */       }
/*      */     });
/* 1099 */     register(Boolean.class, new Builder() {
/*      */       public Class<Boolean> getType() {
/* 1101 */         return Boolean.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Boolean obj, GenericObjectOutput out) throws IOException {
/* 1105 */         if (obj == null)
/* 1106 */           out.write0((byte)24);
/* 1107 */         else if (obj.booleanValue())
/* 1108 */           out.write0((byte)26);
/*      */         else
/* 1110 */           out.write0((byte)25);
/*      */       }
/*      */ 
/*      */       public Boolean parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1115 */         byte b = in.read0();
/* 1116 */         switch (b) {
/*      */         case 24:
/* 1118 */           return null;
/*      */         case 25:
/* 1119 */           return Boolean.FALSE;
/*      */         case 26:
/* 1120 */           return Boolean.TRUE;
/* 1121 */         }throw new IOException("Input format error, expect VARINT_N1|VARINT_0|VARINT_1, get " + b + ".");
/*      */       }
/*      */     });
/* 1125 */     register(Byte.class, new Builder() {
/*      */       public Class<Byte> getType() {
/* 1127 */         return Byte.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Byte obj, GenericObjectOutput out) throws IOException {
/* 1131 */         if (obj == null)
/*      */         {
/* 1133 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1137 */           out.write0((byte)-124);
/* 1138 */           out.writeByte(obj.byteValue());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Byte parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1144 */         byte b = in.read0();
/* 1145 */         if (b == -108)
/* 1146 */           return null;
/* 1147 */         if (b != -124) {
/* 1148 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1150 */         return Byte.valueOf(in.readByte());
/*      */       }
/*      */     });
/* 1153 */     register(Character.class, new Builder() {
/*      */       public Class<Character> getType() {
/* 1155 */         return Character.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Character obj, GenericObjectOutput out) throws IOException {
/* 1159 */         if (obj == null)
/*      */         {
/* 1161 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1165 */           out.write0((byte)-124);
/* 1166 */           out.writeShort((short)obj.charValue());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Character parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1172 */         byte b = in.read0();
/* 1173 */         if (b == -108)
/* 1174 */           return null;
/* 1175 */         if (b != -124) {
/* 1176 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1178 */         return Character.valueOf((char)in.readShort());
/*      */       }
/*      */     });
/* 1181 */     register(Short.class, new Builder() {
/*      */       public Class<Short> getType() {
/* 1183 */         return Short.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Short obj, GenericObjectOutput out) throws IOException {
/* 1187 */         if (obj == null)
/*      */         {
/* 1189 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1193 */           out.write0((byte)-124);
/* 1194 */           out.writeShort(obj.shortValue());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Short parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1200 */         byte b = in.read0();
/* 1201 */         if (b == -108)
/* 1202 */           return null;
/* 1203 */         if (b != -124) {
/* 1204 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1206 */         return Short.valueOf(in.readShort());
/*      */       }
/*      */     });
/* 1209 */     register(Integer.class, new Builder() {
/*      */       public Class<Integer> getType() {
/* 1211 */         return Integer.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Integer obj, GenericObjectOutput out) throws IOException {
/* 1215 */         if (obj == null)
/*      */         {
/* 1217 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1221 */           out.write0((byte)-124);
/* 1222 */           out.writeInt(obj.intValue());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Integer parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1228 */         byte b = in.read0();
/* 1229 */         if (b == -108)
/* 1230 */           return null;
/* 1231 */         if (b != -124) {
/* 1232 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1234 */         return Integer.valueOf(in.readInt());
/*      */       }
/*      */     });
/* 1237 */     register(Long.class, new Builder() {
/*      */       public Class<Long> getType() {
/* 1239 */         return Long.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Long obj, GenericObjectOutput out) throws IOException {
/* 1243 */         if (obj == null)
/*      */         {
/* 1245 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1249 */           out.write0((byte)-124);
/* 1250 */           out.writeLong(obj.longValue());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Long parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1256 */         byte b = in.read0();
/* 1257 */         if (b == -108)
/* 1258 */           return null;
/* 1259 */         if (b != -124) {
/* 1260 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1262 */         return Long.valueOf(in.readLong());
/*      */       }
/*      */     });
/* 1265 */     register(Float.class, new Builder() {
/*      */       public Class<Float> getType() {
/* 1267 */         return Float.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Float obj, GenericObjectOutput out) throws IOException {
/* 1271 */         if (obj == null)
/*      */         {
/* 1273 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1277 */           out.write0((byte)-124);
/* 1278 */           out.writeFloat(obj.floatValue());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Float parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1284 */         byte b = in.read0();
/* 1285 */         if (b == -108)
/* 1286 */           return null;
/* 1287 */         if (b != -124) {
/* 1288 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1290 */         return new Float(in.readFloat());
/*      */       }
/*      */     });
/* 1293 */     register(Double.class, new Builder() {
/*      */       public Class<Double> getType() {
/* 1295 */         return Double.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Double obj, GenericObjectOutput out) throws IOException {
/* 1299 */         if (obj == null)
/*      */         {
/* 1301 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1305 */           out.write0((byte)-124);
/* 1306 */           out.writeDouble(obj.doubleValue());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Double parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1312 */         byte b = in.read0();
/* 1313 */         if (b == -108)
/* 1314 */           return null;
/* 1315 */         if (b != -124) {
/* 1316 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1318 */         return new Double(in.readDouble());
/*      */       }
/*      */     });
/* 1321 */     register(String.class, new Builder() {
/*      */       public Class<String> getType() {
/* 1323 */         return String.class;
/*      */       }
/* 1325 */       public String parseFrom(GenericObjectInput in) throws IOException { return in.readUTF(); } 
/*      */       public void writeTo(String obj, GenericObjectOutput out) throws IOException {
/* 1327 */         out.writeUTF(obj);
/*      */       }
/*      */     });
/* 1329 */     register(StringBuilder.class, new Builder() {
/*      */       public Class<StringBuilder> getType() {
/* 1331 */         return StringBuilder.class;
/*      */       }
/* 1333 */       public StringBuilder parseFrom(GenericObjectInput in) throws IOException { return new StringBuilder(in.readUTF()); } 
/*      */       public void writeTo(StringBuilder obj, GenericObjectOutput out) throws IOException {
/* 1335 */         out.writeUTF(obj.toString());
/*      */       }
/*      */     });
/* 1337 */     register(StringBuffer.class, new Builder() {
/*      */       public Class<StringBuffer> getType() {
/* 1339 */         return StringBuffer.class;
/*      */       }
/* 1341 */       public StringBuffer parseFrom(GenericObjectInput in) throws IOException { return new StringBuffer(in.readUTF()); } 
/*      */       public void writeTo(StringBuffer obj, GenericObjectOutput out) throws IOException {
/* 1343 */         out.writeUTF(obj.toString());
/*      */       }
/*      */     });
/* 1347 */     register(ArrayList.class, new Builder() {
/*      */       public Class<ArrayList> getType() {
/* 1349 */         return ArrayList.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(ArrayList obj, GenericObjectOutput out)
/*      */         throws IOException
/*      */       {
/*      */         Iterator i$;
/* 1353 */         if (obj == null)
/*      */         {
/* 1355 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1359 */           out.write0((byte)-123);
/* 1360 */           out.writeUInt(obj.size());
/* 1361 */           for (i$ = obj.iterator(); i$.hasNext(); ) { Object item = i$.next();
/* 1362 */             out.writeObject(item); }
/*      */         }
/*      */       }
/*      */ 
/*      */       public ArrayList parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1368 */         byte b = in.read0();
/* 1369 */         if (b == -108)
/* 1370 */           return null;
/* 1371 */         if (b != -123) {
/* 1372 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUES, get " + b + ".");
/*      */         }
/* 1374 */         int len = in.readUInt();
/* 1375 */         ArrayList ret = new ArrayList(len);
/* 1376 */         for (int i = 0; i < len; i++)
/* 1377 */           ret.add(in.readObject());
/* 1378 */         return ret;
/*      */       }
/*      */     });
/* 1381 */     register(HashMap.class, new Builder() {
/*      */       public Class<HashMap> getType() {
/* 1383 */         return HashMap.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(HashMap obj, GenericObjectOutput out) throws IOException {
/* 1387 */         if (obj == null)
/*      */         {
/* 1389 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1393 */           out.write0((byte)-122);
/* 1394 */           out.writeUInt(obj.size());
/* 1395 */           for (Map.Entry entry : obj.entrySet())
/*      */           {
/* 1397 */             out.writeObject(entry.getKey());
/* 1398 */             out.writeObject(entry.getValue());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public HashMap parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1405 */         byte b = in.read0();
/* 1406 */         if (b == -108)
/* 1407 */           return null;
/* 1408 */         if (b != -122) {
/* 1409 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_MAP, get " + b + ".");
/*      */         }
/* 1411 */         int len = in.readUInt();
/* 1412 */         HashMap ret = new HashMap(len);
/* 1413 */         for (int i = 0; i < len; i++)
/* 1414 */           ret.put(in.readObject(), in.readObject());
/* 1415 */         return ret;
/*      */       }
/*      */     });
/* 1418 */     register(HashSet.class, new Builder() {
/*      */       public Class<HashSet> getType() {
/* 1420 */         return HashSet.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(HashSet obj, GenericObjectOutput out)
/*      */         throws IOException
/*      */       {
/*      */         Iterator i$;
/* 1424 */         if (obj == null)
/*      */         {
/* 1426 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1430 */           out.write0((byte)-123);
/* 1431 */           out.writeUInt(obj.size());
/* 1432 */           for (i$ = obj.iterator(); i$.hasNext(); ) { Object item = i$.next();
/* 1433 */             out.writeObject(item); }
/*      */         }
/*      */       }
/*      */ 
/*      */       public HashSet parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1439 */         byte b = in.read0();
/* 1440 */         if (b == -108)
/* 1441 */           return null;
/* 1442 */         if (b != -123) {
/* 1443 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUES, get " + b + ".");
/*      */         }
/* 1445 */         int len = in.readUInt();
/* 1446 */         HashSet ret = new HashSet(len);
/* 1447 */         for (int i = 0; i < len; i++)
/* 1448 */           ret.add(in.readObject());
/* 1449 */         return ret;
/*      */       }
/*      */     });
/* 1453 */     register(java.util.Date.class, new Builder() {
/*      */       public Class<java.util.Date> getType() {
/* 1455 */         return java.util.Date.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(java.util.Date obj, GenericObjectOutput out) throws IOException {
/* 1459 */         if (obj == null)
/*      */         {
/* 1461 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1465 */           out.write0((byte)-124);
/* 1466 */           out.writeLong(obj.getTime());
/*      */         }
/*      */       }
/*      */ 
/*      */       public java.util.Date parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1472 */         byte b = in.read0();
/* 1473 */         if (b == -108)
/* 1474 */           return null;
/* 1475 */         if (b != -124) {
/* 1476 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1478 */         return new java.util.Date(in.readLong());
/*      */       }
/*      */     });
/* 1483 */     register(java.sql.Date.class, new Builder() {
/*      */       public Class<java.sql.Date> getType() {
/* 1485 */         return java.sql.Date.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(java.sql.Date obj, GenericObjectOutput out) throws IOException {
/* 1489 */         if (obj == null)
/*      */         {
/* 1491 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1495 */           out.write0((byte)-124);
/* 1496 */           out.writeLong(obj.getTime());
/*      */         }
/*      */       }
/*      */ 
/*      */       public java.sql.Date parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1502 */         byte b = in.read0();
/* 1503 */         if (b == -108)
/* 1504 */           return null;
/* 1505 */         if (b != -124) {
/* 1506 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1508 */         return new java.sql.Date(in.readLong());
/*      */       }
/*      */     });
/* 1511 */     register(Timestamp.class, new Builder() {
/*      */       public Class<Timestamp> getType() {
/* 1513 */         return Timestamp.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Timestamp obj, GenericObjectOutput out) throws IOException {
/* 1517 */         if (obj == null)
/*      */         {
/* 1519 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1523 */           out.write0((byte)-124);
/* 1524 */           out.writeLong(obj.getTime());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Timestamp parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1530 */         byte b = in.read0();
/* 1531 */         if (b == -108)
/* 1532 */           return null;
/* 1533 */         if (b != -124) {
/* 1534 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1536 */         return new Timestamp(in.readLong());
/*      */       }
/*      */     });
/* 1539 */     register(Time.class, new Builder() {
/*      */       public Class<Time> getType() {
/* 1541 */         return Time.class;
/*      */       }
/*      */ 
/*      */       public void writeTo(Time obj, GenericObjectOutput out) throws IOException {
/* 1545 */         if (obj == null)
/*      */         {
/* 1547 */           out.write0((byte)-108);
/*      */         }
/*      */         else
/*      */         {
/* 1551 */           out.write0((byte)-124);
/* 1552 */           out.writeLong(obj.getTime());
/*      */         }
/*      */       }
/*      */ 
/*      */       public Time parseFrom(GenericObjectInput in) throws IOException
/*      */       {
/* 1558 */         byte b = in.read0();
/* 1559 */         if (b == -108)
/* 1560 */           return null;
/* 1561 */         if (b != -124) {
/* 1562 */           throw new IOException("Input format error, expect OBJECT_NULL|OBJECT_VALUE, get " + b + ".");
/*      */         }
/* 1564 */         return new Time(in.readLong());
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static abstract class AbstractObjectBuilder<T> extends Builder<T>
/*      */   {
/*      */     public abstract Class<T> getType();
/*      */ 
/*      */     public void writeTo(T obj, GenericObjectOutput out)
/*      */       throws IOException
/*      */     {
/*  934 */       if (obj == null)
/*      */       {
/*  936 */         out.write0((byte)-108);
/*      */       }
/*      */       else
/*      */       {
/*  940 */         int ref = out.getRef(obj);
/*  941 */         if (ref < 0)
/*      */         {
/*  943 */           out.addRef(obj);
/*  944 */           out.write0((byte)-128);
/*  945 */           writeObject(obj, out);
/*      */         }
/*      */         else
/*      */         {
/*  949 */           out.write0((byte)-127);
/*  950 */           out.writeUInt(ref);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public T parseFrom(GenericObjectInput in) throws IOException
/*      */     {
/*  957 */       byte b = in.read0();
/*  958 */       switch (b)
/*      */       {
/*      */       case -128:
/*  962 */         Object ret = newInstance(in);
/*  963 */         in.addRef(ret);
/*  964 */         readObject(ret, in);
/*  965 */         return ret;
/*      */       case -127:
/*  968 */         return in.getRef(in.readUInt());
/*      */       case -108:
/*  970 */         return null;
/*      */       }
/*  972 */       throw new IOException("Input format error, expect OBJECT|OBJECT_REF|OBJECT_NULL, get " + b);
/*      */     }
/*      */ 
/*      */     protected abstract void writeObject(T paramT, GenericObjectOutput paramGenericObjectOutput)
/*      */       throws IOException;
/*      */ 
/*      */     protected abstract T newInstance(GenericObjectInput paramGenericObjectInput)
/*      */       throws IOException;
/*      */ 
/*      */     protected abstract void readObject(T paramT, GenericObjectInput paramGenericObjectInput)
/*      */       throws IOException;
/*      */   }
/*      */ 
/*      */   static class PropertyMetadata
/*      */   {
/*      */     Class<?> type;
/*      */     String setter;
/*      */     String getter;
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.dubbo.Builder
 * JD-Core Version:    0.6.2
 */