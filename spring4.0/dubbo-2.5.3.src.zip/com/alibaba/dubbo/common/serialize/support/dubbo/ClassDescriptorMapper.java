package com.alibaba.dubbo.common.serialize.support.dubbo;

public abstract interface ClassDescriptorMapper
{
  public abstract String getDescriptor(int paramInt);

  public abstract int getDescriptorIndex(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.dubbo.ClassDescriptorMapper
 * JD-Core Version:    0.6.2
 */