/*    */ package com.alibaba.dubbo.common.serialize.support.dubbo;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*    */ import com.alibaba.dubbo.common.serialize.Serialization;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class DubboSerialization
/*    */   implements Serialization
/*    */ {
/*    */   public byte getContentTypeId()
/*    */   {
/* 33 */     return 1;
/*    */   }
/*    */ 
/*    */   public String getContentType() {
/* 37 */     return "x-application/dubbo";
/*    */   }
/*    */ 
/*    */   public ObjectOutput serialize(URL url, OutputStream out) throws IOException {
/* 41 */     return new GenericObjectOutput(out);
/*    */   }
/*    */ 
/*    */   public ObjectInput deserialize(URL url, InputStream is) throws IOException {
/* 45 */     return new GenericObjectInput(is);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.dubbo.DubboSerialization
 * JD-Core Version:    0.6.2
 */