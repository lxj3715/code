/*     */ package com.alibaba.dubbo.common.serialize.support.dubbo;
/*     */ 
/*     */ import com.alibaba.dubbo.common.serialize.DataInput;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UTFDataFormatException;
/*     */ 
/*     */ public class GenericDataInput
/*     */   implements DataInput, GenericDataFlags
/*     */ {
/*     */   private static final String EMPTY_STRING = "";
/*  36 */   private static final byte[] EMPTY_BYTES = new byte[0];
/*     */   private final InputStream mInput;
/*     */   private final byte[] mBuffer;
/*  42 */   private int mRead = 0;
/*     */ 
/*  44 */   private int mPosition = 0;
/*     */ 
/*     */   public GenericDataInput(InputStream is)
/*     */   {
/*  48 */     this(is, 1024);
/*     */   }
/*     */ 
/*     */   public GenericDataInput(InputStream is, int buffSize)
/*     */   {
/*  53 */     this.mInput = is;
/*  54 */     this.mBuffer = new byte[buffSize];
/*     */   }
/*     */ 
/*     */   public boolean readBool() throws IOException
/*     */   {
/*  59 */     byte b = read0();
/*     */ 
/*  61 */     switch (b) {
/*     */     case 25:
/*  63 */       return false;
/*     */     case 26:
/*  64 */       return true;
/*     */     }
/*  66 */     throw new IOException("Tag error, expect BYTE_TRUE|BYTE_FALSE, but get " + b);
/*     */   }
/*     */ 
/*     */   public byte readByte()
/*     */     throws IOException
/*     */   {
/*  72 */     byte b = read0();
/*     */ 
/*  74 */     switch (b)
/*     */     {
/*     */     case 0:
/*  77 */       return read0();
/*     */     case 25:
/*  78 */       return 0;
/*     */     case 26:
/*  78 */       return 1;
/*     */     case 27:
/*  78 */       return 2;
/*     */     case 28:
/*  78 */       return 3;
/*     */     case 29:
/*  79 */       return 4;
/*     */     case 30:
/*  79 */       return 5;
/*     */     case 31:
/*  79 */       return 6;
/*     */     case 32:
/*  79 */       return 7;
/*     */     case 33:
/*  80 */       return 8;
/*     */     case 34:
/*  80 */       return 9;
/*     */     case 35:
/*  80 */       return 10;
/*     */     case 36:
/*  80 */       return 11;
/*     */     case 37:
/*  81 */       return 12;
/*     */     case 38:
/*  81 */       return 13;
/*     */     case 39:
/*  81 */       return 14;
/*     */     case 40:
/*  81 */       return 15;
/*     */     case 41:
/*  82 */       return 16;
/*     */     case 42:
/*  82 */       return 17;
/*     */     case 43:
/*  82 */       return 18;
/*     */     case 44:
/*  82 */       return 19;
/*     */     case 45:
/*  83 */       return 20;
/*     */     case 46:
/*  83 */       return 21;
/*     */     case 47:
/*  83 */       return 22;
/*     */     case 48:
/*  83 */       return 23;
/*     */     case 49:
/*  84 */       return 24;
/*     */     case 50:
/*  84 */       return 25;
/*     */     case 51:
/*  84 */       return 26;
/*     */     case 52:
/*  84 */       return 27;
/*     */     case 53:
/*  85 */       return 28;
/*     */     case 54:
/*  85 */       return 29;
/*     */     case 55:
/*  85 */       return 30;
/*     */     case 56:
/*  85 */       return 31;
/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 13:
/*     */     case 14:
/*     */     case 15:
/*     */     case 16:
/*     */     case 17:
/*     */     case 18:
/*     */     case 19:
/*     */     case 20:
/*     */     case 21:
/*     */     case 22:
/*     */     case 23:
/*  87 */     case 24: } throw new IOException("Tag error, expect VARINT, but get " + b);
/*     */   }
/*     */ 
/*     */   public short readShort()
/*     */     throws IOException
/*     */   {
/*  93 */     return (short)readVarint32();
/*     */   }
/*     */ 
/*     */   public int readInt() throws IOException
/*     */   {
/*  98 */     return readVarint32();
/*     */   }
/*     */ 
/*     */   public long readLong() throws IOException
/*     */   {
/* 103 */     return readVarint64();
/*     */   }
/*     */ 
/*     */   public float readFloat() throws IOException
/*     */   {
/* 108 */     return Float.intBitsToFloat(readVarint32());
/*     */   }
/*     */ 
/*     */   public double readDouble() throws IOException
/*     */   {
/* 113 */     return Double.longBitsToDouble(readVarint64());
/*     */   }
/*     */ 
/*     */   public String readUTF() throws IOException
/*     */   {
/* 118 */     byte b = read0();
/*     */ 
/* 120 */     switch (b)
/*     */     {
/*     */     case -125:
/* 123 */       int len = readUInt();
/* 124 */       StringBuilder sb = new StringBuilder();
/*     */ 
/* 126 */       for (int i = 0; i < len; i++)
/*     */       {
/* 128 */         byte b1 = read0();
/* 129 */         if ((b1 & 0x80) == 0)
/*     */         {
/* 131 */           sb.append((char)b1);
/*     */         }
/* 133 */         else if ((b1 & 0xE0) == 192)
/*     */         {
/* 135 */           byte b2 = read0();
/* 136 */           sb.append((char)((b1 & 0x1F) << 6 | b2 & 0x3F));
/*     */         }
/* 138 */         else if ((b1 & 0xF0) == 224)
/*     */         {
/* 140 */           byte b2 = read0(); byte b3 = read0();
/* 141 */           sb.append((char)((b1 & 0xF) << 12 | (b2 & 0x3F) << 6 | b3 & 0x3F));
/*     */         }
/*     */         else {
/* 144 */           throw new UTFDataFormatException("Bad utf-8 encoding at " + b1);
/*     */         }
/*     */       }
/* 146 */       return sb.toString();
/*     */     case -108:
/* 147 */       return null;
/*     */     case -107:
/* 148 */       return "";
/*     */     }
/* 150 */     throw new IOException("Tag error, expect BYTES|BYTES_NULL|BYTES_EMPTY, but get " + b);
/*     */   }
/*     */ 
/*     */   public byte[] readBytes()
/*     */     throws IOException
/*     */   {
/* 156 */     byte b = read0();
/*     */ 
/* 158 */     switch (b) {
/*     */     case -125:
/* 160 */       return read0(readUInt());
/*     */     case -108:
/* 161 */       return null;
/*     */     case -107:
/* 162 */       return EMPTY_BYTES;
/*     */     }
/* 164 */     throw new IOException("Tag error, expect BYTES|BYTES_NULL|BYTES_EMPTY, but get " + b);
/*     */   }
/*     */ 
/*     */   public int readUInt()
/*     */     throws IOException
/*     */   {
/* 170 */     byte tmp = read0();
/* 171 */     if (tmp < 0) {
/* 172 */       return tmp & 0x7F;
/*     */     }
/* 174 */     int ret = tmp & 0x7F;
/* 175 */     if ((tmp = read0()) < 0)
/*     */     {
/* 177 */       ret |= (tmp & 0x7F) << 7;
/*     */     }
/*     */     else
/*     */     {
/* 181 */       ret |= tmp << 7;
/* 182 */       if ((tmp = read0()) < 0)
/*     */       {
/* 184 */         ret |= (tmp & 0x7F) << 14;
/*     */       }
/*     */       else
/*     */       {
/* 188 */         ret |= tmp << 14;
/* 189 */         if ((tmp = read0()) < 0)
/*     */         {
/* 191 */           ret |= (tmp & 0x7F) << 21;
/*     */         }
/*     */         else
/*     */         {
/* 195 */           ret |= tmp << 21;
/* 196 */           ret |= (read0() & 0x7F) << 28;
/*     */         }
/*     */       }
/*     */     }
/* 200 */     return ret;
/*     */   }
/*     */ 
/*     */   protected byte read0() throws IOException
/*     */   {
/* 205 */     if (this.mPosition == this.mRead) {
/* 206 */       fillBuffer();
/*     */     }
/* 208 */     return this.mBuffer[(this.mPosition++)];
/*     */   }
/*     */ 
/*     */   protected byte[] read0(int len) throws IOException
/*     */   {
/* 213 */     int rem = this.mRead - this.mPosition;
/* 214 */     byte[] ret = new byte[len];
/* 215 */     if (len <= rem)
/*     */     {
/* 217 */       System.arraycopy(this.mBuffer, this.mPosition, ret, 0, len);
/* 218 */       this.mPosition += len;
/*     */     }
/*     */     else
/*     */     {
/* 222 */       System.arraycopy(this.mBuffer, this.mPosition, ret, 0, rem);
/* 223 */       this.mPosition = this.mRead;
/*     */ 
/* 225 */       len -= rem;
/* 226 */       int pos = rem;
/*     */ 
/* 228 */       while (len > 0)
/*     */       {
/* 230 */         int read = this.mInput.read(ret, pos, len);
/* 231 */         if (read == -1)
/* 232 */           throw new EOFException();
/* 233 */         pos += read;
/* 234 */         len -= read;
/*     */       }
/*     */     }
/* 237 */     return ret;
/*     */   }
/*     */ 
/*     */   private int readVarint32() throws IOException
/*     */   {
/* 242 */     byte b = read0();
/*     */ 
/* 244 */     switch (b)
/*     */     {
/*     */     case 0:
/* 247 */       return read0();
/*     */     case 1:
/* 250 */       byte b1 = read0(); byte b2 = read0();
/* 251 */       return (short)(b1 & 0xFF | (b2 & 0xFF) << 8);
/*     */     case 2:
/* 255 */       byte b1 = read0(); byte b2 = read0(); byte b3 = read0();
/* 256 */       int ret = b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16;
/* 257 */       if (b3 < 0)
/* 258 */         return ret | 0xFF000000;
/* 259 */       return ret;
/*     */     case 3:
/* 263 */       byte b1 = read0(); byte b2 = read0(); byte b3 = read0(); byte b4 = read0();
/* 264 */       return b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24;
/*     */     case 10:
/* 269 */       return -15;
/*     */     case 11:
/* 269 */       return -14;
/*     */     case 12:
/* 269 */       return -13;
/*     */     case 13:
/* 270 */       return -12;
/*     */     case 14:
/* 270 */       return -11;
/*     */     case 15:
/* 270 */       return -10;
/*     */     case 16:
/* 270 */       return -9;
/*     */     case 17:
/* 271 */       return -8;
/*     */     case 18:
/* 271 */       return -7;
/*     */     case 19:
/* 271 */       return -6;
/*     */     case 20:
/* 271 */       return -5;
/*     */     case 21:
/* 272 */       return -4;
/*     */     case 22:
/* 272 */       return -3;
/*     */     case 23:
/* 272 */       return -2;
/*     */     case 24:
/* 272 */       return -1;
/*     */     case 25:
/* 273 */       return 0;
/*     */     case 26:
/* 273 */       return 1;
/*     */     case 27:
/* 273 */       return 2;
/*     */     case 28:
/* 273 */       return 3;
/*     */     case 29:
/* 274 */       return 4;
/*     */     case 30:
/* 274 */       return 5;
/*     */     case 31:
/* 274 */       return 6;
/*     */     case 32:
/* 274 */       return 7;
/*     */     case 33:
/* 275 */       return 8;
/*     */     case 34:
/* 275 */       return 9;
/*     */     case 35:
/* 275 */       return 10;
/*     */     case 36:
/* 275 */       return 11;
/*     */     case 37:
/* 276 */       return 12;
/*     */     case 38:
/* 276 */       return 13;
/*     */     case 39:
/* 276 */       return 14;
/*     */     case 40:
/* 276 */       return 15;
/*     */     case 41:
/* 277 */       return 16;
/*     */     case 42:
/* 277 */       return 17;
/*     */     case 43:
/* 277 */       return 18;
/*     */     case 44:
/* 277 */       return 19;
/*     */     case 45:
/* 278 */       return 20;
/*     */     case 46:
/* 278 */       return 21;
/*     */     case 47:
/* 278 */       return 22;
/*     */     case 48:
/* 278 */       return 23;
/*     */     case 49:
/* 279 */       return 24;
/*     */     case 50:
/* 279 */       return 25;
/*     */     case 51:
/* 279 */       return 26;
/*     */     case 52:
/* 279 */       return 27;
/*     */     case 53:
/* 280 */       return 28;
/*     */     case 54:
/* 280 */       return 29;
/*     */     case 55:
/* 280 */       return 30;
/*     */     case 56:
/* 280 */       return 31;
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/* 282 */     case 9: } throw new IOException("Tag error, expect VARINT, but get " + b);
/*     */   }
/*     */ 
/*     */   private long readVarint64()
/*     */     throws IOException
/*     */   {
/* 288 */     byte b = read0();
/*     */ 
/* 290 */     switch (b)
/*     */     {
/*     */     case 0:
/* 293 */       return read0();
/*     */     case 1:
/* 296 */       byte b1 = read0(); byte b2 = read0();
/* 297 */       return (short)(b1 & 0xFF | (b2 & 0xFF) << 8);
/*     */     case 2:
/* 301 */       byte b1 = read0(); byte b2 = read0(); byte b3 = read0();
/* 302 */       int ret = b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16;
/* 303 */       if (b3 < 0)
/* 304 */         return ret | 0xFF000000;
/* 305 */       return ret;
/*     */     case 3:
/* 309 */       byte b1 = read0(); byte b2 = read0(); byte b3 = read0(); byte b4 = read0();
/* 310 */       return b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24;
/*     */     case 4:
/* 317 */       byte b1 = read0(); byte b2 = read0(); byte b3 = read0(); byte b4 = read0(); byte b5 = read0();
/* 318 */       long ret = b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24 | (b5 & 0xFF) << 32;
/*     */ 
/* 323 */       if (b5 < 0)
/* 324 */         return ret | 0x0;
/* 325 */       return ret;
/*     */     case 5:
/* 329 */       byte b1 = read0(); byte b2 = read0(); byte b3 = read0(); byte b4 = read0(); byte b5 = read0(); byte b6 = read0();
/* 330 */       long ret = b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24 | (b5 & 0xFF) << 32 | (b6 & 0xFF) << 40;
/*     */ 
/* 336 */       if (b6 < 0)
/* 337 */         return ret | 0x0;
/* 338 */       return ret;
/*     */     case 6:
/* 342 */       byte b1 = read0(); byte b2 = read0(); byte b3 = read0(); byte b4 = read0(); byte b5 = read0(); byte b6 = read0(); byte b7 = read0();
/* 343 */       long ret = b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24 | (b5 & 0xFF) << 32 | (b6 & 0xFF) << 40 | (b7 & 0xFF) << 48;
/*     */ 
/* 350 */       if (b7 < 0)
/* 351 */         return ret | 0x0;
/* 352 */       return ret;
/*     */     case 7:
/* 356 */       byte b1 = read0(); byte b2 = read0(); byte b3 = read0(); byte b4 = read0();
/* 357 */       byte b5 = read0(); byte b6 = read0(); byte b7 = read0(); byte b8 = read0();
/* 358 */       return b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24 | (b5 & 0xFF) << 32 | (b6 & 0xFF) << 40 | (b7 & 0xFF) << 48 | (b8 & 0xFF) << 56;
/*     */     case 10:
/* 367 */       return -15L;
/*     */     case 11:
/* 367 */       return -14L;
/*     */     case 12:
/* 367 */       return -13L;
/*     */     case 13:
/* 368 */       return -12L;
/*     */     case 14:
/* 368 */       return -11L;
/*     */     case 15:
/* 368 */       return -10L;
/*     */     case 16:
/* 368 */       return -9L;
/*     */     case 17:
/* 369 */       return -8L;
/*     */     case 18:
/* 369 */       return -7L;
/*     */     case 19:
/* 369 */       return -6L;
/*     */     case 20:
/* 369 */       return -5L;
/*     */     case 21:
/* 370 */       return -4L;
/*     */     case 22:
/* 370 */       return -3L;
/*     */     case 23:
/* 370 */       return -2L;
/*     */     case 24:
/* 370 */       return -1L;
/*     */     case 25:
/* 371 */       return 0L;
/*     */     case 26:
/* 371 */       return 1L;
/*     */     case 27:
/* 371 */       return 2L;
/*     */     case 28:
/* 371 */       return 3L;
/*     */     case 29:
/* 372 */       return 4L;
/*     */     case 30:
/* 372 */       return 5L;
/*     */     case 31:
/* 372 */       return 6L;
/*     */     case 32:
/* 372 */       return 7L;
/*     */     case 33:
/* 373 */       return 8L;
/*     */     case 34:
/* 373 */       return 9L;
/*     */     case 35:
/* 373 */       return 10L;
/*     */     case 36:
/* 373 */       return 11L;
/*     */     case 37:
/* 374 */       return 12L;
/*     */     case 38:
/* 374 */       return 13L;
/*     */     case 39:
/* 374 */       return 14L;
/*     */     case 40:
/* 374 */       return 15L;
/*     */     case 41:
/* 375 */       return 16L;
/*     */     case 42:
/* 375 */       return 17L;
/*     */     case 43:
/* 375 */       return 18L;
/*     */     case 44:
/* 375 */       return 19L;
/*     */     case 45:
/* 376 */       return 20L;
/*     */     case 46:
/* 376 */       return 21L;
/*     */     case 47:
/* 376 */       return 22L;
/*     */     case 48:
/* 376 */       return 23L;
/*     */     case 49:
/* 377 */       return 24L;
/*     */     case 50:
/* 377 */       return 25L;
/*     */     case 51:
/* 377 */       return 26L;
/*     */     case 52:
/* 377 */       return 27L;
/*     */     case 53:
/* 378 */       return 28L;
/*     */     case 54:
/* 378 */       return 29L;
/*     */     case 55:
/* 378 */       return 30L;
/*     */     case 56:
/* 378 */       return 31L;
/*     */     case 8:
/* 380 */     case 9: } throw new IOException("Tag error, expect VARINT, but get " + b);
/*     */   }
/*     */ 
/*     */   private void fillBuffer()
/*     */     throws IOException
/*     */   {
/* 386 */     this.mPosition = 0;
/* 387 */     this.mRead = this.mInput.read(this.mBuffer);
/*     */ 
/* 389 */     if (this.mRead == -1)
/*     */     {
/* 391 */       this.mRead = 0;
/* 392 */       throw new EOFException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.dubbo.GenericDataInput
 * JD-Core Version:    0.6.2
 */