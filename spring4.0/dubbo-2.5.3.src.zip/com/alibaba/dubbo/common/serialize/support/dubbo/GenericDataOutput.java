/*     */ package com.alibaba.dubbo.common.serialize.support.dubbo;
/*     */ 
/*     */ import com.alibaba.dubbo.common.serialize.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class GenericDataOutput
/*     */   implements DataOutput, GenericDataFlags
/*     */ {
/*     */   private static final int CHAR_BUF_SIZE = 256;
/*     */   private final byte[] mBuffer;
/*  34 */   private final byte[] mTemp = new byte[9];
/*     */ 
/*  36 */   private final char[] mCharBuf = new char[256];
/*     */   private final OutputStream mOutput;
/*     */   private final int mLimit;
/*  42 */   private int mPosition = 0;
/*     */ 
/*     */   public GenericDataOutput(OutputStream out)
/*     */   {
/*  46 */     this(out, 1024);
/*     */   }
/*     */ 
/*     */   public GenericDataOutput(OutputStream out, int buffSize)
/*     */   {
/*  51 */     this.mOutput = out;
/*  52 */     this.mLimit = buffSize;
/*  53 */     this.mBuffer = new byte[buffSize];
/*     */   }
/*     */ 
/*     */   public void writeBool(boolean v) throws IOException
/*     */   {
/*  58 */     write0((byte)(v ? 26 : 25));
/*     */   }
/*     */ 
/*     */   public void writeByte(byte v) throws IOException
/*     */   {
/*  63 */     switch (v) {
/*     */     case 0:
/*  65 */       write0((byte)25); break;
/*     */     case 1:
/*  65 */       write0((byte)26); break;
/*     */     case 2:
/*  65 */       write0((byte)27); break;
/*     */     case 3:
/*  65 */       write0((byte)28); break;
/*     */     case 4:
/*  66 */       write0((byte)29); break;
/*     */     case 5:
/*  66 */       write0((byte)30); break;
/*     */     case 6:
/*  66 */       write0((byte)31); break;
/*     */     case 7:
/*  66 */       write0((byte)32); break;
/*     */     case 8:
/*  67 */       write0((byte)33); break;
/*     */     case 9:
/*  67 */       write0((byte)34); break;
/*     */     case 10:
/*  67 */       write0((byte)35); break;
/*     */     case 11:
/*  67 */       write0((byte)36); break;
/*     */     case 12:
/*  68 */       write0((byte)37); break;
/*     */     case 13:
/*  68 */       write0((byte)38); break;
/*     */     case 14:
/*  68 */       write0((byte)39); break;
/*     */     case 15:
/*  68 */       write0((byte)40); break;
/*     */     case 16:
/*  69 */       write0((byte)41); break;
/*     */     case 17:
/*  69 */       write0((byte)42); break;
/*     */     case 18:
/*  69 */       write0((byte)43); break;
/*     */     case 19:
/*  69 */       write0((byte)44); break;
/*     */     case 20:
/*  70 */       write0((byte)45); break;
/*     */     case 21:
/*  70 */       write0((byte)46); break;
/*     */     case 22:
/*  70 */       write0((byte)47); break;
/*     */     case 23:
/*  70 */       write0((byte)48); break;
/*     */     case 24:
/*  71 */       write0((byte)49); break;
/*     */     case 25:
/*  71 */       write0((byte)50); break;
/*     */     case 26:
/*  71 */       write0((byte)51); break;
/*     */     case 27:
/*  71 */       write0((byte)52); break;
/*     */     case 28:
/*  72 */       write0((byte)53); break;
/*     */     case 29:
/*  72 */       write0((byte)54); break;
/*     */     case 30:
/*  72 */       write0((byte)55); break;
/*     */     case 31:
/*  72 */       write0((byte)56); break;
/*     */     default:
/*  74 */       write0((byte)0);
/*  75 */       write0(v);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeShort(short v) throws IOException
/*     */   {
/*  81 */     writeVarint32(v);
/*     */   }
/*     */ 
/*     */   public void writeInt(int v) throws IOException
/*     */   {
/*  86 */     writeVarint32(v);
/*     */   }
/*     */ 
/*     */   public void writeLong(long v) throws IOException
/*     */   {
/*  91 */     writeVarint64(v);
/*     */   }
/*     */ 
/*     */   public void writeFloat(float v) throws IOException
/*     */   {
/*  96 */     writeVarint32(Float.floatToRawIntBits(v));
/*     */   }
/*     */ 
/*     */   public void writeDouble(double v) throws IOException
/*     */   {
/* 101 */     writeVarint64(Double.doubleToRawLongBits(v));
/*     */   }
/*     */ 
/*     */   public void writeUTF(String v) throws IOException
/*     */   {
/* 106 */     if (v == null)
/*     */     {
/* 108 */       write0((byte)-108);
/*     */     }
/*     */     else
/*     */     {
/* 112 */       int len = v.length();
/* 113 */       if (len == 0)
/*     */       {
/* 115 */         write0((byte)-107);
/*     */       }
/*     */       else
/*     */       {
/* 119 */         write0((byte)-125);
/* 120 */         writeUInt(len);
/*     */ 
/* 122 */         int off = 0; int limit = this.mLimit - 3;
/* 123 */         char[] buf = this.mCharBuf;
/*     */         do
/*     */         {
/* 126 */           int size = Math.min(len - off, 256);
/* 127 */           v.getChars(off, off + size, buf, 0);
/*     */ 
/* 129 */           for (int i = 0; i < size; i++)
/*     */           {
/* 131 */             char c = buf[i];
/* 132 */             if (this.mPosition > limit)
/*     */             {
/* 134 */               if (c < '')
/*     */               {
/* 136 */                 write0((byte)c);
/*     */               }
/* 138 */               else if (c < 'ࠀ')
/*     */               {
/* 140 */                 write0((byte)(0xC0 | c >> '\006' & 0x1F));
/* 141 */                 write0((byte)(0x80 | c & 0x3F));
/*     */               }
/*     */               else
/*     */               {
/* 145 */                 write0((byte)(0xE0 | c >> '\f' & 0xF));
/* 146 */                 write0((byte)(0x80 | c >> '\006' & 0x3F));
/* 147 */                 write0((byte)(0x80 | c & 0x3F));
/*     */               }
/*     */ 
/*     */             }
/* 152 */             else if (c < '')
/*     */             {
/* 154 */               this.mBuffer[(this.mPosition++)] = ((byte)c);
/*     */             }
/* 156 */             else if (c < 'ࠀ')
/*     */             {
/* 158 */               this.mBuffer[(this.mPosition++)] = ((byte)(0xC0 | c >> '\006' & 0x1F));
/* 159 */               this.mBuffer[(this.mPosition++)] = ((byte)(0x80 | c & 0x3F));
/*     */             }
/*     */             else
/*     */             {
/* 163 */               this.mBuffer[(this.mPosition++)] = ((byte)(0xE0 | c >> '\f' & 0xF));
/* 164 */               this.mBuffer[(this.mPosition++)] = ((byte)(0x80 | c >> '\006' & 0x3F));
/* 165 */               this.mBuffer[(this.mPosition++)] = ((byte)(0x80 | c & 0x3F));
/*     */             }
/*     */           }
/*     */ 
/* 169 */           off += size;
/*     */         }
/* 171 */         while (off < len);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] b) throws IOException
/*     */   {
/* 178 */     if (b == null)
/* 179 */       write0((byte)-108);
/*     */     else
/* 181 */       writeBytes(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] b, int off, int len) throws IOException
/*     */   {
/* 186 */     if (len == 0)
/*     */     {
/* 188 */       write0((byte)-107);
/*     */     }
/*     */     else
/*     */     {
/* 192 */       write0((byte)-125);
/* 193 */       writeUInt(len);
/* 194 */       write0(b, off, len);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flushBuffer() throws IOException
/*     */   {
/* 200 */     if (this.mPosition > 0)
/*     */     {
/* 202 */       this.mOutput.write(this.mBuffer, 0, this.mPosition);
/* 203 */       this.mPosition = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeUInt(int v)
/*     */     throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/* 212 */       byte tmp = (byte)(v & 0x7F);
/* 213 */       if (v >>>= 7 == 0)
/*     */       {
/* 215 */         write0((byte)(tmp | 0x80));
/* 216 */         return;
/*     */       }
/*     */ 
/* 220 */       write0(tmp);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void write0(byte b)
/*     */     throws IOException
/*     */   {
/* 227 */     if (this.mPosition == this.mLimit) {
/* 228 */       flushBuffer();
/*     */     }
/* 230 */     this.mBuffer[(this.mPosition++)] = b;
/*     */   }
/*     */ 
/*     */   protected void write0(byte[] b, int off, int len) throws IOException
/*     */   {
/* 235 */     int rem = this.mLimit - this.mPosition;
/* 236 */     if (rem > len)
/*     */     {
/* 238 */       System.arraycopy(b, off, this.mBuffer, this.mPosition, len);
/* 239 */       this.mPosition += len;
/*     */     }
/*     */     else
/*     */     {
/* 243 */       System.arraycopy(b, off, this.mBuffer, this.mPosition, rem);
/* 244 */       this.mPosition = this.mLimit;
/* 245 */       flushBuffer();
/*     */ 
/* 247 */       off += rem;
/* 248 */       len -= rem;
/*     */ 
/* 250 */       if (this.mLimit > len)
/*     */       {
/* 252 */         System.arraycopy(b, off, this.mBuffer, 0, len);
/* 253 */         this.mPosition = len;
/*     */       }
/*     */       else
/*     */       {
/* 257 */         this.mOutput.write(b, off, len);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeVarint32(int v) throws IOException
/*     */   {
/* 264 */     switch (v) {
/*     */     case -15:
/* 266 */       write0((byte)10); break;
/*     */     case -14:
/* 266 */       write0((byte)11); break;
/*     */     case -13:
/* 266 */       write0((byte)12); break;
/*     */     case -12:
/* 267 */       write0((byte)13); break;
/*     */     case -11:
/* 267 */       write0((byte)14); break;
/*     */     case -10:
/* 267 */       write0((byte)15); break;
/*     */     case -9:
/* 267 */       write0((byte)16); break;
/*     */     case -8:
/* 268 */       write0((byte)17); break;
/*     */     case -7:
/* 268 */       write0((byte)18); break;
/*     */     case -6:
/* 268 */       write0((byte)19); break;
/*     */     case -5:
/* 268 */       write0((byte)20); break;
/*     */     case -4:
/* 269 */       write0((byte)21); break;
/*     */     case -3:
/* 269 */       write0((byte)22); break;
/*     */     case -2:
/* 269 */       write0((byte)23); break;
/*     */     case -1:
/* 269 */       write0((byte)24); break;
/*     */     case 0:
/* 270 */       write0((byte)25); break;
/*     */     case 1:
/* 270 */       write0((byte)26); break;
/*     */     case 2:
/* 270 */       write0((byte)27); break;
/*     */     case 3:
/* 270 */       write0((byte)28); break;
/*     */     case 4:
/* 271 */       write0((byte)29); break;
/*     */     case 5:
/* 271 */       write0((byte)30); break;
/*     */     case 6:
/* 271 */       write0((byte)31); break;
/*     */     case 7:
/* 271 */       write0((byte)32); break;
/*     */     case 8:
/* 272 */       write0((byte)33); break;
/*     */     case 9:
/* 272 */       write0((byte)34); break;
/*     */     case 10:
/* 272 */       write0((byte)35); break;
/*     */     case 11:
/* 272 */       write0((byte)36); break;
/*     */     case 12:
/* 273 */       write0((byte)37); break;
/*     */     case 13:
/* 273 */       write0((byte)38); break;
/*     */     case 14:
/* 273 */       write0((byte)39); break;
/*     */     case 15:
/* 273 */       write0((byte)40); break;
/*     */     case 16:
/* 274 */       write0((byte)41); break;
/*     */     case 17:
/* 274 */       write0((byte)42); break;
/*     */     case 18:
/* 274 */       write0((byte)43); break;
/*     */     case 19:
/* 274 */       write0((byte)44); break;
/*     */     case 20:
/* 275 */       write0((byte)45); break;
/*     */     case 21:
/* 275 */       write0((byte)46); break;
/*     */     case 22:
/* 275 */       write0((byte)47); break;
/*     */     case 23:
/* 275 */       write0((byte)48); break;
/*     */     case 24:
/* 276 */       write0((byte)49); break;
/*     */     case 25:
/* 276 */       write0((byte)50); break;
/*     */     case 26:
/* 276 */       write0((byte)51); break;
/*     */     case 27:
/* 276 */       write0((byte)52); break;
/*     */     case 28:
/* 277 */       write0((byte)53); break;
/*     */     case 29:
/* 277 */       write0((byte)54); break;
/*     */     case 30:
/* 277 */       write0((byte)55); break;
/*     */     case 31:
/* 277 */       write0((byte)56); break;
/*     */     default:
/* 279 */       int t = v; int ix = 0;
/* 280 */       byte[] b = this.mTemp;
/*     */       while (true)
/*     */       {
/* 284 */         b[(++ix)] = ((byte)(v & 0xFF));
/* 285 */         if (v >>>= 8 == 0) {
/* 286 */           break;
/*     */         }
/*     */       }
/* 289 */       if (t > 0)
/*     */       {
/* 292 */         if (b[ix] < 0) {
/* 293 */           b[(++ix)] = 0;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 298 */         while ((b[ix] == -1) && (b[(ix - 1)] < 0)) {
/* 299 */           ix--;
/*     */         }
/*     */       }
/* 302 */       b[0] = ((byte)(0 + ix - 1));
/* 303 */       write0(b, 0, ix + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeVarint64(long v) throws IOException
/*     */   {
/* 309 */     int i = (int)v;
/* 310 */     if (v == i)
/*     */     {
/* 312 */       writeVarint32(i);
/*     */     }
/*     */     else
/*     */     {
/* 316 */       long t = v;
/* 317 */       int ix = 0;
/* 318 */       byte[] b = this.mTemp;
/*     */       while (true)
/*     */       {
/* 322 */         b[(++ix)] = ((byte)(int)(v & 0xFF));
/* 323 */         if (v >>>= 8 == 0L) {
/* 324 */           break;
/*     */         }
/*     */       }
/* 327 */       if (t > 0L)
/*     */       {
/* 330 */         if (b[ix] < 0) {
/* 331 */           b[(++ix)] = 0;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 336 */         while ((b[ix] == -1) && (b[(ix - 1)] < 0)) {
/* 337 */           ix--;
/*     */         }
/*     */       }
/* 340 */       b[0] = ((byte)(0 + ix - 1));
/* 341 */       write0(b, 0, ix + 1);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.dubbo.GenericDataOutput
 * JD-Core Version:    0.6.2
 */