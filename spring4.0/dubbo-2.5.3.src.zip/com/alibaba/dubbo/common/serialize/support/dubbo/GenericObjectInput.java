/*     */ package com.alibaba.dubbo.common.serialize.support.dubbo;
/*     */ 
/*     */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class GenericObjectInput extends GenericDataInput
/*     */   implements ObjectInput
/*     */ {
/*  35 */   private static Object SKIPPED_OBJECT = new Object();
/*     */   private ClassDescriptorMapper mMapper;
/*  39 */   private List<Object> mRefs = new ArrayList();
/*     */ 
/*     */   public GenericObjectInput(InputStream is)
/*     */   {
/*  43 */     this(is, Builder.DEFAULT_CLASS_DESCRIPTOR_MAPPER);
/*     */   }
/*     */ 
/*     */   public GenericObjectInput(InputStream is, ClassDescriptorMapper mapper)
/*     */   {
/*  48 */     super(is);
/*  49 */     this.mMapper = mapper;
/*     */   }
/*     */ 
/*     */   public GenericObjectInput(InputStream is, int buffSize)
/*     */   {
/*  54 */     this(is, buffSize, Builder.DEFAULT_CLASS_DESCRIPTOR_MAPPER);
/*     */   }
/*     */ 
/*     */   public GenericObjectInput(InputStream is, int buffSize, ClassDescriptorMapper mapper)
/*     */   {
/*  59 */     super(is, buffSize);
/*  60 */     this.mMapper = mapper;
/*     */   }
/*     */ 
/*     */   public Object readObject()
/*     */     throws IOException
/*     */   {
/*  66 */     byte b = read0();
/*     */     String desc;
/*  68 */     switch (b)
/*     */     {
/*     */     case -108:
/*  71 */       return null;
/*     */     case -107:
/*  73 */       return new Object();
/*     */     case -118:
/*  76 */       desc = readUTF();
/*  77 */       break;
/*     */     case -117:
/*  81 */       int index = readUInt();
/*  82 */       desc = this.mMapper.getDescriptor(index);
/*  83 */       if (desc == null) {
/*  84 */         throw new IOException("Can not find desc id: " + index);
/*     */       }
/*     */       break;
/*     */     default:
/*  88 */       throw new IOException("Flag error, expect OBJECT_NULL|OBJECT_DUMMY|OBJECT_DESC|OBJECT_DESC_ID, get " + b);
/*     */     }
/*     */     try
/*     */     {
/*  92 */       Class c = ReflectUtils.desc2class(desc);
/*  93 */       return Builder.register(c).parseFrom(this);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/*  97 */       throw new IOException("Read object failed, class not found. " + StringUtils.toString(e));
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T readObject(Class<T> cls)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 104 */     return readObject();
/*     */   }
/*     */ 
/*     */   public <T> T readObject(Class<T> cls, Type type)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 110 */     return readObject();
/*     */   }
/*     */ 
/*     */   public void addRef(Object obj)
/*     */   {
/* 115 */     this.mRefs.add(obj);
/*     */   }
/*     */ 
/*     */   public Object getRef(int index) throws IOException
/*     */   {
/* 120 */     if ((index < 0) || (index >= this.mRefs.size())) {
/* 121 */       return null;
/*     */     }
/* 123 */     Object ret = this.mRefs.get(index);
/* 124 */     if (ret == SKIPPED_OBJECT)
/* 125 */       throw new IOException("Ref skipped-object.");
/* 126 */     return ret;
/*     */   }
/*     */ 
/*     */   public void skipAny() throws IOException
/*     */   {
/* 131 */     byte b = read0();
/* 132 */     switch (b) { case -108:
/*     */     case -107:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 13:
/*     */     case 14:
/*     */     case 15:
/*     */     case 16:
/*     */     case 17:
/*     */     case 18:
/*     */     case 19:
/*     */     case 20:
/*     */     case 21:
/*     */     case 22:
/*     */     case 23:
/*     */     case 24:
/*     */     case 25:
/*     */     case 26:
/*     */     case 27:
/*     */     case 28:
/*     */     case 29:
/*     */     case 30:
/*     */     case 31:
/*     */     case 32:
/*     */     case 33:
/*     */     case 34:
/*     */     case 35:
/*     */     case 36:
/*     */     case 37:
/*     */     case 38:
/*     */     case 39:
/*     */     case 40:
/*     */     case 41:
/*     */     case 42:
/*     */     case 43:
/*     */     case 44:
/*     */     case 45:
/*     */     case 46:
/*     */     case 47:
/*     */     case 48:
/*     */     case 49:
/*     */     case 50:
/*     */     case 51:
/*     */     case 52:
/*     */     case 53:
/*     */     case 54:
/*     */     case 55:
/*     */     case 56:
/* 141 */       break;
/*     */     case 0:
/* 144 */       read0();
/* 145 */       break;
/*     */     case 1:
/* 149 */       read0(); read0();
/* 150 */       break;
/*     */     case 2:
/* 154 */       read0(); read0(); read0();
/* 155 */       break;
/*     */     case 3:
/* 159 */       read0(); read0(); read0(); read0();
/* 160 */       break;
/*     */     case 4:
/* 164 */       read0(); read0(); read0(); read0(); read0();
/* 165 */       break;
/*     */     case 5:
/* 169 */       read0(); read0(); read0(); read0(); read0(); read0();
/* 170 */       break;
/*     */     case 6:
/* 174 */       read0(); read0(); read0(); read0(); read0(); read0(); read0();
/* 175 */       break;
/*     */     case 7:
/* 179 */       read0(); read0(); read0(); read0(); read0(); read0(); read0(); read0();
/* 180 */       break;
/*     */     case -128:
/* 184 */       addRef(SKIPPED_OBJECT);
/* 185 */       int len = readUInt();
/* 186 */       for (int i = 0; i < len; i++)
/* 187 */         skipAny();
/* 188 */       break;
/*     */     case -127:
/* 192 */       readUInt();
/* 193 */       break;
/*     */     case -126:
/*     */     case -125:
/* 197 */       read0(readUInt());
/* 198 */       break;
/*     */     case -124:
/* 202 */       skipAny();
/* 203 */       break;
/*     */     case -123:
/* 207 */       int len = readUInt();
/* 208 */       for (int i = 0; i < len; i++)
/* 209 */         skipAny();
/* 210 */       break;
/*     */     case -122:
/* 214 */       int len = readUInt();
/* 215 */       for (int i = 0; i < len; i++)
/*     */       {
/* 217 */         skipAny();
/* 218 */         skipAny();
/*     */       }
/* 220 */       break;
/*     */     case -118:
/* 224 */       readUTF();
/* 225 */       int len = readUInt();
/* 226 */       for (int i = 0; i < len; i++)
/* 227 */         skipAny();
/* 228 */       break;
/*     */     case -117:
/* 232 */       readUInt();
/* 233 */       int len = readUInt();
/* 234 */       for (int i = 0; i < len; i++)
/* 235 */         skipAny();
/* 236 */       break;
/*     */     case -121:
/*     */     case -120:
/*     */     case -119:
/*     */     case -116:
/*     */     case -115:
/*     */     case -114:
/*     */     case -113:
/*     */     case -112:
/*     */     case -111:
/*     */     case -110:
/*     */     case -109:
/*     */     case -106:
/*     */     case -105:
/*     */     case -104:
/*     */     case -103:
/*     */     case -102:
/*     */     case -101:
/*     */     case -100:
/*     */     case -99:
/*     */     case -98:
/*     */     case -97:
/*     */     case -96:
/*     */     case -95:
/*     */     case -94:
/*     */     case -93:
/*     */     case -92:
/*     */     case -91:
/*     */     case -90:
/*     */     case -89:
/*     */     case -88:
/*     */     case -87:
/*     */     case -86:
/*     */     case -85:
/*     */     case -84:
/*     */     case -83:
/*     */     case -82:
/*     */     case -81:
/*     */     case -80:
/*     */     case -79:
/*     */     case -78:
/*     */     case -77:
/*     */     case -76:
/*     */     case -75:
/*     */     case -74:
/*     */     case -73:
/*     */     case -72:
/*     */     case -71:
/*     */     case -70:
/*     */     case -69:
/*     */     case -68:
/*     */     case -67:
/*     */     case -66:
/*     */     case -65:
/*     */     case -64:
/*     */     case -63:
/*     */     case -62:
/*     */     case -61:
/*     */     case -60:
/*     */     case -59:
/*     */     case -58:
/*     */     case -57:
/*     */     case -56:
/*     */     case -55:
/*     */     case -54:
/*     */     case -53:
/*     */     case -52:
/*     */     case -51:
/*     */     case -50:
/*     */     case -49:
/*     */     case -48:
/*     */     case -47:
/*     */     case -46:
/*     */     case -45:
/*     */     case -44:
/*     */     case -43:
/*     */     case -42:
/*     */     case -41:
/*     */     case -40:
/*     */     case -39:
/*     */     case -38:
/*     */     case -37:
/*     */     case -36:
/*     */     case -35:
/*     */     case -34:
/*     */     case -33:
/*     */     case -32:
/*     */     case -31:
/*     */     case -30:
/*     */     case -29:
/*     */     case -28:
/*     */     case -27:
/*     */     case -26:
/*     */     case -25:
/*     */     case -24:
/*     */     case -23:
/*     */     case -22:
/*     */     case -21:
/*     */     case -20:
/*     */     case -19:
/*     */     case -18:
/*     */     case -17:
/*     */     case -16:
/*     */     case -15:
/*     */     case -14:
/*     */     case -13:
/*     */     case -12:
/*     */     case -11:
/*     */     case -10:
/*     */     case -9:
/*     */     case -8:
/*     */     case -7:
/*     */     case -6:
/*     */     case -5:
/*     */     case -4:
/*     */     case -3:
/*     */     case -2:
/*     */     case -1:
/*     */     case 8:
/*     */     case 9:
/*     */     default:
/* 239 */       throw new IOException("Flag error, get " + b);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.dubbo.GenericObjectInput
 * JD-Core Version:    0.6.2
 */