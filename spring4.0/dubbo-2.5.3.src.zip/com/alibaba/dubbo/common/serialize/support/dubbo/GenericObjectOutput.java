/*     */ package com.alibaba.dubbo.common.serialize.support.dubbo;
/*     */ 
/*     */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ public class GenericObjectOutput extends GenericDataOutput
/*     */   implements ObjectOutput
/*     */ {
/*     */   private ClassDescriptorMapper mMapper;
/*  36 */   private Map<Object, Integer> mRefs = new ConcurrentHashMap();
/*     */   private final boolean isAllowNonSerializable;
/*     */ 
/*     */   public GenericObjectOutput(OutputStream out)
/*     */   {
/*  42 */     this(out, Builder.DEFAULT_CLASS_DESCRIPTOR_MAPPER);
/*     */   }
/*     */ 
/*     */   public GenericObjectOutput(OutputStream out, ClassDescriptorMapper mapper)
/*     */   {
/*  47 */     super(out);
/*  48 */     this.mMapper = mapper;
/*  49 */     this.isAllowNonSerializable = false;
/*     */   }
/*     */ 
/*     */   public GenericObjectOutput(OutputStream out, int buffSize)
/*     */   {
/*  54 */     this(out, buffSize, Builder.DEFAULT_CLASS_DESCRIPTOR_MAPPER, false);
/*     */   }
/*     */ 
/*     */   public GenericObjectOutput(OutputStream out, int buffSize, ClassDescriptorMapper mapper)
/*     */   {
/*  59 */     this(out, buffSize, mapper, false);
/*     */   }
/*     */ 
/*     */   public GenericObjectOutput(OutputStream out, int buffSize, ClassDescriptorMapper mapper, boolean isAllowNonSerializable)
/*     */   {
/*  64 */     super(out, buffSize);
/*  65 */     this.mMapper = mapper;
/*  66 */     this.isAllowNonSerializable = isAllowNonSerializable;
/*     */   }
/*     */ 
/*     */   public void writeObject(Object obj)
/*     */     throws IOException
/*     */   {
/*  72 */     if (obj == null)
/*     */     {
/*  74 */       write0((byte)-108);
/*  75 */       return;
/*     */     }
/*     */ 
/*  78 */     Class c = obj.getClass();
/*  79 */     if (c == Object.class)
/*     */     {
/*  81 */       write0((byte)-107);
/*     */     }
/*     */     else
/*     */     {
/*  85 */       String desc = ReflectUtils.getDesc(c);
/*  86 */       int index = this.mMapper.getDescriptorIndex(desc);
/*  87 */       if (index < 0)
/*     */       {
/*  89 */         write0((byte)-118);
/*  90 */         writeUTF(desc);
/*     */       }
/*     */       else
/*     */       {
/*  94 */         write0((byte)-117);
/*  95 */         writeUInt(index);
/*     */       }
/*  97 */       Builder b = Builder.register(c, this.isAllowNonSerializable);
/*  98 */       b.writeTo(obj, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addRef(Object obj)
/*     */   {
/* 104 */     this.mRefs.put(obj, Integer.valueOf(this.mRefs.size()));
/*     */   }
/*     */ 
/*     */   public int getRef(Object obj)
/*     */   {
/* 109 */     Integer ref = (Integer)this.mRefs.get(obj);
/* 110 */     if (ref == null)
/* 111 */       return -1;
/* 112 */     return ref.intValue();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.dubbo.GenericObjectOutput
 * JD-Core Version:    0.6.2
 */