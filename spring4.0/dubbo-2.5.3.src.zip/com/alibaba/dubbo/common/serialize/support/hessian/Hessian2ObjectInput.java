/*    */ package com.alibaba.dubbo.common.serialize.support.hessian;
/*    */ 
/*    */ import com.alibaba.com.caucho.hessian.io.Hessian2Input;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class Hessian2ObjectInput
/*    */   implements ObjectInput
/*    */ {
/*    */   private final Hessian2Input mH2i;
/*    */ 
/*    */   public Hessian2ObjectInput(InputStream is)
/*    */   {
/* 37 */     this.mH2i = new Hessian2Input(is);
/* 38 */     this.mH2i.setSerializerFactory(Hessian2SerializerFactory.SERIALIZER_FACTORY);
/*    */   }
/*    */ 
/*    */   public boolean readBool() throws IOException
/*    */   {
/* 43 */     return this.mH2i.readBoolean();
/*    */   }
/*    */ 
/*    */   public byte readByte() throws IOException
/*    */   {
/* 48 */     return (byte)this.mH2i.readInt();
/*    */   }
/*    */ 
/*    */   public short readShort() throws IOException
/*    */   {
/* 53 */     return (short)this.mH2i.readInt();
/*    */   }
/*    */ 
/*    */   public int readInt() throws IOException
/*    */   {
/* 58 */     return this.mH2i.readInt();
/*    */   }
/*    */ 
/*    */   public long readLong() throws IOException
/*    */   {
/* 63 */     return this.mH2i.readLong();
/*    */   }
/*    */ 
/*    */   public float readFloat() throws IOException
/*    */   {
/* 68 */     return (float)this.mH2i.readDouble();
/*    */   }
/*    */ 
/*    */   public double readDouble() throws IOException
/*    */   {
/* 73 */     return this.mH2i.readDouble();
/*    */   }
/*    */ 
/*    */   public byte[] readBytes() throws IOException
/*    */   {
/* 78 */     return this.mH2i.readBytes();
/*    */   }
/*    */ 
/*    */   public String readUTF() throws IOException
/*    */   {
/* 83 */     return this.mH2i.readString();
/*    */   }
/*    */ 
/*    */   public Object readObject() throws IOException
/*    */   {
/* 88 */     return this.mH2i.readObject();
/*    */   }
/*    */ 
/*    */   public <T> T readObject(Class<T> cls)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 94 */     return this.mH2i.readObject(cls);
/*    */   }
/*    */ 
/*    */   public <T> T readObject(Class<T> cls, Type type) throws IOException, ClassNotFoundException
/*    */   {
/* 99 */     return readObject(cls);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.hessian.Hessian2ObjectInput
 * JD-Core Version:    0.6.2
 */