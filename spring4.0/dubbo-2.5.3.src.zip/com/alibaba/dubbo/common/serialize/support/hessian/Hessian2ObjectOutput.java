/*    */ package com.alibaba.dubbo.common.serialize.support.hessian;
/*    */ 
/*    */ import com.alibaba.com.caucho.hessian.io.Hessian2Output;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class Hessian2ObjectOutput
/*    */   implements ObjectOutput
/*    */ {
/*    */   private final Hessian2Output mH2o;
/*    */ 
/*    */   public Hessian2ObjectOutput(OutputStream os)
/*    */   {
/* 36 */     this.mH2o = new Hessian2Output(os);
/* 37 */     this.mH2o.setSerializerFactory(Hessian2SerializerFactory.SERIALIZER_FACTORY);
/*    */   }
/*    */ 
/*    */   public void writeBool(boolean v) throws IOException
/*    */   {
/* 42 */     this.mH2o.writeBoolean(v);
/*    */   }
/*    */ 
/*    */   public void writeByte(byte v) throws IOException
/*    */   {
/* 47 */     this.mH2o.writeInt(v);
/*    */   }
/*    */ 
/*    */   public void writeShort(short v) throws IOException
/*    */   {
/* 52 */     this.mH2o.writeInt(v);
/*    */   }
/*    */ 
/*    */   public void writeInt(int v) throws IOException
/*    */   {
/* 57 */     this.mH2o.writeInt(v);
/*    */   }
/*    */ 
/*    */   public void writeLong(long v) throws IOException
/*    */   {
/* 62 */     this.mH2o.writeLong(v);
/*    */   }
/*    */ 
/*    */   public void writeFloat(float v) throws IOException
/*    */   {
/* 67 */     this.mH2o.writeDouble(v);
/*    */   }
/*    */ 
/*    */   public void writeDouble(double v) throws IOException
/*    */   {
/* 72 */     this.mH2o.writeDouble(v);
/*    */   }
/*    */ 
/*    */   public void writeBytes(byte[] b) throws IOException
/*    */   {
/* 77 */     this.mH2o.writeBytes(b);
/*    */   }
/*    */ 
/*    */   public void writeBytes(byte[] b, int off, int len) throws IOException
/*    */   {
/* 82 */     this.mH2o.writeBytes(b, off, len);
/*    */   }
/*    */ 
/*    */   public void writeUTF(String v) throws IOException
/*    */   {
/* 87 */     this.mH2o.writeString(v);
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj) throws IOException
/*    */   {
/* 92 */     this.mH2o.writeObject(obj);
/*    */   }
/*    */ 
/*    */   public void flushBuffer() throws IOException
/*    */   {
/* 97 */     this.mH2o.flushBuffer();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.hessian.Hessian2ObjectOutput
 * JD-Core Version:    0.6.2
 */