/*    */ package com.alibaba.dubbo.common.serialize.support.hessian;
/*    */ 
/*    */ import com.alibaba.com.caucho.hessian.io.SerializerFactory;
/*    */ 
/*    */ public class Hessian2SerializerFactory extends SerializerFactory
/*    */ {
/* 22 */   public static final SerializerFactory SERIALIZER_FACTORY = new Hessian2SerializerFactory();
/*    */ 
/*    */   public ClassLoader getClassLoader()
/*    */   {
/* 29 */     return Thread.currentThread().getContextClassLoader();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.hessian.Hessian2SerializerFactory
 * JD-Core Version:    0.6.2
 */