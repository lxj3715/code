/*    */ package com.alibaba.dubbo.common.serialize.support.java;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class CompactedObjectOutputStream extends ObjectOutputStream
/*    */ {
/*    */   public CompactedObjectOutputStream(OutputStream out)
/*    */     throws IOException
/*    */   {
/* 33 */     super(out);
/*    */   }
/*    */ 
/*    */   protected void writeClassDescriptor(ObjectStreamClass desc)
/*    */     throws IOException
/*    */   {
/* 39 */     Class clazz = desc.forClass();
/* 40 */     if ((clazz.isPrimitive()) || (clazz.isArray()))
/*    */     {
/* 42 */       write(0);
/* 43 */       super.writeClassDescriptor(desc);
/*    */     }
/*    */     else
/*    */     {
/* 47 */       write(1);
/* 48 */       writeUTF(desc.getName());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.java.CompactedObjectOutputStream
 * JD-Core Version:    0.6.2
 */