/*    */ package com.alibaba.dubbo.common.serialize.support.java;
/*    */ 
/*    */ import com.alibaba.dubbo.common.serialize.support.nativejava.NativeJavaObjectInput;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class JavaObjectInput extends NativeJavaObjectInput
/*    */ {
/*    */   public static final int MAX_BYTE_ARRAY_LENGTH = 8388608;
/*    */ 
/*    */   public JavaObjectInput(InputStream is)
/*    */     throws IOException
/*    */   {
/* 37 */     super(new ObjectInputStream(is));
/*    */   }
/*    */ 
/*    */   public JavaObjectInput(InputStream is, boolean compacted) throws IOException
/*    */   {
/* 42 */     super(compacted ? new CompactedObjectInputStream(is) : new ObjectInputStream(is));
/*    */   }
/*    */ 
/*    */   public byte[] readBytes() throws IOException
/*    */   {
/* 47 */     int len = getObjectInputStream().readInt();
/* 48 */     if (len < 0)
/* 49 */       return null;
/* 50 */     if (len == 0)
/* 51 */       return new byte[0];
/* 52 */     if (len > 8388608) {
/* 53 */       throw new IOException("Byte array length too large. " + len);
/*    */     }
/* 55 */     byte[] b = new byte[len];
/* 56 */     getObjectInputStream().readFully(b);
/* 57 */     return b;
/*    */   }
/*    */ 
/*    */   public String readUTF() throws IOException
/*    */   {
/* 62 */     int len = getObjectInputStream().readInt();
/* 63 */     if (len < 0) {
/* 64 */       return null;
/*    */     }
/* 66 */     return getObjectInputStream().readUTF();
/*    */   }
/*    */ 
/*    */   public Object readObject() throws IOException, ClassNotFoundException
/*    */   {
/* 71 */     byte b = getObjectInputStream().readByte();
/* 72 */     if (b == 0) {
/* 73 */       return null;
/*    */     }
/* 75 */     return getObjectInputStream().readObject();
/*    */   }
/*    */ 
/*    */   public <T> T readObject(Class<T> cls)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 81 */     return readObject();
/*    */   }
/*    */ 
/*    */   public <T> T readObject(Class<T> cls, Type type)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 87 */     return readObject();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.java.JavaObjectInput
 * JD-Core Version:    0.6.2
 */