/*    */ package com.alibaba.dubbo.common.serialize.support.java;
/*    */ 
/*    */ import com.alibaba.dubbo.common.serialize.support.nativejava.NativeJavaObjectOutput;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class JavaObjectOutput extends NativeJavaObjectOutput
/*    */ {
/*    */   public JavaObjectOutput(OutputStream os)
/*    */     throws IOException
/*    */   {
/* 34 */     super(new ObjectOutputStream(os));
/*    */   }
/*    */ 
/*    */   public JavaObjectOutput(OutputStream os, boolean compact) throws IOException
/*    */   {
/* 39 */     super(compact ? new CompactedObjectOutputStream(os) : new ObjectOutputStream(os));
/*    */   }
/*    */ 
/*    */   public void writeUTF(String v) throws IOException
/*    */   {
/* 44 */     if (v == null)
/*    */     {
/* 46 */       getObjectOutputStream().writeInt(-1);
/*    */     }
/*    */     else
/*    */     {
/* 50 */       getObjectOutputStream().writeInt(v.length());
/* 51 */       getObjectOutputStream().writeUTF(v);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj) throws IOException
/*    */   {
/* 57 */     if (obj == null)
/*    */     {
/* 59 */       getObjectOutputStream().writeByte(0);
/*    */     }
/*    */     else
/*    */     {
/* 63 */       getObjectOutputStream().writeByte(1);
/* 64 */       getObjectOutputStream().writeObject(obj);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void flushBuffer() throws IOException
/*    */   {
/* 70 */     getObjectOutputStream().flush();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.java.JavaObjectOutput
 * JD-Core Version:    0.6.2
 */