/*     */ package com.alibaba.dubbo.common.serialize.support.json;
/*     */ 
/*     */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*     */ import com.alibaba.dubbo.common.utils.PojoUtils;
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ public class FastJsonObjectInput
/*     */   implements ObjectInput
/*     */ {
/*     */   private final BufferedReader reader;
/*     */ 
/*     */   public FastJsonObjectInput(InputStream in)
/*     */   {
/*  40 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */   public FastJsonObjectInput(Reader reader) {
/*  44 */     this.reader = new BufferedReader(reader);
/*     */   }
/*     */ 
/*     */   public boolean readBool() throws IOException {
/*     */     try {
/*  49 */       return ((Boolean)readObject(Boolean.TYPE)).booleanValue();
/*     */     } catch (ClassNotFoundException e) {
/*  51 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte readByte() throws IOException {
/*     */     try {
/*  57 */       return ((Byte)readObject(Byte.TYPE)).byteValue();
/*     */     } catch (ClassNotFoundException e) {
/*  59 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public short readShort() throws IOException {
/*     */     try {
/*  65 */       return ((Short)readObject(Short.TYPE)).shortValue();
/*     */     } catch (ClassNotFoundException e) {
/*  67 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public int readInt() throws IOException {
/*     */     try {
/*  73 */       return ((Integer)readObject(Integer.TYPE)).intValue();
/*     */     } catch (ClassNotFoundException e) {
/*  75 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public long readLong() throws IOException {
/*     */     try {
/*  81 */       return ((Long)readObject(Long.TYPE)).longValue();
/*     */     } catch (ClassNotFoundException e) {
/*  83 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public float readFloat() throws IOException {
/*     */     try {
/*  89 */       return ((Float)readObject(Float.TYPE)).floatValue();
/*     */     } catch (ClassNotFoundException e) {
/*  91 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public double readDouble() throws IOException {
/*     */     try {
/*  97 */       return ((Double)readObject(Double.TYPE)).doubleValue();
/*     */     } catch (ClassNotFoundException e) {
/*  99 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String readUTF() throws IOException {
/*     */     try {
/* 105 */       return (String)readObject(String.class);
/*     */     } catch (ClassNotFoundException e) {
/* 107 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] readBytes() throws IOException {
/* 112 */     return readLine().getBytes();
/*     */   }
/*     */ 
/*     */   public Object readObject() throws IOException, ClassNotFoundException {
/* 116 */     String json = readLine();
/* 117 */     return JSON.parse(json);
/*     */   }
/*     */ 
/*     */   public <T> T readObject(Class<T> cls) throws IOException, ClassNotFoundException {
/* 121 */     String json = readLine();
/* 122 */     return JSON.parseObject(json, cls);
/*     */   }
/*     */ 
/*     */   public <T> T readObject(Class<T> cls, Type type)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 128 */     Object value = readObject(cls);
/* 129 */     return PojoUtils.realize(value, cls, type);
/*     */   }
/*     */ 
/*     */   private String readLine() throws IOException, EOFException {
/* 133 */     String line = this.reader.readLine();
/* 134 */     if ((line == null) || (line.trim().length() == 0)) throw new EOFException();
/* 135 */     return line;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.json.FastJsonObjectInput
 * JD-Core Version:    0.6.2
 */