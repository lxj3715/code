/*    */ package com.alibaba.dubbo.common.serialize.support.json;
/*    */ 
/*    */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*    */ import com.alibaba.fastjson.serializer.JSONSerializer;
/*    */ import com.alibaba.fastjson.serializer.SerializeWriter;
/*    */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class FastJsonObjectOutput
/*    */   implements ObjectOutput
/*    */ {
/*    */   private final PrintWriter writer;
/*    */ 
/*    */   public FastJsonObjectOutput(OutputStream out)
/*    */   {
/* 39 */     this(new OutputStreamWriter(out));
/*    */   }
/*    */ 
/*    */   public FastJsonObjectOutput(Writer writer) {
/* 43 */     this.writer = new PrintWriter(writer);
/*    */   }
/*    */ 
/*    */   public void writeBool(boolean v) throws IOException {
/* 47 */     writeObject(Boolean.valueOf(v));
/*    */   }
/*    */ 
/*    */   public void writeByte(byte v) throws IOException {
/* 51 */     writeObject(Byte.valueOf(v));
/*    */   }
/*    */ 
/*    */   public void writeShort(short v) throws IOException {
/* 55 */     writeObject(Short.valueOf(v));
/*    */   }
/*    */ 
/*    */   public void writeInt(int v) throws IOException {
/* 59 */     writeObject(Integer.valueOf(v));
/*    */   }
/*    */ 
/*    */   public void writeLong(long v) throws IOException {
/* 63 */     writeObject(Long.valueOf(v));
/*    */   }
/*    */ 
/*    */   public void writeFloat(float v) throws IOException {
/* 67 */     writeObject(Float.valueOf(v));
/*    */   }
/*    */ 
/*    */   public void writeDouble(double v) throws IOException {
/* 71 */     writeObject(Double.valueOf(v));
/*    */   }
/*    */ 
/*    */   public void writeUTF(String v) throws IOException {
/* 75 */     writeObject(v);
/*    */   }
/*    */ 
/*    */   public void writeBytes(byte[] b) throws IOException {
/* 79 */     this.writer.println(new String(b));
/*    */   }
/*    */ 
/*    */   public void writeBytes(byte[] b, int off, int len) throws IOException {
/* 83 */     this.writer.println(new String(b, off, len));
/*    */   }
/*    */ 
/*    */   public void writeObject(Object obj) throws IOException {
/* 87 */     SerializeWriter out = new SerializeWriter();
/* 88 */     JSONSerializer serializer = new JSONSerializer(out);
/* 89 */     serializer.config(SerializerFeature.WriteEnumUsingToString, true);
/* 90 */     serializer.write(obj);
/* 91 */     out.writeTo(this.writer);
/* 92 */     this.writer.println();
/* 93 */     this.writer.flush();
/*    */   }
/*    */ 
/*    */   public void flushBuffer() throws IOException {
/* 97 */     this.writer.flush();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.json.FastJsonObjectOutput
 * JD-Core Version:    0.6.2
 */