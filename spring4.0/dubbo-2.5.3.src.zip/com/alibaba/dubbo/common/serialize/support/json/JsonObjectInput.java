/*     */ package com.alibaba.dubbo.common.serialize.support.json;
/*     */ 
/*     */ import com.alibaba.dubbo.common.json.JSON;
/*     */ import com.alibaba.dubbo.common.json.ParseException;
/*     */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*     */ import com.alibaba.dubbo.common.utils.PojoUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class JsonObjectInput
/*     */   implements ObjectInput
/*     */ {
/*     */   private final BufferedReader reader;
/*     */ 
/*     */   public JsonObjectInput(InputStream in)
/*     */   {
/*  43 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */   public JsonObjectInput(Reader reader) {
/*  47 */     this.reader = new BufferedReader(reader);
/*     */   }
/*     */ 
/*     */   public boolean readBool() throws IOException {
/*     */     try {
/*  52 */       return ((Boolean)readObject(Boolean.TYPE)).booleanValue();
/*     */     } catch (ClassNotFoundException e) {
/*  54 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte readByte() throws IOException {
/*     */     try {
/*  60 */       return ((Byte)readObject(Byte.TYPE)).byteValue();
/*     */     } catch (ClassNotFoundException e) {
/*  62 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public short readShort() throws IOException {
/*     */     try {
/*  68 */       return ((Short)readObject(Short.TYPE)).shortValue();
/*     */     } catch (ClassNotFoundException e) {
/*  70 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public int readInt() throws IOException {
/*     */     try {
/*  76 */       return ((Integer)readObject(Integer.TYPE)).intValue();
/*     */     } catch (ClassNotFoundException e) {
/*  78 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public long readLong() throws IOException {
/*     */     try {
/*  84 */       return ((Long)readObject(Long.TYPE)).longValue();
/*     */     } catch (ClassNotFoundException e) {
/*  86 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public float readFloat() throws IOException {
/*     */     try {
/*  92 */       return ((Float)readObject(Float.TYPE)).floatValue();
/*     */     } catch (ClassNotFoundException e) {
/*  94 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public double readDouble() throws IOException {
/*     */     try {
/* 100 */       return ((Double)readObject(Double.TYPE)).doubleValue();
/*     */     } catch (ClassNotFoundException e) {
/* 102 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String readUTF() throws IOException {
/*     */     try {
/* 108 */       return (String)readObject(String.class);
/*     */     } catch (ClassNotFoundException e) {
/* 110 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] readBytes() throws IOException {
/* 115 */     return readLine().getBytes();
/*     */   }
/*     */ 
/*     */   public Object readObject() throws IOException, ClassNotFoundException {
/*     */     try {
/* 120 */       String json = readLine();
/* 121 */       if (json.startsWith("{")) {
/* 122 */         return JSON.parse(json, Map.class);
/*     */       }
/* 124 */       json = "{\"value\":" + json + "}";
/*     */ 
/* 127 */       Map map = (Map)JSON.parse(json, Map.class);
/* 128 */       return map.get("value");
/*     */     }
/*     */     catch (ParseException e) {
/* 131 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T readObject(Class<T> cls) throws IOException, ClassNotFoundException
/*     */   {
/* 137 */     Object value = readObject();
/* 138 */     return PojoUtils.realize(value, cls);
/*     */   }
/*     */ 
/*     */   public <T> T readObject(Class<T> cls, Type type)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 149 */     Object value = readObject();
/* 150 */     return PojoUtils.realize(value, cls, type);
/*     */   }
/*     */ 
/*     */   private String readLine() throws IOException, EOFException {
/* 154 */     String line = this.reader.readLine();
/* 155 */     if ((line == null) || (line.trim().length() == 0)) throw new EOFException();
/* 156 */     return line;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.json.JsonObjectInput
 * JD-Core Version:    0.6.2
 */