/*     */ package com.alibaba.dubbo.common.serialize.support.json;
/*     */ 
/*     */ import com.alibaba.dubbo.common.json.JSON;
/*     */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class JsonObjectOutput
/*     */   implements ObjectOutput
/*     */ {
/*     */   private final PrintWriter writer;
/*     */   private final boolean writeClass;
/*     */ 
/*     */   public JsonObjectOutput(OutputStream out)
/*     */   {
/*  39 */     this(new OutputStreamWriter(out), false);
/*     */   }
/*     */ 
/*     */   public JsonObjectOutput(Writer writer) {
/*  43 */     this(writer, false);
/*     */   }
/*     */ 
/*     */   public JsonObjectOutput(OutputStream out, boolean writeClass) {
/*  47 */     this(new OutputStreamWriter(out), writeClass);
/*     */   }
/*     */ 
/*     */   public JsonObjectOutput(Writer writer, boolean writeClass) {
/*  51 */     this.writer = new PrintWriter(writer);
/*  52 */     this.writeClass = writeClass;
/*     */   }
/*     */ 
/*     */   public void writeBool(boolean v) throws IOException {
/*  56 */     writeObject(Boolean.valueOf(v));
/*     */   }
/*     */ 
/*     */   public void writeByte(byte v) throws IOException {
/*  60 */     writeObject(Byte.valueOf(v));
/*     */   }
/*     */ 
/*     */   public void writeShort(short v) throws IOException {
/*  64 */     writeObject(Short.valueOf(v));
/*     */   }
/*     */ 
/*     */   public void writeInt(int v) throws IOException {
/*  68 */     writeObject(Integer.valueOf(v));
/*     */   }
/*     */ 
/*     */   public void writeLong(long v) throws IOException {
/*  72 */     writeObject(Long.valueOf(v));
/*     */   }
/*     */ 
/*     */   public void writeFloat(float v) throws IOException {
/*  76 */     writeObject(Float.valueOf(v));
/*     */   }
/*     */ 
/*     */   public void writeDouble(double v) throws IOException {
/*  80 */     writeObject(Double.valueOf(v));
/*     */   }
/*     */ 
/*     */   public void writeUTF(String v) throws IOException {
/*  84 */     writeObject(v);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] b) throws IOException {
/*  88 */     this.writer.println(new String(b));
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] b, int off, int len) throws IOException {
/*  92 */     this.writer.println(new String(b, off, len));
/*     */   }
/*     */ 
/*     */   public void writeObject(Object obj) throws IOException {
/*  96 */     JSON.json(obj, this.writer, this.writeClass);
/*  97 */     this.writer.println();
/*  98 */     this.writer.flush();
/*     */   }
/*     */ 
/*     */   public void flushBuffer() throws IOException {
/* 102 */     this.writer.flush();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.json.JsonObjectOutput
 * JD-Core Version:    0.6.2
 */