/*    */ package com.alibaba.dubbo.common.serialize.support.json;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*    */ import com.alibaba.dubbo.common.serialize.Serialization;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class JsonSerialization
/*    */   implements Serialization
/*    */ {
/*    */   public byte getContentTypeId()
/*    */   {
/* 35 */     return 5;
/*    */   }
/*    */ 
/*    */   public String getContentType() {
/* 39 */     return "text/json";
/*    */   }
/*    */ 
/*    */   public ObjectOutput serialize(URL url, OutputStream output) throws IOException {
/* 43 */     return new JsonObjectOutput(output, url.getParameter("with.class", true));
/*    */   }
/*    */ 
/*    */   public ObjectInput deserialize(URL url, InputStream input) throws IOException {
/* 47 */     return new JsonObjectInput(input);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.json.JsonSerialization
 * JD-Core Version:    0.6.2
 */