/*     */ package com.alibaba.dubbo.common.serialize.support.nativejava;
/*     */ 
/*     */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*     */ import com.alibaba.dubbo.common.utils.Assert;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ public class NativeJavaObjectInput
/*     */   implements ObjectInput
/*     */ {
/*     */   private final ObjectInputStream inputStream;
/*     */ 
/*     */   public NativeJavaObjectInput(InputStream is)
/*     */     throws IOException
/*     */   {
/*  35 */     this(new ObjectInputStream(is));
/*     */   }
/*     */ 
/*     */   protected NativeJavaObjectInput(ObjectInputStream is) {
/*  39 */     Assert.notNull(is, "input == null");
/*  40 */     this.inputStream = is;
/*     */   }
/*     */ 
/*     */   protected ObjectInputStream getObjectInputStream() {
/*  44 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */   public Object readObject() throws IOException, ClassNotFoundException {
/*  48 */     return this.inputStream.readObject();
/*     */   }
/*     */ 
/*     */   public <T> T readObject(Class<T> cls) throws IOException, ClassNotFoundException
/*     */   {
/*  53 */     return readObject();
/*     */   }
/*     */ 
/*     */   public <T> T readObject(Class<T> cls, Type type) throws IOException, ClassNotFoundException
/*     */   {
/*  58 */     return readObject();
/*     */   }
/*     */ 
/*     */   public boolean readBool() throws IOException {
/*  62 */     return this.inputStream.readBoolean();
/*     */   }
/*     */ 
/*     */   public byte readByte() throws IOException {
/*  66 */     return this.inputStream.readByte();
/*     */   }
/*     */ 
/*     */   public short readShort() throws IOException {
/*  70 */     return this.inputStream.readShort();
/*     */   }
/*     */ 
/*     */   public int readInt() throws IOException {
/*  74 */     return this.inputStream.readInt();
/*     */   }
/*     */ 
/*     */   public long readLong() throws IOException {
/*  78 */     return this.inputStream.readLong();
/*     */   }
/*     */ 
/*     */   public float readFloat() throws IOException {
/*  82 */     return this.inputStream.readFloat();
/*     */   }
/*     */ 
/*     */   public double readDouble() throws IOException {
/*  86 */     return this.inputStream.readDouble();
/*     */   }
/*     */ 
/*     */   public String readUTF() throws IOException {
/*  90 */     return this.inputStream.readUTF();
/*     */   }
/*     */ 
/*     */   public byte[] readBytes() throws IOException {
/*  94 */     int len = this.inputStream.readInt();
/*  95 */     if (len < 0)
/*  96 */       return null;
/*  97 */     if (len == 0) {
/*  98 */       return new byte[0];
/*     */     }
/* 100 */     byte[] result = new byte[len];
/* 101 */     this.inputStream.readFully(result);
/* 102 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.nativejava.NativeJavaObjectInput
 * JD-Core Version:    0.6.2
 */