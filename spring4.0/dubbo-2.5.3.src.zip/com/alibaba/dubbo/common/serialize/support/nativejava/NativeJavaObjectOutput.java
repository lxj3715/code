/*     */ package com.alibaba.dubbo.common.serialize.support.nativejava;
/*     */ 
/*     */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*     */ import com.alibaba.dubbo.common.utils.Assert;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class NativeJavaObjectOutput
/*     */   implements ObjectOutput
/*     */ {
/*     */   private final ObjectOutputStream outputStream;
/*     */ 
/*     */   public NativeJavaObjectOutput(OutputStream os)
/*     */     throws IOException
/*     */   {
/*  34 */     this(new ObjectOutputStream(os));
/*     */   }
/*     */ 
/*     */   protected NativeJavaObjectOutput(ObjectOutputStream out) {
/*  38 */     Assert.notNull(out, "output == null");
/*  39 */     this.outputStream = out;
/*     */   }
/*     */ 
/*     */   protected ObjectOutputStream getObjectOutputStream() {
/*  43 */     return this.outputStream;
/*     */   }
/*     */ 
/*     */   public void writeObject(Object obj) throws IOException {
/*  47 */     this.outputStream.writeObject(obj);
/*     */   }
/*     */ 
/*     */   public void writeBool(boolean v) throws IOException {
/*  51 */     this.outputStream.writeBoolean(v);
/*     */   }
/*     */ 
/*     */   public void writeByte(byte v) throws IOException {
/*  55 */     this.outputStream.writeByte(v);
/*     */   }
/*     */ 
/*     */   public void writeShort(short v) throws IOException {
/*  59 */     this.outputStream.writeShort(v);
/*     */   }
/*     */ 
/*     */   public void writeInt(int v) throws IOException {
/*  63 */     this.outputStream.writeInt(v);
/*     */   }
/*     */ 
/*     */   public void writeLong(long v) throws IOException {
/*  67 */     this.outputStream.writeLong(v);
/*     */   }
/*     */ 
/*     */   public void writeFloat(float v) throws IOException {
/*  71 */     this.outputStream.writeFloat(v);
/*     */   }
/*     */ 
/*     */   public void writeDouble(double v) throws IOException {
/*  75 */     this.outputStream.writeDouble(v);
/*     */   }
/*     */ 
/*     */   public void writeUTF(String v) throws IOException {
/*  79 */     this.outputStream.writeUTF(v);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] v) throws IOException {
/*  83 */     if (v == null)
/*  84 */       this.outputStream.writeInt(-1);
/*     */     else
/*  86 */       writeBytes(v, 0, v.length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] v, int off, int len) throws IOException
/*     */   {
/*  91 */     if (v == null) {
/*  92 */       this.outputStream.writeInt(-1);
/*     */     } else {
/*  94 */       this.outputStream.writeInt(len);
/*  95 */       this.outputStream.write(v, off, len);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flushBuffer() throws IOException {
/* 100 */     this.outputStream.flush();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.nativejava.NativeJavaObjectOutput
 * JD-Core Version:    0.6.2
 */