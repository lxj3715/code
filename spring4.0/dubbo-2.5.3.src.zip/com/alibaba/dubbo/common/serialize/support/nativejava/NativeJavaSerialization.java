/*    */ package com.alibaba.dubbo.common.serialize.support.nativejava;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*    */ import com.alibaba.dubbo.common.serialize.Serialization;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class NativeJavaSerialization
/*    */   implements Serialization
/*    */ {
/*    */   public static final String NAME = "nativejava";
/*    */ 
/*    */   public byte getContentTypeId()
/*    */   {
/* 36 */     return 7;
/*    */   }
/*    */ 
/*    */   public String getContentType() {
/* 40 */     return "x-application/nativejava";
/*    */   }
/*    */ 
/*    */   public ObjectOutput serialize(URL url, OutputStream output) throws IOException {
/* 44 */     return new NativeJavaObjectOutput(output);
/*    */   }
/*    */ 
/*    */   public ObjectInput deserialize(URL url, InputStream input) throws IOException {
/* 48 */     return new NativeJavaObjectInput(input);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.serialize.support.nativejava.NativeJavaSerialization
 * JD-Core Version:    0.6.2
 */