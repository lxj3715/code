/*    */ package com.alibaba.dubbo.common.status;
/*    */ 
/*    */ public class Status
/*    */ {
/*    */   private final Level level;
/*    */   private final String message;
/*    */   private final String description;
/*    */ 
/*    */   public Status(Level level)
/*    */   {
/* 57 */     this(level, null, null);
/*    */   }
/*    */ 
/*    */   public Status(Level level, String message) {
/* 61 */     this(level, message, null);
/*    */   }
/*    */ 
/*    */   public Status(Level level, String message, String description) {
/* 65 */     this.level = level;
/* 66 */     this.message = message;
/* 67 */     this.description = description;
/*    */   }
/*    */ 
/*    */   public Level getLevel() {
/* 71 */     return this.level;
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 75 */     return this.message;
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 79 */     return this.description;
/*    */   }
/*    */ 
/*    */   public static enum Level
/*    */   {
/* 32 */     OK, 
/*    */ 
/* 37 */     WARN, 
/*    */ 
/* 42 */     ERROR, 
/*    */ 
/* 47 */     UNKNOWN;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.status.Status
 * JD-Core Version:    0.6.2
 */