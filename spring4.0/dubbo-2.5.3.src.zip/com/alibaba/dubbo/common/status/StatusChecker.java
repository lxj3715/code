package com.alibaba.dubbo.common.status;

import com.alibaba.dubbo.common.extension.SPI;

@SPI
public abstract interface StatusChecker
{
  public abstract Status check();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.status.StatusChecker
 * JD-Core Version:    0.6.2
 */