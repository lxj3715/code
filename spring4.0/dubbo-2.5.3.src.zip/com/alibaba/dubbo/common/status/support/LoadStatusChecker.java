/*    */ package com.alibaba.dubbo.common.status.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.status.Status;
/*    */ import com.alibaba.dubbo.common.status.Status.Level;
/*    */ import com.alibaba.dubbo.common.status.StatusChecker;
/*    */ import java.lang.management.ManagementFactory;
/*    */ import java.lang.management.OperatingSystemMXBean;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ @Activate
/*    */ public class LoadStatusChecker
/*    */   implements StatusChecker
/*    */ {
/*    */   public Status check()
/*    */   {
/* 35 */     OperatingSystemMXBean operatingSystemMXBean = ManagementFactory.getOperatingSystemMXBean();
/*    */     double load;
/*    */     try
/*    */     {
/* 38 */       Method method = OperatingSystemMXBean.class.getMethod("getSystemLoadAverage", new Class[0]);
/* 39 */       load = ((Double)method.invoke(operatingSystemMXBean, new Object[0])).doubleValue();
/*    */     } catch (Throwable e) {
/* 41 */       load = -1.0D;
/*    */     }
/* 43 */     int cpu = operatingSystemMXBean.getAvailableProcessors();
/* 44 */     return new Status(load < cpu ? Status.Level.OK : load < 0.0D ? Status.Level.UNKNOWN : Status.Level.WARN, (load < 0.0D ? "" : new StringBuilder().append("load:").append(load).append(",").toString()) + "cpu:" + cpu);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.status.support.LoadStatusChecker
 * JD-Core Version:    0.6.2
 */