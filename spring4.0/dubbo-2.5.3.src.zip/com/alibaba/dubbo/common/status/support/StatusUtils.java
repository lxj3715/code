/*    */ package com.alibaba.dubbo.common.status.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.status.Status;
/*    */ import com.alibaba.dubbo.common.status.Status.Level;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ public class StatusUtils
/*    */ {
/*    */   public static Status getSummaryStatus(Map<String, Status> statuses)
/*    */   {
/* 31 */     Status.Level level = Status.Level.OK;
/* 32 */     StringBuilder msg = new StringBuilder();
/* 33 */     for (Map.Entry entry : statuses.entrySet()) {
/* 34 */       String key = (String)entry.getKey();
/* 35 */       Status status = (Status)entry.getValue();
/* 36 */       Status.Level l = status.getLevel();
/* 37 */       if (Status.Level.ERROR.equals(l)) {
/* 38 */         level = Status.Level.ERROR;
/* 39 */         if (msg.length() > 0) {
/* 40 */           msg.append(",");
/*    */         }
/* 42 */         msg.append(key);
/* 43 */       } else if (Status.Level.WARN.equals(l)) {
/* 44 */         if (!Status.Level.ERROR.equals(level)) {
/* 45 */           level = Status.Level.WARN;
/*    */         }
/* 47 */         if (msg.length() > 0) {
/* 48 */           msg.append(",");
/*    */         }
/* 50 */         msg.append(key);
/*    */       }
/*    */     }
/* 53 */     return new Status(level, msg.toString());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.status.support.StatusUtils
 * JD-Core Version:    0.6.2
 */