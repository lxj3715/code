package com.alibaba.dubbo.common.store;

import com.alibaba.dubbo.common.extension.SPI;
import java.util.Map;

@SPI("simple")
public abstract interface DataStore
{
  public abstract Map<String, Object> get(String paramString);

  public abstract Object get(String paramString1, String paramString2);

  public abstract void put(String paramString1, String paramString2, Object paramObject);

  public abstract void remove(String paramString1, String paramString2);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.store.DataStore
 * JD-Core Version:    0.6.2
 */