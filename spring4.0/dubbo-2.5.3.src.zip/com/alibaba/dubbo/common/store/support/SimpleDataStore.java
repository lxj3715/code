/*    */ package com.alibaba.dubbo.common.store.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.store.DataStore;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ public class SimpleDataStore
/*    */   implements DataStore
/*    */ {
/* 33 */   private ConcurrentMap<String, ConcurrentMap<String, Object>> data = new ConcurrentHashMap();
/*    */ 
/*    */   public Map<String, Object> get(String componentName)
/*    */   {
/* 37 */     ConcurrentMap value = (ConcurrentMap)this.data.get(componentName);
/* 38 */     if (value == null) return new HashMap();
/*    */ 
/* 40 */     return new HashMap(value);
/*    */   }
/*    */ 
/*    */   public Object get(String componentName, String key) {
/* 44 */     if (!this.data.containsKey(componentName)) {
/* 45 */       return null;
/*    */     }
/* 47 */     return ((ConcurrentMap)this.data.get(componentName)).get(key);
/*    */   }
/*    */ 
/*    */   public void put(String componentName, String key, Object value) {
/* 51 */     Map componentData = (Map)this.data.get(componentName);
/* 52 */     if (null == componentData) {
/* 53 */       this.data.putIfAbsent(componentName, new ConcurrentHashMap());
/* 54 */       componentData = (Map)this.data.get(componentName);
/*    */     }
/* 56 */     componentData.put(key, value);
/*    */   }
/*    */ 
/*    */   public void remove(String componentName, String key) {
/* 60 */     if (!this.data.containsKey(componentName)) {
/* 61 */       return;
/*    */     }
/* 63 */     ((ConcurrentMap)this.data.get(componentName)).remove(key);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.store.support.SimpleDataStore
 * JD-Core Version:    0.6.2
 */