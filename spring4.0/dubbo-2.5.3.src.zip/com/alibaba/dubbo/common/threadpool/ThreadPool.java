package com.alibaba.dubbo.common.threadpool;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;
import java.util.concurrent.Executor;

@SPI("fixed")
public abstract interface ThreadPool
{
  @Adaptive({"threadpool"})
  public abstract Executor getExecutor(URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.threadpool.ThreadPool
 * JD-Core Version:    0.6.2
 */