/*    */ package com.alibaba.dubbo.common.threadpool.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import java.util.concurrent.RejectedExecutionException;
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;
/*    */ 
/*    */ public class AbortPolicyWithReport extends ThreadPoolExecutor.AbortPolicy
/*    */ {
/* 33 */   protected static final Logger logger = LoggerFactory.getLogger(AbortPolicyWithReport.class);
/*    */   private final String threadName;
/*    */   private final URL url;
/*    */ 
/*    */   public AbortPolicyWithReport(String threadName, URL url)
/*    */   {
/* 40 */     this.threadName = threadName;
/* 41 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public void rejectedExecution(Runnable r, ThreadPoolExecutor e)
/*    */   {
/* 46 */     String msg = String.format("Thread pool is EXHAUSTED! Thread Name: %s, Pool Size: %d (active: %d, core: %d, max: %d, largest: %d), Task: %d (completed: %d), Executor status:(isShutdown:%s, isTerminated:%s, isTerminating:%s), in %s://%s:%d!", new Object[] { this.threadName, Integer.valueOf(e.getPoolSize()), Integer.valueOf(e.getActiveCount()), Integer.valueOf(e.getCorePoolSize()), Integer.valueOf(e.getMaximumPoolSize()), Integer.valueOf(e.getLargestPoolSize()), Long.valueOf(e.getTaskCount()), Long.valueOf(e.getCompletedTaskCount()), Boolean.valueOf(e.isShutdown()), Boolean.valueOf(e.isTerminated()), Boolean.valueOf(e.isTerminating()), this.url.getProtocol(), this.url.getIp(), Integer.valueOf(this.url.getPort()) });
/*    */ 
/* 52 */     logger.warn(msg);
/* 53 */     throw new RejectedExecutionException(msg);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.threadpool.support.AbortPolicyWithReport
 * JD-Core Version:    0.6.2
 */