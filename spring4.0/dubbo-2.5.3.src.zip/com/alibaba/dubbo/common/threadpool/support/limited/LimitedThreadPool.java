/*    */ package com.alibaba.dubbo.common.threadpool.support.limited;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.threadpool.ThreadPool;
/*    */ import com.alibaba.dubbo.common.threadpool.support.AbortPolicyWithReport;
/*    */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*    */ import java.util.concurrent.Executor;
/*    */ import java.util.concurrent.LinkedBlockingQueue;
/*    */ import java.util.concurrent.SynchronousQueue;
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ public class LimitedThreadPool
/*    */   implements ThreadPool
/*    */ {
/*    */   public Executor getExecutor(URL url)
/*    */   {
/* 39 */     String name = url.getParameter("threadname", "Dubbo");
/* 40 */     int cores = url.getParameter("corethreads", 0);
/* 41 */     int threads = url.getParameter("threads", 200);
/* 42 */     int queues = url.getParameter("queues", 0);
/* 43 */     return new ThreadPoolExecutor(cores, threads, 9223372036854775807L, TimeUnit.MILLISECONDS, queues < 0 ? new LinkedBlockingQueue() : queues == 0 ? new SynchronousQueue() : new LinkedBlockingQueue(queues), new NamedThreadFactory(name, true), new AbortPolicyWithReport(name, url));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.threadpool.support.limited.LimitedThreadPool
 * JD-Core Version:    0.6.2
 */