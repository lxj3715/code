/*    */ package com.alibaba.dubbo.common.utils;
/*    */ 
/*    */ public abstract class Assert
/*    */ {
/*    */   public static void notNull(Object obj, String message)
/*    */   {
/* 27 */     if (obj == null)
/* 28 */       throw new IllegalArgumentException(message);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.Assert
 * JD-Core Version:    0.6.2
 */