/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ public class AtomicPositiveInteger extends Number
/*     */ {
/*     */   private static final long serialVersionUID = -3038533876489105940L;
/*     */   private final AtomicInteger i;
/*     */ 
/*     */   public AtomicPositiveInteger()
/*     */   {
/*  33 */     this.i = new AtomicInteger();
/*     */   }
/*     */ 
/*     */   public AtomicPositiveInteger(int initialValue) {
/*  37 */     this.i = new AtomicInteger(initialValue);
/*     */   }
/*     */ 
/*     */   public final int getAndIncrement() {
/*     */     while (true) {
/*  42 */       int current = this.i.get();
/*  43 */       int next = current >= 2147483647 ? 0 : current + 1;
/*  44 */       if (this.i.compareAndSet(current, next))
/*  45 */         return current;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final int getAndDecrement()
/*     */   {
/*     */     while (true) {
/*  52 */       int current = this.i.get();
/*  53 */       int next = current <= 0 ? 2147483647 : current - 1;
/*  54 */       if (this.i.compareAndSet(current, next))
/*  55 */         return current;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final int incrementAndGet()
/*     */   {
/*     */     while (true) {
/*  62 */       int current = this.i.get();
/*  63 */       int next = current >= 2147483647 ? 0 : current + 1;
/*  64 */       if (this.i.compareAndSet(current, next))
/*  65 */         return next;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final int decrementAndGet()
/*     */   {
/*     */     while (true) {
/*  72 */       int current = this.i.get();
/*  73 */       int next = current <= 0 ? 2147483647 : current - 1;
/*  74 */       if (this.i.compareAndSet(current, next))
/*  75 */         return next;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final int get()
/*     */   {
/*  81 */     return this.i.get();
/*     */   }
/*     */ 
/*     */   public final void set(int newValue) {
/*  85 */     if (newValue < 0) {
/*  86 */       throw new IllegalArgumentException("new value " + newValue + " < 0");
/*     */     }
/*  88 */     this.i.set(newValue);
/*     */   }
/*     */ 
/*     */   public final int getAndSet(int newValue) {
/*  92 */     if (newValue < 0) {
/*  93 */       throw new IllegalArgumentException("new value " + newValue + " < 0");
/*     */     }
/*  95 */     return this.i.getAndSet(newValue);
/*     */   }
/*     */ 
/*     */   public final int getAndAdd(int delta) {
/*  99 */     if (delta < 0)
/* 100 */       throw new IllegalArgumentException("delta " + delta + " < 0");
/*     */     while (true)
/*     */     {
/* 103 */       int current = this.i.get();
/* 104 */       int next = current >= 2147483647 - delta + 1 ? delta - 1 : current + delta;
/* 105 */       if (this.i.compareAndSet(current, next))
/* 106 */         return current;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final int addAndGet(int delta)
/*     */   {
/* 112 */     if (delta < 0)
/* 113 */       throw new IllegalArgumentException("delta " + delta + " < 0");
/*     */     while (true)
/*     */     {
/* 116 */       int current = this.i.get();
/* 117 */       int next = current >= 2147483647 - delta + 1 ? delta - 1 : current + delta;
/* 118 */       if (this.i.compareAndSet(current, next))
/* 119 */         return next;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final boolean compareAndSet(int expect, int update)
/*     */   {
/* 125 */     if (update < 0) {
/* 126 */       throw new IllegalArgumentException("update value " + update + " < 0");
/*     */     }
/* 128 */     return this.i.compareAndSet(expect, update);
/*     */   }
/*     */ 
/*     */   public final boolean weakCompareAndSet(int expect, int update) {
/* 132 */     if (update < 0) {
/* 133 */       throw new IllegalArgumentException("update value " + update + " < 0");
/*     */     }
/* 135 */     return this.i.weakCompareAndSet(expect, update);
/*     */   }
/*     */ 
/*     */   public byte byteValue() {
/* 139 */     return this.i.byteValue();
/*     */   }
/*     */ 
/*     */   public short shortValue() {
/* 143 */     return this.i.shortValue();
/*     */   }
/*     */ 
/*     */   public int intValue() {
/* 147 */     return this.i.intValue();
/*     */   }
/*     */ 
/*     */   public long longValue() {
/* 151 */     return this.i.longValue();
/*     */   }
/*     */ 
/*     */   public float floatValue() {
/* 155 */     return this.i.floatValue();
/*     */   }
/*     */ 
/*     */   public double doubleValue() {
/* 159 */     return this.i.doubleValue();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 163 */     return this.i.toString();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 168 */     int prime = 31;
/* 169 */     int result = 1;
/* 170 */     result = 31 * result + (this.i == null ? 0 : this.i.hashCode());
/* 171 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 176 */     if (this == obj) return true;
/* 177 */     if (obj == null) return false;
/* 178 */     if (getClass() != obj.getClass()) return false;
/* 179 */     AtomicPositiveInteger other = (AtomicPositiveInteger)obj;
/* 180 */     if (this.i == null) {
/* 181 */       if (other.i != null) return false; 
/*     */     }
/* 182 */     else if (!this.i.equals(other.i)) return false;
/* 183 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.AtomicPositiveInteger
 * JD-Core Version:    0.6.2
 */