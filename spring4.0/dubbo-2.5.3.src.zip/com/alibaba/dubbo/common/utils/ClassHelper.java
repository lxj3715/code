/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ClassHelper
/*     */ {
/*     */   public static final String ARRAY_SUFFIX = "[]";
/*     */   private static final String INTERNAL_ARRAY_PREFIX = "[L";
/* 169 */   private static final Map<String, Class<?>> primitiveTypeNameMap = new HashMap(16);
/*     */ 
/* 175 */   private static final Map<Class<?>, Class<?>> primitiveWrapperTypeMap = new HashMap(8);
/*     */ 
/*     */   public static Class<?> forNameWithThreadContextClassLoader(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*  30 */     return forName(name, Thread.currentThread().getContextClassLoader());
/*     */   }
/*     */ 
/*     */   public static Class<?> forNameWithCallerClassLoader(String name, Class<?> caller) throws ClassNotFoundException
/*     */   {
/*  35 */     return forName(name, caller.getClassLoader());
/*     */   }
/*     */ 
/*     */   public static ClassLoader getCallerClassLoader(Class<?> caller) {
/*  39 */     return caller.getClassLoader();
/*     */   }
/*     */ 
/*     */   public static ClassLoader getClassLoader(Class<?> cls)
/*     */   {
/*  49 */     ClassLoader cl = null;
/*     */     try {
/*  51 */       cl = Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     catch (Throwable ex) {
/*     */     }
/*  55 */     if (cl == null)
/*     */     {
/*  57 */       cl = cls.getClassLoader();
/*     */     }
/*  59 */     return cl;
/*     */   }
/*     */ 
/*     */   public static ClassLoader getClassLoader()
/*     */   {
/*  77 */     return getClassLoader(ClassHelper.class);
/*     */   }
/*     */ 
/*     */   public static Class<?> forName(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*  85 */     return forName(name, getClassLoader());
/*     */   }
/*     */ 
/*     */   public static Class<?> forName(String name, ClassLoader classLoader)
/*     */     throws ClassNotFoundException, LinkageError
/*     */   {
/* 104 */     Class clazz = resolvePrimitiveClassName(name);
/* 105 */     if (clazz != null) {
/* 106 */       return clazz;
/*     */     }
/*     */ 
/* 110 */     if (name.endsWith("[]")) {
/* 111 */       String elementClassName = name.substring(0, name.length() - "[]".length());
/* 112 */       Class elementClass = forName(elementClassName, classLoader);
/* 113 */       return Array.newInstance(elementClass, 0).getClass();
/*     */     }
/*     */ 
/* 117 */     int internalArrayMarker = name.indexOf("[L");
/* 118 */     if ((internalArrayMarker != -1) && (name.endsWith(";"))) {
/* 119 */       String elementClassName = null;
/* 120 */       if (internalArrayMarker == 0) {
/* 121 */         elementClassName = name.substring("[L".length(), name.length() - 1);
/*     */       }
/* 123 */       else if (name.startsWith("[")) {
/* 124 */         elementClassName = name.substring(1);
/*     */       }
/* 126 */       Class elementClass = forName(elementClassName, classLoader);
/* 127 */       return Array.newInstance(elementClass, 0).getClass();
/*     */     }
/*     */ 
/* 130 */     ClassLoader classLoaderToUse = classLoader;
/* 131 */     if (classLoaderToUse == null) {
/* 132 */       classLoaderToUse = getClassLoader();
/*     */     }
/* 134 */     return classLoaderToUse.loadClass(name);
/*     */   }
/*     */ 
/*     */   public static Class<?> resolvePrimitiveClassName(String name)
/*     */   {
/* 150 */     Class result = null;
/*     */ 
/* 153 */     if ((name != null) && (name.length() <= 8))
/*     */     {
/* 155 */       result = (Class)primitiveTypeNameMap.get(name);
/*     */     }
/* 157 */     return result;
/*     */   }
/*     */ 
/*     */   public static String toShortString(Object obj)
/*     */   {
/* 199 */     if (obj == null) {
/* 200 */       return "null";
/*     */     }
/* 202 */     return obj.getClass().getSimpleName() + "@" + System.identityHashCode(obj);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 178 */     primitiveWrapperTypeMap.put(Boolean.class, Boolean.TYPE);
/* 179 */     primitiveWrapperTypeMap.put(Byte.class, Byte.TYPE);
/* 180 */     primitiveWrapperTypeMap.put(Character.class, Character.TYPE);
/* 181 */     primitiveWrapperTypeMap.put(Double.class, Double.TYPE);
/* 182 */     primitiveWrapperTypeMap.put(Float.class, Float.TYPE);
/* 183 */     primitiveWrapperTypeMap.put(Integer.class, Integer.TYPE);
/* 184 */     primitiveWrapperTypeMap.put(Long.class, Long.TYPE);
/* 185 */     primitiveWrapperTypeMap.put(Short.class, Short.TYPE);
/*     */ 
/* 187 */     Set primitiveTypeNames = new HashSet(16);
/* 188 */     primitiveTypeNames.addAll(primitiveWrapperTypeMap.values());
/* 189 */     primitiveTypeNames.addAll(Arrays.asList(new Class[] { [Z.class, [B.class, [C.class, [D.class, [F.class, [I.class, [J.class, [S.class }));
/*     */ 
/* 192 */     for (Iterator it = primitiveTypeNames.iterator(); it.hasNext(); ) {
/* 193 */       Class primitiveClass = (Class)it.next();
/* 194 */       primitiveTypeNameMap.put(primitiveClass.getName(), primitiveClass);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.ClassHelper
 * JD-Core Version:    0.6.2
 */