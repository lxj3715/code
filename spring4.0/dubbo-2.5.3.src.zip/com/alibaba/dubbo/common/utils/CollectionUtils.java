/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class CollectionUtils
/*     */ {
/*  36 */   private static final Comparator<String> SIMPLE_NAME_COMPARATOR = new Comparator() {
/*     */     public int compare(String s1, String s2) {
/*  38 */       if ((s1 == null) && (s2 == null)) {
/*  39 */         return 0;
/*     */       }
/*  41 */       if (s1 == null) {
/*  42 */         return -1;
/*     */       }
/*  44 */       if (s2 == null) {
/*  45 */         return 1;
/*     */       }
/*  47 */       int i1 = s1.lastIndexOf('.');
/*  48 */       if (i1 >= 0) {
/*  49 */         s1 = s1.substring(i1 + 1);
/*     */       }
/*  51 */       int i2 = s2.lastIndexOf('.');
/*  52 */       if (i2 >= 0) {
/*  53 */         s2 = s2.substring(i2 + 1);
/*     */       }
/*  55 */       return s1.compareToIgnoreCase(s2);
/*     */     }
/*  36 */   };
/*     */ 
/*     */   public static <T> List<T> sort(List<T> list)
/*     */   {
/*  30 */     if ((list != null) && (list.size() > 0)) {
/*  31 */       Collections.sort(list);
/*     */     }
/*  33 */     return list;
/*     */   }
/*     */ 
/*     */   public static List<String> sortSimpleName(List<String> list)
/*     */   {
/*  60 */     if ((list != null) && (list.size() > 0)) {
/*  61 */       Collections.sort(list, SIMPLE_NAME_COMPARATOR);
/*     */     }
/*  63 */     return list;
/*     */   }
/*     */ 
/*     */   public static Map<String, Map<String, String>> splitAll(Map<String, List<String>> list, String separator) {
/*  67 */     if (list == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     Map result = new HashMap();
/*  71 */     for (Map.Entry entry : list.entrySet()) {
/*  72 */       result.put(entry.getKey(), split((List)entry.getValue(), separator));
/*     */     }
/*  74 */     return result;
/*     */   }
/*     */ 
/*     */   public static Map<String, List<String>> joinAll(Map<String, Map<String, String>> map, String separator) {
/*  78 */     if (map == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     Map result = new HashMap();
/*  82 */     for (Map.Entry entry : map.entrySet()) {
/*  83 */       result.put(entry.getKey(), join((Map)entry.getValue(), separator));
/*     */     }
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */   public static Map<String, String> split(List<String> list, String separator) {
/*  89 */     if (list == null) {
/*  90 */       return null;
/*     */     }
/*  92 */     Map map = new HashMap();
/*  93 */     if ((list == null) || (list.size() == 0)) {
/*  94 */       return map;
/*     */     }
/*  96 */     for (String item : list) {
/*  97 */       int index = item.indexOf(separator);
/*  98 */       if (index == -1)
/*  99 */         map.put(item, "");
/*     */       else {
/* 101 */         map.put(item.substring(0, index), item.substring(index + 1));
/*     */       }
/*     */     }
/* 104 */     return map;
/*     */   }
/*     */ 
/*     */   public static List<String> join(Map<String, String> map, String separator) {
/* 108 */     if (map == null) {
/* 109 */       return null;
/*     */     }
/* 111 */     List list = new ArrayList();
/* 112 */     if ((map == null) || (map.size() == 0)) {
/* 113 */       return list;
/*     */     }
/* 115 */     for (Map.Entry entry : map.entrySet()) {
/* 116 */       String key = (String)entry.getKey();
/* 117 */       String value = (String)entry.getValue();
/* 118 */       if ((value == null) || (value.length() == 0))
/* 119 */         list.add(key);
/*     */       else {
/* 121 */         list.add(key + separator + value);
/*     */       }
/*     */     }
/* 124 */     return list;
/*     */   }
/*     */ 
/*     */   public static String join(List<String> list, String separator) {
/* 128 */     StringBuilder sb = new StringBuilder();
/* 129 */     for (String ele : list) {
/* 130 */       if (sb.length() > 0) {
/* 131 */         sb.append(separator);
/*     */       }
/* 133 */       sb.append(ele);
/*     */     }
/* 135 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static boolean mapEquals(Map<?, ?> map1, Map<?, ?> map2) {
/* 139 */     if ((map1 == null) && (map2 == null)) {
/* 140 */       return true;
/*     */     }
/* 142 */     if ((map1 == null) || (map2 == null)) {
/* 143 */       return false;
/*     */     }
/* 145 */     if (map1.size() != map2.size()) {
/* 146 */       return false;
/*     */     }
/* 148 */     for (Map.Entry entry : map1.entrySet()) {
/* 149 */       Object key = entry.getKey();
/* 150 */       Object value1 = entry.getValue();
/* 151 */       Object value2 = map2.get(key);
/* 152 */       if (!objectEquals(value1, value2)) {
/* 153 */         return false;
/*     */       }
/*     */     }
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   private static boolean objectEquals(Object obj1, Object obj2) {
/* 160 */     if ((obj1 == null) && (obj2 == null)) {
/* 161 */       return true;
/*     */     }
/* 163 */     if ((obj1 == null) || (obj2 == null)) {
/* 164 */       return false;
/*     */     }
/* 166 */     return obj1.equals(obj2);
/*     */   }
/*     */ 
/*     */   public static Map<String, String> toStringMap(String[] pairs) {
/* 170 */     Map parameters = new HashMap();
/* 171 */     if (pairs.length > 0) {
/* 172 */       if (pairs.length % 2 != 0) {
/* 173 */         throw new IllegalArgumentException("pairs must be even.");
/*     */       }
/* 175 */       for (int i = 0; i < pairs.length; i += 2) {
/* 176 */         parameters.put(pairs[i], pairs[(i + 1)]);
/*     */       }
/*     */     }
/* 179 */     return parameters;
/*     */   }
/*     */ 
/*     */   public static <K, V> Map<K, V> toMap(Object[] pairs)
/*     */   {
/* 184 */     Map ret = new HashMap();
/* 185 */     if ((pairs == null) || (pairs.length == 0)) return ret;
/*     */ 
/* 187 */     if (pairs.length % 2 != 0) {
/* 188 */       throw new IllegalArgumentException("Map pairs can not be odd number.");
/*     */     }
/* 190 */     int len = pairs.length / 2;
/* 191 */     for (int i = 0; i < len; i++) {
/* 192 */       ret.put(pairs[(2 * i)], pairs[(2 * i + 1)]);
/*     */     }
/* 194 */     return ret;
/*     */   }
/*     */ 
/*     */   public static boolean isEmpty(Collection<?> collection) {
/* 198 */     return (collection == null) || (collection.size() == 0);
/*     */   }
/*     */ 
/*     */   public static boolean isNotEmpty(Collection<?> collection) {
/* 202 */     return (collection != null) && (collection.size() > 0);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.CollectionUtils
 * JD-Core Version:    0.6.2
 */