/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class CompatibleTypeUtils
/*     */ {
/*     */   private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
/*     */ 
/*     */   public static Object compatibleTypeConvert(Object value, Class<?> type)
/*     */   {
/*  51 */     if ((value == null) || (type == null) || (type.isAssignableFrom(value.getClass()))) {
/*  52 */       return value;
/*     */     }
/*  54 */     if ((value instanceof String)) {
/*  55 */       String string = (String)value;
/*  56 */       if ((Character.TYPE.equals(type)) || (Character.class.equals(type))) {
/*  57 */         if (string.length() != 1) {
/*  58 */           throw new IllegalArgumentException(String.format("CAN NOT convert String(%s) to char! when convert String to char, the String MUST only 1 char.", new Object[] { string }));
/*     */         }
/*     */ 
/*  61 */         return Character.valueOf(string.charAt(0));
/*  62 */       }if (type.isEnum())
/*  63 */         return Enum.valueOf(type, string);
/*  64 */       if (type == BigInteger.class)
/*  65 */         return new BigInteger(string);
/*  66 */       if (type == BigDecimal.class)
/*  67 */         return new BigDecimal(string);
/*  68 */       if ((type == Short.class) || (type == Short.TYPE))
/*  69 */         return new Short(string);
/*  70 */       if ((type == Integer.class) || (type == Integer.TYPE))
/*  71 */         return new Integer(string);
/*  72 */       if ((type == Long.class) || (type == Long.TYPE))
/*  73 */         return new Long(string);
/*  74 */       if ((type == Double.class) || (type == Double.TYPE))
/*  75 */         return new Double(string);
/*  76 */       if ((type == Float.class) || (type == Float.TYPE))
/*  77 */         return new Float(string);
/*  78 */       if ((type == Byte.class) || (type == Byte.TYPE))
/*  79 */         return new Byte(string);
/*  80 */       if ((type == Boolean.class) || (type == Boolean.TYPE))
/*  81 */         return new Boolean(string);
/*  82 */       if (type == Date.class)
/*     */         try {
/*  84 */           return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse((String)value);
/*     */         } catch (ParseException e) {
/*  86 */           throw new IllegalStateException("Failed to parse date " + value + " by format " + "yyyy-MM-dd HH:mm:ss" + ", cause: " + e.getMessage(), e);
/*     */         }
/*  88 */       if (type == Class.class)
/*     */         try {
/*  90 */           return ReflectUtils.name2class((String)value);
/*     */         } catch (ClassNotFoundException e) {
/*  92 */           throw new RuntimeException(e.getMessage(), e);
/*     */         }
/*     */     }
/*  95 */     else if ((value instanceof Number)) {
/*  96 */       Number number = (Number)value;
/*  97 */       if ((type == Byte.TYPE) || (type == Byte.class))
/*  98 */         return Byte.valueOf(number.byteValue());
/*  99 */       if ((type == Short.TYPE) || (type == Short.class))
/* 100 */         return Short.valueOf(number.shortValue());
/* 101 */       if ((type == Integer.TYPE) || (type == Integer.class))
/* 102 */         return Integer.valueOf(number.intValue());
/* 103 */       if ((type == Long.TYPE) || (type == Long.class))
/* 104 */         return Long.valueOf(number.longValue());
/* 105 */       if ((type == Float.TYPE) || (type == Float.class))
/* 106 */         return Float.valueOf(number.floatValue());
/* 107 */       if ((type == Double.TYPE) || (type == Double.class))
/* 108 */         return Double.valueOf(number.doubleValue());
/* 109 */       if (type == BigInteger.class)
/* 110 */         return BigInteger.valueOf(number.longValue());
/* 111 */       if (type == BigDecimal.class)
/* 112 */         return BigDecimal.valueOf(number.doubleValue());
/* 113 */       if (type == Date.class)
/* 114 */         return new Date(number.longValue());
/*     */     }
/* 116 */     else if ((value instanceof Collection)) {
/* 117 */       Collection collection = (Collection)value;
/* 118 */       if (type.isArray()) {
/* 119 */         int length = collection.size();
/* 120 */         Object array = Array.newInstance(type.getComponentType(), length);
/* 121 */         int i = 0;
/* 122 */         for (Iterator i$ = collection.iterator(); i$.hasNext(); ) { Object item = i$.next();
/* 123 */           Array.set(array, i++, item);
/*     */         }
/* 125 */         return array;
/* 126 */       }if (!type.isInterface()) {
/*     */         try {
/* 128 */           Collection result = (Collection)type.newInstance();
/* 129 */           result.addAll(collection);
/* 130 */           return result; } catch (Throwable e) {
/*     */         }
/*     */       } else {
/* 133 */         if (type == List.class)
/* 134 */           return new ArrayList(collection);
/* 135 */         if (type == Set.class)
/* 136 */           return new HashSet(collection);
/*     */       }
/* 138 */     } else if ((value.getClass().isArray()) && (Collection.class.isAssignableFrom(type)))
/*     */     {
/*     */       Collection collection;
/* 140 */       if (!type.isInterface()) {
/*     */         try {
/* 142 */           collection = (Collection)type.newInstance();
/*     */         } catch (Throwable e) {
/* 144 */           Collection collection = new ArrayList();
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*     */         Collection collection;
/* 146 */         if (type == Set.class)
/* 147 */           collection = new HashSet();
/*     */         else
/* 149 */           collection = new ArrayList();
/*     */       }
/* 151 */       int length = Array.getLength(value);
/* 152 */       for (int i = 0; i < length; i++) {
/* 153 */         collection.add(Array.get(value, i));
/*     */       }
/* 155 */       return collection;
/*     */     }
/* 157 */     return value;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.CompatibleTypeUtils
 * JD-Core Version:    0.6.2
 */