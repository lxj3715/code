/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ public class ConcurrentHashSet<E> extends AbstractSet<E>
/*     */   implements Set<E>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8672117787651310382L;
/*  28 */   private static final Object PRESENT = new Object();
/*     */   private final ConcurrentHashMap<E, Object> map;
/*     */ 
/*     */   public ConcurrentHashSet()
/*     */   {
/*  33 */     this.map = new ConcurrentHashMap();
/*     */   }
/*     */ 
/*     */   public ConcurrentHashSet(int initialCapacity) {
/*  37 */     this.map = new ConcurrentHashMap(initialCapacity);
/*     */   }
/*     */ 
/*     */   public Iterator<E> iterator()
/*     */   {
/*  48 */     return this.map.keySet().iterator();
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*  57 */     return this.map.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  66 */     return this.map.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean contains(Object o)
/*     */   {
/*  80 */     return this.map.containsKey(o);
/*     */   }
/*     */ 
/*     */   public boolean add(E e)
/*     */   {
/*  97 */     return this.map.put(e, PRESENT) == null;
/*     */   }
/*     */ 
/*     */   public boolean remove(Object o)
/*     */   {
/* 113 */     return this.map.remove(o) == PRESENT;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 121 */     this.map.clear();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.ConcurrentHashSet
 * JD-Core Version:    0.6.2
 */