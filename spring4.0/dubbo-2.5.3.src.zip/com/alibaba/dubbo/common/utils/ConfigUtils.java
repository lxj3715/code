/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.RuntimeMXBean;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class ConfigUtils
/*     */ {
/*  41 */   private static final Logger logger = LoggerFactory.getLogger(ConfigUtils.class);
/*     */ 
/* 118 */   private static Pattern VARIABLE_PATTERN = Pattern.compile("\\$\\s*\\{?\\s*([\\._0-9a-zA-Z]+)\\s*\\}?");
/*     */   private static volatile Properties PROPERTIES;
/* 283 */   private static int PID = -1;
/*     */ 
/*     */   public static boolean isNotEmpty(String value)
/*     */   {
/*  44 */     return !isEmpty(value);
/*     */   }
/*     */ 
/*     */   public static boolean isEmpty(String value) {
/*  48 */     return (value == null) || (value.length() == 0) || ("false".equalsIgnoreCase(value)) || ("0".equalsIgnoreCase(value)) || ("null".equalsIgnoreCase(value)) || ("N/A".equalsIgnoreCase(value));
/*     */   }
/*     */ 
/*     */   public static boolean isDefault(String value)
/*     */   {
/*  56 */     return ("true".equalsIgnoreCase(value)) || ("default".equalsIgnoreCase(value));
/*     */   }
/*     */ 
/*     */   public static List<String> mergeValues(Class<?> type, String cfg, List<String> def)
/*     */   {
/*  74 */     List defaults = new ArrayList();
/*  75 */     if (def != null) {
/*  76 */       for (String name : def) {
/*  77 */         if (ExtensionLoader.getExtensionLoader(type).hasExtension(name)) {
/*  78 */           defaults.add(name);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  83 */     List names = new ArrayList();
/*     */ 
/*  86 */     String[] configs = (cfg == null) || (cfg.trim().length() == 0) ? new String[0] : Constants.COMMA_SPLIT_PATTERN.split(cfg);
/*  87 */     for (String config : configs) {
/*  88 */       if ((config != null) && (config.trim().length() > 0)) {
/*  89 */         names.add(config);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  94 */     if (!names.contains("-default"))
/*     */     {
/*  96 */       int i = names.indexOf("default");
/*  97 */       if (i > 0)
/*  98 */         names.addAll(i, defaults);
/*     */       else {
/* 100 */         names.addAll(0, defaults);
/*     */       }
/* 102 */       names.remove("default");
/*     */     }
/*     */     else {
/* 105 */       names.remove("default");
/*     */     }
/*     */ 
/* 109 */     for (String name : new ArrayList(names)) {
/* 110 */       if (name.startsWith("-")) {
/* 111 */         names.remove(name);
/* 112 */         names.remove(name.substring(1));
/*     */       }
/*     */     }
/* 115 */     return names;
/*     */   }
/*     */ 
/*     */   public static String replaceProperty(String expression, Map<String, String> params)
/*     */   {
/* 122 */     if ((expression == null) || (expression.length() == 0) || (expression.indexOf('$') < 0)) {
/* 123 */       return expression;
/*     */     }
/* 125 */     Matcher matcher = VARIABLE_PATTERN.matcher(expression);
/* 126 */     StringBuffer sb = new StringBuffer();
/* 127 */     while (matcher.find()) {
/* 128 */       String key = matcher.group(1);
/* 129 */       String value = System.getProperty(key);
/* 130 */       if ((value == null) && (params != null)) {
/* 131 */         value = (String)params.get(key);
/*     */       }
/* 133 */       if (value == null) {
/* 134 */         value = "";
/*     */       }
/* 136 */       matcher.appendReplacement(sb, Matcher.quoteReplacement(value));
/*     */     }
/* 138 */     matcher.appendTail(sb);
/* 139 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static Properties getProperties()
/*     */   {
/* 145 */     if (PROPERTIES == null) {
/* 146 */       synchronized (ConfigUtils.class) {
/* 147 */         if (PROPERTIES == null) {
/* 148 */           String path = System.getProperty("dubbo.properties.file");
/* 149 */           if ((path == null) || (path.length() == 0)) {
/* 150 */             path = System.getenv("dubbo.properties.file");
/* 151 */             if ((path == null) || (path.length() == 0)) {
/* 152 */               path = "dubbo.properties";
/*     */             }
/*     */           }
/* 155 */           PROPERTIES = loadProperties(path, false, true);
/*     */         }
/*     */       }
/*     */     }
/* 159 */     return PROPERTIES;
/*     */   }
/*     */ 
/*     */   public static void addProperties(Properties properties) {
/* 163 */     if (properties != null)
/* 164 */       getProperties().putAll(properties);
/*     */   }
/*     */ 
/*     */   public static void setProperties(Properties properties)
/*     */   {
/* 169 */     if (properties != null)
/* 170 */       PROPERTIES = properties;
/*     */   }
/*     */ 
/*     */   public static String getProperty(String key)
/*     */   {
/* 175 */     return getProperty(key, null);
/*     */   }
/*     */ 
/*     */   public static String getProperty(String key, String defaultValue)
/*     */   {
/* 180 */     String value = System.getProperty(key);
/* 181 */     if ((value != null) && (value.length() > 0)) {
/* 182 */       return value;
/*     */     }
/* 184 */     Properties properties = getProperties();
/* 185 */     return replaceProperty(properties.getProperty(key, defaultValue), properties);
/*     */   }
/*     */ 
/*     */   public static Properties loadProperties(String fileName) {
/* 189 */     return loadProperties(fileName, false, false);
/*     */   }
/*     */ 
/*     */   public static Properties loadProperties(String fileName, boolean allowMultiFile) {
/* 193 */     return loadProperties(fileName, allowMultiFile, false);
/*     */   }
/*     */ 
/*     */   public static Properties loadProperties(String fileName, boolean allowMultiFile, boolean optional)
/*     */   {
/* 209 */     Properties properties = new Properties();
/* 210 */     if (fileName.startsWith("/")) {
/*     */       try {
/* 212 */         FileInputStream input = new FileInputStream(fileName);
/*     */         try {
/* 214 */           properties.load(input);
/*     */         } finally {
/* 216 */           input.close();
/*     */         }
/*     */       } catch (Throwable e) {
/* 219 */         logger.warn("Failed to load " + fileName + " file from " + fileName + "(ingore this file): " + e.getMessage(), e);
/*     */       }
/* 221 */       return properties;
/*     */     }
/*     */ 
/* 224 */     List list = new ArrayList();
/*     */     try {
/* 226 */       Enumeration urls = ClassHelper.getClassLoader().getResources(fileName);
/* 227 */       list = new ArrayList();
/* 228 */       while (urls.hasMoreElements())
/* 229 */         list.add(urls.nextElement());
/*     */     }
/*     */     catch (Throwable t) {
/* 232 */       logger.warn("Fail to load " + fileName + " file: " + t.getMessage(), t);
/*     */     }
/*     */ 
/* 235 */     if (list.size() == 0) {
/* 236 */       if (!optional) {
/* 237 */         logger.warn("No " + fileName + " found on the class path.");
/*     */       }
/* 239 */       return properties;
/*     */     }
/*     */ 
/* 242 */     if (!allowMultiFile) {
/* 243 */       if (list.size() > 1) {
/* 244 */         String errMsg = String.format("only 1 %s file is expected, but %d dubbo.properties files found on class path: %s", new Object[] { fileName, Integer.valueOf(list.size()), list.toString() });
/*     */ 
/* 246 */         logger.warn(errMsg);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 252 */         properties.load(ClassHelper.getClassLoader().getResourceAsStream(fileName));
/*     */       } catch (Throwable e) {
/* 254 */         logger.warn("Failed to load " + fileName + " file from " + fileName + "(ingore this file): " + e.getMessage(), e);
/*     */       }
/* 256 */       return properties;
/*     */     }
/*     */ 
/* 259 */     logger.info("load " + fileName + " properties file from " + list);
/*     */ 
/* 261 */     for (URL url : list) {
/*     */       try {
/* 263 */         Properties p = new Properties();
/* 264 */         InputStream input = url.openStream();
/* 265 */         if (input != null)
/*     */           try {
/* 267 */             p.load(input);
/* 268 */             properties.putAll(p);
/*     */           } finally {
/*     */             try {
/* 271 */               input.close();
/*     */             } catch (Throwable t) {
/*     */             }
/*     */           }
/*     */       } catch (Throwable e) {
/* 276 */         logger.warn("Fail to load " + fileName + " file from " + url + "(ingore this file): " + e.getMessage(), e);
/*     */       }
/*     */     }
/*     */ 
/* 280 */     return properties;
/*     */   }
/*     */ 
/*     */   public static int getPid()
/*     */   {
/* 286 */     if (PID < 0) {
/*     */       try {
/* 288 */         RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
/* 289 */         String name = runtime.getName();
/* 290 */         PID = Integer.parseInt(name.substring(0, name.indexOf('@')));
/*     */       } catch (Throwable e) {
/* 292 */         PID = 0;
/*     */       }
/*     */     }
/* 295 */     return PID;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.ConfigUtils
 * JD-Core Version:    0.6.2
 */