/*    */ package com.alibaba.dubbo.common.utils;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Category;
/*    */ import org.apache.log4j.ConsoleAppender;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ public class DubboAppender extends ConsoleAppender
/*    */ {
/* 26 */   public static boolean available = false;
/*    */ 
/* 28 */   public static List<Log> logList = new ArrayList();
/*    */ 
/*    */   public static void doStart() {
/* 31 */     available = true;
/*    */   }
/*    */ 
/*    */   public static void doStop() {
/* 35 */     available = false;
/*    */   }
/*    */ 
/*    */   public static void clear() {
/* 39 */     logList.clear();
/*    */   }
/*    */ 
/*    */   public void append(LoggingEvent event) {
/* 43 */     super.append(event);
/* 44 */     if (available == true) {
/* 45 */       Log temp = parseLog(event);
/* 46 */       logList.add(temp);
/*    */     }
/*    */   }
/*    */ 
/*    */   private Log parseLog(LoggingEvent event) {
/* 51 */     Log log = new Log();
/* 52 */     log.setLogName(event.getLogger().getName());
/* 53 */     log.setLogLevel(event.getLevel());
/* 54 */     log.setLogThread(event.getThreadName());
/* 55 */     log.setLogMessage(event.getMessage().toString());
/* 56 */     return log;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.DubboAppender
 * JD-Core Version:    0.6.2
 */