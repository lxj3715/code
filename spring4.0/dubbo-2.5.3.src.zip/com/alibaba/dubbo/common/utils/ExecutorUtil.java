/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class ExecutorUtil
/*     */ {
/*  34 */   private static final Logger logger = LoggerFactory.getLogger(ExecutorUtil.class);
/*  35 */   private static final ThreadPoolExecutor shutdownExecutor = new ThreadPoolExecutor(0, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue(100), new NamedThreadFactory("Close-ExecutorService-Timer", true));
/*     */ 
/*     */   public static boolean isShutdown(Executor executor)
/*     */   {
/*  41 */     if (((executor instanceof ExecutorService)) && 
/*  42 */       (((ExecutorService)executor).isShutdown())) {
/*  43 */       return true;
/*     */     }
/*     */ 
/*  46 */     return false;
/*     */   }
/*     */   public static void gracefulShutdown(Executor executor, int timeout) {
/*  49 */     if ((!(executor instanceof ExecutorService)) || (isShutdown(executor))) {
/*  50 */       return;
/*     */     }
/*  52 */     ExecutorService es = (ExecutorService)executor;
/*     */     try {
/*  54 */       es.shutdown();
/*     */     } catch (SecurityException ex2) {
/*  56 */       return;
/*     */     } catch (NullPointerException ex2) {
/*  58 */       return;
/*     */     }
/*     */     try {
/*  61 */       if (!es.awaitTermination(timeout, TimeUnit.MILLISECONDS))
/*  62 */         es.shutdownNow();
/*     */     }
/*     */     catch (InterruptedException ex) {
/*  65 */       es.shutdownNow();
/*  66 */       Thread.currentThread().interrupt();
/*     */     }
/*  68 */     if (!isShutdown(es))
/*  69 */       newThreadToCloseExecutor(es);
/*     */   }
/*     */ 
/*     */   public static void shutdownNow(Executor executor, int timeout) {
/*  73 */     if ((!(executor instanceof ExecutorService)) || (isShutdown(executor))) {
/*  74 */       return;
/*     */     }
/*  76 */     ExecutorService es = (ExecutorService)executor;
/*     */     try {
/*  78 */       es.shutdownNow();
/*     */     } catch (SecurityException ex2) {
/*  80 */       return;
/*     */     } catch (NullPointerException ex2) {
/*  82 */       return;
/*     */     }
/*     */     try {
/*  85 */       es.awaitTermination(timeout, TimeUnit.MILLISECONDS);
/*     */     } catch (InterruptedException ex) {
/*  87 */       Thread.currentThread().interrupt();
/*     */     }
/*  89 */     if (!isShutdown(es))
/*  90 */       newThreadToCloseExecutor(es);
/*     */   }
/*     */ 
/*     */   private static void newThreadToCloseExecutor(ExecutorService es)
/*     */   {
/*  95 */     if (!isShutdown(es))
/*  96 */       shutdownExecutor.execute(new Runnable() {
/*     */         public void run() {
/*     */           try {
/*  99 */             for (int i = 0; i < 1000; i++) {
/* 100 */               this.val$es.shutdownNow();
/* 101 */               if (this.val$es.awaitTermination(10L, TimeUnit.MILLISECONDS))
/*     */                 break;
/*     */             }
/*     */           }
/*     */           catch (InterruptedException ex) {
/* 106 */             Thread.currentThread().interrupt();
/*     */           } catch (Throwable e) {
/* 108 */             ExecutorUtil.logger.warn(e.getMessage(), e);
/*     */           }
/*     */         }
/*     */       });
/*     */   }
/*     */ 
/*     */   public static URL setThreadName(URL url, String defaultName)
/*     */   {
/* 120 */     String name = url.getParameter("threadname", defaultName);
/* 121 */     name = 32 + name + "-" + url.getAddress();
/* 122 */     url = url.addParameter("threadname", name);
/* 123 */     return url;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.ExecutorUtil
 * JD-Core Version:    0.6.2
 */