/*    */ package com.alibaba.dubbo.common.utils;
/*    */ 
/*    */ public class Holder<T>
/*    */ {
/*    */   private volatile T value;
/*    */ 
/*    */   public void set(T value)
/*    */   {
/* 28 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public T get() {
/* 32 */     return this.value;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.Holder
 * JD-Core Version:    0.6.2
 */