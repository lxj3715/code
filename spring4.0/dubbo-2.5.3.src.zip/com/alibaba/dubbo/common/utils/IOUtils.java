/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class IOUtils
/*     */ {
/*     */   private static final int BUFFER_SIZE = 8192;
/*     */ 
/*     */   public static long write(InputStream is, OutputStream os)
/*     */     throws IOException
/*     */   {
/*  51 */     return write(is, os, 8192);
/*     */   }
/*     */ 
/*     */   public static long write(InputStream is, OutputStream os, int bufferSize)
/*     */     throws IOException
/*     */   {
/*  66 */     long total = 0L;
/*  67 */     byte[] buff = new byte[bufferSize];
/*  68 */     while (is.available() > 0)
/*     */     {
/*  70 */       int read = is.read(buff, 0, buff.length);
/*  71 */       if (read > 0)
/*     */       {
/*  73 */         os.write(buff, 0, read);
/*  74 */         total += read;
/*     */       }
/*     */     }
/*  77 */     return total;
/*     */   }
/*     */ 
/*     */   public static String read(Reader reader)
/*     */     throws IOException
/*     */   {
/*  89 */     StringWriter writer = new StringWriter();
/*     */     try
/*     */     {
/*  92 */       write(reader, writer);
/*  93 */       return writer.getBuffer().toString();
/*     */     } finally {
/*  95 */       writer.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static long write(Writer writer, String string)
/*     */     throws IOException
/*     */   {
/* 107 */     Reader reader = new StringReader(string);
/*     */     try { return write(reader, writer); } finally { reader.close(); }
/*     */ 
/*     */   }
/*     */ 
/*     */   public static long write(Reader reader, Writer writer)
/*     */     throws IOException
/*     */   {
/* 121 */     return write(reader, writer, 8192);
/*     */   }
/*     */ 
/*     */   public static long write(Reader reader, Writer writer, int bufferSize)
/*     */     throws IOException
/*     */   {
/* 136 */     long total = 0L;
/* 137 */     char[] buf = new char[8192];
/*     */     int read;
/* 138 */     while ((read = reader.read(buf)) != -1)
/*     */     {
/* 140 */       writer.write(buf, 0, read);
/* 141 */       total += read;
/*     */     }
/* 143 */     return total;
/*     */   }
/*     */ 
/*     */   public static String[] readLines(File file)
/*     */     throws IOException
/*     */   {
/* 155 */     if ((file == null) || (!file.exists()) || (!file.canRead())) {
/* 156 */       return new String[0];
/*     */     }
/* 158 */     return readLines(new FileInputStream(file));
/*     */   }
/*     */ 
/*     */   public static String[] readLines(InputStream is)
/*     */     throws IOException
/*     */   {
/* 170 */     List lines = new ArrayList();
/* 171 */     BufferedReader reader = new BufferedReader(new InputStreamReader(is));
/*     */     try
/*     */     {
/*     */       String line;
/* 175 */       while ((line = reader.readLine()) != null)
/* 176 */         lines.add(line);
/* 177 */       return (String[])lines.toArray(new String[0]);
/*     */     }
/*     */     finally
/*     */     {
/* 181 */       reader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void writeLines(OutputStream os, String[] lines)
/*     */     throws IOException
/*     */   {
/* 194 */     PrintWriter writer = new PrintWriter(new OutputStreamWriter(os));
/*     */     try
/*     */     {
/* 197 */       for (String line : lines)
/* 198 */         writer.println(line);
/* 199 */       writer.flush();
/*     */     }
/*     */     finally
/*     */     {
/* 203 */       writer.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void writeLines(File file, String[] lines)
/*     */     throws IOException
/*     */   {
/* 216 */     if (file == null)
/* 217 */       throw new IOException("File is null.");
/* 218 */     writeLines(new FileOutputStream(file), lines);
/*     */   }
/*     */ 
/*     */   public static void appendLines(File file, String[] lines)
/*     */     throws IOException
/*     */   {
/* 230 */     if (file == null)
/* 231 */       throw new IOException("File is null.");
/* 232 */     writeLines(new FileOutputStream(file, true), lines);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.IOUtils
 * JD-Core Version:    0.6.2
 */