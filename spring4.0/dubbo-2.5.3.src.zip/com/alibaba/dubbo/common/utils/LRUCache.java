/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public class LRUCache<K, V> extends LinkedHashMap<K, V>
/*     */ {
/*     */   private static final long serialVersionUID = -5167631809472116969L;
/*     */   private static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   private static final int DEFAULT_MAX_CAPACITY = 1000;
/*     */   private volatile int maxCapacity;
/*  32 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */   public LRUCache() {
/*  35 */     this(1000);
/*     */   }
/*     */ 
/*     */   public LRUCache(int maxCapacity) {
/*  39 */     super(16, 0.75F, true);
/*  40 */     this.maxCapacity = maxCapacity;
/*     */   }
/*     */ 
/*     */   protected boolean removeEldestEntry(Map.Entry<K, V> eldest)
/*     */   {
/*  45 */     return size() > this.maxCapacity;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/*     */     try {
/*  51 */       this.lock.lock();
/*  52 */       return super.containsKey(key);
/*     */     } finally {
/*  54 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public V get(Object key)
/*     */   {
/*     */     try {
/*  61 */       this.lock.lock();
/*  62 */       return super.get(key);
/*     */     } finally {
/*  64 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public V put(K key, V value)
/*     */   {
/*     */     try {
/*  71 */       this.lock.lock();
/*  72 */       return super.put(key, value);
/*     */     } finally {
/*  74 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public V remove(Object key)
/*     */   {
/*     */     try {
/*  81 */       this.lock.lock();
/*  82 */       return super.remove(key);
/*     */     } finally {
/*  84 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*     */     try {
/*  91 */       this.lock.lock();
/*  92 */       return super.size();
/*     */     } finally {
/*  94 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*     */     try {
/* 101 */       this.lock.lock();
/* 102 */       super.clear();
/*     */     } finally {
/* 104 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMaxCapacity() {
/* 109 */     return this.maxCapacity;
/*     */   }
/*     */ 
/*     */   public void setMaxCapacity(int maxCapacity) {
/* 113 */     this.maxCapacity = maxCapacity;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.LRUCache
 * JD-Core Version:    0.6.2
 */