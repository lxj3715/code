/*    */ package com.alibaba.dubbo.common.utils;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.log4j.Level;
/*    */ 
/*    */ public class Log
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -534113138054377073L;
/*    */   private String logName;
/*    */   private Level logLevel;
/*    */   private String logMessage;
/*    */   private String logThread;
/*    */ 
/*    */   public String getLogName()
/*    */   {
/* 33 */     return this.logName;
/*    */   }
/*    */ 
/*    */   public void setLogName(String logName) {
/* 37 */     this.logName = logName;
/*    */   }
/*    */ 
/*    */   public Level getLogLevel() {
/* 41 */     return this.logLevel;
/*    */   }
/*    */ 
/*    */   public void setLogLevel(Level logLevel) {
/* 45 */     this.logLevel = logLevel;
/*    */   }
/*    */ 
/*    */   public String getLogMessage() {
/* 49 */     return this.logMessage;
/*    */   }
/*    */ 
/*    */   public void setLogMessage(String logMessage) {
/* 53 */     this.logMessage = logMessage;
/*    */   }
/*    */ 
/*    */   public String getLogThread() {
/* 57 */     return this.logThread;
/*    */   }
/*    */ 
/*    */   public void setLogThread(String logThread) {
/* 61 */     this.logThread = logThread;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 66 */     int prime = 31;
/* 67 */     int result = 1;
/* 68 */     result = 31 * result + (this.logLevel == null ? 0 : this.logLevel.hashCode());
/* 69 */     result = 31 * result + (this.logMessage == null ? 0 : this.logMessage.hashCode());
/* 70 */     result = 31 * result + (this.logName == null ? 0 : this.logName.hashCode());
/* 71 */     result = 31 * result + (this.logThread == null ? 0 : this.logThread.hashCode());
/* 72 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 77 */     if (this == obj) return true;
/* 78 */     if (obj == null) return false;
/* 79 */     if (getClass() != obj.getClass()) return false;
/* 80 */     Log other = (Log)obj;
/* 81 */     if (this.logLevel == null) {
/* 82 */       if (other.logLevel != null) return false; 
/*    */     }
/* 83 */     else if (!this.logLevel.equals(other.logLevel)) return false;
/* 84 */     if (this.logMessage == null) {
/* 85 */       if (other.logMessage != null) return false; 
/*    */     }
/* 86 */     else if (!this.logMessage.equals(other.logMessage)) return false;
/* 87 */     if (this.logName == null) {
/* 88 */       if (other.logName != null) return false; 
/*    */     }
/* 89 */     else if (!this.logName.equals(other.logName)) return false;
/* 90 */     if (this.logThread == null) {
/* 91 */       if (other.logThread != null) return false; 
/*    */     }
/* 92 */     else if (!this.logThread.equals(other.logThread)) return false;
/* 93 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.Log
 * JD-Core Version:    0.6.2
 */