/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ 
/*     */ public class LogHelper
/*     */ {
/*     */   public static void trace(Logger logger, String msg)
/*     */   {
/*  27 */     if (logger == null) {
/*  28 */       return;
/*     */     }
/*     */ 
/*  31 */     if (logger.isTraceEnabled())
/*  32 */       logger.trace(msg);
/*     */   }
/*     */ 
/*     */   public static void trace(Logger logger, Throwable throwable)
/*     */   {
/*  37 */     if (logger == null) {
/*  38 */       return;
/*     */     }
/*     */ 
/*  41 */     if (logger.isTraceEnabled())
/*  42 */       logger.trace(throwable);
/*     */   }
/*     */ 
/*     */   public static void trace(Logger logger, String msg, Throwable e)
/*     */   {
/*  47 */     if (logger == null) {
/*  48 */       return;
/*     */     }
/*     */ 
/*  51 */     if (logger.isTraceEnabled())
/*  52 */       logger.trace(msg, e);
/*     */   }
/*     */ 
/*     */   public static void debug(Logger logger, String msg)
/*     */   {
/*  57 */     if (logger == null) {
/*  58 */       return;
/*     */     }
/*     */ 
/*  61 */     if (logger.isDebugEnabled())
/*  62 */       logger.debug(msg);
/*     */   }
/*     */ 
/*     */   public static void debug(Logger logger, Throwable e)
/*     */   {
/*  67 */     if (logger == null) {
/*  68 */       return;
/*     */     }
/*     */ 
/*  71 */     if (logger.isDebugEnabled())
/*  72 */       logger.debug(e);
/*     */   }
/*     */ 
/*     */   public static void debug(Logger logger, String msg, Throwable e)
/*     */   {
/*  77 */     if (logger == null) {
/*  78 */       return;
/*     */     }
/*     */ 
/*  81 */     if (logger.isDebugEnabled())
/*  82 */       logger.debug(msg, e);
/*     */   }
/*     */ 
/*     */   public static void info(Logger logger, String msg)
/*     */   {
/*  87 */     if (logger == null) {
/*  88 */       return;
/*     */     }
/*     */ 
/*  91 */     if (logger.isInfoEnabled())
/*  92 */       logger.info(msg);
/*     */   }
/*     */ 
/*     */   public static void info(Logger logger, Throwable e)
/*     */   {
/*  97 */     if (logger == null) {
/*  98 */       return;
/*     */     }
/*     */ 
/* 101 */     if (logger.isInfoEnabled())
/* 102 */       logger.info(e);
/*     */   }
/*     */ 
/*     */   public static void info(Logger logger, String msg, Throwable e)
/*     */   {
/* 107 */     if (logger == null) {
/* 108 */       return;
/*     */     }
/*     */ 
/* 111 */     if (logger.isInfoEnabled())
/* 112 */       logger.info(msg, e);
/*     */   }
/*     */ 
/*     */   public static void warn(Logger logger, String msg, Throwable e)
/*     */   {
/* 117 */     if (logger == null) {
/* 118 */       return;
/*     */     }
/*     */ 
/* 121 */     if (logger.isWarnEnabled())
/* 122 */       logger.warn(msg, e);
/*     */   }
/*     */ 
/*     */   public static void warn(Logger logger, String msg)
/*     */   {
/* 127 */     if (logger == null) {
/* 128 */       return;
/*     */     }
/*     */ 
/* 131 */     if (logger.isWarnEnabled())
/* 132 */       logger.warn(msg);
/*     */   }
/*     */ 
/*     */   public static void warn(Logger logger, Throwable e)
/*     */   {
/* 137 */     if (logger == null) {
/* 138 */       return;
/*     */     }
/*     */ 
/* 141 */     if (logger.isWarnEnabled())
/* 142 */       logger.warn(e);
/*     */   }
/*     */ 
/*     */   public static void error(Logger logger, Throwable e)
/*     */   {
/* 147 */     if (logger == null) {
/* 148 */       return;
/*     */     }
/*     */ 
/* 151 */     if (logger.isErrorEnabled())
/* 152 */       logger.error(e);
/*     */   }
/*     */ 
/*     */   public static void error(Logger logger, String msg)
/*     */   {
/* 157 */     if (logger == null) {
/* 158 */       return;
/*     */     }
/*     */ 
/* 161 */     if (logger.isErrorEnabled())
/* 162 */       logger.error(msg);
/*     */   }
/*     */ 
/*     */   public static void error(Logger logger, String msg, Throwable e)
/*     */   {
/* 167 */     if (logger == null) {
/* 168 */       return;
/*     */     }
/*     */ 
/* 171 */     if (logger.isErrorEnabled())
/* 172 */       logger.error(msg, e);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.LogHelper
 * JD-Core Version:    0.6.2
 */