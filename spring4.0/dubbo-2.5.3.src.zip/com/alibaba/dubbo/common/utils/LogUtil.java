/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Level;
/*     */ 
/*     */ public class LogUtil
/*     */ {
/*  31 */   private static Logger Log = LoggerFactory.getLogger(LogUtil.class);
/*     */ 
/*     */   public static void start() {
/*  34 */     DubboAppender.doStart();
/*     */   }
/*     */ 
/*     */   public static void stop() {
/*  38 */     DubboAppender.doStop();
/*     */   }
/*     */ 
/*     */   public static boolean checkNoError() {
/*  42 */     if (findLevel(Level.ERROR) == 0) {
/*  43 */       return true;
/*     */     }
/*  45 */     return false;
/*     */   }
/*     */ 
/*     */   public static int findName(String expectedLogName)
/*     */   {
/*  51 */     int count = 0;
/*  52 */     List logList = DubboAppender.logList;
/*  53 */     for (int i = 0; i < logList.size(); i++) {
/*  54 */       String logName = ((Log)logList.get(i)).getLogName();
/*  55 */       if (logName.contains(expectedLogName)) count++;
/*     */     }
/*  57 */     return count;
/*     */   }
/*     */ 
/*     */   public static int findLevel(Level expectedLevel) {
/*  61 */     int count = 0;
/*  62 */     List logList = DubboAppender.logList;
/*  63 */     for (int i = 0; i < logList.size(); i++) {
/*  64 */       Level logLevel = ((Log)logList.get(i)).getLogLevel();
/*  65 */       if (logLevel.equals(expectedLevel)) count++;
/*     */     }
/*  67 */     return count;
/*     */   }
/*     */ 
/*     */   public static int findLevelWithThreadName(Level expectedLevel, String threadName) {
/*  71 */     int count = 0;
/*  72 */     List logList = DubboAppender.logList;
/*  73 */     for (int i = 0; i < logList.size(); i++) {
/*  74 */       Log log = (Log)logList.get(i);
/*  75 */       if ((log.getLogLevel().equals(expectedLevel)) && (log.getLogThread().equals(threadName)))
/*  76 */         count++;
/*     */     }
/*  78 */     return count;
/*     */   }
/*     */ 
/*     */   public static int findThread(String expectedThread) {
/*  82 */     int count = 0;
/*  83 */     List logList = DubboAppender.logList;
/*  84 */     for (int i = 0; i < logList.size(); i++) {
/*  85 */       String logThread = ((Log)logList.get(i)).getLogThread();
/*  86 */       if (logThread.contains(expectedThread)) count++;
/*     */     }
/*  88 */     return count;
/*     */   }
/*     */ 
/*     */   public static int findMessage(String expectedMessage) {
/*  92 */     int count = 0;
/*  93 */     List logList = DubboAppender.logList;
/*  94 */     for (int i = 0; i < logList.size(); i++) {
/*  95 */       String logMessage = ((Log)logList.get(i)).getLogMessage();
/*  96 */       if (logMessage.contains(expectedMessage)) count++;
/*     */     }
/*  98 */     return count;
/*     */   }
/*     */ 
/*     */   public static int findMessage(Level expectedLevel, String expectedMessage) {
/* 102 */     int count = 0;
/* 103 */     List logList = DubboAppender.logList;
/* 104 */     for (int i = 0; i < logList.size(); i++) {
/* 105 */       Level logLevel = ((Log)logList.get(i)).getLogLevel();
/* 106 */       if (logLevel.equals(expectedLevel)) {
/* 107 */         String logMessage = ((Log)logList.get(i)).getLogMessage();
/* 108 */         if (logMessage.contains(expectedMessage)) count++;
/*     */       }
/*     */     }
/* 111 */     return count;
/*     */   }
/*     */ 
/*     */   public static <T> void printList(List<T> list) {
/* 115 */     Log.info("PrintList:");
/* 116 */     Iterator it = list.iterator();
/* 117 */     while (it.hasNext())
/* 118 */       Log.info(it.next().toString());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.LogUtil
 * JD-Core Version:    0.6.2
 */