/*    */ package com.alibaba.dubbo.common.utils;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ public class NamedThreadFactory
/*    */   implements ThreadFactory
/*    */ {
/* 29 */   private static final AtomicInteger POOL_SEQ = new AtomicInteger(1);
/*    */ 
/* 31 */   private final AtomicInteger mThreadNum = new AtomicInteger(1);
/*    */   private final String mPrefix;
/*    */   private final boolean mDaemo;
/*    */   private final ThreadGroup mGroup;
/*    */ 
/*    */   public NamedThreadFactory()
/*    */   {
/* 41 */     this("pool-" + POOL_SEQ.getAndIncrement(), false);
/*    */   }
/*    */ 
/*    */   public NamedThreadFactory(String prefix)
/*    */   {
/* 46 */     this(prefix, false);
/*    */   }
/*    */ 
/*    */   public NamedThreadFactory(String prefix, boolean daemo)
/*    */   {
/* 51 */     this.mPrefix = (prefix + "-thread-");
/* 52 */     this.mDaemo = daemo;
/* 53 */     SecurityManager s = System.getSecurityManager();
/* 54 */     this.mGroup = (s == null ? Thread.currentThread().getThreadGroup() : s.getThreadGroup());
/*    */   }
/*    */ 
/*    */   public Thread newThread(Runnable runnable)
/*    */   {
/* 59 */     String name = this.mPrefix + this.mThreadNum.getAndIncrement();
/* 60 */     Thread ret = new Thread(this.mGroup, runnable, name, 0L);
/* 61 */     ret.setDaemon(this.mDaemo);
/* 62 */     return ret;
/*    */   }
/*    */ 
/*    */   public ThreadGroup getThreadGroup()
/*    */   {
/* 67 */     return this.mGroup;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.NamedThreadFactory
 * JD-Core Version:    0.6.2
 */