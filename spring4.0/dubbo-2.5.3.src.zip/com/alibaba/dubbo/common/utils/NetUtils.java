/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class NetUtils
/*     */ {
/*  41 */   private static final Logger logger = LoggerFactory.getLogger(NetUtils.class);
/*     */   public static final String LOCALHOST = "127.0.0.1";
/*     */   public static final String ANYHOST = "0.0.0.0";
/*     */   private static final int RND_PORT_START = 30000;
/*     */   private static final int RND_PORT_RANGE = 10000;
/*  51 */   private static final Random RANDOM = new Random(System.currentTimeMillis());
/*     */   private static final int MIN_PORT = 0;
/*     */   private static final int MAX_PORT = 65535;
/* 106 */   private static final Pattern ADDRESS_PATTERN = Pattern.compile("^\\d{1,3}(\\.\\d{1,3}){3}\\:\\d{1,5}$");
/*     */ 
/* 112 */   private static final Pattern LOCAL_IP_PATTERN = Pattern.compile("127(\\.\\d{1,3}){3}$");
/*     */ 
/* 141 */   private static final Pattern IP_PATTERN = Pattern.compile("\\d{1,3}(\\.\\d{1,3}){3,5}$");
/*     */ 
/* 180 */   private static volatile InetAddress LOCAL_ADDRESS = null;
/*     */ 
/* 241 */   private static final Map<String, String> hostNameCache = new LRUCache(1000);
/*     */ 
/*     */   public static int getRandomPort()
/*     */   {
/*  54 */     return 30000 + RANDOM.nextInt(10000);
/*     */   }
/*     */ 
/*     */   public static int getAvailablePort() {
/*  58 */     ServerSocket ss = null;
/*     */     try {
/*  60 */       ss = new ServerSocket();
/*  61 */       ss.bind(null);
/*  62 */       return ss.getLocalPort();
/*     */     } catch (IOException e) {
/*  64 */       return getRandomPort();
/*     */     } finally {
/*  66 */       if (ss != null)
/*     */         try {
/*  68 */           ss.close();
/*     */         }
/*     */         catch (IOException e) {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getAvailablePort(int port) {
/*  76 */     if (port <= 0) {
/*  77 */       return getAvailablePort();
/*     */     }
/*  79 */     for (int i = port; i < 65535; i++) {
/*  80 */       ServerSocket ss = null;
/*     */       try {
/*  82 */         ss = new ServerSocket(i);
/*  83 */         return i;
/*     */       } catch (IOException e) {
/*     */       }
/*     */       finally {
/*  87 */         if (ss != null)
/*     */           try {
/*  89 */             ss.close();
/*     */           }
/*     */           catch (IOException e) {
/*     */           }
/*     */       }
/*     */     }
/*  95 */     return port;
/*     */   }
/*     */ 
/*     */   public static boolean isInvalidPort(int port)
/*     */   {
/* 103 */     return (port > 0) || (port <= 65535);
/*     */   }
/*     */ 
/*     */   public static boolean isValidAddress(String address)
/*     */   {
/* 109 */     return ADDRESS_PATTERN.matcher(address).matches();
/*     */   }
/*     */ 
/*     */   public static boolean isLocalHost(String host)
/*     */   {
/* 115 */     return (host != null) && ((LOCAL_IP_PATTERN.matcher(host).matches()) || (host.equalsIgnoreCase("localhost")));
/*     */   }
/*     */ 
/*     */   public static boolean isAnyHost(String host)
/*     */   {
/* 121 */     return "0.0.0.0".equals(host);
/*     */   }
/*     */ 
/*     */   public static boolean isInvalidLocalHost(String host) {
/* 125 */     return (host == null) || (host.length() == 0) || (host.equalsIgnoreCase("localhost")) || (host.equals("0.0.0.0")) || (LOCAL_IP_PATTERN.matcher(host).matches());
/*     */   }
/*     */ 
/*     */   public static boolean isValidLocalHost(String host)
/*     */   {
/* 133 */     return !isInvalidLocalHost(host);
/*     */   }
/*     */ 
/*     */   public static InetSocketAddress getLocalSocketAddress(String host, int port) {
/* 137 */     return isInvalidLocalHost(host) ? new InetSocketAddress(port) : new InetSocketAddress(host, port);
/*     */   }
/*     */ 
/*     */   private static boolean isValidAddress(InetAddress address)
/*     */   {
/* 144 */     if ((address == null) || (address.isLoopbackAddress()))
/* 145 */       return false;
/* 146 */     String name = address.getHostAddress();
/* 147 */     return (name != null) && (!"0.0.0.0".equals(name)) && (!"127.0.0.1".equals(name)) && (IP_PATTERN.matcher(name).matches());
/*     */   }
/*     */ 
/*     */   public static String getLocalHost()
/*     */   {
/* 154 */     InetAddress address = getLocalAddress();
/* 155 */     return address == null ? "127.0.0.1" : address.getHostAddress();
/*     */   }
/*     */ 
/*     */   public static String filterLocalHost(String host) {
/* 159 */     if ((host == null) || (host.length() == 0)) {
/* 160 */       return host;
/*     */     }
/* 162 */     if (host.contains("://")) {
/* 163 */       URL u = URL.valueOf(host);
/* 164 */       if (isInvalidLocalHost(u.getHost()))
/* 165 */         return u.setHost(getLocalHost()).toFullString();
/*     */     }
/* 167 */     else if (host.contains(":")) {
/* 168 */       int i = host.lastIndexOf(':');
/* 169 */       if (isInvalidLocalHost(host.substring(0, i))) {
/* 170 */         return getLocalHost() + host.substring(i);
/*     */       }
/*     */     }
/* 173 */     else if (isInvalidLocalHost(host)) {
/* 174 */       return getLocalHost();
/*     */     }
/*     */ 
/* 177 */     return host;
/*     */   }
/*     */ 
/*     */   public static InetAddress getLocalAddress()
/*     */   {
/* 188 */     if (LOCAL_ADDRESS != null)
/* 189 */       return LOCAL_ADDRESS;
/* 190 */     InetAddress localAddress = getLocalAddress0();
/* 191 */     LOCAL_ADDRESS = localAddress;
/* 192 */     return localAddress;
/*     */   }
/*     */ 
/*     */   public static String getLogHost() {
/* 196 */     InetAddress address = LOCAL_ADDRESS;
/* 197 */     return address == null ? "127.0.0.1" : address.getHostAddress();
/*     */   }
/*     */ 
/*     */   private static InetAddress getLocalAddress0() {
/* 201 */     InetAddress localAddress = null;
/*     */     try {
/* 203 */       localAddress = InetAddress.getLocalHost();
/* 204 */       if (isValidAddress(localAddress))
/* 205 */         return localAddress;
/*     */     }
/*     */     catch (Throwable e) {
/* 208 */       logger.warn("Failed to retriving ip address, " + e.getMessage(), e);
/*     */     }
/*     */     try {
/* 211 */       Enumeration interfaces = NetworkInterface.getNetworkInterfaces();
/* 212 */       if (interfaces != null)
/* 213 */         while (interfaces.hasMoreElements())
/*     */           try {
/* 215 */             NetworkInterface network = (NetworkInterface)interfaces.nextElement();
/* 216 */             Enumeration addresses = network.getInetAddresses();
/* 217 */             if (addresses != null)
/* 218 */               while (addresses.hasMoreElements())
/*     */                 try {
/* 220 */                   InetAddress address = (InetAddress)addresses.nextElement();
/* 221 */                   if (isValidAddress(address))
/* 222 */                     return address;
/*     */                 }
/*     */                 catch (Throwable e) {
/* 225 */                   logger.warn("Failed to retriving ip address, " + e.getMessage(), e);
/*     */                 }
/*     */           }
/*     */           catch (Throwable e)
/*     */           {
/* 230 */             logger.warn("Failed to retriving ip address, " + e.getMessage(), e);
/*     */           }
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 235 */       logger.warn("Failed to retriving ip address, " + e.getMessage(), e);
/*     */     }
/* 237 */     logger.error("Could not get local host ip address, will use 127.0.0.1 instead.");
/* 238 */     return localAddress;
/*     */   }
/*     */ 
/*     */   public static String getHostName(String address)
/*     */   {
/*     */     try
/*     */     {
/* 245 */       int i = address.indexOf(':');
/* 246 */       if (i > -1) {
/* 247 */         address = address.substring(0, i);
/*     */       }
/* 249 */       String hostname = (String)hostNameCache.get(address);
/* 250 */       if ((hostname != null) && (hostname.length() > 0)) {
/* 251 */         return hostname;
/*     */       }
/* 253 */       InetAddress inetAddress = InetAddress.getByName(address);
/* 254 */       if (inetAddress != null) {
/* 255 */         hostname = inetAddress.getHostName();
/* 256 */         hostNameCache.put(address, hostname);
/* 257 */         return hostname;
/*     */       }
/*     */     }
/*     */     catch (Throwable e) {
/*     */     }
/* 262 */     return address;
/*     */   }
/*     */ 
/*     */   public static String getIpByHost(String hostName)
/*     */   {
/*     */     try
/*     */     {
/* 271 */       return InetAddress.getByName(hostName).getHostAddress(); } catch (UnknownHostException e) {
/*     */     }
/* 273 */     return hostName;
/*     */   }
/*     */ 
/*     */   public static String toAddressString(InetSocketAddress address)
/*     */   {
/* 278 */     return address.getAddress().getHostAddress() + ":" + address.getPort();
/*     */   }
/*     */ 
/*     */   public static InetSocketAddress toAddress(String address) {
/* 282 */     int i = address.indexOf(':');
/*     */     int port;
/*     */     String host;
/*     */     int port;
/* 285 */     if (i > -1) {
/* 286 */       String host = address.substring(0, i);
/* 287 */       port = Integer.parseInt(address.substring(i + 1));
/*     */     } else {
/* 289 */       host = address;
/* 290 */       port = 0;
/*     */     }
/* 292 */     return new InetSocketAddress(host, port);
/*     */   }
/*     */ 
/*     */   public static String toURL(String protocol, String host, int port, String path) {
/* 296 */     StringBuilder sb = new StringBuilder();
/* 297 */     sb.append(protocol).append("://");
/* 298 */     sb.append(host).append(':').append(port);
/* 299 */     if (path.charAt(0) != '/')
/* 300 */       sb.append('/');
/* 301 */     sb.append(path);
/* 302 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.NetUtils
 * JD-Core Version:    0.6.2
 */