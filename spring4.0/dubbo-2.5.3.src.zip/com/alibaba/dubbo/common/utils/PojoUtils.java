/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.TreeMap;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.ConcurrentSkipListMap;
/*     */ 
/*     */ public class PojoUtils
/*     */ {
/*  62 */   private static final ConcurrentMap<String, Method> NAME_METHODS_CACHE = new ConcurrentHashMap();
/*  63 */   private static final ConcurrentMap<Class<?>, ConcurrentMap<String, Field>> CLASS_FIELD_CACHE = new ConcurrentHashMap();
/*     */ 
/*     */   public static Object[] generalize(Object[] objs)
/*     */   {
/*  67 */     Object[] dests = new Object[objs.length];
/*  68 */     for (int i = 0; i < objs.length; i++) {
/*  69 */       dests[i] = generalize(objs[i]);
/*     */     }
/*  71 */     return dests;
/*     */   }
/*     */ 
/*     */   public static Object[] realize(Object[] objs, Class<?>[] types) {
/*  75 */     if (objs.length != types.length)
/*  76 */       throw new IllegalArgumentException("args.length != types.length");
/*  77 */     Object[] dests = new Object[objs.length];
/*  78 */     for (int i = 0; i < objs.length; i++) {
/*  79 */       dests[i] = realize(objs[i], types[i]);
/*     */     }
/*  81 */     return dests;
/*     */   }
/*     */ 
/*     */   public static Object[] realize(Object[] objs, Class<?>[] types, Type[] gtypes) {
/*  85 */     if ((objs.length != types.length) || (objs.length != gtypes.length))
/*     */     {
/*  87 */       throw new IllegalArgumentException("args.length != types.length");
/*  88 */     }Object[] dests = new Object[objs.length];
/*  89 */     for (int i = 0; i < objs.length; i++) {
/*  90 */       dests[i] = realize(objs[i], types[i], gtypes[i]);
/*     */     }
/*  92 */     return dests;
/*     */   }
/*     */ 
/*     */   public static Object generalize(Object pojo) {
/*  96 */     return generalize(pojo, new IdentityHashMap());
/*     */   }
/*     */ 
/*     */   private static Object generalize(Object pojo, Map<Object, Object> history)
/*     */   {
/* 101 */     if (pojo == null) {
/* 102 */       return null;
/*     */     }
/*     */ 
/* 105 */     if ((pojo instanceof Enum)) {
/* 106 */       return ((Enum)pojo).name();
/*     */     }
/* 108 */     if ((pojo.getClass().isArray()) && (Enum.class.isAssignableFrom(pojo.getClass().getComponentType())))
/*     */     {
/* 111 */       int len = Array.getLength(pojo);
/* 112 */       String[] values = new String[len];
/* 113 */       for (int i = 0; i < len; i++) {
/* 114 */         values[i] = ((Enum)Array.get(pojo, i)).name();
/*     */       }
/* 116 */       return values;
/*     */     }
/*     */ 
/* 119 */     if (ReflectUtils.isPrimitives(pojo.getClass())) {
/* 120 */       return pojo;
/*     */     }
/*     */ 
/* 123 */     if ((pojo instanceof Class)) {
/* 124 */       return ((Class)pojo).getName();
/*     */     }
/*     */ 
/* 127 */     Object o = history.get(pojo);
/* 128 */     if (o != null) {
/* 129 */       return o;
/*     */     }
/* 131 */     history.put(pojo, pojo);
/*     */ 
/* 133 */     if (pojo.getClass().isArray()) {
/* 134 */       int len = Array.getLength(pojo);
/* 135 */       Object[] dest = new Object[len];
/* 136 */       history.put(pojo, dest);
/* 137 */       for (int i = 0; i < len; i++) {
/* 138 */         Object obj = Array.get(pojo, i);
/* 139 */         dest[i] = generalize(obj, history);
/*     */       }
/* 141 */       return dest;
/*     */     }
/* 143 */     if ((pojo instanceof Collection)) {
/* 144 */       Collection src = (Collection)pojo;
/* 145 */       int len = src.size();
/* 146 */       Collection dest = (pojo instanceof List) ? new ArrayList(len) : new HashSet(len);
/* 147 */       history.put(pojo, dest);
/* 148 */       for (Iterator i$ = src.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 149 */         dest.add(generalize(obj, history));
/*     */       }
/* 151 */       return dest;
/*     */     }
/* 153 */     if ((pojo instanceof Map)) {
/* 154 */       Map src = (Map)pojo;
/* 155 */       Map dest = createMap(src);
/* 156 */       history.put(pojo, dest);
/* 157 */       for (Map.Entry obj : src.entrySet()) {
/* 158 */         dest.put(generalize(obj.getKey(), history), generalize(obj.getValue(), history));
/*     */       }
/* 160 */       return dest;
/*     */     }
/* 162 */     Map map = new HashMap();
/* 163 */     history.put(pojo, map);
/* 164 */     map.put("class", pojo.getClass().getName());
/* 165 */     for (Method method : pojo.getClass().getMethods()) {
/* 166 */       if (ReflectUtils.isBeanPropertyReadMethod(method)) {
/*     */         try {
/* 168 */           map.put(ReflectUtils.getPropertyNameFromBeanReadMethod(method), generalize(method.invoke(pojo, new Object[0]), history));
/*     */         }
/*     */         catch (Exception e) {
/* 171 */           throw new RuntimeException(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 176 */     for (Field field : pojo.getClass().getFields()) {
/* 177 */       if (ReflectUtils.isPublicInstanceField(field)) {
/*     */         try {
/* 179 */           Object fieldValue = field.get(pojo);
/*     */ 
/* 181 */           if (history.containsKey(pojo))
/*     */           {
/* 182 */             Object pojoGenerilizedValue = history.get(pojo);
/* 183 */             if (((pojoGenerilizedValue instanceof Map)) && (((Map)pojoGenerilizedValue).containsKey(field.getName())));
/*     */           }
/* 188 */           else if (fieldValue != null) {
/* 189 */             map.put(field.getName(), generalize(fieldValue, history));
/*     */           }
/*     */         } catch (Exception e) {
/* 192 */           throw new RuntimeException(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/* 196 */     return map;
/*     */   }
/*     */ 
/*     */   public static Object realize(Object pojo, Class<?> type) {
/* 200 */     return realize0(pojo, type, null, new IdentityHashMap());
/*     */   }
/*     */ 
/*     */   public static Object realize(Object pojo, Class<?> type, Type genericType) {
/* 204 */     return realize0(pojo, type, genericType, new IdentityHashMap());
/*     */   }
/*     */ 
/*     */   private static Collection<Object> createCollection(Class<?> type, int len)
/*     */   {
/* 238 */     if (type.isAssignableFrom(ArrayList.class)) {
/* 239 */       return new ArrayList(len);
/*     */     }
/* 241 */     if (type.isAssignableFrom(HashSet.class)) {
/* 242 */       return new HashSet(len);
/*     */     }
/* 244 */     if ((!type.isInterface()) && (!Modifier.isAbstract(type.getModifiers())))
/*     */       try {
/* 246 */         return (Collection)type.newInstance();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/* 251 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   private static Map createMap(Map src) {
/* 255 */     Class cl = src.getClass();
/* 256 */     Map result = null;
/* 257 */     if (HashMap.class == cl) {
/* 258 */       result = new HashMap();
/* 259 */     } else if (Hashtable.class == cl) {
/* 260 */       result = new Hashtable();
/* 261 */     } else if (IdentityHashMap.class == cl) {
/* 262 */       result = new IdentityHashMap();
/* 263 */     } else if (LinkedHashMap.class == cl) {
/* 264 */       result = new LinkedHashMap();
/* 265 */     } else if (Properties.class == cl) {
/* 266 */       result = new Properties();
/* 267 */     } else if (TreeMap.class == cl) {
/* 268 */       result = new TreeMap(); } else {
/* 269 */       if (WeakHashMap.class == cl)
/* 270 */         return new WeakHashMap();
/* 271 */       if (ConcurrentHashMap.class == cl) {
/* 272 */         result = new ConcurrentHashMap();
/* 273 */       } else if (ConcurrentSkipListMap.class == cl) {
/* 274 */         result = new ConcurrentSkipListMap();
/*     */       } else {
/*     */         try {
/* 277 */           result = (Map)cl.newInstance();
/*     */         } catch (Exception e) {
/*     */         }
/* 280 */         if (result == null)
/*     */           try {
/* 282 */             Constructor constructor = cl.getConstructor(new Class[] { Map.class });
/* 283 */             result = (Map)constructor.newInstance(new Object[] { Collections.EMPTY_MAP });
/*     */           } catch (Exception e) {
/*     */           }
/*     */       }
/*     */     }
/* 288 */     if (result == null) {
/* 289 */       result = new HashMap();
/*     */     }
/*     */ 
/* 292 */     return result;
/*     */   }
/*     */ 
/*     */   private static Object realize0(Object pojo, Class<?> type, Type genericType, Map<Object, Object> history)
/*     */   {
/* 297 */     if (pojo == null) {
/* 298 */       return null;
/*     */     }
/*     */ 
/* 301 */     if ((type != null) && (type.isEnum()) && (pojo.getClass() == String.class))
/*     */     {
/* 303 */       return Enum.valueOf(type, (String)pojo);
/*     */     }
/*     */ 
/* 306 */     if ((ReflectUtils.isPrimitives(pojo.getClass())) && ((type == null) || (!type.isArray()) || (!type.getComponentType().isEnum()) || (pojo.getClass() != [Ljava.lang.String.class)))
/*     */     {
/* 310 */       return CompatibleTypeUtils.compatibleTypeConvert(pojo, type);
/*     */     }
/*     */ 
/* 313 */     Object o = history.get(pojo);
/*     */ 
/* 315 */     if (o != null) {
/* 316 */       return o;
/*     */     }
/*     */ 
/* 319 */     history.put(pojo, pojo);
/*     */ 
/* 321 */     if (pojo.getClass().isArray()) {
/* 322 */       if (Collection.class.isAssignableFrom(type)) {
/* 323 */         Class ctype = pojo.getClass().getComponentType();
/* 324 */         int len = Array.getLength(pojo);
/* 325 */         Collection dest = createCollection(type, len);
/* 326 */         history.put(pojo, dest);
/* 327 */         for (int i = 0; i < len; i++) {
/* 328 */           Object obj = Array.get(pojo, i);
/* 329 */           Object value = realize0(obj, ctype, null, history);
/* 330 */           dest.add(value);
/*     */         }
/* 332 */         return dest;
/*     */       }
/* 334 */       Class ctype = (type != null) && (type.isArray()) ? type.getComponentType() : pojo.getClass().getComponentType();
/* 335 */       int len = Array.getLength(pojo);
/* 336 */       Object dest = Array.newInstance(ctype, len);
/* 337 */       history.put(pojo, dest);
/* 338 */       for (int i = 0; i < len; i++) {
/* 339 */         Object obj = Array.get(pojo, i);
/* 340 */         Object value = realize0(obj, ctype, null, history);
/* 341 */         Array.set(dest, i, value);
/*     */       }
/* 343 */       return dest;
/*     */     }
/*     */ 
/* 347 */     if ((pojo instanceof Collection)) {
/* 348 */       if (type.isArray()) {
/* 349 */         Class ctype = type.getComponentType();
/* 350 */         Collection src = (Collection)pojo;
/* 351 */         int len = src.size();
/* 352 */         Object dest = Array.newInstance(ctype, len);
/* 353 */         history.put(pojo, dest);
/* 354 */         int i = 0;
/* 355 */         for (Iterator i$ = src.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 356 */           Object value = realize0(obj, ctype, null, history);
/* 357 */           Array.set(dest, i, value);
/* 358 */           i++;
/*     */         }
/* 360 */         return dest;
/*     */       }
/* 362 */       Collection src = (Collection)pojo;
/* 363 */       int len = src.size();
/* 364 */       Collection dest = createCollection(type, len);
/* 365 */       history.put(pojo, dest);
/* 366 */       for (Iterator i$ = src.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 367 */         Type keyType = getGenericClassByIndex(genericType, 0);
/* 368 */         Class keyClazz = obj.getClass();
/* 369 */         if ((keyType instanceof Class)) {
/* 370 */           keyClazz = (Class)keyType;
/*     */         }
/* 372 */         Object value = realize0(obj, keyClazz, keyType, history);
/* 373 */         dest.add(value);
/*     */       }
/* 375 */       return dest;
/*     */     }
/*     */ 
/* 379 */     if (((pojo instanceof Map)) && (type != null)) {
/* 380 */       Object className = ((Map)pojo).get("class");
/* 381 */       if ((className instanceof String))
/*     */         try {
/* 383 */           type = ClassHelper.forName((String)className);
/*     */         }
/*     */         catch (ClassNotFoundException e)
/*     */         {
/*     */         }
/*     */       Map map;
/* 390 */       if ((!type.isInterface()) && (!type.isAssignableFrom(pojo.getClass())))
/*     */         try
/*     */         {
/* 393 */           map = (Map)type.newInstance();
/*     */         }
/*     */         catch (Exception e) {
/* 396 */           Map map = (Map)pojo;
/*     */         }
/*     */       else {
/* 399 */         map = (Map)pojo;
/*     */       }
/*     */ 
/* 402 */       if ((Map.class.isAssignableFrom(type)) || (type == Object.class)) {
/* 403 */         Map result = createMap(map);
/* 404 */         history.put(pojo, result);
/* 405 */         for (Map.Entry entry : map.entrySet()) {
/* 406 */           Type keyType = getGenericClassByIndex(genericType, 0);
/* 407 */           Type valueType = getGenericClassByIndex(genericType, 1);
/*     */           Class keyClazz;
/*     */           Class keyClazz;
/* 409 */           if ((keyType instanceof Class))
/* 410 */             keyClazz = (Class)keyType;
/*     */           else
/* 412 */             keyClazz = entry.getKey() == null ? null : entry.getKey().getClass();
/*     */           Class valueClazz;
/*     */           Class valueClazz;
/* 415 */           if ((valueType instanceof Class))
/* 416 */             valueClazz = (Class)valueType;
/*     */           else {
/* 418 */             valueClazz = entry.getValue() == null ? null : entry.getValue().getClass();
/*     */           }
/*     */ 
/* 421 */           Object key = keyClazz == null ? entry.getKey() : realize0(entry.getKey(), keyClazz, keyType, history);
/* 422 */           Object value = valueClazz == null ? entry.getValue() : realize0(entry.getValue(), valueClazz, valueType, history);
/* 423 */           result.put(key, value);
/*     */         }
/* 425 */         return result;
/* 426 */       }if (type.isInterface()) {
/* 427 */         Object dest = Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class[] { type }, new PojoInvocationHandler(map));
/* 428 */         history.put(pojo, dest);
/* 429 */         return dest;
/*     */       }
/* 431 */       Object dest = newInstance(type);
/* 432 */       history.put(pojo, dest);
/* 433 */       for (Map.Entry entry : map.entrySet()) {
/* 434 */         Object key = entry.getKey();
/* 435 */         if ((key instanceof String)) {
/* 436 */           String name = (String)key;
/* 437 */           Object value = entry.getValue();
/* 438 */           if (value != null) {
/* 439 */             Method method = getSetterMethod(dest.getClass(), name, value.getClass());
/* 440 */             Field field = getField(dest.getClass(), name);
/* 441 */             if (method != null) {
/* 442 */               if (!method.isAccessible())
/* 443 */                 method.setAccessible(true);
/* 444 */               Type ptype = method.getGenericParameterTypes()[0];
/* 445 */               value = realize0(value, method.getParameterTypes()[0], ptype, history);
/*     */               try {
/* 447 */                 method.invoke(dest, new Object[] { value });
/*     */               } catch (Exception e) {
/* 449 */                 e.printStackTrace();
/* 450 */                 throw new RuntimeException("Failed to set pojo " + dest.getClass().getSimpleName() + " property " + name + " value " + value + "(" + value.getClass() + "), cause: " + e.getMessage(), e);
/*     */               }
/*     */             }
/* 453 */             else if (field != null) {
/* 454 */               value = realize0(value, field.getType(), field.getGenericType(), history);
/*     */               try {
/* 456 */                 field.set(dest, value);
/*     */               } catch (IllegalAccessException e) {
/* 458 */                 throw new RuntimeException(32 + "Failed to set filed " + name + " of pojo " + dest.getClass().getName() + " : " + e.getMessage(), e);
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 472 */       if ((dest instanceof Throwable)) {
/* 473 */         Object message = map.get("message");
/* 474 */         if ((message instanceof String))
/*     */           try {
/* 476 */             Field filed = Throwable.class.getDeclaredField("detailMessage");
/* 477 */             if (!filed.isAccessible()) {
/* 478 */               filed.setAccessible(true);
/*     */             }
/* 480 */             filed.set(dest, (String)message);
/*     */           }
/*     */           catch (Exception e) {
/*     */           }
/*     */       }
/* 485 */       return dest;
/*     */     }
/*     */ 
/* 488 */     return pojo;
/*     */   }
/*     */ 
/*     */   private static Type getGenericClassByIndex(Type genericType, int index)
/*     */   {
/* 498 */     Type clazz = null;
/*     */ 
/* 500 */     if ((genericType instanceof ParameterizedType)) {
/* 501 */       ParameterizedType t = (ParameterizedType)genericType;
/* 502 */       Type[] types = t.getActualTypeArguments();
/* 503 */       clazz = types[index];
/*     */     }
/* 505 */     return clazz;
/*     */   }
/*     */ 
/*     */   private static Object newInstance(Class<?> cls) {
/*     */     try {
/* 510 */       return cls.newInstance();
/*     */     } catch (Throwable t) {
/*     */       try {
/* 513 */         Constructor[] constructors = cls.getConstructors();
/* 514 */         if ((constructors != null) && (constructors.length == 0)) {
/* 515 */           throw new RuntimeException("Illegal constructor: " + cls.getName());
/*     */         }
/* 517 */         Constructor constructor = constructors[0];
/* 518 */         if (constructor.getParameterTypes().length > 0) {
/* 519 */           for (Constructor c : constructors) {
/* 520 */             if (c.getParameterTypes().length < constructor.getParameterTypes().length)
/*     */             {
/* 522 */               constructor = c;
/* 523 */               if (constructor.getParameterTypes().length == 0) {
/*     */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 529 */         return constructor.newInstance(new Object[constructor.getParameterTypes().length]);
/*     */       } catch (InstantiationException e) {
/* 531 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } catch (IllegalAccessException e) {
/* 533 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } catch (InvocationTargetException e) {
/* 535 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Method getSetterMethod(Class<?> cls, String property, Class<?> valueCls) {
/* 541 */     String name = "set" + property.substring(0, 1).toUpperCase() + property.substring(1);
/* 542 */     Method method = (Method)NAME_METHODS_CACHE.get(cls.getName() + "." + name + "(" + valueCls.getName() + ")");
/* 543 */     if (method == null) { Method[] arr$;
/*     */       int len$;
/*     */       int i$;
/*     */       try { method = cls.getMethod(name, new Class[] { valueCls });
/*     */       } catch (NoSuchMethodException e) {
/* 547 */         arr$ = cls.getMethods(); len$ = arr$.length; i$ = 0; } for (; i$ < len$; i$++) { Method m = arr$[i$];
/* 548 */         if ((ReflectUtils.isBeanPropertyWriteMethod(m)) && (m.getName().equals(name)))
/*     */         {
/* 550 */           method = m;
/*     */         }
/*     */       }
/*     */ 
/* 554 */       if (method != null) {
/* 555 */         NAME_METHODS_CACHE.put(cls.getName() + "." + name + "(" + valueCls.getName() + ")", method);
/*     */       }
/*     */     }
/* 558 */     return method;
/*     */   }
/*     */ 
/*     */   private static Field getField(Class<?> cls, String fieldName) {
/* 562 */     Field result = null;
/* 563 */     if ((CLASS_FIELD_CACHE.containsKey(cls)) && (((ConcurrentMap)CLASS_FIELD_CACHE.get(cls)).containsKey(fieldName)))
/*     */     {
/* 565 */       return (Field)((ConcurrentMap)CLASS_FIELD_CACHE.get(cls)).get(fieldName); } Field[] arr$;
/*     */     int len$;
/*     */     int i$;
/*     */     try { result = cls.getField(fieldName);
/*     */     } catch (NoSuchFieldException e) {
/* 570 */       arr$ = cls.getFields(); len$ = arr$.length; i$ = 0; } for (; i$ < len$; i$++) { Field field = arr$[i$];
/* 571 */       if ((fieldName.equals(field.getName())) && (ReflectUtils.isPublicInstanceField(field)))
/*     */       {
/* 573 */         result = field;
/* 574 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 578 */     if (result != null) {
/* 579 */       ConcurrentMap fields = (ConcurrentMap)CLASS_FIELD_CACHE.get(cls);
/* 580 */       if (fields == null) {
/* 581 */         fields = new ConcurrentHashMap();
/* 582 */         CLASS_FIELD_CACHE.putIfAbsent(cls, fields);
/*     */       }
/* 584 */       fields = (ConcurrentMap)CLASS_FIELD_CACHE.get(cls);
/* 585 */       fields.putIfAbsent(fieldName, result);
/*     */     }
/* 587 */     return result;
/*     */   }
/*     */ 
/*     */   public static boolean isPojo(Class<?> cls) {
/* 591 */     return (!ReflectUtils.isPrimitives(cls)) && (!Collection.class.isAssignableFrom(cls)) && (!Map.class.isAssignableFrom(cls));
/*     */   }
/*     */ 
/*     */   private static class PojoInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private Map<Object, Object> map;
/*     */ 
/*     */     public PojoInvocationHandler(Map<Object, Object> map)
/*     */     {
/* 212 */       this.map = map;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */     {
/* 217 */       if (method.getDeclaringClass() == Object.class) {
/* 218 */         return method.invoke(this.map, args);
/*     */       }
/* 220 */       String methodName = method.getName();
/* 221 */       Object value = null;
/* 222 */       if ((methodName.length() > 3) && (methodName.startsWith("get")))
/* 223 */         value = this.map.get(methodName.substring(3, 4).toLowerCase() + methodName.substring(4));
/* 224 */       else if ((methodName.length() > 2) && (methodName.startsWith("is")))
/* 225 */         value = this.map.get(methodName.substring(2, 3).toLowerCase() + methodName.substring(3));
/*     */       else {
/* 227 */         value = this.map.get(methodName.substring(0, 1).toLowerCase() + methodName.substring(1));
/*     */       }
/* 229 */       if (((value instanceof Map)) && (!Map.class.isAssignableFrom(method.getReturnType()))) {
/* 230 */         value = PojoUtils.realize0((Map)value, method.getReturnType(), null, new IdentityHashMap());
/*     */       }
/* 232 */       return value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.PojoUtils
 * JD-Core Version:    0.6.2
 */