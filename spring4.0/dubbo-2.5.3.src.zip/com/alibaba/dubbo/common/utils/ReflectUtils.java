/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.net.URL;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtConstructor;
/*     */ import javassist.CtMethod;
/*     */ import javassist.NotFoundException;
/*     */ 
/*     */ public final class ReflectUtils
/*     */ {
/*     */   public static final char JVM_VOID = 'V';
/*     */   public static final char JVM_BOOLEAN = 'Z';
/*     */   public static final char JVM_BYTE = 'B';
/*     */   public static final char JVM_CHAR = 'C';
/*     */   public static final char JVM_DOUBLE = 'D';
/*     */   public static final char JVM_FLOAT = 'F';
/*     */   public static final char JVM_INT = 'I';
/*     */   public static final char JVM_LONG = 'J';
/*     */   public static final char JVM_SHORT = 'S';
/*  96 */   public static final Class<?>[] EMPTY_CLASS_ARRAY = new Class[0];
/*     */   public static final String JAVA_IDENT_REGEX = "(?:[_$a-zA-Z][_$a-zA-Z0-9]*)";
/*     */   public static final String JAVA_NAME_REGEX = "(?:(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\.(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*)";
/*     */   public static final String CLASS_DESC = "(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)";
/*     */   public static final String ARRAY_DESC = "(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)))";
/*     */   public static final String DESC_REGEX = "(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)|(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;))))";
/* 108 */   public static final Pattern DESC_PATTERN = Pattern.compile("(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)|(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;))))");
/*     */   public static final String METHOD_DESC_REGEX = "(?:((?:[_$a-zA-Z][_$a-zA-Z0-9]*))?\\(((?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)|(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;))))*)\\)((?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)|(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)))))?)";
/* 112 */   public static final Pattern METHOD_DESC_PATTERN = Pattern.compile("(?:((?:[_$a-zA-Z][_$a-zA-Z0-9]*))?\\(((?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)|(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;))))*)\\)((?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)|(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)))))?)");
/*     */ 
/* 114 */   public static final Pattern GETTER_METHOD_DESC_PATTERN = Pattern.compile("get([A-Z][_a-zA-Z0-9]*)\\(\\)((?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)|(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)))))");
/*     */ 
/* 116 */   public static final Pattern SETTER_METHOD_DESC_PATTERN = Pattern.compile("set([A-Z][_a-zA-Z0-9]*)\\(((?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)|(?:\\[+(?:(?:[VZBCDFIJS])|(?:L(?:[_$a-zA-Z][_$a-zA-Z0-9]*)(?:\\/(?:[_$a-zA-Z][_$a-zA-Z0-9]*))*;)))))\\)V");
/*     */ 
/* 118 */   public static final Pattern IS_HAS_CAN_METHOD_DESC_PATTERN = Pattern.compile("(?:is|has|can)([A-Z][_a-zA-Z0-9]*)\\(\\)Z");
/*     */ 
/* 120 */   private static final ConcurrentMap<String, Class<?>> DESC_CLASS_CACHE = new ConcurrentHashMap();
/*     */ 
/* 122 */   private static final ConcurrentMap<String, Class<?>> NAME_CLASS_CACHE = new ConcurrentHashMap();
/*     */ 
/* 124 */   private static final ConcurrentMap<String, Method> Signature_METHODS_CACHE = new ConcurrentHashMap();
/*     */ 
/*     */   public static boolean isPrimitives(Class<?> cls) {
/* 127 */     if (cls.isArray()) {
/* 128 */       return isPrimitive(cls.getComponentType());
/*     */     }
/* 130 */     return isPrimitive(cls);
/*     */   }
/*     */ 
/*     */   public static boolean isPrimitive(Class<?> cls) {
/* 134 */     return (cls.isPrimitive()) || (cls == String.class) || (cls == Boolean.class) || (cls == Character.class) || (Number.class.isAssignableFrom(cls)) || (Date.class.isAssignableFrom(cls));
/*     */   }
/*     */ 
/*     */   public static Class<?> getBoxedClass(Class<?> c)
/*     */   {
/* 139 */     if (c == Integer.TYPE)
/* 140 */       c = Integer.class;
/* 141 */     else if (c == Boolean.TYPE)
/* 142 */       c = Boolean.class;
/* 143 */     else if (c == Long.TYPE)
/* 144 */       c = Long.class;
/* 145 */     else if (c == Float.TYPE)
/* 146 */       c = Float.class;
/* 147 */     else if (c == Double.TYPE)
/* 148 */       c = Double.class;
/* 149 */     else if (c == Character.TYPE)
/* 150 */       c = Character.class;
/* 151 */     else if (c == Byte.TYPE)
/* 152 */       c = Byte.class;
/* 153 */     else if (c == Short.TYPE)
/* 154 */       c = Short.class;
/* 155 */     return c;
/*     */   }
/*     */ 
/*     */   public static boolean isCompatible(Class<?> c, Object o)
/*     */   {
/* 167 */     boolean pt = c.isPrimitive();
/* 168 */     if (o == null) {
/* 169 */       return !pt;
/*     */     }
/* 171 */     if (pt)
/*     */     {
/* 173 */       if (c == Integer.TYPE)
/* 174 */         c = Integer.class;
/* 175 */       else if (c == Boolean.TYPE)
/* 176 */         c = Boolean.class;
/* 177 */       else if (c == Long.TYPE)
/* 178 */         c = Long.class;
/* 179 */       else if (c == Float.TYPE)
/* 180 */         c = Float.class;
/* 181 */       else if (c == Double.TYPE)
/* 182 */         c = Double.class;
/* 183 */       else if (c == Character.TYPE)
/* 184 */         c = Character.class;
/* 185 */       else if (c == Byte.TYPE)
/* 186 */         c = Byte.class;
/* 187 */       else if (c == Short.TYPE)
/* 188 */         c = Short.class;
/*     */     }
/* 190 */     if (c == o.getClass())
/* 191 */       return true;
/* 192 */     return c.isInstance(o);
/*     */   }
/*     */ 
/*     */   public static boolean isCompatible(Class<?>[] cs, Object[] os)
/*     */   {
/* 204 */     int len = cs.length;
/* 205 */     if (len != os.length) return false;
/* 206 */     if (len == 0) return true;
/* 207 */     for (int i = 0; i < len; i++)
/* 208 */       if (!isCompatible(cs[i], os[i])) return false;
/* 209 */     return true;
/*     */   }
/*     */ 
/*     */   public static String getCodeBase(Class<?> cls) {
/* 213 */     if (cls == null)
/* 214 */       return null;
/* 215 */     ProtectionDomain domain = cls.getProtectionDomain();
/* 216 */     if (domain == null)
/* 217 */       return null;
/* 218 */     CodeSource source = domain.getCodeSource();
/* 219 */     if (source == null)
/* 220 */       return null;
/* 221 */     URL location = source.getLocation();
/* 222 */     if (location == null)
/* 223 */       return null;
/* 224 */     return location.getFile();
/*     */   }
/*     */ 
/*     */   public static String getName(Class<?> c)
/*     */   {
/* 236 */     if (c.isArray())
/*     */     {
/* 238 */       StringBuilder sb = new StringBuilder();
/*     */       do
/*     */       {
/* 241 */         sb.append("[]");
/* 242 */         c = c.getComponentType();
/*     */       }
/* 244 */       while (c.isArray());
/*     */ 
/* 246 */       return c.getName() + sb.toString();
/*     */     }
/* 248 */     return c.getName();
/*     */   }
/*     */ 
/*     */   public static Class<?> getGenericClass(Class<?> cls)
/*     */   {
/* 253 */     return getGenericClass(cls, 0);
/*     */   }
/*     */ 
/*     */   public static Class<?> getGenericClass(Class<?> cls, int i) {
/*     */     try {
/* 258 */       ParameterizedType parameterizedType = (ParameterizedType)cls.getGenericInterfaces()[0];
/* 259 */       Object genericClass = parameterizedType.getActualTypeArguments()[i];
/* 260 */       if ((genericClass instanceof ParameterizedType))
/* 261 */         return (Class)((ParameterizedType)genericClass).getRawType();
/* 262 */       if ((genericClass instanceof GenericArrayType)) {
/* 263 */         return (Class)((GenericArrayType)genericClass).getGenericComponentType();
/*     */       }
/* 265 */       return (Class)genericClass;
/*     */     }
/*     */     catch (Throwable e) {
/* 268 */       throw new IllegalArgumentException(cls.getName() + " generic type undefined!", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getName(Method m)
/*     */   {
/* 283 */     StringBuilder ret = new StringBuilder();
/* 284 */     ret.append(getName(m.getReturnType())).append(' ');
/* 285 */     ret.append(m.getName()).append('(');
/* 286 */     Class[] parameterTypes = m.getParameterTypes();
/* 287 */     for (int i = 0; i < parameterTypes.length; i++)
/*     */     {
/* 289 */       if (i > 0)
/* 290 */         ret.append(',');
/* 291 */       ret.append(getName(parameterTypes[i]));
/*     */     }
/* 293 */     ret.append(')');
/* 294 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getSignature(String methodName, Class<?>[] parameterTypes) {
/* 298 */     StringBuilder sb = new StringBuilder(methodName);
/* 299 */     sb.append("(");
/* 300 */     if ((parameterTypes != null) && (parameterTypes.length > 0)) {
/* 301 */       boolean first = true;
/* 302 */       for (Class type : parameterTypes) {
/* 303 */         if (first)
/* 304 */           first = false;
/*     */         else {
/* 306 */           sb.append(",");
/*     */         }
/* 308 */         sb.append(type.getName());
/*     */       }
/*     */     }
/* 311 */     sb.append(")");
/* 312 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String getName(Constructor<?> c)
/*     */   {
/* 324 */     StringBuilder ret = new StringBuilder("(");
/* 325 */     Class[] parameterTypes = c.getParameterTypes();
/* 326 */     for (int i = 0; i < parameterTypes.length; i++)
/*     */     {
/* 328 */       if (i > 0)
/* 329 */         ret.append(',');
/* 330 */       ret.append(getName(parameterTypes[i]));
/*     */     }
/* 332 */     ret.append(')');
/* 333 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getDesc(Class<?> c)
/*     */   {
/* 347 */     StringBuilder ret = new StringBuilder();
/*     */ 
/* 349 */     while (c.isArray())
/*     */     {
/* 351 */       ret.append('[');
/* 352 */       c = c.getComponentType();
/*     */     }
/*     */ 
/* 355 */     if (c.isPrimitive())
/*     */     {
/* 357 */       String t = c.getName();
/* 358 */       if ("void".equals(t)) ret.append('V');
/* 359 */       else if ("boolean".equals(t)) ret.append('Z');
/* 360 */       else if ("byte".equals(t)) ret.append('B');
/* 361 */       else if ("char".equals(t)) ret.append('C');
/* 362 */       else if ("double".equals(t)) ret.append('D');
/* 363 */       else if ("float".equals(t)) ret.append('F');
/* 364 */       else if ("int".equals(t)) ret.append('I');
/* 365 */       else if ("long".equals(t)) ret.append('J');
/* 366 */       else if ("short".equals(t)) ret.append('S');
/*     */     }
/*     */     else
/*     */     {
/* 370 */       ret.append('L');
/* 371 */       ret.append(c.getName().replace('.', '/'));
/* 372 */       ret.append(';');
/*     */     }
/* 374 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getDesc(Class<?>[] cs)
/*     */   {
/* 387 */     if (cs.length == 0) {
/* 388 */       return "";
/*     */     }
/* 390 */     StringBuilder sb = new StringBuilder(64);
/* 391 */     for (Class c : cs)
/* 392 */       sb.append(getDesc(c));
/* 393 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String getDesc(Method m)
/*     */   {
/* 406 */     StringBuilder ret = new StringBuilder(m.getName()).append('(');
/* 407 */     Class[] parameterTypes = m.getParameterTypes();
/* 408 */     for (int i = 0; i < parameterTypes.length; i++)
/* 409 */       ret.append(getDesc(parameterTypes[i]));
/* 410 */     ret.append(')').append(getDesc(m.getReturnType()));
/* 411 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getDesc(Constructor<?> c)
/*     */   {
/* 423 */     StringBuilder ret = new StringBuilder("(");
/* 424 */     Class[] parameterTypes = c.getParameterTypes();
/* 425 */     for (int i = 0; i < parameterTypes.length; i++)
/* 426 */       ret.append(getDesc(parameterTypes[i]));
/* 427 */     ret.append(')').append('V');
/* 428 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getDescWithoutMethodName(Method m)
/*     */   {
/* 440 */     StringBuilder ret = new StringBuilder();
/* 441 */     ret.append('(');
/* 442 */     Class[] parameterTypes = m.getParameterTypes();
/* 443 */     for (int i = 0; i < parameterTypes.length; i++)
/* 444 */       ret.append(getDesc(parameterTypes[i]));
/* 445 */     ret.append(')').append(getDesc(m.getReturnType()));
/* 446 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getDesc(CtClass c)
/*     */     throws NotFoundException
/*     */   {
/* 460 */     StringBuilder ret = new StringBuilder();
/* 461 */     if (c.isArray())
/*     */     {
/* 463 */       ret.append('[');
/* 464 */       ret.append(getDesc(c.getComponentType()));
/*     */     }
/* 466 */     else if (c.isPrimitive())
/*     */     {
/* 468 */       String t = c.getName();
/* 469 */       if ("void".equals(t)) ret.append('V');
/* 470 */       else if ("boolean".equals(t)) ret.append('Z');
/* 471 */       else if ("byte".equals(t)) ret.append('B');
/* 472 */       else if ("char".equals(t)) ret.append('C');
/* 473 */       else if ("double".equals(t)) ret.append('D');
/* 474 */       else if ("float".equals(t)) ret.append('F');
/* 475 */       else if ("int".equals(t)) ret.append('I');
/* 476 */       else if ("long".equals(t)) ret.append('J');
/* 477 */       else if ("short".equals(t)) ret.append('S');
/*     */     }
/*     */     else
/*     */     {
/* 481 */       ret.append('L');
/* 482 */       ret.append(c.getName().replace('.', '/'));
/* 483 */       ret.append(';');
/*     */     }
/* 485 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getDesc(CtMethod m)
/*     */     throws NotFoundException
/*     */   {
/* 497 */     StringBuilder ret = new StringBuilder(m.getName()).append('(');
/* 498 */     CtClass[] parameterTypes = m.getParameterTypes();
/* 499 */     for (int i = 0; i < parameterTypes.length; i++)
/* 500 */       ret.append(getDesc(parameterTypes[i]));
/* 501 */     ret.append(')').append(getDesc(m.getReturnType()));
/* 502 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getDesc(CtConstructor c)
/*     */     throws NotFoundException
/*     */   {
/* 514 */     StringBuilder ret = new StringBuilder("(");
/* 515 */     CtClass[] parameterTypes = c.getParameterTypes();
/* 516 */     for (int i = 0; i < parameterTypes.length; i++)
/* 517 */       ret.append(getDesc(parameterTypes[i]));
/* 518 */     ret.append(')').append('V');
/* 519 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String getDescWithoutMethodName(CtMethod m)
/*     */     throws NotFoundException
/*     */   {
/* 531 */     StringBuilder ret = new StringBuilder();
/* 532 */     ret.append('(');
/* 533 */     CtClass[] parameterTypes = m.getParameterTypes();
/* 534 */     for (int i = 0; i < parameterTypes.length; i++)
/* 535 */       ret.append(getDesc(parameterTypes[i]));
/* 536 */     ret.append(')').append(getDesc(m.getReturnType()));
/* 537 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   public static String name2desc(String name)
/*     */   {
/* 549 */     StringBuilder sb = new StringBuilder();
/* 550 */     int c = 0; int index = name.indexOf('[');
/* 551 */     if (index > 0)
/*     */     {
/* 553 */       c = (name.length() - index) / 2;
/* 554 */       name = name.substring(0, index);
/*     */     }
/* 556 */     while (c-- > 0) sb.append("[");
/* 557 */     if ("void".equals(name)) sb.append('V');
/* 558 */     else if ("boolean".equals(name)) sb.append('Z');
/* 559 */     else if ("byte".equals(name)) sb.append('B');
/* 560 */     else if ("char".equals(name)) sb.append('C');
/* 561 */     else if ("double".equals(name)) sb.append('D');
/* 562 */     else if ("float".equals(name)) sb.append('F');
/* 563 */     else if ("int".equals(name)) sb.append('I');
/* 564 */     else if ("long".equals(name)) sb.append('J');
/* 565 */     else if ("short".equals(name)) sb.append('S'); else
/* 566 */       sb.append('L').append(name.replace('.', '/')).append(';');
/* 567 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String desc2name(String desc)
/*     */   {
/* 579 */     StringBuilder sb = new StringBuilder();
/* 580 */     int c = desc.lastIndexOf('[') + 1;
/* 581 */     if (desc.length() == c + 1)
/*     */     {
/* 583 */       switch (desc.charAt(c)) {
/*     */       case 'V':
/* 585 */         sb.append("void"); break;
/*     */       case 'Z':
/* 586 */         sb.append("boolean"); break;
/*     */       case 'B':
/* 587 */         sb.append("byte"); break;
/*     */       case 'C':
/* 588 */         sb.append("char"); break;
/*     */       case 'D':
/* 589 */         sb.append("double"); break;
/*     */       case 'F':
/* 590 */         sb.append("float"); break;
/*     */       case 'I':
/* 591 */         sb.append("int"); break;
/*     */       case 'J':
/* 592 */         sb.append("long"); break;
/*     */       case 'S':
/* 593 */         sb.append("short"); break;
/*     */       case 'E':
/*     */       case 'G':
/*     */       case 'H':
/*     */       case 'K':
/*     */       case 'L':
/*     */       case 'M':
/*     */       case 'N':
/*     */       case 'O':
/*     */       case 'P':
/*     */       case 'Q':
/*     */       case 'R':
/*     */       case 'T':
/*     */       case 'U':
/*     */       case 'W':
/*     */       case 'X':
/*     */       case 'Y':
/*     */       default:
/* 595 */         throw new RuntimeException();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 600 */       sb.append(desc.substring(c + 1, desc.length() - 1).replace('/', '.'));
/*     */     }
/* 602 */     while (c-- > 0) sb.append("[]");
/* 603 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static Class<?> forName(String name) {
/*     */     try {
/* 608 */       return name2class(name);
/*     */     } catch (ClassNotFoundException e) {
/* 610 */       throw new IllegalStateException("Not found class " + name + ", cause: " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Class<?> name2class(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/* 624 */     return name2class(ClassHelper.getClassLoader(), name);
/*     */   }
/*     */ 
/*     */   private static Class<?> name2class(ClassLoader cl, String name)
/*     */     throws ClassNotFoundException
/*     */   {
/* 638 */     int c = 0; int index = name.indexOf('[');
/* 639 */     if (index > 0)
/*     */     {
/* 641 */       c = (name.length() - index) / 2;
/* 642 */       name = name.substring(0, index);
/*     */     }
/* 644 */     if (c > 0)
/*     */     {
/* 646 */       StringBuilder sb = new StringBuilder();
/* 647 */       while (c-- > 0) {
/* 648 */         sb.append("[");
/*     */       }
/* 650 */       if ("void".equals(name)) sb.append('V');
/* 651 */       else if ("boolean".equals(name)) sb.append('Z');
/* 652 */       else if ("byte".equals(name)) sb.append('B');
/* 653 */       else if ("char".equals(name)) sb.append('C');
/* 654 */       else if ("double".equals(name)) sb.append('D');
/* 655 */       else if ("float".equals(name)) sb.append('F');
/* 656 */       else if ("int".equals(name)) sb.append('I');
/* 657 */       else if ("long".equals(name)) sb.append('J');
/* 658 */       else if ("short".equals(name)) sb.append('S'); else
/* 659 */         sb.append('L').append(name).append(';');
/* 660 */       name = sb.toString();
/*     */     }
/*     */     else
/*     */     {
/* 664 */       if ("void".equals(name)) return Void.TYPE;
/* 665 */       if ("boolean".equals(name)) return Boolean.TYPE;
/* 666 */       if ("byte".equals(name)) return Byte.TYPE;
/* 667 */       if ("char".equals(name)) return Character.TYPE;
/* 668 */       if ("double".equals(name)) return Double.TYPE;
/* 669 */       if ("float".equals(name)) return Float.TYPE;
/* 670 */       if ("int".equals(name)) return Integer.TYPE;
/* 671 */       if ("long".equals(name)) return Long.TYPE;
/* 672 */       if ("short".equals(name)) return Short.TYPE;
/*     */     }
/*     */ 
/* 675 */     if (cl == null)
/* 676 */       cl = ClassHelper.getClassLoader();
/* 677 */     Class clazz = (Class)NAME_CLASS_CACHE.get(name);
/* 678 */     if (clazz == null) {
/* 679 */       clazz = Class.forName(name, true, cl);
/* 680 */       NAME_CLASS_CACHE.put(name, clazz);
/*     */     }
/* 682 */     return clazz;
/*     */   }
/*     */ 
/*     */   public static Class<?> desc2class(String desc)
/*     */     throws ClassNotFoundException
/*     */   {
/* 696 */     return desc2class(ClassHelper.getClassLoader(), desc);
/*     */   }
/*     */ 
/*     */   private static Class<?> desc2class(ClassLoader cl, String desc)
/*     */     throws ClassNotFoundException
/*     */   {
/* 711 */     switch (desc.charAt(0)) {
/*     */     case 'V':
/* 713 */       return Void.TYPE;
/*     */     case 'Z':
/* 714 */       return Boolean.TYPE;
/*     */     case 'B':
/* 715 */       return Byte.TYPE;
/*     */     case 'C':
/* 716 */       return Character.TYPE;
/*     */     case 'D':
/* 717 */       return Double.TYPE;
/*     */     case 'F':
/* 718 */       return Float.TYPE;
/*     */     case 'I':
/* 719 */       return Integer.TYPE;
/*     */     case 'J':
/* 720 */       return Long.TYPE;
/*     */     case 'S':
/* 721 */       return Short.TYPE;
/*     */     case 'L':
/* 723 */       desc = desc.substring(1, desc.length() - 1).replace('/', '.');
/* 724 */       break;
/*     */     case '[':
/* 726 */       desc = desc.replace('/', '.');
/* 727 */       break;
/*     */     case 'E':
/*     */     case 'G':
/*     */     case 'H':
/*     */     case 'K':
/*     */     case 'M':
/*     */     case 'N':
/*     */     case 'O':
/*     */     case 'P':
/*     */     case 'Q':
/*     */     case 'R':
/*     */     case 'T':
/*     */     case 'U':
/*     */     case 'W':
/*     */     case 'X':
/*     */     case 'Y':
/*     */     default:
/* 729 */       throw new ClassNotFoundException("Class not found: " + desc);
/*     */     }
/*     */ 
/* 732 */     if (cl == null)
/* 733 */       cl = ClassHelper.getClassLoader();
/* 734 */     Class clazz = (Class)DESC_CLASS_CACHE.get(desc);
/* 735 */     if (clazz == null) {
/* 736 */       clazz = Class.forName(desc, true, cl);
/* 737 */       DESC_CLASS_CACHE.put(desc, clazz);
/*     */     }
/* 739 */     return clazz;
/*     */   }
/*     */ 
/*     */   public static Class<?>[] desc2classArray(String desc)
/*     */     throws ClassNotFoundException
/*     */   {
/* 751 */     Class[] ret = desc2classArray(ClassHelper.getClassLoader(), desc);
/* 752 */     return ret;
/*     */   }
/*     */ 
/*     */   private static Class<?>[] desc2classArray(ClassLoader cl, String desc)
/*     */     throws ClassNotFoundException
/*     */   {
/* 765 */     if (desc.length() == 0) {
/* 766 */       return EMPTY_CLASS_ARRAY;
/*     */     }
/* 768 */     List cs = new ArrayList();
/* 769 */     Matcher m = DESC_PATTERN.matcher(desc);
/* 770 */     while (m.find())
/* 771 */       cs.add(desc2class(cl, m.group()));
/* 772 */     return (Class[])cs.toArray(EMPTY_CLASS_ARRAY);
/*     */   }
/*     */ 
/*     */   public static Method findMethodByMethodSignature(Class<?> clazz, String methodName, String[] parameterTypes)
/*     */     throws NoSuchMethodException, ClassNotFoundException
/*     */   {
/* 787 */     String signature = methodName;
/* 788 */     if ((parameterTypes != null) && (parameterTypes.length > 0)) {
/* 789 */       signature = methodName + StringUtils.join(parameterTypes);
/*     */     }
/* 791 */     Method method = (Method)Signature_METHODS_CACHE.get(signature);
/* 792 */     if (method != null) {
/* 793 */       return method;
/*     */     }
/* 795 */     if (parameterTypes == null) {
/* 796 */       List finded = new ArrayList();
/* 797 */       for (Method m : clazz.getMethods()) {
/* 798 */         if (m.getName().equals(methodName)) {
/* 799 */           finded.add(m);
/*     */         }
/*     */       }
/* 802 */       if (finded.isEmpty()) {
/* 803 */         throw new NoSuchMethodException("No such method " + methodName + " in class " + clazz);
/*     */       }
/* 805 */       if (finded.size() > 1) {
/* 806 */         String msg = String.format("Not unique method for method name(%s) in class(%s), find %d methods.", new Object[] { methodName, clazz.getName(), Integer.valueOf(finded.size()) });
/*     */ 
/* 808 */         throw new IllegalStateException(msg);
/*     */       }
/* 810 */       method = (Method)finded.get(0);
/*     */     } else {
/* 812 */       Class[] types = new Class[parameterTypes.length];
/* 813 */       for (int i = 0; i < parameterTypes.length; i++) {
/* 814 */         types[i] = name2class(parameterTypes[i]);
/*     */       }
/* 816 */       method = clazz.getMethod(methodName, types);
/*     */     }
/*     */ 
/* 819 */     Signature_METHODS_CACHE.put(signature, method);
/* 820 */     return method;
/*     */   }
/*     */ 
/*     */   public static Method findMethodByMethodName(Class<?> clazz, String methodName) throws NoSuchMethodException, ClassNotFoundException
/*     */   {
/* 825 */     return findMethodByMethodSignature(clazz, methodName, null);
/*     */   }
/*     */ 
/*     */   public static Constructor<?> findConstructor(Class<?> clazz, Class<?> paramType) throws NoSuchMethodException {
/*     */     Constructor targetConstructor;
/*     */     try {
/* 831 */       targetConstructor = clazz.getConstructor(new Class[] { paramType });
/*     */     } catch (NoSuchMethodException e) {
/* 833 */       targetConstructor = null;
/* 834 */       Constructor[] constructors = clazz.getConstructors();
/* 835 */       for (Constructor constructor : constructors) {
/* 836 */         if ((Modifier.isPublic(constructor.getModifiers())) && (constructor.getParameterTypes().length == 1) && (constructor.getParameterTypes()[0].isAssignableFrom(paramType)))
/*     */         {
/* 839 */           targetConstructor = constructor;
/* 840 */           break;
/*     */         }
/*     */       }
/* 843 */       if (targetConstructor == null) {
/* 844 */         throw e;
/*     */       }
/*     */     }
/* 847 */     return targetConstructor;
/*     */   }
/*     */ 
/*     */   public static boolean isInstance(Object obj, String interfaceClazzName)
/*     */   {
/* 860 */     for (Class clazz = obj.getClass(); 
/* 861 */       (clazz != null) && (!clazz.equals(Object.class)); 
/* 862 */       clazz = clazz.getSuperclass()) {
/* 863 */       Class[] interfaces = clazz.getInterfaces();
/* 864 */       for (Class itf : interfaces) {
/* 865 */         if (itf.getName().equals(interfaceClazzName)) {
/* 866 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 870 */     return false;
/*     */   }
/*     */ 
/*     */   public static Object getEmptyObject(Class<?> returnType) {
/* 874 */     return getEmptyObject(returnType, new HashMap(), 0);
/*     */   }
/*     */ 
/*     */   private static Object getEmptyObject(Class<?> returnType, Map<Class<?>, Object> emptyInstances, int level) {
/* 878 */     if (level > 2)
/* 879 */       return null;
/* 880 */     if (returnType == null)
/* 881 */       return null;
/* 882 */     if ((returnType == Boolean.TYPE) || (returnType == Boolean.class))
/* 883 */       return Boolean.valueOf(false);
/* 884 */     if ((returnType == Character.TYPE) || (returnType == Character.class))
/* 885 */       return Character.valueOf('\000');
/* 886 */     if ((returnType == Byte.TYPE) || (returnType == Byte.class))
/* 887 */       return Byte.valueOf((byte)0);
/* 888 */     if ((returnType == Short.TYPE) || (returnType == Short.class))
/* 889 */       return Short.valueOf((short)0);
/* 890 */     if ((returnType == Integer.TYPE) || (returnType == Integer.class))
/* 891 */       return Integer.valueOf(0);
/* 892 */     if ((returnType == Long.TYPE) || (returnType == Long.class))
/* 893 */       return Long.valueOf(0L);
/* 894 */     if ((returnType == Float.TYPE) || (returnType == Float.class))
/* 895 */       return Float.valueOf(0.0F);
/* 896 */     if ((returnType == Double.TYPE) || (returnType == Double.class))
/* 897 */       return Double.valueOf(0.0D);
/* 898 */     if (returnType.isArray())
/* 899 */       return Array.newInstance(returnType.getComponentType(), 0);
/* 900 */     if (returnType.isAssignableFrom(ArrayList.class))
/* 901 */       return new ArrayList(0);
/* 902 */     if (returnType.isAssignableFrom(HashSet.class))
/* 903 */       return new HashSet(0);
/* 904 */     if (returnType.isAssignableFrom(HashMap.class))
/* 905 */       return new HashMap(0);
/* 906 */     if (String.class.equals(returnType))
/* 907 */       return "";
/* 908 */     if (!returnType.isInterface()) {
/*     */       try {
/* 910 */         Object value = emptyInstances.get(returnType);
/* 911 */         if (value == null) {
/* 912 */           value = returnType.newInstance();
/* 913 */           emptyInstances.put(returnType, value);
/*     */         }
/* 915 */         Class cls = value.getClass();
/* 916 */         while ((cls != null) && (cls != Object.class)) {
/* 917 */           Field[] fields = cls.getDeclaredFields();
/* 918 */           for (Field field : fields) {
/* 919 */             Object property = getEmptyObject(field.getType(), emptyInstances, level + 1);
/* 920 */             if (property != null)
/*     */               try {
/* 922 */                 if (!field.isAccessible()) {
/* 923 */                   field.setAccessible(true);
/*     */                 }
/* 925 */                 field.set(value, property);
/*     */               }
/*     */               catch (Throwable e) {
/*     */               }
/*     */           }
/* 930 */           cls = cls.getSuperclass();
/*     */         }
/* 932 */         return value;
/*     */       } catch (Throwable e) {
/* 934 */         return null;
/*     */       }
/*     */     }
/* 937 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean isBeanPropertyReadMethod(Method method)
/*     */   {
/* 942 */     return (method != null) && (Modifier.isPublic(method.getModifiers())) && (!Modifier.isStatic(method.getModifiers())) && (method.getReturnType() != Void.TYPE) && (method.getDeclaringClass() != Object.class) && (method.getParameterTypes().length == 0) && (((method.getName().startsWith("get")) && (method.getName().length() > 3)) || ((method.getName().startsWith("is")) && (method.getName().length() > 2)));
/*     */   }
/*     */ 
/*     */   public static String getPropertyNameFromBeanReadMethod(Method method)
/*     */   {
/* 953 */     if (isBeanPropertyReadMethod(method)) {
/* 954 */       if (method.getName().startsWith("get")) {
/* 955 */         return method.getName().substring(3, 4).toLowerCase() + method.getName().substring(4);
/*     */       }
/*     */ 
/* 958 */       if (method.getName().startsWith("is")) {
/* 959 */         return method.getName().substring(2, 3).toLowerCase() + method.getName().substring(3);
/*     */       }
/*     */     }
/*     */ 
/* 963 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean isBeanPropertyWriteMethod(Method method) {
/* 967 */     return (method != null) && (Modifier.isPublic(method.getModifiers())) && (!Modifier.isStatic(method.getModifiers())) && (method.getDeclaringClass() != Object.class) && (method.getParameterTypes().length == 1) && (method.getName().startsWith("set")) && (method.getName().length() > 3);
/*     */   }
/*     */ 
/*     */   public static String getPropertyNameFromBeanWriteMethod(Method method)
/*     */   {
/* 977 */     if (isBeanPropertyWriteMethod(method)) {
/* 978 */       return method.getName().substring(3, 4).toLowerCase() + method.getName().substring(4);
/*     */     }
/*     */ 
/* 981 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean isPublicInstanceField(Field field) {
/* 985 */     return (Modifier.isPublic(field.getModifiers())) && (!Modifier.isStatic(field.getModifiers())) && (!Modifier.isFinal(field.getModifiers())) && (!field.isSynthetic());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.ReflectUtils
 * JD-Core Version:    0.6.2
 */