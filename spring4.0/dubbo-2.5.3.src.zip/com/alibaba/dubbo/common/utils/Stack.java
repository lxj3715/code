/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Stack<E>
/*     */ {
/*  30 */   private int mSize = 0;
/*     */ 
/*  32 */   private List<E> mElements = new ArrayList();
/*     */ 
/*     */   public void push(E ele)
/*     */   {
/*  43 */     if (this.mElements.size() > this.mSize)
/*  44 */       this.mElements.set(this.mSize, ele);
/*     */     else
/*  46 */       this.mElements.add(ele);
/*  47 */     this.mSize += 1;
/*     */   }
/*     */ 
/*     */   public E pop()
/*     */   {
/*  57 */     if (this.mSize == 0)
/*  58 */       throw new EmptyStackException();
/*  59 */     return this.mElements.set(--this.mSize, null);
/*     */   }
/*     */ 
/*     */   public E peek()
/*     */   {
/*  69 */     if (this.mSize == 0)
/*  70 */       throw new EmptyStackException();
/*  71 */     return this.mElements.get(this.mSize - 1);
/*     */   }
/*     */ 
/*     */   public E get(int index)
/*     */   {
/*  82 */     if (index >= this.mSize) {
/*  83 */       throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + this.mSize);
/*     */     }
/*  85 */     return index < 0 ? this.mElements.get(index + this.mSize) : this.mElements.get(index);
/*     */   }
/*     */ 
/*     */   public E set(int index, E value)
/*     */   {
/*  97 */     if (index >= this.mSize) {
/*  98 */       throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + this.mSize);
/*     */     }
/* 100 */     return this.mElements.set(index < 0 ? index + this.mSize : index, value);
/*     */   }
/*     */ 
/*     */   public E remove(int index)
/*     */   {
/* 111 */     if (index >= this.mSize) {
/* 112 */       throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + this.mSize);
/*     */     }
/* 114 */     Object ret = this.mElements.remove(index < 0 ? index + this.mSize : index);
/* 115 */     this.mSize -= 1;
/* 116 */     return ret;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 126 */     return this.mSize;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 136 */     return this.mSize == 0;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 144 */     this.mSize = 0;
/* 145 */     this.mElements.clear();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.Stack
 * JD-Core Version:    0.6.2
 */