/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.io.UnsafeStringWriter;
/*     */ import com.alibaba.dubbo.common.json.JSON;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public final class StringUtils
/*     */ {
/*  43 */   private static final Logger logger = LoggerFactory.getLogger(StringUtils.class);
/*     */ 
/*  45 */   public static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */ 
/*  47 */   private static final Pattern KVP_PATTERN = Pattern.compile("([_.a-zA-Z0-9][-_.a-zA-Z0-9]*)[=](.*)");
/*     */ 
/*  49 */   private static final Pattern INT_PATTERN = Pattern.compile("^\\d+$");
/*     */ 
/*     */   public static boolean isBlank(String str)
/*     */   {
/*  53 */     if ((str == null) || (str.length() == 0))
/*  54 */       return true;
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isEmpty(String str)
/*     */   {
/*  66 */     if ((str == null) || (str.length() == 0))
/*  67 */       return true;
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isNotEmpty(String str)
/*     */   {
/*  79 */     return (str != null) && (str.length() > 0);
/*     */   }
/*     */ 
/*     */   public static boolean isEquals(String s1, String s2)
/*     */   {
/*  89 */     if ((s1 == null) && (s2 == null))
/*  90 */       return true;
/*  91 */     if ((s1 == null) || (s2 == null))
/*  92 */       return false;
/*  93 */     return s1.equals(s2);
/*     */   }
/*     */ 
/*     */   public static boolean isInteger(String str)
/*     */   {
/* 103 */     if ((str == null) || (str.length() == 0))
/* 104 */       return false;
/* 105 */     return INT_PATTERN.matcher(str).matches();
/*     */   }
/*     */ 
/*     */   public static int parseInteger(String str) {
/* 109 */     if (!isInteger(str))
/* 110 */       return 0;
/* 111 */     return Integer.parseInt(str);
/*     */   }
/*     */ 
/*     */   public static boolean isJavaIdentifier(String s)
/*     */   {
/* 119 */     if ((s.length() == 0) || (!Character.isJavaIdentifierStart(s.charAt(0)))) {
/* 120 */       return false;
/*     */     }
/* 122 */     for (int i = 1; i < s.length(); i++) {
/* 123 */       if (!Character.isJavaIdentifierPart(s.charAt(i))) {
/* 124 */         return false;
/*     */       }
/*     */     }
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean isContains(String values, String value) {
/* 131 */     if ((values == null) || (values.length() == 0)) {
/* 132 */       return false;
/*     */     }
/* 134 */     return isContains(Constants.COMMA_SPLIT_PATTERN.split(values), value);
/*     */   }
/*     */ 
/*     */   public static boolean isContains(String[] values, String value)
/*     */   {
/* 144 */     if ((value != null) && (value.length() > 0) && (values != null) && (values.length > 0)) {
/* 145 */       for (String v : values) {
/* 146 */         if (value.equals(v)) {
/* 147 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isNumeric(String str) {
/* 155 */     if (str == null) {
/* 156 */       return false;
/*     */     }
/* 158 */     int sz = str.length();
/* 159 */     for (int i = 0; i < sz; i++) {
/* 160 */       if (!Character.isDigit(str.charAt(i))) {
/* 161 */         return false;
/*     */       }
/*     */     }
/* 164 */     return true;
/*     */   }
/*     */ 
/*     */   public static String toString(Throwable e)
/*     */   {
/* 173 */     UnsafeStringWriter w = new UnsafeStringWriter();
/* 174 */     PrintWriter p = new PrintWriter(w);
/* 175 */     p.print(e.getClass().getName());
/* 176 */     if (e.getMessage() != null) {
/* 177 */       p.print(": " + e.getMessage());
/*     */     }
/* 179 */     p.println();
/*     */     try {
/* 181 */       e.printStackTrace(p);
/* 182 */       return w.toString();
/*     */     } finally {
/* 184 */       p.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String toString(String msg, Throwable e)
/*     */   {
/* 195 */     UnsafeStringWriter w = new UnsafeStringWriter();
/* 196 */     w.write(msg + "\n");
/* 197 */     PrintWriter p = new PrintWriter(w);
/*     */     try {
/* 199 */       e.printStackTrace(p);
/* 200 */       return w.toString();
/*     */     } finally {
/* 202 */       p.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String translat(String src, String from, String to)
/*     */   {
/* 216 */     if (isEmpty(src)) return src;
/* 217 */     StringBuilder sb = null;
/*     */ 
/* 220 */     int i = 0; for (int len = src.length(); i < len; i++)
/*     */     {
/* 222 */       char c = src.charAt(i);
/* 223 */       int ix = from.indexOf(c);
/* 224 */       if (ix == -1)
/*     */       {
/* 226 */         if (sb != null)
/* 227 */           sb.append(c);
/*     */       }
/*     */       else
/*     */       {
/* 231 */         if (sb == null)
/*     */         {
/* 233 */           sb = new StringBuilder(len);
/* 234 */           sb.append(src, 0, i);
/*     */         }
/* 236 */         if (ix < to.length())
/* 237 */           sb.append(to.charAt(ix));
/*     */       }
/*     */     }
/* 240 */     return sb == null ? src : sb.toString();
/*     */   }
/*     */ 
/*     */   public static String[] split(String str, char ch)
/*     */   {
/* 251 */     List list = null;
/*     */ 
/* 253 */     int ix = 0; int len = str.length();
/* 254 */     for (int i = 0; i < len; i++)
/*     */     {
/* 256 */       char c = str.charAt(i);
/* 257 */       if (c == ch)
/*     */       {
/* 259 */         if (list == null)
/* 260 */           list = new ArrayList();
/* 261 */         list.add(str.substring(ix, i));
/* 262 */         ix = i + 1;
/*     */       }
/*     */     }
/* 265 */     if (ix > 0)
/* 266 */       list.add(str.substring(ix));
/* 267 */     return list == null ? EMPTY_STRING_ARRAY : (String[])list.toArray(EMPTY_STRING_ARRAY);
/*     */   }
/*     */ 
/*     */   public static String join(String[] array)
/*     */   {
/* 278 */     if (array.length == 0) return "";
/* 279 */     StringBuilder sb = new StringBuilder();
/* 280 */     for (String s : array)
/* 281 */       sb.append(s);
/* 282 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String join(String[] array, char split)
/*     */   {
/* 294 */     if (array.length == 0) return "";
/* 295 */     StringBuilder sb = new StringBuilder();
/* 296 */     for (int i = 0; i < array.length; i++)
/*     */     {
/* 298 */       if (i > 0)
/* 299 */         sb.append(split);
/* 300 */       sb.append(array[i]);
/*     */     }
/* 302 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String join(String[] array, String split)
/*     */   {
/* 314 */     if (array.length == 0) return "";
/* 315 */     StringBuilder sb = new StringBuilder();
/* 316 */     for (int i = 0; i < array.length; i++)
/*     */     {
/* 318 */       if (i > 0)
/* 319 */         sb.append(split);
/* 320 */       sb.append(array[i]);
/*     */     }
/* 322 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String join(Collection<String> coll, String split) {
/* 326 */     if (coll.isEmpty()) return "";
/*     */ 
/* 328 */     StringBuilder sb = new StringBuilder();
/* 329 */     boolean isFirst = true;
/* 330 */     for (String s : coll) {
/* 331 */       if (isFirst) isFirst = false; else sb.append(split);
/* 332 */       sb.append(s);
/*     */     }
/* 334 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static Map<String, String> parseKeyValuePair(String str, String itemSeparator)
/*     */   {
/* 346 */     String[] tmp = str.split(itemSeparator);
/* 347 */     Map map = new HashMap(tmp.length);
/* 348 */     for (int i = 0; i < tmp.length; i++)
/*     */     {
/* 350 */       Matcher matcher = KVP_PATTERN.matcher(tmp[i]);
/* 351 */       if (matcher.matches())
/*     */       {
/* 353 */         map.put(matcher.group(1), matcher.group(2));
/*     */       }
/*     */     }
/* 355 */     return map;
/*     */   }
/*     */ 
/*     */   public static String getQueryStringValue(String qs, String key) {
/* 359 */     Map map = parseQueryString(qs);
/* 360 */     return (String)map.get(key);
/*     */   }
/*     */ 
/*     */   public static Map<String, String> parseQueryString(String qs)
/*     */   {
/* 371 */     if ((qs == null) || (qs.length() == 0))
/* 372 */       return new HashMap();
/* 373 */     return parseKeyValuePair(qs, "\\&");
/*     */   }
/*     */ 
/*     */   public static String getServiceKey(Map<String, String> ps) {
/* 377 */     StringBuilder buf = new StringBuilder();
/* 378 */     String group = (String)ps.get("group");
/* 379 */     if ((group != null) && (group.length() > 0)) {
/* 380 */       buf.append(group).append("/");
/*     */     }
/* 382 */     buf.append((String)ps.get("interface"));
/* 383 */     String version = (String)ps.get("version");
/* 384 */     if ((version != null) && (version.length() > 0)) {
/* 385 */       buf.append(":").append(version);
/*     */     }
/* 387 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static String toQueryString(Map<String, String> ps) {
/* 391 */     StringBuilder buf = new StringBuilder();
/* 392 */     if ((ps != null) && (ps.size() > 0)) {
/* 393 */       for (Map.Entry entry : new TreeMap(ps).entrySet()) {
/* 394 */         String key = (String)entry.getKey();
/* 395 */         String value = (String)entry.getValue();
/* 396 */         if ((key != null) && (key.length() > 0) && (value != null) && (value.length() > 0))
/*     */         {
/* 398 */           if (buf.length() > 0) {
/* 399 */             buf.append("&");
/*     */           }
/* 401 */           buf.append(key);
/* 402 */           buf.append("=");
/* 403 */           buf.append(value);
/*     */         }
/*     */       }
/*     */     }
/* 407 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static String camelToSplitName(String camelName, String split) {
/* 411 */     if ((camelName == null) || (camelName.length() == 0)) {
/* 412 */       return camelName;
/*     */     }
/* 414 */     StringBuilder buf = null;
/* 415 */     for (int i = 0; i < camelName.length(); i++) {
/* 416 */       char ch = camelName.charAt(i);
/* 417 */       if ((ch >= 'A') && (ch <= 'Z')) {
/* 418 */         if (buf == null) {
/* 419 */           buf = new StringBuilder();
/* 420 */           if (i > 0) {
/* 421 */             buf.append(camelName.substring(0, i));
/*     */           }
/*     */         }
/* 424 */         if (i > 0) {
/* 425 */           buf.append(split);
/*     */         }
/* 427 */         buf.append(Character.toLowerCase(ch));
/* 428 */       } else if (buf != null) {
/* 429 */         buf.append(ch);
/*     */       }
/*     */     }
/* 432 */     return buf == null ? camelName : buf.toString();
/*     */   }
/*     */ 
/*     */   public static String toArgumentString(Object[] args) {
/* 436 */     StringBuilder buf = new StringBuilder();
/* 437 */     for (Object arg : args) {
/* 438 */       if (buf.length() > 0) {
/* 439 */         buf.append(",");
/*     */       }
/* 441 */       if ((arg == null) || (ReflectUtils.isPrimitives(arg.getClass())))
/* 442 */         buf.append(arg);
/*     */       else {
/*     */         try {
/* 445 */           buf.append(JSON.json(arg));
/*     */         } catch (IOException e) {
/* 447 */           logger.warn(e.getMessage(), e);
/* 448 */           buf.append(arg);
/*     */         }
/*     */       }
/*     */     }
/* 452 */     return buf.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.StringUtils
 * JD-Core Version:    0.6.2
 */