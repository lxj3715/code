/*     */ package com.alibaba.dubbo.common.utils;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class UrlUtils
/*     */ {
/*     */   public static URL parseURL(String address, Map<String, String> defaults)
/*     */   {
/*  30 */     if ((address == null) || (address.length() == 0))
/*  31 */       return null;
/*     */     String url;
/*     */     String url;
/*  34 */     if (address.indexOf("://") >= 0) {
/*  35 */       url = address;
/*     */     } else {
/*  37 */       String[] addresses = Constants.COMMA_SPLIT_PATTERN.split(address);
/*  38 */       url = addresses[0];
/*  39 */       if (addresses.length > 1) {
/*  40 */         StringBuilder backup = new StringBuilder();
/*  41 */         for (int i = 1; i < addresses.length; i++) {
/*  42 */           if (i > 1) {
/*  43 */             backup.append(",");
/*     */           }
/*  45 */           backup.append(addresses[i]);
/*     */         }
/*  47 */         url = url + "?backup=" + backup.toString();
/*     */       }
/*     */     }
/*  50 */     String defaultProtocol = defaults == null ? null : (String)defaults.get("protocol");
/*  51 */     if ((defaultProtocol == null) || (defaultProtocol.length() == 0)) {
/*  52 */       defaultProtocol = "dubbo";
/*     */     }
/*  54 */     String defaultUsername = defaults == null ? null : (String)defaults.get("username");
/*  55 */     String defaultPassword = defaults == null ? null : (String)defaults.get("password");
/*  56 */     int defaultPort = StringUtils.parseInteger(defaults == null ? null : (String)defaults.get("port"));
/*  57 */     String defaultPath = defaults == null ? null : (String)defaults.get("path");
/*  58 */     Map defaultParameters = defaults == null ? null : new HashMap(defaults);
/*  59 */     if (defaultParameters != null) {
/*  60 */       defaultParameters.remove("protocol");
/*  61 */       defaultParameters.remove("username");
/*  62 */       defaultParameters.remove("password");
/*  63 */       defaultParameters.remove("host");
/*  64 */       defaultParameters.remove("port");
/*  65 */       defaultParameters.remove("path");
/*     */     }
/*  67 */     URL u = URL.valueOf(url);
/*  68 */     boolean changed = false;
/*  69 */     String protocol = u.getProtocol();
/*  70 */     String username = u.getUsername();
/*  71 */     String password = u.getPassword();
/*  72 */     String host = u.getHost();
/*  73 */     int port = u.getPort();
/*  74 */     String path = u.getPath();
/*  75 */     Map parameters = new HashMap(u.getParameters());
/*  76 */     if (((protocol == null) || (protocol.length() == 0)) && (defaultProtocol != null) && (defaultProtocol.length() > 0)) {
/*  77 */       changed = true;
/*  78 */       protocol = defaultProtocol;
/*     */     }
/*  80 */     if (((username == null) || (username.length() == 0)) && (defaultUsername != null) && (defaultUsername.length() > 0)) {
/*  81 */       changed = true;
/*  82 */       username = defaultUsername;
/*     */     }
/*  84 */     if (((password == null) || (password.length() == 0)) && (defaultPassword != null) && (defaultPassword.length() > 0)) {
/*  85 */       changed = true;
/*  86 */       password = defaultPassword;
/*     */     }
/*     */ 
/*  92 */     if (port <= 0) {
/*  93 */       if (defaultPort > 0) {
/*  94 */         changed = true;
/*  95 */         port = defaultPort;
/*     */       } else {
/*  97 */         changed = true;
/*  98 */         port = 9090;
/*     */       }
/*     */     }
/* 101 */     if (((path == null) || (path.length() == 0)) && 
/* 102 */       (defaultPath != null) && (defaultPath.length() > 0)) {
/* 103 */       changed = true;
/* 104 */       path = defaultPath;
/*     */     }
/*     */ 
/* 107 */     if ((defaultParameters != null) && (defaultParameters.size() > 0)) {
/* 108 */       for (Map.Entry entry : defaultParameters.entrySet()) {
/* 109 */         String key = (String)entry.getKey();
/* 110 */         String defaultValue = (String)entry.getValue();
/* 111 */         if ((defaultValue != null) && (defaultValue.length() > 0)) {
/* 112 */           String value = (String)parameters.get(key);
/* 113 */           if ((value == null) || (value.length() == 0)) {
/* 114 */             changed = true;
/* 115 */             parameters.put(key, defaultValue);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 120 */     if (changed) {
/* 121 */       u = new URL(protocol, username, password, host, port, path, parameters);
/*     */     }
/* 123 */     return u;
/*     */   }
/*     */ 
/*     */   public static List<URL> parseURLs(String address, Map<String, String> defaults) {
/* 127 */     if ((address == null) || (address.length() == 0)) {
/* 128 */       return null;
/*     */     }
/* 130 */     String[] addresses = Constants.REGISTRY_SPLIT_PATTERN.split(address);
/* 131 */     if ((addresses == null) || (addresses.length == 0)) {
/* 132 */       return null;
/*     */     }
/* 134 */     List registries = new ArrayList();
/* 135 */     for (String addr : addresses) {
/* 136 */       registries.add(parseURL(addr, defaults));
/*     */     }
/* 138 */     return registries;
/*     */   }
/*     */ 
/*     */   public static Map<String, Map<String, String>> convertRegister(Map<String, Map<String, String>> register) {
/* 142 */     Map newRegister = new HashMap();
/* 143 */     for (Map.Entry entry : register.entrySet()) {
/* 144 */       String serviceName = (String)entry.getKey();
/* 145 */       Map serviceUrls = (Map)entry.getValue();
/* 146 */       if ((!serviceName.contains(":")) && (!serviceName.contains("/")))
/* 147 */         for (Map.Entry entry2 : serviceUrls.entrySet()) {
/* 148 */           String serviceUrl = (String)entry2.getKey();
/* 149 */           String serviceQuery = (String)entry2.getValue();
/* 150 */           Map params = StringUtils.parseQueryString(serviceQuery);
/* 151 */           String group = (String)params.get("group");
/* 152 */           String version = (String)params.get("version");
/*     */ 
/* 155 */           String name = serviceName;
/* 156 */           if ((group != null) && (group.length() > 0)) {
/* 157 */             name = group + "/" + name;
/*     */           }
/* 159 */           if ((version != null) && (version.length() > 0)) {
/* 160 */             name = name + ":" + version;
/*     */           }
/* 162 */           Map newUrls = (Map)newRegister.get(name);
/* 163 */           if (newUrls == null) {
/* 164 */             newUrls = new HashMap();
/* 165 */             newRegister.put(name, newUrls);
/*     */           }
/* 167 */           newUrls.put(serviceUrl, StringUtils.toQueryString(params));
/*     */         }
/*     */       else {
/* 170 */         newRegister.put(serviceName, serviceUrls);
/*     */       }
/*     */     }
/* 173 */     return newRegister;
/*     */   }
/*     */ 
/*     */   public static Map<String, String> convertSubscribe(Map<String, String> subscribe) {
/* 177 */     Map newSubscribe = new HashMap();
/* 178 */     for (Map.Entry entry : subscribe.entrySet()) {
/* 179 */       String serviceName = (String)entry.getKey();
/* 180 */       String serviceQuery = (String)entry.getValue();
/* 181 */       if ((!serviceName.contains(":")) && (!serviceName.contains("/"))) {
/* 182 */         Map params = StringUtils.parseQueryString(serviceQuery);
/* 183 */         String group = (String)params.get("group");
/* 184 */         String version = (String)params.get("version");
/*     */ 
/* 187 */         String name = serviceName;
/* 188 */         if ((group != null) && (group.length() > 0)) {
/* 189 */           name = group + "/" + name;
/*     */         }
/* 191 */         if ((version != null) && (version.length() > 0)) {
/* 192 */           name = name + ":" + version;
/*     */         }
/* 194 */         newSubscribe.put(name, StringUtils.toQueryString(params));
/*     */       } else {
/* 196 */         newSubscribe.put(serviceName, serviceQuery);
/*     */       }
/*     */     }
/* 199 */     return newSubscribe;
/*     */   }
/*     */ 
/*     */   public static Map<String, Map<String, String>> revertRegister(Map<String, Map<String, String>> register) {
/* 203 */     Map newRegister = new HashMap();
/* 204 */     for (Map.Entry entry : register.entrySet()) {
/* 205 */       String serviceName = (String)entry.getKey();
/* 206 */       Map serviceUrls = (Map)entry.getValue();
/* 207 */       if ((serviceName.contains(":")) || (serviceName.contains("/")))
/* 208 */         for (Map.Entry entry2 : serviceUrls.entrySet()) {
/* 209 */           String serviceUrl = (String)entry2.getKey();
/* 210 */           String serviceQuery = (String)entry2.getValue();
/* 211 */           Map params = StringUtils.parseQueryString(serviceQuery);
/* 212 */           String name = serviceName;
/* 213 */           int i = name.indexOf('/');
/* 214 */           if (i >= 0) {
/* 215 */             params.put("group", name.substring(0, i));
/* 216 */             name = name.substring(i + 1);
/*     */           }
/* 218 */           i = name.lastIndexOf(':');
/* 219 */           if (i >= 0) {
/* 220 */             params.put("version", name.substring(i + 1));
/* 221 */             name = name.substring(0, i);
/*     */           }
/* 223 */           Map newUrls = (Map)newRegister.get(name);
/* 224 */           if (newUrls == null) {
/* 225 */             newUrls = new HashMap();
/* 226 */             newRegister.put(name, newUrls);
/*     */           }
/* 228 */           newUrls.put(serviceUrl, StringUtils.toQueryString(params));
/*     */         }
/*     */       else {
/* 231 */         newRegister.put(serviceName, serviceUrls);
/*     */       }
/*     */     }
/* 234 */     return newRegister;
/*     */   }
/*     */ 
/*     */   public static Map<String, String> revertSubscribe(Map<String, String> subscribe) {
/* 238 */     Map newSubscribe = new HashMap();
/* 239 */     for (Map.Entry entry : subscribe.entrySet()) {
/* 240 */       String serviceName = (String)entry.getKey();
/* 241 */       String serviceQuery = (String)entry.getValue();
/* 242 */       if ((serviceName.contains(":")) || (serviceName.contains("/"))) {
/* 243 */         Map params = StringUtils.parseQueryString(serviceQuery);
/* 244 */         String name = serviceName;
/* 245 */         int i = name.indexOf('/');
/* 246 */         if (i >= 0) {
/* 247 */           params.put("group", name.substring(0, i));
/* 248 */           name = name.substring(i + 1);
/*     */         }
/* 250 */         i = name.lastIndexOf(':');
/* 251 */         if (i >= 0) {
/* 252 */           params.put("version", name.substring(i + 1));
/* 253 */           name = name.substring(0, i);
/*     */         }
/* 255 */         newSubscribe.put(name, StringUtils.toQueryString(params));
/*     */       } else {
/* 257 */         newSubscribe.put(serviceName, serviceQuery);
/*     */       }
/*     */     }
/* 260 */     return newSubscribe;
/*     */   }
/*     */ 
/*     */   public static Map<String, Map<String, String>> revertNotify(Map<String, Map<String, String>> notify) {
/* 264 */     if ((notify != null) && (notify.size() > 0)) {
/* 265 */       Map newNotify = new HashMap();
/* 266 */       for (Map.Entry entry : notify.entrySet()) {
/* 267 */         String serviceName = (String)entry.getKey();
/* 268 */         Map serviceUrls = (Map)entry.getValue();
/* 269 */         if ((!serviceName.contains(":")) && (!serviceName.contains("/"))) {
/* 270 */           if ((serviceUrls != null) && (serviceUrls.size() > 0))
/* 271 */             for (Map.Entry entry2 : serviceUrls.entrySet()) {
/* 272 */               String url = (String)entry2.getKey();
/* 273 */               String query = (String)entry2.getValue();
/* 274 */               Map params = StringUtils.parseQueryString(query);
/* 275 */               String group = (String)params.get("group");
/* 276 */               String version = (String)params.get("version");
/*     */ 
/* 279 */               String name = serviceName;
/* 280 */               if ((group != null) && (group.length() > 0)) {
/* 281 */                 name = group + "/" + name;
/*     */               }
/* 283 */               if ((version != null) && (version.length() > 0)) {
/* 284 */                 name = name + ":" + version;
/*     */               }
/* 286 */               Map newUrls = (Map)newNotify.get(name);
/* 287 */               if (newUrls == null) {
/* 288 */                 newUrls = new HashMap();
/* 289 */                 newNotify.put(name, newUrls);
/*     */               }
/* 291 */               newUrls.put(url, StringUtils.toQueryString(params));
/*     */             }
/*     */         }
/*     */         else {
/* 295 */           newNotify.put(serviceName, serviceUrls);
/*     */         }
/*     */       }
/* 298 */       return newNotify;
/*     */     }
/* 300 */     return notify;
/*     */   }
/*     */ 
/*     */   public static List<String> revertForbid(List<String> forbid, Set<URL> subscribed)
/*     */   {
/* 305 */     if ((forbid != null) && (forbid.size() > 0)) {
/* 306 */       List newForbid = new ArrayList();
/* 307 */       for (String serviceName : forbid) {
/* 308 */         if ((!serviceName.contains(":")) && (!serviceName.contains("/"))) {
/* 309 */           for (URL url : subscribed)
/* 310 */             if (serviceName.equals(url.getServiceInterface())) {
/* 311 */               newForbid.add(url.getServiceKey());
/* 312 */               break;
/*     */             }
/*     */         }
/*     */         else {
/* 316 */           newForbid.add(serviceName);
/*     */         }
/*     */       }
/* 319 */       return newForbid;
/*     */     }
/* 321 */     return forbid;
/*     */   }
/*     */ 
/*     */   public static URL getEmptyUrl(String service, String category) {
/* 325 */     String group = null;
/* 326 */     String version = null;
/* 327 */     int i = service.indexOf('/');
/* 328 */     if (i > 0) {
/* 329 */       group = service.substring(0, i);
/* 330 */       service = service.substring(i + 1);
/*     */     }
/* 332 */     i = service.lastIndexOf(':');
/* 333 */     if (i > 0) {
/* 334 */       version = service.substring(i + 1);
/* 335 */       service = service.substring(0, i);
/*     */     }
/* 337 */     return URL.valueOf("empty://0.0.0.0/" + service + "?" + "category" + "=" + category + (group == null ? "" : new StringBuilder().append("&group=").append(group).toString()) + (version == null ? "" : new StringBuilder().append("&version=").append(version).toString()));
/*     */   }
/*     */ 
/*     */   public static boolean isMatchCategory(String category, String categories)
/*     */   {
/* 344 */     if ((categories == null) || (categories.length() == 0))
/* 345 */       return "providers".equals(category);
/* 346 */     if (categories.contains("*"))
/* 347 */       return true;
/* 348 */     if (categories.contains("-")) {
/* 349 */       return !categories.contains("-" + category);
/*     */     }
/* 351 */     return categories.contains(category);
/*     */   }
/*     */ 
/*     */   public static boolean isMatch(URL consumerUrl, URL providerUrl)
/*     */   {
/* 356 */     String consumerInterface = consumerUrl.getServiceInterface();
/* 357 */     String providerInterface = providerUrl.getServiceInterface();
/* 358 */     if ((!"*".equals(consumerInterface)) && (!StringUtils.isEquals(consumerInterface, providerInterface))) return false;
/*     */ 
/* 360 */     if (!isMatchCategory(providerUrl.getParameter("category", "providers"), consumerUrl.getParameter("category", "providers")))
/*     */     {
/* 362 */       return false;
/*     */     }
/* 364 */     if ((!providerUrl.getParameter("enabled", true)) && (!"*".equals(consumerUrl.getParameter("enabled"))))
/*     */     {
/* 366 */       return false;
/*     */     }
/*     */ 
/* 369 */     String consumerGroup = consumerUrl.getParameter("group");
/* 370 */     String consumerVersion = consumerUrl.getParameter("version");
/* 371 */     String consumerClassifier = consumerUrl.getParameter("classifier", "*");
/*     */ 
/* 373 */     String providerGroup = providerUrl.getParameter("group");
/* 374 */     String providerVersion = providerUrl.getParameter("version");
/* 375 */     String providerClassifier = providerUrl.getParameter("classifier", "*");
/* 376 */     return (("*".equals(consumerGroup)) || (StringUtils.isEquals(consumerGroup, providerGroup)) || (StringUtils.isContains(consumerGroup, providerGroup))) && (("*".equals(consumerVersion)) || (StringUtils.isEquals(consumerVersion, providerVersion))) && ((consumerClassifier == null) || ("*".equals(consumerClassifier)) || (StringUtils.isEquals(consumerClassifier, providerClassifier)));
/*     */   }
/*     */ 
/*     */   public static boolean isMatchGlobPattern(String pattern, String value, URL param)
/*     */   {
/* 382 */     if ((param != null) && (pattern.startsWith("$"))) {
/* 383 */       pattern = param.getRawParameter(pattern.substring(1));
/*     */     }
/* 385 */     return isMatchGlobPattern(pattern, value);
/*     */   }
/*     */ 
/*     */   public static boolean isMatchGlobPattern(String pattern, String value) {
/* 389 */     if ("*".equals(pattern))
/* 390 */       return true;
/* 391 */     if (((pattern == null) || (pattern.length() == 0)) && ((value == null) || (value.length() == 0)))
/*     */     {
/* 393 */       return true;
/* 394 */     }if ((pattern == null) || (pattern.length() == 0) || (value == null) || (value.length() == 0))
/*     */     {
/* 396 */       return false;
/*     */     }
/* 398 */     int i = pattern.lastIndexOf('*');
/*     */ 
/* 400 */     if (i == -1) {
/* 401 */       return value.equals(pattern);
/*     */     }
/*     */ 
/* 404 */     if (i == pattern.length() - 1) {
/* 405 */       return value.startsWith(pattern.substring(0, i));
/*     */     }
/*     */ 
/* 408 */     if (i == 0) {
/* 409 */       return value.endsWith(pattern.substring(i + 1));
/*     */     }
/*     */ 
/* 413 */     String prefix = pattern.substring(0, i);
/* 414 */     String suffix = pattern.substring(i + 1);
/* 415 */     return (value.startsWith(prefix)) && (value.endsWith(suffix));
/*     */   }
/*     */ 
/*     */   public static boolean isServiceKeyMatch(URL pattern, URL value)
/*     */   {
/* 420 */     return (pattern.getParameter("interface").equals(value.getParameter("interface"))) && (isItemMatch(pattern.getParameter("group"), value.getParameter("group"))) && (isItemMatch(pattern.getParameter("version"), value.getParameter("version")));
/*     */   }
/*     */ 
/*     */   static boolean isItemMatch(String pattern, String value)
/*     */   {
/* 436 */     if (pattern == null) {
/* 437 */       return value == null;
/*     */     }
/* 439 */     return ("*".equals(pattern)) || (pattern.equals(value));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.common.utils.UrlUtils
 * JD-Core Version:    0.6.2
 */