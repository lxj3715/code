/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.CollectionUtils;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public abstract class AbstractConfig
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4267533505537413570L;
/*  47 */   protected static final Logger logger = LoggerFactory.getLogger(AbstractConfig.class);
/*     */   private static final int MAX_LENGTH = 100;
/*     */   private static final int MAX_PATH_LENGTH = 200;
/*  53 */   private static final Pattern PATTERN_NAME = Pattern.compile("[\\-._0-9a-zA-Z]+");
/*     */ 
/*  55 */   private static final Pattern PATTERN_MULTI_NAME = Pattern.compile("[,\\-._0-9a-zA-Z]+");
/*     */ 
/*  57 */   private static final Pattern PATTERN_METHOD_NAME = Pattern.compile("[a-zA-Z][0-9a-zA-Z]*");
/*     */ 
/*  59 */   private static final Pattern PATTERN_PATH = Pattern.compile("[/\\-$._0-9a-zA-Z]+");
/*     */ 
/*  61 */   private static final Pattern PATTERN_NAME_HAS_SYMBOL = Pattern.compile("[:*,/\\-._0-9a-zA-Z]+");
/*     */ 
/*  63 */   private static final Pattern PATTERN_KEY = Pattern.compile("[*,\\-._0-9a-zA-Z]+");
/*     */   protected String id;
/*  76 */   private static final Map<String, String> legacyProperties = new HashMap();
/*     */ 
/* 457 */   private static final String[] SUFFIXS = { "Config", "Bean" };
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getId()
/*     */   {
/*  69 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String id) {
/*  73 */     this.id = id;
/*     */   }
/*     */ 
/*     */   private static String convertLegacyValue(String key, String value)
/*     */   {
/*  89 */     if ((value != null) && (value.length() > 0)) {
/*  90 */       if ("dubbo.service.max.retry.providers".equals(key))
/*  91 */         return String.valueOf(Integer.parseInt(value) - 1);
/*  92 */       if ("dubbo.service.allow.no.provider".equals(key)) {
/*  93 */         return String.valueOf(!Boolean.parseBoolean(value));
/*     */       }
/*     */     }
/*  96 */     return value;
/*     */   }
/*     */ 
/*     */   protected void appendAnnotation(Class<?> annotationClass, Object annotation) {
/* 100 */     Method[] methods = annotationClass.getMethods();
/* 101 */     for (Method method : methods)
/* 102 */       if ((method.getDeclaringClass() != Object.class) && (method.getReturnType() != Void.TYPE) && (method.getParameterTypes().length == 0) && (Modifier.isPublic(method.getModifiers())) && (!Modifier.isStatic(method.getModifiers())))
/*     */       {
/*     */         try
/*     */         {
/* 108 */           String property = method.getName();
/* 109 */           if (("interfaceClass".equals(property)) || ("interfaceName".equals(property))) {
/* 110 */             property = "interface";
/*     */           }
/* 112 */           String setter = "set" + property.substring(0, 1).toUpperCase() + property.substring(1);
/* 113 */           Object value = method.invoke(annotation, new Object[0]);
/* 114 */           if ((value != null) && (!value.equals(method.getDefaultValue()))) {
/* 115 */             Class parameterType = ReflectUtils.getBoxedClass(method.getReturnType());
/* 116 */             if (("filter".equals(property)) || ("listener".equals(property))) {
/* 117 */               parameterType = String.class;
/* 118 */               value = StringUtils.join((String[])value, ",");
/* 119 */             } else if ("parameters".equals(property)) {
/* 120 */               parameterType = Map.class;
/* 121 */               value = CollectionUtils.toStringMap((String[])value);
/*     */             }
/*     */             try {
/* 124 */               Method setterMethod = getClass().getMethod(setter, new Class[] { parameterType });
/* 125 */               setterMethod.invoke(this, new Object[] { value });
/*     */             } catch (NoSuchMethodException e) {
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Throwable e) {
/* 131 */           logger.error(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   protected static void appendProperties(AbstractConfig config)
/*     */   {
/* 138 */     if (config == null) {
/* 139 */       return;
/*     */     }
/* 141 */     String prefix = "dubbo." + getTagName(config.getClass()) + ".";
/* 142 */     Method[] methods = config.getClass().getMethods();
/* 143 */     for (Method method : methods)
/*     */       try {
/* 145 */         String name = method.getName();
/* 146 */         if ((name.length() > 3) && (name.startsWith("set")) && (Modifier.isPublic(method.getModifiers())) && (method.getParameterTypes().length == 1) && (isPrimitive(method.getParameterTypes()[0])))
/*     */         {
/* 148 */           String property = StringUtils.camelToSplitName(name.substring(3, 4).toLowerCase() + name.substring(4), "-");
/*     */ 
/* 150 */           String value = null;
/* 151 */           if ((config.getId() != null) && (config.getId().length() > 0)) {
/* 152 */             String pn = prefix + config.getId() + "." + property;
/* 153 */             value = System.getProperty(pn);
/* 154 */             if (!StringUtils.isBlank(value)) {
/* 155 */               logger.info("Use System Property " + pn + " to config dubbo");
/*     */             }
/*     */           }
/* 158 */           if ((value == null) || (value.length() == 0)) {
/* 159 */             String pn = prefix + property;
/* 160 */             value = System.getProperty(pn);
/* 161 */             if (!StringUtils.isBlank(value)) {
/* 162 */               logger.info("Use System Property " + pn + " to config dubbo");
/*     */             }
/*     */           }
/* 165 */           if ((value == null) || (value.length() == 0)) {
/*     */             Method getter;
/*     */             try {
/* 168 */               getter = config.getClass().getMethod("get" + name.substring(3), new Class[0]);
/*     */             } catch (NoSuchMethodException e) {
/*     */               try {
/* 171 */                 getter = config.getClass().getMethod("is" + name.substring(3), new Class[0]);
/*     */               } catch (NoSuchMethodException e2) {
/* 173 */                 getter = null;
/*     */               }
/*     */             }
/* 176 */             if ((getter != null) && 
/* 177 */               (getter.invoke(config, new Object[0]) == null)) {
/* 178 */               if ((config.getId() != null) && (config.getId().length() > 0)) {
/* 179 */                 value = ConfigUtils.getProperty(prefix + config.getId() + "." + property);
/*     */               }
/* 181 */               if ((value == null) || (value.length() == 0)) {
/* 182 */                 value = ConfigUtils.getProperty(prefix + property);
/*     */               }
/* 184 */               if ((value == null) || (value.length() == 0)) {
/* 185 */                 String legacyKey = (String)legacyProperties.get(prefix + property);
/* 186 */                 if ((legacyKey != null) && (legacyKey.length() > 0)) {
/* 187 */                   value = convertLegacyValue(legacyKey, ConfigUtils.getProperty(legacyKey));
/*     */                 }
/*     */               }
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 194 */           if ((value != null) && (value.length() > 0))
/* 195 */             method.invoke(config, new Object[] { convertPrimitive(method.getParameterTypes()[0], value) });
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 199 */         logger.error(e.getMessage(), e);
/*     */       }
/*     */   }
/*     */ 
/*     */   private static String getTagName(Class<?> cls)
/*     */   {
/* 205 */     String tag = cls.getSimpleName();
/* 206 */     for (String suffix : SUFFIXS) {
/* 207 */       if (tag.endsWith(suffix)) {
/* 208 */         tag = tag.substring(0, tag.length() - suffix.length());
/* 209 */         break;
/*     */       }
/*     */     }
/* 212 */     tag = tag.toLowerCase();
/* 213 */     return tag;
/*     */   }
/*     */ 
/*     */   protected static void appendParameters(Map<String, String> parameters, Object config) {
/* 217 */     appendParameters(parameters, config, null);
/*     */   }
/*     */ 
/*     */   protected static void appendParameters(Map<String, String> parameters, Object config, String prefix)
/*     */   {
/* 222 */     if (config == null) {
/* 223 */       return;
/*     */     }
/* 225 */     Method[] methods = config.getClass().getMethods();
/* 226 */     for (Method method : methods)
/*     */       try {
/* 228 */         String name = method.getName();
/* 229 */         if (((name.startsWith("get")) || (name.startsWith("is"))) && (!"getClass".equals(name)) && (Modifier.isPublic(method.getModifiers())) && (method.getParameterTypes().length == 0) && (isPrimitive(method.getReturnType())))
/*     */         {
/* 234 */           Parameter parameter = (Parameter)method.getAnnotation(Parameter.class);
/* 235 */           if ((method.getReturnType() != Object.class) && ((parameter != null) && (parameter.excluded()))) {
/*     */             continue;
/*     */           }
/* 238 */           int i = name.startsWith("get") ? 3 : 2;
/* 239 */           String prop = StringUtils.camelToSplitName(name.substring(i, i + 1).toLowerCase() + name.substring(i + 1), ".");
/*     */           String key;
/*     */           String key;
/* 241 */           if ((parameter != null) && (parameter.key() != null) && (parameter.key().length() > 0))
/* 242 */             key = parameter.key();
/*     */           else {
/* 244 */             key = prop;
/*     */           }
/* 246 */           Object value = method.invoke(config, new Object[0]);
/* 247 */           String str = String.valueOf(value).trim();
/* 248 */           if ((value != null) && (str.length() > 0)) {
/* 249 */             if ((parameter != null) && (parameter.escaped())) {
/* 250 */               str = URL.encode(str);
/*     */             }
/* 252 */             if ((parameter != null) && (parameter.append())) {
/* 253 */               String pre = (String)parameters.get("default." + key);
/* 254 */               if ((pre != null) && (pre.length() > 0)) {
/* 255 */                 str = pre + "," + str;
/*     */               }
/* 257 */               pre = (String)parameters.get(key);
/* 258 */               if ((pre != null) && (pre.length() > 0)) {
/* 259 */                 str = pre + "," + str;
/*     */               }
/*     */             }
/* 262 */             if ((prefix != null) && (prefix.length() > 0)) {
/* 263 */               key = prefix + "." + key;
/*     */             }
/* 265 */             parameters.put(key, str);
/* 266 */           } else if ((parameter != null) && (parameter.required())) {
/* 267 */             throw new IllegalStateException(config.getClass().getSimpleName() + "." + key + " == null");
/*     */           }
/* 269 */         } else if (("getParameters".equals(name)) && (Modifier.isPublic(method.getModifiers())) && (method.getParameterTypes().length == 0) && (method.getReturnType() == Map.class))
/*     */         {
/* 273 */           Map map = (Map)method.invoke(config, new Object[0]);
/* 274 */           if ((map != null) && (map.size() > 0)) {
/* 275 */             pre = (prefix != null) && (prefix.length() > 0) ? prefix + "." : "";
/* 276 */             for (Map.Entry entry : map.entrySet())
/* 277 */               parameters.put(pre + ((String)entry.getKey()).replace('-', '.'), entry.getValue());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */         String pre;
/* 282 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected static void appendAttributes(Map<Object, Object> parameters, Object config)
/*     */   {
/* 288 */     appendAttributes(parameters, config, null);
/*     */   }
/*     */ 
/*     */   protected static void appendAttributes(Map<Object, Object> parameters, Object config, String prefix) {
/* 292 */     if (config == null) {
/* 293 */       return;
/*     */     }
/* 295 */     Method[] methods = config.getClass().getMethods();
/* 296 */     for (Method method : methods)
/*     */       try {
/* 298 */         String name = method.getName();
/* 299 */         if (((name.startsWith("get")) || (name.startsWith("is"))) && (!"getClass".equals(name)) && (Modifier.isPublic(method.getModifiers())) && (method.getParameterTypes().length == 0) && (isPrimitive(method.getReturnType())))
/*     */         {
/* 304 */           Parameter parameter = (Parameter)method.getAnnotation(Parameter.class);
/* 305 */           if ((parameter != null) && (!parameter.attribute()))
/*     */             continue;
/*     */           String key;
/*     */           String key;
/* 308 */           if ((parameter != null) && (parameter.key() != null) && (parameter.key().length() > 0)) {
/* 309 */             key = parameter.key();
/*     */           } else {
/* 311 */             int i = name.startsWith("get") ? 3 : 2;
/* 312 */             key = name.substring(i, i + 1).toLowerCase() + name.substring(i + 1);
/*     */           }
/* 314 */           Object value = method.invoke(config, new Object[0]);
/* 315 */           if (value != null) {
/* 316 */             if ((prefix != null) && (prefix.length() > 0)) {
/* 317 */               key = prefix + "." + key;
/*     */             }
/* 319 */             parameters.put(key, value);
/*     */           }
/*     */         }
/*     */       } catch (Exception e) {
/* 323 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/*     */   }
/*     */ 
/*     */   private static boolean isPrimitive(Class<?> type)
/*     */   {
/* 329 */     return (type.isPrimitive()) || (type == String.class) || (type == Character.class) || (type == Boolean.class) || (type == Byte.class) || (type == Short.class) || (type == Integer.class) || (type == Long.class) || (type == Float.class) || (type == Double.class) || (type == Object.class);
/*     */   }
/*     */ 
/*     */   private static Object convertPrimitive(Class<?> type, String value)
/*     */   {
/* 343 */     if ((type == Character.TYPE) || (type == Character.class))
/* 344 */       return Character.valueOf(value.length() > 0 ? value.charAt(0) : '\000');
/* 345 */     if ((type == Boolean.TYPE) || (type == Boolean.class))
/* 346 */       return Boolean.valueOf(value);
/* 347 */     if ((type == Byte.TYPE) || (type == Byte.class))
/* 348 */       return Byte.valueOf(value);
/* 349 */     if ((type == Short.TYPE) || (type == Short.class))
/* 350 */       return Short.valueOf(value);
/* 351 */     if ((type == Integer.TYPE) || (type == Integer.class))
/* 352 */       return Integer.valueOf(value);
/* 353 */     if ((type == Long.TYPE) || (type == Long.class))
/* 354 */       return Long.valueOf(value);
/* 355 */     if ((type == Float.TYPE) || (type == Float.class))
/* 356 */       return Float.valueOf(value);
/* 357 */     if ((type == Double.TYPE) || (type == Double.class)) {
/* 358 */       return Double.valueOf(value);
/*     */     }
/* 360 */     return value;
/*     */   }
/*     */ 
/*     */   protected static void checkExtension(Class<?> type, String property, String value) {
/* 364 */     checkName(property, value);
/* 365 */     if ((value != null) && (value.length() > 0) && (!ExtensionLoader.getExtensionLoader(type).hasExtension(value)))
/*     */     {
/* 367 */       throw new IllegalStateException("No such extension " + value + " for " + property + "/" + type.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static void checkMultiExtension(Class<?> type, String property, String value) {
/* 372 */     checkMultiName(property, value);
/* 373 */     if ((value != null) && (value.length() > 0)) {
/* 374 */       String[] values = value.split("\\s*[,]+\\s*");
/* 375 */       for (String v : values) {
/* 376 */         if (v.startsWith("-")) {
/* 377 */           v = v.substring(1);
/*     */         }
/* 379 */         if (!"default".equals(v))
/*     */         {
/* 382 */           if (!ExtensionLoader.getExtensionLoader(type).hasExtension(v))
/* 383 */             throw new IllegalStateException("No such extension " + v + " for " + property + "/" + type.getName());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static void checkLength(String property, String value) {
/* 390 */     checkProperty(property, value, 100, null);
/*     */   }
/*     */ 
/*     */   protected static void checkPathLength(String property, String value) {
/* 394 */     checkProperty(property, value, 200, null);
/*     */   }
/*     */ 
/*     */   protected static void checkName(String property, String value) {
/* 398 */     checkProperty(property, value, 100, PATTERN_NAME);
/*     */   }
/*     */ 
/*     */   protected static void checkNameHasSymbol(String property, String value) {
/* 402 */     checkProperty(property, value, 100, PATTERN_NAME_HAS_SYMBOL);
/*     */   }
/*     */ 
/*     */   protected static void checkKey(String property, String value) {
/* 406 */     checkProperty(property, value, 100, PATTERN_KEY);
/*     */   }
/*     */ 
/*     */   protected static void checkMultiName(String property, String value) {
/* 410 */     checkProperty(property, value, 100, PATTERN_MULTI_NAME);
/*     */   }
/*     */ 
/*     */   protected static void checkPathName(String property, String value) {
/* 414 */     checkProperty(property, value, 200, PATTERN_PATH);
/*     */   }
/*     */ 
/*     */   protected static void checkMethodName(String property, String value) {
/* 418 */     checkProperty(property, value, 100, PATTERN_METHOD_NAME);
/*     */   }
/*     */ 
/*     */   protected static void checkParameterName(Map<String, String> parameters) {
/* 422 */     if ((parameters == null) || (parameters.size() == 0)) {
/* 423 */       return;
/*     */     }
/* 425 */     for (Map.Entry entry : parameters.entrySet())
/*     */     {
/* 427 */       checkNameHasSymbol((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static void checkProperty(String property, String value, int maxlength, Pattern pattern) {
/* 432 */     if ((value == null) || (value.length() == 0)) {
/* 433 */       return;
/*     */     }
/* 435 */     if (value.length() > maxlength) {
/* 436 */       throw new IllegalStateException("Invalid " + property + "=\"" + value + "\" is longer than " + maxlength);
/*     */     }
/* 438 */     if (pattern != null) {
/* 439 */       Matcher matcher = pattern.matcher(value);
/* 440 */       if (!matcher.matches())
/* 441 */         throw new IllegalStateException("Invalid " + property + "=\"" + value + "\" contain illegal charactor, only digit, letter, '-', '_' and '.' is legal.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*     */     try
/*     */     {
/* 462 */       StringBuilder buf = new StringBuilder();
/* 463 */       buf.append("<dubbo:");
/* 464 */       buf.append(getTagName(getClass()));
/* 465 */       Method[] methods = getClass().getMethods();
/* 466 */       for (Method method : methods) {
/*     */         try {
/* 468 */           String name = method.getName();
/* 469 */           if (((name.startsWith("get")) || (name.startsWith("is"))) && (!"getClass".equals(name)) && (!"get".equals(name)) && (!"is".equals(name)) && (Modifier.isPublic(method.getModifiers())) && (method.getParameterTypes().length == 0) && (isPrimitive(method.getReturnType())))
/*     */           {
/* 474 */             int i = name.startsWith("get") ? 3 : 2;
/* 475 */             String key = name.substring(i, i + 1).toLowerCase() + name.substring(i + 1);
/* 476 */             Object value = method.invoke(this, new Object[0]);
/* 477 */             if (value != null) {
/* 478 */               buf.append(" ");
/* 479 */               buf.append(key);
/* 480 */               buf.append("=\"");
/* 481 */               buf.append(value);
/* 482 */               buf.append("\"");
/*     */             }
/*     */           }
/*     */         } catch (Exception e) {
/* 486 */           logger.warn(e.getMessage(), e);
/*     */         }
/*     */       }
/* 489 */       buf.append(" />");
/* 490 */       return buf.toString();
/*     */     } catch (Throwable t) {
/* 492 */       logger.warn(t.getMessage(), t);
/* 493 */     }return super.toString();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  78 */     legacyProperties.put("dubbo.protocol.name", "dubbo.service.protocol");
/*  79 */     legacyProperties.put("dubbo.protocol.host", "dubbo.service.server.host");
/*  80 */     legacyProperties.put("dubbo.protocol.port", "dubbo.service.server.port");
/*  81 */     legacyProperties.put("dubbo.protocol.threads", "dubbo.service.max.thread.pool.size");
/*  82 */     legacyProperties.put("dubbo.consumer.timeout", "dubbo.service.invoke.timeout");
/*  83 */     legacyProperties.put("dubbo.consumer.retries", "dubbo.service.max.retry.providers");
/*  84 */     legacyProperties.put("dubbo.consumer.check", "dubbo.service.allow.no.provider");
/*  85 */     legacyProperties.put("dubbo.service.url", "dubbo.service.address");
/*     */ 
/* 447 */     Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
/*     */       public void run() {
/* 449 */         if (AbstractConfig.logger.isInfoEnabled()) {
/* 450 */           AbstractConfig.logger.info("Run shutdown hook now.");
/*     */         }
/* 452 */         ProtocolConfig.destroyAll();
/*     */       }
/*     */     }
/*     */     , "DubboShutdownHook"));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.AbstractConfig
 * JD-Core Version:    0.6.2
 */