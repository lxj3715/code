/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.common.utils.UrlUtils;
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.monitor.MonitorFactory;
/*     */ import com.alibaba.dubbo.monitor.MonitorService;
/*     */ import com.alibaba.dubbo.registry.RegistryFactory;
/*     */ import com.alibaba.dubbo.registry.RegistryService;
/*     */ import com.alibaba.dubbo.rpc.Filter;
/*     */ import com.alibaba.dubbo.rpc.InvokerListener;
/*     */ import com.alibaba.dubbo.rpc.ProxyFactory;
/*     */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*     */ import com.alibaba.dubbo.rpc.support.MockInvoker;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class AbstractInterfaceConfig extends AbstractMethodConfig
/*     */ {
/*     */   private static final long serialVersionUID = -1559314110797223229L;
/*     */   protected String local;
/*     */   protected String stub;
/*     */   protected MonitorConfig monitor;
/*     */   protected String proxy;
/*     */   protected String cluster;
/*     */   protected String filter;
/*     */   protected String listener;
/*     */   protected String owner;
/*     */   protected Integer connections;
/*     */   protected String layer;
/*     */   protected ApplicationConfig application;
/*     */   protected ModuleConfig module;
/*     */   protected List<RegistryConfig> registries;
/*     */   private Integer callbacks;
/*     */   protected String onconnect;
/*     */   protected String ondisconnect;
/*     */   private String scope;
/*     */ 
/*     */   protected void checkRegistry()
/*     */   {
/* 106 */     if ((this.registries == null) || (this.registries.size() == 0)) {
/* 107 */       String address = ConfigUtils.getProperty("dubbo.registry.address");
/* 108 */       if ((address != null) && (address.length() > 0)) {
/* 109 */         this.registries = new ArrayList();
/* 110 */         String[] as = address.split("\\s*[|]+\\s*");
/* 111 */         for (String a : as) {
/* 112 */           RegistryConfig registryConfig = new RegistryConfig();
/* 113 */           registryConfig.setAddress(a);
/* 114 */           this.registries.add(registryConfig);
/*     */         }
/*     */       }
/*     */     }
/* 118 */     if ((this.registries == null) || (this.registries.size() == 0)) {
/* 119 */       throw new IllegalStateException((getClass().getSimpleName().startsWith("Reference") ? "No such any registry to refer service in consumer " : "No such any registry to export service in provider ") + NetUtils.getLocalHost() + " use dubbo version " + Version.getVersion() + ", Please add <dubbo:registry address=\"...\" /> to your spring config. If you want unregister, please set <dubbo:service registry=\"N/A\" />");
/*     */     }
/*     */ 
/* 127 */     for (RegistryConfig registryConfig : this.registries)
/* 128 */       appendProperties(registryConfig);
/*     */   }
/*     */ 
/*     */   protected void checkApplication()
/*     */   {
/* 135 */     if (this.application == null) {
/* 136 */       String applicationName = ConfigUtils.getProperty("dubbo.application.name");
/* 137 */       if ((applicationName != null) && (applicationName.length() > 0)) {
/* 138 */         this.application = new ApplicationConfig();
/*     */       }
/*     */     }
/* 141 */     if (this.application == null) {
/* 142 */       throw new IllegalStateException("No such application config! Please add <dubbo:application name=\"...\" /> to your spring config.");
/*     */     }
/*     */ 
/* 145 */     appendProperties(this.application);
/*     */ 
/* 147 */     String wait = ConfigUtils.getProperty("dubbo.service.shutdown.wait");
/* 148 */     if ((wait != null) && (wait.trim().length() > 0)) {
/* 149 */       System.setProperty("dubbo.service.shutdown.wait", wait.trim());
/*     */     } else {
/* 151 */       wait = ConfigUtils.getProperty("dubbo.service.shutdown.wait.seconds");
/* 152 */       if ((wait != null) && (wait.trim().length() > 0))
/* 153 */         System.setProperty("dubbo.service.shutdown.wait.seconds", wait.trim());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<URL> loadRegistries(boolean provider)
/*     */   {
/* 159 */     checkRegistry();
/* 160 */     List registryList = new ArrayList();
/* 161 */     if ((this.registries != null) && (this.registries.size() > 0)) {
/* 162 */       for (RegistryConfig config : this.registries) {
/* 163 */         String address = config.getAddress();
/* 164 */         if ((address == null) || (address.length() == 0)) {
/* 165 */           address = "0.0.0.0";
/*     */         }
/* 167 */         String sysaddress = System.getProperty("dubbo.registry.address");
/* 168 */         if ((sysaddress != null) && (sysaddress.length() > 0)) {
/* 169 */           address = sysaddress;
/*     */         }
/* 171 */         if ((address != null) && (address.length() > 0) && (!"N/A".equalsIgnoreCase(address)))
/*     */         {
/* 173 */           Map map = new HashMap();
/* 174 */           appendParameters(map, this.application);
/* 175 */           appendParameters(map, config);
/* 176 */           map.put("path", RegistryService.class.getName());
/* 177 */           map.put("dubbo", Version.getVersion());
/* 178 */           map.put("timestamp", String.valueOf(System.currentTimeMillis()));
/* 179 */           if (ConfigUtils.getPid() > 0) {
/* 180 */             map.put("pid", String.valueOf(ConfigUtils.getPid()));
/*     */           }
/* 182 */           if (!map.containsKey("protocol")) {
/* 183 */             if (ExtensionLoader.getExtensionLoader(RegistryFactory.class).hasExtension("remote"))
/* 184 */               map.put("protocol", "remote");
/*     */             else {
/* 186 */               map.put("protocol", "dubbo");
/*     */             }
/*     */           }
/* 189 */           List urls = UrlUtils.parseURLs(address, map);
/* 190 */           for (URL url : urls) {
/* 191 */             url = url.addParameter("registry", url.getProtocol());
/* 192 */             url = url.setProtocol("registry");
/* 193 */             if (((provider) && (url.getParameter("register", true))) || ((!provider) && (url.getParameter("subscribe", true))))
/*     */             {
/* 195 */               registryList.add(url);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 201 */     return registryList;
/*     */   }
/*     */ 
/*     */   protected URL loadMonitor(URL registryURL) {
/* 205 */     if (this.monitor == null) {
/* 206 */       String monitorAddress = ConfigUtils.getProperty("dubbo.monitor.address");
/* 207 */       String monitorProtocol = ConfigUtils.getProperty("dubbo.monitor.protocol");
/* 208 */       if (((monitorAddress != null) && (monitorAddress.length() > 0)) || ((monitorProtocol != null) && (monitorProtocol.length() > 0)))
/*     */       {
/* 210 */         this.monitor = new MonitorConfig();
/*     */       }
/* 212 */       else return null;
/*     */     }
/*     */ 
/* 215 */     appendProperties(this.monitor);
/* 216 */     Map map = new HashMap();
/* 217 */     map.put("interface", MonitorService.class.getName());
/* 218 */     map.put("dubbo", Version.getVersion());
/* 219 */     map.put("timestamp", String.valueOf(System.currentTimeMillis()));
/* 220 */     if (ConfigUtils.getPid() > 0) {
/* 221 */       map.put("pid", String.valueOf(ConfigUtils.getPid()));
/*     */     }
/* 223 */     appendParameters(map, this.monitor);
/* 224 */     String address = this.monitor.getAddress();
/* 225 */     String sysaddress = System.getProperty("dubbo.monitor.address");
/* 226 */     if ((sysaddress != null) && (sysaddress.length() > 0)) {
/* 227 */       address = sysaddress;
/*     */     }
/* 229 */     if (ConfigUtils.isNotEmpty(address)) {
/* 230 */       if (!map.containsKey("protocol")) {
/* 231 */         if (ExtensionLoader.getExtensionLoader(MonitorFactory.class).hasExtension("logstat"))
/* 232 */           map.put("protocol", "logstat");
/*     */         else {
/* 234 */           map.put("protocol", "dubbo");
/*     */         }
/*     */       }
/* 237 */       return UrlUtils.parseURL(address, map);
/* 238 */     }if (("registry".equals(this.monitor.getProtocol())) && (registryURL != null)) {
/* 239 */       return registryURL.setProtocol("dubbo").addParameter("protocol", "registry").addParameterAndEncoded("refer", StringUtils.toQueryString(map));
/*     */     }
/* 241 */     return null;
/*     */   }
/*     */ 
/*     */   protected void checkInterfaceAndMethods(Class<?> interfaceClass, List<MethodConfig> methods)
/*     */   {
/* 246 */     if (interfaceClass == null) {
/* 247 */       throw new IllegalStateException("interface not allow null!");
/*     */     }
/*     */ 
/* 250 */     if (!interfaceClass.isInterface()) {
/* 251 */       throw new IllegalStateException("The interface class " + interfaceClass + " is not a interface!");
/*     */     }
/*     */ 
/* 254 */     if ((methods != null) && (methods.size() > 0))
/* 255 */       for (MethodConfig methodBean : methods) {
/* 256 */         String methodName = methodBean.getName();
/* 257 */         if ((methodName == null) || (methodName.length() == 0)) {
/* 258 */           throw new IllegalStateException("<dubbo:method> name attribute is required! Please check: <dubbo:service interface=\"" + interfaceClass.getName() + "\" ... ><dubbo:method name=\"\" ... /></<dubbo:reference>");
/*     */         }
/* 260 */         boolean hasMethod = false;
/* 261 */         for (Method method : interfaceClass.getMethods()) {
/* 262 */           if (method.getName().equals(methodName)) {
/* 263 */             hasMethod = true;
/* 264 */             break;
/*     */           }
/*     */         }
/* 267 */         if (!hasMethod)
/* 268 */           throw new IllegalStateException("The interface " + interfaceClass.getName() + " not found method " + methodName);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void checkStubAndMock(Class<?> interfaceClass)
/*     */   {
/* 276 */     if (ConfigUtils.isNotEmpty(this.local)) {
/* 277 */       Class localClass = ConfigUtils.isDefault(this.local) ? ReflectUtils.forName(interfaceClass.getName() + "Local") : ReflectUtils.forName(this.local);
/* 278 */       if (!interfaceClass.isAssignableFrom(localClass))
/* 279 */         throw new IllegalStateException("The local implemention class " + localClass.getName() + " not implement interface " + interfaceClass.getName());
/*     */       try
/*     */       {
/* 282 */         ReflectUtils.findConstructor(localClass, interfaceClass);
/*     */       } catch (NoSuchMethodException e) {
/* 284 */         throw new IllegalStateException("No such constructor \"public " + localClass.getSimpleName() + "(" + interfaceClass.getName() + ")\" in local implemention class " + localClass.getName());
/*     */       }
/*     */     }
/* 287 */     if (ConfigUtils.isNotEmpty(this.stub)) {
/* 288 */       Class localClass = ConfigUtils.isDefault(this.stub) ? ReflectUtils.forName(interfaceClass.getName() + "Stub") : ReflectUtils.forName(this.stub);
/* 289 */       if (!interfaceClass.isAssignableFrom(localClass))
/* 290 */         throw new IllegalStateException("The local implemention class " + localClass.getName() + " not implement interface " + interfaceClass.getName());
/*     */       try
/*     */       {
/* 293 */         ReflectUtils.findConstructor(localClass, interfaceClass);
/*     */       } catch (NoSuchMethodException e) {
/* 295 */         throw new IllegalStateException("No such constructor \"public " + localClass.getSimpleName() + "(" + interfaceClass.getName() + ")\" in local implemention class " + localClass.getName());
/*     */       }
/*     */     }
/* 298 */     if (ConfigUtils.isNotEmpty(this.mock))
/* 299 */       if (this.mock.startsWith("return ")) {
/* 300 */         String value = this.mock.substring("return ".length());
/*     */         try {
/* 302 */           MockInvoker.parseMockValue(value);
/*     */         } catch (Exception e) {
/* 304 */           throw new IllegalStateException("Illegal mock json value in <dubbo:service ... mock=\"" + this.mock + "\" />");
/*     */         }
/*     */       } else {
/* 307 */         Class mockClass = ConfigUtils.isDefault(this.mock) ? ReflectUtils.forName(interfaceClass.getName() + "Mock") : ReflectUtils.forName(this.mock);
/* 308 */         if (!interfaceClass.isAssignableFrom(mockClass))
/* 309 */           throw new IllegalStateException("The mock implemention class " + mockClass.getName() + " not implement interface " + interfaceClass.getName());
/*     */         try
/*     */         {
/* 312 */           mockClass.getConstructor(new Class[0]);
/*     */         } catch (NoSuchMethodException e) {
/* 314 */           throw new IllegalStateException("No such empty constructor \"public " + mockClass.getSimpleName() + "()\" in mock implemention class " + mockClass.getName());
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public String getLocal()
/*     */   {
/* 326 */     return this.local;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setLocal(String local)
/*     */   {
/* 335 */     checkName("local", local);
/* 336 */     this.local = local;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setLocal(Boolean local)
/*     */   {
/* 345 */     if (local == null)
/* 346 */       setLocal((String)null);
/*     */     else
/* 348 */       setLocal(String.valueOf(local));
/*     */   }
/*     */ 
/*     */   public String getStub()
/*     */   {
/* 353 */     return this.stub;
/*     */   }
/*     */ 
/*     */   public void setStub(String stub) {
/* 357 */     checkName("stub", stub);
/* 358 */     this.stub = stub;
/*     */   }
/*     */ 
/*     */   public void setStub(Boolean stub) {
/* 362 */     if (this.local == null)
/* 363 */       setStub((String)null);
/*     */     else
/* 365 */       setStub(String.valueOf(stub));
/*     */   }
/*     */ 
/*     */   public String getCluster()
/*     */   {
/* 370 */     return this.cluster;
/*     */   }
/*     */ 
/*     */   public void setCluster(String cluster) {
/* 374 */     checkExtension(Cluster.class, "cluster", cluster);
/* 375 */     this.cluster = cluster;
/*     */   }
/*     */ 
/*     */   public String getProxy() {
/* 379 */     return this.proxy;
/*     */   }
/*     */ 
/*     */   public void setProxy(String proxy) {
/* 383 */     checkExtension(ProxyFactory.class, "proxy", proxy);
/* 384 */     this.proxy = proxy;
/*     */   }
/*     */ 
/*     */   public Integer getConnections() {
/* 388 */     return this.connections;
/*     */   }
/*     */ 
/*     */   public void setConnections(Integer connections) {
/* 392 */     this.connections = connections;
/*     */   }
/*     */ 
/*     */   @Parameter(key="reference.filter", append=true)
/*     */   public String getFilter() {
/* 397 */     return this.filter;
/*     */   }
/*     */ 
/*     */   public void setFilter(String filter) {
/* 401 */     checkMultiExtension(Filter.class, "filter", filter);
/* 402 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */   @Parameter(key="invoker.listener", append=true)
/*     */   public String getListener() {
/* 407 */     checkMultiExtension(InvokerListener.class, "listener", this.listener);
/* 408 */     return this.listener;
/*     */   }
/*     */ 
/*     */   public void setListener(String listener) {
/* 412 */     this.listener = listener;
/*     */   }
/*     */ 
/*     */   public String getLayer() {
/* 416 */     return this.layer;
/*     */   }
/*     */ 
/*     */   public void setLayer(String layer) {
/* 420 */     checkNameHasSymbol("layer", layer);
/* 421 */     this.layer = layer;
/*     */   }
/*     */ 
/*     */   public ApplicationConfig getApplication() {
/* 425 */     return this.application;
/*     */   }
/*     */ 
/*     */   public void setApplication(ApplicationConfig application) {
/* 429 */     this.application = application;
/*     */   }
/*     */ 
/*     */   public ModuleConfig getModule() {
/* 433 */     return this.module;
/*     */   }
/*     */ 
/*     */   public void setModule(ModuleConfig module) {
/* 437 */     this.module = module;
/*     */   }
/*     */ 
/*     */   public RegistryConfig getRegistry() {
/* 441 */     return (this.registries == null) || (this.registries.size() == 0) ? null : (RegistryConfig)this.registries.get(0);
/*     */   }
/*     */ 
/*     */   public void setRegistry(RegistryConfig registry) {
/* 445 */     List registries = new ArrayList(1);
/* 446 */     registries.add(registry);
/* 447 */     this.registries = registries;
/*     */   }
/*     */ 
/*     */   public List<RegistryConfig> getRegistries() {
/* 451 */     return this.registries;
/*     */   }
/*     */ 
/*     */   public void setRegistries(List<? extends RegistryConfig> registries)
/*     */   {
/* 456 */     this.registries = registries;
/*     */   }
/*     */ 
/*     */   public MonitorConfig getMonitor() {
/* 460 */     return this.monitor;
/*     */   }
/*     */ 
/*     */   public void setMonitor(MonitorConfig monitor) {
/* 464 */     this.monitor = monitor;
/*     */   }
/*     */ 
/*     */   public void setMonitor(String monitor) {
/* 468 */     this.monitor = new MonitorConfig(monitor);
/*     */   }
/*     */ 
/*     */   public String getOwner() {
/* 472 */     return this.owner;
/*     */   }
/*     */ 
/*     */   public void setOwner(String owner) {
/* 476 */     checkMultiName("owner", owner);
/* 477 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */   public void setCallbacks(Integer callbacks) {
/* 481 */     this.callbacks = callbacks;
/*     */   }
/*     */ 
/*     */   public Integer getCallbacks() {
/* 485 */     return this.callbacks;
/*     */   }
/*     */ 
/*     */   public String getOnconnect() {
/* 489 */     return this.onconnect;
/*     */   }
/*     */ 
/*     */   public void setOnconnect(String onconnect) {
/* 493 */     this.onconnect = onconnect;
/*     */   }
/*     */ 
/*     */   public String getOndisconnect() {
/* 497 */     return this.ondisconnect;
/*     */   }
/*     */ 
/*     */   public void setOndisconnect(String ondisconnect) {
/* 501 */     this.ondisconnect = ondisconnect;
/*     */   }
/*     */ 
/*     */   public String getScope() {
/* 505 */     return this.scope;
/*     */   }
/*     */ 
/*     */   public void setScope(String scope) {
/* 509 */     this.scope = scope;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.AbstractInterfaceConfig
 * JD-Core Version:    0.6.2
 */