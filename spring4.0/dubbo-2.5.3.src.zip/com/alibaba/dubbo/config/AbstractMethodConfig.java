/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.rpc.cluster.LoadBalance;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class AbstractMethodConfig extends AbstractConfig
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected Integer timeout;
/*     */   protected Integer retries;
/*     */   protected Integer actives;
/*     */   protected String loadbalance;
/*     */   protected Boolean async;
/*     */   protected Boolean sent;
/*     */   protected String mock;
/*     */   protected String merger;
/*     */   protected String cache;
/*     */   protected String validation;
/*     */   protected Map<String, String> parameters;
/*     */ 
/*     */   public Integer getTimeout()
/*     */   {
/*  68 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void setTimeout(Integer timeout) {
/*  72 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public Integer getRetries() {
/*  76 */     return this.retries;
/*     */   }
/*     */ 
/*     */   public void setRetries(Integer retries) {
/*  80 */     this.retries = retries;
/*     */   }
/*     */ 
/*     */   public String getLoadbalance() {
/*  84 */     return this.loadbalance;
/*     */   }
/*     */ 
/*     */   public void setLoadbalance(String loadbalance) {
/*  88 */     checkExtension(LoadBalance.class, "loadbalance", loadbalance);
/*  89 */     this.loadbalance = loadbalance;
/*     */   }
/*     */ 
/*     */   public Boolean isAsync() {
/*  93 */     return this.async;
/*     */   }
/*     */ 
/*     */   public void setAsync(Boolean async) {
/*  97 */     this.async = async;
/*     */   }
/*     */ 
/*     */   public Integer getActives() {
/* 101 */     return this.actives;
/*     */   }
/*     */ 
/*     */   public void setActives(Integer actives) {
/* 105 */     this.actives = actives;
/*     */   }
/*     */ 
/*     */   public Boolean getSent() {
/* 109 */     return this.sent;
/*     */   }
/*     */ 
/*     */   public void setSent(Boolean sent) {
/* 113 */     this.sent = sent;
/*     */   }
/*     */ 
/*     */   @Parameter(escaped=true)
/*     */   public String getMock() {
/* 118 */     return this.mock;
/*     */   }
/*     */ 
/*     */   public void setMock(String mock) {
/* 122 */     if ((mock != null) && (mock.startsWith("return ")))
/* 123 */       checkLength("mock", mock);
/*     */     else {
/* 125 */       checkName("mock", mock);
/*     */     }
/* 127 */     this.mock = mock;
/*     */   }
/*     */ 
/*     */   public void setMock(Boolean mock) {
/* 131 */     if (mock == null)
/* 132 */       setMock((String)null);
/*     */     else
/* 134 */       setMock(String.valueOf(mock));
/*     */   }
/*     */ 
/*     */   public String getMerger()
/*     */   {
/* 139 */     return this.merger;
/*     */   }
/*     */ 
/*     */   public void setMerger(String merger) {
/* 143 */     this.merger = merger;
/*     */   }
/*     */ 
/*     */   public String getCache() {
/* 147 */     return this.cache;
/*     */   }
/*     */ 
/*     */   public void setCache(String cache) {
/* 151 */     this.cache = cache;
/*     */   }
/*     */ 
/*     */   public String getValidation() {
/* 155 */     return this.validation;
/*     */   }
/*     */ 
/*     */   public void setValidation(String validation) {
/* 159 */     this.validation = validation;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParameters() {
/* 163 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public void setParameters(Map<String, String> parameters) {
/* 167 */     checkParameterName(parameters);
/* 168 */     this.parameters = parameters;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.AbstractMethodConfig
 * JD-Core Version:    0.6.2
 */