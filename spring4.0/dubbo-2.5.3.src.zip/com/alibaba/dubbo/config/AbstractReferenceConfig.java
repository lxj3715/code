/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.rpc.InvokerListener;
/*     */ import com.alibaba.dubbo.rpc.support.ProtocolUtils;
/*     */ 
/*     */ public abstract class AbstractReferenceConfig extends AbstractInterfaceConfig
/*     */ {
/*     */   private static final long serialVersionUID = -2786526984373031126L;
/*     */   protected Boolean check;
/*     */   protected Boolean init;
/*     */   protected String generic;
/*     */   protected Boolean injvm;
/*     */   protected Boolean lazy;
/*     */   protected String reconnect;
/*     */   protected Boolean sticky;
/*     */   protected Boolean stubevent;
/*     */   protected String version;
/*     */   protected String group;
/*     */ 
/*     */   public Boolean isCheck()
/*     */   {
/*  66 */     return this.check;
/*     */   }
/*     */ 
/*     */   public void setCheck(Boolean check) {
/*  70 */     this.check = check;
/*     */   }
/*     */ 
/*     */   public Boolean isInit() {
/*  74 */     return this.init;
/*     */   }
/*     */ 
/*     */   public void setInit(Boolean init) {
/*  78 */     this.init = init;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public Boolean isGeneric() {
/*  83 */     return Boolean.valueOf(ProtocolUtils.isGeneric(this.generic));
/*     */   }
/*     */ 
/*     */   public void setGeneric(Boolean generic) {
/*  87 */     if (generic != null)
/*  88 */       this.generic = generic.toString();
/*     */   }
/*     */ 
/*     */   public void setGeneric(String generic)
/*     */   {
/*  93 */     this.generic = generic;
/*     */   }
/*     */ 
/*     */   public String getGeneric() {
/*  97 */     return this.generic;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Boolean isInjvm()
/*     */   {
/* 106 */     return this.injvm;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setInjvm(Boolean injvm)
/*     */   {
/* 115 */     this.injvm = injvm;
/*     */   }
/*     */ 
/*     */   @Parameter(key="reference.filter", append=true)
/*     */   public String getFilter() {
/* 120 */     return super.getFilter();
/*     */   }
/*     */ 
/*     */   @Parameter(key="invoker.listener", append=true)
/*     */   public String getListener() {
/* 125 */     return super.getListener();
/*     */   }
/*     */ 
/*     */   public void setListener(String listener)
/*     */   {
/* 130 */     checkMultiExtension(InvokerListener.class, "listener", listener);
/* 131 */     super.setListener(listener);
/*     */   }
/*     */ 
/*     */   @Parameter(key="lazy")
/*     */   public Boolean getLazy() {
/* 136 */     return this.lazy;
/*     */   }
/*     */ 
/*     */   public void setLazy(Boolean lazy) {
/* 140 */     this.lazy = lazy;
/*     */   }
/*     */ 
/*     */   public void setOnconnect(String onconnect)
/*     */   {
/* 145 */     if ((onconnect != null) && (onconnect.length() > 0)) {
/* 146 */       this.stubevent = Boolean.valueOf(true);
/*     */     }
/* 148 */     super.setOnconnect(onconnect);
/*     */   }
/*     */ 
/*     */   public void setOndisconnect(String ondisconnect)
/*     */   {
/* 153 */     if ((ondisconnect != null) && (ondisconnect.length() > 0)) {
/* 154 */       this.stubevent = Boolean.valueOf(true);
/*     */     }
/* 156 */     super.setOndisconnect(ondisconnect);
/*     */   }
/*     */ 
/*     */   @Parameter(key="dubbo.stub.event")
/*     */   public Boolean getStubevent() {
/* 161 */     return this.stubevent;
/*     */   }
/*     */ 
/*     */   @Parameter(key="reconnect")
/*     */   public String getReconnect() {
/* 166 */     return this.reconnect;
/*     */   }
/*     */ 
/*     */   public void setReconnect(String reconnect) {
/* 170 */     this.reconnect = reconnect;
/*     */   }
/*     */ 
/*     */   @Parameter(key="sticky")
/*     */   public Boolean getSticky() {
/* 175 */     return this.sticky;
/*     */   }
/*     */ 
/*     */   public void setSticky(Boolean sticky) {
/* 179 */     this.sticky = sticky;
/*     */   }
/*     */ 
/*     */   public String getVersion() {
/* 183 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String version) {
/* 187 */     checkKey("version", version);
/* 188 */     this.version = version;
/*     */   }
/*     */ 
/*     */   public String getGroup() {
/* 192 */     return this.group;
/*     */   }
/*     */ 
/*     */   public void setGroup(String group) {
/* 196 */     checkKey("group", group);
/* 197 */     this.group = group;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.AbstractReferenceConfig
 * JD-Core Version:    0.6.2
 */