/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.rpc.ExporterListener;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class AbstractServiceConfig extends AbstractInterfaceConfig
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected String version;
/*     */   protected String group;
/*     */   protected Boolean deprecated;
/*     */   protected Integer delay;
/*     */   protected Boolean export;
/*     */   protected Integer weight;
/*     */   protected String document;
/*     */   protected Boolean dynamic;
/*     */   protected String token;
/*     */   protected String accesslog;
/*     */   private Integer executes;
/*     */   protected List<ProtocolConfig> protocols;
/*     */   private Boolean register;
/*     */ 
/*     */   public String getVersion()
/*     */   {
/*  74 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String version) {
/*  78 */     checkKey("version", version);
/*  79 */     this.version = version;
/*     */   }
/*     */ 
/*     */   public String getGroup() {
/*  83 */     return this.group;
/*     */   }
/*     */ 
/*     */   public void setGroup(String group) {
/*  87 */     checkKey("group", group);
/*  88 */     this.group = group;
/*     */   }
/*     */ 
/*     */   public Integer getDelay() {
/*  92 */     return this.delay;
/*     */   }
/*     */ 
/*     */   public void setDelay(Integer delay) {
/*  96 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public Boolean getExport() {
/* 100 */     return this.export;
/*     */   }
/*     */ 
/*     */   public void setExport(Boolean export) {
/* 104 */     this.export = export;
/*     */   }
/*     */ 
/*     */   public Integer getWeight() {
/* 108 */     return this.weight;
/*     */   }
/*     */ 
/*     */   public void setWeight(Integer weight) {
/* 112 */     this.weight = weight;
/*     */   }
/*     */ 
/*     */   @Parameter(escaped=true)
/*     */   public String getDocument() {
/* 117 */     return this.document;
/*     */   }
/*     */ 
/*     */   public void setDocument(String document) {
/* 121 */     this.document = document;
/*     */   }
/*     */ 
/*     */   public String getToken() {
/* 125 */     return this.token;
/*     */   }
/*     */ 
/*     */   public void setToken(String token) {
/* 129 */     checkName("token", token);
/* 130 */     this.token = token;
/*     */   }
/*     */ 
/*     */   public void setToken(Boolean token) {
/* 134 */     if (token == null)
/* 135 */       setToken((String)null);
/*     */     else
/* 137 */       setToken(String.valueOf(token));
/*     */   }
/*     */ 
/*     */   public Boolean isDeprecated()
/*     */   {
/* 142 */     return this.deprecated;
/*     */   }
/*     */ 
/*     */   public void setDeprecated(Boolean deprecated) {
/* 146 */     this.deprecated = deprecated;
/*     */   }
/*     */ 
/*     */   public Boolean isDynamic() {
/* 150 */     return this.dynamic;
/*     */   }
/*     */ 
/*     */   public void setDynamic(Boolean dynamic) {
/* 154 */     this.dynamic = dynamic;
/*     */   }
/*     */ 
/*     */   public List<ProtocolConfig> getProtocols() {
/* 158 */     return this.protocols;
/*     */   }
/*     */ 
/*     */   public void setProtocols(List<? extends ProtocolConfig> protocols)
/*     */   {
/* 163 */     this.protocols = protocols;
/*     */   }
/*     */ 
/*     */   public ProtocolConfig getProtocol() {
/* 167 */     return (this.protocols == null) || (this.protocols.size() == 0) ? null : (ProtocolConfig)this.protocols.get(0);
/*     */   }
/*     */ 
/*     */   public void setProtocol(ProtocolConfig protocol) {
/* 171 */     this.protocols = Arrays.asList(new ProtocolConfig[] { protocol });
/*     */   }
/*     */ 
/*     */   public String getAccesslog() {
/* 175 */     return this.accesslog;
/*     */   }
/*     */ 
/*     */   public void setAccesslog(String accesslog) {
/* 179 */     this.accesslog = accesslog;
/*     */   }
/*     */ 
/*     */   public void setAccesslog(Boolean accesslog) {
/* 183 */     if (accesslog == null)
/* 184 */       setAccesslog((String)null);
/*     */     else
/* 186 */       setAccesslog(String.valueOf(accesslog));
/*     */   }
/*     */ 
/*     */   public Integer getExecutes()
/*     */   {
/* 191 */     return this.executes;
/*     */   }
/*     */ 
/*     */   public void setExecutes(Integer executes) {
/* 195 */     this.executes = executes;
/*     */   }
/*     */ 
/*     */   @Parameter(key="service.filter", append=true)
/*     */   public String getFilter() {
/* 200 */     return super.getFilter();
/*     */   }
/*     */ 
/*     */   @Parameter(key="exporter.listener", append=true)
/*     */   public String getListener() {
/* 205 */     return super.getListener();
/*     */   }
/*     */ 
/*     */   public void setListener(String listener)
/*     */   {
/* 210 */     checkMultiExtension(ExporterListener.class, "listener", listener);
/* 211 */     super.setListener(listener);
/*     */   }
/*     */ 
/*     */   public Boolean isRegister() {
/* 215 */     return this.register;
/*     */   }
/*     */ 
/*     */   public void setRegister(Boolean register) {
/* 219 */     this.register = register;
/* 220 */     if (Boolean.FALSE.equals(register))
/* 221 */       setRegistry(new RegistryConfig("N/A"));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.AbstractServiceConfig
 * JD-Core Version:    0.6.2
 */