/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.common.compiler.support.AdaptiveCompiler;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ApplicationConfig extends AbstractConfig
/*     */ {
/*     */   private static final long serialVersionUID = 5508512956753757169L;
/*     */   private String name;
/*     */   private String version;
/*     */   private String owner;
/*     */   private String organization;
/*     */   private String architecture;
/*     */   private String environment;
/*     */   private String compiler;
/*     */   private String logger;
/*     */   private List<RegistryConfig> registries;
/*     */   private MonitorConfig monitor;
/*     */   private Boolean isDefault;
/*     */ 
/*     */   public ApplicationConfig()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ApplicationConfig(String name)
/*     */   {
/*  74 */     setName(name);
/*     */   }
/*     */ 
/*     */   @Parameter(key="application", required=true)
/*     */   public String getName() {
/*  79 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  83 */     checkName("name", name);
/*  84 */     this.name = name;
/*  85 */     if ((this.id == null) || (this.id.length() == 0))
/*  86 */       this.id = name;
/*     */   }
/*     */ 
/*     */   @Parameter(key="application.version")
/*     */   public String getVersion()
/*     */   {
/*  92 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String version) {
/*  96 */     this.version = version;
/*     */   }
/*     */ 
/*     */   public String getOwner() {
/* 100 */     return this.owner;
/*     */   }
/*     */ 
/*     */   public void setOwner(String owner) {
/* 104 */     checkMultiName("owner", owner);
/* 105 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */   public String getOrganization() {
/* 109 */     return this.organization;
/*     */   }
/*     */ 
/*     */   public void setOrganization(String organization) {
/* 113 */     checkName("organization", organization);
/* 114 */     this.organization = organization;
/*     */   }
/*     */ 
/*     */   public String getArchitecture() {
/* 118 */     return this.architecture;
/*     */   }
/*     */ 
/*     */   public void setArchitecture(String architecture) {
/* 122 */     checkName("architecture", architecture);
/* 123 */     this.architecture = architecture;
/*     */   }
/*     */ 
/*     */   public String getEnvironment() {
/* 127 */     return this.environment;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(String environment) {
/* 131 */     checkName("environment", environment);
/* 132 */     if ((environment != null) && 
/* 133 */       (!"develop".equals(environment)) && (!"test".equals(environment)) && (!"product".equals(environment))) {
/* 134 */       throw new IllegalStateException("Unsupported environment: " + environment + ", only support develop/test/product, default is product.");
/*     */     }
/*     */ 
/* 137 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public RegistryConfig getRegistry() {
/* 141 */     return (this.registries == null) || (this.registries.size() == 0) ? null : (RegistryConfig)this.registries.get(0);
/*     */   }
/*     */ 
/*     */   public void setRegistry(RegistryConfig registry) {
/* 145 */     List registries = new ArrayList(1);
/* 146 */     registries.add(registry);
/* 147 */     this.registries = registries;
/*     */   }
/*     */ 
/*     */   public List<RegistryConfig> getRegistries() {
/* 151 */     return this.registries;
/*     */   }
/*     */ 
/*     */   public void setRegistries(List<? extends RegistryConfig> registries)
/*     */   {
/* 156 */     this.registries = registries;
/*     */   }
/*     */ 
/*     */   public MonitorConfig getMonitor() {
/* 160 */     return this.monitor;
/*     */   }
/*     */ 
/*     */   public void setMonitor(MonitorConfig monitor) {
/* 164 */     this.monitor = monitor;
/*     */   }
/*     */ 
/*     */   public void setMonitor(String monitor) {
/* 168 */     this.monitor = new MonitorConfig(monitor);
/*     */   }
/*     */ 
/*     */   public String getCompiler() {
/* 172 */     return this.compiler;
/*     */   }
/*     */ 
/*     */   public void setCompiler(String compiler) {
/* 176 */     this.compiler = compiler;
/* 177 */     AdaptiveCompiler.setDefaultCompiler(compiler);
/*     */   }
/*     */ 
/*     */   public String getLogger() {
/* 181 */     return this.logger;
/*     */   }
/*     */ 
/*     */   public void setLogger(String logger) {
/* 185 */     this.logger = logger;
/* 186 */     LoggerFactory.setLoggerAdapter(logger);
/*     */   }
/*     */ 
/*     */   public Boolean isDefault() {
/* 190 */     return this.isDefault;
/*     */   }
/*     */ 
/*     */   public void setDefault(Boolean isDefault) {
/* 194 */     this.isDefault = isDefault;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.ApplicationConfig
 * JD-Core Version:    0.6.2
 */