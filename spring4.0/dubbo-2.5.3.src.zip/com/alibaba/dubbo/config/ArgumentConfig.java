/*    */ package com.alibaba.dubbo.config;
/*    */ 
/*    */ import com.alibaba.dubbo.config.support.Parameter;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class ArgumentConfig
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -2165482463925213595L;
/* 31 */   private Integer index = Integer.valueOf(-1);
/*    */   private String type;
/*    */   private Boolean callback;
/*    */ 
/*    */   public void setIndex(Integer index)
/*    */   {
/* 40 */     this.index = index;
/*    */   }
/*    */   @Parameter(excluded=true)
/*    */   public Integer getIndex() {
/* 44 */     return this.index;
/*    */   }
/*    */   @Parameter(excluded=true)
/*    */   public String getType() {
/* 48 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 52 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void setCallback(Boolean callback) {
/* 56 */     this.callback = callback;
/*    */   }
/*    */ 
/*    */   public Boolean isCallback() {
/* 60 */     return this.callback;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.ArgumentConfig
 * JD-Core Version:    0.6.2
 */