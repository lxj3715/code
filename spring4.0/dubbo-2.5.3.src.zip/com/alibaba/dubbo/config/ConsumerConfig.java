/*    */ package com.alibaba.dubbo.config;
/*    */ 
/*    */ public class ConsumerConfig extends AbstractReferenceConfig
/*    */ {
/*    */   private static final long serialVersionUID = 2827274711143680600L;
/*    */   private Boolean isDefault;
/*    */ 
/*    */   public void setTimeout(Integer timeout)
/*    */   {
/* 33 */     super.setTimeout(timeout);
/* 34 */     String rmiTimeout = System.getProperty("sun.rmi.transport.tcp.responseTimeout");
/* 35 */     if ((timeout != null) && (timeout.intValue() > 0) && ((rmiTimeout == null) || (rmiTimeout.length() == 0)))
/*    */     {
/* 37 */       System.setProperty("sun.rmi.transport.tcp.responseTimeout", String.valueOf(timeout));
/*    */     }
/*    */   }
/*    */ 
/*    */   public Boolean isDefault() {
/* 42 */     return this.isDefault;
/*    */   }
/*    */ 
/*    */   public void setDefault(Boolean isDefault) {
/* 46 */     this.isDefault = isDefault;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.ConsumerConfig
 * JD-Core Version:    0.6.2
 */