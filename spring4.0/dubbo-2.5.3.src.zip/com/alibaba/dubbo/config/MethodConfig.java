/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import java.util.List;
/*     */ 
/*     */ public class MethodConfig extends AbstractMethodConfig
/*     */ {
/*     */   private static final long serialVersionUID = 884908855422675941L;
/*     */   private String name;
/*     */   private Integer stat;
/*     */   private Boolean retry;
/*     */   private Boolean reliable;
/*     */   private Integer executes;
/*     */   private Boolean deprecated;
/*     */   private Boolean sticky;
/*     */   private Boolean isReturn;
/*     */   private Object oninvoke;
/*     */   private String oninvokeMethod;
/*     */   private Object onreturn;
/*     */   private String onreturnMethod;
/*     */   private Object onthrow;
/*     */   private String onthrowMethod;
/*     */   private List<ArgumentConfig> arguments;
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getName()
/*     */   {
/*  79 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  83 */     checkMethodName("name", name);
/*  84 */     this.name = name;
/*  85 */     if ((this.id == null) || (this.id.length() == 0))
/*  86 */       this.id = name;
/*     */   }
/*     */ 
/*     */   public Integer getStat()
/*     */   {
/*  91 */     return this.stat;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setStat(Integer stat) {
/*  96 */     this.stat = stat;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Boolean isRetry() {
/* 101 */     return this.retry;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setRetry(Boolean retry) {
/* 106 */     this.retry = retry;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Boolean isReliable() {
/* 111 */     return this.reliable;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setReliable(Boolean reliable) {
/* 116 */     this.reliable = reliable;
/*     */   }
/*     */ 
/*     */   public Integer getExecutes() {
/* 120 */     return this.executes;
/*     */   }
/*     */ 
/*     */   public void setExecutes(Integer executes) {
/* 124 */     this.executes = executes;
/*     */   }
/*     */ 
/*     */   public Boolean getDeprecated() {
/* 128 */     return this.deprecated;
/*     */   }
/*     */ 
/*     */   public void setDeprecated(Boolean deprecated) {
/* 132 */     this.deprecated = deprecated;
/*     */   }
/*     */ 
/*     */   public void setArguments(List<? extends ArgumentConfig> arguments)
/*     */   {
/* 137 */     this.arguments = arguments;
/*     */   }
/*     */ 
/*     */   public List<ArgumentConfig> getArguments() {
/* 141 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   public Boolean getSticky() {
/* 145 */     return this.sticky;
/*     */   }
/*     */ 
/*     */   public void setSticky(Boolean sticky) {
/* 149 */     this.sticky = sticky;
/*     */   }
/*     */ 
/*     */   @Parameter(key="onreturn.instance", excluded=true, attribute=true)
/*     */   public Object getOnreturn() {
/* 154 */     return this.onreturn;
/*     */   }
/*     */ 
/*     */   public void setOnreturn(Object onreturn) {
/* 158 */     this.onreturn = onreturn;
/*     */   }
/*     */ 
/*     */   @Parameter(key="onreturn.method", excluded=true, attribute=true)
/*     */   public String getOnreturnMethod() {
/* 163 */     return this.onreturnMethod;
/*     */   }
/*     */ 
/*     */   public void setOnreturnMethod(String onreturnMethod) {
/* 167 */     this.onreturnMethod = onreturnMethod;
/*     */   }
/*     */ 
/*     */   @Parameter(key="onthrow.instance", excluded=true, attribute=true)
/*     */   public Object getOnthrow() {
/* 172 */     return this.onthrow;
/*     */   }
/*     */ 
/*     */   public void setOnthrow(Object onthrow) {
/* 176 */     this.onthrow = onthrow;
/*     */   }
/*     */ 
/*     */   @Parameter(key="onthrow.method", excluded=true, attribute=true)
/*     */   public String getOnthrowMethod() {
/* 181 */     return this.onthrowMethod;
/*     */   }
/*     */ 
/*     */   public void setOnthrowMethod(String onthrowMethod) {
/* 185 */     this.onthrowMethod = onthrowMethod;
/*     */   }
/*     */ 
/*     */   @Parameter(key="oninvoke.instance", excluded=true, attribute=true)
/*     */   public Object getOninvoke() {
/* 190 */     return this.oninvoke;
/*     */   }
/*     */ 
/*     */   public void setOninvoke(Object oninvoke) {
/* 194 */     this.oninvoke = oninvoke;
/*     */   }
/*     */ 
/*     */   @Parameter(key="oninvoke.method", excluded=true, attribute=true)
/*     */   public String getOninvokeMethod() {
/* 199 */     return this.oninvokeMethod;
/*     */   }
/*     */ 
/*     */   public void setOninvokeMethod(String oninvokeMethod) {
/* 203 */     this.oninvokeMethod = oninvokeMethod;
/*     */   }
/*     */ 
/*     */   public Boolean isReturn() {
/* 207 */     return this.isReturn;
/*     */   }
/*     */ 
/*     */   public void setReturn(Boolean isReturn) {
/* 211 */     this.isReturn = isReturn;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.MethodConfig
 * JD-Core Version:    0.6.2
 */