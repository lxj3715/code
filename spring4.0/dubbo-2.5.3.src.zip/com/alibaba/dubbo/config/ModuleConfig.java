/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ModuleConfig extends AbstractConfig
/*     */ {
/*     */   private static final long serialVersionUID = 5508512956753757169L;
/*     */   private String name;
/*     */   private String version;
/*     */   private String owner;
/*     */   private String organization;
/*     */   private List<RegistryConfig> registries;
/*     */   private MonitorConfig monitor;
/*     */   private Boolean isDefault;
/*     */ 
/*     */   public ModuleConfig()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ModuleConfig(String name)
/*     */   {
/*  58 */     setName(name);
/*     */   }
/*     */ 
/*     */   @Parameter(key="module", required=true)
/*     */   public String getName() {
/*  63 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  67 */     checkName("name", name);
/*  68 */     this.name = name;
/*  69 */     if ((this.id == null) || (this.id.length() == 0))
/*  70 */       this.id = name;
/*     */   }
/*     */ 
/*     */   @Parameter(key="module.version")
/*     */   public String getVersion()
/*     */   {
/*  76 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String version) {
/*  80 */     this.version = version;
/*     */   }
/*     */ 
/*     */   public String getOwner() {
/*  84 */     return this.owner;
/*     */   }
/*     */ 
/*     */   public void setOwner(String owner) {
/*  88 */     checkName("owner", owner);
/*  89 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */   public String getOrganization() {
/*  93 */     return this.organization;
/*     */   }
/*     */ 
/*     */   public void setOrganization(String organization) {
/*  97 */     checkName("organization", organization);
/*  98 */     this.organization = organization;
/*     */   }
/*     */ 
/*     */   public RegistryConfig getRegistry() {
/* 102 */     return (this.registries == null) || (this.registries.size() == 0) ? null : (RegistryConfig)this.registries.get(0);
/*     */   }
/*     */ 
/*     */   public void setRegistry(RegistryConfig registry) {
/* 106 */     List registries = new ArrayList(1);
/* 107 */     registries.add(registry);
/* 108 */     this.registries = registries;
/*     */   }
/*     */ 
/*     */   public List<RegistryConfig> getRegistries() {
/* 112 */     return this.registries;
/*     */   }
/*     */ 
/*     */   public void setRegistries(List<? extends RegistryConfig> registries)
/*     */   {
/* 117 */     this.registries = registries;
/*     */   }
/*     */ 
/*     */   public MonitorConfig getMonitor() {
/* 121 */     return this.monitor;
/*     */   }
/*     */ 
/*     */   public void setMonitor(MonitorConfig monitor) {
/* 125 */     this.monitor = monitor;
/*     */   }
/*     */ 
/*     */   public void setMonitor(String monitor) {
/* 129 */     this.monitor = new MonitorConfig(monitor);
/*     */   }
/*     */ 
/*     */   public Boolean isDefault() {
/* 133 */     return this.isDefault;
/*     */   }
/*     */ 
/*     */   public void setDefault(Boolean isDefault) {
/* 137 */     this.isDefault = isDefault;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.ModuleConfig
 * JD-Core Version:    0.6.2
 */