/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class MonitorConfig extends AbstractConfig
/*     */ {
/*     */   private static final long serialVersionUID = -1184681514659198203L;
/*     */   private String protocol;
/*     */   private String address;
/*     */   private String username;
/*     */   private String password;
/*     */   private String group;
/*     */   private String version;
/*     */   private Map<String, String> parameters;
/*     */   private Boolean isDefault;
/*     */ 
/*     */   public MonitorConfig()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MonitorConfig(String address)
/*     */   {
/*  54 */     this.address = address;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getAddress() {
/*  59 */     return this.address;
/*     */   }
/*     */ 
/*     */   public void setAddress(String address) {
/*  63 */     this.address = address;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getProtocol() {
/*  68 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public void setProtocol(String protocol) {
/*  72 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getUsername() {
/*  77 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username) {
/*  81 */     this.username = username;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getPassword() {
/*  86 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password) {
/*  90 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public String getGroup() {
/*  94 */     return this.group;
/*     */   }
/*     */ 
/*     */   public void setGroup(String group) {
/*  98 */     this.group = group;
/*     */   }
/*     */ 
/*     */   public String getVersion() {
/* 102 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String version) {
/* 106 */     this.version = version;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParameters() {
/* 110 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public void setParameters(Map<String, String> parameters) {
/* 114 */     checkParameterName(parameters);
/* 115 */     this.parameters = parameters;
/*     */   }
/*     */ 
/*     */   public Boolean isDefault() {
/* 119 */     return this.isDefault;
/*     */   }
/*     */ 
/*     */   public void setDefault(Boolean isDefault) {
/* 123 */     this.isDefault = isDefault;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.MonitorConfig
 * JD-Core Version:    0.6.2
 */