/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.serialize.Serialization;
/*     */ import com.alibaba.dubbo.common.status.StatusChecker;
/*     */ import com.alibaba.dubbo.common.threadpool.ThreadPool;
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.registry.support.AbstractRegistryFactory;
/*     */ import com.alibaba.dubbo.remoting.Codec;
/*     */ import com.alibaba.dubbo.remoting.Dispatcher;
/*     */ import com.alibaba.dubbo.remoting.Transporter;
/*     */ import com.alibaba.dubbo.remoting.exchange.Exchanger;
/*     */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*     */ import com.alibaba.dubbo.rpc.Protocol;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ProtocolConfig extends AbstractConfig
/*     */ {
/*     */   private static final long serialVersionUID = 6913423882496634749L;
/*     */   private String name;
/*     */   private String host;
/*     */   private Integer port;
/*     */   private String contextpath;
/*     */   private String threadpool;
/*     */   private Integer threads;
/*     */   private Integer iothreads;
/*     */   private Integer queues;
/*     */   private Integer accepts;
/*     */   private String codec;
/*     */   private String serialization;
/*     */   private String charset;
/*     */   private Integer payload;
/*     */   private Integer buffer;
/*     */   private Integer heartbeat;
/*     */   private String accesslog;
/*     */   private String transporter;
/*     */   private String exchanger;
/*     */   private String dispatcher;
/*     */   private String networker;
/*     */   private String server;
/*     */   private String client;
/*     */   private String telnet;
/*     */   private String prompt;
/*     */   private String status;
/*     */   private Boolean register;
/*     */   private Map<String, String> parameters;
/*     */   private Boolean isDefault;
/*     */ 
/*     */   public ProtocolConfig()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ProtocolConfig(String name)
/*     */   {
/* 131 */     setName(name);
/*     */   }
/*     */ 
/*     */   public ProtocolConfig(String name, int port) {
/* 135 */     setName(name);
/* 136 */     setPort(Integer.valueOf(port));
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getName() {
/* 141 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 145 */     checkName("name", name);
/* 146 */     this.name = name;
/* 147 */     if ((this.id == null) || (this.id.length() == 0))
/* 148 */       this.id = name;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getHost()
/*     */   {
/* 154 */     return this.host;
/*     */   }
/*     */ 
/*     */   public void setHost(String host) {
/* 158 */     checkName("host", host);
/* 159 */     this.host = host;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public Integer getPort() {
/* 164 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setPort(Integer port) {
/* 168 */     this.port = port;
/*     */   }
/*     */   @Deprecated
/*     */   @Parameter(excluded=true)
/*     */   public String getPath() {
/* 174 */     return getContextpath();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setPath(String path) {
/* 179 */     setContextpath(path);
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getContextpath() {
/* 184 */     return this.contextpath;
/*     */   }
/*     */ 
/*     */   public void setContextpath(String contextpath) {
/* 188 */     checkPathName("contextpath", contextpath);
/* 189 */     this.contextpath = contextpath;
/*     */   }
/*     */ 
/*     */   public String getThreadpool() {
/* 193 */     return this.threadpool;
/*     */   }
/*     */ 
/*     */   public void setThreadpool(String threadpool) {
/* 197 */     checkExtension(ThreadPool.class, "threadpool", threadpool);
/* 198 */     this.threadpool = threadpool;
/*     */   }
/*     */ 
/*     */   public Integer getThreads() {
/* 202 */     return this.threads;
/*     */   }
/*     */ 
/*     */   public void setThreads(Integer threads) {
/* 206 */     this.threads = threads;
/*     */   }
/*     */ 
/*     */   public Integer getIothreads() {
/* 210 */     return this.iothreads;
/*     */   }
/*     */ 
/*     */   public void setIothreads(Integer iothreads) {
/* 214 */     this.iothreads = iothreads;
/*     */   }
/*     */ 
/*     */   public Integer getQueues() {
/* 218 */     return this.queues;
/*     */   }
/*     */ 
/*     */   public void setQueues(Integer queues) {
/* 222 */     this.queues = queues;
/*     */   }
/*     */ 
/*     */   public Integer getAccepts() {
/* 226 */     return this.accepts;
/*     */   }
/*     */ 
/*     */   public void setAccepts(Integer accepts) {
/* 230 */     this.accepts = accepts;
/*     */   }
/*     */ 
/*     */   public String getCodec() {
/* 234 */     return this.codec;
/*     */   }
/*     */ 
/*     */   public void setCodec(String codec) {
/* 238 */     if ("dubbo".equals(this.name)) {
/* 239 */       checkMultiExtension(Codec.class, "codec", codec);
/*     */     }
/* 241 */     this.codec = codec;
/*     */   }
/*     */ 
/*     */   public String getSerialization() {
/* 245 */     return this.serialization;
/*     */   }
/*     */ 
/*     */   public void setSerialization(String serialization) {
/* 249 */     if ("dubbo".equals(this.name)) {
/* 250 */       checkMultiExtension(Serialization.class, "serialization", serialization);
/*     */     }
/* 252 */     this.serialization = serialization;
/*     */   }
/*     */ 
/*     */   public String getCharset() {
/* 256 */     return this.charset;
/*     */   }
/*     */ 
/*     */   public void setCharset(String charset) {
/* 260 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   public Integer getPayload() {
/* 264 */     return this.payload;
/*     */   }
/*     */ 
/*     */   public void setPayload(Integer payload) {
/* 268 */     this.payload = payload;
/*     */   }
/*     */ 
/*     */   public Integer getBuffer() {
/* 272 */     return this.buffer;
/*     */   }
/*     */ 
/*     */   public void setBuffer(Integer buffer) {
/* 276 */     this.buffer = buffer;
/*     */   }
/*     */ 
/*     */   public Integer getHeartbeat() {
/* 280 */     return this.heartbeat;
/*     */   }
/*     */ 
/*     */   public void setHeartbeat(Integer heartbeat) {
/* 284 */     this.heartbeat = heartbeat;
/*     */   }
/*     */ 
/*     */   public String getServer() {
/* 288 */     return this.server;
/*     */   }
/*     */ 
/*     */   public void setServer(String server) {
/* 292 */     if ("dubbo".equals(this.name)) {
/* 293 */       checkMultiExtension(Transporter.class, "server", server);
/*     */     }
/* 295 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public String getClient() {
/* 299 */     return this.client;
/*     */   }
/*     */ 
/*     */   public void setClient(String client) {
/* 303 */     if ("dubbo".equals(this.name)) {
/* 304 */       checkMultiExtension(Transporter.class, "client", client);
/*     */     }
/* 306 */     this.client = client;
/*     */   }
/*     */ 
/*     */   public String getAccesslog() {
/* 310 */     return this.accesslog;
/*     */   }
/*     */ 
/*     */   public void setAccesslog(String accesslog) {
/* 314 */     this.accesslog = accesslog;
/*     */   }
/*     */ 
/*     */   public String getTelnet() {
/* 318 */     return this.telnet;
/*     */   }
/*     */ 
/*     */   public void setTelnet(String telnet) {
/* 322 */     checkMultiExtension(TelnetHandler.class, "telnet", telnet);
/* 323 */     this.telnet = telnet;
/*     */   }
/*     */ 
/*     */   @Parameter(escaped=true)
/*     */   public String getPrompt() {
/* 328 */     return this.prompt;
/*     */   }
/*     */ 
/*     */   public void setPrompt(String prompt) {
/* 332 */     this.prompt = prompt;
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 336 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/* 340 */     checkMultiExtension(StatusChecker.class, "status", status);
/* 341 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public Boolean isRegister() {
/* 345 */     return this.register;
/*     */   }
/*     */ 
/*     */   public void setRegister(Boolean register) {
/* 349 */     this.register = register;
/*     */   }
/*     */ 
/*     */   public String getTransporter() {
/* 353 */     return this.transporter;
/*     */   }
/*     */ 
/*     */   public void setTransporter(String transporter) {
/* 357 */     checkExtension(Transporter.class, "transporter", transporter);
/* 358 */     this.transporter = transporter;
/*     */   }
/*     */ 
/*     */   public String getExchanger() {
/* 362 */     return this.exchanger;
/*     */   }
/*     */ 
/*     */   public void setExchanger(String exchanger) {
/* 366 */     checkExtension(Exchanger.class, "exchanger", exchanger);
/* 367 */     this.exchanger = exchanger;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   @Parameter(excluded=true)
/*     */   public String getDispather()
/*     */   {
/* 377 */     return getDispatcher();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setDispather(String dispather)
/*     */   {
/* 386 */     setDispatcher(dispather);
/*     */   }
/*     */ 
/*     */   public String getDispatcher() {
/* 390 */     return this.dispatcher;
/*     */   }
/*     */ 
/*     */   public void setDispatcher(String dispatcher) {
/* 394 */     checkExtension(Dispatcher.class, "dispacther", dispatcher);
/* 395 */     this.dispatcher = dispatcher;
/*     */   }
/*     */ 
/*     */   public String getNetworker() {
/* 399 */     return this.networker;
/*     */   }
/*     */ 
/*     */   public void setNetworker(String networker) {
/* 403 */     this.networker = networker;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParameters() {
/* 407 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public void setParameters(Map<String, String> parameters) {
/* 411 */     this.parameters = parameters;
/*     */   }
/*     */ 
/*     */   public Boolean isDefault() {
/* 415 */     return this.isDefault;
/*     */   }
/*     */ 
/*     */   public void setDefault(Boolean isDefault) {
/* 419 */     this.isDefault = isDefault;
/*     */   }
/*     */ 
/*     */   public void destory() {
/* 423 */     if (this.name != null)
/* 424 */       ((Protocol)ExtensionLoader.getExtensionLoader(Protocol.class).getExtension(this.name)).destroy();
/*     */   }
/*     */ 
/*     */   public static void destroyAll()
/*     */   {
/* 429 */     AbstractRegistryFactory.destroyAll();
/* 430 */     ExtensionLoader loader = ExtensionLoader.getExtensionLoader(Protocol.class);
/* 431 */     for (String protocolName : loader.getLoadedExtensions())
/*     */       try {
/* 433 */         Protocol protocol = (Protocol)loader.getLoadedExtension(protocolName);
/* 434 */         if (protocol != null)
/* 435 */           protocol.destroy();
/*     */       }
/*     */       catch (Throwable t) {
/* 438 */         logger.warn(t.getMessage(), t);
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.ProtocolConfig
 * JD-Core Version:    0.6.2
 */