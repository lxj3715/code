/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.common.status.StatusChecker;
/*     */ import com.alibaba.dubbo.common.threadpool.ThreadPool;
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.remoting.Dispatcher;
/*     */ import com.alibaba.dubbo.remoting.Transporter;
/*     */ import com.alibaba.dubbo.remoting.exchange.Exchanger;
/*     */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class ProviderConfig extends AbstractServiceConfig
/*     */ {
/*     */   private static final long serialVersionUID = 6913423882496634749L;
/*     */   private String host;
/*     */   private Integer port;
/*     */   private String contextpath;
/*     */   private String threadpool;
/*     */   private Integer threads;
/*     */   private Integer iothreads;
/*     */   private Integer queues;
/*     */   private Integer accepts;
/*     */   private String codec;
/*     */   private String serialization;
/*     */   private String charset;
/*     */   private Integer payload;
/*     */   private Integer buffer;
/*     */   private String transporter;
/*     */   private String exchanger;
/*     */   private String dispatcher;
/*     */   private String networker;
/*     */   private String server;
/*     */   private String client;
/*     */   private String telnet;
/*     */   private String prompt;
/*     */   private String status;
/*     */   private Integer wait;
/*     */   private Boolean isDefault;
/*     */ 
/*     */   @Deprecated
/*     */   public void setProtocol(String protocol)
/*     */   {
/* 117 */     this.protocols = Arrays.asList(new ProtocolConfig[] { new ProtocolConfig(protocol) });
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public Boolean isDefault() {
/* 122 */     return this.isDefault;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setDefault(Boolean isDefault) {
/* 127 */     this.isDefault = isDefault;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getHost() {
/* 132 */     return this.host;
/*     */   }
/*     */ 
/*     */   public void setHost(String host) {
/* 136 */     this.host = host;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public Integer getPort() {
/* 141 */     return this.port;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setPort(Integer port) {
/* 146 */     this.port = port;
/*     */   }
/*     */   @Deprecated
/*     */   @Parameter(excluded=true)
/*     */   public String getPath() {
/* 152 */     return getContextpath();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setPath(String path) {
/* 157 */     setContextpath(path);
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getContextpath() {
/* 162 */     return this.contextpath;
/*     */   }
/*     */ 
/*     */   public void setContextpath(String contextpath) {
/* 166 */     checkPathName("contextpath", contextpath);
/* 167 */     this.contextpath = contextpath;
/*     */   }
/*     */ 
/*     */   public String getThreadpool() {
/* 171 */     return this.threadpool;
/*     */   }
/*     */ 
/*     */   public void setThreadpool(String threadpool) {
/* 175 */     checkExtension(ThreadPool.class, "threadpool", threadpool);
/* 176 */     this.threadpool = threadpool;
/*     */   }
/*     */ 
/*     */   public Integer getThreads() {
/* 180 */     return this.threads;
/*     */   }
/*     */ 
/*     */   public void setThreads(Integer threads) {
/* 184 */     this.threads = threads;
/*     */   }
/*     */ 
/*     */   public Integer getIothreads() {
/* 188 */     return this.iothreads;
/*     */   }
/*     */ 
/*     */   public void setIothreads(Integer iothreads) {
/* 192 */     this.iothreads = iothreads;
/*     */   }
/*     */ 
/*     */   public Integer getQueues() {
/* 196 */     return this.queues;
/*     */   }
/*     */ 
/*     */   public void setQueues(Integer queues) {
/* 200 */     this.queues = queues;
/*     */   }
/*     */ 
/*     */   public Integer getAccepts() {
/* 204 */     return this.accepts;
/*     */   }
/*     */ 
/*     */   public void setAccepts(Integer accepts) {
/* 208 */     this.accepts = accepts;
/*     */   }
/*     */ 
/*     */   public String getCodec() {
/* 212 */     return this.codec;
/*     */   }
/*     */ 
/*     */   public void setCodec(String codec) {
/* 216 */     this.codec = codec;
/*     */   }
/*     */ 
/*     */   public String getSerialization() {
/* 220 */     return this.serialization;
/*     */   }
/*     */ 
/*     */   public void setSerialization(String serialization) {
/* 224 */     this.serialization = serialization;
/*     */   }
/*     */ 
/*     */   public String getCharset() {
/* 228 */     return this.charset;
/*     */   }
/*     */ 
/*     */   public void setCharset(String charset) {
/* 232 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   public Integer getPayload() {
/* 236 */     return this.payload;
/*     */   }
/*     */ 
/*     */   public void setPayload(Integer payload) {
/* 240 */     this.payload = payload;
/*     */   }
/*     */ 
/*     */   public Integer getBuffer() {
/* 244 */     return this.buffer;
/*     */   }
/*     */ 
/*     */   public void setBuffer(Integer buffer) {
/* 248 */     this.buffer = buffer;
/*     */   }
/*     */ 
/*     */   public String getServer() {
/* 252 */     return this.server;
/*     */   }
/*     */ 
/*     */   public void setServer(String server) {
/* 256 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public String getClient() {
/* 260 */     return this.client;
/*     */   }
/*     */ 
/*     */   public void setClient(String client) {
/* 264 */     this.client = client;
/*     */   }
/*     */ 
/*     */   public String getTelnet() {
/* 268 */     return this.telnet;
/*     */   }
/*     */ 
/*     */   public void setTelnet(String telnet) {
/* 272 */     checkMultiExtension(TelnetHandler.class, "telnet", telnet);
/* 273 */     this.telnet = telnet;
/*     */   }
/*     */ 
/*     */   @Parameter(escaped=true)
/*     */   public String getPrompt() {
/* 278 */     return this.prompt;
/*     */   }
/*     */ 
/*     */   public void setPrompt(String prompt) {
/* 282 */     this.prompt = prompt;
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 286 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/* 290 */     checkMultiExtension(StatusChecker.class, "status", status);
/* 291 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public String getCluster()
/*     */   {
/* 296 */     return super.getCluster();
/*     */   }
/*     */ 
/*     */   public Integer getConnections()
/*     */   {
/* 301 */     return super.getConnections();
/*     */   }
/*     */ 
/*     */   public Integer getTimeout()
/*     */   {
/* 306 */     return super.getTimeout();
/*     */   }
/*     */ 
/*     */   public Integer getRetries()
/*     */   {
/* 311 */     return super.getRetries();
/*     */   }
/*     */ 
/*     */   public String getLoadbalance()
/*     */   {
/* 316 */     return super.getLoadbalance();
/*     */   }
/*     */ 
/*     */   public Boolean isAsync()
/*     */   {
/* 321 */     return super.isAsync();
/*     */   }
/*     */ 
/*     */   public Integer getActives()
/*     */   {
/* 326 */     return super.getActives();
/*     */   }
/*     */ 
/*     */   public String getTransporter() {
/* 330 */     return this.transporter;
/*     */   }
/*     */ 
/*     */   public void setTransporter(String transporter) {
/* 334 */     checkExtension(Transporter.class, "transporter", transporter);
/* 335 */     this.transporter = transporter;
/*     */   }
/*     */ 
/*     */   public String getExchanger() {
/* 339 */     return this.exchanger;
/*     */   }
/*     */ 
/*     */   public void setExchanger(String exchanger) {
/* 343 */     checkExtension(Exchanger.class, "exchanger", exchanger);
/* 344 */     this.exchanger = exchanger;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   @Parameter(excluded=true)
/*     */   public String getDispather()
/*     */   {
/* 354 */     return getDispatcher();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setDispather(String dispather)
/*     */   {
/* 363 */     setDispatcher(dispather);
/*     */   }
/*     */ 
/*     */   public String getDispatcher() {
/* 367 */     return this.dispatcher;
/*     */   }
/*     */ 
/*     */   public void setDispatcher(String dispatcher) {
/* 371 */     checkExtension(Dispatcher.class, "dispatcher", this.exchanger);
/* 372 */     checkExtension(Dispatcher.class, "dispather", this.exchanger);
/* 373 */     this.dispatcher = dispatcher;
/*     */   }
/*     */ 
/*     */   public String getNetworker() {
/* 377 */     return this.networker;
/*     */   }
/*     */ 
/*     */   public void setNetworker(String networker) {
/* 381 */     this.networker = networker;
/*     */   }
/*     */ 
/*     */   public Integer getWait() {
/* 385 */     return this.wait;
/*     */   }
/*     */ 
/*     */   public void setWait(Integer wait) {
/* 389 */     this.wait = wait;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.ProviderConfig
 * JD-Core Version:    0.6.2
 */