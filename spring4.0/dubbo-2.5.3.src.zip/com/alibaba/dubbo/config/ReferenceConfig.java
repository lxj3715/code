/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.bytecode.Wrapper;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.config.annotation.Reference;
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Protocol;
/*     */ import com.alibaba.dubbo.rpc.ProxyFactory;
/*     */ import com.alibaba.dubbo.rpc.StaticContext;
/*     */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*     */ import com.alibaba.dubbo.rpc.cluster.directory.StaticDirectory;
/*     */ import com.alibaba.dubbo.rpc.cluster.support.ClusterUtils;
/*     */ import com.alibaba.dubbo.rpc.protocol.injvm.InjvmProtocol;
/*     */ import com.alibaba.dubbo.rpc.service.GenericService;
/*     */ import com.alibaba.dubbo.rpc.support.ProtocolUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class ReferenceConfig<T> extends AbstractReferenceConfig
/*     */ {
/*     */   private static final long serialVersionUID = -5864351140409987595L;
/*  63 */   private static final Protocol refprotocol = (Protocol)ExtensionLoader.getExtensionLoader(Protocol.class).getAdaptiveExtension();
/*     */ 
/*  65 */   private static final Cluster cluster = (Cluster)ExtensionLoader.getExtensionLoader(Cluster.class).getAdaptiveExtension();
/*     */ 
/*  67 */   private static final ProxyFactory proxyFactory = (ProxyFactory)ExtensionLoader.getExtensionLoader(ProxyFactory.class).getAdaptiveExtension();
/*     */   private String interfaceName;
/*     */   private Class<?> interfaceClass;
/*     */   private String client;
/*     */   private String url;
/*     */   private List<MethodConfig> methods;
/*     */   private ConsumerConfig consumer;
/*     */   private String protocol;
/*     */   private volatile transient T ref;
/*     */   private volatile transient Invoker<?> invoker;
/*     */   private volatile transient boolean initialized;
/*     */   private volatile transient boolean destroyed;
/*  97 */   private final List<URL> urls = new ArrayList();
/*     */ 
/*  99 */   private final Object finalizerGuardian = new Object()
/*     */   {
/*     */     protected void finalize() throws Throwable
/*     */     {
/* 103 */       super.finalize();
/*     */ 
/* 105 */       if (!ReferenceConfig.this.destroyed)
/* 106 */         AbstractConfig.logger.warn("ReferenceConfig(" + ReferenceConfig.this.url + ") is not DESTROYED when FINALIZE");
/*     */     }
/*  99 */   };
/*     */ 
/*     */   public ReferenceConfig()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ReferenceConfig(Reference reference)
/*     */   {
/* 122 */     appendAnnotation(Reference.class, reference);
/*     */   }
/*     */ 
/*     */   public URL toUrl() {
/* 126 */     return (this.urls == null) || (this.urls.size() == 0) ? null : (URL)this.urls.iterator().next();
/*     */   }
/*     */ 
/*     */   public List<URL> toUrls() {
/* 130 */     return this.urls;
/*     */   }
/*     */ 
/*     */   public synchronized T get() {
/* 134 */     if (this.destroyed) {
/* 135 */       throw new IllegalStateException("Already destroyed!");
/*     */     }
/* 137 */     if (this.ref == null) {
/* 138 */       init();
/*     */     }
/* 140 */     return this.ref;
/*     */   }
/*     */ 
/*     */   public synchronized void destroy() {
/* 144 */     if (this.ref == null) {
/* 145 */       return;
/*     */     }
/* 147 */     if (this.destroyed) {
/* 148 */       return;
/*     */     }
/* 150 */     this.destroyed = true;
/*     */     try {
/* 152 */       this.invoker.destroy();
/*     */     } catch (Throwable t) {
/* 154 */       logger.warn("Unexpected err when destroy invoker of ReferenceConfig(" + this.url + ").", t);
/*     */     }
/* 156 */     this.invoker = null;
/* 157 */     this.ref = null;
/*     */   }
/*     */ 
/*     */   private void init() {
/* 161 */     if (this.initialized) {
/* 162 */       return;
/*     */     }
/* 164 */     this.initialized = true;
/* 165 */     if ((this.interfaceName == null) || (this.interfaceName.length() == 0)) {
/* 166 */       throw new IllegalStateException("<dubbo:reference interface=\"\" /> interface not allow null!");
/*     */     }
/*     */ 
/* 169 */     checkDefault();
/* 170 */     appendProperties(this);
/* 171 */     if ((getGeneric() == null) && (getConsumer() != null)) {
/* 172 */       setGeneric(getConsumer().getGeneric());
/*     */     }
/* 174 */     if (ProtocolUtils.isGeneric(getGeneric())) {
/* 175 */       this.interfaceClass = GenericService.class;
/*     */     } else {
/*     */       try {
/* 178 */         this.interfaceClass = Class.forName(this.interfaceName, true, Thread.currentThread().getContextClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 181 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/* 183 */       checkInterfaceAndMethods(this.interfaceClass, this.methods);
/*     */     }
/* 185 */     String resolve = System.getProperty(this.interfaceName);
/* 186 */     String resolveFile = null;
/* 187 */     if ((resolve == null) || (resolve.length() == 0)) {
/* 188 */       resolveFile = System.getProperty("dubbo.resolve.file");
/* 189 */       if ((resolveFile == null) || (resolveFile.length() == 0)) {
/* 190 */         File userResolveFile = new File(new File(System.getProperty("user.home")), "dubbo-resolve.properties");
/* 191 */         if (userResolveFile.exists()) {
/* 192 */           resolveFile = userResolveFile.getAbsolutePath();
/*     */         }
/*     */       }
/* 195 */       if ((resolveFile != null) && (resolveFile.length() > 0)) {
/* 196 */         Properties properties = new Properties();
/* 197 */         FileInputStream fis = null;
/*     */         try {
/* 199 */           fis = new FileInputStream(new File(resolveFile));
/* 200 */           properties.load(fis);
/*     */         } catch (IOException e) {
/* 202 */           throw new IllegalStateException("Unload " + resolveFile + ", cause: " + e.getMessage(), e);
/*     */         } finally {
/*     */           try {
/* 205 */             if (null != fis) fis.close(); 
/*     */           }
/* 207 */           catch (IOException e) { logger.warn(e.getMessage(), e); }
/*     */ 
/*     */         }
/* 210 */         resolve = properties.getProperty(this.interfaceName);
/*     */       }
/*     */     }
/* 213 */     if ((resolve != null) && (resolve.length() > 0)) {
/* 214 */       this.url = resolve;
/* 215 */       if (logger.isWarnEnabled()) {
/* 216 */         if ((resolveFile != null) && (resolveFile.length() > 0))
/* 217 */           logger.warn("Using default dubbo resolve file " + resolveFile + " replace " + this.interfaceName + "" + resolve + " to p2p invoke remote service.");
/*     */         else {
/* 219 */           logger.warn("Using -D" + this.interfaceName + "=" + resolve + " to p2p invoke remote service.");
/*     */         }
/*     */       }
/*     */     }
/* 223 */     if (this.consumer != null) {
/* 224 */       if (this.application == null) {
/* 225 */         this.application = this.consumer.getApplication();
/*     */       }
/* 227 */       if (this.module == null) {
/* 228 */         this.module = this.consumer.getModule();
/*     */       }
/* 230 */       if (this.registries == null) {
/* 231 */         this.registries = this.consumer.getRegistries();
/*     */       }
/* 233 */       if (this.monitor == null) {
/* 234 */         this.monitor = this.consumer.getMonitor();
/*     */       }
/*     */     }
/* 237 */     if (this.module != null) {
/* 238 */       if (this.registries == null) {
/* 239 */         this.registries = this.module.getRegistries();
/*     */       }
/* 241 */       if (this.monitor == null) {
/* 242 */         this.monitor = this.module.getMonitor();
/*     */       }
/*     */     }
/* 245 */     if (this.application != null) {
/* 246 */       if (this.registries == null) {
/* 247 */         this.registries = this.application.getRegistries();
/*     */       }
/* 249 */       if (this.monitor == null) {
/* 250 */         this.monitor = this.application.getMonitor();
/*     */       }
/*     */     }
/* 253 */     checkApplication();
/* 254 */     checkStubAndMock(this.interfaceClass);
/* 255 */     Map map = new HashMap();
/* 256 */     Map attributes = new HashMap();
/* 257 */     map.put("side", "consumer");
/* 258 */     map.put("dubbo", Version.getVersion());
/* 259 */     map.put("timestamp", String.valueOf(System.currentTimeMillis()));
/* 260 */     if (ConfigUtils.getPid() > 0) {
/* 261 */       map.put("pid", String.valueOf(ConfigUtils.getPid()));
/*     */     }
/* 263 */     if (!isGeneric().booleanValue()) {
/* 264 */       String revision = Version.getVersion(this.interfaceClass, this.version);
/* 265 */       if ((revision != null) && (revision.length() > 0)) {
/* 266 */         map.put("revision", revision);
/*     */       }
/*     */ 
/* 269 */       String[] methods = Wrapper.getWrapper(this.interfaceClass).getMethodNames();
/* 270 */       if (methods.length == 0) {
/* 271 */         logger.warn("NO method found in service interface " + this.interfaceClass.getName());
/* 272 */         map.put("methods", "*");
/*     */       }
/*     */       else {
/* 275 */         map.put("methods", StringUtils.join(new HashSet(Arrays.asList(methods)), ","));
/*     */       }
/*     */     }
/* 278 */     map.put("interface", this.interfaceName);
/* 279 */     appendParameters(map, this.application);
/* 280 */     appendParameters(map, this.module);
/* 281 */     appendParameters(map, this.consumer, "default");
/* 282 */     appendParameters(map, this);
/* 283 */     String prifix = StringUtils.getServiceKey(map);
/* 284 */     if ((this.methods != null) && (this.methods.size() > 0)) {
/* 285 */       for (MethodConfig method : this.methods) {
/* 286 */         appendParameters(map, method, method.getName());
/* 287 */         String retryKey = method.getName() + ".retry";
/* 288 */         if (map.containsKey(retryKey)) {
/* 289 */           String retryValue = (String)map.remove(retryKey);
/* 290 */           if ("false".equals(retryValue)) {
/* 291 */             map.put(method.getName() + ".retries", "0");
/*     */           }
/*     */         }
/* 294 */         appendAttributes(attributes, method, prifix + "." + method.getName());
/* 295 */         checkAndConvertImplicitConfig(method, map, attributes);
/*     */       }
/*     */     }
/*     */ 
/* 299 */     StaticContext.getSystemContext().putAll(attributes);
/* 300 */     this.ref = createProxy(map);
/*     */   }
/*     */ 
/*     */   private static void checkAndConvertImplicitConfig(MethodConfig method, Map<String, String> map, Map<Object, Object> attributes)
/*     */   {
/* 305 */     if ((Boolean.FALSE.equals(method.isReturn())) && ((method.getOnreturn() != null) || (method.getOnthrow() != null))) {
/* 306 */       throw new IllegalStateException("method config error : return attribute must be set true when onreturn or onthrow has been setted.");
/*     */     }
/*     */ 
/* 309 */     String onReturnMethodKey = StaticContext.getKey(map, method.getName(), "onreturn.method");
/* 310 */     Object onReturnMethod = attributes.get(onReturnMethodKey);
/* 311 */     if ((onReturnMethod != null) && ((onReturnMethod instanceof String))) {
/* 312 */       attributes.put(onReturnMethodKey, getMethodByName(method.getOnreturn().getClass(), onReturnMethod.toString()));
/*     */     }
/*     */ 
/* 315 */     String onThrowMethodKey = StaticContext.getKey(map, method.getName(), "onthrow.method");
/* 316 */     Object onThrowMethod = attributes.get(onThrowMethodKey);
/* 317 */     if ((onThrowMethod != null) && ((onThrowMethod instanceof String))) {
/* 318 */       attributes.put(onThrowMethodKey, getMethodByName(method.getOnthrow().getClass(), onThrowMethod.toString()));
/*     */     }
/*     */ 
/* 321 */     String onInvokeMethodKey = StaticContext.getKey(map, method.getName(), "oninvoke.method");
/* 322 */     Object onInvokeMethod = attributes.get(onInvokeMethodKey);
/* 323 */     if ((onInvokeMethod != null) && ((onInvokeMethod instanceof String)))
/* 324 */       attributes.put(onInvokeMethodKey, getMethodByName(method.getOninvoke().getClass(), onInvokeMethod.toString()));
/*     */   }
/*     */ 
/*     */   private static Method getMethodByName(Class<?> clazz, String methodName)
/*     */   {
/*     */     try {
/* 330 */       return ReflectUtils.findMethodByMethodName(clazz, methodName);
/*     */     } catch (Exception e) {
/* 332 */       throw new IllegalStateException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private T createProxy(Map<String, String> map)
/*     */   {
/* 338 */     URL tmpUrl = new URL("temp", "localhost", 0, map);
/*     */     boolean isJvmRefer;
/*     */     boolean isJvmRefer;
/* 340 */     if (isInjvm() == null)
/*     */     {
/*     */       boolean isJvmRefer;
/* 341 */       if ((this.url != null) && (this.url.length() > 0)) {
/* 342 */         isJvmRefer = false;
/*     */       }
/*     */       else
/*     */       {
/*     */         boolean isJvmRefer;
/* 343 */         if (InjvmProtocol.getInjvmProtocol().isInjvmRefer(tmpUrl))
/*     */         {
/* 345 */           isJvmRefer = true;
/*     */         }
/* 347 */         else isJvmRefer = false; 
/*     */       }
/*     */     }
/* 350 */     else { isJvmRefer = isInjvm().booleanValue(); }
/*     */ 
/*     */ 
/* 353 */     if (isJvmRefer) {
/* 354 */       URL url = new URL("injvm", "127.0.0.1", 0, this.interfaceClass.getName()).addParameters(map);
/* 355 */       this.invoker = refprotocol.refer(this.interfaceClass, url);
/* 356 */       if (logger.isInfoEnabled())
/* 357 */         logger.info("Using injvm service " + this.interfaceClass.getName());
/*     */     }
/*     */     else {
/* 360 */       if ((this.url != null) && (this.url.length() > 0)) {
/* 361 */         String[] us = Constants.SEMICOLON_SPLIT_PATTERN.split(this.url);
/* 362 */         if ((us != null) && (us.length > 0))
/* 363 */           for (String u : us) {
/* 364 */             URL url = URL.valueOf(u);
/* 365 */             if ((url.getPath() == null) || (url.getPath().length() == 0)) {
/* 366 */               url = url.setPath(this.interfaceName);
/*     */             }
/* 368 */             if ("registry".equals(url.getProtocol()))
/* 369 */               this.urls.add(url.addParameterAndEncoded("refer", StringUtils.toQueryString(map)));
/*     */             else
/* 371 */               this.urls.add(ClusterUtils.mergeUrl(url, map));
/*     */           }
/*     */       }
/*     */       else
/*     */       {
/* 376 */         List us = loadRegistries(false);
/* 377 */         if ((us != null) && (us.size() > 0)) {
/* 378 */           for (URL u : us) {
/* 379 */             URL monitorUrl = loadMonitor(u);
/* 380 */             if (monitorUrl != null) {
/* 381 */               map.put("monitor", URL.encode(monitorUrl.toFullString()));
/*     */             }
/* 383 */             this.urls.add(u.addParameterAndEncoded("refer", StringUtils.toQueryString(map)));
/*     */           }
/*     */         }
/* 386 */         if ((this.urls == null) || (this.urls.size() == 0)) {
/* 387 */           throw new IllegalStateException("No such any registry to reference " + this.interfaceName + " on the consumer " + NetUtils.getLocalHost() + " use dubbo version " + Version.getVersion() + ", please config <dubbo:registry address=\"...\" /> to your spring config.");
/*     */         }
/*     */       }
/*     */ 
/* 391 */       if (this.urls.size() == 1) {
/* 392 */         this.invoker = refprotocol.refer(this.interfaceClass, (URL)this.urls.get(0));
/*     */       } else {
/* 394 */         List invokers = new ArrayList();
/* 395 */         URL registryURL = null;
/* 396 */         for (URL url : this.urls) {
/* 397 */           invokers.add(refprotocol.refer(this.interfaceClass, url));
/* 398 */           if ("registry".equals(url.getProtocol())) {
/* 399 */             registryURL = url;
/*     */           }
/*     */         }
/* 402 */         if (registryURL != null)
/*     */         {
/* 404 */           URL u = registryURL.addParameter("cluster", "available");
/* 405 */           this.invoker = cluster.join(new StaticDirectory(u, invokers));
/*     */         } else {
/* 407 */           this.invoker = cluster.join(new StaticDirectory(invokers));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 412 */     Boolean c = this.check;
/* 413 */     if ((c == null) && (this.consumer != null)) {
/* 414 */       c = this.consumer.isCheck();
/*     */     }
/* 416 */     if (c == null) {
/* 417 */       c = Boolean.valueOf(true);
/*     */     }
/* 419 */     if ((c.booleanValue()) && (!this.invoker.isAvailable())) {
/* 420 */       throw new IllegalStateException("Failed to check the status of the service " + this.interfaceName + ". No provider available for the service " + (this.group == null ? "" : new StringBuilder().append(this.group).append("/").toString()) + this.interfaceName + (this.version == null ? "" : new StringBuilder().append(":").append(this.version).toString()) + " from the url " + this.invoker.getUrl() + " to the consumer " + NetUtils.getLocalHost() + " use dubbo version " + Version.getVersion());
/*     */     }
/* 422 */     if (logger.isInfoEnabled()) {
/* 423 */       logger.info("Refer dubbo service " + this.interfaceClass.getName() + " from url " + this.invoker.getUrl());
/*     */     }
/*     */ 
/* 426 */     return proxyFactory.getProxy(this.invoker);
/*     */   }
/*     */ 
/*     */   private void checkDefault() {
/* 430 */     if (this.consumer == null) {
/* 431 */       this.consumer = new ConsumerConfig();
/*     */     }
/* 433 */     appendProperties(this.consumer);
/*     */   }
/*     */ 
/*     */   public Class<?> getInterfaceClass() {
/* 437 */     if (this.interfaceClass != null) {
/* 438 */       return this.interfaceClass;
/*     */     }
/* 440 */     if ((isGeneric().booleanValue()) || ((getConsumer() != null) && (getConsumer().isGeneric().booleanValue())))
/*     */     {
/* 442 */       return GenericService.class;
/*     */     }
/*     */     try {
/* 445 */       if ((this.interfaceName != null) && (this.interfaceName.length() > 0))
/* 446 */         this.interfaceClass = Class.forName(this.interfaceName, true, Thread.currentThread().getContextClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException t)
/*     */     {
/* 450 */       throw new IllegalStateException(t.getMessage(), t);
/*     */     }
/* 452 */     return this.interfaceClass;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setInterfaceClass(Class<?> interfaceClass)
/*     */   {
/* 462 */     setInterface(interfaceClass);
/*     */   }
/*     */ 
/*     */   public String getInterface() {
/* 466 */     return this.interfaceName;
/*     */   }
/*     */ 
/*     */   public void setInterface(String interfaceName) {
/* 470 */     this.interfaceName = interfaceName;
/* 471 */     if ((this.id == null) || (this.id.length() == 0))
/* 472 */       this.id = interfaceName;
/*     */   }
/*     */ 
/*     */   public void setInterface(Class<?> interfaceClass)
/*     */   {
/* 477 */     if ((interfaceClass != null) && (!interfaceClass.isInterface())) {
/* 478 */       throw new IllegalStateException("The interface class " + interfaceClass + " is not a interface!");
/*     */     }
/* 480 */     this.interfaceClass = interfaceClass;
/* 481 */     setInterface(interfaceClass == null ? (String)null : interfaceClass.getName());
/*     */   }
/*     */ 
/*     */   public String getClient() {
/* 485 */     return this.client;
/*     */   }
/*     */ 
/*     */   public void setClient(String client) {
/* 489 */     checkName("client", client);
/* 490 */     this.client = client;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getUrl() {
/* 495 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setUrl(String url) {
/* 499 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public List<MethodConfig> getMethods() {
/* 503 */     return this.methods;
/*     */   }
/*     */ 
/*     */   public void setMethods(List<? extends MethodConfig> methods)
/*     */   {
/* 508 */     this.methods = methods;
/*     */   }
/*     */ 
/*     */   public ConsumerConfig getConsumer() {
/* 512 */     return this.consumer;
/*     */   }
/*     */ 
/*     */   public void setConsumer(ConsumerConfig consumer) {
/* 516 */     this.consumer = consumer;
/*     */   }
/*     */ 
/*     */   public String getProtocol() {
/* 520 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public void setProtocol(String protocol) {
/* 524 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   Invoker<?> getInvoker()
/*     */   {
/* 529 */     return this.invoker;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.ReferenceConfig
 * JD-Core Version:    0.6.2
 */