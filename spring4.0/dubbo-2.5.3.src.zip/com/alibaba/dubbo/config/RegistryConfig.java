/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.registry.support.AbstractRegistryFactory;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class RegistryConfig extends AbstractConfig
/*     */ {
/*     */   private static final long serialVersionUID = 5508512956753757169L;
/*     */   public static final String NO_AVAILABLE = "N/A";
/*     */   private String address;
/*     */   private String username;
/*     */   private String password;
/*     */   private Integer port;
/*     */   private String protocol;
/*     */   private String transporter;
/*     */   private String server;
/*     */   private String client;
/*     */   private String cluster;
/*     */   private String group;
/*     */   private String version;
/*     */   private Integer timeout;
/*     */   private Integer session;
/*     */   private String file;
/*     */   private Integer wait;
/*     */   private Boolean check;
/*     */   private Boolean dynamic;
/*     */   private Boolean register;
/*     */   private Boolean subscribe;
/*     */   private Map<String, String> parameters;
/*     */   private Boolean isDefault;
/*     */ 
/*     */   public RegistryConfig()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RegistryConfig(String address)
/*     */   {
/*  98 */     setAddress(address);
/*     */   }
/*     */ 
/*     */   public String getProtocol() {
/* 102 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public void setProtocol(String protocol) {
/* 106 */     checkName("protocol", protocol);
/* 107 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getAddress() {
/* 112 */     return this.address;
/*     */   }
/*     */ 
/*     */   public void setAddress(String address) {
/* 116 */     this.address = address;
/*     */   }
/*     */ 
/*     */   public Integer getPort() {
/* 120 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setPort(Integer port) {
/* 124 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public String getUsername() {
/* 128 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username) {
/* 132 */     checkName("username", username);
/* 133 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getPassword() {
/* 137 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password) {
/* 141 */     checkLength("password", password);
/* 142 */     this.password = password;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Integer getWait()
/*     */   {
/* 152 */     return this.wait;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setWait(Integer wait)
/*     */   {
/* 162 */     this.wait = wait;
/* 163 */     if ((wait != null) && (wait.intValue() > 0))
/* 164 */       System.setProperty("dubbo.service.shutdown.wait", String.valueOf(wait));
/*     */   }
/*     */ 
/*     */   public Boolean isCheck() {
/* 168 */     return this.check;
/*     */   }
/*     */ 
/*     */   public void setCheck(Boolean check) {
/* 172 */     this.check = check;
/*     */   }
/*     */ 
/*     */   public String getFile() {
/* 176 */     return this.file;
/*     */   }
/*     */ 
/*     */   public void setFile(String file) {
/* 180 */     checkPathLength("file", file);
/* 181 */     this.file = file;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   @Parameter(excluded=true)
/*     */   public String getTransport()
/*     */   {
/* 192 */     return getTransporter();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setTransport(String transport)
/*     */   {
/* 202 */     setTransporter(transport);
/*     */   }
/*     */ 
/*     */   public String getTransporter() {
/* 206 */     return this.transporter;
/*     */   }
/*     */ 
/*     */   public void setTransporter(String transporter) {
/* 210 */     checkName("transporter", transporter);
/*     */ 
/* 214 */     this.transporter = transporter;
/*     */   }
/*     */ 
/*     */   public String getServer() {
/* 218 */     return this.server;
/*     */   }
/*     */ 
/*     */   public void setServer(String server) {
/* 222 */     checkName("server", server);
/*     */ 
/* 226 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public String getClient() {
/* 230 */     return this.client;
/*     */   }
/*     */ 
/*     */   public void setClient(String client) {
/* 234 */     checkName("client", client);
/*     */ 
/* 238 */     this.client = client;
/*     */   }
/*     */ 
/*     */   public Integer getTimeout() {
/* 242 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void setTimeout(Integer timeout) {
/* 246 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public Integer getSession() {
/* 250 */     return this.session;
/*     */   }
/*     */ 
/*     */   public void setSession(Integer session) {
/* 254 */     this.session = session;
/*     */   }
/*     */ 
/*     */   public Boolean isDynamic() {
/* 258 */     return this.dynamic;
/*     */   }
/*     */ 
/*     */   public void setDynamic(Boolean dynamic) {
/* 262 */     this.dynamic = dynamic;
/*     */   }
/*     */ 
/*     */   public Boolean isRegister() {
/* 266 */     return this.register;
/*     */   }
/*     */ 
/*     */   public void setRegister(Boolean register) {
/* 270 */     this.register = register;
/*     */   }
/*     */ 
/*     */   public Boolean isSubscribe() {
/* 274 */     return this.subscribe;
/*     */   }
/*     */ 
/*     */   public void setSubscribe(Boolean subscribe) {
/* 278 */     this.subscribe = subscribe;
/*     */   }
/*     */ 
/*     */   public String getCluster() {
/* 282 */     return this.cluster;
/*     */   }
/*     */ 
/*     */   public void setCluster(String cluster) {
/* 286 */     this.cluster = cluster;
/*     */   }
/*     */ 
/*     */   public String getGroup() {
/* 290 */     return this.group;
/*     */   }
/*     */ 
/*     */   public void setGroup(String group) {
/* 294 */     this.group = group;
/*     */   }
/*     */ 
/*     */   public String getVersion() {
/* 298 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String version) {
/* 302 */     this.version = version;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParameters() {
/* 306 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public void setParameters(Map<String, String> parameters) {
/* 310 */     checkParameterName(parameters);
/* 311 */     this.parameters = parameters;
/*     */   }
/*     */ 
/*     */   public Boolean isDefault() {
/* 315 */     return this.isDefault;
/*     */   }
/*     */ 
/*     */   public void setDefault(Boolean isDefault) {
/* 319 */     this.isDefault = isDefault;
/*     */   }
/*     */ 
/*     */   public static void destroyAll() {
/* 323 */     AbstractRegistryFactory.destroyAll();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void closeAll() {
/* 328 */     destroyAll();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.RegistryConfig
 * JD-Core Version:    0.6.2
 */