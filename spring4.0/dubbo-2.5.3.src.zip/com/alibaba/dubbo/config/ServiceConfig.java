/*     */ package com.alibaba.dubbo.config;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.bytecode.Wrapper;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.utils.ClassHelper;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.config.annotation.Service;
/*     */ import com.alibaba.dubbo.config.support.Parameter;
/*     */ import com.alibaba.dubbo.rpc.Exporter;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Protocol;
/*     */ import com.alibaba.dubbo.rpc.ProxyFactory;
/*     */ import com.alibaba.dubbo.rpc.cluster.Configurator;
/*     */ import com.alibaba.dubbo.rpc.cluster.ConfiguratorFactory;
/*     */ import com.alibaba.dubbo.rpc.service.GenericService;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ 
/*     */ public class ServiceConfig<T> extends AbstractServiceConfig
/*     */ {
/*     */   private static final long serialVersionUID = 3033787999037024738L;
/*  60 */   private static final Protocol protocol = (Protocol)ExtensionLoader.getExtensionLoader(Protocol.class).getAdaptiveExtension();
/*     */ 
/*  62 */   private static final ProxyFactory proxyFactory = (ProxyFactory)ExtensionLoader.getExtensionLoader(ProxyFactory.class).getAdaptiveExtension();
/*     */ 
/*  64 */   private static final Map<String, Integer> RANDOM_PORT_MAP = new HashMap();
/*     */   private String interfaceName;
/*     */   private Class<?> interfaceClass;
/*     */   private T ref;
/*     */   private String path;
/*     */   private List<MethodConfig> methods;
/*     */   private ProviderConfig provider;
/*  82 */   private final List<URL> urls = new ArrayList();
/*     */ 
/*  84 */   private final List<Exporter<?>> exporters = new ArrayList();
/*     */   private volatile transient boolean exported;
/*     */   private volatile transient boolean unexported;
/*     */   private volatile transient boolean generic;
/*     */ 
/*     */   public ServiceConfig()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ServiceConfig(Service service)
/*     */   {
/*  96 */     appendAnnotation(Service.class, service);
/*     */   }
/*     */ 
/*     */   public URL toUrl() {
/* 100 */     return (this.urls == null) || (this.urls.size() == 0) ? null : (URL)this.urls.iterator().next();
/*     */   }
/*     */ 
/*     */   public List<URL> toUrls() {
/* 104 */     return this.urls;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public boolean isExported() {
/* 109 */     return this.exported;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public boolean isUnexported() {
/* 114 */     return this.unexported;
/*     */   }
/*     */ 
/*     */   public synchronized void export() {
/* 118 */     if (this.provider != null) {
/* 119 */       if (this.export == null) {
/* 120 */         this.export = this.provider.getExport();
/*     */       }
/* 122 */       if (this.delay == null) {
/* 123 */         this.delay = this.provider.getDelay();
/*     */       }
/*     */     }
/* 126 */     if ((this.export != null) && (!this.export.booleanValue())) {
/* 127 */       return;
/*     */     }
/* 129 */     if ((this.delay != null) && (this.delay.intValue() > 0)) {
/* 130 */       Thread thread = new Thread(new Runnable() {
/*     */         public void run() {
/*     */           try {
/* 133 */             Thread.sleep(ServiceConfig.this.delay.intValue());
/*     */           } catch (Throwable e) {
/*     */           }
/* 136 */           ServiceConfig.this.doExport();
/*     */         }
/*     */       });
/* 139 */       thread.setDaemon(true);
/* 140 */       thread.setName("DelayExportServiceThread");
/* 141 */       thread.start();
/*     */     } else {
/* 143 */       doExport();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected synchronized void doExport() {
/* 148 */     if (this.unexported) {
/* 149 */       throw new IllegalStateException("Already unexported!");
/*     */     }
/* 151 */     if (this.exported) {
/* 152 */       return;
/*     */     }
/* 154 */     this.exported = true;
/* 155 */     if ((this.interfaceName == null) || (this.interfaceName.length() == 0)) {
/* 156 */       throw new IllegalStateException("<dubbo:service interface=\"\" /> interface not allow null!");
/*     */     }
/* 158 */     checkDefault();
/* 159 */     if (this.provider != null) {
/* 160 */       if (this.application == null) {
/* 161 */         this.application = this.provider.getApplication();
/*     */       }
/* 163 */       if (this.module == null) {
/* 164 */         this.module = this.provider.getModule();
/*     */       }
/* 166 */       if (this.registries == null) {
/* 167 */         this.registries = this.provider.getRegistries();
/*     */       }
/* 169 */       if (this.monitor == null) {
/* 170 */         this.monitor = this.provider.getMonitor();
/*     */       }
/* 172 */       if (this.protocols == null) {
/* 173 */         this.protocols = this.provider.getProtocols();
/*     */       }
/*     */     }
/* 176 */     if (this.module != null) {
/* 177 */       if (this.registries == null) {
/* 178 */         this.registries = this.module.getRegistries();
/*     */       }
/* 180 */       if (this.monitor == null) {
/* 181 */         this.monitor = this.module.getMonitor();
/*     */       }
/*     */     }
/* 184 */     if (this.application != null) {
/* 185 */       if (this.registries == null) {
/* 186 */         this.registries = this.application.getRegistries();
/*     */       }
/* 188 */       if (this.monitor == null) {
/* 189 */         this.monitor = this.application.getMonitor();
/*     */       }
/*     */     }
/* 192 */     if ((this.ref instanceof GenericService)) {
/* 193 */       this.interfaceClass = GenericService.class;
/* 194 */       this.generic = true;
/*     */     } else {
/*     */       try {
/* 197 */         this.interfaceClass = Class.forName(this.interfaceName, true, Thread.currentThread().getContextClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 200 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/* 202 */       checkInterfaceAndMethods(this.interfaceClass, this.methods);
/* 203 */       checkRef();
/* 204 */       this.generic = false;
/*     */     }
/* 206 */     if (this.local != null) {
/* 207 */       if (this.local == "true")
/* 208 */         this.local = (this.interfaceName + "Local");
/*     */       Class localClass;
/*     */       try
/*     */       {
/* 212 */         localClass = ClassHelper.forNameWithThreadContextClassLoader(this.local);
/*     */       } catch (ClassNotFoundException e) {
/* 214 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/* 216 */       if (!this.interfaceClass.isAssignableFrom(localClass)) {
/* 217 */         throw new IllegalStateException("The local implemention class " + localClass.getName() + " not implement interface " + this.interfaceName);
/*     */       }
/*     */     }
/* 220 */     if (this.stub != null) {
/* 221 */       if (this.stub == "true")
/* 222 */         this.stub = (this.interfaceName + "Stub");
/*     */       Class stubClass;
/*     */       try
/*     */       {
/* 226 */         stubClass = ClassHelper.forNameWithThreadContextClassLoader(this.stub);
/*     */       } catch (ClassNotFoundException e) {
/* 228 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/* 230 */       if (!this.interfaceClass.isAssignableFrom(stubClass)) {
/* 231 */         throw new IllegalStateException("The stub implemention class " + stubClass.getName() + " not implement interface " + this.interfaceName);
/*     */       }
/*     */     }
/* 234 */     checkApplication();
/* 235 */     checkRegistry();
/* 236 */     checkProtocol();
/* 237 */     appendProperties(this);
/* 238 */     checkStubAndMock(this.interfaceClass);
/* 239 */     if ((this.path == null) || (this.path.length() == 0)) {
/* 240 */       this.path = this.interfaceName;
/*     */     }
/* 242 */     doExportUrls();
/*     */   }
/*     */ 
/*     */   private void checkRef()
/*     */   {
/* 247 */     if (this.ref == null) {
/* 248 */       throw new IllegalStateException("ref not allow null!");
/*     */     }
/* 250 */     if (!this.interfaceClass.isInstance(this.ref))
/* 251 */       throw new IllegalStateException("The class " + this.ref.getClass().getName() + " unimplemented interface " + this.interfaceClass + "!");
/*     */   }
/*     */ 
/*     */   public synchronized void unexport()
/*     */   {
/* 258 */     if (!this.exported) {
/* 259 */       return;
/*     */     }
/* 261 */     if (this.unexported) {
/* 262 */       return;
/*     */     }
/* 264 */     if ((this.exporters != null) && (this.exporters.size() > 0)) {
/* 265 */       for (Exporter exporter : this.exporters) {
/*     */         try {
/* 267 */           exporter.unexport();
/*     */         } catch (Throwable t) {
/* 269 */           logger.warn("unexpected err when unexport" + exporter, t);
/*     */         }
/*     */       }
/* 272 */       this.exporters.clear();
/*     */     }
/* 274 */     this.unexported = true;
/*     */   }
/*     */ 
/*     */   private void doExportUrls()
/*     */   {
/* 279 */     List registryURLs = loadRegistries(true);
/* 280 */     for (ProtocolConfig protocolConfig : this.protocols)
/* 281 */       doExportUrlsFor1Protocol(protocolConfig, registryURLs);
/*     */   }
/*     */ 
/*     */   private void doExportUrlsFor1Protocol(ProtocolConfig protocolConfig, List<URL> registryURLs)
/*     */   {
/* 286 */     String name = protocolConfig.getName();
/* 287 */     if ((name == null) || (name.length() == 0)) {
/* 288 */       name = "dubbo";
/*     */     }
/*     */ 
/* 291 */     String host = protocolConfig.getHost();
/* 292 */     if ((this.provider != null) && ((host == null) || (host.length() == 0))) {
/* 293 */       host = this.provider.getHost();
/*     */     }
/* 295 */     boolean anyhost = false;
/* 296 */     if (NetUtils.isInvalidLocalHost(host)) {
/* 297 */       anyhost = true;
/*     */       try {
/* 299 */         host = InetAddress.getLocalHost().getHostAddress();
/*     */       } catch (UnknownHostException e) {
/* 301 */         logger.warn(e.getMessage(), e);
/*     */       }
/* 303 */       if (NetUtils.isInvalidLocalHost(host)) {
/* 304 */         if ((registryURLs != null) && (registryURLs.size() > 0)) {
/* 305 */           for (URL registryURL : registryURLs) {
/*     */             try {
/* 307 */               Socket socket = new Socket();
/*     */               try {
/* 309 */                 SocketAddress addr = new InetSocketAddress(registryURL.getHost(), registryURL.getPort());
/* 310 */                 socket.connect(addr, 1000);
/* 311 */                 host = socket.getLocalAddress().getHostAddress();
/*     */               }
/*     */               finally {
/*     */                 try {
/* 315 */                   socket.close(); } catch (Throwable e) {
/*     */                 }
/*     */               }
/*     */             } catch (Exception e) {
/* 319 */               logger.warn(e.getMessage(), e);
/*     */             }
/*     */           }
/*     */         }
/* 323 */         if (NetUtils.isInvalidLocalHost(host)) {
/* 324 */           host = NetUtils.getLocalHost();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 329 */     Integer port = protocolConfig.getPort();
/* 330 */     if ((this.provider != null) && ((port == null) || (port.intValue() == 0))) {
/* 331 */       port = this.provider.getPort();
/*     */     }
/* 333 */     int defaultPort = ((Protocol)ExtensionLoader.getExtensionLoader(Protocol.class).getExtension(name)).getDefaultPort();
/* 334 */     if ((port == null) || (port.intValue() == 0)) {
/* 335 */       port = Integer.valueOf(defaultPort);
/*     */     }
/* 337 */     if ((port == null) || (port.intValue() <= 0)) {
/* 338 */       port = getRandomPort(name);
/* 339 */       if ((port == null) || (port.intValue() < 0)) {
/* 340 */         port = Integer.valueOf(NetUtils.getAvailablePort(defaultPort));
/* 341 */         putRandomPort(name, port);
/*     */       }
/* 343 */       logger.warn("Use random available port(" + port + ") for protocol " + name);
/*     */     }
/*     */ 
/* 346 */     Map map = new HashMap();
/* 347 */     if (anyhost) {
/* 348 */       map.put("anyhost", "true");
/*     */     }
/* 350 */     map.put("side", "provider");
/* 351 */     map.put("dubbo", Version.getVersion());
/* 352 */     map.put("timestamp", String.valueOf(System.currentTimeMillis()));
/* 353 */     if (ConfigUtils.getPid() > 0) {
/* 354 */       map.put("pid", String.valueOf(ConfigUtils.getPid()));
/*     */     }
/* 356 */     appendParameters(map, this.application);
/* 357 */     appendParameters(map, this.module);
/* 358 */     appendParameters(map, this.provider, "default");
/* 359 */     appendParameters(map, protocolConfig);
/* 360 */     appendParameters(map, this);
/*     */     Iterator i$;
/* 361 */     if ((this.methods != null) && (this.methods.size() > 0))
/* 362 */       for (i$ = this.methods.iterator(); i$.hasNext(); ) { method = (MethodConfig)i$.next();
/* 363 */         appendParameters(map, method, method.getName());
/* 364 */         String retryKey = method.getName() + ".retry";
/* 365 */         if (map.containsKey(retryKey)) {
/* 366 */           String retryValue = (String)map.remove(retryKey);
/* 367 */           if ("false".equals(retryValue)) {
/* 368 */             map.put(method.getName() + ".retries", "0");
/*     */           }
/*     */         }
/* 371 */         List arguments = method.getArguments();
/* 372 */         if ((arguments != null) && (arguments.size() > 0))
/* 373 */           for (ArgumentConfig argument : arguments)
/*     */           {
/* 375 */             if ((argument.getType() != null) && (argument.getType().length() > 0)) {
/* 376 */               Method[] methods = this.interfaceClass.getMethods();
/*     */ 
/* 378 */               if ((methods != null) && (methods.length > 0)) {
/* 379 */                 for (int i = 0; i < methods.length; i++) {
/* 380 */                   String methodName = methods[i].getName();
/*     */ 
/* 382 */                   if (methodName.equals(method.getName())) {
/* 383 */                     Class[] argtypes = methods[i].getParameterTypes();
/*     */ 
/* 385 */                     if (argument.getIndex().intValue() != -1) {
/* 386 */                       if (argtypes[argument.getIndex().intValue()].getName().equals(argument.getType()))
/* 387 */                         appendParameters(map, argument, method.getName() + "." + argument.getIndex());
/*     */                       else {
/* 389 */                         throw new IllegalArgumentException("argument config error : the index attribute and type attirbute not match :index :" + argument.getIndex() + ", type:" + argument.getType());
/*     */                       }
/*     */                     }
/*     */                     else {
/* 393 */                       for (int j = 0; j < argtypes.length; j++) {
/* 394 */                         Class argclazz = argtypes[j];
/* 395 */                         if (argclazz.getName().equals(argument.getType())) {
/* 396 */                           appendParameters(map, argument, method.getName() + "." + j);
/* 397 */                           if ((argument.getIndex().intValue() != -1) && (argument.getIndex().intValue() != j))
/* 398 */                             throw new IllegalArgumentException("argument config error : the index attribute and type attirbute not match :index :" + argument.getIndex() + ", type:" + argument.getType());
/*     */                         }
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/* 406 */             else if (argument.getIndex().intValue() != -1) {
/* 407 */               appendParameters(map, argument, method.getName() + "." + argument.getIndex());
/*     */             } else {
/* 409 */               throw new IllegalArgumentException("argument config must set index or type attribute.eg: <dubbo:argument index='0' .../> or <dubbo:argument type=xxx .../>");
/*     */             }
/*     */           }
/*     */       }
/*     */     MethodConfig method;
/* 417 */     if (this.generic) {
/* 418 */       map.put("generic", String.valueOf(true));
/* 419 */       map.put("methods", "*");
/*     */     } else {
/* 421 */       String revision = Version.getVersion(this.interfaceClass, this.version);
/* 422 */       if ((revision != null) && (revision.length() > 0)) {
/* 423 */         map.put("revision", revision);
/*     */       }
/*     */ 
/* 426 */       String[] methods = Wrapper.getWrapper(this.interfaceClass).getMethodNames();
/* 427 */       if (methods.length == 0) {
/* 428 */         logger.warn("NO method found in service interface " + this.interfaceClass.getName());
/* 429 */         map.put("methods", "*");
/*     */       }
/*     */       else {
/* 432 */         map.put("methods", StringUtils.join(new HashSet(Arrays.asList(methods)), ","));
/*     */       }
/*     */     }
/* 435 */     if (!ConfigUtils.isEmpty(this.token)) {
/* 436 */       if (ConfigUtils.isDefault(this.token))
/* 437 */         map.put("token", UUID.randomUUID().toString());
/*     */       else {
/* 439 */         map.put("token", this.token);
/*     */       }
/*     */     }
/* 442 */     if ("injvm".equals(protocolConfig.getName())) {
/* 443 */       protocolConfig.setRegister(Boolean.valueOf(false));
/* 444 */       map.put("notify", "false");
/*     */     }
/*     */ 
/* 447 */     String contextPath = protocolConfig.getContextpath();
/* 448 */     if (((contextPath == null) || (contextPath.length() == 0)) && (this.provider != null)) {
/* 449 */       contextPath = this.provider.getContextpath();
/*     */     }
/* 451 */     URL url = new URL(name, host, port.intValue(), ((contextPath == null) || (contextPath.length() == 0) ? "" : new StringBuilder().append(contextPath).append("/").toString()) + this.path, map);
/*     */ 
/* 453 */     if (ExtensionLoader.getExtensionLoader(ConfiguratorFactory.class).hasExtension(url.getProtocol()))
/*     */     {
/* 455 */       url = ((ConfiguratorFactory)ExtensionLoader.getExtensionLoader(ConfiguratorFactory.class).getExtension(url.getProtocol())).getConfigurator(url).configure(url);
/*     */     }
/*     */ 
/* 459 */     String scope = url.getParameter("scope");
/*     */ 
/* 461 */     if (!"none".toString().equalsIgnoreCase(scope))
/*     */     {
/* 464 */       if (!"remote".toString().equalsIgnoreCase(scope)) {
/* 465 */         exportLocal(url);
/*     */       }
/*     */ 
/* 468 */       if (!"local".toString().equalsIgnoreCase(scope)) {
/* 469 */         if (logger.isInfoEnabled()) {
/* 470 */           logger.info("Export dubbo service " + this.interfaceClass.getName() + " to url " + url);
/*     */         }
/* 472 */         if ((registryURLs != null) && (registryURLs.size() > 0) && (url.getParameter("register", true)))
/*     */         {
/* 474 */           for (URL registryURL : registryURLs) {
/* 475 */             url = url.addParameterIfAbsent("dynamic", registryURL.getParameter("dynamic"));
/* 476 */             URL monitorUrl = loadMonitor(registryURL);
/* 477 */             if (monitorUrl != null) {
/* 478 */               url = url.addParameterAndEncoded("monitor", monitorUrl.toFullString());
/*     */             }
/* 480 */             if (logger.isInfoEnabled()) {
/* 481 */               logger.info("Register dubbo service " + this.interfaceClass.getName() + " url " + url + " to registry " + registryURL);
/*     */             }
/* 483 */             Invoker invoker = proxyFactory.getInvoker(this.ref, this.interfaceClass, registryURL.addParameterAndEncoded("export", url.toFullString()));
/*     */ 
/* 485 */             Exporter exporter = protocol.export(invoker);
/* 486 */             this.exporters.add(exporter);
/*     */           }
/*     */         } else {
/* 489 */           Invoker invoker = proxyFactory.getInvoker(this.ref, this.interfaceClass, url);
/*     */ 
/* 491 */           Exporter exporter = protocol.export(invoker);
/* 492 */           this.exporters.add(exporter);
/*     */         }
/*     */       }
/*     */     }
/* 496 */     this.urls.add(url);
/*     */   }
/*     */ 
/*     */   private void exportLocal(URL url)
/*     */   {
/* 502 */     if (!"injvm".equalsIgnoreCase(url.getProtocol())) {
/* 503 */       URL local = URL.valueOf(url.toFullString()).setProtocol("injvm").setHost("127.0.0.1").setPort(0);
/*     */ 
/* 507 */       Exporter exporter = protocol.export(proxyFactory.getInvoker(this.ref, this.interfaceClass, local));
/*     */ 
/* 509 */       this.exporters.add(exporter);
/* 510 */       logger.info("Export dubbo service " + this.interfaceClass.getName() + " to local registry");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkDefault() {
/* 515 */     if (this.provider == null) {
/* 516 */       this.provider = new ProviderConfig();
/*     */     }
/* 518 */     appendProperties(this.provider);
/*     */   }
/*     */ 
/*     */   private void checkProtocol() {
/* 522 */     if (((this.protocols == null) || (this.protocols.size() == 0)) && (this.provider != null))
/*     */     {
/* 524 */       setProtocols(this.provider.getProtocols());
/*     */     }
/*     */ 
/* 527 */     if ((this.protocols == null) || (this.protocols.size() == 0)) {
/* 528 */       setProtocol(new ProtocolConfig());
/*     */     }
/* 530 */     for (ProtocolConfig protocolConfig : this.protocols) {
/* 531 */       if (StringUtils.isEmpty(protocolConfig.getName())) {
/* 532 */         protocolConfig.setName("dubbo");
/*     */       }
/* 534 */       appendProperties(protocolConfig);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<?> getInterfaceClass() {
/* 539 */     if (this.interfaceClass != null) {
/* 540 */       return this.interfaceClass;
/*     */     }
/* 542 */     if ((this.ref instanceof GenericService))
/* 543 */       return GenericService.class;
/*     */     try
/*     */     {
/* 546 */       if ((this.interfaceName != null) && (this.interfaceName.length() > 0))
/* 547 */         this.interfaceClass = Class.forName(this.interfaceName, true, Thread.currentThread().getContextClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException t)
/*     */     {
/* 551 */       throw new IllegalStateException(t.getMessage(), t);
/*     */     }
/* 553 */     return this.interfaceClass;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setInterfaceClass(Class<?> interfaceClass)
/*     */   {
/* 562 */     setInterface(interfaceClass);
/*     */   }
/*     */ 
/*     */   public String getInterface() {
/* 566 */     return this.interfaceName;
/*     */   }
/*     */ 
/*     */   public void setInterface(String interfaceName) {
/* 570 */     this.interfaceName = interfaceName;
/* 571 */     if ((this.id == null) || (this.id.length() == 0))
/* 572 */       this.id = interfaceName;
/*     */   }
/*     */ 
/*     */   public void setInterface(Class<?> interfaceClass)
/*     */   {
/* 577 */     if ((interfaceClass != null) && (!interfaceClass.isInterface())) {
/* 578 */       throw new IllegalStateException("The interface class " + interfaceClass + " is not a interface!");
/*     */     }
/* 580 */     this.interfaceClass = interfaceClass;
/* 581 */     setInterface(interfaceClass == null ? (String)null : interfaceClass.getName());
/*     */   }
/*     */ 
/*     */   public T getRef() {
/* 585 */     return this.ref;
/*     */   }
/*     */ 
/*     */   public void setRef(T ref) {
/* 589 */     this.ref = ref;
/*     */   }
/*     */ 
/*     */   @Parameter(excluded=true)
/*     */   public String getPath() {
/* 594 */     return this.path;
/*     */   }
/*     */ 
/*     */   public void setPath(String path) {
/* 598 */     checkPathName("path", path);
/* 599 */     this.path = path;
/*     */   }
/*     */ 
/*     */   public List<MethodConfig> getMethods() {
/* 603 */     return this.methods;
/*     */   }
/*     */ 
/*     */   public void setMethods(List<? extends MethodConfig> methods)
/*     */   {
/* 608 */     this.methods = methods;
/*     */   }
/*     */ 
/*     */   public ProviderConfig getProvider() {
/* 612 */     return this.provider;
/*     */   }
/*     */ 
/*     */   public void setProvider(ProviderConfig provider) {
/* 616 */     this.provider = provider;
/*     */   }
/*     */ 
/*     */   public List<URL> getExportedUrls() {
/* 620 */     return this.urls;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public List<ProviderConfig> getProviders()
/*     */   {
/* 630 */     return convertProtocolToProvider(this.protocols);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setProviders(List<ProviderConfig> providers)
/*     */   {
/* 638 */     this.protocols = convertProviderToProtocol(providers);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private static final List<ProtocolConfig> convertProviderToProtocol(List<ProviderConfig> providers) {
/* 643 */     if ((providers == null) || (providers.size() == 0)) {
/* 644 */       return null;
/*     */     }
/* 646 */     List protocols = new ArrayList(providers.size());
/* 647 */     for (ProviderConfig provider : providers) {
/* 648 */       protocols.add(convertProviderToProtocol(provider));
/*     */     }
/* 650 */     return protocols;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private static final List<ProviderConfig> convertProtocolToProvider(List<ProtocolConfig> protocols) {
/* 655 */     if ((protocols == null) || (protocols.size() == 0)) {
/* 656 */       return null;
/*     */     }
/* 658 */     List providers = new ArrayList(protocols.size());
/* 659 */     for (ProtocolConfig provider : protocols) {
/* 660 */       providers.add(convertProtocolToProvider(provider));
/*     */     }
/* 662 */     return providers;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private static final ProtocolConfig convertProviderToProtocol(ProviderConfig provider) {
/* 667 */     ProtocolConfig protocol = new ProtocolConfig();
/* 668 */     protocol.setName(provider.getProtocol().getName());
/* 669 */     protocol.setServer(provider.getServer());
/* 670 */     protocol.setClient(provider.getClient());
/* 671 */     protocol.setCodec(provider.getCodec());
/* 672 */     protocol.setHost(provider.getHost());
/* 673 */     protocol.setPort(provider.getPort());
/* 674 */     protocol.setPath(provider.getPath());
/* 675 */     protocol.setPayload(provider.getPayload());
/* 676 */     protocol.setThreads(provider.getThreads());
/* 677 */     protocol.setParameters(provider.getParameters());
/* 678 */     return protocol;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private static final ProviderConfig convertProtocolToProvider(ProtocolConfig protocol) {
/* 683 */     ProviderConfig provider = new ProviderConfig();
/* 684 */     provider.setProtocol(protocol);
/* 685 */     provider.setServer(protocol.getServer());
/* 686 */     provider.setClient(protocol.getClient());
/* 687 */     provider.setCodec(protocol.getCodec());
/* 688 */     provider.setHost(protocol.getHost());
/* 689 */     provider.setPort(protocol.getPort());
/* 690 */     provider.setPath(protocol.getPath());
/* 691 */     provider.setPayload(protocol.getPayload());
/* 692 */     provider.setThreads(protocol.getThreads());
/* 693 */     provider.setParameters(protocol.getParameters());
/* 694 */     return provider;
/*     */   }
/*     */ 
/*     */   private static Integer getRandomPort(String protocol) {
/* 698 */     protocol = protocol.toLowerCase();
/* 699 */     if (RANDOM_PORT_MAP.containsKey(protocol)) {
/* 700 */       return (Integer)RANDOM_PORT_MAP.get(protocol);
/*     */     }
/* 702 */     return Integer.valueOf(-2147483648);
/*     */   }
/*     */ 
/*     */   private static void putRandomPort(String protocol, Integer port) {
/* 706 */     protocol = protocol.toLowerCase();
/* 707 */     if (!RANDOM_PORT_MAP.containsKey(protocol))
/* 708 */       RANDOM_PORT_MAP.put(protocol, port);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.ServiceConfig
 * JD-Core Version:    0.6.2
 */