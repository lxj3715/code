package com.alibaba.dubbo.config.support;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.METHOD})
public @interface Parameter
{
  public abstract String key();

  public abstract boolean required();

  public abstract boolean excluded();

  public abstract boolean escaped();

  public abstract boolean attribute();

  public abstract boolean append();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.support.Parameter
 * JD-Core Version:    0.6.2
 */