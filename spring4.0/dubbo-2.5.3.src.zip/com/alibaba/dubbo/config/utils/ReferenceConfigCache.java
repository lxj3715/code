/*     */ package com.alibaba.dubbo.config.utils;
/*     */ 
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.config.ReferenceConfig;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ public class ReferenceConfigCache
/*     */ {
/*     */   public static final String DEFAULT_NAME = "_DEFAULT_";
/*  39 */   static final ConcurrentMap<String, ReferenceConfigCache> cacheHolder = new ConcurrentHashMap();
/*     */ 
/*  79 */   public static final KeyGenerator DEFAULT_KEY_GENERATOR = new KeyGenerator() {
/*     */     public String generateKey(ReferenceConfig<?> referenceConfig) {
/*  81 */       String iName = referenceConfig.getInterface();
/*  82 */       if (StringUtils.isBlank(iName)) {
/*  83 */         Class clazz = referenceConfig.getInterfaceClass();
/*  84 */         iName = clazz.getName();
/*     */       }
/*  86 */       if (StringUtils.isBlank(iName)) {
/*  87 */         throw new IllegalArgumentException("No interface info in ReferenceConfig" + referenceConfig);
/*     */       }
/*     */ 
/*  90 */       StringBuilder ret = new StringBuilder();
/*  91 */       if (!StringUtils.isBlank(referenceConfig.getGroup())) {
/*  92 */         ret.append(referenceConfig.getGroup()).append("/");
/*     */       }
/*  94 */       ret.append(iName);
/*  95 */       if (!StringUtils.isBlank(referenceConfig.getVersion())) {
/*  96 */         ret.append(":").append(referenceConfig.getVersion());
/*     */       }
/*  98 */       return ret.toString();
/*     */     }
/*  79 */   };
/*     */   private final String name;
/*     */   private final KeyGenerator generator;
/* 105 */   ConcurrentMap<String, ReferenceConfig<?>> cache = new ConcurrentHashMap();
/*     */ 
/*     */   public static ReferenceConfigCache getCache()
/*     */   {
/*  46 */     return getCache("_DEFAULT_");
/*     */   }
/*     */ 
/*     */   public static ReferenceConfigCache getCache(String name)
/*     */   {
/*  54 */     return getCache(name, DEFAULT_KEY_GENERATOR);
/*     */   }
/*     */ 
/*     */   public static ReferenceConfigCache getCache(String name, KeyGenerator keyGenerator)
/*     */   {
/*  62 */     ReferenceConfigCache cache = (ReferenceConfigCache)cacheHolder.get(name);
/*  63 */     if (cache != null) {
/*  64 */       return cache;
/*     */     }
/*  66 */     cacheHolder.putIfAbsent(name, new ReferenceConfigCache(name, keyGenerator));
/*  67 */     return (ReferenceConfigCache)cacheHolder.get(name);
/*     */   }
/*     */ 
/*     */   private ReferenceConfigCache(String name, KeyGenerator generator)
/*     */   {
/* 108 */     this.name = name;
/* 109 */     this.generator = generator;
/*     */   }
/*     */ 
/*     */   public <T> T get(ReferenceConfig<T> referenceConfig)
/*     */   {
/* 114 */     String key = this.generator.generateKey(referenceConfig);
/*     */ 
/* 116 */     ReferenceConfig config = (ReferenceConfig)this.cache.get(key);
/* 117 */     if (config != null) {
/* 118 */       return config.get();
/*     */     }
/*     */ 
/* 121 */     this.cache.putIfAbsent(key, referenceConfig);
/* 122 */     config = (ReferenceConfig)this.cache.get(key);
/* 123 */     return config.get();
/*     */   }
/*     */ 
/*     */   void destroyKey(String key) {
/* 127 */     ReferenceConfig config = (ReferenceConfig)this.cache.remove(key);
/* 128 */     if (config == null) return;
/* 129 */     config.destroy();
/*     */   }
/*     */ 
/*     */   public <T> void destroy(ReferenceConfig<T> referenceConfig)
/*     */   {
/* 137 */     String key = this.generator.generateKey(referenceConfig);
/* 138 */     destroyKey(key);
/*     */   }
/*     */ 
/*     */   public void destroyAll()
/*     */   {
/* 145 */     Set set = new HashSet(this.cache.keySet());
/* 146 */     for (String key : set)
/* 147 */       destroyKey(key);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 153 */     return "ReferenceConfigCache(name: " + this.name + ")";
/*     */   }
/*     */ 
/*     */   public static abstract interface KeyGenerator
/*     */   {
/*     */     public abstract String generateKey(ReferenceConfig<?> paramReferenceConfig);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.config.utils.ReferenceConfigCache
 * JD-Core Version:    0.6.2
 */