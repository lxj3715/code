/*    */ package com.alibaba.dubbo.container;
/*    */ 
/*    */ import com.alibaba.dubbo.common.Constants;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*    */ import java.io.PrintStream;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public class Main
/*    */ {
/*    */   public static final String CONTAINER_KEY = "dubbo.container";
/*    */   public static final String SHUTDOWN_HOOK_KEY = "dubbo.shutdown.hook";
/* 41 */   private static final Logger logger = LoggerFactory.getLogger(Main.class);
/*    */ 
/* 43 */   private static final ExtensionLoader<Container> loader = ExtensionLoader.getExtensionLoader(Container.class);
/*    */ 
/* 45 */   private static volatile boolean running = true;
/*    */ 
/*    */   public static void main(String[] args) {
/*    */     try {
/* 49 */       if ((args == null) || (args.length == 0)) {
/* 50 */         String config = ConfigUtils.getProperty("dubbo.container", loader.getDefaultExtensionName());
/* 51 */         args = Constants.COMMA_SPLIT_PATTERN.split(config);
/*    */       }
/*    */ 
/* 54 */       List containers = new ArrayList();
/* 55 */       for (int i = 0; i < args.length; i++) {
/* 56 */         containers.add(loader.getExtension(args[i]));
/*    */       }
/* 58 */       logger.info("Use container type(" + Arrays.toString(args) + ") to run dubbo serivce.");
/*    */ 
/* 60 */       if ("true".equals(System.getProperty("dubbo.shutdown.hook"))) {
/* 61 */         Runtime.getRuntime().addShutdownHook(new Thread() {
/*    */           public void run() {
/* 63 */             for (Container container : this.val$containers) {
/*    */               try {
/* 65 */                 container.stop();
/* 66 */                 Main.logger.info("Dubbo " + container.getClass().getSimpleName() + " stopped!");
/*    */               } catch (Throwable t) {
/* 68 */                 Main.logger.error(t.getMessage(), t);
/*    */               }
/* 70 */               synchronized (Main.class) {
/* 71 */                 Main.access$102(false);
/* 72 */                 Main.class.notify();
/*    */               }
/*    */             }
/*    */           }
/*    */         });
/*    */       }
/*    */ 
/* 79 */       for (Container container : containers) {
/* 80 */         container.start();
/* 81 */         logger.info("Dubbo " + container.getClass().getSimpleName() + " started!");
/*    */       }
/* 83 */       System.out.println(new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss]").format(new Date()) + " Dubbo service server started!");
/*    */     } catch (RuntimeException e) {
/* 85 */       e.printStackTrace();
/* 86 */       logger.error(e.getMessage(), e);
/* 87 */       System.exit(1);
/*    */     }
/* 89 */     synchronized (Main.class) {
/* 90 */       while (running)
/*    */         try {
/* 92 */           Main.class.wait();
/*    */         }
/*    */         catch (Throwable e)
/*    */         {
/*    */         }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.Main
 * JD-Core Version:    0.6.2
 */