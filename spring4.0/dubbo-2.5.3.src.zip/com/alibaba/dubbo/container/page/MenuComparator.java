/*    */ package com.alibaba.dubbo.container.page;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class MenuComparator
/*    */   implements Comparator<PageHandler>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -3161526932904414029L;
/*    */ 
/*    */   public int compare(PageHandler o1, PageHandler o2)
/*    */   {
/* 31 */     if ((o1 == null) && (o2 == null)) {
/* 32 */       return 0;
/*    */     }
/* 34 */     if (o1 == null) {
/* 35 */       return -1;
/*    */     }
/* 37 */     if (o2 == null) {
/* 38 */       return 1;
/*    */     }
/* 40 */     return ((Menu)o1.getClass().getAnnotation(Menu.class)).order() > ((Menu)o2.getClass().getAnnotation(Menu.class)).order() ? 1 : o1.equals(o2) ? 0 : -1;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.page.MenuComparator
 * JD-Core Version:    0.6.2
 */