/*    */ package com.alibaba.dubbo.container.page;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Page
/*    */ {
/*    */   private final String navigation;
/*    */   private final String title;
/*    */   private final List<String> columns;
/*    */   private final List<List<String>> rows;
/*    */ 
/*    */   public Page(String navigation)
/*    */   {
/* 38 */     this(navigation, (String)null, (String[])null, (List)null);
/*    */   }
/*    */ 
/*    */   public Page(String navigation, String title, String column, String row)
/*    */   {
/* 43 */     this(navigation, title, column == null ? null : Arrays.asList(new String[] { column }), row == null ? null : stringToList(row));
/*    */   }
/*    */ 
/*    */   private static List<List<String>> stringToList(String str) {
/* 47 */     List rows = new ArrayList();
/* 48 */     List row = new ArrayList();
/* 49 */     row.add(str);
/* 50 */     rows.add(row);
/* 51 */     return rows;
/*    */   }
/*    */ 
/*    */   public Page(String navigation, String title, String[] columns, List<List<String>> rows)
/*    */   {
/* 56 */     this(navigation, title, columns == null ? null : Arrays.asList(columns), rows);
/*    */   }
/*    */ 
/*    */   public Page(String navigation, String title, List<String> columns, List<List<String>> rows)
/*    */   {
/* 61 */     this.navigation = navigation;
/* 62 */     this.title = title;
/* 63 */     this.columns = columns;
/* 64 */     this.rows = rows;
/*    */   }
/*    */ 
/*    */   public String getNavigation() {
/* 68 */     return this.navigation;
/*    */   }
/*    */ 
/*    */   public String getTitle() {
/* 72 */     return this.title;
/*    */   }
/*    */ 
/*    */   public List<String> getColumns() {
/* 76 */     return this.columns;
/*    */   }
/*    */ 
/*    */   public List<List<String>> getRows() {
/* 80 */     return this.rows;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.page.Page
 * JD-Core Version:    0.6.2
 */