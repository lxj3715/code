/*     */ package com.alibaba.dubbo.container.page;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class PageServlet extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = -8370312705453328501L;
/*  50 */   protected static final Logger logger = LoggerFactory.getLogger(PageServlet.class);
/*     */ 
/*  52 */   protected final Random random = new Random();
/*     */ 
/*  54 */   protected final Map<String, PageHandler> pages = new ConcurrentHashMap();
/*     */ 
/*  56 */   protected final List<PageHandler> menus = new ArrayList();
/*     */   private static PageServlet INSTANCE;
/*     */ 
/*     */   public static PageServlet getInstance()
/*     */   {
/*  61 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public List<PageHandler> getMenus() {
/*  65 */     return Collections.unmodifiableList(this.menus);
/*     */   }
/*     */ 
/*     */   public void init() throws ServletException
/*     */   {
/*  70 */     super.init();
/*  71 */     INSTANCE = this;
/*  72 */     String config = getServletConfig().getInitParameter("pages");
/*     */     Collection names;
/*     */     Collection names;
/*  74 */     if ((config != null) && (config.length() > 0))
/*  75 */       names = Arrays.asList(Constants.COMMA_SPLIT_PATTERN.split(config));
/*     */     else {
/*  77 */       names = ExtensionLoader.getExtensionLoader(PageHandler.class).getSupportedExtensions();
/*     */     }
/*  79 */     for (String name : names) {
/*  80 */       PageHandler handler = (PageHandler)ExtensionLoader.getExtensionLoader(PageHandler.class).getExtension(name);
/*  81 */       this.pages.put(ExtensionLoader.getExtensionLoader(PageHandler.class).getExtensionName(handler), handler);
/*  82 */       Menu menu = (Menu)handler.getClass().getAnnotation(Menu.class);
/*  83 */       if (menu != null) {
/*  84 */         this.menus.add(handler);
/*     */       }
/*     */     }
/*  87 */     Collections.sort(this.menus, new MenuComparator());
/*     */   }
/*     */ 
/*     */   protected final void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  93 */     doPost(request, response);
/*     */   }
/*     */ 
/*     */   protected final void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  99 */     if (!response.isCommitted()) {
/* 100 */       PrintWriter writer = response.getWriter();
/* 101 */       String uri = request.getRequestURI();
/* 102 */       boolean isHtml = false;
/* 103 */       if ((uri == null) || (uri.length() == 0) || ("/".equals(uri))) {
/* 104 */         uri = "index";
/* 105 */         isHtml = true;
/*     */       } else {
/* 107 */         if (uri.startsWith("/")) {
/* 108 */           uri = uri.substring(1);
/*     */         }
/* 110 */         if (uri.endsWith(".html")) {
/* 111 */           uri = uri.substring(0, uri.length() - ".html".length());
/* 112 */           isHtml = true;
/*     */         }
/*     */       }
/* 115 */       if (uri.endsWith("favicon.ico")) {
/* 116 */         response.sendError(404);
/* 117 */         return;
/*     */       }
/* 119 */       ExtensionLoader pageHandlerLoader = ExtensionLoader.getExtensionLoader(PageHandler.class);
/* 120 */       PageHandler pageHandler = pageHandlerLoader.hasExtension(uri) ? (PageHandler)pageHandlerLoader.getExtension(uri) : null;
/* 121 */       if (isHtml) {
/* 122 */         writer.println("<html><head><title>Dubbo</title>");
/* 123 */         writer.println("<style type=\"text/css\">html, body {margin: 10;padding: 0;background-color: #6D838C;font-family: Arial, Verdana;font-size: 12px;color: #FFFFFF;text-align: center;vertical-align: middle;word-break: break-all; } table {width: 90%; margin: 0px auto;border-collapse: collapse;border: 8px solid #FFFFFF; } thead tr {background-color: #253c46; } tbody tr {background-color: #8da5af; } th {padding-top: 4px;padding-bottom: 4px;font-size: 14px;height: 20px; } td {margin: 3px;padding: 3px;border: 2px solid #FFFFFF;font-size: 14px;height: 25px; } a {color: #FFFFFF;cursor: pointer;text-decoration: underline; } a:hover {text-decoration: none; }</style>");
/* 124 */         writer.println("</head><body>");
/*     */       }
/* 126 */       if (pageHandler != null) {
/* 127 */         Page page = null;
/*     */         try {
/* 129 */           String query = request.getQueryString();
/* 130 */           page = pageHandler.handle(URL.valueOf(request.getRequestURL().toString() + ((query == null) || (query.length() == 0) ? "" : new StringBuilder().append("?").append(query).toString())));
/*     */         }
/*     */         catch (Throwable t) {
/* 133 */           logger.warn(t.getMessage(), t);
/* 134 */           String msg = t.getMessage();
/* 135 */           if (msg == null) {
/* 136 */             msg = StringUtils.toString(t);
/*     */           }
/* 138 */           if (isHtml) {
/* 139 */             writer.println("<table>");
/* 140 */             writer.println("<thead>");
/* 141 */             writer.println("    <tr>");
/* 142 */             writer.println("        <th>Error</th>");
/* 143 */             writer.println("    </tr>");
/* 144 */             writer.println("</thead>");
/* 145 */             writer.println("<tbody>");
/* 146 */             writer.println("    <tr>");
/* 147 */             writer.println("        <td>");
/* 148 */             writer.println("            " + msg.replace("<", "&lt;").replace(">", "&lt;").replace("\n", "<br/>"));
/* 149 */             writer.println("        </td>");
/* 150 */             writer.println("    </tr>");
/* 151 */             writer.println("</tbody>");
/* 152 */             writer.println("</table>");
/* 153 */             writer.println("<br/>");
/*     */           } else {
/* 155 */             writer.println(msg);
/*     */           }
/*     */         }
/* 158 */         if (page != null) {
/* 159 */           if (isHtml) {
/* 160 */             String nav = page.getNavigation();
/* 161 */             if ((nav == null) || (nav.length() == 0)) {
/* 162 */               nav = ExtensionLoader.getExtensionLoader(PageHandler.class).getExtensionName(pageHandler);
/* 163 */               nav = nav.substring(0, 1).toUpperCase() + nav.substring(1);
/*     */             }
/* 165 */             if (!"index".equals(uri)) {
/* 166 */               nav = "<a href=\"/\">Home</a> &gt; " + nav;
/*     */             }
/* 168 */             writeMenu(request, writer, nav);
/* 169 */             writeTable(writer, page.getTitle(), page.getColumns(), page.getRows());
/*     */           }
/* 172 */           else if ((page.getRows().size() > 0) && (((List)page.getRows().get(0)).size() > 0)) {
/* 173 */             writer.println((String)((List)page.getRows().get(0)).get(0));
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 178 */       else if (isHtml) {
/* 179 */         writer.println("<table>");
/* 180 */         writer.println("<thead>");
/* 181 */         writer.println("    <tr>");
/* 182 */         writer.println("        <th>Error</th>");
/* 183 */         writer.println("    </tr>");
/* 184 */         writer.println("</thead>");
/* 185 */         writer.println("<tbody>");
/* 186 */         writer.println("    <tr>");
/* 187 */         writer.println("        <td>");
/* 188 */         writer.println("            Not found " + uri + " page. Please goto <a href=\"/\">Home</a> page.");
/* 189 */         writer.println("        </td>");
/* 190 */         writer.println("    </tr>");
/* 191 */         writer.println("</tbody>");
/* 192 */         writer.println("</table>");
/* 193 */         writer.println("<br/>");
/*     */       } else {
/* 195 */         writer.println("Not found " + uri + " page.");
/*     */       }
/*     */ 
/* 198 */       if (isHtml) {
/* 199 */         writer.println("</body></html>");
/*     */       }
/* 201 */       writer.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final void writeMenu(HttpServletRequest request, PrintWriter writer, String nav) {
/* 206 */     writer.println("<table>");
/* 207 */     writer.println("<thead>");
/* 208 */     writer.println("    <tr>");
/* 209 */     for (PageHandler handler : this.menus) {
/* 210 */       String uri = ExtensionLoader.getExtensionLoader(PageHandler.class).getExtensionName(handler);
/* 211 */       Menu menu = (Menu)handler.getClass().getAnnotation(Menu.class);
/* 212 */       writer.println("        <th><a href=\"" + uri + ".html\">" + menu.name() + "</a></th>");
/*     */     }
/* 214 */     writer.println("    </tr>");
/* 215 */     writer.println("</thead>");
/* 216 */     writer.println("<tbody>");
/* 217 */     writer.println("    <tr>");
/* 218 */     writer.println("        <td style=\"text-align: left\" colspan=\"" + this.menus.size() + "\">");
/* 219 */     writer.println(nav);
/* 220 */     writer.println("        </td>");
/* 221 */     writer.println("    </tr>");
/* 222 */     writer.println("</tbody>");
/* 223 */     writer.println("</table>");
/* 224 */     writer.println("<br/>");
/*     */   }
/*     */ 
/*     */   protected final void writeTable(PrintWriter writer, String title, List<String> columns, List<List<String>> rows)
/*     */   {
/* 229 */     int n = this.random.nextInt();
/* 230 */     int c = columns == null ? ((List)rows.get(0)).size() : (rows == null) || (rows.size() == 0) ? 0 : columns.size();
/*     */ 
/* 232 */     int r = rows == null ? 0 : rows.size();
/* 233 */     writer.println("<table>");
/* 234 */     writer.println("<thead>");
/* 235 */     writer.println("    <tr>");
/* 236 */     writer.println("        <th colspan=\"" + c + "\">" + title + "</th>");
/* 237 */     writer.println("    </tr>");
/* 238 */     if ((columns != null) && (columns.size() > 0)) {
/* 239 */       writer.println("    <tr>");
/* 240 */       for (int i = 0; i < columns.size(); i++) {
/* 241 */         String col = (String)columns.get(i);
/* 242 */         if (col.endsWith(":")) {
/* 243 */           col = col + " <input type=\"text\" id=\"in_" + n + "_" + i + "\" onkeyup=\"for (var i = 0; i < " + r + "; i ++) { var m = true; for (var j = 0; j < " + columns.size() + "; j ++) { if (document.getElementById('in_" + n + "_' + j)) { var iv = document.getElementById('in_" + n + "_' + j).value; var tv = document.getElementById('td_" + n + "_' + i + '_' + j).innerHTML; if (iv.length > 0 && (tv.length < iv.length || tv.indexOf(iv) == -1)) { m = false; break; } } } document.getElementById('tr_" + n + "_' + i).style.display = (m ? '' : 'none');}\" sytle=\"width: 100%\" />";
/*     */         }
/*     */ 
/* 261 */         writer.println("        <td>" + col + "</td>");
/*     */       }
/* 263 */       writer.println("    </tr>");
/*     */     }
/* 265 */     writer.println("</thead>");
/* 266 */     if ((rows != null) && (rows.size() > 0)) {
/* 267 */       writer.println("<tbody>");
/* 268 */       int i = 0;
/* 269 */       for (Collection row : rows) {
/* 270 */         writer.println("    <tr id=\"tr_" + n + "_" + i + "\">");
/* 271 */         int j = 0;
/* 272 */         for (String col : row) {
/* 273 */           writer.println("        <td id=\"td_" + n + "_" + i + "_" + j + "\" style=\"display: ;\">" + col + "</td>");
/*     */ 
/* 275 */           j++;
/*     */         }
/* 277 */         writer.println("    </tr>");
/* 278 */         i++;
/*     */       }
/* 280 */       writer.println("</tbody>");
/*     */     }
/* 282 */     writer.println("</table>");
/* 283 */     writer.println("<br/>");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.page.PageServlet
 * JD-Core Version:    0.6.2
 */