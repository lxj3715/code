/*     */ package com.alibaba.dubbo.container.page;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class ResourceFilter
/*     */   implements Filter
/*     */ {
/*     */   private static final String CLASSPATH_PREFIX = "classpath:";
/*  48 */   private final long start = System.currentTimeMillis();
/*     */ 
/*  50 */   private final List<String> resources = new ArrayList();
/*     */ 
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/*  53 */     String config = filterConfig.getInitParameter("resources");
/*  54 */     if ((config != null) && (config.length() > 0)) {
/*  55 */       String[] configs = Constants.COMMA_SPLIT_PATTERN.split(config);
/*  56 */       for (String c : configs)
/*  57 */         if ((c != null) && (c.length() > 0)) {
/*  58 */           c = c.replace('\\', '/');
/*  59 */           if (c.endsWith("/")) {
/*  60 */             c = c.substring(0, c.length() - 1);
/*     */           }
/*  62 */           this.resources.add(c);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException
/*     */   {
/*  73 */     HttpServletRequest request = (HttpServletRequest)req;
/*  74 */     HttpServletResponse response = (HttpServletResponse)res;
/*  75 */     if (response.isCommitted()) {
/*  76 */       return;
/*     */     }
/*  78 */     String uri = request.getRequestURI();
/*  79 */     String context = request.getContextPath();
/*  80 */     if (uri.endsWith("/favicon.ico"))
/*  81 */       uri = "/favicon.ico";
/*  82 */     else if ((context != null) && (!"/".equals(context))) {
/*  83 */       uri = uri.substring(context.length());
/*     */     }
/*  85 */     if (!uri.startsWith("/")) {
/*  86 */       uri = "/" + uri;
/*     */     }
/*  88 */     long lastModified = getLastModified(uri);
/*  89 */     long since = request.getDateHeader("If-Modified-Since");
/*  90 */     if (since >= lastModified) {
/*  91 */       response.sendError(304);
/*  92 */       return;
/*     */     }
/*     */ 
/*  95 */     InputStream input = getInputStream(uri);
/*  96 */     if (input == null) { chain.doFilter(req, res);
/*     */       return; }
/*     */     byte[] data;
/*     */     try {
/* 101 */       ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 102 */       byte[] buffer = new byte[8192];
/* 103 */       int n = 0;
/* 104 */       while (-1 != (n = input.read(buffer))) {
/* 105 */         output.write(buffer, 0, n);
/*     */       }
/* 107 */       data = output.toByteArray();
/*     */     } finally {
/* 109 */       input.close();
/*     */     }
/* 111 */     response.setDateHeader("Last-Modified", lastModified);
/* 112 */     OutputStream output = response.getOutputStream();
/* 113 */     output.write(data);
/* 114 */     output.flush();
/*     */   }
/*     */ 
/*     */   private boolean isFile(String path) {
/* 118 */     return (path.startsWith("/")) || (path.indexOf(":") <= 1);
/*     */   }
/*     */ 
/*     */   private long getLastModified(String uri) {
/* 122 */     for (String resource : this.resources) {
/* 123 */       if ((resource != null) && (resource.length() > 0)) {
/* 124 */         String path = resource + uri;
/* 125 */         if (isFile(path)) {
/* 126 */           File file = new File(path);
/* 127 */           if (file.exists()) {
/* 128 */             return file.lastModified();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 133 */     return this.start;
/*     */   }
/*     */ 
/*     */   private InputStream getInputStream(String uri) {
/* 137 */     for (String resource : this.resources) {
/* 138 */       String path = resource + uri;
/*     */       try {
/* 140 */         if (isFile(path))
/* 141 */           return new FileInputStream(path);
/* 142 */         if (path.startsWith("classpath:")) {
/* 143 */           return Thread.currentThread().getContextClassLoader().getResourceAsStream(path.substring("classpath:".length()));
/*     */         }
/* 145 */         return new URL(path).openStream();
/*     */       }
/*     */       catch (IOException e) {
/*     */       }
/*     */     }
/* 150 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.page.ResourceFilter
 * JD-Core Version:    0.6.2
 */