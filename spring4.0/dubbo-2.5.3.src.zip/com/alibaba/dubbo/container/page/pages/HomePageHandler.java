/*    */ package com.alibaba.dubbo.container.page.pages;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.container.page.Menu;
/*    */ import com.alibaba.dubbo.container.page.Page;
/*    */ import com.alibaba.dubbo.container.page.PageHandler;
/*    */ import com.alibaba.dubbo.container.page.PageServlet;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ @Menu(name="Home", desc="Home page.", order=-2147483648)
/*    */ public class HomePageHandler
/*    */   implements PageHandler
/*    */ {
/*    */   public Page handle(URL url)
/*    */   {
/* 37 */     List rows = new ArrayList();
/* 38 */     for (PageHandler handler : PageServlet.getInstance().getMenus()) {
/* 39 */       String uri = ExtensionLoader.getExtensionLoader(PageHandler.class).getExtensionName(handler);
/* 40 */       Menu menu = (Menu)handler.getClass().getAnnotation(Menu.class);
/* 41 */       List row = new ArrayList();
/* 42 */       row.add("<a href=\"" + uri + ".html\">" + menu.name() + "</a>");
/* 43 */       row.add(menu.desc());
/* 44 */       rows.add(row);
/*    */     }
/* 46 */     return new Page("Home", "Menus", new String[] { "Menu Name", "Menu Desc" }, rows);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.page.pages.HomePageHandler
 * JD-Core Version:    0.6.2
 */