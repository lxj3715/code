/*     */ package com.alibaba.dubbo.container.page.pages;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.container.page.Menu;
/*     */ import com.alibaba.dubbo.container.page.Page;
/*     */ import com.alibaba.dubbo.container.page.PageHandler;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Appender;
/*     */ import org.apache.log4j.FileAppender;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.LogManager;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ @Menu(name="Log", desc="Show system log.", order=2147472647)
/*     */ public class LogPageHandler
/*     */   implements PageHandler
/*     */ {
/*     */   private static final int SHOW_LOG_LENGTH = 30000;
/*     */   private File file;
/*     */ 
/*     */   public LogPageHandler()
/*     */   {
/*     */     try
/*     */     {
/*  54 */       Logger logger = LogManager.getRootLogger();
/*  55 */       if (logger != null) {
/*  56 */         Enumeration appenders = logger.getAllAppenders();
/*  57 */         if (appenders != null)
/*  58 */           while (appenders.hasMoreElements()) {
/*  59 */             Appender appender = (Appender)appenders.nextElement();
/*  60 */             if ((appender instanceof FileAppender)) {
/*  61 */               FileAppender fileAppender = (FileAppender)appender;
/*  62 */               String filename = fileAppender.getFile();
/*  63 */               this.file = new File(filename);
/*  64 */               break;
/*     */             }
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public Page handle(URL url) {
/*  74 */     long size = 0L;
/*  75 */     String content = "";
/*  76 */     String modified = "Not exist";
/*  77 */     if ((this.file != null) && (this.file.exists()))
/*     */       try {
/*  79 */         FileInputStream fis = new FileInputStream(this.file);
/*  80 */         FileChannel channel = fis.getChannel();
/*  81 */         size = channel.size();
/*     */         ByteBuffer bb;
/*  83 */         if (size <= 30000L) {
/*  84 */           ByteBuffer bb = ByteBuffer.allocate((int)size);
/*  85 */           channel.read(bb, 0L);
/*     */         } else {
/*  87 */           int pos = (int)(size - 30000L);
/*  88 */           bb = ByteBuffer.allocate(30000);
/*  89 */           channel.read(bb, pos);
/*     */         }
/*  91 */         bb.flip();
/*  92 */         content = new String(bb.array()).replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br/><br/>");
/*     */ 
/*  94 */         modified = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(this.file.lastModified()));
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*  99 */     Level level = LogManager.getRootLogger().getLevel();
/* 100 */     List rows = new ArrayList();
/* 101 */     List row = new ArrayList();
/* 102 */     row.add(content);
/* 103 */     rows.add(row);
/* 104 */     return new Page("Log", "Log", new String[] { (this.file == null ? "" : this.file.getName()) + ", " + size + " bytes, " + modified + ", " + level }, rows);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.page.pages.LogPageHandler
 * JD-Core Version:    0.6.2
 */