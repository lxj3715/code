/*    */ package com.alibaba.dubbo.container.page.pages;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.common.status.Status;
/*    */ import com.alibaba.dubbo.common.status.Status.Level;
/*    */ import com.alibaba.dubbo.common.status.StatusChecker;
/*    */ import com.alibaba.dubbo.common.status.support.StatusUtils;
/*    */ import com.alibaba.dubbo.container.page.Menu;
/*    */ import com.alibaba.dubbo.container.page.Page;
/*    */ import com.alibaba.dubbo.container.page.PageHandler;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ @Menu(name="Status", desc="Show system status.", order=2147471647)
/*    */ public class StatusPageHandler
/*    */   implements PageHandler
/*    */ {
/*    */   public Page handle(URL url)
/*    */   {
/* 42 */     List rows = new ArrayList();
/* 43 */     Set names = ExtensionLoader.getExtensionLoader(StatusChecker.class).getSupportedExtensions();
/* 44 */     Map statuses = new HashMap();
/* 45 */     for (String name : names) {
/* 46 */       StatusChecker checker = (StatusChecker)ExtensionLoader.getExtensionLoader(StatusChecker.class).getExtension(name);
/* 47 */       List row = new ArrayList();
/* 48 */       row.add(name);
/* 49 */       Status status = checker.check();
/* 50 */       if ((status != null) && (!Status.Level.UNKNOWN.equals(status.getLevel()))) {
/* 51 */         statuses.put(name, status);
/* 52 */         row.add(getLevelHtml(status.getLevel()));
/* 53 */         row.add(status.getMessage());
/* 54 */         rows.add(row);
/*    */       }
/*    */     }
/* 57 */     Status status = StatusUtils.getSummaryStatus(statuses);
/* 58 */     if ("status".equals(url.getPath())) {
/* 59 */       return new Page("", "", "", status.getLevel().toString());
/*    */     }
/* 61 */     List row = new ArrayList();
/* 62 */     row.add("summary");
/* 63 */     row.add(getLevelHtml(status.getLevel()));
/* 64 */     row.add("<a href=\"/status\" target=\"_blank\">summary</a>");
/* 65 */     rows.add(row);
/* 66 */     return new Page("Status (<a href=\"/status\" target=\"_blank\">summary</a>)", "Status", new String[] { "Name", "Status", "Description" }, rows);
/*    */   }
/*    */ 
/*    */   private String getLevelHtml(Status.Level level)
/*    */   {
/* 71 */     return "<font color=\"" + getLevelColor(level) + "\">" + level.name() + "</font>";
/*    */   }
/*    */ 
/*    */   private String getLevelColor(Status.Level level) {
/* 75 */     if (level == Status.Level.OK)
/* 76 */       return "green";
/* 77 */     if (level == Status.Level.ERROR)
/* 78 */       return "red";
/* 79 */     if (level == Status.Level.WARN) {
/* 80 */       return "yellow";
/*    */     }
/* 82 */     return "gray";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.page.pages.StatusPageHandler
 * JD-Core Version:    0.6.2
 */