/*     */ package com.alibaba.dubbo.container.page.pages;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.container.page.Menu;
/*     */ import com.alibaba.dubbo.container.page.Page;
/*     */ import com.alibaba.dubbo.container.page.PageHandler;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.RuntimeMXBean;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ @Menu(name="System", desc="Show system environment information.", order=2147473647)
/*     */ public class SystemPageHandler
/*     */   implements PageHandler
/*     */ {
/*     */   private static final long SECOND = 1000L;
/*     */   private static final long MINUTE = 60000L;
/*     */   private static final long HOUR = 3600000L;
/*     */   private static final long DAY = 86400000L;
/*     */ 
/*     */   public Page handle(URL url)
/*     */   {
/*  41 */     List rows = new ArrayList();
/*     */ 
/*  44 */     List row = new ArrayList();
/*  45 */     row.add("Version");
/*  46 */     row.add(Version.getVersion(SystemPageHandler.class, "2.0.0"));
/*  47 */     rows.add(row);
/*     */ 
/*  49 */     row = new ArrayList();
/*  50 */     row.add("Host");
/*  51 */     String address = NetUtils.getLocalHost();
/*  52 */     row.add(NetUtils.getHostName(address) + "/" + address);
/*  53 */     rows.add(row);
/*     */ 
/*  55 */     row = new ArrayList();
/*  56 */     row.add("OS");
/*  57 */     row.add(System.getProperty("os.name") + " " + System.getProperty("os.version"));
/*  58 */     rows.add(row);
/*     */ 
/*  60 */     row = new ArrayList();
/*  61 */     row.add("JVM");
/*  62 */     row.add(System.getProperty("java.runtime.name") + " " + System.getProperty("java.runtime.version") + ",<br/>" + System.getProperty("java.vm.name") + " " + System.getProperty("java.vm.version") + " " + System.getProperty("java.vm.info", ""));
/*  63 */     rows.add(row);
/*     */ 
/*  65 */     row = new ArrayList();
/*  66 */     row.add("CPU");
/*  67 */     row.add(System.getProperty("os.arch", "") + ", " + String.valueOf(Runtime.getRuntime().availableProcessors()) + " cores");
/*  68 */     rows.add(row);
/*     */ 
/*  70 */     row = new ArrayList();
/*  71 */     row.add("Locale");
/*  72 */     row.add(Locale.getDefault().toString() + "/" + System.getProperty("file.encoding"));
/*  73 */     rows.add(row);
/*     */ 
/*  75 */     row = new ArrayList();
/*  76 */     row.add("Uptime");
/*  77 */     row.add(formatUptime(ManagementFactory.getRuntimeMXBean().getUptime()));
/*  78 */     rows.add(row);
/*     */ 
/*  80 */     row = new ArrayList();
/*  81 */     row.add("Time");
/*  82 */     row.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z").format(new Date()));
/*  83 */     rows.add(row);
/*     */ 
/*  85 */     return new Page("System", "System", new String[] { "Property", "Value" }, rows);
/*     */   }
/*     */ 
/*     */   private String formatUptime(long uptime)
/*     */   {
/*  98 */     StringBuilder buf = new StringBuilder();
/*  99 */     if (uptime > 86400000L) {
/* 100 */       long days = (uptime - uptime % 86400000L) / 86400000L;
/* 101 */       buf.append(days);
/* 102 */       buf.append(" Days");
/* 103 */       uptime %= 86400000L;
/*     */     }
/* 105 */     if (uptime > 3600000L) {
/* 106 */       long hours = (uptime - uptime % 3600000L) / 3600000L;
/* 107 */       if (buf.length() > 0) {
/* 108 */         buf.append(", ");
/*     */       }
/* 110 */       buf.append(hours);
/* 111 */       buf.append(" Hours");
/* 112 */       uptime %= 3600000L;
/*     */     }
/* 114 */     if (uptime > 60000L) {
/* 115 */       long minutes = (uptime - uptime % 60000L) / 60000L;
/* 116 */       if (buf.length() > 0) {
/* 117 */         buf.append(", ");
/*     */       }
/* 119 */       buf.append(minutes);
/* 120 */       buf.append(" Minutes");
/* 121 */       uptime %= 60000L;
/*     */     }
/* 123 */     if (uptime > 1000L) {
/* 124 */       long seconds = (uptime - uptime % 1000L) / 1000L;
/* 125 */       if (buf.length() > 0) {
/* 126 */         buf.append(", ");
/*     */       }
/* 128 */       buf.append(seconds);
/* 129 */       buf.append(" Seconds");
/* 130 */       uptime %= 1000L;
/*     */     }
/* 132 */     if (uptime > 0L) {
/* 133 */       if (buf.length() > 0) {
/* 134 */         buf.append(", ");
/*     */       }
/* 136 */       buf.append(uptime);
/* 137 */       buf.append(" Milliseconds");
/*     */     }
/* 139 */     return buf.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.container.page.pages.SystemPageHandler
 * JD-Core Version:    0.6.2
 */