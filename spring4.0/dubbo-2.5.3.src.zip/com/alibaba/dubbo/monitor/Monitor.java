package com.alibaba.dubbo.monitor;

import com.alibaba.dubbo.common.Node;

public abstract interface Monitor extends Node, MonitorService
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.monitor.Monitor
 * JD-Core Version:    0.6.2
 */