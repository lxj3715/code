package com.alibaba.dubbo.monitor;

import com.alibaba.dubbo.common.URL;
import java.util.List;

public abstract interface MonitorService
{
  public static final String APPLICATION = "application";
  public static final String INTERFACE = "interface";
  public static final String METHOD = "method";
  public static final String GROUP = "group";
  public static final String VERSION = "version";
  public static final String CONSUMER = "consumer";
  public static final String PROVIDER = "provider";
  public static final String TIMESTAMP = "timestamp";
  public static final String SUCCESS = "success";
  public static final String FAILURE = "failure";
  public static final String INPUT = "input";
  public static final String OUTPUT = "output";
  public static final String ELAPSED = "elapsed";
  public static final String CONCURRENT = "concurrent";
  public static final String MAX_INPUT = "max.input";
  public static final String MAX_OUTPUT = "max.output";
  public static final String MAX_ELAPSED = "max.elapsed";
  public static final String MAX_CONCURRENT = "max.concurrent";

  public abstract void collect(URL paramURL);

  public abstract List<URL> lookup(URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.monitor.MonitorService
 * JD-Core Version:    0.6.2
 */