/*    */ package com.alibaba.dubbo.monitor.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.monitor.Monitor;
/*    */ import com.alibaba.dubbo.monitor.MonitorFactory;
/*    */ import com.alibaba.dubbo.monitor.MonitorService;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ public abstract class AbstractMonitorFactory
/*    */   implements MonitorFactory
/*    */ {
/* 38 */   private static final ReentrantLock LOCK = new ReentrantLock();
/*    */ 
/* 41 */   private static final Map<String, Monitor> MONITORS = new ConcurrentHashMap();
/*    */ 
/*    */   public static Collection<Monitor> getMonitors() {
/* 44 */     return Collections.unmodifiableCollection(MONITORS.values());
/*    */   }
/*    */ 
/*    */   public Monitor getMonitor(URL url) {
/* 48 */     url = url.setPath(MonitorService.class.getName()).addParameter("interface", MonitorService.class.getName());
/* 49 */     String key = url.toServiceString();
/* 50 */     LOCK.lock();
/*    */     try {
/* 52 */       Monitor monitor = (Monitor)MONITORS.get(key);
/*    */       Monitor localMonitor1;
/* 53 */       if (monitor != null) {
/* 54 */         return monitor;
/*    */       }
/* 56 */       monitor = createMonitor(url);
/* 57 */       if (monitor == null) {
/* 58 */         throw new IllegalStateException("Can not create monitor " + url);
/*    */       }
/* 60 */       MONITORS.put(key, monitor);
/* 61 */       return monitor;
/*    */     }
/*    */     finally {
/* 64 */       LOCK.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract Monitor createMonitor(URL paramURL);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.monitor.support.AbstractMonitorFactory
 * JD-Core Version:    0.6.2
 */