/*     */ package com.alibaba.dubbo.monitor.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.Activate;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.monitor.Monitor;
/*     */ import com.alibaba.dubbo.monitor.MonitorFactory;
/*     */ import com.alibaba.dubbo.rpc.Filter;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcContext;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.support.RpcUtils;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ @Activate(group={"provider", "consumer"})
/*     */ public class MonitorFilter
/*     */   implements Filter
/*     */ {
/*  48 */   private static final Logger logger = LoggerFactory.getLogger(MonitorFilter.class);
/*     */ 
/*  50 */   private final ConcurrentMap<String, AtomicInteger> concurrents = new ConcurrentHashMap();
/*     */   private MonitorFactory monitorFactory;
/*     */ 
/*     */   public void setMonitorFactory(MonitorFactory monitorFactory)
/*     */   {
/*  55 */     this.monitorFactory = monitorFactory;
/*     */   }
/*     */ 
/*     */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException
/*     */   {
/*  60 */     if (invoker.getUrl().hasParameter("monitor")) {
/*  61 */       RpcContext context = RpcContext.getContext();
/*  62 */       long start = System.currentTimeMillis();
/*  63 */       getConcurrent(invoker, invocation).incrementAndGet();
/*     */       try {
/*  65 */         Result result = invoker.invoke(invocation);
/*  66 */         collect(invoker, invocation, result, context, start, false);
/*  67 */         return result;
/*     */       } catch (RpcException e) {
/*  69 */         collect(invoker, invocation, null, context, start, true);
/*  70 */         throw e;
/*     */       } finally {
/*  72 */         getConcurrent(invoker, invocation).decrementAndGet();
/*     */       }
/*     */     }
/*  75 */     return invoker.invoke(invocation);
/*     */   }
/*     */ 
/*     */   private void collect(Invoker<?> invoker, Invocation invocation, Result result, RpcContext context, long start, boolean error)
/*     */   {
/*     */     try
/*     */     {
/*  83 */       long elapsed = System.currentTimeMillis() - start;
/*  84 */       int concurrent = getConcurrent(invoker, invocation).get();
/*  85 */       String application = invoker.getUrl().getParameter("application");
/*  86 */       String service = invoker.getInterface().getName();
/*  87 */       String method = RpcUtils.getMethodName(invocation);
/*  88 */       URL url = invoker.getUrl().getUrlParameter("monitor");
/*  89 */       Monitor monitor = this.monitorFactory.getMonitor(url);
/*     */       String remoteValue;
/*     */       int localPort;
/*     */       String remoteKey;
/*     */       String remoteValue;
/*  93 */       if ("consumer".equals(invoker.getUrl().getParameter("side")))
/*     */       {
/*  95 */         context = RpcContext.getContext();
/*  96 */         int localPort = 0;
/*  97 */         String remoteKey = "provider";
/*  98 */         remoteValue = invoker.getUrl().getAddress();
/*     */       }
/*     */       else {
/* 101 */         localPort = invoker.getUrl().getPort();
/* 102 */         remoteKey = "consumer";
/* 103 */         remoteValue = context.getRemoteHost();
/*     */       }
/* 105 */       String input = ""; String output = "";
/* 106 */       if (invocation.getAttachment("input") != null) {
/* 107 */         input = invocation.getAttachment("input");
/*     */       }
/* 109 */       if ((result != null) && (result.getAttachment("output") != null)) {
/* 110 */         output = result.getAttachment("output");
/*     */       }
/* 112 */       monitor.collect(new URL("count", NetUtils.getLocalHost(), localPort, service + "/" + method, new String[] { "application", application, "interface", service, "method", method, remoteKey, remoteValue, error ? "failure" : "success", "1", "elapsed", String.valueOf(elapsed), "concurrent", String.valueOf(concurrent), "input", input, "output", output }));
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 125 */       logger.error("Failed to monitor count service " + invoker.getUrl() + ", cause: " + t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private AtomicInteger getConcurrent(Invoker<?> invoker, Invocation invocation)
/*     */   {
/* 131 */     String key = invoker.getInterface().getName() + "." + invocation.getMethodName();
/* 132 */     AtomicInteger concurrent = (AtomicInteger)this.concurrents.get(key);
/* 133 */     if (concurrent == null) {
/* 134 */       this.concurrents.putIfAbsent(key, new AtomicInteger());
/* 135 */       concurrent = (AtomicInteger)this.concurrents.get(key);
/*     */     }
/* 137 */     return concurrent;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.monitor.support.MonitorFilter
 * JD-Core Version:    0.6.2
 */