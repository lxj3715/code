package com.alibaba.dubbo.registry;

import com.alibaba.dubbo.common.URL;
import java.util.List;

public abstract interface NotifyListener
{
  public abstract void notify(List<URL> paramList);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.NotifyListener
 * JD-Core Version:    0.6.2
 */