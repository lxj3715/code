package com.alibaba.dubbo.registry;

import com.alibaba.dubbo.common.Node;

public abstract interface Registry extends Node, RegistryService
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.Registry
 * JD-Core Version:    0.6.2
 */