package com.alibaba.dubbo.registry;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;

@SPI("dubbo")
public abstract interface RegistryFactory
{
  @Adaptive({"protocol"})
  public abstract Registry getRegistry(URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.RegistryFactory
 * JD-Core Version:    0.6.2
 */