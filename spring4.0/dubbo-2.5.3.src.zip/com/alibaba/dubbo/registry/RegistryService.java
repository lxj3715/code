package com.alibaba.dubbo.registry;

import com.alibaba.dubbo.common.URL;
import java.util.List;

public abstract interface RegistryService
{
  public abstract void register(URL paramURL);

  public abstract void unregister(URL paramURL);

  public abstract void subscribe(URL paramURL, NotifyListener paramNotifyListener);

  public abstract void unsubscribe(URL paramURL, NotifyListener paramNotifyListener);

  public abstract List<URL> lookup(URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.RegistryService
 * JD-Core Version:    0.6.2
 */