/*     */ package com.alibaba.dubbo.registry.integration;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.registry.NotifyListener;
/*     */ import com.alibaba.dubbo.registry.Registry;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Protocol;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*     */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*     */ import com.alibaba.dubbo.rpc.cluster.Configurator;
/*     */ import com.alibaba.dubbo.rpc.cluster.ConfiguratorFactory;
/*     */ import com.alibaba.dubbo.rpc.cluster.Router;
/*     */ import com.alibaba.dubbo.rpc.cluster.RouterFactory;
/*     */ import com.alibaba.dubbo.rpc.cluster.directory.AbstractDirectory;
/*     */ import com.alibaba.dubbo.rpc.cluster.directory.StaticDirectory;
/*     */ import com.alibaba.dubbo.rpc.cluster.support.ClusterUtils;
/*     */ import com.alibaba.dubbo.rpc.protocol.InvokerWrapper;
/*     */ import com.alibaba.dubbo.rpc.support.RpcUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class RegistryDirectory<T> extends AbstractDirectory<T>
/*     */   implements NotifyListener
/*     */ {
/*  63 */   private static final Logger logger = LoggerFactory.getLogger(RegistryDirectory.class);
/*     */ 
/*  65 */   private static final Cluster cluster = (Cluster)ExtensionLoader.getExtensionLoader(Cluster.class).getAdaptiveExtension();
/*     */ 
/*  67 */   private static final RouterFactory routerFactory = (RouterFactory)ExtensionLoader.getExtensionLoader(RouterFactory.class).getAdaptiveExtension();
/*     */ 
/*  69 */   private static final ConfiguratorFactory configuratorFactory = (ConfiguratorFactory)ExtensionLoader.getExtensionLoader(ConfiguratorFactory.class).getAdaptiveExtension();
/*     */   private Protocol protocol;
/*     */   private Registry registry;
/*     */   private final String serviceKey;
/*     */   private final Class<T> serviceType;
/*     */   private final Map<String, String> queryMap;
/*     */   private final URL directoryUrl;
/*     */   private final String[] serviceMethods;
/*     */   private final boolean multiGroup;
/*  87 */   private volatile boolean forbidden = false;
/*     */   private volatile URL overrideDirectoryUrl;
/*     */   private volatile List<Configurator> configurators;
/*     */   private volatile Map<String, Invoker<T>> urlInvokerMap;
/*     */   private volatile Map<String, List<Invoker<T>>> methodInvokerMap;
/*     */   private volatile Set<URL> cachedInvokerUrls;
/*     */ 
/*     */   public RegistryDirectory(Class<T> serviceType, URL url)
/*     */   {
/* 108 */     super(url);
/* 109 */     if (serviceType == null)
/* 110 */       throw new IllegalArgumentException("service type is null.");
/* 111 */     if ((url.getServiceKey() == null) || (url.getServiceKey().length() == 0))
/* 112 */       throw new IllegalArgumentException("registry serviceKey is null.");
/* 113 */     this.serviceType = serviceType;
/* 114 */     this.serviceKey = url.getServiceKey();
/* 115 */     this.queryMap = StringUtils.parseQueryString(url.getParameterAndDecoded("refer"));
/* 116 */     this.overrideDirectoryUrl = (this.directoryUrl = url.setPath(url.getServiceInterface()).clearParameters().addParameters(this.queryMap).removeParameter("monitor"));
/* 117 */     String group = this.directoryUrl.getParameter("group", "");
/* 118 */     this.multiGroup = ((group != null) && (("*".equals(group)) || (group.contains(","))));
/* 119 */     String methods = (String)this.queryMap.get("methods");
/* 120 */     this.serviceMethods = (methods == null ? null : Constants.COMMA_SPLIT_PATTERN.split(methods));
/*     */   }
/*     */ 
/*     */   public void setProtocol(Protocol protocol) {
/* 124 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   public void setRegistry(Registry registry) {
/* 128 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */   public void subscribe(URL url) {
/* 132 */     setConsumerUrl(url);
/* 133 */     this.registry.subscribe(url, this);
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 137 */     if (isDestroyed()) {
/* 138 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 142 */       if ((getConsumerUrl() != null) && (this.registry != null) && (this.registry.isAvailable()))
/* 143 */         this.registry.unsubscribe(getConsumerUrl(), this);
/*     */     }
/*     */     catch (Throwable t) {
/* 146 */       logger.warn("unexpeced error when unsubscribe service " + this.serviceKey + "from registry" + this.registry.getUrl(), t);
/*     */     }
/* 148 */     super.destroy();
/*     */     try {
/* 150 */       destroyAllInvokers();
/*     */     } catch (Throwable t) {
/* 152 */       logger.warn("Failed to destroy service " + this.serviceKey, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void notify(List<URL> urls) {
/* 157 */     List invokerUrls = new ArrayList();
/* 158 */     List routerUrls = new ArrayList();
/* 159 */     List configuratorUrls = new ArrayList();
/* 160 */     for (URL url : urls) {
/* 161 */       String protocol = url.getProtocol();
/* 162 */       String category = url.getParameter("category", "providers");
/* 163 */       if (("routers".equals(category)) || ("route".equals(protocol)))
/*     */       {
/* 165 */         routerUrls.add(url);
/* 166 */       } else if (("configurators".equals(category)) || ("override".equals(protocol)))
/*     */       {
/* 168 */         configuratorUrls.add(url);
/* 169 */       } else if ("providers".equals(category))
/* 170 */         invokerUrls.add(url);
/*     */       else {
/* 172 */         logger.warn("Unsupported category " + category + " in notified url: " + url + " from registry " + getUrl().getAddress() + " to consumer " + NetUtils.getLocalHost());
/*     */       }
/*     */     }
/*     */ 
/* 176 */     if ((configuratorUrls != null) && (configuratorUrls.size() > 0)) {
/* 177 */       this.configurators = toConfigurators(configuratorUrls);
/*     */     }
/*     */ 
/* 180 */     if ((routerUrls != null) && (routerUrls.size() > 0)) {
/* 181 */       List routers = toRouters(routerUrls);
/* 182 */       if (routers != null) {
/* 183 */         setRouters(routers);
/*     */       }
/*     */     }
/* 186 */     List localConfigurators = this.configurators;
/*     */ 
/* 188 */     this.overrideDirectoryUrl = this.directoryUrl;
/* 189 */     if ((localConfigurators != null) && (localConfigurators.size() > 0)) {
/* 190 */       for (Configurator configurator : localConfigurators) {
/* 191 */         this.overrideDirectoryUrl = configurator.configure(this.overrideDirectoryUrl);
/*     */       }
/*     */     }
/*     */ 
/* 195 */     refreshInvoker(invokerUrls);
/*     */   }
/*     */ 
/*     */   private void refreshInvoker(List<URL> invokerUrls)
/*     */   {
/* 207 */     if ((invokerUrls != null) && (invokerUrls.size() == 1) && (invokerUrls.get(0) != null) && ("empty".equals(((URL)invokerUrls.get(0)).getProtocol())))
/*     */     {
/* 209 */       this.forbidden = true;
/* 210 */       this.methodInvokerMap = null;
/* 211 */       destroyAllInvokers();
/*     */     } else {
/* 213 */       this.forbidden = false;
/* 214 */       Map oldUrlInvokerMap = this.urlInvokerMap;
/* 215 */       if ((invokerUrls.size() == 0) && (this.cachedInvokerUrls != null)) {
/* 216 */         invokerUrls.addAll(this.cachedInvokerUrls);
/*     */       } else {
/* 218 */         this.cachedInvokerUrls = new HashSet();
/* 219 */         this.cachedInvokerUrls.addAll(invokerUrls);
/*     */       }
/* 221 */       if (invokerUrls.size() == 0) {
/* 222 */         return;
/*     */       }
/* 224 */       Map newUrlInvokerMap = toInvokers(invokerUrls);
/* 225 */       Map newMethodInvokerMap = toMethodInvokers(newUrlInvokerMap);
/*     */ 
/* 228 */       if ((newUrlInvokerMap == null) || (newUrlInvokerMap.size() == 0)) {
/* 229 */         logger.error(new IllegalStateException("urls to invokers error .invokerUrls.size :" + invokerUrls.size() + ", invoker.size :0. urls :" + invokerUrls.toString()));
/* 230 */         return;
/*     */       }
/* 232 */       this.methodInvokerMap = (this.multiGroup ? toMergeMethodInvokerMap(newMethodInvokerMap) : newMethodInvokerMap);
/* 233 */       this.urlInvokerMap = newUrlInvokerMap;
/*     */       try {
/* 235 */         destroyUnusedInvokers(oldUrlInvokerMap, newUrlInvokerMap);
/*     */       } catch (Exception e) {
/* 237 */         logger.warn("destroyUnusedInvokers error. ", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Map<String, List<Invoker<T>>> toMergeMethodInvokerMap(Map<String, List<Invoker<T>>> methodMap) {
/* 243 */     Map result = new HashMap();
/* 244 */     for (Map.Entry entry : methodMap.entrySet()) {
/* 245 */       String method = (String)entry.getKey();
/* 246 */       List invokers = (List)entry.getValue();
/* 247 */       Map groupMap = new HashMap();
/* 248 */       for (Invoker invoker : invokers) {
/* 249 */         String group = invoker.getUrl().getParameter("group", "");
/* 250 */         List groupInvokers = (List)groupMap.get(group);
/* 251 */         if (groupInvokers == null) {
/* 252 */           groupInvokers = new ArrayList();
/* 253 */           groupMap.put(group, groupInvokers);
/*     */         }
/* 255 */         groupInvokers.add(invoker);
/*     */       }
/* 257 */       if (groupMap.size() == 1) {
/* 258 */         result.put(method, groupMap.values().iterator().next());
/* 259 */       } else if (groupMap.size() > 1) {
/* 260 */         List groupInvokers = new ArrayList();
/* 261 */         for (List groupList : groupMap.values()) {
/* 262 */           groupInvokers.add(cluster.join(new StaticDirectory(groupList)));
/*     */         }
/* 264 */         result.put(method, groupInvokers);
/*     */       } else {
/* 266 */         result.put(method, invokers);
/*     */       }
/*     */     }
/* 269 */     return result;
/*     */   }
/*     */ 
/*     */   public static List<Configurator> toConfigurators(List<URL> urls)
/*     */   {
/* 284 */     List configurators = new ArrayList(urls.size());
/* 285 */     if ((urls == null) || (urls.size() == 0)) {
/* 286 */       return configurators;
/*     */     }
/* 288 */     for (URL url : urls) {
/* 289 */       if ("empty".equals(url.getProtocol())) {
/* 290 */         configurators.clear();
/* 291 */         break;
/*     */       }
/* 293 */       Map override = new HashMap(url.getParameters());
/*     */ 
/* 295 */       override.remove("anyhost");
/* 296 */       if (override.size() == 0) {
/* 297 */         configurators.clear();
/*     */       }
/*     */       else
/* 300 */         configurators.add(configuratorFactory.getConfigurator(url));
/*     */     }
/* 302 */     Collections.sort(configurators);
/* 303 */     return configurators;
/*     */   }
/*     */ 
/*     */   private List<Router> toRouters(List<URL> urls)
/*     */   {
/* 313 */     List routers = new ArrayList();
/* 314 */     if ((urls == null) || (urls.size() < 1)) {
/* 315 */       return routers;
/*     */     }
/* 317 */     if ((urls != null) && (urls.size() > 0)) {
/* 318 */       for (URL url : urls)
/* 319 */         if (!"empty".equals(url.getProtocol()))
/*     */         {
/* 322 */           String routerType = url.getParameter("router");
/* 323 */           if ((routerType != null) && (routerType.length() > 0))
/* 324 */             url = url.setProtocol(routerType);
/*     */           try
/*     */           {
/* 327 */             Router router = routerFactory.getRouter(url);
/* 328 */             if (!routers.contains(router))
/* 329 */               routers.add(router);
/*     */           } catch (Throwable t) {
/* 331 */             logger.error("convert router url to router error, url: " + url, t);
/*     */           }
/*     */         }
/*     */     }
/* 335 */     return routers;
/*     */   }
/*     */ 
/*     */   private Map<String, Invoker<T>> toInvokers(List<URL> urls)
/*     */   {
/* 347 */     Map newUrlInvokerMap = new HashMap();
/* 348 */     if ((urls == null) || (urls.size() == 0)) {
/* 349 */       return newUrlInvokerMap;
/*     */     }
/* 351 */     Set keys = new HashSet();
/* 352 */     String queryProtocols = (String)this.queryMap.get("protocol");
/* 353 */     for (URL providerUrl : urls)
/*     */     {
/* 355 */       if ((queryProtocols != null) && (queryProtocols.length() > 0)) {
/* 356 */         boolean accept = false;
/* 357 */         String[] acceptProtocols = queryProtocols.split(",");
/* 358 */         for (String acceptProtocol : acceptProtocols) {
/* 359 */           if (providerUrl.getProtocol().equals(acceptProtocol)) {
/* 360 */             accept = true;
/* 361 */             break;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 364 */         if (!accept);
/*     */       }
/* 368 */       else if (!"empty".equals(providerUrl.getProtocol()))
/*     */       {
/* 371 */         if (!ExtensionLoader.getExtensionLoader(Protocol.class).hasExtension(providerUrl.getProtocol())) {
/* 372 */           logger.error(new IllegalStateException("Unsupported protocol " + providerUrl.getProtocol() + " in notified url: " + providerUrl + " from registry " + getUrl().getAddress() + " to consumer " + NetUtils.getLocalHost() + ", supported protocol: " + ExtensionLoader.getExtensionLoader(Protocol.class).getSupportedExtensions()));
/*     */         }
/*     */         else
/*     */         {
/* 376 */           URL url = mergeUrl(providerUrl);
/*     */ 
/* 378 */           String key = url.toFullString();
/* 379 */           if (!keys.contains(key))
/*     */           {
/* 382 */             keys.add(key);
/*     */ 
/* 384 */             Map localUrlInvokerMap = this.urlInvokerMap;
/* 385 */             Invoker invoker = localUrlInvokerMap == null ? null : (Invoker)localUrlInvokerMap.get(key);
/* 386 */             if (invoker == null) {
/*     */               try {
/* 388 */                 boolean enabled = true;
/* 389 */                 if (url.hasParameter("disabled"))
/* 390 */                   enabled = !url.getParameter("disabled", false);
/*     */                 else {
/* 392 */                   enabled = url.getParameter("enabled", true);
/*     */                 }
/* 394 */                 if (enabled)
/* 395 */                   invoker = new InvokerDelegete(this.protocol.refer(this.serviceType, url), url, providerUrl);
/*     */               }
/*     */               catch (Throwable t) {
/* 398 */                 logger.error("Failed to refer invoker for interface:" + this.serviceType + ",url:(" + url + ")" + t.getMessage(), t);
/*     */               }
/* 400 */               if (invoker != null)
/* 401 */                 newUrlInvokerMap.put(key, invoker);
/*     */             }
/*     */             else {
/* 404 */               newUrlInvokerMap.put(key, invoker);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 407 */     keys.clear();
/* 408 */     return newUrlInvokerMap;
/*     */   }
/*     */ 
/*     */   private URL mergeUrl(URL providerUrl)
/*     */   {
/* 418 */     providerUrl = ClusterUtils.mergeUrl(providerUrl, this.queryMap);
/*     */ 
/* 420 */     List localConfigurators = this.configurators;
/* 421 */     if ((localConfigurators != null) && (localConfigurators.size() > 0)) {
/* 422 */       for (Configurator configurator : localConfigurators) {
/* 423 */         providerUrl = configurator.configure(providerUrl);
/*     */       }
/*     */     }
/*     */ 
/* 427 */     providerUrl = providerUrl.addParameter("check", String.valueOf(false));
/*     */ 
/* 430 */     this.overrideDirectoryUrl = this.overrideDirectoryUrl.addParametersIfAbsent(providerUrl.getParameters());
/*     */ 
/* 432 */     if (((providerUrl.getPath() == null) || (providerUrl.getPath().length() == 0)) && ("dubbo".equals(providerUrl.getProtocol())))
/*     */     {
/* 435 */       String path = this.directoryUrl.getParameter("interface");
/* 436 */       if (path != null) {
/* 437 */         int i = path.indexOf('/');
/* 438 */         if (i >= 0) {
/* 439 */           path = path.substring(i + 1);
/*     */         }
/* 441 */         i = path.lastIndexOf(':');
/* 442 */         if (i >= 0) {
/* 443 */           path = path.substring(0, i);
/*     */         }
/* 445 */         providerUrl = providerUrl.setPath(path);
/*     */       }
/*     */     }
/* 448 */     return providerUrl;
/*     */   }
/*     */ 
/*     */   private List<Invoker<T>> route(List<Invoker<T>> invokers, String method) {
/* 452 */     Invocation invocation = new RpcInvocation(method, new Class[0], new Object[0]);
/* 453 */     List routers = getRouters();
/* 454 */     if (routers != null) {
/* 455 */       for (Router router : routers) {
/* 456 */         if ((router.getUrl() != null) && (!router.getUrl().getParameter("runtime", true))) {
/* 457 */           invokers = router.route(invokers, getConsumerUrl(), invocation);
/*     */         }
/*     */       }
/*     */     }
/* 461 */     return invokers;
/*     */   }
/*     */ 
/*     */   private Map<String, List<Invoker<T>>> toMethodInvokers(Map<String, Invoker<T>> invokersMap)
/*     */   {
/* 471 */     Map newMethodInvokerMap = new HashMap();
/*     */ 
/* 473 */     List invokersList = new ArrayList();
/* 474 */     if ((invokersMap != null) && (invokersMap.size() > 0)) {
/* 475 */       for (Invoker invoker : invokersMap.values()) {
/* 476 */         String parameter = invoker.getUrl().getParameter("methods");
/* 477 */         if ((parameter != null) && (parameter.length() > 0)) {
/* 478 */           String[] methods = Constants.COMMA_SPLIT_PATTERN.split(parameter);
/* 479 */           if ((methods != null) && (methods.length > 0)) {
/* 480 */             for (String method : methods) {
/* 481 */               if ((method != null) && (method.length() > 0) && (!"*".equals(method)))
/*     */               {
/* 483 */                 List methodInvokers = (List)newMethodInvokerMap.get(method);
/* 484 */                 if (methodInvokers == null) {
/* 485 */                   methodInvokers = new ArrayList();
/* 486 */                   newMethodInvokerMap.put(method, methodInvokers);
/*     */                 }
/* 488 */                 methodInvokers.add(invoker);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 493 */         invokersList.add(invoker);
/*     */       }
/*     */     }
/* 496 */     newMethodInvokerMap.put("*", invokersList);
/* 497 */     if ((this.serviceMethods != null) && (this.serviceMethods.length > 0)) {
/* 498 */       for (String method : this.serviceMethods) {
/* 499 */         List methodInvokers = (List)newMethodInvokerMap.get(method);
/* 500 */         if ((methodInvokers == null) || (methodInvokers.size() == 0)) {
/* 501 */           methodInvokers = invokersList;
/*     */         }
/* 503 */         newMethodInvokerMap.put(method, route(methodInvokers, method));
/*     */       }
/*     */     }
/*     */ 
/* 507 */     for (String method : new HashSet(newMethodInvokerMap.keySet())) {
/* 508 */       List methodInvokers = (List)newMethodInvokerMap.get(method);
/* 509 */       Collections.sort(methodInvokers, InvokerComparator.getComparator());
/* 510 */       newMethodInvokerMap.put(method, Collections.unmodifiableList(methodInvokers));
/*     */     }
/* 512 */     return Collections.unmodifiableMap(newMethodInvokerMap);
/*     */   }
/*     */ 
/*     */   private void destroyAllInvokers()
/*     */   {
/* 519 */     Map localUrlInvokerMap = this.urlInvokerMap;
/* 520 */     if (localUrlInvokerMap != null) {
/* 521 */       for (Invoker invoker : new ArrayList(localUrlInvokerMap.values())) {
/*     */         try {
/* 523 */           invoker.destroy();
/*     */         } catch (Throwable t) {
/* 525 */           logger.warn("Failed to destroy service " + this.serviceKey + " to provider " + invoker.getUrl(), t);
/*     */         }
/*     */       }
/* 528 */       localUrlInvokerMap.clear();
/*     */     }
/* 530 */     this.methodInvokerMap = null;
/*     */   }
/*     */ 
/*     */   private void destroyUnusedInvokers(Map<String, Invoker<T>> oldUrlInvokerMap, Map<String, Invoker<T>> newUrlInvokerMap)
/*     */   {
/* 540 */     if ((newUrlInvokerMap == null) || (newUrlInvokerMap.size() == 0)) {
/* 541 */       destroyAllInvokers();
/* 542 */       return;
/*     */     }
/*     */ 
/* 545 */     List deleted = null;
/*     */     Collection newInvokers;
/* 546 */     if (oldUrlInvokerMap != null) {
/* 547 */       newInvokers = newUrlInvokerMap.values();
/* 548 */       for (Map.Entry entry : oldUrlInvokerMap.entrySet()) {
/* 549 */         if (!newInvokers.contains(entry.getValue())) {
/* 550 */           if (deleted == null) {
/* 551 */             deleted = new ArrayList();
/*     */           }
/* 553 */           deleted.add(entry.getKey());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 558 */     if (deleted != null)
/* 559 */       for (String url : deleted)
/* 560 */         if (url != null) {
/* 561 */           Invoker invoker = (Invoker)oldUrlInvokerMap.remove(url);
/* 562 */           if (invoker != null)
/*     */             try {
/* 564 */               invoker.destroy();
/* 565 */               if (logger.isDebugEnabled())
/* 566 */                 logger.debug("destory invoker[" + invoker.getUrl() + "] success. ");
/*     */             }
/*     */             catch (Exception e) {
/* 569 */               logger.warn("destory invoker[" + invoker.getUrl() + "] faild. " + e.getMessage(), e);
/*     */             }
/*     */         }
/*     */   }
/*     */ 
/*     */   public List<Invoker<T>> doList(Invocation invocation)
/*     */   {
/* 578 */     if (this.forbidden) {
/* 579 */       throw new RpcException(4, "Forbid consumer " + NetUtils.getLocalHost() + " access service " + getInterface().getName() + " from registry " + getUrl().getAddress() + " use dubbo version " + Version.getVersion() + ", Please check registry access list (whitelist/blacklist).");
/*     */     }
/* 581 */     List invokers = null;
/* 582 */     Map localMethodInvokerMap = this.methodInvokerMap;
/* 583 */     if ((localMethodInvokerMap != null) && (localMethodInvokerMap.size() > 0)) {
/* 584 */       String methodName = RpcUtils.getMethodName(invocation);
/* 585 */       Object[] args = RpcUtils.getArguments(invocation);
/* 586 */       if ((args != null) && (args.length > 0) && (args[0] != null) && (((args[0] instanceof String)) || (args[0].getClass().isEnum())))
/*     */       {
/* 588 */         invokers = (List)localMethodInvokerMap.get(methodName + "." + args[0]);
/*     */       }
/* 590 */       if (invokers == null) {
/* 591 */         invokers = (List)localMethodInvokerMap.get(methodName);
/*     */       }
/* 593 */       if (invokers == null) {
/* 594 */         invokers = (List)localMethodInvokerMap.get("*");
/*     */       }
/* 596 */       if (invokers == null) {
/* 597 */         Iterator iterator = localMethodInvokerMap.values().iterator();
/* 598 */         if (iterator.hasNext()) {
/* 599 */           invokers = (List)iterator.next();
/*     */         }
/*     */       }
/*     */     }
/* 603 */     return invokers == null ? new ArrayList(0) : invokers;
/*     */   }
/*     */ 
/*     */   public Class<T> getInterface() {
/* 607 */     return this.serviceType;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/* 611 */     return this.overrideDirectoryUrl;
/*     */   }
/*     */ 
/*     */   public boolean isAvailable() {
/* 615 */     if (isDestroyed()) {
/* 616 */       return false;
/*     */     }
/* 618 */     Map localUrlInvokerMap = this.urlInvokerMap;
/* 619 */     if ((localUrlInvokerMap != null) && (localUrlInvokerMap.size() > 0)) {
/* 620 */       for (Invoker invoker : new ArrayList(localUrlInvokerMap.values())) {
/* 621 */         if (invoker.isAvailable()) {
/* 622 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 626 */     return false;
/*     */   }
/*     */ 
/*     */   public Map<String, Invoker<T>> getUrlInvokerMap()
/*     */   {
/* 633 */     return this.urlInvokerMap;
/*     */   }
/*     */ 
/*     */   public Map<String, List<Invoker<T>>> getMethodInvokerMap()
/*     */   {
/* 640 */     return this.methodInvokerMap;
/*     */   }
/*     */ 
/*     */   private static class InvokerDelegete<T> extends InvokerWrapper<T>
/*     */   {
/*     */     private URL providerUrl;
/*     */ 
/*     */     public InvokerDelegete(Invoker<T> invoker, URL url, URL providerUrl)
/*     */     {
/* 669 */       super(url);
/* 670 */       this.providerUrl = providerUrl;
/*     */     }
/*     */     public URL getProviderUrl() {
/* 673 */       return this.providerUrl;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InvokerComparator
/*     */     implements Comparator<Invoker<?>>
/*     */   {
/* 645 */     private static final InvokerComparator comparator = new InvokerComparator();
/*     */ 
/*     */     public static InvokerComparator getComparator() {
/* 648 */       return comparator;
/*     */     }
/*     */ 
/*     */     public int compare(Invoker<?> o1, Invoker<?> o2)
/*     */     {
/* 654 */       return o1.getUrl().toString().compareTo(o2.getUrl().toString());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.integration.RegistryDirectory
 * JD-Core Version:    0.6.2
 */