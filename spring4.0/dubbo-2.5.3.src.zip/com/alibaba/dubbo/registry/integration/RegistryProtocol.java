/*     */ package com.alibaba.dubbo.registry.integration;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.common.utils.UrlUtils;
/*     */ import com.alibaba.dubbo.registry.NotifyListener;
/*     */ import com.alibaba.dubbo.registry.Registry;
/*     */ import com.alibaba.dubbo.registry.RegistryFactory;
/*     */ import com.alibaba.dubbo.registry.RegistryService;
/*     */ import com.alibaba.dubbo.rpc.Exporter;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Protocol;
/*     */ import com.alibaba.dubbo.rpc.ProxyFactory;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*     */ import com.alibaba.dubbo.rpc.cluster.Configurator;
/*     */ import com.alibaba.dubbo.rpc.protocol.InvokerWrapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class RegistryProtocol
/*     */   implements Protocol
/*     */ {
/*     */   private Cluster cluster;
/*     */   private Protocol protocol;
/*     */   private RegistryFactory registryFactory;
/*     */   private ProxyFactory proxyFactory;
/*     */   private static RegistryProtocol INSTANCE;
/*  93 */   private final Map<URL, NotifyListener> overrideListeners = new ConcurrentHashMap();
/*     */ 
/* 101 */   private final Map<String, ExporterChangeableWrapper<?>> bounds = new ConcurrentHashMap();
/*     */ 
/* 103 */   private static final Logger logger = LoggerFactory.getLogger(RegistryProtocol.class);
/*     */ 
/*     */   public void setCluster(Cluster cluster)
/*     */   {
/*  55 */     this.cluster = cluster;
/*     */   }
/*     */ 
/*     */   public void setProtocol(Protocol protocol)
/*     */   {
/*  61 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   public void setRegistryFactory(RegistryFactory registryFactory)
/*     */   {
/*  67 */     this.registryFactory = registryFactory;
/*     */   }
/*     */ 
/*     */   public void setProxyFactory(ProxyFactory proxyFactory)
/*     */   {
/*  73 */     this.proxyFactory = proxyFactory;
/*     */   }
/*     */ 
/*     */   public int getDefaultPort() {
/*  77 */     return 9090;
/*     */   }
/*     */ 
/*     */   public RegistryProtocol()
/*     */   {
/*  83 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   public static RegistryProtocol getRegistryProtocol() {
/*  87 */     if (INSTANCE == null) {
/*  88 */       ExtensionLoader.getExtensionLoader(Protocol.class).getExtension("registry");
/*     */     }
/*  90 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public Map<URL, NotifyListener> getOverrideListeners()
/*     */   {
/*  96 */     return this.overrideListeners;
/*     */   }
/*     */ 
/*     */   public <T> Exporter<T> export(Invoker<T> originInvoker)
/*     */     throws RpcException
/*     */   {
/* 107 */     final ExporterChangeableWrapper exporter = doLocalExport(originInvoker);
/*     */ 
/* 109 */     final Registry registry = getRegistry(originInvoker);
/* 110 */     final URL registedProviderUrl = getRegistedProviderUrl(originInvoker);
/* 111 */     registry.register(registedProviderUrl);
/*     */ 
/* 114 */     final URL overrideSubscribeUrl = getSubscribedOverrideUrl(registedProviderUrl);
/* 115 */     final OverrideListener overrideSubscribeListener = new OverrideListener(overrideSubscribeUrl);
/* 116 */     this.overrideListeners.put(overrideSubscribeUrl, overrideSubscribeListener);
/* 117 */     registry.subscribe(overrideSubscribeUrl, overrideSubscribeListener);
/*     */ 
/* 119 */     return new Exporter() {
/*     */       public Invoker<T> getInvoker() {
/* 121 */         return exporter.getInvoker();
/*     */       }
/*     */       public void unexport() {
/*     */         try {
/* 125 */           exporter.unexport();
/*     */         } catch (Throwable t) {
/* 127 */           RegistryProtocol.logger.warn(t.getMessage(), t);
/*     */         }
/*     */         try {
/* 130 */           registry.unregister(registedProviderUrl);
/*     */         } catch (Throwable t) {
/* 132 */           RegistryProtocol.logger.warn(t.getMessage(), t);
/*     */         }
/*     */         try {
/* 135 */           RegistryProtocol.this.overrideListeners.remove(overrideSubscribeUrl);
/* 136 */           registry.unsubscribe(overrideSubscribeUrl, overrideSubscribeListener);
/*     */         } catch (Throwable t) {
/* 138 */           RegistryProtocol.logger.warn(t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private <T> ExporterChangeableWrapper<T> doLocalExport(Invoker<T> originInvoker)
/*     */   {
/* 146 */     String key = getCacheKey(originInvoker);
/* 147 */     ExporterChangeableWrapper exporter = (ExporterChangeableWrapper)this.bounds.get(key);
/* 148 */     if (exporter == null) {
/* 149 */       synchronized (this.bounds) {
/* 150 */         exporter = (ExporterChangeableWrapper)this.bounds.get(key);
/* 151 */         if (exporter == null) {
/* 152 */           Invoker invokerDelegete = new InvokerDelegete(originInvoker, getProviderUrl(originInvoker));
/* 153 */           exporter = new ExporterChangeableWrapper(this.protocol.export(invokerDelegete), originInvoker);
/* 154 */           this.bounds.put(key, exporter);
/*     */         }
/*     */       }
/*     */     }
/* 158 */     return exporter;
/*     */   }
/*     */ 
/*     */   private <T> void doChangeLocalExport(Invoker<T> originInvoker, URL newInvokerUrl)
/*     */   {
/* 168 */     String key = getCacheKey(originInvoker);
/* 169 */     ExporterChangeableWrapper exporter = (ExporterChangeableWrapper)this.bounds.get(key);
/* 170 */     if (exporter == null) {
/* 171 */       logger.warn(new IllegalStateException("error state, exporter should not be null"));
/* 172 */       return;
/*     */     }
/* 174 */     Invoker invokerDelegete = new InvokerDelegete(originInvoker, newInvokerUrl);
/* 175 */     exporter.setExporter(this.protocol.export(invokerDelegete));
/*     */   }
/*     */ 
/*     */   private Registry getRegistry(Invoker<?> originInvoker)
/*     */   {
/* 185 */     URL registryUrl = originInvoker.getUrl();
/* 186 */     if ("registry".equals(registryUrl.getProtocol())) {
/* 187 */       String protocol = registryUrl.getParameter("registry", "dubbo");
/* 188 */       registryUrl = registryUrl.setProtocol(protocol).removeParameter("registry");
/*     */     }
/* 190 */     return this.registryFactory.getRegistry(registryUrl);
/*     */   }
/*     */ 
/*     */   private URL getRegistedProviderUrl(Invoker<?> originInvoker)
/*     */   {
/* 199 */     URL providerUrl = getProviderUrl(originInvoker);
/*     */ 
/* 201 */     URL registedProviderUrl = providerUrl.removeParameters(getFilteredKeys(providerUrl)).removeParameter("monitor");
/* 202 */     return registedProviderUrl;
/*     */   }
/*     */ 
/*     */   private URL getSubscribedOverrideUrl(URL registedProviderUrl) {
/* 206 */     return registedProviderUrl.setProtocol("provider").addParameters(new String[] { "category", "configurators", "check", String.valueOf(false) });
/*     */   }
/*     */ 
/*     */   private URL getProviderUrl(Invoker<?> origininvoker)
/*     */   {
/* 217 */     String export = origininvoker.getUrl().getParameterAndDecoded("export");
/* 218 */     if ((export == null) || (export.length() == 0)) {
/* 219 */       throw new IllegalArgumentException("The registry export url is null! registry: " + origininvoker.getUrl());
/*     */     }
/*     */ 
/* 222 */     URL providerUrl = URL.valueOf(export);
/* 223 */     return providerUrl;
/*     */   }
/*     */ 
/*     */   private String getCacheKey(Invoker<?> originInvoker)
/*     */   {
/* 232 */     URL providerUrl = getProviderUrl(originInvoker);
/* 233 */     String key = providerUrl.removeParameters(new String[] { "dynamic", "enabled" }).toFullString();
/* 234 */     return key;
/*     */   }
/*     */ 
/*     */   public <T> Invoker<T> refer(Class<T> type, URL url) throws RpcException
/*     */   {
/* 239 */     url = url.setProtocol(url.getParameter("registry", "dubbo")).removeParameter("registry");
/* 240 */     Registry registry = this.registryFactory.getRegistry(url);
/* 241 */     if (RegistryService.class.equals(type)) {
/* 242 */       return this.proxyFactory.getInvoker(registry, type, url);
/*     */     }
/*     */ 
/* 246 */     Map qs = StringUtils.parseQueryString(url.getParameterAndDecoded("refer"));
/* 247 */     String group = (String)qs.get("group");
/* 248 */     if ((group != null) && (group.length() > 0) && (
/* 249 */       (Constants.COMMA_SPLIT_PATTERN.split(group).length > 1) || ("*".equals(group))))
/*     */     {
/* 251 */       return doRefer(getMergeableCluster(), registry, type, url);
/*     */     }
/*     */ 
/* 254 */     return doRefer(this.cluster, registry, type, url);
/*     */   }
/*     */ 
/*     */   private Cluster getMergeableCluster() {
/* 258 */     return (Cluster)ExtensionLoader.getExtensionLoader(Cluster.class).getExtension("mergeable");
/*     */   }
/*     */ 
/*     */   private <T> Invoker<T> doRefer(Cluster cluster, Registry registry, Class<T> type, URL url) {
/* 262 */     RegistryDirectory directory = new RegistryDirectory(type, url);
/* 263 */     directory.setRegistry(registry);
/* 264 */     directory.setProtocol(this.protocol);
/* 265 */     URL subscribeUrl = new URL("consumer", NetUtils.getLocalHost(), 0, type.getName(), directory.getUrl().getParameters());
/* 266 */     if ((!"*".equals(url.getServiceInterface())) && (url.getParameter("register", true)))
/*     */     {
/* 268 */       registry.register(subscribeUrl.addParameters(new String[] { "category", "consumers", "check", String.valueOf(false) }));
/*     */     }
/*     */ 
/* 271 */     directory.subscribe(subscribeUrl.addParameter("category", "providers,configurators,routers"));
/*     */ 
/* 275 */     return cluster.join(directory);
/*     */   }
/*     */ 
/*     */   private static String[] getFilteredKeys(URL url)
/*     */   {
/* 280 */     Map params = url.getParameters();
/* 281 */     if ((params != null) && (!params.isEmpty())) {
/* 282 */       List filteredKeys = new ArrayList();
/* 283 */       for (Map.Entry entry : params.entrySet()) {
/* 284 */         if ((entry != null) && (entry.getKey() != null) && (((String)entry.getKey()).startsWith("."))) {
/* 285 */           filteredKeys.add(entry.getKey());
/*     */         }
/*     */       }
/* 288 */       return (String[])filteredKeys.toArray(new String[filteredKeys.size()]);
/*     */     }
/* 290 */     return new String[0];
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 295 */     List exporters = new ArrayList(this.bounds.values());
/* 296 */     for (Exporter exporter : exporters) {
/* 297 */       exporter.unexport();
/*     */     }
/* 299 */     this.bounds.clear();
/*     */   }
/*     */ 
/*     */   private class ExporterChangeableWrapper<T>
/*     */     implements Exporter<T>
/*     */   {
/*     */     private Exporter<T> exporter;
/*     */     private final Invoker<T> originInvoker;
/*     */ 
/*     */     public ExporterChangeableWrapper(Invoker<T> exporter)
/*     */     {
/* 408 */       this.exporter = exporter;
/* 409 */       this.originInvoker = originInvoker;
/*     */     }
/*     */ 
/*     */     public Invoker<T> getOriginInvoker() {
/* 413 */       return this.originInvoker;
/*     */     }
/*     */ 
/*     */     public Invoker<T> getInvoker() {
/* 417 */       return this.exporter.getInvoker();
/*     */     }
/*     */ 
/*     */     public void setExporter(Exporter<T> exporter) {
/* 421 */       this.exporter = exporter;
/*     */     }
/*     */ 
/*     */     public void unexport() {
/* 425 */       String key = RegistryProtocol.this.getCacheKey(this.originInvoker);
/* 426 */       RegistryProtocol.this.bounds.remove(key);
/* 427 */       this.exporter.unexport();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class InvokerDelegete<T> extends InvokerWrapper<T>
/*     */   {
/*     */     private final Invoker<T> invoker;
/*     */ 
/*     */     public InvokerDelegete(Invoker<T> invoker, URL url)
/*     */     {
/* 382 */       super(url);
/* 383 */       this.invoker = invoker;
/*     */     }
/*     */     public Invoker<T> getInvoker() {
/* 386 */       if ((this.invoker instanceof InvokerDelegete)) {
/* 387 */         return ((InvokerDelegete)this.invoker).getInvoker();
/*     */       }
/* 389 */       return this.invoker;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class OverrideListener
/*     */     implements NotifyListener
/*     */   {
/*     */     private volatile List<Configurator> configurators;
/*     */     private final URL subscribeUrl;
/*     */ 
/*     */     public OverrideListener(URL subscribeUrl)
/*     */     {
/* 315 */       this.subscribeUrl = subscribeUrl;
/*     */     }
/*     */ 
/*     */     public void notify(List<URL> urls)
/*     */     {
/* 324 */       List result = null;
/* 325 */       for (URL url : urls) {
/* 326 */         URL overrideUrl = url;
/* 327 */         if ((url.getParameter("category") == null) && ("override".equals(url.getProtocol())))
/*     */         {
/* 330 */           overrideUrl = url.addParameter("category", "configurators");
/*     */         }
/* 332 */         if (!UrlUtils.isMatch(this.subscribeUrl, overrideUrl)) {
/* 333 */           if (result == null) {
/* 334 */             result = new ArrayList(urls);
/*     */           }
/* 336 */           result.remove(url);
/* 337 */           RegistryProtocol.logger.warn("Subsribe category=configurator, but notifed non-configurator urls. may be registry bug. unexcepted url: " + url);
/*     */         }
/*     */       }
/* 340 */       if (result != null) {
/* 341 */         urls = result;
/*     */       }
/* 343 */       this.configurators = RegistryDirectory.toConfigurators(urls);
/* 344 */       List exporters = new ArrayList(RegistryProtocol.this.bounds.values());
/* 345 */       for (RegistryProtocol.ExporterChangeableWrapper exporter : exporters) {
/* 346 */         Invoker invoker = exporter.getOriginInvoker();
/*     */         Invoker originInvoker;
/*     */         Invoker originInvoker;
/* 348 */         if ((invoker instanceof RegistryProtocol.InvokerDelegete))
/* 349 */           originInvoker = ((RegistryProtocol.InvokerDelegete)invoker).getInvoker();
/*     */         else {
/* 351 */           originInvoker = invoker;
/*     */         }
/*     */ 
/* 354 */         URL originUrl = RegistryProtocol.this.getProviderUrl(originInvoker);
/* 355 */         URL newUrl = getNewInvokerUrl(originUrl, urls);
/*     */ 
/* 357 */         if (!originUrl.equals(newUrl))
/* 358 */           RegistryProtocol.this.doChangeLocalExport(originInvoker, newUrl);
/*     */       }
/*     */     }
/*     */ 
/*     */     private URL getNewInvokerUrl(URL url, List<URL> urls)
/*     */     {
/* 364 */       List localConfigurators = this.configurators;
/*     */ 
/* 366 */       if ((localConfigurators != null) && (localConfigurators.size() > 0)) {
/* 367 */         for (Configurator configurator : localConfigurators) {
/* 368 */           url = configurator.configure(url);
/*     */         }
/*     */       }
/* 371 */       return url;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.integration.RegistryProtocol
 * JD-Core Version:    0.6.2
 */