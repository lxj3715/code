/*    */ package com.alibaba.dubbo.registry.pages;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.utils.NetUtils;
/*    */ import com.alibaba.dubbo.container.page.Menu;
/*    */ import com.alibaba.dubbo.container.page.Page;
/*    */ import com.alibaba.dubbo.container.page.PageHandler;
/*    */ import com.alibaba.dubbo.registry.Registry;
/*    */ import com.alibaba.dubbo.registry.support.AbstractRegistry;
/*    */ import com.alibaba.dubbo.registry.support.AbstractRegistryFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ @Menu(name="Registries", desc="Show connected registries.", order=10000)
/*    */ public class RegistriesPageHandler
/*    */   implements PageHandler
/*    */ {
/*    */   public Page handle(URL url)
/*    */   {
/* 40 */     List rows = new ArrayList();
/* 41 */     Collection registries = AbstractRegistryFactory.getRegistries();
/* 42 */     int registeredCount = 0;
/* 43 */     int subscribedCount = 0;
/* 44 */     if ((registries != null) && (registries.size() > 0)) {
/* 45 */       for (Registry registry : registries) {
/* 46 */         String server = registry.getUrl().getAddress();
/* 47 */         List row = new ArrayList();
/* 48 */         row.add(NetUtils.getHostName(server) + "/" + server);
/* 49 */         if (registry.isAvailable())
/* 50 */           row.add("<font color=\"green\">Connected</font>");
/*    */         else {
/* 52 */           row.add("<font color=\"red\">Disconnected</font>");
/*    */         }
/* 54 */         int registeredSize = 0;
/* 55 */         int subscribedSize = 0;
/* 56 */         if ((registry instanceof AbstractRegistry)) {
/* 57 */           registeredSize = ((AbstractRegistry)registry).getRegistered().size();
/* 58 */           registeredCount += registeredSize;
/* 59 */           subscribedSize = ((AbstractRegistry)registry).getSubscribed().size();
/* 60 */           subscribedCount += subscribedSize;
/*    */         }
/* 62 */         row.add("<a href=\"registered.html?registry=" + server + "\">Registered(" + registeredSize + ")</a>");
/* 63 */         row.add("<a href=\"subscribed.html?registry=" + server + "\">Subscribed(" + subscribedSize + ")</a>");
/* 64 */         rows.add(row);
/*    */       }
/*    */     }
/* 67 */     return new Page("Registries", "Registries (" + rows.size() + ")", new String[] { "Registry Address:", "Status", "Registered(" + registeredCount + ")", "Subscribed(" + subscribedCount + ")" }, rows);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.pages.RegistriesPageHandler
 * JD-Core Version:    0.6.2
 */