/*    */ package com.alibaba.dubbo.registry.pages;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.container.page.Page;
/*    */ import com.alibaba.dubbo.container.page.PageHandler;
/*    */ import com.alibaba.dubbo.registry.Registry;
/*    */ import com.alibaba.dubbo.registry.support.AbstractRegistry;
/*    */ import com.alibaba.dubbo.registry.support.AbstractRegistryFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class SubscribedPageHandler
/*    */   implements PageHandler
/*    */ {
/*    */   public Page handle(URL url)
/*    */   {
/* 38 */     String registryAddress = url.getParameter("registry", "");
/* 39 */     List rows = new ArrayList();
/* 40 */     Collection registries = AbstractRegistryFactory.getRegistries();
/* 41 */     StringBuilder select = new StringBuilder();
/* 42 */     Registry registry = null;
/* 43 */     if ((registries != null) && (registries.size() > 0)) {
/* 44 */       if (registries.size() == 1) {
/* 45 */         registry = (Registry)registries.iterator().next();
/* 46 */         select.append(" &gt; " + registry.getUrl().getAddress());
/*    */       } else {
/* 48 */         select.append(" &gt; <select onchange=\"window.location.href='subscribed.html?registry=' + this.value;\">");
/* 49 */         for (Registry r : registries) {
/* 50 */           String sp = r.getUrl().getAddress();
/* 51 */           select.append("<option value=\">");
/* 52 */           select.append(sp);
/* 53 */           if (((registryAddress != null) && (registryAddress.length() != 0)) || ((registry == null) || (registryAddress.equals(sp))))
/*    */           {
/* 55 */             registry = r;
/* 56 */             select.append("\" selected=\"selected");
/*    */           }
/* 58 */           select.append("\">");
/* 59 */           select.append(sp);
/* 60 */           select.append("</option>");
/*    */         }
/* 62 */         select.append("</select>");
/*    */       }
/*    */     }
/* 65 */     if ((registry instanceof AbstractRegistry)) {
/* 66 */       Set services = ((AbstractRegistry)registry).getSubscribed().keySet();
/* 67 */       if ((services != null) && (services.size() > 0)) {
/* 68 */         for (URL u : services) {
/* 69 */           List row = new ArrayList();
/* 70 */           row.add(u.toFullString().replace("<", "&lt;").replace(">", "&gt;"));
/* 71 */           rows.add(row);
/*    */         }
/*    */       }
/*    */     }
/* 75 */     return new Page("<a href=\"registries.html\">Registries</a>" + select.toString() + " &gt; <a href=\"registered.html?registry=" + registryAddress + "\">Registered</a> | Subscribed", "Subscribed (" + rows.size() + ")", new String[] { "Consumer URL:" }, rows);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.pages.SubscribedPageHandler
 * JD-Core Version:    0.6.2
 */