/*    */ package com.alibaba.dubbo.registry.status;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.status.Status;
/*    */ import com.alibaba.dubbo.common.status.Status.Level;
/*    */ import com.alibaba.dubbo.common.status.StatusChecker;
/*    */ import com.alibaba.dubbo.registry.Registry;
/*    */ import com.alibaba.dubbo.registry.support.AbstractRegistryFactory;
/*    */ import java.util.Collection;
/*    */ 
/*    */ @Activate
/*    */ public class RegistryStatusChecker
/*    */   implements StatusChecker
/*    */ {
/*    */   public Status check()
/*    */   {
/* 35 */     Collection regsitries = AbstractRegistryFactory.getRegistries();
/* 36 */     if ((regsitries == null) || (regsitries.size() == 0)) {
/* 37 */       return new Status(Status.Level.UNKNOWN);
/*    */     }
/* 39 */     Status.Level level = Status.Level.OK;
/* 40 */     StringBuilder buf = new StringBuilder();
/* 41 */     for (Registry registry : regsitries) {
/* 42 */       if (buf.length() > 0) {
/* 43 */         buf.append(",");
/*    */       }
/* 45 */       buf.append(registry.getUrl().getAddress());
/* 46 */       if (!registry.isAvailable()) {
/* 47 */         level = Status.Level.ERROR;
/* 48 */         buf.append("(disconnected)");
/*    */       } else {
/* 50 */         buf.append("(connected)");
/*    */       }
/*    */     }
/* 53 */     return new Status(level, buf.toString());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.status.RegistryStatusChecker
 * JD-Core Version:    0.6.2
 */