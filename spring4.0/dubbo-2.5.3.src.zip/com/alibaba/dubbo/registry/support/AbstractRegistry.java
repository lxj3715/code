/*     */ package com.alibaba.dubbo.registry.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ConcurrentHashSet;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.common.utils.UrlUtils;
/*     */ import com.alibaba.dubbo.registry.NotifyListener;
/*     */ import com.alibaba.dubbo.registry.Registry;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ public abstract class AbstractRegistry
/*     */   implements Registry
/*     */ {
/*  60 */   protected final Logger logger = LoggerFactory.getLogger(getClass());
/*     */   private static final char URL_SEPARATOR = ' ';
/*     */   private static final String URL_SPLIT = "\\s+";
/*     */   private URL registryUrl;
/*     */   private File file;
/*  74 */   private final Properties properties = new Properties();
/*     */ 
/*  77 */   private final ExecutorService registryCacheExecutor = Executors.newFixedThreadPool(1, new NamedThreadFactory("DubboSaveRegistryCache", true));
/*     */   private final boolean syncSaveFile;
/*  82 */   private final AtomicLong lastCacheChanged = new AtomicLong();
/*     */ 
/*  84 */   private final Set<URL> registered = new ConcurrentHashSet();
/*     */ 
/*  86 */   private final ConcurrentMap<URL, Set<NotifyListener>> subscribed = new ConcurrentHashMap();
/*     */ 
/*  88 */   private final ConcurrentMap<URL, Map<String, List<URL>>> notified = new ConcurrentHashMap();
/*     */ 
/*     */   public AbstractRegistry(URL url) {
/*  91 */     setUrl(url);
/*     */ 
/*  93 */     this.syncSaveFile = url.getParameter("save.file", false);
/*  94 */     String filename = url.getParameter("file", System.getProperty("user.home") + "/.dubbo/dubbo-registry-" + url.getHost() + ".cache");
/*  95 */     File file = null;
/*  96 */     if (ConfigUtils.isNotEmpty(filename)) {
/*  97 */       file = new File(filename);
/*  98 */       if ((!file.exists()) && (file.getParentFile() != null) && (!file.getParentFile().exists()) && 
/*  99 */         (!file.getParentFile().mkdirs())) {
/* 100 */         throw new IllegalArgumentException("Invalid registry store file " + file + ", cause: Failed to create directory " + file.getParentFile() + "!");
/*     */       }
/*     */     }
/*     */ 
/* 104 */     this.file = file;
/* 105 */     loadProperties();
/* 106 */     notify(url.getBackupUrls());
/*     */   }
/*     */ 
/*     */   protected void setUrl(URL url) {
/* 110 */     if (url == null) {
/* 111 */       throw new IllegalArgumentException("registry url == null");
/*     */     }
/* 113 */     this.registryUrl = url;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/* 117 */     return this.registryUrl;
/*     */   }
/*     */ 
/*     */   public Set<URL> getRegistered() {
/* 121 */     return this.registered;
/*     */   }
/*     */ 
/*     */   public Map<URL, Set<NotifyListener>> getSubscribed() {
/* 125 */     return this.subscribed;
/*     */   }
/*     */ 
/*     */   public Map<URL, Map<String, List<URL>>> getNotified() {
/* 129 */     return this.notified;
/*     */   }
/*     */ 
/*     */   public File getCacheFile() {
/* 133 */     return this.file;
/*     */   }
/*     */ 
/*     */   public Properties getCacheProperties() {
/* 137 */     return this.properties;
/*     */   }
/*     */ 
/*     */   public AtomicLong getLastCacheChanged() {
/* 141 */     return this.lastCacheChanged;
/*     */   }
/*     */ 
/*     */   public void doSaveProperties(long version)
/*     */   {
/* 155 */     if (version < this.lastCacheChanged.get()) {
/* 156 */       return;
/*     */     }
/* 158 */     if (this.file == null) {
/* 159 */       return;
/*     */     }
/* 161 */     Properties newProperties = new Properties();
/*     */ 
/* 163 */     InputStream in = null;
/*     */     try {
/* 165 */       if (this.file.exists()) {
/* 166 */         in = new FileInputStream(this.file);
/* 167 */         newProperties.load(in);
/*     */       }
/*     */     } catch (Throwable e) {
/* 170 */       this.logger.warn("Failed to load registry store file, cause: " + e.getMessage(), e);
/*     */     } finally {
/* 172 */       if (in != null) {
/*     */         try {
/* 174 */           in.close();
/*     */         } catch (IOException e) {
/* 176 */           this.logger.warn(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 182 */       newProperties.putAll(this.properties);
/* 183 */       File lockfile = new File(this.file.getAbsolutePath() + ".lock");
/* 184 */       if (!lockfile.exists()) {
/* 185 */         lockfile.createNewFile();
/*     */       }
/* 187 */       RandomAccessFile raf = new RandomAccessFile(lockfile, "rw");
/*     */       try {
/* 189 */         FileChannel channel = raf.getChannel();
/*     */         try {
/* 191 */           FileLock lock = channel.tryLock();
/* 192 */           if (lock == null) {
/* 193 */             throw new IOException("Can not lock the registry cache file " + this.file.getAbsolutePath() + ", ignore and retry later, maybe multi java process use the file, please config: dubbo.registry.file=xxx.properties");
/*     */           }
/*     */           try
/*     */           {
/* 197 */             if (!this.file.exists()) {
/* 198 */               this.file.createNewFile();
/*     */             }
/* 200 */             FileOutputStream outputFile = new FileOutputStream(this.file);
/*     */             try {
/* 202 */               newProperties.store(outputFile, "Dubbo Registry Cache");
/*     */             } finally {
/*     */             }
/*     */           }
/*     */           finally {
/*     */           }
/*     */         }
/*     */         finally {
/*     */         }
/*     */       }
/*     */       finally {
/* 213 */         raf.close();
/*     */       }
/*     */     } catch (Throwable e) {
/* 216 */       if (version < this.lastCacheChanged.get()) {
/* 217 */         return;
/*     */       }
/* 219 */       this.registryCacheExecutor.execute(new SaveProperties(this.lastCacheChanged.incrementAndGet(), null));
/*     */ 
/* 221 */       this.logger.warn("Failed to save registry store file, cause: " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadProperties() {
/* 226 */     if ((this.file != null) && (this.file.exists())) {
/* 227 */       InputStream in = null;
/*     */       try {
/* 229 */         in = new FileInputStream(this.file);
/* 230 */         this.properties.load(in);
/* 231 */         if (this.logger.isInfoEnabled())
/* 232 */           this.logger.info("Load registry store file " + this.file + ", data: " + this.properties);
/*     */       }
/*     */       catch (Throwable e) {
/* 235 */         this.logger.warn("Failed to load registry store file " + this.file, e);
/*     */       } finally {
/* 237 */         if (in != null)
/*     */           try {
/* 239 */             in.close();
/*     */           } catch (IOException e) {
/* 241 */             this.logger.warn(e.getMessage(), e);
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<URL> getCacheUrls(URL url)
/*     */   {
/* 249 */     for (Map.Entry entry : this.properties.entrySet()) {
/* 250 */       String key = (String)entry.getKey();
/* 251 */       String value = (String)entry.getValue();
/* 252 */       if ((key != null) && (key.length() > 0) && (key.equals(url.getServiceKey())) && ((Character.isLetter(key.charAt(0))) || (key.charAt(0) == '_')) && (value != null) && (value.length() > 0))
/*     */       {
/* 255 */         String[] arr = value.trim().split("\\s+");
/* 256 */         List urls = new ArrayList();
/* 257 */         for (String u : arr) {
/* 258 */           urls.add(URL.valueOf(u));
/*     */         }
/* 260 */         return urls;
/*     */       }
/*     */     }
/* 263 */     return null;
/*     */   }
/*     */ 
/*     */   public List<URL> lookup(URL url) {
/* 267 */     List result = new ArrayList();
/* 268 */     Map notifiedUrls = (Map)getNotified().get(url);
/* 269 */     if ((notifiedUrls != null) && (notifiedUrls.size() > 0)) {
/* 270 */       for (List urls : notifiedUrls.values()) {
/* 271 */         for (URL u : urls)
/* 272 */           if (!"empty".equals(u.getProtocol()))
/* 273 */             result.add(u);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 278 */       final AtomicReference reference = new AtomicReference();
/* 279 */       NotifyListener listener = new NotifyListener() {
/*     */         public void notify(List<URL> urls) {
/* 281 */           reference.set(urls);
/*     */         }
/*     */       };
/* 284 */       subscribe(url, listener);
/* 285 */       List urls = (List)reference.get();
/* 286 */       if ((urls != null) && (urls.size() > 0)) {
/* 287 */         for (URL u : urls) {
/* 288 */           if (!"empty".equals(u.getProtocol())) {
/* 289 */             result.add(u);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 294 */     return result;
/*     */   }
/*     */ 
/*     */   public void register(URL url) {
/* 298 */     if (url == null) {
/* 299 */       throw new IllegalArgumentException("register url == null");
/*     */     }
/* 301 */     if (this.logger.isInfoEnabled()) {
/* 302 */       this.logger.info("Register: " + url);
/*     */     }
/* 304 */     this.registered.add(url);
/*     */   }
/*     */ 
/*     */   public void unregister(URL url) {
/* 308 */     if (url == null) {
/* 309 */       throw new IllegalArgumentException("unregister url == null");
/*     */     }
/* 311 */     if (this.logger.isInfoEnabled()) {
/* 312 */       this.logger.info("Unregister: " + url);
/*     */     }
/* 314 */     this.registered.remove(url);
/*     */   }
/*     */ 
/*     */   public void subscribe(URL url, NotifyListener listener) {
/* 318 */     if (url == null) {
/* 319 */       throw new IllegalArgumentException("subscribe url == null");
/*     */     }
/* 321 */     if (listener == null) {
/* 322 */       throw new IllegalArgumentException("subscribe listener == null");
/*     */     }
/* 324 */     if (this.logger.isInfoEnabled()) {
/* 325 */       this.logger.info("Subscribe: " + url);
/*     */     }
/* 327 */     Set listeners = (Set)this.subscribed.get(url);
/* 328 */     if (listeners == null) {
/* 329 */       this.subscribed.putIfAbsent(url, new ConcurrentHashSet());
/* 330 */       listeners = (Set)this.subscribed.get(url);
/*     */     }
/* 332 */     listeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void unsubscribe(URL url, NotifyListener listener) {
/* 336 */     if (url == null) {
/* 337 */       throw new IllegalArgumentException("unsubscribe url == null");
/*     */     }
/* 339 */     if (listener == null) {
/* 340 */       throw new IllegalArgumentException("unsubscribe listener == null");
/*     */     }
/* 342 */     if (this.logger.isInfoEnabled()) {
/* 343 */       this.logger.info("Unsubscribe: " + url);
/*     */     }
/* 345 */     Set listeners = (Set)this.subscribed.get(url);
/* 346 */     if (listeners != null)
/* 347 */       listeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void recover()
/*     */     throws Exception
/*     */   {
/* 353 */     Set recoverRegistered = new HashSet(getRegistered());
/* 354 */     if (!recoverRegistered.isEmpty()) {
/* 355 */       if (this.logger.isInfoEnabled()) {
/* 356 */         this.logger.info("Recover register url " + recoverRegistered);
/*     */       }
/* 358 */       for (URL url : recoverRegistered) {
/* 359 */         register(url);
/*     */       }
/*     */     }
/*     */ 
/* 363 */     Map recoverSubscribed = new HashMap(getSubscribed());
/* 364 */     if (!recoverSubscribed.isEmpty()) {
/* 365 */       if (this.logger.isInfoEnabled()) {
/* 366 */         this.logger.info("Recover subscribe url " + recoverSubscribed.keySet());
/*     */       }
/* 368 */       for (Map.Entry entry : recoverSubscribed.entrySet()) {
/* 369 */         url = (URL)entry.getKey();
/* 370 */         for (NotifyListener listener : (Set)entry.getValue())
/* 371 */           subscribe(url, listener);
/*     */       }
/*     */     }
/*     */     URL url;
/*     */   }
/*     */ 
/*     */   protected static List<URL> filterEmpty(URL url, List<URL> urls) {
/* 378 */     if ((urls == null) || (urls.size() == 0)) {
/* 379 */       List result = new ArrayList(1);
/* 380 */       result.add(url.setProtocol("empty"));
/* 381 */       return result;
/*     */     }
/* 383 */     return urls;
/*     */   }
/*     */ 
/*     */   protected void notify(List<URL> urls) {
/* 387 */     if ((urls == null) || (urls.isEmpty())) return;
/*     */ 
/* 389 */     for (Map.Entry entry : getSubscribed().entrySet()) {
/* 390 */       url = (URL)entry.getKey();
/*     */ 
/* 392 */       if (UrlUtils.isMatch(url, (URL)urls.get(0)))
/*     */       {
/* 396 */         Set listeners = (Set)entry.getValue();
/* 397 */         if (listeners != null)
/* 398 */           for (NotifyListener listener : listeners)
/*     */             try {
/* 400 */               notify(url, listener, filterEmpty(url, urls));
/*     */             } catch (Throwable t) {
/* 402 */               this.logger.error("Failed to notify registry event, urls: " + urls + ", cause: " + t.getMessage(), t);
/*     */             }
/*     */       }
/*     */     }
/*     */     URL url;
/*     */   }
/*     */ 
/*     */   protected void notify(URL url, NotifyListener listener, List<URL> urls) {
/* 410 */     if (url == null) {
/* 411 */       throw new IllegalArgumentException("notify url == null");
/*     */     }
/* 413 */     if (listener == null) {
/* 414 */       throw new IllegalArgumentException("notify listener == null");
/*     */     }
/* 416 */     if (((urls == null) || (urls.size() == 0)) && (!"*".equals(url.getServiceInterface())))
/*     */     {
/* 418 */       this.logger.warn("Ignore empty notify urls for subscribe url " + url);
/* 419 */       return;
/*     */     }
/* 421 */     if (this.logger.isInfoEnabled()) {
/* 422 */       this.logger.info("Notify urls for subscribe url " + url + ", urls: " + urls);
/*     */     }
/* 424 */     Map result = new HashMap();
/* 425 */     for (URL u : urls) {
/* 426 */       if (UrlUtils.isMatch(url, u)) {
/* 427 */         String category = u.getParameter("category", "providers");
/* 428 */         List categoryList = (List)result.get(category);
/* 429 */         if (categoryList == null) {
/* 430 */           categoryList = new ArrayList();
/* 431 */           result.put(category, categoryList);
/*     */         }
/* 433 */         categoryList.add(u);
/*     */       }
/*     */     }
/* 436 */     if (result.size() == 0) {
/* 437 */       return;
/*     */     }
/* 439 */     Map categoryNotified = (Map)this.notified.get(url);
/* 440 */     if (categoryNotified == null) {
/* 441 */       this.notified.putIfAbsent(url, new ConcurrentHashMap());
/* 442 */       categoryNotified = (Map)this.notified.get(url);
/*     */     }
/* 444 */     for (Map.Entry entry : result.entrySet()) {
/* 445 */       String category = (String)entry.getKey();
/* 446 */       List categoryList = (List)entry.getValue();
/* 447 */       categoryNotified.put(category, categoryList);
/* 448 */       saveProperties(url);
/* 449 */       listener.notify(categoryList);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void saveProperties(URL url) {
/* 454 */     if (this.file == null) {
/* 455 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 459 */       StringBuilder buf = new StringBuilder();
/* 460 */       Map categoryNotified = (Map)this.notified.get(url);
/* 461 */       if (categoryNotified != null) {
/* 462 */         for (List us : categoryNotified.values()) {
/* 463 */           for (URL u : us) {
/* 464 */             if (buf.length() > 0) {
/* 465 */               buf.append(' ');
/*     */             }
/* 467 */             buf.append(u.toFullString());
/*     */           }
/*     */         }
/*     */       }
/* 471 */       this.properties.setProperty(url.getServiceKey(), buf.toString());
/* 472 */       long version = this.lastCacheChanged.incrementAndGet();
/* 473 */       if (this.syncSaveFile)
/* 474 */         doSaveProperties(version);
/*     */       else
/* 476 */         this.registryCacheExecutor.execute(new SaveProperties(version, null));
/*     */     }
/*     */     catch (Throwable t) {
/* 479 */       this.logger.warn(t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 484 */     if (this.logger.isInfoEnabled()) {
/* 485 */       this.logger.info("Destroy registry:" + getUrl());
/*     */     }
/* 487 */     Set destroyRegistered = new HashSet(getRegistered());
/* 488 */     if (!destroyRegistered.isEmpty()) {
/* 489 */       for (URL url : new HashSet(getRegistered())) {
/* 490 */         if (url.getParameter("dynamic", true)) {
/*     */           try {
/* 492 */             unregister(url);
/* 493 */             if (this.logger.isInfoEnabled())
/* 494 */               this.logger.info("Destroy unregister url " + url);
/*     */           }
/*     */           catch (Throwable t) {
/* 497 */             this.logger.warn("Failed to unregister url " + url + " to registry " + getUrl() + " on destroy, cause: " + t.getMessage(), t);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 502 */     Map destroySubscribed = new HashMap(getSubscribed());
/* 503 */     if (!destroySubscribed.isEmpty())
/* 504 */       for (Map.Entry entry : destroySubscribed.entrySet()) {
/* 505 */         url = (URL)entry.getKey();
/* 506 */         for (NotifyListener listener : (Set)entry.getValue())
/*     */           try {
/* 508 */             unsubscribe(url, listener);
/* 509 */             if (this.logger.isInfoEnabled())
/* 510 */               this.logger.info("Destroy unsubscribe url " + url);
/*     */           }
/*     */           catch (Throwable t) {
/* 513 */             this.logger.warn("Failed to unsubscribe url " + url + " to registry " + getUrl() + " on destroy, cause: " + t.getMessage(), t);
/*     */           }
/*     */       }
/*     */     URL url;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 521 */     return getUrl().toString();
/*     */   }
/*     */ 
/*     */   private class SaveProperties
/*     */     implements Runnable
/*     */   {
/*     */     private long version;
/*     */ 
/*     */     private SaveProperties(long version)
/*     */     {
/* 147 */       this.version = version;
/*     */     }
/*     */     public void run() {
/* 150 */       AbstractRegistry.this.doSaveProperties(this.version);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.support.AbstractRegistry
 * JD-Core Version:    0.6.2
 */