/*    */ package com.alibaba.dubbo.registry.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.registry.Registry;
/*    */ import com.alibaba.dubbo.registry.RegistryFactory;
/*    */ import com.alibaba.dubbo.registry.RegistryService;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ public abstract class AbstractRegistryFactory
/*    */   implements RegistryFactory
/*    */ {
/* 41 */   private static final Logger LOGGER = LoggerFactory.getLogger(AbstractRegistryFactory.class);
/*    */ 
/* 44 */   private static final ReentrantLock LOCK = new ReentrantLock();
/*    */ 
/* 47 */   private static final Map<String, Registry> REGISTRIES = new ConcurrentHashMap();
/*    */ 
/*    */   public static Collection<Registry> getRegistries()
/*    */   {
/* 55 */     return Collections.unmodifiableCollection(REGISTRIES.values());
/*    */   }
/*    */ 
/*    */   public static void destroyAll()
/*    */   {
/* 62 */     if (LOGGER.isInfoEnabled()) {
/* 63 */       LOGGER.info("Close all registries " + getRegistries());
/*    */     }
/*    */ 
/* 66 */     LOCK.lock();
/*    */     try {
/* 68 */       for (Registry registry : getRegistries()) {
/*    */         try {
/* 70 */           registry.destroy();
/*    */         } catch (Throwable e) {
/* 72 */           LOGGER.error(e.getMessage(), e);
/*    */         }
/*    */       }
/* 75 */       REGISTRIES.clear();
/*    */     }
/*    */     finally {
/* 78 */       LOCK.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Registry getRegistry(URL url) {
/* 83 */     url = url.setPath(RegistryService.class.getName()).addParameter("interface", RegistryService.class.getName()).removeParameters(new String[] { "export", "refer" });
/*    */ 
/* 86 */     String key = url.toServiceString();
/*    */ 
/* 88 */     LOCK.lock();
/*    */     try {
/* 90 */       Registry registry = (Registry)REGISTRIES.get(key);
/*    */       Registry localRegistry1;
/* 91 */       if (registry != null) {
/* 92 */         return registry;
/*    */       }
/* 94 */       registry = createRegistry(url);
/* 95 */       if (registry == null) {
/* 96 */         throw new IllegalStateException("Can not create registry " + url);
/*    */       }
/* 98 */       REGISTRIES.put(key, registry);
/* 99 */       return registry;
/*    */     }
/*    */     finally {
/* 102 */       LOCK.unlock();
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract Registry createRegistry(URL paramURL);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.support.AbstractRegistryFactory
 * JD-Core Version:    0.6.2
 */