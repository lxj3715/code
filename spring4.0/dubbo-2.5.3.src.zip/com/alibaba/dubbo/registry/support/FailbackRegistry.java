/*     */ package com.alibaba.dubbo.registry.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.utils.ConcurrentHashSet;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.registry.NotifyListener;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public abstract class FailbackRegistry extends AbstractRegistry
/*     */ {
/*  45 */   private final ScheduledExecutorService retryExecutor = Executors.newScheduledThreadPool(1, new NamedThreadFactory("DubboRegistryFailedRetryTimer", true));
/*     */   private final ScheduledFuture<?> retryFuture;
/*  50 */   private final Set<URL> failedRegistered = new ConcurrentHashSet();
/*     */ 
/*  52 */   private final Set<URL> failedUnregistered = new ConcurrentHashSet();
/*     */ 
/*  54 */   private final ConcurrentMap<URL, Set<NotifyListener>> failedSubscribed = new ConcurrentHashMap();
/*     */ 
/*  56 */   private final ConcurrentMap<URL, Set<NotifyListener>> failedUnsubscribed = new ConcurrentHashMap();
/*     */ 
/*  58 */   private final ConcurrentMap<URL, Map<NotifyListener, List<URL>>> failedNotified = new ConcurrentHashMap();
/*     */ 
/*     */   public FailbackRegistry(URL url) {
/*  61 */     super(url);
/*  62 */     int retryPeriod = url.getParameter("retry.period", 5000);
/*  63 */     this.retryFuture = this.retryExecutor.scheduleWithFixedDelay(new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/*  67 */           FailbackRegistry.this.retry();
/*     */         } catch (Throwable t) {
/*  69 */           FailbackRegistry.this.logger.error("Unexpected error occur at failed retry, cause: " + t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/*     */     , retryPeriod, retryPeriod, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   public Future<?> getRetryFuture()
/*     */   {
/*  76 */     return this.retryFuture;
/*     */   }
/*     */ 
/*     */   public Set<URL> getFailedRegistered() {
/*  80 */     return this.failedRegistered;
/*     */   }
/*     */ 
/*     */   public Set<URL> getFailedUnregistered() {
/*  84 */     return this.failedUnregistered;
/*     */   }
/*     */ 
/*     */   public Map<URL, Set<NotifyListener>> getFailedSubscribed() {
/*  88 */     return this.failedSubscribed;
/*     */   }
/*     */ 
/*     */   public Map<URL, Set<NotifyListener>> getFailedUnsubscribed() {
/*  92 */     return this.failedUnsubscribed;
/*     */   }
/*     */ 
/*     */   public Map<URL, Map<NotifyListener, List<URL>>> getFailedNotified() {
/*  96 */     return this.failedNotified;
/*     */   }
/*     */ 
/*     */   private void addFailedSubscribed(URL url, NotifyListener listener) {
/* 100 */     Set listeners = (Set)this.failedSubscribed.get(url);
/* 101 */     if (listeners == null) {
/* 102 */       this.failedSubscribed.putIfAbsent(url, new ConcurrentHashSet());
/* 103 */       listeners = (Set)this.failedSubscribed.get(url);
/*     */     }
/* 105 */     listeners.add(listener);
/*     */   }
/*     */ 
/*     */   private void removeFailedSubscribed(URL url, NotifyListener listener) {
/* 109 */     Set listeners = (Set)this.failedSubscribed.get(url);
/* 110 */     if (listeners != null) {
/* 111 */       listeners.remove(listener);
/*     */     }
/* 113 */     listeners = (Set)this.failedUnsubscribed.get(url);
/* 114 */     if (listeners != null) {
/* 115 */       listeners.remove(listener);
/*     */     }
/* 117 */     Map notified = (Map)this.failedNotified.get(url);
/* 118 */     if (notified != null)
/* 119 */       notified.remove(listener);
/*     */   }
/*     */ 
/*     */   public void register(URL url)
/*     */   {
/* 125 */     super.register(url);
/* 126 */     this.failedRegistered.remove(url);
/* 127 */     this.failedUnregistered.remove(url);
/*     */     try
/*     */     {
/* 130 */       doRegister(url);
/*     */     } catch (Exception e) {
/* 132 */       Throwable t = e;
/*     */ 
/* 135 */       boolean check = (getUrl().getParameter("check", true)) && (url.getParameter("check", true)) && (!"consumer".equals(url.getProtocol()));
/*     */ 
/* 138 */       boolean skipFailback = t instanceof SkipFailbackWrapperException;
/* 139 */       if ((check) || (skipFailback)) {
/* 140 */         if (skipFailback) {
/* 141 */           t = t.getCause();
/*     */         }
/* 143 */         throw new IllegalStateException("Failed to register " + url + " to registry " + getUrl().getAddress() + ", cause: " + t.getMessage(), t);
/*     */       }
/* 145 */       this.logger.error("Failed to register " + url + ", waiting for retry, cause: " + t.getMessage(), t);
/*     */ 
/* 149 */       this.failedRegistered.add(url);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void unregister(URL url)
/*     */   {
/* 155 */     super.unregister(url);
/* 156 */     this.failedRegistered.remove(url);
/* 157 */     this.failedUnregistered.remove(url);
/*     */     try
/*     */     {
/* 160 */       doUnregister(url);
/*     */     } catch (Exception e) {
/* 162 */       Throwable t = e;
/*     */ 
/* 165 */       boolean check = (getUrl().getParameter("check", true)) && (url.getParameter("check", true)) && (!"consumer".equals(url.getProtocol()));
/*     */ 
/* 168 */       boolean skipFailback = t instanceof SkipFailbackWrapperException;
/* 169 */       if ((check) || (skipFailback)) {
/* 170 */         if (skipFailback) {
/* 171 */           t = t.getCause();
/*     */         }
/* 173 */         throw new IllegalStateException("Failed to unregister " + url + " to registry " + getUrl().getAddress() + ", cause: " + t.getMessage(), t);
/*     */       }
/* 175 */       this.logger.error("Failed to uregister " + url + ", waiting for retry, cause: " + t.getMessage(), t);
/*     */ 
/* 179 */       this.failedUnregistered.add(url);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void subscribe(URL url, NotifyListener listener)
/*     */   {
/* 185 */     super.subscribe(url, listener);
/* 186 */     removeFailedSubscribed(url, listener);
/*     */     try
/*     */     {
/* 189 */       doSubscribe(url, listener);
/*     */     } catch (Exception e) {
/* 191 */       Throwable t = e;
/*     */ 
/* 193 */       List urls = getCacheUrls(url);
/* 194 */       if ((urls != null) && (urls.size() > 0)) {
/* 195 */         notify(url, listener, urls);
/* 196 */         this.logger.error("Failed to subscribe " + url + ", Using cached list: " + urls + " from cache file: " + getUrl().getParameter("file", new StringBuilder().append(System.getProperty("user.home")).append("/dubbo-registry-").append(url.getHost()).append(".cache").toString()) + ", cause: " + t.getMessage(), t);
/*     */       }
/*     */       else {
/* 199 */         boolean check = (getUrl().getParameter("check", true)) && (url.getParameter("check", true));
/*     */ 
/* 201 */         boolean skipFailback = t instanceof SkipFailbackWrapperException;
/* 202 */         if ((check) || (skipFailback)) {
/* 203 */           if (skipFailback) {
/* 204 */             t = t.getCause();
/*     */           }
/* 206 */           throw new IllegalStateException("Failed to subscribe " + url + ", cause: " + t.getMessage(), t);
/*     */         }
/* 208 */         this.logger.error("Failed to subscribe " + url + ", waiting for retry, cause: " + t.getMessage(), t);
/*     */       }
/*     */ 
/* 213 */       addFailedSubscribed(url, listener);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void unsubscribe(URL url, NotifyListener listener)
/*     */   {
/* 219 */     super.unsubscribe(url, listener);
/* 220 */     removeFailedSubscribed(url, listener);
/*     */     try
/*     */     {
/* 223 */       doUnsubscribe(url, listener);
/*     */     } catch (Exception e) {
/* 225 */       Throwable t = e;
/*     */ 
/* 228 */       boolean check = (getUrl().getParameter("check", true)) && (url.getParameter("check", true));
/*     */ 
/* 230 */       boolean skipFailback = t instanceof SkipFailbackWrapperException;
/* 231 */       if ((check) || (skipFailback)) {
/* 232 */         if (skipFailback) {
/* 233 */           t = t.getCause();
/*     */         }
/* 235 */         throw new IllegalStateException("Failed to unsubscribe " + url + " to registry " + getUrl().getAddress() + ", cause: " + t.getMessage(), t);
/*     */       }
/* 237 */       this.logger.error("Failed to unsubscribe " + url + ", waiting for retry, cause: " + t.getMessage(), t);
/*     */ 
/* 241 */       Set listeners = (Set)this.failedUnsubscribed.get(url);
/* 242 */       if (listeners == null) {
/* 243 */         this.failedUnsubscribed.putIfAbsent(url, new ConcurrentHashSet());
/* 244 */         listeners = (Set)this.failedUnsubscribed.get(url);
/*     */       }
/* 246 */       listeners.add(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void notify(URL url, NotifyListener listener, List<URL> urls)
/*     */   {
/* 252 */     if (url == null) {
/* 253 */       throw new IllegalArgumentException("notify url == null");
/*     */     }
/* 255 */     if (listener == null)
/* 256 */       throw new IllegalArgumentException("notify listener == null");
/*     */     try
/*     */     {
/* 259 */       doNotify(url, listener, urls);
/*     */     }
/*     */     catch (Exception t) {
/* 262 */       Map listeners = (Map)this.failedNotified.get(url);
/* 263 */       if (listeners == null) {
/* 264 */         this.failedNotified.putIfAbsent(url, new ConcurrentHashMap());
/* 265 */         listeners = (Map)this.failedNotified.get(url);
/*     */       }
/* 267 */       listeners.put(listener, urls);
/* 268 */       this.logger.error("Failed to notify for subscribe " + url + ", waiting for retry, cause: " + t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doNotify(URL url, NotifyListener listener, List<URL> urls) {
/* 273 */     super.notify(url, listener, urls);
/*     */   }
/*     */ 
/*     */   protected void recover()
/*     */     throws Exception
/*     */   {
/* 279 */     Set recoverRegistered = new HashSet(getRegistered());
/* 280 */     if (!recoverRegistered.isEmpty()) {
/* 281 */       if (this.logger.isInfoEnabled()) {
/* 282 */         this.logger.info("Recover register url " + recoverRegistered);
/*     */       }
/* 284 */       for (URL url : recoverRegistered) {
/* 285 */         this.failedRegistered.add(url);
/*     */       }
/*     */     }
/*     */ 
/* 289 */     Map recoverSubscribed = new HashMap(getSubscribed());
/* 290 */     if (!recoverSubscribed.isEmpty()) {
/* 291 */       if (this.logger.isInfoEnabled()) {
/* 292 */         this.logger.info("Recover subscribe url " + recoverSubscribed.keySet());
/*     */       }
/* 294 */       for (Map.Entry entry : recoverSubscribed.entrySet()) {
/* 295 */         url = (URL)entry.getKey();
/* 296 */         for (NotifyListener listener : (Set)entry.getValue())
/* 297 */           addFailedSubscribed(url, listener);
/*     */       }
/*     */     }
/*     */     URL url;
/*     */   }
/*     */ 
/*     */   protected void retry()
/*     */   {
/* 305 */     if (!this.failedRegistered.isEmpty()) {
/* 306 */       Set failed = new HashSet(this.failedRegistered);
/* 307 */       if (failed.size() > 0) {
/* 308 */         if (this.logger.isInfoEnabled())
/* 309 */           this.logger.info("Retry register " + failed);
/*     */         try
/*     */         {
/* 312 */           for (URL url : failed)
/*     */             try {
/* 314 */               doRegister(url);
/* 315 */               this.failedRegistered.remove(url);
/*     */             } catch (Throwable t) {
/* 317 */               this.logger.warn("Failed to retry register " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */             }
/*     */         }
/*     */         catch (Throwable t) {
/* 321 */           this.logger.warn("Failed to retry register " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/* 325 */     if (!this.failedUnregistered.isEmpty()) {
/* 326 */       Set failed = new HashSet(this.failedUnregistered);
/* 327 */       if (failed.size() > 0) {
/* 328 */         if (this.logger.isInfoEnabled())
/* 329 */           this.logger.info("Retry unregister " + failed);
/*     */         try
/*     */         {
/* 332 */           for (URL url : failed)
/*     */             try {
/* 334 */               doUnregister(url);
/* 335 */               this.failedUnregistered.remove(url);
/*     */             } catch (Throwable t) {
/* 337 */               this.logger.warn("Failed to retry unregister  " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */             }
/*     */         }
/*     */         catch (Throwable t) {
/* 341 */           this.logger.warn("Failed to retry unregister  " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/* 345 */     if (!this.failedSubscribed.isEmpty()) {
/* 346 */       Map failed = new HashMap(this.failedSubscribed);
/* 347 */       for (Map.Entry entry : new HashMap(failed).entrySet()) {
/* 348 */         if ((entry.getValue() == null) || (((Set)entry.getValue()).size() == 0)) {
/* 349 */           failed.remove(entry.getKey());
/*     */         }
/*     */       }
/* 352 */       if (failed.size() > 0) {
/* 353 */         if (this.logger.isInfoEnabled())
/* 354 */           this.logger.info("Retry subscribe " + failed);
/*     */         try
/*     */         {
/* 357 */           for (Map.Entry entry : failed.entrySet()) {
/* 358 */             url = (URL)entry.getKey();
/* 359 */             listeners = (Set)entry.getValue();
/* 360 */             for (NotifyListener listener : listeners)
/*     */               try {
/* 362 */                 doSubscribe(url, listener);
/* 363 */                 listeners.remove(listener);
/*     */               } catch (Throwable t) {
/* 365 */                 this.logger.warn("Failed to retry subscribe " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */               }
/*     */           }
/*     */         }
/*     */         catch (Throwable t)
/*     */         {
/*     */           URL url;
/*     */           Set listeners;
/* 370 */           this.logger.warn("Failed to retry subscribe " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/* 374 */     if (!this.failedUnsubscribed.isEmpty()) {
/* 375 */       Map failed = new HashMap(this.failedUnsubscribed);
/* 376 */       for (Map.Entry entry : new HashMap(failed).entrySet()) {
/* 377 */         if ((entry.getValue() == null) || (((Set)entry.getValue()).size() == 0)) {
/* 378 */           failed.remove(entry.getKey());
/*     */         }
/*     */       }
/* 381 */       if (failed.size() > 0) {
/* 382 */         if (this.logger.isInfoEnabled())
/* 383 */           this.logger.info("Retry unsubscribe " + failed);
/*     */         try
/*     */         {
/* 386 */           for (Map.Entry entry : failed.entrySet()) {
/* 387 */             url = (URL)entry.getKey();
/* 388 */             listeners = (Set)entry.getValue();
/* 389 */             for (NotifyListener listener : listeners)
/*     */               try {
/* 391 */                 doUnsubscribe(url, listener);
/* 392 */                 listeners.remove(listener);
/*     */               } catch (Throwable t) {
/* 394 */                 this.logger.warn("Failed to retry unsubscribe " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */               }
/*     */           }
/*     */         }
/*     */         catch (Throwable t)
/*     */         {
/*     */           URL url;
/*     */           Set listeners;
/* 399 */           this.logger.warn("Failed to retry unsubscribe " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/* 403 */     if (!this.failedNotified.isEmpty()) {
/* 404 */       Map failed = new HashMap(this.failedNotified);
/* 405 */       for (Map.Entry entry : new HashMap(failed).entrySet()) {
/* 406 */         if ((entry.getValue() == null) || (((Map)entry.getValue()).size() == 0)) {
/* 407 */           failed.remove(entry.getKey());
/*     */         }
/*     */       }
/* 410 */       if (failed.size() > 0) {
/* 411 */         if (this.logger.isInfoEnabled())
/* 412 */           this.logger.info("Retry notify " + failed);
/*     */         try
/*     */         {
/* 415 */           for (i$ = failed.values().iterator(); i$.hasNext(); ) { values = (Map)i$.next();
/* 416 */             for (Map.Entry entry : values.entrySet())
/*     */               try {
/* 418 */                 NotifyListener listener = (NotifyListener)entry.getKey();
/* 419 */                 List urls = (List)entry.getValue();
/* 420 */                 listener.notify(urls);
/* 421 */                 values.remove(listener);
/*     */               } catch (Throwable t) {
/* 423 */                 this.logger.warn("Failed to retry notify " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */               }
/*     */           }
/*     */         }
/*     */         catch (Throwable t)
/*     */         {
/*     */           Iterator i$;
/*     */           Map values;
/* 428 */           this.logger.warn("Failed to retry notify " + failed + ", waiting for again, cause: " + t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 436 */     super.destroy();
/*     */     try {
/* 438 */       this.retryFuture.cancel(true);
/*     */     } catch (Throwable t) {
/* 440 */       this.logger.warn(t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void doRegister(URL paramURL);
/*     */ 
/*     */   protected abstract void doUnregister(URL paramURL);
/*     */ 
/*     */   protected abstract void doSubscribe(URL paramURL, NotifyListener paramNotifyListener);
/*     */ 
/*     */   protected abstract void doUnsubscribe(URL paramURL, NotifyListener paramNotifyListener);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.support.FailbackRegistry
 * JD-Core Version:    0.6.2
 */