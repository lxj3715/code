/*    */ package com.alibaba.dubbo.registry.support;
/*    */ 
/*    */ public class SkipFailbackWrapperException extends RuntimeException
/*    */ {
/*    */   public SkipFailbackWrapperException(Throwable cause)
/*    */   {
/* 13 */     super(cause);
/*    */   }
/*    */ 
/*    */   public synchronized Throwable fillInStackTrace()
/*    */   {
/* 19 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.registry.support.SkipFailbackWrapperException
 * JD-Core Version:    0.6.2
 */