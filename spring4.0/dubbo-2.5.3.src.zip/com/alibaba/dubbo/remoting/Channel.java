package com.alibaba.dubbo.remoting;

import java.net.InetSocketAddress;

public abstract interface Channel extends Endpoint
{
  public abstract InetSocketAddress getRemoteAddress();

  public abstract boolean isConnected();

  public abstract boolean hasAttribute(String paramString);

  public abstract Object getAttribute(String paramString);

  public abstract void setAttribute(String paramString, Object paramObject);

  public abstract void removeAttribute(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Channel
 * JD-Core Version:    0.6.2
 */