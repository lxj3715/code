package com.alibaba.dubbo.remoting;

import com.alibaba.dubbo.common.extension.SPI;

@SPI
public abstract interface ChannelHandler
{
  public abstract void connected(Channel paramChannel)
    throws RemotingException;

  public abstract void disconnected(Channel paramChannel)
    throws RemotingException;

  public abstract void sent(Channel paramChannel, Object paramObject)
    throws RemotingException;

  public abstract void received(Channel paramChannel, Object paramObject)
    throws RemotingException;

  public abstract void caught(Channel paramChannel, Throwable paramThrowable)
    throws RemotingException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.ChannelHandler
 * JD-Core Version:    0.6.2
 */