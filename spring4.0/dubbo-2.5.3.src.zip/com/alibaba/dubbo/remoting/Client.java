package com.alibaba.dubbo.remoting;

import com.alibaba.dubbo.common.Parameters;
import com.alibaba.dubbo.common.Resetable;

public abstract interface Client extends Endpoint, Channel, Resetable
{
  public abstract void reconnect()
    throws RemotingException;

  @Deprecated
  public abstract void reset(Parameters paramParameters);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Client
 * JD-Core Version:    0.6.2
 */