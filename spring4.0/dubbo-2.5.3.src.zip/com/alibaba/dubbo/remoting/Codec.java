/*    */ package com.alibaba.dubbo.remoting;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Adaptive;
/*    */ import com.alibaba.dubbo.common.extension.SPI;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ @Deprecated
/*    */ @SPI
/*    */ public abstract interface Codec
/*    */ {
/* 42 */   public static final Object NEED_MORE_INPUT = new Object();
/*    */ 
/*    */   @Adaptive({"codec"})
/*    */   public abstract void encode(Channel paramChannel, OutputStream paramOutputStream, Object paramObject)
/*    */     throws IOException;
/*    */ 
/*    */   @Adaptive({"codec"})
/*    */   public abstract Object decode(Channel paramChannel, InputStream paramInputStream)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Codec
 * JD-Core Version:    0.6.2
 */