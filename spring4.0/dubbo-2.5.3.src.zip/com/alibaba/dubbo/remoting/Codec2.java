/*    */ package com.alibaba.dubbo.remoting;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Adaptive;
/*    */ import com.alibaba.dubbo.common.extension.SPI;
/*    */ import com.alibaba.dubbo.remoting.buffer.ChannelBuffer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ @SPI
/*    */ public abstract interface Codec2
/*    */ {
/*    */   @Adaptive({"codec"})
/*    */   public abstract void encode(Channel paramChannel, ChannelBuffer paramChannelBuffer, Object paramObject)
/*    */     throws IOException;
/*    */ 
/*    */   @Adaptive({"codec"})
/*    */   public abstract Object decode(Channel paramChannel, ChannelBuffer paramChannelBuffer)
/*    */     throws IOException;
/*    */ 
/*    */   public static enum DecodeResult
/*    */   {
/* 39 */     NEED_MORE_INPUT, SKIP_SOME_INPUT;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Codec2
 * JD-Core Version:    0.6.2
 */