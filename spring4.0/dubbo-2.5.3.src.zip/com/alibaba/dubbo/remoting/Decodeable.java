package com.alibaba.dubbo.remoting;

public abstract interface Decodeable
{
  public abstract void decode()
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Decodeable
 * JD-Core Version:    0.6.2
 */