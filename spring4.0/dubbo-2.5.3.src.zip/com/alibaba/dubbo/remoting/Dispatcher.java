package com.alibaba.dubbo.remoting;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;

@SPI("all")
public abstract interface Dispatcher
{
  @Adaptive({"dispatcher", "dispather", "channel.handler"})
  public abstract ChannelHandler dispatch(ChannelHandler paramChannelHandler, URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Dispatcher
 * JD-Core Version:    0.6.2
 */