package com.alibaba.dubbo.remoting;

import com.alibaba.dubbo.common.URL;
import java.net.InetSocketAddress;

public abstract interface Endpoint
{
  public abstract URL getUrl();

  public abstract ChannelHandler getChannelHandler();

  public abstract InetSocketAddress getLocalAddress();

  public abstract void send(Object paramObject)
    throws RemotingException;

  public abstract void send(Object paramObject, boolean paramBoolean)
    throws RemotingException;

  public abstract void close();

  public abstract void close(int paramInt);

  public abstract boolean isClosed();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Endpoint
 * JD-Core Version:    0.6.2
 */