/*    */ package com.alibaba.dubbo.remoting;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ public class ExecutionException extends RemotingException
/*    */ {
/*    */   private static final long serialVersionUID = -2531085236111056860L;
/*    */   private final Object request;
/*    */ 
/*    */   public ExecutionException(Object request, Channel channel, String message, Throwable cause)
/*    */   {
/* 33 */     super(channel, message, cause);
/* 34 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public ExecutionException(Object request, Channel channel, String msg) {
/* 38 */     super(channel, msg);
/* 39 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public ExecutionException(Object request, Channel channel, Throwable cause) {
/* 43 */     super(channel, cause);
/* 44 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public ExecutionException(Object request, InetSocketAddress localAddress, InetSocketAddress remoteAddress, String message, Throwable cause)
/*    */   {
/* 49 */     super(localAddress, remoteAddress, message, cause);
/* 50 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public ExecutionException(Object request, InetSocketAddress localAddress, InetSocketAddress remoteAddress, String message) {
/* 54 */     super(localAddress, remoteAddress, message);
/* 55 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public ExecutionException(Object request, InetSocketAddress localAddress, InetSocketAddress remoteAddress, Throwable cause) {
/* 59 */     super(localAddress, remoteAddress, cause);
/* 60 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public Object getRequest()
/*    */   {
/* 65 */     return this.request;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.ExecutionException
 * JD-Core Version:    0.6.2
 */