/*    */ package com.alibaba.dubbo.remoting;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ public class RemotingException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -3160452149606778709L;
/*    */   private InetSocketAddress localAddress;
/*    */   private InetSocketAddress remoteAddress;
/*    */ 
/*    */   public RemotingException(Channel channel, String msg)
/*    */   {
/* 42 */     this(channel == null ? null : channel.getLocalAddress(), channel == null ? null : channel.getRemoteAddress(), msg);
/*    */   }
/*    */ 
/*    */   public RemotingException(InetSocketAddress localAddress, InetSocketAddress remoteAddress, String message)
/*    */   {
/* 47 */     super(message);
/*    */ 
/* 49 */     this.localAddress = localAddress;
/* 50 */     this.remoteAddress = remoteAddress;
/*    */   }
/*    */ 
/*    */   public RemotingException(Channel channel, Throwable cause) {
/* 54 */     this(channel == null ? null : channel.getLocalAddress(), channel == null ? null : channel.getRemoteAddress(), cause);
/*    */   }
/*    */ 
/*    */   public RemotingException(InetSocketAddress localAddress, InetSocketAddress remoteAddress, Throwable cause)
/*    */   {
/* 59 */     super(cause);
/*    */ 
/* 61 */     this.localAddress = localAddress;
/* 62 */     this.remoteAddress = remoteAddress;
/*    */   }
/*    */ 
/*    */   public RemotingException(Channel channel, String message, Throwable cause) {
/* 66 */     this(channel == null ? null : channel.getLocalAddress(), channel == null ? null : channel.getRemoteAddress(), message, cause);
/*    */   }
/*    */ 
/*    */   public RemotingException(InetSocketAddress localAddress, InetSocketAddress remoteAddress, String message, Throwable cause)
/*    */   {
/* 72 */     super(message, cause);
/*    */ 
/* 74 */     this.localAddress = localAddress;
/* 75 */     this.remoteAddress = remoteAddress;
/*    */   }
/*    */ 
/*    */   public InetSocketAddress getLocalAddress() {
/* 79 */     return this.localAddress;
/*    */   }
/*    */ 
/*    */   public InetSocketAddress getRemoteAddress() {
/* 83 */     return this.remoteAddress;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.RemotingException
 * JD-Core Version:    0.6.2
 */