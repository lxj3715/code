package com.alibaba.dubbo.remoting;

import com.alibaba.dubbo.common.Parameters;
import com.alibaba.dubbo.common.Resetable;
import java.net.InetSocketAddress;
import java.util.Collection;

public abstract interface Server extends Endpoint, Resetable
{
  public abstract boolean isBound();

  public abstract Collection<Channel> getChannels();

  public abstract Channel getChannel(InetSocketAddress paramInetSocketAddress);

  @Deprecated
  public abstract void reset(Parameters paramParameters);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Server
 * JD-Core Version:    0.6.2
 */