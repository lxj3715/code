/*    */ package com.alibaba.dubbo.remoting;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ public class TimeoutException extends RemotingException
/*    */ {
/*    */   private static final long serialVersionUID = 3122966731958222692L;
/*    */   public static final int CLIENT_SIDE = 0;
/*    */   public static final int SERVER_SIDE = 1;
/*    */   private final int phase;
/*    */ 
/*    */   public TimeoutException(boolean serverSide, Channel channel, String message)
/*    */   {
/* 39 */     super(channel, message);
/* 40 */     this.phase = (serverSide ? 1 : 0);
/*    */   }
/*    */ 
/*    */   public TimeoutException(boolean serverSide, InetSocketAddress localAddress, InetSocketAddress remoteAddress, String message)
/*    */   {
/* 45 */     super(localAddress, remoteAddress, message);
/* 46 */     this.phase = (serverSide ? 1 : 0);
/*    */   }
/*    */ 
/*    */   public int getPhase() {
/* 50 */     return this.phase;
/*    */   }
/*    */ 
/*    */   public boolean isServerSide() {
/* 54 */     return this.phase == 1;
/*    */   }
/*    */ 
/*    */   public boolean isClientSide() {
/* 58 */     return this.phase == 0;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.TimeoutException
 * JD-Core Version:    0.6.2
 */