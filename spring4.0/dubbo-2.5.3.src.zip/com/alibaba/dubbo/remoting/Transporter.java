package com.alibaba.dubbo.remoting;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;

@SPI("netty")
public abstract interface Transporter
{
  @Adaptive({"server", "transporter"})
  public abstract Server bind(URL paramURL, ChannelHandler paramChannelHandler)
    throws RemotingException;

  @Adaptive({"client", "transporter"})
  public abstract Client connect(URL paramURL, ChannelHandler paramChannelHandler)
    throws RemotingException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Transporter
 * JD-Core Version:    0.6.2
 */