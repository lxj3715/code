/*    */ package com.alibaba.dubbo.remoting;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.Version;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.remoting.transport.ChannelHandlerAdapter;
/*    */ import com.alibaba.dubbo.remoting.transport.ChannelHandlerDispatcher;
/*    */ 
/*    */ public class Transporters
/*    */ {
/*    */   public static Server bind(String url, ChannelHandler[] handler)
/*    */     throws RemotingException
/*    */   {
/* 32 */     return bind(URL.valueOf(url), handler);
/*    */   }
/*    */ 
/*    */   public static Server bind(URL url, ChannelHandler[] handlers) throws RemotingException {
/* 36 */     if (url == null) {
/* 37 */       throw new IllegalArgumentException("url == null");
/*    */     }
/* 39 */     if ((handlers == null) || (handlers.length == 0))
/* 40 */       throw new IllegalArgumentException("handlers == null");
/*    */     ChannelHandler handler;
/*    */     ChannelHandler handler;
/* 43 */     if (handlers.length == 1)
/* 44 */       handler = handlers[0];
/*    */     else {
/* 46 */       handler = new ChannelHandlerDispatcher(handlers);
/*    */     }
/* 48 */     return getTransporter().bind(url, handler);
/*    */   }
/*    */ 
/*    */   public static Client connect(String url, ChannelHandler[] handler) throws RemotingException {
/* 52 */     return connect(URL.valueOf(url), handler);
/*    */   }
/*    */ 
/*    */   public static Client connect(URL url, ChannelHandler[] handlers) throws RemotingException {
/* 56 */     if (url == null)
/* 57 */       throw new IllegalArgumentException("url == null");
/*    */     ChannelHandler handler;
/*    */     ChannelHandler handler;
/* 60 */     if ((handlers == null) || (handlers.length == 0)) {
/* 61 */       handler = new ChannelHandlerAdapter();
/*    */     }
/*    */     else
/*    */     {
/*    */       ChannelHandler handler;
/* 62 */       if (handlers.length == 1)
/* 63 */         handler = handlers[0];
/*    */       else
/* 65 */         handler = new ChannelHandlerDispatcher(handlers);
/*    */     }
/* 67 */     return getTransporter().connect(url, handler);
/*    */   }
/*    */ 
/*    */   public static Transporter getTransporter() {
/* 71 */     return (Transporter)ExtensionLoader.getExtensionLoader(Transporter.class).getAdaptiveExtension();
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 76 */     Version.checkDuplicate(Transporters.class);
/* 77 */     Version.checkDuplicate(RemotingException.class);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.Transporters
 * JD-Core Version:    0.6.2
 */