/*     */ package com.alibaba.dubbo.remoting.buffer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public abstract class AbstractChannelBuffer
/*     */   implements ChannelBuffer
/*     */ {
/*     */   private int readerIndex;
/*     */   private int writerIndex;
/*     */   private int markedReaderIndex;
/*     */   private int markedWriterIndex;
/*     */ 
/*     */   public int readerIndex()
/*     */   {
/*  38 */     return this.readerIndex;
/*     */   }
/*     */ 
/*     */   public void readerIndex(int readerIndex) {
/*  42 */     if ((readerIndex < 0) || (readerIndex > this.writerIndex)) {
/*  43 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  45 */     this.readerIndex = readerIndex;
/*     */   }
/*     */ 
/*     */   public int writerIndex() {
/*  49 */     return this.writerIndex;
/*     */   }
/*     */ 
/*     */   public void writerIndex(int writerIndex) {
/*  53 */     if ((writerIndex < this.readerIndex) || (writerIndex > capacity())) {
/*  54 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  56 */     this.writerIndex = writerIndex;
/*     */   }
/*     */ 
/*     */   public void setIndex(int readerIndex, int writerIndex) {
/*  60 */     if ((readerIndex < 0) || (readerIndex > writerIndex) || (writerIndex > capacity())) {
/*  61 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  63 */     this.readerIndex = readerIndex;
/*  64 */     this.writerIndex = writerIndex;
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  68 */     this.readerIndex = (this.writerIndex = 0);
/*     */   }
/*     */ 
/*     */   public boolean readable() {
/*  72 */     return readableBytes() > 0;
/*     */   }
/*     */ 
/*     */   public boolean writable() {
/*  76 */     return writableBytes() > 0;
/*     */   }
/*     */ 
/*     */   public int readableBytes() {
/*  80 */     return this.writerIndex - this.readerIndex;
/*     */   }
/*     */ 
/*     */   public int writableBytes() {
/*  84 */     return capacity() - this.writerIndex;
/*     */   }
/*     */ 
/*     */   public void markReaderIndex() {
/*  88 */     this.markedReaderIndex = this.readerIndex;
/*     */   }
/*     */ 
/*     */   public void resetReaderIndex() {
/*  92 */     readerIndex(this.markedReaderIndex);
/*     */   }
/*     */ 
/*     */   public void markWriterIndex() {
/*  96 */     this.markedWriterIndex = this.writerIndex;
/*     */   }
/*     */ 
/*     */   public void resetWriterIndex() {
/* 100 */     this.writerIndex = this.markedWriterIndex;
/*     */   }
/*     */ 
/*     */   public void discardReadBytes() {
/* 104 */     if (this.readerIndex == 0) {
/* 105 */       return;
/*     */     }
/* 107 */     setBytes(0, this, this.readerIndex, this.writerIndex - this.readerIndex);
/* 108 */     this.writerIndex -= this.readerIndex;
/* 109 */     this.markedReaderIndex = Math.max(this.markedReaderIndex - this.readerIndex, 0);
/* 110 */     this.markedWriterIndex = Math.max(this.markedWriterIndex - this.readerIndex, 0);
/* 111 */     this.readerIndex = 0;
/*     */   }
/*     */ 
/*     */   public void ensureWritableBytes(int writableBytes) {
/* 115 */     if (writableBytes > writableBytes())
/* 116 */       throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, byte[] dst)
/*     */   {
/* 121 */     getBytes(index, dst, 0, dst.length);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, ChannelBuffer dst) {
/* 125 */     getBytes(index, dst, dst.writableBytes());
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, ChannelBuffer dst, int length) {
/* 129 */     if (length > dst.writableBytes()) {
/* 130 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 132 */     getBytes(index, dst, dst.writerIndex(), length);
/* 133 */     dst.writerIndex(dst.writerIndex() + length);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, byte[] src) {
/* 137 */     setBytes(index, src, 0, src.length);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, ChannelBuffer src) {
/* 141 */     setBytes(index, src, src.readableBytes());
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, ChannelBuffer src, int length) {
/* 145 */     if (length > src.readableBytes()) {
/* 146 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 148 */     setBytes(index, src, src.readerIndex(), length);
/* 149 */     src.readerIndex(src.readerIndex() + length);
/*     */   }
/*     */ 
/*     */   public byte readByte() {
/* 153 */     if (this.readerIndex == this.writerIndex) {
/* 154 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 156 */     return getByte(this.readerIndex++);
/*     */   }
/*     */ 
/*     */   public ChannelBuffer readBytes(int length) {
/* 160 */     checkReadableBytes(length);
/* 161 */     if (length == 0) {
/* 162 */       return ChannelBuffers.EMPTY_BUFFER;
/*     */     }
/* 164 */     ChannelBuffer buf = factory().getBuffer(length);
/* 165 */     buf.writeBytes(this, this.readerIndex, length);
/* 166 */     this.readerIndex += length;
/* 167 */     return buf;
/*     */   }
/*     */ 
/*     */   public void readBytes(byte[] dst, int dstIndex, int length) {
/* 171 */     checkReadableBytes(length);
/* 172 */     getBytes(this.readerIndex, dst, dstIndex, length);
/* 173 */     this.readerIndex += length;
/*     */   }
/*     */ 
/*     */   public void readBytes(byte[] dst) {
/* 177 */     readBytes(dst, 0, dst.length);
/*     */   }
/*     */ 
/*     */   public void readBytes(ChannelBuffer dst) {
/* 181 */     readBytes(dst, dst.writableBytes());
/*     */   }
/*     */ 
/*     */   public void readBytes(ChannelBuffer dst, int length) {
/* 185 */     if (length > dst.writableBytes()) {
/* 186 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 188 */     readBytes(dst, dst.writerIndex(), length);
/* 189 */     dst.writerIndex(dst.writerIndex() + length);
/*     */   }
/*     */ 
/*     */   public void readBytes(ChannelBuffer dst, int dstIndex, int length) {
/* 193 */     checkReadableBytes(length);
/* 194 */     getBytes(this.readerIndex, dst, dstIndex, length);
/* 195 */     this.readerIndex += length;
/*     */   }
/*     */ 
/*     */   public void readBytes(ByteBuffer dst) {
/* 199 */     int length = dst.remaining();
/* 200 */     checkReadableBytes(length);
/* 201 */     getBytes(this.readerIndex, dst);
/* 202 */     this.readerIndex += length;
/*     */   }
/*     */ 
/*     */   public void readBytes(OutputStream out, int length) throws IOException {
/* 206 */     checkReadableBytes(length);
/* 207 */     getBytes(this.readerIndex, out, length);
/* 208 */     this.readerIndex += length;
/*     */   }
/*     */ 
/*     */   public void skipBytes(int length) {
/* 212 */     int newReaderIndex = this.readerIndex + length;
/* 213 */     if (newReaderIndex > this.writerIndex) {
/* 214 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 216 */     this.readerIndex = newReaderIndex;
/*     */   }
/*     */ 
/*     */   public void writeByte(int value) {
/* 220 */     setByte(this.writerIndex++, value);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] src, int srcIndex, int length) {
/* 224 */     setBytes(this.writerIndex, src, srcIndex, length);
/* 225 */     this.writerIndex += length;
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] src) {
/* 229 */     writeBytes(src, 0, src.length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(ChannelBuffer src) {
/* 233 */     writeBytes(src, src.readableBytes());
/*     */   }
/*     */ 
/*     */   public void writeBytes(ChannelBuffer src, int length) {
/* 237 */     if (length > src.readableBytes()) {
/* 238 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 240 */     writeBytes(src, src.readerIndex(), length);
/* 241 */     src.readerIndex(src.readerIndex() + length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(ChannelBuffer src, int srcIndex, int length) {
/* 245 */     setBytes(this.writerIndex, src, srcIndex, length);
/* 246 */     this.writerIndex += length;
/*     */   }
/*     */ 
/*     */   public void writeBytes(ByteBuffer src) {
/* 250 */     int length = src.remaining();
/* 251 */     setBytes(this.writerIndex, src);
/* 252 */     this.writerIndex += length;
/*     */   }
/*     */ 
/*     */   public int writeBytes(InputStream in, int length) throws IOException {
/* 256 */     int writtenBytes = setBytes(this.writerIndex, in, length);
/* 257 */     if (writtenBytes > 0) {
/* 258 */       this.writerIndex += writtenBytes;
/*     */     }
/* 260 */     return writtenBytes;
/*     */   }
/*     */ 
/*     */   public ChannelBuffer copy() {
/* 264 */     return copy(this.readerIndex, readableBytes());
/*     */   }
/*     */ 
/*     */   public ByteBuffer toByteBuffer() {
/* 268 */     return toByteBuffer(this.readerIndex, readableBytes());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 273 */     return ((o instanceof ChannelBuffer)) && (ChannelBuffers.equals(this, (ChannelBuffer)o));
/*     */   }
/*     */ 
/*     */   public int compareTo(ChannelBuffer that)
/*     */   {
/* 278 */     return ChannelBuffers.compare(this, that);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 283 */     return getClass().getSimpleName() + '(' + "ridx=" + this.readerIndex + ", " + "widx=" + this.writerIndex + ", " + "cap=" + capacity() + ')';
/*     */   }
/*     */ 
/*     */   protected void checkReadableBytes(int minimumReadableBytes)
/*     */   {
/* 291 */     if (readableBytes() < minimumReadableBytes)
/* 292 */       throw new IndexOutOfBoundsException();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.AbstractChannelBuffer
 * JD-Core Version:    0.6.2
 */