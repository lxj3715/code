/*     */ package com.alibaba.dubbo.remoting.buffer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public class ByteBufferBackedChannelBuffer extends AbstractChannelBuffer
/*     */ {
/*     */   private final ByteBuffer buffer;
/*     */   private final int capacity;
/*     */ 
/*     */   public ByteBufferBackedChannelBuffer(ByteBuffer buffer)
/*     */   {
/*  35 */     if (buffer == null) {
/*  36 */       throw new NullPointerException("buffer");
/*     */     }
/*     */ 
/*  39 */     this.buffer = buffer.slice();
/*  40 */     this.capacity = buffer.remaining();
/*  41 */     writerIndex(this.capacity);
/*     */   }
/*     */ 
/*     */   private ByteBufferBackedChannelBuffer(ByteBufferBackedChannelBuffer buffer) {
/*  45 */     this.buffer = buffer.buffer;
/*  46 */     this.capacity = buffer.capacity;
/*  47 */     setIndex(buffer.readerIndex(), buffer.writerIndex());
/*     */   }
/*     */ 
/*     */   public ChannelBufferFactory factory() {
/*  51 */     if (this.buffer.isDirect()) {
/*  52 */       return DirectChannelBufferFactory.getInstance();
/*     */     }
/*  54 */     return HeapChannelBufferFactory.getInstance();
/*     */   }
/*     */ 
/*     */   public int capacity()
/*     */   {
/*  60 */     return this.capacity;
/*     */   }
/*     */ 
/*     */   public ChannelBuffer copy(int index, int length)
/*     */   {
/*     */     ByteBuffer src;
/*     */     try {
/*  67 */       src = (ByteBuffer)this.buffer.duplicate().position(index).limit(index + length);
/*     */     } catch (IllegalArgumentException e) {
/*  69 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */ 
/*  72 */     ByteBuffer dst = this.buffer.isDirect() ? ByteBuffer.allocateDirect(length) : ByteBuffer.allocate(length);
/*     */ 
/*  75 */     dst.put(src);
/*  76 */     dst.clear();
/*  77 */     return new ByteBufferBackedChannelBuffer(dst);
/*     */   }
/*     */ 
/*     */   public byte getByte(int index)
/*     */   {
/*  82 */     return this.buffer.get(index);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, byte[] dst, int dstIndex, int length)
/*     */   {
/*  87 */     ByteBuffer data = this.buffer.duplicate();
/*     */     try {
/*  89 */       data.limit(index + length).position(index);
/*     */     } catch (IllegalArgumentException e) {
/*  91 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  93 */     data.get(dst, dstIndex, length);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, ByteBuffer dst)
/*     */   {
/*  98 */     ByteBuffer data = this.buffer.duplicate();
/*  99 */     int bytesToCopy = Math.min(capacity() - index, dst.remaining());
/*     */     try {
/* 101 */       data.limit(index + bytesToCopy).position(index);
/*     */     } catch (IllegalArgumentException e) {
/* 103 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 105 */     dst.put(data);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, ChannelBuffer dst, int dstIndex, int length)
/*     */   {
/* 110 */     if ((dst instanceof ByteBufferBackedChannelBuffer)) {
/* 111 */       ByteBufferBackedChannelBuffer bbdst = (ByteBufferBackedChannelBuffer)dst;
/* 112 */       ByteBuffer data = bbdst.buffer.duplicate();
/*     */ 
/* 114 */       data.limit(dstIndex + length).position(dstIndex);
/* 115 */       getBytes(index, data);
/* 116 */     } else if (this.buffer.hasArray()) {
/* 117 */       dst.setBytes(dstIndex, this.buffer.array(), index + this.buffer.arrayOffset(), length);
/*     */     } else {
/* 119 */       dst.setBytes(dstIndex, this, index, length);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, OutputStream out, int length) throws IOException
/*     */   {
/* 125 */     if (length == 0) {
/* 126 */       return;
/*     */     }
/*     */ 
/* 129 */     if (this.buffer.hasArray()) {
/* 130 */       out.write(this.buffer.array(), index + this.buffer.arrayOffset(), length);
/*     */     }
/*     */     else
/*     */     {
/* 135 */       byte[] tmp = new byte[length];
/* 136 */       ((ByteBuffer)this.buffer.duplicate().position(index)).get(tmp);
/* 137 */       out.write(tmp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isDirect()
/*     */   {
/* 143 */     return this.buffer.isDirect();
/*     */   }
/*     */ 
/*     */   public void setByte(int index, int value)
/*     */   {
/* 148 */     this.buffer.put(index, (byte)value);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, byte[] src, int srcIndex, int length)
/*     */   {
/* 153 */     ByteBuffer data = this.buffer.duplicate();
/* 154 */     data.limit(index + length).position(index);
/* 155 */     data.put(src, srcIndex, length);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, ByteBuffer src)
/*     */   {
/* 160 */     ByteBuffer data = this.buffer.duplicate();
/* 161 */     data.limit(index + src.remaining()).position(index);
/* 162 */     data.put(src);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, ChannelBuffer src, int srcIndex, int length)
/*     */   {
/* 167 */     if ((src instanceof ByteBufferBackedChannelBuffer)) {
/* 168 */       ByteBufferBackedChannelBuffer bbsrc = (ByteBufferBackedChannelBuffer)src;
/* 169 */       ByteBuffer data = bbsrc.buffer.duplicate();
/*     */ 
/* 171 */       data.limit(srcIndex + length).position(srcIndex);
/* 172 */       setBytes(index, data);
/* 173 */     } else if (this.buffer.hasArray()) {
/* 174 */       src.getBytes(srcIndex, this.buffer.array(), index + this.buffer.arrayOffset(), length);
/*     */     } else {
/* 176 */       src.getBytes(srcIndex, this, index, length);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ByteBuffer toByteBuffer(int index, int length)
/*     */   {
/* 182 */     if ((index == 0) && (length == capacity())) {
/* 183 */       return this.buffer.duplicate();
/*     */     }
/* 185 */     return ((ByteBuffer)this.buffer.duplicate().position(index).limit(index + length)).slice();
/*     */   }
/*     */ 
/*     */   public int setBytes(int index, InputStream in, int length)
/*     */     throws IOException
/*     */   {
/* 192 */     int readBytes = 0;
/*     */ 
/* 194 */     if (this.buffer.hasArray()) {
/* 195 */       index += this.buffer.arrayOffset();
/*     */       do {
/* 197 */         int localReadBytes = in.read(this.buffer.array(), index, length);
/* 198 */         if (localReadBytes < 0) {
/* 199 */           if (readBytes != 0) break;
/* 200 */           return -1;
/*     */         }
/*     */ 
/* 205 */         readBytes += localReadBytes;
/* 206 */         index += localReadBytes;
/* 207 */         length -= localReadBytes;
/* 208 */       }while (length > 0);
/*     */     } else {
/* 210 */       byte[] tmp = new byte[length];
/* 211 */       int i = 0;
/*     */       do {
/* 213 */         int localReadBytes = in.read(tmp, i, tmp.length - i);
/* 214 */         if (localReadBytes < 0) {
/* 215 */           if (readBytes != 0) break;
/* 216 */           return -1;
/*     */         }
/*     */ 
/* 221 */         readBytes += localReadBytes;
/* 222 */         i += readBytes;
/* 223 */       }while (i < tmp.length);
/* 224 */       ((ByteBuffer)this.buffer.duplicate().position(index)).put(tmp);
/*     */     }
/*     */ 
/* 227 */     return readBytes;
/*     */   }
/*     */ 
/*     */   public byte[] array()
/*     */   {
/* 232 */     return this.buffer.array();
/*     */   }
/*     */ 
/*     */   public boolean hasArray()
/*     */   {
/* 237 */     return this.buffer.hasArray();
/*     */   }
/*     */ 
/*     */   public int arrayOffset()
/*     */   {
/* 242 */     return this.buffer.arrayOffset();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.ByteBufferBackedChannelBuffer
 * JD-Core Version:    0.6.2
 */