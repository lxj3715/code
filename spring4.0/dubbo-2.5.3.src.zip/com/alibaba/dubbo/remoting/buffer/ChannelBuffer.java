package com.alibaba.dubbo.remoting.buffer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public abstract interface ChannelBuffer extends Comparable<ChannelBuffer>
{
  public abstract int capacity();

  public abstract void clear();

  public abstract ChannelBuffer copy();

  public abstract ChannelBuffer copy(int paramInt1, int paramInt2);

  public abstract void discardReadBytes();

  public abstract void ensureWritableBytes(int paramInt);

  public abstract boolean equals(Object paramObject);

  public abstract ChannelBufferFactory factory();

  public abstract byte getByte(int paramInt);

  public abstract void getBytes(int paramInt, byte[] paramArrayOfByte);

  public abstract void getBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);

  public abstract void getBytes(int paramInt, ByteBuffer paramByteBuffer);

  public abstract void getBytes(int paramInt, ChannelBuffer paramChannelBuffer);

  public abstract void getBytes(int paramInt1, ChannelBuffer paramChannelBuffer, int paramInt2);

  public abstract void getBytes(int paramInt1, ChannelBuffer paramChannelBuffer, int paramInt2, int paramInt3);

  public abstract void getBytes(int paramInt1, OutputStream paramOutputStream, int paramInt2)
    throws IOException;

  public abstract boolean isDirect();

  public abstract void markReaderIndex();

  public abstract void markWriterIndex();

  public abstract boolean readable();

  public abstract int readableBytes();

  public abstract byte readByte();

  public abstract void readBytes(byte[] paramArrayOfByte);

  public abstract void readBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract void readBytes(ByteBuffer paramByteBuffer);

  public abstract void readBytes(ChannelBuffer paramChannelBuffer);

  public abstract void readBytes(ChannelBuffer paramChannelBuffer, int paramInt);

  public abstract void readBytes(ChannelBuffer paramChannelBuffer, int paramInt1, int paramInt2);

  public abstract ChannelBuffer readBytes(int paramInt);

  public abstract void resetReaderIndex();

  public abstract void resetWriterIndex();

  public abstract int readerIndex();

  public abstract void readerIndex(int paramInt);

  public abstract void readBytes(OutputStream paramOutputStream, int paramInt)
    throws IOException;

  public abstract void setByte(int paramInt1, int paramInt2);

  public abstract void setBytes(int paramInt, byte[] paramArrayOfByte);

  public abstract void setBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);

  public abstract void setBytes(int paramInt, ByteBuffer paramByteBuffer);

  public abstract void setBytes(int paramInt, ChannelBuffer paramChannelBuffer);

  public abstract void setBytes(int paramInt1, ChannelBuffer paramChannelBuffer, int paramInt2);

  public abstract void setBytes(int paramInt1, ChannelBuffer paramChannelBuffer, int paramInt2, int paramInt3);

  public abstract int setBytes(int paramInt1, InputStream paramInputStream, int paramInt2)
    throws IOException;

  public abstract void setIndex(int paramInt1, int paramInt2);

  public abstract void skipBytes(int paramInt);

  public abstract ByteBuffer toByteBuffer();

  public abstract ByteBuffer toByteBuffer(int paramInt1, int paramInt2);

  public abstract boolean writable();

  public abstract int writableBytes();

  public abstract void writeByte(int paramInt);

  public abstract void writeBytes(byte[] paramArrayOfByte);

  public abstract void writeBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract void writeBytes(ByteBuffer paramByteBuffer);

  public abstract void writeBytes(ChannelBuffer paramChannelBuffer);

  public abstract void writeBytes(ChannelBuffer paramChannelBuffer, int paramInt);

  public abstract void writeBytes(ChannelBuffer paramChannelBuffer, int paramInt1, int paramInt2);

  public abstract int writeBytes(InputStream paramInputStream, int paramInt)
    throws IOException;

  public abstract int writerIndex();

  public abstract void writerIndex(int paramInt);

  public abstract byte[] array();

  public abstract boolean hasArray();

  public abstract int arrayOffset();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.ChannelBuffer
 * JD-Core Version:    0.6.2
 */