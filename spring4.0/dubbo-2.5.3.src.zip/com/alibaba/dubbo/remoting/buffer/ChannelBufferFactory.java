package com.alibaba.dubbo.remoting.buffer;

import java.nio.ByteBuffer;

public abstract interface ChannelBufferFactory
{
  public abstract ChannelBuffer getBuffer(int paramInt);

  public abstract ChannelBuffer getBuffer(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract ChannelBuffer getBuffer(ByteBuffer paramByteBuffer);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.ChannelBufferFactory
 * JD-Core Version:    0.6.2
 */