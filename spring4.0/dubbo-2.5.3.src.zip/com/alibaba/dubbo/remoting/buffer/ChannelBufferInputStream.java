/*     */ package com.alibaba.dubbo.remoting.buffer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class ChannelBufferInputStream extends InputStream
/*     */ {
/*     */   private final ChannelBuffer buffer;
/*     */   private final int startIndex;
/*     */   private final int endIndex;
/*     */ 
/*     */   public ChannelBufferInputStream(ChannelBuffer buffer)
/*     */   {
/*  32 */     this(buffer, buffer.readableBytes());
/*     */   }
/*     */ 
/*     */   public ChannelBufferInputStream(ChannelBuffer buffer, int length) {
/*  36 */     if (buffer == null) {
/*  37 */       throw new NullPointerException("buffer");
/*     */     }
/*  39 */     if (length < 0) {
/*  40 */       throw new IllegalArgumentException("length: " + length);
/*     */     }
/*  42 */     if (length > buffer.readableBytes()) {
/*  43 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */ 
/*  46 */     this.buffer = buffer;
/*  47 */     this.startIndex = buffer.readerIndex();
/*  48 */     this.endIndex = (this.startIndex + length);
/*  49 */     buffer.markReaderIndex();
/*     */   }
/*     */ 
/*     */   public int readBytes() {
/*  53 */     return this.buffer.readerIndex() - this.startIndex;
/*     */   }
/*     */ 
/*     */   public int available() throws IOException
/*     */   {
/*  58 */     return this.endIndex - this.buffer.readerIndex();
/*     */   }
/*     */ 
/*     */   public void mark(int readlimit)
/*     */   {
/*  63 */     this.buffer.markReaderIndex();
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/*  73 */     if (!this.buffer.readable()) {
/*  74 */       return -1;
/*     */     }
/*  76 */     return this.buffer.readByte() & 0xFF;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/*  81 */     int available = available();
/*  82 */     if (available == 0) {
/*  83 */       return -1;
/*     */     }
/*     */ 
/*  86 */     len = Math.min(available, len);
/*  87 */     this.buffer.readBytes(b, off, len);
/*  88 */     return len;
/*     */   }
/*     */ 
/*     */   public void reset() throws IOException
/*     */   {
/*  93 */     this.buffer.resetReaderIndex();
/*     */   }
/*     */ 
/*     */   public long skip(long n) throws IOException
/*     */   {
/*  98 */     if (n > 2147483647L) {
/*  99 */       return skipBytes(2147483647);
/*     */     }
/* 101 */     return skipBytes((int)n);
/*     */   }
/*     */ 
/*     */   private int skipBytes(int n) throws IOException
/*     */   {
/* 106 */     int nBytes = Math.min(available(), n);
/* 107 */     this.buffer.skipBytes(nBytes);
/* 108 */     return nBytes;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.ChannelBufferInputStream
 * JD-Core Version:    0.6.2
 */