/*    */ package com.alibaba.dubbo.remoting.buffer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class ChannelBufferOutputStream extends OutputStream
/*    */ {
/*    */   private final ChannelBuffer buffer;
/*    */   private final int startIndex;
/*    */ 
/*    */   public ChannelBufferOutputStream(ChannelBuffer buffer)
/*    */   {
/* 31 */     if (buffer == null) {
/* 32 */       throw new NullPointerException("buffer");
/*    */     }
/* 34 */     this.buffer = buffer;
/* 35 */     this.startIndex = buffer.writerIndex();
/*    */   }
/*    */ 
/*    */   public int writtenBytes() {
/* 39 */     return this.buffer.writerIndex() - this.startIndex;
/*    */   }
/*    */ 
/*    */   public void write(byte[] b, int off, int len) throws IOException
/*    */   {
/* 44 */     if (len == 0) {
/* 45 */       return;
/*    */     }
/*    */ 
/* 48 */     this.buffer.writeBytes(b, off, len);
/*    */   }
/*    */ 
/*    */   public void write(byte[] b) throws IOException
/*    */   {
/* 53 */     this.buffer.writeBytes(b);
/*    */   }
/*    */ 
/*    */   public void write(int b) throws IOException
/*    */   {
/* 58 */     this.buffer.writeByte((byte)b);
/*    */   }
/*    */ 
/*    */   public ChannelBuffer buffer() {
/* 62 */     return this.buffer;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.ChannelBufferOutputStream
 * JD-Core Version:    0.6.2
 */