/*     */ package com.alibaba.dubbo.remoting.buffer;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public final class ChannelBuffers
/*     */ {
/*  26 */   public static final ChannelBuffer EMPTY_BUFFER = new HeapChannelBuffer(0);
/*     */ 
/*     */   public static ChannelBuffer dynamicBuffer()
/*     */   {
/*  31 */     return dynamicBuffer(256);
/*     */   }
/*     */ 
/*     */   public static ChannelBuffer dynamicBuffer(int capacity) {
/*  35 */     return new DynamicChannelBuffer(capacity);
/*     */   }
/*     */ 
/*     */   public static ChannelBuffer dynamicBuffer(int capacity, ChannelBufferFactory factory)
/*     */   {
/*  40 */     return new DynamicChannelBuffer(capacity, factory);
/*     */   }
/*     */ 
/*     */   public static ChannelBuffer buffer(int capacity) {
/*  44 */     if (capacity < 0) {
/*  45 */       throw new IllegalArgumentException("capacity can not be negative");
/*     */     }
/*  47 */     if (capacity == 0) {
/*  48 */       return EMPTY_BUFFER;
/*     */     }
/*  50 */     return new HeapChannelBuffer(capacity);
/*     */   }
/*     */ 
/*     */   public static ChannelBuffer wrappedBuffer(byte[] array, int offset, int length) {
/*  54 */     if (array == null) {
/*  55 */       throw new NullPointerException("array == null");
/*     */     }
/*  57 */     byte[] dest = new byte[length];
/*  58 */     System.arraycopy(array, offset, dest, 0, length);
/*  59 */     return wrappedBuffer(dest);
/*     */   }
/*     */ 
/*     */   public static ChannelBuffer wrappedBuffer(byte[] array) {
/*  63 */     if (array == null) {
/*  64 */       throw new NullPointerException("array == null");
/*     */     }
/*  66 */     if (array.length == 0) {
/*  67 */       return EMPTY_BUFFER;
/*     */     }
/*  69 */     return new HeapChannelBuffer(array);
/*     */   }
/*     */ 
/*     */   public static ChannelBuffer wrappedBuffer(ByteBuffer buffer) {
/*  73 */     if (!buffer.hasRemaining()) {
/*  74 */       return EMPTY_BUFFER;
/*     */     }
/*  76 */     if (buffer.hasArray()) {
/*  77 */       return wrappedBuffer(buffer.array(), buffer.arrayOffset() + buffer.position(), buffer.remaining());
/*     */     }
/*  79 */     return new ByteBufferBackedChannelBuffer(buffer);
/*     */   }
/*     */ 
/*     */   public static ChannelBuffer directBuffer(int capacity)
/*     */   {
/*  84 */     if (capacity == 0) {
/*  85 */       return EMPTY_BUFFER;
/*     */     }
/*     */ 
/*  88 */     ChannelBuffer buffer = new ByteBufferBackedChannelBuffer(ByteBuffer.allocateDirect(capacity));
/*     */ 
/*  90 */     buffer.clear();
/*  91 */     return buffer;
/*     */   }
/*     */ 
/*     */   public static boolean equals(ChannelBuffer bufferA, ChannelBuffer bufferB) {
/*  95 */     int aLen = bufferA.readableBytes();
/*  96 */     if (aLen != bufferB.readableBytes()) {
/*  97 */       return false;
/*     */     }
/*     */ 
/* 100 */     int byteCount = aLen & 0x7;
/*     */ 
/* 102 */     int aIndex = bufferA.readerIndex();
/* 103 */     int bIndex = bufferB.readerIndex();
/*     */ 
/* 105 */     for (int i = byteCount; i > 0; i--) {
/* 106 */       if (bufferA.getByte(aIndex) != bufferB.getByte(bIndex)) {
/* 107 */         return false;
/*     */       }
/* 109 */       aIndex++;
/* 110 */       bIndex++;
/*     */     }
/*     */ 
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */   public static int compare(ChannelBuffer bufferA, ChannelBuffer bufferB) {
/* 117 */     int aLen = bufferA.readableBytes();
/* 118 */     int bLen = bufferB.readableBytes();
/* 119 */     int minLength = Math.min(aLen, bLen);
/*     */ 
/* 121 */     int aIndex = bufferA.readerIndex();
/* 122 */     int bIndex = bufferB.readerIndex();
/*     */ 
/* 124 */     for (int i = minLength; i > 0; i--) {
/* 125 */       byte va = bufferA.getByte(aIndex);
/* 126 */       byte vb = bufferB.getByte(bIndex);
/* 127 */       if (va > vb)
/* 128 */         return 1;
/* 129 */       if (va < vb) {
/* 130 */         return -1;
/*     */       }
/* 132 */       aIndex++;
/* 133 */       bIndex++;
/*     */     }
/*     */ 
/* 136 */     return aLen - bLen;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.ChannelBuffers
 * JD-Core Version:    0.6.2
 */