/*    */ package com.alibaba.dubbo.remoting.buffer;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class DirectChannelBufferFactory
/*    */   implements ChannelBufferFactory
/*    */ {
/* 26 */   private static final DirectChannelBufferFactory INSTANCE = new DirectChannelBufferFactory();
/*    */ 
/*    */   public static ChannelBufferFactory getInstance() {
/* 29 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   public ChannelBuffer getBuffer(int capacity)
/*    */   {
/* 37 */     if (capacity < 0) {
/* 38 */       throw new IllegalArgumentException("capacity: " + capacity);
/*    */     }
/* 40 */     if (capacity == 0) {
/* 41 */       return ChannelBuffers.EMPTY_BUFFER;
/*    */     }
/* 43 */     return ChannelBuffers.directBuffer(capacity);
/*    */   }
/*    */ 
/*    */   public ChannelBuffer getBuffer(byte[] array, int offset, int length) {
/* 47 */     if (array == null) {
/* 48 */       throw new NullPointerException("array");
/*    */     }
/* 50 */     if (offset < 0) {
/* 51 */       throw new IndexOutOfBoundsException("offset: " + offset);
/*    */     }
/* 53 */     if (length == 0) {
/* 54 */       return ChannelBuffers.EMPTY_BUFFER;
/*    */     }
/* 56 */     if (offset + length > array.length) {
/* 57 */       throw new IndexOutOfBoundsException("length: " + length);
/*    */     }
/*    */ 
/* 60 */     ChannelBuffer buf = getBuffer(length);
/* 61 */     buf.writeBytes(array, offset, length);
/* 62 */     return buf;
/*    */   }
/*    */ 
/*    */   public ChannelBuffer getBuffer(ByteBuffer nioBuffer) {
/* 66 */     if ((!nioBuffer.isReadOnly()) && (nioBuffer.isDirect())) {
/* 67 */       return ChannelBuffers.wrappedBuffer(nioBuffer);
/*    */     }
/*    */ 
/* 70 */     ChannelBuffer buf = getBuffer(nioBuffer.remaining());
/* 71 */     int pos = nioBuffer.position();
/* 72 */     buf.writeBytes(nioBuffer);
/* 73 */     nioBuffer.position(pos);
/* 74 */     return buf;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.DirectChannelBufferFactory
 * JD-Core Version:    0.6.2
 */