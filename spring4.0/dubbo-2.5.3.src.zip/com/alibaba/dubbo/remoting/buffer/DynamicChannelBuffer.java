/*     */ package com.alibaba.dubbo.remoting.buffer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ public class DynamicChannelBuffer extends AbstractChannelBuffer
/*     */ {
/*     */   private final ChannelBufferFactory factory;
/*     */   private ChannelBuffer buffer;
/*     */ 
/*     */   public DynamicChannelBuffer(int estimatedLength)
/*     */   {
/*  35 */     this(estimatedLength, HeapChannelBufferFactory.getInstance());
/*     */   }
/*     */ 
/*     */   public DynamicChannelBuffer(int estimatedLength, ChannelBufferFactory factory) {
/*  39 */     if (estimatedLength < 0) {
/*  40 */       throw new IllegalArgumentException("estimatedLength: " + estimatedLength);
/*     */     }
/*  42 */     if (factory == null) {
/*  43 */       throw new NullPointerException("factory");
/*     */     }
/*  45 */     this.factory = factory;
/*  46 */     this.buffer = factory.getBuffer(estimatedLength);
/*     */   }
/*     */ 
/*     */   public void ensureWritableBytes(int minWritableBytes)
/*     */   {
/*  51 */     if (minWritableBytes <= writableBytes())
/*     */       return;
/*     */     int newCapacity;
/*     */     int newCapacity;
/*  56 */     if (capacity() == 0)
/*  57 */       newCapacity = 1;
/*     */     else {
/*  59 */       newCapacity = capacity();
/*     */     }
/*  61 */     int minNewCapacity = writerIndex() + minWritableBytes;
/*  62 */     while (newCapacity < minNewCapacity) {
/*  63 */       newCapacity <<= 1;
/*     */     }
/*     */ 
/*  66 */     ChannelBuffer newBuffer = factory().getBuffer(newCapacity);
/*  67 */     newBuffer.writeBytes(this.buffer, 0, writerIndex());
/*  68 */     this.buffer = newBuffer;
/*     */   }
/*     */ 
/*     */   public int capacity()
/*     */   {
/*  73 */     return this.buffer.capacity();
/*     */   }
/*     */ 
/*     */   public ChannelBuffer copy(int index, int length)
/*     */   {
/*  78 */     DynamicChannelBuffer copiedBuffer = new DynamicChannelBuffer(Math.max(length, 64), factory());
/*  79 */     copiedBuffer.buffer = this.buffer.copy(index, length);
/*  80 */     copiedBuffer.setIndex(0, length);
/*  81 */     return copiedBuffer;
/*     */   }
/*     */ 
/*     */   public ChannelBufferFactory factory()
/*     */   {
/*  86 */     return this.factory;
/*     */   }
/*     */ 
/*     */   public byte getByte(int index)
/*     */   {
/*  91 */     return this.buffer.getByte(index);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, byte[] dst, int dstIndex, int length)
/*     */   {
/*  96 */     this.buffer.getBytes(index, dst, dstIndex, length);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, ByteBuffer dst)
/*     */   {
/* 101 */     this.buffer.getBytes(index, dst);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, ChannelBuffer dst, int dstIndex, int length)
/*     */   {
/* 106 */     this.buffer.getBytes(index, dst, dstIndex, length);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, OutputStream dst, int length) throws IOException
/*     */   {
/* 111 */     this.buffer.getBytes(index, dst, length);
/*     */   }
/*     */ 
/*     */   public boolean isDirect()
/*     */   {
/* 116 */     return this.buffer.isDirect();
/*     */   }
/*     */ 
/*     */   public void setByte(int index, int value)
/*     */   {
/* 121 */     this.buffer.setByte(index, value);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, byte[] src, int srcIndex, int length)
/*     */   {
/* 126 */     this.buffer.setBytes(index, src, srcIndex, length);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, ByteBuffer src)
/*     */   {
/* 131 */     this.buffer.setBytes(index, src);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, ChannelBuffer src, int srcIndex, int length)
/*     */   {
/* 136 */     this.buffer.setBytes(index, src, srcIndex, length);
/*     */   }
/*     */ 
/*     */   public int setBytes(int index, InputStream src, int length) throws IOException
/*     */   {
/* 141 */     return this.buffer.setBytes(index, src, length);
/*     */   }
/*     */ 
/*     */   public ByteBuffer toByteBuffer(int index, int length)
/*     */   {
/* 146 */     return this.buffer.toByteBuffer(index, length);
/*     */   }
/*     */ 
/*     */   public void writeByte(int value)
/*     */   {
/* 151 */     ensureWritableBytes(1);
/* 152 */     super.writeByte(value);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] src, int srcIndex, int length)
/*     */   {
/* 157 */     ensureWritableBytes(length);
/* 158 */     super.writeBytes(src, srcIndex, length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(ChannelBuffer src, int srcIndex, int length)
/*     */   {
/* 163 */     ensureWritableBytes(length);
/* 164 */     super.writeBytes(src, srcIndex, length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(ByteBuffer src)
/*     */   {
/* 169 */     ensureWritableBytes(src.remaining());
/* 170 */     super.writeBytes(src);
/*     */   }
/*     */ 
/*     */   public int writeBytes(InputStream in, int length) throws IOException
/*     */   {
/* 175 */     ensureWritableBytes(length);
/* 176 */     return super.writeBytes(in, length);
/*     */   }
/*     */ 
/*     */   public byte[] array()
/*     */   {
/* 181 */     return this.buffer.array();
/*     */   }
/*     */ 
/*     */   public boolean hasArray()
/*     */   {
/* 186 */     return this.buffer.hasArray();
/*     */   }
/*     */ 
/*     */   public int arrayOffset()
/*     */   {
/* 191 */     return this.buffer.arrayOffset();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.DynamicChannelBuffer
 * JD-Core Version:    0.6.2
 */