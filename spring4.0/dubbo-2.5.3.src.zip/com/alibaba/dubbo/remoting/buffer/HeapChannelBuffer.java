/*     */ package com.alibaba.dubbo.remoting.buffer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.nio.channels.GatheringByteChannel;
/*     */ import java.nio.channels.ScatteringByteChannel;
/*     */ 
/*     */ public class HeapChannelBuffer extends AbstractChannelBuffer
/*     */ {
/*     */   protected final byte[] array;
/*     */ 
/*     */   public HeapChannelBuffer(int length)
/*     */   {
/*  43 */     this(new byte[length], 0, 0);
/*     */   }
/*     */ 
/*     */   public HeapChannelBuffer(byte[] array)
/*     */   {
/*  52 */     this(array, 0, array.length);
/*     */   }
/*     */ 
/*     */   protected HeapChannelBuffer(byte[] array, int readerIndex, int writerIndex)
/*     */   {
/*  63 */     if (array == null) {
/*  64 */       throw new NullPointerException("array");
/*     */     }
/*  66 */     this.array = array;
/*  67 */     setIndex(readerIndex, writerIndex);
/*     */   }
/*     */ 
/*     */   public boolean isDirect() {
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */   public int capacity() {
/*  75 */     return this.array.length;
/*     */   }
/*     */ 
/*     */   public boolean hasArray() {
/*  79 */     return true;
/*     */   }
/*     */ 
/*     */   public byte[] array() {
/*  83 */     return this.array;
/*     */   }
/*     */ 
/*     */   public int arrayOffset() {
/*  87 */     return 0;
/*     */   }
/*     */ 
/*     */   public byte getByte(int index) {
/*  91 */     return this.array[index];
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, ChannelBuffer dst, int dstIndex, int length) {
/*  95 */     if ((dst instanceof HeapChannelBuffer))
/*  96 */       getBytes(index, ((HeapChannelBuffer)dst).array, dstIndex, length);
/*     */     else
/*  98 */       dst.setBytes(dstIndex, this.array, index, length);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, byte[] dst, int dstIndex, int length)
/*     */   {
/* 103 */     System.arraycopy(this.array, index, dst, dstIndex, length);
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, ByteBuffer dst) {
/* 107 */     dst.put(this.array, index, Math.min(capacity() - index, dst.remaining()));
/*     */   }
/*     */ 
/*     */   public void getBytes(int index, OutputStream out, int length) throws IOException
/*     */   {
/* 112 */     out.write(this.array, index, length);
/*     */   }
/*     */ 
/*     */   public int getBytes(int index, GatheringByteChannel out, int length) throws IOException
/*     */   {
/* 117 */     return out.write(ByteBuffer.wrap(this.array, index, length));
/*     */   }
/*     */ 
/*     */   public void setByte(int index, int value) {
/* 121 */     this.array[index] = ((byte)value);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, ChannelBuffer src, int srcIndex, int length) {
/* 125 */     if ((src instanceof HeapChannelBuffer))
/* 126 */       setBytes(index, ((HeapChannelBuffer)src).array, srcIndex, length);
/*     */     else
/* 128 */       src.getBytes(srcIndex, this.array, index, length);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, byte[] src, int srcIndex, int length)
/*     */   {
/* 133 */     System.arraycopy(src, srcIndex, this.array, index, length);
/*     */   }
/*     */ 
/*     */   public void setBytes(int index, ByteBuffer src) {
/* 137 */     src.get(this.array, index, src.remaining());
/*     */   }
/*     */ 
/*     */   public int setBytes(int index, InputStream in, int length) throws IOException {
/* 141 */     int readBytes = 0;
/*     */     do {
/* 143 */       int localReadBytes = in.read(this.array, index, length);
/* 144 */       if (localReadBytes < 0) {
/* 145 */         if (readBytes != 0) break;
/* 146 */         return -1;
/*     */       }
/*     */ 
/* 151 */       readBytes += localReadBytes;
/* 152 */       index += localReadBytes;
/* 153 */       length -= localReadBytes;
/* 154 */     }while (length > 0);
/*     */ 
/* 156 */     return readBytes;
/*     */   }
/*     */ 
/*     */   public int setBytes(int index, ScatteringByteChannel in, int length) throws IOException {
/* 160 */     ByteBuffer buf = ByteBuffer.wrap(this.array, index, length);
/* 161 */     int readBytes = 0;
/*     */     do
/*     */     {
/*     */       int localReadBytes;
/*     */       try {
/* 166 */         localReadBytes = in.read(buf);
/*     */       } catch (ClosedChannelException e) {
/* 168 */         localReadBytes = -1;
/*     */       }
/* 170 */       if (localReadBytes < 0) {
/* 171 */         if (readBytes != 0) break;
/* 172 */         return -1;
/*     */       }
/*     */ 
/* 176 */       if (localReadBytes == 0) {
/*     */         break;
/*     */       }
/* 179 */       readBytes += localReadBytes;
/* 180 */     }while (readBytes < length);
/*     */ 
/* 182 */     return readBytes;
/*     */   }
/*     */ 
/*     */   public ChannelBuffer copy(int index, int length) {
/* 186 */     if ((index < 0) || (length < 0) || (index + length > this.array.length)) {
/* 187 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 190 */     byte[] copiedArray = new byte[length];
/* 191 */     System.arraycopy(this.array, index, copiedArray, 0, length);
/* 192 */     return new HeapChannelBuffer(copiedArray);
/*     */   }
/*     */ 
/*     */   public ChannelBufferFactory factory() {
/* 196 */     return HeapChannelBufferFactory.getInstance();
/*     */   }
/*     */ 
/*     */   public ByteBuffer toByteBuffer(int index, int length) {
/* 200 */     return ByteBuffer.wrap(this.array, index, length);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.HeapChannelBuffer
 * JD-Core Version:    0.6.2
 */