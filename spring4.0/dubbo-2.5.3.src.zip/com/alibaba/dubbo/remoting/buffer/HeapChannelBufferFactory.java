/*    */ package com.alibaba.dubbo.remoting.buffer;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class HeapChannelBufferFactory
/*    */   implements ChannelBufferFactory
/*    */ {
/* 26 */   private static final HeapChannelBufferFactory INSTANCE = new HeapChannelBufferFactory();
/*    */ 
/*    */   public static ChannelBufferFactory getInstance() {
/* 29 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   public ChannelBuffer getBuffer(int capacity)
/*    */   {
/* 37 */     return ChannelBuffers.buffer(capacity);
/*    */   }
/*    */ 
/*    */   public ChannelBuffer getBuffer(byte[] array, int offset, int length) {
/* 41 */     return ChannelBuffers.wrappedBuffer(array, offset, length);
/*    */   }
/*    */ 
/*    */   public ChannelBuffer getBuffer(ByteBuffer nioBuffer) {
/* 45 */     if (nioBuffer.hasArray()) {
/* 46 */       return ChannelBuffers.wrappedBuffer(nioBuffer);
/*    */     }
/*    */ 
/* 49 */     ChannelBuffer buf = getBuffer(nioBuffer.remaining());
/* 50 */     int pos = nioBuffer.position();
/* 51 */     buf.writeBytes(nioBuffer);
/* 52 */     nioBuffer.position(pos);
/* 53 */     return buf;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.buffer.HeapChannelBufferFactory
 * JD-Core Version:    0.6.2
 */