package com.alibaba.dubbo.remoting.exchange;

import com.alibaba.dubbo.remoting.Channel;
import com.alibaba.dubbo.remoting.RemotingException;

public abstract interface ExchangeChannel extends Channel
{
  public abstract ResponseFuture request(Object paramObject)
    throws RemotingException;

  public abstract ResponseFuture request(Object paramObject, int paramInt)
    throws RemotingException;

  public abstract ExchangeHandler getExchangeHandler();

  public abstract void close(int paramInt);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.ExchangeChannel
 * JD-Core Version:    0.6.2
 */