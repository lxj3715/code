package com.alibaba.dubbo.remoting.exchange;

import com.alibaba.dubbo.remoting.Client;

public abstract interface ExchangeClient extends Client, ExchangeChannel
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.ExchangeClient
 * JD-Core Version:    0.6.2
 */