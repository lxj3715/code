package com.alibaba.dubbo.remoting.exchange;

import com.alibaba.dubbo.remoting.ChannelHandler;
import com.alibaba.dubbo.remoting.RemotingException;
import com.alibaba.dubbo.remoting.telnet.TelnetHandler;

public abstract interface ExchangeHandler extends ChannelHandler, TelnetHandler
{
  public abstract Object reply(ExchangeChannel paramExchangeChannel, Object paramObject)
    throws RemotingException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.ExchangeHandler
 * JD-Core Version:    0.6.2
 */