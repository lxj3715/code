package com.alibaba.dubbo.remoting.exchange;

import com.alibaba.dubbo.remoting.Server;
import java.net.InetSocketAddress;
import java.util.Collection;

public abstract interface ExchangeServer extends Server
{
  public abstract Collection<ExchangeChannel> getExchangeChannels();

  public abstract ExchangeChannel getExchangeChannel(InetSocketAddress paramInetSocketAddress);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.ExchangeServer
 * JD-Core Version:    0.6.2
 */