package com.alibaba.dubbo.remoting.exchange;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;
import com.alibaba.dubbo.remoting.RemotingException;

@SPI("header")
public abstract interface Exchanger
{
  @Adaptive({"exchanger"})
  public abstract ExchangeServer bind(URL paramURL, ExchangeHandler paramExchangeHandler)
    throws RemotingException;

  @Adaptive({"exchanger"})
  public abstract ExchangeClient connect(URL paramURL, ExchangeHandler paramExchangeHandler)
    throws RemotingException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.Exchanger
 * JD-Core Version:    0.6.2
 */