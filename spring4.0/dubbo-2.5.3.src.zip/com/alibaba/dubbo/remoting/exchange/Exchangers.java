/*     */ package com.alibaba.dubbo.remoting.exchange;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.exchange.support.ExchangeHandlerDispatcher;
/*     */ import com.alibaba.dubbo.remoting.exchange.support.Replier;
/*     */ import com.alibaba.dubbo.remoting.transport.ChannelHandlerAdapter;
/*     */ 
/*     */ public class Exchangers
/*     */ {
/*     */   public static ExchangeServer bind(String url, Replier<?> replier)
/*     */     throws RemotingException
/*     */   {
/*  36 */     return bind(URL.valueOf(url), replier);
/*     */   }
/*     */ 
/*     */   public static ExchangeServer bind(URL url, Replier<?> replier) throws RemotingException {
/*  40 */     return bind(url, new ChannelHandlerAdapter(), replier);
/*     */   }
/*     */ 
/*     */   public static ExchangeServer bind(String url, ChannelHandler handler, Replier<?> replier) throws RemotingException {
/*  44 */     return bind(URL.valueOf(url), handler, replier);
/*     */   }
/*     */ 
/*     */   public static ExchangeServer bind(URL url, ChannelHandler handler, Replier<?> replier) throws RemotingException {
/*  48 */     return bind(url, new ExchangeHandlerDispatcher(replier, new ChannelHandler[] { handler }));
/*     */   }
/*     */ 
/*     */   public static ExchangeServer bind(String url, ExchangeHandler handler) throws RemotingException {
/*  52 */     return bind(URL.valueOf(url), handler);
/*     */   }
/*     */ 
/*     */   public static ExchangeServer bind(URL url, ExchangeHandler handler) throws RemotingException {
/*  56 */     if (url == null) {
/*  57 */       throw new IllegalArgumentException("url == null");
/*     */     }
/*  59 */     if (handler == null) {
/*  60 */       throw new IllegalArgumentException("handler == null");
/*     */     }
/*  62 */     url = url.addParameterIfAbsent("codec", "exchange");
/*  63 */     return getExchanger(url).bind(url, handler);
/*     */   }
/*     */ 
/*     */   public static ExchangeClient connect(String url) throws RemotingException {
/*  67 */     return connect(URL.valueOf(url));
/*     */   }
/*     */ 
/*     */   public static ExchangeClient connect(URL url) throws RemotingException {
/*  71 */     return connect(url, new ChannelHandlerAdapter(), null);
/*     */   }
/*     */ 
/*     */   public static ExchangeClient connect(String url, Replier<?> replier) throws RemotingException {
/*  75 */     return connect(URL.valueOf(url), new ChannelHandlerAdapter(), replier);
/*     */   }
/*     */ 
/*     */   public static ExchangeClient connect(URL url, Replier<?> replier) throws RemotingException {
/*  79 */     return connect(url, new ChannelHandlerAdapter(), replier);
/*     */   }
/*     */ 
/*     */   public static ExchangeClient connect(String url, ChannelHandler handler, Replier<?> replier) throws RemotingException {
/*  83 */     return connect(URL.valueOf(url), handler, replier);
/*     */   }
/*     */ 
/*     */   public static ExchangeClient connect(URL url, ChannelHandler handler, Replier<?> replier) throws RemotingException {
/*  87 */     return connect(url, new ExchangeHandlerDispatcher(replier, new ChannelHandler[] { handler }));
/*     */   }
/*     */ 
/*     */   public static ExchangeClient connect(String url, ExchangeHandler handler) throws RemotingException {
/*  91 */     return connect(URL.valueOf(url), handler);
/*     */   }
/*     */ 
/*     */   public static ExchangeClient connect(URL url, ExchangeHandler handler) throws RemotingException {
/*  95 */     if (url == null) {
/*  96 */       throw new IllegalArgumentException("url == null");
/*     */     }
/*  98 */     if (handler == null) {
/*  99 */       throw new IllegalArgumentException("handler == null");
/*     */     }
/* 101 */     url = url.addParameterIfAbsent("codec", "exchange");
/* 102 */     return getExchanger(url).connect(url, handler);
/*     */   }
/*     */ 
/*     */   public static Exchanger getExchanger(URL url) {
/* 106 */     String type = url.getParameter("exchanger", "header");
/* 107 */     return getExchanger(type);
/*     */   }
/*     */ 
/*     */   public static Exchanger getExchanger(String type) {
/* 111 */     return (Exchanger)ExtensionLoader.getExtensionLoader(Exchanger.class).getExtension(type);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 116 */     Version.checkDuplicate(Exchangers.class);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.Exchangers
 * JD-Core Version:    0.6.2
 */