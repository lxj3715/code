/*     */ package com.alibaba.dubbo.remoting.exchange;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ public class Request
/*     */ {
/*  28 */   public static final String HEARTBEAT_EVENT = null;
/*     */   public static final String READONLY_EVENT = "R";
/*  32 */   private static final AtomicLong INVOKE_ID = new AtomicLong(0L);
/*     */   private final long mId;
/*     */   private String mVersion;
/*  38 */   private boolean mTwoWay = true;
/*     */ 
/*  40 */   private boolean mEvent = false;
/*     */ 
/*  42 */   private boolean mBroken = false;
/*     */   private Object mData;
/*     */ 
/*     */   public Request()
/*     */   {
/*  47 */     this.mId = newId();
/*     */   }
/*     */ 
/*     */   public Request(long id) {
/*  51 */     this.mId = id;
/*     */   }
/*     */ 
/*     */   public long getId() {
/*  55 */     return this.mId;
/*     */   }
/*     */ 
/*     */   public String getVersion() {
/*  59 */     return this.mVersion;
/*     */   }
/*     */ 
/*     */   public void setVersion(String version) {
/*  63 */     this.mVersion = version;
/*     */   }
/*     */ 
/*     */   public boolean isTwoWay() {
/*  67 */     return this.mTwoWay;
/*     */   }
/*     */ 
/*     */   public void setTwoWay(boolean twoWay) {
/*  71 */     this.mTwoWay = twoWay;
/*     */   }
/*     */ 
/*     */   public boolean isEvent() {
/*  75 */     return this.mEvent;
/*     */   }
/*     */ 
/*     */   public void setEvent(String event) {
/*  79 */     this.mEvent = true;
/*  80 */     this.mData = event;
/*     */   }
/*     */ 
/*     */   public boolean isBroken() {
/*  84 */     return this.mBroken;
/*     */   }
/*     */ 
/*     */   public void setBroken(boolean mBroken) {
/*  88 */     this.mBroken = mBroken;
/*     */   }
/*     */ 
/*     */   public Object getData() {
/*  92 */     return this.mData;
/*     */   }
/*     */ 
/*     */   public void setData(Object msg) {
/*  96 */     this.mData = msg;
/*     */   }
/*     */ 
/*     */   public boolean isHeartbeat() {
/* 100 */     return (this.mEvent) && (HEARTBEAT_EVENT == this.mData);
/*     */   }
/*     */ 
/*     */   public void setHeartbeat(boolean isHeartbeat) {
/* 104 */     if (isHeartbeat)
/* 105 */       setEvent(HEARTBEAT_EVENT);
/*     */   }
/*     */ 
/*     */   private static long newId()
/*     */   {
/* 111 */     return INVOKE_ID.getAndIncrement();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 116 */     return "Request [id=" + this.mId + ", version=" + this.mVersion + ", twoway=" + this.mTwoWay + ", event=" + this.mEvent + ", broken=" + this.mBroken + ", data=" + (this.mData == this ? "this" : this.mData) + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.Request
 * JD-Core Version:    0.6.2
 */