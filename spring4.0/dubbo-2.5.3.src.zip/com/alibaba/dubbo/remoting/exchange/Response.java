/*     */ package com.alibaba.dubbo.remoting.exchange;
/*     */ 
/*     */ public class Response
/*     */ {
/*  26 */   public static final String HEARTBEAT_EVENT = null;
/*     */   public static final String READONLY_EVENT = "R";
/*     */   public static final byte OK = 20;
/*     */   public static final byte CLIENT_TIMEOUT = 30;
/*     */   public static final byte SERVER_TIMEOUT = 31;
/*     */   public static final byte BAD_REQUEST = 40;
/*     */   public static final byte BAD_RESPONSE = 50;
/*     */   public static final byte SERVICE_NOT_FOUND = 60;
/*     */   public static final byte SERVICE_ERROR = 70;
/*     */   public static final byte SERVER_ERROR = 80;
/*     */   public static final byte CLIENT_ERROR = 90;
/*  75 */   private long mId = 0L;
/*     */   private String mVersion;
/*  79 */   private byte mStatus = 20;
/*     */ 
/*  81 */   private boolean mEvent = false;
/*     */   private String mErrorMsg;
/*     */   private Object mResult;
/*     */ 
/*     */   public Response()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Response(long id)
/*     */   {
/*  91 */     this.mId = id;
/*     */   }
/*     */ 
/*     */   public Response(long id, String version) {
/*  95 */     this.mId = id;
/*  96 */     this.mVersion = version;
/*     */   }
/*     */ 
/*     */   public long getId() {
/* 100 */     return this.mId;
/*     */   }
/*     */ 
/*     */   public void setId(long id) {
/* 104 */     this.mId = id;
/*     */   }
/*     */ 
/*     */   public String getVersion() {
/* 108 */     return this.mVersion;
/*     */   }
/*     */ 
/*     */   public void setVersion(String version) {
/* 112 */     this.mVersion = version;
/*     */   }
/*     */ 
/*     */   public byte getStatus() {
/* 116 */     return this.mStatus;
/*     */   }
/*     */ 
/*     */   public void setStatus(byte status) {
/* 120 */     this.mStatus = status;
/*     */   }
/*     */ 
/*     */   public boolean isEvent() {
/* 124 */     return this.mEvent;
/*     */   }
/*     */ 
/*     */   public void setEvent(String event) {
/* 128 */     this.mEvent = true;
/* 129 */     this.mResult = event;
/*     */   }
/*     */ 
/*     */   public boolean isHeartbeat() {
/* 133 */     return (this.mEvent) && (HEARTBEAT_EVENT == this.mResult);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setHeartbeat(boolean isHeartbeat) {
/* 138 */     if (isHeartbeat)
/* 139 */       setEvent(HEARTBEAT_EVENT);
/*     */   }
/*     */ 
/*     */   public Object getResult()
/*     */   {
/* 144 */     return this.mResult;
/*     */   }
/*     */ 
/*     */   public void setResult(Object msg) {
/* 148 */     this.mResult = msg;
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 152 */     return this.mErrorMsg;
/*     */   }
/*     */ 
/*     */   public void setErrorMessage(String msg) {
/* 156 */     this.mErrorMsg = msg;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 161 */     return "Response [id=" + this.mId + ", version=" + this.mVersion + ", status=" + this.mStatus + ", event=" + this.mEvent + ", error=" + this.mErrorMsg + ", result=" + (this.mResult == this ? "this" : this.mResult) + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.Response
 * JD-Core Version:    0.6.2
 */