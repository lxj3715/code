package com.alibaba.dubbo.remoting.exchange;

public abstract interface ResponseCallback
{
  public abstract void done(Object paramObject);

  public abstract void caught(Throwable paramThrowable);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.ResponseCallback
 * JD-Core Version:    0.6.2
 */