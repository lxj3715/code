package com.alibaba.dubbo.remoting.exchange;

import com.alibaba.dubbo.remoting.RemotingException;

public abstract interface ResponseFuture
{
  public abstract Object get()
    throws RemotingException;

  public abstract Object get(int paramInt)
    throws RemotingException;

  public abstract void setCallback(ResponseCallback paramResponseCallback);

  public abstract boolean isDone();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.ResponseFuture
 * JD-Core Version:    0.6.2
 */