/*     */ package com.alibaba.dubbo.remoting.exchange.codec;
/*     */ 
/*     */ import com.alibaba.dubbo.common.io.Bytes;
/*     */ import com.alibaba.dubbo.common.io.StreamUtils;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*     */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*     */ import com.alibaba.dubbo.common.serialize.Serialization;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.Codec2.DecodeResult;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.buffer.ChannelBuffer;
/*     */ import com.alibaba.dubbo.remoting.buffer.ChannelBufferInputStream;
/*     */ import com.alibaba.dubbo.remoting.buffer.ChannelBufferOutputStream;
/*     */ import com.alibaba.dubbo.remoting.exchange.Request;
/*     */ import com.alibaba.dubbo.remoting.exchange.Response;
/*     */ import com.alibaba.dubbo.remoting.exchange.support.DefaultFuture;
/*     */ import com.alibaba.dubbo.remoting.telnet.codec.TelnetCodec;
/*     */ import com.alibaba.dubbo.remoting.transport.CodecSupport;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class ExchangeCodec extends TelnetCodec
/*     */ {
/*  48 */   private static final Logger logger = LoggerFactory.getLogger(ExchangeCodec.class);
/*     */   protected static final int HEADER_LENGTH = 16;
/*     */   protected static final short MAGIC = -9541;
/*  56 */   protected static final byte MAGIC_HIGH = Bytes.short2bytes(-9541)[0];
/*     */ 
/*  58 */   protected static final byte MAGIC_LOW = Bytes.short2bytes(-9541)[1];
/*     */   protected static final byte FLAG_REQUEST = -128;
/*     */   protected static final byte FLAG_TWOWAY = 64;
/*     */   protected static final byte FLAG_EVENT = 32;
/*     */   protected static final int SERIALIZATION_MASK = 31;
/*     */ 
/*     */   public Short getMagicCode()
/*     */   {
/*  70 */     return Short.valueOf((short)-9541);
/*     */   }
/*     */ 
/*     */   public void encode(Channel channel, ChannelBuffer buffer, Object msg) throws IOException {
/*  74 */     if ((msg instanceof Request))
/*  75 */       encodeRequest(channel, buffer, (Request)msg);
/*  76 */     else if ((msg instanceof Response))
/*  77 */       encodeResponse(channel, buffer, (Response)msg);
/*     */     else
/*  79 */       super.encode(channel, buffer, msg);
/*     */   }
/*     */ 
/*     */   public Object decode(Channel channel, ChannelBuffer buffer) throws IOException
/*     */   {
/*  84 */     int readable = buffer.readableBytes();
/*  85 */     byte[] header = new byte[Math.min(readable, 16)];
/*  86 */     buffer.readBytes(header);
/*  87 */     return decode(channel, buffer, readable, header);
/*     */   }
/*     */ 
/*     */   protected Object decode(Channel channel, ChannelBuffer buffer, int readable, byte[] header) throws IOException
/*     */   {
/*  92 */     if (((readable > 0) && (header[0] != MAGIC_HIGH)) || ((readable > 1) && (header[1] != MAGIC_LOW)))
/*     */     {
/*  94 */       int length = header.length;
/*  95 */       if (header.length < readable) {
/*  96 */         header = Bytes.copyOf(header, readable);
/*  97 */         buffer.readBytes(header, length, readable - length);
/*     */       }
/*  99 */       for (int i = 1; i < header.length - 1; i++) {
/* 100 */         if ((header[i] == MAGIC_HIGH) && (header[(i + 1)] == MAGIC_LOW)) {
/* 101 */           buffer.readerIndex(buffer.readerIndex() - header.length + i);
/* 102 */           header = Bytes.copyOf(header, i);
/* 103 */           break;
/*     */         }
/*     */       }
/* 106 */       return super.decode(channel, buffer, readable, header);
/*     */     }
/*     */ 
/* 109 */     if (readable < 16) {
/* 110 */       return Codec2.DecodeResult.NEED_MORE_INPUT;
/*     */     }
/*     */ 
/* 114 */     int len = Bytes.bytes2int(header, 12);
/* 115 */     checkPayload(channel, len);
/*     */ 
/* 117 */     int tt = len + 16;
/* 118 */     if (readable < tt) {
/* 119 */       return Codec2.DecodeResult.NEED_MORE_INPUT;
/*     */     }
/*     */ 
/* 123 */     ChannelBufferInputStream is = new ChannelBufferInputStream(buffer, len);
/*     */     try
/*     */     {
/* 126 */       return decodeBody(channel, is, header);
/*     */     } finally {
/* 128 */       if (is.available() > 0)
/*     */         try {
/* 130 */           if (logger.isWarnEnabled()) {
/* 131 */             logger.warn("Skip input stream " + is.available());
/*     */           }
/* 133 */           StreamUtils.skipUnusedStream(is);
/*     */         } catch (IOException e) {
/* 135 */           logger.warn(e.getMessage(), e);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object decodeBody(Channel channel, InputStream is, byte[] header) throws IOException
/*     */   {
/* 142 */     byte flag = header[2]; byte proto = (byte)(flag & 0x1F);
/* 143 */     Serialization s = CodecSupport.getSerialization(channel.getUrl(), Byte.valueOf(proto));
/* 144 */     ObjectInput in = s.deserialize(channel.getUrl(), is);
/*     */ 
/* 146 */     long id = Bytes.bytes2long(header, 4);
/* 147 */     if ((flag & 0xFFFFFF80) == 0)
/*     */     {
/* 149 */       Response res = new Response(id);
/* 150 */       if ((flag & 0x20) != 0) {
/* 151 */         res.setEvent(Response.HEARTBEAT_EVENT);
/*     */       }
/*     */ 
/* 154 */       byte status = header[3];
/* 155 */       res.setStatus(status);
/* 156 */       if (status == 20)
/*     */         try
/*     */         {
/*     */           Object data;
/*     */           Object data;
/* 159 */           if (res.isHeartbeat()) {
/* 160 */             data = decodeHeartbeatData(channel, in);
/*     */           }
/*     */           else
/*     */           {
/*     */             Object data;
/* 161 */             if (res.isEvent())
/* 162 */               data = decodeEventData(channel, in);
/*     */             else
/* 164 */               data = decodeResponseData(channel, in, getRequestData(id));
/*     */           }
/* 166 */           res.setResult(data);
/*     */         } catch (Throwable t) {
/* 168 */           res.setStatus((byte)90);
/* 169 */           res.setErrorMessage(StringUtils.toString(t));
/*     */         }
/*     */       else {
/* 172 */         res.setErrorMessage(in.readUTF());
/*     */       }
/* 174 */       return res;
/*     */     }
/*     */ 
/* 177 */     Request req = new Request(id);
/* 178 */     req.setVersion("2.0.0");
/* 179 */     req.setTwoWay((flag & 0x40) != 0);
/* 180 */     if ((flag & 0x20) != 0)
/* 181 */       req.setEvent(Request.HEARTBEAT_EVENT);
/*     */     try
/*     */     {
/*     */       Object data;
/*     */       Object data;
/* 185 */       if (req.isHeartbeat()) {
/* 186 */         data = decodeHeartbeatData(channel, in);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object data;
/* 187 */         if (req.isEvent())
/* 188 */           data = decodeEventData(channel, in);
/*     */         else
/* 190 */           data = decodeRequestData(channel, in);
/*     */       }
/* 192 */       req.setData(data);
/*     */     }
/*     */     catch (Throwable t) {
/* 195 */       req.setBroken(true);
/* 196 */       req.setData(t);
/*     */     }
/* 198 */     return req;
/*     */   }
/*     */ 
/*     */   protected Object getRequestData(long id)
/*     */   {
/* 203 */     DefaultFuture future = DefaultFuture.getFuture(id);
/* 204 */     if (future == null)
/* 205 */       return null;
/* 206 */     Request req = future.getRequest();
/* 207 */     if (req == null)
/* 208 */       return null;
/* 209 */     return req.getData();
/*     */   }
/*     */ 
/*     */   protected void encodeRequest(Channel channel, ChannelBuffer buffer, Request req) throws IOException {
/* 213 */     Serialization serialization = getSerialization(channel);
/*     */ 
/* 215 */     byte[] header = new byte[16];
/*     */ 
/* 217 */     Bytes.short2bytes((short)-9541, header);
/*     */ 
/* 220 */     header[2] = ((byte)(0xFFFFFF80 | serialization.getContentTypeId()));
/*     */ 
/* 222 */     if (req.isTwoWay())
/*     */     {
/*     */       int tmp46_45 = 2;
/*     */       byte[] tmp46_43 = header; tmp46_43[tmp46_45] = ((byte)(tmp46_43[tmp46_45] | 0x40));
/* 223 */     }if (req.isEvent())
/*     */     {
/*     */       int tmp63_62 = 2;
/*     */       byte[] tmp63_60 = header; tmp63_60[tmp63_62] = ((byte)(tmp63_60[tmp63_62] | 0x20));
/*     */     }
/*     */ 
/* 226 */     Bytes.long2bytes(req.getId(), header, 4);
/*     */ 
/* 229 */     int savedWriteIndex = buffer.writerIndex();
/* 230 */     buffer.writerIndex(savedWriteIndex + 16);
/* 231 */     ChannelBufferOutputStream bos = new ChannelBufferOutputStream(buffer);
/* 232 */     ObjectOutput out = serialization.serialize(channel.getUrl(), bos);
/* 233 */     if (req.isEvent())
/* 234 */       encodeEventData(channel, out, req.getData());
/*     */     else {
/* 236 */       encodeRequestData(channel, out, req.getData());
/*     */     }
/* 238 */     out.flushBuffer();
/* 239 */     bos.flush();
/* 240 */     bos.close();
/* 241 */     int len = bos.writtenBytes();
/* 242 */     checkPayload(channel, len);
/* 243 */     Bytes.int2bytes(len, header, 12);
/*     */ 
/* 246 */     buffer.writerIndex(savedWriteIndex);
/* 247 */     buffer.writeBytes(header);
/* 248 */     buffer.writerIndex(savedWriteIndex + 16 + len);
/*     */   }
/*     */ 
/*     */   protected void encodeResponse(Channel channel, ChannelBuffer buffer, Response res) throws IOException {
/*     */     try {
/* 253 */       Serialization serialization = getSerialization(channel);
/*     */ 
/* 255 */       byte[] header = new byte[16];
/*     */ 
/* 257 */       Bytes.short2bytes((short)-9541, header);
/*     */ 
/* 259 */       header[2] = serialization.getContentTypeId();
/* 260 */       if (res.isHeartbeat())
/*     */       {
/*     */         int tmp42_41 = 2;
/*     */         byte[] tmp42_39 = header; tmp42_39[tmp42_41] = ((byte)(tmp42_39[tmp42_41] | 0x20));
/*     */       }
/* 262 */       byte status = res.getStatus();
/* 263 */       header[3] = status;
/*     */ 
/* 265 */       Bytes.long2bytes(res.getId(), header, 4);
/*     */ 
/* 267 */       int savedWriteIndex = buffer.writerIndex();
/* 268 */       buffer.writerIndex(savedWriteIndex + 16);
/* 269 */       ChannelBufferOutputStream bos = new ChannelBufferOutputStream(buffer);
/* 270 */       ObjectOutput out = serialization.serialize(channel.getUrl(), bos);
/*     */ 
/* 272 */       if (status == 20) {
/* 273 */         if (res.isHeartbeat())
/* 274 */           encodeHeartbeatData(channel, out, res.getResult());
/*     */         else
/* 276 */           encodeResponseData(channel, out, res.getResult());
/*     */       }
/*     */       else
/* 279 */         out.writeUTF(res.getErrorMessage());
/* 280 */       out.flushBuffer();
/* 281 */       bos.flush();
/* 282 */       bos.close();
/*     */ 
/* 284 */       int len = bos.writtenBytes();
/* 285 */       checkPayload(channel, len);
/* 286 */       Bytes.int2bytes(len, header, 12);
/*     */ 
/* 288 */       buffer.writerIndex(savedWriteIndex);
/* 289 */       buffer.writeBytes(header);
/* 290 */       buffer.writerIndex(savedWriteIndex + 16 + len);
/*     */     }
/*     */     catch (Throwable t) {
/* 293 */       if ((!res.isEvent()) && (res.getStatus() != 50)) {
/*     */         try
/*     */         {
/* 296 */           logger.warn("Fail to encode response: " + res + ", send bad_response info instead, cause: " + t.getMessage(), t);
/*     */ 
/* 298 */           Response r = new Response(res.getId(), res.getVersion());
/* 299 */           r.setStatus((byte)50);
/* 300 */           r.setErrorMessage("Failed to send response: " + res + ", cause: " + StringUtils.toString(t));
/* 301 */           channel.send(r);
/*     */ 
/* 303 */           return;
/*     */         } catch (RemotingException e) {
/* 305 */           logger.warn("Failed to send bad_response info back: " + res + ", cause: " + e.getMessage(), e);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 310 */       if ((t instanceof IOException))
/* 311 */         throw ((IOException)t);
/* 312 */       if ((t instanceof RuntimeException))
/* 313 */         throw ((RuntimeException)t);
/* 314 */       if ((t instanceof Error)) {
/* 315 */         throw ((Error)t);
/*     */       }
/* 317 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object decodeData(ObjectInput in)
/*     */     throws IOException
/*     */   {
/* 324 */     return decodeRequestData(in);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected Object decodeHeartbeatData(ObjectInput in) throws IOException {
/*     */     try {
/* 330 */       return in.readObject();
/*     */     } catch (ClassNotFoundException e) {
/* 332 */       throw new IOException(StringUtils.toString("Read object failed.", e));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object decodeRequestData(ObjectInput in) throws IOException {
/*     */     try {
/* 338 */       return in.readObject();
/*     */     } catch (ClassNotFoundException e) {
/* 340 */       throw new IOException(StringUtils.toString("Read object failed.", e));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object decodeResponseData(ObjectInput in) throws IOException {
/*     */     try {
/* 346 */       return in.readObject();
/*     */     } catch (ClassNotFoundException e) {
/* 348 */       throw new IOException(StringUtils.toString("Read object failed.", e));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void encodeData(ObjectOutput out, Object data) throws IOException
/*     */   {
/* 354 */     encodeRequestData(out, data);
/*     */   }
/*     */ 
/*     */   private void encodeEventData(ObjectOutput out, Object data) throws IOException {
/* 358 */     out.writeObject(data);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected void encodeHeartbeatData(ObjectOutput out, Object data) throws IOException {
/* 363 */     encodeEventData(out, data);
/*     */   }
/*     */ 
/*     */   protected void encodeRequestData(ObjectOutput out, Object data) throws IOException {
/* 367 */     out.writeObject(data);
/*     */   }
/*     */ 
/*     */   protected void encodeResponseData(ObjectOutput out, Object data) throws IOException {
/* 371 */     out.writeObject(data);
/*     */   }
/*     */ 
/*     */   protected Object decodeData(Channel channel, ObjectInput in) throws IOException
/*     */   {
/* 376 */     return decodeRequestData(channel, in);
/*     */   }
/*     */ 
/*     */   protected Object decodeEventData(Channel channel, ObjectInput in) throws IOException {
/*     */     try {
/* 381 */       return in.readObject();
/*     */     } catch (ClassNotFoundException e) {
/* 383 */       throw new IOException(StringUtils.toString("Read object failed.", e));
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected Object decodeHeartbeatData(Channel channel, ObjectInput in) throws IOException {
/*     */     try {
/* 390 */       return in.readObject();
/*     */     } catch (ClassNotFoundException e) {
/* 392 */       throw new IOException(StringUtils.toString("Read object failed.", e));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object decodeRequestData(Channel channel, ObjectInput in) throws IOException {
/* 397 */     return decodeRequestData(in);
/*     */   }
/*     */ 
/*     */   protected Object decodeResponseData(Channel channel, ObjectInput in) throws IOException {
/* 401 */     return decodeResponseData(in);
/*     */   }
/*     */ 
/*     */   protected Object decodeResponseData(Channel channel, ObjectInput in, Object requestData) throws IOException {
/* 405 */     return decodeResponseData(channel, in);
/*     */   }
/*     */ 
/*     */   protected void encodeData(Channel channel, ObjectOutput out, Object data) throws IOException
/*     */   {
/* 410 */     encodeRequestData(channel, out, data);
/*     */   }
/*     */ 
/*     */   private void encodeEventData(Channel channel, ObjectOutput out, Object data) throws IOException {
/* 414 */     encodeEventData(out, data);
/*     */   }
/*     */   @Deprecated
/*     */   protected void encodeHeartbeatData(Channel channel, ObjectOutput out, Object data) throws IOException {
/* 418 */     encodeHeartbeatData(out, data);
/*     */   }
/*     */ 
/*     */   protected void encodeRequestData(Channel channel, ObjectOutput out, Object data) throws IOException {
/* 422 */     encodeRequestData(out, data);
/*     */   }
/*     */ 
/*     */   protected void encodeResponseData(Channel channel, ObjectOutput out, Object data) throws IOException {
/* 426 */     encodeResponseData(out, data);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.codec.ExchangeCodec
 * JD-Core Version:    0.6.2
 */