/*     */ package com.alibaba.dubbo.remoting.exchange.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.TimeoutException;
/*     */ import com.alibaba.dubbo.remoting.exchange.Request;
/*     */ import com.alibaba.dubbo.remoting.exchange.Response;
/*     */ import com.alibaba.dubbo.remoting.exchange.ResponseCallback;
/*     */ import com.alibaba.dubbo.remoting.exchange.ResponseFuture;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public class DefaultFuture
/*     */   implements ResponseFuture
/*     */ {
/*  46 */   private static final Logger logger = LoggerFactory.getLogger(DefaultFuture.class);
/*     */ 
/*  48 */   private static final Map<Long, Channel> CHANNELS = new ConcurrentHashMap();
/*     */ 
/*  50 */   private static final Map<Long, DefaultFuture> FUTURES = new ConcurrentHashMap();
/*     */   private final long id;
/*     */   private final Channel channel;
/*     */   private final Request request;
/*     */   private final int timeout;
/*  61 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*  63 */   private final Condition done = this.lock.newCondition();
/*     */ 
/*  65 */   private final long start = System.currentTimeMillis();
/*     */   private volatile long sent;
/*     */   private volatile Response response;
/*     */   private volatile ResponseCallback callback;
/*     */ 
/*     */   public DefaultFuture(Channel channel, Request request, int timeout)
/*     */   {
/*  74 */     this.channel = channel;
/*  75 */     this.request = request;
/*  76 */     this.id = request.getId();
/*  77 */     this.timeout = (timeout > 0 ? timeout : channel.getUrl().getPositiveParameter("timeout", 1000));
/*     */ 
/*  79 */     FUTURES.put(Long.valueOf(this.id), this);
/*  80 */     CHANNELS.put(Long.valueOf(this.id), channel);
/*     */   }
/*     */ 
/*     */   public Object get() throws RemotingException {
/*  84 */     return get(this.timeout);
/*     */   }
/*     */ 
/*     */   public Object get(int timeout) throws RemotingException {
/*  88 */     if (timeout <= 0) {
/*  89 */       timeout = 1000;
/*     */     }
/*  91 */     if (!isDone()) {
/*  92 */       long start = System.currentTimeMillis();
/*  93 */       this.lock.lock();
/*     */       try {
/*  95 */         while (!isDone()) {
/*  96 */           this.done.await(timeout, TimeUnit.MILLISECONDS);
/*  97 */           if (!isDone()) if (System.currentTimeMillis() - start > timeout)
/*  98 */               break; 
/*     */         }
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/* 102 */         throw new RuntimeException(e);
/*     */       } finally {
/* 104 */         this.lock.unlock();
/*     */       }
/* 106 */       if (!isDone()) {
/* 107 */         throw new TimeoutException(this.sent > 0L, this.channel, getTimeoutMessage(false));
/*     */       }
/*     */     }
/* 110 */     return returnFromResponse();
/*     */   }
/*     */ 
/*     */   public void cancel() {
/* 114 */     Response errorResult = new Response(this.id);
/* 115 */     errorResult.setErrorMessage("request future has been canceled.");
/* 116 */     this.response = errorResult;
/* 117 */     FUTURES.remove(Long.valueOf(this.id));
/* 118 */     CHANNELS.remove(Long.valueOf(this.id));
/*     */   }
/*     */ 
/*     */   public boolean isDone() {
/* 122 */     return this.response != null;
/*     */   }
/*     */ 
/*     */   public void setCallback(ResponseCallback callback) {
/* 126 */     if (isDone()) {
/* 127 */       invokeCallback(callback);
/*     */     } else {
/* 129 */       boolean isdone = false;
/* 130 */       this.lock.lock();
/*     */       try {
/* 132 */         if (!isDone())
/* 133 */           this.callback = callback;
/*     */         else
/* 135 */           isdone = true;
/*     */       }
/*     */       finally {
/* 138 */         this.lock.unlock();
/*     */       }
/* 140 */       if (isdone)
/* 141 */         invokeCallback(callback);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void invokeCallback(ResponseCallback c) {
/* 146 */     ResponseCallback callbackCopy = c;
/* 147 */     if (callbackCopy == null) {
/* 148 */       throw new NullPointerException("callback cannot be null.");
/*     */     }
/* 150 */     c = null;
/* 151 */     Response res = this.response;
/* 152 */     if (res == null) {
/* 153 */       throw new IllegalStateException("response cannot be null. url:" + this.channel.getUrl());
/*     */     }
/*     */ 
/* 156 */     if (res.getStatus() == 20)
/*     */       try {
/* 158 */         callbackCopy.done(res.getResult());
/*     */       } catch (Exception e) {
/* 160 */         logger.error("callback invoke error .reasult:" + res.getResult() + ",url:" + this.channel.getUrl(), e);
/*     */       }
/* 162 */     else if ((res.getStatus() == 30) || (res.getStatus() == 31))
/*     */       try {
/* 164 */         TimeoutException te = new TimeoutException(res.getStatus() == 31, this.channel, res.getErrorMessage());
/* 165 */         callbackCopy.caught(te);
/*     */       } catch (Exception e) {
/* 167 */         logger.error("callback invoke error ,url:" + this.channel.getUrl(), e);
/*     */       }
/*     */     else
/*     */       try {
/* 171 */         RuntimeException re = new RuntimeException(res.getErrorMessage());
/* 172 */         callbackCopy.caught(re);
/*     */       } catch (Exception e) {
/* 174 */         logger.error("callback invoke error ,url:" + this.channel.getUrl(), e);
/*     */       }
/*     */   }
/*     */ 
/*     */   private Object returnFromResponse() throws RemotingException
/*     */   {
/* 180 */     Response res = this.response;
/* 181 */     if (res == null) {
/* 182 */       throw new IllegalStateException("response cannot be null");
/*     */     }
/* 184 */     if (res.getStatus() == 20) {
/* 185 */       return res.getResult();
/*     */     }
/* 187 */     if ((res.getStatus() == 30) || (res.getStatus() == 31)) {
/* 188 */       throw new TimeoutException(res.getStatus() == 31, this.channel, res.getErrorMessage());
/*     */     }
/* 190 */     throw new RemotingException(this.channel, res.getErrorMessage());
/*     */   }
/*     */ 
/*     */   private long getId() {
/* 194 */     return this.id;
/*     */   }
/*     */ 
/*     */   private Channel getChannel() {
/* 198 */     return this.channel;
/*     */   }
/*     */ 
/*     */   private boolean isSent() {
/* 202 */     return this.sent > 0L;
/*     */   }
/*     */ 
/*     */   public Request getRequest() {
/* 206 */     return this.request;
/*     */   }
/*     */ 
/*     */   private int getTimeout() {
/* 210 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   private long getStartTimestamp() {
/* 214 */     return this.start;
/*     */   }
/*     */ 
/*     */   public static DefaultFuture getFuture(long id) {
/* 218 */     return (DefaultFuture)FUTURES.get(Long.valueOf(id));
/*     */   }
/*     */ 
/*     */   public static boolean hasFuture(Channel channel) {
/* 222 */     return CHANNELS.containsValue(channel);
/*     */   }
/*     */ 
/*     */   public static void sent(Channel channel, Request request) {
/* 226 */     DefaultFuture future = (DefaultFuture)FUTURES.get(Long.valueOf(request.getId()));
/* 227 */     if (future != null)
/* 228 */       future.doSent();
/*     */   }
/*     */ 
/*     */   private void doSent()
/*     */   {
/* 233 */     this.sent = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   public static void received(Channel channel, Response response) {
/*     */     try {
/* 238 */       DefaultFuture future = (DefaultFuture)FUTURES.remove(Long.valueOf(response.getId()));
/* 239 */       if (future != null)
/* 240 */         future.doReceived(response);
/*     */       else {
/* 242 */         logger.warn("The timeout response finally returned at " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()) + ", response " + response + (channel == null ? "" : new StringBuilder().append(", channel: ").append(channel.getLocalAddress()).append(" -> ").append(channel.getRemoteAddress()).toString()));
/*     */       }
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 249 */       CHANNELS.remove(Long.valueOf(response.getId()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void doReceived(Response res) {
/* 254 */     this.lock.lock();
/*     */     try {
/* 256 */       this.response = res;
/* 257 */       if (this.done != null)
/* 258 */         this.done.signal();
/*     */     }
/*     */     finally {
/* 261 */       this.lock.unlock();
/*     */     }
/* 263 */     if (this.callback != null)
/* 264 */       invokeCallback(this.callback);
/*     */   }
/*     */ 
/*     */   private String getTimeoutMessage(boolean scan)
/*     */   {
/* 269 */     long nowTimestamp = System.currentTimeMillis();
/* 270 */     return (this.sent > 0L ? "Waiting server-side response timeout" : "Sending request timeout in client-side") + (scan ? " by scan timer" : "") + ". start time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date(this.start)) + ", end time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()) + "," + (this.sent > 0L ? " client elapsed: " + (this.sent - this.start) + " ms, server elapsed: " + (nowTimestamp - this.sent) : new StringBuilder().append(" elapsed: ").append(nowTimestamp - this.start).toString()) + " ms, timeout: " + this.timeout + " ms, request: " + this.request + ", channel: " + this.channel.getLocalAddress() + " -> " + this.channel.getRemoteAddress();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 309 */     Thread th = new Thread(new RemotingInvocationTimeoutScan(null), "DubboResponseTimeoutScanTimer");
/* 310 */     th.setDaemon(true);
/* 311 */     th.start();
/*     */   }
/*     */ 
/*     */   private static class RemotingInvocationTimeoutScan
/*     */     implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/*     */       while (true)
/*     */         try
/*     */         {
/* 286 */           Iterator i$ = DefaultFuture.FUTURES.values().iterator(); if (i$.hasNext()) { DefaultFuture future = (DefaultFuture)i$.next();
/* 287 */             if ((future != null) && (!future.isDone()))
/*     */             {
/* 290 */               if (System.currentTimeMillis() - future.getStartTimestamp() > future.getTimeout())
/*     */               {
/* 292 */                 Response timeoutResponse = new Response(future.getId());
/*     */ 
/* 294 */                 timeoutResponse.setStatus((byte)(future.isSent() ? 31 : 30));
/* 295 */                 timeoutResponse.setErrorMessage(future.getTimeoutMessage(true));
/*     */ 
/* 297 */                 DefaultFuture.received(future.getChannel(), timeoutResponse);
/*     */               }
/*     */             } } else {
/* 300 */             Thread.sleep(30L);
/*     */           }
/*     */         } catch (Throwable e) { DefaultFuture.logger.error("Exception when scan the timeout invocation of remoting.", e); }
/*     */ 
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.DefaultFuture
 * JD-Core Version:    0.6.2
 */