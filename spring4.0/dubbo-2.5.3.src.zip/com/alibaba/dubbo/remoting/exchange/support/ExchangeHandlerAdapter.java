/*    */ package com.alibaba.dubbo.remoting.exchange.support;
/*    */ 
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;
/*    */ import com.alibaba.dubbo.remoting.exchange.ExchangeHandler;
/*    */ import com.alibaba.dubbo.remoting.telnet.support.TelnetHandlerAdapter;
/*    */ 
/*    */ public abstract class ExchangeHandlerAdapter extends TelnetHandlerAdapter
/*    */   implements ExchangeHandler
/*    */ {
/*    */   public Object reply(ExchangeChannel channel, Object msg)
/*    */     throws RemotingException
/*    */   {
/* 31 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.ExchangeHandlerAdapter
 * JD-Core Version:    0.6.2
 */