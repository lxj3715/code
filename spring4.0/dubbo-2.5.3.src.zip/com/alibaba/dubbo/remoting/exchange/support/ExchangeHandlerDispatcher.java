/*     */ package com.alibaba.dubbo.remoting.exchange.support;
/*     */ 
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeHandler;
/*     */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*     */ import com.alibaba.dubbo.remoting.telnet.support.TelnetHandlerAdapter;
/*     */ import com.alibaba.dubbo.remoting.transport.ChannelHandlerDispatcher;
/*     */ 
/*     */ public class ExchangeHandlerDispatcher
/*     */   implements ExchangeHandler
/*     */ {
/*     */   private final ReplierDispatcher replierDispatcher;
/*     */   private final ChannelHandlerDispatcher handlerDispatcher;
/*     */   private final TelnetHandler telnetHandler;
/*     */ 
/*     */   public ExchangeHandlerDispatcher()
/*     */   {
/*  41 */     this.replierDispatcher = new ReplierDispatcher();
/*  42 */     this.handlerDispatcher = new ChannelHandlerDispatcher();
/*  43 */     this.telnetHandler = new TelnetHandlerAdapter();
/*     */   }
/*     */ 
/*     */   public ExchangeHandlerDispatcher(Replier<?> replier) {
/*  47 */     this.replierDispatcher = new ReplierDispatcher(replier);
/*  48 */     this.handlerDispatcher = new ChannelHandlerDispatcher();
/*  49 */     this.telnetHandler = new TelnetHandlerAdapter();
/*     */   }
/*     */ 
/*     */   public ExchangeHandlerDispatcher(ChannelHandler[] handlers) {
/*  53 */     this.replierDispatcher = new ReplierDispatcher();
/*  54 */     this.handlerDispatcher = new ChannelHandlerDispatcher(handlers);
/*  55 */     this.telnetHandler = new TelnetHandlerAdapter();
/*     */   }
/*     */ 
/*     */   public ExchangeHandlerDispatcher(Replier<?> replier, ChannelHandler[] handlers) {
/*  59 */     this.replierDispatcher = new ReplierDispatcher(replier);
/*  60 */     this.handlerDispatcher = new ChannelHandlerDispatcher(handlers);
/*  61 */     this.telnetHandler = new TelnetHandlerAdapter();
/*     */   }
/*     */ 
/*     */   public ExchangeHandlerDispatcher addChannelHandler(ChannelHandler handler) {
/*  65 */     this.handlerDispatcher.addChannelHandler(handler);
/*  66 */     return this;
/*     */   }
/*     */ 
/*     */   public ExchangeHandlerDispatcher removeChannelHandler(ChannelHandler handler) {
/*  70 */     this.handlerDispatcher.removeChannelHandler(handler);
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */   public <T> ExchangeHandlerDispatcher addReplier(Class<T> type, Replier<T> replier) {
/*  75 */     this.replierDispatcher.addReplier(type, replier);
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */   public <T> ExchangeHandlerDispatcher removeReplier(Class<T> type) {
/*  80 */     this.replierDispatcher.removeReplier(type);
/*  81 */     return this;
/*     */   }
/*     */ 
/*     */   public Object reply(ExchangeChannel channel, Object request) throws RemotingException
/*     */   {
/*  86 */     return this.replierDispatcher.reply(channel, request);
/*     */   }
/*     */ 
/*     */   public void connected(Channel channel) {
/*  90 */     this.handlerDispatcher.connected(channel);
/*     */   }
/*     */ 
/*     */   public void disconnected(Channel channel) {
/*  94 */     this.handlerDispatcher.disconnected(channel);
/*     */   }
/*     */ 
/*     */   public void sent(Channel channel, Object message) {
/*  98 */     this.handlerDispatcher.sent(channel, message);
/*     */   }
/*     */ 
/*     */   public void received(Channel channel, Object message) {
/* 102 */     this.handlerDispatcher.received(channel, message);
/*     */   }
/*     */ 
/*     */   public void caught(Channel channel, Throwable exception) {
/* 106 */     this.handlerDispatcher.caught(channel, exception);
/*     */   }
/*     */ 
/*     */   public String telnet(Channel channel, String message) throws RemotingException {
/* 110 */     return this.telnetHandler.telnet(channel, message);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.ExchangeHandlerDispatcher
 * JD-Core Version:    0.6.2
 */