/*     */ package com.alibaba.dubbo.remoting.exchange.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Parameters;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeServer;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public class ExchangeServerDelegate
/*     */   implements ExchangeServer
/*     */ {
/*     */   private transient ExchangeServer server;
/*     */ 
/*     */   public ExchangeServerDelegate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ExchangeServerDelegate(ExchangeServer server)
/*     */   {
/*  41 */     setServer(server);
/*     */   }
/*     */ 
/*     */   public ExchangeServer getServer() {
/*  45 */     return this.server;
/*     */   }
/*     */ 
/*     */   public void setServer(ExchangeServer server) {
/*  49 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public boolean isBound() {
/*  53 */     return this.server.isBound();
/*     */   }
/*     */ 
/*     */   public void reset(URL url) {
/*  57 */     this.server.reset(url);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void reset(Parameters parameters) {
/*  62 */     reset(getUrl().addParameters(parameters.getParameters()));
/*     */   }
/*     */ 
/*     */   public Collection<Channel> getChannels() {
/*  66 */     return this.server.getChannels();
/*     */   }
/*     */ 
/*     */   public Channel getChannel(InetSocketAddress remoteAddress) {
/*  70 */     return this.server.getChannel(remoteAddress);
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  74 */     return this.server.getUrl();
/*     */   }
/*     */ 
/*     */   public ChannelHandler getChannelHandler() {
/*  78 */     return this.server.getChannelHandler();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/*  82 */     return this.server.getLocalAddress();
/*     */   }
/*     */ 
/*     */   public void send(Object message) throws RemotingException {
/*  86 */     this.server.send(message);
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/*  90 */     this.server.send(message, sent);
/*     */   }
/*     */ 
/*     */   public void close() {
/*  94 */     this.server.close();
/*     */   }
/*     */ 
/*     */   public boolean isClosed() {
/*  98 */     return this.server.isClosed();
/*     */   }
/*     */ 
/*     */   public Collection<ExchangeChannel> getExchangeChannels() {
/* 102 */     return this.server.getExchangeChannels();
/*     */   }
/*     */ 
/*     */   public ExchangeChannel getExchangeChannel(InetSocketAddress remoteAddress) {
/* 106 */     return this.server.getExchangeChannel(remoteAddress);
/*     */   }
/*     */ 
/*     */   public void close(int timeout) {
/* 110 */     this.server.close(timeout);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.ExchangeServerDelegate
 * JD-Core Version:    0.6.2
 */