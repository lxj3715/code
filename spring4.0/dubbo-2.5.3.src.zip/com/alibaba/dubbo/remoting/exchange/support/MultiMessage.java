/*    */ package com.alibaba.dubbo.remoting.exchange.support;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public final class MultiMessage
/*    */   implements Iterable
/*    */ {
/* 46 */   private final List messages = new ArrayList();
/*    */ 
/*    */   public static MultiMessage createFromCollection(Collection collection)
/*    */   {
/* 33 */     MultiMessage result = new MultiMessage();
/* 34 */     result.addMessages(collection);
/* 35 */     return result;
/*    */   }
/*    */ 
/*    */   public static MultiMessage createFromArray(Object[] args) {
/* 39 */     return createFromCollection(Arrays.asList(args));
/*    */   }
/*    */ 
/*    */   public static MultiMessage create() {
/* 43 */     return new MultiMessage();
/*    */   }
/*    */ 
/*    */   public void addMessage(Object msg)
/*    */   {
/* 51 */     this.messages.add(msg);
/*    */   }
/*    */ 
/*    */   public void addMessages(Collection collection) {
/* 55 */     this.messages.addAll(collection);
/*    */   }
/*    */ 
/*    */   public Collection getMessages() {
/* 59 */     return Collections.unmodifiableCollection(this.messages);
/*    */   }
/*    */ 
/*    */   public int size() {
/* 63 */     return this.messages.size();
/*    */   }
/*    */ 
/*    */   public Object get(int index) {
/* 67 */     return this.messages.get(index);
/*    */   }
/*    */ 
/*    */   public boolean isEmpty() {
/* 71 */     return this.messages.isEmpty();
/*    */   }
/*    */ 
/*    */   public Collection removeMessages() {
/* 75 */     Collection result = Collections.unmodifiableCollection(this.messages);
/* 76 */     this.messages.clear();
/* 77 */     return result;
/*    */   }
/*    */ 
/*    */   public Iterator iterator() {
/* 81 */     return this.messages.iterator();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.MultiMessage
 * JD-Core Version:    0.6.2
 */