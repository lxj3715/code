package com.alibaba.dubbo.remoting.exchange.support;

import com.alibaba.dubbo.remoting.RemotingException;
import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;

public abstract interface Replier<T>
{
  public abstract Object reply(ExchangeChannel paramExchangeChannel, T paramT)
    throws RemotingException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.Replier
 * JD-Core Version:    0.6.2
 */