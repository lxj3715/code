/*    */ package com.alibaba.dubbo.remoting.exchange.support;
/*    */ 
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ public class ReplierDispatcher
/*    */   implements Replier<Object>
/*    */ {
/*    */   private final Replier<?> defaultReplier;
/* 33 */   private final Map<Class<?>, Replier<?>> repliers = new ConcurrentHashMap();
/*    */ 
/*    */   public ReplierDispatcher() {
/* 36 */     this(null, null);
/*    */   }
/*    */ 
/*    */   public ReplierDispatcher(Replier<?> defaultReplier) {
/* 40 */     this(defaultReplier, null);
/*    */   }
/*    */ 
/*    */   public ReplierDispatcher(Replier<?> defaultReplier, Map<Class<?>, Replier<?>> repliers) {
/* 44 */     this.defaultReplier = defaultReplier;
/* 45 */     if ((repliers != null) && (repliers.size() > 0))
/* 46 */       this.repliers.putAll(repliers);
/*    */   }
/*    */ 
/*    */   public <T> ReplierDispatcher addReplier(Class<T> type, Replier<T> replier)
/*    */   {
/* 51 */     this.repliers.put(type, replier);
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */   public <T> ReplierDispatcher removeReplier(Class<T> type) {
/* 56 */     this.repliers.remove(type);
/* 57 */     return this;
/*    */   }
/*    */ 
/*    */   private Replier<?> getReplier(Class<?> type) {
/* 61 */     for (Map.Entry entry : this.repliers.entrySet()) {
/* 62 */       if (((Class)entry.getKey()).isAssignableFrom(type)) {
/* 63 */         return (Replier)entry.getValue();
/*    */       }
/*    */     }
/* 66 */     if (this.defaultReplier != null) {
/* 67 */       return this.defaultReplier;
/*    */     }
/* 69 */     throw new IllegalStateException("Replier not found, Unsupported message object: " + type);
/*    */   }
/*    */ 
/*    */   public Object reply(ExchangeChannel channel, Object request) throws RemotingException
/*    */   {
/* 74 */     return getReplier(request.getClass()).reply(channel, request);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.ReplierDispatcher
 * JD-Core Version:    0.6.2
 */