/*    */ package com.alibaba.dubbo.remoting.exchange.support;
/*    */ 
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.exchange.ResponseCallback;
/*    */ import com.alibaba.dubbo.remoting.exchange.ResponseFuture;
/*    */ 
/*    */ public class SimpleFuture
/*    */   implements ResponseFuture
/*    */ {
/*    */   private final Object value;
/*    */ 
/*    */   public SimpleFuture(Object value)
/*    */   {
/* 32 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Object get() throws RemotingException {
/* 36 */     return this.value;
/*    */   }
/*    */ 
/*    */   public Object get(int timeoutInMillis) throws RemotingException {
/* 40 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setCallback(ResponseCallback callback) {
/* 44 */     callback.done(this.value);
/*    */   }
/*    */ 
/*    */   public boolean isDone() {
/* 48 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.SimpleFuture
 * JD-Core Version:    0.6.2
 */