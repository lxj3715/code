/*     */ package com.alibaba.dubbo.remoting.exchange.support.header;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeHandler;
/*     */ import com.alibaba.dubbo.remoting.exchange.Request;
/*     */ import com.alibaba.dubbo.remoting.exchange.Response;
/*     */ import com.alibaba.dubbo.remoting.exchange.ResponseFuture;
/*     */ import com.alibaba.dubbo.remoting.exchange.support.DefaultFuture;
/*     */ import java.net.InetSocketAddress;
/*     */ 
/*     */ final class HeaderExchangeChannel
/*     */   implements ExchangeChannel
/*     */ {
/*  41 */   private static final Logger logger = LoggerFactory.getLogger(HeaderExchangeChannel.class);
/*     */ 
/*  43 */   private static final String CHANNEL_KEY = HeaderExchangeChannel.class.getName() + ".CHANNEL";
/*     */   private final Channel channel;
/*  47 */   private volatile boolean closed = false;
/*     */ 
/*     */   HeaderExchangeChannel(Channel channel) {
/*  50 */     if (channel == null) {
/*  51 */       throw new IllegalArgumentException("channel == null");
/*     */     }
/*  53 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */   static HeaderExchangeChannel getOrAddChannel(Channel ch) {
/*  57 */     if (ch == null) {
/*  58 */       return null;
/*     */     }
/*  60 */     HeaderExchangeChannel ret = (HeaderExchangeChannel)ch.getAttribute(CHANNEL_KEY);
/*  61 */     if (ret == null) {
/*  62 */       ret = new HeaderExchangeChannel(ch);
/*  63 */       if (ch.isConnected()) {
/*  64 */         ch.setAttribute(CHANNEL_KEY, ret);
/*     */       }
/*     */     }
/*  67 */     return ret;
/*     */   }
/*     */ 
/*     */   static void removeChannelIfDisconnected(Channel ch) {
/*  71 */     if ((ch != null) && (!ch.isConnected()))
/*  72 */       ch.removeAttribute(CHANNEL_KEY);
/*     */   }
/*     */ 
/*     */   public void send(Object message) throws RemotingException
/*     */   {
/*  77 */     send(message, getUrl().getParameter("sent", false));
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/*  81 */     if (this.closed) {
/*  82 */       throw new RemotingException(getLocalAddress(), null, "Failed to send message " + message + ", cause: The channel " + this + " is closed!");
/*     */     }
/*  84 */     if (((message instanceof Request)) || ((message instanceof Response)) || ((message instanceof String)))
/*     */     {
/*  87 */       this.channel.send(message, sent);
/*     */     } else {
/*  89 */       Request request = new Request();
/*  90 */       request.setVersion("2.0.0");
/*  91 */       request.setTwoWay(false);
/*  92 */       request.setData(message);
/*  93 */       this.channel.send(request, sent);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ResponseFuture request(Object request) throws RemotingException {
/*  98 */     return request(request, this.channel.getUrl().getPositiveParameter("timeout", 1000));
/*     */   }
/*     */ 
/*     */   public ResponseFuture request(Object request, int timeout) throws RemotingException {
/* 102 */     if (this.closed) {
/* 103 */       throw new RemotingException(getLocalAddress(), null, "Failed to send request " + request + ", cause: The channel " + this + " is closed!");
/*     */     }
/*     */ 
/* 106 */     Request req = new Request();
/* 107 */     req.setVersion("2.0.0");
/* 108 */     req.setTwoWay(true);
/* 109 */     req.setData(request);
/* 110 */     DefaultFuture future = new DefaultFuture(this.channel, req, timeout);
/*     */     try {
/* 112 */       this.channel.send(req);
/*     */     } catch (RemotingException e) {
/* 114 */       future.cancel();
/* 115 */       throw e;
/*     */     }
/* 117 */     return future;
/*     */   }
/*     */ 
/*     */   public boolean isClosed() {
/* 121 */     return this.closed;
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */     try {
/* 126 */       this.channel.close();
/*     */     } catch (Throwable e) {
/* 128 */       logger.warn(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close(int timeout)
/*     */   {
/* 134 */     if (this.closed) {
/* 135 */       return;
/*     */     }
/* 137 */     this.closed = true;
/* 138 */     if (timeout > 0) {
/* 139 */       long start = System.currentTimeMillis();
/*     */ 
/* 141 */       while ((DefaultFuture.hasFuture(this)) && (System.currentTimeMillis() - start < timeout)) {
/*     */         try {
/* 143 */           Thread.sleep(10L);
/*     */         } catch (InterruptedException e) {
/* 145 */           logger.warn(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/* 149 */     close();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/* 153 */     return this.channel.getLocalAddress();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getRemoteAddress() {
/* 157 */     return this.channel.getRemoteAddress();
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/* 161 */     return this.channel.getUrl();
/*     */   }
/*     */ 
/*     */   public boolean isConnected() {
/* 165 */     return this.channel.isConnected();
/*     */   }
/*     */ 
/*     */   public ChannelHandler getChannelHandler() {
/* 169 */     return this.channel.getChannelHandler();
/*     */   }
/*     */ 
/*     */   public ExchangeHandler getExchangeHandler() {
/* 173 */     return (ExchangeHandler)this.channel.getChannelHandler();
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String key) {
/* 177 */     return this.channel.getAttribute(key);
/*     */   }
/*     */ 
/*     */   public void setAttribute(String key, Object value) {
/* 181 */     this.channel.setAttribute(key, value);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String key) {
/* 185 */     this.channel.removeAttribute(key);
/*     */   }
/*     */ 
/*     */   public boolean hasAttribute(String key) {
/* 189 */     return this.channel.hasAttribute(key);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 194 */     int prime = 31;
/* 195 */     int result = 1;
/* 196 */     result = 31 * result + (this.channel == null ? 0 : this.channel.hashCode());
/* 197 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 202 */     if (this == obj) return true;
/* 203 */     if (obj == null) return false;
/* 204 */     if (getClass() != obj.getClass()) return false;
/* 205 */     HeaderExchangeChannel other = (HeaderExchangeChannel)obj;
/* 206 */     if (this.channel == null) {
/* 207 */       if (other.channel != null) return false; 
/*     */     }
/* 208 */     else if (!this.channel.equals(other.channel)) return false;
/* 209 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 214 */     return this.channel.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.header.HeaderExchangeChannel
 * JD-Core Version:    0.6.2
 */