/*     */ package com.alibaba.dubbo.remoting.exchange.support.header;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Parameters;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.Client;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeClient;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeHandler;
/*     */ import com.alibaba.dubbo.remoting.exchange.ResponseFuture;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class HeaderExchangeClient
/*     */   implements ExchangeClient
/*     */ {
/*  47 */   private static final Logger logger = LoggerFactory.getLogger(HeaderExchangeClient.class);
/*     */ 
/*  49 */   private static final ScheduledThreadPoolExecutor scheduled = new ScheduledThreadPoolExecutor(2, new NamedThreadFactory("dubbo-remoting-client-heartbeat", true));
/*     */   private ScheduledFuture<?> heatbeatTimer;
/*     */   private int heartbeat;
/*     */   private int heartbeatTimeout;
/*     */   private final Client client;
/*     */   private final ExchangeChannel channel;
/*     */ 
/*     */   public HeaderExchangeClient(Client client)
/*     */   {
/*  64 */     if (client == null) {
/*  65 */       throw new IllegalArgumentException("client == null");
/*     */     }
/*  67 */     this.client = client;
/*  68 */     this.channel = new HeaderExchangeChannel(client);
/*  69 */     String dubbo = client.getUrl().getParameter("dubbo");
/*  70 */     this.heartbeat = client.getUrl().getParameter("heartbeat", (dubbo != null) && (dubbo.startsWith("1.0.")) ? 60000 : 0);
/*  71 */     this.heartbeatTimeout = client.getUrl().getParameter("heartbeat.timeout", this.heartbeat * 3);
/*  72 */     if (this.heartbeatTimeout < this.heartbeat * 2) {
/*  73 */       throw new IllegalStateException("heartbeatTimeout < heartbeatInterval * 2");
/*     */     }
/*  75 */     startHeatbeatTimer();
/*     */   }
/*     */ 
/*     */   public ResponseFuture request(Object request) throws RemotingException {
/*  79 */     return this.channel.request(request);
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  83 */     return this.channel.getUrl();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getRemoteAddress() {
/*  87 */     return this.channel.getRemoteAddress();
/*     */   }
/*     */ 
/*     */   public ResponseFuture request(Object request, int timeout) throws RemotingException {
/*  91 */     return this.channel.request(request, timeout);
/*     */   }
/*     */ 
/*     */   public ChannelHandler getChannelHandler() {
/*  95 */     return this.channel.getChannelHandler();
/*     */   }
/*     */ 
/*     */   public boolean isConnected() {
/*  99 */     return this.channel.isConnected();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/* 103 */     return this.channel.getLocalAddress();
/*     */   }
/*     */ 
/*     */   public ExchangeHandler getExchangeHandler() {
/* 107 */     return this.channel.getExchangeHandler();
/*     */   }
/*     */ 
/*     */   public void send(Object message) throws RemotingException {
/* 111 */     this.channel.send(message);
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/* 115 */     this.channel.send(message, sent);
/*     */   }
/*     */ 
/*     */   public boolean isClosed() {
/* 119 */     return this.channel.isClosed();
/*     */   }
/*     */ 
/*     */   public void close() {
/* 123 */     doClose();
/* 124 */     this.channel.close();
/*     */   }
/*     */ 
/*     */   public void close(int timeout) {
/* 128 */     doClose();
/* 129 */     this.channel.close(timeout);
/*     */   }
/*     */ 
/*     */   public void reset(URL url) {
/* 133 */     this.client.reset(url);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void reset(Parameters parameters) {
/* 138 */     reset(getUrl().addParameters(parameters.getParameters()));
/*     */   }
/*     */ 
/*     */   public void reconnect() throws RemotingException {
/* 142 */     this.client.reconnect();
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String key) {
/* 146 */     return this.channel.getAttribute(key);
/*     */   }
/*     */ 
/*     */   public void setAttribute(String key, Object value) {
/* 150 */     this.channel.setAttribute(key, value);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String key) {
/* 154 */     this.channel.removeAttribute(key);
/*     */   }
/*     */ 
/*     */   public boolean hasAttribute(String key) {
/* 158 */     return this.channel.hasAttribute(key);
/*     */   }
/*     */ 
/*     */   private void startHeatbeatTimer() {
/* 162 */     stopHeartbeatTimer();
/* 163 */     if (this.heartbeat > 0)
/* 164 */       this.heatbeatTimer = scheduled.scheduleWithFixedDelay(new HeartBeatTask(new HeartBeatTask.ChannelProvider()
/*     */       {
/*     */         public Collection<Channel> getChannels() {
/* 167 */           return Collections.singletonList(HeaderExchangeClient.this);
/*     */         }
/*     */       }
/*     */       , this.heartbeat, this.heartbeatTimeout), this.heartbeat, this.heartbeat, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   private void stopHeartbeatTimer()
/*     */   {
/* 175 */     if ((this.heatbeatTimer != null) && (!this.heatbeatTimer.isCancelled())) {
/*     */       try {
/* 177 */         this.heatbeatTimer.cancel(true);
/* 178 */         scheduled.purge();
/*     */       } catch (Throwable e) {
/* 180 */         if (logger.isWarnEnabled()) {
/* 181 */           logger.warn(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/* 185 */     this.heatbeatTimer = null;
/*     */   }
/*     */ 
/*     */   private void doClose() {
/* 189 */     stopHeartbeatTimer();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 194 */     return "HeaderExchangeClient [channel=" + this.channel + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.header.HeaderExchangeClient
 * JD-Core Version:    0.6.2
 */