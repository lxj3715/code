/*     */ package com.alibaba.dubbo.remoting.exchange.support.header;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.ExecutionException;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeHandler;
/*     */ import com.alibaba.dubbo.remoting.exchange.Request;
/*     */ import com.alibaba.dubbo.remoting.exchange.Response;
/*     */ import com.alibaba.dubbo.remoting.exchange.support.DefaultFuture;
/*     */ import com.alibaba.dubbo.remoting.transport.ChannelHandlerDelegate;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ 
/*     */ public class HeaderExchangeHandler
/*     */   implements ChannelHandlerDelegate
/*     */ {
/*  45 */   protected static final Logger logger = LoggerFactory.getLogger(HeaderExchangeHandler.class);
/*     */ 
/*  47 */   public static String KEY_READ_TIMESTAMP = HeartbeatHandler.KEY_READ_TIMESTAMP;
/*     */ 
/*  49 */   public static String KEY_WRITE_TIMESTAMP = HeartbeatHandler.KEY_WRITE_TIMESTAMP;
/*     */   private final ExchangeHandler handler;
/*     */ 
/*     */   public HeaderExchangeHandler(ExchangeHandler handler)
/*     */   {
/*  54 */     if (handler == null) {
/*  55 */       throw new IllegalArgumentException("handler == null");
/*     */     }
/*  57 */     this.handler = handler;
/*     */   }
/*     */ 
/*     */   void handlerEvent(Channel channel, Request req) throws RemotingException {
/*  61 */     if ((req.getData() != null) && (req.getData().equals("R")))
/*  62 */       channel.setAttribute("channel.readonly", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   Response handleRequest(ExchangeChannel channel, Request req) throws RemotingException
/*     */   {
/*  67 */     Response res = new Response(req.getId(), req.getVersion());
/*  68 */     if (req.isBroken()) {
/*  69 */       Object data = req.getData();
/*     */       String msg;
/*     */       String msg;
/*  72 */       if (data == null) { msg = null; }
/*     */       else
/*     */       {
/*  73 */         String msg;
/*  73 */         if ((data instanceof Throwable)) msg = StringUtils.toString((Throwable)data); else
/*  74 */           msg = data.toString(); 
/*     */       }
/*  75 */       res.setErrorMessage("Fail to decode request due to: " + msg);
/*  76 */       res.setStatus((byte)40);
/*     */ 
/*  78 */       return res;
/*     */     }
/*     */ 
/*  81 */     Object msg = req.getData();
/*     */     try
/*     */     {
/*  84 */       Object result = this.handler.reply(channel, msg);
/*  85 */       res.setStatus((byte)20);
/*  86 */       res.setResult(result);
/*     */     } catch (Throwable e) {
/*  88 */       res.setStatus((byte)70);
/*  89 */       res.setErrorMessage(StringUtils.toString(e));
/*     */     }
/*  91 */     return res;
/*     */   }
/*     */ 
/*     */   static void handleResponse(Channel channel, Response response) throws RemotingException {
/*  95 */     if ((response != null) && (!response.isHeartbeat()))
/*  96 */       DefaultFuture.received(channel, response);
/*     */   }
/*     */ 
/*     */   public void connected(Channel channel) throws RemotingException
/*     */   {
/* 101 */     channel.setAttribute(KEY_READ_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
/* 102 */     channel.setAttribute(KEY_WRITE_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
/* 103 */     ExchangeChannel exchangeChannel = HeaderExchangeChannel.getOrAddChannel(channel);
/*     */     try {
/* 105 */       this.handler.connected(exchangeChannel);
/*     */     } finally {
/* 107 */       HeaderExchangeChannel.removeChannelIfDisconnected(channel);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void disconnected(Channel channel) throws RemotingException {
/* 112 */     channel.setAttribute(KEY_READ_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
/* 113 */     channel.setAttribute(KEY_WRITE_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
/* 114 */     ExchangeChannel exchangeChannel = HeaderExchangeChannel.getOrAddChannel(channel);
/*     */     try {
/* 116 */       this.handler.disconnected(exchangeChannel);
/*     */     } finally {
/* 118 */       HeaderExchangeChannel.removeChannelIfDisconnected(channel);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sent(Channel channel, Object message) throws RemotingException {
/* 123 */     Throwable exception = null;
/*     */     try {
/* 125 */       channel.setAttribute(KEY_WRITE_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
/* 126 */       ExchangeChannel exchangeChannel = HeaderExchangeChannel.getOrAddChannel(channel);
/*     */       try {
/* 128 */         this.handler.sent(exchangeChannel, message);
/*     */       } finally {
/* 130 */         HeaderExchangeChannel.removeChannelIfDisconnected(channel);
/*     */       }
/*     */     } catch (Throwable t) {
/* 133 */       exception = t;
/*     */     }
/* 135 */     if ((message instanceof Request)) {
/* 136 */       Request request = (Request)message;
/* 137 */       DefaultFuture.sent(channel, request);
/*     */     }
/* 139 */     if (exception != null) {
/* 140 */       if ((exception instanceof RuntimeException))
/* 141 */         throw ((RuntimeException)exception);
/* 142 */       if ((exception instanceof RemotingException)) {
/* 143 */         throw ((RemotingException)exception);
/*     */       }
/* 145 */       throw new RemotingException(channel.getLocalAddress(), channel.getRemoteAddress(), exception.getMessage(), exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static boolean isClientSide(Channel channel)
/*     */   {
/* 152 */     InetSocketAddress address = channel.getRemoteAddress();
/* 153 */     URL url = channel.getUrl();
/* 154 */     return (url.getPort() == address.getPort()) && (NetUtils.filterLocalHost(url.getIp()).equals(NetUtils.filterLocalHost(address.getAddress().getHostAddress())));
/*     */   }
/*     */ 
/*     */   public void received(Channel channel, Object message)
/*     */     throws RemotingException
/*     */   {
/* 160 */     channel.setAttribute(KEY_READ_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
/* 161 */     ExchangeChannel exchangeChannel = HeaderExchangeChannel.getOrAddChannel(channel);
/*     */     try {
/* 163 */       if ((message instanceof Request))
/*     */       {
/* 165 */         Request request = (Request)message;
/* 166 */         if (request.isEvent()) {
/* 167 */           handlerEvent(channel, request);
/*     */         }
/* 169 */         else if (request.isTwoWay()) {
/* 170 */           Response response = handleRequest(exchangeChannel, request);
/* 171 */           channel.send(response);
/*     */         } else {
/* 173 */           this.handler.received(exchangeChannel, request.getData());
/*     */         }
/*     */       }
/* 176 */       else if ((message instanceof Response)) {
/* 177 */         handleResponse(channel, (Response)message);
/* 178 */       } else if ((message instanceof String)) {
/* 179 */         if (isClientSide(channel)) {
/* 180 */           Exception e = new Exception("Dubbo client can not supported string message: " + message + " in channel: " + channel + ", url: " + channel.getUrl());
/* 181 */           logger.error(e.getMessage(), e);
/*     */         } else {
/* 183 */           String echo = this.handler.telnet(channel, (String)message);
/* 184 */           if ((echo != null) && (echo.length() > 0))
/* 185 */             channel.send(echo);
/*     */         }
/*     */       }
/*     */       else {
/* 189 */         this.handler.received(exchangeChannel, message);
/*     */       }
/*     */     } finally {
/* 192 */       HeaderExchangeChannel.removeChannelIfDisconnected(channel);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void caught(Channel channel, Throwable exception) throws RemotingException {
/* 197 */     if ((exception instanceof ExecutionException)) {
/* 198 */       ExecutionException e = (ExecutionException)exception;
/* 199 */       Object msg = e.getRequest();
/* 200 */       if ((msg instanceof Request)) {
/* 201 */         Request req = (Request)msg;
/* 202 */         if ((req.isTwoWay()) && (!req.isHeartbeat())) {
/* 203 */           Response res = new Response(req.getId(), req.getVersion());
/* 204 */           res.setStatus((byte)80);
/* 205 */           res.setErrorMessage(StringUtils.toString(e));
/* 206 */           channel.send(res);
/* 207 */           return;
/*     */         }
/*     */       }
/*     */     }
/* 211 */     ExchangeChannel exchangeChannel = HeaderExchangeChannel.getOrAddChannel(channel);
/*     */     try {
/* 213 */       this.handler.caught(exchangeChannel, exception);
/*     */     } finally {
/* 215 */       HeaderExchangeChannel.removeChannelIfDisconnected(channel);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ChannelHandler getHandler() {
/* 220 */     if ((this.handler instanceof ChannelHandlerDelegate)) {
/* 221 */       return ((ChannelHandlerDelegate)this.handler).getHandler();
/*     */     }
/* 223 */     return this.handler;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.header.HeaderExchangeHandler
 * JD-Core Version:    0.6.2
 */