/*     */ package com.alibaba.dubbo.remoting.exchange.support.header;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Parameters;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.Server;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeChannel;
/*     */ import com.alibaba.dubbo.remoting.exchange.ExchangeServer;
/*     */ import com.alibaba.dubbo.remoting.exchange.Request;
/*     */ import com.alibaba.dubbo.remoting.exchange.support.DefaultFuture;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class HeaderExchangeServer
/*     */   implements ExchangeServer
/*     */ {
/*  49 */   protected final Logger logger = LoggerFactory.getLogger(getClass());
/*     */ 
/*  51 */   private final ScheduledExecutorService scheduled = Executors.newScheduledThreadPool(1, new NamedThreadFactory("dubbo-remoting-server-heartbeat", true));
/*     */   private ScheduledFuture<?> heatbeatTimer;
/*     */   private int heartbeat;
/*     */   private int heartbeatTimeout;
/*     */   private final Server server;
/*  66 */   private volatile boolean closed = false;
/*     */ 
/*     */   public HeaderExchangeServer(Server server) {
/*  69 */     if (server == null) {
/*  70 */       throw new IllegalArgumentException("server == null");
/*     */     }
/*  72 */     this.server = server;
/*  73 */     this.heartbeat = server.getUrl().getParameter("heartbeat", 0);
/*  74 */     this.heartbeatTimeout = server.getUrl().getParameter("heartbeat.timeout", this.heartbeat * 3);
/*  75 */     if (this.heartbeatTimeout < this.heartbeat * 2) {
/*  76 */       throw new IllegalStateException("heartbeatTimeout < heartbeatInterval * 2");
/*     */     }
/*  78 */     startHeatbeatTimer();
/*     */   }
/*     */ 
/*     */   public Server getServer() {
/*  82 */     return this.server;
/*     */   }
/*     */ 
/*     */   public boolean isClosed() {
/*  86 */     return this.server.isClosed();
/*     */   }
/*     */ 
/*     */   private boolean isRunning() {
/*  90 */     Collection channels = getChannels();
/*  91 */     for (Channel channel : channels) {
/*  92 */       if (DefaultFuture.hasFuture(channel)) {
/*  93 */         return true;
/*     */       }
/*     */     }
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   public void close() {
/* 100 */     doClose();
/* 101 */     this.server.close();
/*     */   }
/*     */ 
/*     */   public void close(int timeout) {
/* 105 */     if (timeout > 0) {
/* 106 */       long max = timeout;
/* 107 */       long start = System.currentTimeMillis();
/* 108 */       if (getUrl().getParameter("channel.readonly.send", false)) {
/* 109 */         sendChannelReadOnlyEvent();
/*     */       }
/*     */ 
/* 112 */       while ((isRunning()) && (System.currentTimeMillis() - start < max)) {
/*     */         try {
/* 114 */           Thread.sleep(10L);
/*     */         } catch (InterruptedException e) {
/* 116 */           this.logger.warn(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/* 120 */     doClose();
/* 121 */     this.server.close(timeout);
/*     */   }
/*     */ 
/*     */   private void sendChannelReadOnlyEvent() {
/* 125 */     Request request = new Request();
/* 126 */     request.setEvent("R");
/* 127 */     request.setTwoWay(false);
/* 128 */     request.setVersion(Version.getVersion());
/*     */ 
/* 130 */     Collection channels = getChannels();
/* 131 */     for (Channel channel : channels)
/*     */       try {
/* 133 */         if (channel.isConnected()) channel.send(request, getUrl().getParameter("channel.readonly.sent", true)); 
/*     */       }
/* 135 */       catch (RemotingException e) { this.logger.warn("send connot write messge error.", e); }
/*     */ 
/*     */   }
/*     */ 
/*     */   private void doClose()
/*     */   {
/* 141 */     if (this.closed) {
/* 142 */       return;
/*     */     }
/* 144 */     this.closed = true;
/* 145 */     stopHeartbeatTimer();
/*     */     try {
/* 147 */       this.scheduled.shutdown();
/*     */     } catch (Throwable t) {
/* 149 */       this.logger.warn(t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Collection<ExchangeChannel> getExchangeChannels() {
/* 154 */     Collection exchangeChannels = new ArrayList();
/* 155 */     Collection channels = this.server.getChannels();
/* 156 */     if ((channels != null) && (channels.size() > 0)) {
/* 157 */       for (Channel channel : channels) {
/* 158 */         exchangeChannels.add(HeaderExchangeChannel.getOrAddChannel(channel));
/*     */       }
/*     */     }
/* 161 */     return exchangeChannels;
/*     */   }
/*     */ 
/*     */   public ExchangeChannel getExchangeChannel(InetSocketAddress remoteAddress) {
/* 165 */     Channel channel = this.server.getChannel(remoteAddress);
/* 166 */     return HeaderExchangeChannel.getOrAddChannel(channel);
/*     */   }
/*     */ 
/*     */   public Collection<Channel> getChannels()
/*     */   {
/* 171 */     return getExchangeChannels();
/*     */   }
/*     */ 
/*     */   public Channel getChannel(InetSocketAddress remoteAddress) {
/* 175 */     return getExchangeChannel(remoteAddress);
/*     */   }
/*     */ 
/*     */   public boolean isBound() {
/* 179 */     return this.server.isBound();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/* 183 */     return this.server.getLocalAddress();
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/* 187 */     return this.server.getUrl();
/*     */   }
/*     */ 
/*     */   public ChannelHandler getChannelHandler() {
/* 191 */     return this.server.getChannelHandler();
/*     */   }
/*     */ 
/*     */   public void reset(URL url) {
/* 195 */     this.server.reset(url);
/*     */     try {
/* 197 */       if ((url.hasParameter("heartbeat")) || (url.hasParameter("heartbeat.timeout")))
/*     */       {
/* 199 */         int h = url.getParameter("heartbeat", this.heartbeat);
/* 200 */         int t = url.getParameter("heartbeat.timeout", h * 3);
/* 201 */         if (t < h * 2) {
/* 202 */           throw new IllegalStateException("heartbeatTimeout < heartbeatInterval * 2");
/*     */         }
/* 204 */         if ((h != this.heartbeat) || (t != this.heartbeatTimeout)) {
/* 205 */           this.heartbeat = h;
/* 206 */           this.heartbeatTimeout = t;
/* 207 */           startHeatbeatTimer();
/*     */         }
/*     */       }
/*     */     } catch (Throwable t) {
/* 211 */       this.logger.error(t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void reset(Parameters parameters) {
/* 217 */     reset(getUrl().addParameters(parameters.getParameters()));
/*     */   }
/*     */ 
/*     */   public void send(Object message) throws RemotingException {
/* 221 */     if (this.closed) {
/* 222 */       throw new RemotingException(getLocalAddress(), null, "Failed to send message " + message + ", cause: The server " + getLocalAddress() + " is closed!");
/*     */     }
/* 224 */     this.server.send(message);
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/* 228 */     if (this.closed) {
/* 229 */       throw new RemotingException(getLocalAddress(), null, "Failed to send message " + message + ", cause: The server " + getLocalAddress() + " is closed!");
/*     */     }
/* 231 */     this.server.send(message, sent);
/*     */   }
/*     */ 
/*     */   private void startHeatbeatTimer() {
/* 235 */     stopHeartbeatTimer();
/* 236 */     if (this.heartbeat > 0)
/* 237 */       this.heatbeatTimer = this.scheduled.scheduleWithFixedDelay(new HeartBeatTask(new HeartBeatTask.ChannelProvider()
/*     */       {
/*     */         public Collection<Channel> getChannels() {
/* 240 */           return Collections.unmodifiableCollection(HeaderExchangeServer.this.getChannels());
/*     */         }
/*     */       }
/*     */       , this.heartbeat, this.heartbeatTimeout), this.heartbeat, this.heartbeat, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   private void stopHeartbeatTimer()
/*     */   {
/*     */     try
/*     */     {
/* 250 */       ScheduledFuture timer = this.heatbeatTimer;
/* 251 */       if ((timer != null) && (!timer.isCancelled()))
/* 252 */         timer.cancel(true);
/*     */     }
/*     */     catch (Throwable t) {
/* 255 */       this.logger.warn(t.getMessage(), t);
/*     */     } finally {
/* 257 */       this.heatbeatTimer = null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.header.HeaderExchangeServer
 * JD-Core Version:    0.6.2
 */