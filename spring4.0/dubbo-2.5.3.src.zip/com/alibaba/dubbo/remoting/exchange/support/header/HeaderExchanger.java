/*    */ package com.alibaba.dubbo.remoting.exchange.support.header;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.Transporters;
/*    */ import com.alibaba.dubbo.remoting.exchange.ExchangeClient;
/*    */ import com.alibaba.dubbo.remoting.exchange.ExchangeHandler;
/*    */ import com.alibaba.dubbo.remoting.exchange.ExchangeServer;
/*    */ import com.alibaba.dubbo.remoting.exchange.Exchanger;
/*    */ import com.alibaba.dubbo.remoting.transport.DecodeHandler;
/*    */ 
/*    */ public class HeaderExchanger
/*    */   implements Exchanger
/*    */ {
/*    */   public static final String NAME = "header";
/*    */ 
/*    */   public ExchangeClient connect(URL url, ExchangeHandler handler)
/*    */     throws RemotingException
/*    */   {
/* 37 */     return new HeaderExchangeClient(Transporters.connect(url, new ChannelHandler[] { new DecodeHandler(new HeaderExchangeHandler(handler)) }));
/*    */   }
/*    */ 
/*    */   public ExchangeServer bind(URL url, ExchangeHandler handler) throws RemotingException {
/* 41 */     return new HeaderExchangeServer(Transporters.bind(url, new ChannelHandler[] { new DecodeHandler(new HeaderExchangeHandler(handler)) }));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.header.HeaderExchanger
 * JD-Core Version:    0.6.2
 */