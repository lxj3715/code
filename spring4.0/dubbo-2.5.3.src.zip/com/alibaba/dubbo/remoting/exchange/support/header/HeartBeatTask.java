/*    */ package com.alibaba.dubbo.remoting.exchange.support.header;
/*    */ 
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.Client;
/*    */ import com.alibaba.dubbo.remoting.exchange.Request;
/*    */ import java.util.Collection;
/*    */ 
/*    */ final class HeartBeatTask
/*    */   implements Runnable
/*    */ {
/* 32 */   private static final Logger logger = LoggerFactory.getLogger(HeartBeatTask.class);
/*    */   private ChannelProvider channelProvider;
/*    */   private int heartbeat;
/*    */   private int heartbeatTimeout;
/*    */ 
/*    */   HeartBeatTask(ChannelProvider provider, int heartbeat, int heartbeatTimeout)
/*    */   {
/* 41 */     this.channelProvider = provider;
/* 42 */     this.heartbeat = heartbeat;
/* 43 */     this.heartbeatTimeout = heartbeatTimeout;
/*    */   }
/*    */ 
/*    */   public void run() {
/*    */     try {
/* 48 */       now = System.currentTimeMillis();
/* 49 */       for (Channel channel : this.channelProvider.getChannels())
/* 50 */         if (!channel.isClosed())
/*    */         {
/*    */           try
/*    */           {
/* 54 */             Long lastRead = (Long)channel.getAttribute(HeaderExchangeHandler.KEY_READ_TIMESTAMP);
/*    */ 
/* 56 */             Long lastWrite = (Long)channel.getAttribute(HeaderExchangeHandler.KEY_WRITE_TIMESTAMP);
/*    */ 
/* 58 */             if (((lastRead != null) && (now - lastRead.longValue() > this.heartbeat)) || ((lastWrite != null) && (now - lastWrite.longValue() > this.heartbeat)))
/*    */             {
/* 60 */               Request req = new Request();
/* 61 */               req.setVersion("2.0.0");
/* 62 */               req.setTwoWay(true);
/* 63 */               req.setEvent(Request.HEARTBEAT_EVENT);
/* 64 */               channel.send(req);
/* 65 */               if (logger.isDebugEnabled()) {
/* 66 */                 logger.debug("Send heartbeat to remote channel " + channel.getRemoteAddress() + ", cause: The channel has no data-transmission exceeds a heartbeat period: " + this.heartbeat + "ms");
/*    */               }
/*    */             }
/*    */ 
/* 70 */             if ((lastRead != null) && (now - lastRead.longValue() > this.heartbeatTimeout)) {
/* 71 */               logger.warn("Close channel " + channel + ", because heartbeat read idle time out: " + this.heartbeatTimeout + "ms");
/*    */ 
/* 73 */               if ((channel instanceof Client))
/*    */                 try {
/* 75 */                   ((Client)channel).reconnect();
/*    */                 }
/*    */                 catch (Exception e) {
/*    */                 }
/*    */               else
/* 80 */                 channel.close();
/*    */             }
/*    */           }
/*    */           catch (Throwable t) {
/* 84 */             logger.warn("Exception when heartbeat to remote channel " + channel.getRemoteAddress(), t);
/*    */           }
/*    */         }
/*    */     }
/*    */     catch (Throwable t)
/*    */     {
/*    */       long now;
/* 88 */       logger.warn("Unhandled exception when heartbeat, cause: " + t.getMessage(), t);
/*    */     }
/*    */   }
/*    */ 
/*    */   static abstract interface ChannelProvider
/*    */   {
/*    */     public abstract Collection<Channel> getChannels();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.header.HeartBeatTask
 * JD-Core Version:    0.6.2
 */