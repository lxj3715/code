/*     */ package com.alibaba.dubbo.remoting.exchange.support.header;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.exchange.Request;
/*     */ import com.alibaba.dubbo.remoting.exchange.Response;
/*     */ import com.alibaba.dubbo.remoting.transport.AbstractChannelHandlerDelegate;
/*     */ 
/*     */ public class HeartbeatHandler extends AbstractChannelHandlerDelegate
/*     */ {
/*  34 */   private static final Logger logger = LoggerFactory.getLogger(HeartbeatHandler.class);
/*     */ 
/*  36 */   public static String KEY_READ_TIMESTAMP = "READ_TIMESTAMP";
/*     */ 
/*  38 */   public static String KEY_WRITE_TIMESTAMP = "WRITE_TIMESTAMP";
/*     */ 
/*     */   public HeartbeatHandler(ChannelHandler handler) {
/*  41 */     super(handler);
/*     */   }
/*     */ 
/*     */   public void connected(Channel channel) throws RemotingException {
/*  45 */     setReadTimestamp(channel);
/*  46 */     setWriteTimestamp(channel);
/*  47 */     this.handler.connected(channel);
/*     */   }
/*     */ 
/*     */   public void disconnected(Channel channel) throws RemotingException {
/*  51 */     clearReadTimestamp(channel);
/*  52 */     clearWriteTimestamp(channel);
/*  53 */     this.handler.disconnected(channel);
/*     */   }
/*     */ 
/*     */   public void sent(Channel channel, Object message) throws RemotingException {
/*  57 */     setWriteTimestamp(channel);
/*  58 */     this.handler.sent(channel, message);
/*     */   }
/*     */ 
/*     */   public void received(Channel channel, Object message) throws RemotingException {
/*  62 */     setReadTimestamp(channel);
/*  63 */     if (isHeartbeatRequest(message)) {
/*  64 */       Request req = (Request)message;
/*  65 */       if (req.isTwoWay()) {
/*  66 */         Response res = new Response(req.getId(), req.getVersion());
/*  67 */         res.setEvent(Response.HEARTBEAT_EVENT);
/*  68 */         channel.send(res);
/*  69 */         if (logger.isInfoEnabled()) {
/*  70 */           int heartbeat = channel.getUrl().getParameter("heartbeat", 0);
/*  71 */           if (logger.isDebugEnabled()) {
/*  72 */             logger.debug("Received heartbeat from remote channel " + channel.getRemoteAddress() + ", cause: The channel has no data-transmission exceeds a heartbeat period" + (heartbeat > 0 ? ": " + heartbeat + "ms" : ""));
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  78 */       return;
/*     */     }
/*  80 */     if (isHeartbeatResponse(message)) {
/*  81 */       if (logger.isDebugEnabled()) {
/*  82 */         logger.debug(32 + "Receive heartbeat response in thread " + Thread.currentThread().getName());
/*     */       }
/*     */ 
/*  88 */       return;
/*     */     }
/*  90 */     this.handler.received(channel, message);
/*     */   }
/*     */ 
/*     */   private void setReadTimestamp(Channel channel) {
/*  94 */     channel.setAttribute(KEY_READ_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
/*     */   }
/*     */ 
/*     */   private void setWriteTimestamp(Channel channel) {
/*  98 */     channel.setAttribute(KEY_WRITE_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
/*     */   }
/*     */ 
/*     */   private void clearReadTimestamp(Channel channel) {
/* 102 */     channel.removeAttribute(KEY_READ_TIMESTAMP);
/*     */   }
/*     */ 
/*     */   private void clearWriteTimestamp(Channel channel) {
/* 106 */     channel.removeAttribute(KEY_WRITE_TIMESTAMP);
/*     */   }
/*     */ 
/*     */   private boolean isHeartbeatRequest(Object message) {
/* 110 */     return ((message instanceof Request)) && (((Request)message).isHeartbeat());
/*     */   }
/*     */ 
/*     */   private boolean isHeartbeatResponse(Object message) {
/* 114 */     return ((message instanceof Response)) && (((Response)message).isHeartbeat());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.exchange.support.header.HeartbeatHandler
 * JD-Core Version:    0.6.2
 */