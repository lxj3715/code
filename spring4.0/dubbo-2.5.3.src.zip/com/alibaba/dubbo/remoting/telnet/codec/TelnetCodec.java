/*     */ package com.alibaba.dubbo.remoting.telnet.codec;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.Codec2.DecodeResult;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.buffer.ChannelBuffer;
/*     */ import com.alibaba.dubbo.remoting.transport.codec.TransportCodec;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class TelnetCodec extends TransportCodec
/*     */ {
/*  44 */   private static final Logger logger = LoggerFactory.getLogger(TelnetCodec.class);
/*     */   private static final String HISTORY_LIST_KEY = "telnet.history.list";
/*     */   private static final String HISTORY_INDEX_KEY = "telnet.history.index";
/*  50 */   private static final byte[] UP = { 27, 91, 65 };
/*     */ 
/*  52 */   private static final byte[] DOWN = { 27, 91, 66 };
/*     */ 
/*  54 */   private static final List<?> ENTER = Arrays.asList(new Object[] { { 13, 10 }, { 10 } });
/*     */ 
/*  56 */   private static final List<?> EXIT = Arrays.asList(new Object[] { { 3 }, { -1, -12, -1, -3, 6 }, { -1, -19, -1, -3, 6 } });
/*     */ 
/*     */   public void encode(Channel channel, ChannelBuffer buffer, Object message) throws IOException {
/*  59 */     if ((message instanceof String)) {
/*  60 */       if (isClientSide(channel)) {
/*  61 */         message = message + "\r\n";
/*     */       }
/*  63 */       byte[] msgData = ((String)message).getBytes(getCharset(channel).name());
/*  64 */       buffer.writeBytes(msgData);
/*     */     } else {
/*  66 */       super.encode(channel, buffer, message);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object decode(Channel channel, ChannelBuffer buffer) throws IOException {
/*  71 */     int readable = buffer.readableBytes();
/*  72 */     byte[] message = new byte[readable];
/*  73 */     buffer.readBytes(message);
/*  74 */     return decode(channel, buffer, readable, message);
/*     */   }
/*     */ 
/*     */   protected Object decode(Channel channel, ChannelBuffer buffer, int readable, byte[] message) throws IOException
/*     */   {
/*  79 */     if (isClientSide(channel)) {
/*  80 */       return toString(message, getCharset(channel));
/*     */     }
/*  82 */     checkPayload(channel, readable);
/*  83 */     if ((message == null) || (message.length == 0)) {
/*  84 */       return Codec2.DecodeResult.NEED_MORE_INPUT;
/*     */     }
/*     */ 
/*  87 */     if (message[(message.length - 1)] == 8) {
/*     */       try {
/*  89 */         boolean doublechar = (message.length >= 3) && (message[(message.length - 3)] < 0);
/*  90 */         channel.send(new String(new byte[] { 32, doublechar ? new byte[] { 32, 32, 8, 8 } : 8 }, getCharset(channel).name()));
/*     */       } catch (RemotingException e) {
/*  92 */         throw new IOException(StringUtils.toString(e));
/*     */       }
/*  94 */       return Codec2.DecodeResult.NEED_MORE_INPUT;
/*     */     }
/*     */ 
/*  97 */     for (Iterator i$ = EXIT.iterator(); i$.hasNext(); ) { Object command = i$.next();
/*  98 */       if (isEquals(message, (byte[])command)) {
/*  99 */         if (logger.isInfoEnabled()) {
/* 100 */           logger.info(new Exception("Close channel " + channel + " on exit command: " + Arrays.toString((byte[])command)));
/*     */         }
/* 102 */         channel.close();
/* 103 */         return null;
/*     */       }
/*     */     }
/*     */ 
/* 107 */     boolean up = endsWith(message, UP);
/* 108 */     boolean down = endsWith(message, DOWN);
/* 109 */     if ((up) || (down)) {
/* 110 */       LinkedList history = (LinkedList)channel.getAttribute("telnet.history.list");
/* 111 */       if ((history == null) || (history.size() == 0)) {
/* 112 */         return Codec2.DecodeResult.NEED_MORE_INPUT;
/*     */       }
/* 114 */       Integer index = (Integer)channel.getAttribute("telnet.history.index");
/* 115 */       Integer old = index;
/* 116 */       if (index == null) {
/* 117 */         index = Integer.valueOf(history.size() - 1);
/*     */       }
/* 119 */       else if (up) {
/* 120 */         index = Integer.valueOf(index.intValue() - 1);
/* 121 */         if (index.intValue() < 0)
/* 122 */           index = Integer.valueOf(history.size() - 1);
/*     */       }
/*     */       else {
/* 125 */         index = Integer.valueOf(index.intValue() + 1);
/* 126 */         if (index.intValue() > history.size() - 1) {
/* 127 */           index = Integer.valueOf(0);
/*     */         }
/*     */       }
/*     */ 
/* 131 */       if ((old == null) || (!old.equals(index))) {
/* 132 */         channel.setAttribute("telnet.history.index", index);
/* 133 */         String value = (String)history.get(index.intValue());
/* 134 */         if ((old != null) && (old.intValue() >= 0) && (old.intValue() < history.size())) {
/* 135 */           String ov = (String)history.get(old.intValue());
/* 136 */           StringBuilder buf = new StringBuilder();
/* 137 */           for (int i = 0; i < ov.length(); i++) {
/* 138 */             buf.append("\b");
/*     */           }
/* 140 */           for (int i = 0; i < ov.length(); i++) {
/* 141 */             buf.append(" ");
/*     */           }
/* 143 */           for (int i = 0; i < ov.length(); i++) {
/* 144 */             buf.append("\b");
/*     */           }
/* 146 */           value = buf.toString() + value;
/*     */         }
/*     */         try {
/* 149 */           channel.send(value);
/*     */         } catch (RemotingException e) {
/* 151 */           throw new IOException(StringUtils.toString(e));
/*     */         }
/*     */       }
/* 154 */       return Codec2.DecodeResult.NEED_MORE_INPUT;
/*     */     }
/* 156 */     for (Iterator i$ = EXIT.iterator(); i$.hasNext(); ) { Object command = i$.next();
/* 157 */       if (isEquals(message, (byte[])command)) {
/* 158 */         if (logger.isInfoEnabled()) {
/* 159 */           logger.info(new Exception("Close channel " + channel + " on exit command " + command));
/*     */         }
/* 161 */         channel.close();
/* 162 */         return null;
/*     */       }
/*     */     }
/* 165 */     byte[] enter = null;
/* 166 */     for (Iterator i$ = ENTER.iterator(); i$.hasNext(); ) { Object command = i$.next();
/* 167 */       if (endsWith(message, (byte[])command)) {
/* 168 */         enter = (byte[])command;
/* 169 */         break;
/*     */       }
/*     */     }
/* 172 */     if (enter == null) {
/* 173 */       return Codec2.DecodeResult.NEED_MORE_INPUT;
/*     */     }
/* 175 */     LinkedList history = (LinkedList)channel.getAttribute("telnet.history.list");
/* 176 */     Integer index = (Integer)channel.getAttribute("telnet.history.index");
/* 177 */     channel.removeAttribute("telnet.history.index");
/* 178 */     if ((history != null) && (history.size() > 0) && (index != null) && (index.intValue() >= 0) && (index.intValue() < history.size())) {
/* 179 */       String value = (String)history.get(index.intValue());
/* 180 */       if (value != null) {
/* 181 */         byte[] b1 = value.getBytes();
/* 182 */         if ((message != null) && (message.length > 0)) {
/* 183 */           byte[] b2 = new byte[b1.length + message.length];
/* 184 */           System.arraycopy(b1, 0, b2, 0, b1.length);
/* 185 */           System.arraycopy(message, 0, b2, b1.length, message.length);
/* 186 */           message = b2;
/*     */         } else {
/* 188 */           message = b1;
/*     */         }
/*     */       }
/*     */     }
/* 192 */     String result = toString(message, getCharset(channel));
/* 193 */     if ((result != null) && (result.trim().length() > 0)) {
/* 194 */       if (history == null) {
/* 195 */         history = new LinkedList();
/* 196 */         channel.setAttribute("telnet.history.list", history);
/*     */       }
/* 198 */       if (history.size() == 0) {
/* 199 */         history.addLast(result);
/* 200 */       } else if (!result.equals(history.getLast())) {
/* 201 */         history.remove(result);
/* 202 */         history.addLast(result);
/* 203 */         if (history.size() > 10) {
/* 204 */           history.removeFirst();
/*     */         }
/*     */       }
/*     */     }
/* 208 */     return result;
/*     */   }
/*     */ 
/*     */   private static Charset getCharset(Channel channel) {
/* 212 */     if (channel != null) {
/* 213 */       Object attribute = channel.getAttribute("charset");
/* 214 */       if ((attribute instanceof String))
/*     */         try {
/* 216 */           return Charset.forName((String)attribute);
/*     */         } catch (Throwable t) {
/* 218 */           logger.warn(t.getMessage(), t);
/*     */         }
/* 220 */       else if ((attribute instanceof Charset)) {
/* 221 */         return (Charset)attribute;
/*     */       }
/* 223 */       URL url = channel.getUrl();
/* 224 */       if (url != null) {
/* 225 */         String parameter = url.getParameter("charset");
/* 226 */         if ((parameter != null) && (parameter.length() > 0))
/*     */           try {
/* 228 */             return Charset.forName(parameter);
/*     */           } catch (Throwable t) {
/* 230 */             logger.warn(t.getMessage(), t);
/*     */           }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 236 */       return Charset.forName("GBK");
/*     */     } catch (Throwable t) {
/* 238 */       logger.warn(t.getMessage(), t);
/*     */     }
/* 240 */     return Charset.defaultCharset();
/*     */   }
/*     */ 
/*     */   private static String toString(byte[] message, Charset charset) throws UnsupportedEncodingException {
/* 244 */     byte[] copy = new byte[message.length];
/* 245 */     int index = 0;
/* 246 */     for (int i = 0; i < message.length; i++) {
/* 247 */       byte b = message[i];
/* 248 */       if (b == 8) {
/* 249 */         if (index > 0) {
/* 250 */           index--;
/*     */         }
/* 252 */         if ((i > 2) && (message[(i - 2)] < 0) && 
/* 253 */           (index > 0)) {
/* 254 */           index--;
/*     */         }
/*     */       }
/* 257 */       else if (b == 27) {
/* 258 */         if ((i < message.length - 4) && (message[(i + 4)] == 126))
/* 259 */           i += 4;
/* 260 */         else if ((i < message.length - 3) && (message[(i + 3)] == 126))
/* 261 */           i += 3;
/* 262 */         else if (i < message.length - 2)
/* 263 */           i += 2;
/*     */       }
/* 265 */       else if ((b == -1) && (i < message.length - 2) && ((message[(i + 1)] == -3) || (message[(i + 1)] == -5)))
/*     */       {
/* 267 */         i += 2;
/*     */       } else {
/* 269 */         copy[(index++)] = message[i];
/*     */       }
/*     */     }
/* 272 */     if (index == 0) {
/* 273 */       return "";
/*     */     }
/* 275 */     return new String(copy, 0, index, charset.name()).trim();
/*     */   }
/*     */ 
/*     */   private static boolean isEquals(byte[] message, byte[] command) throws IOException {
/* 279 */     return (message.length == command.length) && (endsWith(message, command));
/*     */   }
/*     */ 
/*     */   private static boolean endsWith(byte[] message, byte[] command) throws IOException {
/* 283 */     if (message.length < command.length) {
/* 284 */       return false;
/*     */     }
/* 286 */     int offset = message.length - command.length;
/* 287 */     for (int i = command.length - 1; i >= 0; i--) {
/* 288 */       if (message[(offset + i)] != command[i]) {
/* 289 */         return false;
/*     */       }
/*     */     }
/* 292 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.telnet.codec.TelnetCodec
 * JD-Core Version:    0.6.2
 */