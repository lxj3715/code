/*    */ package com.alibaba.dubbo.remoting.telnet.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*    */ import com.alibaba.dubbo.remoting.transport.ChannelHandlerAdapter;
/*    */ 
/*    */ public class TelnetHandlerAdapter extends ChannelHandlerAdapter
/*    */   implements TelnetHandler
/*    */ {
/* 30 */   private final ExtensionLoader<TelnetHandler> extensionLoader = ExtensionLoader.getExtensionLoader(TelnetHandler.class);
/*    */ 
/*    */   public String telnet(Channel channel, String message) throws RemotingException {
/* 33 */     String prompt = channel.getUrl().getParameterAndDecoded("prompt", "dubbo>");
/* 34 */     boolean noprompt = message.contains("--no-prompt");
/* 35 */     message = message.replace("--no-prompt", "");
/* 36 */     StringBuilder buf = new StringBuilder();
/* 37 */     message = message.trim();
/*    */     String command;
/* 39 */     if (message.length() > 0) {
/* 40 */       int i = message.indexOf(' ');
/* 41 */       if (i > 0) {
/* 42 */         String command = message.substring(0, i).trim();
/* 43 */         message = message.substring(i + 1).trim();
/*    */       } else {
/* 45 */         String command = message;
/* 46 */         message = "";
/*    */       }
/*    */     } else {
/* 49 */       command = "";
/*    */     }
/* 51 */     if (command.length() > 0) {
/* 52 */       if (this.extensionLoader.hasExtension(command)) {
/*    */         try {
/* 54 */           String result = ((TelnetHandler)this.extensionLoader.getExtension(command)).telnet(channel, message);
/* 55 */           if (result == null) {
/* 56 */             return null;
/*    */           }
/* 58 */           buf.append(result);
/*    */         } catch (Throwable t) {
/* 60 */           buf.append(t.getMessage());
/*    */         }
/*    */       } else {
/* 63 */         buf.append("Unsupported command: ");
/* 64 */         buf.append(command);
/*    */       }
/*    */     }
/* 67 */     if (buf.length() > 0) {
/* 68 */       buf.append("\r\n");
/*    */     }
/* 70 */     if ((prompt != null) && (prompt.length() > 0) && (!noprompt)) {
/* 71 */       buf.append(prompt);
/*    */     }
/* 73 */     return buf.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.telnet.support.TelnetHandlerAdapter
 * JD-Core Version:    0.6.2
 */