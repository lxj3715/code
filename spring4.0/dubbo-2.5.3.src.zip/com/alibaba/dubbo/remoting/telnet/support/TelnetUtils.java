/*     */ package com.alibaba.dubbo.remoting.telnet.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ public class TelnetUtils
/*     */ {
/*     */   public static String toList(List<List<String>> table)
/*     */   {
/*  29 */     int[] widths = new int[((List)table.get(0)).size()];
/*  30 */     for (int j = 0; j < widths.length; j++) {
/*  31 */       for (List row : table) {
/*  32 */         widths[j] = Math.max(widths[j], ((String)row.get(j)).length());
/*     */       }
/*     */     }
/*  35 */     StringBuilder buf = new StringBuilder();
/*  36 */     for (List row : table) {
/*  37 */       if (buf.length() > 0) {
/*  38 */         buf.append("\r\n");
/*     */       }
/*  40 */       for (int j = 0; j < widths.length; j++) {
/*  41 */         if (j > 0) {
/*  42 */           buf.append(" - ");
/*     */         }
/*  44 */         String value = (String)row.get(j);
/*  45 */         buf.append(value);
/*  46 */         if (j < widths.length - 1) {
/*  47 */           int pad = widths[j] - value.length();
/*  48 */           if (pad > 0) {
/*  49 */             for (int k = 0; k < pad; k++) {
/*  50 */               buf.append(" ");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  56 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static String toTable(String[] header, List<List<String>> table) {
/*  60 */     return toTable(Arrays.asList(header), table);
/*     */   }
/*     */ 
/*     */   public static String toTable(List<String> header, List<List<String>> table) {
/*  64 */     int totalWidth = 0;
/*  65 */     int[] widths = new int[header.size()];
/*  66 */     int maxwidth = 70;
/*  67 */     int maxcountbefore = 0;
/*  68 */     for (int j = 0; j < widths.length; j++) {
/*  69 */       widths[j] = Math.max(widths[j], ((String)header.get(j)).length());
/*     */     }
/*  71 */     for (List row : table) {
/*  72 */       int countbefore = 0;
/*  73 */       for (int j = 0; j < widths.length; j++) {
/*  74 */         widths[j] = Math.max(widths[j], ((String)row.get(j)).length());
/*  75 */         totalWidth = totalWidth + widths[j] > maxwidth ? maxwidth : totalWidth + widths[j];
/*  76 */         if (j < widths.length - 1) {
/*  77 */           countbefore += widths[j];
/*     */         }
/*     */       }
/*  80 */       maxcountbefore = Math.max(countbefore, maxcountbefore);
/*     */     }
/*  82 */     widths[(widths.length - 1)] = Math.min(widths[(widths.length - 1)], maxwidth - maxcountbefore);
/*  83 */     StringBuilder buf = new StringBuilder();
/*     */ 
/*  85 */     buf.append("+");
/*  86 */     for (int j = 0; j < widths.length; j++) {
/*  87 */       for (int k = 0; k < widths[j] + 2; k++) {
/*  88 */         buf.append("-");
/*     */       }
/*  90 */       buf.append("+");
/*     */     }
/*  92 */     buf.append("\r\n");
/*     */ 
/*  94 */     buf.append("|");
/*  95 */     for (int j = 0; j < widths.length; j++) {
/*  96 */       String cell = (String)header.get(j);
/*  97 */       buf.append(" ");
/*  98 */       buf.append(cell);
/*  99 */       int pad = widths[j] - cell.length();
/* 100 */       if (pad > 0) {
/* 101 */         for (int k = 0; k < pad; k++) {
/* 102 */           buf.append(" ");
/*     */         }
/*     */       }
/* 105 */       buf.append(" |");
/*     */     }
/* 107 */     buf.append("\r\n");
/*     */ 
/* 109 */     buf.append("+");
/* 110 */     for (int j = 0; j < widths.length; j++) {
/* 111 */       for (int k = 0; k < widths[j] + 2; k++) {
/* 112 */         buf.append("-");
/*     */       }
/* 114 */       buf.append("+");
/*     */     }
/* 116 */     buf.append("\r\n");
/*     */ 
/* 118 */     for (List row : table) {
/* 119 */       StringBuffer rowbuf = new StringBuffer();
/* 120 */       rowbuf.append("|");
/* 121 */       for (int j = 0; j < widths.length; j++) {
/* 122 */         String cell = (String)row.get(j);
/* 123 */         rowbuf.append(" ");
/* 124 */         int remaing = cell.length();
/* 125 */         while (remaing > 0)
/*     */         {
/* 127 */           if (rowbuf.length() >= totalWidth) {
/* 128 */             buf.append(rowbuf.toString());
/* 129 */             rowbuf = new StringBuffer();
/*     */           }
/*     */ 
/* 135 */           rowbuf.append(cell.substring(cell.length() - remaing, cell.length() - remaing + 1));
/* 136 */           remaing--;
/*     */         }
/* 138 */         int pad = widths[j] - cell.length();
/* 139 */         if (pad > 0) {
/* 140 */           for (int k = 0; k < pad; k++) {
/* 141 */             rowbuf.append(" ");
/*     */           }
/*     */         }
/* 144 */         rowbuf.append(" |");
/*     */       }
/* 146 */       buf.append(rowbuf).append("\r\n");
/*     */     }
/*     */ 
/* 149 */     buf.append("+");
/* 150 */     for (int j = 0; j < widths.length; j++) {
/* 151 */       for (int k = 0; k < widths[j] + 2; k++) {
/* 152 */         buf.append("-");
/*     */       }
/* 154 */       buf.append("+");
/*     */     }
/* 156 */     buf.append("\r\n");
/* 157 */     return buf.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.telnet.support.TelnetUtils
 * JD-Core Version:    0.6.2
 */