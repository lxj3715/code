/*    */ package com.alibaba.dubbo.remoting.telnet.support.command;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.utils.StringUtils;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*    */ import com.alibaba.dubbo.remoting.telnet.support.Help;
/*    */ 
/*    */ @Activate
/*    */ @Help(parameter="[lines]", summary="Clear screen.", detail="Clear screen.")
/*    */ public class ClearTelnetHandler
/*    */   implements TelnetHandler
/*    */ {
/*    */   public String telnet(Channel channel, String message)
/*    */   {
/* 34 */     int lines = 100;
/* 35 */     if (message.length() > 0) {
/* 36 */       if (!StringUtils.isInteger(message)) {
/* 37 */         return "Illegal lines " + message + ", must be integer.";
/*    */       }
/* 39 */       lines = Integer.parseInt(message);
/*    */     }
/* 41 */     StringBuilder buf = new StringBuilder();
/* 42 */     for (int i = 0; i < lines; i++) {
/* 43 */       buf.append("\r\n");
/*    */     }
/* 45 */     return buf.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.telnet.support.command.ClearTelnetHandler
 * JD-Core Version:    0.6.2
 */