/*    */ package com.alibaba.dubbo.remoting.telnet.support.command;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*    */ import com.alibaba.dubbo.remoting.telnet.support.Help;
/*    */ 
/*    */ @Activate
/*    */ @Help(parameter="", summary="Exit the telnet.", detail="Exit the telnet.")
/*    */ public class ExitTelnetHandler
/*    */   implements TelnetHandler
/*    */ {
/*    */   public String telnet(Channel channel, String message)
/*    */   {
/* 33 */     channel.close();
/* 34 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.telnet.support.command.ExitTelnetHandler
 * JD-Core Version:    0.6.2
 */