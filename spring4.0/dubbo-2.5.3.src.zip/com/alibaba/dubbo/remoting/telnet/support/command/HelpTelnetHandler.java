/*    */ package com.alibaba.dubbo.remoting.telnet.support.command;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*    */ import com.alibaba.dubbo.remoting.telnet.support.Help;
/*    */ import com.alibaba.dubbo.remoting.telnet.support.TelnetUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ @Activate
/*    */ @Help(parameter="[command]", summary="Show help.", detail="Show help.")
/*    */ public class HelpTelnetHandler
/*    */   implements TelnetHandler
/*    */ {
/* 37 */   private final ExtensionLoader<TelnetHandler> extensionLoader = ExtensionLoader.getExtensionLoader(TelnetHandler.class);
/*    */ 
/*    */   public String telnet(Channel channel, String message) {
/* 40 */     if (message.length() > 0) {
/* 41 */       if (!this.extensionLoader.hasExtension(message)) {
/* 42 */         return "No such command " + message;
/*    */       }
/* 44 */       TelnetHandler handler = (TelnetHandler)this.extensionLoader.getExtension(message);
/* 45 */       Help help = (Help)handler.getClass().getAnnotation(Help.class);
/* 46 */       StringBuilder buf = new StringBuilder();
/* 47 */       buf.append("Command:\r\n    ");
/* 48 */       buf.append(message + " " + help.parameter().replace("\r\n", " ").replace("\n", " "));
/* 49 */       buf.append("\r\nSummary:\r\n    ");
/* 50 */       buf.append(help.summary().replace("\r\n", " ").replace("\n", " "));
/* 51 */       buf.append("\r\nDetail:\r\n    ");
/* 52 */       buf.append(help.detail().replace("\r\n", "    \r\n").replace("\n", "    \n"));
/* 53 */       return buf.toString();
/*    */     }
/* 55 */     List table = new ArrayList();
/* 56 */     List handlers = this.extensionLoader.getActivateExtension(channel.getUrl(), "telnet");
/* 57 */     if ((handlers != null) && (handlers.size() > 0)) {
/* 58 */       for (TelnetHandler handler : handlers) {
/* 59 */         Help help = (Help)handler.getClass().getAnnotation(Help.class);
/* 60 */         List row = new ArrayList();
/* 61 */         String parameter = " " + this.extensionLoader.getExtensionName(handler) + " " + (help != null ? help.parameter().replace("\r\n", " ").replace("\n", " ") : "");
/* 62 */         row.add(parameter.length() > 50 ? parameter.substring(0, 50) + "..." : parameter);
/* 63 */         String summary = help != null ? help.summary().replace("\r\n", " ").replace("\n", " ") : "";
/* 64 */         row.add(summary.length() > 50 ? summary.substring(0, 50) + "..." : summary);
/* 65 */         table.add(row);
/*    */       }
/*    */     }
/* 68 */     return "Please input \"help [command]\" show detail.\r\n" + TelnetUtils.toList(table);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.telnet.support.command.HelpTelnetHandler
 * JD-Core Version:    0.6.2
 */