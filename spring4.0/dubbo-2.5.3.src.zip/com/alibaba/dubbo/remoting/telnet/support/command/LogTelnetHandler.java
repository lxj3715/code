/*    */ package com.alibaba.dubbo.remoting.telnet.support.command;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.logger.Level;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.common.utils.StringUtils;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*    */ import com.alibaba.dubbo.remoting.telnet.support.Help;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.FileChannel;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ @Activate
/*    */ @Help(parameter="level", summary="Change log level or show log ", detail="Change log level or show log")
/*    */ public class LogTelnetHandler
/*    */   implements TelnetHandler
/*    */ {
/*    */   public static final String SERVICE_KEY = "telnet.log";
/*    */ 
/*    */   public String telnet(Channel channel, String message)
/*    */   {
/* 46 */     long size = 0L;
/* 47 */     File file = LoggerFactory.getFile();
/* 48 */     StringBuffer buf = new StringBuffer();
/* 49 */     if ((message == null) || (message.trim().length() == 0)) {
/* 50 */       buf.append("EXAMPLE: log error / log 100");
/*    */     } else {
/* 52 */       String[] str = message.split(" ");
/* 53 */       if (!StringUtils.isInteger(str[0])) {
/* 54 */         LoggerFactory.setLevel(Level.valueOf(message.toUpperCase()));
/*    */       } else {
/* 56 */         int SHOW_LOG_LENGTH = Integer.parseInt(str[0]);
/*    */ 
/* 58 */         if ((file != null) && (file.exists())) {
/*    */           try {
/* 60 */             FileInputStream fis = new FileInputStream(file);
/*    */             try {
/* 62 */               FileChannel filechannel = fis.getChannel();
/*    */               try {
/* 64 */                 size = filechannel.size();
/*    */                 ByteBuffer bb;
/* 66 */                 if (size <= SHOW_LOG_LENGTH) {
/* 67 */                   ByteBuffer bb = ByteBuffer.allocate((int)size);
/* 68 */                   filechannel.read(bb, 0L);
/*    */                 } else {
/* 70 */                   int pos = (int)(size - SHOW_LOG_LENGTH);
/* 71 */                   bb = ByteBuffer.allocate(SHOW_LOG_LENGTH);
/* 72 */                   filechannel.read(bb, pos);
/*    */                 }
/* 74 */                 bb.flip();
/* 75 */                 String content = new String(bb.array()).replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br/><br/>");
/*    */ 
/* 77 */                 buf.append("\r\ncontent:" + content);
/*    */ 
/* 79 */                 buf.append("\r\nmodified:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(file.lastModified())));
/*    */ 
/* 81 */                 buf.append("\r\nsize:" + size + "\r\n");
/*    */               } finally {
/*    */               }
/*    */             }
/*    */             finally {
/* 86 */               fis.close();
/*    */             }
/*    */           } catch (Exception e) {
/* 89 */             buf.append(e.getMessage());
/*    */           }
/*    */         } else {
/* 92 */           size = 0L;
/* 93 */           buf.append("\r\nMESSAGE: log file not exists or log appender is console .");
/*    */         }
/*    */       }
/*    */     }
/* 97 */     buf.append("\r\nCURRENT LOG LEVEL:" + LoggerFactory.getLevel()).append("\r\nCURRENT LOG APPENDER:" + (file == null ? "console" : file.getAbsolutePath()));
/*    */ 
/* 99 */     return buf.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.telnet.support.command.LogTelnetHandler
 * JD-Core Version:    0.6.2
 */