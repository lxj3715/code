/*    */ package com.alibaba.dubbo.remoting.telnet.support.command;
/*    */ 
/*    */ import com.alibaba.dubbo.common.Constants;
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.common.status.Status;
/*    */ import com.alibaba.dubbo.common.status.Status.Level;
/*    */ import com.alibaba.dubbo.common.status.StatusChecker;
/*    */ import com.alibaba.dubbo.common.status.support.StatusUtils;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.telnet.TelnetHandler;
/*    */ import com.alibaba.dubbo.remoting.telnet.support.Help;
/*    */ import com.alibaba.dubbo.remoting.telnet.support.TelnetUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ @Activate
/*    */ @Help(parameter="[-l]", summary="Show status.", detail="Show status.")
/*    */ public class StatusTelnetHandler
/*    */   implements TelnetHandler
/*    */ {
/* 43 */   private final ExtensionLoader<StatusChecker> extensionLoader = ExtensionLoader.getExtensionLoader(StatusChecker.class);
/*    */ 
/*    */   public String telnet(Channel channel, String message) {
/* 46 */     if (message.equals("-l")) {
/* 47 */       List checkers = this.extensionLoader.getActivateExtension(channel.getUrl(), "status");
/* 48 */       String[] header = { "resource", "status", "message" };
/* 49 */       List table = new ArrayList();
/* 50 */       Map statuses = new HashMap();
/* 51 */       if ((checkers != null) && (checkers.size() > 0)) {
/* 52 */         for (StatusChecker checker : checkers) { String name = this.extensionLoader.getExtensionName(checker);
/*    */           Status stat;
/*    */           try {
/* 56 */             stat = checker.check();
/*    */           } catch (Throwable t) {
/* 58 */             stat = new Status(Status.Level.ERROR, t.getMessage());
/*    */           }
/* 60 */           statuses.put(name, stat);
/* 61 */           if ((stat.getLevel() != null) && (stat.getLevel() != Status.Level.UNKNOWN)) {
/* 62 */             List row = new ArrayList();
/* 63 */             row.add(name);
/* 64 */             row.add(String.valueOf(stat.getLevel()));
/* 65 */             row.add(stat.getMessage() == null ? "" : stat.getMessage());
/* 66 */             table.add(row);
/*    */           }
/*    */         }
/*    */       }
/* 70 */       Status stat = StatusUtils.getSummaryStatus(statuses);
/* 71 */       List row = new ArrayList();
/* 72 */       row.add("summary");
/* 73 */       row.add(String.valueOf(stat.getLevel()));
/* 74 */       row.add(stat.getMessage());
/* 75 */       table.add(row);
/* 76 */       return TelnetUtils.toTable(header, table);
/* 77 */     }if (message.length() > 0) {
/* 78 */       return "Unsupported parameter " + message + " for status.";
/*    */     }
/* 80 */     String status = channel.getUrl().getParameter("status");
/* 81 */     Map statuses = new HashMap();
/* 82 */     if ((status != null) && (status.length() > 0)) {
/* 83 */       String[] ss = Constants.COMMA_SPLIT_PATTERN.split(status);
/* 84 */       for (String s : ss) { StatusChecker handler = (StatusChecker)this.extensionLoader.getExtension(s);
/*    */         Status stat;
/*    */         try {
/* 88 */           stat = handler.check();
/*    */         } catch (Throwable t) {
/* 90 */           stat = new Status(Status.Level.ERROR, t.getMessage());
/*    */         }
/* 92 */         statuses.put(s, stat);
/*    */       }
/*    */     }
/* 95 */     Status stat = StatusUtils.getSummaryStatus(statuses);
/* 96 */     return String.valueOf(stat.getLevel());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.telnet.support.command.StatusTelnetHandler
 * JD-Core Version:    0.6.2
 */