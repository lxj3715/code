/*    */ package com.alibaba.dubbo.remoting.transport;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ 
/*    */ public abstract class AbstractChannel extends AbstractPeer
/*    */   implements Channel
/*    */ {
/*    */   public AbstractChannel(URL url, ChannelHandler handler)
/*    */   {
/* 31 */     super(url, handler);
/*    */   }
/*    */ 
/*    */   public void send(Object message, boolean sent) throws RemotingException {
/* 35 */     if (isClosed())
/* 36 */       throw new RemotingException(this, "Failed to send message " + (message == null ? "" : message.getClass().getName()) + ":" + message + ", cause: Channel closed. channel: " + getLocalAddress() + " -> " + getRemoteAddress());
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 44 */     return getLocalAddress() + " -> " + getRemoteAddress();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.AbstractChannel
 * JD-Core Version:    0.6.2
 */