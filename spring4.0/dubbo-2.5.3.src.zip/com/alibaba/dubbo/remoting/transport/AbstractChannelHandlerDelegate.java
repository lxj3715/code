/*    */ package com.alibaba.dubbo.remoting.transport;
/*    */ 
/*    */ import com.alibaba.dubbo.common.utils.Assert;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ 
/*    */ public abstract class AbstractChannelHandlerDelegate
/*    */   implements ChannelHandlerDelegate
/*    */ {
/*    */   protected ChannelHandler handler;
/*    */ 
/*    */   protected AbstractChannelHandlerDelegate(ChannelHandler handler)
/*    */   {
/* 16 */     Assert.notNull(handler, "handler == null");
/* 17 */     this.handler = handler;
/*    */   }
/*    */ 
/*    */   public ChannelHandler getHandler() {
/* 21 */     if ((this.handler instanceof ChannelHandlerDelegate)) {
/* 22 */       return ((ChannelHandlerDelegate)this.handler).getHandler();
/*    */     }
/* 24 */     return this.handler;
/*    */   }
/*    */ 
/*    */   public void connected(Channel channel) throws RemotingException {
/* 28 */     this.handler.connected(channel);
/*    */   }
/*    */ 
/*    */   public void disconnected(Channel channel) throws RemotingException {
/* 32 */     this.handler.disconnected(channel);
/*    */   }
/*    */ 
/*    */   public void sent(Channel channel, Object message) throws RemotingException {
/* 36 */     this.handler.sent(channel, message);
/*    */   }
/*    */ 
/*    */   public void received(Channel channel, Object message) throws RemotingException {
/* 40 */     this.handler.received(channel, message);
/*    */   }
/*    */ 
/*    */   public void caught(Channel channel, Throwable exception) throws RemotingException {
/* 44 */     this.handler.caught(channel, exception);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.AbstractChannelHandlerDelegate
 * JD-Core Version:    0.6.2
 */