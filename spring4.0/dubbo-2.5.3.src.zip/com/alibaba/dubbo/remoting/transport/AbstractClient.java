/*     */ package com.alibaba.dubbo.remoting.transport;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.store.DataStore;
/*     */ import com.alibaba.dubbo.common.utils.ExecutorUtil;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.Client;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelHandlers;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public abstract class AbstractClient extends AbstractEndpoint
/*     */   implements Client
/*     */ {
/*  53 */   private static final Logger logger = LoggerFactory.getLogger(AbstractClient.class);
/*     */   protected static final String CLIENT_THREAD_POOL_NAME = "DubboClientHandler";
/*  57 */   private static final AtomicInteger CLIENT_THREAD_POOL_ID = new AtomicInteger();
/*     */ 
/*  59 */   private final Lock connectLock = new ReentrantLock();
/*     */ 
/*  61 */   private static final ScheduledThreadPoolExecutor reconnectExecutorService = new ScheduledThreadPoolExecutor(2, new NamedThreadFactory("DubboClientReconnectTimer", true));
/*     */ 
/*  63 */   private volatile ScheduledFuture<?> reconnectExecutorFuture = null;
/*     */   protected volatile ExecutorService executor;
/*     */   private final boolean send_reconnect;
/*  69 */   private final AtomicInteger reconnect_count = new AtomicInteger(0);
/*     */ 
/*  72 */   private final AtomicBoolean reconnect_error_log_flag = new AtomicBoolean(false);
/*     */   private final int reconnect_warning_period;
/*  78 */   private long lastConnectedTime = System.currentTimeMillis();
/*     */   private final long shutdown_timeout;
/*     */ 
/*     */   public AbstractClient(URL url, ChannelHandler handler)
/*     */     throws RemotingException
/*     */   {
/*  84 */     super(url, handler);
/*     */ 
/*  86 */     this.send_reconnect = url.getParameter("send.reconnect", false);
/*     */ 
/*  88 */     this.shutdown_timeout = url.getParameter("shutdown.timeout", 900000);
/*     */ 
/*  91 */     this.reconnect_warning_period = url.getParameter("reconnect.waring.period", 1800);
/*     */     try
/*     */     {
/*  94 */       doOpen();
/*     */     } catch (Throwable t) {
/*  96 */       close();
/*  97 */       throw new RemotingException(url.toInetSocketAddress(), null, "Failed to start " + getClass().getSimpleName() + " " + NetUtils.getLocalAddress() + " connect to the server " + getRemoteAddress() + ", cause: " + t.getMessage(), t);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 103 */       connect();
/* 104 */       if (logger.isInfoEnabled())
/* 105 */         logger.info("Start " + getClass().getSimpleName() + " " + NetUtils.getLocalAddress() + " connect to the server " + getRemoteAddress());
/*     */     }
/*     */     catch (RemotingException t) {
/* 108 */       if (url.getParameter("check", true)) {
/* 109 */         close();
/* 110 */         throw t;
/*     */       }
/* 112 */       logger.error("Failed to start " + getClass().getSimpleName() + " " + NetUtils.getLocalAddress() + " connect to the server " + getRemoteAddress() + " (check == false, ignore and retry later!), cause: " + t.getMessage(), t);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 116 */       close();
/* 117 */       throw new RemotingException(url.toInetSocketAddress(), null, "Failed to start " + getClass().getSimpleName() + " " + NetUtils.getLocalAddress() + " connect to the server " + getRemoteAddress() + ", cause: " + t.getMessage(), t);
/*     */     }
/*     */ 
/* 122 */     this.executor = ((ExecutorService)((DataStore)ExtensionLoader.getExtensionLoader(DataStore.class).getDefaultExtension()).get("consumer", Integer.toString(url.getPort())));
/*     */ 
/* 124 */     ((DataStore)ExtensionLoader.getExtensionLoader(DataStore.class).getDefaultExtension()).remove("consumer", Integer.toString(url.getPort()));
/*     */   }
/*     */ 
/*     */   protected static ChannelHandler wrapChannelHandler(URL url, ChannelHandler handler)
/*     */   {
/* 129 */     url = ExecutorUtil.setThreadName(url, "DubboClientHandler");
/* 130 */     url = url.addParameterIfAbsent("threadpool", "cached");
/* 131 */     return ChannelHandlers.wrap(handler, url);
/*     */   }
/*     */ 
/*     */   private synchronized void initConnectStatusCheckCommand()
/*     */   {
/* 139 */     int reconnect = getReconnectParam(getUrl());
/* 140 */     if ((reconnect > 0) && ((this.reconnectExecutorFuture == null) || (this.reconnectExecutorFuture.isCancelled()))) {
/* 141 */       Runnable connectStatusCheckCommand = new Runnable() {
/*     */         public void run() {
/*     */           try {
/* 144 */             if (!AbstractClient.this.isConnected())
/* 145 */               AbstractClient.this.connect();
/*     */             else
/* 147 */               AbstractClient.this.lastConnectedTime = System.currentTimeMillis();
/*     */           }
/*     */           catch (Throwable t) {
/* 150 */             String errorMsg = "client reconnect to " + AbstractClient.this.getUrl().getAddress() + " find error . url: " + AbstractClient.this.getUrl();
/*     */ 
/* 152 */             if ((System.currentTimeMillis() - AbstractClient.this.lastConnectedTime > AbstractClient.this.shutdown_timeout) && 
/* 153 */               (!AbstractClient.this.reconnect_error_log_flag.get())) {
/* 154 */               AbstractClient.this.reconnect_error_log_flag.set(true);
/* 155 */               AbstractClient.logger.error(errorMsg, t);
/* 156 */               return;
/*     */             }
/*     */ 
/* 159 */             if (AbstractClient.this.reconnect_count.getAndIncrement() % AbstractClient.this.reconnect_warning_period == 0)
/* 160 */               AbstractClient.logger.warn(errorMsg, t);
/*     */           }
/*     */         }
/*     */       };
/* 165 */       this.reconnectExecutorFuture = reconnectExecutorService.scheduleWithFixedDelay(connectStatusCheckCommand, reconnect, reconnect, TimeUnit.MILLISECONDS);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static int getReconnectParam(URL url)
/*     */   {
/* 175 */     String param = url.getParameter("reconnect");
/*     */     int reconnect;
/*     */     int reconnect;
/* 176 */     if ((param == null) || (param.length() == 0) || ("true".equalsIgnoreCase(param))) {
/* 177 */       reconnect = 2000;
/*     */     }
/*     */     else
/*     */     {
/*     */       int reconnect;
/* 178 */       if ("false".equalsIgnoreCase(param)) {
/* 179 */         reconnect = 0;
/*     */       } else {
/*     */         try {
/* 182 */           reconnect = Integer.parseInt(param);
/*     */         } catch (Exception e) {
/* 184 */           throw new IllegalArgumentException("reconnect param must be nonnegative integer or false/true. input is:" + param);
/*     */         }
/* 186 */         if (reconnect < 0)
/* 187 */           throw new IllegalArgumentException("reconnect param must be nonnegative integer or false/true. input is:" + param);
/*     */       }
/*     */     }
/* 190 */     return reconnect;
/*     */   }
/*     */ 
/*     */   private synchronized void destroyConnectStatusCheckCommand() {
/*     */     try {
/* 195 */       if ((this.reconnectExecutorFuture != null) && (!this.reconnectExecutorFuture.isDone())) {
/* 196 */         this.reconnectExecutorFuture.cancel(true);
/* 197 */         reconnectExecutorService.purge();
/*     */       }
/*     */     } catch (Throwable e) {
/* 200 */       logger.warn(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ExecutorService createExecutor() {
/* 205 */     return Executors.newCachedThreadPool(new NamedThreadFactory("DubboClientHandler" + CLIENT_THREAD_POOL_ID.incrementAndGet() + "-" + getUrl().getAddress(), true));
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getConnectAddress() {
/* 209 */     return new InetSocketAddress(NetUtils.filterLocalHost(getUrl().getHost()), getUrl().getPort());
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getRemoteAddress() {
/* 213 */     Channel channel = getChannel();
/* 214 */     if (channel == null)
/* 215 */       return getUrl().toInetSocketAddress();
/* 216 */     return channel.getRemoteAddress();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/* 220 */     Channel channel = getChannel();
/* 221 */     if (channel == null)
/* 222 */       return InetSocketAddress.createUnresolved(NetUtils.getLocalHost(), 0);
/* 223 */     return channel.getLocalAddress();
/*     */   }
/*     */ 
/*     */   public boolean isConnected() {
/* 227 */     Channel channel = getChannel();
/* 228 */     if (channel == null)
/* 229 */       return false;
/* 230 */     return channel.isConnected();
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String key) {
/* 234 */     Channel channel = getChannel();
/* 235 */     if (channel == null)
/* 236 */       return null;
/* 237 */     return channel.getAttribute(key);
/*     */   }
/*     */ 
/*     */   public void setAttribute(String key, Object value) {
/* 241 */     Channel channel = getChannel();
/* 242 */     if (channel == null)
/* 243 */       return;
/* 244 */     channel.setAttribute(key, value);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String key) {
/* 248 */     Channel channel = getChannel();
/* 249 */     if (channel == null)
/* 250 */       return;
/* 251 */     channel.removeAttribute(key);
/*     */   }
/*     */ 
/*     */   public boolean hasAttribute(String key) {
/* 255 */     Channel channel = getChannel();
/* 256 */     if (channel == null)
/* 257 */       return false;
/* 258 */     return channel.hasAttribute(key);
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/* 262 */     if ((this.send_reconnect) && (!isConnected())) {
/* 263 */       connect();
/*     */     }
/* 265 */     Channel channel = getChannel();
/*     */ 
/* 267 */     if ((channel == null) || (!channel.isConnected())) {
/* 268 */       throw new RemotingException(this, "message can not send, because channel is closed . url:" + getUrl());
/*     */     }
/* 270 */     channel.send(message, sent);
/*     */   }
/*     */ 
/*     */   protected void connect() throws RemotingException {
/* 274 */     this.connectLock.lock();
/*     */     try {
/* 276 */       if (isConnected()) {
/*     */         return;
/*     */       }
/* 279 */       initConnectStatusCheckCommand();
/* 280 */       doConnect();
/* 281 */       if (!isConnected()) {
/* 282 */         throw new RemotingException(this, "Failed connect to server " + getRemoteAddress() + " from " + getClass().getSimpleName() + " " + NetUtils.getLocalHost() + " using dubbo version " + Version.getVersion() + ", cause: Connect wait timeout: " + getTimeout() + "ms.");
/*     */       }
/*     */ 
/* 286 */       if (logger.isInfoEnabled()) {
/* 287 */         logger.info("Successed connect to server " + getRemoteAddress() + " from " + getClass().getSimpleName() + " " + NetUtils.getLocalHost() + " using dubbo version " + Version.getVersion() + ", channel is " + getChannel());
/*     */       }
/*     */ 
/* 292 */       this.reconnect_count.set(0);
/* 293 */       this.reconnect_error_log_flag.set(false);
/*     */     } catch (RemotingException e) {
/* 295 */       throw e;
/*     */     } catch (Throwable e) {
/* 297 */       throw new RemotingException(this, "Failed connect to server " + getRemoteAddress() + " from " + getClass().getSimpleName() + " " + NetUtils.getLocalHost() + " using dubbo version " + Version.getVersion() + ", cause: " + e.getMessage(), e);
/*     */     }
/*     */     finally
/*     */     {
/* 301 */       this.connectLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void disconnect() {
/* 306 */     this.connectLock.lock();
/*     */     try {
/* 308 */       destroyConnectStatusCheckCommand();
/*     */       try {
/* 310 */         Channel channel = getChannel();
/* 311 */         if (channel != null)
/* 312 */           channel.close();
/*     */       }
/*     */       catch (Throwable e) {
/* 315 */         logger.warn(e.getMessage(), e);
/*     */       }
/*     */       try {
/* 318 */         doDisConnect();
/*     */       } catch (Throwable e) {
/* 320 */         logger.warn(e.getMessage(), e);
/*     */       }
/*     */     } finally {
/* 323 */       this.connectLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reconnect() throws RemotingException {
/* 328 */     disconnect();
/* 329 */     connect();
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */     try {
/* 334 */       if (this.executor != null)
/* 335 */         ExecutorUtil.shutdownNow(this.executor, 100);
/*     */     }
/*     */     catch (Throwable e) {
/* 338 */       logger.warn(e.getMessage(), e);
/*     */     }
/*     */     try {
/* 341 */       super.close();
/*     */     } catch (Throwable e) {
/* 343 */       logger.warn(e.getMessage(), e);
/*     */     }
/*     */     try {
/* 346 */       disconnect();
/*     */     } catch (Throwable e) {
/* 348 */       logger.warn(e.getMessage(), e);
/*     */     }
/*     */     try {
/* 351 */       doClose();
/*     */     } catch (Throwable e) {
/* 353 */       logger.warn(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close(int timeout) {
/* 358 */     ExecutorUtil.gracefulShutdown(this.executor, timeout);
/* 359 */     close();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 364 */     return getClass().getName() + " [" + getLocalAddress() + " -> " + getRemoteAddress() + "]";
/*     */   }
/*     */ 
/*     */   protected abstract void doOpen()
/*     */     throws Throwable;
/*     */ 
/*     */   protected abstract void doClose()
/*     */     throws Throwable;
/*     */ 
/*     */   protected abstract void doConnect()
/*     */     throws Throwable;
/*     */ 
/*     */   protected abstract void doDisConnect()
/*     */     throws Throwable;
/*     */ 
/*     */   protected abstract Channel getChannel();
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.AbstractClient
 * JD-Core Version:    0.6.2
 */