/*    */ package com.alibaba.dubbo.remoting.transport;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.common.serialize.Serialization;
/*    */ import com.alibaba.dubbo.common.utils.NetUtils;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.Codec2;
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ public abstract class AbstractCodec
/*    */   implements Codec2
/*    */ {
/* 37 */   private static final Logger logger = LoggerFactory.getLogger(AbstractCodec.class);
/*    */ 
/*    */   protected Serialization getSerialization(Channel channel) {
/* 40 */     return CodecSupport.getSerialization(channel.getUrl());
/*    */   }
/*    */ 
/*    */   protected static void checkPayload(Channel channel, long size) throws IOException {
/* 44 */     int payload = 8388608;
/* 45 */     if ((channel != null) && (channel.getUrl() != null)) {
/* 46 */       payload = channel.getUrl().getParameter("payload", 8388608);
/*    */     }
/* 48 */     if ((payload > 0) && (size > payload)) {
/* 49 */       IOException e = new IOException("Data length too large: " + size + ", max payload: " + payload + ", channel: " + channel);
/* 50 */       logger.error(e);
/* 51 */       throw e;
/*    */     }
/*    */   }
/*    */ 
/*    */   protected boolean isClientSide(Channel channel) {
/* 56 */     String side = (String)channel.getAttribute("side");
/* 57 */     if ("client".equals(side))
/* 58 */       return true;
/* 59 */     if ("server".equals(side)) {
/* 60 */       return false;
/*    */     }
/* 62 */     InetSocketAddress address = channel.getRemoteAddress();
/* 63 */     URL url = channel.getUrl();
/* 64 */     boolean client = (url.getPort() == address.getPort()) && (NetUtils.filterLocalHost(url.getIp()).equals(NetUtils.filterLocalHost(address.getAddress().getHostAddress())));
/*    */ 
/* 68 */     channel.setAttribute("side", client ? "client" : "server");
/*    */ 
/* 70 */     return client;
/*    */   }
/*    */ 
/*    */   protected boolean isServerSide(Channel channel)
/*    */   {
/* 75 */     return !isClientSide(channel);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.AbstractCodec
 * JD-Core Version:    0.6.2
 */