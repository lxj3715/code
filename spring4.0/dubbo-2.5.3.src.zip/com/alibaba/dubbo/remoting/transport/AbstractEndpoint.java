/*     */ package com.alibaba.dubbo.remoting.transport;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Parameters;
/*     */ import com.alibaba.dubbo.common.Resetable;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.Codec;
/*     */ import com.alibaba.dubbo.remoting.Codec2;
/*     */ import com.alibaba.dubbo.remoting.transport.codec.CodecAdapter;
/*     */ 
/*     */ public abstract class AbstractEndpoint extends AbstractPeer
/*     */   implements Resetable
/*     */ {
/*  36 */   private static final Logger logger = LoggerFactory.getLogger(AbstractEndpoint.class);
/*     */   private Codec2 codec;
/*     */   private int timeout;
/*     */   private int connectTimeout;
/*     */ 
/*     */   public AbstractEndpoint(URL url, ChannelHandler handler)
/*     */   {
/*  45 */     super(url, handler);
/*  46 */     this.codec = getChannelCodec(url);
/*  47 */     this.timeout = url.getPositiveParameter("timeout", 1000);
/*  48 */     this.connectTimeout = url.getPositiveParameter("connect.timeout", 3000);
/*     */   }
/*     */ 
/*     */   public void reset(URL url) {
/*  52 */     if (isClosed()) {
/*  53 */       throw new IllegalStateException("Failed to reset parameters " + url + ", cause: Channel closed. channel: " + getLocalAddress());
/*     */     }
/*     */     try
/*     */     {
/*  57 */       if (url.hasParameter("heartbeat")) {
/*  58 */         int t = url.getParameter("timeout", 0);
/*  59 */         if (t > 0)
/*  60 */           this.timeout = t;
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/*  64 */       logger.error(t.getMessage(), t);
/*     */     }
/*     */     try {
/*  67 */       if (url.hasParameter("connect.timeout")) {
/*  68 */         int t = url.getParameter("connect.timeout", 0);
/*  69 */         if (t > 0)
/*  70 */           this.connectTimeout = t;
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/*  74 */       logger.error(t.getMessage(), t);
/*     */     }
/*     */     try {
/*  77 */       if (url.hasParameter("codec"))
/*  78 */         this.codec = getChannelCodec(url);
/*     */     }
/*     */     catch (Throwable t) {
/*  81 */       logger.error(t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void reset(Parameters parameters) {
/*  87 */     reset(getUrl().addParameters(parameters.getParameters()));
/*     */   }
/*     */ 
/*     */   protected Codec2 getCodec() {
/*  91 */     return this.codec;
/*     */   }
/*     */ 
/*     */   protected int getTimeout() {
/*  95 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   protected int getConnectTimeout() {
/*  99 */     return this.connectTimeout;
/*     */   }
/*     */ 
/*     */   protected static Codec2 getChannelCodec(URL url) {
/* 103 */     String codecName = url.getParameter("codec", "telnet");
/* 104 */     if (ExtensionLoader.getExtensionLoader(Codec2.class).hasExtension(codecName)) {
/* 105 */       return (Codec2)ExtensionLoader.getExtensionLoader(Codec2.class).getExtension(codecName);
/*     */     }
/* 107 */     return new CodecAdapter((Codec)ExtensionLoader.getExtensionLoader(Codec.class).getExtension(codecName));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.AbstractEndpoint
 * JD-Core Version:    0.6.2
 */