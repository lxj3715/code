/*     */ package com.alibaba.dubbo.remoting.transport;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.Endpoint;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ 
/*     */ public abstract class AbstractPeer
/*     */   implements Endpoint, ChannelHandler
/*     */ {
/*     */   private final ChannelHandler handler;
/*     */   private volatile URL url;
/*     */   private volatile boolean closed;
/*     */ 
/*     */   public AbstractPeer(URL url, ChannelHandler handler)
/*     */   {
/*  40 */     if (url == null) {
/*  41 */       throw new IllegalArgumentException("url == null");
/*     */     }
/*  43 */     if (handler == null) {
/*  44 */       throw new IllegalArgumentException("handler == null");
/*     */     }
/*  46 */     this.url = url;
/*  47 */     this.handler = handler;
/*     */   }
/*     */ 
/*     */   public void send(Object message) throws RemotingException {
/*  51 */     send(message, this.url.getParameter("sent", false));
/*     */   }
/*     */ 
/*     */   public void close() {
/*  55 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   public void close(int timeout) {
/*  59 */     close();
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  63 */     return this.url;
/*     */   }
/*     */ 
/*     */   protected void setUrl(URL url) {
/*  67 */     if (url == null) {
/*  68 */       throw new IllegalArgumentException("url == null");
/*     */     }
/*  70 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public ChannelHandler getChannelHandler() {
/*  74 */     if ((this.handler instanceof ChannelHandlerDelegate)) {
/*  75 */       return ((ChannelHandlerDelegate)this.handler).getHandler();
/*     */     }
/*  77 */     return this.handler;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ChannelHandler getHandler()
/*     */   {
/*  86 */     return getDelegateHandler();
/*     */   }
/*     */ 
/*     */   public ChannelHandler getDelegateHandler()
/*     */   {
/*  94 */     return this.handler;
/*     */   }
/*     */ 
/*     */   public boolean isClosed() {
/*  98 */     return this.closed;
/*     */   }
/*     */ 
/*     */   public void connected(Channel ch) throws RemotingException {
/* 102 */     if (this.closed) {
/* 103 */       return;
/*     */     }
/* 105 */     this.handler.connected(ch);
/*     */   }
/*     */ 
/*     */   public void disconnected(Channel ch) throws RemotingException {
/* 109 */     this.handler.disconnected(ch);
/*     */   }
/*     */ 
/*     */   public void sent(Channel ch, Object msg) throws RemotingException {
/* 113 */     if (this.closed) {
/* 114 */       return;
/*     */     }
/* 116 */     this.handler.sent(ch, msg);
/*     */   }
/*     */ 
/*     */   public void received(Channel ch, Object msg) throws RemotingException {
/* 120 */     if (this.closed) {
/* 121 */       return;
/*     */     }
/* 123 */     this.handler.received(ch, msg);
/*     */   }
/*     */ 
/*     */   public void caught(Channel ch, Throwable ex) throws RemotingException {
/* 127 */     this.handler.caught(ch, ex);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.AbstractPeer
 * JD-Core Version:    0.6.2
 */