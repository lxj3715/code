/*     */ package com.alibaba.dubbo.remoting.transport;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ExecutorUtil;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.Server;
/*     */ import com.alibaba.dubbo.remoting.transport.dispatcher.WrappedChannelHandler;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ 
/*     */ public abstract class AbstractServer extends AbstractEndpoint
/*     */   implements Server
/*     */ {
/*  43 */   private static final Logger logger = LoggerFactory.getLogger(AbstractServer.class);
/*     */   private InetSocketAddress localAddress;
/*     */   private InetSocketAddress bindAddress;
/*     */   private int accepts;
/*  51 */   private int idleTimeout = 600;
/*     */   protected static final String SERVER_THREAD_POOL_NAME = "DubboServerHandler";
/*     */   ExecutorService executor;
/*     */ 
/*     */   public AbstractServer(URL url, ChannelHandler handler)
/*     */     throws RemotingException
/*     */   {
/*  58 */     super(url, handler);
/*  59 */     this.localAddress = getUrl().toInetSocketAddress();
/*  60 */     String host = (url.getParameter("anyhost", false)) || (NetUtils.isInvalidLocalHost(getUrl().getHost())) ? "0.0.0.0" : getUrl().getHost();
/*     */ 
/*  63 */     this.bindAddress = new InetSocketAddress(host, getUrl().getPort());
/*  64 */     this.accepts = url.getParameter("accepts", 0);
/*  65 */     this.idleTimeout = url.getParameter("idle.timeout", 600000);
/*     */     try {
/*  67 */       doOpen();
/*  68 */       if (logger.isInfoEnabled())
/*  69 */         logger.info("Start " + getClass().getSimpleName() + " bind " + getBindAddress() + ", export " + getLocalAddress());
/*     */     }
/*     */     catch (Throwable t) {
/*  72 */       throw new RemotingException(url.toInetSocketAddress(), null, "Failed to bind " + getClass().getSimpleName() + " on " + getLocalAddress() + ", cause: " + t.getMessage(), t);
/*     */     }
/*     */ 
/*  75 */     if ((handler instanceof WrappedChannelHandler))
/*  76 */       this.executor = ((WrappedChannelHandler)handler).getExecutor();
/*     */   }
/*     */ 
/*     */   protected abstract void doOpen() throws Throwable;
/*     */ 
/*     */   protected abstract void doClose() throws Throwable;
/*     */ 
/*     */   public void reset(URL url)
/*     */   {
/*  85 */     if (url == null)
/*  86 */       return;
/*     */     try
/*     */     {
/*  89 */       if (url.hasParameter("accepts")) {
/*  90 */         int a = url.getParameter("accepts", 0);
/*  91 */         if (a > 0)
/*  92 */           this.accepts = a;
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/*  96 */       logger.error(t.getMessage(), t);
/*     */     }
/*     */     try {
/*  99 */       if (url.hasParameter("idle.timeout")) {
/* 100 */         int t = url.getParameter("idle.timeout", 0);
/* 101 */         if (t > 0)
/* 102 */           this.idleTimeout = t;
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/* 106 */       logger.error(t.getMessage(), t);
/*     */     }
/*     */     try {
/* 109 */       if ((url.hasParameter("threads")) && ((this.executor instanceof ThreadPoolExecutor)) && (!this.executor.isShutdown()))
/*     */       {
/* 111 */         ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor)this.executor;
/* 112 */         int threads = url.getParameter("threads", 0);
/* 113 */         int max = threadPoolExecutor.getMaximumPoolSize();
/* 114 */         int core = threadPoolExecutor.getCorePoolSize();
/* 115 */         if ((threads > 0) && ((threads != max) || (threads != core)))
/* 116 */           if (threads < core) {
/* 117 */             threadPoolExecutor.setCorePoolSize(threads);
/* 118 */             if (core == max)
/* 119 */               threadPoolExecutor.setMaximumPoolSize(threads);
/*     */           }
/*     */           else {
/* 122 */             threadPoolExecutor.setMaximumPoolSize(threads);
/* 123 */             if (core == max)
/* 124 */               threadPoolExecutor.setCorePoolSize(threads);
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 130 */       logger.error(t.getMessage(), t);
/*     */     }
/* 132 */     super.setUrl(getUrl().addParameters(url.getParameters()));
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/* 136 */     Collection channels = getChannels();
/* 137 */     for (Channel channel : channels)
/* 138 */       if (channel.isConnected())
/* 139 */         channel.send(message, sent);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 145 */     if (logger.isInfoEnabled()) {
/* 146 */       logger.info("Close " + getClass().getSimpleName() + " bind " + getBindAddress() + ", export " + getLocalAddress());
/*     */     }
/* 148 */     ExecutorUtil.shutdownNow(this.executor, 100);
/*     */     try {
/* 150 */       super.close();
/*     */     } catch (Throwable e) {
/* 152 */       logger.warn(e.getMessage(), e);
/*     */     }
/*     */     try {
/* 155 */       doClose();
/*     */     } catch (Throwable e) {
/* 157 */       logger.warn(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close(int timeout) {
/* 162 */     ExecutorUtil.gracefulShutdown(this.executor, timeout);
/* 163 */     close();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/* 167 */     return this.localAddress;
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getBindAddress() {
/* 171 */     return this.bindAddress;
/*     */   }
/*     */ 
/*     */   public int getAccepts() {
/* 175 */     return this.accepts;
/*     */   }
/*     */ 
/*     */   public int getIdleTimeout() {
/* 179 */     return this.idleTimeout;
/*     */   }
/*     */ 
/*     */   public void connected(Channel ch) throws RemotingException
/*     */   {
/* 184 */     Collection channels = getChannels();
/* 185 */     if ((this.accepts > 0) && (channels.size() > this.accepts)) {
/* 186 */       logger.error("Close channel " + ch + ", cause: The server " + ch.getLocalAddress() + " connections greater than max config " + this.accepts);
/* 187 */       ch.close();
/* 188 */       return;
/*     */     }
/* 190 */     super.connected(ch);
/*     */   }
/*     */ 
/*     */   public void disconnected(Channel ch) throws RemotingException
/*     */   {
/* 195 */     Collection channels = getChannels();
/* 196 */     if (channels.size() == 0) {
/* 197 */       logger.warn("All clients has discontected from " + ch.getLocalAddress() + ". You can graceful shutdown now.");
/*     */     }
/* 199 */     super.disconnected(ch);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.AbstractServer
 * JD-Core Version:    0.6.2
 */