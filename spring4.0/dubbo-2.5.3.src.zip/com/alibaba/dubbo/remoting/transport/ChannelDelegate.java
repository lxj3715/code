/*     */ package com.alibaba.dubbo.remoting.transport;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import java.net.InetSocketAddress;
/*     */ 
/*     */ public class ChannelDelegate
/*     */   implements Channel
/*     */ {
/*     */   private transient Channel channel;
/*     */ 
/*     */   public ChannelDelegate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ChannelDelegate(Channel channel)
/*     */   {
/*  38 */     setChannel(channel);
/*     */   }
/*     */ 
/*     */   public Channel getChannel() {
/*  42 */     return this.channel;
/*     */   }
/*     */ 
/*     */   public void setChannel(Channel channel) {
/*  46 */     if (channel == null) {
/*  47 */       throw new IllegalArgumentException("channel == null");
/*     */     }
/*  49 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  53 */     return this.channel.getUrl();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getRemoteAddress() {
/*  57 */     return this.channel.getRemoteAddress();
/*     */   }
/*     */ 
/*     */   public ChannelHandler getChannelHandler() {
/*  61 */     return this.channel.getChannelHandler();
/*     */   }
/*     */ 
/*     */   public boolean isConnected() {
/*  65 */     return this.channel.isConnected();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/*  69 */     return this.channel.getLocalAddress();
/*     */   }
/*     */ 
/*     */   public boolean hasAttribute(String key) {
/*  73 */     return this.channel.hasAttribute(key);
/*     */   }
/*     */ 
/*     */   public void send(Object message) throws RemotingException {
/*  77 */     this.channel.send(message);
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String key) {
/*  81 */     return this.channel.getAttribute(key);
/*     */   }
/*     */ 
/*     */   public void setAttribute(String key, Object value) {
/*  85 */     this.channel.setAttribute(key, value);
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/*  89 */     this.channel.send(message, sent);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String key) {
/*  93 */     this.channel.removeAttribute(key);
/*     */   }
/*     */ 
/*     */   public void close() {
/*  97 */     this.channel.close();
/*     */   }
/*     */   public void close(int timeout) {
/* 100 */     this.channel.close(timeout);
/*     */   }
/*     */ 
/*     */   public boolean isClosed() {
/* 104 */     return this.channel.isClosed();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.ChannelDelegate
 * JD-Core Version:    0.6.2
 */