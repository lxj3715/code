package com.alibaba.dubbo.remoting.transport;

import com.alibaba.dubbo.remoting.Channel;
import com.alibaba.dubbo.remoting.ChannelHandler;
import com.alibaba.dubbo.remoting.RemotingException;

public class ChannelHandlerAdapter
  implements ChannelHandler
{
  public void connected(Channel channel)
    throws RemotingException
  {
  }

  public void disconnected(Channel channel)
    throws RemotingException
  {
  }

  public void sent(Channel channel, Object message)
    throws RemotingException
  {
  }

  public void received(Channel channel, Object message)
    throws RemotingException
  {
  }

  public void caught(Channel channel, Throwable exception)
    throws RemotingException
  {
  }
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.ChannelHandlerAdapter
 * JD-Core Version:    0.6.2
 */