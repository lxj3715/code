package com.alibaba.dubbo.remoting.transport;

import com.alibaba.dubbo.remoting.ChannelHandler;

public abstract interface ChannelHandlerDelegate extends ChannelHandler
{
  public abstract ChannelHandler getHandler();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.ChannelHandlerDelegate
 * JD-Core Version:    0.6.2
 */