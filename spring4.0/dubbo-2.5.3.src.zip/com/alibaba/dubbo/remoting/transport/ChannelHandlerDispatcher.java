/*     */ package com.alibaba.dubbo.remoting.transport;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ 
/*     */ public class ChannelHandlerDispatcher
/*     */   implements ChannelHandler
/*     */ {
/*  34 */   private static final Logger logger = LoggerFactory.getLogger(ChannelHandlerDispatcher.class);
/*     */ 
/*  36 */   private final Collection<ChannelHandler> channelHandlers = new CopyOnWriteArraySet();
/*     */ 
/*     */   public ChannelHandlerDispatcher() {
/*     */   }
/*     */ 
/*     */   public ChannelHandlerDispatcher(ChannelHandler[] handlers) {
/*  42 */     this(handlers == null ? null : Arrays.asList(handlers));
/*     */   }
/*     */ 
/*     */   public ChannelHandlerDispatcher(Collection<ChannelHandler> handlers) {
/*  46 */     if ((handlers != null) && (handlers.size() > 0))
/*  47 */       this.channelHandlers.addAll(handlers);
/*     */   }
/*     */ 
/*     */   public Collection<ChannelHandler> getChannelHandlers()
/*     */   {
/*  52 */     return this.channelHandlers;
/*     */   }
/*     */ 
/*     */   public ChannelHandlerDispatcher addChannelHandler(ChannelHandler handler) {
/*  56 */     this.channelHandlers.add(handler);
/*  57 */     return this;
/*     */   }
/*     */ 
/*     */   public ChannelHandlerDispatcher removeChannelHandler(ChannelHandler handler) {
/*  61 */     this.channelHandlers.remove(handler);
/*  62 */     return this;
/*     */   }
/*     */ 
/*     */   public void connected(Channel channel) {
/*  66 */     for (ChannelHandler listener : this.channelHandlers)
/*     */       try {
/*  68 */         listener.connected(channel);
/*     */       } catch (Throwable t) {
/*  70 */         logger.error(t.getMessage(), t);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void disconnected(Channel channel)
/*     */   {
/*  76 */     for (ChannelHandler listener : this.channelHandlers)
/*     */       try {
/*  78 */         listener.disconnected(channel);
/*     */       } catch (Throwable t) {
/*  80 */         logger.error(t.getMessage(), t);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void sent(Channel channel, Object message)
/*     */   {
/*  86 */     for (ChannelHandler listener : this.channelHandlers)
/*     */       try {
/*  88 */         listener.sent(channel, message);
/*     */       } catch (Throwable t) {
/*  90 */         logger.error(t.getMessage(), t);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void received(Channel channel, Object message)
/*     */   {
/*  96 */     for (ChannelHandler listener : this.channelHandlers)
/*     */       try {
/*  98 */         listener.received(channel, message);
/*     */       } catch (Throwable t) {
/* 100 */         logger.error(t.getMessage(), t);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void caught(Channel channel, Throwable exception)
/*     */   {
/* 106 */     for (ChannelHandler listener : this.channelHandlers)
/*     */       try {
/* 108 */         listener.caught(channel, exception);
/*     */       } catch (Throwable t) {
/* 110 */         logger.error(t.getMessage(), t);
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.ChannelHandlerDispatcher
 * JD-Core Version:    0.6.2
 */