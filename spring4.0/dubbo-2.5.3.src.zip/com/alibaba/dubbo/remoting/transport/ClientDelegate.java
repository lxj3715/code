/*     */ package com.alibaba.dubbo.remoting.transport;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Parameters;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.Client;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import java.net.InetSocketAddress;
/*     */ 
/*     */ public class ClientDelegate
/*     */   implements Client
/*     */ {
/*     */   private transient Client client;
/*     */ 
/*     */   public ClientDelegate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ClientDelegate(Client client)
/*     */   {
/*  38 */     setClient(client);
/*     */   }
/*     */ 
/*     */   public Client getClient() {
/*  42 */     return this.client;
/*     */   }
/*     */ 
/*     */   public void setClient(Client client) {
/*  46 */     if (client == null) {
/*  47 */       throw new IllegalArgumentException("client == null");
/*     */     }
/*  49 */     this.client = client;
/*     */   }
/*     */ 
/*     */   public void reset(URL url) {
/*  53 */     this.client.reset(url);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void reset(Parameters parameters) {
/*  58 */     reset(getUrl().addParameters(parameters.getParameters()));
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  62 */     return this.client.getUrl();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getRemoteAddress() {
/*  66 */     return this.client.getRemoteAddress();
/*     */   }
/*     */ 
/*     */   public void reconnect() throws RemotingException {
/*  70 */     this.client.reconnect();
/*     */   }
/*     */ 
/*     */   public ChannelHandler getChannelHandler() {
/*  74 */     return this.client.getChannelHandler();
/*     */   }
/*     */ 
/*     */   public boolean isConnected() {
/*  78 */     return this.client.isConnected();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/*  82 */     return this.client.getLocalAddress();
/*     */   }
/*     */ 
/*     */   public boolean hasAttribute(String key) {
/*  86 */     return this.client.hasAttribute(key);
/*     */   }
/*     */ 
/*     */   public void send(Object message) throws RemotingException {
/*  90 */     this.client.send(message);
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String key) {
/*  94 */     return this.client.getAttribute(key);
/*     */   }
/*     */ 
/*     */   public void setAttribute(String key, Object value) {
/*  98 */     this.client.setAttribute(key, value);
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/* 102 */     this.client.send(message, sent);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String key) {
/* 106 */     this.client.removeAttribute(key);
/*     */   }
/*     */ 
/*     */   public void close() {
/* 110 */     this.client.close();
/*     */   }
/*     */   public void close(int timeout) {
/* 113 */     this.client.close(timeout);
/*     */   }
/*     */ 
/*     */   public boolean isClosed() {
/* 117 */     return this.client.isClosed();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.ClientDelegate
 * JD-Core Version:    0.6.2
 */