/*    */ package com.alibaba.dubbo.remoting.transport;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.common.serialize.Serialization;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class CodecSupport
/*    */ {
/* 35 */   private static final Logger logger = LoggerFactory.getLogger(CodecSupport.class);
/*    */ 
/* 40 */   private static Map<Byte, Serialization> ID_SERIALIZATION_MAP = new HashMap();
/*    */ 
/*    */   public static Serialization getSerializationById(Byte id)
/*    */   {
/* 59 */     return (Serialization)ID_SERIALIZATION_MAP.get(id);
/*    */   }
/*    */ 
/*    */   public static Serialization getSerialization(URL url) {
/* 63 */     return (Serialization)ExtensionLoader.getExtensionLoader(Serialization.class).getExtension(url.getParameter("serialization", "hessian2"));
/*    */   }
/*    */ 
/*    */   public static Serialization getSerialization(URL url, Byte id)
/*    */   {
/* 68 */     Serialization result = getSerializationById(id);
/* 69 */     if (result == null) {
/* 70 */       result = getSerialization(url);
/*    */     }
/* 72 */     return result;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 43 */     Set supportedExtensions = ExtensionLoader.getExtensionLoader(Serialization.class).getSupportedExtensions();
/* 44 */     for (String name : supportedExtensions) {
/* 45 */       Serialization serialization = (Serialization)ExtensionLoader.getExtensionLoader(Serialization.class).getExtension(name);
/* 46 */       byte idByte = serialization.getContentTypeId();
/* 47 */       if (ID_SERIALIZATION_MAP.containsKey(Byte.valueOf(idByte))) {
/* 48 */         logger.error("Serialization extension " + serialization.getClass().getName() + " has duplicate id to Serialization extension " + ((Serialization)ID_SERIALIZATION_MAP.get(Byte.valueOf(idByte))).getClass().getName() + ", ignore this Serialization extension");
/*    */       }
/*    */       else
/*    */       {
/* 54 */         ID_SERIALIZATION_MAP.put(Byte.valueOf(idByte), serialization);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.CodecSupport
 * JD-Core Version:    0.6.2
 */