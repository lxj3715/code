/*    */ package com.alibaba.dubbo.remoting.transport;
/*    */ 
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.Decodeable;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.exchange.Request;
/*    */ import com.alibaba.dubbo.remoting.exchange.Response;
/*    */ 
/*    */ public class DecodeHandler extends AbstractChannelHandlerDelegate
/*    */ {
/* 33 */   private static final Logger log = LoggerFactory.getLogger(DecodeHandler.class);
/*    */ 
/*    */   public DecodeHandler(ChannelHandler handler) {
/* 36 */     super(handler);
/*    */   }
/*    */ 
/*    */   public void received(Channel channel, Object message) throws RemotingException {
/* 40 */     if ((message instanceof Decodeable)) {
/* 41 */       decode(message);
/*    */     }
/*    */ 
/* 44 */     if ((message instanceof Request)) {
/* 45 */       decode(((Request)message).getData());
/*    */     }
/*    */ 
/* 48 */     if ((message instanceof Response)) {
/* 49 */       decode(((Response)message).getResult());
/*    */     }
/*    */ 
/* 52 */     this.handler.received(channel, message);
/*    */   }
/*    */ 
/*    */   private void decode(Object message) {
/* 56 */     if ((message != null) && ((message instanceof Decodeable)))
/*    */       try {
/* 58 */         ((Decodeable)message).decode();
/* 59 */         if (log.isDebugEnabled())
/* 60 */           log.debug(32 + "Decode decodeable message " + message.getClass().getName());
/*    */       }
/*    */       catch (Throwable e)
/*    */       {
/* 64 */         if (log.isWarnEnabled())
/* 65 */           log.warn(32 + "Call Decodeable.decode failed: " + e.getMessage(), e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.DecodeHandler
 * JD-Core Version:    0.6.2
 */