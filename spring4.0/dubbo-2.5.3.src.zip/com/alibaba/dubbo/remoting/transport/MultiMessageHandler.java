/*    */ package com.alibaba.dubbo.remoting.transport;
/*    */ 
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.exchange.support.MultiMessage;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class MultiMessageHandler extends AbstractChannelHandlerDelegate
/*    */ {
/*    */   public MultiMessageHandler(ChannelHandler handler)
/*    */   {
/* 16 */     super(handler);
/*    */   }
/*    */ 
/*    */   public void received(Channel channel, Object message)
/*    */     throws RemotingException
/*    */   {
/*    */     Iterator i$;
/* 22 */     if ((message instanceof MultiMessage)) {
/* 23 */       MultiMessage list = (MultiMessage)message;
/* 24 */       for (i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 25 */         this.handler.received(channel, obj); }
/*    */     }
/*    */     else {
/* 28 */       this.handler.received(channel, message);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.MultiMessageHandler
 * JD-Core Version:    0.6.2
 */