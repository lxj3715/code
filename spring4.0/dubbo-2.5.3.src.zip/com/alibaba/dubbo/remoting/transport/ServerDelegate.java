/*     */ package com.alibaba.dubbo.remoting.transport;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Parameters;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.Server;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public class ServerDelegate
/*     */   implements Server
/*     */ {
/*     */   private transient Server server;
/*     */ 
/*     */   public ServerDelegate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ServerDelegate(Server server)
/*     */   {
/*  40 */     setServer(server);
/*     */   }
/*     */ 
/*     */   public Server getServer() {
/*  44 */     return this.server;
/*     */   }
/*     */ 
/*     */   public void setServer(Server server) {
/*  48 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public boolean isBound() {
/*  52 */     return this.server.isBound();
/*     */   }
/*     */ 
/*     */   public void reset(URL url) {
/*  56 */     this.server.reset(url);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void reset(Parameters parameters) {
/*  61 */     reset(getUrl().addParameters(parameters.getParameters()));
/*     */   }
/*     */ 
/*     */   public Collection<Channel> getChannels() {
/*  65 */     return this.server.getChannels();
/*     */   }
/*     */ 
/*     */   public Channel getChannel(InetSocketAddress remoteAddress) {
/*  69 */     return this.server.getChannel(remoteAddress);
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  73 */     return this.server.getUrl();
/*     */   }
/*     */ 
/*     */   public ChannelHandler getChannelHandler() {
/*  77 */     return this.server.getChannelHandler();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress() {
/*  81 */     return this.server.getLocalAddress();
/*     */   }
/*     */ 
/*     */   public void send(Object message) throws RemotingException {
/*  85 */     this.server.send(message);
/*     */   }
/*     */ 
/*     */   public void send(Object message, boolean sent) throws RemotingException {
/*  89 */     this.server.send(message, sent);
/*     */   }
/*     */ 
/*     */   public void close() {
/*  93 */     this.server.close();
/*     */   }
/*     */ 
/*     */   public void close(int timeout) {
/*  97 */     this.server.close(timeout);
/*     */   }
/*     */ 
/*     */   public boolean isClosed() {
/* 101 */     return this.server.isClosed();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.ServerDelegate
 * JD-Core Version:    0.6.2
 */