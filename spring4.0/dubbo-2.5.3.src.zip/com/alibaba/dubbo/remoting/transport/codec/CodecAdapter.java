/*    */ package com.alibaba.dubbo.remoting.transport.codec;
/*    */ 
/*    */ import com.alibaba.dubbo.common.io.UnsafeByteArrayInputStream;
/*    */ import com.alibaba.dubbo.common.io.UnsafeByteArrayOutputStream;
/*    */ import com.alibaba.dubbo.common.utils.Assert;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.Codec;
/*    */ import com.alibaba.dubbo.remoting.Codec2;
/*    */ import com.alibaba.dubbo.remoting.Codec2.DecodeResult;
/*    */ import com.alibaba.dubbo.remoting.buffer.ChannelBuffer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class CodecAdapter
/*    */   implements Codec2
/*    */ {
/*    */   private Codec codec;
/*    */ 
/*    */   public CodecAdapter(Codec codec)
/*    */   {
/* 37 */     Assert.notNull(codec, "codec == null");
/* 38 */     this.codec = codec;
/*    */   }
/*    */ 
/*    */   public void encode(Channel channel, ChannelBuffer buffer, Object message) throws IOException
/*    */   {
/* 43 */     UnsafeByteArrayOutputStream os = new UnsafeByteArrayOutputStream(1024);
/* 44 */     this.codec.encode(channel, os, message);
/* 45 */     buffer.writeBytes(os.toByteArray());
/*    */   }
/*    */ 
/*    */   public Object decode(Channel channel, ChannelBuffer buffer) throws IOException {
/* 49 */     byte[] bytes = new byte[buffer.readableBytes()];
/* 50 */     int savedReaderIndex = buffer.readerIndex();
/* 51 */     buffer.readBytes(bytes);
/* 52 */     UnsafeByteArrayInputStream is = new UnsafeByteArrayInputStream(bytes);
/* 53 */     Object result = this.codec.decode(channel, is);
/* 54 */     buffer.readerIndex(savedReaderIndex + is.position());
/* 55 */     return result == Codec.NEED_MORE_INPUT ? Codec2.DecodeResult.NEED_MORE_INPUT : result;
/*    */   }
/*    */ 
/*    */   public Codec getCodec() {
/* 59 */     return this.codec;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.codec.CodecAdapter
 * JD-Core Version:    0.6.2
 */