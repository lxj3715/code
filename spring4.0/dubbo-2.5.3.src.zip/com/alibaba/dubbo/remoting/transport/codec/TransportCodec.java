/*    */ package com.alibaba.dubbo.remoting.transport.codec;
/*    */ 
/*    */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*    */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*    */ import com.alibaba.dubbo.common.serialize.Serialization;
/*    */ import com.alibaba.dubbo.common.utils.StringUtils;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.buffer.ChannelBuffer;
/*    */ import com.alibaba.dubbo.remoting.buffer.ChannelBufferInputStream;
/*    */ import com.alibaba.dubbo.remoting.buffer.ChannelBufferOutputStream;
/*    */ import com.alibaba.dubbo.remoting.transport.AbstractCodec;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class TransportCodec extends AbstractCodec
/*    */ {
/*    */   public void encode(Channel channel, ChannelBuffer buffer, Object message)
/*    */     throws IOException
/*    */   {
/* 39 */     OutputStream output = new ChannelBufferOutputStream(buffer);
/* 40 */     ObjectOutput objectOutput = getSerialization(channel).serialize(channel.getUrl(), output);
/* 41 */     encodeData(channel, objectOutput, message);
/* 42 */     objectOutput.flushBuffer();
/*    */   }
/*    */ 
/*    */   public Object decode(Channel channel, ChannelBuffer buffer) throws IOException {
/* 46 */     InputStream input = new ChannelBufferInputStream(buffer);
/* 47 */     return decodeData(channel, getSerialization(channel).deserialize(channel.getUrl(), input));
/*    */   }
/*    */ 
/*    */   protected void encodeData(Channel channel, ObjectOutput output, Object message) throws IOException {
/* 51 */     encodeData(output, message);
/*    */   }
/*    */ 
/*    */   protected Object decodeData(Channel channel, ObjectInput input) throws IOException {
/* 55 */     return decodeData(input);
/*    */   }
/*    */ 
/*    */   protected void encodeData(ObjectOutput output, Object message) throws IOException {
/* 59 */     output.writeObject(message);
/*    */   }
/*    */ 
/*    */   protected Object decodeData(ObjectInput input) throws IOException {
/*    */     try {
/* 64 */       return input.readObject();
/*    */     } catch (ClassNotFoundException e) {
/* 66 */       throw new IOException("ClassNotFoundException: " + StringUtils.toString(e));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.codec.TransportCodec
 * JD-Core Version:    0.6.2
 */