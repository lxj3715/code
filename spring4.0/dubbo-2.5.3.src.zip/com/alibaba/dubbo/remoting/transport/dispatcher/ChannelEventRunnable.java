/*     */ package com.alibaba.dubbo.remoting.transport.dispatcher;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ 
/*     */ public class ChannelEventRunnable
/*     */   implements Runnable
/*     */ {
/*  28 */   private static final Logger logger = LoggerFactory.getLogger(ChannelEventRunnable.class);
/*     */   private final ChannelHandler handler;
/*     */   private final Channel channel;
/*     */   private final ChannelState state;
/*     */   private final Throwable exception;
/*     */   private final Object message;
/*     */ 
/*     */   public ChannelEventRunnable(Channel channel, ChannelHandler handler, ChannelState state)
/*     */   {
/*  37 */     this(channel, handler, state, null);
/*     */   }
/*     */ 
/*     */   public ChannelEventRunnable(Channel channel, ChannelHandler handler, ChannelState state, Object message) {
/*  41 */     this(channel, handler, state, message, null);
/*     */   }
/*     */ 
/*     */   public ChannelEventRunnable(Channel channel, ChannelHandler handler, ChannelState state, Throwable t) {
/*  45 */     this(channel, handler, state, null, t);
/*     */   }
/*     */ 
/*     */   public ChannelEventRunnable(Channel channel, ChannelHandler handler, ChannelState state, Object message, Throwable exception) {
/*  49 */     this.channel = channel;
/*  50 */     this.handler = handler;
/*  51 */     this.state = state;
/*  52 */     this.message = message;
/*  53 */     this.exception = exception;
/*     */   }
/*     */ 
/*     */   public void run() {
/*  57 */     switch (1.$SwitchMap$com$alibaba$dubbo$remoting$transport$dispatcher$ChannelEventRunnable$ChannelState[this.state.ordinal()]) {
/*     */     case 1:
/*     */       try {
/*  60 */         this.handler.connected(this.channel);
/*     */       } catch (Exception e) {
/*  62 */         logger.warn("ChannelEventRunnable handle " + this.state + " operation error, channel is " + this.channel, e);
/*     */       }
/*     */     case 2:
/*     */       try
/*     */       {
/*  67 */         this.handler.disconnected(this.channel);
/*     */       } catch (Exception e) {
/*  69 */         logger.warn("ChannelEventRunnable handle " + this.state + " operation error, channel is " + this.channel, e);
/*     */       }
/*     */     case 3:
/*     */       try
/*     */       {
/*  74 */         this.handler.sent(this.channel, this.message);
/*     */       } catch (Exception e) {
/*  76 */         logger.warn("ChannelEventRunnable handle " + this.state + " operation error, channel is " + this.channel + ", message is " + this.message, e);
/*     */       }
/*     */ 
/*     */     case 4:
/*     */       try
/*     */       {
/*  82 */         this.handler.received(this.channel, this.message);
/*     */       } catch (Exception e) {
/*  84 */         logger.warn("ChannelEventRunnable handle " + this.state + " operation error, channel is " + this.channel + ", message is " + this.message, e);
/*     */       }
/*     */ 
/*     */     case 5:
/*     */       try
/*     */       {
/*  90 */         this.handler.caught(this.channel, this.exception);
/*     */       } catch (Exception e) {
/*  92 */         logger.warn("ChannelEventRunnable handle " + this.state + " operation error, channel is " + this.channel + ", message is: " + this.message + ", exception is " + this.exception, e);
/*     */       }
/*     */ 
/*     */     default:
/*  97 */       logger.warn("unknown state: " + this.state + ", message is " + this.message);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum ChannelState
/*     */   {
/* 111 */     CONNECTED, 
/*     */ 
/* 116 */     DISCONNECTED, 
/*     */ 
/* 121 */     SENT, 
/*     */ 
/* 126 */     RECEIVED, 
/*     */ 
/* 131 */     CAUGHT;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable
 * JD-Core Version:    0.6.2
 */