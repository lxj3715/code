/*    */ package com.alibaba.dubbo.remoting.transport.dispatcher;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.Dispatcher;
/*    */ import com.alibaba.dubbo.remoting.exchange.support.header.HeartbeatHandler;
/*    */ import com.alibaba.dubbo.remoting.transport.MultiMessageHandler;
/*    */ 
/*    */ public class ChannelHandlers
/*    */ {
/* 43 */   private static ChannelHandlers INSTANCE = new ChannelHandlers();
/*    */ 
/*    */   public static ChannelHandler wrap(ChannelHandler handler, URL url)
/*    */   {
/* 33 */     return getInstance().wrapInternal(handler, url);
/*    */   }
/*    */ 
/*    */   protected ChannelHandler wrapInternal(ChannelHandler handler, URL url)
/*    */   {
/* 39 */     return new MultiMessageHandler(new HeartbeatHandler(((Dispatcher)ExtensionLoader.getExtensionLoader(Dispatcher.class).getAdaptiveExtension()).dispatch(handler, url)));
/*    */   }
/*    */ 
/*    */   protected static ChannelHandlers getInstance()
/*    */   {
/* 46 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   static void setTestingChannelHandlers(ChannelHandlers instance) {
/* 50 */     INSTANCE = instance;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.ChannelHandlers
 * JD-Core Version:    0.6.2
 */