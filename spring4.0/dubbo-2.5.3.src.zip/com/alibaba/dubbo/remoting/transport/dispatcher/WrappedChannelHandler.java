/*     */ package com.alibaba.dubbo.remoting.transport.dispatcher;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.store.DataStore;
/*     */ import com.alibaba.dubbo.common.threadpool.ThreadPool;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.remoting.Channel;
/*     */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*     */ import com.alibaba.dubbo.remoting.RemotingException;
/*     */ import com.alibaba.dubbo.remoting.transport.ChannelHandlerDelegate;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ 
/*     */ public class WrappedChannelHandler
/*     */   implements ChannelHandlerDelegate
/*     */ {
/*  36 */   protected static final Logger logger = LoggerFactory.getLogger(WrappedChannelHandler.class);
/*     */ 
/*  38 */   protected static final ExecutorService SHARED_EXECUTOR = Executors.newCachedThreadPool(new NamedThreadFactory("DubboSharedHandler", true));
/*     */   protected final ExecutorService executor;
/*     */   protected final ChannelHandler handler;
/*     */   protected final URL url;
/*     */ 
/*     */   public WrappedChannelHandler(ChannelHandler handler, URL url)
/*     */   {
/*  47 */     this.handler = handler;
/*  48 */     this.url = url;
/*  49 */     this.executor = ((ExecutorService)((ThreadPool)ExtensionLoader.getExtensionLoader(ThreadPool.class).getAdaptiveExtension()).getExecutor(url));
/*     */ 
/*  51 */     String componentKey = Constants.EXECUTOR_SERVICE_COMPONENT_KEY;
/*  52 */     if ("consumer".equalsIgnoreCase(url.getParameter("side"))) {
/*  53 */       componentKey = "consumer";
/*     */     }
/*  55 */     DataStore dataStore = (DataStore)ExtensionLoader.getExtensionLoader(DataStore.class).getDefaultExtension();
/*  56 */     dataStore.put(componentKey, Integer.toString(url.getPort()), this.executor);
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */     try {
/*  61 */       if ((this.executor instanceof ExecutorService))
/*  62 */         this.executor.shutdown();
/*     */     }
/*     */     catch (Throwable t) {
/*  65 */       logger.warn("fail to destroy thread pool of server: " + t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void connected(Channel channel) throws RemotingException {
/*  70 */     this.handler.connected(channel);
/*     */   }
/*     */ 
/*     */   public void disconnected(Channel channel) throws RemotingException {
/*  74 */     this.handler.disconnected(channel);
/*     */   }
/*     */ 
/*     */   public void sent(Channel channel, Object message) throws RemotingException {
/*  78 */     this.handler.sent(channel, message);
/*     */   }
/*     */ 
/*     */   public void received(Channel channel, Object message) throws RemotingException {
/*  82 */     this.handler.received(channel, message);
/*     */   }
/*     */ 
/*     */   public void caught(Channel channel, Throwable exception) throws RemotingException {
/*  86 */     this.handler.caught(channel, exception);
/*     */   }
/*     */ 
/*     */   public ExecutorService getExecutor() {
/*  90 */     return this.executor;
/*     */   }
/*     */ 
/*     */   public ChannelHandler getHandler() {
/*  94 */     if ((this.handler instanceof ChannelHandlerDelegate)) {
/*  95 */       return ((ChannelHandlerDelegate)this.handler).getHandler();
/*     */     }
/*  97 */     return this.handler;
/*     */   }
/*     */ 
/*     */   public URL getUrl()
/*     */   {
/* 102 */     return this.url;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.WrappedChannelHandler
 * JD-Core Version:    0.6.2
 */