/*    */ package com.alibaba.dubbo.remoting.transport.dispatcher.all;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.ExecutionException;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable.ChannelState;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.WrappedChannelHandler;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ 
/*    */ public class AllChannelHandler extends WrappedChannelHandler
/*    */ {
/*    */   public AllChannelHandler(ChannelHandler handler, URL url)
/*    */   {
/* 32 */     super(handler, url);
/*    */   }
/*    */ 
/*    */   public void connected(Channel channel) throws RemotingException {
/* 36 */     ExecutorService cexecutor = getExecutorService();
/*    */     try {
/* 38 */       cexecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.CONNECTED));
/*    */     } catch (Throwable t) {
/* 40 */       throw new ExecutionException("connect event", channel, getClass() + " error when process connected event .", t);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void disconnected(Channel channel) throws RemotingException {
/* 45 */     ExecutorService cexecutor = getExecutorService();
/*    */     try {
/* 47 */       cexecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.DISCONNECTED));
/*    */     } catch (Throwable t) {
/* 49 */       throw new ExecutionException("disconnect event", channel, getClass() + " error when process disconnected event .", t);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void received(Channel channel, Object message) throws RemotingException {
/* 54 */     ExecutorService cexecutor = getExecutorService();
/*    */     try {
/* 56 */       cexecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.RECEIVED, message));
/*    */     } catch (Throwable t) {
/* 58 */       throw new ExecutionException(message, channel, getClass() + " error when process received event .", t);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void caught(Channel channel, Throwable exception) throws RemotingException {
/* 63 */     ExecutorService cexecutor = getExecutorService();
/*    */     try {
/* 65 */       cexecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.CAUGHT, exception));
/*    */     } catch (Throwable t) {
/* 67 */       throw new ExecutionException("caught event", channel, getClass() + " error when process caught event .", t);
/*    */     }
/*    */   }
/*    */ 
/*    */   private ExecutorService getExecutorService() {
/* 72 */     ExecutorService cexecutor = this.executor;
/* 73 */     if ((cexecutor == null) || (cexecutor.isShutdown())) {
/* 74 */       cexecutor = SHARED_EXECUTOR;
/*    */     }
/* 76 */     return cexecutor;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.all.AllChannelHandler
 * JD-Core Version:    0.6.2
 */