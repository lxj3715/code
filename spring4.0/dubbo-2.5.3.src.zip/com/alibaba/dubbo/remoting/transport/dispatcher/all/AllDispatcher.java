/*    */ package com.alibaba.dubbo.remoting.transport.dispatcher.all;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.Dispatcher;
/*    */ 
/*    */ public class AllDispatcher
/*    */   implements Dispatcher
/*    */ {
/*    */   public static final String NAME = "all";
/*    */ 
/*    */   public ChannelHandler dispatch(ChannelHandler handler, URL url)
/*    */   {
/* 32 */     return new AllChannelHandler(handler, url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.all.AllDispatcher
 * JD-Core Version:    0.6.2
 */