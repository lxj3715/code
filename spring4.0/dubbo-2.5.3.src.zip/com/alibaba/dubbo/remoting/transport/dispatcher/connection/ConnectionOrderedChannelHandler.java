/*    */ package com.alibaba.dubbo.remoting.transport.dispatcher.connection;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.threadpool.support.AbortPolicyWithReport;
/*    */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.ExecutionException;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable.ChannelState;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.WrappedChannelHandler;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.LinkedBlockingQueue;
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ public class ConnectionOrderedChannelHandler extends WrappedChannelHandler
/*    */ {
/*    */   protected final ThreadPoolExecutor connectionExecutor;
/*    */   private final int queuewarninglimit;
/*    */ 
/*    */   public ConnectionOrderedChannelHandler(ChannelHandler handler, URL url)
/*    */   {
/* 41 */     super(handler, url);
/* 42 */     String threadName = url.getParameter("threadname", "Dubbo");
/* 43 */     this.connectionExecutor = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue(url.getPositiveParameter("connect.queue.capacity", 2147483647)), new NamedThreadFactory(threadName, true), new AbortPolicyWithReport(threadName, url));
/*    */ 
/* 49 */     this.queuewarninglimit = url.getParameter("connect.queue.warning.size", 1000);
/*    */   }
/*    */ 
/*    */   public void connected(Channel channel) throws RemotingException {
/*    */     try {
/* 54 */       checkQueueLength();
/* 55 */       this.connectionExecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.CONNECTED));
/*    */     } catch (Throwable t) {
/* 57 */       throw new ExecutionException("connect event", channel, getClass() + " error when process connected event .", t);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void disconnected(Channel channel) throws RemotingException {
/*    */     try {
/* 63 */       checkQueueLength();
/* 64 */       this.connectionExecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.DISCONNECTED));
/*    */     } catch (Throwable t) {
/* 66 */       throw new ExecutionException("disconnected event", channel, getClass() + " error when process disconnected event .", t);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void received(Channel channel, Object message) throws RemotingException {
/* 71 */     ExecutorService cexecutor = this.executor;
/* 72 */     if ((cexecutor == null) || (cexecutor.isShutdown()))
/* 73 */       cexecutor = SHARED_EXECUTOR;
/*    */     try
/*    */     {
/* 76 */       cexecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.RECEIVED, message));
/*    */     } catch (Throwable t) {
/* 78 */       throw new ExecutionException(message, channel, getClass() + " error when process received event .", t);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void caught(Channel channel, Throwable exception) throws RemotingException {
/* 83 */     ExecutorService cexecutor = this.executor;
/* 84 */     if ((cexecutor == null) || (cexecutor.isShutdown()))
/* 85 */       cexecutor = SHARED_EXECUTOR;
/*    */     try
/*    */     {
/* 88 */       cexecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.CAUGHT, exception));
/*    */     } catch (Throwable t) {
/* 90 */       throw new ExecutionException("caught event", channel, getClass() + " error when process caught event .", t);
/*    */     }
/*    */   }
/*    */ 
/*    */   private void checkQueueLength() {
/* 95 */     if (this.connectionExecutor.getQueue().size() > this.queuewarninglimit)
/* 96 */       logger.warn(new IllegalThreadStateException("connectionordered channel handler `queue size: " + this.connectionExecutor.getQueue().size() + " exceed the warning limit number :" + this.queuewarninglimit));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.connection.ConnectionOrderedChannelHandler
 * JD-Core Version:    0.6.2
 */