/*    */ package com.alibaba.dubbo.remoting.transport.dispatcher.connection;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.Dispatcher;
/*    */ 
/*    */ public class ConnectionOrderedDispatcher
/*    */   implements Dispatcher
/*    */ {
/*    */   public static final String NAME = "connection";
/*    */ 
/*    */   public ChannelHandler dispatch(ChannelHandler handler, URL url)
/*    */   {
/* 32 */     return new ConnectionOrderedChannelHandler(handler, url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.connection.ConnectionOrderedDispatcher
 * JD-Core Version:    0.6.2
 */