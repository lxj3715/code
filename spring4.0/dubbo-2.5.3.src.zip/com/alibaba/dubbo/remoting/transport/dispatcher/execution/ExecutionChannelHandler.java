/*    */ package com.alibaba.dubbo.remoting.transport.dispatcher.execution;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable.ChannelState;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.WrappedChannelHandler;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ 
/*    */ public class ExecutionChannelHandler extends WrappedChannelHandler
/*    */ {
/*    */   public ExecutionChannelHandler(ChannelHandler handler, URL url)
/*    */   {
/* 29 */     super(handler, url);
/*    */   }
/*    */ 
/*    */   public void connected(Channel channel) throws RemotingException {
/* 33 */     this.executor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.CONNECTED));
/*    */   }
/*    */ 
/*    */   public void disconnected(Channel channel) throws RemotingException {
/* 37 */     this.executor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.DISCONNECTED));
/*    */   }
/*    */ 
/*    */   public void received(Channel channel, Object message) throws RemotingException {
/* 41 */     this.executor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.RECEIVED, message));
/*    */   }
/*    */ 
/*    */   public void caught(Channel channel, Throwable exception) throws RemotingException {
/* 45 */     this.executor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.CAUGHT, exception));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.execution.ExecutionChannelHandler
 * JD-Core Version:    0.6.2
 */