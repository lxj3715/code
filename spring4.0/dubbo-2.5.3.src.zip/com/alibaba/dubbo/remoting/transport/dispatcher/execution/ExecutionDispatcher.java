/*    */ package com.alibaba.dubbo.remoting.transport.dispatcher.execution;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.Dispatcher;
/*    */ 
/*    */ public class ExecutionDispatcher
/*    */   implements Dispatcher
/*    */ {
/*    */   public static final String NAME = "execution";
/*    */ 
/*    */   public ChannelHandler dispatch(ChannelHandler handler, URL url)
/*    */   {
/* 32 */     return new ExecutionChannelHandler(handler, url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.execution.ExecutionDispatcher
 * JD-Core Version:    0.6.2
 */