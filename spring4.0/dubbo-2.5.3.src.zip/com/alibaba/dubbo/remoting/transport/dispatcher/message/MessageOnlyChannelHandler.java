/*    */ package com.alibaba.dubbo.remoting.transport.dispatcher.message;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.remoting.Channel;
/*    */ import com.alibaba.dubbo.remoting.ChannelHandler;
/*    */ import com.alibaba.dubbo.remoting.ExecutionException;
/*    */ import com.alibaba.dubbo.remoting.RemotingException;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.ChannelEventRunnable.ChannelState;
/*    */ import com.alibaba.dubbo.remoting.transport.dispatcher.WrappedChannelHandler;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ 
/*    */ public class MessageOnlyChannelHandler extends WrappedChannelHandler
/*    */ {
/*    */   public MessageOnlyChannelHandler(ChannelHandler handler, URL url)
/*    */   {
/* 32 */     super(handler, url);
/*    */   }
/*    */ 
/*    */   public void received(Channel channel, Object message) throws RemotingException {
/* 36 */     ExecutorService cexecutor = this.executor;
/* 37 */     if ((cexecutor == null) || (cexecutor.isShutdown()))
/* 38 */       cexecutor = SHARED_EXECUTOR;
/*    */     try
/*    */     {
/* 41 */       cexecutor.execute(new ChannelEventRunnable(channel, this.handler, ChannelEventRunnable.ChannelState.RECEIVED, message));
/*    */     } catch (Throwable t) {
/* 43 */       throw new ExecutionException(message, channel, getClass() + " error when process received event .", t);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.remoting.transport.dispatcher.message.MessageOnlyChannelHandler
 * JD-Core Version:    0.6.2
 */