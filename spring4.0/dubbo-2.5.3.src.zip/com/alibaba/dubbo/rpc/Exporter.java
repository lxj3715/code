package com.alibaba.dubbo.rpc;

public abstract interface Exporter<T>
{
  public abstract Invoker<T> getInvoker();

  public abstract void unexport();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.Exporter
 * JD-Core Version:    0.6.2
 */