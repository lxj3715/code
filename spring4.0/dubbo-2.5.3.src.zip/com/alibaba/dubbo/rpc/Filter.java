package com.alibaba.dubbo.rpc;

import com.alibaba.dubbo.common.extension.SPI;

@SPI
public abstract interface Filter
{
  public abstract Result invoke(Invoker<?> paramInvoker, Invocation paramInvocation)
    throws RpcException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.Filter
 * JD-Core Version:    0.6.2
 */