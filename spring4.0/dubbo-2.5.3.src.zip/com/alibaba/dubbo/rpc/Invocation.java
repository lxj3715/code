package com.alibaba.dubbo.rpc;

import java.util.Map;

public abstract interface Invocation
{
  public abstract String getMethodName();

  public abstract Class<?>[] getParameterTypes();

  public abstract Object[] getArguments();

  public abstract Map<String, String> getAttachments();

  public abstract String getAttachment(String paramString);

  public abstract String getAttachment(String paramString1, String paramString2);

  public abstract Invoker<?> getInvoker();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.Invocation
 * JD-Core Version:    0.6.2
 */