package com.alibaba.dubbo.rpc;

import com.alibaba.dubbo.common.Node;

public abstract interface Invoker<T> extends Node
{
  public abstract Class<T> getInterface();

  public abstract Result invoke(Invocation paramInvocation)
    throws RpcException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.Invoker
 * JD-Core Version:    0.6.2
 */