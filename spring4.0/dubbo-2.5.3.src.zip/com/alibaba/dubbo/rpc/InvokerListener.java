package com.alibaba.dubbo.rpc;

import com.alibaba.dubbo.common.extension.SPI;

@SPI
public abstract interface InvokerListener
{
  public abstract void referred(Invoker<?> paramInvoker)
    throws RpcException;

  public abstract void destroyed(Invoker<?> paramInvoker);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.InvokerListener
 * JD-Core Version:    0.6.2
 */