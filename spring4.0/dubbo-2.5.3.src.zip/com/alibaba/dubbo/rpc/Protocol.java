package com.alibaba.dubbo.rpc;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;

@SPI("dubbo")
public abstract interface Protocol
{
  public abstract int getDefaultPort();

  @Adaptive
  public abstract <T> Exporter<T> export(Invoker<T> paramInvoker)
    throws RpcException;

  @Adaptive
  public abstract <T> Invoker<T> refer(Class<T> paramClass, URL paramURL)
    throws RpcException;

  public abstract void destroy();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.Protocol
 * JD-Core Version:    0.6.2
 */