package com.alibaba.dubbo.rpc;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;

@SPI("javassist")
public abstract interface ProxyFactory
{
  @Adaptive({"proxy"})
  public abstract <T> T getProxy(Invoker<T> paramInvoker)
    throws RpcException;

  @Adaptive({"proxy"})
  public abstract <T> Invoker<T> getInvoker(T paramT, Class<T> paramClass, URL paramURL)
    throws RpcException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.ProxyFactory
 * JD-Core Version:    0.6.2
 */