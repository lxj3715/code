package com.alibaba.dubbo.rpc;

import java.util.Map;

public abstract interface Result
{
  public abstract Object getValue();

  public abstract Throwable getException();

  public abstract boolean hasException();

  public abstract Object recreate()
    throws Throwable;

  @Deprecated
  public abstract Object getResult();

  public abstract Map<String, String> getAttachments();

  public abstract String getAttachment(String paramString);

  public abstract String getAttachment(String paramString1, String paramString2);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.Result
 * JD-Core Version:    0.6.2
 */