package com.alibaba.dubbo.rpc;

import com.alibaba.dubbo.common.Constants;

@Deprecated
public final class RpcConstants extends Constants
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.RpcConstants
 * JD-Core Version:    0.6.2
 */