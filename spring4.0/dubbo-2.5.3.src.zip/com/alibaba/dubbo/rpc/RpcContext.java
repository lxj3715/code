/*     */ package com.alibaba.dubbo.rpc;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ public class RpcContext
/*     */ {
/*  48 */   private static final ThreadLocal<RpcContext> LOCAL = new ThreadLocal()
/*     */   {
/*     */     protected RpcContext initialValue() {
/*  51 */       return new RpcContext();
/*     */     }
/*  48 */   };
/*     */   private Future<?> future;
/*     */   private List<URL> urls;
/*     */   private URL url;
/*     */   private String methodName;
/*     */   private Class<?>[] parameterTypes;
/*     */   private Object[] arguments;
/*     */   private InetSocketAddress localAddress;
/*     */   private InetSocketAddress remoteAddress;
/*  89 */   private final Map<String, String> attachments = new HashMap();
/*     */ 
/*  91 */   private final Map<String, Object> values = new HashMap();
/*     */ 
/*     */   @Deprecated
/*     */   private List<Invoker<?>> invokers;
/*     */ 
/*     */   @Deprecated
/*     */   private Invoker<?> invoker;
/*     */ 
/*     */   @Deprecated
/*     */   private Invocation invocation;
/*     */ 
/*     */   public static RpcContext getContext()
/*     */   {
/*  61 */     return (RpcContext)LOCAL.get();
/*     */   }
/*     */ 
/*     */   public static void removeContext()
/*     */   {
/*  70 */     LOCAL.remove();
/*     */   }
/*     */ 
/*     */   public boolean isProviderSide()
/*     */   {
/* 111 */     URL url = getUrl();
/* 112 */     if (url == null) {
/* 113 */       return false;
/*     */     }
/* 115 */     InetSocketAddress address = getRemoteAddress();
/* 116 */     if (address == null)
/* 117 */       return false;
/*     */     String host;
/*     */     String host;
/* 120 */     if (address.getAddress() == null)
/* 121 */       host = address.getHostName();
/*     */     else {
/* 123 */       host = address.getAddress().getHostAddress();
/*     */     }
/* 125 */     return (url.getPort() != address.getPort()) || (!NetUtils.filterLocalHost(url.getIp()).equals(NetUtils.filterLocalHost(host)));
/*     */   }
/*     */ 
/*     */   public boolean isConsumerSide()
/*     */   {
/* 135 */     URL url = getUrl();
/* 136 */     if (url == null) {
/* 137 */       return false;
/*     */     }
/* 139 */     InetSocketAddress address = getRemoteAddress();
/* 140 */     if (address == null)
/* 141 */       return false;
/*     */     String host;
/*     */     String host;
/* 144 */     if (address.getAddress() == null)
/* 145 */       host = address.getHostName();
/*     */     else {
/* 147 */       host = address.getAddress().getHostAddress();
/*     */     }
/* 149 */     return (url.getPort() == address.getPort()) && (NetUtils.filterLocalHost(url.getIp()).equals(NetUtils.filterLocalHost(host)));
/*     */   }
/*     */ 
/*     */   public <T> Future<T> getFuture()
/*     */   {
/* 161 */     return this.future;
/*     */   }
/*     */ 
/*     */   public void setFuture(Future<?> future)
/*     */   {
/* 170 */     this.future = future;
/*     */   }
/*     */ 
/*     */   public List<URL> getUrls() {
/* 174 */     return (this.urls == null) && (this.url != null) ? Arrays.asList(new URL[] { this.url }) : this.urls;
/*     */   }
/*     */ 
/*     */   public void setUrls(List<URL> urls) {
/* 178 */     this.urls = urls;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/* 182 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setUrl(URL url) {
/* 186 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public String getMethodName()
/*     */   {
/* 195 */     return this.methodName;
/*     */   }
/*     */ 
/*     */   public void setMethodName(String methodName) {
/* 199 */     this.methodName = methodName;
/*     */   }
/*     */ 
/*     */   public Class<?>[] getParameterTypes()
/*     */   {
/* 208 */     return this.parameterTypes;
/*     */   }
/*     */ 
/*     */   public void setParameterTypes(Class<?>[] parameterTypes) {
/* 212 */     this.parameterTypes = parameterTypes;
/*     */   }
/*     */ 
/*     */   public Object[] getArguments()
/*     */   {
/* 221 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   public void setArguments(Object[] arguments) {
/* 225 */     this.arguments = arguments;
/*     */   }
/*     */ 
/*     */   public RpcContext setLocalAddress(InetSocketAddress address)
/*     */   {
/* 235 */     this.localAddress = address;
/* 236 */     return this;
/*     */   }
/*     */ 
/*     */   public RpcContext setLocalAddress(String host, int port)
/*     */   {
/* 247 */     if (port < 0) {
/* 248 */       port = 0;
/*     */     }
/* 250 */     this.localAddress = InetSocketAddress.createUnresolved(host, port);
/* 251 */     return this;
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress()
/*     */   {
/* 260 */     return this.localAddress;
/*     */   }
/*     */ 
/*     */   public String getLocalAddressString() {
/* 264 */     return getLocalHost() + ":" + getLocalPort();
/*     */   }
/*     */ 
/*     */   public String getLocalHostName()
/*     */   {
/* 273 */     String host = this.localAddress == null ? null : this.localAddress.getHostName();
/* 274 */     if ((host == null) || (host.length() == 0)) {
/* 275 */       return getLocalHost();
/*     */     }
/* 277 */     return host;
/*     */   }
/*     */ 
/*     */   public RpcContext setRemoteAddress(InetSocketAddress address)
/*     */   {
/* 287 */     this.remoteAddress = address;
/* 288 */     return this;
/*     */   }
/*     */ 
/*     */   public RpcContext setRemoteAddress(String host, int port)
/*     */   {
/* 299 */     if (port < 0) {
/* 300 */       port = 0;
/*     */     }
/* 302 */     this.remoteAddress = InetSocketAddress.createUnresolved(host, port);
/* 303 */     return this;
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getRemoteAddress()
/*     */   {
/* 312 */     return this.remoteAddress;
/*     */   }
/*     */ 
/*     */   public String getRemoteAddressString()
/*     */   {
/* 321 */     return getRemoteHost() + ":" + getRemotePort();
/*     */   }
/*     */ 
/*     */   public String getRemoteHostName()
/*     */   {
/* 330 */     return this.remoteAddress == null ? null : this.remoteAddress.getHostName();
/*     */   }
/*     */ 
/*     */   public String getLocalHost()
/*     */   {
/* 339 */     String host = this.localAddress.getAddress() == null ? this.localAddress.getHostName() : this.localAddress == null ? null : NetUtils.filterLocalHost(this.localAddress.getAddress().getHostAddress());
/*     */ 
/* 342 */     if ((host == null) || (host.length() == 0)) {
/* 343 */       return NetUtils.getLocalHost();
/*     */     }
/* 345 */     return host;
/*     */   }
/*     */ 
/*     */   public int getLocalPort()
/*     */   {
/* 354 */     return this.localAddress == null ? 0 : this.localAddress.getPort();
/*     */   }
/*     */ 
/*     */   public String getRemoteHost()
/*     */   {
/* 363 */     return this.remoteAddress.getAddress() == null ? this.remoteAddress.getHostName() : this.remoteAddress == null ? null : NetUtils.filterLocalHost(this.remoteAddress.getAddress().getHostAddress());
/*     */   }
/*     */ 
/*     */   public int getRemotePort()
/*     */   {
/* 374 */     return this.remoteAddress == null ? 0 : this.remoteAddress.getPort();
/*     */   }
/*     */ 
/*     */   public String getAttachment(String key)
/*     */   {
/* 384 */     return (String)this.attachments.get(key);
/*     */   }
/*     */ 
/*     */   public RpcContext setAttachment(String key, String value)
/*     */   {
/* 395 */     if (value == null)
/* 396 */       this.attachments.remove(key);
/*     */     else {
/* 398 */       this.attachments.put(key, value);
/*     */     }
/* 400 */     return this;
/*     */   }
/*     */ 
/*     */   public RpcContext removeAttachment(String key)
/*     */   {
/* 410 */     this.attachments.remove(key);
/* 411 */     return this;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getAttachments()
/*     */   {
/* 420 */     return this.attachments;
/*     */   }
/*     */ 
/*     */   public RpcContext setAttachments(Map<String, String> attachment)
/*     */   {
/* 430 */     this.attachments.clear();
/* 431 */     if ((attachment != null) && (attachment.size() > 0)) {
/* 432 */       this.attachments.putAll(attachment);
/*     */     }
/* 434 */     return this;
/*     */   }
/*     */ 
/*     */   public void clearAttachments() {
/* 438 */     this.attachments.clear();
/*     */   }
/*     */ 
/*     */   public Map<String, Object> get()
/*     */   {
/* 447 */     return this.values;
/*     */   }
/*     */ 
/*     */   public RpcContext set(String key, Object value)
/*     */   {
/* 458 */     if (value == null)
/* 459 */       this.values.remove(key);
/*     */     else {
/* 461 */       this.values.put(key, value);
/*     */     }
/* 463 */     return this;
/*     */   }
/*     */ 
/*     */   public RpcContext remove(String key)
/*     */   {
/* 473 */     this.values.remove(key);
/* 474 */     return this;
/*     */   }
/*     */ 
/*     */   public Object get(String key)
/*     */   {
/* 484 */     return this.values.get(key);
/*     */   }
/*     */ 
/*     */   public RpcContext setInvokers(List<Invoker<?>> invokers) {
/* 488 */     this.invokers = invokers;
/* 489 */     if ((invokers != null) && (invokers.size() > 0)) {
/* 490 */       List urls = new ArrayList(invokers.size());
/* 491 */       for (Invoker invoker : invokers) {
/* 492 */         urls.add(invoker.getUrl());
/*     */       }
/* 494 */       setUrls(urls);
/*     */     }
/* 496 */     return this;
/*     */   }
/*     */ 
/*     */   public RpcContext setInvoker(Invoker<?> invoker) {
/* 500 */     this.invoker = invoker;
/* 501 */     if (invoker != null) {
/* 502 */       setUrl(invoker.getUrl());
/*     */     }
/* 504 */     return this;
/*     */   }
/*     */ 
/*     */   public RpcContext setInvocation(Invocation invocation) {
/* 508 */     this.invocation = invocation;
/* 509 */     if (invocation != null) {
/* 510 */       setMethodName(invocation.getMethodName());
/* 511 */       setParameterTypes(invocation.getParameterTypes());
/* 512 */       setArguments(invocation.getArguments());
/*     */     }
/* 514 */     return this;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean isServerSide()
/*     */   {
/* 522 */     return isProviderSide();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean isClientSide()
/*     */   {
/* 530 */     return isConsumerSide();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public List<Invoker<?>> getInvokers()
/*     */   {
/* 539 */     return (this.invokers == null) && (this.invoker != null) ? Arrays.asList(new Invoker[] { this.invoker }) : this.invokers;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Invoker<?> getInvoker()
/*     */   {
/* 547 */     return this.invoker;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Invocation getInvocation()
/*     */   {
/* 555 */     return this.invocation;
/*     */   }
/*     */ 
/*     */   public <T> Future<T> asyncCall(Callable<T> callable)
/*     */   {
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/* 567 */         setAttachment("async", Boolean.TRUE.toString());
/* 568 */         final Object o = callable.call();
/*     */ 
/* 570 */         if (o != null) {
/* 571 */           FutureTask f = new FutureTask(new Callable() {
/*     */             public T call() throws Exception {
/* 573 */               return o;
/*     */             }
/*     */           });
/* 576 */           f.run();
/* 577 */           return f;
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 582 */         throw new RpcException(e);
/*     */       } finally {
/* 584 */         removeAttachment("async");
/*     */       }
/*     */     } catch (RpcException e) {
/* 587 */       return new Future() {
/*     */         public boolean cancel(boolean mayInterruptIfRunning) {
/* 589 */           return false;
/*     */         }
/*     */         public boolean isCancelled() {
/* 592 */           return false;
/*     */         }
/*     */         public boolean isDone() {
/* 595 */           return true;
/*     */         }
/*     */         public T get() throws InterruptedException, ExecutionException {
/* 598 */           throw new ExecutionException(e.getCause());
/*     */         }
/*     */ 
/*     */         public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException
/*     */         {
/* 603 */           return get();
/*     */         }
/*     */       };
/*     */     }
/* 607 */     return getContext().getFuture();
/*     */   }
/*     */ 
/*     */   public void asyncCall(Runnable runable)
/*     */   {
/*     */     try
/*     */     {
/* 616 */       setAttachment("return", Boolean.FALSE.toString());
/* 617 */       runable.run();
/*     */     }
/*     */     catch (Throwable e) {
/* 620 */       throw new RpcException("oneway call error ." + e.getMessage(), e);
/*     */     } finally {
/* 622 */       removeAttachment("return");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.RpcContext
 * JD-Core Version:    0.6.2
 */