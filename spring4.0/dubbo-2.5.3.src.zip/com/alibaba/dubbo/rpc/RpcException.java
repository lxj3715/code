/*     */ package com.alibaba.dubbo.rpc;
/*     */ 
/*     */ public final class RpcException extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 7815426752583648734L;
/*     */   public static final int UNKNOWN_EXCEPTION = 0;
/*     */   public static final int NETWORK_EXCEPTION = 1;
/*     */   public static final int TIMEOUT_EXCEPTION = 2;
/*     */   public static final int BIZ_EXCEPTION = 3;
/*     */   public static final int FORBIDDEN_EXCEPTION = 4;
/*     */   public static final int SERIALIZATION_EXCEPTION = 5;
/*     */   private int code;
/*     */ 
/*     */   public RpcException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RpcException(String message, Throwable cause)
/*     */   {
/*  51 */     super(message, cause);
/*     */   }
/*     */ 
/*     */   public RpcException(String message) {
/*  55 */     super(message);
/*     */   }
/*     */ 
/*     */   public RpcException(Throwable cause) {
/*  59 */     super(cause);
/*     */   }
/*     */ 
/*     */   public RpcException(int code)
/*     */   {
/*  64 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public RpcException(int code, String message, Throwable cause) {
/*  68 */     super(message, cause);
/*  69 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public RpcException(int code, String message) {
/*  73 */     super(message);
/*  74 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public RpcException(int code, Throwable cause) {
/*  78 */     super(cause);
/*  79 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public void setCode(int code) {
/*  83 */     this.code = code;
/*     */   }
/*     */ 
/*     */   public int getCode() {
/*  87 */     return this.code;
/*     */   }
/*     */ 
/*     */   public boolean isBiz() {
/*  91 */     return this.code == 3;
/*     */   }
/*     */ 
/*     */   public boolean isForbidded() {
/*  95 */     return this.code == 4;
/*     */   }
/*     */ 
/*     */   public boolean isTimeout() {
/*  99 */     return this.code == 2;
/*     */   }
/*     */ 
/*     */   public boolean isNetwork() {
/* 103 */     return this.code == 1;
/*     */   }
/*     */ 
/*     */   public boolean isSerialization() {
/* 107 */     return this.code == 5;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.RpcException
 * JD-Core Version:    0.6.2
 */