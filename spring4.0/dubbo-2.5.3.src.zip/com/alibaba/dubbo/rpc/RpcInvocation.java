/*     */ package com.alibaba.dubbo.rpc;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class RpcInvocation
/*     */   implements Invocation, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -4355285085441097045L;
/*     */   private String methodName;
/*     */   private Class<?>[] parameterTypes;
/*     */   private Object[] arguments;
/*     */   private Map<String, String> attachments;
/*     */   private transient Invoker<?> invoker;
/*     */ 
/*     */   public RpcInvocation()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RpcInvocation(Invocation invocation, Invoker<?> invoker)
/*     */   {
/*  51 */     this(invocation.getMethodName(), invocation.getParameterTypes(), invocation.getArguments(), new HashMap(invocation.getAttachments()), invocation.getInvoker());
/*     */ 
/*  54 */     if (invoker != null) {
/*  55 */       URL url = invoker.getUrl();
/*  56 */       setAttachment("path", url.getPath());
/*  57 */       if (url.hasParameter("interface")) {
/*  58 */         setAttachment("interface", url.getParameter("interface"));
/*     */       }
/*  60 */       if (url.hasParameter("group")) {
/*  61 */         setAttachment("group", url.getParameter("group"));
/*     */       }
/*  63 */       if (url.hasParameter("version")) {
/*  64 */         setAttachment("version", url.getParameter("version", "0.0.0"));
/*     */       }
/*  66 */       if (url.hasParameter("timeout")) {
/*  67 */         setAttachment("timeout", url.getParameter("timeout"));
/*     */       }
/*  69 */       if (url.hasParameter("token")) {
/*  70 */         setAttachment("token", url.getParameter("token"));
/*     */       }
/*  72 */       if (url.hasParameter("application"))
/*  73 */         setAttachment("application", url.getParameter("application"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public RpcInvocation(Invocation invocation)
/*     */   {
/*  79 */     this(invocation.getMethodName(), invocation.getParameterTypes(), invocation.getArguments(), invocation.getAttachments(), invocation.getInvoker());
/*     */   }
/*     */ 
/*     */   public RpcInvocation(Method method, Object[] arguments)
/*     */   {
/*  84 */     this(method.getName(), method.getParameterTypes(), arguments, null, null);
/*     */   }
/*     */ 
/*     */   public RpcInvocation(Method method, Object[] arguments, Map<String, String> attachment) {
/*  88 */     this(method.getName(), method.getParameterTypes(), arguments, attachment, null);
/*     */   }
/*     */ 
/*     */   public RpcInvocation(String methodName, Class<?>[] parameterTypes, Object[] arguments) {
/*  92 */     this(methodName, parameterTypes, arguments, null, null);
/*     */   }
/*     */ 
/*     */   public RpcInvocation(String methodName, Class<?>[] parameterTypes, Object[] arguments, Map<String, String> attachments) {
/*  96 */     this(methodName, parameterTypes, arguments, attachments, null);
/*     */   }
/*     */ 
/*     */   public RpcInvocation(String methodName, Class<?>[] parameterTypes, Object[] arguments, Map<String, String> attachments, Invoker<?> invoker) {
/* 100 */     this.methodName = methodName;
/* 101 */     this.parameterTypes = (parameterTypes == null ? new Class[0] : parameterTypes);
/* 102 */     this.arguments = (arguments == null ? new Object[0] : arguments);
/* 103 */     this.attachments = (attachments == null ? new HashMap() : attachments);
/* 104 */     this.invoker = invoker;
/*     */   }
/*     */ 
/*     */   public Invoker<?> getInvoker() {
/* 108 */     return this.invoker;
/*     */   }
/*     */ 
/*     */   public void setInvoker(Invoker<?> invoker) {
/* 112 */     this.invoker = invoker;
/*     */   }
/*     */ 
/*     */   public String getMethodName() {
/* 116 */     return this.methodName;
/*     */   }
/*     */ 
/*     */   public Class<?>[] getParameterTypes() {
/* 120 */     return this.parameterTypes;
/*     */   }
/*     */ 
/*     */   public Object[] getArguments() {
/* 124 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getAttachments() {
/* 128 */     return this.attachments;
/*     */   }
/*     */ 
/*     */   public void setMethodName(String methodName) {
/* 132 */     this.methodName = methodName;
/*     */   }
/*     */ 
/*     */   public void setParameterTypes(Class<?>[] parameterTypes) {
/* 136 */     this.parameterTypes = (parameterTypes == null ? new Class[0] : parameterTypes);
/*     */   }
/*     */ 
/*     */   public void setArguments(Object[] arguments) {
/* 140 */     this.arguments = (arguments == null ? new Object[0] : arguments);
/*     */   }
/*     */ 
/*     */   public void setAttachments(Map<String, String> attachments) {
/* 144 */     this.attachments = (attachments == null ? new HashMap() : attachments);
/*     */   }
/*     */ 
/*     */   public void setAttachment(String key, String value) {
/* 148 */     if (this.attachments == null) {
/* 149 */       this.attachments = new HashMap();
/*     */     }
/* 151 */     this.attachments.put(key, value);
/*     */   }
/*     */ 
/*     */   public void setAttachmentIfAbsent(String key, String value) {
/* 155 */     if (this.attachments == null) {
/* 156 */       this.attachments = new HashMap();
/*     */     }
/* 158 */     if (!this.attachments.containsKey(key))
/* 159 */       this.attachments.put(key, value);
/*     */   }
/*     */ 
/*     */   public void addAttachments(Map<String, String> attachments)
/*     */   {
/* 164 */     if (attachments == null) {
/* 165 */       return;
/*     */     }
/* 167 */     if (this.attachments == null) {
/* 168 */       this.attachments = new HashMap();
/*     */     }
/* 170 */     this.attachments.putAll(attachments);
/*     */   }
/*     */ 
/*     */   public void addAttachmentsIfAbsent(Map<String, String> attachments) {
/* 174 */     if (attachments == null) {
/* 175 */       return;
/*     */     }
/* 177 */     for (Map.Entry entry : attachments.entrySet())
/* 178 */       setAttachmentIfAbsent((String)entry.getKey(), (String)entry.getValue());
/*     */   }
/*     */ 
/*     */   public String getAttachment(String key)
/*     */   {
/* 183 */     if (this.attachments == null) {
/* 184 */       return null;
/*     */     }
/* 186 */     return (String)this.attachments.get(key);
/*     */   }
/*     */ 
/*     */   public String getAttachment(String key, String defaultValue) {
/* 190 */     if (this.attachments == null) {
/* 191 */       return defaultValue;
/*     */     }
/* 193 */     String value = (String)this.attachments.get(key);
/* 194 */     if ((value == null) || (value.length() == 0)) {
/* 195 */       return defaultValue;
/*     */     }
/* 197 */     return value;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 202 */     return "RpcInvocation [methodName=" + this.methodName + ", parameterTypes=" + Arrays.toString(this.parameterTypes) + ", arguments=" + Arrays.toString(this.arguments) + ", attachments=" + this.attachments + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.RpcInvocation
 * JD-Core Version:    0.6.2
 */