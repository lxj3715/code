/*     */ package com.alibaba.dubbo.rpc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class RpcResult
/*     */   implements Result, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6925924956850004727L;
/*     */   private Object result;
/*     */   private Throwable exception;
/*  36 */   private Map<String, String> attachments = new HashMap();
/*     */ 
/*     */   public RpcResult() {
/*     */   }
/*     */ 
/*     */   public RpcResult(Object result) {
/*  42 */     this.result = result;
/*     */   }
/*     */ 
/*     */   public RpcResult(Throwable exception) {
/*  46 */     this.exception = exception;
/*     */   }
/*     */ 
/*     */   public Object recreate() throws Throwable {
/*  50 */     if (this.exception != null) {
/*  51 */       throw this.exception;
/*     */     }
/*  53 */     return this.result;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Object getResult()
/*     */   {
/*  62 */     return getValue();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setResult(Object result)
/*     */   {
/*  71 */     setValue(result);
/*     */   }
/*     */ 
/*     */   public Object getValue() {
/*  75 */     return this.result;
/*     */   }
/*     */ 
/*     */   public void setValue(Object value) {
/*  79 */     this.result = value;
/*     */   }
/*     */ 
/*     */   public Throwable getException() {
/*  83 */     return this.exception;
/*     */   }
/*     */ 
/*     */   public void setException(Throwable e) {
/*  87 */     this.exception = e;
/*     */   }
/*     */ 
/*     */   public boolean hasException() {
/*  91 */     return this.exception != null;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getAttachments() {
/*  95 */     return this.attachments;
/*     */   }
/*     */ 
/*     */   public String getAttachment(String key) {
/*  99 */     return (String)this.attachments.get(key);
/*     */   }
/*     */ 
/*     */   public String getAttachment(String key, String defaultValue) {
/* 103 */     String result = (String)this.attachments.get(key);
/* 104 */     if ((result == null) || (result.length() == 0)) {
/* 105 */       result = defaultValue;
/*     */     }
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAttachments(Map<String, String> map) {
/* 111 */     if ((map != null) && (map.size() > 0))
/* 112 */       this.attachments.putAll(map);
/*     */   }
/*     */ 
/*     */   public void setAttachment(String key, String value)
/*     */   {
/* 117 */     this.attachments.put(key, value);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 122 */     return "RpcResult [result=" + this.result + ", exception=" + this.exception + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.RpcResult
 * JD-Core Version:    0.6.2
 */