/*     */ package com.alibaba.dubbo.rpc;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ public class RpcStatus
/*     */ {
/*  35 */   private static final ConcurrentMap<String, RpcStatus> SERVICE_STATISTICS = new ConcurrentHashMap();
/*     */ 
/*  37 */   private static final ConcurrentMap<String, ConcurrentMap<String, RpcStatus>> METHOD_STATISTICS = new ConcurrentHashMap();
/*     */ 
/* 140 */   private final ConcurrentMap<String, Object> values = new ConcurrentHashMap();
/*     */ 
/* 142 */   private final AtomicInteger active = new AtomicInteger();
/*     */ 
/* 144 */   private final AtomicLong total = new AtomicLong();
/*     */ 
/* 146 */   private final AtomicInteger failed = new AtomicInteger();
/*     */ 
/* 148 */   private final AtomicLong totalElapsed = new AtomicLong();
/*     */ 
/* 150 */   private final AtomicLong failedElapsed = new AtomicLong();
/*     */ 
/* 152 */   private final AtomicLong maxElapsed = new AtomicLong();
/*     */ 
/* 154 */   private final AtomicLong failedMaxElapsed = new AtomicLong();
/*     */ 
/* 156 */   private final AtomicLong succeededMaxElapsed = new AtomicLong();
/*     */ 
/*     */   public static RpcStatus getStatus(URL url)
/*     */   {
/*  45 */     String uri = url.toIdentityString();
/*  46 */     RpcStatus status = (RpcStatus)SERVICE_STATISTICS.get(uri);
/*  47 */     if (status == null) {
/*  48 */       SERVICE_STATISTICS.putIfAbsent(uri, new RpcStatus());
/*  49 */       status = (RpcStatus)SERVICE_STATISTICS.get(uri);
/*     */     }
/*  51 */     return status;
/*     */   }
/*     */ 
/*     */   public static void removeStatus(URL url)
/*     */   {
/*  59 */     String uri = url.toIdentityString();
/*  60 */     SERVICE_STATISTICS.remove(uri);
/*     */   }
/*     */ 
/*     */   public static RpcStatus getStatus(URL url, String methodName)
/*     */   {
/*  70 */     String uri = url.toIdentityString();
/*  71 */     ConcurrentMap map = (ConcurrentMap)METHOD_STATISTICS.get(uri);
/*  72 */     if (map == null) {
/*  73 */       METHOD_STATISTICS.putIfAbsent(uri, new ConcurrentHashMap());
/*  74 */       map = (ConcurrentMap)METHOD_STATISTICS.get(uri);
/*     */     }
/*  76 */     RpcStatus status = (RpcStatus)map.get(methodName);
/*  77 */     if (status == null) {
/*  78 */       map.putIfAbsent(methodName, new RpcStatus());
/*  79 */       status = (RpcStatus)map.get(methodName);
/*     */     }
/*  81 */     return status;
/*     */   }
/*     */ 
/*     */   public static void removeStatus(URL url, String methodName)
/*     */   {
/*  89 */     String uri = url.toIdentityString();
/*  90 */     ConcurrentMap map = (ConcurrentMap)METHOD_STATISTICS.get(uri);
/*  91 */     if (map != null)
/*  92 */       map.remove(methodName);
/*     */   }
/*     */ 
/*     */   public static void beginCount(URL url, String methodName)
/*     */   {
/* 101 */     beginCount(getStatus(url));
/* 102 */     beginCount(getStatus(url, methodName));
/*     */   }
/*     */ 
/*     */   private static void beginCount(RpcStatus status) {
/* 106 */     status.active.incrementAndGet();
/*     */   }
/*     */ 
/*     */   public static void endCount(URL url, String methodName, long elapsed, boolean succeeded)
/*     */   {
/* 116 */     endCount(getStatus(url), elapsed, succeeded);
/* 117 */     endCount(getStatus(url, methodName), elapsed, succeeded);
/*     */   }
/*     */ 
/*     */   private static void endCount(RpcStatus status, long elapsed, boolean succeeded) {
/* 121 */     status.active.decrementAndGet();
/* 122 */     status.total.incrementAndGet();
/* 123 */     status.totalElapsed.addAndGet(elapsed);
/* 124 */     if (status.maxElapsed.get() < elapsed) {
/* 125 */       status.maxElapsed.set(elapsed);
/*     */     }
/* 127 */     if (succeeded) {
/* 128 */       if (status.succeededMaxElapsed.get() < elapsed)
/* 129 */         status.succeededMaxElapsed.set(elapsed);
/*     */     }
/*     */     else {
/* 132 */       status.failed.incrementAndGet();
/* 133 */       status.failedElapsed.addAndGet(elapsed);
/* 134 */       if (status.failedMaxElapsed.get() < elapsed)
/* 135 */         status.failedMaxElapsed.set(elapsed);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void set(String key, Object value)
/*     */   {
/* 167 */     this.values.put(key, value);
/*     */   }
/*     */ 
/*     */   public Object get(String key)
/*     */   {
/* 177 */     return this.values.get(key);
/*     */   }
/*     */ 
/*     */   public int getActive()
/*     */   {
/* 186 */     return this.active.get();
/*     */   }
/*     */ 
/*     */   public long getTotal()
/*     */   {
/* 195 */     return this.total.longValue();
/*     */   }
/*     */ 
/*     */   public long getTotalElapsed()
/*     */   {
/* 204 */     return this.totalElapsed.get();
/*     */   }
/*     */ 
/*     */   public long getAverageElapsed()
/*     */   {
/* 213 */     long total = getTotal();
/* 214 */     if (total == 0L) {
/* 215 */       return 0L;
/*     */     }
/* 217 */     return getTotalElapsed() / total;
/*     */   }
/*     */ 
/*     */   public long getMaxElapsed()
/*     */   {
/* 226 */     return this.maxElapsed.get();
/*     */   }
/*     */ 
/*     */   public int getFailed()
/*     */   {
/* 235 */     return this.failed.get();
/*     */   }
/*     */ 
/*     */   public long getFailedElapsed()
/*     */   {
/* 244 */     return this.failedElapsed.get();
/*     */   }
/*     */ 
/*     */   public long getFailedAverageElapsed()
/*     */   {
/* 253 */     long failed = getFailed();
/* 254 */     if (failed == 0L) {
/* 255 */       return 0L;
/*     */     }
/* 257 */     return getFailedElapsed() / failed;
/*     */   }
/*     */ 
/*     */   public long getFailedMaxElapsed()
/*     */   {
/* 266 */     return this.failedMaxElapsed.get();
/*     */   }
/*     */ 
/*     */   public long getSucceeded()
/*     */   {
/* 275 */     return getTotal() - getFailed();
/*     */   }
/*     */ 
/*     */   public long getSucceededElapsed()
/*     */   {
/* 284 */     return getTotalElapsed() - getFailedElapsed();
/*     */   }
/*     */ 
/*     */   public long getSucceededAverageElapsed()
/*     */   {
/* 293 */     long succeeded = getSucceeded();
/* 294 */     if (succeeded == 0L) {
/* 295 */       return 0L;
/*     */     }
/* 297 */     return getSucceededElapsed() / succeeded;
/*     */   }
/*     */ 
/*     */   public long getSucceededMaxElapsed()
/*     */   {
/* 306 */     return this.succeededMaxElapsed.get();
/*     */   }
/*     */ 
/*     */   public long getAverageTps()
/*     */   {
/* 315 */     if (getTotalElapsed() >= 1000L) {
/* 316 */       return getTotal() / (getTotalElapsed() / 1000L);
/*     */     }
/* 318 */     return getTotal();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.RpcStatus
 * JD-Core Version:    0.6.2
 */