/*    */ package com.alibaba.dubbo.rpc;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.utils.StringUtils;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ public class StaticContext extends ConcurrentHashMap<Object, Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String SYSTEMNAME = "system";
/*    */   private String name;
/* 33 */   private static final ConcurrentMap<String, StaticContext> context_map = new ConcurrentHashMap();
/*    */ 
/*    */   private StaticContext(String name)
/*    */   {
/* 37 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 41 */     return this.name;
/*    */   }
/*    */ 
/*    */   public static StaticContext getSystemContext() {
/* 45 */     return getContext("system");
/*    */   }
/*    */ 
/*    */   public static StaticContext getContext(String name) {
/* 49 */     StaticContext appContext = (StaticContext)context_map.get(name);
/* 50 */     if (appContext == null) {
/* 51 */       appContext = (StaticContext)context_map.putIfAbsent(name, new StaticContext(name));
/* 52 */       if (appContext == null) {
/* 53 */         appContext = (StaticContext)context_map.get(name);
/*    */       }
/*    */     }
/* 56 */     return appContext;
/*    */   }
/*    */   public static StaticContext remove(String name) {
/* 59 */     return (StaticContext)context_map.remove(name);
/*    */   }
/*    */ 
/*    */   public static String getKey(URL url, String methodName, String suffix) {
/* 63 */     return getKey(url.getServiceKey(), methodName, suffix);
/*    */   }
/*    */   public static String getKey(Map<String, String> paras, String methodName, String suffix) {
/* 66 */     return getKey(StringUtils.getServiceKey(paras), methodName, suffix);
/*    */   }
/*    */   private static String getKey(String servicekey, String methodName, String suffix) {
/* 69 */     StringBuffer sb = new StringBuffer().append(servicekey).append(".").append(methodName).append(".").append(suffix);
/* 70 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.StaticContext
 * JD-Core Version:    0.6.2
 */