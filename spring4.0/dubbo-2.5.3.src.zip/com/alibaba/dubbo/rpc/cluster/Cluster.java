package com.alibaba.dubbo.rpc.cluster;

import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.RpcException;

@SPI("failover")
public abstract interface Cluster
{
  @Adaptive
  public abstract <T> Invoker<T> join(Directory<T> paramDirectory)
    throws RpcException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.Cluster
 * JD-Core Version:    0.6.2
 */