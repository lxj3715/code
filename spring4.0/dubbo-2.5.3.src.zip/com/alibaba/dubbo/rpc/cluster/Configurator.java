package com.alibaba.dubbo.rpc.cluster;

import com.alibaba.dubbo.common.URL;

public abstract interface Configurator extends Comparable<Configurator>
{
  public abstract URL getUrl();

  public abstract URL configure(URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.Configurator
 * JD-Core Version:    0.6.2
 */