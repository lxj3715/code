package com.alibaba.dubbo.rpc.cluster;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;

@SPI
public abstract interface ConfiguratorFactory
{
  @Adaptive({"protocol"})
  public abstract Configurator getConfigurator(URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.ConfiguratorFactory
 * JD-Core Version:    0.6.2
 */