package com.alibaba.dubbo.rpc.cluster;

import com.alibaba.dubbo.common.Node;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.RpcException;
import java.util.List;

public abstract interface Directory<T> extends Node
{
  public abstract Class<T> getInterface();

  public abstract List<Invoker<T>> list(Invocation paramInvocation)
    throws RpcException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.Directory
 * JD-Core Version:    0.6.2
 */