package com.alibaba.dubbo.rpc.cluster;

import com.alibaba.dubbo.common.extension.SPI;

@SPI
public abstract interface Merger<T>
{
  public abstract T merge(T[] paramArrayOfT);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.Merger
 * JD-Core Version:    0.6.2
 */