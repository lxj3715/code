package com.alibaba.dubbo.rpc.cluster;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.RpcException;
import java.util.List;

public abstract interface Router extends Comparable<Router>
{
  public abstract URL getUrl();

  public abstract <T> List<Invoker<T>> route(List<Invoker<T>> paramList, URL paramURL, Invocation paramInvocation)
    throws RpcException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.Router
 * JD-Core Version:    0.6.2
 */