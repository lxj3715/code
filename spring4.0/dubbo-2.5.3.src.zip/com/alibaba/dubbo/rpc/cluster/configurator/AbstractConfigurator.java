/*    */ package com.alibaba.dubbo.rpc.cluster.configurator;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.cluster.Configurator;
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ 
/*    */ public abstract class AbstractConfigurator
/*    */   implements Configurator
/*    */ {
/*    */   private final URL configuratorUrl;
/*    */ 
/*    */   public AbstractConfigurator(URL url)
/*    */   {
/* 36 */     if (url == null) {
/* 37 */       throw new IllegalArgumentException("configurator url == null");
/*    */     }
/* 39 */     this.configuratorUrl = url;
/*    */   }
/*    */ 
/*    */   public URL getUrl() {
/* 43 */     return this.configuratorUrl;
/*    */   }
/*    */ 
/*    */   public URL configure(URL url) {
/* 47 */     if ((this.configuratorUrl == null) || (this.configuratorUrl.getHost() == null) || (url == null) || (url.getHost() == null))
/*    */     {
/* 49 */       return url;
/*    */     }
/* 51 */     if (("0.0.0.0".equals(this.configuratorUrl.getHost())) || (url.getHost().equals(this.configuratorUrl.getHost())))
/*    */     {
/* 53 */       String configApplication = this.configuratorUrl.getParameter("application", this.configuratorUrl.getUsername());
/* 54 */       String currentApplication = url.getParameter("application", url.getUsername());
/* 55 */       if ((configApplication == null) || ("*".equals(configApplication)) || (configApplication.equals(currentApplication)))
/*    */       {
/* 57 */         if ((this.configuratorUrl.getPort() == 0) || (url.getPort() == this.configuratorUrl.getPort())) {
/* 58 */           Set condtionKeys = new HashSet();
/* 59 */           condtionKeys.add("category");
/* 60 */           condtionKeys.add("check");
/* 61 */           condtionKeys.add("dynamic");
/* 62 */           condtionKeys.add("enabled");
/* 63 */           for (Map.Entry entry : this.configuratorUrl.getParameters().entrySet()) {
/* 64 */             String key = (String)entry.getKey();
/* 65 */             String value = (String)entry.getValue();
/* 66 */             if ((key.startsWith("~")) || ("application".equals(key)) || ("side".equals(key)))
/*    */             {
/* 68 */               condtionKeys.add(key);
/* 69 */               if ((value != null) && (!"*".equals(value))) if (!value.equals(url.getParameter(key.startsWith("~") ? key.substring(1) : key)))
/*    */                 {
/* 71 */                   return url;
/*    */                 }
/*    */             }
/*    */           }
/* 75 */           return doConfigure(url, this.configuratorUrl.removeParameters(condtionKeys));
/*    */         }
/*    */       }
/*    */     }
/* 79 */     return url;
/*    */   }
/*    */ 
/*    */   public int compareTo(Configurator o) {
/* 83 */     if (o == null) {
/* 84 */       return -1;
/*    */     }
/* 86 */     return getUrl().getHost().compareTo(o.getUrl().getHost());
/*    */   }
/*    */ 
/*    */   protected abstract URL doConfigure(URL paramURL1, URL paramURL2);
/*    */ 
/*    */   public static void main(String[] args) {
/* 92 */     System.out.println(URL.encode("timeout=100"));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.configurator.AbstractConfigurator
 * JD-Core Version:    0.6.2
 */