/*    */ package com.alibaba.dubbo.rpc.cluster.configurator.absent;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.cluster.Configurator;
/*    */ import com.alibaba.dubbo.rpc.cluster.ConfiguratorFactory;
/*    */ 
/*    */ public class AbsentConfiguratorFactory
/*    */   implements ConfiguratorFactory
/*    */ {
/*    */   public Configurator getConfigurator(URL url)
/*    */   {
/* 30 */     return new AbsentConfigurator(url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.configurator.absent.AbsentConfiguratorFactory
 * JD-Core Version:    0.6.2
 */