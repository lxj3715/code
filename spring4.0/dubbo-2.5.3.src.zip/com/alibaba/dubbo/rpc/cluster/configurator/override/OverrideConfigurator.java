/*    */ package com.alibaba.dubbo.rpc.cluster.configurator.override;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.cluster.configurator.AbstractConfigurator;
/*    */ 
/*    */ public class OverrideConfigurator extends AbstractConfigurator
/*    */ {
/*    */   public OverrideConfigurator(URL url)
/*    */   {
/* 29 */     super(url);
/*    */   }
/*    */ 
/*    */   public URL doConfigure(URL currentUrl, URL configUrl) {
/* 33 */     return currentUrl.addParameters(configUrl.getParameters());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.configurator.override.OverrideConfigurator
 * JD-Core Version:    0.6.2
 */