/*    */ package com.alibaba.dubbo.rpc.cluster.configurator.override;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.cluster.Configurator;
/*    */ import com.alibaba.dubbo.rpc.cluster.ConfiguratorFactory;
/*    */ 
/*    */ public class OverrideConfiguratorFactory
/*    */   implements ConfiguratorFactory
/*    */ {
/*    */   public Configurator getConfigurator(URL url)
/*    */   {
/* 30 */     return new OverrideConfigurator(url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.configurator.override.OverrideConfiguratorFactory
 * JD-Core Version:    0.6.2
 */