/*     */ package com.alibaba.dubbo.rpc.cluster.directory;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*     */ import com.alibaba.dubbo.rpc.cluster.Router;
/*     */ import com.alibaba.dubbo.rpc.cluster.RouterFactory;
/*     */ import com.alibaba.dubbo.rpc.cluster.router.MockInvokersSelector;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class AbstractDirectory<T>
/*     */   implements Directory<T>
/*     */ {
/*  43 */   private static final Logger logger = LoggerFactory.getLogger(AbstractDirectory.class);
/*     */   private final URL url;
/*  47 */   private volatile boolean destroyed = false;
/*     */   private volatile URL consumerUrl;
/*     */   private volatile List<Router> routers;
/*     */ 
/*     */   public AbstractDirectory(URL url)
/*     */   {
/*  54 */     this(url, null);
/*     */   }
/*     */ 
/*     */   public AbstractDirectory(URL url, List<Router> routers) {
/*  58 */     this(url, url, routers);
/*     */   }
/*     */ 
/*     */   public AbstractDirectory(URL url, URL consumerUrl, List<Router> routers) {
/*  62 */     if (url == null)
/*  63 */       throw new IllegalArgumentException("url == null");
/*  64 */     this.url = url;
/*  65 */     this.consumerUrl = consumerUrl;
/*  66 */     setRouters(routers);
/*     */   }
/*     */ 
/*     */   public List<Invoker<T>> list(Invocation invocation) throws RpcException {
/*  70 */     if (this.destroyed) {
/*  71 */       throw new RpcException("Directory already destroyed .url: " + getUrl());
/*     */     }
/*  73 */     List invokers = doList(invocation);
/*  74 */     List localRouters = this.routers;
/*  75 */     if ((localRouters != null) && (localRouters.size() > 0)) {
/*  76 */       for (Router router : localRouters) {
/*     */         try {
/*  78 */           if ((router.getUrl() == null) || (router.getUrl().getParameter("runtime", true)))
/*  79 */             invokers = router.route(invokers, getConsumerUrl(), invocation);
/*     */         }
/*     */         catch (Throwable t) {
/*  82 */           logger.error("Failed to execute router: " + getUrl() + ", cause: " + t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/*  86 */     return invokers;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  90 */     return this.url;
/*     */   }
/*     */ 
/*     */   public List<Router> getRouters() {
/*  94 */     return this.routers;
/*     */   }
/*     */ 
/*     */   public URL getConsumerUrl() {
/*  98 */     return this.consumerUrl;
/*     */   }
/*     */ 
/*     */   public void setConsumerUrl(URL consumerUrl) {
/* 102 */     this.consumerUrl = consumerUrl;
/*     */   }
/*     */ 
/*     */   protected void setRouters(List<Router> routers)
/*     */   {
/* 107 */     routers = routers == null ? new ArrayList() : new ArrayList(routers);
/*     */ 
/* 109 */     String routerkey = this.url.getParameter("router");
/* 110 */     if ((routerkey != null) && (routerkey.length() > 0)) {
/* 111 */       RouterFactory routerFactory = (RouterFactory)ExtensionLoader.getExtensionLoader(RouterFactory.class).getExtension(routerkey);
/* 112 */       routers.add(routerFactory.getRouter(this.url));
/*     */     }
/*     */ 
/* 115 */     routers.add(new MockInvokersSelector());
/* 116 */     Collections.sort(routers);
/* 117 */     this.routers = routers;
/*     */   }
/*     */ 
/*     */   public boolean isDestroyed() {
/* 121 */     return this.destroyed;
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 125 */     this.destroyed = true;
/*     */   }
/*     */ 
/*     */   protected abstract List<Invoker<T>> doList(Invocation paramInvocation)
/*     */     throws RpcException;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.directory.AbstractDirectory
 * JD-Core Version:    0.6.2
 */