/*    */ package com.alibaba.dubbo.rpc.cluster.directory;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Router;
/*    */ import java.util.List;
/*    */ 
/*    */ public class StaticDirectory<T> extends AbstractDirectory<T>
/*    */ {
/*    */   private final List<Invoker<T>> invokers;
/*    */ 
/*    */   public StaticDirectory(List<Invoker<T>> invokers)
/*    */   {
/* 36 */     this(null, invokers, null);
/*    */   }
/*    */ 
/*    */   public StaticDirectory(List<Invoker<T>> invokers, List<Router> routers) {
/* 40 */     this(null, invokers, routers);
/*    */   }
/*    */ 
/*    */   public StaticDirectory(URL url, List<Invoker<T>> invokers) {
/* 44 */     this(url, invokers, null);
/*    */   }
/*    */ 
/*    */   public StaticDirectory(URL url, List<Invoker<T>> invokers, List<Router> routers) {
/* 48 */     super((url == null) && (invokers != null) && (invokers.size() > 0) ? ((Invoker)invokers.get(0)).getUrl() : url, routers);
/* 49 */     if ((invokers == null) || (invokers.size() == 0))
/* 50 */       throw new IllegalArgumentException("invokers == null");
/* 51 */     this.invokers = invokers;
/*    */   }
/*    */ 
/*    */   public Class<T> getInterface() {
/* 55 */     return ((Invoker)this.invokers.get(0)).getInterface();
/*    */   }
/*    */ 
/*    */   public boolean isAvailable() {
/* 59 */     if (isDestroyed()) {
/* 60 */       return false;
/*    */     }
/* 62 */     for (Invoker invoker : this.invokers) {
/* 63 */       if (invoker.isAvailable()) {
/* 64 */         return true;
/*    */       }
/*    */     }
/* 67 */     return false;
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 71 */     if (isDestroyed()) {
/* 72 */       return;
/*    */     }
/* 74 */     super.destroy();
/* 75 */     for (Invoker invoker : this.invokers) {
/* 76 */       invoker.destroy();
/*    */     }
/* 78 */     this.invokers.clear();
/*    */   }
/*    */ 
/*    */   protected List<Invoker<T>> doList(Invocation invocation)
/*    */     throws RpcException
/*    */   {
/* 84 */     return this.invokers;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.directory.StaticDirectory
 * JD-Core Version:    0.6.2
 */