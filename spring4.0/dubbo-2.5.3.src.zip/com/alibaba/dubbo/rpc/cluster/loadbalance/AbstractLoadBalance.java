/*    */ package com.alibaba.dubbo.rpc.cluster.loadbalance;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.cluster.LoadBalance;
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class AbstractLoadBalance
/*    */   implements LoadBalance
/*    */ {
/*    */   public <T> Invoker<T> select(List<Invoker<T>> invokers, URL url, Invocation invocation)
/*    */   {
/* 34 */     if ((invokers == null) || (invokers.size() == 0))
/* 35 */       return null;
/* 36 */     if (invokers.size() == 1)
/* 37 */       return (Invoker)invokers.get(0);
/* 38 */     return doSelect(invokers, url, invocation);
/*    */   }
/*    */ 
/*    */   protected abstract <T> Invoker<T> doSelect(List<Invoker<T>> paramList, URL paramURL, Invocation paramInvocation);
/*    */ 
/*    */   protected int getWeight(Invoker<?> invoker, Invocation invocation) {
/* 44 */     int weight = invoker.getUrl().getMethodParameter(invocation.getMethodName(), "weight", 100);
/* 45 */     if (weight > 0) {
/* 46 */       long timestamp = invoker.getUrl().getParameter("timestamp", 0L);
/* 47 */       if (timestamp > 0L) {
/* 48 */         int uptime = (int)(System.currentTimeMillis() - timestamp);
/* 49 */         int warmup = invoker.getUrl().getParameter("warmup", 600000);
/* 50 */         if ((uptime > 0) && (uptime < warmup)) {
/* 51 */           weight = calculateWarmupWeight(uptime, warmup, weight);
/*    */         }
/*    */       }
/*    */     }
/* 55 */     return weight;
/*    */   }
/*    */ 
/*    */   static int calculateWarmupWeight(int uptime, int warmup, int weight) {
/* 59 */     int ww = (int)(uptime / (warmup / weight));
/* 60 */     return ww > weight ? weight : ww < 1 ? 1 : ww;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.loadbalance.AbstractLoadBalance
 * JD-Core Version:    0.6.2
 */