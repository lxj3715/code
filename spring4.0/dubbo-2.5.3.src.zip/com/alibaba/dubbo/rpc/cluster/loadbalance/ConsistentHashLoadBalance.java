/*     */ package com.alibaba.dubbo.rpc.cluster.loadbalance;
/*     */ 
/*     */ import com.alibaba.dubbo.common.Constants;
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.List;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class ConsistentHashLoadBalance extends AbstractLoadBalance
/*     */ {
/*     */   private final ConcurrentMap<String, ConsistentHashSelector<?>> selectors;
/*     */ 
/*     */   public ConsistentHashLoadBalance()
/*     */   {
/*  39 */     this.selectors = new ConcurrentHashMap();
/*     */   }
/*     */ 
/*     */   protected <T> Invoker<T> doSelect(List<Invoker<T>> invokers, URL url, Invocation invocation)
/*     */   {
/*  44 */     String key = ((Invoker)invokers.get(0)).getUrl().getServiceKey() + "." + invocation.getMethodName();
/*  45 */     int identityHashCode = System.identityHashCode(invokers);
/*  46 */     ConsistentHashSelector selector = (ConsistentHashSelector)this.selectors.get(key);
/*  47 */     if ((selector == null) || (selector.getIdentityHashCode() != identityHashCode)) {
/*  48 */       this.selectors.put(key, new ConsistentHashSelector(invokers, invocation.getMethodName(), identityHashCode));
/*  49 */       selector = (ConsistentHashSelector)this.selectors.get(key);
/*     */     }
/*  51 */     return selector.select(invocation);
/*     */   }
/*     */ 
/*     */   private static final class ConsistentHashSelector<T>
/*     */   {
/*     */     private final TreeMap<Long, Invoker<T>> virtualInvokers;
/*     */     private final int replicaNumber;
/*     */     private final int identityHashCode;
/*     */     private final int[] argumentIndex;
/*     */ 
/*     */     public ConsistentHashSelector(List<Invoker<T>> invokers, String methodName, int identityHashCode) {
/*  65 */       this.virtualInvokers = new TreeMap();
/*  66 */       this.identityHashCode = System.identityHashCode(invokers);
/*  67 */       URL url = ((Invoker)invokers.get(0)).getUrl();
/*  68 */       this.replicaNumber = url.getMethodParameter(methodName, "hash.nodes", 160);
/*  69 */       String[] index = Constants.COMMA_SPLIT_PATTERN.split(url.getMethodParameter(methodName, "hash.arguments", "0"));
/*  70 */       this.argumentIndex = new int[index.length];
/*  71 */       for (int i = 0; i < index.length; i++) {
/*  72 */         this.argumentIndex[i] = Integer.parseInt(index[i]);
/*     */       }
/*  74 */       for (Invoker invoker : invokers)
/*  75 */         for (int i = 0; i < this.replicaNumber / 4; i++) {
/*  76 */           byte[] digest = md5(invoker.getUrl().toFullString() + i);
/*  77 */           for (int h = 0; h < 4; h++) {
/*  78 */             long m = hash(digest, h);
/*  79 */             this.virtualInvokers.put(Long.valueOf(m), invoker);
/*     */           }
/*     */         }
/*     */     }
/*     */ 
/*     */     public int getIdentityHashCode()
/*     */     {
/*  86 */       return this.identityHashCode;
/*     */     }
/*     */ 
/*     */     public Invoker<T> select(Invocation invocation) {
/*  90 */       String key = toKey(invocation.getArguments());
/*  91 */       byte[] digest = md5(key);
/*  92 */       Invoker invoker = sekectForKey(hash(digest, 0));
/*  93 */       return invoker;
/*     */     }
/*     */ 
/*     */     private String toKey(Object[] args) {
/*  97 */       StringBuilder buf = new StringBuilder();
/*  98 */       for (int i : this.argumentIndex) {
/*  99 */         if ((i >= 0) && (i < args.length)) {
/* 100 */           buf.append(args[i]);
/*     */         }
/*     */       }
/* 103 */       return buf.toString();
/*     */     }
/*     */ 
/*     */     private Invoker<T> sekectForKey(long hash)
/*     */     {
/* 108 */       Long key = Long.valueOf(hash);
/* 109 */       if (!this.virtualInvokers.containsKey(key)) {
/* 110 */         SortedMap tailMap = this.virtualInvokers.tailMap(key);
/* 111 */         if (tailMap.isEmpty())
/* 112 */           key = (Long)this.virtualInvokers.firstKey();
/*     */         else {
/* 114 */           key = (Long)tailMap.firstKey();
/*     */         }
/*     */       }
/* 117 */       Invoker invoker = (Invoker)this.virtualInvokers.get(key);
/* 118 */       return invoker;
/*     */     }
/*     */ 
/*     */     private long hash(byte[] digest, int number) {
/* 122 */       return ((digest[(3 + number * 4)] & 0xFF) << 24 | (digest[(2 + number * 4)] & 0xFF) << 16 | (digest[(1 + number * 4)] & 0xFF) << 8 | digest[(0 + number * 4)] & 0xFF) & 0xFFFFFFFF;
/*     */     }
/*     */ 
/*     */     private byte[] md5(String value)
/*     */     {
/*     */       MessageDigest md5;
/*     */       try
/*     */       {
/* 132 */         md5 = MessageDigest.getInstance("MD5");
/*     */       } catch (NoSuchAlgorithmException e) {
/* 134 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/* 136 */       md5.reset();
/* 137 */       byte[] bytes = null;
/*     */       try {
/* 139 */         bytes = value.getBytes("UTF-8");
/*     */       } catch (UnsupportedEncodingException e) {
/* 141 */         throw new IllegalStateException(e.getMessage(), e);
/*     */       }
/* 143 */       md5.update(bytes);
/* 144 */       return md5.digest();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.loadbalance.ConsistentHashLoadBalance
 * JD-Core Version:    0.6.2
 */