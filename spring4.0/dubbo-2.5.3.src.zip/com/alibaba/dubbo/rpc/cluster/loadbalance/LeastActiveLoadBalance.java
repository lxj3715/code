/*    */ package com.alibaba.dubbo.rpc.cluster.loadbalance;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcStatus;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class LeastActiveLoadBalance extends AbstractLoadBalance
/*    */ {
/*    */   public static final String NAME = "leastactive";
/* 36 */   private final Random random = new Random();
/*    */ 
/*    */   protected <T> Invoker<T> doSelect(List<Invoker<T>> invokers, URL url, Invocation invocation) {
/* 39 */     int length = invokers.size();
/* 40 */     int leastActive = -1;
/* 41 */     int leastCount = 0;
/* 42 */     int[] leastIndexs = new int[length];
/* 43 */     int totalWeight = 0;
/* 44 */     int firstWeight = 0;
/* 45 */     boolean sameWeight = true;
/* 46 */     for (int i = 0; i < length; i++) {
/* 47 */       Invoker invoker = (Invoker)invokers.get(i);
/* 48 */       int active = RpcStatus.getStatus(invoker.getUrl(), invocation.getMethodName()).getActive();
/* 49 */       int weight = invoker.getUrl().getMethodParameter(invocation.getMethodName(), "weight", 100);
/* 50 */       if ((leastActive == -1) || (active < leastActive)) {
/* 51 */         leastActive = active;
/* 52 */         leastCount = 1;
/* 53 */         leastIndexs[0] = i;
/* 54 */         totalWeight = weight;
/* 55 */         firstWeight = weight;
/* 56 */         sameWeight = true;
/* 57 */       } else if (active == leastActive) {
/* 58 */         leastIndexs[(leastCount++)] = i;
/* 59 */         totalWeight += weight;
/*    */ 
/* 61 */         if ((sameWeight) && (i > 0) && (weight != firstWeight))
/*    */         {
/* 63 */           sameWeight = false;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 68 */     if (leastCount == 1)
/*    */     {
/* 70 */       return (Invoker)invokers.get(leastIndexs[0]);
/*    */     }
/* 72 */     if ((!sameWeight) && (totalWeight > 0))
/*    */     {
/* 74 */       int offsetWeight = this.random.nextInt(totalWeight);
/*    */ 
/* 76 */       for (int i = 0; i < leastCount; i++) {
/* 77 */         int leastIndex = leastIndexs[i];
/* 78 */         offsetWeight -= getWeight((Invoker)invokers.get(leastIndex), invocation);
/* 79 */         if (offsetWeight <= 0) {
/* 80 */           return (Invoker)invokers.get(leastIndex);
/*    */         }
/*    */       }
/*    */     }
/* 84 */     return (Invoker)invokers.get(leastIndexs[this.random.nextInt(leastCount)]);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.loadbalance.LeastActiveLoadBalance
 * JD-Core Version:    0.6.2
 */