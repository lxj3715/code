/*    */ package com.alibaba.dubbo.rpc.cluster.loadbalance;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class RandomLoadBalance extends AbstractLoadBalance
/*    */ {
/*    */   public static final String NAME = "random";
/* 35 */   private final Random random = new Random();
/*    */ 
/*    */   protected <T> Invoker<T> doSelect(List<Invoker<T>> invokers, URL url, Invocation invocation) {
/* 38 */     int length = invokers.size();
/* 39 */     int totalWeight = 0;
/* 40 */     boolean sameWeight = true;
/* 41 */     for (int i = 0; i < length; i++) {
/* 42 */       int weight = getWeight((Invoker)invokers.get(i), invocation);
/* 43 */       totalWeight += weight;
/* 44 */       if ((sameWeight) && (i > 0) && (weight != getWeight((Invoker)invokers.get(i - 1), invocation)))
/*    */       {
/* 46 */         sameWeight = false;
/*    */       }
/*    */     }
/* 49 */     if ((totalWeight > 0) && (!sameWeight))
/*    */     {
/* 51 */       int offset = this.random.nextInt(totalWeight);
/*    */ 
/* 53 */       for (int i = 0; i < length; i++) {
/* 54 */         offset -= getWeight((Invoker)invokers.get(i), invocation);
/* 55 */         if (offset < 0) {
/* 56 */           return (Invoker)invokers.get(i);
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 61 */     return (Invoker)invokers.get(this.random.nextInt(length));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.loadbalance.RandomLoadBalance
 * JD-Core Version:    0.6.2
 */