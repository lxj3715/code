/*    */ package com.alibaba.dubbo.rpc.cluster.loadbalance;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.utils.AtomicPositiveInteger;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ public class RoundRobinLoadBalance extends AbstractLoadBalance
/*    */ {
/*    */   public static final String NAME = "roundrobin";
/* 38 */   private final ConcurrentMap<String, AtomicPositiveInteger> sequences = new ConcurrentHashMap();
/*    */ 
/* 40 */   private final ConcurrentMap<String, AtomicPositiveInteger> weightSequences = new ConcurrentHashMap();
/*    */ 
/*    */   protected <T> Invoker<T> doSelect(List<Invoker<T>> invokers, URL url, Invocation invocation) {
/* 43 */     String key = ((Invoker)invokers.get(0)).getUrl().getServiceKey() + "." + invocation.getMethodName();
/* 44 */     int length = invokers.size();
/* 45 */     int maxWeight = 0;
/* 46 */     int minWeight = 2147483647;
/* 47 */     for (int i = 0; i < length; i++) {
/* 48 */       int weight = getWeight((Invoker)invokers.get(i), invocation);
/* 49 */       maxWeight = Math.max(maxWeight, weight);
/* 50 */       minWeight = Math.min(minWeight, weight);
/*    */     }
/* 52 */     if ((maxWeight > 0) && (minWeight < maxWeight)) {
/* 53 */       AtomicPositiveInteger weightSequence = (AtomicPositiveInteger)this.weightSequences.get(key);
/* 54 */       if (weightSequence == null) {
/* 55 */         this.weightSequences.putIfAbsent(key, new AtomicPositiveInteger());
/* 56 */         weightSequence = (AtomicPositiveInteger)this.weightSequences.get(key);
/*    */       }
/* 58 */       int currentWeight = weightSequence.getAndIncrement() % maxWeight;
/* 59 */       List weightInvokers = new ArrayList();
/* 60 */       for (Invoker invoker : invokers) {
/* 61 */         if (getWeight(invoker, invocation) > currentWeight) {
/* 62 */           weightInvokers.add(invoker);
/*    */         }
/*    */       }
/* 65 */       int weightLength = weightInvokers.size();
/* 66 */       if (weightLength == 1)
/* 67 */         return (Invoker)weightInvokers.get(0);
/* 68 */       if (weightLength > 1) {
/* 69 */         invokers = weightInvokers;
/* 70 */         length = invokers.size();
/*    */       }
/*    */     }
/* 73 */     AtomicPositiveInteger sequence = (AtomicPositiveInteger)this.sequences.get(key);
/* 74 */     if (sequence == null) {
/* 75 */       this.sequences.putIfAbsent(key, new AtomicPositiveInteger());
/* 76 */       sequence = (AtomicPositiveInteger)this.sequences.get(key);
/*    */     }
/*    */ 
/* 79 */     return (Invoker)invokers.get(sequence.getAndIncrement() % length);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.loadbalance.RoundRobinLoadBalance
 * JD-Core Version:    0.6.2
 */