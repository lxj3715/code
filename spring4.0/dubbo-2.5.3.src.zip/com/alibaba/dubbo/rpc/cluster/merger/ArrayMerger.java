/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ import java.lang.reflect.Array;
/*    */ 
/*    */ public class ArrayMerger
/*    */   implements Merger<Object[]>
/*    */ {
/* 27 */   public static final ArrayMerger INSTANCE = new ArrayMerger();
/*    */ 
/*    */   public Object[] merge(Object[][] others) {
/* 30 */     if (others.length == 0) {
/* 31 */       return null;
/*    */     }
/* 33 */     int totalLen = 0;
/* 34 */     for (int i = 0; i < others.length; i++) {
/* 35 */       Object item = others[i];
/* 36 */       if ((item != null) && (item.getClass().isArray()))
/* 37 */         totalLen += Array.getLength(item);
/*    */       else {
/* 39 */         throw new IllegalArgumentException(32 + (i + 1) + "th argument is not an array");
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 45 */     if (totalLen == 0) {
/* 46 */       return null;
/*    */     }
/*    */ 
/* 49 */     Class type = others[0].getClass().getComponentType();
/*    */ 
/* 51 */     Object result = Array.newInstance(type, totalLen);
/* 52 */     int index = 0;
/* 53 */     for (Object array : others) {
/* 54 */       for (int i = 0; i < Array.getLength(array); i++) {
/* 55 */         Array.set(result, index++, Array.get(array, i));
/*    */       }
/*    */     }
/* 58 */     return (Object[])result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.ArrayMerger
 * JD-Core Version:    0.6.2
 */