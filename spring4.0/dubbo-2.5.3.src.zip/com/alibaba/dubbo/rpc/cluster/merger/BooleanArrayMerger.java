/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ 
/*    */ public class BooleanArrayMerger
/*    */   implements Merger<boolean[]>
/*    */ {
/*    */   public boolean[] merge(boolean[][] items)
/*    */   {
/* 27 */     int totalLen = 0;
/* 28 */     for (boolean[] array : items) {
/* 29 */       totalLen += array.length;
/*    */     }
/* 31 */     boolean[] result = new boolean[totalLen];
/* 32 */     int index = 0;
/* 33 */     for (boolean[] array : items) {
/* 34 */       for (boolean item : array) {
/* 35 */         result[(index++)] = item;
/*    */       }
/*    */     }
/* 38 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.BooleanArrayMerger
 * JD-Core Version:    0.6.2
 */