/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ 
/*    */ public class CharArrayMerger
/*    */   implements Merger<char[]>
/*    */ {
/*    */   public char[] merge(char[][] items)
/*    */   {
/* 27 */     int total = 0;
/* 28 */     for (char[] array : items) {
/* 29 */       total += array.length;
/*    */     }
/* 31 */     char[] result = new char[total];
/* 32 */     int index = 0;
/* 33 */     for (char[] array : items) {
/* 34 */       for (char item : array) {
/* 35 */         result[(index++)] = item;
/*    */       }
/*    */     }
/* 38 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.CharArrayMerger
 * JD-Core Version:    0.6.2
 */