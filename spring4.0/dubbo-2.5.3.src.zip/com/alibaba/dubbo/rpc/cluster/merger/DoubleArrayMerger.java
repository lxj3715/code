/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ 
/*    */ public class DoubleArrayMerger
/*    */   implements Merger<double[]>
/*    */ {
/*    */   public double[] merge(double[][] items)
/*    */   {
/* 27 */     int total = 0;
/* 28 */     for (double[] array : items) {
/* 29 */       total += array.length;
/*    */     }
/* 31 */     double[] result = new double[total];
/* 32 */     int index = 0;
/* 33 */     for (double[] array : items) {
/* 34 */       for (double item : array) {
/* 35 */         result[(index++)] = item;
/*    */       }
/*    */     }
/* 38 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.DoubleArrayMerger
 * JD-Core Version:    0.6.2
 */