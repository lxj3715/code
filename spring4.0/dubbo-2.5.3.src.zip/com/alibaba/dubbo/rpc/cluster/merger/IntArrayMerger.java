/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ 
/*    */ public class IntArrayMerger
/*    */   implements Merger<int[]>
/*    */ {
/*    */   public int[] merge(int[][] items)
/*    */   {
/* 27 */     int totalLen = 0;
/* 28 */     for (int[] item : items) {
/* 29 */       totalLen += item.length;
/*    */     }
/* 31 */     int[] result = new int[totalLen];
/* 32 */     int index = 0;
/* 33 */     for (int[] item : items) {
/* 34 */       for (int i : item) {
/* 35 */         result[(index++)] = i;
/*    */       }
/*    */     }
/* 38 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.IntArrayMerger
 * JD-Core Version:    0.6.2
 */