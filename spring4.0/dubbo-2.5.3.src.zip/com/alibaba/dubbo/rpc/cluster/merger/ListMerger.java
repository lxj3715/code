/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ListMerger
/*    */   implements Merger<List<?>>
/*    */ {
/*    */   public List<Object> merge(List<?>[] items)
/*    */   {
/* 30 */     List result = new ArrayList();
/* 31 */     for (List item : items) {
/* 32 */       if (item != null) {
/* 33 */         result.addAll(item);
/*    */       }
/*    */     }
/* 36 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.ListMerger
 * JD-Core Version:    0.6.2
 */