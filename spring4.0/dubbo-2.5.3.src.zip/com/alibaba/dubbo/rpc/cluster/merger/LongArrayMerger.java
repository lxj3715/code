/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ 
/*    */ public class LongArrayMerger
/*    */   implements Merger<long[]>
/*    */ {
/*    */   public long[] merge(long[][] items)
/*    */   {
/* 27 */     int total = 0;
/* 28 */     for (long[] array : items) {
/* 29 */       total += array.length;
/*    */     }
/* 31 */     long[] result = new long[total];
/* 32 */     int index = 0;
/* 33 */     for (long[] array : items) {
/* 34 */       for (long item : array) {
/* 35 */         result[(index++)] = item;
/*    */       }
/*    */     }
/* 38 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.LongArrayMerger
 * JD-Core Version:    0.6.2
 */