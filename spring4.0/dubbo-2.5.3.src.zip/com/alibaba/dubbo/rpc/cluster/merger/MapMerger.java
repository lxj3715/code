/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MapMerger
/*    */   implements Merger<Map<?, ?>>
/*    */ {
/*    */   public Map<?, ?> merge(Map<?, ?>[] items)
/*    */   {
/* 29 */     if (items.length == 0) {
/* 30 */       return null;
/*    */     }
/* 32 */     Map result = new HashMap();
/* 33 */     for (Map item : items) {
/* 34 */       if (item != null) {
/* 35 */         result.putAll(item);
/*    */       }
/*    */     }
/* 38 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.MapMerger
 * JD-Core Version:    0.6.2
 */