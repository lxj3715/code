/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ public class MergerFactory
/*    */ {
/* 32 */   private static final ConcurrentMap<Class<?>, Merger<?>> mergerCache = new ConcurrentHashMap();
/*    */ 
/*    */   public static <T> Merger<T> getMerger(Class<T> returnType)
/*    */   {
/*    */     Merger result;
/* 37 */     if (returnType.isArray()) {
/* 38 */       Class type = returnType.getComponentType();
/* 39 */       Merger result = (Merger)mergerCache.get(type);
/* 40 */       if (result == null) {
/* 41 */         loadMergers();
/* 42 */         result = (Merger)mergerCache.get(type);
/*    */       }
/* 44 */       if ((result == null) && (!type.isPrimitive()))
/* 45 */         result = ArrayMerger.INSTANCE;
/*    */     }
/*    */     else {
/* 48 */       result = (Merger)mergerCache.get(returnType);
/* 49 */       if (result == null) {
/* 50 */         loadMergers();
/* 51 */         result = (Merger)mergerCache.get(returnType);
/*    */       }
/*    */     }
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   static void loadMergers() {
/* 58 */     Set names = ExtensionLoader.getExtensionLoader(Merger.class).getSupportedExtensions();
/*    */ 
/* 60 */     for (String name : names) {
/* 61 */       Merger m = (Merger)ExtensionLoader.getExtensionLoader(Merger.class).getExtension(name);
/* 62 */       mergerCache.putIfAbsent(ReflectUtils.getGenericClass(m.getClass()), m);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.MergerFactory
 * JD-Core Version:    0.6.2
 */