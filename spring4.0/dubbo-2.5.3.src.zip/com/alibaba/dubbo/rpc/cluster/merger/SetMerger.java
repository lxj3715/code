/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class SetMerger
/*    */   implements Merger<Set<?>>
/*    */ {
/*    */   public Set<Object> merge(Set<?>[] items)
/*    */   {
/* 31 */     Set result = new HashSet();
/*    */ 
/* 33 */     for (Set item : items) {
/* 34 */       if (item != null) {
/* 35 */         result.addAll(item);
/*    */       }
/*    */     }
/*    */ 
/* 39 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.SetMerger
 * JD-Core Version:    0.6.2
 */