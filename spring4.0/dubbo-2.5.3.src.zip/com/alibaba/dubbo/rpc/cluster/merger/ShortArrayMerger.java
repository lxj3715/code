/*    */ package com.alibaba.dubbo.rpc.cluster.merger;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*    */ 
/*    */ public class ShortArrayMerger
/*    */   implements Merger<short[]>
/*    */ {
/*    */   public short[] merge(short[][] items)
/*    */   {
/* 27 */     int total = 0;
/* 28 */     for (short[] array : items) {
/* 29 */       total += array.length;
/*    */     }
/* 31 */     short[] result = new short[total];
/* 32 */     int index = 0;
/* 33 */     for (short[] array : items) {
/* 34 */       for (short item : array) {
/* 35 */         result[(index++)] = item;
/*    */       }
/*    */     }
/* 38 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.merger.ShortArrayMerger
 * JD-Core Version:    0.6.2
 */