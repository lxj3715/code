/*    */ package com.alibaba.dubbo.rpc.cluster.router;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Router;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MockInvokersSelector
/*    */   implements Router
/*    */ {
/*    */   public <T> List<Invoker<T>> route(List<Invoker<T>> invokers, URL url, Invocation invocation)
/*    */     throws RpcException
/*    */   {
/* 37 */     if (invocation.getAttachments() == null) {
/* 38 */       return getNormalInvokers(invokers);
/*    */     }
/* 40 */     String value = (String)invocation.getAttachments().get("invocation.need.mock");
/* 41 */     if (value == null)
/* 42 */       return getNormalInvokers(invokers);
/* 43 */     if (Boolean.TRUE.toString().equalsIgnoreCase(value)) {
/* 44 */       return getMockedInvokers(invokers);
/*    */     }
/*    */ 
/* 47 */     return invokers;
/*    */   }
/*    */ 
/*    */   private <T> List<Invoker<T>> getMockedInvokers(List<Invoker<T>> invokers) {
/* 51 */     if (!hasMockProviders(invokers)) {
/* 52 */       return null;
/*    */     }
/* 54 */     List sInvokers = new ArrayList(1);
/* 55 */     for (Invoker invoker : invokers) {
/* 56 */       if (invoker.getUrl().getProtocol().equals("mock")) {
/* 57 */         sInvokers.add(invoker);
/*    */       }
/*    */     }
/* 60 */     return sInvokers;
/*    */   }
/*    */ 
/*    */   private <T> List<Invoker<T>> getNormalInvokers(List<Invoker<T>> invokers) {
/* 64 */     if (!hasMockProviders(invokers)) {
/* 65 */       return invokers;
/*    */     }
/* 67 */     List sInvokers = new ArrayList(invokers.size());
/* 68 */     for (Invoker invoker : invokers) {
/* 69 */       if (!invoker.getUrl().getProtocol().equals("mock")) {
/* 70 */         sInvokers.add(invoker);
/*    */       }
/*    */     }
/* 73 */     return sInvokers;
/*    */   }
/*    */ 
/*    */   private <T> boolean hasMockProviders(List<Invoker<T>> invokers)
/*    */   {
/* 78 */     boolean hasMockProvider = false;
/* 79 */     for (Invoker invoker : invokers) {
/* 80 */       if (invoker.getUrl().getProtocol().equals("mock")) {
/* 81 */         hasMockProvider = true;
/* 82 */         break;
/*    */       }
/*    */     }
/* 85 */     return hasMockProvider;
/*    */   }
/*    */ 
/*    */   public URL getUrl() {
/* 89 */     return null;
/*    */   }
/*    */ 
/*    */   public int compareTo(Router o) {
/* 93 */     return 1;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.router.MockInvokersSelector
 * JD-Core Version:    0.6.2
 */