/*     */ package com.alibaba.dubbo.rpc.cluster.router.condition;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.common.utils.UrlUtils;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.cluster.Router;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class ConditionRouter
/*     */   implements Router, Comparable<Router>
/*     */ {
/*  47 */   private static final Logger logger = LoggerFactory.getLogger(ConditionRouter.class);
/*     */   private final URL url;
/*     */   private final int priority;
/*     */   private final boolean force;
/*     */   private final Map<String, MatchPair> whenCondition;
/*     */   private final Map<String, MatchPair> thenCondition;
/* 145 */   private static Pattern ROUTE_PATTERN = Pattern.compile("([&!=,]*)\\s*([^&!=,\\s]+)");
/*     */ 
/*     */   public ConditionRouter(URL url)
/*     */   {
/*  60 */     this.url = url;
/*  61 */     this.priority = url.getParameter("priority", 0);
/*  62 */     this.force = url.getParameter("force", false);
/*     */     try {
/*  64 */       String rule = url.getParameterAndDecoded("rule");
/*  65 */       if ((rule == null) || (rule.trim().length() == 0)) {
/*  66 */         throw new IllegalArgumentException("Illegal route rule!");
/*     */       }
/*  68 */       rule = rule.replace("consumer.", "").replace("provider.", "");
/*  69 */       int i = rule.indexOf("=>");
/*  70 */       String whenRule = i < 0 ? null : rule.substring(0, i).trim();
/*  71 */       String thenRule = i < 0 ? rule.trim() : rule.substring(i + 2).trim();
/*  72 */       Map when = (StringUtils.isBlank(whenRule)) || ("true".equals(whenRule)) ? new HashMap() : parseRule(whenRule);
/*  73 */       Map then = (StringUtils.isBlank(thenRule)) || ("false".equals(thenRule)) ? null : parseRule(thenRule);
/*     */ 
/*  75 */       this.whenCondition = when;
/*  76 */       this.thenCondition = then;
/*     */     } catch (ParseException e) {
/*  78 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> List<Invoker<T>> route(List<Invoker<T>> invokers, URL url, Invocation invocation) throws RpcException
/*     */   {
/*  84 */     if ((invokers == null) || (invokers.size() == 0))
/*  85 */       return invokers;
/*     */     try
/*     */     {
/*  88 */       if (!matchWhen(url)) {
/*  89 */         return invokers;
/*     */       }
/*  91 */       List result = new ArrayList();
/*  92 */       if (this.thenCondition == null) {
/*  93 */         logger.warn("The current consumer in the service blacklist. consumer: " + NetUtils.getLocalHost() + ", service: " + url.getServiceKey());
/*  94 */         return result;
/*     */       }
/*  96 */       for (Invoker invoker : invokers) {
/*  97 */         if (matchThen(invoker.getUrl(), url)) {
/*  98 */           result.add(invoker);
/*     */         }
/*     */       }
/* 101 */       if (result.size() > 0)
/* 102 */         return result;
/* 103 */       if (this.force) {
/* 104 */         logger.warn("The route result is empty and force execute. consumer: " + NetUtils.getLocalHost() + ", service: " + url.getServiceKey() + ", router: " + url.getParameterAndDecoded("rule"));
/* 105 */         return result;
/*     */       }
/*     */     } catch (Throwable t) {
/* 108 */       logger.error("Failed to execute condition router rule: " + getUrl() + ", invokers: " + invokers + ", cause: " + t.getMessage(), t);
/*     */     }
/* 110 */     return invokers;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/* 114 */     return this.url;
/*     */   }
/*     */ 
/*     */   public int compareTo(Router o) {
/* 118 */     if ((o == null) || (o.getClass() != ConditionRouter.class)) {
/* 119 */       return 1;
/*     */     }
/* 121 */     ConditionRouter c = (ConditionRouter)o;
/* 122 */     return this.priority > c.priority ? 1 : this.priority == c.priority ? this.url.toFullString().compareTo(c.url.toFullString()) : -1;
/*     */   }
/*     */ 
/*     */   public boolean matchWhen(URL url) {
/* 126 */     return matchCondition(this.whenCondition, url, null);
/*     */   }
/*     */ 
/*     */   public boolean matchThen(URL url, URL param) {
/* 130 */     return (this.thenCondition != null) && (matchCondition(this.thenCondition, url, param));
/*     */   }
/*     */ 
/*     */   private boolean matchCondition(Map<String, MatchPair> condition, URL url, URL param) {
/* 134 */     Map sample = url.toMap();
/* 135 */     for (Map.Entry entry : sample.entrySet()) {
/* 136 */       String key = (String)entry.getKey();
/* 137 */       MatchPair pair = (MatchPair)condition.get(key);
/* 138 */       if ((pair != null) && (!pair.isMatch((String)entry.getValue(), param))) {
/* 139 */         return false;
/*     */       }
/*     */     }
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */   private static Map<String, MatchPair> parseRule(String rule)
/*     */     throws ParseException
/*     */   {
/* 149 */     Map condition = new HashMap();
/* 150 */     if (StringUtils.isBlank(rule)) {
/* 151 */       return condition;
/*     */     }
/*     */ 
/* 154 */     MatchPair pair = null;
/*     */ 
/* 156 */     Set values = null;
/* 157 */     Matcher matcher = ROUTE_PATTERN.matcher(rule);
/* 158 */     while (matcher.find()) {
/* 159 */       String separator = matcher.group(1);
/* 160 */       String content = matcher.group(2);
/*     */ 
/* 162 */       if ((separator == null) || (separator.length() == 0)) {
/* 163 */         pair = new MatchPair(null);
/* 164 */         condition.put(content, pair);
/*     */       }
/* 167 */       else if ("&".equals(separator)) {
/* 168 */         if (condition.get(content) == null) {
/* 169 */           pair = new MatchPair(null);
/* 170 */           condition.put(content, pair);
/*     */         } else {
/* 172 */           condition.put(content, pair);
/*     */         }
/*     */ 
/*     */       }
/* 176 */       else if ("=".equals(separator)) {
/* 177 */         if (pair == null) {
/* 178 */           throw new ParseException("Illegal route rule \"" + rule + "\", The error char '" + separator + "' at index " + matcher.start() + " before \"" + content + "\".", matcher.start());
/*     */         }
/*     */ 
/* 183 */         values = pair.matches;
/* 184 */         values.add(content);
/*     */       }
/* 187 */       else if ("!=".equals(separator)) {
/* 188 */         if (pair == null) {
/* 189 */           throw new ParseException("Illegal route rule \"" + rule + "\", The error char '" + separator + "' at index " + matcher.start() + " before \"" + content + "\".", matcher.start());
/*     */         }
/*     */ 
/* 194 */         values = pair.mismatches;
/* 195 */         values.add(content);
/*     */       }
/* 198 */       else if (",".equals(separator)) {
/* 199 */         if ((values == null) || (values.size() == 0)) {
/* 200 */           throw new ParseException("Illegal route rule \"" + rule + "\", The error char '" + separator + "' at index " + matcher.start() + " before \"" + content + "\".", matcher.start());
/*     */         }
/*     */ 
/* 204 */         values.add(content);
/*     */       } else {
/* 206 */         throw new ParseException("Illegal route rule \"" + rule + "\", The error char '" + separator + "' at index " + matcher.start() + " before \"" + content + "\".", matcher.start());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 211 */     return condition;
/*     */   }
/*     */ 
/*     */   private static final class MatchPair {
/* 215 */     final Set<String> matches = new HashSet();
/* 216 */     final Set<String> mismatches = new HashSet();
/*     */ 
/* 218 */     public boolean isMatch(String value, URL param) { for (String match : this.matches) {
/* 219 */         if (!UrlUtils.isMatchGlobPattern(match, value, param)) {
/* 220 */           return false;
/*     */         }
/*     */       }
/* 223 */       for (String mismatch : this.mismatches) {
/* 224 */         if (UrlUtils.isMatchGlobPattern(mismatch, value, param)) {
/* 225 */           return false;
/*     */         }
/*     */       }
/* 228 */       return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.router.condition.ConditionRouter
 * JD-Core Version:    0.6.2
 */