/*    */ package com.alibaba.dubbo.rpc.cluster.router.condition;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.cluster.Router;
/*    */ import com.alibaba.dubbo.rpc.cluster.RouterFactory;
/*    */ 
/*    */ public class ConditionRouterFactory
/*    */   implements RouterFactory
/*    */ {
/*    */   public static final String NAME = "condition";
/*    */ 
/*    */   public Router getRouter(URL url)
/*    */   {
/* 32 */     return new ConditionRouter(url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.router.condition.ConditionRouterFactory
 * JD-Core Version:    0.6.2
 */