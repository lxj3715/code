/*    */ package com.alibaba.dubbo.rpc.cluster.router.file;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.utils.IOUtils;
/*    */ import com.alibaba.dubbo.rpc.cluster.Router;
/*    */ import com.alibaba.dubbo.rpc.cluster.RouterFactory;
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class FileRouterFactory
/*    */   implements RouterFactory
/*    */ {
/*    */   public static final String NAME = "file";
/*    */   private RouterFactory routerFactory;
/*    */ 
/*    */   public void setRouterFactory(RouterFactory routerFactory)
/*    */   {
/* 36 */     this.routerFactory = routerFactory;
/*    */   }
/*    */ 
/*    */   public Router getRouter(URL url)
/*    */   {
/*    */     try
/*    */     {
/* 43 */       String protocol = url.getParameter("router", "script");
/* 44 */       String type = null;
/* 45 */       String path = url.getPath();
/* 46 */       if (path != null) {
/* 47 */         int i = path.lastIndexOf('.');
/* 48 */         if (i > 0) {
/* 49 */           type = path.substring(i + 1);
/*    */         }
/*    */       }
/* 52 */       String rule = IOUtils.read(new FileReader(new File(url.getAbsolutePath())));
/* 53 */       URL script = url.setProtocol(protocol).addParameter("type", type).addParameterAndEncoded("rule", rule);
/*    */ 
/* 55 */       return this.routerFactory.getRouter(script);
/*    */     } catch (IOException e) {
/* 57 */       throw new IllegalStateException(e.getMessage(), e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.router.file.FileRouterFactory
 * JD-Core Version:    0.6.2
 */