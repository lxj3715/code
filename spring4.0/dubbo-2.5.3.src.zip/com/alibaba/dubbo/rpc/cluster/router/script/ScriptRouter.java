/*     */ package com.alibaba.dubbo.rpc.cluster.router.script;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.RpcContext;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.cluster.Router;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.script.Bindings;
/*     */ import javax.script.Compilable;
/*     */ import javax.script.CompiledScript;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.ScriptException;
/*     */ 
/*     */ public class ScriptRouter
/*     */   implements Router
/*     */ {
/*  48 */   private static final Logger logger = LoggerFactory.getLogger(ScriptRouter.class);
/*     */ 
/*  50 */   private static final Map<String, ScriptEngine> engines = new ConcurrentHashMap();
/*     */   private final ScriptEngine engine;
/*     */   private final int priority;
/*     */   private final String rule;
/*     */   private final URL url;
/*     */ 
/*     */   public URL getUrl()
/*     */   {
/*  61 */     return this.url;
/*     */   }
/*     */ 
/*     */   public ScriptRouter(URL url) {
/*  65 */     this.url = url;
/*  66 */     String type = url.getParameter("type");
/*  67 */     this.priority = url.getParameter("priority", 0);
/*  68 */     String rule = url.getParameterAndDecoded("rule");
/*  69 */     if ((type == null) || (type.length() == 0)) {
/*  70 */       type = "javascript";
/*     */     }
/*  72 */     if ((rule == null) || (rule.length() == 0)) {
/*  73 */       throw new IllegalStateException(new IllegalStateException("route rule can not be empty. rule:" + rule));
/*     */     }
/*  75 */     ScriptEngine engine = (ScriptEngine)engines.get(type);
/*  76 */     if (engine == null) {
/*  77 */       engine = new ScriptEngineManager().getEngineByName(type);
/*  78 */       if (engine == null) {
/*  79 */         throw new IllegalStateException(new IllegalStateException("Unsupported route rule type: " + type + ", rule: " + rule));
/*     */       }
/*  81 */       engines.put(type, engine);
/*     */     }
/*  83 */     this.engine = engine;
/*  84 */     this.rule = rule;
/*     */   }
/*     */ 
/*     */   public <T> List<Invoker<T>> route(List<Invoker<T>> invokers, URL url, Invocation invocation) throws RpcException
/*     */   {
/*     */     try {
/*  90 */       List invokersCopy = new ArrayList(invokers);
/*  91 */       Compilable compilable = (Compilable)this.engine;
/*  92 */       Bindings bindings = this.engine.createBindings();
/*  93 */       bindings.put("invokers", invokersCopy);
/*  94 */       bindings.put("invocation", invocation);
/*  95 */       bindings.put("context", RpcContext.getContext());
/*  96 */       CompiledScript function = compilable.compile(this.rule);
/*  97 */       Object obj = function.eval(bindings);
/*  98 */       if ((obj instanceof Invoker[])) {
/*  99 */         invokersCopy = Arrays.asList((Invoker[])obj);
/* 100 */       } else if ((obj instanceof Object[])) {
/* 101 */         invokersCopy = new ArrayList();
/* 102 */         for (Object inv : (Object[])obj) {
/* 103 */           invokersCopy.add((Invoker)inv);
/*     */         }
/*     */       }
/* 106 */       return (List)obj;
/*     */     }
/*     */     catch (ScriptException e)
/*     */     {
/* 111 */       logger.error("route error , rule has been ignored. rule: " + this.rule + ", method:" + invocation.getMethodName() + ", url: " + RpcContext.getContext().getUrl(), e);
/* 112 */     }return invokers;
/*     */   }
/*     */ 
/*     */   public int compareTo(Router o)
/*     */   {
/* 117 */     if ((o == null) || (o.getClass() != ScriptRouter.class)) {
/* 118 */       return 1;
/*     */     }
/* 120 */     ScriptRouter c = (ScriptRouter)o;
/* 121 */     return this.priority > c.priority ? 1 : this.priority == c.priority ? this.rule.compareTo(c.rule) : -1;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.router.script.ScriptRouter
 * JD-Core Version:    0.6.2
 */