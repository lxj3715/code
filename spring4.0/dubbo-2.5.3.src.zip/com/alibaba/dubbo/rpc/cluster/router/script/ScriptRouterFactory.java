/*    */ package com.alibaba.dubbo.rpc.cluster.router.script;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.cluster.Router;
/*    */ import com.alibaba.dubbo.rpc.cluster.RouterFactory;
/*    */ 
/*    */ public class ScriptRouterFactory
/*    */   implements RouterFactory
/*    */ {
/*    */   public static final String NAME = "script";
/*    */ 
/*    */   public Router getRouter(URL url)
/*    */   {
/* 41 */     return new ScriptRouter(url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.router.script.ScriptRouterFactory
 * JD-Core Version:    0.6.2
 */