/*     */ package com.alibaba.dubbo.rpc.cluster.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*     */ import com.alibaba.dubbo.rpc.cluster.LoadBalance;
/*     */ import com.alibaba.dubbo.rpc.support.RpcUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class AbstractClusterInvoker<T>
/*     */   implements Invoker<T>
/*     */ {
/*  44 */   private static final Logger logger = LoggerFactory.getLogger(AbstractClusterInvoker.class);
/*     */   protected final Directory<T> directory;
/*     */   protected final boolean availablecheck;
/*  50 */   private volatile boolean destroyed = false;
/*     */ 
/*  52 */   private volatile Invoker<T> stickyInvoker = null;
/*     */ 
/*     */   public AbstractClusterInvoker(Directory<T> directory) {
/*  55 */     this(directory, directory.getUrl());
/*     */   }
/*     */ 
/*     */   public AbstractClusterInvoker(Directory<T> directory, URL url) {
/*  59 */     if (directory == null) {
/*  60 */       throw new IllegalArgumentException("service directory == null");
/*     */     }
/*  62 */     this.directory = directory;
/*     */ 
/*  64 */     this.availablecheck = url.getParameter("cluster.availablecheck", true);
/*     */   }
/*     */ 
/*     */   public Class<T> getInterface() {
/*  68 */     return this.directory.getInterface();
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  72 */     return this.directory.getUrl();
/*     */   }
/*     */ 
/*     */   public boolean isAvailable() {
/*  76 */     Invoker invoker = this.stickyInvoker;
/*  77 */     if (invoker != null) {
/*  78 */       return invoker.isAvailable();
/*     */     }
/*  80 */     return this.directory.isAvailable();
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*  84 */     this.directory.destroy();
/*  85 */     this.destroyed = true;
/*     */   }
/*     */ 
/*     */   protected Invoker<T> select(LoadBalance loadbalance, Invocation invocation, List<Invoker<T>> invokers, List<Invoker<T>> selected)
/*     */     throws RpcException
/*     */   {
/*  98 */     if ((invokers == null) || (invokers.size() == 0))
/*  99 */       return null;
/* 100 */     String methodName = invocation == null ? "" : invocation.getMethodName();
/*     */ 
/* 102 */     boolean sticky = ((Invoker)invokers.get(0)).getUrl().getMethodParameter(methodName, "sticky", false);
/*     */ 
/* 105 */     if ((this.stickyInvoker != null) && (!invokers.contains(this.stickyInvoker))) {
/* 106 */       this.stickyInvoker = null;
/*     */     }
/*     */ 
/* 109 */     if ((sticky) && (this.stickyInvoker != null) && ((selected == null) || (!selected.contains(this.stickyInvoker))) && 
/* 110 */       (this.availablecheck) && (this.stickyInvoker.isAvailable())) {
/* 111 */       return this.stickyInvoker;
/*     */     }
/*     */ 
/* 115 */     Invoker invoker = doselect(loadbalance, invocation, invokers, selected);
/*     */ 
/* 117 */     if (sticky) {
/* 118 */       this.stickyInvoker = invoker;
/*     */     }
/* 120 */     return invoker;
/*     */   }
/*     */ 
/*     */   private Invoker<T> doselect(LoadBalance loadbalance, Invocation invocation, List<Invoker<T>> invokers, List<Invoker<T>> selected) throws RpcException {
/* 124 */     if ((invokers == null) || (invokers.size() == 0))
/* 125 */       return null;
/* 126 */     if (invokers.size() == 1) {
/* 127 */       return (Invoker)invokers.get(0);
/*     */     }
/* 129 */     if ((invokers.size() == 2) && (selected != null) && (selected.size() > 0)) {
/* 130 */       return selected.get(0) == invokers.get(0) ? (Invoker)invokers.get(1) : (Invoker)invokers.get(0);
/*     */     }
/* 132 */     Invoker invoker = loadbalance.select(invokers, getUrl(), invocation);
/*     */ 
/* 135 */     if (((selected != null) && (selected.contains(invoker))) || ((!invoker.isAvailable()) && (getUrl() != null) && (this.availablecheck))) {
/*     */       try
/*     */       {
/* 138 */         Invoker rinvoker = reselect(loadbalance, invocation, invokers, selected, this.availablecheck);
/* 139 */         if (rinvoker != null) {
/* 140 */           invoker = rinvoker;
/*     */         }
/*     */         else {
/* 143 */           int index = invokers.indexOf(invoker);
/*     */           try
/*     */           {
/* 146 */             invoker = index < invokers.size() - 1 ? (Invoker)invokers.get(index + 1) : invoker;
/*     */           } catch (Exception e) {
/* 148 */             logger.warn(e.getMessage() + " may because invokers list dynamic change, ignore.", e);
/*     */           }
/*     */         }
/*     */       } catch (Throwable t) {
/* 152 */         logger.error("clustor relselect fail reason is :" + t.getMessage() + " if can not slove ,you can set cluster.availablecheck=false in url", t);
/*     */       }
/*     */     }
/* 155 */     return invoker;
/*     */   }
/*     */ 
/*     */   private Invoker<T> reselect(LoadBalance loadbalance, Invocation invocation, List<Invoker<T>> invokers, List<Invoker<T>> selected, boolean availablecheck)
/*     */     throws RpcException
/*     */   {
/* 172 */     List reselectInvokers = new ArrayList(invokers.size() > 1 ? invokers.size() - 1 : invokers.size());
/*     */ 
/* 175 */     if (availablecheck) {
/* 176 */       for (Invoker invoker : invokers) {
/* 177 */         if ((invoker.isAvailable()) && (
/* 178 */           (selected == null) || (!selected.contains(invoker)))) {
/* 179 */           reselectInvokers.add(invoker);
/*     */         }
/*     */       }
/*     */ 
/* 183 */       if (reselectInvokers.size() > 0)
/* 184 */         return loadbalance.select(reselectInvokers, getUrl(), invocation);
/*     */     }
/*     */     else {
/* 187 */       for (Invoker invoker : invokers) {
/* 188 */         if ((selected == null) || (!selected.contains(invoker))) {
/* 189 */           reselectInvokers.add(invoker);
/*     */         }
/*     */       }
/* 192 */       if (reselectInvokers.size() > 0) {
/* 193 */         return loadbalance.select(reselectInvokers, getUrl(), invocation);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 198 */     if (selected != null) {
/* 199 */       for (Invoker invoker : selected) {
/* 200 */         if ((invoker.isAvailable()) && (!reselectInvokers.contains(invoker)))
/*     */         {
/* 202 */           reselectInvokers.add(invoker);
/*     */         }
/*     */       }
/*     */     }
/* 206 */     if (reselectInvokers.size() > 0) {
/* 207 */       return loadbalance.select(reselectInvokers, getUrl(), invocation);
/*     */     }
/*     */ 
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */   public Result invoke(Invocation invocation) throws RpcException
/*     */   {
/* 215 */     checkWheatherDestoried();
/*     */ 
/* 219 */     List invokers = list(invocation);
/*     */     LoadBalance loadbalance;
/*     */     LoadBalance loadbalance;
/* 220 */     if ((invokers != null) && (invokers.size() > 0)) {
/* 221 */       loadbalance = (LoadBalance)ExtensionLoader.getExtensionLoader(LoadBalance.class).getExtension(((Invoker)invokers.get(0)).getUrl().getMethodParameter(invocation.getMethodName(), "loadbalance", "random"));
/*     */     }
/*     */     else {
/* 224 */       loadbalance = (LoadBalance)ExtensionLoader.getExtensionLoader(LoadBalance.class).getExtension("random");
/*     */     }
/* 226 */     RpcUtils.attachInvocationIdIfAsync(getUrl(), invocation);
/* 227 */     return doInvoke(invocation, invokers, loadbalance);
/*     */   }
/*     */ 
/*     */   protected void checkWheatherDestoried()
/*     */   {
/* 232 */     if (this.destroyed)
/* 233 */       throw new RpcException("Rpc cluster invoker for " + getInterface() + " on consumer " + NetUtils.getLocalHost() + " use dubbo version " + Version.getVersion() + " is now destroyed! Can not invoke any more.");
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 241 */     return getInterface() + " -> " + getUrl().toString();
/*     */   }
/*     */ 
/*     */   protected void checkInvokers(List<Invoker<T>> invokers, Invocation invocation) {
/* 245 */     if ((invokers == null) || (invokers.size() == 0))
/* 246 */       throw new RpcException("Failed to invoke the method " + invocation.getMethodName() + " in the service " + getInterface().getName() + ". No provider available for the service " + this.directory.getUrl().getServiceKey() + " from registry " + this.directory.getUrl().getAddress() + " on the consumer " + NetUtils.getLocalHost() + " using the dubbo version " + Version.getVersion() + ". Please check if the providers have been started and registered.");
/*     */   }
/*     */ 
/*     */   protected abstract Result doInvoke(Invocation paramInvocation, List<Invoker<T>> paramList, LoadBalance paramLoadBalance)
/*     */     throws RpcException;
/*     */ 
/*     */   protected List<Invoker<T>> list(Invocation invocation)
/*     */     throws RpcException
/*     */   {
/* 260 */     List invokers = this.directory.list(invocation);
/* 261 */     return invokers;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.AbstractClusterInvoker
 * JD-Core Version:    0.6.2
 */