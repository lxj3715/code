/*    */ package com.alibaba.dubbo.rpc.cluster.support;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*    */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*    */ import com.alibaba.dubbo.rpc.cluster.LoadBalance;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AvailableCluster
/*    */   implements Cluster
/*    */ {
/*    */   public static final String NAME = "available";
/*    */ 
/*    */   public <T> Invoker<T> join(Directory<T> directory)
/*    */     throws RpcException
/*    */   {
/* 39 */     return new AbstractClusterInvoker(directory) {
/*    */       public Result doInvoke(Invocation invocation, List<Invoker<T>> invokers, LoadBalance loadbalance) throws RpcException {
/* 41 */         for (Invoker invoker : invokers) {
/* 42 */           if (invoker.isAvailable()) {
/* 43 */             return invoker.invoke(invocation);
/*    */           }
/*    */         }
/* 46 */         throw new RpcException("No provider available in " + invokers);
/*    */       }
/*    */     };
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.AvailableCluster
 * JD-Core Version:    0.6.2
 */