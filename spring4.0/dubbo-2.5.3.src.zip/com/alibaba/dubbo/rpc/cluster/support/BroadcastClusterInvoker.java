/*    */ package com.alibaba.dubbo.rpc.cluster.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcContext;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*    */ import com.alibaba.dubbo.rpc.cluster.LoadBalance;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BroadcastClusterInvoker<T> extends AbstractClusterInvoker<T>
/*    */ {
/* 37 */   private static final Logger logger = LoggerFactory.getLogger(BroadcastClusterInvoker.class);
/*    */ 
/*    */   public BroadcastClusterInvoker(Directory<T> directory) {
/* 40 */     super(directory);
/*    */   }
/*    */ 
/*    */   public Result doInvoke(Invocation invocation, List<Invoker<T>> invokers, LoadBalance loadbalance) throws RpcException
/*    */   {
/* 45 */     checkInvokers(invokers, invocation);
/* 46 */     RpcContext.getContext().setInvokers(invokers);
/* 47 */     RpcException exception = null;
/* 48 */     Result result = null;
/* 49 */     for (Invoker invoker : invokers) {
/*    */       try {
/* 51 */         result = invoker.invoke(invocation);
/*    */       } catch (RpcException e) {
/* 53 */         exception = e;
/* 54 */         logger.warn(e.getMessage(), e);
/*    */       } catch (Throwable e) {
/* 56 */         exception = new RpcException(e.getMessage(), e);
/* 57 */         logger.warn(e.getMessage(), e);
/*    */       }
/*    */     }
/* 60 */     if (exception != null) {
/* 61 */       throw exception;
/*    */     }
/* 63 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.BroadcastClusterInvoker
 * JD-Core Version:    0.6.2
 */