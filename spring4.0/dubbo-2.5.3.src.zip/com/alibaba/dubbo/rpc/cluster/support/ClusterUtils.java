/*    */ package com.alibaba.dubbo.rpc.cluster.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ClusterUtils
/*    */ {
/*    */   public static URL mergeUrl(URL remoteUrl, Map<String, String> localMap)
/*    */   {
/* 32 */     Map map = new HashMap();
/* 33 */     Map remoteMap = remoteUrl.getParameters();
/*    */ 
/* 36 */     if ((remoteMap != null) && (remoteMap.size() > 0)) {
/* 37 */       map.putAll(remoteMap);
/*    */ 
/* 40 */       map.remove("threadname");
/* 41 */       map.remove("default.threadname");
/*    */ 
/* 43 */       map.remove("threadpool");
/* 44 */       map.remove("default.threadpool");
/*    */ 
/* 46 */       map.remove("corethreads");
/* 47 */       map.remove("default.corethreads");
/*    */ 
/* 49 */       map.remove("threads");
/* 50 */       map.remove("default.threads");
/*    */ 
/* 52 */       map.remove("queues");
/* 53 */       map.remove("default.queues");
/*    */ 
/* 55 */       map.remove("alive");
/* 56 */       map.remove("default.alive");
/*    */     }
/*    */ 
/* 59 */     if ((localMap != null) && (localMap.size() > 0)) {
/* 60 */       map.putAll(localMap);
/*    */     }
/* 62 */     if ((remoteMap != null) && (remoteMap.size() > 0))
/*    */     {
/* 64 */       String dubbo = (String)remoteMap.get("dubbo");
/* 65 */       if ((dubbo != null) && (dubbo.length() > 0)) {
/* 66 */         map.put("dubbo", dubbo);
/*    */       }
/* 68 */       String version = (String)remoteMap.get("version");
/* 69 */       if ((version != null) && (version.length() > 0)) {
/* 70 */         map.put("version", version);
/*    */       }
/* 72 */       String group = (String)remoteMap.get("group");
/* 73 */       if ((group != null) && (group.length() > 0)) {
/* 74 */         map.put("group", group);
/*    */       }
/* 76 */       String methods = (String)remoteMap.get("methods");
/* 77 */       if ((methods != null) && (methods.length() > 0)) {
/* 78 */         map.put("methods", methods);
/*    */       }
/*    */ 
/* 81 */       String remoteFilter = (String)remoteMap.get("reference.filter");
/* 82 */       String localFilter = (String)localMap.get("reference.filter");
/* 83 */       if ((remoteFilter != null) && (remoteFilter.length() > 0) && (localFilter != null) && (localFilter.length() > 0))
/*    */       {
/* 85 */         localMap.put("reference.filter", remoteFilter + "," + localFilter);
/*    */       }
/* 87 */       String remoteListener = (String)remoteMap.get("invoker.listener");
/* 88 */       String localListener = (String)localMap.get("invoker.listener");
/* 89 */       if ((remoteListener != null) && (remoteListener.length() > 0) && (localListener != null) && (localListener.length() > 0))
/*    */       {
/* 91 */         localMap.put("invoker.listener", remoteListener + "," + localListener);
/*    */       }
/*    */     }
/*    */ 
/* 95 */     return remoteUrl.clearParameters().addParameters(map);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.ClusterUtils
 * JD-Core Version:    0.6.2
 */