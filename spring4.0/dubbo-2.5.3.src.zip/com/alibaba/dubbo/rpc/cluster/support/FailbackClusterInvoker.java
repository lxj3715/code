/*     */ package com.alibaba.dubbo.rpc.cluster.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.RpcResult;
/*     */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*     */ import com.alibaba.dubbo.rpc.cluster.LoadBalance;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class FailbackClusterInvoker<T> extends AbstractClusterInvoker<T>
/*     */ {
/*  46 */   private static final Logger logger = LoggerFactory.getLogger(FailbackClusterInvoker.class);
/*     */   private static final long RETRY_FAILED_PERIOD = 5000L;
/*  50 */   private final ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(2, new NamedThreadFactory("failback-cluster-timer", true));
/*     */   private volatile ScheduledFuture<?> retryFuture;
/*  54 */   private final ConcurrentMap<Invocation, AbstractClusterInvoker<?>> failed = new ConcurrentHashMap();
/*     */ 
/*     */   public FailbackClusterInvoker(Directory<T> directory) {
/*  57 */     super(directory);
/*     */   }
/*     */ 
/*     */   private void addFailed(Invocation invocation, AbstractClusterInvoker<?> router) {
/*  61 */     if (this.retryFuture == null) {
/*  62 */       synchronized (this) {
/*  63 */         if (this.retryFuture == null) {
/*  64 */           this.retryFuture = this.scheduledExecutorService.scheduleWithFixedDelay(new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/*     */               try {
/*  69 */                 FailbackClusterInvoker.this.retryFailed();
/*     */               } catch (Throwable t) {
/*  71 */                 FailbackClusterInvoker.logger.error("Unexpected error occur at collect statistic", t);
/*     */               }
/*     */             }
/*     */           }
/*     */           , 5000L, 5000L, TimeUnit.MILLISECONDS);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  78 */     this.failed.put(invocation, router);
/*     */   }
/*     */ 
/*     */   void retryFailed() {
/*  82 */     if (this.failed.size() == 0) {
/*  83 */       return;
/*     */     }
/*  85 */     for (Map.Entry entry : new HashMap(this.failed).entrySet())
/*     */     {
/*  87 */       Invocation invocation = (Invocation)entry.getKey();
/*  88 */       Invoker invoker = (Invoker)entry.getValue();
/*     */       try {
/*  90 */         invoker.invoke(invocation);
/*  91 */         this.failed.remove(invocation);
/*     */       } catch (Throwable e) {
/*  93 */         logger.error("Failed retry to invoke method " + invocation.getMethodName() + ", waiting again.", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Result doInvoke(Invocation invocation, List<Invoker<T>> invokers, LoadBalance loadbalance) throws RpcException {
/*     */     try {
/* 100 */       checkInvokers(invokers, invocation);
/* 101 */       Invoker invoker = select(loadbalance, invocation, invokers, null);
/* 102 */       return invoker.invoke(invocation);
/*     */     } catch (Throwable e) {
/* 104 */       logger.error("Failback to invoke method " + invocation.getMethodName() + ", wait for retry in background. Ignored exception: " + e.getMessage() + ", ", e);
/*     */ 
/* 106 */       addFailed(invocation, this);
/* 107 */     }return new RpcResult();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.FailbackClusterInvoker
 * JD-Core Version:    0.6.2
 */