/*    */ package com.alibaba.dubbo.rpc.cluster.support;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*    */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*    */ 
/*    */ public class FailoverCluster
/*    */   implements Cluster
/*    */ {
/*    */   public static final String NAME = "failover";
/*    */ 
/*    */   public <T> Invoker<T> join(Directory<T> directory)
/*    */     throws RpcException
/*    */   {
/* 35 */     return new FailoverClusterInvoker(directory);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.FailoverCluster
 * JD-Core Version:    0.6.2
 */