/*     */ package com.alibaba.dubbo.rpc.cluster.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcContext;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*     */ import com.alibaba.dubbo.rpc.cluster.LoadBalance;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class FailoverClusterInvoker<T> extends AbstractClusterInvoker<T>
/*     */ {
/*  46 */   private static final Logger logger = LoggerFactory.getLogger(FailoverClusterInvoker.class);
/*     */ 
/*     */   public FailoverClusterInvoker(Directory<T> directory) {
/*  49 */     super(directory);
/*     */   }
/*     */ 
/*     */   public Result doInvoke(Invocation invocation, List<Invoker<T>> invokers, LoadBalance loadbalance) throws RpcException
/*     */   {
/*  54 */     List copyinvokers = invokers;
/*  55 */     checkInvokers(copyinvokers, invocation);
/*  56 */     int len = getUrl().getMethodParameter(invocation.getMethodName(), "retries", 2) + 1;
/*  57 */     if (len <= 0) {
/*  58 */       len = 1;
/*     */     }
/*     */ 
/*  61 */     RpcException le = null;
/*  62 */     List invoked = new ArrayList(copyinvokers.size());
/*  63 */     Set providers = new HashSet(len);
/*  64 */     for (int i = 0; i < len; i++)
/*     */     {
/*  67 */       if (i > 0) {
/*  68 */         checkWheatherDestoried();
/*  69 */         copyinvokers = list(invocation);
/*     */ 
/*  71 */         checkInvokers(copyinvokers, invocation);
/*     */       }
/*  73 */       Invoker invoker = select(loadbalance, invocation, copyinvokers, invoked);
/*  74 */       invoked.add(invoker);
/*  75 */       RpcContext.getContext().setInvokers(invoked);
/*     */       try {
/*  77 */         Result result = invoker.invoke(invocation);
/*  78 */         if ((le != null) && (logger.isWarnEnabled())) {
/*  79 */           logger.warn("Although retry the method " + invocation.getMethodName() + " in the service " + getInterface().getName() + " was successful by the provider " + invoker.getUrl().getAddress() + ", but there have been failed providers " + providers + " (" + providers.size() + "/" + copyinvokers.size() + ") from the registry " + this.directory.getUrl().getAddress() + " on the consumer " + NetUtils.getLocalHost() + " using the dubbo version " + Version.getVersion() + ". Last error is: " + le.getMessage(), le);
/*     */         }
/*     */ 
/*  89 */         return result;
/*     */       } catch (RpcException e) {
/*  91 */         if (e.isBiz()) {
/*  92 */           throw e;
/*     */         }
/*  94 */         le = e;
/*     */       } catch (Throwable e) {
/*  96 */         le = new RpcException(e.getMessage(), e);
/*     */       } finally {
/*  98 */         providers.add(invoker.getUrl().getAddress());
/*     */       }
/*     */     }
/* 101 */     throw new RpcException(le != null ? le.getCode() : 0, "Failed to invoke the method " + invocation.getMethodName() + " in the service " + getInterface().getName() + ". Tried " + len + " times of the providers " + providers + " (" + providers.size() + "/" + copyinvokers.size() + ") from the registry " + this.directory.getUrl().getAddress() + " on the consumer " + NetUtils.getLocalHost() + " using the dubbo version " + Version.getVersion() + ". Last error is: " + (le != null ? le.getMessage() : ""), (le != null) && (le.getCause() != null) ? le.getCause() : le);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.FailoverClusterInvoker
 * JD-Core Version:    0.6.2
 */