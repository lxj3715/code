/*    */ package com.alibaba.dubbo.rpc.cluster.support;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*    */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*    */ 
/*    */ public class FailsafeCluster
/*    */   implements Cluster
/*    */ {
/*    */   public static final String NAME = "failsafe";
/*    */ 
/*    */   public <T> Invoker<T> join(Directory<T> directory)
/*    */     throws RpcException
/*    */   {
/* 35 */     return new FailsafeClusterInvoker(directory);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.FailsafeCluster
 * JD-Core Version:    0.6.2
 */