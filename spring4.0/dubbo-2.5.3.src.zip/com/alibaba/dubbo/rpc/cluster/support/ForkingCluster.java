/*    */ package com.alibaba.dubbo.rpc.cluster.support;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*    */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*    */ 
/*    */ public class ForkingCluster
/*    */   implements Cluster
/*    */ {
/*    */   public static final String NAME = "forking";
/*    */ 
/*    */   public <T> Invoker<T> join(Directory<T> directory)
/*    */     throws RpcException
/*    */   {
/* 35 */     return new ForkingClusterInvoker(directory);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.ForkingCluster
 * JD-Core Version:    0.6.2
 */