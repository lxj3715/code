/*    */ package com.alibaba.dubbo.rpc.cluster.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcContext;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*    */ import com.alibaba.dubbo.rpc.cluster.LoadBalance;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.LinkedBlockingQueue;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ public class ForkingClusterInvoker<T> extends AbstractClusterInvoker<T>
/*    */ {
/* 46 */   private final ExecutorService executor = Executors.newCachedThreadPool(new NamedThreadFactory("forking-cluster-timer", true));
/*    */ 
/*    */   public ForkingClusterInvoker(Directory<T> directory) {
/* 49 */     super(directory);
/*    */   }
/*    */ 
/*    */   public Result doInvoke(final Invocation invocation, List<Invoker<T>> invokers, LoadBalance loadbalance) throws RpcException
/*    */   {
/* 54 */     checkInvokers(invokers, invocation);
/*    */ 
/* 56 */     int forks = getUrl().getParameter("forks", 2);
/* 57 */     int timeout = getUrl().getParameter("timeout", 1000);
/*    */     List selected;
/*    */     final List selected;
/* 58 */     if ((forks <= 0) || (forks >= invokers.size())) {
/* 59 */       selected = invokers;
/*    */     } else {
/* 61 */       selected = new ArrayList();
/* 62 */       for (int i = 0; i < forks; i++)
/*    */       {
/* 64 */         Invoker invoker = select(loadbalance, invocation, invokers, selected);
/* 65 */         if (!selected.contains(invoker)) {
/* 66 */           selected.add(invoker);
/*    */         }
/*    */       }
/*    */     }
/* 70 */     RpcContext.getContext().setInvokers(selected);
/* 71 */     final AtomicInteger count = new AtomicInteger();
/* 72 */     final BlockingQueue ref = new LinkedBlockingQueue();
/* 73 */     for (final Invoker invoker : selected) {
/* 74 */       this.executor.execute(new Runnable() {
/*    */         public void run() {
/*    */           try {
/* 77 */             Result result = invoker.invoke(invocation);
/* 78 */             ref.offer(result);
/*    */           } catch (Throwable e) {
/* 80 */             int value = count.incrementAndGet();
/* 81 */             if (value >= selected.size())
/* 82 */               ref.offer(e);
/*    */           }
/*    */         }
/*    */       });
/*    */     }
/*    */     try
/*    */     {
/* 89 */       Object ret = ref.poll(timeout, TimeUnit.MILLISECONDS);
/* 90 */       if ((ret instanceof Throwable)) {
/* 91 */         Throwable e = (Throwable)ret;
/* 92 */         throw new RpcException((e instanceof RpcException) ? ((RpcException)e).getCode() : 0, "Failed to forking invoke provider " + selected + ", but no luck to perform the invocation. Last error is: " + e.getMessage(), e.getCause() != null ? e.getCause() : e);
/*    */       }
/* 94 */       return (Result)ret;
/*    */     } catch (InterruptedException e) {
/* 96 */       throw new RpcException("Failed to forking invoke provider " + selected + ", but no luck to perform the invocation. Last error is: " + e.getMessage(), e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.ForkingClusterInvoker
 * JD-Core Version:    0.6.2
 */