/*    */ package com.alibaba.dubbo.rpc.cluster.support;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.cluster.Cluster;
/*    */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*    */ 
/*    */ public class MergeableCluster
/*    */   implements Cluster
/*    */ {
/*    */   public static final String NAME = "mergeable";
/*    */ 
/*    */   public <T> Invoker<T> join(Directory<T> directory)
/*    */     throws RpcException
/*    */   {
/* 31 */     return new MergeableClusterInvoker(directory);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.MergeableCluster
 * JD-Core Version:    0.6.2
 */