/*     */ package com.alibaba.dubbo.rpc.cluster.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*     */ import com.alibaba.dubbo.rpc.RpcResult;
/*     */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*     */ import com.alibaba.dubbo.rpc.cluster.Merger;
/*     */ import com.alibaba.dubbo.rpc.cluster.merger.MergerFactory;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class MergeableClusterInvoker<T>
/*     */   implements Invoker<T>
/*     */ {
/*  54 */   private static final Logger log = LoggerFactory.getLogger(MergeableClusterInvoker.class);
/*     */ 
/*  56 */   private ExecutorService executor = Executors.newCachedThreadPool(new NamedThreadFactory("mergeable-cluster-executor", true));
/*     */   private final Directory<T> directory;
/*     */ 
/*     */   public MergeableClusterInvoker(Directory<T> directory)
/*     */   {
/*  61 */     this.directory = directory;
/*     */   }
/*     */ 
/*     */   public Result invoke(final Invocation invocation) throws RpcException
/*     */   {
/*  66 */     List invokers = this.directory.list(invocation);
/*     */ 
/*  68 */     String merger = getUrl().getMethodParameter(invocation.getMethodName(), "merger");
/*  69 */     if (ConfigUtils.isEmpty(merger)) {
/*  70 */       for (Invoker invoker : invokers) {
/*  71 */         if (invoker.isAvailable()) {
/*  72 */           return invoker.invoke(invocation);
/*     */         }
/*     */       }
/*  75 */       return ((Invoker)invokers.iterator().next()).invoke(invocation);
/*     */     }
/*     */     Class returnType;
/*     */     try
/*     */     {
/*  80 */       returnType = getInterface().getMethod(invocation.getMethodName(), invocation.getParameterTypes()).getReturnType();
/*     */     }
/*     */     catch (NoSuchMethodException e) {
/*  83 */       returnType = null;
/*     */     }
/*     */ 
/*  86 */     Map results = new HashMap();
/*  87 */     for (final Invoker invoker : invokers) {
/*  88 */       Future future = this.executor.submit(new Callable() {
/*     */         public Result call() throws Exception {
/*  90 */           return invoker.invoke(new RpcInvocation(invocation, invoker));
/*     */         }
/*     */       });
/*  93 */       results.put(invoker.getUrl().getServiceKey(), future);
/*     */     }
/*     */ 
/*  96 */     Object result = null;
/*     */ 
/*  98 */     List resultList = new ArrayList(results.size());
/*     */ 
/* 100 */     int timeout = getUrl().getMethodParameter(invocation.getMethodName(), "timeout", 1000);
/* 101 */     for (Map.Entry entry : results.entrySet()) {
/* 102 */       Future future = (Future)entry.getValue();
/*     */       try {
/* 104 */         Result r = (Result)future.get(timeout, TimeUnit.MILLISECONDS);
/* 105 */         if (r.hasException()) {
/* 106 */           log.error(32 + "Invoke " + getGroupDescFromServiceKey((String)entry.getKey()) + " failed: " + r.getException().getMessage(), r.getException());
/*     */         }
/*     */         else
/*     */         {
/* 112 */           resultList.add(r);
/*     */         }
/*     */       } catch (Exception e) {
/* 115 */         throw new RpcException(32 + "Failed to invoke service " + (String)entry.getKey() + ": " + e.getMessage(), e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 124 */     if (resultList.size() == 0)
/* 125 */       return new RpcResult((Object)null);
/* 126 */     if (resultList.size() == 1) {
/* 127 */       return (Result)resultList.iterator().next();
/*     */     }
/*     */ 
/* 130 */     if (returnType == Void.TYPE) {
/* 131 */       return new RpcResult((Object)null);
/*     */     }
/*     */ 
/* 134 */     if (merger.startsWith(".")) { merger = merger.substring(1);
/*     */       Method method;
/*     */       try {
/* 138 */         method = returnType.getMethod(merger, new Class[] { returnType });
/*     */       } catch (NoSuchMethodException e) {
/* 140 */         throw new RpcException(32 + "Can not merge result because missing method [ " + merger + " ] in class [ " + returnType.getClass().getName() + " ]");
/*     */       }
/*     */ 
/* 148 */       if (method != null) {
/* 149 */         if (!Modifier.isPublic(method.getModifiers())) {
/* 150 */           method.setAccessible(true);
/*     */         }
/* 152 */         result = ((Result)resultList.remove(0)).getValue();
/*     */         try {
/* 154 */           if ((method.getReturnType() != Void.TYPE) && (method.getReturnType().isAssignableFrom(result.getClass())))
/*     */           {
/* 156 */             for (Result r : resultList)
/* 157 */               result = method.invoke(result, new Object[] { r.getValue() });
/*     */           }
/*     */           else
/* 160 */             for (Result r : resultList)
/* 161 */               method.invoke(result, new Object[] { r.getValue() });
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 165 */           throw new RpcException(32 + "Can not merge result: " + e.getMessage(), e);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 172 */         throw new RpcException(32 + "Can not merge result because missing method [ " + merger + " ] in class [ " + returnType.getClass().getName() + " ]");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       Merger resultMerger;
/*     */       Merger resultMerger;
/* 183 */       if (ConfigUtils.isDefault(merger))
/* 184 */         resultMerger = MergerFactory.getMerger(returnType);
/*     */       else {
/* 186 */         resultMerger = (Merger)ExtensionLoader.getExtensionLoader(Merger.class).getExtension(merger);
/*     */       }
/* 188 */       if (resultMerger != null) {
/* 189 */         List rets = new ArrayList(resultList.size());
/* 190 */         for (Result r : resultList) {
/* 191 */           rets.add(r.getValue());
/*     */         }
/* 193 */         result = resultMerger.merge(rets.toArray((Object[])Array.newInstance(returnType, 0)));
/*     */       }
/*     */       else {
/* 196 */         throw new RpcException("There is no merger to merge result.");
/*     */       }
/*     */     }
/* 199 */     return new RpcResult(result);
/*     */   }
/*     */ 
/*     */   public Class<T> getInterface() {
/* 203 */     return this.directory.getInterface();
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/* 207 */     return this.directory.getUrl();
/*     */   }
/*     */ 
/*     */   public boolean isAvailable() {
/* 211 */     return this.directory.isAvailable();
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 215 */     this.directory.destroy();
/*     */   }
/*     */ 
/*     */   private String getGroupDescFromServiceKey(String key) {
/* 219 */     int index = key.indexOf("/");
/* 220 */     if (index > 0) {
/* 221 */       return 32 + "group [ " + key.substring(0, index) + " ]";
/*     */     }
/*     */ 
/* 224 */     return key;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.MergeableClusterInvoker
 * JD-Core Version:    0.6.2
 */