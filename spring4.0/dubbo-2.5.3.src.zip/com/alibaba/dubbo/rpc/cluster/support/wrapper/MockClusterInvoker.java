/*     */ package com.alibaba.dubbo.rpc.cluster.support.wrapper;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*     */ import com.alibaba.dubbo.rpc.RpcResult;
/*     */ import com.alibaba.dubbo.rpc.cluster.Directory;
/*     */ import com.alibaba.dubbo.rpc.support.MockInvoker;
/*     */ import java.util.List;
/*     */ 
/*     */ public class MockClusterInvoker<T>
/*     */   implements Invoker<T>
/*     */ {
/*  39 */   private static final Logger logger = LoggerFactory.getLogger(MockClusterInvoker.class);
/*     */   private final Directory<T> directory;
/*     */   private final Invoker<T> invoker;
/*     */ 
/*     */   public MockClusterInvoker(Directory<T> directory, Invoker<T> invoker)
/*     */   {
/*  46 */     this.directory = directory;
/*  47 */     this.invoker = invoker;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  51 */     return this.directory.getUrl();
/*     */   }
/*     */ 
/*     */   public boolean isAvailable() {
/*  55 */     return this.directory.isAvailable();
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*  59 */     this.invoker.destroy();
/*     */   }
/*     */ 
/*     */   public Class<T> getInterface() {
/*  63 */     return this.directory.getInterface();
/*     */   }
/*     */ 
/*     */   public Result invoke(Invocation invocation) throws RpcException {
/*  67 */     Result result = null;
/*     */ 
/*  69 */     String value = this.directory.getUrl().getMethodParameter(invocation.getMethodName(), "mock", Boolean.FALSE.toString()).trim();
/*  70 */     if ((value.length() == 0) || (value.equalsIgnoreCase("false")))
/*     */     {
/*  72 */       result = this.invoker.invoke(invocation);
/*  73 */     } else if (value.startsWith("force")) {
/*  74 */       if (logger.isWarnEnabled()) {
/*  75 */         logger.info("force-mock: " + invocation.getMethodName() + " force-mock enabled , url : " + this.directory.getUrl());
/*     */       }
/*     */ 
/*  78 */       result = doMockInvoke(invocation, null);
/*     */     }
/*     */     else {
/*     */       try {
/*  82 */         result = this.invoker.invoke(invocation);
/*     */       } catch (RpcException e) {
/*  84 */         if (e.isBiz()) {
/*  85 */           throw e;
/*     */         }
/*  87 */         if (logger.isWarnEnabled()) {
/*  88 */           logger.info("fail-mock: " + invocation.getMethodName() + " fail-mock enabled , url : " + this.directory.getUrl(), e);
/*     */         }
/*  90 */         result = doMockInvoke(invocation, e);
/*     */       }
/*     */     }
/*     */ 
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */   private Result doMockInvoke(Invocation invocation, RpcException e)
/*     */   {
/*  99 */     Result result = null;
/*     */ 
/* 102 */     List mockInvokers = selectMockInvoker(invocation);
/*     */     Invoker minvoker;
/*     */     Invoker minvoker;
/* 103 */     if ((mockInvokers == null) || (mockInvokers.size() == 0))
/* 104 */       minvoker = new MockInvoker(this.directory.getUrl());
/*     */     else
/* 106 */       minvoker = (Invoker)mockInvokers.get(0);
/*     */     try
/*     */     {
/* 109 */       result = minvoker.invoke(invocation);
/*     */     } catch (RpcException me) {
/* 111 */       if (me.isBiz())
/* 112 */         result = new RpcResult(me.getCause());
/*     */       else
/* 114 */         throw new RpcException(me.getCode(), getMockExceptionMessage(e, me), me.getCause());
/*     */     }
/*     */     catch (Throwable me)
/*     */     {
/* 118 */       throw new RpcException(getMockExceptionMessage(e, me), me.getCause());
/*     */     }
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */   private String getMockExceptionMessage(Throwable t, Throwable mt) {
/* 124 */     String msg = "mock error : " + mt.getMessage();
/* 125 */     if (t != null) {
/* 126 */       msg = msg + ", invoke error is :" + StringUtils.toString(t);
/*     */     }
/* 128 */     return msg;
/*     */   }
/*     */ 
/*     */   private List<Invoker<T>> selectMockInvoker(Invocation invocation)
/*     */   {
/* 141 */     if ((invocation instanceof RpcInvocation))
/*     */     {
/* 143 */       ((RpcInvocation)invocation).setAttachment("invocation.need.mock", Boolean.TRUE.toString());
/*     */ 
/* 145 */       List invokers = this.directory.list(invocation);
/* 146 */       return invokers;
/*     */     }
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 154 */     return "invoker :" + this.invoker + ",directory: " + this.directory;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.cluster.support.wrapper.MockClusterInvoker
 * JD-Core Version:    0.6.2
 */