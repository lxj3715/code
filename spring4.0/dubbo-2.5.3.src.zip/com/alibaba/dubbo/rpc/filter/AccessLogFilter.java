/*     */ package com.alibaba.dubbo.rpc.filter;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.Activate;
/*     */ import com.alibaba.dubbo.common.json.JSON;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ConcurrentHashSet;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.NamedThreadFactory;
/*     */ import com.alibaba.dubbo.rpc.Filter;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcContext;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ @Activate(group={"provider"}, value={"accesslog"})
/*     */ public class AccessLogFilter
/*     */   implements Filter
/*     */ {
/*  64 */   private static final Logger logger = LoggerFactory.getLogger(AccessLogFilter.class);
/*     */   private static final String ACCESS_LOG_KEY = "dubbo.accesslog";
/*     */   private static final String FILE_DATE_FORMAT = "yyyyMMdd";
/*     */   private static final String MESSAGE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
/*     */   private static final int LOG_MAX_BUFFER = 5000;
/*     */   private static final long LOG_OUTPUT_INTERVAL = 5000L;
/*     */   private final ConcurrentMap<String, Set<String>> logQueue;
/*     */   private final ScheduledExecutorService logScheduled;
/*     */   private volatile ScheduledFuture<?> logFuture;
/*     */ 
/*     */   public AccessLogFilter()
/*     */   {
/*  76 */     this.logQueue = new ConcurrentHashMap();
/*     */ 
/*  78 */     this.logScheduled = Executors.newScheduledThreadPool(2, new NamedThreadFactory("Dubbo-Access-Log", true));
/*     */ 
/*  80 */     this.logFuture = null;
/*     */   }
/*     */ 
/*     */   private void init()
/*     */   {
/* 129 */     if (this.logFuture == null)
/* 130 */       synchronized (this.logScheduled) {
/* 131 */         if (this.logFuture == null)
/* 132 */           this.logFuture = this.logScheduled.scheduleWithFixedDelay(new LogTask(null), 5000L, 5000L, TimeUnit.MILLISECONDS);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void log(String accesslog, String logmessage)
/*     */   {
/* 139 */     init();
/* 140 */     Set logSet = (Set)this.logQueue.get(accesslog);
/* 141 */     if (logSet == null) {
/* 142 */       this.logQueue.putIfAbsent(accesslog, new ConcurrentHashSet());
/* 143 */       logSet = (Set)this.logQueue.get(accesslog);
/*     */     }
/* 145 */     if (logSet.size() < 5000)
/* 146 */       logSet.add(logmessage);
/*     */   }
/*     */ 
/*     */   public Result invoke(Invoker<?> invoker, Invocation inv) throws RpcException
/*     */   {
/*     */     try {
/* 152 */       String accesslog = invoker.getUrl().getParameter("accesslog");
/* 153 */       if (ConfigUtils.isNotEmpty(accesslog)) {
/* 154 */         RpcContext context = RpcContext.getContext();
/* 155 */         String serviceName = invoker.getInterface().getName();
/* 156 */         String version = invoker.getUrl().getParameter("version");
/* 157 */         String group = invoker.getUrl().getParameter("group");
/* 158 */         StringBuilder sn = new StringBuilder();
/* 159 */         sn.append("[").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())).append("] ").append(context.getRemoteHost()).append(":").append(context.getRemotePort()).append(" -> ").append(context.getLocalHost()).append(":").append(context.getLocalPort()).append(" - ");
/*     */ 
/* 162 */         if ((null != group) && (group.length() > 0)) {
/* 163 */           sn.append(group).append("/");
/*     */         }
/* 165 */         sn.append(serviceName);
/* 166 */         if ((null != version) && (version.length() > 0)) {
/* 167 */           sn.append(":").append(version);
/*     */         }
/* 169 */         sn.append(" ");
/* 170 */         sn.append(inv.getMethodName());
/* 171 */         sn.append("(");
/* 172 */         Class[] types = inv.getParameterTypes();
/* 173 */         if ((types != null) && (types.length > 0)) {
/* 174 */           boolean first = true;
/* 175 */           for (Class type : types) {
/* 176 */             if (first)
/* 177 */               first = false;
/*     */             else {
/* 179 */               sn.append(",");
/*     */             }
/* 181 */             sn.append(type.getName());
/*     */           }
/*     */         }
/* 184 */         sn.append(") ");
/* 185 */         Object[] args = inv.getArguments();
/* 186 */         if ((args != null) && (args.length > 0)) {
/* 187 */           sn.append(JSON.json(args));
/*     */         }
/* 189 */         String msg = sn.toString();
/* 190 */         if (ConfigUtils.isDefault(accesslog))
/* 191 */           LoggerFactory.getLogger("dubbo.accesslog." + invoker.getInterface().getName()).info(msg);
/*     */         else
/* 193 */           log(accesslog, msg);
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/* 197 */       logger.warn("Exception in AcessLogFilter of service(" + invoker + " -> " + inv + ")", t);
/*     */     }
/* 199 */     return invoker.invoke(inv);
/*     */   }
/*     */ 
/*     */   private class LogTask
/*     */     implements Runnable
/*     */   {
/*     */     private LogTask()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/*  85 */         if ((AccessLogFilter.this.logQueue != null) && (AccessLogFilter.this.logQueue.size() > 0))
/*  86 */           for (Map.Entry entry : AccessLogFilter.this.logQueue.entrySet())
/*     */             try {
/*  88 */               String accesslog = (String)entry.getKey();
/*  89 */               Set logSet = (Set)entry.getValue();
/*  90 */               File file = new File(accesslog);
/*  91 */               File dir = file.getParentFile();
/*  92 */               if ((null != dir) && (!dir.exists())) {
/*  93 */                 dir.mkdirs();
/*     */               }
/*  95 */               if (AccessLogFilter.logger.isDebugEnabled()) {
/*  96 */                 AccessLogFilter.logger.debug("Append log to " + accesslog);
/*     */               }
/*  98 */               if (file.exists()) {
/*  99 */                 String now = new SimpleDateFormat("yyyyMMdd").format(new Date());
/* 100 */                 String last = new SimpleDateFormat("yyyyMMdd").format(new Date(file.lastModified()));
/* 101 */                 if (!now.equals(last)) {
/* 102 */                   File archive = new File(file.getAbsolutePath() + "." + last);
/* 103 */                   file.renameTo(archive);
/*     */                 }
/*     */               }
/* 106 */               FileWriter writer = new FileWriter(file, true);
/*     */               try {
/* 108 */                 for (String msg : logSet) {
/* 109 */                   writer.write(msg);
/* 110 */                   writer.write("\r\n");
/*     */                 }
/* 112 */                 writer.flush();
/*     */               } finally {
/* 114 */                 writer.close();
/*     */               }
/* 116 */               logSet.clear();
/*     */             } catch (Exception e) {
/* 118 */               AccessLogFilter.logger.error(e.getMessage(), e);
/*     */             }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 123 */         AccessLogFilter.logger.error(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.AccessLogFilter
 * JD-Core Version:    0.6.2
 */