/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ 
/*    */ @Activate(group={"consumer"}, value={"actives"})
/*    */ public class ActiveLimitFilter
/*    */   implements Filter
/*    */ {
/*    */   // ERROR //
/*    */   public com.alibaba.dubbo.rpc.Result invoke(com.alibaba.dubbo.rpc.Invoker<?> invoker, com.alibaba.dubbo.rpc.Invocation invocation)
/*    */     throws com.alibaba.dubbo.rpc.RpcException
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: invokeinterface 2 1 0
/*    */     //   6: astore_3
/*    */     //   7: aload_2
/*    */     //   8: invokeinterface 3 1 0
/*    */     //   13: astore 4
/*    */     //   15: aload_1
/*    */     //   16: invokeinterface 2 1 0
/*    */     //   21: aload 4
/*    */     //   23: ldc 4
/*    */     //   25: iconst_0
/*    */     //   26: invokevirtual 5	com/alibaba/dubbo/common/URL:getMethodParameter	(Ljava/lang/String;Ljava/lang/String;I)I
/*    */     //   29: istore 5
/*    */     //   31: aload_1
/*    */     //   32: invokeinterface 2 1 0
/*    */     //   37: aload_2
/*    */     //   38: invokeinterface 3 1 0
/*    */     //   43: invokestatic 6	com/alibaba/dubbo/rpc/RpcStatus:getStatus	(Lcom/alibaba/dubbo/common/URL;Ljava/lang/String;)Lcom/alibaba/dubbo/rpc/RpcStatus;
/*    */     //   46: astore 6
/*    */     //   48: iload 5
/*    */     //   50: ifle +206 -> 256
/*    */     //   53: aload_1
/*    */     //   54: invokeinterface 2 1 0
/*    */     //   59: aload_2
/*    */     //   60: invokeinterface 3 1 0
/*    */     //   65: ldc 7
/*    */     //   67: iconst_0
/*    */     //   68: invokevirtual 5	com/alibaba/dubbo/common/URL:getMethodParameter	(Ljava/lang/String;Ljava/lang/String;I)I
/*    */     //   71: i2l
/*    */     //   72: lstore 7
/*    */     //   74: invokestatic 8	java/lang/System:currentTimeMillis	()J
/*    */     //   77: lstore 9
/*    */     //   79: lload 7
/*    */     //   81: lstore 11
/*    */     //   83: aload 6
/*    */     //   85: invokevirtual 9	com/alibaba/dubbo/rpc/RpcStatus:getActive	()I
/*    */     //   88: istore 13
/*    */     //   90: iload 13
/*    */     //   92: iload 5
/*    */     //   94: if_icmplt +162 -> 256
/*    */     //   97: aload 6
/*    */     //   99: dup
/*    */     //   100: astore 14
/*    */     //   102: monitorenter
/*    */     //   103: aload 6
/*    */     //   105: invokevirtual 9	com/alibaba/dubbo/rpc/RpcStatus:getActive	()I
/*    */     //   108: dup
/*    */     //   109: istore 13
/*    */     //   111: iload 5
/*    */     //   113: if_icmplt +129 -> 242
/*    */     //   116: aload 6
/*    */     //   118: lload 11
/*    */     //   120: invokevirtual 10	java/lang/Object:wait	(J)V
/*    */     //   123: goto +5 -> 128
/*    */     //   126: astore 15
/*    */     //   128: invokestatic 8	java/lang/System:currentTimeMillis	()J
/*    */     //   131: lload 9
/*    */     //   133: lsub
/*    */     //   134: lstore 15
/*    */     //   136: lload 7
/*    */     //   138: lload 15
/*    */     //   140: lsub
/*    */     //   141: lstore 11
/*    */     //   143: lload 11
/*    */     //   145: lconst_0
/*    */     //   146: lcmp
/*    */     //   147: ifgt +92 -> 239
/*    */     //   150: new 12	com/alibaba/dubbo/rpc/RpcException
/*    */     //   153: dup
/*    */     //   154: new 13	java/lang/StringBuilder
/*    */     //   157: dup
/*    */     //   158: invokespecial 14	java/lang/StringBuilder:<init>	()V
/*    */     //   161: ldc 15
/*    */     //   163: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   166: aload_1
/*    */     //   167: invokeinterface 17 1 0
/*    */     //   172: invokevirtual 18	java/lang/Class:getName	()Ljava/lang/String;
/*    */     //   175: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   178: ldc 19
/*    */     //   180: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   183: aload_2
/*    */     //   184: invokeinterface 3 1 0
/*    */     //   189: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   192: ldc 20
/*    */     //   194: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   197: lload 15
/*    */     //   199: invokevirtual 21	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
/*    */     //   202: ldc 22
/*    */     //   204: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   207: lload 7
/*    */     //   209: invokevirtual 21	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
/*    */     //   212: ldc 23
/*    */     //   214: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   217: iload 13
/*    */     //   219: invokevirtual 24	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*    */     //   222: ldc 25
/*    */     //   224: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   227: iload 5
/*    */     //   229: invokevirtual 24	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*    */     //   232: invokevirtual 26	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   235: invokespecial 27	com/alibaba/dubbo/rpc/RpcException:<init>	(Ljava/lang/String;)V
/*    */     //   238: athrow
/*    */     //   239: goto -136 -> 103
/*    */     //   242: aload 14
/*    */     //   244: monitorexit
/*    */     //   245: goto +11 -> 256
/*    */     //   248: astore 17
/*    */     //   250: aload 14
/*    */     //   252: monitorexit
/*    */     //   253: aload 17
/*    */     //   255: athrow
/*    */     //   256: invokestatic 8	java/lang/System:currentTimeMillis	()J
/*    */     //   259: lstore 7
/*    */     //   261: aload_3
/*    */     //   262: aload 4
/*    */     //   264: invokestatic 28	com/alibaba/dubbo/rpc/RpcStatus:beginCount	(Lcom/alibaba/dubbo/common/URL;Ljava/lang/String;)V
/*    */     //   267: aload_1
/*    */     //   268: aload_2
/*    */     //   269: invokeinterface 29 2 0
/*    */     //   274: astore 9
/*    */     //   276: aload_3
/*    */     //   277: aload 4
/*    */     //   279: invokestatic 8	java/lang/System:currentTimeMillis	()J
/*    */     //   282: lload 7
/*    */     //   284: lsub
/*    */     //   285: iconst_1
/*    */     //   286: invokestatic 30	com/alibaba/dubbo/rpc/RpcStatus:endCount	(Lcom/alibaba/dubbo/common/URL;Ljava/lang/String;JZ)V
/*    */     //   289: aload 9
/*    */     //   291: astore 10
/*    */     //   293: jsr +32 -> 325
/*    */     //   296: aload 10
/*    */     //   298: areturn
/*    */     //   299: astore 9
/*    */     //   301: aload_3
/*    */     //   302: aload 4
/*    */     //   304: invokestatic 8	java/lang/System:currentTimeMillis	()J
/*    */     //   307: lload 7
/*    */     //   309: lsub
/*    */     //   310: iconst_0
/*    */     //   311: invokestatic 30	com/alibaba/dubbo/rpc/RpcStatus:endCount	(Lcom/alibaba/dubbo/common/URL;Ljava/lang/String;JZ)V
/*    */     //   314: aload 9
/*    */     //   316: athrow
/*    */     //   317: astore 18
/*    */     //   319: jsr +6 -> 325
/*    */     //   322: aload 18
/*    */     //   324: athrow
/*    */     //   325: astore 19
/*    */     //   327: iload 5
/*    */     //   329: ifle +28 -> 357
/*    */     //   332: aload 6
/*    */     //   334: dup
/*    */     //   335: astore 20
/*    */     //   337: monitorenter
/*    */     //   338: aload 6
/*    */     //   340: invokevirtual 32	java/lang/Object:notify	()V
/*    */     //   343: aload 20
/*    */     //   345: monitorexit
/*    */     //   346: goto +11 -> 357
/*    */     //   349: astore 21
/*    */     //   351: aload 20
/*    */     //   353: monitorexit
/*    */     //   354: aload 21
/*    */     //   356: athrow
/*    */     //   357: ret 19
/*    */     //
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   116	123	126	java/lang/InterruptedException
/*    */     //   103	245	248	finally
/*    */     //   248	253	248	finally
/*    */     //   267	293	299	java/lang/RuntimeException
/*    */     //   256	296	317	finally
/*    */     //   299	322	317	finally
/*    */     //   338	346	349	finally
/*    */     //   349	354	349	finally
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.ActiveLimitFilter
 * JD-Core Version:    0.6.2
 */