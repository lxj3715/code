/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ 
/*    */ @Activate(group={"provider"}, order=-30000)
/*    */ public class ClassLoaderFilter
/*    */   implements Filter
/*    */ {
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation)
/*    */     throws RpcException
/*    */   {
/* 35 */     ClassLoader ocl = Thread.currentThread().getContextClassLoader();
/* 36 */     Thread.currentThread().setContextClassLoader(invoker.getInterface().getClassLoader());
/*    */     try {
/* 38 */       return invoker.invoke(invocation);
/*    */     } finally {
/* 40 */       Thread.currentThread().setContextClassLoader(ocl);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.ClassLoaderFilter
 * JD-Core Version:    0.6.2
 */