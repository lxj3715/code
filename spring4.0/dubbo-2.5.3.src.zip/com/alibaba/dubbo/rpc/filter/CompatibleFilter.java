/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.common.utils.CompatibleTypeUtils;
/*    */ import com.alibaba.dubbo.common.utils.PojoUtils;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.RpcResult;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class CompatibleFilter
/*    */   implements Filter
/*    */ {
/* 40 */   private static Logger logger = LoggerFactory.getLogger(CompatibleFilter.class);
/*    */ 
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
/* 43 */     Result result = invoker.invoke(invocation);
/* 44 */     if ((!invocation.getMethodName().startsWith("$")) && (!result.hasException())) {
/* 45 */       Object value = result.getValue();
/* 46 */       if (value != null) {
/*    */         try {
/* 48 */           Method method = invoker.getInterface().getMethod(invocation.getMethodName(), invocation.getParameterTypes());
/* 49 */           Class type = method.getReturnType();
/*    */ 
/* 51 */           String serialization = invoker.getUrl().getParameter("serialization");
/*    */           Object newValue;
/*    */           Object newValue;
/* 52 */           if (("json".equals(serialization)) || ("fastjson".equals(serialization)))
/*    */           {
/* 54 */             Type gtype = method.getGenericReturnType();
/* 55 */             newValue = PojoUtils.realize(value, type, gtype);
/*    */           }
/*    */           else
/*    */           {
/*    */             Object newValue;
/* 56 */             if (!type.isInstance(value)) {
/* 57 */               newValue = PojoUtils.isPojo(type) ? PojoUtils.realize(value, type) : CompatibleTypeUtils.compatibleTypeConvert(value, type);
/*    */             }
/*    */             else
/*    */             {
/* 62 */               newValue = value;
/*    */             }
/*    */           }
/* 64 */           if (newValue != value)
/* 65 */             result = new RpcResult(newValue);
/*    */         }
/*    */         catch (Throwable t) {
/* 68 */           logger.warn(t.getMessage(), t);
/*    */         }
/*    */       }
/*    */     }
/* 72 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.CompatibleFilter
 * JD-Core Version:    0.6.2
 */