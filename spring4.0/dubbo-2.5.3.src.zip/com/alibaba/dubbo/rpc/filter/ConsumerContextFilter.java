/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.utils.NetUtils;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcContext;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*    */ 
/*    */ @Activate(group={"consumer"}, order=-10000)
/*    */ public class ConsumerContextFilter
/*    */   implements Filter
/*    */ {
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation)
/*    */     throws RpcException
/*    */   {
/* 38 */     RpcContext.getContext().setInvoker(invoker).setInvocation(invocation).setLocalAddress(NetUtils.getLocalHost(), 0).setRemoteAddress(invoker.getUrl().getHost(), invoker.getUrl().getPort());
/*    */ 
/* 44 */     if ((invocation instanceof RpcInvocation))
/* 45 */       ((RpcInvocation)invocation).setInvoker(invoker);
/*    */     try
/*    */     {
/* 48 */       return invoker.invoke(invocation);
/*    */     } finally {
/* 50 */       RpcContext.getContext().clearAttachments();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.ConsumerContextFilter
 * JD-Core Version:    0.6.2
 */