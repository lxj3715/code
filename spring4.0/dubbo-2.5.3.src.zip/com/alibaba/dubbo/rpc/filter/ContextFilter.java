/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcContext;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ @Activate(group={"provider"}, order=-10000)
/*    */ public class ContextFilter
/*    */   implements Filter
/*    */ {
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation)
/*    */     throws RpcException
/*    */   {
/* 40 */     Map attachments = invocation.getAttachments();
/* 41 */     if (attachments != null) {
/* 42 */       attachments = new HashMap(attachments);
/* 43 */       attachments.remove("path");
/* 44 */       attachments.remove("group");
/* 45 */       attachments.remove("version");
/* 46 */       attachments.remove("dubbo");
/* 47 */       attachments.remove("token");
/* 48 */       attachments.remove("timeout");
/*    */     }
/* 50 */     RpcContext.getContext().setInvoker(invoker).setInvocation(invocation).setAttachments(attachments).setLocalAddress(invoker.getUrl().getHost(), invoker.getUrl().getPort());
/*    */ 
/* 56 */     if ((invocation instanceof RpcInvocation))
/* 57 */       ((RpcInvocation)invocation).setInvoker(invoker);
/*    */     try
/*    */     {
/* 60 */       return invoker.invoke(invocation);
/*    */     } finally {
/* 62 */       RpcContext.removeContext();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.ContextFilter
 * JD-Core Version:    0.6.2
 */