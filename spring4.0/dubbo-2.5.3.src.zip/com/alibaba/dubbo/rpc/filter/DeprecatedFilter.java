/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.common.utils.ConcurrentHashSet;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import java.util.Set;
/*    */ 
/*    */ @Activate(group={"consumer"}, value={"deprecated"})
/*    */ public class DeprecatedFilter
/*    */   implements Filter
/*    */ {
/* 39 */   private static final Logger LOGGER = LoggerFactory.getLogger(DeprecatedFilter.class);
/*    */ 
/* 41 */   private static final Set<String> logged = new ConcurrentHashSet();
/*    */ 
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
/* 44 */     String key = invoker.getInterface().getName() + "." + invocation.getMethodName();
/* 45 */     if (!logged.contains(key)) {
/* 46 */       logged.add(key);
/* 47 */       if (invoker.getUrl().getMethodParameter(invocation.getMethodName(), "deprecated", false)) {
/* 48 */         LOGGER.error("The service method " + invoker.getInterface().getName() + "." + getMethodSignature(invocation) + " is DEPRECATED! Declare from " + invoker.getUrl());
/*    */       }
/*    */     }
/* 51 */     return invoker.invoke(invocation);
/*    */   }
/*    */ 
/*    */   private String getMethodSignature(Invocation invocation) {
/* 55 */     StringBuilder buf = new StringBuilder(invocation.getMethodName());
/* 56 */     buf.append("(");
/* 57 */     Class[] types = invocation.getParameterTypes();
/* 58 */     if ((types != null) && (types.length > 0)) {
/* 59 */       boolean first = true;
/* 60 */       for (Class type : types) {
/* 61 */         if (first)
/* 62 */           first = false;
/*    */         else {
/* 64 */           buf.append(", ");
/*    */         }
/* 66 */         buf.append(type.getSimpleName());
/*    */       }
/*    */     }
/* 69 */     buf.append(")");
/* 70 */     return buf.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.DeprecatedFilter
 * JD-Core Version:    0.6.2
 */