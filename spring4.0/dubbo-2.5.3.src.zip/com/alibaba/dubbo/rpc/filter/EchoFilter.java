/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.RpcResult;
/*    */ 
/*    */ @Activate(group={"provider"}, order=-110000)
/*    */ public class EchoFilter
/*    */   implements Filter
/*    */ {
/*    */   public Result invoke(Invoker<?> invoker, Invocation inv)
/*    */     throws RpcException
/*    */   {
/* 36 */     if ((inv.getMethodName().equals("$echo")) && (inv.getArguments() != null) && (inv.getArguments().length == 1))
/* 37 */       return new RpcResult(inv.getArguments()[0]);
/* 38 */     return invoker.invoke(inv);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.EchoFilter
 * JD-Core Version:    0.6.2
 */