/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*    */ import com.alibaba.dubbo.common.utils.StringUtils;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcContext;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.RpcResult;
/*    */ import com.alibaba.dubbo.rpc.service.GenericService;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ @Activate(group={"provider"})
/*    */ public class ExceptionFilter
/*    */   implements Filter
/*    */ {
/*    */   private final Logger logger;
/*    */ 
/*    */   public ExceptionFilter()
/*    */   {
/* 55 */     this(LoggerFactory.getLogger(ExceptionFilter.class));
/*    */   }
/*    */ 
/*    */   public ExceptionFilter(Logger logger) {
/* 59 */     this.logger = logger;
/*    */   }
/*    */ 
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
/*    */     try {
/* 64 */       Result result = invoker.invoke(invocation);
/* 65 */       if ((result.hasException()) && (GenericService.class != invoker.getInterface())) {
/*    */         try {
/* 67 */           Throwable exception = result.getException();
/*    */ 
/* 70 */           if ((!(exception instanceof RuntimeException)) && ((exception instanceof Exception))) {
/* 71 */             return result;
/*    */           }
/*    */           try
/*    */           {
/* 75 */             Method method = invoker.getInterface().getMethod(invocation.getMethodName(), invocation.getParameterTypes());
/* 76 */             Class[] exceptionClassses = method.getExceptionTypes();
/* 77 */             for (Class exceptionClass : exceptionClassses)
/* 78 */               if (exception.getClass().equals(exceptionClass))
/* 79 */                 return result;
/*    */           }
/*    */           catch (NoSuchMethodException e)
/*    */           {
/* 83 */             return result;
/*    */           }
/*    */ 
/* 87 */           this.logger.error("Got unchecked and undeclared exception which called by " + RpcContext.getContext().getRemoteHost() + ". service: " + invoker.getInterface().getName() + ", method: " + invocation.getMethodName() + ", exception: " + exception.getClass().getName() + ": " + exception.getMessage(), exception);
/*    */ 
/* 92 */           String serviceFile = ReflectUtils.getCodeBase(invoker.getInterface());
/* 93 */           String exceptionFile = ReflectUtils.getCodeBase(exception.getClass());
/* 94 */           if ((serviceFile == null) || (exceptionFile == null) || (serviceFile.equals(exceptionFile))) {
/* 95 */             return result;
/*    */           }
/*    */ 
/* 98 */           String className = exception.getClass().getName();
/* 99 */           if ((className.startsWith("java.")) || (className.startsWith("javax."))) {
/* 100 */             return result;
/*    */           }
/*    */ 
/* 103 */           if ((exception instanceof RpcException)) {
/* 104 */             return result;
/*    */           }
/*    */ 
/* 108 */           return new RpcResult(new RuntimeException(StringUtils.toString(exception)));
/*    */         } catch (Throwable e) {
/* 110 */           this.logger.warn("Fail to ExceptionFilter when called by " + RpcContext.getContext().getRemoteHost() + ". service: " + invoker.getInterface().getName() + ", method: " + invocation.getMethodName() + ", exception: " + e.getClass().getName() + ": " + e.getMessage(), e);
/*    */ 
/* 113 */           return result;
/*    */         }
/*    */       }
/* 116 */       return result;
/*    */     } catch (RuntimeException e) {
/* 118 */       this.logger.error("Got unchecked and undeclared exception which called by " + RpcContext.getContext().getRemoteHost() + ". service: " + invoker.getInterface().getName() + ", method: " + invocation.getMethodName() + ", exception: " + e.getClass().getName() + ": " + e.getMessage(), e);
/*    */ 
/* 121 */       throw e;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.ExceptionFilter
 * JD-Core Version:    0.6.2
 */