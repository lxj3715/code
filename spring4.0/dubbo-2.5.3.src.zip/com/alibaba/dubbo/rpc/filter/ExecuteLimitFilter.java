/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.RpcStatus;
/*    */ 
/*    */ @Activate(group={"provider"}, value={"executes"})
/*    */ public class ExecuteLimitFilter
/*    */   implements Filter
/*    */ {
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation)
/*    */     throws RpcException
/*    */   {
/* 37 */     URL url = invoker.getUrl();
/* 38 */     String methodName = invocation.getMethodName();
/* 39 */     int max = url.getMethodParameter(methodName, "executes", 0);
/* 40 */     if (max > 0) {
/* 41 */       RpcStatus count = RpcStatus.getStatus(url, invocation.getMethodName());
/* 42 */       if (count.getActive() >= max) {
/* 43 */         throw new RpcException("Failed to invoke method " + invocation.getMethodName() + " in provider " + url + ", cause: The service using threads greater than <dubbo:service executes=\"" + max + "\" /> limited.");
/*    */       }
/*    */     }
/* 46 */     long begin = System.currentTimeMillis();
/* 47 */     boolean isException = false;
/* 48 */     RpcStatus.beginCount(url, methodName);
/*    */     try {
/* 50 */       Result result = invoker.invoke(invocation);
/* 51 */       return result;
/*    */     } catch (Throwable t) {
/* 53 */       isException = true;
/* 54 */       if ((t instanceof RuntimeException)) {
/* 55 */         throw ((RuntimeException)t);
/*    */       }
/*    */ 
/* 58 */       throw new RpcException("unexpected exception when ExecuteLimitFilter", t);
/*    */     }
/*    */     finally
/*    */     {
/* 62 */       RpcStatus.endCount(url, methodName, System.currentTimeMillis() - begin, isException);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.ExecuteLimitFilter
 * JD-Core Version:    0.6.2
 */