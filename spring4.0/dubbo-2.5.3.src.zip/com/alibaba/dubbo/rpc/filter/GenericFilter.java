/*     */ package com.alibaba.dubbo.rpc.filter;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.Activate;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.io.UnsafeByteArrayInputStream;
/*     */ import com.alibaba.dubbo.common.io.UnsafeByteArrayOutputStream;
/*     */ import com.alibaba.dubbo.common.serialize.ObjectInput;
/*     */ import com.alibaba.dubbo.common.serialize.ObjectOutput;
/*     */ import com.alibaba.dubbo.common.serialize.Serialization;
/*     */ import com.alibaba.dubbo.common.utils.PojoUtils;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.rpc.Filter;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*     */ import com.alibaba.dubbo.rpc.RpcResult;
/*     */ import com.alibaba.dubbo.rpc.service.GenericException;
/*     */ import com.alibaba.dubbo.rpc.support.ProtocolUtils;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ @Activate(group={"provider"}, order=-20000)
/*     */ public class GenericFilter
/*     */   implements Filter
/*     */ {
/*     */   public Result invoke(Invoker<?> invoker, Invocation inv)
/*     */     throws RpcException
/*     */   {
/*  49 */     if ((inv.getMethodName().equals("$invoke")) && (inv.getArguments() != null) && (inv.getArguments().length == 3) && (!invoker.getUrl().getParameter("generic", false)))
/*     */     {
/*  53 */       String name = ((String)inv.getArguments()[0]).trim();
/*  54 */       String[] types = (String[])inv.getArguments()[1];
/*  55 */       Object[] args = (Object[])inv.getArguments()[2];
/*     */       try {
/*  57 */         Method method = ReflectUtils.findMethodByMethodSignature(invoker.getInterface(), name, types);
/*  58 */         Class[] params = method.getParameterTypes();
/*  59 */         if (args == null) {
/*  60 */           args = new Object[params.length];
/*     */         }
/*  62 */         String generic = inv.getAttachment("generic");
/*  63 */         if ((StringUtils.isEmpty(generic)) || (ProtocolUtils.isDefaultGenericSerialization(generic)))
/*     */         {
/*  65 */           args = PojoUtils.realize(args, params, method.getGenericParameterTypes());
/*  66 */         } else if (ProtocolUtils.isJavaGenericSerialization(generic)) {
/*  67 */           for (int i = 0; i < args.length; i++) {
/*  68 */             if ([B.class == args[i].getClass())
/*     */               try {
/*  70 */                 UnsafeByteArrayInputStream is = new UnsafeByteArrayInputStream((byte[])args[i]);
/*  71 */                 args[i] = ((Serialization)ExtensionLoader.getExtensionLoader(Serialization.class).getExtension("nativejava")).deserialize(null, is).readObject();
/*     */               }
/*     */               catch (Exception e)
/*     */               {
/*  75 */                 throw new RpcException("Deserialize argument [" + (i + 1) + "] failed.", e);
/*     */               }
/*     */             else {
/*  78 */               throw new RpcException(32 + "Generic serialization [" + "nativejava" + "] only support message type " + [B.class + " and your message type is " + args[i].getClass());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  88 */         Result result = invoker.invoke(new RpcInvocation(method, args, inv.getAttachments()));
/*  89 */         if ((result.hasException()) && (!(result.getException() instanceof GenericException)))
/*     */         {
/*  91 */           return new RpcResult(new GenericException(result.getException()));
/*     */         }
/*  93 */         if (ProtocolUtils.isJavaGenericSerialization(generic)) {
/*     */           try {
/*  95 */             UnsafeByteArrayOutputStream os = new UnsafeByteArrayOutputStream(512);
/*  96 */             ((Serialization)ExtensionLoader.getExtensionLoader(Serialization.class).getExtension("nativejava")).serialize(null, os).writeObject(result.getValue());
/*     */ 
/*  99 */             return new RpcResult(os.toByteArray());
/*     */           } catch (IOException e) {
/* 101 */             throw new RpcException("Serialize result failed.", e);
/*     */           }
/*     */         }
/* 104 */         return new RpcResult(PojoUtils.generalize(result.getValue()));
/*     */       }
/*     */       catch (NoSuchMethodException e) {
/* 107 */         throw new RpcException(e.getMessage(), e);
/*     */       } catch (ClassNotFoundException e) {
/* 109 */         throw new RpcException(e.getMessage(), e);
/*     */       }
/*     */     }
/* 112 */     return invoker.invoke(inv);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.GenericFilter
 * JD-Core Version:    0.6.2
 */