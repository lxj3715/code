/*     */ package com.alibaba.dubbo.rpc.filter;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.Activate;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.PojoUtils;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.rpc.Filter;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*     */ import com.alibaba.dubbo.rpc.RpcResult;
/*     */ import com.alibaba.dubbo.rpc.service.GenericException;
/*     */ import com.alibaba.dubbo.rpc.support.ProtocolUtils;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ @Activate(group={"consumer"}, value={"generic"}, order=20000)
/*     */ public class GenericImplFilter
/*     */   implements Filter
/*     */ {
/*  46 */   private static final Logger logger = LoggerFactory.getLogger(GenericImplFilter.class);
/*     */ 
/*  48 */   private static final Class<?>[] GENERIC_PARAMETER_TYPES = { String.class, [Ljava.lang.String.class, [Ljava.lang.Object.class };
/*     */ 
/*     */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
/*  51 */     String generic = invoker.getUrl().getParameter("generic");
/*  52 */     if ((ProtocolUtils.isGeneric(generic)) && (!"$invoke".equals(invocation.getMethodName())) && ((invocation instanceof RpcInvocation)))
/*     */     {
/*  55 */       RpcInvocation invocation2 = (RpcInvocation)invocation;
/*  56 */       String methodName = invocation2.getMethodName();
/*  57 */       Class[] parameterTypes = invocation2.getParameterTypes();
/*  58 */       Object[] arguments = invocation2.getArguments();
/*     */ 
/*  60 */       String[] types = new String[parameterTypes.length];
/*  61 */       for (int i = 0; i < parameterTypes.length; i++) {
/*  62 */         types[i] = ReflectUtils.getName(parameterTypes[i]);
/*     */       }
/*  64 */       Object[] args = PojoUtils.generalize(arguments);
/*     */ 
/*  66 */       invocation2.setMethodName("$invoke");
/*  67 */       invocation2.setParameterTypes(GENERIC_PARAMETER_TYPES);
/*  68 */       invocation2.setArguments(new Object[] { methodName, types, args });
/*  69 */       Result result = invoker.invoke(invocation2);
/*     */ 
/*  71 */       if (!result.hasException()) {
/*  72 */         Object value = result.getValue();
/*     */         try {
/*  74 */           Method method = invoker.getInterface().getMethod(methodName, parameterTypes);
/*  75 */           return new RpcResult(PojoUtils.realize(value, method.getReturnType(), method.getGenericReturnType()));
/*     */         } catch (NoSuchMethodException e) {
/*  77 */           throw new RpcException(e.getMessage(), e);
/*     */         }
/*     */       }
/*  79 */       if ((result.getException() instanceof GenericException)) {
/*  80 */         GenericException exception = (GenericException)result.getException();
/*     */         try { String className = exception.getExceptionClass();
/*  83 */           Class clazz = ReflectUtils.forName(className);
/*  84 */           Throwable targetException = null;
/*  85 */           Throwable lastException = null;
/*     */           Constructor[] arr$;
/*     */           int len$;
/*     */           int i$;
/*     */           try { targetException = (Throwable)clazz.newInstance();
/*     */           } catch (Throwable e) {
/*  89 */             lastException = e;
/*  90 */             arr$ = clazz.getConstructors(); len$ = arr$.length; i$ = 0; } for (; i$ < len$; i$++) { Constructor constructor = arr$[i$];
/*     */             try {
/*  92 */               targetException = (Throwable)constructor.newInstance(new Object[constructor.getParameterTypes().length]);
/*     */             }
/*     */             catch (Throwable e1) {
/*  95 */               lastException = e1;
/*     */             }
/*     */           }
/*     */ 
/*  99 */           if (targetException != null) {
/*     */             try {
/* 101 */               Field field = Throwable.class.getDeclaredField("detailMessage");
/* 102 */               if (!field.isAccessible()) {
/* 103 */                 field.setAccessible(true);
/*     */               }
/* 105 */               field.set(targetException, exception.getExceptionMessage());
/*     */             } catch (Throwable e) {
/* 107 */               logger.warn(e.getMessage(), e);
/*     */             }
/* 109 */             result = new RpcResult(targetException);
/* 110 */           } else if (lastException != null) {
/* 111 */             throw lastException;
/*     */           }
/*     */         } catch (Throwable e) {
/* 114 */           throw new RpcException("Can not deserialize exception " + exception.getExceptionClass() + ", message: " + exception.getExceptionMessage(), e);
/*     */         }
/*     */       }
/* 117 */       return result;
/*     */     }
/*     */ 
/* 120 */     if ((invocation.getMethodName().equals("$invoke")) && (invocation.getArguments() != null) && (invocation.getArguments().length == 3) && (ProtocolUtils.isGeneric(generic)))
/*     */     {
/* 125 */       if (ProtocolUtils.isJavaGenericSerialization(generic)) {
/* 126 */         Object[] args = (Object[])invocation.getArguments()[2];
/*     */ 
/* 128 */         for (Object arg : args) {
/* 129 */           if ([B.class != arg.getClass()) {
/* 130 */             error(arg.getClass().getName());
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 135 */       ((RpcInvocation)invocation).setAttachment("generic", invoker.getUrl().getParameter("generic"));
/*     */     }
/*     */ 
/* 138 */     return invoker.invoke(invocation);
/*     */   }
/*     */ 
/*     */   private void error(String type) throws RpcException {
/* 142 */     throw new RpcException(32 + "Generic serialization [" + "nativejava" + "] only support message type " + [B.class + " and your message type is " + type);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.GenericImplFilter
 * JD-Core Version:    0.6.2
 */