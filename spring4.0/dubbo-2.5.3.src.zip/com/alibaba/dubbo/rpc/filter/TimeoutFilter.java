/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ @Activate(group={"provider"})
/*    */ public class TimeoutFilter
/*    */   implements Filter
/*    */ {
/* 38 */   private static final Logger logger = LoggerFactory.getLogger(TimeoutFilter.class);
/*    */ 
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
/* 41 */     long start = System.currentTimeMillis();
/* 42 */     Result result = invoker.invoke(invocation);
/* 43 */     long elapsed = System.currentTimeMillis() - start;
/* 44 */     if ((invoker.getUrl() != null) && (elapsed > invoker.getUrl().getMethodParameter(invocation.getMethodName(), "timeout", 2147483647)))
/*    */     {
/* 47 */       if (logger.isWarnEnabled()) {
/* 48 */         logger.warn("invoke time out. method: " + invocation.getMethodName() + "arguments: " + Arrays.toString(invocation.getArguments()) + " , url is " + invoker.getUrl() + ", invoke elapsed " + elapsed + " ms.");
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 53 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.TimeoutFilter
 * JD-Core Version:    0.6.2
 */