/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcContext;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import java.util.Map;
/*    */ 
/*    */ @Activate(group={"provider"}, value={"token"})
/*    */ public class TokenFilter
/*    */   implements Filter
/*    */ {
/*    */   public Result invoke(Invoker<?> invoker, Invocation inv)
/*    */     throws RpcException
/*    */   {
/* 40 */     String token = invoker.getUrl().getParameter("token");
/* 41 */     if (ConfigUtils.isNotEmpty(token)) {
/* 42 */       Class serviceType = invoker.getInterface();
/* 43 */       Map attachments = inv.getAttachments();
/* 44 */       String remoteToken = attachments == null ? null : (String)attachments.get("token");
/* 45 */       if (!token.equals(remoteToken)) {
/* 46 */         throw new RpcException("Invalid token! Forbid invoke remote service " + serviceType + " method " + inv.getMethodName() + "() from consumer " + RpcContext.getContext().getRemoteHost() + " to provider " + RpcContext.getContext().getLocalHost());
/*    */       }
/*    */     }
/* 49 */     return invoker.invoke(inv);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.TokenFilter
 * JD-Core Version:    0.6.2
 */