/*    */ package com.alibaba.dubbo.rpc.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.filter.tps.DefaultTPSLimiter;
/*    */ import com.alibaba.dubbo.rpc.filter.tps.TPSLimiter;
/*    */ 
/*    */ @Activate(group={"provider"}, value={"tps"})
/*    */ public class TpsLimitFilter
/*    */   implements Filter
/*    */ {
/* 37 */   private final TPSLimiter tpsLimiter = new DefaultTPSLimiter();
/*    */ 
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException
/*    */   {
/* 41 */     if (!this.tpsLimiter.isAllowable(invoker.getUrl(), invocation)) {
/* 42 */       throw new RpcException(64 + "Failed to invoke service " + invoker.getInterface().getName() + "." + invocation.getMethodName() + " because exceed max service tps.");
/*    */     }
/*    */ 
/* 52 */     return invoker.invoke(invocation);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.TpsLimitFilter
 * JD-Core Version:    0.6.2
 */