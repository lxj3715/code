/*    */ package com.alibaba.dubbo.rpc.filter.tps;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ public class DefaultTPSLimiter
/*    */   implements TPSLimiter
/*    */ {
/* 31 */   private final ConcurrentMap<String, StatItem> stats = new ConcurrentHashMap();
/*    */ 
/*    */   public boolean isAllowable(URL url, Invocation invocation)
/*    */   {
/* 35 */     int rate = url.getParameter("tps", -1);
/* 36 */     long interval = url.getParameter("tps.interval", 60000L);
/*    */ 
/* 38 */     String serviceKey = url.getServiceKey();
/* 39 */     if (rate > 0) {
/* 40 */       StatItem statItem = (StatItem)this.stats.get(serviceKey);
/* 41 */       if (statItem == null) {
/* 42 */         this.stats.putIfAbsent(serviceKey, new StatItem(serviceKey, rate, interval));
/*    */ 
/* 44 */         statItem = (StatItem)this.stats.get(serviceKey);
/*    */       }
/* 46 */       return statItem.isAllowable(url, invocation);
/*    */     }
/* 48 */     StatItem statItem = (StatItem)this.stats.get(serviceKey);
/* 49 */     if (statItem != null) {
/* 50 */       this.stats.remove(serviceKey);
/*    */     }
/*    */ 
/* 54 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.tps.DefaultTPSLimiter
 * JD-Core Version:    0.6.2
 */