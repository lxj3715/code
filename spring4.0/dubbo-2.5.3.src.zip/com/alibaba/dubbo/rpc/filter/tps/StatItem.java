/*    */ package com.alibaba.dubbo.rpc.filter.tps;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ class StatItem
/*    */ {
/*    */   private String name;
/*    */   private long lastResetTime;
/*    */   private long interval;
/*    */   private AtomicInteger token;
/*    */   private int rate;
/*    */ 
/*    */   StatItem(String name, int rate, long interval)
/*    */   {
/* 40 */     this.name = name;
/* 41 */     this.rate = rate;
/* 42 */     this.interval = interval;
/* 43 */     this.lastResetTime = System.currentTimeMillis();
/* 44 */     this.token = new AtomicInteger(rate);
/*    */   }
/*    */ 
/*    */   public boolean isAllowable(URL url, Invocation invocation) {
/* 48 */     long now = System.currentTimeMillis();
/* 49 */     if (now > this.lastResetTime + this.interval) {
/* 50 */       this.token.set(this.rate);
/* 51 */       this.lastResetTime = now;
/*    */     }
/*    */ 
/* 54 */     int value = this.token.get();
/* 55 */     boolean flag = false;
/* 56 */     while ((value > 0) && (!flag)) {
/* 57 */       flag = this.token.compareAndSet(value, value - 1);
/* 58 */       value = this.token.get();
/*    */     }
/*    */ 
/* 61 */     return flag;
/*    */   }
/*    */ 
/*    */   long getLastResetTime() {
/* 65 */     return this.lastResetTime;
/*    */   }
/*    */ 
/*    */   int getToken() {
/* 69 */     return this.token.get();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 73 */     return 32 + "StatItem " + "[name=" + this.name + ", " + "rate = " + this.rate + ", " + "interval = " + this.interval + "]";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.tps.StatItem
 * JD-Core Version:    0.6.2
 */