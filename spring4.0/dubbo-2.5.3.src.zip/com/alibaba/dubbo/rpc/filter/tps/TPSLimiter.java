package com.alibaba.dubbo.rpc.filter.tps;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.rpc.Invocation;

public abstract interface TPSLimiter
{
  public abstract boolean isAllowable(URL paramURL, Invocation paramInvocation);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.filter.tps.TPSLimiter
 * JD-Core Version:    0.6.2
 */