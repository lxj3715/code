/*    */ package com.alibaba.dubbo.rpc.listener;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ 
/*    */ @Activate({"deprecated"})
/*    */ public class DeprecatedInvokerListener extends InvokerListenerAdapter
/*    */ {
/* 33 */   private static final Logger LOGGER = LoggerFactory.getLogger(DeprecatedInvokerListener.class);
/*    */ 
/*    */   public void referred(Invoker<?> invoker) throws RpcException {
/* 36 */     if (invoker.getUrl().getParameter("deprecated", false))
/* 37 */       LOGGER.error("The service " + invoker.getInterface().getName() + " is DEPRECATED! Declare from " + invoker.getUrl());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.listener.DeprecatedInvokerListener
 * JD-Core Version:    0.6.2
 */