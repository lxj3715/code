package com.alibaba.dubbo.rpc.listener;

import com.alibaba.dubbo.rpc.Exporter;
import com.alibaba.dubbo.rpc.ExporterListener;
import com.alibaba.dubbo.rpc.RpcException;

public abstract class ExporterListenerAdapter
  implements ExporterListener
{
  public void exported(Exporter<?> exporter)
    throws RpcException
  {
  }

  public void unexported(Exporter<?> exporter)
    throws RpcException
  {
  }
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.listener.ExporterListenerAdapter
 * JD-Core Version:    0.6.2
 */