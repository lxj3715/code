package com.alibaba.dubbo.rpc.listener;

import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.InvokerListener;
import com.alibaba.dubbo.rpc.RpcException;

public abstract class InvokerListenerAdapter
  implements InvokerListener
{
  public void referred(Invoker<?> invoker)
    throws RpcException
  {
  }

  public void destroyed(Invoker<?> invoker)
  {
  }
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.listener.InvokerListenerAdapter
 * JD-Core Version:    0.6.2
 */