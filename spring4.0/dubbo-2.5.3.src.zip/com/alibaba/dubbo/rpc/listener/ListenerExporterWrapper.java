/*    */ package com.alibaba.dubbo.rpc.listener;
/*    */ 
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.rpc.Exporter;
/*    */ import com.alibaba.dubbo.rpc.ExporterListener;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ListenerExporterWrapper<T>
/*    */   implements Exporter<T>
/*    */ {
/* 33 */   private static final Logger logger = LoggerFactory.getLogger(ListenerExporterWrapper.class);
/*    */   private final Exporter<T> exporter;
/*    */   private final List<ExporterListener> listeners;
/*    */ 
/*    */   public ListenerExporterWrapper(Exporter<T> exporter, List<ExporterListener> listeners)
/*    */   {
/* 40 */     if (exporter == null) {
/* 41 */       throw new IllegalArgumentException("exporter == null");
/*    */     }
/* 43 */     this.exporter = exporter;
/* 44 */     this.listeners = listeners;
/* 45 */     if ((listeners != null) && (listeners.size() > 0)) {
/* 46 */       RuntimeException exception = null;
/* 47 */       for (ExporterListener listener : listeners) {
/* 48 */         if (listener != null) {
/*    */           try {
/* 50 */             listener.exported(this);
/*    */           } catch (RuntimeException t) {
/* 52 */             logger.error(t.getMessage(), t);
/* 53 */             exception = t;
/*    */           }
/*    */         }
/*    */       }
/* 57 */       if (exception != null)
/* 58 */         throw exception;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Invoker<T> getInvoker()
/*    */   {
/* 64 */     return this.exporter.getInvoker();
/*    */   }
/*    */ 
/*    */   public void unexport() {
/*    */     try {
/* 69 */       this.exporter.unexport();
/*    */     } finally {
/* 71 */       if ((this.listeners != null) && (this.listeners.size() > 0)) {
/* 72 */         RuntimeException exception = null;
/* 73 */         for (ExporterListener listener : this.listeners) {
/* 74 */           if (listener != null) {
/*    */             try {
/* 76 */               listener.unexported(this);
/*    */             } catch (RuntimeException t) {
/* 78 */               logger.error(t.getMessage(), t);
/* 79 */               exception = t;
/*    */             }
/*    */           }
/*    */         }
/* 83 */         if (exception != null)
/* 84 */           throw exception;
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.listener.ListenerExporterWrapper
 * JD-Core Version:    0.6.2
 */