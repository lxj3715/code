/*    */ package com.alibaba.dubbo.rpc.listener;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.InvokerListener;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ListenerInvokerWrapper<T>
/*    */   implements Invoker<T>
/*    */ {
/* 36 */   private static final Logger logger = LoggerFactory.getLogger(ListenerInvokerWrapper.class);
/*    */   private final Invoker<T> invoker;
/*    */   private final List<InvokerListener> listeners;
/*    */ 
/*    */   public ListenerInvokerWrapper(Invoker<T> invoker, List<InvokerListener> listeners)
/*    */   {
/* 43 */     if (invoker == null) {
/* 44 */       throw new IllegalArgumentException("invoker == null");
/*    */     }
/* 46 */     this.invoker = invoker;
/* 47 */     this.listeners = listeners;
/* 48 */     if ((listeners != null) && (listeners.size() > 0))
/* 49 */       for (InvokerListener listener : listeners)
/* 50 */         if (listener != null)
/*    */           try {
/* 52 */             listener.referred(invoker);
/*    */           } catch (Throwable t) {
/* 54 */             logger.error(t.getMessage(), t);
/*    */           }
/*    */   }
/*    */ 
/*    */   public Class<T> getInterface()
/*    */   {
/* 62 */     return this.invoker.getInterface();
/*    */   }
/*    */ 
/*    */   public URL getUrl() {
/* 66 */     return this.invoker.getUrl();
/*    */   }
/*    */ 
/*    */   public boolean isAvailable() {
/* 70 */     return this.invoker.isAvailable();
/*    */   }
/*    */ 
/*    */   public Result invoke(Invocation invocation) throws RpcException {
/* 74 */     return this.invoker.invoke(invocation);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 79 */     return getInterface() + " -> " + getUrl() == null ? " " : getUrl().toString();
/*    */   }
/*    */ 
/*    */   public void destroy() {
/*    */     try {
/* 84 */       this.invoker.destroy();
/*    */     } finally {
/* 86 */       if ((this.listeners != null) && (this.listeners.size() > 0))
/* 87 */         for (InvokerListener listener : this.listeners)
/* 88 */           if (listener != null)
/*    */             try {
/* 90 */               listener.destroyed(this.invoker);
/*    */             } catch (Throwable t) {
/* 92 */               logger.error(t.getMessage(), t);
/*    */             }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.listener.ListenerInvokerWrapper
 * JD-Core Version:    0.6.2
 */