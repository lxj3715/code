/*    */ package com.alibaba.dubbo.rpc.protocol;
/*    */ 
/*    */ import com.alibaba.dubbo.common.logger.Logger;
/*    */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*    */ import com.alibaba.dubbo.rpc.Exporter;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ 
/*    */ public abstract class AbstractExporter<T>
/*    */   implements Exporter<T>
/*    */ {
/* 31 */   protected final Logger logger = LoggerFactory.getLogger(getClass());
/*    */   private final Invoker<T> invoker;
/* 35 */   private volatile boolean unexported = false;
/*    */ 
/*    */   public AbstractExporter(Invoker<T> invoker) {
/* 38 */     if (invoker == null)
/* 39 */       throw new IllegalStateException("service invoker == null");
/* 40 */     if (invoker.getInterface() == null)
/* 41 */       throw new IllegalStateException("service type == null");
/* 42 */     if (invoker.getUrl() == null)
/* 43 */       throw new IllegalStateException("service url == null");
/* 44 */     this.invoker = invoker;
/*    */   }
/*    */ 
/*    */   public Invoker<T> getInvoker() {
/* 48 */     return this.invoker;
/*    */   }
/*    */ 
/*    */   public void unexport() {
/* 52 */     if (this.unexported) {
/* 53 */       return;
/*    */     }
/* 55 */     this.unexported = true;
/* 56 */     getInvoker().destroy();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 60 */     return getInvoker().toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.protocol.AbstractExporter
 * JD-Core Version:    0.6.2
 */