/*     */ package com.alibaba.dubbo.rpc.protocol;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcContext;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*     */ import com.alibaba.dubbo.rpc.RpcResult;
/*     */ import com.alibaba.dubbo.rpc.support.RpcUtils;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class AbstractInvoker<T>
/*     */   implements Invoker<T>
/*     */ {
/*  46 */   protected final Logger logger = LoggerFactory.getLogger(getClass());
/*     */   private final Class<T> type;
/*     */   private final URL url;
/*     */   private final Map<String, String> attachment;
/*  54 */   private volatile boolean available = true;
/*     */ 
/*  56 */   private volatile boolean destroyed = false;
/*     */ 
/*     */   public AbstractInvoker(Class<T> type, URL url) {
/*  59 */     this(type, url, (Map)null);
/*     */   }
/*     */ 
/*     */   public AbstractInvoker(Class<T> type, URL url, String[] keys) {
/*  63 */     this(type, url, convertAttachment(url, keys));
/*     */   }
/*     */ 
/*     */   public AbstractInvoker(Class<T> type, URL url, Map<String, String> attachment) {
/*  67 */     if (type == null)
/*  68 */       throw new IllegalArgumentException("service type == null");
/*  69 */     if (url == null)
/*  70 */       throw new IllegalArgumentException("service url == null");
/*  71 */     this.type = type;
/*  72 */     this.url = url;
/*  73 */     this.attachment = (attachment == null ? null : Collections.unmodifiableMap(attachment));
/*     */   }
/*     */ 
/*     */   private static Map<String, String> convertAttachment(URL url, String[] keys) {
/*  77 */     if ((keys == null) || (keys.length == 0)) {
/*  78 */       return null;
/*     */     }
/*  80 */     Map attachment = new HashMap();
/*  81 */     for (String key : keys) {
/*  82 */       String value = url.getParameter(key);
/*  83 */       if ((value != null) && (value.length() > 0)) {
/*  84 */         attachment.put(key, value);
/*     */       }
/*     */     }
/*  87 */     return attachment;
/*     */   }
/*     */ 
/*     */   public Class<T> getInterface() {
/*  91 */     return this.type;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/*  95 */     return this.url;
/*     */   }
/*     */ 
/*     */   public boolean isAvailable() {
/*  99 */     return this.available;
/*     */   }
/*     */ 
/*     */   protected void setAvailable(boolean available) {
/* 103 */     this.available = available;
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 107 */     if (isDestroyed()) {
/* 108 */       return;
/*     */     }
/* 110 */     this.destroyed = true;
/* 111 */     setAvailable(false);
/*     */   }
/*     */ 
/*     */   public boolean isDestroyed() {
/* 115 */     return this.destroyed;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 119 */     return getInterface() + " -> " + (getUrl() == null ? "" : getUrl().toString());
/*     */   }
/*     */ 
/*     */   public Result invoke(Invocation inv) throws RpcException {
/* 123 */     if (this.destroyed) {
/* 124 */       throw new RpcException("Rpc invoker for service " + this + " on consumer " + NetUtils.getLocalHost() + " use dubbo version " + Version.getVersion() + " is DESTROYED, can not be invoked any more!");
/*     */     }
/*     */ 
/* 128 */     RpcInvocation invocation = (RpcInvocation)inv;
/* 129 */     invocation.setInvoker(this);
/* 130 */     if ((this.attachment != null) && (this.attachment.size() > 0)) {
/* 131 */       invocation.addAttachmentsIfAbsent(this.attachment);
/*     */     }
/* 133 */     Map context = RpcContext.getContext().getAttachments();
/* 134 */     if (context != null) {
/* 135 */       invocation.addAttachmentsIfAbsent(context);
/*     */     }
/* 137 */     if (getUrl().getMethodParameter(invocation.getMethodName(), "async", false)) {
/* 138 */       invocation.setAttachment("async", Boolean.TRUE.toString());
/*     */     }
/* 140 */     RpcUtils.attachInvocationIdIfAsync(getUrl(), invocation);
/*     */     try
/*     */     {
/* 144 */       return doInvoke(invocation);
/*     */     } catch (InvocationTargetException e) {
/* 146 */       Throwable te = e.getTargetException();
/* 147 */       if (te == null) {
/* 148 */         return new RpcResult(e);
/*     */       }
/* 150 */       if ((te instanceof RpcException)) {
/* 151 */         ((RpcException)te).setCode(3);
/*     */       }
/* 153 */       return new RpcResult(te);
/*     */     }
/*     */     catch (RpcException e) {
/* 156 */       if (e.isBiz()) {
/* 157 */         return new RpcResult(e);
/*     */       }
/* 159 */       throw e;
/*     */     }
/*     */     catch (Throwable e) {
/* 162 */       return new RpcResult(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract Result doInvoke(Invocation paramInvocation)
/*     */     throws Throwable;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.protocol.AbstractInvoker
 * JD-Core Version:    0.6.2
 */