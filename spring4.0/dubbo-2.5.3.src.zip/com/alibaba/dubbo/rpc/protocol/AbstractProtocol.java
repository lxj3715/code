/*     */ package com.alibaba.dubbo.rpc.protocol;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ConcurrentHashSet;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.rpc.Exporter;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Protocol;
/*     */ import com.alibaba.dubbo.rpc.support.ProtocolUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ public abstract class AbstractProtocol
/*     */   implements Protocol
/*     */ {
/*  42 */   protected final Logger logger = LoggerFactory.getLogger(getClass());
/*     */ 
/*  44 */   protected final Map<String, Exporter<?>> exporterMap = new ConcurrentHashMap();
/*     */ 
/*  47 */   protected final Set<Invoker<?>> invokers = new ConcurrentHashSet();
/*     */ 
/*     */   protected static String serviceKey(URL url) {
/*  50 */     return ProtocolUtils.serviceKey(url);
/*     */   }
/*     */ 
/*     */   protected static String serviceKey(int port, String serviceName, String serviceVersion, String serviceGroup) {
/*  54 */     return ProtocolUtils.serviceKey(port, serviceName, serviceVersion, serviceGroup);
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*  58 */     for (Invoker invoker : this.invokers) {
/*  59 */       if (invoker != null) {
/*  60 */         this.invokers.remove(invoker);
/*     */         try {
/*  62 */           if (this.logger.isInfoEnabled()) {
/*  63 */             this.logger.info("Destroy reference: " + invoker.getUrl());
/*     */           }
/*  65 */           invoker.destroy();
/*     */         } catch (Throwable t) {
/*  67 */           this.logger.warn(t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/*  71 */     for (String key : new ArrayList(this.exporterMap.keySet())) {
/*  72 */       Exporter exporter = (Exporter)this.exporterMap.remove(key);
/*  73 */       if (exporter != null)
/*     */         try {
/*  75 */           if (this.logger.isInfoEnabled()) {
/*  76 */             this.logger.info("Unexport service: " + exporter.getInvoker().getUrl());
/*     */           }
/*  78 */           exporter.unexport();
/*     */         } catch (Throwable t) {
/*  80 */           this.logger.warn(t.getMessage(), t);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static int getServerShutdownTimeout()
/*     */   {
/*  87 */     int timeout = 10000;
/*  88 */     String value = ConfigUtils.getProperty("dubbo.service.shutdown.wait");
/*  89 */     if ((value != null) && (value.length() > 0)) {
/*     */       try {
/*  91 */         timeout = Integer.parseInt(value);
/*     */       } catch (Exception e) {
/*     */       }
/*     */     } else {
/*  95 */       value = ConfigUtils.getProperty("dubbo.service.shutdown.wait.seconds");
/*  96 */       if ((value != null) && (value.length() > 0))
/*     */         try {
/*  98 */           timeout = Integer.parseInt(value) * 1000;
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */         }
/*     */     }
/* 104 */     return timeout;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.protocol.AbstractProtocol
 * JD-Core Version:    0.6.2
 */