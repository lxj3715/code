/*     */ package com.alibaba.dubbo.rpc.protocol;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.rpc.Exporter;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.ProxyFactory;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ 
/*     */ public abstract class AbstractProxyProtocol extends AbstractProtocol
/*     */ {
/*  37 */   private final List<Class<?>> rpcExceptions = new CopyOnWriteArrayList();
/*     */   private ProxyFactory proxyFactory;
/*     */ 
/*     */   public AbstractProxyProtocol()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AbstractProxyProtocol(Class<?>[] exceptions)
/*     */   {
/*  45 */     for (Class exception : exceptions)
/*  46 */       addRpcException(exception);
/*     */   }
/*     */ 
/*     */   public void addRpcException(Class<?> exception)
/*     */   {
/*  51 */     this.rpcExceptions.add(exception);
/*     */   }
/*     */ 
/*     */   public void setProxyFactory(ProxyFactory proxyFactory) {
/*  55 */     this.proxyFactory = proxyFactory;
/*     */   }
/*     */ 
/*     */   public ProxyFactory getProxyFactory() {
/*  59 */     return this.proxyFactory;
/*     */   }
/*     */ 
/*     */   public <T> Exporter<T> export(Invoker<T> invoker) throws RpcException
/*     */   {
/*  64 */     final String uri = serviceKey(invoker.getUrl());
/*  65 */     Exporter exporter = (Exporter)this.exporterMap.get(uri);
/*  66 */     if (exporter != null) {
/*  67 */       return exporter;
/*     */     }
/*  69 */     final Runnable runnable = doExport(this.proxyFactory.getProxy(invoker), invoker.getInterface(), invoker.getUrl());
/*  70 */     exporter = new AbstractExporter(invoker) {
/*     */       public void unexport() {
/*  72 */         super.unexport();
/*  73 */         AbstractProxyProtocol.this.exporterMap.remove(uri);
/*  74 */         if (runnable != null)
/*     */           try {
/*  76 */             runnable.run();
/*     */           } catch (Throwable t) {
/*  78 */             this.logger.warn(t.getMessage(), t);
/*     */           }
/*     */       }
/*     */     };
/*  83 */     this.exporterMap.put(uri, exporter);
/*  84 */     return exporter;
/*     */   }
/*     */ 
/*     */   public <T> Invoker<T> refer(final Class<T> type, final URL url) throws RpcException {
/*  88 */     final Invoker tagert = this.proxyFactory.getInvoker(doRefer(type, url), type, url);
/*  89 */     Invoker invoker = new AbstractInvoker(type, url)
/*     */     {
/*     */       protected Result doInvoke(Invocation invocation) throws Throwable {
/*     */         try {
/*  93 */           Result result = tagert.invoke(invocation);
/*  94 */           Throwable e = result.getException();
/*  95 */           if (e != null) {
/*  96 */             for (Class rpcException : AbstractProxyProtocol.this.rpcExceptions) {
/*  97 */               if (rpcException.isAssignableFrom(e.getClass())) {
/*  98 */                 throw AbstractProxyProtocol.this.getRpcException(type, url, invocation, e);
/*     */               }
/*     */             }
/*     */           }
/* 102 */           return result;
/*     */         } catch (RpcException e) {
/* 104 */           if (e.getCode() == 0) {
/* 105 */             e.setCode(AbstractProxyProtocol.this.getErrorCode(e.getCause()));
/*     */           }
/* 107 */           throw e;
/*     */         } catch (Throwable e) {
/* 109 */           throw AbstractProxyProtocol.this.getRpcException(type, url, invocation, e);
/*     */         }
/*     */       }
/*     */     };
/* 113 */     this.invokers.add(invoker);
/* 114 */     return invoker;
/*     */   }
/*     */ 
/*     */   protected RpcException getRpcException(Class<?> type, URL url, Invocation invocation, Throwable e) {
/* 118 */     RpcException re = new RpcException("Failed to invoke remote service: " + type + ", method: " + invocation.getMethodName() + ", cause: " + e.getMessage(), e);
/*     */ 
/* 120 */     re.setCode(getErrorCode(e));
/* 121 */     return re;
/*     */   }
/*     */ 
/*     */   protected int getErrorCode(Throwable e) {
/* 125 */     return 0;
/*     */   }
/*     */ 
/*     */   protected abstract <T> Runnable doExport(T paramT, Class<T> paramClass, URL paramURL)
/*     */     throws RpcException;
/*     */ 
/*     */   protected abstract <T> T doRefer(Class<T> paramClass, URL paramURL)
/*     */     throws RpcException;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.protocol.AbstractProxyProtocol
 * JD-Core Version:    0.6.2
 */