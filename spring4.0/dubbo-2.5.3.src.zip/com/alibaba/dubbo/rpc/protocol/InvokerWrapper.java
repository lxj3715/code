/*    */ package com.alibaba.dubbo.rpc.protocol;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ 
/*    */ public class InvokerWrapper<T>
/*    */   implements Invoker<T>
/*    */ {
/*    */   private final Invoker<T> invoker;
/*    */   private final URL url;
/*    */ 
/*    */   public InvokerWrapper(Invoker<T> invoker, URL url)
/*    */   {
/* 36 */     this.invoker = invoker;
/* 37 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public Class<T> getInterface() {
/* 41 */     return this.invoker.getInterface();
/*    */   }
/*    */ 
/*    */   public URL getUrl() {
/* 45 */     return this.url;
/*    */   }
/*    */ 
/*    */   public boolean isAvailable() {
/* 49 */     return this.invoker.isAvailable();
/*    */   }
/*    */ 
/*    */   public Result invoke(Invocation invocation) throws RpcException {
/* 53 */     return this.invoker.invoke(invocation);
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 57 */     this.invoker.destroy();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.protocol.InvokerWrapper
 * JD-Core Version:    0.6.2
 */