/*     */ package com.alibaba.dubbo.rpc.protocol;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.rpc.Exporter;
/*     */ import com.alibaba.dubbo.rpc.Filter;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Protocol;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ProtocolFilterWrapper
/*     */   implements Protocol
/*     */ {
/*     */   private final Protocol protocol;
/*     */ 
/*     */   public ProtocolFilterWrapper(Protocol protocol)
/*     */   {
/*  41 */     if (protocol == null) {
/*  42 */       throw new IllegalArgumentException("protocol == null");
/*     */     }
/*  44 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   public int getDefaultPort() {
/*  48 */     return this.protocol.getDefaultPort();
/*     */   }
/*     */ 
/*     */   public <T> Exporter<T> export(Invoker<T> invoker) throws RpcException {
/*  52 */     if ("registry".equals(invoker.getUrl().getProtocol())) {
/*  53 */       return this.protocol.export(invoker);
/*     */     }
/*  55 */     return this.protocol.export(buildInvokerChain(invoker, "service.filter", "provider"));
/*     */   }
/*     */ 
/*     */   public <T> Invoker<T> refer(Class<T> type, URL url) throws RpcException {
/*  59 */     if ("registry".equals(url.getProtocol())) {
/*  60 */       return this.protocol.refer(type, url);
/*     */     }
/*  62 */     return buildInvokerChain(this.protocol.refer(type, url), "reference.filter", "consumer");
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*  66 */     this.protocol.destroy();
/*     */   }
/*     */ 
/*     */   private static <T> Invoker<T> buildInvokerChain(Invoker<T> invoker, String key, String group) {
/*  70 */     Invoker last = invoker;
/*  71 */     List filters = ExtensionLoader.getExtensionLoader(Filter.class).getActivateExtension(invoker.getUrl(), key, group);
/*  72 */     if (filters.size() > 0) {
/*  73 */       for (int i = filters.size() - 1; i >= 0; i--) {
/*  74 */         final Filter filter = (Filter)filters.get(i);
/*  75 */         final Invoker next = last;
/*  76 */         last = new Invoker()
/*     */         {
/*     */           public Class<T> getInterface() {
/*  79 */             return this.val$invoker.getInterface();
/*     */           }
/*     */ 
/*     */           public URL getUrl() {
/*  83 */             return this.val$invoker.getUrl();
/*     */           }
/*     */ 
/*     */           public boolean isAvailable() {
/*  87 */             return this.val$invoker.isAvailable();
/*     */           }
/*     */ 
/*     */           public Result invoke(Invocation invocation) throws RpcException {
/*  91 */             return filter.invoke(next, invocation);
/*     */           }
/*     */ 
/*     */           public void destroy() {
/*  95 */             this.val$invoker.destroy();
/*     */           }
/*     */ 
/*     */           public String toString()
/*     */           {
/* 100 */             return this.val$invoker.toString();
/*     */           }
/*     */         };
/*     */       }
/*     */     }
/* 105 */     return last;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.protocol.ProtocolFilterWrapper
 * JD-Core Version:    0.6.2
 */