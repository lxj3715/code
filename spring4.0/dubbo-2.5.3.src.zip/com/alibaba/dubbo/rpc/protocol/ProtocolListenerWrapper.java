/*    */ package com.alibaba.dubbo.rpc.protocol;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*    */ import com.alibaba.dubbo.rpc.Exporter;
/*    */ import com.alibaba.dubbo.rpc.ExporterListener;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.InvokerListener;
/*    */ import com.alibaba.dubbo.rpc.Protocol;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.listener.ListenerExporterWrapper;
/*    */ import com.alibaba.dubbo.rpc.listener.ListenerInvokerWrapper;
/*    */ import java.util.Collections;
/*    */ 
/*    */ public class ProtocolListenerWrapper
/*    */   implements Protocol
/*    */ {
/*    */   private final Protocol protocol;
/*    */ 
/*    */   public ProtocolListenerWrapper(Protocol protocol)
/*    */   {
/* 42 */     if (protocol == null) {
/* 43 */       throw new IllegalArgumentException("protocol == null");
/*    */     }
/* 45 */     this.protocol = protocol;
/*    */   }
/*    */ 
/*    */   public int getDefaultPort() {
/* 49 */     return this.protocol.getDefaultPort();
/*    */   }
/*    */ 
/*    */   public <T> Exporter<T> export(Invoker<T> invoker) throws RpcException {
/* 53 */     if ("registry".equals(invoker.getUrl().getProtocol())) {
/* 54 */       return this.protocol.export(invoker);
/*    */     }
/* 56 */     return new ListenerExporterWrapper(this.protocol.export(invoker), Collections.unmodifiableList(ExtensionLoader.getExtensionLoader(ExporterListener.class).getActivateExtension(invoker.getUrl(), "exporter.listener")));
/*    */   }
/*    */ 
/*    */   public <T> Invoker<T> refer(Class<T> type, URL url)
/*    */     throws RpcException
/*    */   {
/* 62 */     if ("registry".equals(url.getProtocol())) {
/* 63 */       return this.protocol.refer(type, url);
/*    */     }
/* 65 */     return new ListenerInvokerWrapper(this.protocol.refer(type, url), Collections.unmodifiableList(ExtensionLoader.getExtensionLoader(InvokerListener.class).getActivateExtension(url, "invoker.listener")));
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/* 72 */     this.protocol.destroy();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.protocol.ProtocolListenerWrapper
 * JD-Core Version:    0.6.2
 */