/*    */ package com.alibaba.dubbo.rpc.proxy;
/*    */ 
/*    */ import com.alibaba.dubbo.common.Constants;
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.ProxyFactory;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.service.EchoService;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public abstract class AbstractProxyFactory
/*    */   implements ProxyFactory
/*    */ {
/*    */   public <T> T getProxy(Invoker<T> invoker)
/*    */     throws RpcException
/*    */   {
/* 33 */     Class[] interfaces = null;
/* 34 */     String config = invoker.getUrl().getParameter("interfaces");
/* 35 */     if ((config != null) && (config.length() > 0)) {
/* 36 */       String[] types = Constants.COMMA_SPLIT_PATTERN.split(config);
/* 37 */       if ((types != null) && (types.length > 0)) {
/* 38 */         interfaces = new Class[types.length + 2];
/* 39 */         interfaces[0] = invoker.getInterface();
/* 40 */         interfaces[1] = EchoService.class;
/* 41 */         for (int i = 0; i < types.length; i++) {
/* 42 */           interfaces[(i + 1)] = ReflectUtils.forName(types[i]);
/*    */         }
/*    */       }
/*    */     }
/* 46 */     if (interfaces == null) {
/* 47 */       interfaces = new Class[] { invoker.getInterface(), EchoService.class };
/*    */     }
/* 49 */     return getProxy(invoker, interfaces);
/*    */   }
/*    */ 
/*    */   public abstract <T> T getProxy(Invoker<T> paramInvoker, Class<?>[] paramArrayOfClass);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.proxy.AbstractProxyFactory
 * JD-Core Version:    0.6.2
 */