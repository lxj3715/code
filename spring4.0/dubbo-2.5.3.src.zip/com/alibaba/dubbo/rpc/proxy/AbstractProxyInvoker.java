/*    */ package com.alibaba.dubbo.rpc.proxy;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.RpcResult;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ 
/*    */ public abstract class AbstractProxyInvoker<T>
/*    */   implements Invoker<T>
/*    */ {
/*    */   private final T proxy;
/*    */   private final Class<T> type;
/*    */   private final URL url;
/*    */ 
/*    */   public AbstractProxyInvoker(T proxy, Class<T> type, URL url)
/*    */   {
/* 41 */     if (proxy == null) {
/* 42 */       throw new IllegalArgumentException("proxy == null");
/*    */     }
/* 44 */     if (type == null) {
/* 45 */       throw new IllegalArgumentException("interface == null");
/*    */     }
/* 47 */     if (!type.isInstance(proxy)) {
/* 48 */       throw new IllegalArgumentException(proxy.getClass().getName() + " not implement interface " + type);
/*    */     }
/* 50 */     this.proxy = proxy;
/* 51 */     this.type = type;
/* 52 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public Class<T> getInterface() {
/* 56 */     return this.type;
/*    */   }
/*    */ 
/*    */   public URL getUrl() {
/* 60 */     return this.url;
/*    */   }
/*    */ 
/*    */   public boolean isAvailable() {
/* 64 */     return true;
/*    */   }
/*    */ 
/*    */   public void destroy() {
/*    */   }
/*    */ 
/*    */   public Result invoke(Invocation invocation) throws RpcException {
/*    */     try {
/* 72 */       return new RpcResult(doInvoke(this.proxy, invocation.getMethodName(), invocation.getParameterTypes(), invocation.getArguments()));
/*    */     } catch (InvocationTargetException e) {
/* 74 */       return new RpcResult(e.getTargetException());
/*    */     } catch (Throwable e) {
/* 76 */       throw new RpcException("Failed to invoke remote proxy method " + invocation.getMethodName() + " to " + getUrl() + ", cause: " + e.getMessage(), e);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract Object doInvoke(T paramT, String paramString, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject) throws Throwable;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 84 */     return getInterface() + " -> " + getUrl() == null ? " " : getUrl().toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.proxy.AbstractProxyInvoker
 * JD-Core Version:    0.6.2
 */