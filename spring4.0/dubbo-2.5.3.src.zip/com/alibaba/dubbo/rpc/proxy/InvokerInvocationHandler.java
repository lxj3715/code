/*    */ package com.alibaba.dubbo.rpc.proxy;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class InvokerInvocationHandler
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final Invoker<?> invoker;
/*    */ 
/*    */   public InvokerInvocationHandler(Invoker<?> handler)
/*    */   {
/* 34 */     this.invoker = handler;
/*    */   }
/*    */ 
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 38 */     String methodName = method.getName();
/* 39 */     Class[] parameterTypes = method.getParameterTypes();
/* 40 */     if (method.getDeclaringClass() == Object.class) {
/* 41 */       return method.invoke(this.invoker, args);
/*    */     }
/* 43 */     if (("toString".equals(methodName)) && (parameterTypes.length == 0)) {
/* 44 */       return this.invoker.toString();
/*    */     }
/* 46 */     if (("hashCode".equals(methodName)) && (parameterTypes.length == 0)) {
/* 47 */       return Integer.valueOf(this.invoker.hashCode());
/*    */     }
/* 49 */     if (("equals".equals(methodName)) && (parameterTypes.length == 1)) {
/* 50 */       return Boolean.valueOf(this.invoker.equals(args[0]));
/*    */     }
/* 52 */     return this.invoker.invoke(new RpcInvocation(method, args)).recreate();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.proxy.InvokerInvocationHandler
 * JD-Core Version:    0.6.2
 */