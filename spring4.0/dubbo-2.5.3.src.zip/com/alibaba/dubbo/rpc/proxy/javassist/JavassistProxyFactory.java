/*    */ package com.alibaba.dubbo.rpc.proxy.javassist;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.bytecode.Proxy;
/*    */ import com.alibaba.dubbo.common.bytecode.Wrapper;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.proxy.AbstractProxyFactory;
/*    */ import com.alibaba.dubbo.rpc.proxy.AbstractProxyInvoker;
/*    */ import com.alibaba.dubbo.rpc.proxy.InvokerInvocationHandler;
/*    */ 
/*    */ public class JavassistProxyFactory extends AbstractProxyFactory
/*    */ {
/*    */   public <T> T getProxy(Invoker<T> invoker, Class<?>[] interfaces)
/*    */   {
/* 35 */     return Proxy.getProxy(interfaces).newInstance(new InvokerInvocationHandler(invoker));
/*    */   }
/*    */ 
/*    */   public <T> Invoker<T> getInvoker(T proxy, Class<T> type, URL url)
/*    */   {
/* 40 */     final Wrapper wrapper = Wrapper.getWrapper(proxy.getClass().getName().indexOf('$') < 0 ? proxy.getClass() : type);
/* 41 */     return new AbstractProxyInvoker(proxy, type, url)
/*    */     {
/*    */       protected Object doInvoke(T proxy, String methodName, Class<?>[] parameterTypes, Object[] arguments)
/*    */         throws Throwable
/*    */       {
/* 46 */         return wrapper.invokeMethod(proxy, methodName, parameterTypes, arguments);
/*    */       }
/*    */     };
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.proxy.javassist.JavassistProxyFactory
 * JD-Core Version:    0.6.2
 */