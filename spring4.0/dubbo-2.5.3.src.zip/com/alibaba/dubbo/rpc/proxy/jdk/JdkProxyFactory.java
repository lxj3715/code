/*    */ package com.alibaba.dubbo.rpc.proxy.jdk;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.proxy.AbstractProxyFactory;
/*    */ import com.alibaba.dubbo.rpc.proxy.AbstractProxyInvoker;
/*    */ import com.alibaba.dubbo.rpc.proxy.InvokerInvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ 
/*    */ public class JdkProxyFactory extends AbstractProxyFactory
/*    */ {
/*    */   public <T> T getProxy(Invoker<T> invoker, Class<?>[] interfaces)
/*    */   {
/* 36 */     return Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), interfaces, new InvokerInvocationHandler(invoker));
/*    */   }
/*    */ 
/*    */   public <T> Invoker<T> getInvoker(T proxy, Class<T> type, URL url) {
/* 40 */     return new AbstractProxyInvoker(proxy, type, url)
/*    */     {
/*    */       protected Object doInvoke(T proxy, String methodName, Class<?>[] parameterTypes, Object[] arguments)
/*    */         throws Throwable
/*    */       {
/* 45 */         Method method = proxy.getClass().getMethod(methodName, parameterTypes);
/* 46 */         return method.invoke(proxy, arguments);
/*    */       }
/*    */     };
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.proxy.jdk.JdkProxyFactory
 * JD-Core Version:    0.6.2
 */