/*     */ package com.alibaba.dubbo.rpc.proxy.wrapper;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.Version;
/*     */ import com.alibaba.dubbo.common.bytecode.Wrapper;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.NetUtils;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.rpc.Exporter;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.Protocol;
/*     */ import com.alibaba.dubbo.rpc.ProxyFactory;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.service.GenericService;
/*     */ import java.lang.reflect.Constructor;
/*     */ 
/*     */ public class StubProxyFactoryWrapper
/*     */   implements ProxyFactory
/*     */ {
/*  44 */   private static final Logger LOGGER = LoggerFactory.getLogger(StubProxyFactoryWrapper.class);
/*     */   private final ProxyFactory proxyFactory;
/*     */   private Protocol protocol;
/*     */ 
/*     */   public StubProxyFactoryWrapper(ProxyFactory proxyFactory)
/*     */   {
/*  51 */     this.proxyFactory = proxyFactory;
/*     */   }
/*     */ 
/*     */   public void setProtocol(Protocol protocol) {
/*  55 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   public <T> T getProxy(Invoker<T> invoker) throws RpcException
/*     */   {
/*  60 */     Object proxy = this.proxyFactory.getProxy(invoker);
/*  61 */     if (GenericService.class != invoker.getInterface()) {
/*  62 */       String stub = invoker.getUrl().getParameter("stub", invoker.getUrl().getParameter("local"));
/*  63 */       if (ConfigUtils.isNotEmpty(stub)) {
/*  64 */         Class serviceType = invoker.getInterface();
/*  65 */         if (ConfigUtils.isDefault(stub)) {
/*  66 */           if (invoker.getUrl().hasParameter("stub"))
/*  67 */             stub = serviceType.getName() + "Stub";
/*     */           else
/*  69 */             stub = serviceType.getName() + "Local";
/*     */         }
/*     */         try
/*     */         {
/*  73 */           Class stubClass = ReflectUtils.forName(stub);
/*  74 */           if (!serviceType.isAssignableFrom(stubClass))
/*  75 */             throw new IllegalStateException("The stub implemention class " + stubClass.getName() + " not implement interface " + serviceType.getName());
/*     */           try
/*     */           {
/*  78 */             Constructor constructor = ReflectUtils.findConstructor(stubClass, serviceType);
/*  79 */             proxy = constructor.newInstance(new Object[] { proxy });
/*     */ 
/*  81 */             URL url = invoker.getUrl();
/*  82 */             if (url.getParameter("dubbo.stub.event", false)) {
/*  83 */               url = url.addParameter("dubbo.stub.event.methods", StringUtils.join(Wrapper.getWrapper(proxy.getClass()).getDeclaredMethodNames(), ","));
/*  84 */               url = url.addParameter("isserver", Boolean.FALSE.toString());
/*     */               try {
/*  86 */                 export(proxy, invoker.getInterface(), url);
/*     */               } catch (Exception e) {
/*  88 */                 LOGGER.error("export a stub service error.", e);
/*     */               }
/*     */             }
/*     */           } catch (NoSuchMethodException e) {
/*  92 */             throw new IllegalStateException("No such constructor \"public " + stubClass.getSimpleName() + "(" + serviceType.getName() + ")\" in stub implemention class " + stubClass.getName(), e);
/*     */           }
/*     */         } catch (Throwable t) {
/*  95 */           LOGGER.error("Failed to create stub implemention class " + stub + " in consumer " + NetUtils.getLocalHost() + " use dubbo version " + Version.getVersion() + ", cause: " + t.getMessage(), t);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 100 */     return proxy;
/*     */   }
/*     */ 
/*     */   public <T> Invoker<T> getInvoker(T proxy, Class<T> type, URL url) throws RpcException {
/* 104 */     return this.proxyFactory.getInvoker(proxy, type, url);
/*     */   }
/*     */ 
/*     */   private <T> Exporter<T> export(T instance, Class<T> type, URL url) {
/* 108 */     return this.protocol.export(this.proxyFactory.getInvoker(instance, type, url));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.proxy.wrapper.StubProxyFactoryWrapper
 * JD-Core Version:    0.6.2
 */