/*    */ package com.alibaba.dubbo.rpc.service;
/*    */ 
/*    */ import com.alibaba.dubbo.common.utils.StringUtils;
/*    */ 
/*    */ public class GenericException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -1182299763306599962L;
/*    */   private String exceptionClass;
/*    */   private String exceptionMessage;
/*    */ 
/*    */   public GenericException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GenericException(String exceptionClass, String exceptionMessage)
/*    */   {
/* 39 */     super(exceptionMessage);
/* 40 */     this.exceptionClass = exceptionClass;
/* 41 */     this.exceptionMessage = exceptionMessage;
/*    */   }
/*    */ 
/*    */   public GenericException(Throwable cause) {
/* 45 */     super(StringUtils.toString(cause));
/* 46 */     this.exceptionClass = cause.getClass().getName();
/* 47 */     this.exceptionMessage = cause.getMessage();
/*    */   }
/*    */ 
/*    */   public String getExceptionClass() {
/* 51 */     return this.exceptionClass;
/*    */   }
/*    */ 
/*    */   public void setExceptionClass(String exceptionClass) {
/* 55 */     this.exceptionClass = exceptionClass;
/*    */   }
/*    */ 
/*    */   public String getExceptionMessage() {
/* 59 */     return this.exceptionMessage;
/*    */   }
/*    */ 
/*    */   public void setExceptionMessage(String exceptionMessage) {
/* 63 */     this.exceptionMessage = exceptionMessage;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.service.GenericException
 * JD-Core Version:    0.6.2
 */