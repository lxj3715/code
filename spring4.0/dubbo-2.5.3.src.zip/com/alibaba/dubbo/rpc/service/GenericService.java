package com.alibaba.dubbo.rpc.service;

public abstract interface GenericService
{
  public abstract Object $invoke(String paramString, String[] paramArrayOfString, Object[] paramArrayOfObject)
    throws GenericException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.service.GenericService
 * JD-Core Version:    0.6.2
 */