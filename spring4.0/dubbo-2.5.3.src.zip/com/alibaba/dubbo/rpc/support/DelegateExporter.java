/*    */ package com.alibaba.dubbo.rpc.support;
/*    */ 
/*    */ import com.alibaba.dubbo.rpc.Exporter;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ 
/*    */ public class DelegateExporter<T>
/*    */   implements Exporter<T>
/*    */ {
/*    */   private final Exporter<T> exporter;
/*    */ 
/*    */   public DelegateExporter(Exporter<T> exporter)
/*    */   {
/* 31 */     if (exporter == null) {
/* 32 */       throw new IllegalArgumentException("exporter can not be null");
/*    */     }
/* 34 */     this.exporter = exporter;
/*    */   }
/*    */ 
/*    */   public Invoker<T> getInvoker()
/*    */   {
/* 40 */     return this.exporter.getInvoker();
/*    */   }
/*    */   public void unexport() {
/* 43 */     this.exporter.unexport();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.support.DelegateExporter
 * JD-Core Version:    0.6.2
 */