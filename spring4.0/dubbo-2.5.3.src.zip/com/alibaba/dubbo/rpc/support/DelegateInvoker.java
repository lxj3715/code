/*    */ package com.alibaba.dubbo.rpc.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ 
/*    */ public abstract class DelegateInvoker<T>
/*    */   implements Invoker<T>
/*    */ {
/*    */   protected final Invoker<T> invoker;
/*    */ 
/*    */   public DelegateInvoker(Invoker<T> invoker)
/*    */   {
/* 34 */     this.invoker = invoker;
/*    */   }
/*    */ 
/*    */   public Class<T> getInterface() {
/* 38 */     return this.invoker.getInterface();
/*    */   }
/*    */ 
/*    */   public URL getUrl() {
/* 42 */     return this.invoker.getUrl();
/*    */   }
/*    */ 
/*    */   public boolean isAvailable() {
/* 46 */     return this.invoker.isAvailable();
/*    */   }
/*    */ 
/*    */   public Result invoke(Invocation invocation) throws RpcException {
/* 50 */     return this.invoker.invoke(invocation);
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 54 */     this.invoker.destroy();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.support.DelegateInvoker
 * JD-Core Version:    0.6.2
 */