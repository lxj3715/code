/*     */ package com.alibaba.dubbo.rpc.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.extension.ExtensionLoader;
/*     */ import com.alibaba.dubbo.common.json.JSON;
/*     */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*     */ import com.alibaba.dubbo.common.utils.PojoUtils;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.common.utils.StringUtils;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.ProxyFactory;
/*     */ import com.alibaba.dubbo.rpc.Result;
/*     */ import com.alibaba.dubbo.rpc.RpcException;
/*     */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*     */ import com.alibaba.dubbo.rpc.RpcResult;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ public final class MockInvoker<T>
/*     */   implements Invoker<T>
/*     */ {
/*  46 */   private static final ProxyFactory proxyFactory = (ProxyFactory)ExtensionLoader.getExtensionLoader(ProxyFactory.class).getAdaptiveExtension();
/*  47 */   private static final Map<String, Invoker<?>> mocks = new ConcurrentHashMap();
/*  48 */   private static final Map<String, Throwable> throwables = new ConcurrentHashMap();
/*     */   private final URL url;
/*     */ 
/*     */   public MockInvoker(URL url)
/*     */   {
/*  53 */     this.url = url;
/*     */   }
/*     */   public Result invoke(Invocation invocation) throws RpcException {
/*  56 */     String mock = getUrl().getParameter(invocation.getMethodName() + "." + "mock");
/*  57 */     if ((invocation instanceof RpcInvocation)) {
/*  58 */       ((RpcInvocation)invocation).setInvoker(this);
/*     */     }
/*  60 */     if (StringUtils.isBlank(mock)) {
/*  61 */       mock = getUrl().getParameter("mock");
/*     */     }
/*     */ 
/*  64 */     if (StringUtils.isBlank(mock)) {
/*  65 */       throw new RpcException(new IllegalAccessException("mock can not be null. url :" + this.url));
/*     */     }
/*  67 */     mock = normallizeMock(URL.decode(mock));
/*  68 */     if ("return ".trim().equalsIgnoreCase(mock.trim())) {
/*  69 */       RpcResult result = new RpcResult();
/*  70 */       result.setValue(null);
/*  71 */       return result;
/*  72 */     }if (mock.startsWith("return ")) {
/*  73 */       mock = mock.substring("return ".length()).trim();
/*  74 */       mock = mock.replace('`', '"');
/*     */       try {
/*  76 */         Type[] returnTypes = RpcUtils.getReturnTypes(invocation);
/*  77 */         Object value = parseMockValue(mock, returnTypes);
/*  78 */         return new RpcResult(value);
/*     */       } catch (Exception ew) {
/*  80 */         throw new RpcException("mock return invoke error. method :" + invocation.getMethodName() + ", mock:" + mock + ", url: " + this.url, ew);
/*     */       }
/*     */     }
/*  82 */     if (mock.startsWith("throw")) {
/*  83 */       mock = mock.substring("throw".length()).trim();
/*  84 */       mock = mock.replace('`', '"');
/*  85 */       if (StringUtils.isBlank(mock)) {
/*  86 */         throw new RpcException(" mocked exception for Service degradation. ");
/*     */       }
/*  88 */       Throwable t = getThrowable(mock);
/*  89 */       throw new RpcException(3, t);
/*     */     }
/*     */     try
/*     */     {
/*  93 */       Invoker invoker = getInvoker(mock);
/*  94 */       return invoker.invoke(invocation);
/*     */     } catch (Throwable t) {
/*  96 */       throw new RpcException("Failed to create mock implemention class " + mock, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Throwable getThrowable(String throwstr)
/*     */   {
/* 102 */     Throwable throwable = (Throwable)throwables.get(throwstr);
/* 103 */     if (throwable != null) {
/* 104 */       return throwable;
/*     */     }
/* 106 */     Throwable t = null;
/*     */     try {
/* 108 */       Class bizException = ReflectUtils.forName(throwstr);
/*     */ 
/* 110 */       Constructor constructor = ReflectUtils.findConstructor(bizException, String.class);
/* 111 */       t = (Throwable)constructor.newInstance(new Object[] { " mocked exception for Service degradation. " });
/* 112 */       if (throwables.size() < 1000)
/* 113 */         throwables.put(throwstr, t);
/*     */     }
/*     */     catch (Exception e) {
/* 116 */       throw new RpcException("mock throw error :" + throwstr + " argument error.", e);
/*     */     }
/* 118 */     return t;
/*     */   }
/*     */ 
/*     */   private Invoker<T> getInvoker(String mockService)
/*     */   {
/* 124 */     Invoker invoker = (Invoker)mocks.get(mockService);
/* 125 */     if (invoker != null) {
/* 126 */       return invoker;
/*     */     }
/* 128 */     Class serviceType = ReflectUtils.forName(this.url.getServiceInterface());
/* 129 */     if (ConfigUtils.isDefault(mockService)) {
/* 130 */       mockService = serviceType.getName() + "Mock";
/*     */     }
/*     */ 
/* 133 */     Class mockClass = ReflectUtils.forName(mockService);
/* 134 */     if (!serviceType.isAssignableFrom(mockClass)) {
/* 135 */       throw new IllegalArgumentException("The mock implemention class " + mockClass.getName() + " not implement interface " + serviceType.getName());
/*     */     }
/*     */ 
/* 138 */     if (!serviceType.isAssignableFrom(mockClass))
/* 139 */       throw new IllegalArgumentException("The mock implemention class " + mockClass.getName() + " not implement interface " + serviceType.getName());
/*     */     try
/*     */     {
/* 142 */       Object mockObject = mockClass.newInstance();
/* 143 */       invoker = proxyFactory.getInvoker(mockObject, serviceType, this.url);
/* 144 */       if (mocks.size() < 10000) {
/* 145 */         mocks.put(mockService, invoker);
/*     */       }
/* 147 */       return invoker;
/*     */     } catch (InstantiationException e) {
/* 149 */       throw new IllegalStateException("No such empty constructor \"public " + mockClass.getSimpleName() + "()\" in mock implemention class " + mockClass.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/* 151 */       throw new IllegalStateException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String normallizeMock(String mock)
/*     */   {
/* 159 */     if ((mock == null) || (mock.trim().length() == 0))
/* 160 */       return mock;
/* 161 */     if ((ConfigUtils.isDefault(mock)) || ("fail".equalsIgnoreCase(mock.trim())) || ("force".equalsIgnoreCase(mock.trim()))) {
/* 162 */       mock = this.url.getServiceInterface() + "Mock";
/*     */     }
/* 164 */     if (mock.startsWith("fail:"))
/* 165 */       mock = mock.substring("fail:".length()).trim();
/* 166 */     else if (mock.startsWith("force:")) {
/* 167 */       mock = mock.substring("force:".length()).trim();
/*     */     }
/* 169 */     return mock;
/*     */   }
/*     */ 
/*     */   public static Object parseMockValue(String mock) throws Exception {
/* 173 */     return parseMockValue(mock, null);
/*     */   }
/*     */ 
/*     */   public static Object parseMockValue(String mock, Type[] returnTypes) throws Exception {
/* 177 */     Object value = null;
/* 178 */     if ("empty".equals(mock))
/* 179 */       value = ReflectUtils.getEmptyObject((returnTypes != null) && (returnTypes.length > 0) ? (Class)returnTypes[0] : null);
/* 180 */     else if ("null".equals(mock))
/* 181 */       value = null;
/* 182 */     else if ("true".equals(mock))
/* 183 */       value = Boolean.valueOf(true);
/* 184 */     else if ("false".equals(mock))
/* 185 */       value = Boolean.valueOf(false);
/* 186 */     else if ((mock.length() >= 2) && (((mock.startsWith("\"")) && (mock.endsWith("\""))) || ((mock.startsWith("'")) && (mock.endsWith("'")))))
/*     */     {
/* 188 */       value = mock.subSequence(1, mock.length() - 1);
/* 189 */     } else if ((returnTypes != null) && (returnTypes.length > 0) && (returnTypes[0] == String.class))
/* 190 */       value = mock;
/* 191 */     else if (StringUtils.isNumeric(mock))
/* 192 */       value = JSON.parse(mock);
/* 193 */     else if (mock.startsWith("{"))
/* 194 */       value = JSON.parse(mock, Map.class);
/* 195 */     else if (mock.startsWith("["))
/* 196 */       value = JSON.parse(mock, List.class);
/*     */     else {
/* 198 */       value = mock;
/*     */     }
/* 200 */     if ((returnTypes != null) && (returnTypes.length > 0)) {
/* 201 */       value = PojoUtils.realize(value, (Class)returnTypes[0], returnTypes.length > 1 ? returnTypes[1] : null);
/*     */     }
/* 203 */     return value;
/*     */   }
/*     */ 
/*     */   public URL getUrl() {
/* 207 */     return this.url;
/*     */   }
/*     */ 
/*     */   public boolean isAvailable() {
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Class<T> getInterface()
/*     */   {
/* 220 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.support.MockInvoker
 * JD-Core Version:    0.6.2
 */