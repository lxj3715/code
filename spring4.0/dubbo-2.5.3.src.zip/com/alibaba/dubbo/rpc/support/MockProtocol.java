/*    */ package com.alibaba.dubbo.rpc.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.rpc.Exporter;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.rpc.protocol.AbstractProtocol;
/*    */ 
/*    */ public final class MockProtocol extends AbstractProtocol
/*    */ {
/*    */   public int getDefaultPort()
/*    */   {
/* 32 */     return 0;
/*    */   }
/*    */ 
/*    */   public <T> Exporter<T> export(Invoker<T> invoker) throws RpcException {
/* 36 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public <T> Invoker<T> refer(Class<T> type, URL url) throws RpcException {
/* 40 */     return new MockInvoker(url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.support.MockProtocol
 * JD-Core Version:    0.6.2
 */