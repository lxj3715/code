/*    */ package com.alibaba.dubbo.rpc.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ 
/*    */ public class ProtocolUtils
/*    */ {
/*    */   public static String serviceKey(URL url)
/*    */   {
/* 15 */     return serviceKey(url.getPort(), url.getPath(), url.getParameter("version"), url.getParameter("group"));
/*    */   }
/*    */ 
/*    */   public static String serviceKey(int port, String serviceName, String serviceVersion, String serviceGroup)
/*    */   {
/* 20 */     StringBuilder buf = new StringBuilder();
/* 21 */     if ((serviceGroup != null) && (serviceGroup.length() > 0)) {
/* 22 */       buf.append(serviceGroup);
/* 23 */       buf.append("/");
/*    */     }
/* 25 */     buf.append(serviceName);
/* 26 */     if ((serviceVersion != null) && (serviceVersion.length() > 0) && (!"0.0.0".equals(serviceVersion))) {
/* 27 */       buf.append(":");
/* 28 */       buf.append(serviceVersion);
/*    */     }
/* 30 */     buf.append(":");
/* 31 */     buf.append(port);
/* 32 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   public static boolean isGeneric(String generic) {
/* 36 */     return (generic != null) && (!"".equals(generic)) && (("true".equalsIgnoreCase(generic)) || ("nativejava".equalsIgnoreCase(generic)));
/*    */   }
/*    */ 
/*    */   public static boolean isDefaultGenericSerialization(String generic)
/*    */   {
/* 43 */     return (isGeneric(generic)) && ("true".equalsIgnoreCase(generic));
/*    */   }
/*    */ 
/*    */   public static boolean isJavaGenericSerialization(String generic)
/*    */   {
/* 48 */     return (isGeneric(generic)) && ("nativejava".equalsIgnoreCase(generic));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.support.ProtocolUtils
 * JD-Core Version:    0.6.2
 */