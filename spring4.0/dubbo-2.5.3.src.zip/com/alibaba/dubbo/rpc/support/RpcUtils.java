/*     */ package com.alibaba.dubbo.rpc.support;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import com.alibaba.dubbo.rpc.Invocation;
/*     */ import com.alibaba.dubbo.rpc.Invoker;
/*     */ import com.alibaba.dubbo.rpc.RpcInvocation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ public class RpcUtils
/*     */ {
/*  38 */   private static final Logger logger = LoggerFactory.getLogger(RpcUtils.class);
/*     */ 
/*  82 */   private static final AtomicLong INVOKE_ID = new AtomicLong(0L);
/*     */ 
/*     */   public static Class<?> getReturnType(Invocation invocation)
/*     */   {
/*     */     try
/*     */     {
/*  42 */       if ((invocation != null) && (invocation.getInvoker() != null) && (invocation.getInvoker().getUrl() != null) && (!invocation.getMethodName().startsWith("$")))
/*     */       {
/*  45 */         String service = invocation.getInvoker().getUrl().getServiceInterface();
/*  46 */         if ((service != null) && (service.length() > 0)) {
/*  47 */           Class cls = ReflectUtils.forName(service);
/*  48 */           Method method = cls.getMethod(invocation.getMethodName(), invocation.getParameterTypes());
/*  49 */           if (method.getReturnType() == Void.TYPE) {
/*  50 */             return null;
/*     */           }
/*  52 */           return method.getReturnType();
/*     */         }
/*     */       }
/*     */     } catch (Throwable t) {
/*  56 */       logger.warn(t.getMessage(), t);
/*     */     }
/*  58 */     return null;
/*     */   }
/*     */ 
/*     */   public static Type[] getReturnTypes(Invocation invocation) {
/*     */     try {
/*  63 */       if ((invocation != null) && (invocation.getInvoker() != null) && (invocation.getInvoker().getUrl() != null) && (!invocation.getMethodName().startsWith("$")))
/*     */       {
/*  66 */         String service = invocation.getInvoker().getUrl().getServiceInterface();
/*  67 */         if ((service != null) && (service.length() > 0)) {
/*  68 */           Class cls = ReflectUtils.forName(service);
/*  69 */           Method method = cls.getMethod(invocation.getMethodName(), invocation.getParameterTypes());
/*  70 */           if (method.getReturnType() == Void.TYPE) {
/*  71 */             return null;
/*     */           }
/*  73 */           return new Type[] { method.getReturnType(), method.getGenericReturnType() };
/*     */         }
/*     */       }
/*     */     } catch (Throwable t) {
/*  77 */       logger.warn(t.getMessage(), t);
/*     */     }
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   public static Long getInvocationId(Invocation inv)
/*     */   {
/*  85 */     String id = inv.getAttachment("id");
/*  86 */     return id == null ? null : new Long(id);
/*     */   }
/*     */ 
/*     */   public static void attachInvocationIdIfAsync(URL url, Invocation inv)
/*     */   {
/*  95 */     if ((isAttachInvocationId(url, inv)) && (getInvocationId(inv) == null) && ((inv instanceof RpcInvocation)))
/*  96 */       ((RpcInvocation)inv).setAttachment("id", String.valueOf(INVOKE_ID.getAndIncrement()));
/*     */   }
/*     */ 
/*     */   private static boolean isAttachInvocationId(URL url, Invocation invocation)
/*     */   {
/* 101 */     String value = url.getMethodParameter(invocation.getMethodName(), "invocationid.autoattach");
/* 102 */     if (value == null)
/*     */     {
/* 104 */       return isAsync(url, invocation);
/* 105 */     }if (Boolean.TRUE.toString().equalsIgnoreCase(value))
/*     */     {
/* 107 */       return true;
/*     */     }
/*     */ 
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */   public static String getMethodName(Invocation invocation)
/*     */   {
/* 115 */     if (("$invoke".equals(invocation.getMethodName())) && (invocation.getArguments() != null) && (invocation.getArguments().length > 0) && ((invocation.getArguments()[0] instanceof String)))
/*     */     {
/* 119 */       return (String)invocation.getArguments()[0];
/*     */     }
/* 121 */     return invocation.getMethodName();
/*     */   }
/*     */ 
/*     */   public static Object[] getArguments(Invocation invocation) {
/* 125 */     if (("$invoke".equals(invocation.getMethodName())) && (invocation.getArguments() != null) && (invocation.getArguments().length > 2) && ((invocation.getArguments()[2] instanceof Object[])))
/*     */     {
/* 129 */       return (Object[])invocation.getArguments()[2];
/*     */     }
/* 131 */     return invocation.getArguments();
/*     */   }
/*     */ 
/*     */   public static Class<?>[] getParameterTypes(Invocation invocation) {
/* 135 */     if (("$invoke".equals(invocation.getMethodName())) && (invocation.getArguments() != null) && (invocation.getArguments().length > 1) && ((invocation.getArguments()[1] instanceof String[])))
/*     */     {
/* 139 */       String[] types = (String[])invocation.getArguments()[1];
/* 140 */       if (types == null) {
/* 141 */         return new Class[0];
/*     */       }
/* 143 */       Class[] parameterTypes = new Class[types.length];
/* 144 */       for (int i = 0; i < types.length; i++) {
/* 145 */         parameterTypes[i] = ReflectUtils.forName(types[0]);
/*     */       }
/* 147 */       return parameterTypes;
/*     */     }
/* 149 */     return invocation.getParameterTypes();
/*     */   }
/*     */ 
/*     */   public static boolean isAsync(URL url, Invocation inv)
/*     */   {
/*     */     boolean isAsync;
/*     */     boolean isAsync;
/* 155 */     if (Boolean.TRUE.toString().equals(inv.getAttachment("async")))
/* 156 */       isAsync = true;
/*     */     else {
/* 158 */       isAsync = url.getMethodParameter(getMethodName(inv), "async", false);
/*     */     }
/* 160 */     return isAsync;
/*     */   }
/*     */ 
/*     */   public static boolean isOneway(URL url, Invocation inv)
/*     */   {
/*     */     boolean isOneway;
/*     */     boolean isOneway;
/* 166 */     if (Boolean.FALSE.toString().equals(inv.getAttachment("return")))
/* 167 */       isOneway = true;
/*     */     else {
/* 169 */       isOneway = !url.getMethodParameter(getMethodName(inv), "return", true);
/*     */     }
/* 171 */     return isOneway;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.rpc.support.RpcUtils
 * JD-Core Version:    0.6.2
 */