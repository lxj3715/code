package com.alibaba.dubbo.validation;

import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;

@SPI("jvalidation")
public abstract interface Validation
{
  @Adaptive({"validation"})
  public abstract Validator getValidator(URL paramURL);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.validation.Validation
 * JD-Core Version:    0.6.2
 */