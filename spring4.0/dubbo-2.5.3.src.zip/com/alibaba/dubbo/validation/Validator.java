package com.alibaba.dubbo.validation;

public abstract interface Validator
{
  public abstract void validate(String paramString, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject)
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.validation.Validator
 * JD-Core Version:    0.6.2
 */