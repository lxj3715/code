/*    */ package com.alibaba.dubbo.validation.filter;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.common.extension.Activate;
/*    */ import com.alibaba.dubbo.common.utils.ConfigUtils;
/*    */ import com.alibaba.dubbo.rpc.Filter;
/*    */ import com.alibaba.dubbo.rpc.Invocation;
/*    */ import com.alibaba.dubbo.rpc.Invoker;
/*    */ import com.alibaba.dubbo.rpc.Result;
/*    */ import com.alibaba.dubbo.rpc.RpcException;
/*    */ import com.alibaba.dubbo.validation.Validation;
/*    */ import com.alibaba.dubbo.validation.Validator;
/*    */ 
/*    */ @Activate(group={"consumer", "provider"}, value={"validation"}, order=10000)
/*    */ public class ValidationFilter
/*    */   implements Filter
/*    */ {
/*    */   private Validation validation;
/*    */ 
/*    */   public void setValidation(Validation validation)
/*    */   {
/* 40 */     this.validation = validation;
/*    */   }
/*    */ 
/*    */   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
/* 44 */     if ((this.validation != null) && (!invocation.getMethodName().startsWith("$")) && (ConfigUtils.isNotEmpty(invoker.getUrl().getMethodParameter(invocation.getMethodName(), "validation")))) {
/*    */       try
/*    */       {
/* 47 */         Validator validator = this.validation.getValidator(invoker.getUrl());
/* 48 */         if (validator != null)
/* 49 */           validator.validate(invocation.getMethodName(), invocation.getParameterTypes(), invocation.getArguments());
/*    */       }
/*    */       catch (RpcException e) {
/* 52 */         throw e;
/*    */       } catch (Throwable t) {
/* 54 */         throw new RpcException(t.getMessage(), t);
/*    */       }
/*    */     }
/* 57 */     return invoker.invoke(invocation);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.validation.filter.ValidationFilter
 * JD-Core Version:    0.6.2
 */