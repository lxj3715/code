/*    */ package com.alibaba.dubbo.validation.support;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.validation.Validation;
/*    */ import com.alibaba.dubbo.validation.Validator;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ public abstract class AbstractValidation
/*    */   implements Validation
/*    */ {
/* 32 */   private final ConcurrentMap<String, Validator> validators = new ConcurrentHashMap();
/*    */ 
/*    */   public Validator getValidator(URL url) {
/* 35 */     String key = url.toFullString();
/* 36 */     Validator validator = (Validator)this.validators.get(key);
/* 37 */     if (validator == null) {
/* 38 */       this.validators.put(key, createValidator(url));
/* 39 */       validator = (Validator)this.validators.get(key);
/*    */     }
/* 41 */     return validator;
/*    */   }
/*    */ 
/*    */   protected abstract Validator createValidator(URL paramURL);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.validation.support.AbstractValidation
 * JD-Core Version:    0.6.2
 */