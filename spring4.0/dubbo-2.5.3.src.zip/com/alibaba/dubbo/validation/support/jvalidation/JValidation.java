/*    */ package com.alibaba.dubbo.validation.support.jvalidation;
/*    */ 
/*    */ import com.alibaba.dubbo.common.URL;
/*    */ import com.alibaba.dubbo.validation.Validator;
/*    */ import com.alibaba.dubbo.validation.support.AbstractValidation;
/*    */ 
/*    */ public class JValidation extends AbstractValidation
/*    */ {
/*    */   protected Validator createValidator(URL url)
/*    */   {
/* 31 */     return new JValidator(url);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.validation.support.jvalidation.JValidation
 * JD-Core Version:    0.6.2
 */