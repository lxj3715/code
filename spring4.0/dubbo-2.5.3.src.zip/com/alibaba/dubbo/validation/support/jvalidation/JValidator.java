/*     */ package com.alibaba.dubbo.validation.support.jvalidation;
/*     */ 
/*     */ import com.alibaba.dubbo.common.URL;
/*     */ import com.alibaba.dubbo.common.bytecode.ClassGenerator;
/*     */ import com.alibaba.dubbo.common.logger.Logger;
/*     */ import com.alibaba.dubbo.common.logger.LoggerFactory;
/*     */ import com.alibaba.dubbo.common.utils.ReflectUtils;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javassist.ClassPool;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtField;
/*     */ import javassist.CtNewConstructor;
/*     */ import javassist.Modifier;
/*     */ import javassist.NotFoundException;
/*     */ import javassist.bytecode.AnnotationsAttribute;
/*     */ import javassist.bytecode.ClassFile;
/*     */ import javassist.bytecode.ConstPool;
/*     */ import javassist.bytecode.FieldInfo;
/*     */ import javassist.bytecode.annotation.ArrayMemberValue;
/*     */ import javassist.bytecode.annotation.BooleanMemberValue;
/*     */ import javassist.bytecode.annotation.ByteMemberValue;
/*     */ import javassist.bytecode.annotation.CharMemberValue;
/*     */ import javassist.bytecode.annotation.ClassMemberValue;
/*     */ import javassist.bytecode.annotation.DoubleMemberValue;
/*     */ import javassist.bytecode.annotation.EnumMemberValue;
/*     */ import javassist.bytecode.annotation.FloatMemberValue;
/*     */ import javassist.bytecode.annotation.IntegerMemberValue;
/*     */ import javassist.bytecode.annotation.LongMemberValue;
/*     */ import javassist.bytecode.annotation.MemberValue;
/*     */ import javassist.bytecode.annotation.ShortMemberValue;
/*     */ import javassist.bytecode.annotation.StringMemberValue;
/*     */ import javax.validation.Configuration;
/*     */ import javax.validation.Constraint;
/*     */ import javax.validation.ConstraintViolation;
/*     */ import javax.validation.ConstraintViolationException;
/*     */ import javax.validation.Validation;
/*     */ import javax.validation.ValidatorFactory;
/*     */ import javax.validation.bootstrap.ProviderSpecificBootstrap;
/*     */ import javax.validation.groups.Default;
/*     */ 
/*     */ public class JValidator
/*     */   implements com.alibaba.dubbo.validation.Validator
/*     */ {
/*  72 */   private static final Logger logger = LoggerFactory.getLogger(JValidator.class);
/*     */   private final Class<?> clazz;
/*     */   private final javax.validation.Validator validator;
/*     */ 
/*     */   public JValidator(URL url)
/*     */   {
/*  80 */     this.clazz = ReflectUtils.forName(url.getServiceInterface());
/*  81 */     String jvalidation = url.getParameter("jvalidation");
/*     */     ValidatorFactory factory;
/*     */     ValidatorFactory factory;
/*  83 */     if ((jvalidation != null) && (jvalidation.length() > 0))
/*  84 */       factory = Validation.byProvider(ReflectUtils.forName(jvalidation)).configure().buildValidatorFactory();
/*     */     else {
/*  86 */       factory = Validation.buildDefaultValidatorFactory();
/*     */     }
/*  88 */     this.validator = factory.getValidator();
/*     */   }
/*     */ 
/*     */   public void validate(String methodName, Class<?>[] parameterTypes, Object[] arguments) throws Exception {
/*  92 */     String methodClassName = this.clazz.getName() + "$" + toUpperMethoName(methodName);
/*  93 */     Class methodClass = null;
/*     */     try {
/*  95 */       methodClass = Class.forName(methodClassName, false, Thread.currentThread().getContextClassLoader());
/*     */     } catch (ClassNotFoundException e) {
/*     */     }
/*  98 */     Set violations = new HashSet();
/*  99 */     Method method = this.clazz.getMethod(methodName, parameterTypes);
/* 100 */     Object parameterBean = getMethodParameterBean(this.clazz, method, arguments);
/* 101 */     if (parameterBean != null) {
/* 102 */       if (methodClass != null)
/* 103 */         violations.addAll(this.validator.validate(parameterBean, new Class[] { Default.class, this.clazz, methodClass }));
/*     */       else {
/* 105 */         violations.addAll(this.validator.validate(parameterBean, new Class[] { Default.class, this.clazz }));
/*     */       }
/*     */     }
/* 108 */     for (Object arg : arguments) {
/* 109 */       validate(violations, arg, this.clazz, methodClass);
/*     */     }
/* 111 */     if (violations.size() > 0)
/* 112 */       throw new ConstraintViolationException("Failed to validate service: " + this.clazz.getName() + ", method: " + methodName + ", cause: " + violations, violations);
/*     */   }
/*     */ 
/*     */   private void validate(Set<ConstraintViolation<?>> violations, Object arg, Class<?> clazz, Class<?> methodClass)
/*     */   {
/* 117 */     if ((arg != null) && (!isPrimitives(arg.getClass())))
/* 118 */       if ([Ljava.lang.Object.class.isInstance(arg)) {
/* 119 */         for (Object item : (Object[])arg)
/* 120 */           validate(violations, item, clazz, methodClass);
/*     */       }
/*     */       else
/*     */       {
/*     */         Iterator i$;
/* 122 */         if (Collection.class.isInstance(arg))
/* 123 */           for (i$ = ((Collection)arg).iterator(); i$.hasNext(); ) { Object item = i$.next();
/* 124 */             validate(violations, item, clazz, methodClass);
/*     */           }
/* 126 */         else if (Map.class.isInstance(arg)) {
/* 127 */           for (Map.Entry entry : ((Map)arg).entrySet()) {
/* 128 */             validate(violations, entry.getKey(), clazz, methodClass);
/* 129 */             validate(violations, entry.getValue(), clazz, methodClass);
/*     */           }
/*     */         }
/* 132 */         else if (methodClass != null)
/* 133 */           violations.addAll(this.validator.validate(arg, new Class[] { Default.class, clazz, methodClass }));
/*     */         else
/* 135 */           violations.addAll(this.validator.validate(arg, new Class[] { Default.class, clazz }));
/*     */       }
/*     */   }
/*     */ 
/*     */   private static boolean isPrimitives(Class<?> cls)
/*     */   {
/* 142 */     if (cls.isArray()) {
/* 143 */       return isPrimitive(cls.getComponentType());
/*     */     }
/* 145 */     return isPrimitive(cls);
/*     */   }
/*     */ 
/*     */   private static boolean isPrimitive(Class<?> cls) {
/* 149 */     return (cls.isPrimitive()) || (cls == String.class) || (cls == Boolean.class) || (cls == Character.class) || (Number.class.isAssignableFrom(cls)) || (Date.class.isAssignableFrom(cls));
/*     */   }
/*     */ 
/*     */   private static Object getMethodParameterBean(Class<?> clazz, Method method, Object[] args)
/*     */   {
/* 154 */     if (!hasConstraintParameter(method))
/* 155 */       return null; try {
/* 158 */       String upperName = toUpperMethoName(method.getName());
/* 159 */       String parameterSimpleName = upperName + "Parameter";
/* 160 */       String parameterClassName = clazz.getName() + "$" + parameterSimpleName;
/*     */       Class parameterClass;
/*     */       try { parameterClass = Class.forName(parameterClassName, true, clazz.getClassLoader());
/*     */       } catch (ClassNotFoundException e) {
/* 165 */         ClassPool pool = ClassGenerator.getClassPool(clazz.getClassLoader());
/* 166 */         CtClass ctClass = pool.makeClass(parameterClassName);
/* 167 */         ClassFile classFile = ctClass.getClassFile();
/* 168 */         classFile.setVersionToJava5();
/* 169 */         ctClass.addConstructor(CtNewConstructor.defaultConstructor(pool.getCtClass(parameterClassName)));
/*     */ 
/* 171 */         Class[] parameterTypes = method.getParameterTypes();
/* 172 */         java.lang.annotation.Annotation[][] parameterAnnotations = method.getParameterAnnotations();
/* 173 */         for (int i = 0; i < parameterTypes.length; i++) {
/* 174 */           Class type = parameterTypes[i];
/* 175 */           java.lang.annotation.Annotation[] annotations = parameterAnnotations[i];
/* 176 */           AnnotationsAttribute attribute = new AnnotationsAttribute(classFile.getConstPool(), "RuntimeVisibleAnnotations");
/* 177 */           for (java.lang.annotation.Annotation annotation : annotations) {
/* 178 */             if (annotation.annotationType().isAnnotationPresent(Constraint.class)) {
/* 179 */               javassist.bytecode.annotation.Annotation ja = new javassist.bytecode.annotation.Annotation(classFile.getConstPool(), pool.getCtClass(annotation.annotationType().getName()));
/*     */ 
/* 181 */               Method[] members = annotation.annotationType().getMethods();
/* 182 */               for (Method member : members) {
/* 183 */                 if ((Modifier.isPublic(member.getModifiers())) && (member.getParameterTypes().length == 0) && (member.getDeclaringClass() == annotation.annotationType()))
/*     */                 {
/* 186 */                   Object value = member.invoke(annotation, new Object[0]);
/* 187 */                   if ((value != null) && (!value.equals(member.getDefaultValue()))) {
/* 188 */                     MemberValue memberValue = createMemberValue(classFile.getConstPool(), pool.get(member.getReturnType().getName()), value);
/*     */ 
/* 190 */                     ja.addMemberValue(member.getName(), memberValue);
/*     */                   }
/*     */                 }
/*     */               }
/* 194 */               attribute.addAnnotation(ja);
/*     */             }
/*     */           }
/* 197 */           String fieldName = method.getName() + "Argument" + i;
/* 198 */           CtField ctField = CtField.make("public " + type.getCanonicalName() + " " + fieldName + ";", pool.getCtClass(parameterClassName));
/* 199 */           ctField.getFieldInfo().addAttribute(attribute);
/* 200 */           ctClass.addField(ctField);
/*     */         }
/* 202 */         parameterClass = ctClass.toClass();
/*     */       }
/* 204 */       Object parameterBean = parameterClass.newInstance();
/* 205 */       for (int i = 0; i < args.length; i++) {
/* 206 */         Field field = parameterClass.getField(method.getName() + "Argument" + i);
/* 207 */         field.set(parameterBean, args[i]);
/*     */       }
/* 209 */       return parameterBean;
/*     */     } catch (Throwable e) {
/* 211 */       logger.warn(e.getMessage(), e);
/* 212 */     }return null;
/*     */   }
/*     */ 
/*     */   private static boolean hasConstraintParameter(Method method)
/*     */   {
/* 217 */     java.lang.annotation.Annotation[][] parameterAnnotations = method.getParameterAnnotations();
/* 218 */     if ((parameterAnnotations != null) && (parameterAnnotations.length > 0)) {
/* 219 */       for (java.lang.annotation.Annotation[] annotations : parameterAnnotations) {
/* 220 */         for (java.lang.annotation.Annotation annotation : annotations) {
/* 221 */           if (annotation.annotationType().isAnnotationPresent(Constraint.class)) {
/* 222 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */   private static String toUpperMethoName(String methodName) {
/* 231 */     return methodName.substring(0, 1).toUpperCase() + methodName.substring(1);
/*     */   }
/*     */ 
/*     */   private static MemberValue createMemberValue(ConstPool cp, CtClass type, Object value) throws NotFoundException
/*     */   {
/* 236 */     MemberValue memberValue = javassist.bytecode.annotation.Annotation.createMemberValue(cp, type);
/* 237 */     if ((memberValue instanceof BooleanMemberValue)) {
/* 238 */       ((BooleanMemberValue)memberValue).setValue(((Boolean)value).booleanValue());
/* 239 */     } else if ((memberValue instanceof ByteMemberValue)) {
/* 240 */       ((ByteMemberValue)memberValue).setValue(((Byte)value).byteValue());
/* 241 */     } else if ((memberValue instanceof CharMemberValue)) {
/* 242 */       ((CharMemberValue)memberValue).setValue(((Character)value).charValue());
/* 243 */     } else if ((memberValue instanceof ShortMemberValue)) {
/* 244 */       ((ShortMemberValue)memberValue).setValue(((Short)value).shortValue());
/* 245 */     } else if ((memberValue instanceof IntegerMemberValue)) {
/* 246 */       ((IntegerMemberValue)memberValue).setValue(((Integer)value).intValue());
/* 247 */     } else if ((memberValue instanceof LongMemberValue)) {
/* 248 */       ((LongMemberValue)memberValue).setValue(((Long)value).longValue());
/* 249 */     } else if ((memberValue instanceof FloatMemberValue)) {
/* 250 */       ((FloatMemberValue)memberValue).setValue(((Float)value).floatValue());
/* 251 */     } else if ((memberValue instanceof DoubleMemberValue)) {
/* 252 */       ((DoubleMemberValue)memberValue).setValue(((Double)value).doubleValue());
/* 253 */     } else if ((memberValue instanceof ClassMemberValue)) {
/* 254 */       ((ClassMemberValue)memberValue).setValue(((Class)value).getName());
/* 255 */     } else if ((memberValue instanceof StringMemberValue)) {
/* 256 */       ((StringMemberValue)memberValue).setValue((String)value);
/* 257 */     } else if ((memberValue instanceof EnumMemberValue)) {
/* 258 */       ((EnumMemberValue)memberValue).setValue(((Enum)value).name());
/*     */     }
/* 260 */     else if ((memberValue instanceof ArrayMemberValue)) {
/* 261 */       CtClass arrayType = type.getComponentType();
/* 262 */       int len = Array.getLength(value);
/* 263 */       MemberValue[] members = new MemberValue[len];
/* 264 */       for (int i = 0; i < len; i++) {
/* 265 */         members[i] = createMemberValue(cp, arrayType, Array.get(value, i));
/*     */       }
/* 267 */       ((ArrayMemberValue)memberValue).setValue(members);
/*     */     }
/* 269 */     return memberValue;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\dubbo-2.5.3.jar
 * Qualified Name:     com.alibaba.dubbo.validation.support.jvalidation.JValidator
 * JD-Core Version:    0.6.2
 */