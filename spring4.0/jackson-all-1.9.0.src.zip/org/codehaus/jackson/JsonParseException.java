/*    */ package org.codehaus.jackson;
/*    */ 
/*    */ public class JsonParseException extends JsonProcessingException
/*    */ {
/*    */   static final long serialVersionUID = 123L;
/*    */ 
/*    */   public JsonParseException(String msg, JsonLocation loc)
/*    */   {
/* 15 */     super(msg, loc);
/*    */   }
/*    */ 
/*    */   public JsonParseException(String msg, JsonLocation loc, Throwable root)
/*    */   {
/* 20 */     super(msg, loc, root);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.JsonParseException
 * JD-Core Version:    0.6.2
 */