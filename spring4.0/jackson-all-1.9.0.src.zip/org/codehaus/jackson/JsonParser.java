/*      */ package org.codehaus.jackson;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Iterator;
/*      */ import org.codehaus.jackson.type.TypeReference;
/*      */ 
/*      */ public abstract class JsonParser
/*      */   implements Closeable, Versioned
/*      */ {
/*      */   private static final int MIN_BYTE_I = -128;
/*      */   private static final int MAX_BYTE_I = 127;
/*      */   private static final int MIN_SHORT_I = -32768;
/*      */   private static final int MAX_SHORT_I = 32767;
/*      */   protected int _features;
/*      */   protected JsonToken _currToken;
/*      */   protected JsonToken _lastClearedToken;
/*      */ 
/*      */   protected JsonParser()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected JsonParser(int features)
/*      */   {
/*  289 */     this._features = features;
/*      */   }
/*      */ 
/*      */   public abstract ObjectCodec getCodec();
/*      */ 
/*      */   public abstract void setCodec(ObjectCodec paramObjectCodec);
/*      */ 
/*      */   public void setSchema(FormatSchema schema)
/*      */   {
/*  328 */     throw new UnsupportedOperationException("Parser of type " + getClass().getName() + " does not support schema of type '" + schema.getSchemaType() + "'");
/*      */   }
/*      */ 
/*      */   public boolean canUseSchema(FormatSchema schema)
/*      */   {
/*  343 */     return false;
/*      */   }
/*      */ 
/*      */   public Version version()
/*      */   {
/*  351 */     return Version.unknownVersion();
/*      */   }
/*      */ 
/*      */   public Object getInputSource()
/*      */   {
/*  372 */     return null;
/*      */   }
/*      */ 
/*      */   public abstract void close()
/*      */     throws IOException;
/*      */ 
/*      */   public int releaseBuffered(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  423 */     return -1;
/*      */   }
/*      */ 
/*      */   public int releaseBuffered(Writer w)
/*      */     throws IOException
/*      */   {
/*  445 */     return -1;
/*      */   }
/*      */ 
/*      */   public JsonParser enable(Feature f)
/*      */   {
/*  462 */     this._features |= f.getMask();
/*  463 */     return this;
/*      */   }
/*      */ 
/*      */   public JsonParser disable(Feature f)
/*      */   {
/*  474 */     this._features &= (f.getMask() ^ 0xFFFFFFFF);
/*  475 */     return this;
/*      */   }
/*      */ 
/*      */   public JsonParser configure(Feature f, boolean state)
/*      */   {
/*  486 */     if (state)
/*  487 */       enableFeature(f);
/*      */     else {
/*  489 */       disableFeature(f);
/*      */     }
/*  491 */     return this;
/*      */   }
/*      */ 
/*      */   public boolean isEnabled(Feature f)
/*      */   {
/*  501 */     return (this._features & f.getMask()) != 0;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void setFeature(Feature f, boolean state)
/*      */   {
/*  507 */     configure(f, state);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void enableFeature(Feature f) {
/*  512 */     enable(f);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void disableFeature(Feature f) {
/*  517 */     disable(f);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public final boolean isFeatureEnabled(Feature f) {
/*  522 */     return isEnabled(f);
/*      */   }
/*      */ 
/*      */   public abstract JsonToken nextToken()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public JsonToken nextValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  567 */     JsonToken t = nextToken();
/*  568 */     if (t == JsonToken.FIELD_NAME) {
/*  569 */       t = nextToken();
/*      */     }
/*  571 */     return t;
/*      */   }
/*      */ 
/*      */   public boolean nextFieldName(SerializableString str)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  592 */     return (nextToken() == JsonToken.FIELD_NAME) && (str.getValue().equals(getCurrentName()));
/*      */   }
/*      */ 
/*      */   public String nextTextValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  611 */     return nextToken() == JsonToken.VALUE_STRING ? getText() : null;
/*      */   }
/*      */ 
/*      */   public int nextIntValue(int defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  630 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */   public long nextLongValue(long defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  649 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */   public Boolean nextBooleanValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  671 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[nextToken().ordinal()]) {
/*      */     case 1:
/*  673 */       return Boolean.TRUE;
/*      */     case 2:
/*  675 */       return Boolean.FALSE;
/*      */     }
/*  677 */     return null;
/*      */   }
/*      */ 
/*      */   public abstract JsonParser skipChildren()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract boolean isClosed();
/*      */ 
/*      */   public JsonToken getCurrentToken()
/*      */   {
/*  725 */     return this._currToken;
/*      */   }
/*      */ 
/*      */   public boolean hasCurrentToken()
/*      */   {
/*  740 */     return this._currToken != null;
/*      */   }
/*      */ 
/*      */   public void clearCurrentToken()
/*      */   {
/*  757 */     if (this._currToken != null) {
/*  758 */       this._lastClearedToken = this._currToken;
/*  759 */       this._currToken = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public abstract String getCurrentName()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract JsonStreamContext getParsingContext();
/*      */ 
/*      */   public abstract JsonLocation getTokenLocation();
/*      */ 
/*      */   public abstract JsonLocation getCurrentLocation();
/*      */ 
/*      */   public JsonToken getLastClearedToken()
/*      */   {
/*  806 */     return this._lastClearedToken;
/*      */   }
/*      */ 
/*      */   public boolean isExpectedStartArrayToken()
/*      */   {
/*  829 */     return getCurrentToken() == JsonToken.START_ARRAY;
/*      */   }
/*      */ 
/*      */   public abstract String getText()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract char[] getTextCharacters()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract int getTextLength()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract int getTextOffset()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public boolean hasTextCharacters()
/*      */   {
/*  917 */     return false;
/*      */   }
/*      */ 
/*      */   public abstract Number getNumberValue()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract NumberType getNumberType()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public byte getByteValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  960 */     int value = getIntValue();
/*      */ 
/*  962 */     if ((value < -128) || (value > 127)) {
/*  963 */       throw _constructError("Numeric value (" + getText() + ") out of range of Java byte");
/*      */     }
/*  965 */     return (byte)value;
/*      */   }
/*      */ 
/*      */   public short getShortValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  984 */     int value = getIntValue();
/*  985 */     if ((value < -32768) || (value > 32767)) {
/*  986 */       throw _constructError("Numeric value (" + getText() + ") out of range of Java short");
/*      */     }
/*  988 */     return (short)value;
/*      */   }
/*      */ 
/*      */   public abstract int getIntValue()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract long getLongValue()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract BigInteger getBigIntegerValue()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract float getFloatValue()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract double getDoubleValue()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public abstract BigDecimal getDecimalValue()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public boolean getBooleanValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1097 */     if (this._currToken == JsonToken.VALUE_TRUE) return true;
/* 1098 */     if (this._currToken == JsonToken.VALUE_FALSE) return false;
/* 1099 */     throw new JsonParseException("Current token (" + this._currToken + ") not of boolean type", getCurrentLocation());
/*      */   }
/*      */ 
/*      */   public Object getEmbeddedObject()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1117 */     return null;
/*      */   }
/*      */ 
/*      */   public abstract byte[] getBinaryValue(Base64Variant paramBase64Variant)
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   public byte[] getBinaryValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1157 */     return getBinaryValue(Base64Variants.getDefaultVariant());
/*      */   }
/*      */ 
/*      */   public int getValueAsInt()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1180 */     return getValueAsInt(0);
/*      */   }
/*      */ 
/*      */   public int getValueAsInt(int defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1197 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public long getValueAsLong()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1214 */     return getValueAsInt(0);
/*      */   }
/*      */ 
/*      */   public long getValueAsLong(long defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1231 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public double getValueAsDouble()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1248 */     return getValueAsDouble(0.0D);
/*      */   }
/*      */ 
/*      */   public double getValueAsDouble(double defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1265 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public boolean getValueAsBoolean()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1282 */     return getValueAsBoolean(false);
/*      */   }
/*      */ 
/*      */   public boolean getValueAsBoolean(boolean defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1299 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public <T> T readValueAs(Class<T> valueType)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1332 */     ObjectCodec codec = getCodec();
/* 1333 */     if (codec == null) {
/* 1334 */       throw new IllegalStateException("No ObjectCodec defined for the parser, can not deserialize JSON into Java objects");
/*      */     }
/* 1336 */     return codec.readValue(this, valueType);
/*      */   }
/*      */ 
/*      */   public <T> T readValueAs(TypeReference<?> valueTypeRef)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1361 */     ObjectCodec codec = getCodec();
/* 1362 */     if (codec == null) {
/* 1363 */       throw new IllegalStateException("No ObjectCodec defined for the parser, can not deserialize JSON into Java objects");
/*      */     }
/*      */ 
/* 1368 */     return codec.readValue(this, valueTypeRef);
/*      */   }
/*      */ 
/*      */   public <T> Iterator<T> readValuesAs(Class<T> valueType)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1380 */     ObjectCodec codec = getCodec();
/* 1381 */     if (codec == null) {
/* 1382 */       throw new IllegalStateException("No ObjectCodec defined for the parser, can not deserialize JSON into Java objects");
/*      */     }
/* 1384 */     return codec.readValues(this, valueType);
/*      */   }
/*      */ 
/*      */   public <T> Iterator<T> readValuesAs(TypeReference<?> valueTypeRef)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1396 */     ObjectCodec codec = getCodec();
/* 1397 */     if (codec == null) {
/* 1398 */       throw new IllegalStateException("No ObjectCodec defined for the parser, can not deserialize JSON into Java objects");
/*      */     }
/* 1400 */     return codec.readValues(this, valueTypeRef);
/*      */   }
/*      */ 
/*      */   public JsonNode readValueAsTree()
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1413 */     ObjectCodec codec = getCodec();
/* 1414 */     if (codec == null) {
/* 1415 */       throw new IllegalStateException("No ObjectCodec defined for the parser, can not deserialize JSON into JsonNode tree");
/*      */     }
/* 1417 */     return codec.readTree(this);
/*      */   }
/*      */ 
/*      */   protected JsonParseException _constructError(String msg)
/*      */   {
/* 1432 */     return new JsonParseException(msg, getCurrentLocation());
/*      */   }
/*      */ 
/*      */   public static enum Feature
/*      */   {
/*   68 */     AUTO_CLOSE_SOURCE(true), 
/*      */ 
/*   86 */     ALLOW_COMMENTS(false), 
/*      */ 
/*  102 */     ALLOW_UNQUOTED_FIELD_NAMES(false), 
/*      */ 
/*  120 */     ALLOW_SINGLE_QUOTES(false), 
/*      */ 
/*  137 */     ALLOW_UNQUOTED_CONTROL_CHARS(false), 
/*      */ 
/*  152 */     ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER(false), 
/*      */ 
/*  168 */     ALLOW_NUMERIC_LEADING_ZEROS(false), 
/*      */ 
/*  186 */     ALLOW_NON_NUMERIC_NUMBERS(false), 
/*      */ 
/*  205 */     INTERN_FIELD_NAMES(true), 
/*      */ 
/*  215 */     CANONICALIZE_FIELD_NAMES(true);
/*      */ 
/*      */     final boolean _defaultState;
/*      */ 
/*      */     public static int collectDefaults()
/*      */     {
/*  228 */       int flags = 0;
/*  229 */       for (Feature f : values()) {
/*  230 */         if (f.enabledByDefault()) {
/*  231 */           flags |= f.getMask();
/*      */         }
/*      */       }
/*  234 */       return flags;
/*      */     }
/*      */ 
/*      */     private Feature(boolean defaultState) {
/*  238 */       this._defaultState = defaultState;
/*      */     }
/*      */     public boolean enabledByDefault() {
/*  241 */       return this._defaultState;
/*      */     }
/*  243 */     public boolean enabledIn(int flags) { return (flags & getMask()) != 0; } 
/*      */     public int getMask() {
/*  245 */       return 1 << ordinal();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum NumberType
/*      */   {
/*   46 */     INT, LONG, BIG_INTEGER, FLOAT, DOUBLE, BIG_DECIMAL;
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.JsonParser
 * JD-Core Version:    0.6.2
 */