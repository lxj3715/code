package org.codehaus.jackson;

public abstract interface Versioned
{
  public abstract Version version();
}

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.Versioned
 * JD-Core Version:    0.6.2
 */