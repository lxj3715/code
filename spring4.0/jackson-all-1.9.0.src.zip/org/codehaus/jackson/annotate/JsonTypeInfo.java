/*     */ package org.codehaus.jackson.annotate;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ 
/*     */ @Target({java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.PARAMETER})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @JacksonAnnotation
/*     */ public @interface JsonTypeInfo
/*     */ {
/*     */   public abstract Id use();
/*     */ 
/*     */   public abstract As include();
/*     */ 
/*     */   public abstract String property();
/*     */ 
/*     */   public abstract Class<?> defaultImpl();
/*     */ 
/*     */   public static abstract class None
/*     */   {
/*     */   }
/*     */ 
/*     */   public static enum As
/*     */   {
/* 127 */     PROPERTY, 
/*     */ 
/* 140 */     WRAPPER_OBJECT, 
/*     */ 
/* 149 */     WRAPPER_ARRAY, 
/*     */ 
/* 161 */     EXTERNAL_PROPERTY;
/*     */   }
/*     */ 
/*     */   public static enum Id
/*     */   {
/*  66 */     NONE(null), 
/*     */ 
/*  71 */     CLASS("@class"), 
/*     */ 
/*  90 */     MINIMAL_CLASS("@c"), 
/*     */ 
/*  96 */     NAME("@type"), 
/*     */ 
/* 103 */     CUSTOM(null);
/*     */ 
/*     */     private final String _defaultPropertyName;
/*     */ 
/*     */     private Id(String defProp)
/*     */     {
/* 109 */       this._defaultPropertyName = defProp;
/*     */     }
/*     */     public String getDefaultPropertyName() {
/* 112 */       return this._defaultPropertyName;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.annotate.JsonTypeInfo
 * JD-Core Version:    0.6.2
 */