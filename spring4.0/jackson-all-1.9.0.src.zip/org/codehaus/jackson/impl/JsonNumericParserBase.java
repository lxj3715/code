/*    */ package org.codehaus.jackson.impl;
/*    */ 
/*    */ import org.codehaus.jackson.io.IOContext;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class JsonNumericParserBase extends JsonParserBase
/*    */ {
/*    */   protected JsonNumericParserBase(IOContext ctxt, int features)
/*    */   {
/* 18 */     super(ctxt, features);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.impl.JsonNumericParserBase
 * JD-Core Version:    0.6.2
 */