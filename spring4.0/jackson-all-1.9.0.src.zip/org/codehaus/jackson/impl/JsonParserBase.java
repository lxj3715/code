/*      */ package org.codehaus.jackson.impl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import org.codehaus.jackson.Base64Variant;
/*      */ import org.codehaus.jackson.JsonLocation;
/*      */ import org.codehaus.jackson.JsonParseException;
/*      */ import org.codehaus.jackson.JsonParser.NumberType;
/*      */ import org.codehaus.jackson.JsonToken;
/*      */ import org.codehaus.jackson.Version;
/*      */ import org.codehaus.jackson.io.IOContext;
/*      */ import org.codehaus.jackson.io.NumberInput;
/*      */ import org.codehaus.jackson.util.ByteArrayBuilder;
/*      */ import org.codehaus.jackson.util.TextBuffer;
/*      */ import org.codehaus.jackson.util.VersionUtil;
/*      */ 
/*      */ public abstract class JsonParserBase extends JsonParserMinimalBase
/*      */ {
/*      */   protected final IOContext _ioContext;
/*      */   protected boolean _closed;
/*   54 */   protected int _inputPtr = 0;
/*      */ 
/*   59 */   protected int _inputEnd = 0;
/*      */ 
/*   71 */   protected long _currInputProcessed = 0L;
/*      */ 
/*   77 */   protected int _currInputRow = 1;
/*      */ 
/*   85 */   protected int _currInputRowStart = 0;
/*      */ 
/*  101 */   protected long _tokenInputTotal = 0L;
/*      */ 
/*  106 */   protected int _tokenInputRow = 1;
/*      */ 
/*  112 */   protected int _tokenInputCol = 0;
/*      */   protected JsonReadContext _parsingContext;
/*      */   protected JsonToken _nextToken;
/*      */   protected final TextBuffer _textBuffer;
/*  151 */   protected char[] _nameCopyBuffer = null;
/*      */ 
/*  158 */   protected boolean _nameCopied = false;
/*      */ 
/*  164 */   protected ByteArrayBuilder _byteArrayBuilder = null;
/*      */   protected byte[] _binaryValue;
/*      */   protected static final int NR_UNKNOWN = 0;
/*      */   protected static final int NR_INT = 1;
/*      */   protected static final int NR_LONG = 2;
/*      */   protected static final int NR_BIGINT = 4;
/*      */   protected static final int NR_DOUBLE = 8;
/*      */   protected static final int NR_BIGDECIMAL = 16;
/*  195 */   static final BigDecimal BD_MIN_LONG = new BigDecimal(-9223372036854775808L);
/*  196 */   static final BigDecimal BD_MAX_LONG = new BigDecimal(9223372036854775807L);
/*      */ 
/*  198 */   static final BigDecimal BD_MIN_INT = new BigDecimal(-9223372036854775808L);
/*  199 */   static final BigDecimal BD_MAX_INT = new BigDecimal(9223372036854775807L);
/*      */   static final long MIN_INT_L = -2147483648L;
/*      */   static final long MAX_INT_L = 2147483647L;
/*      */   static final double MIN_LONG_D = -9.223372036854776E+018D;
/*      */   static final double MAX_LONG_D = 9.223372036854776E+018D;
/*      */   static final double MIN_INT_D = -2147483648.0D;
/*      */   static final double MAX_INT_D = 2147483647.0D;
/*      */   protected static final int INT_0 = 48;
/*      */   protected static final int INT_1 = 49;
/*      */   protected static final int INT_2 = 50;
/*      */   protected static final int INT_3 = 51;
/*      */   protected static final int INT_4 = 52;
/*      */   protected static final int INT_5 = 53;
/*      */   protected static final int INT_6 = 54;
/*      */   protected static final int INT_7 = 55;
/*      */   protected static final int INT_8 = 56;
/*      */   protected static final int INT_9 = 57;
/*      */   protected static final int INT_MINUS = 45;
/*      */   protected static final int INT_PLUS = 43;
/*      */   protected static final int INT_DECIMAL_POINT = 46;
/*      */   protected static final int INT_e = 101;
/*      */   protected static final int INT_E = 69;
/*      */   protected static final char CHAR_NULL = '\000';
/*  241 */   protected int _numTypesValid = 0;
/*      */   protected int _numberInt;
/*      */   protected long _numberLong;
/*      */   protected double _numberDouble;
/*      */   protected BigInteger _numberBigInt;
/*      */   protected BigDecimal _numberBigDecimal;
/*      */   protected boolean _numberNegative;
/*      */   protected int _intLength;
/*      */   protected int _fractLength;
/*      */   protected int _expLength;
/*      */ 
/*      */   protected JsonParserBase(IOContext ctxt, int features)
/*      */   {
/*  294 */     this._features = features;
/*  295 */     this._ioContext = ctxt;
/*  296 */     this._textBuffer = ctxt.constructTextBuffer();
/*  297 */     this._parsingContext = JsonReadContext.createRootContext();
/*      */   }
/*      */ 
/*      */   public Version version()
/*      */   {
/*  302 */     return VersionUtil.versionFor(getClass());
/*      */   }
/*      */ 
/*      */   public String getCurrentName()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  320 */     if ((this._currToken == JsonToken.START_OBJECT) || (this._currToken == JsonToken.START_ARRAY)) {
/*  321 */       JsonReadContext parent = this._parsingContext.getParent();
/*  322 */       return parent.getCurrentName();
/*      */     }
/*  324 */     return this._parsingContext.getCurrentName();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  330 */     if (!this._closed) {
/*  331 */       this._closed = true;
/*      */       try {
/*  333 */         _closeInput();
/*      */       }
/*      */       finally
/*      */       {
/*  337 */         _releaseBuffers();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isClosed() {
/*  343 */     return this._closed;
/*      */   }
/*      */ 
/*      */   public JsonReadContext getParsingContext()
/*      */   {
/*  348 */     return this._parsingContext;
/*      */   }
/*      */ 
/*      */   public JsonLocation getTokenLocation()
/*      */   {
/*  359 */     return new JsonLocation(this._ioContext.getSourceReference(), getTokenCharacterOffset(), getTokenLineNr(), getTokenColumnNr());
/*      */   }
/*      */ 
/*      */   public JsonLocation getCurrentLocation()
/*      */   {
/*  372 */     int col = this._inputPtr - this._currInputRowStart + 1;
/*  373 */     return new JsonLocation(this._ioContext.getSourceReference(), this._currInputProcessed + this._inputPtr - 1L, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */   public boolean hasTextCharacters()
/*      */   {
/*  387 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  388 */       return true;
/*      */     }
/*  390 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  391 */       return this._nameCopied;
/*      */     }
/*  393 */     return false;
/*      */   }
/*      */ 
/*      */   public final long getTokenCharacterOffset()
/*      */   {
/*  402 */     return this._tokenInputTotal; } 
/*  403 */   public final int getTokenLineNr() { return this._tokenInputRow; }
/*      */ 
/*      */   public final int getTokenColumnNr() {
/*  406 */     int col = this._tokenInputCol;
/*  407 */     return col < 0 ? col : col + 1;
/*      */   }
/*      */ 
/*      */   protected final void loadMoreGuaranteed()
/*      */     throws IOException
/*      */   {
/*  419 */     if (!loadMore())
/*  420 */       _reportInvalidEOF();
/*      */   }
/*      */ 
/*      */   protected abstract boolean loadMore()
/*      */     throws IOException;
/*      */ 
/*      */   protected abstract void _finishString()
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   protected abstract void _closeInput()
/*      */     throws IOException;
/*      */ 
/*      */   protected abstract byte[] _decodeBase64(Base64Variant paramBase64Variant)
/*      */     throws IOException, JsonParseException;
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */     throws IOException
/*      */   {
/*  452 */     this._textBuffer.releaseBuffers();
/*  453 */     char[] buf = this._nameCopyBuffer;
/*  454 */     if (buf != null) {
/*  455 */       this._nameCopyBuffer = null;
/*  456 */       this._ioContext.releaseNameCopyBuffer(buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _handleEOF()
/*      */     throws JsonParseException
/*      */   {
/*  468 */     if (!this._parsingContext.inRoot())
/*  469 */       _reportInvalidEOF(": expected close marker for " + this._parsingContext.getTypeDesc() + " (from " + this._parsingContext.getStartLocation(this._ioContext.getSourceReference()) + ")");
/*      */   }
/*      */ 
/*      */   protected void _reportMismatchedEndMarker(int actCh, char expCh)
/*      */     throws JsonParseException
/*      */   {
/*  482 */     String startDesc = "" + this._parsingContext.getStartLocation(this._ioContext.getSourceReference());
/*  483 */     _reportError("Unexpected close marker '" + (char)actCh + "': expected '" + expCh + "' (for " + this._parsingContext.getTypeDesc() + " starting at " + startDesc + ")");
/*      */   }
/*      */ 
/*      */   public ByteArrayBuilder _getByteArrayBuilder()
/*      */   {
/*  494 */     if (this._byteArrayBuilder == null)
/*  495 */       this._byteArrayBuilder = new ByteArrayBuilder();
/*      */     else {
/*  497 */       this._byteArrayBuilder.reset();
/*      */     }
/*  499 */     return this._byteArrayBuilder;
/*      */   }
/*      */ 
/*      */   protected final JsonToken reset(boolean negative, int intLen, int fractLen, int expLen)
/*      */   {
/*  512 */     if ((fractLen < 1) && (expLen < 1)) {
/*  513 */       return resetInt(negative, intLen);
/*      */     }
/*  515 */     return resetFloat(negative, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */   protected final JsonToken resetInt(boolean negative, int intLen)
/*      */   {
/*  520 */     this._numberNegative = negative;
/*  521 */     this._intLength = intLen;
/*  522 */     this._fractLength = 0;
/*  523 */     this._expLength = 0;
/*  524 */     this._numTypesValid = 0;
/*  525 */     return JsonToken.VALUE_NUMBER_INT;
/*      */   }
/*      */ 
/*      */   protected final JsonToken resetFloat(boolean negative, int intLen, int fractLen, int expLen)
/*      */   {
/*  530 */     this._numberNegative = negative;
/*  531 */     this._intLength = intLen;
/*  532 */     this._fractLength = fractLen;
/*  533 */     this._expLength = expLen;
/*  534 */     this._numTypesValid = 0;
/*  535 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */ 
/*      */   protected final JsonToken resetAsNaN(String valueStr, double value)
/*      */   {
/*  540 */     this._textBuffer.resetWithString(valueStr);
/*  541 */     this._numberDouble = value;
/*  542 */     this._numTypesValid = 8;
/*  543 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */ 
/*      */   public Number getNumberValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  555 */     if (this._numTypesValid == 0) {
/*  556 */       _parseNumericValue(0);
/*      */     }
/*      */ 
/*  559 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  560 */       if ((this._numTypesValid & 0x1) != 0) {
/*  561 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  563 */       if ((this._numTypesValid & 0x2) != 0) {
/*  564 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  566 */       if ((this._numTypesValid & 0x4) != 0) {
/*  567 */         return this._numberBigInt;
/*      */       }
/*      */ 
/*  570 */       return this._numberBigDecimal;
/*      */     }
/*      */ 
/*  576 */     if ((this._numTypesValid & 0x10) != 0) {
/*  577 */       return this._numberBigDecimal;
/*      */     }
/*  579 */     if ((this._numTypesValid & 0x8) == 0) {
/*  580 */       _throwInternal();
/*      */     }
/*  582 */     return Double.valueOf(this._numberDouble);
/*      */   }
/*      */ 
/*      */   public JsonParser.NumberType getNumberType()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  588 */     if (this._numTypesValid == 0) {
/*  589 */       _parseNumericValue(0);
/*      */     }
/*  591 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  592 */       if ((this._numTypesValid & 0x1) != 0) {
/*  593 */         return JsonParser.NumberType.INT;
/*      */       }
/*  595 */       if ((this._numTypesValid & 0x2) != 0) {
/*  596 */         return JsonParser.NumberType.LONG;
/*      */       }
/*  598 */       return JsonParser.NumberType.BIG_INTEGER;
/*      */     }
/*      */ 
/*  607 */     if ((this._numTypesValid & 0x10) != 0) {
/*  608 */       return JsonParser.NumberType.BIG_DECIMAL;
/*      */     }
/*  610 */     return JsonParser.NumberType.DOUBLE;
/*      */   }
/*      */ 
/*      */   public int getIntValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  616 */     if ((this._numTypesValid & 0x1) == 0) {
/*  617 */       if (this._numTypesValid == 0) {
/*  618 */         _parseNumericValue(1);
/*      */       }
/*  620 */       if ((this._numTypesValid & 0x1) == 0) {
/*  621 */         convertNumberToInt();
/*      */       }
/*      */     }
/*  624 */     return this._numberInt;
/*      */   }
/*      */ 
/*      */   public long getLongValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  630 */     if ((this._numTypesValid & 0x2) == 0) {
/*  631 */       if (this._numTypesValid == 0) {
/*  632 */         _parseNumericValue(2);
/*      */       }
/*  634 */       if ((this._numTypesValid & 0x2) == 0) {
/*  635 */         convertNumberToLong();
/*      */       }
/*      */     }
/*  638 */     return this._numberLong;
/*      */   }
/*      */ 
/*      */   public BigInteger getBigIntegerValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  644 */     if ((this._numTypesValid & 0x4) == 0) {
/*  645 */       if (this._numTypesValid == 0) {
/*  646 */         _parseNumericValue(4);
/*      */       }
/*  648 */       if ((this._numTypesValid & 0x4) == 0) {
/*  649 */         convertNumberToBigInteger();
/*      */       }
/*      */     }
/*  652 */     return this._numberBigInt;
/*      */   }
/*      */ 
/*      */   public float getFloatValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  658 */     double value = getDoubleValue();
/*      */ 
/*  667 */     return (float)value;
/*      */   }
/*      */ 
/*      */   public double getDoubleValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  673 */     if ((this._numTypesValid & 0x8) == 0) {
/*  674 */       if (this._numTypesValid == 0) {
/*  675 */         _parseNumericValue(8);
/*      */       }
/*  677 */       if ((this._numTypesValid & 0x8) == 0) {
/*  678 */         convertNumberToDouble();
/*      */       }
/*      */     }
/*  681 */     return this._numberDouble;
/*      */   }
/*      */ 
/*      */   public BigDecimal getDecimalValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  687 */     if ((this._numTypesValid & 0x10) == 0) {
/*  688 */       if (this._numTypesValid == 0) {
/*  689 */         _parseNumericValue(16);
/*      */       }
/*  691 */       if ((this._numTypesValid & 0x10) == 0) {
/*  692 */         convertNumberToBigDecimal();
/*      */       }
/*      */     }
/*  695 */     return this._numberBigDecimal;
/*      */   }
/*      */ 
/*      */   protected void _parseNumericValue(int expType)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  718 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  719 */       char[] buf = this._textBuffer.getTextBuffer();
/*  720 */       int offset = this._textBuffer.getTextOffset();
/*  721 */       int len = this._intLength;
/*  722 */       if (this._numberNegative) {
/*  723 */         offset++;
/*      */       }
/*  725 */       if (len <= 9) {
/*  726 */         int i = NumberInput.parseInt(buf, offset, len);
/*  727 */         this._numberInt = (this._numberNegative ? -i : i);
/*  728 */         this._numTypesValid = 1;
/*  729 */         return;
/*      */       }
/*  731 */       if (len <= 18) {
/*  732 */         long l = NumberInput.parseLong(buf, offset, len);
/*  733 */         if (this._numberNegative) {
/*  734 */           l = -l;
/*      */         }
/*      */ 
/*  737 */         if (len == 10) {
/*  738 */           if (this._numberNegative) {
/*  739 */             if (l >= -2147483648L) {
/*  740 */               this._numberInt = ((int)l);
/*  741 */               this._numTypesValid = 1;
/*      */             }
/*      */ 
/*      */           }
/*  745 */           else if (l <= 2147483647L) {
/*  746 */             this._numberInt = ((int)l);
/*  747 */             this._numTypesValid = 1;
/*  748 */             return;
/*      */           }
/*      */         }
/*      */ 
/*  752 */         this._numberLong = l;
/*  753 */         this._numTypesValid = 2;
/*  754 */         return;
/*      */       }
/*  756 */       _parseSlowIntValue(expType, buf, offset, len);
/*  757 */       return;
/*      */     }
/*  759 */     if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/*  760 */       _parseSlowFloatValue(expType);
/*  761 */       return;
/*      */     }
/*  763 */     _reportError("Current token (" + this._currToken + ") not numeric, can not use numeric value accessors");
/*      */   }
/*      */ 
/*      */   private final void _parseSlowFloatValue(int expType)
/*      */     throws IOException, JsonParseException
/*      */   {
/*      */     try
/*      */     {
/*  777 */       if (expType == 16) {
/*  778 */         this._numberBigDecimal = this._textBuffer.contentsAsDecimal();
/*  779 */         this._numTypesValid = 16;
/*      */       }
/*      */       else {
/*  782 */         this._numberDouble = this._textBuffer.contentsAsDouble();
/*  783 */         this._numTypesValid = 8;
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException nex) {
/*  787 */       _wrapError("Malformed numeric value '" + this._textBuffer.contentsAsString() + "'", nex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _parseSlowIntValue(int expType, char[] buf, int offset, int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  794 */     String numStr = this._textBuffer.contentsAsString();
/*      */     try
/*      */     {
/*  797 */       if (NumberInput.inLongRange(buf, offset, len, this._numberNegative))
/*      */       {
/*  799 */         this._numberLong = Long.parseLong(numStr);
/*  800 */         this._numTypesValid = 2;
/*      */       }
/*      */       else {
/*  803 */         this._numberBigInt = new BigInteger(numStr);
/*  804 */         this._numTypesValid = 4;
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException nex) {
/*  808 */       _wrapError("Malformed numeric value '" + numStr + "'", nex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void convertNumberToInt()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  822 */     if ((this._numTypesValid & 0x2) != 0)
/*      */     {
/*  824 */       int result = (int)this._numberLong;
/*  825 */       if (result != this._numberLong) {
/*  826 */         _reportError("Numeric value (" + getText() + ") out of range of int");
/*      */       }
/*  828 */       this._numberInt = result;
/*  829 */     } else if ((this._numTypesValid & 0x4) != 0)
/*      */     {
/*  831 */       this._numberInt = this._numberBigInt.intValue();
/*  832 */     } else if ((this._numTypesValid & 0x8) != 0)
/*      */     {
/*  834 */       if ((this._numberDouble < -2147483648.0D) || (this._numberDouble > 2147483647.0D)) {
/*  835 */         reportOverflowInt();
/*      */       }
/*  837 */       this._numberInt = ((int)this._numberDouble);
/*  838 */     } else if ((this._numTypesValid & 0x10) != 0) {
/*  839 */       if ((BD_MIN_INT.compareTo(this._numberBigDecimal) > 0) || (BD_MAX_INT.compareTo(this._numberBigDecimal) < 0))
/*      */       {
/*  841 */         reportOverflowInt();
/*      */       }
/*  843 */       this._numberInt = this._numberBigDecimal.intValue();
/*      */     } else {
/*  845 */       _throwInternal();
/*      */     }
/*      */ 
/*  848 */     this._numTypesValid |= 1;
/*      */   }
/*      */ 
/*      */   protected void convertNumberToLong()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  854 */     if ((this._numTypesValid & 0x1) != 0) {
/*  855 */       this._numberLong = this._numberInt;
/*  856 */     } else if ((this._numTypesValid & 0x4) != 0)
/*      */     {
/*  858 */       this._numberLong = this._numberBigInt.longValue();
/*  859 */     } else if ((this._numTypesValid & 0x8) != 0)
/*      */     {
/*  861 */       if ((this._numberDouble < -9.223372036854776E+018D) || (this._numberDouble > 9.223372036854776E+018D)) {
/*  862 */         reportOverflowLong();
/*      */       }
/*  864 */       this._numberLong = (()this._numberDouble);
/*  865 */     } else if ((this._numTypesValid & 0x10) != 0) {
/*  866 */       if ((BD_MIN_LONG.compareTo(this._numberBigDecimal) > 0) || (BD_MAX_LONG.compareTo(this._numberBigDecimal) < 0))
/*      */       {
/*  868 */         reportOverflowLong();
/*      */       }
/*  870 */       this._numberLong = this._numberBigDecimal.longValue();
/*      */     } else {
/*  872 */       _throwInternal();
/*      */     }
/*      */ 
/*  875 */     this._numTypesValid |= 2;
/*      */   }
/*      */ 
/*      */   protected void convertNumberToBigInteger()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  881 */     if ((this._numTypesValid & 0x10) != 0)
/*      */     {
/*  883 */       this._numberBigInt = this._numberBigDecimal.toBigInteger();
/*  884 */     } else if ((this._numTypesValid & 0x2) != 0)
/*  885 */       this._numberBigInt = BigInteger.valueOf(this._numberLong);
/*  886 */     else if ((this._numTypesValid & 0x1) != 0)
/*  887 */       this._numberBigInt = BigInteger.valueOf(this._numberInt);
/*  888 */     else if ((this._numTypesValid & 0x8) != 0)
/*  889 */       this._numberBigInt = BigDecimal.valueOf(this._numberDouble).toBigInteger();
/*      */     else {
/*  891 */       _throwInternal();
/*      */     }
/*  893 */     this._numTypesValid |= 4;
/*      */   }
/*      */ 
/*      */   protected void convertNumberToDouble()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  905 */     if ((this._numTypesValid & 0x10) != 0)
/*  906 */       this._numberDouble = this._numberBigDecimal.doubleValue();
/*  907 */     else if ((this._numTypesValid & 0x4) != 0)
/*  908 */       this._numberDouble = this._numberBigInt.doubleValue();
/*  909 */     else if ((this._numTypesValid & 0x2) != 0)
/*  910 */       this._numberDouble = this._numberLong;
/*  911 */     else if ((this._numTypesValid & 0x1) != 0)
/*  912 */       this._numberDouble = this._numberInt;
/*      */     else {
/*  914 */       _throwInternal();
/*      */     }
/*      */ 
/*  917 */     this._numTypesValid |= 8;
/*      */   }
/*      */ 
/*      */   protected void convertNumberToBigDecimal()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  929 */     if ((this._numTypesValid & 0x8) != 0)
/*      */     {
/*  934 */       this._numberBigDecimal = new BigDecimal(getText());
/*  935 */     } else if ((this._numTypesValid & 0x4) != 0)
/*  936 */       this._numberBigDecimal = new BigDecimal(this._numberBigInt);
/*  937 */     else if ((this._numTypesValid & 0x2) != 0)
/*  938 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberLong);
/*  939 */     else if ((this._numTypesValid & 0x1) != 0)
/*  940 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberInt);
/*      */     else {
/*  942 */       _throwInternal();
/*      */     }
/*  944 */     this._numTypesValid |= 16;
/*      */   }
/*      */ 
/*      */   protected void reportUnexpectedNumberChar(int ch, String comment)
/*      */     throws JsonParseException
/*      */   {
/*  956 */     String msg = "Unexpected character (" + _getCharDesc(ch) + ") in numeric value";
/*  957 */     if (comment != null) {
/*  958 */       msg = msg + ": " + comment;
/*      */     }
/*  960 */     _reportError(msg);
/*      */   }
/*      */ 
/*      */   protected void reportInvalidNumber(String msg)
/*      */     throws JsonParseException
/*      */   {
/*  966 */     _reportError("Invalid numeric value: " + msg);
/*      */   }
/*      */ 
/*      */   protected void reportOverflowInt()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  973 */     _reportError("Numeric value (" + getText() + ") out of range of int (" + -2147483648 + " - " + 2147483647 + ")");
/*      */   }
/*      */ 
/*      */   protected void reportOverflowLong()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  979 */     _reportError("Numeric value (" + getText() + ") out of range of long (" + -9223372036854775808L + " - " + 9223372036854775807L + ")");
/*      */   }
/*      */ 
/*      */   protected char _decodeEscaped()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  995 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, int ch, int index)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1002 */     if (ch != 92) {
/* 1003 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1005 */     int unescaped = _decodeEscaped();
/*      */ 
/* 1007 */     if ((unescaped <= 32) && 
/* 1008 */       (index == 0)) {
/* 1009 */       return -1;
/*      */     }
/*      */ 
/* 1013 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1014 */     if (bits < 0) {
/* 1015 */       throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */     }
/* 1017 */     return bits;
/*      */   }
/*      */ 
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, char ch, int index)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1024 */     if (ch != '\\') {
/* 1025 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1027 */     char unescaped = _decodeEscaped();
/*      */ 
/* 1029 */     if ((unescaped <= ' ') && 
/* 1030 */       (index == 0)) {
/* 1031 */       return -1;
/*      */     }
/*      */ 
/* 1035 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1036 */     if (bits < 0) {
/* 1037 */       throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */     }
/* 1039 */     return bits;
/*      */   }
/*      */ 
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1045 */     return reportInvalidBase64Char(b64variant, ch, bindex, null);
/*      */   }
/*      */ 
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex, String msg)
/*      */     throws IllegalArgumentException
/*      */   {
/*      */     String base;
/*      */     String base;
/* 1056 */     if (ch <= 32) {
/* 1057 */       base = "Illegal white space character (code 0x" + Integer.toHexString(ch) + ") as character #" + (bindex + 1) + " of 4-char base64 unit: can only used between units";
/*      */     }
/*      */     else
/*      */     {
/*      */       String base;
/* 1058 */       if (b64variant.usesPaddingChar(ch)) {
/* 1059 */         base = "Unexpected padding character ('" + b64variant.getPaddingChar() + "') as character #" + (bindex + 1) + " of 4-char base64 unit: padding only legal as 3rd or 4th character";
/*      */       }
/*      */       else
/*      */       {
/*      */         String base;
/* 1060 */         if ((!Character.isDefined(ch)) || (Character.isISOControl(ch)))
/*      */         {
/* 1062 */           base = "Illegal character (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */         }
/* 1064 */         else base = "Illegal character '" + (char)ch + "' (code 0x" + Integer.toHexString(ch) + ") in base64 content"; 
/*      */       }
/*      */     }
/* 1066 */     if (msg != null) {
/* 1067 */       base = base + ": " + msg;
/*      */     }
/* 1069 */     return new IllegalArgumentException(base);
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.impl.JsonParserBase
 * JD-Core Version:    0.6.2
 */