/*      */ package org.codehaus.jackson.impl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import org.codehaus.jackson.Base64Variant;
/*      */ import org.codehaus.jackson.JsonParseException;
/*      */ import org.codehaus.jackson.JsonParser.Feature;
/*      */ import org.codehaus.jackson.JsonToken;
/*      */ import org.codehaus.jackson.ObjectCodec;
/*      */ import org.codehaus.jackson.io.IOContext;
/*      */ import org.codehaus.jackson.sym.CharsToNameCanonicalizer;
/*      */ import org.codehaus.jackson.util.ByteArrayBuilder;
/*      */ import org.codehaus.jackson.util.CharTypes;
/*      */ import org.codehaus.jackson.util.TextBuffer;
/*      */ 
/*      */ public final class ReaderBasedParser extends JsonParserBase
/*      */ {
/*      */   protected Reader _reader;
/*      */   protected char[] _inputBuffer;
/*      */   protected ObjectCodec _objectCodec;
/*      */   protected final CharsToNameCanonicalizer _symbols;
/*   58 */   protected boolean _tokenIncomplete = false;
/*      */ 
/*      */   public ReaderBasedParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st)
/*      */   {
/*   69 */     super(ctxt, features);
/*   70 */     this._reader = r;
/*   71 */     this._inputBuffer = ctxt.allocTokenBuffer();
/*   72 */     this._objectCodec = codec;
/*   73 */     this._symbols = st;
/*      */   }
/*      */ 
/*      */   public ObjectCodec getCodec()
/*      */   {
/*   84 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   public void setCodec(ObjectCodec c)
/*      */   {
/*   89 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */   public int releaseBuffered(Writer w)
/*      */     throws IOException
/*      */   {
/*   95 */     int count = this._inputEnd - this._inputPtr;
/*   96 */     if (count < 1) {
/*   97 */       return 0;
/*      */     }
/*      */ 
/*  100 */     int origPtr = this._inputPtr;
/*  101 */     w.write(this._inputBuffer, origPtr, count);
/*  102 */     return count;
/*      */   }
/*      */ 
/*      */   public Object getInputSource()
/*      */   {
/*  107 */     return this._reader;
/*      */   }
/*      */ 
/*      */   protected final boolean loadMore()
/*      */     throws IOException
/*      */   {
/*  113 */     this._currInputProcessed += this._inputEnd;
/*  114 */     this._currInputRowStart -= this._inputEnd;
/*      */ 
/*  116 */     if (this._reader != null) {
/*  117 */       int count = this._reader.read(this._inputBuffer, 0, this._inputBuffer.length);
/*  118 */       if (count > 0) {
/*  119 */         this._inputPtr = 0;
/*  120 */         this._inputEnd = count;
/*  121 */         return true;
/*      */       }
/*      */ 
/*  124 */       _closeInput();
/*      */ 
/*  126 */       if (count == 0) {
/*  127 */         throw new IOException("Reader returned 0 characters when trying to read " + this._inputEnd);
/*      */       }
/*      */     }
/*  130 */     return false;
/*      */   }
/*      */ 
/*      */   protected char getNextChar(String eofMsg)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  136 */     if ((this._inputPtr >= this._inputEnd) && 
/*  137 */       (!loadMore())) {
/*  138 */       _reportInvalidEOF(eofMsg);
/*      */     }
/*      */ 
/*  141 */     return this._inputBuffer[(this._inputPtr++)];
/*      */   }
/*      */ 
/*      */   protected void _closeInput()
/*      */     throws IOException
/*      */   {
/*  154 */     if (this._reader != null) {
/*  155 */       if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE))) {
/*  156 */         this._reader.close();
/*      */       }
/*  158 */       this._reader = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */     throws IOException
/*      */   {
/*  172 */     super._releaseBuffers();
/*  173 */     char[] buf = this._inputBuffer;
/*  174 */     if (buf != null) {
/*  175 */       this._inputBuffer = null;
/*  176 */       this._ioContext.releaseTokenBuffer(buf);
/*      */     }
/*      */   }
/*      */ 
/*      */   public final String getText()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  196 */     JsonToken t = this._currToken;
/*  197 */     if (t == JsonToken.VALUE_STRING) {
/*  198 */       if (this._tokenIncomplete) {
/*  199 */         this._tokenIncomplete = false;
/*  200 */         _finishString();
/*      */       }
/*  202 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  204 */     return _getText2(t);
/*      */   }
/*      */ 
/*      */   protected final String _getText2(JsonToken t)
/*      */   {
/*  209 */     if (t == null) {
/*  210 */       return null;
/*      */     }
/*  212 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[t.ordinal()]) {
/*      */     case 1:
/*  214 */       return this._parsingContext.getCurrentName();
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*  220 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  222 */     return t.asString();
/*      */   }
/*      */ 
/*      */   public char[] getTextCharacters()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  229 */     if (this._currToken != null) {
/*  230 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[this._currToken.ordinal()])
/*      */       {
/*      */       case 1:
/*  233 */         if (!this._nameCopied) {
/*  234 */           String name = this._parsingContext.getCurrentName();
/*  235 */           int nameLen = name.length();
/*  236 */           if (this._nameCopyBuffer == null)
/*  237 */             this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  238 */           else if (this._nameCopyBuffer.length < nameLen) {
/*  239 */             this._nameCopyBuffer = new char[nameLen];
/*      */           }
/*  241 */           name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  242 */           this._nameCopied = true;
/*      */         }
/*  244 */         return this._nameCopyBuffer;
/*      */       case 2:
/*  247 */         if (this._tokenIncomplete) {
/*  248 */           this._tokenIncomplete = false;
/*  249 */           _finishString();
/*      */         }
/*      */ 
/*      */       case 3:
/*      */       case 4:
/*  254 */         return this._textBuffer.getTextBuffer();
/*      */       }
/*      */ 
/*  257 */       return this._currToken.asCharArray();
/*      */     }
/*      */ 
/*  260 */     return null;
/*      */   }
/*      */ 
/*      */   public int getTextLength()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  267 */     if (this._currToken != null) {
/*  268 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[this._currToken.ordinal()])
/*      */       {
/*      */       case 1:
/*  271 */         return this._parsingContext.getCurrentName().length();
/*      */       case 2:
/*  273 */         if (this._tokenIncomplete) {
/*  274 */           this._tokenIncomplete = false;
/*  275 */           _finishString();
/*      */         }
/*      */ 
/*      */       case 3:
/*      */       case 4:
/*  280 */         return this._textBuffer.size();
/*      */       }
/*      */ 
/*  283 */       return this._currToken.asCharArray().length;
/*      */     }
/*      */ 
/*  286 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getTextOffset()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  293 */     if (this._currToken != null) {
/*  294 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[this._currToken.ordinal()]) {
/*      */       case 1:
/*  296 */         return 0;
/*      */       case 2:
/*  298 */         if (this._tokenIncomplete) {
/*  299 */           this._tokenIncomplete = false;
/*  300 */           _finishString();
/*      */         }
/*      */ 
/*      */       case 3:
/*      */       case 4:
/*  305 */         return this._textBuffer.getTextOffset();
/*      */       }
/*      */     }
/*  308 */     return 0;
/*      */   }
/*      */ 
/*      */   public byte[] getBinaryValue(Base64Variant b64variant)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  315 */     if ((this._currToken != JsonToken.VALUE_STRING) && ((this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT) || (this._binaryValue == null)))
/*      */     {
/*  317 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */ 
/*  322 */     if (this._tokenIncomplete) {
/*      */       try {
/*  324 */         this._binaryValue = _decodeBase64(b64variant);
/*      */       } catch (IllegalArgumentException iae) {
/*  326 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       }
/*      */ 
/*  331 */       this._tokenIncomplete = false;
/*      */     }
/*  333 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */   public JsonToken nextToken()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  350 */     this._numTypesValid = 0;
/*      */ 
/*  356 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  357 */       return _nextAfterName();
/*      */     }
/*  359 */     if (this._tokenIncomplete) {
/*  360 */       _skipString();
/*      */     }
/*  362 */     int i = _skipWSOrEnd();
/*  363 */     if (i < 0)
/*      */     {
/*  367 */       close();
/*  368 */       return this._currToken = null;
/*      */     }
/*      */ 
/*  374 */     this._tokenInputTotal = (this._currInputProcessed + this._inputPtr - 1L);
/*  375 */     this._tokenInputRow = this._currInputRow;
/*  376 */     this._tokenInputCol = (this._inputPtr - this._currInputRowStart - 1);
/*      */ 
/*  379 */     this._binaryValue = null;
/*      */ 
/*  382 */     if (i == 93) {
/*  383 */       if (!this._parsingContext.inArray()) {
/*  384 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/*  386 */       this._parsingContext = this._parsingContext.getParent();
/*  387 */       return this._currToken = JsonToken.END_ARRAY;
/*      */     }
/*  389 */     if (i == 125) {
/*  390 */       if (!this._parsingContext.inObject()) {
/*  391 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/*  393 */       this._parsingContext = this._parsingContext.getParent();
/*  394 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     }
/*      */ 
/*  398 */     if (this._parsingContext.expectComma()) {
/*  399 */       if (i != 44) {
/*  400 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.getTypeDesc() + " entries");
/*      */       }
/*  402 */       i = _skipWS();
/*      */     }
/*      */ 
/*  409 */     boolean inObject = this._parsingContext.inObject();
/*  410 */     if (inObject)
/*      */     {
/*  412 */       String name = _parseFieldName(i);
/*  413 */       this._parsingContext.setCurrentName(name);
/*  414 */       this._currToken = JsonToken.FIELD_NAME;
/*  415 */       i = _skipWS();
/*  416 */       if (i != 58) {
/*  417 */         _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */       }
/*  419 */       i = _skipWS();
/*      */     }
/*      */     JsonToken t;
/*  426 */     switch (i) {
/*      */     case 34:
/*  428 */       this._tokenIncomplete = true;
/*  429 */       t = JsonToken.VALUE_STRING;
/*  430 */       break;
/*      */     case 91:
/*  432 */       if (!inObject) {
/*  433 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  435 */       t = JsonToken.START_ARRAY;
/*  436 */       break;
/*      */     case 123:
/*  438 */       if (!inObject) {
/*  439 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  441 */       t = JsonToken.START_OBJECT;
/*  442 */       break;
/*      */     case 93:
/*      */     case 125:
/*  447 */       _reportUnexpectedChar(i, "expected a value");
/*      */     case 116:
/*  449 */       _matchToken("true", 1);
/*  450 */       t = JsonToken.VALUE_TRUE;
/*  451 */       break;
/*      */     case 102:
/*  453 */       _matchToken("false", 1);
/*  454 */       t = JsonToken.VALUE_FALSE;
/*  455 */       break;
/*      */     case 110:
/*  457 */       _matchToken("null", 1);
/*  458 */       t = JsonToken.VALUE_NULL;
/*  459 */       break;
/*      */     case 45:
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 56:
/*      */     case 57:
/*  476 */       t = parseNumberText(i);
/*  477 */       break;
/*      */     default:
/*  479 */       t = _handleUnexpectedValue(i);
/*      */     }
/*      */ 
/*  483 */     if (inObject) {
/*  484 */       this._nextToken = t;
/*  485 */       return this._currToken;
/*      */     }
/*  487 */     this._currToken = t;
/*  488 */     return t;
/*      */   }
/*      */ 
/*      */   private final JsonToken _nextAfterName()
/*      */   {
/*  493 */     this._nameCopied = false;
/*  494 */     JsonToken t = this._nextToken;
/*  495 */     this._nextToken = null;
/*      */ 
/*  497 */     if (t == JsonToken.START_ARRAY)
/*  498 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  499 */     else if (t == JsonToken.START_OBJECT) {
/*  500 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     }
/*  502 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   public String nextTextValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  516 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  517 */       this._nameCopied = false;
/*  518 */       JsonToken t = this._nextToken;
/*  519 */       this._nextToken = null;
/*  520 */       this._currToken = t;
/*  521 */       if (t == JsonToken.VALUE_STRING) {
/*  522 */         if (this._tokenIncomplete) {
/*  523 */           this._tokenIncomplete = false;
/*  524 */           _finishString();
/*      */         }
/*  526 */         return this._textBuffer.contentsAsString();
/*      */       }
/*  528 */       if (t == JsonToken.START_ARRAY)
/*  529 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  530 */       else if (t == JsonToken.START_OBJECT) {
/*  531 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  533 */       return null;
/*      */     }
/*      */ 
/*  536 */     return nextToken() == JsonToken.VALUE_STRING ? getText() : null;
/*      */   }
/*      */ 
/*      */   public int nextIntValue(int defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  544 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  545 */       this._nameCopied = false;
/*  546 */       JsonToken t = this._nextToken;
/*  547 */       this._nextToken = null;
/*  548 */       this._currToken = t;
/*  549 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  550 */         return getIntValue();
/*      */       }
/*  552 */       if (t == JsonToken.START_ARRAY)
/*  553 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  554 */       else if (t == JsonToken.START_OBJECT) {
/*  555 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  557 */       return defaultValue;
/*      */     }
/*      */ 
/*  560 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */   public long nextLongValue(long defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  568 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  569 */       this._nameCopied = false;
/*  570 */       JsonToken t = this._nextToken;
/*  571 */       this._nextToken = null;
/*  572 */       this._currToken = t;
/*  573 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  574 */         return getLongValue();
/*      */       }
/*  576 */       if (t == JsonToken.START_ARRAY)
/*  577 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  578 */       else if (t == JsonToken.START_OBJECT) {
/*  579 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  581 */       return defaultValue;
/*      */     }
/*      */ 
/*  584 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */   public Boolean nextBooleanValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  592 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  593 */       this._nameCopied = false;
/*  594 */       JsonToken t = this._nextToken;
/*  595 */       this._nextToken = null;
/*  596 */       this._currToken = t;
/*  597 */       if (t == JsonToken.VALUE_TRUE) {
/*  598 */         return Boolean.TRUE;
/*      */       }
/*  600 */       if (t == JsonToken.VALUE_FALSE) {
/*  601 */         return Boolean.FALSE;
/*      */       }
/*  603 */       if (t == JsonToken.START_ARRAY)
/*  604 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  605 */       else if (t == JsonToken.START_OBJECT) {
/*  606 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  608 */       return null;
/*      */     }
/*  610 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[nextToken().ordinal()]) {
/*      */     case 5:
/*  612 */       return Boolean.TRUE;
/*      */     case 6:
/*  614 */       return Boolean.FALSE;
/*      */     }
/*  616 */     return null;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  622 */     super.close();
/*  623 */     this._symbols.release();
/*      */   }
/*      */ 
/*      */   protected final JsonToken parseNumberText(int ch)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  656 */     boolean negative = ch == 45;
/*  657 */     int ptr = this._inputPtr;
/*  658 */     int startPtr = ptr - 1;
/*  659 */     int inputLen = this._inputEnd;
/*      */ 
/*  663 */     if (negative) {
/*  664 */       if (ptr >= this._inputEnd) {
/*      */         break label347;
/*      */       }
/*  667 */       ch = this._inputBuffer[(ptr++)];
/*      */ 
/*  669 */       if ((ch > 57) || (ch < 48)) {
/*  670 */         this._inputPtr = ptr;
/*  671 */         return _handleInvalidNumberStart(ch, true);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  679 */     if (ch != 48)
/*      */     {
/*  689 */       int intLen = 1;
/*      */ 
/*  695 */       while (ptr < this._inputEnd)
/*      */       {
/*  698 */         ch = this._inputBuffer[(ptr++)];
/*  699 */         if ((ch >= 48) && (ch <= 57))
/*      */         {
/*  702 */           intLen++;
/*      */         }
/*      */         else {
/*  705 */           int fractLen = 0;
/*      */ 
/*  708 */           if (ch == 46)
/*      */           {
/*      */             while (true) {
/*  711 */               if (ptr >= inputLen) {
/*      */                 break label347;
/*      */               }
/*  714 */               ch = this._inputBuffer[(ptr++)];
/*  715 */               if ((ch < 48) || (ch > 57)) {
/*      */                 break;
/*      */               }
/*  718 */               fractLen++;
/*      */             }
/*      */ 
/*  721 */             if (fractLen == 0) {
/*  722 */               reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */             }
/*      */           }
/*      */ 
/*  726 */           int expLen = 0;
/*  727 */           if ((ch == 101) || (ch == 69)) {
/*  728 */             if (ptr >= inputLen)
/*      */             {
/*      */               break;
/*      */             }
/*  732 */             ch = this._inputBuffer[(ptr++)];
/*  733 */             if ((ch == 45) || (ch == 43)) {
/*  734 */               if (ptr >= inputLen) {
/*      */                 break;
/*      */               }
/*  737 */               ch = this._inputBuffer[(ptr++)];
/*      */             }
/*  739 */             while ((ch <= 57) && (ch >= 48)) {
/*  740 */               expLen++;
/*  741 */               if (ptr >= inputLen) {
/*      */                 break label347;
/*      */               }
/*  744 */               ch = this._inputBuffer[(ptr++)];
/*      */             }
/*      */ 
/*  747 */             if (expLen == 0) {
/*  748 */               reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  753 */           ptr--;
/*  754 */           this._inputPtr = ptr;
/*  755 */           int len = ptr - startPtr;
/*  756 */           this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/*  757 */           return reset(negative, intLen, fractLen, expLen);
/*      */         }
/*      */       }
/*      */     }
/*  760 */     label347: this._inputPtr = (negative ? startPtr + 1 : startPtr);
/*  761 */     return parseNumberText2(negative);
/*      */   }
/*      */ 
/*      */   private final JsonToken parseNumberText2(boolean negative)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  774 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*  775 */     int outPtr = 0;
/*      */ 
/*  778 */     if (negative) {
/*  779 */       outBuf[(outPtr++)] = '-';
/*      */     }
/*      */ 
/*  783 */     int intLen = 0;
/*  784 */     char c = this._inputPtr < this._inputEnd ? this._inputBuffer[(this._inputPtr++)] : getNextChar("No digit following minus sign");
/*  785 */     if (c == '0') {
/*  786 */       c = _verifyNoLeadingZeroes();
/*      */     }
/*  788 */     boolean eof = false;
/*      */ 
/*  792 */     while ((c >= '0') && (c <= '9')) {
/*  793 */       intLen++;
/*  794 */       if (outPtr >= outBuf.length) {
/*  795 */         outBuf = this._textBuffer.finishCurrentSegment();
/*  796 */         outPtr = 0;
/*      */       }
/*  798 */       outBuf[(outPtr++)] = c;
/*  799 */       if ((this._inputPtr >= this._inputEnd) && (!loadMore()))
/*      */       {
/*  801 */         c = '\000';
/*  802 */         eof = true;
/*  803 */         break;
/*      */       }
/*  805 */       c = this._inputBuffer[(this._inputPtr++)];
/*      */     }
/*      */ 
/*  808 */     if (intLen == 0) {
/*  809 */       reportInvalidNumber("Missing integer part (next char " + _getCharDesc(c) + ")");
/*      */     }
/*      */ 
/*  812 */     int fractLen = 0;
/*      */ 
/*  814 */     if (c == '.') {
/*  815 */       outBuf[(outPtr++)] = c;
/*      */       while (true)
/*      */       {
/*  819 */         if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/*  820 */           eof = true;
/*  821 */           break;
/*      */         }
/*  823 */         c = this._inputBuffer[(this._inputPtr++)];
/*  824 */         if ((c < '0') || (c > '9')) {
/*      */           break;
/*      */         }
/*  827 */         fractLen++;
/*  828 */         if (outPtr >= outBuf.length) {
/*  829 */           outBuf = this._textBuffer.finishCurrentSegment();
/*  830 */           outPtr = 0;
/*      */         }
/*  832 */         outBuf[(outPtr++)] = c;
/*      */       }
/*      */ 
/*  835 */       if (fractLen == 0) {
/*  836 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     }
/*      */ 
/*  840 */     int expLen = 0;
/*  841 */     if ((c == 'e') || (c == 'E')) {
/*  842 */       if (outPtr >= outBuf.length) {
/*  843 */         outBuf = this._textBuffer.finishCurrentSegment();
/*  844 */         outPtr = 0;
/*      */       }
/*  846 */       outBuf[(outPtr++)] = c;
/*      */ 
/*  848 */       c = this._inputPtr < this._inputEnd ? this._inputBuffer[(this._inputPtr++)] : getNextChar("expected a digit for number exponent");
/*      */ 
/*  851 */       if ((c == '-') || (c == '+')) {
/*  852 */         if (outPtr >= outBuf.length) {
/*  853 */           outBuf = this._textBuffer.finishCurrentSegment();
/*  854 */           outPtr = 0;
/*      */         }
/*  856 */         outBuf[(outPtr++)] = c;
/*      */ 
/*  858 */         c = this._inputPtr < this._inputEnd ? this._inputBuffer[(this._inputPtr++)] : getNextChar("expected a digit for number exponent");
/*      */       }
/*      */ 
/*  863 */       while ((c <= '9') && (c >= '0')) {
/*  864 */         expLen++;
/*  865 */         if (outPtr >= outBuf.length) {
/*  866 */           outBuf = this._textBuffer.finishCurrentSegment();
/*  867 */           outPtr = 0;
/*      */         }
/*  869 */         outBuf[(outPtr++)] = c;
/*  870 */         if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/*  871 */           eof = true;
/*  872 */           break;
/*      */         }
/*  874 */         c = this._inputBuffer[(this._inputPtr++)];
/*      */       }
/*      */ 
/*  877 */       if (expLen == 0) {
/*  878 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  883 */     if (!eof) {
/*  884 */       this._inputPtr -= 1;
/*      */     }
/*  886 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*  888 */     return reset(negative, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */   private final char _verifyNoLeadingZeroes()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  899 */     if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/*  900 */       return '0';
/*      */     }
/*  902 */     char ch = this._inputBuffer[this._inputPtr];
/*      */ 
/*  904 */     if ((ch < '0') || (ch > '9')) {
/*  905 */       return '0';
/*      */     }
/*  907 */     if (!isEnabled(JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS)) {
/*  908 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */ 
/*  911 */     this._inputPtr += 1;
/*  912 */     if (ch == '0') {
/*  913 */       while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/*  914 */         ch = this._inputBuffer[this._inputPtr];
/*  915 */         if ((ch < '0') || (ch > '9')) {
/*  916 */           return '0';
/*      */         }
/*  918 */         this._inputPtr += 1;
/*  919 */         if (ch != '0') {
/*  920 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  924 */     return ch;
/*      */   }
/*      */ 
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean negative)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  934 */     if (ch == 73) {
/*  935 */       if ((this._inputPtr >= this._inputEnd) && 
/*  936 */         (!loadMore())) {
/*  937 */         _reportInvalidEOFInValue();
/*      */       }
/*      */ 
/*  940 */       ch = this._inputBuffer[(this._inputPtr++)];
/*  941 */       if (ch == 78) {
/*  942 */         String match = negative ? "-INF" : "+INF";
/*  943 */         _matchToken(match, 3);
/*  944 */         if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/*  945 */           return resetAsNaN(match, negative ? (-1.0D / 0.0D) : (1.0D / 0.0D));
/*      */         }
/*  947 */         _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*  948 */       } else if (ch == 110) {
/*  949 */         String match = negative ? "-Infinity" : "+Infinity";
/*  950 */         _matchToken(match, 3);
/*  951 */         if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/*  952 */           return resetAsNaN(match, negative ? (-1.0D / 0.0D) : (1.0D / 0.0D));
/*      */         }
/*  954 */         _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */       }
/*      */     }
/*  957 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/*  958 */     return null;
/*      */   }
/*      */ 
/*      */   protected final String _parseFieldName(int i)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  970 */     if (i != 34) {
/*  971 */       return _handleUnusualFieldName(i);
/*      */     }
/*      */ 
/*  977 */     int ptr = this._inputPtr;
/*  978 */     int hash = 0;
/*  979 */     int inputLen = this._inputEnd;
/*      */ 
/*  981 */     if (ptr < inputLen) {
/*  982 */       int[] codes = CharTypes.getInputCodeLatin1();
/*  983 */       int maxCode = codes.length;
/*      */       do
/*      */       {
/*  986 */         int ch = this._inputBuffer[ptr];
/*  987 */         if ((ch < maxCode) && (codes[ch] != 0)) {
/*  988 */           if (ch != 34) break;
/*  989 */           int start = this._inputPtr;
/*  990 */           this._inputPtr = (ptr + 1);
/*  991 */           return this._symbols.findSymbol(this._inputBuffer, start, ptr - start, hash);
/*      */         }
/*      */ 
/*  995 */         hash = hash * 31 + ch;
/*  996 */         ptr++;
/*  997 */       }while (ptr < inputLen);
/*      */     }
/*      */ 
/* 1000 */     int start = this._inputPtr;
/* 1001 */     this._inputPtr = ptr;
/* 1002 */     return _parseFieldName2(start, hash, 34);
/*      */   }
/*      */ 
/*      */   private String _parseFieldName2(int startPtr, int hash, int endChar)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1008 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/*      */ 
/* 1013 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 1014 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     while (true)
/*      */     {
/* 1017 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1018 */         (!loadMore())) {
/* 1019 */         _reportInvalidEOF(": was expecting closing '" + (char)endChar + "' for name");
/*      */       }
/*      */ 
/* 1022 */       char c = this._inputBuffer[(this._inputPtr++)];
/* 1023 */       int i = c;
/* 1024 */       if (i <= 92) {
/* 1025 */         if (i == 92)
/*      */         {
/* 1030 */           c = _decodeEscaped();
/* 1031 */         } else if (i <= endChar) {
/* 1032 */           if (i == endChar) {
/*      */             break;
/*      */           }
/* 1035 */           if (i < 32) {
/* 1036 */             _throwUnquotedSpace(i, "name");
/*      */           }
/*      */         }
/*      */       }
/* 1040 */       hash = hash * 31 + i;
/*      */ 
/* 1042 */       outBuf[(outPtr++)] = c;
/*      */ 
/* 1045 */       if (outPtr >= outBuf.length) {
/* 1046 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1047 */         outPtr = 0;
/*      */       }
/*      */     }
/* 1050 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/* 1052 */     TextBuffer tb = this._textBuffer;
/* 1053 */     char[] buf = tb.getTextBuffer();
/* 1054 */     int start = tb.getTextOffset();
/* 1055 */     int len = tb.size();
/*      */ 
/* 1057 */     return this._symbols.findSymbol(buf, start, len, hash);
/*      */   }
/*      */ 
/*      */   protected final String _handleUnusualFieldName(int i)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1073 */     if ((i == 39) && (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES))) {
/* 1074 */       return _parseApostropheFieldName();
/*      */     }
/*      */ 
/* 1077 */     if (!isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES)) {
/* 1078 */       _reportUnexpectedChar(i, "was expecting double-quote to start field name");
/*      */     }
/* 1080 */     int[] codes = CharTypes.getInputCodeLatin1JsNames();
/* 1081 */     int maxCode = codes.length;
/*      */     boolean firstOk;
/*      */     boolean firstOk;
/* 1086 */     if (i < maxCode)
/* 1087 */       firstOk = (codes[i] == 0) && ((i < 48) || (i > 57));
/*      */     else {
/* 1089 */       firstOk = Character.isJavaIdentifierPart((char)i);
/*      */     }
/* 1091 */     if (!firstOk) {
/* 1092 */       _reportUnexpectedChar(i, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/* 1094 */     int ptr = this._inputPtr;
/* 1095 */     int hash = 0;
/* 1096 */     int inputLen = this._inputEnd;
/*      */ 
/* 1098 */     if (ptr < inputLen) {
/*      */       do {
/* 1100 */         int ch = this._inputBuffer[ptr];
/* 1101 */         if (ch < maxCode) {
/* 1102 */           if (codes[ch] != 0) {
/* 1103 */             int start = this._inputPtr - 1;
/* 1104 */             this._inputPtr = ptr;
/* 1105 */             return this._symbols.findSymbol(this._inputBuffer, start, ptr - start, hash);
/*      */           }
/* 1107 */         } else if (!Character.isJavaIdentifierPart((char)ch)) {
/* 1108 */           int start = this._inputPtr - 1;
/* 1109 */           this._inputPtr = ptr;
/* 1110 */           return this._symbols.findSymbol(this._inputBuffer, start, ptr - start, hash);
/*      */         }
/* 1112 */         hash = hash * 31 + ch;
/* 1113 */         ptr++;
/* 1114 */       }while (ptr < inputLen);
/*      */     }
/* 1116 */     int start = this._inputPtr - 1;
/* 1117 */     this._inputPtr = ptr;
/* 1118 */     return _parseUnusualFieldName2(start, hash, codes);
/*      */   }
/*      */ 
/*      */   protected final String _parseApostropheFieldName()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1125 */     int ptr = this._inputPtr;
/* 1126 */     int hash = 0;
/* 1127 */     int inputLen = this._inputEnd;
/*      */ 
/* 1129 */     if (ptr < inputLen) {
/* 1130 */       int[] codes = CharTypes.getInputCodeLatin1();
/* 1131 */       int maxCode = codes.length;
/*      */       do
/*      */       {
/* 1134 */         int ch = this._inputBuffer[ptr];
/* 1135 */         if (ch == 39) {
/* 1136 */           int start = this._inputPtr;
/* 1137 */           this._inputPtr = (ptr + 1);
/* 1138 */           return this._symbols.findSymbol(this._inputBuffer, start, ptr - start, hash);
/*      */         }
/* 1140 */         if ((ch < maxCode) && (codes[ch] != 0)) {
/*      */           break;
/*      */         }
/* 1143 */         hash = hash * 31 + ch;
/* 1144 */         ptr++;
/* 1145 */       }while (ptr < inputLen);
/*      */     }
/*      */ 
/* 1148 */     int start = this._inputPtr;
/* 1149 */     this._inputPtr = ptr;
/*      */ 
/* 1151 */     return _parseFieldName2(start, hash, 39);
/*      */   }
/*      */ 
/*      */   protected final JsonToken _handleUnexpectedValue(int i)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1164 */     switch (i)
/*      */     {
/*      */     case 39:
/* 1173 */       if (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 1174 */         return _handleApostropheValue();
/*      */       }
/*      */       break;
/*      */     case 78:
/* 1178 */       _matchToken("NaN", 1);
/* 1179 */       if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 1180 */         return resetAsNaN("NaN", (0.0D / 0.0D));
/*      */       }
/* 1182 */       _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 1183 */       break;
/*      */     case 43:
/* 1185 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1186 */         (!loadMore())) {
/* 1187 */         _reportInvalidEOFInValue();
/*      */       }
/*      */ 
/* 1190 */       return _handleInvalidNumberStart(this._inputBuffer[(this._inputPtr++)], false);
/*      */     }
/* 1192 */     _reportUnexpectedChar(i, "expected a valid value (number, String, array, object, 'true', 'false' or 'null')");
/* 1193 */     return null;
/*      */   }
/*      */ 
/*      */   protected final JsonToken _handleApostropheValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1202 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1203 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     while (true)
/*      */     {
/* 1206 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1207 */         (!loadMore())) {
/* 1208 */         _reportInvalidEOF(": was expecting closing quote for a string value");
/*      */       }
/*      */ 
/* 1211 */       char c = this._inputBuffer[(this._inputPtr++)];
/* 1212 */       int i = c;
/* 1213 */       if (i <= 92) {
/* 1214 */         if (i == 92)
/*      */         {
/* 1219 */           c = _decodeEscaped();
/* 1220 */         } else if (i <= 39) {
/* 1221 */           if (i == 39) {
/*      */             break;
/*      */           }
/* 1224 */           if (i < 32) {
/* 1225 */             _throwUnquotedSpace(i, "string value");
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1230 */       if (outPtr >= outBuf.length) {
/* 1231 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1232 */         outPtr = 0;
/*      */       }
/*      */ 
/* 1235 */       outBuf[(outPtr++)] = c;
/*      */     }
/* 1237 */     this._textBuffer.setCurrentLength(outPtr);
/* 1238 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */   private String _parseUnusualFieldName2(int startPtr, int hash, int[] codes)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1247 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/* 1248 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 1249 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 1250 */     int maxCode = codes.length;
/*      */ 
/* 1253 */     while ((this._inputPtr < this._inputEnd) || 
/* 1254 */       (loadMore()))
/*      */     {
/* 1258 */       char c = this._inputBuffer[this._inputPtr];
/* 1259 */       int i = c;
/* 1260 */       if (i <= maxCode ? 
/* 1261 */         codes[i] != 0 : 
/* 1264 */         !Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 1267 */       this._inputPtr += 1;
/* 1268 */       hash = hash * 31 + i;
/*      */ 
/* 1270 */       outBuf[(outPtr++)] = c;
/*      */ 
/* 1273 */       if (outPtr >= outBuf.length) {
/* 1274 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1275 */         outPtr = 0;
/*      */       }
/*      */     }
/* 1278 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/* 1280 */     TextBuffer tb = this._textBuffer;
/* 1281 */     char[] buf = tb.getTextBuffer();
/* 1282 */     int start = tb.getTextOffset();
/* 1283 */     int len = tb.size();
/*      */ 
/* 1285 */     return this._symbols.findSymbol(buf, start, len, hash);
/*      */   }
/*      */ 
/*      */   protected void _finishString()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1297 */     int ptr = this._inputPtr;
/* 1298 */     int inputLen = this._inputEnd;
/*      */ 
/* 1300 */     if (ptr < inputLen) {
/* 1301 */       int[] codes = CharTypes.getInputCodeLatin1();
/* 1302 */       int maxCode = codes.length;
/*      */       do
/*      */       {
/* 1305 */         int ch = this._inputBuffer[ptr];
/* 1306 */         if ((ch < maxCode) && (codes[ch] != 0)) {
/* 1307 */           if (ch != 34) break;
/* 1308 */           this._textBuffer.resetWithShared(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 1309 */           this._inputPtr = (ptr + 1);
/*      */ 
/* 1311 */           return;
/*      */         }
/*      */ 
/* 1315 */         ptr++;
/* 1316 */       }while (ptr < inputLen);
/*      */     }
/*      */ 
/* 1322 */     this._textBuffer.resetWithCopy(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 1323 */     this._inputPtr = ptr;
/* 1324 */     _finishString2();
/*      */   }
/*      */ 
/*      */   protected void _finishString2()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1330 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 1331 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     while (true)
/*      */     {
/* 1334 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1335 */         (!loadMore())) {
/* 1336 */         _reportInvalidEOF(": was expecting closing quote for a string value");
/*      */       }
/*      */ 
/* 1339 */       char c = this._inputBuffer[(this._inputPtr++)];
/* 1340 */       int i = c;
/* 1341 */       if (i <= 92) {
/* 1342 */         if (i == 92)
/*      */         {
/* 1347 */           c = _decodeEscaped();
/* 1348 */         } else if (i <= 34) {
/* 1349 */           if (i == 34) {
/*      */             break;
/*      */           }
/* 1352 */           if (i < 32) {
/* 1353 */             _throwUnquotedSpace(i, "string value");
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1358 */       if (outPtr >= outBuf.length) {
/* 1359 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1360 */         outPtr = 0;
/*      */       }
/*      */ 
/* 1363 */       outBuf[(outPtr++)] = c;
/*      */     }
/* 1365 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */   protected void _skipString()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1376 */     this._tokenIncomplete = false;
/*      */ 
/* 1378 */     int inputPtr = this._inputPtr;
/* 1379 */     int inputLen = this._inputEnd;
/* 1380 */     char[] inputBuffer = this._inputBuffer;
/*      */     while (true)
/*      */     {
/* 1383 */       if (inputPtr >= inputLen) {
/* 1384 */         this._inputPtr = inputPtr;
/* 1385 */         if (!loadMore()) {
/* 1386 */           _reportInvalidEOF(": was expecting closing quote for a string value");
/*      */         }
/* 1388 */         inputPtr = this._inputPtr;
/* 1389 */         inputLen = this._inputEnd;
/*      */       }
/* 1391 */       char c = inputBuffer[(inputPtr++)];
/* 1392 */       int i = c;
/* 1393 */       if (i <= 92)
/* 1394 */         if (i == 92)
/*      */         {
/* 1399 */           this._inputPtr = inputPtr;
/* 1400 */           c = _decodeEscaped();
/* 1401 */           inputPtr = this._inputPtr;
/* 1402 */           inputLen = this._inputEnd;
/* 1403 */         } else if (i <= 34) {
/* 1404 */           if (i == 34) {
/* 1405 */             this._inputPtr = inputPtr;
/* 1406 */             break;
/*      */           }
/* 1408 */           if (i < 32) {
/* 1409 */             this._inputPtr = inputPtr;
/* 1410 */             _throwUnquotedSpace(i, "string value");
/*      */           }
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void _skipCR()
/*      */     throws IOException
/*      */   {
/* 1429 */     if (((this._inputPtr < this._inputEnd) || (loadMore())) && 
/* 1430 */       (this._inputBuffer[this._inputPtr] == '\n')) {
/* 1431 */       this._inputPtr += 1;
/*      */     }
/*      */ 
/* 1434 */     this._currInputRow += 1;
/* 1435 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   protected final void _skipLF() throws IOException
/*      */   {
/* 1440 */     this._currInputRow += 1;
/* 1441 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   private final int _skipWS()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1447 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 1448 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 1449 */       if (i > 32) {
/* 1450 */         if (i != 47) {
/* 1451 */           return i;
/*      */         }
/* 1453 */         _skipComment();
/* 1454 */       } else if (i != 32) {
/* 1455 */         if (i == 10)
/* 1456 */           _skipLF();
/* 1457 */         else if (i == 13)
/* 1458 */           _skipCR();
/* 1459 */         else if (i != 9) {
/* 1460 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 1464 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.getTypeDesc() + " entries");
/*      */   }
/*      */ 
/*      */   private final int _skipWSOrEnd()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1470 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 1471 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 1472 */       if (i > 32) {
/* 1473 */         if (i == 47) {
/* 1474 */           _skipComment();
/*      */         }
/*      */         else
/* 1477 */           return i;
/*      */       }
/* 1479 */       else if (i != 32) {
/* 1480 */         if (i == 10)
/* 1481 */           _skipLF();
/* 1482 */         else if (i == 13)
/* 1483 */           _skipCR();
/* 1484 */         else if (i != 9) {
/* 1485 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1490 */     _handleEOF();
/* 1491 */     return -1;
/*      */   }
/*      */ 
/*      */   private final void _skipComment()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1497 */     if (!isEnabled(JsonParser.Feature.ALLOW_COMMENTS)) {
/* 1498 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */ 
/* 1501 */     if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/* 1502 */       _reportInvalidEOF(" in a comment");
/*      */     }
/* 1504 */     char c = this._inputBuffer[(this._inputPtr++)];
/* 1505 */     if (c == '/')
/* 1506 */       _skipCppComment();
/* 1507 */     else if (c == '*')
/* 1508 */       _skipCComment();
/*      */     else
/* 1510 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */   }
/*      */ 
/*      */   private final void _skipCComment()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1519 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 1520 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 1521 */       if (i <= 42) {
/* 1522 */         if (i == 42) {
/* 1523 */           if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/*      */             break;
/*      */           }
/* 1526 */           if (this._inputBuffer[this._inputPtr] == '/') {
/* 1527 */             this._inputPtr += 1;
/*      */           }
/*      */ 
/*      */         }
/* 1532 */         else if (i < 32) {
/* 1533 */           if (i == 10)
/* 1534 */             _skipLF();
/* 1535 */           else if (i == 13)
/* 1536 */             _skipCR();
/* 1537 */           else if (i != 9) {
/* 1538 */             _throwInvalidSpace(i);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1543 */     _reportInvalidEOF(" in a comment");
/*      */   }
/*      */ 
/*      */   private final void _skipCppComment()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1550 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 1551 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 1552 */       if (i < 32) {
/* 1553 */         if (i == 10) {
/* 1554 */           _skipLF();
/* 1555 */           break;
/* 1556 */         }if (i == 13) {
/* 1557 */           _skipCR();
/* 1558 */           break;
/* 1559 */         }if (i != 9)
/* 1560 */           _throwInvalidSpace(i);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final char _decodeEscaped()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1570 */     if ((this._inputPtr >= this._inputEnd) && 
/* 1571 */       (!loadMore())) {
/* 1572 */       _reportInvalidEOF(" in character escape sequence");
/*      */     }
/*      */ 
/* 1575 */     char c = this._inputBuffer[(this._inputPtr++)];
/*      */ 
/* 1577 */     switch (c)
/*      */     {
/*      */     case 'b':
/* 1580 */       return '\b';
/*      */     case 't':
/* 1582 */       return '\t';
/*      */     case 'n':
/* 1584 */       return '\n';
/*      */     case 'f':
/* 1586 */       return '\f';
/*      */     case 'r':
/* 1588 */       return '\r';
/*      */     case '"':
/*      */     case '/':
/*      */     case '\\':
/* 1594 */       return c;
/*      */     case 'u':
/* 1597 */       break;
/*      */     default:
/* 1600 */       return _handleUnrecognizedCharacterEscape(c);
/*      */     }
/*      */ 
/* 1604 */     int value = 0;
/* 1605 */     for (int i = 0; i < 4; i++) {
/* 1606 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1607 */         (!loadMore())) {
/* 1608 */         _reportInvalidEOF(" in character escape sequence");
/*      */       }
/*      */ 
/* 1611 */       int ch = this._inputBuffer[(this._inputPtr++)];
/* 1612 */       int digit = CharTypes.charToHex(ch);
/* 1613 */       if (digit < 0) {
/* 1614 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 1616 */       value = value << 4 | digit;
/*      */     }
/* 1618 */     return (char)value;
/*      */   }
/*      */ 
/*      */   protected final void _matchToken(String matchStr, int i)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1629 */     int len = matchStr.length();
/*      */     do
/*      */     {
/* 1632 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1633 */         (!loadMore())) {
/* 1634 */         _reportInvalidEOFInValue();
/*      */       }
/*      */ 
/* 1637 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 1638 */         _reportInvalidToken(matchStr.substring(0, i), "'null', 'true', 'false' or NaN");
/*      */       }
/* 1640 */       this._inputPtr += 1;
/* 1641 */       i++; } while (i < len);
/*      */ 
/* 1644 */     if ((this._inputPtr >= this._inputEnd) && 
/* 1645 */       (!loadMore())) {
/* 1646 */       return;
/*      */     }
/*      */ 
/* 1649 */     char c = this._inputBuffer[this._inputPtr];
/* 1650 */     if ((c < '0') || (c == ']') || (c == '}')) {
/* 1651 */       return;
/*      */     }
/*      */ 
/* 1654 */     if (Character.isJavaIdentifierPart(c)) {
/* 1655 */       this._inputPtr += 1;
/* 1656 */       _reportInvalidToken(matchStr.substring(0, i), "'null', 'true', 'false' or NaN");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected byte[] _decodeBase64(Base64Variant b64variant)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1671 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */     while (true)
/*      */     {
/* 1678 */       if (this._inputPtr >= this._inputEnd) {
/* 1679 */         loadMoreGuaranteed();
/*      */       }
/* 1681 */       char ch = this._inputBuffer[(this._inputPtr++)];
/* 1682 */       if (ch > ' ') {
/* 1683 */         int bits = b64variant.decodeBase64Char(ch);
/* 1684 */         if (bits < 0) {
/* 1685 */           if (ch == '"') {
/* 1686 */             return builder.toByteArray();
/*      */           }
/* 1688 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 1689 */           if (bits < 0);
/*      */         }
/*      */         else {
/* 1693 */           int decodedData = bits;
/*      */ 
/* 1697 */           if (this._inputPtr >= this._inputEnd) {
/* 1698 */             loadMoreGuaranteed();
/*      */           }
/* 1700 */           ch = this._inputBuffer[(this._inputPtr++)];
/* 1701 */           bits = b64variant.decodeBase64Char(ch);
/* 1702 */           if (bits < 0) {
/* 1703 */             bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */           }
/* 1705 */           decodedData = decodedData << 6 | bits;
/*      */ 
/* 1708 */           if (this._inputPtr >= this._inputEnd) {
/* 1709 */             loadMoreGuaranteed();
/*      */           }
/* 1711 */           ch = this._inputBuffer[(this._inputPtr++)];
/* 1712 */           bits = b64variant.decodeBase64Char(ch);
/*      */ 
/* 1715 */           if (bits < 0) {
/* 1716 */             if (bits != -2)
/*      */             {
/* 1718 */               if ((ch == '"') && (!b64variant.usesPadding())) {
/* 1719 */                 decodedData >>= 4;
/* 1720 */                 builder.append(decodedData);
/* 1721 */                 return builder.toByteArray();
/*      */               }
/* 1723 */               bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */             }
/* 1725 */             if (bits == -2)
/*      */             {
/* 1727 */               if (this._inputPtr >= this._inputEnd) {
/* 1728 */                 loadMoreGuaranteed();
/*      */               }
/* 1730 */               ch = this._inputBuffer[(this._inputPtr++)];
/* 1731 */               if (!b64variant.usesPaddingChar(ch)) {
/* 1732 */                 throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */               }
/*      */ 
/* 1735 */               decodedData >>= 4;
/* 1736 */               builder.append(decodedData);
/*      */             }
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1742 */             decodedData = decodedData << 6 | bits;
/*      */ 
/* 1744 */             if (this._inputPtr >= this._inputEnd) {
/* 1745 */               loadMoreGuaranteed();
/*      */             }
/* 1747 */             ch = this._inputBuffer[(this._inputPtr++)];
/* 1748 */             bits = b64variant.decodeBase64Char(ch);
/* 1749 */             if (bits < 0) {
/* 1750 */               if (bits != -2)
/*      */               {
/* 1752 */                 if ((ch == '"') && (!b64variant.usesPadding())) {
/* 1753 */                   decodedData >>= 2;
/* 1754 */                   builder.appendTwoBytes(decodedData);
/* 1755 */                   return builder.toByteArray();
/*      */                 }
/* 1757 */                 bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */               }
/* 1759 */               if (bits == -2)
/*      */               {
/* 1766 */                 decodedData >>= 2;
/* 1767 */                 builder.appendTwoBytes(decodedData);
/*      */               }
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1773 */               decodedData = decodedData << 6 | bits;
/* 1774 */               builder.appendThreeBytes(decodedData);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidToken(String matchedPart, String msg)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1787 */     StringBuilder sb = new StringBuilder(matchedPart);
/*      */ 
/* 1793 */     while ((this._inputPtr < this._inputEnd) || 
/* 1794 */       (loadMore()))
/*      */     {
/* 1798 */       char c = this._inputBuffer[this._inputPtr];
/* 1799 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 1802 */       this._inputPtr += 1;
/* 1803 */       sb.append(c);
/*      */     }
/* 1805 */     _reportError("Unrecognized token '" + sb.toString() + "': was expecting ");
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.impl.ReaderBasedParser
 * JD-Core Version:    0.6.2
 */