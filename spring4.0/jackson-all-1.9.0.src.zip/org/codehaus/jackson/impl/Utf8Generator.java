/*      */ package org.codehaus.jackson.impl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import org.codehaus.jackson.Base64Variant;
/*      */ import org.codehaus.jackson.JsonGenerationException;
/*      */ import org.codehaus.jackson.JsonGenerator;
/*      */ import org.codehaus.jackson.JsonGenerator.Feature;
/*      */ import org.codehaus.jackson.JsonStreamContext;
/*      */ import org.codehaus.jackson.ObjectCodec;
/*      */ import org.codehaus.jackson.PrettyPrinter;
/*      */ import org.codehaus.jackson.SerializableString;
/*      */ import org.codehaus.jackson.io.CharacterEscapes;
/*      */ import org.codehaus.jackson.io.IOContext;
/*      */ import org.codehaus.jackson.io.NumberOutput;
/*      */ import org.codehaus.jackson.io.SerializedString;
/*      */ import org.codehaus.jackson.util.CharTypes;
/*      */ 
/*      */ public class Utf8Generator extends JsonGeneratorBase
/*      */ {
/*      */   private static final byte BYTE_u = 117;
/*      */   private static final byte BYTE_0 = 48;
/*      */   private static final byte BYTE_LBRACKET = 91;
/*      */   private static final byte BYTE_RBRACKET = 93;
/*      */   private static final byte BYTE_LCURLY = 123;
/*      */   private static final byte BYTE_RCURLY = 125;
/*      */   private static final byte BYTE_BACKSLASH = 92;
/*      */   private static final byte BYTE_SPACE = 32;
/*      */   private static final byte BYTE_COMMA = 44;
/*      */   private static final byte BYTE_COLON = 58;
/*      */   private static final byte BYTE_QUOTE = 34;
/*      */   protected static final int SURR1_FIRST = 55296;
/*      */   protected static final int SURR1_LAST = 56319;
/*      */   protected static final int SURR2_FIRST = 56320;
/*      */   protected static final int SURR2_LAST = 57343;
/*      */   private static final int MAX_BYTES_TO_BUFFER = 512;
/*   40 */   static final byte[] HEX_CHARS = CharTypes.copyHexBytes();
/*      */ 
/*   42 */   private static final byte[] NULL_BYTES = { 110, 117, 108, 108 };
/*   43 */   private static final byte[] TRUE_BYTES = { 116, 114, 117, 101 };
/*   44 */   private static final byte[] FALSE_BYTES = { 102, 97, 108, 115, 101 };
/*      */ 
/*   50 */   protected static final int[] sOutputEscapes = CharTypes.get7BitOutputEscapes();
/*      */   protected final IOContext _ioContext;
/*      */   protected final OutputStream _outputStream;
/*   77 */   protected int[] _outputEscapes = sOutputEscapes;
/*      */   protected int _maximumNonEscapedChar;
/*      */   protected CharacterEscapes _characterEscapes;
/*      */   protected byte[] _outputBuffer;
/*  115 */   protected int _outputTail = 0;
/*      */   protected final int _outputEnd;
/*      */   protected final int _outputMaxContiguous;
/*      */   protected char[] _charBuffer;
/*      */   protected final int _charBufferLength;
/*      */   protected byte[] _entityBuffer;
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */   public Utf8Generator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out)
/*      */   {
/*  162 */     super(features, codec);
/*  163 */     this._ioContext = ctxt;
/*  164 */     this._outputStream = out;
/*  165 */     this._bufferRecyclable = true;
/*  166 */     this._outputBuffer = ctxt.allocWriteEncodingBuffer();
/*  167 */     this._outputEnd = this._outputBuffer.length;
/*      */ 
/*  172 */     this._outputMaxContiguous = (this._outputEnd >> 3);
/*  173 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  174 */     this._charBufferLength = this._charBuffer.length;
/*      */ 
/*  177 */     if (isEnabled(JsonGenerator.Feature.ESCAPE_NON_ASCII))
/*  178 */       setHighestNonEscapedChar(127);
/*      */   }
/*      */ 
/*      */   public Utf8Generator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, byte[] outputBuffer, int outputOffset, boolean bufferRecyclable)
/*      */   {
/*  186 */     super(features, codec);
/*  187 */     this._ioContext = ctxt;
/*  188 */     this._outputStream = out;
/*  189 */     this._bufferRecyclable = bufferRecyclable;
/*  190 */     this._outputTail = outputOffset;
/*  191 */     this._outputBuffer = outputBuffer;
/*  192 */     this._outputEnd = this._outputBuffer.length;
/*      */ 
/*  194 */     this._outputMaxContiguous = (this._outputEnd >> 3);
/*  195 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  196 */     this._charBufferLength = this._charBuffer.length;
/*      */ 
/*  198 */     if (isEnabled(JsonGenerator.Feature.ESCAPE_NON_ASCII))
/*  199 */       setHighestNonEscapedChar(127);
/*      */   }
/*      */ 
/*      */   public JsonGenerator setHighestNonEscapedChar(int charCode)
/*      */   {
/*  211 */     this._maximumNonEscapedChar = (charCode < 0 ? 0 : charCode);
/*  212 */     return this;
/*      */   }
/*      */ 
/*      */   public int getHighestEscapedChar()
/*      */   {
/*  217 */     return this._maximumNonEscapedChar;
/*      */   }
/*      */ 
/*      */   public JsonGenerator setCharacterEscapes(CharacterEscapes esc)
/*      */   {
/*  223 */     this._characterEscapes = esc;
/*  224 */     if (esc == null)
/*  225 */       this._outputEscapes = sOutputEscapes;
/*      */     else {
/*  227 */       this._outputEscapes = esc.getEscapeCodesForAscii();
/*      */     }
/*  229 */     return this;
/*      */   }
/*      */ 
/*      */   public CharacterEscapes getCharacterEscapes()
/*      */   {
/*  240 */     return this._characterEscapes;
/*      */   }
/*      */ 
/*      */   public Object getOutputTarget()
/*      */   {
/*  245 */     return this._outputStream;
/*      */   }
/*      */ 
/*      */   public final void writeStringField(String fieldName, String value)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  261 */     writeFieldName(fieldName);
/*  262 */     writeString(value);
/*      */   }
/*      */ 
/*      */   public final void writeFieldName(String name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  268 */     int status = this._writeContext.writeFieldName(name);
/*  269 */     if (status == 4) {
/*  270 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  272 */     if (this._cfgPrettyPrinter != null) {
/*  273 */       _writePPFieldName(name, status == 1);
/*  274 */       return;
/*      */     }
/*  276 */     if (status == 1) {
/*  277 */       if (this._outputTail >= this._outputEnd) {
/*  278 */         _flushBuffer();
/*      */       }
/*  280 */       this._outputBuffer[(this._outputTail++)] = 44;
/*      */     }
/*  282 */     _writeFieldName(name);
/*      */   }
/*      */ 
/*      */   public final void writeFieldName(SerializedString name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  290 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  291 */     if (status == 4) {
/*  292 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  294 */     if (this._cfgPrettyPrinter != null) {
/*  295 */       _writePPFieldName(name, status == 1);
/*  296 */       return;
/*      */     }
/*  298 */     if (status == 1) {
/*  299 */       if (this._outputTail >= this._outputEnd) {
/*  300 */         _flushBuffer();
/*      */       }
/*  302 */       this._outputBuffer[(this._outputTail++)] = 44;
/*      */     }
/*  304 */     _writeFieldName(name);
/*      */   }
/*      */ 
/*      */   public final void writeFieldName(SerializableString name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  312 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  313 */     if (status == 4) {
/*  314 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  316 */     if (this._cfgPrettyPrinter != null) {
/*  317 */       _writePPFieldName(name, status == 1);
/*  318 */       return;
/*      */     }
/*  320 */     if (status == 1) {
/*  321 */       if (this._outputTail >= this._outputEnd) {
/*  322 */         _flushBuffer();
/*      */       }
/*  324 */       this._outputBuffer[(this._outputTail++)] = 44;
/*      */     }
/*  326 */     _writeFieldName(name);
/*      */   }
/*      */ 
/*      */   public final void writeStartArray()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  338 */     _verifyValueWrite("start an array");
/*  339 */     this._writeContext = this._writeContext.createChildArrayContext();
/*  340 */     if (this._cfgPrettyPrinter != null) {
/*  341 */       this._cfgPrettyPrinter.writeStartArray(this);
/*      */     } else {
/*  343 */       if (this._outputTail >= this._outputEnd) {
/*  344 */         _flushBuffer();
/*      */       }
/*  346 */       this._outputBuffer[(this._outputTail++)] = 91;
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void writeEndArray()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  353 */     if (!this._writeContext.inArray()) {
/*  354 */       _reportError("Current context not an ARRAY but " + this._writeContext.getTypeDesc());
/*      */     }
/*  356 */     if (this._cfgPrettyPrinter != null) {
/*  357 */       this._cfgPrettyPrinter.writeEndArray(this, this._writeContext.getEntryCount());
/*      */     } else {
/*  359 */       if (this._outputTail >= this._outputEnd) {
/*  360 */         _flushBuffer();
/*      */       }
/*  362 */       this._outputBuffer[(this._outputTail++)] = 93;
/*      */     }
/*  364 */     this._writeContext = this._writeContext.getParent();
/*      */   }
/*      */ 
/*      */   public final void writeStartObject()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  370 */     _verifyValueWrite("start an object");
/*  371 */     this._writeContext = this._writeContext.createChildObjectContext();
/*  372 */     if (this._cfgPrettyPrinter != null) {
/*  373 */       this._cfgPrettyPrinter.writeStartObject(this);
/*      */     } else {
/*  375 */       if (this._outputTail >= this._outputEnd) {
/*  376 */         _flushBuffer();
/*      */       }
/*  378 */       this._outputBuffer[(this._outputTail++)] = 123;
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void writeEndObject()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  385 */     if (!this._writeContext.inObject()) {
/*  386 */       _reportError("Current context not an object but " + this._writeContext.getTypeDesc());
/*      */     }
/*  388 */     this._writeContext = this._writeContext.getParent();
/*  389 */     if (this._cfgPrettyPrinter != null) {
/*  390 */       this._cfgPrettyPrinter.writeEndObject(this, this._writeContext.getEntryCount());
/*      */     } else {
/*  392 */       if (this._outputTail >= this._outputEnd) {
/*  393 */         _flushBuffer();
/*      */       }
/*  395 */       this._outputBuffer[(this._outputTail++)] = 125;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void _writeFieldName(String name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  405 */     if (!isEnabled(JsonGenerator.Feature.QUOTE_FIELD_NAMES)) {
/*  406 */       _writeStringSegments(name);
/*  407 */       return;
/*      */     }
/*  409 */     if (this._outputTail >= this._outputEnd) {
/*  410 */       _flushBuffer();
/*      */     }
/*  412 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */ 
/*  414 */     int len = name.length();
/*  415 */     if (len <= this._charBufferLength) {
/*  416 */       name.getChars(0, len, this._charBuffer, 0);
/*      */ 
/*  418 */       if (len <= this._outputMaxContiguous) {
/*  419 */         if (this._outputTail + len > this._outputEnd) {
/*  420 */           _flushBuffer();
/*      */         }
/*  422 */         _writeStringSegment(this._charBuffer, 0, len);
/*      */       } else {
/*  424 */         _writeStringSegments(this._charBuffer, 0, len);
/*      */       }
/*      */     } else {
/*  427 */       _writeStringSegments(name);
/*      */     }
/*      */ 
/*  431 */     if (this._outputTail >= this._outputEnd) {
/*  432 */       _flushBuffer();
/*      */     }
/*  434 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   protected final void _writeFieldName(SerializableString name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  440 */     byte[] raw = name.asQuotedUTF8();
/*  441 */     if (!isEnabled(JsonGenerator.Feature.QUOTE_FIELD_NAMES)) {
/*  442 */       _writeBytes(raw);
/*  443 */       return;
/*      */     }
/*  445 */     if (this._outputTail >= this._outputEnd) {
/*  446 */       _flushBuffer();
/*      */     }
/*  448 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */ 
/*  451 */     int len = raw.length;
/*  452 */     if (this._outputTail + len + 1 < this._outputEnd) {
/*  453 */       System.arraycopy(raw, 0, this._outputBuffer, this._outputTail, len);
/*  454 */       this._outputTail += len;
/*  455 */       this._outputBuffer[(this._outputTail++)] = 34;
/*      */     } else {
/*  457 */       _writeBytes(raw);
/*  458 */       if (this._outputTail >= this._outputEnd) {
/*  459 */         _flushBuffer();
/*      */       }
/*  461 */       this._outputBuffer[(this._outputTail++)] = 34;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void _writePPFieldName(String name, boolean commaBefore)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  472 */     if (commaBefore)
/*  473 */       this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
/*      */     else {
/*  475 */       this._cfgPrettyPrinter.beforeObjectEntries(this);
/*      */     }
/*      */ 
/*  478 */     if (isEnabled(JsonGenerator.Feature.QUOTE_FIELD_NAMES)) {
/*  479 */       if (this._outputTail >= this._outputEnd) {
/*  480 */         _flushBuffer();
/*      */       }
/*  482 */       this._outputBuffer[(this._outputTail++)] = 34;
/*  483 */       int len = name.length();
/*  484 */       if (len <= this._charBufferLength) {
/*  485 */         name.getChars(0, len, this._charBuffer, 0);
/*      */ 
/*  487 */         if (len <= this._outputMaxContiguous) {
/*  488 */           if (this._outputTail + len > this._outputEnd) {
/*  489 */             _flushBuffer();
/*      */           }
/*  491 */           _writeStringSegment(this._charBuffer, 0, len);
/*      */         } else {
/*  493 */           _writeStringSegments(this._charBuffer, 0, len);
/*      */         }
/*      */       } else {
/*  496 */         _writeStringSegments(name);
/*      */       }
/*  498 */       if (this._outputTail >= this._outputEnd) {
/*  499 */         _flushBuffer();
/*      */       }
/*  501 */       this._outputBuffer[(this._outputTail++)] = 34;
/*      */     } else {
/*  503 */       _writeStringSegments(name);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void _writePPFieldName(SerializableString name, boolean commaBefore)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  510 */     if (commaBefore)
/*  511 */       this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
/*      */     else {
/*  513 */       this._cfgPrettyPrinter.beforeObjectEntries(this);
/*      */     }
/*      */ 
/*  516 */     boolean addQuotes = isEnabled(JsonGenerator.Feature.QUOTE_FIELD_NAMES);
/*  517 */     if (addQuotes) {
/*  518 */       if (this._outputTail >= this._outputEnd) {
/*  519 */         _flushBuffer();
/*      */       }
/*  521 */       this._outputBuffer[(this._outputTail++)] = 34;
/*      */     }
/*  523 */     _writeBytes(name.asQuotedUTF8());
/*  524 */     if (addQuotes) {
/*  525 */       if (this._outputTail >= this._outputEnd) {
/*  526 */         _flushBuffer();
/*      */       }
/*  528 */       this._outputBuffer[(this._outputTail++)] = 34;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeString(String text)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  542 */     _verifyValueWrite("write text value");
/*  543 */     if (text == null) {
/*  544 */       _writeNull();
/*  545 */       return;
/*      */     }
/*      */ 
/*  548 */     int len = text.length();
/*  549 */     if (len > this._charBufferLength) {
/*  550 */       _writeLongString(text);
/*  551 */       return;
/*      */     }
/*      */ 
/*  554 */     text.getChars(0, len, this._charBuffer, 0);
/*      */ 
/*  556 */     if (len > this._outputMaxContiguous) {
/*  557 */       _writeLongString(this._charBuffer, 0, len);
/*  558 */       return;
/*      */     }
/*  560 */     if (this._outputTail + len + 2 > this._outputEnd) {
/*  561 */       _flushBuffer();
/*      */     }
/*  563 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  564 */     _writeStringSegment(this._charBuffer, 0, len);
/*  565 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   private final void _writeLongString(String text)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  571 */     if (this._outputTail >= this._outputEnd) {
/*  572 */       _flushBuffer();
/*      */     }
/*  574 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  575 */     _writeStringSegments(text);
/*  576 */     if (this._outputTail >= this._outputEnd) {
/*  577 */       _flushBuffer();
/*      */     }
/*  579 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   private final void _writeLongString(char[] text, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  585 */     if (this._outputTail >= this._outputEnd) {
/*  586 */       _flushBuffer();
/*      */     }
/*  588 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  589 */     _writeStringSegments(this._charBuffer, 0, len);
/*  590 */     if (this._outputTail >= this._outputEnd) {
/*  591 */       _flushBuffer();
/*      */     }
/*  593 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public void writeString(char[] text, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  600 */     _verifyValueWrite("write text value");
/*  601 */     if (this._outputTail >= this._outputEnd) {
/*  602 */       _flushBuffer();
/*      */     }
/*  604 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */ 
/*  606 */     if (len <= this._outputMaxContiguous) {
/*  607 */       if (this._outputTail + len > this._outputEnd) {
/*  608 */         _flushBuffer();
/*      */       }
/*  610 */       _writeStringSegment(text, offset, len);
/*      */     } else {
/*  612 */       _writeStringSegments(text, offset, len);
/*      */     }
/*      */ 
/*  615 */     if (this._outputTail >= this._outputEnd) {
/*  616 */       _flushBuffer();
/*      */     }
/*  618 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public final void writeString(SerializableString text)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  625 */     _verifyValueWrite("write text value");
/*  626 */     if (this._outputTail >= this._outputEnd) {
/*  627 */       _flushBuffer();
/*      */     }
/*  629 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  630 */     _writeBytes(text.asQuotedUTF8());
/*  631 */     if (this._outputTail >= this._outputEnd) {
/*  632 */       _flushBuffer();
/*      */     }
/*  634 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  641 */     _verifyValueWrite("write text value");
/*  642 */     if (this._outputTail >= this._outputEnd) {
/*  643 */       _flushBuffer();
/*      */     }
/*  645 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  646 */     _writeBytes(text, offset, length);
/*  647 */     if (this._outputTail >= this._outputEnd) {
/*  648 */       _flushBuffer();
/*      */     }
/*  650 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public void writeUTF8String(byte[] text, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  657 */     _verifyValueWrite("write text value");
/*  658 */     if (this._outputTail >= this._outputEnd) {
/*  659 */       _flushBuffer();
/*      */     }
/*  661 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */ 
/*  663 */     if (len <= this._outputMaxContiguous)
/*  664 */       _writeUTF8Segment(text, offset, len);
/*      */     else {
/*  666 */       _writeUTF8Segments(text, offset, len);
/*      */     }
/*  668 */     if (this._outputTail >= this._outputEnd) {
/*  669 */       _flushBuffer();
/*      */     }
/*  671 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public void writeRaw(String text)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  684 */     int start = 0;
/*  685 */     int len = text.length();
/*  686 */     while (len > 0) {
/*  687 */       char[] buf = this._charBuffer;
/*  688 */       int blen = buf.length;
/*  689 */       int len2 = len < blen ? len : blen;
/*  690 */       text.getChars(start, start + len2, buf, 0);
/*  691 */       writeRaw(buf, 0, len2);
/*  692 */       start += len2;
/*  693 */       len -= len2;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeRaw(String text, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  701 */     while (len > 0) {
/*  702 */       char[] buf = this._charBuffer;
/*  703 */       int blen = buf.length;
/*  704 */       int len2 = len < blen ? len : blen;
/*  705 */       text.getChars(offset, offset + len2, buf, 0);
/*  706 */       writeRaw(buf, 0, len2);
/*  707 */       offset += len2;
/*  708 */       len -= len2;
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void writeRaw(char[] cbuf, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  719 */     int len3 = len + len + len;
/*  720 */     if (this._outputTail + len3 > this._outputEnd)
/*      */     {
/*  722 */       if (this._outputEnd < len3) {
/*  723 */         _writeSegmentedRaw(cbuf, offset, len);
/*  724 */         return;
/*      */       }
/*      */ 
/*  727 */       _flushBuffer();
/*      */     }
/*      */ 
/*  730 */     len += offset;
/*      */ 
/*  734 */     while (offset < len)
/*      */     {
/*      */       while (true) {
/*  737 */         int ch = cbuf[offset];
/*  738 */         if (ch > 127) {
/*      */           break;
/*      */         }
/*  741 */         this._outputBuffer[(this._outputTail++)] = ((byte)ch);
/*  742 */         offset++; if (offset >= len) {
/*      */           return;
/*      */         }
/*      */       }
/*  746 */       char ch = cbuf[(offset++)];
/*  747 */       if (ch < 'ࠀ') {
/*  748 */         this._outputBuffer[(this._outputTail++)] = ((byte)(0xC0 | ch >> '\006'));
/*  749 */         this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/*  751 */         _outputRawMultiByteChar(ch, cbuf, offset, len);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeRaw(char ch)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  760 */     if (this._outputTail + 3 >= this._outputEnd) {
/*  761 */       _flushBuffer();
/*      */     }
/*  763 */     byte[] bbuf = this._outputBuffer;
/*  764 */     if (ch <= '') {
/*  765 */       bbuf[(this._outputTail++)] = ((byte)ch);
/*  766 */     } else if (ch < 'ࠀ') {
/*  767 */       bbuf[(this._outputTail++)] = ((byte)(0xC0 | ch >> '\006'));
/*  768 */       bbuf[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/*      */     } else {
/*  770 */       _outputRawMultiByteChar(ch, null, 0, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _writeSegmentedRaw(char[] cbuf, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  781 */     int end = this._outputEnd;
/*  782 */     byte[] bbuf = this._outputBuffer;
/*      */ 
/*  785 */     while (offset < len)
/*      */     {
/*      */       while (true) {
/*  788 */         int ch = cbuf[offset];
/*  789 */         if (ch >= 128)
/*      */         {
/*      */           break;
/*      */         }
/*  793 */         if (this._outputTail >= end) {
/*  794 */           _flushBuffer();
/*      */         }
/*  796 */         bbuf[(this._outputTail++)] = ((byte)ch);
/*  797 */         offset++; if (offset >= len) {
/*      */           return;
/*      */         }
/*      */       }
/*  801 */       if (this._outputTail + 3 >= this._outputEnd) {
/*  802 */         _flushBuffer();
/*      */       }
/*  804 */       char ch = cbuf[(offset++)];
/*  805 */       if (ch < 'ࠀ') {
/*  806 */         bbuf[(this._outputTail++)] = ((byte)(0xC0 | ch >> '\006'));
/*  807 */         bbuf[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/*  809 */         _outputRawMultiByteChar(ch, cbuf, offset, len);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  824 */     _verifyValueWrite("write binary value");
/*      */ 
/*  826 */     if (this._outputTail >= this._outputEnd) {
/*  827 */       _flushBuffer();
/*      */     }
/*  829 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  830 */     _writeBinary(b64variant, data, offset, offset + len);
/*      */ 
/*  832 */     if (this._outputTail >= this._outputEnd) {
/*  833 */       _flushBuffer();
/*      */     }
/*  835 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public void writeNumber(int i)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  848 */     _verifyValueWrite("write number");
/*      */ 
/*  850 */     if (this._outputTail + 11 >= this._outputEnd) {
/*  851 */       _flushBuffer();
/*      */     }
/*  853 */     if (this._cfgNumbersAsStrings) {
/*  854 */       _writeQuotedInt(i);
/*  855 */       return;
/*      */     }
/*  857 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*      */   }
/*      */ 
/*      */   private final void _writeQuotedInt(int i) throws IOException {
/*  861 */     if (this._outputTail + 13 >= this._outputEnd) {
/*  862 */       _flushBuffer();
/*      */     }
/*  864 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  865 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*  866 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public void writeNumber(long l)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  873 */     _verifyValueWrite("write number");
/*  874 */     if (this._cfgNumbersAsStrings) {
/*  875 */       _writeQuotedLong(l);
/*  876 */       return;
/*      */     }
/*  878 */     if (this._outputTail + 21 >= this._outputEnd)
/*      */     {
/*  880 */       _flushBuffer();
/*      */     }
/*  882 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*      */   }
/*      */ 
/*      */   private final void _writeQuotedLong(long l) throws IOException {
/*  886 */     if (this._outputTail + 23 >= this._outputEnd) {
/*  887 */       _flushBuffer();
/*      */     }
/*  889 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  890 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*  891 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public void writeNumber(BigInteger value)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  898 */     _verifyValueWrite("write number");
/*  899 */     if (value == null)
/*  900 */       _writeNull();
/*  901 */     else if (this._cfgNumbersAsStrings)
/*  902 */       _writeQuotedRaw(value);
/*      */     else
/*  904 */       writeRaw(value.toString());
/*      */   }
/*      */ 
/*      */   public void writeNumber(double d)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  913 */     if ((this._cfgNumbersAsStrings) || (((Double.isNaN(d)) || (Double.isInfinite(d))) && (isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS))))
/*      */     {
/*  917 */       writeString(String.valueOf(d));
/*  918 */       return;
/*      */     }
/*      */ 
/*  921 */     _verifyValueWrite("write number");
/*  922 */     writeRaw(String.valueOf(d));
/*      */   }
/*      */ 
/*      */   public void writeNumber(float f)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  929 */     if ((this._cfgNumbersAsStrings) || (((Float.isNaN(f)) || (Float.isInfinite(f))) && (isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS))))
/*      */     {
/*  933 */       writeString(String.valueOf(f));
/*  934 */       return;
/*      */     }
/*      */ 
/*  937 */     _verifyValueWrite("write number");
/*  938 */     writeRaw(String.valueOf(f));
/*      */   }
/*      */ 
/*      */   public void writeNumber(BigDecimal value)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  946 */     _verifyValueWrite("write number");
/*  947 */     if (value == null)
/*  948 */       _writeNull();
/*  949 */     else if (this._cfgNumbersAsStrings)
/*  950 */       _writeQuotedRaw(value);
/*      */     else
/*  952 */       writeRaw(value.toString());
/*      */   }
/*      */ 
/*      */   public void writeNumber(String encodedValue)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  960 */     _verifyValueWrite("write number");
/*  961 */     if (this._cfgNumbersAsStrings)
/*  962 */       _writeQuotedRaw(encodedValue);
/*      */     else
/*  964 */       writeRaw(encodedValue);
/*      */   }
/*      */ 
/*      */   private final void _writeQuotedRaw(Object value)
/*      */     throws IOException
/*      */   {
/*  970 */     if (this._outputTail >= this._outputEnd) {
/*  971 */       _flushBuffer();
/*      */     }
/*  973 */     this._outputBuffer[(this._outputTail++)] = 34;
/*  974 */     writeRaw(value.toString());
/*  975 */     if (this._outputTail >= this._outputEnd) {
/*  976 */       _flushBuffer();
/*      */     }
/*  978 */     this._outputBuffer[(this._outputTail++)] = 34;
/*      */   }
/*      */ 
/*      */   public void writeBoolean(boolean state)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  985 */     _verifyValueWrite("write boolean value");
/*  986 */     if (this._outputTail + 5 >= this._outputEnd) {
/*  987 */       _flushBuffer();
/*      */     }
/*  989 */     byte[] keyword = state ? TRUE_BYTES : FALSE_BYTES;
/*  990 */     int len = keyword.length;
/*  991 */     System.arraycopy(keyword, 0, this._outputBuffer, this._outputTail, len);
/*  992 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   public void writeNull()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  999 */     _verifyValueWrite("write null value");
/* 1000 */     _writeNull();
/*      */   }
/*      */ 
/*      */   protected final void _verifyValueWrite(String typeMsg)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1013 */     int status = this._writeContext.writeValue();
/* 1014 */     if (status == 5) {
/* 1015 */       _reportError("Can not " + typeMsg + ", expecting field name");
/*      */     }
/* 1017 */     if (this._cfgPrettyPrinter == null)
/*      */     {
/*      */       byte b;
/* 1019 */       switch (status) {
/*      */       case 1:
/* 1021 */         b = 44;
/* 1022 */         break;
/*      */       case 2:
/* 1024 */         b = 58;
/* 1025 */         break;
/*      */       case 3:
/* 1027 */         b = 32;
/* 1028 */         break;
/*      */       case 0:
/*      */       default:
/* 1031 */         return;
/*      */       }
/* 1033 */       if (this._outputTail >= this._outputEnd) {
/* 1034 */         _flushBuffer();
/*      */       }
/* 1036 */       this._outputBuffer[this._outputTail] = b;
/* 1037 */       this._outputTail += 1;
/* 1038 */       return;
/*      */     }
/*      */ 
/* 1041 */     _verifyPrettyValueWrite(typeMsg, status);
/*      */   }
/*      */ 
/*      */   protected final void _verifyPrettyValueWrite(String typeMsg, int status)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1048 */     switch (status) {
/*      */     case 1:
/* 1050 */       this._cfgPrettyPrinter.writeArrayValueSeparator(this);
/* 1051 */       break;
/*      */     case 2:
/* 1053 */       this._cfgPrettyPrinter.writeObjectFieldValueSeparator(this);
/* 1054 */       break;
/*      */     case 3:
/* 1056 */       this._cfgPrettyPrinter.writeRootValueSeparator(this);
/* 1057 */       break;
/*      */     case 0:
/* 1060 */       if (this._writeContext.inArray())
/* 1061 */         this._cfgPrettyPrinter.beforeArrayValues(this);
/* 1062 */       else if (this._writeContext.inObject())
/* 1063 */         this._cfgPrettyPrinter.beforeObjectEntries(this); break;
/*      */     default:
/* 1067 */       _cantHappen();
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void flush()
/*      */     throws IOException
/*      */   {
/* 1082 */     _flushBuffer();
/* 1083 */     if ((this._outputStream != null) && 
/* 1084 */       (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)))
/* 1085 */       this._outputStream.flush();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/* 1094 */     super.close();
/*      */ 
/* 1100 */     if ((this._outputBuffer != null) && (isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT))) {
/*      */       while (true)
/*      */       {
/* 1103 */         JsonStreamContext ctxt = getOutputContext();
/* 1104 */         if (ctxt.inArray()) {
/* 1105 */           writeEndArray(); } else {
/* 1106 */           if (!ctxt.inObject()) break;
/* 1107 */           writeEndObject();
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1113 */     _flushBuffer();
/*      */ 
/* 1121 */     if (this._outputStream != null) {
/* 1122 */       if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET)))
/* 1123 */         this._outputStream.close();
/* 1124 */       else if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM))
/*      */       {
/* 1126 */         this._outputStream.flush();
/*      */       }
/*      */     }
/*      */ 
/* 1130 */     _releaseBuffers();
/*      */   }
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */   {
/* 1136 */     byte[] buf = this._outputBuffer;
/* 1137 */     if ((buf != null) && (this._bufferRecyclable)) {
/* 1138 */       this._outputBuffer = null;
/* 1139 */       this._ioContext.releaseWriteEncodingBuffer(buf);
/*      */     }
/* 1141 */     char[] cbuf = this._charBuffer;
/* 1142 */     if (cbuf != null) {
/* 1143 */       this._charBuffer = null;
/* 1144 */       this._ioContext.releaseConcatBuffer(cbuf);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _writeBytes(byte[] bytes)
/*      */     throws IOException
/*      */   {
/* 1156 */     int len = bytes.length;
/* 1157 */     if (this._outputTail + len > this._outputEnd) {
/* 1158 */       _flushBuffer();
/*      */ 
/* 1160 */       if (len > 512) {
/* 1161 */         this._outputStream.write(bytes, 0, len);
/* 1162 */         return;
/*      */       }
/*      */     }
/* 1165 */     System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, len);
/* 1166 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   private final void _writeBytes(byte[] bytes, int offset, int len) throws IOException
/*      */   {
/* 1171 */     if (this._outputTail + len > this._outputEnd) {
/* 1172 */       _flushBuffer();
/*      */ 
/* 1174 */       if (len > 512) {
/* 1175 */         this._outputStream.write(bytes, offset, len);
/* 1176 */         return;
/*      */       }
/*      */     }
/* 1179 */     System.arraycopy(bytes, offset, this._outputBuffer, this._outputTail, len);
/* 1180 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   private final void _writeStringSegments(String text)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1199 */     int left = text.length();
/* 1200 */     int offset = 0;
/* 1201 */     char[] cbuf = this._charBuffer;
/*      */ 
/* 1203 */     while (left > 0) {
/* 1204 */       int len = Math.min(this._outputMaxContiguous, left);
/* 1205 */       text.getChars(offset, offset + len, cbuf, 0);
/* 1206 */       if (this._outputTail + len > this._outputEnd) {
/* 1207 */         _flushBuffer();
/*      */       }
/* 1209 */       _writeStringSegment(cbuf, 0, len);
/* 1210 */       offset += len;
/* 1211 */       left -= len;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _writeStringSegments(char[] cbuf, int offset, int totalLen)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*      */     do
/*      */     {
/* 1225 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1226 */       if (this._outputTail + len > this._outputEnd) {
/* 1227 */         _flushBuffer();
/*      */       }
/* 1229 */       _writeStringSegment(cbuf, offset, len);
/* 1230 */       offset += len;
/* 1231 */       totalLen -= len;
/* 1232 */     }while (totalLen > 0);
/*      */   }
/*      */ 
/*      */   private final void _writeStringSegment(char[] cbuf, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1255 */     len += offset;
/*      */ 
/* 1257 */     int outputPtr = this._outputTail;
/* 1258 */     byte[] outputBuffer = this._outputBuffer;
/* 1259 */     int[] escCodes = this._outputEscapes;
/*      */ 
/* 1261 */     while (offset < len) {
/* 1262 */       int ch = cbuf[offset];
/*      */ 
/* 1264 */       if ((ch > 127) || (escCodes[ch] != 0)) {
/*      */         break;
/*      */       }
/* 1267 */       outputBuffer[(outputPtr++)] = ((byte)ch);
/* 1268 */       offset++;
/*      */     }
/* 1270 */     this._outputTail = outputPtr;
/* 1271 */     if (offset < len)
/*      */     {
/* 1273 */       if (this._characterEscapes != null) {
/* 1274 */         _writeCustomStringSegment2(cbuf, offset, len);
/*      */       }
/* 1276 */       else if (this._maximumNonEscapedChar == 0)
/* 1277 */         _writeStringSegment2(cbuf, offset, len);
/*      */       else
/* 1279 */         _writeStringSegmentASCII2(cbuf, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _writeStringSegment2(char[] cbuf, int offset, int end)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1293 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1294 */       _flushBuffer();
/*      */     }
/*      */ 
/* 1297 */     int outputPtr = this._outputTail;
/*      */ 
/* 1299 */     byte[] outputBuffer = this._outputBuffer;
/* 1300 */     int[] escCodes = this._outputEscapes;
/*      */ 
/* 1302 */     while (offset < end) {
/* 1303 */       int ch = cbuf[(offset++)];
/* 1304 */       if (ch <= 127) {
/* 1305 */         if (escCodes[ch] == 0) {
/* 1306 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1309 */           int escape = escCodes[ch];
/* 1310 */           if (escape > 0) {
/* 1311 */             outputBuffer[(outputPtr++)] = 92;
/* 1312 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/*      */           }
/*      */           else {
/* 1315 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1319 */       else if (ch <= 2047) {
/* 1320 */         outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1321 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/* 1323 */         outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */       }
/*      */     }
/* 1326 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */   private final void _writeStringSegmentASCII2(char[] cbuf, int offset, int end)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1347 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1348 */       _flushBuffer();
/*      */     }
/*      */ 
/* 1351 */     int outputPtr = this._outputTail;
/*      */ 
/* 1353 */     byte[] outputBuffer = this._outputBuffer;
/* 1354 */     int[] escCodes = this._outputEscapes;
/* 1355 */     int maxUnescaped = this._maximumNonEscapedChar;
/*      */ 
/* 1357 */     while (offset < end) {
/* 1358 */       int ch = cbuf[(offset++)];
/* 1359 */       if (ch <= 127) {
/* 1360 */         if (escCodes[ch] == 0) {
/* 1361 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1364 */           int escape = escCodes[ch];
/* 1365 */           if (escape > 0) {
/* 1366 */             outputBuffer[(outputPtr++)] = 92;
/* 1367 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/*      */           }
/*      */           else {
/* 1370 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1374 */       else if (ch > maxUnescaped) {
/* 1375 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */       }
/* 1378 */       else if (ch <= 2047) {
/* 1379 */         outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1380 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/* 1382 */         outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */       }
/*      */     }
/* 1385 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */   private final void _writeCustomStringSegment2(char[] cbuf, int offset, int end)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1405 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1406 */       _flushBuffer();
/*      */     }
/* 1408 */     int outputPtr = this._outputTail;
/*      */ 
/* 1410 */     byte[] outputBuffer = this._outputBuffer;
/* 1411 */     int[] escCodes = this._outputEscapes;
/*      */ 
/* 1413 */     int maxUnescaped = this._maximumNonEscapedChar <= 0 ? 65535 : this._maximumNonEscapedChar;
/* 1414 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */ 
/* 1416 */     while (offset < end) {
/* 1417 */       int ch = cbuf[(offset++)];
/* 1418 */       if (ch <= 127) {
/* 1419 */         if (escCodes[ch] == 0) {
/* 1420 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1423 */           int escape = escCodes[ch];
/* 1424 */           if (escape > 0) {
/* 1425 */             outputBuffer[(outputPtr++)] = 92;
/* 1426 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/* 1427 */           } else if (escape == -2) {
/* 1428 */             SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1429 */             if (esc == null) {
/* 1430 */               throw new JsonGenerationException("Invalid custom escape definitions; custom escape not found for character code 0x" + Integer.toHexString(ch) + ", although was supposed to have one");
/*      */             }
/*      */ 
/* 1433 */             outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */           }
/*      */           else {
/* 1436 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1440 */       else if (ch > maxUnescaped) {
/* 1441 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */       }
/*      */       else {
/* 1444 */         SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1445 */         if (esc != null) {
/* 1446 */           outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */         }
/* 1449 */         else if (ch <= 2047) {
/* 1450 */           outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1451 */           outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */         } else {
/* 1453 */           outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */         }
/*      */       }
/*      */     }
/* 1456 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */   private int _writeCustomEscape(byte[] outputBuffer, int outputPtr, SerializableString esc, int remainingChars)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1462 */     byte[] raw = esc.asUnquotedUTF8();
/* 1463 */     int len = raw.length;
/* 1464 */     if (len > 6) {
/* 1465 */       return _handleLongCustomEscape(outputBuffer, outputPtr, this._outputEnd, raw, remainingChars);
/*      */     }
/*      */ 
/* 1468 */     System.arraycopy(raw, 0, outputBuffer, outputPtr, len);
/* 1469 */     return outputPtr + len;
/*      */   }
/*      */ 
/*      */   private int _handleLongCustomEscape(byte[] outputBuffer, int outputPtr, int outputEnd, byte[] raw, int remainingChars)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1476 */     int len = raw.length;
/* 1477 */     if (outputPtr + len > outputEnd) {
/* 1478 */       this._outputTail = outputPtr;
/* 1479 */       _flushBuffer();
/* 1480 */       outputPtr = this._outputTail;
/* 1481 */       if (len > outputBuffer.length) {
/* 1482 */         this._outputStream.write(raw, 0, len);
/* 1483 */         return outputPtr;
/*      */       }
/* 1485 */       System.arraycopy(raw, 0, outputBuffer, outputPtr, len);
/* 1486 */       outputPtr += len;
/*      */     }
/*      */ 
/* 1489 */     if (outputPtr + 6 * remainingChars > outputEnd) {
/* 1490 */       _flushBuffer();
/* 1491 */       return this._outputTail;
/*      */     }
/* 1493 */     return outputPtr;
/*      */   }
/*      */ 
/*      */   private final void _writeUTF8Segments(byte[] utf8, int offset, int totalLen)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*      */     do
/*      */     {
/* 1511 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1512 */       _writeUTF8Segment(utf8, offset, len);
/* 1513 */       offset += len;
/* 1514 */       totalLen -= len;
/* 1515 */     }while (totalLen > 0);
/*      */   }
/*      */ 
/*      */   private final void _writeUTF8Segment(byte[] utf8, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1522 */     int[] escCodes = this._outputEscapes;
/*      */ 
/* 1524 */     int ptr = offset; for (int end = offset + len; ptr < end; )
/*      */     {
/* 1526 */       int ch = utf8[(ptr++)];
/* 1527 */       if ((ch >= 0) && (escCodes[ch] != 0)) {
/* 1528 */         _writeUTF8Segment2(utf8, offset, len);
/* 1529 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1534 */     if (this._outputTail + len > this._outputEnd) {
/* 1535 */       _flushBuffer();
/*      */     }
/* 1537 */     System.arraycopy(utf8, offset, this._outputBuffer, this._outputTail, len);
/* 1538 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   private final void _writeUTF8Segment2(byte[] utf8, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1544 */     int outputPtr = this._outputTail;
/*      */ 
/* 1547 */     if (outputPtr + len * 6 > this._outputEnd) {
/* 1548 */       _flushBuffer();
/* 1549 */       outputPtr = this._outputTail;
/*      */     }
/*      */ 
/* 1552 */     byte[] outputBuffer = this._outputBuffer;
/* 1553 */     int[] escCodes = this._outputEscapes;
/* 1554 */     len += offset;
/*      */ 
/* 1556 */     while (offset < len) {
/* 1557 */       byte b = utf8[(offset++)];
/* 1558 */       int ch = b;
/* 1559 */       if ((ch < 0) || (escCodes[ch] == 0)) {
/* 1560 */         outputBuffer[(outputPtr++)] = b;
/*      */       }
/*      */       else {
/* 1563 */         int escape = escCodes[ch];
/* 1564 */         if (escape > 0) {
/* 1565 */           outputBuffer[(outputPtr++)] = 92;
/* 1566 */           outputBuffer[(outputPtr++)] = ((byte)escape);
/*      */         }
/*      */         else {
/* 1569 */           outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         }
/*      */       }
/*      */     }
/* 1572 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */   protected void _writeBinary(Base64Variant b64variant, byte[] input, int inputPtr, int inputEnd)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1585 */     int safeInputEnd = inputEnd - 3;
/*      */ 
/* 1587 */     int safeOutputEnd = this._outputEnd - 6;
/* 1588 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/* 1591 */     while (inputPtr <= safeInputEnd) {
/* 1592 */       if (this._outputTail > safeOutputEnd) {
/* 1593 */         _flushBuffer();
/*      */       }
/*      */ 
/* 1596 */       int b24 = input[(inputPtr++)] << 8;
/* 1597 */       b24 |= input[(inputPtr++)] & 0xFF;
/* 1598 */       b24 = b24 << 8 | input[(inputPtr++)] & 0xFF;
/* 1599 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1600 */       chunksBeforeLF--; if (chunksBeforeLF <= 0)
/*      */       {
/* 1602 */         this._outputBuffer[(this._outputTail++)] = 92;
/* 1603 */         this._outputBuffer[(this._outputTail++)] = 110;
/* 1604 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1609 */     int inputLeft = inputEnd - inputPtr;
/* 1610 */     if (inputLeft > 0) {
/* 1611 */       if (this._outputTail > safeOutputEnd) {
/* 1612 */         _flushBuffer();
/*      */       }
/* 1614 */       int b24 = input[(inputPtr++)] << 16;
/* 1615 */       if (inputLeft == 2) {
/* 1616 */         b24 |= (input[(inputPtr++)] & 0xFF) << 8;
/*      */       }
/* 1618 */       this._outputTail = b64variant.encodeBase64Partial(b24, inputLeft, this._outputBuffer, this._outputTail);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final int _outputRawMultiByteChar(int ch, char[] cbuf, int inputOffset, int inputLen)
/*      */     throws IOException
/*      */   {
/* 1637 */     if ((ch >= 55296) && 
/* 1638 */       (ch <= 57343))
/*      */     {
/* 1640 */       if (inputOffset >= inputLen) {
/* 1641 */         _reportError("Split surrogate on writeRaw() input (last character)");
/*      */       }
/* 1643 */       _outputSurrogates(ch, cbuf[inputOffset]);
/* 1644 */       return inputOffset + 1;
/*      */     }
/*      */ 
/* 1647 */     byte[] bbuf = this._outputBuffer;
/* 1648 */     bbuf[(this._outputTail++)] = ((byte)(0xE0 | ch >> 12));
/* 1649 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | ch >> 6 & 0x3F));
/* 1650 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/* 1651 */     return inputOffset;
/*      */   }
/*      */ 
/*      */   protected final void _outputSurrogates(int surr1, int surr2)
/*      */     throws IOException
/*      */   {
/* 1657 */     int c = _decodeSurrogate(surr1, surr2);
/* 1658 */     if (this._outputTail + 4 > this._outputEnd) {
/* 1659 */       _flushBuffer();
/*      */     }
/* 1661 */     byte[] bbuf = this._outputBuffer;
/* 1662 */     bbuf[(this._outputTail++)] = ((byte)(0xF0 | c >> 18));
/* 1663 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 1664 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 1665 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | c & 0x3F));
/*      */   }
/*      */ 
/*      */   private final int _outputMultiByteChar(int ch, int outputPtr)
/*      */     throws IOException
/*      */   {
/* 1680 */     byte[] bbuf = this._outputBuffer;
/* 1681 */     if ((ch >= 55296) && (ch <= 57343)) {
/* 1682 */       bbuf[(outputPtr++)] = 92;
/* 1683 */       bbuf[(outputPtr++)] = 117;
/*      */ 
/* 1685 */       bbuf[(outputPtr++)] = HEX_CHARS[(ch >> 12 & 0xF)];
/* 1686 */       bbuf[(outputPtr++)] = HEX_CHARS[(ch >> 8 & 0xF)];
/* 1687 */       bbuf[(outputPtr++)] = HEX_CHARS[(ch >> 4 & 0xF)];
/* 1688 */       bbuf[(outputPtr++)] = HEX_CHARS[(ch & 0xF)];
/*      */     } else {
/* 1690 */       bbuf[(outputPtr++)] = ((byte)(0xE0 | ch >> 12));
/* 1691 */       bbuf[(outputPtr++)] = ((byte)(0x80 | ch >> 6 & 0x3F));
/* 1692 */       bbuf[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */     }
/* 1694 */     return outputPtr;
/*      */   }
/*      */ 
/*      */   protected final int _decodeSurrogate(int surr1, int surr2)
/*      */     throws IOException
/*      */   {
/* 1700 */     if ((surr2 < 56320) || (surr2 > 57343)) {
/* 1701 */       String msg = "Incomplete surrogate pair: first char 0x" + Integer.toHexString(surr1) + ", second 0x" + Integer.toHexString(surr2);
/* 1702 */       _reportError(msg);
/*      */     }
/* 1704 */     int c = 65536 + (surr1 - 55296 << 10) + (surr2 - 56320);
/* 1705 */     return c;
/*      */   }
/*      */ 
/*      */   private final void _writeNull() throws IOException
/*      */   {
/* 1710 */     if (this._outputTail + 4 >= this._outputEnd) {
/* 1711 */       _flushBuffer();
/*      */     }
/* 1713 */     System.arraycopy(NULL_BYTES, 0, this._outputBuffer, this._outputTail, 4);
/* 1714 */     this._outputTail += 4;
/*      */   }
/*      */ 
/*      */   private int _writeGenericEscape(int charToEscape, int outputPtr)
/*      */     throws IOException
/*      */   {
/* 1725 */     byte[] bbuf = this._outputBuffer;
/* 1726 */     bbuf[(outputPtr++)] = 92;
/* 1727 */     bbuf[(outputPtr++)] = 117;
/* 1728 */     if (charToEscape > 255) {
/* 1729 */       int hi = charToEscape >> 8 & 0xFF;
/* 1730 */       bbuf[(outputPtr++)] = HEX_CHARS[(hi >> 4)];
/* 1731 */       bbuf[(outputPtr++)] = HEX_CHARS[(hi & 0xF)];
/* 1732 */       charToEscape &= 255;
/*      */     } else {
/* 1734 */       bbuf[(outputPtr++)] = 48;
/* 1735 */       bbuf[(outputPtr++)] = 48;
/*      */     }
/*      */ 
/* 1738 */     bbuf[(outputPtr++)] = HEX_CHARS[(charToEscape >> 4)];
/* 1739 */     bbuf[(outputPtr++)] = HEX_CHARS[(charToEscape & 0xF)];
/* 1740 */     return outputPtr;
/*      */   }
/*      */ 
/*      */   protected final void _flushBuffer() throws IOException
/*      */   {
/* 1745 */     int len = this._outputTail;
/* 1746 */     if (len > 0) {
/* 1747 */       this._outputTail = 0;
/* 1748 */       this._outputStream.write(this._outputBuffer, 0, len);
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.impl.Utf8Generator
 * JD-Core Version:    0.6.2
 */