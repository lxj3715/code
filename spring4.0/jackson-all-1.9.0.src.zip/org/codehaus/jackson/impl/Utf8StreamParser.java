/*      */ package org.codehaus.jackson.impl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import org.codehaus.jackson.Base64Variant;
/*      */ import org.codehaus.jackson.JsonParseException;
/*      */ import org.codehaus.jackson.JsonParser.Feature;
/*      */ import org.codehaus.jackson.JsonToken;
/*      */ import org.codehaus.jackson.ObjectCodec;
/*      */ import org.codehaus.jackson.SerializableString;
/*      */ import org.codehaus.jackson.io.IOContext;
/*      */ import org.codehaus.jackson.sym.BytesToNameCanonicalizer;
/*      */ import org.codehaus.jackson.sym.Name;
/*      */ import org.codehaus.jackson.util.ByteArrayBuilder;
/*      */ import org.codehaus.jackson.util.CharTypes;
/*      */ import org.codehaus.jackson.util.TextBuffer;
/*      */ 
/*      */ public final class Utf8StreamParser extends JsonParserBase
/*      */ {
/*      */   static final byte BYTE_LF = 10;
/*   19 */   private static final int[] sInputCodesUtf8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*   25 */   private static final int[] sInputCodesLatin1 = CharTypes.getInputCodeLatin1();
/*      */   protected ObjectCodec _objectCodec;
/*      */   protected final BytesToNameCanonicalizer _symbols;
/*   54 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*   61 */   protected boolean _tokenIncomplete = false;
/*      */   private int _quad1;
/*      */   protected InputStream _inputStream;
/*      */   protected byte[] _inputBuffer;
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */   public Utf8StreamParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, BytesToNameCanonicalizer sym, byte[] inputBuffer, int start, int end, boolean bufferRecyclable)
/*      */   {
/*  109 */     super(ctxt, features);
/*  110 */     this._inputStream = in;
/*  111 */     this._objectCodec = codec;
/*  112 */     this._symbols = sym;
/*  113 */     this._inputBuffer = inputBuffer;
/*  114 */     this._inputPtr = start;
/*  115 */     this._inputEnd = end;
/*  116 */     this._bufferRecyclable = bufferRecyclable;
/*      */ 
/*  118 */     if (!JsonParser.Feature.CANONICALIZE_FIELD_NAMES.enabledIn(features))
/*      */     {
/*  120 */       _throwInternal();
/*      */     }
/*      */   }
/*      */ 
/*      */   public ObjectCodec getCodec()
/*      */   {
/*  126 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   public void setCodec(ObjectCodec c)
/*      */   {
/*  131 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */   public int releaseBuffered(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  143 */     int count = this._inputEnd - this._inputPtr;
/*  144 */     if (count < 1) {
/*  145 */       return 0;
/*      */     }
/*      */ 
/*  148 */     int origPtr = this._inputPtr;
/*  149 */     out.write(this._inputBuffer, origPtr, count);
/*  150 */     return count;
/*      */   }
/*      */ 
/*      */   public Object getInputSource()
/*      */   {
/*  155 */     return this._inputStream;
/*      */   }
/*      */ 
/*      */   protected final boolean loadMore()
/*      */     throws IOException
/*      */   {
/*  168 */     this._currInputProcessed += this._inputEnd;
/*  169 */     this._currInputRowStart -= this._inputEnd;
/*      */ 
/*  171 */     if (this._inputStream != null) {
/*  172 */       int count = this._inputStream.read(this._inputBuffer, 0, this._inputBuffer.length);
/*  173 */       if (count > 0) {
/*  174 */         this._inputPtr = 0;
/*  175 */         this._inputEnd = count;
/*  176 */         return true;
/*      */       }
/*      */ 
/*  179 */       _closeInput();
/*      */ 
/*  181 */       if (count == 0) {
/*  182 */         throw new IOException("InputStream.read() returned 0 characters when trying to read " + this._inputBuffer.length + " bytes");
/*      */       }
/*      */     }
/*  185 */     return false;
/*      */   }
/*      */ 
/*      */   protected final boolean _loadToHaveAtLeast(int minAvailable)
/*      */     throws IOException
/*      */   {
/*  198 */     if (this._inputStream == null) {
/*  199 */       return false;
/*      */     }
/*      */ 
/*  202 */     int amount = this._inputEnd - this._inputPtr;
/*  203 */     if ((amount > 0) && (this._inputPtr > 0)) {
/*  204 */       this._currInputProcessed += this._inputPtr;
/*  205 */       this._currInputRowStart -= this._inputPtr;
/*  206 */       System.arraycopy(this._inputBuffer, this._inputPtr, this._inputBuffer, 0, amount);
/*  207 */       this._inputEnd = amount;
/*      */     } else {
/*  209 */       this._inputEnd = 0;
/*      */     }
/*  211 */     this._inputPtr = 0;
/*  212 */     while (this._inputEnd < minAvailable) {
/*  213 */       int count = this._inputStream.read(this._inputBuffer, this._inputEnd, this._inputBuffer.length - this._inputEnd);
/*  214 */       if (count < 1)
/*      */       {
/*  216 */         _closeInput();
/*      */ 
/*  218 */         if (count == 0) {
/*  219 */           throw new IOException("InputStream.read() returned 0 characters when trying to read " + amount + " bytes");
/*      */         }
/*  221 */         return false;
/*      */       }
/*  223 */       this._inputEnd += count;
/*      */     }
/*  225 */     return true;
/*      */   }
/*      */ 
/*      */   protected void _closeInput()
/*      */     throws IOException
/*      */   {
/*  235 */     if (this._inputStream != null) {
/*  236 */       if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE))) {
/*  237 */         this._inputStream.close();
/*      */       }
/*  239 */       this._inputStream = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */     throws IOException
/*      */   {
/*  252 */     super._releaseBuffers();
/*  253 */     if (this._bufferRecyclable) {
/*  254 */       byte[] buf = this._inputBuffer;
/*  255 */       if (buf != null) {
/*  256 */         this._inputBuffer = null;
/*  257 */         this._ioContext.releaseReadIOBuffer(buf);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getText()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  272 */     JsonToken t = this._currToken;
/*  273 */     if (t == JsonToken.VALUE_STRING) {
/*  274 */       if (this._tokenIncomplete) {
/*  275 */         this._tokenIncomplete = false;
/*  276 */         _finishString();
/*      */       }
/*  278 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  280 */     return _getText2(t);
/*      */   }
/*      */ 
/*      */   protected final String _getText2(JsonToken t)
/*      */   {
/*  285 */     if (t == null) {
/*  286 */       return null;
/*      */     }
/*  288 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[t.ordinal()]) {
/*      */     case 1:
/*  290 */       return this._parsingContext.getCurrentName();
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*  296 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  298 */     return t.asString();
/*      */   }
/*      */ 
/*      */   public char[] getTextCharacters()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  305 */     if (this._currToken != null) {
/*  306 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[this._currToken.ordinal()])
/*      */       {
/*      */       case 1:
/*  309 */         if (!this._nameCopied) {
/*  310 */           String name = this._parsingContext.getCurrentName();
/*  311 */           int nameLen = name.length();
/*  312 */           if (this._nameCopyBuffer == null)
/*  313 */             this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  314 */           else if (this._nameCopyBuffer.length < nameLen) {
/*  315 */             this._nameCopyBuffer = new char[nameLen];
/*      */           }
/*  317 */           name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  318 */           this._nameCopied = true;
/*      */         }
/*  320 */         return this._nameCopyBuffer;
/*      */       case 2:
/*  323 */         if (this._tokenIncomplete) {
/*  324 */           this._tokenIncomplete = false;
/*  325 */           _finishString();
/*      */         }
/*      */ 
/*      */       case 3:
/*      */       case 4:
/*  330 */         return this._textBuffer.getTextBuffer();
/*      */       }
/*      */ 
/*  333 */       return this._currToken.asCharArray();
/*      */     }
/*      */ 
/*  336 */     return null;
/*      */   }
/*      */ 
/*      */   public int getTextLength()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  343 */     if (this._currToken != null) {
/*  344 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[this._currToken.ordinal()])
/*      */       {
/*      */       case 1:
/*  347 */         return this._parsingContext.getCurrentName().length();
/*      */       case 2:
/*  349 */         if (this._tokenIncomplete) {
/*  350 */           this._tokenIncomplete = false;
/*  351 */           _finishString();
/*      */         }
/*      */ 
/*      */       case 3:
/*      */       case 4:
/*  356 */         return this._textBuffer.size();
/*      */       }
/*      */ 
/*  359 */       return this._currToken.asCharArray().length;
/*      */     }
/*      */ 
/*  362 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getTextOffset()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  369 */     if (this._currToken != null) {
/*  370 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[this._currToken.ordinal()]) {
/*      */       case 1:
/*  372 */         return 0;
/*      */       case 2:
/*  374 */         if (this._tokenIncomplete) {
/*  375 */           this._tokenIncomplete = false;
/*  376 */           _finishString();
/*      */         }
/*      */ 
/*      */       case 3:
/*      */       case 4:
/*  381 */         return this._textBuffer.getTextOffset();
/*      */       }
/*      */     }
/*  384 */     return 0;
/*      */   }
/*      */ 
/*      */   public byte[] getBinaryValue(Base64Variant b64variant)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  391 */     if ((this._currToken != JsonToken.VALUE_STRING) && ((this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT) || (this._binaryValue == null)))
/*      */     {
/*  393 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */ 
/*  398 */     if (this._tokenIncomplete) {
/*      */       try {
/*  400 */         this._binaryValue = _decodeBase64(b64variant);
/*      */       } catch (IllegalArgumentException iae) {
/*  402 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       }
/*      */ 
/*  407 */       this._tokenIncomplete = false;
/*      */     }
/*  409 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */   public JsonToken nextToken()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  426 */     this._numTypesValid = 0;
/*      */ 
/*  431 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  432 */       return _nextAfterName();
/*      */     }
/*  434 */     if (this._tokenIncomplete) {
/*  435 */       _skipString();
/*      */     }
/*      */ 
/*  438 */     int i = _skipWSOrEnd();
/*  439 */     if (i < 0)
/*      */     {
/*  443 */       close();
/*  444 */       return this._currToken = null;
/*      */     }
/*      */ 
/*  450 */     this._tokenInputTotal = (this._currInputProcessed + this._inputPtr - 1L);
/*  451 */     this._tokenInputRow = this._currInputRow;
/*  452 */     this._tokenInputCol = (this._inputPtr - this._currInputRowStart - 1);
/*      */ 
/*  455 */     this._binaryValue = null;
/*      */ 
/*  458 */     if (i == 93) {
/*  459 */       if (!this._parsingContext.inArray()) {
/*  460 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/*  462 */       this._parsingContext = this._parsingContext.getParent();
/*  463 */       return this._currToken = JsonToken.END_ARRAY;
/*      */     }
/*  465 */     if (i == 125) {
/*  466 */       if (!this._parsingContext.inObject()) {
/*  467 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/*  469 */       this._parsingContext = this._parsingContext.getParent();
/*  470 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     }
/*      */ 
/*  474 */     if (this._parsingContext.expectComma()) {
/*  475 */       if (i != 44) {
/*  476 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.getTypeDesc() + " entries");
/*      */       }
/*  478 */       i = _skipWS();
/*      */     }
/*      */ 
/*  485 */     if (!this._parsingContext.inObject()) {
/*  486 */       return _nextTokenNotInObject(i);
/*      */     }
/*      */ 
/*  489 */     Name n = _parseFieldName(i);
/*  490 */     this._parsingContext.setCurrentName(n.getName());
/*  491 */     this._currToken = JsonToken.FIELD_NAME;
/*  492 */     i = _skipWS();
/*  493 */     if (i != 58) {
/*  494 */       _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */     }
/*  496 */     i = _skipWS();
/*      */ 
/*  499 */     if (i == 34) {
/*  500 */       this._tokenIncomplete = true;
/*  501 */       this._nextToken = JsonToken.VALUE_STRING;
/*  502 */       return this._currToken;
/*      */     }
/*      */     JsonToken t;
/*  506 */     switch (i) {
/*      */     case 91:
/*  508 */       t = JsonToken.START_ARRAY;
/*  509 */       break;
/*      */     case 123:
/*  511 */       t = JsonToken.START_OBJECT;
/*  512 */       break;
/*      */     case 93:
/*      */     case 125:
/*  517 */       _reportUnexpectedChar(i, "expected a value");
/*      */     case 116:
/*  519 */       _matchToken("true", 1);
/*  520 */       t = JsonToken.VALUE_TRUE;
/*  521 */       break;
/*      */     case 102:
/*  523 */       _matchToken("false", 1);
/*  524 */       t = JsonToken.VALUE_FALSE;
/*  525 */       break;
/*      */     case 110:
/*  527 */       _matchToken("null", 1);
/*  528 */       t = JsonToken.VALUE_NULL;
/*  529 */       break;
/*      */     case 45:
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 56:
/*      */     case 57:
/*  546 */       t = parseNumberText(i);
/*  547 */       break;
/*      */     default:
/*  549 */       t = _handleUnexpectedValue(i);
/*      */     }
/*  551 */     this._nextToken = t;
/*  552 */     return this._currToken;
/*      */   }
/*      */ 
/*      */   private final JsonToken _nextTokenNotInObject(int i)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  558 */     if (i == 34) {
/*  559 */       this._tokenIncomplete = true;
/*  560 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     }
/*  562 */     switch (i) {
/*      */     case 91:
/*  564 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  565 */       return this._currToken = JsonToken.START_ARRAY;
/*      */     case 123:
/*  567 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  568 */       return this._currToken = JsonToken.START_OBJECT;
/*      */     case 93:
/*      */     case 125:
/*  573 */       _reportUnexpectedChar(i, "expected a value");
/*      */     case 116:
/*  575 */       _matchToken("true", 1);
/*  576 */       return this._currToken = JsonToken.VALUE_TRUE;
/*      */     case 102:
/*  578 */       _matchToken("false", 1);
/*  579 */       return this._currToken = JsonToken.VALUE_FALSE;
/*      */     case 110:
/*  581 */       _matchToken("null", 1);
/*  582 */       return this._currToken = JsonToken.VALUE_NULL;
/*      */     case 45:
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 56:
/*      */     case 57:
/*  598 */       return this._currToken = parseNumberText(i);
/*      */     }
/*  600 */     return this._currToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */   private final JsonToken _nextAfterName()
/*      */   {
/*  605 */     this._nameCopied = false;
/*  606 */     JsonToken t = this._nextToken;
/*  607 */     this._nextToken = null;
/*      */ 
/*  609 */     if (t == JsonToken.START_ARRAY)
/*  610 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  611 */     else if (t == JsonToken.START_OBJECT) {
/*  612 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     }
/*  614 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  620 */     super.close();
/*      */ 
/*  622 */     this._symbols.release();
/*      */   }
/*      */ 
/*      */   public boolean nextFieldName(SerializableString str)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  637 */     this._numTypesValid = 0;
/*  638 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  639 */       _nextAfterName();
/*  640 */       return false;
/*      */     }
/*  642 */     if (this._tokenIncomplete) {
/*  643 */       _skipString();
/*      */     }
/*  645 */     int i = _skipWSOrEnd();
/*  646 */     if (i < 0) {
/*  647 */       close();
/*  648 */       this._currToken = null;
/*  649 */       return false;
/*      */     }
/*  651 */     this._tokenInputTotal = (this._currInputProcessed + this._inputPtr - 1L);
/*  652 */     this._tokenInputRow = this._currInputRow;
/*  653 */     this._tokenInputCol = (this._inputPtr - this._currInputRowStart - 1);
/*      */ 
/*  656 */     this._binaryValue = null;
/*      */ 
/*  659 */     if (i == 93) {
/*  660 */       if (!this._parsingContext.inArray()) {
/*  661 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/*  663 */       this._parsingContext = this._parsingContext.getParent();
/*  664 */       this._currToken = JsonToken.END_ARRAY;
/*  665 */       return false;
/*      */     }
/*  667 */     if (i == 125) {
/*  668 */       if (!this._parsingContext.inObject()) {
/*  669 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/*  671 */       this._parsingContext = this._parsingContext.getParent();
/*  672 */       this._currToken = JsonToken.END_OBJECT;
/*  673 */       return false;
/*      */     }
/*      */ 
/*  677 */     if (this._parsingContext.expectComma()) {
/*  678 */       if (i != 44) {
/*  679 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.getTypeDesc() + " entries");
/*      */       }
/*  681 */       i = _skipWS();
/*      */     }
/*      */ 
/*  684 */     if (!this._parsingContext.inObject()) {
/*  685 */       _nextTokenNotInObject(i);
/*  686 */       return false;
/*      */     }
/*      */ 
/*  690 */     if (i == 34)
/*      */     {
/*  692 */       byte[] nameBytes = str.asQuotedUTF8();
/*  693 */       int len = nameBytes.length;
/*  694 */       if (this._inputPtr + len < this._inputEnd)
/*      */       {
/*  696 */         int end = this._inputPtr + len;
/*  697 */         if (this._inputBuffer[end] == 34) {
/*  698 */           int offset = 0;
/*  699 */           int ptr = this._inputPtr;
/*      */           while (true) {
/*  701 */             if (offset == len) {
/*  702 */               this._inputPtr = (end + 1);
/*      */ 
/*  704 */               this._parsingContext.setCurrentName(str.getValue());
/*  705 */               this._currToken = JsonToken.FIELD_NAME;
/*      */ 
/*  707 */               _isNextTokenNameYes();
/*  708 */               return true;
/*      */             }
/*  710 */             if (nameBytes[offset] != this._inputBuffer[(ptr + offset)]) {
/*      */               break;
/*      */             }
/*  713 */             offset++;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  718 */     _isNextTokenNameNo(i);
/*  719 */     return false;
/*      */   }
/*      */ 
/*      */   private final void _isNextTokenNameYes()
/*      */     throws IOException, JsonParseException
/*      */   {
/*      */     int i;
/*  727 */     if ((this._inputPtr < this._inputEnd) && (this._inputBuffer[this._inputPtr] == 58)) {
/*  728 */       this._inputPtr += 1;
/*  729 */       int i = this._inputBuffer[(this._inputPtr++)];
/*  730 */       if (i == 34) {
/*  731 */         this._tokenIncomplete = true;
/*  732 */         this._nextToken = JsonToken.VALUE_STRING;
/*  733 */         return;
/*      */       }
/*  735 */       if (i == 123) {
/*  736 */         this._nextToken = JsonToken.START_OBJECT;
/*  737 */         return;
/*      */       }
/*  739 */       if (i == 91) {
/*  740 */         this._nextToken = JsonToken.START_ARRAY;
/*  741 */         return;
/*      */       }
/*  743 */       i &= 255;
/*  744 */       if ((i <= 32) || (i == 47)) {
/*  745 */         this._inputPtr -= 1;
/*  746 */         i = _skipWS();
/*      */       }
/*      */     } else {
/*  749 */       i = _skipColon();
/*      */     }
/*  751 */     switch (i) {
/*      */     case 34:
/*  753 */       this._tokenIncomplete = true;
/*  754 */       this._nextToken = JsonToken.VALUE_STRING;
/*  755 */       return;
/*      */     case 91:
/*  757 */       this._nextToken = JsonToken.START_ARRAY;
/*  758 */       return;
/*      */     case 123:
/*  760 */       this._nextToken = JsonToken.START_OBJECT;
/*  761 */       return;
/*      */     case 93:
/*      */     case 125:
/*  764 */       _reportUnexpectedChar(i, "expected a value");
/*      */     case 116:
/*  766 */       _matchToken("true", 1);
/*  767 */       this._nextToken = JsonToken.VALUE_TRUE;
/*  768 */       return;
/*      */     case 102:
/*  770 */       _matchToken("false", 1);
/*  771 */       this._nextToken = JsonToken.VALUE_FALSE;
/*  772 */       return;
/*      */     case 110:
/*  774 */       _matchToken("null", 1);
/*  775 */       this._nextToken = JsonToken.VALUE_NULL;
/*  776 */       return;
/*      */     case 45:
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 56:
/*      */     case 57:
/*  788 */       this._nextToken = parseNumberText(i);
/*  789 */       return;
/*      */     }
/*  791 */     this._nextToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */   private final void _isNextTokenNameNo(int i)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  799 */     Name n = _parseFieldName(i);
/*  800 */     this._parsingContext.setCurrentName(n.getName());
/*  801 */     this._currToken = JsonToken.FIELD_NAME;
/*  802 */     i = _skipWS();
/*  803 */     if (i != 58) {
/*  804 */       _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */     }
/*  806 */     i = _skipWS();
/*      */ 
/*  809 */     if (i == 34) {
/*  810 */       this._tokenIncomplete = true;
/*  811 */       this._nextToken = JsonToken.VALUE_STRING;
/*      */       return;
/*      */     }
/*      */     JsonToken t;
/*  816 */     switch (i) {
/*      */     case 91:
/*  818 */       t = JsonToken.START_ARRAY;
/*  819 */       break;
/*      */     case 123:
/*  821 */       t = JsonToken.START_OBJECT;
/*  822 */       break;
/*      */     case 93:
/*      */     case 125:
/*  825 */       _reportUnexpectedChar(i, "expected a value");
/*      */     case 116:
/*  827 */       _matchToken("true", 1);
/*  828 */       t = JsonToken.VALUE_TRUE;
/*  829 */       break;
/*      */     case 102:
/*  831 */       _matchToken("false", 1);
/*  832 */       t = JsonToken.VALUE_FALSE;
/*  833 */       break;
/*      */     case 110:
/*  835 */       _matchToken("null", 1);
/*  836 */       t = JsonToken.VALUE_NULL;
/*  837 */       break;
/*      */     case 45:
/*      */     case 48:
/*      */     case 49:
/*      */     case 50:
/*      */     case 51:
/*      */     case 52:
/*      */     case 53:
/*      */     case 54:
/*      */     case 55:
/*      */     case 56:
/*      */     case 57:
/*  850 */       t = parseNumberText(i);
/*  851 */       break;
/*      */     default:
/*  853 */       t = _handleUnexpectedValue(i);
/*      */     }
/*  855 */     this._nextToken = t;
/*      */   }
/*      */ 
/*      */   public String nextTextValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  863 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  864 */       this._nameCopied = false;
/*  865 */       JsonToken t = this._nextToken;
/*  866 */       this._nextToken = null;
/*  867 */       this._currToken = t;
/*  868 */       if (t == JsonToken.VALUE_STRING) {
/*  869 */         if (this._tokenIncomplete) {
/*  870 */           this._tokenIncomplete = false;
/*  871 */           _finishString();
/*      */         }
/*  873 */         return this._textBuffer.contentsAsString();
/*      */       }
/*  875 */       if (t == JsonToken.START_ARRAY)
/*  876 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  877 */       else if (t == JsonToken.START_OBJECT) {
/*  878 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  880 */       return null;
/*      */     }
/*      */ 
/*  883 */     return nextToken() == JsonToken.VALUE_STRING ? getText() : null;
/*      */   }
/*      */ 
/*      */   public int nextIntValue(int defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  891 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  892 */       this._nameCopied = false;
/*  893 */       JsonToken t = this._nextToken;
/*  894 */       this._nextToken = null;
/*  895 */       this._currToken = t;
/*  896 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  897 */         return getIntValue();
/*      */       }
/*  899 */       if (t == JsonToken.START_ARRAY)
/*  900 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  901 */       else if (t == JsonToken.START_OBJECT) {
/*  902 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  904 */       return defaultValue;
/*      */     }
/*      */ 
/*  907 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */   public long nextLongValue(long defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  915 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  916 */       this._nameCopied = false;
/*  917 */       JsonToken t = this._nextToken;
/*  918 */       this._nextToken = null;
/*  919 */       this._currToken = t;
/*  920 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  921 */         return getLongValue();
/*      */       }
/*  923 */       if (t == JsonToken.START_ARRAY)
/*  924 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  925 */       else if (t == JsonToken.START_OBJECT) {
/*  926 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  928 */       return defaultValue;
/*      */     }
/*      */ 
/*  931 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */   public Boolean nextBooleanValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  939 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  940 */       this._nameCopied = false;
/*  941 */       JsonToken t = this._nextToken;
/*  942 */       this._nextToken = null;
/*  943 */       this._currToken = t;
/*  944 */       if (t == JsonToken.VALUE_TRUE) {
/*  945 */         return Boolean.TRUE;
/*      */       }
/*  947 */       if (t == JsonToken.VALUE_FALSE) {
/*  948 */         return Boolean.FALSE;
/*      */       }
/*  950 */       if (t == JsonToken.START_ARRAY)
/*  951 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  952 */       else if (t == JsonToken.START_OBJECT) {
/*  953 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  955 */       return null;
/*      */     }
/*  957 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[nextToken().ordinal()]) {
/*      */     case 5:
/*  959 */       return Boolean.TRUE;
/*      */     case 6:
/*  961 */       return Boolean.FALSE;
/*      */     }
/*  963 */     return null;
/*      */   }
/*      */ 
/*      */   protected final JsonToken parseNumberText(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  991 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*  992 */     int outPtr = 0;
/*  993 */     boolean negative = c == 45;
/*      */ 
/*  996 */     if (negative) {
/*  997 */       outBuf[(outPtr++)] = '-';
/*      */ 
/*  999 */       if (this._inputPtr >= this._inputEnd) {
/* 1000 */         loadMoreGuaranteed();
/*      */       }
/* 1002 */       c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */ 
/* 1004 */       if ((c < 48) || (c > 57)) {
/* 1005 */         return _handleInvalidNumberStart(c, true);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1010 */     if (c == 48) {
/* 1011 */       c = _verifyNoLeadingZeroes();
/*      */     }
/*      */ 
/* 1015 */     outBuf[(outPtr++)] = ((char)c);
/* 1016 */     int intLen = 1;
/*      */ 
/* 1019 */     int end = this._inputPtr + outBuf.length;
/* 1020 */     if (end > this._inputEnd) {
/* 1021 */       end = this._inputEnd;
/*      */     }
/*      */ 
/*      */     while (true)
/*      */     {
/* 1026 */       if (this._inputPtr >= end)
/*      */       {
/* 1028 */         return _parserNumber2(outBuf, outPtr, negative, intLen);
/*      */       }
/* 1030 */       c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1031 */       if ((c < 48) || (c > 57)) {
/*      */         break;
/*      */       }
/* 1034 */       intLen++;
/* 1035 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 1037 */     if ((c == 46) || (c == 101) || (c == 69)) {
/* 1038 */       return _parseFloatText(outBuf, outPtr, c, negative, intLen);
/*      */     }
/*      */ 
/* 1041 */     this._inputPtr -= 1;
/* 1042 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/* 1045 */     return resetInt(negative, intLen);
/*      */   }
/*      */ 
/*      */   private final JsonToken _parserNumber2(char[] outBuf, int outPtr, boolean negative, int intPartLength)
/*      */     throws IOException, JsonParseException
/*      */   {
/*      */     while (true)
/*      */     {
/* 1058 */       if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/* 1059 */         this._textBuffer.setCurrentLength(outPtr);
/* 1060 */         return resetInt(negative, intPartLength);
/*      */       }
/* 1062 */       int c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1063 */       if ((c > 57) || (c < 48)) {
/* 1064 */         if ((c != 46) && (c != 101) && (c != 69)) break;
/* 1065 */         return _parseFloatText(outBuf, outPtr, c, negative, intPartLength);
/*      */       }
/*      */ 
/* 1069 */       if (outPtr >= outBuf.length) {
/* 1070 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1071 */         outPtr = 0;
/*      */       }
/* 1073 */       outBuf[(outPtr++)] = ((char)c);
/* 1074 */       intPartLength++;
/*      */     }
/* 1076 */     this._inputPtr -= 1;
/* 1077 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/* 1080 */     return resetInt(negative, intPartLength);
/*      */   }
/*      */ 
/*      */   private final int _verifyNoLeadingZeroes()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1092 */     if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/* 1093 */       return 48;
/*      */     }
/* 1095 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */ 
/* 1097 */     if ((ch < 48) || (ch > 57)) {
/* 1098 */       return 48;
/*      */     }
/*      */ 
/* 1101 */     if (!isEnabled(JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS)) {
/* 1102 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */ 
/* 1105 */     this._inputPtr += 1;
/* 1106 */     if (ch == 48) {
/* 1107 */       while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 1108 */         ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1109 */         if ((ch < 48) || (ch > 57)) {
/* 1110 */           return 48;
/*      */         }
/* 1112 */         this._inputPtr += 1;
/* 1113 */         if (ch != 48) {
/* 1114 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1118 */     return ch;
/*      */   }
/*      */ 
/*      */   private final JsonToken _parseFloatText(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1125 */     int fractLen = 0;
/* 1126 */     boolean eof = false;
/*      */ 
/* 1129 */     if (c == 46) {
/* 1130 */       outBuf[(outPtr++)] = ((char)c);
/*      */       while (true)
/*      */       {
/* 1134 */         if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/* 1135 */           eof = true;
/* 1136 */           break;
/*      */         }
/* 1138 */         c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1139 */         if ((c < 48) || (c > 57)) {
/*      */           break;
/*      */         }
/* 1142 */         fractLen++;
/* 1143 */         if (outPtr >= outBuf.length) {
/* 1144 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1145 */           outPtr = 0;
/*      */         }
/* 1147 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/*      */ 
/* 1150 */       if (fractLen == 0) {
/* 1151 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     }
/*      */ 
/* 1155 */     int expLen = 0;
/* 1156 */     if ((c == 101) || (c == 69)) {
/* 1157 */       if (outPtr >= outBuf.length) {
/* 1158 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1159 */         outPtr = 0;
/*      */       }
/* 1161 */       outBuf[(outPtr++)] = ((char)c);
/*      */ 
/* 1163 */       if (this._inputPtr >= this._inputEnd) {
/* 1164 */         loadMoreGuaranteed();
/*      */       }
/* 1166 */       c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */ 
/* 1168 */       if ((c == 45) || (c == 43)) {
/* 1169 */         if (outPtr >= outBuf.length) {
/* 1170 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1171 */           outPtr = 0;
/*      */         }
/* 1173 */         outBuf[(outPtr++)] = ((char)c);
/*      */ 
/* 1175 */         if (this._inputPtr >= this._inputEnd) {
/* 1176 */           loadMoreGuaranteed();
/*      */         }
/* 1178 */         c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */       }
/*      */ 
/* 1182 */       while ((c <= 57) && (c >= 48)) {
/* 1183 */         expLen++;
/* 1184 */         if (outPtr >= outBuf.length) {
/* 1185 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1186 */           outPtr = 0;
/*      */         }
/* 1188 */         outBuf[(outPtr++)] = ((char)c);
/* 1189 */         if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/* 1190 */           eof = true;
/* 1191 */           break;
/*      */         }
/* 1193 */         c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */       }
/*      */ 
/* 1196 */       if (expLen == 0) {
/* 1197 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1202 */     if (!eof) {
/* 1203 */       this._inputPtr -= 1;
/*      */     }
/* 1205 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/* 1208 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */   protected final Name _parseFieldName(int i)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1220 */     if (i != 34) {
/* 1221 */       return _handleUnusualFieldName(i);
/*      */     }
/*      */ 
/* 1224 */     if (this._inputPtr + 9 > this._inputEnd) {
/* 1225 */       return slowParseFieldName();
/*      */     }
/*      */ 
/* 1234 */     byte[] input = this._inputBuffer;
/* 1235 */     int[] codes = sInputCodesLatin1;
/*      */ 
/* 1237 */     int q = input[(this._inputPtr++)] & 0xFF;
/*      */ 
/* 1239 */     if (codes[q] == 0) {
/* 1240 */       i = input[(this._inputPtr++)] & 0xFF;
/* 1241 */       if (codes[i] == 0) {
/* 1242 */         q = q << 8 | i;
/* 1243 */         i = input[(this._inputPtr++)] & 0xFF;
/* 1244 */         if (codes[i] == 0) {
/* 1245 */           q = q << 8 | i;
/* 1246 */           i = input[(this._inputPtr++)] & 0xFF;
/* 1247 */           if (codes[i] == 0) {
/* 1248 */             q = q << 8 | i;
/* 1249 */             i = input[(this._inputPtr++)] & 0xFF;
/* 1250 */             if (codes[i] == 0) {
/* 1251 */               this._quad1 = q;
/* 1252 */               return parseMediumFieldName(i, codes);
/*      */             }
/* 1254 */             if (i == 34) {
/* 1255 */               return findName(q, 4);
/*      */             }
/* 1257 */             return parseFieldName(q, i, 4);
/*      */           }
/* 1259 */           if (i == 34) {
/* 1260 */             return findName(q, 3);
/*      */           }
/* 1262 */           return parseFieldName(q, i, 3);
/*      */         }
/* 1264 */         if (i == 34) {
/* 1265 */           return findName(q, 2);
/*      */         }
/* 1267 */         return parseFieldName(q, i, 2);
/*      */       }
/* 1269 */       if (i == 34) {
/* 1270 */         return findName(q, 1);
/*      */       }
/* 1272 */       return parseFieldName(q, i, 1);
/*      */     }
/* 1274 */     if (q == 34) {
/* 1275 */       return BytesToNameCanonicalizer.getEmptyName();
/*      */     }
/* 1277 */     return parseFieldName(0, q, 0);
/*      */   }
/*      */ 
/*      */   protected final Name parseMediumFieldName(int q2, int[] codes)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1284 */     int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1285 */     if (codes[i] != 0) {
/* 1286 */       if (i == 34) {
/* 1287 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1289 */       return parseFieldName(this._quad1, q2, i, 1);
/*      */     }
/* 1291 */     q2 = q2 << 8 | i;
/* 1292 */     i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1293 */     if (codes[i] != 0) {
/* 1294 */       if (i == 34) {
/* 1295 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1297 */       return parseFieldName(this._quad1, q2, i, 2);
/*      */     }
/* 1299 */     q2 = q2 << 8 | i;
/* 1300 */     i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1301 */     if (codes[i] != 0) {
/* 1302 */       if (i == 34) {
/* 1303 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1305 */       return parseFieldName(this._quad1, q2, i, 3);
/*      */     }
/* 1307 */     q2 = q2 << 8 | i;
/* 1308 */     i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1309 */     if (codes[i] != 0) {
/* 1310 */       if (i == 34) {
/* 1311 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1313 */       return parseFieldName(this._quad1, q2, i, 4);
/*      */     }
/* 1315 */     this._quadBuffer[0] = this._quad1;
/* 1316 */     this._quadBuffer[1] = q2;
/* 1317 */     return parseLongFieldName(i);
/*      */   }
/*      */ 
/*      */   protected Name parseLongFieldName(int q)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1324 */     int[] codes = sInputCodesLatin1;
/* 1325 */     int qlen = 2;
/*      */     while (true)
/*      */     {
/* 1332 */       if (this._inputEnd - this._inputPtr < 4) {
/* 1333 */         return parseEscapedFieldName(this._quadBuffer, qlen, 0, q, 0);
/*      */       }
/*      */ 
/* 1337 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1338 */       if (codes[i] != 0) {
/* 1339 */         if (i == 34) {
/* 1340 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1342 */         return parseEscapedFieldName(this._quadBuffer, qlen, q, i, 1);
/*      */       }
/*      */ 
/* 1345 */       q = q << 8 | i;
/* 1346 */       i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1347 */       if (codes[i] != 0) {
/* 1348 */         if (i == 34) {
/* 1349 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1351 */         return parseEscapedFieldName(this._quadBuffer, qlen, q, i, 2);
/*      */       }
/*      */ 
/* 1354 */       q = q << 8 | i;
/* 1355 */       i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1356 */       if (codes[i] != 0) {
/* 1357 */         if (i == 34) {
/* 1358 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1360 */         return parseEscapedFieldName(this._quadBuffer, qlen, q, i, 3);
/*      */       }
/*      */ 
/* 1363 */       q = q << 8 | i;
/* 1364 */       i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1365 */       if (codes[i] != 0) {
/* 1366 */         if (i == 34) {
/* 1367 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1369 */         return parseEscapedFieldName(this._quadBuffer, qlen, q, i, 4);
/*      */       }
/*      */ 
/* 1373 */       if (qlen >= this._quadBuffer.length) {
/* 1374 */         this._quadBuffer = growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1376 */       this._quadBuffer[(qlen++)] = q;
/* 1377 */       q = i;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Name slowParseFieldName()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1389 */     if ((this._inputPtr >= this._inputEnd) && 
/* 1390 */       (!loadMore())) {
/* 1391 */       _reportInvalidEOF(": was expecting closing '\"' for name");
/*      */     }
/*      */ 
/* 1394 */     int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1395 */     if (i == 34) {
/* 1396 */       return BytesToNameCanonicalizer.getEmptyName();
/*      */     }
/* 1398 */     return parseEscapedFieldName(this._quadBuffer, 0, 0, i, 0);
/*      */   }
/*      */ 
/*      */   private final Name parseFieldName(int q1, int ch, int lastQuadBytes)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1404 */     return parseEscapedFieldName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   private final Name parseFieldName(int q1, int q2, int ch, int lastQuadBytes)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1410 */     this._quadBuffer[0] = q1;
/* 1411 */     return parseEscapedFieldName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   protected Name parseEscapedFieldName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1430 */     int[] codes = sInputCodesLatin1;
/*      */     while (true)
/*      */     {
/* 1433 */       if (codes[ch] != 0) {
/* 1434 */         if (ch == 34)
/*      */         {
/*      */           break;
/*      */         }
/* 1438 */         if (ch != 92)
/*      */         {
/* 1440 */           _throwUnquotedSpace(ch, "name");
/*      */         }
/*      */         else {
/* 1443 */           ch = _decodeEscaped();
/*      */         }
/*      */ 
/* 1450 */         if (ch > 127)
/*      */         {
/* 1452 */           if (currQuadBytes >= 4) {
/* 1453 */             if (qlen >= quads.length) {
/* 1454 */               this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */             }
/* 1456 */             quads[(qlen++)] = currQuad;
/* 1457 */             currQuad = 0;
/* 1458 */             currQuadBytes = 0;
/*      */           }
/* 1460 */           if (ch < 2048) {
/* 1461 */             currQuad = currQuad << 8 | (0xC0 | ch >> 6);
/* 1462 */             currQuadBytes++;
/*      */           }
/*      */           else {
/* 1465 */             currQuad = currQuad << 8 | (0xE0 | ch >> 12);
/* 1466 */             currQuadBytes++;
/*      */ 
/* 1468 */             if (currQuadBytes >= 4) {
/* 1469 */               if (qlen >= quads.length) {
/* 1470 */                 this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */               }
/* 1472 */               quads[(qlen++)] = currQuad;
/* 1473 */               currQuad = 0;
/* 1474 */               currQuadBytes = 0;
/*      */             }
/* 1476 */             currQuad = currQuad << 8 | (0x80 | ch >> 6 & 0x3F);
/* 1477 */             currQuadBytes++;
/*      */           }
/*      */ 
/* 1480 */           ch = 0x80 | ch & 0x3F;
/*      */         }
/*      */       }
/*      */ 
/* 1484 */       if (currQuadBytes < 4) {
/* 1485 */         currQuadBytes++;
/* 1486 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1488 */         if (qlen >= quads.length) {
/* 1489 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 1491 */         quads[(qlen++)] = currQuad;
/* 1492 */         currQuad = ch;
/* 1493 */         currQuadBytes = 1;
/*      */       }
/* 1495 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1496 */         (!loadMore())) {
/* 1497 */         _reportInvalidEOF(" in field name");
/*      */       }
/*      */ 
/* 1500 */       ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */     }
/*      */ 
/* 1503 */     if (currQuadBytes > 0) {
/* 1504 */       if (qlen >= quads.length) {
/* 1505 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 1507 */       quads[(qlen++)] = currQuad;
/*      */     }
/* 1509 */     Name name = this._symbols.findName(quads, qlen);
/* 1510 */     if (name == null) {
/* 1511 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1513 */     return name;
/*      */   }
/*      */ 
/*      */   protected final Name _handleUnusualFieldName(int ch)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1526 */     if ((ch == 39) && (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES))) {
/* 1527 */       return _parseApostropheFieldName();
/*      */     }
/*      */ 
/* 1530 */     if (!isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES)) {
/* 1531 */       _reportUnexpectedChar(ch, "was expecting double-quote to start field name");
/*      */     }
/*      */ 
/* 1537 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */ 
/* 1539 */     if (codes[ch] != 0) {
/* 1540 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/* 1547 */     int[] quads = this._quadBuffer;
/* 1548 */     int qlen = 0;
/* 1549 */     int currQuad = 0;
/* 1550 */     int currQuadBytes = 0;
/*      */     while (true)
/*      */     {
/* 1554 */       if (currQuadBytes < 4) {
/* 1555 */         currQuadBytes++;
/* 1556 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1558 */         if (qlen >= quads.length) {
/* 1559 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 1561 */         quads[(qlen++)] = currQuad;
/* 1562 */         currQuad = ch;
/* 1563 */         currQuadBytes = 1;
/*      */       }
/* 1565 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1566 */         (!loadMore())) {
/* 1567 */         _reportInvalidEOF(" in field name");
/*      */       }
/*      */ 
/* 1570 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1571 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 1574 */       this._inputPtr += 1;
/*      */     }
/*      */ 
/* 1577 */     if (currQuadBytes > 0) {
/* 1578 */       if (qlen >= quads.length) {
/* 1579 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 1581 */       quads[(qlen++)] = currQuad;
/*      */     }
/* 1583 */     Name name = this._symbols.findName(quads, qlen);
/* 1584 */     if (name == null) {
/* 1585 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1587 */     return name;
/*      */   }
/*      */ 
/*      */   protected final Name _parseApostropheFieldName()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1598 */     if ((this._inputPtr >= this._inputEnd) && 
/* 1599 */       (!loadMore())) {
/* 1600 */       _reportInvalidEOF(": was expecting closing ''' for name");
/*      */     }
/*      */ 
/* 1603 */     int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1604 */     if (ch == 39) {
/* 1605 */       return BytesToNameCanonicalizer.getEmptyName();
/*      */     }
/* 1607 */     int[] quads = this._quadBuffer;
/* 1608 */     int qlen = 0;
/* 1609 */     int currQuad = 0;
/* 1610 */     int currQuadBytes = 0;
/*      */ 
/* 1614 */     int[] codes = sInputCodesLatin1;
/*      */ 
/* 1617 */     while (ch != 39)
/*      */     {
/* 1621 */       if ((ch != 34) && (codes[ch] != 0)) {
/* 1622 */         if (ch != 92)
/*      */         {
/* 1625 */           _throwUnquotedSpace(ch, "name");
/*      */         }
/*      */         else {
/* 1628 */           ch = _decodeEscaped();
/*      */         }
/*      */ 
/* 1635 */         if (ch > 127)
/*      */         {
/* 1637 */           if (currQuadBytes >= 4) {
/* 1638 */             if (qlen >= quads.length) {
/* 1639 */               this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */             }
/* 1641 */             quads[(qlen++)] = currQuad;
/* 1642 */             currQuad = 0;
/* 1643 */             currQuadBytes = 0;
/*      */           }
/* 1645 */           if (ch < 2048) {
/* 1646 */             currQuad = currQuad << 8 | (0xC0 | ch >> 6);
/* 1647 */             currQuadBytes++;
/*      */           }
/*      */           else {
/* 1650 */             currQuad = currQuad << 8 | (0xE0 | ch >> 12);
/* 1651 */             currQuadBytes++;
/*      */ 
/* 1653 */             if (currQuadBytes >= 4) {
/* 1654 */               if (qlen >= quads.length) {
/* 1655 */                 this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */               }
/* 1657 */               quads[(qlen++)] = currQuad;
/* 1658 */               currQuad = 0;
/* 1659 */               currQuadBytes = 0;
/*      */             }
/* 1661 */             currQuad = currQuad << 8 | (0x80 | ch >> 6 & 0x3F);
/* 1662 */             currQuadBytes++;
/*      */           }
/*      */ 
/* 1665 */           ch = 0x80 | ch & 0x3F;
/*      */         }
/*      */       }
/*      */ 
/* 1669 */       if (currQuadBytes < 4) {
/* 1670 */         currQuadBytes++;
/* 1671 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1673 */         if (qlen >= quads.length) {
/* 1674 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 1676 */         quads[(qlen++)] = currQuad;
/* 1677 */         currQuad = ch;
/* 1678 */         currQuadBytes = 1;
/*      */       }
/* 1680 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1681 */         (!loadMore())) {
/* 1682 */         _reportInvalidEOF(" in field name");
/*      */       }
/*      */ 
/* 1685 */       ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */     }
/*      */ 
/* 1688 */     if (currQuadBytes > 0) {
/* 1689 */       if (qlen >= quads.length) {
/* 1690 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 1692 */       quads[(qlen++)] = currQuad;
/*      */     }
/* 1694 */     Name name = this._symbols.findName(quads, qlen);
/* 1695 */     if (name == null) {
/* 1696 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1698 */     return name;
/*      */   }
/*      */ 
/*      */   private final Name findName(int q1, int lastQuadBytes)
/*      */     throws JsonParseException
/*      */   {
/* 1711 */     Name name = this._symbols.findName(q1);
/* 1712 */     if (name != null) {
/* 1713 */       return name;
/*      */     }
/*      */ 
/* 1716 */     this._quadBuffer[0] = q1;
/* 1717 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   private final Name findName(int q1, int q2, int lastQuadBytes)
/*      */     throws JsonParseException
/*      */   {
/* 1724 */     Name name = this._symbols.findName(q1, q2);
/* 1725 */     if (name != null) {
/* 1726 */       return name;
/*      */     }
/*      */ 
/* 1729 */     this._quadBuffer[0] = q1;
/* 1730 */     this._quadBuffer[1] = q2;
/* 1731 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   private final Name findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes)
/*      */     throws JsonParseException
/*      */   {
/* 1737 */     if (qlen >= quads.length) {
/* 1738 */       this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */     }
/* 1740 */     quads[(qlen++)] = lastQuad;
/* 1741 */     Name name = this._symbols.findName(quads, qlen);
/* 1742 */     if (name == null) {
/* 1743 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 1745 */     return name;
/*      */   }
/*      */ 
/*      */   private final Name addName(int[] quads, int qlen, int lastQuadBytes)
/*      */     throws JsonParseException
/*      */   {
/* 1762 */     int byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */     int lastQuad;
/* 1771 */     if (lastQuadBytes < 4) {
/* 1772 */       int lastQuad = quads[(qlen - 1)];
/*      */ 
/* 1774 */       quads[(qlen - 1)] = (lastQuad << (4 - lastQuadBytes << 3));
/*      */     } else {
/* 1776 */       lastQuad = 0;
/*      */     }
/*      */ 
/* 1780 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1781 */     int cix = 0;
/*      */ 
/* 1783 */     for (int ix = 0; ix < byteLen; ) {
/* 1784 */       int ch = quads[(ix >> 2)];
/* 1785 */       int byteIx = ix & 0x3;
/* 1786 */       ch = ch >> (3 - byteIx << 3) & 0xFF;
/* 1787 */       ix++;
/*      */ 
/* 1789 */       if (ch > 127)
/*      */       {
/*      */         int needed;
/*      */         int needed;
/* 1791 */         if ((ch & 0xE0) == 192) {
/* 1792 */           ch &= 31;
/* 1793 */           needed = 1;
/*      */         }
/*      */         else
/*      */         {
/*      */           int needed;
/* 1794 */           if ((ch & 0xF0) == 224) {
/* 1795 */             ch &= 15;
/* 1796 */             needed = 2;
/*      */           }
/*      */           else
/*      */           {
/*      */             int needed;
/* 1797 */             if ((ch & 0xF8) == 240) {
/* 1798 */               ch &= 7;
/* 1799 */               needed = 3;
/*      */             } else {
/* 1801 */               _reportInvalidInitial(ch);
/* 1802 */               needed = ch = 1;
/*      */             }
/*      */           }
/*      */         }
/* 1804 */         if (ix + needed > byteLen) {
/* 1805 */           _reportInvalidEOF(" in field name");
/*      */         }
/*      */ 
/* 1809 */         int ch2 = quads[(ix >> 2)];
/* 1810 */         byteIx = ix & 0x3;
/* 1811 */         ch2 >>= 3 - byteIx << 3;
/* 1812 */         ix++;
/*      */ 
/* 1814 */         if ((ch2 & 0xC0) != 128) {
/* 1815 */           _reportInvalidOther(ch2);
/*      */         }
/* 1817 */         ch = ch << 6 | ch2 & 0x3F;
/* 1818 */         if (needed > 1) {
/* 1819 */           ch2 = quads[(ix >> 2)];
/* 1820 */           byteIx = ix & 0x3;
/* 1821 */           ch2 >>= 3 - byteIx << 3;
/* 1822 */           ix++;
/*      */ 
/* 1824 */           if ((ch2 & 0xC0) != 128) {
/* 1825 */             _reportInvalidOther(ch2);
/*      */           }
/* 1827 */           ch = ch << 6 | ch2 & 0x3F;
/* 1828 */           if (needed > 2) {
/* 1829 */             ch2 = quads[(ix >> 2)];
/* 1830 */             byteIx = ix & 0x3;
/* 1831 */             ch2 >>= 3 - byteIx << 3;
/* 1832 */             ix++;
/* 1833 */             if ((ch2 & 0xC0) != 128) {
/* 1834 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 1836 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           }
/*      */         }
/* 1839 */         if (needed > 2) {
/* 1840 */           ch -= 65536;
/* 1841 */           if (cix >= cbuf.length) {
/* 1842 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 1844 */           cbuf[(cix++)] = ((char)(55296 + (ch >> 10)));
/* 1845 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         }
/*      */       }
/* 1848 */       if (cix >= cbuf.length) {
/* 1849 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1851 */       cbuf[(cix++)] = ((char)ch);
/*      */     }
/*      */ 
/* 1855 */     String baseName = new String(cbuf, 0, cix);
/*      */ 
/* 1857 */     if (lastQuadBytes < 4) {
/* 1858 */       quads[(qlen - 1)] = lastQuad;
/*      */     }
/* 1860 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */   protected void _finishString()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1874 */     int ptr = this._inputPtr;
/* 1875 */     if (ptr >= this._inputEnd) {
/* 1876 */       loadMoreGuaranteed();
/* 1877 */       ptr = this._inputPtr;
/*      */     }
/* 1879 */     int outPtr = 0;
/* 1880 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1881 */     int[] codes = sInputCodesUtf8;
/*      */ 
/* 1883 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 1884 */     byte[] inputBuffer = this._inputBuffer;
/* 1885 */     while (ptr < max) {
/* 1886 */       int c = inputBuffer[ptr] & 0xFF;
/* 1887 */       if (codes[c] != 0) {
/* 1888 */         if (c != 34) break;
/* 1889 */         this._inputPtr = (ptr + 1);
/* 1890 */         this._textBuffer.setCurrentLength(outPtr);
/* 1891 */         return;
/*      */       }
/*      */ 
/* 1895 */       ptr++;
/* 1896 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 1898 */     this._inputPtr = ptr;
/* 1899 */     _finishString2(outBuf, outPtr);
/*      */   }
/*      */ 
/*      */   private final void _finishString2(char[] outBuf, int outPtr)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1908 */     int[] codes = sInputCodesUtf8;
/* 1909 */     byte[] inputBuffer = this._inputBuffer;
/*      */     while (true)
/*      */     {
/* 1916 */       int ptr = this._inputPtr;
/* 1917 */       if (ptr >= this._inputEnd) {
/* 1918 */         loadMoreGuaranteed();
/* 1919 */         ptr = this._inputPtr;
/*      */       }
/* 1921 */       if (outPtr >= outBuf.length) {
/* 1922 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1923 */         outPtr = 0;
/*      */       }
/* 1925 */       int max = Math.min(this._inputEnd, ptr + (outBuf.length - outPtr));
/* 1926 */       while (ptr < max) {
/* 1927 */         int c = inputBuffer[(ptr++)] & 0xFF;
/* 1928 */         if (codes[c] != 0) {
/* 1929 */           this._inputPtr = ptr;
/* 1930 */           break label124;
/*      */         }
/* 1932 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/* 1934 */       this._inputPtr = ptr;
/* 1935 */       continue;
/*      */       label124: int c;
/* 1937 */       if (c == 34)
/*      */       {
/*      */         break;
/*      */       }
/* 1941 */       switch (codes[c]) {
/*      */       case 1:
/* 1943 */         c = _decodeEscaped();
/* 1944 */         break;
/*      */       case 2:
/* 1946 */         c = _decodeUtf8_2(c);
/* 1947 */         break;
/*      */       case 3:
/* 1949 */         if (this._inputEnd - this._inputPtr >= 2)
/* 1950 */           c = _decodeUtf8_3fast(c);
/*      */         else {
/* 1952 */           c = _decodeUtf8_3(c);
/*      */         }
/* 1954 */         break;
/*      */       case 4:
/* 1956 */         c = _decodeUtf8_4(c);
/*      */ 
/* 1958 */         outBuf[(outPtr++)] = ((char)(0xD800 | c >> 10));
/* 1959 */         if (outPtr >= outBuf.length) {
/* 1960 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1961 */           outPtr = 0;
/*      */         }
/* 1963 */         c = 0xDC00 | c & 0x3FF;
/*      */ 
/* 1965 */         break;
/*      */       default:
/* 1967 */         if (c < 32)
/*      */         {
/* 1969 */           _throwUnquotedSpace(c, "string value");
/*      */         }
/*      */         else {
/* 1972 */           _reportInvalidChar(c);
/*      */         }
/*      */         break;
/*      */       }
/* 1976 */       if (outPtr >= outBuf.length) {
/* 1977 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1978 */         outPtr = 0;
/*      */       }
/*      */ 
/* 1981 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 1983 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */   protected void _skipString()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1994 */     this._tokenIncomplete = false;
/*      */ 
/* 1997 */     int[] codes = sInputCodesUtf8;
/* 1998 */     byte[] inputBuffer = this._inputBuffer;
/*      */     while (true)
/*      */     {
/* 2006 */       int ptr = this._inputPtr;
/* 2007 */       int max = this._inputEnd;
/* 2008 */       if (ptr >= max) {
/* 2009 */         loadMoreGuaranteed();
/* 2010 */         ptr = this._inputPtr;
/* 2011 */         max = this._inputEnd;
/*      */       }
/* 2013 */       while (ptr < max) {
/* 2014 */         int c = inputBuffer[(ptr++)] & 0xFF;
/* 2015 */         if (codes[c] != 0) {
/* 2016 */           this._inputPtr = ptr;
/* 2017 */           break label92;
/*      */         }
/*      */       }
/* 2020 */       this._inputPtr = ptr;
/* 2021 */       continue;
/*      */       label92: int c;
/* 2023 */       if (c == 34)
/*      */       {
/*      */         break;
/*      */       }
/* 2027 */       switch (codes[c]) {
/*      */       case 1:
/* 2029 */         _decodeEscaped();
/* 2030 */         break;
/*      */       case 2:
/* 2032 */         _skipUtf8_2(c);
/* 2033 */         break;
/*      */       case 3:
/* 2035 */         _skipUtf8_3(c);
/* 2036 */         break;
/*      */       case 4:
/* 2038 */         _skipUtf8_4(c);
/* 2039 */         break;
/*      */       default:
/* 2041 */         if (c < 32)
/*      */         {
/* 2043 */           _throwUnquotedSpace(c, "string value");
/*      */         }
/*      */         else
/* 2046 */           _reportInvalidChar(c);
/*      */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected JsonToken _handleUnexpectedValue(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2062 */     switch (c) {
/*      */     case 39:
/* 2064 */       if (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 2065 */         return _handleApostropheValue();
/*      */       }
/*      */       break;
/*      */     case 78:
/* 2069 */       _matchToken("NaN", 1);
/* 2070 */       if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2071 */         return resetAsNaN("NaN", (0.0D / 0.0D));
/*      */       }
/* 2073 */       _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 2074 */       break;
/*      */     case 43:
/* 2076 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2077 */         (!loadMore())) {
/* 2078 */         _reportInvalidEOFInValue();
/*      */       }
/*      */ 
/* 2081 */       return _handleInvalidNumberStart(this._inputBuffer[(this._inputPtr++)] & 0xFF, false);
/*      */     }
/*      */ 
/* 2084 */     _reportUnexpectedChar(c, "expected a valid value (number, String, array, object, 'true', 'false' or 'null')");
/* 2085 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonToken _handleApostropheValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2091 */     int c = 0;
/*      */ 
/* 2093 */     int outPtr = 0;
/* 2094 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/* 2097 */     int[] codes = sInputCodesUtf8;
/* 2098 */     byte[] inputBuffer = this._inputBuffer;
/*      */     while (true)
/*      */     {
/* 2105 */       if (this._inputPtr >= this._inputEnd) {
/* 2106 */         loadMoreGuaranteed();
/*      */       }
/* 2108 */       if (outPtr >= outBuf.length) {
/* 2109 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2110 */         outPtr = 0;
/*      */       }
/* 2112 */       int max = this._inputEnd;
/*      */ 
/* 2114 */       int max2 = this._inputPtr + (outBuf.length - outPtr);
/* 2115 */       if (max2 < max) {
/* 2116 */         max = max2;
/*      */       }
/*      */ 
/* 2119 */       while (this._inputPtr < max) {
/* 2120 */         c = inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2121 */         if ((c == 39) || (codes[c] != 0)) {
/*      */           break label140;
/*      */         }
/* 2124 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/* 2126 */       continue;
/*      */ 
/* 2129 */       label140: if (c == 39)
/*      */       {
/*      */         break;
/*      */       }
/* 2133 */       switch (codes[c]) {
/*      */       case 1:
/* 2135 */         if (c != 34)
/* 2136 */           c = _decodeEscaped(); break;
/*      */       case 2:
/* 2140 */         c = _decodeUtf8_2(c);
/* 2141 */         break;
/*      */       case 3:
/* 2143 */         if (this._inputEnd - this._inputPtr >= 2)
/* 2144 */           c = _decodeUtf8_3fast(c);
/*      */         else {
/* 2146 */           c = _decodeUtf8_3(c);
/*      */         }
/* 2148 */         break;
/*      */       case 4:
/* 2150 */         c = _decodeUtf8_4(c);
/*      */ 
/* 2152 */         outBuf[(outPtr++)] = ((char)(0xD800 | c >> 10));
/* 2153 */         if (outPtr >= outBuf.length) {
/* 2154 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2155 */           outPtr = 0;
/*      */         }
/* 2157 */         c = 0xDC00 | c & 0x3FF;
/*      */ 
/* 2159 */         break;
/*      */       default:
/* 2161 */         if (c < 32) {
/* 2162 */           _throwUnquotedSpace(c, "string value");
/*      */         }
/*      */ 
/* 2165 */         _reportInvalidChar(c);
/*      */       }
/*      */ 
/* 2168 */       if (outPtr >= outBuf.length) {
/* 2169 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2170 */         outPtr = 0;
/*      */       }
/*      */ 
/* 2173 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 2175 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/* 2177 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean negative)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2187 */     if (ch == 73) {
/* 2188 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2189 */         (!loadMore())) {
/* 2190 */         _reportInvalidEOFInValue();
/*      */       }
/*      */ 
/* 2193 */       ch = this._inputBuffer[(this._inputPtr++)];
/* 2194 */       if (ch == 78) {
/* 2195 */         String match = negative ? "-INF" : "+INF";
/* 2196 */         _matchToken(match, 3);
/* 2197 */         if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2198 */           return resetAsNaN(match, negative ? (-1.0D / 0.0D) : (1.0D / 0.0D));
/*      */         }
/* 2200 */         _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 2201 */       } else if (ch == 110) {
/* 2202 */         String match = negative ? "-Infinity" : "+Infinity";
/* 2203 */         _matchToken(match, 3);
/* 2204 */         if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2205 */           return resetAsNaN(match, negative ? (-1.0D / 0.0D) : (1.0D / 0.0D));
/*      */         }
/* 2207 */         _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */       }
/*      */     }
/* 2210 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 2211 */     return null;
/*      */   }
/*      */ 
/*      */   protected final void _matchToken(String matchStr, int i)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2217 */     int len = matchStr.length();
/*      */     do
/*      */     {
/* 2220 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2221 */         (!loadMore())) {
/* 2222 */         _reportInvalidEOF(" in a value");
/*      */       }
/*      */ 
/* 2225 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2226 */         _reportInvalidToken(matchStr.substring(0, i), "'null', 'true', 'false' or NaN");
/*      */       }
/* 2228 */       this._inputPtr += 1;
/* 2229 */       i++; } while (i < len);
/*      */ 
/* 2232 */     if ((this._inputPtr >= this._inputEnd) && 
/* 2233 */       (!loadMore())) {
/* 2234 */       return;
/*      */     }
/*      */ 
/* 2237 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2238 */     if ((ch < 48) || (ch == 93) || (ch == 125)) {
/* 2239 */       return;
/*      */     }
/*      */ 
/* 2242 */     char c = (char)_decodeCharForError(ch);
/* 2243 */     if (Character.isJavaIdentifierPart(c)) {
/* 2244 */       this._inputPtr += 1;
/* 2245 */       _reportInvalidToken(matchStr.substring(0, i), "'null', 'true', 'false' or NaN");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidToken(String matchedPart, String msg)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2252 */     StringBuilder sb = new StringBuilder(matchedPart);
/*      */ 
/* 2258 */     while ((this._inputPtr < this._inputEnd) || (loadMore()))
/*      */     {
/* 2261 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 2262 */       char c = (char)_decodeCharForError(i);
/* 2263 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2266 */       this._inputPtr += 1;
/* 2267 */       sb.append(c);
/*      */     }
/* 2269 */     _reportError("Unrecognized token '" + sb.toString() + "': was expecting " + msg);
/*      */   }
/*      */ 
/*      */   private final int _skipWS()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2281 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 2282 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2283 */       if (i > 32) {
/* 2284 */         if (i != 47) {
/* 2285 */           return i;
/*      */         }
/* 2287 */         _skipComment();
/* 2288 */       } else if (i != 32) {
/* 2289 */         if (i == 10)
/* 2290 */           _skipLF();
/* 2291 */         else if (i == 13)
/* 2292 */           _skipCR();
/* 2293 */         else if (i != 9) {
/* 2294 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 2298 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.getTypeDesc() + " entries");
/*      */   }
/*      */ 
/*      */   private final int _skipWSOrEnd()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2304 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 2305 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2306 */       if (i > 32) {
/* 2307 */         if (i != 47) {
/* 2308 */           return i;
/*      */         }
/* 2310 */         _skipComment();
/* 2311 */       } else if (i != 32) {
/* 2312 */         if (i == 10)
/* 2313 */           _skipLF();
/* 2314 */         else if (i == 13)
/* 2315 */           _skipCR();
/* 2316 */         else if (i != 9) {
/* 2317 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2322 */     _handleEOF();
/* 2323 */     return -1;
/*      */   }
/*      */ 
/*      */   private final int _skipColon()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2335 */     if (this._inputPtr >= this._inputEnd) {
/* 2336 */       loadMoreGuaranteed();
/*      */     }
/*      */ 
/* 2339 */     int i = this._inputBuffer[(this._inputPtr++)];
/* 2340 */     if (i == 58) {
/* 2341 */       if (this._inputPtr < this._inputEnd) {
/* 2342 */         i = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2343 */         if ((i > 32) && (i != 47)) {
/* 2344 */           this._inputPtr += 1;
/* 2345 */           return i;
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 2350 */       i &= 255;
/*      */       while (true)
/*      */       {
/* 2354 */         switch (i) {
/*      */         case 9:
/*      */         case 13:
/*      */         case 32:
/* 2358 */           _skipCR();
/* 2359 */           break;
/*      */         case 10:
/* 2361 */           _skipLF();
/* 2362 */           break;
/*      */         case 47:
/* 2364 */           _skipComment();
/*      */         }
/*      */       }
/* 2367 */       if (i < 32) {
/* 2368 */         _throwInvalidSpace(i);
/*      */       }
/*      */ 
/* 2373 */       if (this._inputPtr >= this._inputEnd) {
/* 2374 */         loadMoreGuaranteed();
/*      */       }
/* 2376 */       i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2377 */       if (i != 58) {
/* 2378 */         _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2383 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 2384 */       i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2385 */       if (i > 32) {
/* 2386 */         if (i != 47) {
/* 2387 */           return i;
/*      */         }
/* 2389 */         _skipComment();
/* 2390 */       } else if (i != 32) {
/* 2391 */         if (i == 10)
/* 2392 */           _skipLF();
/* 2393 */         else if (i == 13)
/* 2394 */           _skipCR();
/* 2395 */         else if (i != 9) {
/* 2396 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 2400 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.getTypeDesc() + " entries");
/*      */   }
/*      */ 
/*      */   private final void _skipComment()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2406 */     if (!isEnabled(JsonParser.Feature.ALLOW_COMMENTS)) {
/* 2407 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */ 
/* 2410 */     if ((this._inputPtr >= this._inputEnd) && (!loadMore())) {
/* 2411 */       _reportInvalidEOF(" in a comment");
/*      */     }
/* 2413 */     int c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2414 */     if (c == 47)
/* 2415 */       _skipCppComment();
/* 2416 */     else if (c == 42)
/* 2417 */       _skipCComment();
/*      */     else
/* 2419 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */   }
/*      */ 
/*      */   private final void _skipCComment()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2427 */     int[] codes = CharTypes.getInputCodeComment();
/*      */ 
/* 2430 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 2431 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2432 */       int code = codes[i];
/* 2433 */       if (code != 0) {
/* 2434 */         switch (code) {
/*      */         case 42:
/* 2436 */           if (this._inputBuffer[this._inputPtr] == 47) { this._inputPtr += 1;
/*      */             return;
/*      */           }
/*      */           break;
/*      */         case 10:
/* 2442 */           _skipLF();
/* 2443 */           break;
/*      */         case 13:
/* 2445 */           _skipCR();
/* 2446 */           break;
/*      */         default:
/* 2449 */           _reportInvalidChar(i);
/*      */         }
/*      */       }
/*      */     }
/* 2453 */     _reportInvalidEOF(" in a comment");
/*      */   }
/*      */ 
/*      */   private final void _skipCppComment()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2460 */     int[] codes = CharTypes.getInputCodeComment();
/* 2461 */     while ((this._inputPtr < this._inputEnd) || (loadMore())) {
/* 2462 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2463 */       int code = codes[i];
/* 2464 */       if (code != 0)
/* 2465 */         switch (code) {
/*      */         case 10:
/* 2467 */           _skipLF();
/* 2468 */           return;
/*      */         case 13:
/* 2470 */           _skipCR();
/* 2471 */           return;
/*      */         case 42:
/* 2473 */           break;
/*      */         default:
/* 2476 */           _reportInvalidChar(i);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final char _decodeEscaped()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2486 */     if ((this._inputPtr >= this._inputEnd) && 
/* 2487 */       (!loadMore())) {
/* 2488 */       _reportInvalidEOF(" in character escape sequence");
/*      */     }
/*      */ 
/* 2491 */     int c = this._inputBuffer[(this._inputPtr++)];
/*      */ 
/* 2493 */     switch (c)
/*      */     {
/*      */     case 98:
/* 2496 */       return '\b';
/*      */     case 116:
/* 2498 */       return '\t';
/*      */     case 110:
/* 2500 */       return '\n';
/*      */     case 102:
/* 2502 */       return '\f';
/*      */     case 114:
/* 2504 */       return '\r';
/*      */     case 34:
/*      */     case 47:
/*      */     case 92:
/* 2510 */       return (char)c;
/*      */     case 117:
/* 2513 */       break;
/*      */     default:
/* 2516 */       return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     }
/*      */ 
/* 2520 */     int value = 0;
/* 2521 */     for (int i = 0; i < 4; i++) {
/* 2522 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2523 */         (!loadMore())) {
/* 2524 */         _reportInvalidEOF(" in character escape sequence");
/*      */       }
/*      */ 
/* 2527 */       int ch = this._inputBuffer[(this._inputPtr++)];
/* 2528 */       int digit = CharTypes.charToHex(ch);
/* 2529 */       if (digit < 0) {
/* 2530 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2532 */       value = value << 4 | digit;
/*      */     }
/* 2534 */     return (char)value;
/*      */   }
/*      */ 
/*      */   protected int _decodeCharForError(int firstByte)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2540 */     int c = firstByte;
/* 2541 */     if (c < 0)
/*      */     {
/*      */       int needed;
/*      */       int needed;
/* 2545 */       if ((c & 0xE0) == 192) {
/* 2546 */         c &= 31;
/* 2547 */         needed = 1;
/*      */       }
/*      */       else
/*      */       {
/*      */         int needed;
/* 2548 */         if ((c & 0xF0) == 224) {
/* 2549 */           c &= 15;
/* 2550 */           needed = 2;
/*      */         }
/*      */         else
/*      */         {
/*      */           int needed;
/* 2551 */           if ((c & 0xF8) == 240)
/*      */           {
/* 2553 */             c &= 7;
/* 2554 */             needed = 3;
/*      */           } else {
/* 2556 */             _reportInvalidInitial(c & 0xFF);
/* 2557 */             needed = 1;
/*      */           }
/*      */         }
/*      */       }
/* 2560 */       int d = nextByte();
/* 2561 */       if ((d & 0xC0) != 128) {
/* 2562 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 2564 */       c = c << 6 | d & 0x3F;
/*      */ 
/* 2566 */       if (needed > 1) {
/* 2567 */         d = nextByte();
/* 2568 */         if ((d & 0xC0) != 128) {
/* 2569 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 2571 */         c = c << 6 | d & 0x3F;
/* 2572 */         if (needed > 2) {
/* 2573 */           d = nextByte();
/* 2574 */           if ((d & 0xC0) != 128) {
/* 2575 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 2577 */           c = c << 6 | d & 0x3F;
/*      */         }
/*      */       }
/*      */     }
/* 2581 */     return c;
/*      */   }
/*      */ 
/*      */   private final int _decodeUtf8_2(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2593 */     if (this._inputPtr >= this._inputEnd) {
/* 2594 */       loadMoreGuaranteed();
/*      */     }
/* 2596 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2597 */     if ((d & 0xC0) != 128) {
/* 2598 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2600 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   private final int _decodeUtf8_3(int c1)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2606 */     if (this._inputPtr >= this._inputEnd) {
/* 2607 */       loadMoreGuaranteed();
/*      */     }
/* 2609 */     c1 &= 15;
/* 2610 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2611 */     if ((d & 0xC0) != 128) {
/* 2612 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2614 */     int c = c1 << 6 | d & 0x3F;
/* 2615 */     if (this._inputPtr >= this._inputEnd) {
/* 2616 */       loadMoreGuaranteed();
/*      */     }
/* 2618 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2619 */     if ((d & 0xC0) != 128) {
/* 2620 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2622 */     c = c << 6 | d & 0x3F;
/* 2623 */     return c;
/*      */   }
/*      */ 
/*      */   private final int _decodeUtf8_3fast(int c1)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2629 */     c1 &= 15;
/* 2630 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2631 */     if ((d & 0xC0) != 128) {
/* 2632 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2634 */     int c = c1 << 6 | d & 0x3F;
/* 2635 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2636 */     if ((d & 0xC0) != 128) {
/* 2637 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2639 */     c = c << 6 | d & 0x3F;
/* 2640 */     return c;
/*      */   }
/*      */ 
/*      */   private final int _decodeUtf8_4(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2650 */     if (this._inputPtr >= this._inputEnd) {
/* 2651 */       loadMoreGuaranteed();
/*      */     }
/* 2653 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2654 */     if ((d & 0xC0) != 128) {
/* 2655 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2657 */     c = (c & 0x7) << 6 | d & 0x3F;
/*      */ 
/* 2659 */     if (this._inputPtr >= this._inputEnd) {
/* 2660 */       loadMoreGuaranteed();
/*      */     }
/* 2662 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2663 */     if ((d & 0xC0) != 128) {
/* 2664 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2666 */     c = c << 6 | d & 0x3F;
/* 2667 */     if (this._inputPtr >= this._inputEnd) {
/* 2668 */       loadMoreGuaranteed();
/*      */     }
/* 2670 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2671 */     if ((d & 0xC0) != 128) {
/* 2672 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */ 
/* 2678 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   private final void _skipUtf8_2(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2684 */     if (this._inputPtr >= this._inputEnd) {
/* 2685 */       loadMoreGuaranteed();
/*      */     }
/* 2687 */     c = this._inputBuffer[(this._inputPtr++)];
/* 2688 */     if ((c & 0xC0) != 128)
/* 2689 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */   }
/*      */ 
/*      */   private final void _skipUtf8_3(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2699 */     if (this._inputPtr >= this._inputEnd) {
/* 2700 */       loadMoreGuaranteed();
/*      */     }
/*      */ 
/* 2703 */     c = this._inputBuffer[(this._inputPtr++)];
/* 2704 */     if ((c & 0xC0) != 128) {
/* 2705 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/* 2707 */     if (this._inputPtr >= this._inputEnd) {
/* 2708 */       loadMoreGuaranteed();
/*      */     }
/* 2710 */     c = this._inputBuffer[(this._inputPtr++)];
/* 2711 */     if ((c & 0xC0) != 128)
/* 2712 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */   }
/*      */ 
/*      */   private final void _skipUtf8_4(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2719 */     if (this._inputPtr >= this._inputEnd) {
/* 2720 */       loadMoreGuaranteed();
/*      */     }
/* 2722 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2723 */     if ((d & 0xC0) != 128) {
/* 2724 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2726 */     if (this._inputPtr >= this._inputEnd) {
/* 2727 */       loadMoreGuaranteed();
/*      */     }
/* 2729 */     if ((d & 0xC0) != 128) {
/* 2730 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2732 */     if (this._inputPtr >= this._inputEnd) {
/* 2733 */       loadMoreGuaranteed();
/*      */     }
/* 2735 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2736 */     if ((d & 0xC0) != 128)
/* 2737 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */   }
/*      */ 
/*      */   protected final void _skipCR()
/*      */     throws IOException
/*      */   {
/* 2753 */     if (((this._inputPtr < this._inputEnd) || (loadMore())) && 
/* 2754 */       (this._inputBuffer[this._inputPtr] == 10)) {
/* 2755 */       this._inputPtr += 1;
/*      */     }
/*      */ 
/* 2758 */     this._currInputRow += 1;
/* 2759 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   protected final void _skipLF() throws IOException
/*      */   {
/* 2764 */     this._currInputRow += 1;
/* 2765 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   private int nextByte()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2771 */     if (this._inputPtr >= this._inputEnd) {
/* 2772 */       loadMoreGuaranteed();
/*      */     }
/* 2774 */     return this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidChar(int c)
/*      */     throws JsonParseException
/*      */   {
/* 2787 */     if (c < 32) {
/* 2788 */       _throwInvalidSpace(c);
/*      */     }
/* 2790 */     _reportInvalidInitial(c);
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidInitial(int mask)
/*      */     throws JsonParseException
/*      */   {
/* 2796 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidOther(int mask)
/*      */     throws JsonParseException
/*      */   {
/* 2802 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidOther(int mask, int ptr)
/*      */     throws JsonParseException
/*      */   {
/* 2808 */     this._inputPtr = ptr;
/* 2809 */     _reportInvalidOther(mask);
/*      */   }
/*      */ 
/*      */   public static int[] growArrayBy(int[] arr, int more)
/*      */   {
/* 2814 */     if (arr == null) {
/* 2815 */       return new int[more];
/*      */     }
/* 2817 */     int[] old = arr;
/* 2818 */     int len = arr.length;
/* 2819 */     arr = new int[len + more];
/* 2820 */     System.arraycopy(old, 0, arr, 0, len);
/* 2821 */     return arr;
/*      */   }
/*      */ 
/*      */   protected byte[] _decodeBase64(Base64Variant b64variant)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2834 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */     while (true)
/*      */     {
/* 2841 */       if (this._inputPtr >= this._inputEnd) {
/* 2842 */         loadMoreGuaranteed();
/*      */       }
/* 2844 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2845 */       if (ch > 32) {
/* 2846 */         int bits = b64variant.decodeBase64Char(ch);
/* 2847 */         if (bits < 0) {
/* 2848 */           if (ch == 34) {
/* 2849 */             return builder.toByteArray();
/*      */           }
/* 2851 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2852 */           if (bits < 0);
/*      */         }
/*      */         else {
/* 2856 */           int decodedData = bits;
/*      */ 
/* 2860 */           if (this._inputPtr >= this._inputEnd) {
/* 2861 */             loadMoreGuaranteed();
/*      */           }
/* 2863 */           ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2864 */           bits = b64variant.decodeBase64Char(ch);
/* 2865 */           if (bits < 0) {
/* 2866 */             bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */           }
/* 2868 */           decodedData = decodedData << 6 | bits;
/*      */ 
/* 2871 */           if (this._inputPtr >= this._inputEnd) {
/* 2872 */             loadMoreGuaranteed();
/*      */           }
/* 2874 */           ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2875 */           bits = b64variant.decodeBase64Char(ch);
/*      */ 
/* 2878 */           if (bits < 0) {
/* 2879 */             if (bits != -2)
/*      */             {
/* 2881 */               if ((ch == 34) && (!b64variant.usesPadding())) {
/* 2882 */                 decodedData >>= 4;
/* 2883 */                 builder.append(decodedData);
/* 2884 */                 return builder.toByteArray();
/*      */               }
/* 2886 */               bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */             }
/* 2888 */             if (bits == -2)
/*      */             {
/* 2890 */               if (this._inputPtr >= this._inputEnd) {
/* 2891 */                 loadMoreGuaranteed();
/*      */               }
/* 2893 */               ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2894 */               if (!b64variant.usesPaddingChar(ch)) {
/* 2895 */                 throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */               }
/*      */ 
/* 2898 */               decodedData >>= 4;
/* 2899 */               builder.append(decodedData);
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 2904 */             decodedData = decodedData << 6 | bits;
/*      */ 
/* 2906 */             if (this._inputPtr >= this._inputEnd) {
/* 2907 */               loadMoreGuaranteed();
/*      */             }
/* 2909 */             ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2910 */             bits = b64variant.decodeBase64Char(ch);
/* 2911 */             if (bits < 0) {
/* 2912 */               if (bits != -2)
/*      */               {
/* 2914 */                 if ((ch == 34) && (!b64variant.usesPadding())) {
/* 2915 */                   decodedData >>= 2;
/* 2916 */                   builder.appendTwoBytes(decodedData);
/* 2917 */                   return builder.toByteArray();
/*      */                 }
/* 2919 */                 bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */               }
/* 2921 */               if (bits == -2)
/*      */               {
/* 2928 */                 decodedData >>= 2;
/* 2929 */                 builder.appendTwoBytes(decodedData);
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 2934 */               decodedData = decodedData << 6 | bits;
/* 2935 */               builder.appendThreeBytes(decodedData);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.impl.Utf8StreamParser
 * JD-Core Version:    0.6.2
 */