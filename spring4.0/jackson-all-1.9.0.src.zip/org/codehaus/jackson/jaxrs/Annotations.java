/*    */ package org.codehaus.jackson.jaxrs;
/*    */ 
/*    */ public enum Annotations
/*    */ {
/* 12 */   JACKSON, 
/*    */ 
/* 19 */   JAXB;
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.jaxrs.Annotations
 * JD-Core Version:    0.6.2
 */