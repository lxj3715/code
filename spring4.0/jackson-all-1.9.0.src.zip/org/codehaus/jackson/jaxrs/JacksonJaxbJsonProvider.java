/*    */ package org.codehaus.jackson.jaxrs;
/*    */ 
/*    */ import javax.ws.rs.Consumes;
/*    */ import javax.ws.rs.Produces;
/*    */ import javax.ws.rs.ext.Provider;
/*    */ import org.codehaus.jackson.map.ObjectMapper;
/*    */ 
/*    */ @Provider
/*    */ @Consumes({"application/json", "text/json"})
/*    */ @Produces({"application/json", "text/json"})
/*    */ public class JacksonJaxbJsonProvider extends JacksonJsonProvider
/*    */ {
/* 35 */   public static final Annotations[] DEFAULT_ANNOTATIONS = { Annotations.JACKSON, Annotations.JAXB };
/*    */ 
/*    */   public JacksonJaxbJsonProvider()
/*    */   {
/* 45 */     this(null, DEFAULT_ANNOTATIONS);
/*    */   }
/*    */ 
/*    */   public JacksonJaxbJsonProvider(Annotations[] annotationsToUse)
/*    */   {
/* 54 */     this(null, annotationsToUse);
/*    */   }
/*    */ 
/*    */   public JacksonJaxbJsonProvider(ObjectMapper mapper, Annotations[] annotationsToUse)
/*    */   {
/* 64 */     super(mapper, annotationsToUse);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.jaxrs.JacksonJaxbJsonProvider
 * JD-Core Version:    0.6.2
 */