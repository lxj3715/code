/*     */ package org.codehaus.jackson.jaxrs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashSet;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.StreamingOutput;
/*     */ import javax.ws.rs.ext.ContextResolver;
/*     */ import javax.ws.rs.ext.MessageBodyReader;
/*     */ import javax.ws.rs.ext.MessageBodyWriter;
/*     */ import javax.ws.rs.ext.Provider;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonGenerator.Feature;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonParser.Feature;
/*     */ import org.codehaus.jackson.Version;
/*     */ import org.codehaus.jackson.Versioned;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ import org.codehaus.jackson.map.ObjectWriter;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.annotate.JsonView;
/*     */ import org.codehaus.jackson.map.type.ClassKey;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.map.util.JSONPObject;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.codehaus.jackson.util.VersionUtil;
/*     */ 
/*     */ @Provider
/*     */ @Consumes({"application/json", "text/json"})
/*     */ @Produces({"application/json", "text/json"})
/*     */ public class JacksonJsonProvider
/*     */   implements MessageBodyReader<Object>, MessageBodyWriter<Object>, Versioned
/*     */ {
/*  73 */   public static final Annotations[] BASIC_ANNOTATIONS = { Annotations.JACKSON };
/*     */ 
/*  86 */   public static final HashSet<ClassKey> _untouchables = new HashSet();
/*     */ 
/* 109 */   public static final Class<?>[] _unreadableClasses = { InputStream.class, Reader.class };
/*     */ 
/* 117 */   public static final Class<?>[] _unwritableClasses = { OutputStream.class, Writer.class, StreamingOutput.class, Response.class };
/*     */   protected final MapperConfigurator _mapperConfig;
/*     */   protected HashSet<ClassKey> _cfgCustomUntouchables;
/*     */   protected String _jsonpFunctionName;
/*     */ 
/*     */   @Context
/*     */   protected Providers _providers;
/* 167 */   protected boolean _cfgCheckCanSerialize = false;
/*     */ 
/* 175 */   protected boolean _cfgCheckCanDeserialize = false;
/*     */ 
/*     */   public JacksonJsonProvider()
/*     */   {
/* 189 */     this(null, BASIC_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider(Annotations[] annotationsToUse)
/*     */   {
/* 198 */     this(null, annotationsToUse);
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider(ObjectMapper mapper)
/*     */   {
/* 203 */     this(mapper, BASIC_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider(ObjectMapper mapper, Annotations[] annotationsToUse)
/*     */   {
/* 216 */     this._mapperConfig = new MapperConfigurator(mapper, annotationsToUse);
/*     */   }
/*     */ 
/*     */   public Version version()
/*     */   {
/* 227 */     return VersionUtil.versionFor(getClass());
/*     */   }
/*     */ 
/*     */   public void checkCanDeserialize(boolean state)
/*     */   {
/* 241 */     this._cfgCheckCanDeserialize = state;
/*     */   }
/*     */ 
/*     */   public void checkCanSerialize(boolean state)
/*     */   {
/* 248 */     this._cfgCheckCanSerialize = state;
/*     */   }
/*     */ 
/*     */   public void setAnnotationsToUse(Annotations[] annotationsToUse)
/*     */   {
/* 259 */     this._mapperConfig.setAnnotationsToUse(annotationsToUse);
/*     */   }
/*     */ 
/*     */   public void setMapper(ObjectMapper m)
/*     */   {
/* 268 */     this._mapperConfig.setMapper(m);
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider configure(DeserializationConfig.Feature f, boolean state) {
/* 272 */     this._mapperConfig.configure(f, state);
/* 273 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider configure(SerializationConfig.Feature f, boolean state) {
/* 277 */     this._mapperConfig.configure(f, state);
/* 278 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider configure(JsonParser.Feature f, boolean state) {
/* 282 */     this._mapperConfig.configure(f, state);
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider configure(JsonGenerator.Feature f, boolean state) {
/* 287 */     this._mapperConfig.configure(f, state);
/* 288 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider enable(DeserializationConfig.Feature f, boolean state) {
/* 292 */     this._mapperConfig.configure(f, true);
/* 293 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider enable(SerializationConfig.Feature f, boolean state) {
/* 297 */     this._mapperConfig.configure(f, true);
/* 298 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider enable(JsonParser.Feature f, boolean state) {
/* 302 */     this._mapperConfig.configure(f, true);
/* 303 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider enable(JsonGenerator.Feature f, boolean state) {
/* 307 */     this._mapperConfig.configure(f, true);
/* 308 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider disable(DeserializationConfig.Feature f, boolean state) {
/* 312 */     this._mapperConfig.configure(f, false);
/* 313 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider disable(SerializationConfig.Feature f, boolean state) {
/* 317 */     this._mapperConfig.configure(f, false);
/* 318 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider disable(JsonParser.Feature f, boolean state) {
/* 322 */     this._mapperConfig.configure(f, false);
/* 323 */     return this;
/*     */   }
/*     */ 
/*     */   public JacksonJsonProvider disable(JsonGenerator.Feature f, boolean state) {
/* 327 */     this._mapperConfig.configure(f, false);
/* 328 */     return this;
/*     */   }
/*     */ 
/*     */   public void addUntouchable(Class<?> type)
/*     */   {
/* 344 */     if (this._cfgCustomUntouchables == null) {
/* 345 */       this._cfgCustomUntouchables = new HashSet();
/*     */     }
/* 347 */     this._cfgCustomUntouchables.add(new ClassKey(type));
/*     */   }
/*     */ 
/*     */   public void setJSONPFunctionName(String fname) {
/* 351 */     this._jsonpFunctionName = fname;
/*     */   }
/*     */ 
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/* 374 */     if (!isJsonType(mediaType)) {
/* 375 */       return false;
/*     */     }
/*     */ 
/* 381 */     if (_untouchables.contains(new ClassKey(type))) {
/* 382 */       return false;
/*     */     }
/*     */ 
/* 385 */     for (Class cls : _unreadableClasses) {
/* 386 */       if (cls.isAssignableFrom(type)) {
/* 387 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 391 */     if (_containedIn(type, this._cfgCustomUntouchables)) {
/* 392 */       return false;
/*     */     }
/*     */ 
/* 396 */     if (this._cfgCheckCanSerialize) {
/* 397 */       ObjectMapper mapper = locateMapper(type, mediaType);
/* 398 */       if (!mapper.canDeserialize(mapper.constructType(type))) {
/* 399 */         return false;
/*     */       }
/*     */     }
/* 402 */     return true;
/*     */   }
/*     */ 
/*     */   public Object readFrom(Class<Object> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
/*     */     throws IOException
/*     */   {
/* 413 */     ObjectMapper mapper = locateMapper(type, mediaType);
/* 414 */     JsonParser jp = mapper.getJsonFactory().createJsonParser(entityStream);
/*     */ 
/* 418 */     jp.disable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/* 419 */     return mapper.readValue(jp, mapper.constructType(genericType));
/*     */   }
/*     */ 
/*     */   public long getSize(Object value, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/* 442 */     return -1L;
/*     */   }
/*     */ 
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType)
/*     */   {
/* 459 */     if (!isJsonType(mediaType)) {
/* 460 */       return false;
/*     */     }
/*     */ 
/* 466 */     if (_untouchables.contains(new ClassKey(type))) {
/* 467 */       return false;
/*     */     }
/*     */ 
/* 470 */     for (Class cls : _unwritableClasses) {
/* 471 */       if (cls.isAssignableFrom(type)) {
/* 472 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 476 */     if (_containedIn(type, this._cfgCustomUntouchables)) {
/* 477 */       return false;
/*     */     }
/*     */ 
/* 481 */     if ((this._cfgCheckCanSerialize) && 
/* 482 */       (!locateMapper(type, mediaType).canSerialize(type))) {
/* 483 */       return false;
/*     */     }
/*     */ 
/* 486 */     return true;
/*     */   }
/*     */ 
/*     */   public void writeTo(Object value, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
/*     */     throws IOException
/*     */   {
/* 500 */     ObjectMapper mapper = locateMapper(type, mediaType);
/* 501 */     JsonEncoding enc = findEncoding(mediaType, httpHeaders);
/* 502 */     JsonGenerator jg = mapper.getJsonFactory().createJsonGenerator(entityStream, enc);
/* 503 */     jg.disable(JsonGenerator.Feature.AUTO_CLOSE_TARGET);
/*     */ 
/* 506 */     if (mapper.getSerializationConfig().isEnabled(SerializationConfig.Feature.INDENT_OUTPUT)) {
/* 507 */       jg.useDefaultPrettyPrinter();
/*     */     }
/*     */ 
/* 510 */     JavaType rootType = null;
/*     */ 
/* 512 */     if ((genericType != null) && (value != null))
/*     */     {
/* 518 */       if (genericType.getClass() != Class.class)
/*     */       {
/* 523 */         rootType = mapper.getTypeFactory().constructType(genericType);
/*     */ 
/* 528 */         if (rootType.getRawClass() == Object.class) {
/* 529 */           rootType = null;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 534 */     Class viewToUse = null;
/* 535 */     if ((annotations != null) && (annotations.length > 0)) {
/* 536 */       viewToUse = _findView(mapper, annotations);
/*     */     }
/* 538 */     if (viewToUse != null)
/*     */     {
/* 540 */       ObjectWriter viewWriter = mapper.viewWriter(viewToUse);
/*     */ 
/* 542 */       if (this._jsonpFunctionName != null)
/* 543 */         viewWriter.writeValue(jg, new JSONPObject(this._jsonpFunctionName, value, rootType));
/* 544 */       else if (rootType != null)
/*     */       {
/* 546 */         mapper.typedWriter(rootType).withView(viewToUse).writeValue(jg, value);
/*     */       }
/* 548 */       else viewWriter.writeValue(jg, value);
/*     */ 
/*     */     }
/* 552 */     else if (this._jsonpFunctionName != null) {
/* 553 */       mapper.writeValue(jg, new JSONPObject(this._jsonpFunctionName, value, rootType));
/* 554 */     } else if (rootType != null)
/*     */     {
/* 556 */       mapper.typedWriter(rootType).writeValue(jg, value);
/*     */     } else {
/* 558 */       mapper.writeValue(jg, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JsonEncoding findEncoding(MediaType mediaType, MultivaluedMap<String, Object> httpHeaders)
/*     */   {
/* 571 */     return JsonEncoding.UTF8;
/*     */   }
/*     */ 
/*     */   protected boolean isJsonType(MediaType mediaType)
/*     */   {
/* 595 */     if (mediaType != null)
/*     */     {
/* 597 */       String subtype = mediaType.getSubtype();
/* 598 */       return ("json".equalsIgnoreCase(subtype)) || (subtype.endsWith("+json"));
/*     */     }
/*     */ 
/* 603 */     return true;
/*     */   }
/*     */ 
/*     */   public ObjectMapper locateMapper(Class<?> type, MediaType mediaType)
/*     */   {
/* 629 */     ObjectMapper m = this._mapperConfig.getConfiguredMapper();
/* 630 */     if (m == null)
/*     */     {
/* 632 */       if (this._providers != null) {
/* 633 */         ContextResolver resolver = this._providers.getContextResolver(ObjectMapper.class, mediaType);
/*     */ 
/* 639 */         if (resolver == null) {
/* 640 */           resolver = this._providers.getContextResolver(ObjectMapper.class, null);
/*     */         }
/* 642 */         if (resolver != null) {
/* 643 */           m = (ObjectMapper)resolver.getContext(type);
/*     */         }
/*     */       }
/* 646 */       if (m == null)
/*     */       {
/* 648 */         m = this._mapperConfig.getDefaultMapper();
/*     */       }
/*     */     }
/* 651 */     return m;
/*     */   }
/*     */ 
/*     */   protected static boolean _containedIn(Class<?> mainType, HashSet<ClassKey> set)
/*     */   {
/*     */     ClassKey key;
/* 662 */     if (set != null) {
/* 663 */       key = new ClassKey(mainType);
/*     */ 
/* 665 */       if (set.contains(key)) return true;
/*     */ 
/* 667 */       for (Class cls : ClassUtil.findSuperTypes(mainType, null)) {
/* 668 */         key.reset(cls);
/* 669 */         if (set.contains(key)) return true;
/*     */       }
/*     */     }
/* 672 */     return false;
/*     */   }
/*     */ 
/*     */   protected Class<?> _findView(ObjectMapper mapper, Annotation[] annotations)
/*     */     throws JsonMappingException
/*     */   {
/* 683 */     for (Annotation annotation : annotations) {
/* 684 */       if (annotation.annotationType().isAssignableFrom(JsonView.class)) {
/* 685 */         JsonView jsonView = (JsonView)annotation;
/* 686 */         Class[] views = jsonView.value();
/* 687 */         if (views.length > 1) {
/* 688 */           StringBuilder s = new StringBuilder("Multiple @JsonView's can not be used on a JAX-RS method. Got ");
/* 689 */           s.append(views.length).append(" views: ");
/* 690 */           for (int i = 0; i < views.length; i++) {
/* 691 */             if (i > 0) {
/* 692 */               s.append(", ");
/*     */             }
/* 694 */             s.append(views[i].getName());
/*     */           }
/* 696 */           throw new JsonMappingException(s.toString());
/*     */         }
/* 698 */         return views[0];
/*     */       }
/*     */     }
/* 701 */     return null;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  89 */     _untouchables.add(new ClassKey(InputStream.class));
/*  90 */     _untouchables.add(new ClassKey(Reader.class));
/*  91 */     _untouchables.add(new ClassKey(OutputStream.class));
/*  92 */     _untouchables.add(new ClassKey(Writer.class));
/*     */ 
/*  95 */     _untouchables.add(new ClassKey([B.class));
/*  96 */     _untouchables.add(new ClassKey([C.class));
/*     */ 
/*  98 */     _untouchables.add(new ClassKey(String.class));
/*     */ 
/* 101 */     _untouchables.add(new ClassKey(StreamingOutput.class));
/* 102 */     _untouchables.add(new ClassKey(Response.class));
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.jaxrs.JacksonJsonProvider
 * JD-Core Version:    0.6.2
 */