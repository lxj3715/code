/*    */ package org.codehaus.jackson.jaxrs;
/*    */ 
/*    */ import javax.ws.rs.core.Response;
/*    */ import javax.ws.rs.core.Response.ResponseBuilder;
/*    */ import javax.ws.rs.core.Response.Status;
/*    */ import javax.ws.rs.ext.ExceptionMapper;
/*    */ import javax.ws.rs.ext.Provider;
/*    */ import org.codehaus.jackson.JsonParseException;
/*    */ 
/*    */ @Provider
/*    */ public class JsonParseExceptionMapper
/*    */   implements ExceptionMapper<JsonParseException>
/*    */ {
/*    */   public Response toResponse(JsonParseException exception)
/*    */   {
/* 17 */     return Response.status(Response.Status.BAD_REQUEST).entity(exception.getMessage()).type("text/plain").build();
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.jaxrs.JsonParseExceptionMapper
 * JD-Core Version:    0.6.2
 */