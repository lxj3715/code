/*     */ package org.codehaus.jackson.jaxrs;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.codehaus.jackson.JsonGenerator.Feature;
/*     */ import org.codehaus.jackson.JsonParser.Feature;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.introspect.JacksonAnnotationIntrospector;
/*     */ import org.codehaus.jackson.xc.JaxbAnnotationIntrospector;
/*     */ 
/*     */ public class MapperConfigurator
/*     */ {
/*     */   protected ObjectMapper _mapper;
/*     */   protected ObjectMapper _defaultMapper;
/*     */   protected Annotations[] _defaultAnnotationsToUse;
/*     */   protected Class<? extends AnnotationIntrospector> _jaxbIntrospectorClass;
/*     */ 
/*     */   public MapperConfigurator(ObjectMapper mapper, Annotations[] defAnnotations)
/*     */   {
/*  53 */     this._mapper = mapper;
/*  54 */     this._defaultAnnotationsToUse = defAnnotations;
/*     */   }
/*     */ 
/*     */   public synchronized ObjectMapper getConfiguredMapper()
/*     */   {
/*  64 */     return this._mapper;
/*     */   }
/*     */ 
/*     */   public synchronized ObjectMapper getDefaultMapper() {
/*  68 */     if (this._defaultMapper == null) {
/*  69 */       this._defaultMapper = new ObjectMapper();
/*  70 */       _setAnnotations(this._defaultMapper, this._defaultAnnotationsToUse);
/*     */     }
/*  72 */     return this._defaultMapper;
/*     */   }
/*     */ 
/*     */   public synchronized void setMapper(ObjectMapper m)
/*     */   {
/*  82 */     this._mapper = m;
/*     */   }
/*     */ 
/*     */   public synchronized void setAnnotationsToUse(Annotations[] annotationsToUse) {
/*  86 */     _setAnnotations(mapper(), annotationsToUse);
/*     */   }
/*     */ 
/*     */   public synchronized void configure(DeserializationConfig.Feature f, boolean state) {
/*  90 */     mapper().configure(f, state);
/*     */   }
/*     */ 
/*     */   public synchronized void configure(SerializationConfig.Feature f, boolean state) {
/*  94 */     mapper().configure(f, state);
/*     */   }
/*     */ 
/*     */   public synchronized void configure(JsonParser.Feature f, boolean state) {
/*  98 */     mapper().configure(f, state);
/*     */   }
/*     */ 
/*     */   public synchronized void configure(JsonGenerator.Feature f, boolean state) {
/* 102 */     mapper().configure(f, state);
/*     */   }
/*     */ 
/*     */   protected ObjectMapper mapper()
/*     */   {
/* 118 */     if (this._mapper == null) {
/* 119 */       this._mapper = new ObjectMapper();
/* 120 */       _setAnnotations(this._mapper, this._defaultAnnotationsToUse);
/*     */     }
/* 122 */     return this._mapper;
/*     */   }
/*     */ 
/*     */   protected void _setAnnotations(ObjectMapper mapper, Annotations[] annotationsToUse)
/*     */   {
/*     */     AnnotationIntrospector intr;
/*     */     AnnotationIntrospector intr;
/* 130 */     if ((annotationsToUse == null) || (annotationsToUse.length == 0))
/* 131 */       intr = AnnotationIntrospector.nopInstance();
/*     */     else {
/* 133 */       intr = _resolveIntrospectors(annotationsToUse);
/*     */     }
/* 135 */     mapper.getDeserializationConfig().setAnnotationIntrospector(intr);
/* 136 */     mapper.getSerializationConfig().setAnnotationIntrospector(intr);
/*     */   }
/*     */ 
/*     */   protected AnnotationIntrospector _resolveIntrospectors(Annotations[] annotationsToUse)
/*     */   {
/* 143 */     ArrayList intr = new ArrayList();
/* 144 */     for (Annotations a : annotationsToUse) {
/* 145 */       if (a != null) {
/* 146 */         intr.add(_resolveIntrospector(a));
/*     */       }
/*     */     }
/* 149 */     int count = intr.size();
/* 150 */     if (count == 0) {
/* 151 */       return AnnotationIntrospector.nopInstance();
/*     */     }
/* 153 */     AnnotationIntrospector curr = (AnnotationIntrospector)intr.get(0);
/* 154 */     int i = 1; for (int len = intr.size(); i < len; i++) {
/* 155 */       curr = AnnotationIntrospector.pair(curr, (AnnotationIntrospector)intr.get(i));
/*     */     }
/* 157 */     return curr;
/*     */   }
/*     */ 
/*     */   protected AnnotationIntrospector _resolveIntrospector(Annotations ann)
/*     */   {
/* 162 */     switch (1.$SwitchMap$org$codehaus$jackson$jaxrs$Annotations[ann.ordinal()]) {
/*     */     case 1:
/* 164 */       return new JacksonAnnotationIntrospector();
/*     */     case 2:
/*     */       try
/*     */       {
/* 170 */         if (this._jaxbIntrospectorClass == null) {
/* 171 */           this._jaxbIntrospectorClass = JaxbAnnotationIntrospector.class;
/*     */         }
/* 173 */         return (AnnotationIntrospector)this._jaxbIntrospectorClass.newInstance();
/*     */       } catch (Exception e) {
/* 175 */         throw new IllegalStateException("Failed to instantiate JaxbAnnotationIntrospector: " + e.getMessage(), e);
/*     */       }
/*     */     }
/* 178 */     throw new IllegalStateException();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.jaxrs.MapperConfigurator
 * JD-Core Version:    0.6.2
 */