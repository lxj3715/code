/*    */ package org.codehaus.jackson.map;
/*    */ 
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public abstract class AbstractTypeResolver
/*    */ {
/*    */   public JavaType findTypeMapping(DeserializationConfig config, JavaType type)
/*    */   {
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */   public JavaType resolveAbstractType(DeserializationConfig config, JavaType type)
/*    */   {
/* 61 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.AbstractTypeResolver
 * JD-Core Version:    0.6.2
 */