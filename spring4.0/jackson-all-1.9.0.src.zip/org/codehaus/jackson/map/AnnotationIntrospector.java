/*      */ package org.codehaus.jackson.map;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
/*      */ import org.codehaus.jackson.map.annotate.JsonSerialize.Typing;
/*      */ import org.codehaus.jackson.map.introspect.Annotated;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedConstructor;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedParameter;
/*      */ import org.codehaus.jackson.map.introspect.NopAnnotationIntrospector;
/*      */ import org.codehaus.jackson.map.introspect.VisibilityChecker;
/*      */ import org.codehaus.jackson.map.jsontype.NamedType;
/*      */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*      */ import org.codehaus.jackson.type.JavaType;
/*      */ 
/*      */ public abstract class AnnotationIntrospector
/*      */ {
/*      */   public static AnnotationIntrospector nopInstance()
/*      */   {
/*   95 */     return NopAnnotationIntrospector.instance;
/*      */   }
/*      */ 
/*      */   public static AnnotationIntrospector pair(AnnotationIntrospector a1, AnnotationIntrospector a2) {
/*   99 */     return new Pair(a1, a2);
/*      */   }
/*      */ 
/*      */   public Collection<AnnotationIntrospector> allIntrospectors()
/*      */   {
/*  120 */     return Collections.singletonList(this);
/*      */   }
/*      */ 
/*      */   public Collection<AnnotationIntrospector> allIntrospectors(Collection<AnnotationIntrospector> result)
/*      */   {
/*  134 */     result.add(this);
/*  135 */     return result;
/*      */   }
/*      */ 
/*      */   public abstract boolean isHandled(Annotation paramAnnotation);
/*      */ 
/*      */   public Boolean findCachability(AnnotatedClass ac)
/*      */   {
/*  172 */     return null;
/*      */   }
/*      */ 
/*      */   public abstract String findRootName(AnnotatedClass paramAnnotatedClass);
/*      */ 
/*      */   public abstract String[] findPropertiesToIgnore(AnnotatedClass paramAnnotatedClass);
/*      */ 
/*      */   public abstract Boolean findIgnoreUnknownProperties(AnnotatedClass paramAnnotatedClass);
/*      */ 
/*      */   public Boolean isIgnorableType(AnnotatedClass ac)
/*      */   {
/*  218 */     return null;
/*      */   }
/*      */ 
/*      */   public Object findFilterId(AnnotatedClass ac)
/*      */   {
/*  229 */     return null;
/*      */   }
/*      */ 
/*      */   public VisibilityChecker<?> findAutoDetectVisibility(AnnotatedClass ac, VisibilityChecker<?> checker)
/*      */   {
/*  248 */     return checker;
/*      */   }
/*      */ 
/*      */   public TypeResolverBuilder<?> findTypeResolver(MapperConfig<?> config, AnnotatedClass ac, JavaType baseType)
/*      */   {
/*  275 */     return null;
/*      */   }
/*      */ 
/*      */   public TypeResolverBuilder<?> findPropertyTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType)
/*      */   {
/*  297 */     return null;
/*      */   }
/*      */ 
/*      */   public TypeResolverBuilder<?> findPropertyContentTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType containerType)
/*      */   {
/*  321 */     return null;
/*      */   }
/*      */ 
/*      */   public List<NamedType> findSubtypes(Annotated a)
/*      */   {
/*  336 */     return null;
/*      */   }
/*      */ 
/*      */   public String findTypeName(AnnotatedClass ac)
/*      */   {
/*  347 */     return null;
/*      */   }
/*      */ 
/*      */   public ReferenceProperty findReferenceType(AnnotatedMember member)
/*      */   {
/*  363 */     return null;
/*      */   }
/*      */ 
/*      */   public Boolean shouldUnwrapProperty(AnnotatedMember member)
/*      */   {
/*  374 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean hasIgnoreMarker(AnnotatedMember m)
/*      */   {
/*  395 */     if ((m instanceof AnnotatedMethod)) {
/*  396 */       return isIgnorableMethod((AnnotatedMethod)m);
/*      */     }
/*  398 */     if ((m instanceof AnnotatedField)) {
/*  399 */       return isIgnorableField((AnnotatedField)m);
/*      */     }
/*  401 */     if ((m instanceof AnnotatedConstructor)) {
/*  402 */       return isIgnorableConstructor((AnnotatedConstructor)m);
/*      */     }
/*  404 */     return false;
/*      */   }
/*      */ 
/*      */   public Object findInjectableValueId(AnnotatedMember m)
/*      */   {
/*  421 */     return null;
/*      */   }
/*      */ 
/*      */   public abstract boolean isIgnorableMethod(AnnotatedMethod paramAnnotatedMethod);
/*      */ 
/*      */   public abstract boolean isIgnorableConstructor(AnnotatedConstructor paramAnnotatedConstructor);
/*      */ 
/*      */   public abstract boolean isIgnorableField(AnnotatedField paramAnnotatedField);
/*      */ 
/*      */   public abstract Object findSerializer(Annotated paramAnnotated);
/*      */ 
/*      */   public Class<? extends JsonSerializer<?>> findKeySerializer(Annotated am)
/*      */   {
/*  492 */     return null;
/*      */   }
/*      */ 
/*      */   public Class<? extends JsonSerializer<?>> findContentSerializer(Annotated am)
/*      */   {
/*  506 */     return null;
/*      */   }
/*      */ 
/*      */   public JsonSerialize.Inclusion findSerializationInclusion(Annotated a, JsonSerialize.Inclusion defValue)
/*      */   {
/*  520 */     return defValue;
/*      */   }
/*      */ 
/*      */   public abstract Class<?> findSerializationType(Annotated paramAnnotated);
/*      */ 
/*      */   public Class<?> findSerializationKeyType(Annotated am, JavaType baseType)
/*      */   {
/*  543 */     return null;
/*      */   }
/*      */ 
/*      */   public Class<?> findSerializationContentType(Annotated am, JavaType baseType)
/*      */   {
/*  555 */     return null;
/*      */   }
/*      */ 
/*      */   public abstract JsonSerialize.Typing findSerializationTyping(Annotated paramAnnotated);
/*      */ 
/*      */   public abstract Class<?>[] findSerializationViews(Annotated paramAnnotated);
/*      */ 
/*      */   public abstract String[] findSerializationPropertyOrder(AnnotatedClass paramAnnotatedClass);
/*      */ 
/*      */   public abstract Boolean findSerializationSortAlphabetically(AnnotatedClass paramAnnotatedClass);
/*      */ 
/*      */   public abstract String findGettablePropertyName(AnnotatedMethod paramAnnotatedMethod);
/*      */ 
/*      */   public abstract boolean hasAsValueAnnotation(AnnotatedMethod paramAnnotatedMethod);
/*      */ 
/*      */   public abstract String findEnumValue(Enum<?> paramEnum);
/*      */ 
/*      */   public abstract String findSerializablePropertyName(AnnotatedField paramAnnotatedField);
/*      */ 
/*      */   public abstract Object findDeserializer(Annotated paramAnnotated);
/*      */ 
/*      */   public abstract Class<? extends KeyDeserializer> findKeyDeserializer(Annotated paramAnnotated);
/*      */ 
/*      */   public abstract Class<? extends JsonDeserializer<?>> findContentDeserializer(Annotated paramAnnotated);
/*      */ 
/*      */   public abstract Class<?> findDeserializationType(Annotated paramAnnotated, JavaType paramJavaType, String paramString);
/*      */ 
/*      */   public abstract Class<?> findDeserializationKeyType(Annotated paramAnnotated, JavaType paramJavaType, String paramString);
/*      */ 
/*      */   public abstract Class<?> findDeserializationContentType(Annotated paramAnnotated, JavaType paramJavaType, String paramString);
/*      */ 
/*      */   public Object findValueInstantiator(AnnotatedClass ac)
/*      */   {
/*  769 */     return null;
/*      */   }
/*      */ 
/*      */   public abstract String findSettablePropertyName(AnnotatedMethod paramAnnotatedMethod);
/*      */ 
/*      */   public boolean hasAnySetterAnnotation(AnnotatedMethod am)
/*      */   {
/*  800 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean hasAnyGetterAnnotation(AnnotatedMethod am)
/*      */   {
/*  815 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean hasCreatorAnnotation(Annotated a)
/*      */   {
/*  829 */     return false;
/*      */   }
/*      */ 
/*      */   public abstract String findDeserializablePropertyName(AnnotatedField paramAnnotatedField);
/*      */ 
/*      */   public abstract String findPropertyNameForParam(AnnotatedParameter paramAnnotatedParameter);
/*      */ 
/*      */   public static class Pair extends AnnotationIntrospector
/*      */   {
/*      */     protected final AnnotationIntrospector _primary;
/*      */     protected final AnnotationIntrospector _secondary;
/*      */ 
/*      */     public Pair(AnnotationIntrospector p, AnnotationIntrospector s)
/*      */     {
/*  891 */       this._primary = p;
/*  892 */       this._secondary = s;
/*      */     }
/*      */ 
/*      */     public static AnnotationIntrospector create(AnnotationIntrospector primary, AnnotationIntrospector secondary)
/*      */     {
/*  905 */       if (primary == null) {
/*  906 */         return secondary;
/*      */       }
/*  908 */       if (secondary == null) {
/*  909 */         return primary;
/*      */       }
/*  911 */       return new Pair(primary, secondary);
/*      */     }
/*      */ 
/*      */     public Collection<AnnotationIntrospector> allIntrospectors()
/*      */     {
/*  916 */       return allIntrospectors(new ArrayList());
/*      */     }
/*      */ 
/*      */     public Collection<AnnotationIntrospector> allIntrospectors(Collection<AnnotationIntrospector> result)
/*      */     {
/*  922 */       this._primary.allIntrospectors(result);
/*  923 */       this._secondary.allIntrospectors(result);
/*  924 */       return result;
/*      */     }
/*      */ 
/*      */     public boolean isHandled(Annotation ann)
/*      */     {
/*  932 */       return (this._primary.isHandled(ann)) || (this._secondary.isHandled(ann));
/*      */     }
/*      */ 
/*      */     public Boolean findCachability(AnnotatedClass ac)
/*      */     {
/*  944 */       Boolean result = this._primary.findCachability(ac);
/*  945 */       if (result == null) {
/*  946 */         result = this._secondary.findCachability(ac);
/*      */       }
/*  948 */       return result;
/*      */     }
/*      */ 
/*      */     public String findRootName(AnnotatedClass ac)
/*      */     {
/*  954 */       String name1 = this._primary.findRootName(ac);
/*  955 */       if (name1 == null)
/*  956 */         return this._secondary.findRootName(ac);
/*  957 */       if (name1.length() > 0) {
/*  958 */         return name1;
/*      */       }
/*      */ 
/*  961 */       String name2 = this._secondary.findRootName(ac);
/*  962 */       return name2 == null ? name1 : name2;
/*      */     }
/*      */ 
/*      */     public String[] findPropertiesToIgnore(AnnotatedClass ac)
/*      */     {
/*  968 */       String[] result = this._primary.findPropertiesToIgnore(ac);
/*  969 */       if (result == null) {
/*  970 */         result = this._secondary.findPropertiesToIgnore(ac);
/*      */       }
/*  972 */       return result;
/*      */     }
/*      */ 
/*      */     public Boolean findIgnoreUnknownProperties(AnnotatedClass ac)
/*      */     {
/*  978 */       Boolean result = this._primary.findIgnoreUnknownProperties(ac);
/*  979 */       if (result == null) {
/*  980 */         result = this._secondary.findIgnoreUnknownProperties(ac);
/*      */       }
/*  982 */       return result;
/*      */     }
/*      */ 
/*      */     public Boolean isIgnorableType(AnnotatedClass ac)
/*      */     {
/*  988 */       Boolean result = this._primary.isIgnorableType(ac);
/*  989 */       if (result == null) {
/*  990 */         result = this._secondary.isIgnorableType(ac);
/*      */       }
/*  992 */       return result;
/*      */     }
/*      */ 
/*      */     public Object findFilterId(AnnotatedClass ac)
/*      */     {
/*  998 */       Object id = this._primary.findFilterId(ac);
/*  999 */       if (id == null) {
/* 1000 */         id = this._secondary.findFilterId(ac);
/*      */       }
/* 1002 */       return id;
/*      */     }
/*      */ 
/*      */     public VisibilityChecker<?> findAutoDetectVisibility(AnnotatedClass ac, VisibilityChecker<?> checker)
/*      */     {
/* 1018 */       checker = this._secondary.findAutoDetectVisibility(ac, checker);
/* 1019 */       return this._primary.findAutoDetectVisibility(ac, checker);
/*      */     }
/*      */ 
/*      */     public TypeResolverBuilder<?> findTypeResolver(MapperConfig<?> config, AnnotatedClass ac, JavaType baseType)
/*      */     {
/* 1032 */       TypeResolverBuilder b = this._primary.findTypeResolver(config, ac, baseType);
/* 1033 */       if (b == null) {
/* 1034 */         b = this._secondary.findTypeResolver(config, ac, baseType);
/*      */       }
/* 1036 */       return b;
/*      */     }
/*      */ 
/*      */     public TypeResolverBuilder<?> findPropertyTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType)
/*      */     {
/* 1043 */       TypeResolverBuilder b = this._primary.findPropertyTypeResolver(config, am, baseType);
/* 1044 */       if (b == null) {
/* 1045 */         b = this._secondary.findPropertyTypeResolver(config, am, baseType);
/*      */       }
/* 1047 */       return b;
/*      */     }
/*      */ 
/*      */     public TypeResolverBuilder<?> findPropertyContentTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType)
/*      */     {
/* 1054 */       TypeResolverBuilder b = this._primary.findPropertyContentTypeResolver(config, am, baseType);
/* 1055 */       if (b == null) {
/* 1056 */         b = this._secondary.findPropertyContentTypeResolver(config, am, baseType);
/*      */       }
/* 1058 */       return b;
/*      */     }
/*      */ 
/*      */     public List<NamedType> findSubtypes(Annotated a)
/*      */     {
/* 1064 */       List types1 = this._primary.findSubtypes(a);
/* 1065 */       List types2 = this._secondary.findSubtypes(a);
/* 1066 */       if ((types1 == null) || (types1.isEmpty())) return types2;
/* 1067 */       if ((types2 == null) || (types2.isEmpty())) return types1;
/* 1068 */       ArrayList result = new ArrayList(types1.size() + types2.size());
/* 1069 */       result.addAll(types1);
/* 1070 */       result.addAll(types2);
/* 1071 */       return result;
/*      */     }
/*      */ 
/*      */     public String findTypeName(AnnotatedClass ac)
/*      */     {
/* 1077 */       String name = this._primary.findTypeName(ac);
/* 1078 */       if ((name == null) || (name.length() == 0)) {
/* 1079 */         name = this._secondary.findTypeName(ac);
/*      */       }
/* 1081 */       return name;
/*      */     }
/*      */ 
/*      */     public AnnotationIntrospector.ReferenceProperty findReferenceType(AnnotatedMember member)
/*      */     {
/* 1089 */       AnnotationIntrospector.ReferenceProperty ref = this._primary.findReferenceType(member);
/* 1090 */       if (ref == null) {
/* 1091 */         ref = this._secondary.findReferenceType(member);
/*      */       }
/* 1093 */       return ref;
/*      */     }
/*      */ 
/*      */     public Boolean shouldUnwrapProperty(AnnotatedMember member)
/*      */     {
/* 1099 */       Boolean value = this._primary.shouldUnwrapProperty(member);
/* 1100 */       if (value == null) {
/* 1101 */         value = this._secondary.shouldUnwrapProperty(member);
/*      */       }
/* 1103 */       return value;
/*      */     }
/*      */ 
/*      */     public Object findInjectableValueId(AnnotatedMember m)
/*      */     {
/* 1109 */       Object value = this._primary.findInjectableValueId(m);
/* 1110 */       if (value == null) {
/* 1111 */         value = this._secondary.findInjectableValueId(m);
/*      */       }
/* 1113 */       return value;
/*      */     }
/*      */ 
/*      */     public boolean hasIgnoreMarker(AnnotatedMember m)
/*      */     {
/* 1118 */       return (this._primary.hasIgnoreMarker(m)) || (this._secondary.hasIgnoreMarker(m));
/*      */     }
/*      */ 
/*      */     public boolean isIgnorableMethod(AnnotatedMethod m)
/*      */     {
/* 1125 */       return (this._primary.isIgnorableMethod(m)) || (this._secondary.isIgnorableMethod(m));
/*      */     }
/*      */ 
/*      */     public boolean isIgnorableConstructor(AnnotatedConstructor c)
/*      */     {
/* 1130 */       return (this._primary.isIgnorableConstructor(c)) || (this._secondary.isIgnorableConstructor(c));
/*      */     }
/*      */ 
/*      */     public boolean isIgnorableField(AnnotatedField f)
/*      */     {
/* 1138 */       return (this._primary.isIgnorableField(f)) || (this._secondary.isIgnorableField(f));
/*      */     }
/*      */ 
/*      */     public Object findSerializer(Annotated am)
/*      */     {
/* 1146 */       Object result = this._primary.findSerializer(am);
/* 1147 */       if (result == null) {
/* 1148 */         result = this._secondary.findSerializer(am);
/*      */       }
/* 1150 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<? extends JsonSerializer<?>> findKeySerializer(Annotated a)
/*      */     {
/* 1156 */       Class result = this._primary.findKeySerializer(a);
/* 1157 */       if ((result == null) || (result == JsonSerializer.None.class)) {
/* 1158 */         result = this._secondary.findKeySerializer(a);
/*      */       }
/* 1160 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<? extends JsonSerializer<?>> findContentSerializer(Annotated a)
/*      */     {
/* 1166 */       Class result = this._primary.findContentSerializer(a);
/* 1167 */       if ((result == null) || (result == JsonSerializer.None.class)) {
/* 1168 */         result = this._secondary.findContentSerializer(a);
/*      */       }
/* 1170 */       return result;
/*      */     }
/*      */ 
/*      */     public JsonSerialize.Inclusion findSerializationInclusion(Annotated a, JsonSerialize.Inclusion defValue)
/*      */     {
/* 1188 */       defValue = this._secondary.findSerializationInclusion(a, defValue);
/* 1189 */       defValue = this._primary.findSerializationInclusion(a, defValue);
/* 1190 */       return defValue;
/*      */     }
/*      */ 
/*      */     public Class<?> findSerializationType(Annotated a)
/*      */     {
/* 1196 */       Class result = this._primary.findSerializationType(a);
/* 1197 */       if (result == null) {
/* 1198 */         result = this._secondary.findSerializationType(a);
/*      */       }
/* 1200 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<?> findSerializationKeyType(Annotated am, JavaType baseType)
/*      */     {
/* 1206 */       Class result = this._primary.findSerializationKeyType(am, baseType);
/* 1207 */       if (result == null) {
/* 1208 */         result = this._secondary.findSerializationKeyType(am, baseType);
/*      */       }
/* 1210 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<?> findSerializationContentType(Annotated am, JavaType baseType)
/*      */     {
/* 1216 */       Class result = this._primary.findSerializationContentType(am, baseType);
/* 1217 */       if (result == null) {
/* 1218 */         result = this._secondary.findSerializationContentType(am, baseType);
/*      */       }
/* 1220 */       return result;
/*      */     }
/*      */ 
/*      */     public JsonSerialize.Typing findSerializationTyping(Annotated a)
/*      */     {
/* 1226 */       JsonSerialize.Typing result = this._primary.findSerializationTyping(a);
/* 1227 */       if (result == null) {
/* 1228 */         result = this._secondary.findSerializationTyping(a);
/*      */       }
/* 1230 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<?>[] findSerializationViews(Annotated a)
/*      */     {
/* 1240 */       Class[] result = this._primary.findSerializationViews(a);
/* 1241 */       if (result == null) {
/* 1242 */         result = this._secondary.findSerializationViews(a);
/*      */       }
/* 1244 */       return result;
/*      */     }
/*      */ 
/*      */     public String[] findSerializationPropertyOrder(AnnotatedClass ac)
/*      */     {
/* 1251 */       String[] result = this._primary.findSerializationPropertyOrder(ac);
/* 1252 */       if (result == null) {
/* 1253 */         result = this._secondary.findSerializationPropertyOrder(ac);
/*      */       }
/* 1255 */       return result;
/*      */     }
/*      */ 
/*      */     public Boolean findSerializationSortAlphabetically(AnnotatedClass ac)
/*      */     {
/* 1265 */       Boolean result = this._primary.findSerializationSortAlphabetically(ac);
/* 1266 */       if (result == null) {
/* 1267 */         result = this._secondary.findSerializationSortAlphabetically(ac);
/*      */       }
/* 1269 */       return result;
/*      */     }
/*      */ 
/*      */     public String findGettablePropertyName(AnnotatedMethod am)
/*      */     {
/* 1277 */       String result = this._primary.findGettablePropertyName(am);
/* 1278 */       if (result == null) {
/* 1279 */         result = this._secondary.findGettablePropertyName(am);
/* 1280 */       } else if (result.length() == 0)
/*      */       {
/* 1284 */         String str2 = this._secondary.findGettablePropertyName(am);
/* 1285 */         if (str2 != null) {
/* 1286 */           result = str2;
/*      */         }
/*      */       }
/* 1289 */       return result;
/*      */     }
/*      */ 
/*      */     public boolean hasAsValueAnnotation(AnnotatedMethod am)
/*      */     {
/* 1295 */       return (this._primary.hasAsValueAnnotation(am)) || (this._secondary.hasAsValueAnnotation(am));
/*      */     }
/*      */ 
/*      */     public String findEnumValue(Enum<?> value)
/*      */     {
/* 1301 */       String result = this._primary.findEnumValue(value);
/* 1302 */       if (result == null) {
/* 1303 */         result = this._secondary.findEnumValue(value);
/*      */       }
/* 1305 */       return result;
/*      */     }
/*      */ 
/*      */     public String findSerializablePropertyName(AnnotatedField af)
/*      */     {
/* 1313 */       String result = this._primary.findSerializablePropertyName(af);
/* 1314 */       if (result == null) {
/* 1315 */         result = this._secondary.findSerializablePropertyName(af);
/* 1316 */       } else if (result.length() == 0)
/*      */       {
/* 1320 */         String str2 = this._secondary.findSerializablePropertyName(af);
/* 1321 */         if (str2 != null) {
/* 1322 */           result = str2;
/*      */         }
/*      */       }
/* 1325 */       return result;
/*      */     }
/*      */ 
/*      */     public Object findDeserializer(Annotated am)
/*      */     {
/* 1333 */       Object result = this._primary.findDeserializer(am);
/* 1334 */       if (result == null) {
/* 1335 */         result = this._secondary.findDeserializer(am);
/*      */       }
/* 1337 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<? extends KeyDeserializer> findKeyDeserializer(Annotated am)
/*      */     {
/* 1343 */       Class result = this._primary.findKeyDeserializer(am);
/* 1344 */       if ((result == null) || (result == KeyDeserializer.None.class)) {
/* 1345 */         result = this._secondary.findKeyDeserializer(am);
/*      */       }
/* 1347 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<? extends JsonDeserializer<?>> findContentDeserializer(Annotated am)
/*      */     {
/* 1353 */       Class result = this._primary.findContentDeserializer(am);
/* 1354 */       if ((result == null) || (result == JsonDeserializer.None.class)) {
/* 1355 */         result = this._secondary.findContentDeserializer(am);
/*      */       }
/* 1357 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<?> findDeserializationType(Annotated am, JavaType baseType, String propName)
/*      */     {
/* 1364 */       Class result = this._primary.findDeserializationType(am, baseType, propName);
/* 1365 */       if (result == null) {
/* 1366 */         result = this._secondary.findDeserializationType(am, baseType, propName);
/*      */       }
/* 1368 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<?> findDeserializationKeyType(Annotated am, JavaType baseKeyType, String propName)
/*      */     {
/* 1375 */       Class result = this._primary.findDeserializationKeyType(am, baseKeyType, propName);
/* 1376 */       if (result == null) {
/* 1377 */         result = this._secondary.findDeserializationKeyType(am, baseKeyType, propName);
/*      */       }
/* 1379 */       return result;
/*      */     }
/*      */ 
/*      */     public Class<?> findDeserializationContentType(Annotated am, JavaType baseContentType, String propName)
/*      */     {
/* 1386 */       Class result = this._primary.findDeserializationContentType(am, baseContentType, propName);
/* 1387 */       if (result == null) {
/* 1388 */         result = this._secondary.findDeserializationContentType(am, baseContentType, propName);
/*      */       }
/* 1390 */       return result;
/*      */     }
/*      */ 
/*      */     public Object findValueInstantiator(AnnotatedClass ac)
/*      */     {
/* 1398 */       Object result = this._primary.findValueInstantiator(ac);
/* 1399 */       if (result == null) {
/* 1400 */         result = this._secondary.findValueInstantiator(ac);
/*      */       }
/* 1402 */       return result;
/*      */     }
/*      */ 
/*      */     public String findSettablePropertyName(AnnotatedMethod am)
/*      */     {
/* 1410 */       String result = this._primary.findSettablePropertyName(am);
/* 1411 */       if (result == null) {
/* 1412 */         result = this._secondary.findSettablePropertyName(am);
/* 1413 */       } else if (result.length() == 0)
/*      */       {
/* 1417 */         String str2 = this._secondary.findSettablePropertyName(am);
/* 1418 */         if (str2 != null) {
/* 1419 */           result = str2;
/*      */         }
/*      */       }
/* 1422 */       return result;
/*      */     }
/*      */ 
/*      */     public boolean hasAnySetterAnnotation(AnnotatedMethod am)
/*      */     {
/* 1428 */       return (this._primary.hasAnySetterAnnotation(am)) || (this._secondary.hasAnySetterAnnotation(am));
/*      */     }
/*      */ 
/*      */     public boolean hasAnyGetterAnnotation(AnnotatedMethod am)
/*      */     {
/* 1434 */       return (this._primary.hasAnyGetterAnnotation(am)) || (this._secondary.hasAnyGetterAnnotation(am));
/*      */     }
/*      */ 
/*      */     public boolean hasCreatorAnnotation(Annotated a)
/*      */     {
/* 1440 */       return (this._primary.hasCreatorAnnotation(a)) || (this._secondary.hasCreatorAnnotation(a));
/*      */     }
/*      */ 
/*      */     public String findDeserializablePropertyName(AnnotatedField af)
/*      */     {
/* 1448 */       String result = this._primary.findDeserializablePropertyName(af);
/* 1449 */       if (result == null) {
/* 1450 */         result = this._secondary.findDeserializablePropertyName(af);
/* 1451 */       } else if (result.length() == 0)
/*      */       {
/* 1455 */         String str2 = this._secondary.findDeserializablePropertyName(af);
/* 1456 */         if (str2 != null) {
/* 1457 */           result = str2;
/*      */         }
/*      */       }
/* 1460 */       return result;
/*      */     }
/*      */ 
/*      */     public String findPropertyNameForParam(AnnotatedParameter param)
/*      */     {
/* 1468 */       String result = this._primary.findPropertyNameForParam(param);
/* 1469 */       if (result == null) {
/* 1470 */         result = this._secondary.findPropertyNameForParam(param);
/*      */       }
/* 1472 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ReferenceProperty
/*      */   {
/*      */     private final Type _type;
/*      */     private final String _name;
/*      */ 
/*      */     public ReferenceProperty(Type t, String n)
/*      */     {
/*   67 */       this._type = t;
/*   68 */       this._name = n;
/*      */     }
/*      */     public static ReferenceProperty managed(String name) {
/*   71 */       return new ReferenceProperty(Type.MANAGED_REFERENCE, name); } 
/*   72 */     public static ReferenceProperty back(String name) { return new ReferenceProperty(Type.BACK_REFERENCE, name); } 
/*      */     public Type getType() {
/*   74 */       return this._type; } 
/*   75 */     public String getName() { return this._name; } 
/*      */     public boolean isManagedReference() {
/*   77 */       return this._type == Type.MANAGED_REFERENCE; } 
/*   78 */     public boolean isBackReference() { return this._type == Type.BACK_REFERENCE; }
/*      */ 
/*      */ 
/*      */     public static enum Type
/*      */     {
/*   51 */       MANAGED_REFERENCE, 
/*      */ 
/*   59 */       BACK_REFERENCE;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.AnnotationIntrospector
 * JD-Core Version:    0.6.2
 */