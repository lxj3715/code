/*    */ package org.codehaus.jackson.map;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedConstructor;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*    */ import org.codehaus.jackson.map.introspect.VisibilityChecker;
/*    */ import org.codehaus.jackson.map.type.TypeBindings;
/*    */ import org.codehaus.jackson.map.util.Annotations;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public abstract class BeanDescription
/*    */ {
/*    */   protected final JavaType _type;
/*    */ 
/*    */   protected BeanDescription(JavaType type)
/*    */   {
/* 46 */     this._type = type;
/*    */   }
/*    */ 
/*    */   public JavaType getType()
/*    */   {
/* 59 */     return this._type;
/*    */   }
/* 61 */   public Class<?> getBeanClass() { return this._type.getRawClass(); }
/*    */ 
/*    */ 
/*    */   public abstract AnnotatedClass getClassInfo();
/*    */ 
/*    */   public abstract boolean hasKnownClassAnnotations();
/*    */ 
/*    */   public abstract TypeBindings bindingsForBeanType();
/*    */ 
/*    */   public abstract JavaType resolveType(Type paramType);
/*    */ 
/*    */   public abstract Annotations getClassAnnotations();
/*    */ 
/*    */   public abstract List<BeanPropertyDefinition> findProperties();
/*    */ 
/*    */   public abstract Map<Object, AnnotatedMember> findInjectables();
/*    */ 
/*    */   public abstract AnnotatedMethod findAnyGetter();
/*    */ 
/*    */   public abstract AnnotatedMethod findAnySetter();
/*    */ 
/*    */   public abstract AnnotatedMethod findJsonValueMethod();
/*    */ 
/*    */   public abstract AnnotatedConstructor findDefaultConstructor();
/*    */ 
/*    */   public abstract Set<String> getIgnoredPropertyNames();
/*    */ 
/*    */   @Deprecated
/*    */   public abstract LinkedHashMap<String, AnnotatedMethod> findGetters(VisibilityChecker<?> paramVisibilityChecker, Collection<String> paramCollection);
/*    */ 
/*    */   @Deprecated
/*    */   public abstract LinkedHashMap<String, AnnotatedMethod> findSetters(VisibilityChecker<?> paramVisibilityChecker);
/*    */ 
/*    */   @Deprecated
/*    */   public abstract LinkedHashMap<String, AnnotatedField> findDeserializableFields(VisibilityChecker<?> paramVisibilityChecker, Collection<String> paramCollection);
/*    */ 
/*    */   @Deprecated
/*    */   public abstract Map<String, AnnotatedField> findSerializableFields(VisibilityChecker<?> paramVisibilityChecker, Collection<String> paramCollection);
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.BeanDescription
 * JD-Core Version:    0.6.2
 */