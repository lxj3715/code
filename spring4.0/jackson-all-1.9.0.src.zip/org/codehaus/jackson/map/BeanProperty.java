/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.util.Annotations;
/*     */ import org.codehaus.jackson.map.util.Named;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract interface BeanProperty extends Named
/*     */ {
/*     */   public abstract String getName();
/*     */ 
/*     */   public abstract JavaType getType();
/*     */ 
/*     */   public abstract <A extends Annotation> A getAnnotation(Class<A> paramClass);
/*     */ 
/*     */   public abstract <A extends Annotation> A getContextAnnotation(Class<A> paramClass);
/*     */ 
/*     */   public abstract AnnotatedMember getMember();
/*     */ 
/*     */   public static class Std
/*     */     implements BeanProperty
/*     */   {
/*     */     protected final String _name;
/*     */     protected final JavaType _type;
/*     */     protected final AnnotatedMember _member;
/*     */     protected final Annotations _contextAnnotations;
/*     */ 
/*     */     public Std(String name, JavaType type, Annotations contextAnnotations, AnnotatedMember member)
/*     */     {
/*  88 */       this._name = name;
/*  89 */       this._type = type;
/*  90 */       this._member = member;
/*  91 */       this._contextAnnotations = contextAnnotations;
/*     */     }
/*     */ 
/*     */     public Std withType(JavaType type) {
/*  95 */       return new Std(this._name, type, this._contextAnnotations, this._member);
/*     */     }
/*     */ 
/*     */     public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */     {
/* 100 */       return this._member.getAnnotation(acls);
/*     */     }
/*     */ 
/*     */     public <A extends Annotation> A getContextAnnotation(Class<A> acls)
/*     */     {
/* 105 */       return this._contextAnnotations == null ? null : this._contextAnnotations.get(acls);
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/* 110 */       return this._name;
/*     */     }
/*     */ 
/*     */     public JavaType getType()
/*     */     {
/* 115 */       return this._type;
/*     */     }
/*     */ 
/*     */     public AnnotatedMember getMember()
/*     */     {
/* 120 */       return this._member;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.BeanProperty
 * JD-Core Version:    0.6.2
 */