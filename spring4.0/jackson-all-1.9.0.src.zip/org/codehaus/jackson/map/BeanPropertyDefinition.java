/*    */ package org.codehaus.jackson.map;
/*    */ 
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedParameter;
/*    */ import org.codehaus.jackson.map.util.Named;
/*    */ 
/*    */ public abstract class BeanPropertyDefinition
/*    */   implements Named
/*    */ {
/*    */   public abstract String getName();
/*    */ 
/*    */   public abstract String getInternalName();
/*    */ 
/*    */   public abstract boolean hasGetter();
/*    */ 
/*    */   public abstract boolean hasSetter();
/*    */ 
/*    */   public abstract boolean hasField();
/*    */ 
/*    */   public abstract boolean hasConstructorParameter();
/*    */ 
/*    */   public boolean couldDeserialize()
/*    */   {
/* 42 */     return getMutator() != null;
/*    */   }
/*    */   public boolean couldSerialize() {
/* 45 */     return getAccessor() != null;
/*    */   }
/*    */ 
/*    */   public abstract AnnotatedMethod getGetter();
/*    */ 
/*    */   public abstract AnnotatedMethod getSetter();
/*    */ 
/*    */   public abstract AnnotatedField getField();
/*    */ 
/*    */   public abstract AnnotatedParameter getConstructorParameter();
/*    */ 
/*    */   public abstract AnnotatedMember getAccessor();
/*    */ 
/*    */   public abstract AnnotatedMember getMutator();
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.BeanPropertyDefinition
 * JD-Core Version:    0.6.2
 */