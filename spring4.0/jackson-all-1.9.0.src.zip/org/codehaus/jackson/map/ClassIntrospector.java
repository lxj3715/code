/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class ClassIntrospector<T extends BeanDescription>
/*     */ {
/*     */   public abstract T forSerialization(SerializationConfig paramSerializationConfig, JavaType paramJavaType, MixInResolver paramMixInResolver);
/*     */ 
/*     */   public abstract T forDeserialization(DeserializationConfig paramDeserializationConfig, JavaType paramJavaType, MixInResolver paramMixInResolver);
/*     */ 
/*     */   public abstract T forCreation(DeserializationConfig paramDeserializationConfig, JavaType paramJavaType, MixInResolver paramMixInResolver);
/*     */ 
/*     */   public abstract T forClassAnnotations(MapperConfig<?> paramMapperConfig, JavaType paramJavaType, MixInResolver paramMixInResolver);
/*     */ 
/*     */   public abstract T forDirectClassAnnotations(MapperConfig<?> paramMapperConfig, JavaType paramJavaType, MixInResolver paramMixInResolver);
/*     */ 
/*     */   @Deprecated
/*     */   public T forClassAnnotations(MapperConfig<?> cfg, Class<?> cls, MixInResolver r)
/*     */   {
/*  99 */     return forClassAnnotations(cfg, cfg.constructType(cls), r);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public T forDirectClassAnnotations(MapperConfig<?> cfg, Class<?> cls, MixInResolver r)
/*     */   {
/* 114 */     return forDirectClassAnnotations(cfg, cfg.constructType(cls), r);
/*     */   }
/*     */ 
/*     */   public static abstract interface MixInResolver
/*     */   {
/*     */     public abstract Class<?> findMixInClassFor(Class<?> paramClass);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ClassIntrospector
 * JD-Core Version:    0.6.2
 */