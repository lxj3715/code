/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.Base64Variant;
/*     */ import org.codehaus.jackson.Base64Variants;
/*     */ import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
/*     */ import org.codehaus.jackson.annotate.JsonMethod;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ import org.codehaus.jackson.map.introspect.Annotated;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*     */ import org.codehaus.jackson.map.introspect.NopAnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.introspect.VisibilityChecker;
/*     */ import org.codehaus.jackson.map.jsontype.SubtypeResolver;
/*     */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*     */ import org.codehaus.jackson.map.type.ClassKey;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.map.util.LinkedNode;
/*     */ import org.codehaus.jackson.node.JsonNodeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class DeserializationConfig extends MapperConfig.Impl<Feature, DeserializationConfig>
/*     */ {
/*     */   protected LinkedNode<DeserializationProblemHandler> _problemHandlers;
/*     */   protected final JsonNodeFactory _nodeFactory;
/*     */   protected boolean _sortPropertiesAlphabetically;
/*     */ 
/*     */   public DeserializationConfig(ClassIntrospector<? extends BeanDescription> intr, AnnotationIntrospector annIntr, VisibilityChecker<?> vc, SubtypeResolver subtypeResolver, PropertyNamingStrategy propertyNamingStrategy, TypeFactory typeFactory, HandlerInstantiator handlerInstantiator)
/*     */   {
/* 406 */     super(intr, annIntr, vc, subtypeResolver, propertyNamingStrategy, typeFactory, handlerInstantiator, collectFeatureDefaults(Feature.class));
/*     */ 
/* 408 */     this._nodeFactory = JsonNodeFactory.instance;
/*     */   }
/*     */ 
/*     */   protected DeserializationConfig(DeserializationConfig src)
/*     */   {
/* 415 */     this(src, src._base);
/*     */   }
/*     */ 
/*     */   private DeserializationConfig(DeserializationConfig src, HashMap<ClassKey, Class<?>> mixins, SubtypeResolver str)
/*     */   {
/* 427 */     this(src, src._base);
/* 428 */     this._mixInAnnotations = mixins;
/* 429 */     this._subtypeResolver = str;
/*     */   }
/*     */ 
/*     */   protected DeserializationConfig(DeserializationConfig src, MapperConfig.Base base)
/*     */   {
/* 437 */     super(src, base, src._subtypeResolver);
/* 438 */     this._problemHandlers = src._problemHandlers;
/* 439 */     this._nodeFactory = src._nodeFactory;
/* 440 */     this._sortPropertiesAlphabetically = src._sortPropertiesAlphabetically;
/*     */   }
/*     */ 
/*     */   protected DeserializationConfig(DeserializationConfig src, JsonNodeFactory f)
/*     */   {
/* 448 */     super(src);
/* 449 */     this._problemHandlers = src._problemHandlers;
/* 450 */     this._nodeFactory = f;
/* 451 */     this._sortPropertiesAlphabetically = src._sortPropertiesAlphabetically;
/*     */   }
/*     */ 
/*     */   protected DeserializationConfig(DeserializationConfig src, int featureFlags)
/*     */   {
/* 459 */     super(src, featureFlags);
/* 460 */     this._problemHandlers = src._problemHandlers;
/* 461 */     this._nodeFactory = src._nodeFactory;
/* 462 */     this._sortPropertiesAlphabetically = src._sortPropertiesAlphabetically;
/*     */   }
/*     */ 
/*     */   protected DeserializationConfig passSerializationFeatures(int serializationFeatureFlags)
/*     */   {
/* 474 */     this._sortPropertiesAlphabetically = ((serializationFeatureFlags & SerializationConfig.Feature.SORT_PROPERTIES_ALPHABETICALLY.getMask()) != 0);
/*     */ 
/* 476 */     return this;
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withClassIntrospector(ClassIntrospector<? extends BeanDescription> ci)
/*     */   {
/* 487 */     return new DeserializationConfig(this, this._base.withClassIntrospector(ci));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withAnnotationIntrospector(AnnotationIntrospector ai)
/*     */   {
/* 492 */     return new DeserializationConfig(this, this._base.withAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withVisibilityChecker(VisibilityChecker<?> vc)
/*     */   {
/* 497 */     return new DeserializationConfig(this, this._base.withVisibilityChecker(vc));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withVisibility(JsonMethod forMethod, JsonAutoDetect.Visibility visibility)
/*     */   {
/* 502 */     return new DeserializationConfig(this, this._base.withVisibility(forMethod, visibility));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withTypeResolverBuilder(TypeResolverBuilder<?> trb)
/*     */   {
/* 507 */     return new DeserializationConfig(this, this._base.withTypeResolverBuilder(trb));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withSubtypeResolver(SubtypeResolver str)
/*     */   {
/* 513 */     DeserializationConfig cfg = new DeserializationConfig(this);
/* 514 */     cfg._subtypeResolver = str;
/* 515 */     return cfg;
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withPropertyNamingStrategy(PropertyNamingStrategy pns)
/*     */   {
/* 520 */     return new DeserializationConfig(this, this._base.withPropertyNamingStrategy(pns));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withTypeFactory(TypeFactory tf)
/*     */   {
/* 525 */     return tf == this._base.getTypeFactory() ? this : new DeserializationConfig(this, this._base.withTypeFactory(tf));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withDateFormat(DateFormat df)
/*     */   {
/* 530 */     return df == this._base.getDateFormat() ? this : new DeserializationConfig(this, this._base.withDateFormat(df));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withHandlerInstantiator(HandlerInstantiator hi)
/*     */   {
/* 535 */     return hi == this._base.getHandlerInstantiator() ? this : new DeserializationConfig(this, this._base.withHandlerInstantiator(hi));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withInsertedAnnotationIntrospector(AnnotationIntrospector ai)
/*     */   {
/* 540 */     return new DeserializationConfig(this, this._base.withInsertedAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withAppendedAnnotationIntrospector(AnnotationIntrospector ai)
/*     */   {
/* 545 */     return new DeserializationConfig(this, this._base.withAppendedAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig withNodeFactory(JsonNodeFactory f)
/*     */   {
/* 561 */     return new DeserializationConfig(this, f);
/*     */   }
/*     */ 
/*     */   public DeserializationConfig with(Feature[] features)
/*     */   {
/* 573 */     int flags = this._featureFlags;
/* 574 */     for (Feature f : features) {
/* 575 */       flags |= f.getMask();
/*     */     }
/* 577 */     return new DeserializationConfig(this, flags);
/*     */   }
/*     */ 
/*     */   public DeserializationConfig without(Feature[] features)
/*     */   {
/* 589 */     int flags = this._featureFlags;
/* 590 */     for (Feature f : features) {
/* 591 */       flags &= (f.getMask() ^ 0xFFFFFFFF);
/*     */     }
/* 593 */     return new DeserializationConfig(this, flags);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void fromAnnotations(Class<?> cls)
/*     */   {
/* 637 */     AnnotationIntrospector ai = getAnnotationIntrospector();
/* 638 */     AnnotatedClass ac = AnnotatedClass.construct(cls, ai, null);
/*     */ 
/* 640 */     VisibilityChecker prevVc = getDefaultVisibilityChecker();
/* 641 */     this._base = this._base.withVisibilityChecker(ai.findAutoDetectVisibility(ac, prevVc));
/*     */   }
/*     */ 
/*     */   public DeserializationConfig createUnshared(SubtypeResolver subtypeResolver)
/*     */   {
/* 655 */     HashMap mixins = this._mixInAnnotations;
/*     */ 
/* 657 */     this._mixInAnnotationsShared = true;
/* 658 */     return new DeserializationConfig(this, mixins, subtypeResolver);
/*     */   }
/*     */ 
/*     */   public AnnotationIntrospector getAnnotationIntrospector()
/*     */   {
/* 671 */     if (isEnabled(Feature.USE_ANNOTATIONS)) {
/* 672 */       return super.getAnnotationIntrospector();
/*     */     }
/* 674 */     return NopAnnotationIntrospector.instance;
/*     */   }
/*     */ 
/*     */   public <T extends BeanDescription> T introspectClassAnnotations(JavaType type)
/*     */   {
/* 686 */     return getClassIntrospector().forClassAnnotations(this, type, this);
/*     */   }
/*     */ 
/*     */   public <T extends BeanDescription> T introspectDirectClassAnnotations(JavaType type)
/*     */   {
/* 699 */     return getClassIntrospector().forDirectClassAnnotations(this, type, this);
/*     */   }
/*     */ 
/*     */   public boolean isAnnotationProcessingEnabled()
/*     */   {
/* 704 */     return isEnabled(Feature.USE_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */   public boolean canOverrideAccessModifiers()
/*     */   {
/* 709 */     return isEnabled(Feature.CAN_OVERRIDE_ACCESS_MODIFIERS);
/*     */   }
/*     */ 
/*     */   public boolean shouldSortPropertiesAlphabetically()
/*     */   {
/* 714 */     return this._sortPropertiesAlphabetically;
/*     */   }
/*     */ 
/*     */   public VisibilityChecker<?> getDefaultVisibilityChecker()
/*     */   {
/* 720 */     VisibilityChecker vchecker = super.getDefaultVisibilityChecker();
/* 721 */     if (!isEnabled(Feature.AUTO_DETECT_SETTERS)) {
/* 722 */       vchecker = vchecker.withSetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */     }
/* 724 */     if (!isEnabled(Feature.AUTO_DETECT_CREATORS)) {
/* 725 */       vchecker = vchecker.withCreatorVisibility(JsonAutoDetect.Visibility.NONE);
/*     */     }
/* 727 */     if (!isEnabled(Feature.AUTO_DETECT_FIELDS)) {
/* 728 */       vchecker = vchecker.withFieldVisibility(JsonAutoDetect.Visibility.NONE);
/*     */     }
/* 730 */     return vchecker;
/*     */   }
/*     */ 
/*     */   public LinkedNode<DeserializationProblemHandler> getProblemHandlers()
/*     */   {
/* 745 */     return this._problemHandlers;
/*     */   }
/*     */ 
/*     */   public void addHandler(DeserializationProblemHandler h)
/*     */   {
/* 757 */     if (!LinkedNode.contains(this._problemHandlers, h))
/* 758 */       this._problemHandlers = new LinkedNode(h, this._problemHandlers);
/*     */   }
/*     */ 
/*     */   public void clearHandlers()
/*     */   {
/* 770 */     this._problemHandlers = null;
/*     */   }
/*     */ 
/*     */   public Base64Variant getBase64Variant()
/*     */   {
/* 786 */     return Base64Variants.getDefaultVariant();
/*     */   }
/*     */ 
/*     */   public final JsonNodeFactory getNodeFactory()
/*     */   {
/* 793 */     return this._nodeFactory;
/*     */   }
/*     */ 
/*     */   public <T extends BeanDescription> T introspect(JavaType type)
/*     */   {
/* 810 */     return getClassIntrospector().forDeserialization(this, type, this);
/*     */   }
/*     */ 
/*     */   public <T extends BeanDescription> T introspectForCreation(JavaType type)
/*     */   {
/* 819 */     return getClassIntrospector().forCreation(this, type, this);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> deserializerInstance(Annotated annotated, Class<? extends JsonDeserializer<?>> deserClass)
/*     */   {
/* 832 */     HandlerInstantiator hi = getHandlerInstantiator();
/* 833 */     if (hi != null) {
/* 834 */       JsonDeserializer deser = hi.deserializerInstance(this, annotated, deserClass);
/* 835 */       if (deser != null) {
/* 836 */         return deser;
/*     */       }
/*     */     }
/* 839 */     return (JsonDeserializer)ClassUtil.createInstance(deserClass, canOverrideAccessModifiers());
/*     */   }
/*     */ 
/*     */   public KeyDeserializer keyDeserializerInstance(Annotated annotated, Class<? extends KeyDeserializer> keyDeserClass)
/*     */   {
/* 845 */     HandlerInstantiator hi = getHandlerInstantiator();
/* 846 */     if (hi != null) {
/* 847 */       KeyDeserializer keyDeser = hi.keyDeserializerInstance(this, annotated, keyDeserClass);
/* 848 */       if (keyDeser != null) {
/* 849 */         return keyDeser;
/*     */       }
/*     */     }
/* 852 */     return (KeyDeserializer)ClassUtil.createInstance(keyDeserClass, canOverrideAccessModifiers());
/*     */   }
/*     */ 
/*     */   public ValueInstantiator valueInstantiatorInstance(Annotated annotated, Class<? extends ValueInstantiator> instClass)
/*     */   {
/* 858 */     HandlerInstantiator hi = getHandlerInstantiator();
/* 859 */     if (hi != null) {
/* 860 */       ValueInstantiator inst = hi.valueInstantiatorInstance(this, annotated, instClass);
/* 861 */       if (inst != null) {
/* 862 */         return inst;
/*     */       }
/*     */     }
/* 865 */     return (ValueInstantiator)ClassUtil.createInstance(instClass, canOverrideAccessModifiers());
/*     */   }
/*     */ 
/*     */   public static enum Feature
/*     */     implements MapperConfig.ConfigFeature
/*     */   {
/*  66 */     USE_ANNOTATIONS(true), 
/*     */ 
/*  82 */     AUTO_DETECT_SETTERS(true), 
/*     */ 
/*  98 */     AUTO_DETECT_CREATORS(true), 
/*     */ 
/* 115 */     AUTO_DETECT_FIELDS(true), 
/*     */ 
/* 133 */     USE_GETTERS_AS_SETTERS(true), 
/*     */ 
/* 143 */     CAN_OVERRIDE_ACCESS_MODIFIERS(true), 
/*     */ 
/* 165 */     USE_BIG_DECIMAL_FOR_FLOATS(false), 
/*     */ 
/* 183 */     USE_BIG_INTEGER_FOR_INTS(false), 
/*     */ 
/* 197 */     USE_JAVA_ARRAY_FOR_JSON_ARRAY(false), 
/*     */ 
/* 213 */     READ_ENUMS_USING_TO_STRING(false), 
/*     */ 
/* 238 */     FAIL_ON_UNKNOWN_PROPERTIES(true), 
/*     */ 
/* 253 */     FAIL_ON_NULL_FOR_PRIMITIVES(false), 
/*     */ 
/* 271 */     FAIL_ON_NUMBERS_FOR_ENUMS(false), 
/*     */ 
/* 291 */     WRAP_EXCEPTIONS(true), 
/*     */ 
/* 310 */     ACCEPT_SINGLE_VALUE_AS_ARRAY(false), 
/*     */ 
/* 322 */     UNWRAP_ROOT_VALUE(false), 
/*     */ 
/* 341 */     ACCEPT_EMPTY_STRING_AS_NULL_OBJECT(false);
/*     */ 
/*     */     final boolean _defaultState;
/*     */ 
/*     */     private Feature(boolean defaultState)
/*     */     {
/* 348 */       this._defaultState = defaultState;
/*     */     }
/*     */ 
/*     */     public boolean enabledByDefault() {
/* 352 */       return this._defaultState;
/*     */     }
/*     */     public int getMask() {
/* 355 */       return 1 << ordinal();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.DeserializationConfig
 * JD-Core Version:    0.6.2
 */