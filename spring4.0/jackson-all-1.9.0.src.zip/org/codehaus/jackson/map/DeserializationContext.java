/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.codehaus.jackson.Base64Variant;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders;
/*     */ import org.codehaus.jackson.map.util.ObjectBuffer;
/*     */ import org.codehaus.jackson.node.JsonNodeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class DeserializationContext
/*     */ {
/*     */   protected final DeserializationConfig _config;
/*     */   protected final int _featureFlags;
/*     */ 
/*     */   protected DeserializationContext(DeserializationConfig config)
/*     */   {
/*  34 */     this._config = config;
/*  35 */     this._featureFlags = config._featureFlags;
/*     */   }
/*     */ 
/*     */   public DeserializationConfig getConfig()
/*     */   {
/*  48 */     return this._config;
/*     */   }
/*     */ 
/*     */   public DeserializerProvider getDeserializerProvider()
/*     */   {
/*  58 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isEnabled(DeserializationConfig.Feature feat)
/*     */   {
/*  69 */     return (this._featureFlags & feat.getMask()) != 0;
/*     */   }
/*     */ 
/*     */   public Base64Variant getBase64Variant()
/*     */   {
/*  81 */     return this._config.getBase64Variant();
/*     */   }
/*     */ 
/*     */   public abstract JsonParser getParser();
/*     */ 
/*     */   public final JsonNodeFactory getNodeFactory()
/*     */   {
/*  91 */     return this._config.getNodeFactory();
/*     */   }
/*     */ 
/*     */   public JavaType constructType(Class<?> cls)
/*     */   {
/*  98 */     return this._config.constructType(cls);
/*     */   }
/*     */ 
/*     */   public TypeFactory getTypeFactory()
/*     */   {
/* 105 */     return this._config.getTypeFactory();
/*     */   }
/*     */ 
/*     */   public abstract Object findInjectableValue(Object paramObject1, BeanProperty paramBeanProperty, Object paramObject2);
/*     */ 
/*     */   public abstract ObjectBuffer leaseObjectBuffer();
/*     */ 
/*     */   public abstract void returnObjectBuffer(ObjectBuffer paramObjectBuffer);
/*     */ 
/*     */   public abstract ArrayBuilders getArrayBuilders();
/*     */ 
/*     */   public abstract Date parseDate(String paramString)
/*     */     throws IllegalArgumentException;
/*     */ 
/*     */   public abstract Calendar constructCalendar(Date paramDate);
/*     */ 
/*     */   public abstract boolean handleUnknownProperty(JsonParser paramJsonParser, JsonDeserializer<?> paramJsonDeserializer, Object paramObject, String paramString)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract JsonMappingException mappingException(Class<?> paramClass);
/*     */ 
/*     */   public abstract JsonMappingException mappingException(Class<?> paramClass, JsonToken paramJsonToken);
/*     */ 
/*     */   public JsonMappingException mappingException(String message)
/*     */   {
/* 203 */     return JsonMappingException.from(getParser(), message);
/*     */   }
/*     */ 
/*     */   public abstract JsonMappingException instantiationException(Class<?> paramClass, Throwable paramThrowable);
/*     */ 
/*     */   public abstract JsonMappingException instantiationException(Class<?> paramClass, String paramString);
/*     */ 
/*     */   public abstract JsonMappingException weirdStringException(Class<?> paramClass, String paramString);
/*     */ 
/*     */   public abstract JsonMappingException weirdNumberException(Class<?> paramClass, String paramString);
/*     */ 
/*     */   public abstract JsonMappingException weirdKeyException(Class<?> paramClass, String paramString1, String paramString2);
/*     */ 
/*     */   public abstract JsonMappingException wrongTokenException(JsonParser paramJsonParser, JsonToken paramJsonToken, String paramString);
/*     */ 
/*     */   public abstract JsonMappingException unknownFieldException(Object paramObject, String paramString);
/*     */ 
/*     */   public abstract JsonMappingException unknownTypeException(JavaType paramJavaType, String paramString);
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.DeserializationContext
 * JD-Core Version:    0.6.2
 */