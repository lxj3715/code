/*    */ package org.codehaus.jackson.map;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ 
/*    */ public abstract class DeserializationProblemHandler
/*    */ {
/*    */   public boolean handleUnknownProperty(DeserializationContext ctxt, JsonDeserializer<?> deserializer, Object beanOrClass, String propertyName)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 54 */     return false;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.DeserializationProblemHandler
 * JD-Core Version:    0.6.2
 */