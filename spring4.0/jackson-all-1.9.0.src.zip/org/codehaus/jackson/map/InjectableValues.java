/*    */ package org.codehaus.jackson.map;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class InjectableValues
/*    */ {
/*    */   public abstract Object findInjectableValue(Object paramObject1, DeserializationContext paramDeserializationContext, BeanProperty paramBeanProperty, Object paramObject2);
/*    */ 
/*    */   public static class Std extends InjectableValues
/*    */   {
/*    */     protected final Map<String, Object> _values;
/*    */ 
/*    */     public Std()
/*    */     {
/* 47 */       this(new HashMap());
/*    */     }
/*    */ 
/*    */     public Std(Map<String, Object> values) {
/* 51 */       this._values = values;
/*    */     }
/*    */ 
/*    */     public Std addValue(String key, Object value)
/*    */     {
/* 56 */       this._values.put(key, value);
/* 57 */       return this;
/*    */     }
/*    */ 
/*    */     public Std addValue(Class<?> classKey, Object value)
/*    */     {
/* 62 */       this._values.put(classKey.getName(), value);
/* 63 */       return this;
/*    */     }
/*    */ 
/*    */     public Object findInjectableValue(Object valueId, DeserializationContext ctxt, BeanProperty forProperty, Object beanInstance)
/*    */     {
/* 71 */       if (!(valueId instanceof String)) {
/* 72 */         String type = valueId == null ? "[null]" : valueId.getClass().getName();
/* 73 */         throw new IllegalArgumentException("Unrecognized inject value id type (" + type + "), expecting String");
/*    */       }
/* 75 */       String key = (String)valueId;
/* 76 */       Object ob = this._values.get(key);
/* 77 */       if ((ob == null) && (!this._values.containsKey(key))) {
/* 78 */         throw new IllegalArgumentException("No injectable id with value '" + key + "' found (for property '" + forProperty.getName() + "')");
/*    */       }
/*    */ 
/* 81 */       return ob;
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.InjectableValues
 * JD-Core Version:    0.6.2
 */