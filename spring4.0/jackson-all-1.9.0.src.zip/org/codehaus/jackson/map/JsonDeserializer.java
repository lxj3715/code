/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ 
/*     */ public abstract class JsonDeserializer<T>
/*     */ {
/*     */   public abstract T deserialize(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public T deserialize(JsonParser jp, DeserializationContext ctxt, T intoValue)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  64 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  89 */     return typeDeserializer.deserializeTypedFromAny(jp, ctxt);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<T> unwrappingDeserializer()
/*     */   {
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */   public T getNullValue()
/*     */   {
/* 132 */     return null;
/*     */   }
/*     */ 
/*     */   public T getEmptyValue()
/*     */   {
/* 147 */     return getNullValue();
/*     */   }
/*     */ 
/*     */   public static abstract class None extends JsonDeserializer<Object>
/*     */   {
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.JsonDeserializer
 * JD-Core Version:    0.6.2
 */