/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ 
/*     */ public abstract class JsonSerializer<T>
/*     */ {
/*     */   public JsonSerializer<T> unwrappingSerializer()
/*     */   {
/*  34 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean isUnwrappingSerializer()
/*     */   {
/*  46 */     return false;
/*     */   }
/*     */ 
/*     */   public abstract void serialize(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public void serializeWithType(T value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  95 */     serialize(value, jgen, provider);
/*     */   }
/*     */ 
/*     */   public Class<T> handledType()
/*     */   {
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   public static abstract class None extends JsonSerializer<Object>
/*     */   {
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.JsonSerializer
 * JD-Core Version:    0.6.2
 */