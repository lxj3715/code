/*      */ package org.codehaus.jackson.map;
/*      */ 
/*      */ import java.text.DateFormat;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
/*      */ import org.codehaus.jackson.annotate.JsonMethod;
/*      */ import org.codehaus.jackson.map.introspect.Annotated;
/*      */ import org.codehaus.jackson.map.introspect.VisibilityChecker;
/*      */ import org.codehaus.jackson.map.jsontype.SubtypeResolver;
/*      */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*      */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*      */ import org.codehaus.jackson.map.jsontype.impl.StdSubtypeResolver;
/*      */ import org.codehaus.jackson.map.type.ClassKey;
/*      */ import org.codehaus.jackson.map.type.TypeBindings;
/*      */ import org.codehaus.jackson.map.type.TypeFactory;
/*      */ import org.codehaus.jackson.map.util.ClassUtil;
/*      */ import org.codehaus.jackson.map.util.StdDateFormat;
/*      */ import org.codehaus.jackson.type.JavaType;
/*      */ import org.codehaus.jackson.type.TypeReference;
/*      */ 
/*      */ public abstract class MapperConfig<T extends MapperConfig<T>>
/*      */   implements ClassIntrospector.MixInResolver
/*      */ {
/*   52 */   protected static final DateFormat DEFAULT_DATE_FORMAT = StdDateFormat.instance;
/*      */   protected Base _base;
/*      */   protected HashMap<ClassKey, Class<?>> _mixInAnnotations;
/*      */   protected boolean _mixInAnnotationsShared;
/*      */   protected SubtypeResolver _subtypeResolver;
/*      */ 
/*      */   protected MapperConfig(ClassIntrospector<? extends BeanDescription> ci, AnnotationIntrospector ai, VisibilityChecker<?> vc, SubtypeResolver str, PropertyNamingStrategy pns, TypeFactory tf, HandlerInstantiator hi)
/*      */   {
/*  129 */     this._base = new Base(ci, ai, vc, pns, tf, null, DEFAULT_DATE_FORMAT, hi);
/*  130 */     this._subtypeResolver = str;
/*      */ 
/*  132 */     this._mixInAnnotationsShared = true;
/*      */   }
/*      */ 
/*      */   protected MapperConfig(MapperConfig<T> src)
/*      */   {
/*  141 */     this(src, src._base, src._subtypeResolver);
/*      */   }
/*      */ 
/*      */   protected MapperConfig(MapperConfig<T> src, Base base, SubtypeResolver str)
/*      */   {
/*  149 */     this._base = base;
/*  150 */     this._subtypeResolver = str;
/*      */ 
/*  152 */     this._mixInAnnotationsShared = true;
/*  153 */     this._mixInAnnotations = src._mixInAnnotations;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public abstract void fromAnnotations(Class<?> paramClass);
/*      */ 
/*      */   public abstract T createUnshared(SubtypeResolver paramSubtypeResolver);
/*      */ 
/*      */   public abstract T withClassIntrospector(ClassIntrospector<? extends BeanDescription> paramClassIntrospector);
/*      */ 
/*      */   public abstract T withAnnotationIntrospector(AnnotationIntrospector paramAnnotationIntrospector);
/*      */ 
/*      */   public abstract T withVisibilityChecker(VisibilityChecker<?> paramVisibilityChecker);
/*      */ 
/*      */   public abstract T withVisibility(JsonMethod paramJsonMethod, JsonAutoDetect.Visibility paramVisibility);
/*      */ 
/*      */   public abstract T withTypeResolverBuilder(TypeResolverBuilder<?> paramTypeResolverBuilder);
/*      */ 
/*      */   public abstract T withSubtypeResolver(SubtypeResolver paramSubtypeResolver);
/*      */ 
/*      */   public abstract T withPropertyNamingStrategy(PropertyNamingStrategy paramPropertyNamingStrategy);
/*      */ 
/*      */   public abstract T withTypeFactory(TypeFactory paramTypeFactory);
/*      */ 
/*      */   public abstract T withDateFormat(DateFormat paramDateFormat);
/*      */ 
/*      */   public abstract T withHandlerInstantiator(HandlerInstantiator paramHandlerInstantiator);
/*      */ 
/*      */   public abstract T withInsertedAnnotationIntrospector(AnnotationIntrospector paramAnnotationIntrospector);
/*      */ 
/*      */   public abstract T withAppendedAnnotationIntrospector(AnnotationIntrospector paramAnnotationIntrospector);
/*      */ 
/*      */   public abstract boolean isEnabled(ConfigFeature paramConfigFeature);
/*      */ 
/*      */   public abstract boolean isAnnotationProcessingEnabled();
/*      */ 
/*      */   public abstract boolean canOverrideAccessModifiers();
/*      */ 
/*      */   public abstract boolean shouldSortPropertiesAlphabetically();
/*      */ 
/*      */   public ClassIntrospector<? extends BeanDescription> getClassIntrospector()
/*      */   {
/*  372 */     return this._base.getClassIntrospector();
/*      */   }
/*      */ 
/*      */   public AnnotationIntrospector getAnnotationIntrospector()
/*      */   {
/*  382 */     return this._base.getAnnotationIntrospector();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public final void insertAnnotationIntrospector(AnnotationIntrospector introspector)
/*      */   {
/*  399 */     this._base = this._base.withAnnotationIntrospector(AnnotationIntrospector.Pair.create(introspector, getAnnotationIntrospector()));
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public final void appendAnnotationIntrospector(AnnotationIntrospector introspector)
/*      */   {
/*  417 */     this._base = this._base.withAnnotationIntrospector(AnnotationIntrospector.Pair.create(getAnnotationIntrospector(), introspector));
/*      */   }
/*      */ 
/*      */   public VisibilityChecker<?> getDefaultVisibilityChecker()
/*      */   {
/*  433 */     return this._base.getVisibilityChecker();
/*      */   }
/*      */ 
/*      */   public final PropertyNamingStrategy getPropertyNamingStrategy()
/*      */   {
/*  440 */     return this._base.getPropertyNamingStrategy();
/*      */   }
/*      */ 
/*      */   public final HandlerInstantiator getHandlerInstantiator()
/*      */   {
/*  447 */     return this._base.getHandlerInstantiator();
/*      */   }
/*      */ 
/*      */   public final void setMixInAnnotations(Map<Class<?>, Class<?>> sourceMixins)
/*      */   {
/*  472 */     HashMap mixins = null;
/*  473 */     if ((sourceMixins != null) && (sourceMixins.size() > 0)) {
/*  474 */       mixins = new HashMap(sourceMixins.size());
/*  475 */       for (Map.Entry en : sourceMixins.entrySet()) {
/*  476 */         mixins.put(new ClassKey((Class)en.getKey()), en.getValue());
/*      */       }
/*      */     }
/*  479 */     this._mixInAnnotationsShared = false;
/*  480 */     this._mixInAnnotations = mixins;
/*      */   }
/*      */ 
/*      */   public final void addMixInAnnotations(Class<?> target, Class<?> mixinSource)
/*      */   {
/*  497 */     if (this._mixInAnnotations == null) {
/*  498 */       this._mixInAnnotationsShared = false;
/*  499 */       this._mixInAnnotations = new HashMap();
/*  500 */     } else if (this._mixInAnnotationsShared) {
/*  501 */       this._mixInAnnotationsShared = false;
/*  502 */       this._mixInAnnotations = new HashMap(this._mixInAnnotations);
/*      */     }
/*  504 */     this._mixInAnnotations.put(new ClassKey(target), mixinSource);
/*      */   }
/*      */ 
/*      */   public final Class<?> findMixInClassFor(Class<?> cls)
/*      */   {
/*  517 */     return this._mixInAnnotations == null ? null : (Class)this._mixInAnnotations.get(new ClassKey(cls));
/*      */   }
/*      */ 
/*      */   public final int mixInCount()
/*      */   {
/*  524 */     return this._mixInAnnotations == null ? 0 : this._mixInAnnotations.size();
/*      */   }
/*      */ 
/*      */   public final TypeResolverBuilder<?> getDefaultTyper(JavaType baseType)
/*      */   {
/*  542 */     return this._base.getTypeResolverBuilder();
/*      */   }
/*      */ 
/*      */   public final SubtypeResolver getSubtypeResolver()
/*      */   {
/*  553 */     if (this._subtypeResolver == null) {
/*  554 */       this._subtypeResolver = new StdSubtypeResolver();
/*      */     }
/*  556 */     return this._subtypeResolver;
/*      */   }
/*      */ 
/*      */   public final TypeFactory getTypeFactory()
/*      */   {
/*  563 */     return this._base.getTypeFactory();
/*      */   }
/*      */ 
/*      */   public final JavaType constructType(Class<?> cls)
/*      */   {
/*  577 */     return getTypeFactory().constructType(cls, (TypeBindings)null);
/*      */   }
/*      */ 
/*      */   public final JavaType constructType(TypeReference<?> valueTypeRef)
/*      */   {
/*  591 */     return getTypeFactory().constructType(valueTypeRef.getType(), (TypeBindings)null);
/*      */   }
/*      */ 
/*      */   public final DateFormat getDateFormat()
/*      */   {
/*  616 */     return this._base.getDateFormat();
/*      */   }
/*      */ 
/*      */   public <DESC extends BeanDescription> DESC introspectClassAnnotations(Class<?> cls)
/*      */   {
/*  626 */     return introspectClassAnnotations(constructType(cls));
/*      */   }
/*      */ 
/*      */   public abstract <DESC extends BeanDescription> DESC introspectClassAnnotations(JavaType paramJavaType);
/*      */ 
/*      */   public <DESC extends BeanDescription> DESC introspectDirectClassAnnotations(Class<?> cls)
/*      */   {
/*  646 */     return introspectDirectClassAnnotations(constructType(cls));
/*      */   }
/*      */ 
/*      */   public abstract <DESC extends BeanDescription> DESC introspectDirectClassAnnotations(JavaType paramJavaType);
/*      */ 
/*      */   public TypeResolverBuilder<?> typeResolverBuilderInstance(Annotated annotated, Class<? extends TypeResolverBuilder<?>> builderClass)
/*      */   {
/*  670 */     HandlerInstantiator hi = getHandlerInstantiator();
/*  671 */     if (hi != null) {
/*  672 */       TypeResolverBuilder builder = hi.typeResolverBuilderInstance(this, annotated, builderClass);
/*  673 */       if (builder != null) {
/*  674 */         return builder;
/*      */       }
/*      */     }
/*  677 */     return (TypeResolverBuilder)ClassUtil.createInstance(builderClass, canOverrideAccessModifiers());
/*      */   }
/*      */ 
/*      */   public TypeIdResolver typeIdResolverInstance(Annotated annotated, Class<? extends TypeIdResolver> resolverClass)
/*      */   {
/*  689 */     HandlerInstantiator hi = getHandlerInstantiator();
/*  690 */     if (hi != null) {
/*  691 */       TypeIdResolver builder = hi.typeIdResolverInstance(this, annotated, resolverClass);
/*  692 */       if (builder != null) {
/*  693 */         return builder;
/*      */       }
/*      */     }
/*  696 */     return (TypeIdResolver)ClassUtil.createInstance(resolverClass, canOverrideAccessModifiers());
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public final void setAnnotationIntrospector(AnnotationIntrospector ai)
/*      */   {
/*  717 */     this._base = this._base.withAnnotationIntrospector(ai);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void setDateFormat(DateFormat df)
/*      */   {
/*  733 */     if (df == null) {
/*  734 */       df = StdDateFormat.instance;
/*      */     }
/*  736 */     this._base = this._base.withDateFormat(df);
/*      */   }
/*      */ 
/*      */   static abstract class Impl<CFG extends MapperConfig.ConfigFeature, T extends Impl<CFG, T>> extends MapperConfig<T>
/*      */   {
/*      */     protected int _featureFlags;
/*      */ 
/*      */     protected Impl(ClassIntrospector<? extends BeanDescription> ci, AnnotationIntrospector ai, VisibilityChecker<?> vc, SubtypeResolver str, PropertyNamingStrategy pns, TypeFactory tf, HandlerInstantiator hi, int defaultFeatures)
/*      */     {
/* 1014 */       super(ai, vc, str, pns, tf, hi);
/* 1015 */       this._featureFlags = defaultFeatures;
/*      */     }
/*      */ 
/*      */     protected Impl(Impl<CFG, T> src) {
/* 1019 */       super();
/* 1020 */       this._featureFlags = src._featureFlags;
/*      */     }
/*      */ 
/*      */     protected Impl(Impl<CFG, T> src, int features) {
/* 1024 */       super();
/* 1025 */       this._featureFlags = features;
/*      */     }
/*      */ 
/*      */     protected Impl(Impl<CFG, T> src, MapperConfig.Base base, SubtypeResolver str)
/*      */     {
/* 1033 */       super(base, str);
/* 1034 */       this._featureFlags = src._featureFlags;
/*      */     }
/*      */ 
/*      */     static <F extends Enum<F>,  extends MapperConfig.ConfigFeature> int collectFeatureDefaults(Class<F> enumClass)
/*      */     {
/* 1043 */       int flags = 0;
/* 1044 */       for (Enum value : (Enum[])enumClass.getEnumConstants()) {
/* 1045 */         if (((MapperConfig.ConfigFeature)value).enabledByDefault()) {
/* 1046 */           flags |= ((MapperConfig.ConfigFeature)value).getMask();
/*      */         }
/*      */       }
/* 1049 */       return flags;
/*      */     }
/*      */ 
/*      */     public abstract T with(CFG[] paramArrayOfCFG);
/*      */ 
/*      */     public abstract T without(CFG[] paramArrayOfCFG);
/*      */ 
/*      */     public boolean isEnabled(MapperConfig.ConfigFeature f)
/*      */     {
/* 1082 */       return (this._featureFlags & f.getMask()) != 0;
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public final void enable(CFG f)
/*      */     {
/* 1100 */       this._featureFlags |= f.getMask();
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public final void disable(CFG f)
/*      */     {
/* 1112 */       this._featureFlags &= (f.getMask() ^ 0xFFFFFFFF);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public final void set(CFG f, boolean state)
/*      */     {
/* 1127 */       if (state)
/* 1128 */         enable(f);
/*      */       else
/* 1130 */         disable(f);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Base
/*      */   {
/*      */     protected final ClassIntrospector<? extends BeanDescription> _classIntrospector;
/*      */     protected final AnnotationIntrospector _annotationIntrospector;
/*      */     protected final VisibilityChecker<?> _visibilityChecker;
/*      */     protected final PropertyNamingStrategy _propertyNamingStrategy;
/*      */     protected final TypeFactory _typeFactory;
/*      */     protected final TypeResolverBuilder<?> _typeResolverBuilder;
/*      */     protected final DateFormat _dateFormat;
/*      */     protected final HandlerInstantiator _handlerInstantiator;
/*      */ 
/*      */     public Base(ClassIntrospector<? extends BeanDescription> ci, AnnotationIntrospector ai, VisibilityChecker<?> vc, PropertyNamingStrategy pns, TypeFactory tf, TypeResolverBuilder<?> typer, DateFormat dateFormat, HandlerInstantiator hi)
/*      */     {
/*  872 */       this._classIntrospector = ci;
/*  873 */       this._annotationIntrospector = ai;
/*  874 */       this._visibilityChecker = vc;
/*  875 */       this._propertyNamingStrategy = pns;
/*  876 */       this._typeFactory = tf;
/*  877 */       this._typeResolverBuilder = typer;
/*  878 */       this._dateFormat = dateFormat;
/*  879 */       this._handlerInstantiator = hi;
/*      */     }
/*      */ 
/*      */     public Base withClassIntrospector(ClassIntrospector<? extends BeanDescription> ci)
/*      */     {
/*  889 */       return new Base(ci, this._annotationIntrospector, this._visibilityChecker, this._propertyNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator);
/*      */     }
/*      */ 
/*      */     public Base withAnnotationIntrospector(AnnotationIntrospector ai)
/*      */     {
/*  894 */       return new Base(this._classIntrospector, ai, this._visibilityChecker, this._propertyNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator);
/*      */     }
/*      */ 
/*      */     public Base withInsertedAnnotationIntrospector(AnnotationIntrospector ai)
/*      */     {
/*  899 */       return withAnnotationIntrospector(AnnotationIntrospector.Pair.create(ai, this._annotationIntrospector));
/*      */     }
/*      */ 
/*      */     public Base withAppendedAnnotationIntrospector(AnnotationIntrospector ai) {
/*  903 */       return withAnnotationIntrospector(AnnotationIntrospector.Pair.create(this._annotationIntrospector, ai));
/*      */     }
/*      */ 
/*      */     public Base withVisibilityChecker(VisibilityChecker<?> vc) {
/*  907 */       return new Base(this._classIntrospector, this._annotationIntrospector, vc, this._propertyNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator);
/*      */     }
/*      */ 
/*      */     public Base withVisibility(JsonMethod forMethod, JsonAutoDetect.Visibility visibility)
/*      */     {
/*  912 */       return new Base(this._classIntrospector, this._annotationIntrospector, this._visibilityChecker.withVisibility(forMethod, visibility), this._propertyNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator);
/*      */     }
/*      */ 
/*      */     public Base withPropertyNamingStrategy(PropertyNamingStrategy pns)
/*      */     {
/*  919 */       return new Base(this._classIntrospector, this._annotationIntrospector, this._visibilityChecker, pns, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator);
/*      */     }
/*      */ 
/*      */     public Base withTypeFactory(TypeFactory tf)
/*      */     {
/*  924 */       return new Base(this._classIntrospector, this._annotationIntrospector, this._visibilityChecker, this._propertyNamingStrategy, tf, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator);
/*      */     }
/*      */ 
/*      */     public Base withTypeResolverBuilder(TypeResolverBuilder<?> typer)
/*      */     {
/*  929 */       return new Base(this._classIntrospector, this._annotationIntrospector, this._visibilityChecker, this._propertyNamingStrategy, this._typeFactory, typer, this._dateFormat, this._handlerInstantiator);
/*      */     }
/*      */ 
/*      */     public Base withDateFormat(DateFormat df)
/*      */     {
/*  934 */       return new Base(this._classIntrospector, this._annotationIntrospector, this._visibilityChecker, this._propertyNamingStrategy, this._typeFactory, this._typeResolverBuilder, df, this._handlerInstantiator);
/*      */     }
/*      */ 
/*      */     public Base withHandlerInstantiator(HandlerInstantiator hi)
/*      */     {
/*  939 */       return new Base(this._classIntrospector, this._annotationIntrospector, this._visibilityChecker, this._propertyNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, hi);
/*      */     }
/*      */ 
/*      */     public ClassIntrospector<? extends BeanDescription> getClassIntrospector()
/*      */     {
/*  950 */       return this._classIntrospector;
/*      */     }
/*      */ 
/*      */     public AnnotationIntrospector getAnnotationIntrospector() {
/*  954 */       return this._annotationIntrospector;
/*      */     }
/*      */ 
/*      */     public VisibilityChecker<?> getVisibilityChecker()
/*      */     {
/*  959 */       return this._visibilityChecker;
/*      */     }
/*      */ 
/*      */     public PropertyNamingStrategy getPropertyNamingStrategy() {
/*  963 */       return this._propertyNamingStrategy;
/*      */     }
/*      */ 
/*      */     public TypeFactory getTypeFactory() {
/*  967 */       return this._typeFactory;
/*      */     }
/*      */ 
/*      */     public TypeResolverBuilder<?> getTypeResolverBuilder() {
/*  971 */       return this._typeResolverBuilder;
/*      */     }
/*      */ 
/*      */     public DateFormat getDateFormat() {
/*  975 */       return this._dateFormat;
/*      */     }
/*      */ 
/*      */     public HandlerInstantiator getHandlerInstantiator() {
/*  979 */       return this._handlerInstantiator;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface ConfigFeature
/*      */   {
/*      */     public abstract boolean enabledByDefault();
/*      */ 
/*      */     public abstract int getMask();
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.MapperConfig
 * JD-Core Version:    0.6.2
 */