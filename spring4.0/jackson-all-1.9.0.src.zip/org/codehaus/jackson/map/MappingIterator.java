/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonStreamContext;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class MappingIterator<T>
/*     */   implements Iterator<T>
/*     */ {
/*  18 */   protected static final MappingIterator<?> EMPTY_ITERATOR = new MappingIterator(null, null, null, null);
/*     */   protected final JavaType _type;
/*     */   protected final DeserializationContext _context;
/*     */   protected final JsonDeserializer<T> _deserializer;
/*     */   protected final JsonParser _parser;
/*     */ 
/*     */   protected MappingIterator(JavaType type, JsonParser jp, DeserializationContext ctxt, JsonDeserializer<?> deser)
/*     */   {
/*  32 */     this._type = type;
/*  33 */     this._parser = jp;
/*  34 */     this._context = ctxt;
/*  35 */     this._deserializer = deser;
/*     */ 
/*  40 */     if ((jp != null) && (jp.getCurrentToken() == JsonToken.START_ARRAY)) {
/*  41 */       JsonStreamContext sc = jp.getParsingContext();
/*     */ 
/*  43 */       if (!sc.inRoot())
/*  44 */         jp.clearCurrentToken();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static <T> MappingIterator<T> emptyIterator()
/*     */   {
/*  51 */     return EMPTY_ITERATOR;
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*     */     try
/*     */     {
/*  64 */       return hasNextValue();
/*     */     } catch (JsonMappingException e) {
/*  66 */       throw new RuntimeJsonMappingException(e.getMessage(), e);
/*     */     } catch (IOException e) {
/*  68 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public T next()
/*     */   {
/*     */     try
/*     */     {
/*  76 */       return nextValue();
/*     */     } catch (JsonMappingException e) {
/*  78 */       throw new RuntimeJsonMappingException(e.getMessage(), e);
/*     */     } catch (IOException e) {
/*  80 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void remove() {
/*  85 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean hasNextValue()
/*     */     throws IOException
/*     */   {
/* 100 */     if (this._parser == null) {
/* 101 */       return false;
/*     */     }
/* 103 */     JsonToken t = this._parser.getCurrentToken();
/* 104 */     if (t == null) {
/* 105 */       t = this._parser.nextToken();
/*     */ 
/* 107 */       if (t == null) {
/* 108 */         this._parser.close();
/* 109 */         return false;
/*     */       }
/*     */ 
/* 112 */       if (t == JsonToken.END_ARRAY) {
/* 113 */         return false;
/*     */       }
/*     */     }
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   public T nextValue() throws IOException
/*     */   {
/* 121 */     Object result = this._deserializer.deserialize(this._parser, this._context);
/*     */ 
/* 123 */     this._parser.clearCurrentToken();
/* 124 */     return result;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.MappingIterator
 * JD-Core Version:    0.6.2
 */