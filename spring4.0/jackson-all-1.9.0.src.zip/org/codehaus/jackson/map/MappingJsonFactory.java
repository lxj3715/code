/*    */ package org.codehaus.jackson.map;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonFactory;
/*    */ import org.codehaus.jackson.format.InputAccessor;
/*    */ import org.codehaus.jackson.format.MatchStrength;
/*    */ 
/*    */ public class MappingJsonFactory extends JsonFactory
/*    */ {
/*    */   public MappingJsonFactory()
/*    */   {
/* 36 */     this(null);
/*    */   }
/*    */ 
/*    */   public MappingJsonFactory(ObjectMapper mapper)
/*    */   {
/* 41 */     super(mapper);
/* 42 */     if (mapper == null)
/* 43 */       setCodec(new ObjectMapper(this));
/*    */   }
/*    */ 
/*    */   public final ObjectMapper getCodec()
/*    */   {
/* 52 */     return (ObjectMapper)this._objectCodec;
/*    */   }
/*    */ 
/*    */   public String getFormatName()
/*    */   {
/* 69 */     return "JSON";
/*    */   }
/*    */ 
/*    */   public MatchStrength hasFormat(InputAccessor acc)
/*    */     throws IOException
/*    */   {
/* 78 */     return hasJSONFormat(acc);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.MappingJsonFactory
 * JD-Core Version:    0.6.2
 */