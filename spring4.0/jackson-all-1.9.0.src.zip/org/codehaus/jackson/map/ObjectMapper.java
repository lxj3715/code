/*      */ package org.codehaus.jackson.map;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URL;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Collection;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.codehaus.jackson.FormatSchema;
/*      */ import org.codehaus.jackson.JsonEncoding;
/*      */ import org.codehaus.jackson.JsonFactory;
/*      */ import org.codehaus.jackson.JsonGenerationException;
/*      */ import org.codehaus.jackson.JsonGenerator;
/*      */ import org.codehaus.jackson.JsonGenerator.Feature;
/*      */ import org.codehaus.jackson.JsonNode;
/*      */ import org.codehaus.jackson.JsonParseException;
/*      */ import org.codehaus.jackson.JsonParser;
/*      */ import org.codehaus.jackson.JsonParser.Feature;
/*      */ import org.codehaus.jackson.JsonProcessingException;
/*      */ import org.codehaus.jackson.JsonToken;
/*      */ import org.codehaus.jackson.ObjectCodec;
/*      */ import org.codehaus.jackson.PrettyPrinter;
/*      */ import org.codehaus.jackson.Version;
/*      */ import org.codehaus.jackson.Versioned;
/*      */ import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
/*      */ import org.codehaus.jackson.annotate.JsonMethod;
/*      */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*      */ import org.codehaus.jackson.annotate.JsonTypeInfo.Id;
/*      */ import org.codehaus.jackson.io.SegmentedStringWriter;
/*      */ import org.codehaus.jackson.io.SerializedString;
/*      */ import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
/*      */ import org.codehaus.jackson.map.deser.BeanDeserializerModifier;
/*      */ import org.codehaus.jackson.map.deser.StdDeserializationContext;
/*      */ import org.codehaus.jackson.map.deser.StdDeserializerProvider;
/*      */ import org.codehaus.jackson.map.deser.ValueInstantiators;
/*      */ import org.codehaus.jackson.map.introspect.BasicClassIntrospector;
/*      */ import org.codehaus.jackson.map.introspect.JacksonAnnotationIntrospector;
/*      */ import org.codehaus.jackson.map.introspect.VisibilityChecker;
/*      */ import org.codehaus.jackson.map.introspect.VisibilityChecker.Std;
/*      */ import org.codehaus.jackson.map.jsontype.NamedType;
/*      */ import org.codehaus.jackson.map.jsontype.SubtypeResolver;
/*      */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*      */ import org.codehaus.jackson.map.jsontype.impl.StdSubtypeResolver;
/*      */ import org.codehaus.jackson.map.jsontype.impl.StdTypeResolverBuilder;
/*      */ import org.codehaus.jackson.map.ser.BeanSerializerFactory;
/*      */ import org.codehaus.jackson.map.ser.BeanSerializerModifier;
/*      */ import org.codehaus.jackson.map.ser.FilterProvider;
/*      */ import org.codehaus.jackson.map.ser.StdSerializerProvider;
/*      */ import org.codehaus.jackson.map.type.SimpleType;
/*      */ import org.codehaus.jackson.map.type.TypeFactory;
/*      */ import org.codehaus.jackson.map.type.TypeModifier;
/*      */ import org.codehaus.jackson.node.ArrayNode;
/*      */ import org.codehaus.jackson.node.JsonNodeFactory;
/*      */ import org.codehaus.jackson.node.NullNode;
/*      */ import org.codehaus.jackson.node.ObjectNode;
/*      */ import org.codehaus.jackson.node.TreeTraversingParser;
/*      */ import org.codehaus.jackson.schema.JsonSchema;
/*      */ import org.codehaus.jackson.type.JavaType;
/*      */ import org.codehaus.jackson.type.TypeReference;
/*      */ import org.codehaus.jackson.util.ByteArrayBuilder;
/*      */ import org.codehaus.jackson.util.DefaultPrettyPrinter;
/*      */ import org.codehaus.jackson.util.TokenBuffer;
/*      */ import org.codehaus.jackson.util.VersionUtil;
/*      */ 
/*      */ public class ObjectMapper extends ObjectCodec
/*      */   implements Versioned
/*      */ {
/*  183 */   private static final JavaType JSON_NODE_TYPE = SimpleType.constructUnsafe(JsonNode.class);
/*      */ 
/*  188 */   protected static final ClassIntrospector<? extends BeanDescription> DEFAULT_INTROSPECTOR = BasicClassIntrospector.instance;
/*      */ 
/*  191 */   protected static final AnnotationIntrospector DEFAULT_ANNOTATION_INTROSPECTOR = new JacksonAnnotationIntrospector();
/*      */ 
/*  196 */   protected static final VisibilityChecker<?> STD_VISIBILITY_CHECKER = VisibilityChecker.Std.defaultInstance();
/*      */   protected final JsonFactory _jsonFactory;
/*      */   protected SubtypeResolver _subtypeResolver;
/*      */   protected TypeFactory _typeFactory;
/*      */   protected InjectableValues _injectableValues;
/*      */   protected SerializationConfig _serializationConfig;
/*      */   protected SerializerProvider _serializerProvider;
/*      */   protected SerializerFactory _serializerFactory;
/*      */   protected DeserializationConfig _deserializationConfig;
/*      */   protected DeserializerProvider _deserializerProvider;
/*  305 */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _rootDeserializers = new ConcurrentHashMap(64, 0.6F, 2);
/*      */ 
/*      */   public ObjectMapper()
/*      */   {
/*  328 */     this(null, null, null);
/*      */   }
/*      */ 
/*      */   public ObjectMapper(JsonFactory jf)
/*      */   {
/*  338 */     this(jf, null, null);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectMapper(SerializerFactory sf)
/*      */   {
/*  351 */     this(null, null, null);
/*  352 */     setSerializerFactory(sf);
/*      */   }
/*      */ 
/*      */   public ObjectMapper(JsonFactory jf, SerializerProvider sp, DeserializerProvider dp)
/*      */   {
/*  358 */     this(jf, sp, dp, null, null);
/*      */   }
/*      */ 
/*      */   public ObjectMapper(JsonFactory jf, SerializerProvider sp, DeserializerProvider dp, SerializationConfig sconfig, DeserializationConfig dconfig)
/*      */   {
/*  381 */     this._jsonFactory = (jf == null ? new MappingJsonFactory(this) : jf);
/*      */ 
/*  383 */     this._typeFactory = TypeFactory.defaultInstance();
/*  384 */     this._serializationConfig = (sconfig != null ? sconfig : new SerializationConfig(DEFAULT_INTROSPECTOR, DEFAULT_ANNOTATION_INTROSPECTOR, STD_VISIBILITY_CHECKER, null, null, this._typeFactory, null));
/*      */ 
/*  387 */     this._deserializationConfig = (dconfig != null ? dconfig : new DeserializationConfig(DEFAULT_INTROSPECTOR, DEFAULT_ANNOTATION_INTROSPECTOR, STD_VISIBILITY_CHECKER, null, null, this._typeFactory, null));
/*      */ 
/*  390 */     this._serializerProvider = (sp == null ? new StdSerializerProvider() : sp);
/*  391 */     this._deserializerProvider = (dp == null ? new StdDeserializerProvider() : dp);
/*      */ 
/*  394 */     this._serializerFactory = BeanSerializerFactory.instance;
/*      */   }
/*      */ 
/*      */   public Version version()
/*      */   {
/*  411 */     return VersionUtil.versionFor(getClass());
/*      */   }
/*      */ 
/*      */   public void registerModule(Module module)
/*      */   {
/*  435 */     String name = module.getModuleName();
/*  436 */     if (name == null) {
/*  437 */       throw new IllegalArgumentException("Module without defined name");
/*      */     }
/*  439 */     Version version = module.version();
/*  440 */     if (version == null) {
/*  441 */       throw new IllegalArgumentException("Module without defined version");
/*      */     }
/*      */ 
/*  444 */     final ObjectMapper mapper = this;
/*      */ 
/*  447 */     module.setupModule(new Module.SetupContext()
/*      */     {
/*      */       public Version getMapperVersion()
/*      */       {
/*  453 */         return ObjectMapper.this.version();
/*      */       }
/*      */ 
/*      */       public DeserializationConfig getDeserializationConfig()
/*      */       {
/*  458 */         return mapper.getDeserializationConfig();
/*      */       }
/*      */ 
/*      */       public SerializationConfig getSerializationConfig()
/*      */       {
/*  463 */         return mapper.getSerializationConfig();
/*      */       }
/*      */ 
/*      */       public boolean isEnabled(DeserializationConfig.Feature f)
/*      */       {
/*  468 */         return mapper.isEnabled(f);
/*      */       }
/*      */ 
/*      */       public boolean isEnabled(SerializationConfig.Feature f)
/*      */       {
/*  473 */         return mapper.isEnabled(f);
/*      */       }
/*      */ 
/*      */       public boolean isEnabled(JsonParser.Feature f)
/*      */       {
/*  478 */         return mapper.isEnabled(f);
/*      */       }
/*      */ 
/*      */       public boolean isEnabled(JsonGenerator.Feature f)
/*      */       {
/*  483 */         return mapper.isEnabled(f);
/*      */       }
/*      */ 
/*      */       public void addDeserializers(Deserializers d)
/*      */       {
/*  490 */         mapper._deserializerProvider = mapper._deserializerProvider.withAdditionalDeserializers(d);
/*      */       }
/*      */ 
/*      */       public void addKeyDeserializers(KeyDeserializers d)
/*      */       {
/*  495 */         mapper._deserializerProvider = mapper._deserializerProvider.withAdditionalKeyDeserializers(d);
/*      */       }
/*      */ 
/*      */       public void addSerializers(Serializers s)
/*      */       {
/*  500 */         mapper._serializerFactory = mapper._serializerFactory.withAdditionalSerializers(s);
/*      */       }
/*      */ 
/*      */       public void addKeySerializers(Serializers s)
/*      */       {
/*  505 */         mapper._serializerFactory = mapper._serializerFactory.withAdditionalKeySerializers(s);
/*      */       }
/*      */ 
/*      */       public void addBeanSerializerModifier(BeanSerializerModifier modifier)
/*      */       {
/*  510 */         mapper._serializerFactory = mapper._serializerFactory.withSerializerModifier(modifier);
/*      */       }
/*      */ 
/*      */       public void addBeanDeserializerModifier(BeanDeserializerModifier modifier)
/*      */       {
/*  515 */         mapper._deserializerProvider = mapper._deserializerProvider.withDeserializerModifier(modifier);
/*      */       }
/*      */ 
/*      */       public void addAbstractTypeResolver(AbstractTypeResolver resolver)
/*      */       {
/*  522 */         mapper._deserializerProvider = mapper._deserializerProvider.withAbstractTypeResolver(resolver);
/*      */       }
/*      */ 
/*      */       public void addTypeModifier(TypeModifier modifier)
/*      */       {
/*  527 */         TypeFactory f = mapper._typeFactory;
/*  528 */         f = f.withModifier(modifier);
/*  529 */         mapper.setTypeFactory(f);
/*      */       }
/*      */ 
/*      */       public void addValueInstantiators(ValueInstantiators instantiators)
/*      */       {
/*  534 */         mapper._deserializerProvider = mapper._deserializerProvider.withValueInstantiators(instantiators);
/*      */       }
/*      */ 
/*      */       public void insertAnnotationIntrospector(AnnotationIntrospector ai)
/*      */       {
/*  539 */         mapper._deserializationConfig = mapper._deserializationConfig.withInsertedAnnotationIntrospector(ai);
/*  540 */         mapper._serializationConfig = mapper._serializationConfig.withInsertedAnnotationIntrospector(ai);
/*      */       }
/*      */ 
/*      */       public void appendAnnotationIntrospector(AnnotationIntrospector ai)
/*      */       {
/*  545 */         mapper._deserializationConfig = mapper._deserializationConfig.withAppendedAnnotationIntrospector(ai);
/*  546 */         mapper._serializationConfig = mapper._serializationConfig.withAppendedAnnotationIntrospector(ai);
/*      */       }
/*      */ 
/*      */       public void setMixInAnnotations(Class<?> target, Class<?> mixinSource)
/*      */       {
/*  551 */         mapper._deserializationConfig.addMixInAnnotations(target, mixinSource);
/*  552 */         mapper._serializationConfig.addMixInAnnotations(target, mixinSource);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public ObjectMapper withModule(Module module)
/*      */   {
/*  573 */     registerModule(module);
/*  574 */     return this;
/*      */   }
/*      */ 
/*      */   public SerializationConfig getSerializationConfig()
/*      */   {
/*  591 */     return this._serializationConfig;
/*      */   }
/*      */ 
/*      */   public SerializationConfig copySerializationConfig()
/*      */   {
/*  608 */     return this._serializationConfig.createUnshared(this._subtypeResolver);
/*      */   }
/*      */ 
/*      */   public ObjectMapper setSerializationConfig(SerializationConfig cfg)
/*      */   {
/*  616 */     this._serializationConfig = cfg;
/*  617 */     return this;
/*      */   }
/*      */ 
/*      */   public DeserializationConfig getDeserializationConfig()
/*      */   {
/*  629 */     return this._deserializationConfig;
/*      */   }
/*      */ 
/*      */   public DeserializationConfig copyDeserializationConfig()
/*      */   {
/*  647 */     return this._deserializationConfig.createUnshared(this._subtypeResolver).passSerializationFeatures(this._serializationConfig._featureFlags);
/*      */   }
/*      */ 
/*      */   public ObjectMapper setDeserializationConfig(DeserializationConfig cfg)
/*      */   {
/*  656 */     this._deserializationConfig = cfg;
/*  657 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper setSerializerFactory(SerializerFactory f)
/*      */   {
/*  671 */     this._serializerFactory = f;
/*  672 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper setSerializerProvider(SerializerProvider p)
/*      */   {
/*  680 */     this._serializerProvider = p;
/*  681 */     return this;
/*      */   }
/*      */ 
/*      */   public SerializerProvider getSerializerProvider()
/*      */   {
/*  688 */     return this._serializerProvider;
/*      */   }
/*      */ 
/*      */   public ObjectMapper setDeserializerProvider(DeserializerProvider p)
/*      */   {
/*  696 */     this._deserializerProvider = p;
/*  697 */     return this;
/*      */   }
/*      */ 
/*      */   public DeserializerProvider getDeserializerProvider()
/*      */   {
/*  704 */     return this._deserializerProvider;
/*      */   }
/*      */ 
/*      */   public VisibilityChecker<?> getVisibilityChecker()
/*      */   {
/*  721 */     return this._serializationConfig.getDefaultVisibilityChecker();
/*      */   }
/*      */ 
/*      */   public void setVisibilityChecker(VisibilityChecker<?> vc)
/*      */   {
/*  734 */     this._deserializationConfig = this._deserializationConfig.withVisibilityChecker(vc);
/*  735 */     this._serializationConfig = this._serializationConfig.withVisibilityChecker(vc);
/*      */   }
/*      */ 
/*      */   public ObjectMapper setVisibility(JsonMethod forMethod, JsonAutoDetect.Visibility visibility)
/*      */   {
/*  766 */     this._deserializationConfig = this._deserializationConfig.withVisibility(forMethod, visibility);
/*  767 */     this._serializationConfig = this._serializationConfig.withVisibility(forMethod, visibility);
/*  768 */     return this;
/*      */   }
/*      */ 
/*      */   public SubtypeResolver getSubtypeResolver()
/*      */   {
/*  777 */     if (this._subtypeResolver == null) {
/*  778 */       this._subtypeResolver = new StdSubtypeResolver();
/*      */     }
/*  780 */     return this._subtypeResolver;
/*      */   }
/*      */ 
/*      */   public void setSubtypeResolver(SubtypeResolver r)
/*      */   {
/*  789 */     this._subtypeResolver = r;
/*      */   }
/*      */ 
/*      */   public ObjectMapper setAnnotationIntrospector(AnnotationIntrospector ai)
/*      */   {
/*  799 */     this._serializationConfig = this._serializationConfig.withAnnotationIntrospector(ai);
/*  800 */     this._deserializationConfig = this._deserializationConfig.withAnnotationIntrospector(ai);
/*  801 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper setPropertyNamingStrategy(PropertyNamingStrategy s)
/*      */   {
/*  810 */     this._serializationConfig = this._serializationConfig.withPropertyNamingStrategy(s);
/*  811 */     this._deserializationConfig = this._deserializationConfig.withPropertyNamingStrategy(s);
/*  812 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper setSerializationInclusion(JsonSerialize.Inclusion incl)
/*      */   {
/*  825 */     this._serializationConfig = this._serializationConfig.withSerializationInclusion(incl);
/*  826 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper enableDefaultTyping()
/*      */   {
/*  842 */     return enableDefaultTyping(DefaultTyping.OBJECT_AND_NON_CONCRETE);
/*      */   }
/*      */ 
/*      */   public ObjectMapper enableDefaultTyping(DefaultTyping dti)
/*      */   {
/*  852 */     return enableDefaultTyping(dti, JsonTypeInfo.As.WRAPPER_ARRAY);
/*      */   }
/*      */ 
/*      */   public ObjectMapper enableDefaultTyping(DefaultTyping applicability, JsonTypeInfo.As includeAs)
/*      */   {
/*  865 */     TypeResolverBuilder typer = new DefaultTypeResolverBuilder(applicability);
/*      */ 
/*  867 */     typer = typer.init(JsonTypeInfo.Id.CLASS, null);
/*  868 */     typer = typer.inclusion(includeAs);
/*  869 */     return setDefaultTyping(typer);
/*      */   }
/*      */ 
/*      */   public ObjectMapper enableDefaultTypingAsProperty(DefaultTyping applicability, String propertyName)
/*      */   {
/*  884 */     TypeResolverBuilder typer = new DefaultTypeResolverBuilder(applicability);
/*      */ 
/*  886 */     typer = typer.init(JsonTypeInfo.Id.CLASS, null);
/*  887 */     typer = typer.inclusion(JsonTypeInfo.As.PROPERTY);
/*  888 */     typer = typer.typeProperty(propertyName);
/*  889 */     return setDefaultTyping(typer);
/*      */   }
/*      */ 
/*      */   public ObjectMapper disableDefaultTyping()
/*      */   {
/*  899 */     return setDefaultTyping(null);
/*      */   }
/*      */ 
/*      */   public ObjectMapper setDefaultTyping(TypeResolverBuilder<?> typer)
/*      */   {
/*  912 */     this._deserializationConfig = this._deserializationConfig.withTypeResolverBuilder(typer);
/*  913 */     this._serializationConfig = this._serializationConfig.withTypeResolverBuilder(typer);
/*  914 */     return this;
/*      */   }
/*      */ 
/*      */   public void registerSubtypes(Class<?>[] classes)
/*      */   {
/*  927 */     getSubtypeResolver().registerSubtypes(classes);
/*      */   }
/*      */ 
/*      */   public void registerSubtypes(NamedType[] types)
/*      */   {
/*  941 */     getSubtypeResolver().registerSubtypes(types);
/*      */   }
/*      */ 
/*      */   public TypeFactory getTypeFactory()
/*      */   {
/*  956 */     return this._typeFactory;
/*      */   }
/*      */ 
/*      */   public ObjectMapper setTypeFactory(TypeFactory f)
/*      */   {
/*  968 */     this._typeFactory = f;
/*  969 */     this._deserializationConfig = this._deserializationConfig.withTypeFactory(f);
/*  970 */     this._serializationConfig = this._serializationConfig.withTypeFactory(f);
/*  971 */     return this;
/*      */   }
/*      */ 
/*      */   public JavaType constructType(Type t)
/*      */   {
/*  982 */     return this._typeFactory.constructType(t);
/*      */   }
/*      */ 
/*      */   public ObjectMapper setNodeFactory(JsonNodeFactory f)
/*      */   {
/*  999 */     this._deserializationConfig = this._deserializationConfig.withNodeFactory(f);
/* 1000 */     return this;
/*      */   }
/*      */ 
/*      */   public void setFilters(FilterProvider filterProvider)
/*      */   {
/* 1022 */     this._serializationConfig = this._serializationConfig.withFilters(filterProvider);
/*      */   }
/*      */ 
/*      */   public JsonFactory getJsonFactory()
/*      */   {
/* 1039 */     return this._jsonFactory;
/*      */   }
/*      */ 
/*      */   public void setDateFormat(DateFormat dateFormat)
/*      */   {
/* 1055 */     this._deserializationConfig = this._deserializationConfig.withDateFormat(dateFormat);
/* 1056 */     this._serializationConfig = this._serializationConfig.withDateFormat(dateFormat);
/*      */   }
/*      */ 
/*      */   public void setHandlerInstantiator(HandlerInstantiator hi)
/*      */   {
/* 1068 */     this._deserializationConfig = this._deserializationConfig.withHandlerInstantiator(hi);
/* 1069 */     this._serializationConfig = this._serializationConfig.withHandlerInstantiator(hi);
/*      */   }
/*      */ 
/*      */   public ObjectMapper setInjectableValues(InjectableValues injectableValues)
/*      */   {
/* 1076 */     this._injectableValues = injectableValues;
/* 1077 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper configure(SerializationConfig.Feature f, boolean state)
/*      */   {
/* 1096 */     this._serializationConfig.set(f, state);
/* 1097 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper configure(DeserializationConfig.Feature f, boolean state)
/*      */   {
/* 1110 */     this._deserializationConfig.set(f, state);
/* 1111 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper configure(JsonParser.Feature f, boolean state)
/*      */   {
/* 1126 */     this._jsonFactory.configure(f, state);
/* 1127 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper configure(JsonGenerator.Feature f, boolean state)
/*      */   {
/* 1142 */     this._jsonFactory.configure(f, state);
/* 1143 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper enable(DeserializationConfig.Feature[] f)
/*      */   {
/* 1153 */     this._deserializationConfig = this._deserializationConfig.with(f);
/* 1154 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper disable(DeserializationConfig.Feature[] f)
/*      */   {
/* 1164 */     this._deserializationConfig = this._deserializationConfig.without(f);
/* 1165 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper enable(SerializationConfig.Feature[] f)
/*      */   {
/* 1175 */     this._serializationConfig = this._serializationConfig.with(f);
/* 1176 */     return this;
/*      */   }
/*      */ 
/*      */   public ObjectMapper disable(SerializationConfig.Feature[] f)
/*      */   {
/* 1186 */     this._serializationConfig = this._serializationConfig.without(f);
/* 1187 */     return this;
/*      */   }
/*      */ 
/*      */   public boolean isEnabled(SerializationConfig.Feature f)
/*      */   {
/* 1199 */     return this._serializationConfig.isEnabled(f);
/*      */   }
/*      */ 
/*      */   public boolean isEnabled(DeserializationConfig.Feature f)
/*      */   {
/* 1211 */     return this._deserializationConfig.isEnabled(f);
/*      */   }
/*      */ 
/*      */   public boolean isEnabled(JsonParser.Feature f)
/*      */   {
/* 1223 */     return this._jsonFactory.isEnabled(f);
/*      */   }
/*      */ 
/*      */   public boolean isEnabled(JsonGenerator.Feature f)
/*      */   {
/* 1235 */     return this._jsonFactory.isEnabled(f);
/*      */   }
/*      */ 
/*      */   public JsonNodeFactory getNodeFactory()
/*      */   {
/* 1251 */     return this._deserializationConfig.getNodeFactory();
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonParser jp, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1279 */     return _readValue(copyDeserializationConfig(), jp, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonParser jp, TypeReference<?> valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1294 */     return _readValue(copyDeserializationConfig(), jp, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonParser jp, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1308 */     return _readValue(copyDeserializationConfig(), jp, valueType);
/*      */   }
/*      */ 
/*      */   public JsonNode readTree(JsonParser jp)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1329 */     DeserializationConfig cfg = copyDeserializationConfig();
/* 1330 */     JsonToken t = jp.getCurrentToken();
/* 1331 */     if (t == null) {
/* 1332 */       t = jp.nextToken();
/* 1333 */       if (t == null) {
/* 1334 */         return null;
/*      */       }
/*      */     }
/* 1337 */     JsonNode n = (JsonNode)_readValue(cfg, jp, JSON_NODE_TYPE);
/* 1338 */     return n == null ? getNodeFactory().nullNode() : n;
/*      */   }
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(JsonParser jp, JavaType valueType)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1352 */     DeserializationConfig config = copyDeserializationConfig();
/* 1353 */     DeserializationContext ctxt = _createDeserializationContext(jp, config);
/* 1354 */     JsonDeserializer deser = _findRootDeserializer(config, valueType);
/* 1355 */     return new MappingIterator(valueType, jp, ctxt, deser);
/*      */   }
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(JsonParser jp, Class<T> valueType)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1367 */     return readValues(jp, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(JsonParser jp, TypeReference<?> valueTypeRef)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1379 */     return readValues(jp, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonParser jp, Class<T> valueType, DeserializationConfig cfg)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1413 */     return _readValue(cfg, jp, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonParser jp, TypeReference<?> valueTypeRef, DeserializationConfig cfg)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1436 */     return _readValue(cfg, jp, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonParser jp, JavaType valueType, DeserializationConfig cfg)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1458 */     return _readValue(cfg, jp, valueType);
/*      */   }
/*      */ 
/*      */   public JsonNode readTree(JsonParser jp, DeserializationConfig cfg)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1479 */     JsonNode n = (JsonNode)_readValue(cfg, jp, JSON_NODE_TYPE);
/* 1480 */     return n == null ? NullNode.instance : n;
/*      */   }
/*      */ 
/*      */   public JsonNode readTree(InputStream in)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1498 */     JsonNode n = (JsonNode)_readMapAndClose(this._jsonFactory.createJsonParser(in), JSON_NODE_TYPE);
/* 1499 */     return n == null ? NullNode.instance : n;
/*      */   }
/*      */ 
/*      */   public JsonNode readTree(Reader r)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1517 */     JsonNode n = (JsonNode)_readMapAndClose(this._jsonFactory.createJsonParser(r), JSON_NODE_TYPE);
/* 1518 */     return n == null ? NullNode.instance : n;
/*      */   }
/*      */ 
/*      */   public JsonNode readTree(String content)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1533 */     JsonNode n = (JsonNode)_readMapAndClose(this._jsonFactory.createJsonParser(content), JSON_NODE_TYPE);
/* 1534 */     return n == null ? NullNode.instance : n;
/*      */   }
/*      */ 
/*      */   public JsonNode readTree(byte[] content)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1549 */     JsonNode n = (JsonNode)_readMapAndClose(this._jsonFactory.createJsonParser(content), JSON_NODE_TYPE);
/* 1550 */     return n == null ? NullNode.instance : n;
/*      */   }
/*      */ 
/*      */   public JsonNode readTree(File file)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1565 */     JsonNode n = (JsonNode)_readMapAndClose(this._jsonFactory.createJsonParser(file), JSON_NODE_TYPE);
/* 1566 */     return n == null ? NullNode.instance : n;
/*      */   }
/*      */ 
/*      */   public JsonNode readTree(URL source)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1581 */     JsonNode n = (JsonNode)_readMapAndClose(this._jsonFactory.createJsonParser(source), JSON_NODE_TYPE);
/* 1582 */     return n == null ? NullNode.instance : n;
/*      */   }
/*      */ 
/*      */   public void writeValue(JsonGenerator jgen, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 1600 */     SerializationConfig config = copySerializationConfig();
/* 1601 */     if ((config.isEnabled(SerializationConfig.Feature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 1602 */       _writeCloseableValue(jgen, value, config);
/*      */     } else {
/* 1604 */       this._serializerProvider.serializeValue(config, jgen, value, this._serializerFactory);
/* 1605 */       if (config.isEnabled(SerializationConfig.Feature.FLUSH_AFTER_WRITE_VALUE))
/* 1606 */         jgen.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeValue(JsonGenerator jgen, Object value, SerializationConfig config)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 1622 */     if ((config.isEnabled(SerializationConfig.Feature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 1623 */       _writeCloseableValue(jgen, value, config);
/*      */     } else {
/* 1625 */       this._serializerProvider.serializeValue(config, jgen, value, this._serializerFactory);
/* 1626 */       if (config.isEnabled(SerializationConfig.Feature.FLUSH_AFTER_WRITE_VALUE))
/* 1627 */         jgen.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeTree(JsonGenerator jgen, JsonNode rootNode)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1640 */     SerializationConfig config = copySerializationConfig();
/* 1641 */     this._serializerProvider.serializeValue(config, jgen, rootNode, this._serializerFactory);
/* 1642 */     if (config.isEnabled(SerializationConfig.Feature.FLUSH_AFTER_WRITE_VALUE))
/* 1643 */       jgen.flush();
/*      */   }
/*      */ 
/*      */   public void writeTree(JsonGenerator jgen, JsonNode rootNode, SerializationConfig cfg)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1657 */     this._serializerProvider.serializeValue(cfg, jgen, rootNode, this._serializerFactory);
/* 1658 */     if (cfg.isEnabled(SerializationConfig.Feature.FLUSH_AFTER_WRITE_VALUE))
/* 1659 */       jgen.flush();
/*      */   }
/*      */ 
/*      */   public ObjectNode createObjectNode()
/*      */   {
/* 1680 */     return this._deserializationConfig.getNodeFactory().objectNode();
/*      */   }
/*      */ 
/*      */   public ArrayNode createArrayNode()
/*      */   {
/* 1694 */     return this._deserializationConfig.getNodeFactory().arrayNode();
/*      */   }
/*      */ 
/*      */   public JsonParser treeAsTokens(JsonNode n)
/*      */   {
/* 1708 */     return new TreeTraversingParser(n, this);
/*      */   }
/*      */ 
/*      */   public <T> T treeToValue(JsonNode n, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1724 */     return readValue(treeAsTokens(n), valueType);
/*      */   }
/*      */ 
/*      */   public <T extends JsonNode> T valueToTree(Object fromValue)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1744 */     if (fromValue == null) return null; TokenBuffer buf = new TokenBuffer(this);
/*      */     JsonNode result;
/*      */     try {
/* 1748 */       writeValue(buf, fromValue);
/* 1749 */       JsonParser jp = buf.asParser();
/* 1750 */       result = readTree(jp);
/* 1751 */       jp.close();
/*      */     } catch (IOException e) {
/* 1753 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     }
/* 1755 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean canSerialize(Class<?> type)
/*      */   {
/* 1776 */     return this._serializerProvider.hasSerializerFor(copySerializationConfig(), type, this._serializerFactory);
/*      */   }
/*      */ 
/*      */   public boolean canDeserialize(JavaType type)
/*      */   {
/* 1792 */     return this._deserializerProvider.hasValueDeserializerFor(copyDeserializationConfig(), type);
/*      */   }
/*      */ 
/*      */   public <T> T readValue(File src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1808 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(File src, TypeReference valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1815 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(File src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1822 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), valueType);
/*      */   }
/*      */ 
/*      */   public <T> T readValue(URL src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1831 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(URL src, TypeReference valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1838 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(URL src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1845 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), valueType);
/*      */   }
/*      */ 
/*      */   public <T> T readValue(String content, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1854 */     return _readMapAndClose(this._jsonFactory.createJsonParser(content), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(String content, TypeReference valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1861 */     return _readMapAndClose(this._jsonFactory.createJsonParser(content), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(String content, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1868 */     return _readMapAndClose(this._jsonFactory.createJsonParser(content), valueType);
/*      */   }
/*      */ 
/*      */   public <T> T readValue(Reader src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1877 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(Reader src, TypeReference valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1884 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(Reader src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1891 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), valueType);
/*      */   }
/*      */ 
/*      */   public <T> T readValue(InputStream src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1900 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(InputStream src, TypeReference valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1907 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(InputStream src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1914 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), valueType);
/*      */   }
/*      */ 
/*      */   public <T> T readValue(byte[] src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1926 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(byte[] src, int offset, int len, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1936 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src, offset, len), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(byte[] src, TypeReference valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1946 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(byte[] src, int offset, int len, TypeReference valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1954 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src, offset, len), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(byte[] src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1964 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src), valueType);
/*      */   }
/*      */ 
/*      */   public <T> T readValue(byte[] src, int offset, int len, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1972 */     return _readMapAndClose(this._jsonFactory.createJsonParser(src, offset, len), valueType);
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonNode root, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 1990 */     return _readValue(copyDeserializationConfig(), treeAsTokens(root), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonNode root, TypeReference valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2006 */     return _readValue(copyDeserializationConfig(), treeAsTokens(root), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T readValue(JsonNode root, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2022 */     return _readValue(copyDeserializationConfig(), treeAsTokens(root), valueType);
/*      */   }
/*      */ 
/*      */   public void writeValue(File resultFile, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 2039 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(resultFile, JsonEncoding.UTF8), value);
/*      */   }
/*      */ 
/*      */   public void writeValue(OutputStream out, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 2056 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(out, JsonEncoding.UTF8), value);
/*      */   }
/*      */ 
/*      */   public void writeValue(Writer w, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 2072 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(w), value);
/*      */   }
/*      */ 
/*      */   public String writeValueAsString(Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 2087 */     SegmentedStringWriter sw = new SegmentedStringWriter(this._jsonFactory._getBufferRecycler());
/* 2088 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(sw), value);
/* 2089 */     return sw.getAndClear();
/*      */   }
/*      */ 
/*      */   public byte[] writeValueAsBytes(Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 2104 */     ByteArrayBuilder bb = new ByteArrayBuilder(this._jsonFactory._getBufferRecycler());
/* 2105 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(bb, JsonEncoding.UTF8), value);
/* 2106 */     byte[] result = bb.toByteArray();
/* 2107 */     bb.release();
/* 2108 */     return result;
/*      */   }
/*      */ 
/*      */   public ObjectWriter writer()
/*      */   {
/* 2125 */     return new ObjectWriter(this, copySerializationConfig());
/*      */   }
/*      */ 
/*      */   public ObjectWriter writer(DateFormat df)
/*      */   {
/* 2136 */     return new ObjectWriter(this, copySerializationConfig().withDateFormat(df));
/*      */   }
/*      */ 
/*      */   public ObjectWriter writerWithView(Class<?> serializationView)
/*      */   {
/* 2147 */     return new ObjectWriter(this, copySerializationConfig().withView(serializationView));
/*      */   }
/*      */ 
/*      */   public ObjectWriter writerWithType(Class<?> rootType)
/*      */   {
/* 2159 */     JavaType t = rootType == null ? null : this._typeFactory.constructType(rootType);
/* 2160 */     return new ObjectWriter(this, copySerializationConfig(), t, null);
/*      */   }
/*      */ 
/*      */   public ObjectWriter writerWithType(JavaType rootType)
/*      */   {
/* 2171 */     return new ObjectWriter(this, copySerializationConfig(), rootType, null);
/*      */   }
/*      */ 
/*      */   public ObjectWriter writerWithType(TypeReference<?> rootType)
/*      */   {
/* 2182 */     JavaType t = rootType == null ? null : this._typeFactory.constructType(rootType);
/* 2183 */     return new ObjectWriter(this, copySerializationConfig(), t, null);
/*      */   }
/*      */ 
/*      */   public ObjectWriter writer(PrettyPrinter pp)
/*      */   {
/* 2194 */     if (pp == null) {
/* 2195 */       pp = ObjectWriter.NULL_PRETTY_PRINTER;
/*      */     }
/* 2197 */     return new ObjectWriter(this, copySerializationConfig(), null, pp);
/*      */   }
/*      */ 
/*      */   public ObjectWriter writerWithDefaultPrettyPrinter()
/*      */   {
/* 2207 */     return new ObjectWriter(this, copySerializationConfig(), null, _defaultPrettyPrinter());
/*      */   }
/*      */ 
/*      */   public ObjectWriter writer(FilterProvider filterProvider)
/*      */   {
/* 2218 */     return new ObjectWriter(this, copySerializationConfig().withFilters(filterProvider));
/*      */   }
/*      */ 
/*      */   public ObjectWriter writer(FormatSchema schema)
/*      */   {
/* 2232 */     return new ObjectWriter(this, copySerializationConfig(), schema);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter typedWriter(Class<?> rootType)
/*      */   {
/* 2246 */     return writerWithType(rootType);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter typedWriter(JavaType rootType)
/*      */   {
/* 2254 */     return writerWithType(rootType);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter typedWriter(TypeReference<?> rootType)
/*      */   {
/* 2262 */     return writerWithType(rootType);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter viewWriter(Class<?> serializationView)
/*      */   {
/* 2270 */     return writerWithView(serializationView);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter prettyPrintingWriter(PrettyPrinter pp)
/*      */   {
/* 2278 */     return writer(pp);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter defaultPrettyPrintingWriter()
/*      */   {
/* 2286 */     return writerWithDefaultPrettyPrinter();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter filteredWriter(FilterProvider filterProvider)
/*      */   {
/* 2294 */     return writer(filterProvider);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter schemaBasedWriter(FormatSchema schema)
/*      */   {
/* 2302 */     return writer(schema);
/*      */   }
/*      */ 
/*      */   public ObjectReader reader()
/*      */   {
/* 2320 */     return new ObjectReader(this, copyDeserializationConfig()).withInjectableValues(this._injectableValues);
/*      */   }
/*      */ 
/*      */   public ObjectReader readerForUpdating(Object valueToUpdate)
/*      */   {
/* 2338 */     JavaType t = this._typeFactory.constructType(valueToUpdate.getClass());
/* 2339 */     return new ObjectReader(this, copyDeserializationConfig(), t, valueToUpdate, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */   public ObjectReader reader(JavaType type)
/*      */   {
/* 2351 */     return new ObjectReader(this, copyDeserializationConfig(), type, null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */   public ObjectReader reader(Class<?> type)
/*      */   {
/* 2363 */     return reader(this._typeFactory.constructType(type));
/*      */   }
/*      */ 
/*      */   public ObjectReader reader(TypeReference<?> type)
/*      */   {
/* 2374 */     return reader(this._typeFactory.constructType(type));
/*      */   }
/*      */ 
/*      */   public ObjectReader reader(JsonNodeFactory f)
/*      */   {
/* 2385 */     return new ObjectReader(this, copyDeserializationConfig()).withNodeFactory(f);
/*      */   }
/*      */ 
/*      */   public ObjectReader reader(FormatSchema schema)
/*      */   {
/* 2398 */     return new ObjectReader(this, copyDeserializationConfig(), null, null, schema, this._injectableValues);
/*      */   }
/*      */ 
/*      */   public ObjectReader reader(InjectableValues injectableValues)
/*      */   {
/* 2411 */     return new ObjectReader(this, copyDeserializationConfig(), null, null, null, injectableValues);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader updatingReader(Object valueToUpdate)
/*      */   {
/* 2426 */     return readerForUpdating(valueToUpdate);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader schemaBasedReader(FormatSchema schema)
/*      */   {
/* 2434 */     return reader(schema);
/*      */   }
/*      */ 
/*      */   public <T> T convertValue(Object fromValue, Class<T> toValueType)
/*      */     throws IllegalArgumentException
/*      */   {
/* 2459 */     return _convert(fromValue, this._typeFactory.constructType(toValueType));
/*      */   }
/*      */ 
/*      */   public <T> T convertValue(Object fromValue, TypeReference toValueTypeRef)
/*      */     throws IllegalArgumentException
/*      */   {
/* 2466 */     return _convert(fromValue, this._typeFactory.constructType(toValueTypeRef));
/*      */   }
/*      */ 
/*      */   public <T> T convertValue(Object fromValue, JavaType toValueType)
/*      */     throws IllegalArgumentException
/*      */   {
/* 2473 */     return _convert(fromValue, toValueType);
/*      */   }
/*      */ 
/*      */   protected Object _convert(Object fromValue, JavaType toValueType)
/*      */     throws IllegalArgumentException
/*      */   {
/* 2480 */     if (fromValue == null) return null;
/*      */ 
/* 2484 */     TokenBuffer buf = new TokenBuffer(this);
/*      */     try {
/* 2486 */       writeValue(buf, fromValue);
/*      */ 
/* 2488 */       JsonParser jp = buf.asParser();
/* 2489 */       Object result = readValue(jp, toValueType);
/* 2490 */       jp.close();
/* 2491 */       return result;
/*      */     } catch (IOException e) {
/* 2493 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public JsonSchema generateJsonSchema(Class<?> t)
/*      */     throws JsonMappingException
/*      */   {
/* 2513 */     return generateJsonSchema(t, copySerializationConfig());
/*      */   }
/*      */ 
/*      */   public JsonSchema generateJsonSchema(Class<?> t, SerializationConfig cfg)
/*      */     throws JsonMappingException
/*      */   {
/* 2527 */     return this._serializerProvider.generateJsonSchema(t, cfg, this._serializerFactory);
/*      */   }
/*      */ 
/*      */   protected PrettyPrinter _defaultPrettyPrinter()
/*      */   {
/* 2544 */     return new DefaultPrettyPrinter();
/*      */   }
/*      */ 
/*      */   protected final void _configAndWriteValue(JsonGenerator jgen, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 2554 */     SerializationConfig cfg = copySerializationConfig();
/*      */ 
/* 2556 */     if (cfg.isEnabled(SerializationConfig.Feature.INDENT_OUTPUT)) {
/* 2557 */       jgen.useDefaultPrettyPrinter();
/*      */     }
/*      */ 
/* 2560 */     if ((cfg.isEnabled(SerializationConfig.Feature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 2561 */       _configAndWriteCloseable(jgen, value, cfg);
/* 2562 */       return;
/*      */     }
/* 2564 */     boolean closed = false;
/*      */     try {
/* 2566 */       this._serializerProvider.serializeValue(cfg, jgen, value, this._serializerFactory);
/* 2567 */       closed = true;
/* 2568 */       jgen.close();
/*      */     }
/*      */     finally
/*      */     {
/* 2573 */       if (!closed)
/*      */         try {
/* 2575 */           jgen.close();
/*      */         }
/*      */         catch (IOException ioe)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void _configAndWriteValue(JsonGenerator jgen, Object value, Class<?> viewClass) throws IOException, JsonGenerationException, JsonMappingException {
/* 2584 */     SerializationConfig cfg = copySerializationConfig().withView(viewClass);
/* 2585 */     if (cfg.isEnabled(SerializationConfig.Feature.INDENT_OUTPUT)) {
/* 2586 */       jgen.useDefaultPrettyPrinter();
/*      */     }
/*      */ 
/* 2589 */     if ((cfg.isEnabled(SerializationConfig.Feature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 2590 */       _configAndWriteCloseable(jgen, value, cfg);
/* 2591 */       return;
/*      */     }
/* 2593 */     boolean closed = false;
/*      */     try {
/* 2595 */       this._serializerProvider.serializeValue(cfg, jgen, value, this._serializerFactory);
/* 2596 */       closed = true;
/* 2597 */       jgen.close();
/*      */     } finally {
/* 2599 */       if (!closed)
/*      */         try {
/* 2601 */           jgen.close();
/*      */         }
/*      */         catch (IOException ioe)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _configAndWriteCloseable(JsonGenerator jgen, Object value, SerializationConfig cfg)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 2614 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 2616 */       this._serializerProvider.serializeValue(cfg, jgen, value, this._serializerFactory);
/* 2617 */       JsonGenerator tmpJgen = jgen;
/* 2618 */       jgen = null;
/* 2619 */       tmpJgen.close();
/* 2620 */       Closeable tmpToClose = toClose;
/* 2621 */       toClose = null;
/* 2622 */       tmpToClose.close();
/*      */     }
/*      */     finally
/*      */     {
/* 2627 */       if (jgen != null)
/*      */         try {
/* 2629 */           jgen.close();
/*      */         } catch (IOException ioe) {
/*      */         }
/* 2632 */       if (toClose != null)
/*      */         try {
/* 2634 */           toClose.close();
/*      */         }
/*      */         catch (IOException ioe)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _writeCloseableValue(JsonGenerator jgen, Object value, SerializationConfig cfg)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 2647 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 2649 */       this._serializerProvider.serializeValue(cfg, jgen, value, this._serializerFactory);
/* 2650 */       if (cfg.isEnabled(SerializationConfig.Feature.FLUSH_AFTER_WRITE_VALUE)) {
/* 2651 */         jgen.flush();
/*      */       }
/* 2653 */       Closeable tmpToClose = toClose;
/* 2654 */       toClose = null;
/* 2655 */       tmpToClose.close();
/*      */     } finally {
/* 2657 */       if (toClose != null)
/*      */         try {
/* 2659 */           toClose.close();
/*      */         }
/*      */         catch (IOException ioe)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Object _readValue(DeserializationConfig cfg, JsonParser jp, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2682 */     JsonToken t = _initForReading(jp);
/*      */     Object result;
/*      */     Object result;
/* 2683 */     if (t == JsonToken.VALUE_NULL)
/*      */     {
/* 2685 */       result = _findRootDeserializer(cfg, valueType).getNullValue();
/*      */     }
/*      */     else
/*      */     {
/*      */       Object result;
/* 2686 */       if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 2687 */         result = null;
/*      */       } else {
/* 2689 */         DeserializationContext ctxt = _createDeserializationContext(jp, cfg);
/* 2690 */         JsonDeserializer deser = _findRootDeserializer(cfg, valueType);
/*      */         Object result;
/* 2692 */         if (cfg.isEnabled(DeserializationConfig.Feature.UNWRAP_ROOT_VALUE))
/* 2693 */           result = _unwrapAndDeserialize(jp, valueType, ctxt, deser);
/*      */         else {
/* 2695 */           result = deser.deserialize(jp, ctxt);
/*      */         }
/*      */       }
/*      */     }
/* 2699 */     jp.clearCurrentToken();
/* 2700 */     return result;
/*      */   }
/*      */ 
/*      */   protected Object _readMapAndClose(JsonParser jp, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/*      */     try
/*      */     {
/* 2709 */       JsonToken t = _initForReading(jp);
/*      */       Object result;
/*      */       DeserializationConfig cfg;
/*      */       Object result;
/* 2710 */       if (t == JsonToken.VALUE_NULL)
/*      */       {
/* 2713 */         result = _findRootDeserializer(this._deserializationConfig, valueType).getNullValue();
/*      */       }
/*      */       else
/*      */       {
/*      */         Object result;
/* 2714 */         if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 2715 */           result = null;
/*      */         } else {
/* 2717 */           cfg = copyDeserializationConfig();
/* 2718 */           DeserializationContext ctxt = _createDeserializationContext(jp, cfg);
/* 2719 */           JsonDeserializer deser = _findRootDeserializer(cfg, valueType);
/*      */           Object result;
/* 2720 */           if (cfg.isEnabled(DeserializationConfig.Feature.UNWRAP_ROOT_VALUE))
/* 2721 */             result = _unwrapAndDeserialize(jp, valueType, ctxt, deser);
/*      */           else {
/* 2723 */             result = deser.deserialize(jp, ctxt);
/*      */           }
/*      */         }
/*      */       }
/* 2727 */       jp.clearCurrentToken();
/* 2728 */       return result;
/*      */     } finally {
/*      */       try {
/* 2731 */         jp.close();
/*      */       }
/*      */       catch (IOException ioe)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected JsonToken _initForReading(JsonParser jp)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2758 */     JsonToken t = jp.getCurrentToken();
/* 2759 */     if (t == null)
/*      */     {
/* 2761 */       t = jp.nextToken();
/* 2762 */       if (t == null)
/*      */       {
/* 2766 */         throw new EOFException("No content to map to Object due to end of input");
/*      */       }
/*      */     }
/* 2769 */     return t;
/*      */   }
/*      */ 
/*      */   protected Object _unwrapAndDeserialize(JsonParser jp, JavaType rootType, DeserializationContext ctxt, JsonDeserializer<Object> deser)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2776 */     SerializedString rootName = this._deserializerProvider.findExpectedRootName(ctxt.getConfig(), rootType);
/* 2777 */     if (jp.getCurrentToken() != JsonToken.START_OBJECT) {
/* 2778 */       throw JsonMappingException.from(jp, "Current token not START_OBJECT (needed to unwrap root name '" + rootName + "'), but " + jp.getCurrentToken());
/*      */     }
/*      */ 
/* 2781 */     if (jp.nextToken() != JsonToken.FIELD_NAME) {
/* 2782 */       throw JsonMappingException.from(jp, "Current token not FIELD_NAME (to contain expected root name '" + rootName + "'), but " + jp.getCurrentToken());
/*      */     }
/*      */ 
/* 2785 */     String actualName = jp.getCurrentName();
/* 2786 */     if (!rootName.getValue().equals(actualName)) {
/* 2787 */       throw JsonMappingException.from(jp, "Root name '" + actualName + "' does not match expected ('" + rootName + "') for type " + rootType);
/*      */     }
/*      */ 
/* 2791 */     jp.nextToken();
/*      */ 
/* 2793 */     Object result = deser.deserialize(jp, ctxt);
/*      */ 
/* 2795 */     if (jp.nextToken() != JsonToken.END_OBJECT) {
/* 2796 */       throw JsonMappingException.from(jp, "Current token not END_OBJECT (to match wrapper object with root name '" + rootName + "'), but " + jp.getCurrentToken());
/*      */     }
/*      */ 
/* 2799 */     return result;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<Object> _findRootDeserializer(DeserializationConfig cfg, JavaType valueType)
/*      */     throws JsonMappingException
/*      */   {
/* 2815 */     JsonDeserializer deser = (JsonDeserializer)this._rootDeserializers.get(valueType);
/* 2816 */     if (deser != null) {
/* 2817 */       return deser;
/*      */     }
/*      */ 
/* 2820 */     deser = this._deserializerProvider.findTypedValueDeserializer(cfg, valueType, null);
/* 2821 */     if (deser == null) {
/* 2822 */       throw new JsonMappingException("Can not find a deserializer for type " + valueType);
/*      */     }
/* 2824 */     this._rootDeserializers.put(valueType, deser);
/* 2825 */     return deser;
/*      */   }
/*      */ 
/*      */   protected DeserializationContext _createDeserializationContext(JsonParser jp, DeserializationConfig cfg)
/*      */   {
/* 2830 */     return new StdDeserializationContext(cfg, jp, this._deserializerProvider, this._injectableValues);
/*      */   }
/*      */ 
/*      */   public static class DefaultTypeResolverBuilder extends StdTypeResolverBuilder
/*      */   {
/*      */     protected final ObjectMapper.DefaultTyping _appliesFor;
/*      */ 
/*      */     public DefaultTypeResolverBuilder(ObjectMapper.DefaultTyping t)
/*      */     {
/*  129 */       this._appliesFor = t;
/*      */     }
/*      */ 
/*      */     public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes, BeanProperty property)
/*      */     {
/*  136 */       return useForType(baseType) ? super.buildTypeDeserializer(config, baseType, subtypes, property) : null;
/*      */     }
/*      */ 
/*      */     public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes, BeanProperty property)
/*      */     {
/*  143 */       return useForType(baseType) ? super.buildTypeSerializer(config, baseType, subtypes, property) : null;
/*      */     }
/*      */ 
/*      */     public boolean useForType(JavaType t)
/*      */     {
/*  156 */       switch (ObjectMapper.2.$SwitchMap$org$codehaus$jackson$map$ObjectMapper$DefaultTyping[this._appliesFor.ordinal()]) {
/*      */       case 1:
/*  158 */         if (t.isArrayType()) {
/*  159 */           t = t.getContentType();
/*      */         }
/*      */ 
/*      */       case 2:
/*  163 */         return (t.getRawClass() == Object.class) || (!t.isConcrete());
/*      */       case 3:
/*  165 */         if (t.isArrayType()) {
/*  166 */           t = t.getContentType();
/*      */         }
/*  168 */         return !t.isFinal();
/*      */       }
/*      */ 
/*  171 */       return t.getRawClass() == Object.class;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum DefaultTyping
/*      */   {
/*   83 */     JAVA_LANG_OBJECT, 
/*      */ 
/*   91 */     OBJECT_AND_NON_CONCRETE, 
/*      */ 
/*   98 */     NON_CONCRETE_AND_ARRAYS, 
/*      */ 
/*  107 */     NON_FINAL;
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ObjectMapper
 * JD-Core Version:    0.6.2
 */