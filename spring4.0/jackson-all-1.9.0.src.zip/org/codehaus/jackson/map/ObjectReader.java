/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URL;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.codehaus.jackson.FormatSchema;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.JsonParseException;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.ObjectCodec;
/*     */ import org.codehaus.jackson.Version;
/*     */ import org.codehaus.jackson.Versioned;
/*     */ import org.codehaus.jackson.io.SerializedString;
/*     */ import org.codehaus.jackson.map.deser.StdDeserializationContext;
/*     */ import org.codehaus.jackson.map.type.SimpleType;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.node.JsonNodeFactory;
/*     */ import org.codehaus.jackson.node.NullNode;
/*     */ import org.codehaus.jackson.node.TreeTraversingParser;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.codehaus.jackson.type.TypeReference;
/*     */ import org.codehaus.jackson.util.VersionUtil;
/*     */ 
/*     */ public class ObjectReader extends ObjectCodec
/*     */   implements Versioned
/*     */ {
/*  36 */   private static final JavaType JSON_NODE_TYPE = SimpleType.constructUnsafe(JsonNode.class);
/*     */   protected final DeserializationConfig _config;
/*     */   protected final boolean _unwrapRoot;
/*     */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _rootDeserializers;
/*     */   protected final DeserializerProvider _provider;
/*     */   protected final JsonFactory _jsonFactory;
/*     */   protected final JavaType _valueType;
/*     */   protected final Object _valueToUpdate;
/*     */   protected final FormatSchema _schema;
/*     */   protected final InjectableValues _injectableValues;
/*     */ 
/*     */   protected ObjectReader(ObjectMapper mapper, DeserializationConfig config)
/*     */   {
/* 124 */     this(mapper, config, null, null, null, null);
/*     */   }
/*     */ 
/*     */   protected ObjectReader(ObjectMapper mapper, DeserializationConfig config, JavaType valueType, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues)
/*     */   {
/* 131 */     this._config = config;
/* 132 */     this._rootDeserializers = mapper._rootDeserializers;
/* 133 */     this._provider = mapper._deserializerProvider;
/* 134 */     this._jsonFactory = mapper._jsonFactory;
/* 135 */     this._valueType = valueType;
/* 136 */     this._valueToUpdate = valueToUpdate;
/* 137 */     if ((valueToUpdate != null) && (valueType.isArrayType())) {
/* 138 */       throw new IllegalArgumentException("Can not update an array value");
/*     */     }
/* 140 */     this._schema = schema;
/* 141 */     this._injectableValues = injectableValues;
/* 142 */     this._unwrapRoot = config.isEnabled(DeserializationConfig.Feature.UNWRAP_ROOT_VALUE);
/*     */   }
/*     */ 
/*     */   protected ObjectReader(ObjectReader base, DeserializationConfig config, JavaType valueType, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues)
/*     */   {
/* 152 */     this._config = config;
/*     */ 
/* 154 */     this._rootDeserializers = base._rootDeserializers;
/* 155 */     this._provider = base._provider;
/* 156 */     this._jsonFactory = base._jsonFactory;
/*     */ 
/* 158 */     this._valueType = valueType;
/* 159 */     this._valueToUpdate = valueToUpdate;
/* 160 */     if ((valueToUpdate != null) && (valueType.isArrayType())) {
/* 161 */       throw new IllegalArgumentException("Can not update an array value");
/*     */     }
/* 163 */     this._schema = schema;
/* 164 */     this._injectableValues = injectableValues;
/* 165 */     this._unwrapRoot = config.isEnabled(DeserializationConfig.Feature.UNWRAP_ROOT_VALUE);
/*     */   }
/*     */ 
/*     */   public Version version()
/*     */   {
/* 176 */     return VersionUtil.versionFor(getClass());
/*     */   }
/*     */ 
/*     */   public ObjectReader withType(JavaType valueType)
/*     */   {
/* 181 */     if (valueType == this._valueType) return this;
/*     */ 
/* 183 */     return new ObjectReader(this, this._config, valueType, this._valueToUpdate, this._schema, this._injectableValues);
/*     */   }
/*     */ 
/*     */   public ObjectReader withType(Class<?> valueType)
/*     */   {
/* 189 */     return withType(this._config.constructType(valueType));
/*     */   }
/*     */ 
/*     */   public ObjectReader withType(Type valueType)
/*     */   {
/* 194 */     return withType(this._config.getTypeFactory().constructType(valueType));
/*     */   }
/*     */ 
/*     */   public ObjectReader withType(TypeReference<?> valueTypeRef)
/*     */   {
/* 202 */     return withType(this._config.getTypeFactory().constructType(valueTypeRef.getType()));
/*     */   }
/*     */ 
/*     */   public ObjectReader withNodeFactory(JsonNodeFactory f)
/*     */   {
/* 208 */     if (f == this._config.getNodeFactory()) return this;
/* 209 */     return new ObjectReader(this, this._config.withNodeFactory(f), this._valueType, this._valueToUpdate, this._schema, this._injectableValues);
/*     */   }
/*     */ 
/*     */   public ObjectReader withValueToUpdate(Object value)
/*     */   {
/* 215 */     if (value == this._valueToUpdate) return this;
/* 216 */     if (value == null) {
/* 217 */       throw new IllegalArgumentException("cat not update null value");
/*     */     }
/* 219 */     JavaType t = this._config.constructType(value.getClass());
/* 220 */     return new ObjectReader(this, this._config, t, value, this._schema, this._injectableValues);
/*     */   }
/*     */ 
/*     */   public ObjectReader withSchema(FormatSchema schema)
/*     */   {
/* 229 */     if (this._schema == schema) {
/* 230 */       return this;
/*     */     }
/* 232 */     return new ObjectReader(this, this._config, this._valueType, this._valueToUpdate, schema, this._injectableValues);
/*     */   }
/*     */ 
/*     */   public ObjectReader withInjectableValues(InjectableValues injectableValues)
/*     */   {
/* 241 */     if (this._injectableValues == injectableValues) {
/* 242 */       return this;
/*     */     }
/* 244 */     return new ObjectReader(this, this._config, this._valueType, this._valueToUpdate, this._schema, injectableValues);
/*     */   }
/*     */ 
/*     */   public <T> T readValue(JsonParser jp)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 260 */     return _bind(jp);
/*     */   }
/*     */ 
/*     */   public <T> T readValue(JsonParser jp, Class<T> valueType)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 268 */     return withType(valueType).readValue(jp);
/*     */   }
/*     */ 
/*     */   public <T> T readValue(JsonParser jp, TypeReference<?> valueTypeRef)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 275 */     return withType(valueTypeRef).readValue(jp);
/*     */   }
/*     */ 
/*     */   public <T> T readValue(JsonParser jp, JavaType valueType)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 281 */     return withType(valueType).readValue(jp);
/*     */   }
/*     */ 
/*     */   public JsonNode readTree(JsonParser jp)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 288 */     return _bindAsTree(jp);
/*     */   }
/*     */ 
/*     */   public <T> Iterator<T> readValues(JsonParser jp, Class<T> valueType)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 294 */     return withType(valueType).readValues(jp);
/*     */   }
/*     */ 
/*     */   public <T> Iterator<T> readValues(JsonParser jp, TypeReference<?> valueTypeRef)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 300 */     return withType(valueTypeRef).readValues(jp);
/*     */   }
/*     */ 
/*     */   public <T> Iterator<T> readValues(JsonParser jp, JavaType valueType)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 306 */     return withType(valueType).readValues(jp);
/*     */   }
/*     */ 
/*     */   public <T> T readValue(InputStream src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 319 */     return _bindAndClose(this._jsonFactory.createJsonParser(src));
/*     */   }
/*     */ 
/*     */   public <T> T readValue(Reader src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 326 */     return _bindAndClose(this._jsonFactory.createJsonParser(src));
/*     */   }
/*     */ 
/*     */   public <T> T readValue(String src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 333 */     return _bindAndClose(this._jsonFactory.createJsonParser(src));
/*     */   }
/*     */ 
/*     */   public <T> T readValue(byte[] src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 340 */     return _bindAndClose(this._jsonFactory.createJsonParser(src));
/*     */   }
/*     */ 
/*     */   public <T> T readValue(byte[] src, int offset, int length)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 347 */     return _bindAndClose(this._jsonFactory.createJsonParser(src, offset, length));
/*     */   }
/*     */ 
/*     */   public <T> T readValue(File src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 354 */     return _bindAndClose(this._jsonFactory.createJsonParser(src));
/*     */   }
/*     */ 
/*     */   public <T> T readValue(URL src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 361 */     return _bindAndClose(this._jsonFactory.createJsonParser(src));
/*     */   }
/*     */ 
/*     */   public <T> T readValue(JsonNode src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 375 */     return _bindAndClose(treeAsTokens(src));
/*     */   }
/*     */ 
/*     */   public JsonNode readTree(InputStream in)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 381 */     return _bindAndCloseAsTree(this._jsonFactory.createJsonParser(in));
/*     */   }
/*     */ 
/*     */   public JsonNode readTree(Reader r)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 387 */     return _bindAndCloseAsTree(this._jsonFactory.createJsonParser(r));
/*     */   }
/*     */ 
/*     */   public JsonNode readTree(String content)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 393 */     return _bindAndCloseAsTree(this._jsonFactory.createJsonParser(content));
/*     */   }
/*     */ 
/*     */   public <T> MappingIterator<T> readValues(JsonParser jp)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 410 */     DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 411 */     return new MappingIterator(this._valueType, jp, ctxt, _findRootDeserializer(this._config, this._valueType));
/*     */   }
/*     */ 
/*     */   public <T> MappingIterator<T> readValues(InputStream src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 422 */     JsonParser jp = this._jsonFactory.createJsonParser(src);
/* 423 */     if (this._schema != null) {
/* 424 */       jp.setSchema(this._schema);
/*     */     }
/* 426 */     DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 427 */     return new MappingIterator(this._valueType, jp, ctxt, _findRootDeserializer(this._config, this._valueType));
/*     */   }
/*     */ 
/*     */   public <T> MappingIterator<T> readValues(Reader src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 438 */     JsonParser jp = this._jsonFactory.createJsonParser(src);
/* 439 */     if (this._schema != null) {
/* 440 */       jp.setSchema(this._schema);
/*     */     }
/* 442 */     DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 443 */     return new MappingIterator(this._valueType, jp, ctxt, _findRootDeserializer(this._config, this._valueType));
/*     */   }
/*     */ 
/*     */   public <T> MappingIterator<T> readValues(String json)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 454 */     JsonParser jp = this._jsonFactory.createJsonParser(json);
/* 455 */     if (this._schema != null) {
/* 456 */       jp.setSchema(this._schema);
/*     */     }
/* 458 */     DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 459 */     return new MappingIterator(this._valueType, jp, ctxt, _findRootDeserializer(this._config, this._valueType));
/*     */   }
/*     */ 
/*     */   public <T> MappingIterator<T> readValues(byte[] src, int offset, int length)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 470 */     JsonParser jp = this._jsonFactory.createJsonParser(src, offset, length);
/* 471 */     if (this._schema != null) {
/* 472 */       jp.setSchema(this._schema);
/*     */     }
/* 474 */     DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 475 */     return new MappingIterator(this._valueType, jp, ctxt, _findRootDeserializer(this._config, this._valueType));
/*     */   }
/*     */ 
/*     */   public <T> MappingIterator<T> readValues(File src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 486 */     JsonParser jp = this._jsonFactory.createJsonParser(src);
/* 487 */     if (this._schema != null) {
/* 488 */       jp.setSchema(this._schema);
/*     */     }
/* 490 */     DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 491 */     return new MappingIterator(this._valueType, jp, ctxt, _findRootDeserializer(this._config, this._valueType));
/*     */   }
/*     */ 
/*     */   public <T> MappingIterator<T> readValues(URL src)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 502 */     JsonParser jp = this._jsonFactory.createJsonParser(src);
/* 503 */     if (this._schema != null) {
/* 504 */       jp.setSchema(this._schema);
/*     */     }
/* 506 */     DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 507 */     return new MappingIterator(this._valueType, jp, ctxt, _findRootDeserializer(this._config, this._valueType));
/*     */   }
/*     */ 
/*     */   protected Object _bind(JsonParser jp)
/*     */     throws IOException, JsonParseException, JsonMappingException
/*     */   {
/* 526 */     JsonToken t = _initForReading(jp);
/*     */     Object result;
/*     */     Object result;
/* 527 */     if (t == JsonToken.VALUE_NULL)
/*     */     {
/*     */       Object result;
/* 528 */       if (this._valueToUpdate == null)
/* 529 */         result = _findRootDeserializer(this._config, this._valueType).getNullValue();
/*     */       else
/* 531 */         result = this._valueToUpdate;
/*     */     }
/*     */     else
/*     */     {
/*     */       Object result;
/* 533 */       if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 534 */         result = this._valueToUpdate;
/*     */       } else {
/* 536 */         DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 537 */         JsonDeserializer deser = _findRootDeserializer(this._config, this._valueType);
/*     */         Object result;
/* 538 */         if (this._unwrapRoot) {
/* 539 */           result = _unwrapAndDeserialize(jp, ctxt, this._valueType, deser);
/*     */         }
/*     */         else
/*     */         {
/*     */           Object result;
/* 541 */           if (this._valueToUpdate == null) {
/* 542 */             result = deser.deserialize(jp, ctxt);
/*     */           } else {
/* 544 */             deser.deserialize(jp, ctxt, this._valueToUpdate);
/* 545 */             result = this._valueToUpdate;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 550 */     jp.clearCurrentToken();
/* 551 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object _bindAndClose(JsonParser jp)
/*     */     throws IOException, JsonParseException, JsonMappingException
/*     */   {
/* 557 */     if (this._schema != null) {
/* 558 */       jp.setSchema(this._schema);
/*     */     }
/*     */     try
/*     */     {
/* 562 */       JsonToken t = _initForReading(jp);
/*     */       Object result;
/*     */       DeserializationContext ctxt;
/*     */       Object result;
/* 563 */       if (t == JsonToken.VALUE_NULL)
/*     */       {
/*     */         Object result;
/* 564 */         if (this._valueToUpdate == null)
/* 565 */           result = _findRootDeserializer(this._config, this._valueType).getNullValue();
/*     */         else
/* 567 */           result = this._valueToUpdate;
/*     */       }
/*     */       else
/*     */       {
/*     */         Object result;
/* 569 */         if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 570 */           result = this._valueToUpdate;
/*     */         } else {
/* 572 */           ctxt = _createDeserializationContext(jp, this._config);
/* 573 */           JsonDeserializer deser = _findRootDeserializer(this._config, this._valueType);
/*     */           Object result;
/* 574 */           if (this._unwrapRoot) {
/* 575 */             result = _unwrapAndDeserialize(jp, ctxt, this._valueType, deser);
/*     */           }
/*     */           else
/*     */           {
/*     */             Object result;
/* 577 */             if (this._valueToUpdate == null) {
/* 578 */               result = deser.deserialize(jp, ctxt);
/*     */             } else {
/* 580 */               deser.deserialize(jp, ctxt, this._valueToUpdate);
/* 581 */               result = this._valueToUpdate;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 585 */       return result;
/*     */     } finally {
/*     */       try {
/* 588 */         jp.close();
/*     */       }
/*     */       catch (IOException ioe)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JsonNode _bindAsTree(JsonParser jp) throws IOException, JsonParseException, JsonMappingException {
/* 597 */     JsonToken t = _initForReading(jp);
/*     */     JsonNode result;
/*     */     JsonNode result;
/* 598 */     if ((t == JsonToken.VALUE_NULL) || (t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 599 */       result = NullNode.instance;
/*     */     } else {
/* 601 */       DeserializationContext ctxt = _createDeserializationContext(jp, this._config);
/* 602 */       JsonDeserializer deser = _findRootDeserializer(this._config, JSON_NODE_TYPE);
/*     */       JsonNode result;
/* 603 */       if (this._unwrapRoot)
/* 604 */         result = (JsonNode)_unwrapAndDeserialize(jp, ctxt, JSON_NODE_TYPE, deser);
/*     */       else {
/* 606 */         result = (JsonNode)deser.deserialize(jp, ctxt);
/*     */       }
/*     */     }
/*     */ 
/* 610 */     jp.clearCurrentToken();
/* 611 */     return result;
/*     */   }
/*     */ 
/*     */   protected JsonNode _bindAndCloseAsTree(JsonParser jp)
/*     */     throws IOException, JsonParseException, JsonMappingException
/*     */   {
/* 617 */     if (this._schema != null)
/* 618 */       jp.setSchema(this._schema);
/*     */     try
/*     */     {
/* 621 */       return _bindAsTree(jp);
/*     */     } finally {
/*     */       try {
/* 624 */         jp.close();
/*     */       }
/*     */       catch (IOException ioe)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static JsonToken _initForReading(JsonParser jp)
/*     */     throws IOException, JsonParseException, JsonMappingException
/*     */   {
/* 636 */     JsonToken t = jp.getCurrentToken();
/* 637 */     if (t == null) {
/* 638 */       t = jp.nextToken();
/* 639 */       if (t == null) {
/* 640 */         throw new EOFException("No content to map to Object due to end of input");
/*     */       }
/*     */     }
/* 643 */     return t;
/*     */   }
/*     */ 
/*     */   protected JsonDeserializer<Object> _findRootDeserializer(DeserializationConfig cfg, JavaType valueType)
/*     */     throws JsonMappingException
/*     */   {
/* 653 */     JsonDeserializer deser = (JsonDeserializer)this._rootDeserializers.get(valueType);
/* 654 */     if (deser != null) {
/* 655 */       return deser;
/*     */     }
/*     */ 
/* 659 */     deser = this._provider.findTypedValueDeserializer(cfg, valueType, null);
/* 660 */     if (deser == null) {
/* 661 */       throw new JsonMappingException("Can not find a deserializer for type " + valueType);
/*     */     }
/* 663 */     this._rootDeserializers.put(valueType, deser);
/* 664 */     return deser;
/*     */   }
/*     */ 
/*     */   protected DeserializationContext _createDeserializationContext(JsonParser jp, DeserializationConfig cfg)
/*     */   {
/* 669 */     return new StdDeserializationContext(cfg, jp, this._provider, this._injectableValues);
/*     */   }
/*     */ 
/*     */   protected Object _unwrapAndDeserialize(JsonParser jp, DeserializationContext ctxt, JavaType rootType, JsonDeserializer<Object> deser)
/*     */     throws IOException, JsonParseException, JsonMappingException
/*     */   {
/* 676 */     SerializedString rootName = this._provider.findExpectedRootName(ctxt.getConfig(), rootType);
/* 677 */     if (jp.getCurrentToken() != JsonToken.START_OBJECT) {
/* 678 */       throw JsonMappingException.from(jp, "Current token not START_OBJECT (needed to unwrap root name '" + rootName + "'), but " + jp.getCurrentToken());
/*     */     }
/*     */ 
/* 681 */     if (jp.nextToken() != JsonToken.FIELD_NAME) {
/* 682 */       throw JsonMappingException.from(jp, "Current token not FIELD_NAME (to contain expected root name '" + rootName + "'), but " + jp.getCurrentToken());
/*     */     }
/*     */ 
/* 685 */     String actualName = jp.getCurrentName();
/* 686 */     if (!rootName.getValue().equals(actualName)) {
/* 687 */       throw JsonMappingException.from(jp, "Root name '" + actualName + "' does not match expected ('" + rootName + "') for type " + rootType);
/*     */     }
/*     */ 
/* 691 */     jp.nextToken();
/*     */     Object result;
/*     */     Object result;
/* 693 */     if (this._valueToUpdate == null) {
/* 694 */       result = deser.deserialize(jp, ctxt);
/*     */     } else {
/* 696 */       deser.deserialize(jp, ctxt, this._valueToUpdate);
/* 697 */       result = this._valueToUpdate;
/*     */     }
/*     */ 
/* 700 */     if (jp.nextToken() != JsonToken.END_OBJECT) {
/* 701 */       throw JsonMappingException.from(jp, "Current token not END_OBJECT (to match wrapper object with root name '" + rootName + "'), but " + jp.getCurrentToken());
/*     */     }
/*     */ 
/* 704 */     return result;
/*     */   }
/*     */ 
/*     */   public JsonNode createArrayNode()
/*     */   {
/* 715 */     return this._config.getNodeFactory().arrayNode();
/*     */   }
/*     */ 
/*     */   public JsonNode createObjectNode()
/*     */   {
/* 720 */     return this._config.getNodeFactory().objectNode();
/*     */   }
/*     */ 
/*     */   public JsonParser treeAsTokens(JsonNode n)
/*     */   {
/* 725 */     return new TreeTraversingParser(n, this);
/*     */   }
/*     */ 
/*     */   public <T> T treeToValue(JsonNode n, Class<T> valueType)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 732 */     return readValue(treeAsTokens(n), valueType);
/*     */   }
/*     */ 
/*     */   public void writeTree(JsonGenerator jgen, JsonNode rootNode)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 741 */     throw new UnsupportedOperationException("Not implemented for ObjectReader");
/*     */   }
/*     */ 
/*     */   public void writeValue(JsonGenerator jgen, Object value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 747 */     throw new UnsupportedOperationException("Not implemented for ObjectReader");
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ObjectReader
 * JD-Core Version:    0.6.2
 */