/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.text.DateFormat;
/*     */ import org.codehaus.jackson.FormatSchema;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.PrettyPrinter;
/*     */ import org.codehaus.jackson.Version;
/*     */ import org.codehaus.jackson.Versioned;
/*     */ import org.codehaus.jackson.io.SegmentedStringWriter;
/*     */ import org.codehaus.jackson.map.ser.FilterProvider;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.codehaus.jackson.type.TypeReference;
/*     */ import org.codehaus.jackson.util.ByteArrayBuilder;
/*     */ import org.codehaus.jackson.util.DefaultPrettyPrinter;
/*     */ import org.codehaus.jackson.util.MinimalPrettyPrinter;
/*     */ import org.codehaus.jackson.util.VersionUtil;
/*     */ 
/*     */ public class ObjectWriter
/*     */   implements Versioned
/*     */ {
/*  34 */   protected static final PrettyPrinter NULL_PRETTY_PRINTER = new MinimalPrettyPrinter();
/*     */   protected final SerializationConfig _config;
/*     */   protected final SerializerProvider _provider;
/*     */   protected final SerializerFactory _serializerFactory;
/*     */   protected final JsonFactory _jsonFactory;
/*     */   protected final JavaType _rootType;
/*     */   protected final PrettyPrinter _prettyPrinter;
/*     */   protected final FormatSchema _schema;
/*     */ 
/*     */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config, JavaType rootType, PrettyPrinter pp)
/*     */   {
/*  95 */     this._config = config;
/*     */ 
/*  97 */     this._provider = mapper._serializerProvider;
/*  98 */     this._serializerFactory = mapper._serializerFactory;
/*  99 */     this._jsonFactory = mapper._jsonFactory;
/*     */ 
/* 101 */     this._rootType = rootType;
/* 102 */     this._prettyPrinter = pp;
/* 103 */     this._schema = null;
/*     */   }
/*     */ 
/*     */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config)
/*     */   {
/* 113 */     this._config = config;
/*     */ 
/* 115 */     this._provider = mapper._serializerProvider;
/* 116 */     this._serializerFactory = mapper._serializerFactory;
/* 117 */     this._jsonFactory = mapper._jsonFactory;
/*     */ 
/* 119 */     this._rootType = null;
/* 120 */     this._prettyPrinter = null;
/* 121 */     this._schema = null;
/*     */   }
/*     */ 
/*     */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config, FormatSchema s)
/*     */   {
/* 132 */     this._config = config;
/*     */ 
/* 134 */     this._provider = mapper._serializerProvider;
/* 135 */     this._serializerFactory = mapper._serializerFactory;
/* 136 */     this._jsonFactory = mapper._jsonFactory;
/*     */ 
/* 138 */     this._rootType = null;
/* 139 */     this._prettyPrinter = null;
/* 140 */     this._schema = s;
/*     */   }
/*     */ 
/*     */   protected ObjectWriter(ObjectWriter base, SerializationConfig config, JavaType rootType, PrettyPrinter pp, FormatSchema s)
/*     */   {
/* 149 */     this._config = config;
/*     */ 
/* 151 */     this._provider = base._provider;
/* 152 */     this._serializerFactory = base._serializerFactory;
/* 153 */     this._jsonFactory = base._jsonFactory;
/*     */ 
/* 155 */     this._rootType = rootType;
/* 156 */     this._prettyPrinter = pp;
/* 157 */     this._schema = s;
/*     */   }
/*     */ 
/*     */   protected ObjectWriter(ObjectWriter base, SerializationConfig config)
/*     */   {
/* 167 */     this._config = config;
/*     */ 
/* 169 */     this._provider = base._provider;
/* 170 */     this._serializerFactory = base._serializerFactory;
/* 171 */     this._jsonFactory = base._jsonFactory;
/* 172 */     this._schema = base._schema;
/*     */ 
/* 174 */     this._rootType = base._rootType;
/* 175 */     this._prettyPrinter = base._prettyPrinter;
/*     */   }
/*     */ 
/*     */   public Version version()
/*     */   {
/* 186 */     return VersionUtil.versionFor(getClass());
/*     */   }
/*     */ 
/*     */   public ObjectWriter withView(Class<?> view)
/*     */   {
/* 202 */     if (view == this._config.getSerializationView()) return this;
/* 203 */     return new ObjectWriter(this, this._config.withView(view));
/*     */   }
/*     */ 
/*     */   public ObjectWriter withType(JavaType rootType)
/*     */   {
/* 213 */     if (rootType == this._rootType) return this;
/*     */ 
/* 215 */     return new ObjectWriter(this, this._config, rootType, this._prettyPrinter, this._schema);
/*     */   }
/*     */ 
/*     */   public ObjectWriter withType(Class<?> rootType)
/*     */   {
/* 225 */     return withType(this._config.constructType(rootType));
/*     */   }
/*     */ 
/*     */   public ObjectWriter withType(TypeReference<?> rootType)
/*     */   {
/* 233 */     return withType(this._config.getTypeFactory().constructType(rootType.getType()));
/*     */   }
/*     */ 
/*     */   public ObjectWriter withPrettyPrinter(PrettyPrinter pp)
/*     */   {
/* 244 */     if (pp == this._prettyPrinter) {
/* 245 */       return this;
/*     */     }
/*     */ 
/* 248 */     if (pp == null) {
/* 249 */       pp = NULL_PRETTY_PRINTER;
/*     */     }
/* 251 */     return new ObjectWriter(this, this._config, this._rootType, pp, this._schema);
/*     */   }
/*     */ 
/*     */   public ObjectWriter withDefaultPrettyPrinter()
/*     */   {
/* 262 */     return withPrettyPrinter(new DefaultPrettyPrinter());
/*     */   }
/*     */ 
/*     */   public ObjectWriter withFilters(FilterProvider filterProvider)
/*     */   {
/* 273 */     if (filterProvider == this._config.getFilterProvider()) {
/* 274 */       return this;
/*     */     }
/* 276 */     return new ObjectWriter(this, this._config.withFilters(filterProvider));
/*     */   }
/*     */ 
/*     */   public ObjectWriter withSchema(FormatSchema schema)
/*     */   {
/* 284 */     if (this._schema == schema) {
/* 285 */       return this;
/*     */     }
/* 287 */     return new ObjectWriter(this, this._config, this._rootType, this._prettyPrinter, schema);
/*     */   }
/*     */ 
/*     */   public ObjectWriter withDateFormat(DateFormat df)
/*     */   {
/* 299 */     SerializationConfig newConfig = this._config.withDateFormat(df);
/* 300 */     if (newConfig == this._config) {
/* 301 */       return this;
/*     */     }
/* 303 */     return new ObjectWriter(this, newConfig);
/*     */   }
/*     */ 
/*     */   public void writeValue(JsonGenerator jgen, Object value)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 319 */     if ((this._config.isEnabled(SerializationConfig.Feature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 320 */       _writeCloseableValue(jgen, value, this._config);
/*     */     } else {
/* 322 */       if (this._rootType == null)
/* 323 */         this._provider.serializeValue(this._config, jgen, value, this._serializerFactory);
/*     */       else {
/* 325 */         this._provider.serializeValue(this._config, jgen, value, this._rootType, this._serializerFactory);
/*     */       }
/* 327 */       if (this._config.isEnabled(SerializationConfig.Feature.FLUSH_AFTER_WRITE_VALUE))
/* 328 */         jgen.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeValue(File resultFile, Object value)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 346 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(resultFile, JsonEncoding.UTF8), value);
/*     */   }
/*     */ 
/*     */   public void writeValue(OutputStream out, Object value)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 363 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(out, JsonEncoding.UTF8), value);
/*     */   }
/*     */ 
/*     */   public void writeValue(Writer w, Object value)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 379 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(w), value);
/*     */   }
/*     */ 
/*     */   public String writeValueAsString(Object value)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 392 */     SegmentedStringWriter sw = new SegmentedStringWriter(this._jsonFactory._getBufferRecycler());
/* 393 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(sw), value);
/* 394 */     return sw.getAndClear();
/*     */   }
/*     */ 
/*     */   public byte[] writeValueAsBytes(Object value)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 407 */     ByteArrayBuilder bb = new ByteArrayBuilder(this._jsonFactory._getBufferRecycler());
/* 408 */     _configAndWriteValue(this._jsonFactory.createJsonGenerator(bb, JsonEncoding.UTF8), value);
/* 409 */     byte[] result = bb.toByteArray();
/* 410 */     bb.release();
/* 411 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean canSerialize(Class<?> type)
/*     */   {
/* 422 */     return this._provider.hasSerializerFor(this._config, type, this._serializerFactory);
/*     */   }
/*     */ 
/*     */   protected final void _configAndWriteValue(JsonGenerator jgen, Object value)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 438 */     if (this._prettyPrinter != null) {
/* 439 */       PrettyPrinter pp = this._prettyPrinter;
/* 440 */       jgen.setPrettyPrinter(pp == NULL_PRETTY_PRINTER ? null : pp);
/* 441 */     } else if (this._config.isEnabled(SerializationConfig.Feature.INDENT_OUTPUT)) {
/* 442 */       jgen.useDefaultPrettyPrinter();
/*     */     }
/*     */ 
/* 445 */     if (this._schema != null) {
/* 446 */       jgen.setSchema(this._schema);
/*     */     }
/*     */ 
/* 449 */     if ((this._config.isEnabled(SerializationConfig.Feature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 450 */       _configAndWriteCloseable(jgen, value, this._config);
/* 451 */       return;
/*     */     }
/* 453 */     boolean closed = false;
/*     */     try {
/* 455 */       if (this._rootType == null)
/* 456 */         this._provider.serializeValue(this._config, jgen, value, this._serializerFactory);
/*     */       else {
/* 458 */         this._provider.serializeValue(this._config, jgen, value, this._rootType, this._serializerFactory);
/*     */       }
/* 460 */       closed = true;
/* 461 */       jgen.close();
/*     */     }
/*     */     finally
/*     */     {
/* 466 */       if (!closed)
/*     */         try {
/* 468 */           jgen.close();
/*     */         }
/*     */         catch (IOException ioe)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void _configAndWriteCloseable(JsonGenerator jgen, Object value, SerializationConfig cfg)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 481 */     Closeable toClose = (Closeable)value;
/*     */     try {
/* 483 */       if (this._rootType == null)
/* 484 */         this._provider.serializeValue(cfg, jgen, value, this._serializerFactory);
/*     */       else {
/* 486 */         this._provider.serializeValue(cfg, jgen, value, this._rootType, this._serializerFactory);
/*     */       }
/*     */ 
/* 489 */       if (this._schema != null) {
/* 490 */         jgen.setSchema(this._schema);
/*     */       }
/* 492 */       JsonGenerator tmpJgen = jgen;
/* 493 */       jgen = null;
/* 494 */       tmpJgen.close();
/* 495 */       Closeable tmpToClose = toClose;
/* 496 */       toClose = null;
/* 497 */       tmpToClose.close();
/*     */     }
/*     */     finally
/*     */     {
/* 502 */       if (jgen != null)
/*     */         try {
/* 504 */           jgen.close();
/*     */         } catch (IOException ioe) {
/*     */         }
/* 507 */       if (toClose != null)
/*     */         try {
/* 509 */           toClose.close();
/*     */         }
/*     */         catch (IOException ioe)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void _writeCloseableValue(JsonGenerator jgen, Object value, SerializationConfig cfg)
/*     */     throws IOException, JsonGenerationException, JsonMappingException
/*     */   {
/* 522 */     Closeable toClose = (Closeable)value;
/*     */     try {
/* 524 */       if (this._rootType == null)
/* 525 */         this._provider.serializeValue(cfg, jgen, value, this._serializerFactory);
/*     */       else {
/* 527 */         this._provider.serializeValue(cfg, jgen, value, this._rootType, this._serializerFactory);
/*     */       }
/* 529 */       if (this._config.isEnabled(SerializationConfig.Feature.FLUSH_AFTER_WRITE_VALUE)) {
/* 530 */         jgen.flush();
/*     */       }
/* 532 */       Closeable tmpToClose = toClose;
/* 533 */       toClose = null;
/* 534 */       tmpToClose.close();
/*     */     } finally {
/* 536 */       if (toClose != null)
/*     */         try {
/* 538 */           toClose.close();
/*     */         }
/*     */         catch (IOException ioe)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ObjectWriter
 * JD-Core Version:    0.6.2
 */