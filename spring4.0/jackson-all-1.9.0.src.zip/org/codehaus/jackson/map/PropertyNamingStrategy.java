/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedParameter;
/*     */ 
/*     */ public abstract class PropertyNamingStrategy
/*     */ {
/* 168 */   public static final PropertyNamingStrategy CAMEL_CASE_TO_LOWER_CASE_WITH_UNDERSCORES = new LowerCaseWithUnderscoresStrategy();
/*     */ 
/*     */   public String nameForField(MapperConfig<?> config, AnnotatedField field, String defaultName)
/*     */   {
/*  54 */     return defaultName;
/*     */   }
/*     */ 
/*     */   public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName)
/*     */   {
/*  75 */     return defaultName;
/*     */   }
/*     */ 
/*     */   public String nameForSetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName)
/*     */   {
/*  95 */     return defaultName;
/*     */   }
/*     */ 
/*     */   public String nameForConstructorParameter(MapperConfig<?> config, AnnotatedParameter ctorParam, String defaultName)
/*     */   {
/* 114 */     return defaultName;
/*     */   }
/*     */ 
/*     */   public static class LowerCaseWithUnderscoresStrategy extends PropertyNamingStrategy.PropertyNamingStrategyBase
/*     */   {
/*     */     public String translate(String input)
/*     */     {
/* 227 */       if (input == null) return input;
/* 228 */       int length = input.length();
/* 229 */       StringBuilder result = new StringBuilder(length * 2);
/* 230 */       int resultLength = 0;
/* 231 */       boolean wasPrevTranslated = false;
/* 232 */       for (int i = 0; i < length; i++)
/*     */       {
/* 234 */         char c = input.charAt(i);
/* 235 */         if ((i > 0) || (c != '_'))
/*     */         {
/* 237 */           if (Character.isUpperCase(c))
/*     */           {
/* 239 */             if ((!wasPrevTranslated) && (resultLength > 0) && (result.charAt(resultLength - 1) != '_'))
/*     */             {
/* 241 */               result.append('_');
/* 242 */               resultLength++;
/*     */             }
/* 244 */             c = Character.toLowerCase(c);
/* 245 */             wasPrevTranslated = true;
/*     */           }
/*     */           else
/*     */           {
/* 249 */             wasPrevTranslated = false;
/*     */           }
/* 251 */           result.append(c);
/* 252 */           resultLength++;
/*     */         }
/*     */       }
/* 255 */       return resultLength > 0 ? result.toString() : input;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class PropertyNamingStrategyBase extends PropertyNamingStrategy
/*     */   {
/*     */     public String nameForField(MapperConfig<?> config, AnnotatedField field, String defaultName)
/*     */     {
/* 131 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */     public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName)
/*     */     {
/* 137 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */     public String nameForSetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName)
/*     */     {
/* 143 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */     public String nameForConstructorParameter(MapperConfig<?> config, AnnotatedParameter ctorParam, String defaultName)
/*     */     {
/* 150 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */     public abstract String translate(String paramString);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.PropertyNamingStrategy
 * JD-Core Version:    0.6.2
 */