/*    */ package org.codehaus.jackson.map;
/*    */ 
/*    */ public class RuntimeJsonMappingException extends RuntimeException
/*    */ {
/*    */   public RuntimeJsonMappingException(JsonMappingException cause)
/*    */   {
/* 11 */     super(cause);
/*    */   }
/*    */ 
/*    */   public RuntimeJsonMappingException(String message) {
/* 15 */     super(message);
/*    */   }
/*    */ 
/*    */   public RuntimeJsonMappingException(String message, JsonMappingException cause) {
/* 19 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.RuntimeJsonMappingException
 * JD-Core Version:    0.6.2
 */