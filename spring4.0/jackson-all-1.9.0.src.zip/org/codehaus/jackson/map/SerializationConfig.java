/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
/*     */ import org.codehaus.jackson.annotate.JsonMethod;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Typing;
/*     */ import org.codehaus.jackson.map.introspect.Annotated;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*     */ import org.codehaus.jackson.map.introspect.VisibilityChecker;
/*     */ import org.codehaus.jackson.map.jsontype.SubtypeResolver;
/*     */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*     */ import org.codehaus.jackson.map.ser.FilterProvider;
/*     */ import org.codehaus.jackson.map.type.ClassKey;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class SerializationConfig extends MapperConfig.Impl<Feature, SerializationConfig>
/*     */ {
/* 459 */   protected JsonSerialize.Inclusion _serializationInclusion = null;
/*     */   protected Class<?> _serializationView;
/*     */   protected FilterProvider _filterProvider;
/*     */ 
/*     */   public SerializationConfig(ClassIntrospector<? extends BeanDescription> intr, AnnotationIntrospector annIntr, VisibilityChecker<?> vc, SubtypeResolver subtypeResolver, PropertyNamingStrategy propertyNamingStrategy, TypeFactory typeFactory, HandlerInstantiator handlerInstantiator)
/*     */   {
/* 490 */     super(intr, annIntr, vc, subtypeResolver, propertyNamingStrategy, typeFactory, handlerInstantiator, collectFeatureDefaults(Feature.class));
/*     */ 
/* 492 */     this._filterProvider = null;
/*     */   }
/*     */ 
/*     */   protected SerializationConfig(SerializationConfig src)
/*     */   {
/* 499 */     this(src, src._base);
/*     */   }
/*     */ 
/*     */   protected SerializationConfig(SerializationConfig src, HashMap<ClassKey, Class<?>> mixins, SubtypeResolver str)
/*     */   {
/* 510 */     this(src, src._base);
/* 511 */     this._mixInAnnotations = mixins;
/* 512 */     this._subtypeResolver = str;
/*     */   }
/*     */ 
/*     */   protected SerializationConfig(SerializationConfig src, MapperConfig.Base base)
/*     */   {
/* 520 */     super(src, base, src._subtypeResolver);
/* 521 */     this._serializationInclusion = src._serializationInclusion;
/* 522 */     this._serializationView = src._serializationView;
/* 523 */     this._filterProvider = src._filterProvider;
/*     */   }
/*     */ 
/*     */   protected SerializationConfig(SerializationConfig src, FilterProvider filters)
/*     */   {
/* 531 */     super(src);
/* 532 */     this._serializationInclusion = src._serializationInclusion;
/* 533 */     this._serializationView = src._serializationView;
/* 534 */     this._filterProvider = filters;
/*     */   }
/*     */ 
/*     */   protected SerializationConfig(SerializationConfig src, Class<?> view)
/*     */   {
/* 542 */     super(src);
/* 543 */     this._serializationInclusion = src._serializationInclusion;
/* 544 */     this._serializationView = view;
/* 545 */     this._filterProvider = src._filterProvider;
/*     */   }
/*     */ 
/*     */   protected SerializationConfig(SerializationConfig src, JsonSerialize.Inclusion incl)
/*     */   {
/* 553 */     super(src);
/* 554 */     this._serializationInclusion = incl;
/*     */ 
/* 556 */     if (incl == JsonSerialize.Inclusion.NON_NULL)
/* 557 */       this._featureFlags &= (Feature.WRITE_NULL_PROPERTIES.getMask() ^ 0xFFFFFFFF);
/*     */     else {
/* 559 */       this._featureFlags |= Feature.WRITE_NULL_PROPERTIES.getMask();
/*     */     }
/* 561 */     this._serializationView = src._serializationView;
/* 562 */     this._filterProvider = src._filterProvider;
/*     */   }
/*     */ 
/*     */   protected SerializationConfig(SerializationConfig src, int features)
/*     */   {
/* 570 */     super(src, features);
/* 571 */     this._serializationInclusion = src._serializationInclusion;
/* 572 */     this._serializationView = src._serializationView;
/* 573 */     this._filterProvider = src._filterProvider;
/*     */   }
/*     */ 
/*     */   public SerializationConfig withClassIntrospector(ClassIntrospector<? extends BeanDescription> ci)
/*     */   {
/* 584 */     return new SerializationConfig(this, this._base.withClassIntrospector(ci));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withAnnotationIntrospector(AnnotationIntrospector ai)
/*     */   {
/* 589 */     return new SerializationConfig(this, this._base.withAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withInsertedAnnotationIntrospector(AnnotationIntrospector ai)
/*     */   {
/* 594 */     return new SerializationConfig(this, this._base.withInsertedAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withAppendedAnnotationIntrospector(AnnotationIntrospector ai)
/*     */   {
/* 599 */     return new SerializationConfig(this, this._base.withAppendedAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withVisibilityChecker(VisibilityChecker<?> vc)
/*     */   {
/* 604 */     return new SerializationConfig(this, this._base.withVisibilityChecker(vc));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withVisibility(JsonMethod forMethod, JsonAutoDetect.Visibility visibility)
/*     */   {
/* 609 */     return new SerializationConfig(this, this._base.withVisibility(forMethod, visibility));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withTypeResolverBuilder(TypeResolverBuilder<?> trb)
/*     */   {
/* 614 */     return new SerializationConfig(this, this._base.withTypeResolverBuilder(trb));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withSubtypeResolver(SubtypeResolver str)
/*     */   {
/* 619 */     SerializationConfig cfg = new SerializationConfig(this);
/* 620 */     cfg._subtypeResolver = str;
/* 621 */     return cfg;
/*     */   }
/*     */ 
/*     */   public SerializationConfig withPropertyNamingStrategy(PropertyNamingStrategy pns)
/*     */   {
/* 626 */     return new SerializationConfig(this, this._base.withPropertyNamingStrategy(pns));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withTypeFactory(TypeFactory tf)
/*     */   {
/* 631 */     return new SerializationConfig(this, this._base.withTypeFactory(tf));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withDateFormat(DateFormat df)
/*     */   {
/* 641 */     SerializationConfig cfg = new SerializationConfig(this, this._base.withDateFormat(df));
/*     */ 
/* 643 */     if (df == null)
/* 644 */       cfg = cfg.with(new Feature[] { Feature.WRITE_DATES_AS_TIMESTAMPS });
/*     */     else {
/* 646 */       cfg = cfg.without(new Feature[] { Feature.WRITE_DATES_AS_TIMESTAMPS });
/*     */     }
/* 648 */     return cfg;
/*     */   }
/*     */ 
/*     */   public SerializationConfig withHandlerInstantiator(HandlerInstantiator hi)
/*     */   {
/* 653 */     return new SerializationConfig(this, this._base.withHandlerInstantiator(hi));
/*     */   }
/*     */ 
/*     */   public SerializationConfig withFilters(FilterProvider filterProvider)
/*     */   {
/* 666 */     return new SerializationConfig(this, filterProvider);
/*     */   }
/*     */ 
/*     */   public SerializationConfig withView(Class<?> view)
/*     */   {
/* 673 */     return new SerializationConfig(this, view);
/*     */   }
/*     */ 
/*     */   public SerializationConfig withSerializationInclusion(JsonSerialize.Inclusion incl)
/*     */   {
/* 680 */     return new SerializationConfig(this, incl);
/*     */   }
/*     */ 
/*     */   public SerializationConfig with(Feature[] features)
/*     */   {
/* 692 */     int flags = this._featureFlags;
/* 693 */     for (Feature f : features) {
/* 694 */       flags |= f.getMask();
/*     */     }
/* 696 */     return new SerializationConfig(this, flags);
/*     */   }
/*     */ 
/*     */   public SerializationConfig without(Feature[] features)
/*     */   {
/* 708 */     int flags = this._featureFlags;
/* 709 */     for (Feature f : features) {
/* 710 */       flags &= (f.getMask() ^ 0xFFFFFFFF);
/*     */     }
/* 712 */     return new SerializationConfig(this, flags);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void fromAnnotations(Class<?> cls)
/*     */   {
/* 754 */     AnnotationIntrospector ai = getAnnotationIntrospector();
/* 755 */     AnnotatedClass ac = AnnotatedClass.construct(cls, ai, null);
/* 756 */     this._base = this._base.withVisibilityChecker(ai.findAutoDetectVisibility(ac, getDefaultVisibilityChecker()));
/*     */ 
/* 760 */     JsonSerialize.Inclusion incl = ai.findSerializationInclusion(ac, null);
/* 761 */     if (incl != this._serializationInclusion) {
/* 762 */       setSerializationInclusion(incl);
/*     */     }
/*     */ 
/* 765 */     JsonSerialize.Typing typing = ai.findSerializationTyping(ac);
/* 766 */     if (typing != null)
/* 767 */       set(Feature.USE_STATIC_TYPING, typing == JsonSerialize.Typing.STATIC);
/*     */   }
/*     */ 
/*     */   public SerializationConfig createUnshared(SubtypeResolver subtypeResolver)
/*     */   {
/* 774 */     HashMap mixins = this._mixInAnnotations;
/* 775 */     this._mixInAnnotationsShared = true;
/* 776 */     return new SerializationConfig(this, mixins, subtypeResolver);
/*     */   }
/*     */ 
/*     */   public AnnotationIntrospector getAnnotationIntrospector()
/*     */   {
/* 785 */     if (isEnabled(Feature.USE_ANNOTATIONS)) {
/* 786 */       return super.getAnnotationIntrospector();
/*     */     }
/* 788 */     return AnnotationIntrospector.nopInstance();
/*     */   }
/*     */ 
/*     */   public <T extends BeanDescription> T introspectClassAnnotations(JavaType type)
/*     */   {
/* 800 */     return getClassIntrospector().forClassAnnotations(this, type, this);
/*     */   }
/*     */ 
/*     */   public <T extends BeanDescription> T introspectDirectClassAnnotations(JavaType type)
/*     */   {
/* 813 */     return getClassIntrospector().forDirectClassAnnotations(this, type, this);
/*     */   }
/*     */ 
/*     */   public boolean isAnnotationProcessingEnabled()
/*     */   {
/* 818 */     return isEnabled(Feature.USE_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */   public boolean canOverrideAccessModifiers()
/*     */   {
/* 823 */     return isEnabled(Feature.CAN_OVERRIDE_ACCESS_MODIFIERS);
/*     */   }
/*     */ 
/*     */   public boolean shouldSortPropertiesAlphabetically()
/*     */   {
/* 828 */     return isEnabled(Feature.SORT_PROPERTIES_ALPHABETICALLY);
/*     */   }
/*     */ 
/*     */   public VisibilityChecker<?> getDefaultVisibilityChecker()
/*     */   {
/* 834 */     VisibilityChecker vchecker = super.getDefaultVisibilityChecker();
/* 835 */     if (!isEnabled(Feature.AUTO_DETECT_GETTERS)) {
/* 836 */       vchecker = vchecker.withGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */     }
/*     */ 
/* 839 */     if (!isEnabled(Feature.AUTO_DETECT_IS_GETTERS)) {
/* 840 */       vchecker = vchecker.withIsGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */     }
/* 842 */     if (!isEnabled(Feature.AUTO_DETECT_FIELDS)) {
/* 843 */       vchecker = vchecker.withFieldVisibility(JsonAutoDetect.Visibility.NONE);
/*     */     }
/* 845 */     return vchecker;
/*     */   }
/*     */ 
/*     */   public Class<?> getSerializationView()
/*     */   {
/* 860 */     return this._serializationView;
/*     */   }
/*     */ 
/*     */   public JsonSerialize.Inclusion getSerializationInclusion() {
/* 864 */     if (this._serializationInclusion != null) {
/* 865 */       return this._serializationInclusion;
/*     */     }
/* 867 */     return isEnabled(Feature.WRITE_NULL_PROPERTIES) ? JsonSerialize.Inclusion.ALWAYS : JsonSerialize.Inclusion.NON_NULL;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setSerializationInclusion(JsonSerialize.Inclusion props)
/*     */   {
/* 886 */     this._serializationInclusion = props;
/*     */ 
/* 888 */     if (props == JsonSerialize.Inclusion.NON_NULL)
/* 889 */       disable(Feature.WRITE_NULL_PROPERTIES);
/*     */     else
/* 891 */       enable(Feature.WRITE_NULL_PROPERTIES);
/*     */   }
/*     */ 
/*     */   public FilterProvider getFilterProvider()
/*     */   {
/* 904 */     return this._filterProvider;
/*     */   }
/*     */ 
/*     */   public <T extends BeanDescription> T introspect(JavaType type)
/*     */   {
/* 919 */     return getClassIntrospector().forSerialization(this, type, this);
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> serializerInstance(Annotated annotated, Class<? extends JsonSerializer<?>> serClass)
/*     */   {
/* 931 */     HandlerInstantiator hi = getHandlerInstantiator();
/* 932 */     if (hi != null) {
/* 933 */       JsonSerializer ser = hi.serializerInstance(this, annotated, serClass);
/* 934 */       if (ser != null) {
/* 935 */         return ser;
/*     */       }
/*     */     }
/* 938 */     return (JsonSerializer)ClassUtil.createInstance(serClass, canOverrideAccessModifiers());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final void setDateFormat(DateFormat df)
/*     */   {
/* 957 */     super.setDateFormat(df);
/* 958 */     set(Feature.WRITE_DATES_AS_TIMESTAMPS, df == null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setSerializationView(Class<?> view)
/*     */   {
/* 972 */     this._serializationView = view;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 983 */     return "[SerializationConfig: flags=0x" + Integer.toHexString(this._featureFlags) + "]";
/*     */   }
/*     */ 
/*     */   public static enum Feature
/*     */     implements MapperConfig.ConfigFeature
/*     */   {
/*  63 */     USE_ANNOTATIONS(true), 
/*     */ 
/*  82 */     AUTO_DETECT_GETTERS(true), 
/*     */ 
/*  98 */     AUTO_DETECT_IS_GETTERS(true), 
/*     */ 
/* 115 */     AUTO_DETECT_FIELDS(true), 
/*     */ 
/* 127 */     CAN_OVERRIDE_ACCESS_MODIFIERS(true), 
/*     */ 
/* 141 */     REQUIRE_SETTERS_FOR_GETTERS(false), 
/*     */ 
/* 163 */     WRITE_NULL_PROPERTIES(true), 
/*     */ 
/* 176 */     USE_STATIC_TYPING(false), 
/*     */ 
/* 194 */     DEFAULT_VIEW_INCLUSION(true), 
/*     */ 
/* 209 */     WRAP_ROOT_VALUE(false), 
/*     */ 
/* 228 */     INDENT_OUTPUT(false), 
/*     */ 
/* 244 */     SORT_PROPERTIES_ALPHABETICALLY(false), 
/*     */ 
/* 267 */     FAIL_ON_EMPTY_BEANS(true), 
/*     */ 
/* 287 */     WRAP_EXCEPTIONS(true), 
/*     */ 
/* 311 */     CLOSE_CLOSEABLE(false), 
/*     */ 
/* 325 */     FLUSH_AFTER_WRITE_VALUE(true), 
/*     */ 
/* 348 */     WRITE_DATES_AS_TIMESTAMPS(true), 
/*     */ 
/* 361 */     WRITE_DATE_KEYS_AS_TIMESTAMPS(false), 
/*     */ 
/* 371 */     WRITE_CHAR_ARRAYS_AS_JSON_ARRAYS(false), 
/*     */ 
/* 386 */     WRITE_ENUMS_USING_TO_STRING(false), 
/*     */ 
/* 401 */     WRITE_ENUMS_USING_INDEX(false), 
/*     */ 
/* 411 */     WRITE_NULL_MAP_VALUES(true), 
/*     */ 
/* 424 */     WRITE_EMPTY_JSON_ARRAYS(true);
/*     */ 
/*     */     final boolean _defaultState;
/*     */ 
/*     */     private Feature(boolean defaultState)
/*     */     {
/* 431 */       this._defaultState = defaultState;
/*     */     }
/*     */ 
/*     */     public boolean enabledByDefault() {
/* 435 */       return this._defaultState;
/*     */     }
/*     */     public int getMask() {
/* 438 */       return 1 << ordinal();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.SerializationConfig
 * JD-Core Version:    0.6.2
 */