/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import org.codehaus.jackson.map.ser.BeanSerializerModifier;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class SerializerFactory
/*     */ {
/*     */   public abstract Config getConfig();
/*     */ 
/*     */   public abstract SerializerFactory withConfig(Config paramConfig);
/*     */ 
/*     */   public final SerializerFactory withAdditionalSerializers(Serializers additional)
/*     */   {
/*  90 */     return withConfig(getConfig().withAdditionalSerializers(additional));
/*     */   }
/*     */ 
/*     */   public final SerializerFactory withAdditionalKeySerializers(Serializers additional)
/*     */   {
/*  97 */     return withConfig(getConfig().withAdditionalKeySerializers(additional));
/*     */   }
/*     */ 
/*     */   public final SerializerFactory withSerializerModifier(BeanSerializerModifier modifier)
/*     */   {
/* 110 */     return withConfig(getConfig().withSerializerModifier(modifier));
/*     */   }
/*     */ 
/*     */   public abstract JsonSerializer<Object> createSerializer(SerializationConfig paramSerializationConfig, JavaType paramJavaType, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract TypeSerializer createTypeSerializer(SerializationConfig paramSerializationConfig, JavaType paramJavaType, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract JsonSerializer<Object> createKeySerializer(SerializationConfig paramSerializationConfig, JavaType paramJavaType, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   @Deprecated
/*     */   public final JsonSerializer<Object> createSerializer(JavaType type, SerializationConfig config)
/*     */   {
/*     */     try
/*     */     {
/* 176 */       return createSerializer(config, type, null);
/*     */     } catch (JsonMappingException e) {
/* 178 */       throw new RuntimeJsonMappingException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final TypeSerializer createTypeSerializer(JavaType baseType, SerializationConfig config)
/*     */   {
/*     */     try
/*     */     {
/* 193 */       return createTypeSerializer(config, baseType, null);
/*     */     } catch (JsonMappingException e) {
/* 195 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class Config
/*     */   {
/*     */     public abstract Config withAdditionalSerializers(Serializers paramSerializers);
/*     */ 
/*     */     public abstract Config withAdditionalKeySerializers(Serializers paramSerializers);
/*     */ 
/*     */     public abstract Config withSerializerModifier(BeanSerializerModifier paramBeanSerializerModifier);
/*     */ 
/*     */     public abstract boolean hasSerializers();
/*     */ 
/*     */     public abstract boolean hasKeySerializers();
/*     */ 
/*     */     public abstract boolean hasSerializerModifiers();
/*     */ 
/*     */     public abstract Iterable<Serializers> serializers();
/*     */ 
/*     */     public abstract Iterable<Serializers> keySerializers();
/*     */ 
/*     */     public abstract Iterable<BeanSerializerModifier> serializerModifiers();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.SerializerFactory
 * JD-Core Version:    0.6.2
 */