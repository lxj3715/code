/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Date;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.ser.FilterProvider;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.schema.JsonSchema;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class SerializerProvider
/*     */ {
/*  25 */   protected static final JavaType TYPE_OBJECT = TypeFactory.defaultInstance().uncheckedSimpleType(Object.class);
/*     */   protected final SerializationConfig _config;
/*     */   protected final Class<?> _serializationView;
/*     */ 
/*     */   protected SerializerProvider(SerializationConfig config)
/*     */   {
/*  39 */     this._config = config;
/*  40 */     this._serializationView = (config == null ? null : this._config.getSerializationView());
/*     */   }
/*     */ 
/*     */   public abstract void setNullKeySerializer(JsonSerializer<Object> paramJsonSerializer);
/*     */ 
/*     */   public abstract void setNullValueSerializer(JsonSerializer<Object> paramJsonSerializer);
/*     */ 
/*     */   public abstract void setDefaultKeySerializer(JsonSerializer<Object> paramJsonSerializer);
/*     */ 
/*     */   public abstract void serializeValue(SerializationConfig paramSerializationConfig, JsonGenerator paramJsonGenerator, Object paramObject, SerializerFactory paramSerializerFactory)
/*     */     throws IOException, JsonGenerationException;
/*     */ 
/*     */   public abstract void serializeValue(SerializationConfig paramSerializationConfig, JsonGenerator paramJsonGenerator, Object paramObject, JavaType paramJavaType, SerializerFactory paramSerializerFactory)
/*     */     throws IOException, JsonGenerationException;
/*     */ 
/*     */   public abstract JsonSchema generateJsonSchema(Class<?> paramClass, SerializationConfig paramSerializationConfig, SerializerFactory paramSerializerFactory)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract boolean hasSerializerFor(SerializationConfig paramSerializationConfig, Class<?> paramClass, SerializerFactory paramSerializerFactory);
/*     */ 
/*     */   public final SerializationConfig getConfig()
/*     */   {
/* 142 */     return this._config;
/*     */   }
/*     */ 
/*     */   public final boolean isEnabled(SerializationConfig.Feature feature)
/*     */   {
/* 153 */     return this._config.isEnabled(feature);
/*     */   }
/*     */ 
/*     */   public final Class<?> getSerializationView()
/*     */   {
/* 164 */     return this._serializationView;
/*     */   }
/*     */ 
/*     */   public final FilterProvider getFilterProvider()
/*     */   {
/* 176 */     return this._config.getFilterProvider();
/*     */   }
/*     */ 
/*     */   public JavaType constructType(Type type)
/*     */   {
/* 183 */     return this._config.getTypeFactory().constructType(type);
/*     */   }
/*     */ 
/*     */   public abstract JsonSerializer<Object> findValueSerializer(Class<?> paramClass, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract JsonSerializer<Object> findValueSerializer(JavaType paramJavaType, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract JsonSerializer<Object> findTypedValueSerializer(Class<?> paramClass, boolean paramBoolean, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract JsonSerializer<Object> findTypedValueSerializer(JavaType paramJavaType, boolean paramBoolean, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract JsonSerializer<Object> findKeySerializer(JavaType paramJavaType, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   @Deprecated
/*     */   public final JsonSerializer<Object> findValueSerializer(Class<?> runtimeType)
/*     */     throws JsonMappingException
/*     */   {
/* 298 */     return findValueSerializer(runtimeType, null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final JsonSerializer<Object> findValueSerializer(JavaType serializationType)
/*     */     throws JsonMappingException
/*     */   {
/* 313 */     return findValueSerializer(serializationType, null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final JsonSerializer<Object> findTypedValueSerializer(Class<?> valueType, boolean cache)
/*     */     throws JsonMappingException
/*     */   {
/* 329 */     return findTypedValueSerializer(valueType, cache, null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final JsonSerializer<Object> findTypedValueSerializer(JavaType valueType, boolean cache)
/*     */     throws JsonMappingException
/*     */   {
/* 345 */     return findTypedValueSerializer(valueType, cache, null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final JsonSerializer<Object> getKeySerializer()
/*     */     throws JsonMappingException
/*     */   {
/* 360 */     return findKeySerializer(TYPE_OBJECT, null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public final JsonSerializer<Object> getKeySerializer(JavaType valueType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 374 */     return findKeySerializer(valueType, property);
/*     */   }
/*     */ 
/*     */   public abstract JsonSerializer<Object> getNullKeySerializer();
/*     */ 
/*     */   public abstract JsonSerializer<Object> getNullValueSerializer();
/*     */ 
/*     */   public abstract JsonSerializer<Object> getUnknownTypeSerializer(Class<?> paramClass);
/*     */ 
/*     */   public final void defaultSerializeValue(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 435 */     if (value == null) {
/* 436 */       getNullValueSerializer().serialize(null, jgen, this);
/*     */     } else {
/* 438 */       Class cls = value.getClass();
/* 439 */       findTypedValueSerializer(cls, true, null).serialize(value, jgen, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void defaultSerializeField(String fieldName, Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 451 */     jgen.writeFieldName(fieldName);
/* 452 */     if (value == null)
/*     */     {
/* 456 */       getNullValueSerializer().serialize(null, jgen, this);
/*     */     } else {
/* 458 */       Class cls = value.getClass();
/* 459 */       findTypedValueSerializer(cls, true, null).serialize(value, jgen, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public abstract void defaultSerializeDateValue(long paramLong, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void defaultSerializeDateValue(Date paramDate, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void defaultSerializeDateKey(long paramLong, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void defaultSerializeDateKey(Date paramDate, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public final void defaultSerializeNull(JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 510 */     getNullValueSerializer().serialize(null, jgen, this);
/*     */   }
/*     */ 
/*     */   public abstract int cachedSerializersCount();
/*     */ 
/*     */   public abstract void flushCachedSerializers();
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.SerializerProvider
 * JD-Core Version:    0.6.2
 */