/*     */ package org.codehaus.jackson.map;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ 
/*     */ public abstract class TypeSerializer
/*     */ {
/*     */   public abstract JsonTypeInfo.As getTypeInclusion();
/*     */ 
/*     */   public abstract String getPropertyName();
/*     */ 
/*     */   public abstract TypeIdResolver getTypeIdResolver();
/*     */ 
/*     */   public abstract void writeTypePrefixForScalar(Object paramObject, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void writeTypePrefixForObject(Object paramObject, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void writeTypePrefixForArray(Object paramObject, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void writeTypeSuffixForScalar(Object paramObject, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void writeTypeSuffixForObject(Object paramObject, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void writeTypeSuffixForArray(Object paramObject, JsonGenerator paramJsonGenerator)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 133 */     writeTypePrefixForScalar(value, jgen);
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 147 */     writeTypePrefixForObject(value, jgen);
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 161 */     writeTypePrefixForArray(value, jgen);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.TypeSerializer
 * JD-Core Version:    0.6.2
 */