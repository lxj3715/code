/*     */ package org.codehaus.jackson.map.annotate;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import org.codehaus.jackson.annotate.JacksonAnnotation;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ 
/*     */ @Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.PARAMETER})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @JacksonAnnotation
/*     */ public @interface JsonSerialize
/*     */ {
/*     */   public abstract Class<? extends JsonSerializer<?>> using();
/*     */ 
/*     */   public abstract Class<? extends JsonSerializer<?>> contentUsing();
/*     */ 
/*     */   public abstract Class<? extends JsonSerializer<?>> keyUsing();
/*     */ 
/*     */   public abstract Class<?> as();
/*     */ 
/*     */   public abstract Class<?> keyAs();
/*     */ 
/*     */   public abstract Class<?> contentAs();
/*     */ 
/*     */   public abstract Typing typing();
/*     */ 
/*     */   public abstract Inclusion include();
/*     */ 
/*     */   public static enum Typing
/*     */   {
/* 207 */     DYNAMIC, 
/*     */ 
/* 213 */     STATIC;
/*     */   }
/*     */ 
/*     */   public static enum Inclusion
/*     */   {
/* 152 */     ALWAYS, 
/*     */ 
/* 158 */     NON_NULL, 
/*     */ 
/* 168 */     NON_DEFAULT, 
/*     */ 
/* 190 */     NON_EMPTY;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.annotate.JsonSerialize
 * JD-Core Version:    0.6.2
 */