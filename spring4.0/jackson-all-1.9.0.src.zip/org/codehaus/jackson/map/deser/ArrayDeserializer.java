/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import org.codehaus.jackson.map.JsonDeserializer;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.map.deser.std.ObjectArrayDeserializer;
/*    */ import org.codehaus.jackson.map.type.ArrayType;
/*    */ 
/*    */ @Deprecated
/*    */ public class ArrayDeserializer extends ObjectArrayDeserializer
/*    */ {
/*    */   @Deprecated
/*    */   public ArrayDeserializer(ArrayType arrayType, JsonDeserializer<Object> elemDeser)
/*    */   {
/* 19 */     this(arrayType, elemDeser, null);
/*    */   }
/*    */ 
/*    */   public ArrayDeserializer(ArrayType arrayType, JsonDeserializer<Object> elemDeser, TypeDeserializer elemTypeDeser)
/*    */   {
/* 25 */     super(arrayType, elemDeser, elemTypeDeser);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.ArrayDeserializer
 * JD-Core Version:    0.6.2
 */