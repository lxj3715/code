package org.codehaus.jackson.map.deser;

import org.codehaus.jackson.map.deser.std.PrimitiveArrayDeserializers;

@Deprecated
public class ArrayDeserializers extends PrimitiveArrayDeserializers
{
}

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.ArrayDeserializers
 * JD-Core Version:    0.6.2
 */