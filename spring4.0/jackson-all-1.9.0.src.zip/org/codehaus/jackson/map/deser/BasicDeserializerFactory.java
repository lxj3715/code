/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.ContextualDeserializer;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializerFactory;
/*     */ import org.codehaus.jackson.map.DeserializerFactory.Config;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonDeserializer.None;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.KeyDeserializer;
/*     */ import org.codehaus.jackson.map.KeyDeserializer.None;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.AtomicReferenceDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.CollectionDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.EnumDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.EnumMapDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.EnumSetDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.JsonNodeDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.MapDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.ObjectArrayDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.PrimitiveArrayDeserializers;
/*     */ import org.codehaus.jackson.map.deser.std.StringCollectionDeserializer;
/*     */ import org.codehaus.jackson.map.ext.OptionalHandlerFactory;
/*     */ import org.codehaus.jackson.map.introspect.Annotated;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*     */ import org.codehaus.jackson.map.jsontype.SubtypeResolver;
/*     */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*     */ import org.codehaus.jackson.map.type.ArrayType;
/*     */ import org.codehaus.jackson.map.type.ClassKey;
/*     */ import org.codehaus.jackson.map.type.CollectionLikeType;
/*     */ import org.codehaus.jackson.map.type.CollectionType;
/*     */ import org.codehaus.jackson.map.type.MapLikeType;
/*     */ import org.codehaus.jackson.map.type.MapType;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.map.util.EnumResolver;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class BasicDeserializerFactory extends DeserializerFactory
/*     */ {
/*  45 */   static final HashMap<ClassKey, JsonDeserializer<Object>> _simpleDeserializers = StdDeserializers.constructAll();
/*     */ 
/*  52 */   static final HashMap<String, Class<? extends Map>> _mapFallbacks = new HashMap();
/*     */   static final HashMap<String, Class<? extends Collection>> _collectionFallbacks;
/* 102 */   protected static final HashMap<JavaType, JsonDeserializer<Object>> _arrayDeserializers = PrimitiveArrayDeserializers.getAll();
/*     */ 
/* 109 */   protected OptionalHandlerFactory optionalHandlers = OptionalHandlerFactory.instance;
/*     */ 
/*     */   public abstract DeserializerFactory withConfig(DeserializerFactory.Config paramConfig);
/*     */ 
/*     */   protected abstract JsonDeserializer<?> _findCustomArrayDeserializer(ArrayType paramArrayType, DeserializationConfig paramDeserializationConfig, DeserializerProvider paramDeserializerProvider, BeanProperty paramBeanProperty, TypeDeserializer paramTypeDeserializer, JsonDeserializer<?> paramJsonDeserializer)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   protected abstract JsonDeserializer<?> _findCustomCollectionDeserializer(CollectionType paramCollectionType, DeserializationConfig paramDeserializationConfig, DeserializerProvider paramDeserializerProvider, BasicBeanDescription paramBasicBeanDescription, BeanProperty paramBeanProperty, TypeDeserializer paramTypeDeserializer, JsonDeserializer<?> paramJsonDeserializer)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   protected abstract JsonDeserializer<?> _findCustomCollectionLikeDeserializer(CollectionLikeType paramCollectionLikeType, DeserializationConfig paramDeserializationConfig, DeserializerProvider paramDeserializerProvider, BasicBeanDescription paramBasicBeanDescription, BeanProperty paramBeanProperty, TypeDeserializer paramTypeDeserializer, JsonDeserializer<?> paramJsonDeserializer)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   protected abstract JsonDeserializer<?> _findCustomEnumDeserializer(Class<?> paramClass, DeserializationConfig paramDeserializationConfig, BasicBeanDescription paramBasicBeanDescription, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   protected abstract JsonDeserializer<?> _findCustomMapDeserializer(MapType paramMapType, DeserializationConfig paramDeserializationConfig, DeserializerProvider paramDeserializerProvider, BasicBeanDescription paramBasicBeanDescription, BeanProperty paramBeanProperty, KeyDeserializer paramKeyDeserializer, TypeDeserializer paramTypeDeserializer, JsonDeserializer<?> paramJsonDeserializer)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   protected abstract JsonDeserializer<?> _findCustomMapLikeDeserializer(MapLikeType paramMapLikeType, DeserializationConfig paramDeserializationConfig, DeserializerProvider paramDeserializerProvider, BasicBeanDescription paramBasicBeanDescription, BeanProperty paramBeanProperty, KeyDeserializer paramKeyDeserializer, TypeDeserializer paramTypeDeserializer, JsonDeserializer<?> paramJsonDeserializer)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   protected abstract JsonDeserializer<?> _findCustomTreeNodeDeserializer(Class<? extends JsonNode> paramClass, DeserializationConfig paramDeserializationConfig, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract ValueInstantiator findValueInstantiator(DeserializationConfig paramDeserializationConfig, BasicBeanDescription paramBasicBeanDescription)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public abstract JavaType mapAbstractType(DeserializationConfig paramDeserializationConfig, JavaType paramJavaType)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public JsonDeserializer<?> createArrayDeserializer(DeserializationConfig config, DeserializerProvider p, ArrayType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 189 */     JavaType elemType = type.getContentType();
/*     */ 
/* 192 */     JsonDeserializer contentDeser = (JsonDeserializer)elemType.getValueHandler();
/* 193 */     if (contentDeser == null)
/*     */     {
/* 195 */       JsonDeserializer deser = (JsonDeserializer)_arrayDeserializers.get(elemType);
/* 196 */       if (deser != null)
/*     */       {
/* 201 */         JsonDeserializer custom = _findCustomArrayDeserializer(type, config, p, property, null, null);
/* 202 */         if (custom != null) {
/* 203 */           return custom;
/*     */         }
/* 205 */         return deser;
/*     */       }
/*     */ 
/* 208 */       if (elemType.isPrimitive()) {
/* 209 */         throw new IllegalArgumentException("Internal error: primitive type (" + type + ") passed, no array deserializer found");
/*     */       }
/*     */     }
/*     */ 
/* 213 */     TypeDeserializer elemTypeDeser = (TypeDeserializer)elemType.getTypeHandler();
/*     */ 
/* 215 */     if (elemTypeDeser == null) {
/* 216 */       elemTypeDeser = findTypeDeserializer(config, elemType, property);
/*     */     }
/*     */ 
/* 219 */     JsonDeserializer custom = _findCustomArrayDeserializer(type, config, p, property, elemTypeDeser, contentDeser);
/* 220 */     if (custom != null) {
/* 221 */       return custom;
/*     */     }
/*     */ 
/* 224 */     if (contentDeser == null)
/*     */     {
/* 226 */       contentDeser = p.findValueDeserializer(config, elemType, property);
/*     */     }
/* 228 */     return new ObjectArrayDeserializer(type, contentDeser, elemTypeDeser);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> createCollectionDeserializer(DeserializationConfig config, DeserializerProvider p, CollectionType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 237 */     type = (CollectionType)mapAbstractType(config, type);
/*     */ 
/* 239 */     Class collectionClass = type.getRawClass();
/* 240 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspectForCreation(type);
/*     */ 
/* 242 */     JsonDeserializer deser = findDeserializerFromAnnotation(config, beanDesc.getClassInfo(), property);
/* 243 */     if (deser != null) {
/* 244 */       return deser;
/*     */     }
/*     */ 
/* 247 */     type = (CollectionType)modifyTypeByAnnotation(config, beanDesc.getClassInfo(), type, null);
/*     */ 
/* 249 */     JavaType contentType = type.getContentType();
/*     */ 
/* 251 */     JsonDeserializer contentDeser = (JsonDeserializer)contentType.getValueHandler();
/*     */ 
/* 254 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*     */ 
/* 256 */     if (contentTypeDeser == null) {
/* 257 */       contentTypeDeser = findTypeDeserializer(config, contentType, property);
/*     */     }
/*     */ 
/* 261 */     JsonDeserializer custom = _findCustomCollectionDeserializer(type, config, p, beanDesc, property, contentTypeDeser, contentDeser);
/*     */ 
/* 263 */     if (custom != null) {
/* 264 */       return custom;
/*     */     }
/*     */ 
/* 267 */     if (contentDeser == null)
/*     */     {
/* 269 */       if (EnumSet.class.isAssignableFrom(collectionClass)) {
/* 270 */         return new EnumSetDeserializer(constructEnumResolver(contentType.getRawClass(), config));
/*     */       }
/*     */ 
/* 274 */       contentDeser = p.findValueDeserializer(config, contentType, property);
/*     */     }
/*     */ 
/* 286 */     if ((type.isInterface()) || (type.isAbstract()))
/*     */     {
/* 288 */       Class fallback = (Class)_collectionFallbacks.get(collectionClass.getName());
/* 289 */       if (fallback == null) {
/* 290 */         throw new IllegalArgumentException("Can not find a deserializer for non-concrete Collection type " + type);
/*     */       }
/* 292 */       collectionClass = fallback;
/* 293 */       type = (CollectionType)type.forcedNarrowBy(collectionClass);
/*     */ 
/* 295 */       beanDesc = (BasicBeanDescription)config.introspectForCreation(type);
/*     */     }
/* 297 */     ValueInstantiator inst = findValueInstantiator(config, beanDesc);
/*     */ 
/* 299 */     if (contentType.getRawClass() == String.class)
/*     */     {
/* 301 */       return new StringCollectionDeserializer(type, contentDeser, inst);
/*     */     }
/* 303 */     return new CollectionDeserializer(type, contentDeser, contentTypeDeser, inst);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> createCollectionLikeDeserializer(DeserializationConfig config, DeserializerProvider p, CollectionLikeType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 313 */     type = (CollectionLikeType)mapAbstractType(config, type);
/*     */ 
/* 315 */     Class collectionClass = type.getRawClass();
/* 316 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspectClassAnnotations(collectionClass);
/*     */ 
/* 318 */     JsonDeserializer deser = findDeserializerFromAnnotation(config, beanDesc.getClassInfo(), property);
/* 319 */     if (deser != null) {
/* 320 */       return deser;
/*     */     }
/*     */ 
/* 323 */     type = (CollectionLikeType)modifyTypeByAnnotation(config, beanDesc.getClassInfo(), type, null);
/*     */ 
/* 325 */     JavaType contentType = type.getContentType();
/*     */ 
/* 327 */     JsonDeserializer contentDeser = (JsonDeserializer)contentType.getValueHandler();
/*     */ 
/* 330 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*     */ 
/* 332 */     if (contentTypeDeser == null) {
/* 333 */       contentTypeDeser = findTypeDeserializer(config, contentType, property);
/*     */     }
/* 335 */     return _findCustomCollectionLikeDeserializer(type, config, p, beanDesc, property, contentTypeDeser, contentDeser);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> createMapDeserializer(DeserializationConfig config, DeserializerProvider p, MapType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 345 */     type = (MapType)mapAbstractType(config, type);
/*     */ 
/* 347 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspectForCreation(type);
/*     */ 
/* 349 */     JsonDeserializer deser = findDeserializerFromAnnotation(config, beanDesc.getClassInfo(), property);
/* 350 */     if (deser != null) {
/* 351 */       return deser;
/*     */     }
/*     */ 
/* 354 */     type = (MapType)modifyTypeByAnnotation(config, beanDesc.getClassInfo(), type, null);
/* 355 */     JavaType keyType = type.getKeyType();
/* 356 */     JavaType contentType = type.getContentType();
/*     */ 
/* 360 */     JsonDeserializer contentDeser = (JsonDeserializer)contentType.getValueHandler();
/*     */ 
/* 363 */     KeyDeserializer keyDes = (KeyDeserializer)keyType.getValueHandler();
/* 364 */     if (keyDes == null) {
/* 365 */       keyDes = p.findKeyDeserializer(config, keyType, property);
/*     */     }
/*     */ 
/* 368 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*     */ 
/* 370 */     if (contentTypeDeser == null) {
/* 371 */       contentTypeDeser = findTypeDeserializer(config, contentType, property);
/*     */     }
/*     */ 
/* 375 */     JsonDeserializer custom = _findCustomMapDeserializer(type, config, p, beanDesc, property, keyDes, contentTypeDeser, contentDeser);
/*     */ 
/* 378 */     if (custom != null) {
/* 379 */       return custom;
/*     */     }
/*     */ 
/* 382 */     if (contentDeser == null)
/*     */     {
/* 384 */       contentDeser = p.findValueDeserializer(config, contentType, property);
/*     */     }
/*     */ 
/* 389 */     Class mapClass = type.getRawClass();
/* 390 */     if (EnumMap.class.isAssignableFrom(mapClass)) {
/* 391 */       Class kt = keyType.getRawClass();
/* 392 */       if ((kt == null) || (!kt.isEnum())) {
/* 393 */         throw new IllegalArgumentException("Can not construct EnumMap; generic (key) type not available");
/*     */       }
/* 395 */       return new EnumMapDeserializer(constructEnumResolver(kt, config), contentDeser);
/*     */     }
/*     */ 
/* 409 */     if ((type.isInterface()) || (type.isAbstract()))
/*     */     {
/* 411 */       Class fallback = (Class)_mapFallbacks.get(mapClass.getName());
/* 412 */       if (fallback == null) {
/* 413 */         throw new IllegalArgumentException("Can not find a deserializer for non-concrete Map type " + type);
/*     */       }
/* 415 */       mapClass = fallback;
/* 416 */       type = (MapType)type.forcedNarrowBy(mapClass);
/*     */ 
/* 418 */       beanDesc = (BasicBeanDescription)config.introspectForCreation(type);
/*     */     }
/* 420 */     ValueInstantiator inst = findValueInstantiator(config, beanDesc);
/* 421 */     MapDeserializer md = new MapDeserializer(type, inst, keyDes, contentDeser, contentTypeDeser);
/* 422 */     md.setIgnorableProperties(config.getAnnotationIntrospector().findPropertiesToIgnore(beanDesc.getClassInfo()));
/* 423 */     return md;
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> createMapLikeDeserializer(DeserializationConfig config, DeserializerProvider p, MapLikeType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 433 */     type = (MapLikeType)mapAbstractType(config, type);
/* 434 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspectForCreation(type);
/*     */ 
/* 436 */     JsonDeserializer deser = findDeserializerFromAnnotation(config, beanDesc.getClassInfo(), property);
/* 437 */     if (deser != null) {
/* 438 */       return deser;
/*     */     }
/*     */ 
/* 441 */     type = (MapLikeType)modifyTypeByAnnotation(config, beanDesc.getClassInfo(), type, null);
/* 442 */     JavaType keyType = type.getKeyType();
/* 443 */     JavaType contentType = type.getContentType();
/*     */ 
/* 447 */     JsonDeserializer contentDeser = (JsonDeserializer)contentType.getValueHandler();
/*     */ 
/* 450 */     KeyDeserializer keyDes = (KeyDeserializer)keyType.getValueHandler();
/* 451 */     if (keyDes == null) {
/* 452 */       keyDes = p.findKeyDeserializer(config, keyType, property);
/*     */     }
/*     */ 
/* 455 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*     */ 
/* 457 */     if (contentTypeDeser == null) {
/* 458 */       contentTypeDeser = findTypeDeserializer(config, contentType, property);
/*     */     }
/* 460 */     return _findCustomMapLikeDeserializer(type, config, p, beanDesc, property, keyDes, contentTypeDeser, contentDeser);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> createEnumDeserializer(DeserializationConfig config, DeserializerProvider p, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 475 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspectForCreation(type);
/* 476 */     JsonDeserializer des = findDeserializerFromAnnotation(config, beanDesc.getClassInfo(), property);
/* 477 */     if (des != null) {
/* 478 */       return des;
/*     */     }
/* 480 */     Class enumClass = type.getRawClass();
/*     */ 
/* 482 */     JsonDeserializer custom = _findCustomEnumDeserializer(enumClass, config, beanDesc, property);
/* 483 */     if (custom != null) {
/* 484 */       return custom;
/*     */     }
/*     */ 
/* 488 */     for (AnnotatedMethod factory : beanDesc.getFactoryMethods()) {
/* 489 */       if (config.getAnnotationIntrospector().hasCreatorAnnotation(factory)) {
/* 490 */         int argCount = factory.getParameterCount();
/* 491 */         if (argCount == 1) {
/* 492 */           Class returnType = factory.getRawType();
/*     */ 
/* 494 */           if (returnType.isAssignableFrom(enumClass)) {
/* 495 */             return EnumDeserializer.deserializerForCreator(config, enumClass, factory);
/*     */           }
/*     */         }
/* 498 */         throw new IllegalArgumentException("Unsuitable method (" + factory + ") decorated with @JsonCreator (for Enum type " + enumClass.getName() + ")");
/*     */       }
/*     */     }
/*     */ 
/* 502 */     return new EnumDeserializer(constructEnumResolver(enumClass, config));
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> createTreeDeserializer(DeserializationConfig config, DeserializerProvider p, JavaType nodeType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 511 */     Class nodeClass = nodeType.getRawClass();
/*     */ 
/* 513 */     JsonDeserializer custom = _findCustomTreeNodeDeserializer(nodeClass, config, property);
/* 514 */     if (custom != null) {
/* 515 */       return custom;
/*     */     }
/* 517 */     return JsonNodeDeserializer.getDeserializer(nodeClass);
/*     */   }
/*     */ 
/*     */   protected JsonDeserializer<Object> findStdBeanDeserializer(DeserializationConfig config, DeserializerProvider p, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 531 */     Class cls = type.getRawClass();
/*     */ 
/* 533 */     JsonDeserializer deser = (JsonDeserializer)_simpleDeserializers.get(new ClassKey(cls));
/* 534 */     if (deser != null) {
/* 535 */       return deser;
/*     */     }
/*     */ 
/* 539 */     if (AtomicReference.class.isAssignableFrom(cls))
/*     */     {
/* 541 */       TypeFactory tf = config.getTypeFactory();
/* 542 */       JavaType[] params = tf.findTypeParameters(type, AtomicReference.class);
/*     */       JavaType referencedType;
/*     */       JavaType referencedType;
/* 544 */       if ((params == null) || (params.length < 1))
/* 545 */         referencedType = TypeFactory.unknownType();
/*     */       else {
/* 547 */         referencedType = params[0];
/*     */       }
/*     */ 
/* 550 */       JsonDeserializer d2 = new AtomicReferenceDeserializer(referencedType, property);
/* 551 */       return d2;
/*     */     }
/*     */ 
/* 554 */     JsonDeserializer d = this.optionalHandlers.findDeserializer(type, config, p);
/* 555 */     if (d != null) {
/* 556 */       return d;
/*     */     }
/* 558 */     return null;
/*     */   }
/*     */ 
/*     */   public TypeDeserializer findTypeDeserializer(DeserializationConfig config, JavaType baseType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 566 */     Class cls = baseType.getRawClass();
/* 567 */     BasicBeanDescription bean = (BasicBeanDescription)config.introspectClassAnnotations(cls);
/* 568 */     AnnotatedClass ac = bean.getClassInfo();
/* 569 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 570 */     TypeResolverBuilder b = ai.findTypeResolver(config, ac, baseType);
/*     */ 
/* 575 */     Collection subtypes = null;
/* 576 */     if (b == null) {
/* 577 */       b = config.getDefaultTyper(baseType);
/* 578 */       if (b == null)
/* 579 */         return null;
/*     */     }
/*     */     else {
/* 582 */       subtypes = config.getSubtypeResolver().collectAndResolveSubtypes(ac, config, ai);
/*     */     }
/*     */ 
/* 586 */     if ((b.getDefaultImpl() == null) && (baseType.isAbstract())) {
/* 587 */       JavaType defaultType = mapAbstractType(config, baseType);
/* 588 */       if ((defaultType != null) && (defaultType.getRawClass() != baseType.getRawClass())) {
/* 589 */         b = b.defaultImpl(defaultType.getRawClass());
/*     */       }
/*     */     }
/* 592 */     return b.buildTypeDeserializer(config, baseType, subtypes, property);
/*     */   }
/*     */ 
/*     */   public TypeDeserializer findPropertyTypeDeserializer(DeserializationConfig config, JavaType baseType, AnnotatedMember annotated, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 620 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 621 */     TypeResolverBuilder b = ai.findPropertyTypeResolver(config, annotated, baseType);
/*     */ 
/* 623 */     if (b == null) {
/* 624 */       return findTypeDeserializer(config, baseType, property);
/*     */     }
/*     */ 
/* 627 */     Collection subtypes = config.getSubtypeResolver().collectAndResolveSubtypes(annotated, config, ai);
/* 628 */     return b.buildTypeDeserializer(config, baseType, subtypes, property);
/*     */   }
/*     */ 
/*     */   public TypeDeserializer findPropertyContentTypeDeserializer(DeserializationConfig config, JavaType containerType, AnnotatedMember propertyEntity, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 648 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 649 */     TypeResolverBuilder b = ai.findPropertyContentTypeResolver(config, propertyEntity, containerType);
/* 650 */     JavaType contentType = containerType.getContentType();
/*     */ 
/* 652 */     if (b == null) {
/* 653 */       return findTypeDeserializer(config, contentType, property);
/*     */     }
/*     */ 
/* 656 */     Collection subtypes = config.getSubtypeResolver().collectAndResolveSubtypes(propertyEntity, config, ai);
/* 657 */     return b.buildTypeDeserializer(config, contentType, subtypes, property);
/*     */   }
/*     */ 
/*     */   protected JsonDeserializer<Object> findDeserializerFromAnnotation(DeserializationConfig config, Annotated ann, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 675 */     Object deserDef = config.getAnnotationIntrospector().findDeserializer(ann);
/* 676 */     if (deserDef != null) {
/* 677 */       return _constructDeserializer(config, ann, property, deserDef);
/*     */     }
/* 679 */     return null;
/*     */   }
/*     */ 
/*     */   JsonDeserializer<Object> _constructDeserializer(DeserializationConfig config, Annotated ann, BeanProperty property, Object deserDef)
/*     */     throws JsonMappingException
/*     */   {
/* 687 */     if ((deserDef instanceof JsonDeserializer)) {
/* 688 */       JsonDeserializer deser = (JsonDeserializer)deserDef;
/*     */ 
/* 690 */       if ((deser instanceof ContextualDeserializer)) {
/* 691 */         deser = ((ContextualDeserializer)deser).createContextual(config, property);
/*     */       }
/* 693 */       return deser;
/*     */     }
/*     */ 
/* 698 */     if (!(deserDef instanceof Class)) {
/* 699 */       throw new IllegalStateException("AnnotationIntrospector returned deserializer definition of type " + deserDef.getClass().getName() + "; expected type JsonDeserializer or Class<JsonDeserializer> instead");
/*     */     }
/* 701 */     Class deserClass = (Class)deserDef;
/* 702 */     if (!JsonDeserializer.class.isAssignableFrom(deserClass)) {
/* 703 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + deserClass.getName() + "; expected Class<JsonDeserializer>");
/*     */     }
/* 705 */     JsonDeserializer deser = config.deserializerInstance(ann, deserClass);
/*     */ 
/* 707 */     if ((deser instanceof ContextualDeserializer)) {
/* 708 */       deser = ((ContextualDeserializer)deser).createContextual(config, property);
/*     */     }
/* 710 */     return deser;
/*     */   }
/*     */ 
/*     */   protected <T extends JavaType> T modifyTypeByAnnotation(DeserializationConfig config, Annotated a, T type, String propName)
/*     */     throws JsonMappingException
/*     */   {
/* 738 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 739 */     Class subclass = intr.findDeserializationType(a, type, propName);
/* 740 */     if (subclass != null) {
/*     */       try {
/* 742 */         type = type.narrowBy(subclass);
/*     */       } catch (IllegalArgumentException iae) {
/* 744 */         throw new JsonMappingException("Failed to narrow type " + type + " with concrete-type annotation (value " + subclass.getName() + "), method '" + a.getName() + "': " + iae.getMessage(), null, iae);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 749 */     if (type.isContainerType()) {
/* 750 */       Class keyClass = intr.findDeserializationKeyType(a, type.getKeyType(), propName);
/* 751 */       if (keyClass != null)
/*     */       {
/* 753 */         if (!(type instanceof MapLikeType))
/* 754 */           throw new JsonMappingException("Illegal key-type annotation: type " + type + " is not a Map(-like) type");
/*     */         try
/*     */         {
/* 757 */           type = ((MapLikeType)type).narrowKey(keyClass);
/*     */         } catch (IllegalArgumentException iae) {
/* 759 */           throw new JsonMappingException("Failed to narrow key type " + type + " with key-type annotation (" + keyClass.getName() + "): " + iae.getMessage(), null, iae);
/*     */         }
/*     */       }
/* 762 */       JavaType keyType = type.getKeyType();
/*     */ 
/* 767 */       if ((keyType != null) && (keyType.getValueHandler() == null)) {
/* 768 */         Class kdClass = intr.findKeyDeserializer(a);
/* 769 */         if ((kdClass != null) && (kdClass != KeyDeserializer.None.class)) {
/* 770 */           KeyDeserializer kd = config.keyDeserializerInstance(a, kdClass);
/*     */ 
/* 776 */           keyType.setValueHandler(kd);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 781 */       Class cc = intr.findDeserializationContentType(a, type.getContentType(), propName);
/* 782 */       if (cc != null) {
/*     */         try {
/* 784 */           type = type.narrowContentsBy(cc);
/*     */         } catch (IllegalArgumentException iae) {
/* 786 */           throw new JsonMappingException("Failed to narrow content type " + type + " with content-type annotation (" + cc.getName() + "): " + iae.getMessage(), null, iae);
/*     */         }
/*     */       }
/*     */ 
/* 790 */       JavaType contentType = type.getContentType();
/* 791 */       if (contentType.getValueHandler() == null) {
/* 792 */         Class cdClass = intr.findContentDeserializer(a);
/* 793 */         if ((cdClass != null) && (cdClass != JsonDeserializer.None.class)) {
/* 794 */           JsonDeserializer cd = config.deserializerInstance(a, cdClass);
/*     */ 
/* 799 */           type.getContentType().setValueHandler(cd);
/*     */         }
/*     */       }
/*     */     }
/* 803 */     return type;
/*     */   }
/*     */ 
/*     */   protected JavaType resolveType(DeserializationConfig config, BasicBeanDescription beanDesc, JavaType type, AnnotatedMember member, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 823 */     if (type.isContainerType()) {
/* 824 */       AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 825 */       JavaType keyType = type.getKeyType();
/* 826 */       if (keyType != null) {
/* 827 */         Class kdClass = intr.findKeyDeserializer(member);
/* 828 */         if ((kdClass != null) && (kdClass != KeyDeserializer.None.class)) {
/* 829 */           KeyDeserializer kd = config.keyDeserializerInstance(member, kdClass);
/*     */ 
/* 835 */           keyType.setValueHandler(kd);
/*     */         }
/*     */       }
/*     */ 
/* 839 */       Class cdClass = intr.findContentDeserializer(member);
/* 840 */       if ((cdClass != null) && (cdClass != JsonDeserializer.None.class)) {
/* 841 */         JsonDeserializer cd = config.deserializerInstance(member, cdClass);
/*     */ 
/* 846 */         type.getContentType().setValueHandler(cd);
/*     */       }
/*     */ 
/* 853 */       if ((member instanceof AnnotatedMember)) {
/* 854 */         TypeDeserializer contentTypeDeser = findPropertyContentTypeDeserializer(config, type, member, property);
/*     */ 
/* 856 */         if (contentTypeDeser != null)
/* 857 */           type = type.withContentTypeHandler(contentTypeDeser);
/*     */       }
/*     */     }
/*     */     TypeDeserializer valueTypeDeser;
/*     */     TypeDeserializer valueTypeDeser;
/* 863 */     if ((member instanceof AnnotatedMember)) {
/* 864 */       valueTypeDeser = findPropertyTypeDeserializer(config, type, member, property);
/*     */     }
/*     */     else {
/* 867 */       valueTypeDeser = findTypeDeserializer(config, type, null);
/*     */     }
/* 869 */     if (valueTypeDeser != null) {
/* 870 */       type = type.withTypeHandler(valueTypeDeser);
/*     */     }
/* 872 */     return type;
/*     */   }
/*     */ 
/*     */   protected EnumResolver<?> constructEnumResolver(Class<?> enumClass, DeserializationConfig config)
/*     */   {
/* 878 */     if (config.isEnabled(DeserializationConfig.Feature.READ_ENUMS_USING_TO_STRING)) {
/* 879 */       return EnumResolver.constructUnsafeUsingToString(enumClass);
/*     */     }
/* 881 */     return EnumResolver.constructUnsafe(enumClass, config.getAnnotationIntrospector());
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  55 */     _mapFallbacks.put(Map.class.getName(), LinkedHashMap.class);
/*  56 */     _mapFallbacks.put(ConcurrentMap.class.getName(), ConcurrentHashMap.class);
/*  57 */     _mapFallbacks.put(SortedMap.class.getName(), TreeMap.class);
/*     */ 
/*  64 */     _mapFallbacks.put("java.util.NavigableMap", TreeMap.class);
/*     */     try {
/*  66 */       Class key = Class.forName("java.util.ConcurrentNavigableMap");
/*  67 */       Class value = Class.forName("java.util.ConcurrentSkipListMap");
/*     */ 
/*  69 */       Class mapValue = value;
/*  70 */       _mapFallbacks.put(key.getName(), mapValue);
/*     */     }
/*     */     catch (ClassNotFoundException cnfe)
/*     */     {
/*     */     }
/*     */ 
/*  80 */     _collectionFallbacks = new HashMap();
/*     */ 
/*  83 */     _collectionFallbacks.put(Collection.class.getName(), ArrayList.class);
/*  84 */     _collectionFallbacks.put(List.class.getName(), ArrayList.class);
/*  85 */     _collectionFallbacks.put(Set.class.getName(), HashSet.class);
/*  86 */     _collectionFallbacks.put(SortedSet.class.getName(), TreeSet.class);
/*  87 */     _collectionFallbacks.put(Queue.class.getName(), LinkedList.class);
/*     */ 
/*  94 */     _collectionFallbacks.put("java.util.Deque", LinkedList.class);
/*  95 */     _collectionFallbacks.put("java.util.NavigableSet", TreeSet.class);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.BasicDeserializerFactory
 * JD-Core Version:    0.6.2
 */