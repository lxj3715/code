/*      */ package org.codehaus.jackson.map.deser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.codehaus.jackson.JsonParser;
/*      */ import org.codehaus.jackson.JsonParser.NumberType;
/*      */ import org.codehaus.jackson.JsonProcessingException;
/*      */ import org.codehaus.jackson.JsonToken;
/*      */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*      */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*      */ import org.codehaus.jackson.map.BeanDescription;
/*      */ import org.codehaus.jackson.map.BeanProperty;
/*      */ import org.codehaus.jackson.map.BeanProperty.Std;
/*      */ import org.codehaus.jackson.map.DeserializationConfig;
/*      */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*      */ import org.codehaus.jackson.map.DeserializationContext;
/*      */ import org.codehaus.jackson.map.DeserializerProvider;
/*      */ import org.codehaus.jackson.map.JsonDeserializer;
/*      */ import org.codehaus.jackson.map.JsonMappingException;
/*      */ import org.codehaus.jackson.map.ResolvableDeserializer;
/*      */ import org.codehaus.jackson.map.TypeDeserializer;
/*      */ import org.codehaus.jackson.map.annotate.JsonCachable;
/*      */ import org.codehaus.jackson.map.deser.impl.BeanPropertyMap;
/*      */ import org.codehaus.jackson.map.deser.impl.CreatorCollector;
/*      */ import org.codehaus.jackson.map.deser.impl.ExternalTypeHandler;
/*      */ import org.codehaus.jackson.map.deser.impl.ExternalTypeHandler.Builder;
/*      */ import org.codehaus.jackson.map.deser.impl.PropertyBasedCreator;
/*      */ import org.codehaus.jackson.map.deser.impl.PropertyValueBuffer;
/*      */ import org.codehaus.jackson.map.deser.impl.UnwrappedPropertyHandler;
/*      */ import org.codehaus.jackson.map.deser.impl.ValueInjector;
/*      */ import org.codehaus.jackson.map.deser.std.ContainerDeserializerBase;
/*      */ import org.codehaus.jackson.map.deser.std.StdDeserializer;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedWithParams;
/*      */ import org.codehaus.jackson.map.type.ClassKey;
/*      */ import org.codehaus.jackson.map.util.ClassUtil;
/*      */ import org.codehaus.jackson.type.JavaType;
/*      */ import org.codehaus.jackson.util.TokenBuffer;
/*      */ 
/*      */ @JsonCachable
/*      */ public class BeanDeserializer extends StdDeserializer<Object>
/*      */   implements ResolvableDeserializer
/*      */ {
/*      */   protected final AnnotatedClass _forClass;
/*      */   protected final JavaType _beanType;
/*      */   protected final BeanProperty _property;
/*      */   protected final ValueInstantiator _valueInstantiator;
/*      */   protected JsonDeserializer<Object> _delegateDeserializer;
/*      */   protected final PropertyBasedCreator _propertyBasedCreator;
/*      */   protected boolean _nonStandardCreation;
/*      */   protected final BeanPropertyMap _beanProperties;
/*      */   protected final ValueInjector[] _injectables;
/*      */   protected SettableAnyProperty _anySetter;
/*      */   protected final HashSet<String> _ignorableProps;
/*      */   protected final boolean _ignoreAllUnknown;
/*      */   protected final Map<String, SettableBeanProperty> _backRefs;
/*      */   protected HashMap<ClassKey, JsonDeserializer<Object>> _subDeserializers;
/*      */   protected UnwrappedPropertyHandler _unwrappedPropertyHandler;
/*      */   protected ExternalTypeHandler _externalTypeIdHandler;
/*      */ 
/*      */   @Deprecated
/*      */   public BeanDeserializer(AnnotatedClass forClass, JavaType type, BeanProperty property, CreatorCollector creators, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, SettableAnyProperty anySetter)
/*      */   {
/*  189 */     this(forClass, type, property, creators.constructValueInstantiator(null), properties, backRefs, ignorableProps, ignoreAllUnknown, anySetter, null);
/*      */   }
/*      */ 
/*      */   public BeanDeserializer(BeanDescription beanDesc, BeanProperty property, ValueInstantiator valueInstantiator, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, SettableAnyProperty anySetter, List<ValueInjector> injectables)
/*      */   {
/*  205 */     this(beanDesc.getClassInfo(), beanDesc.getType(), property, valueInstantiator, properties, backRefs, ignorableProps, ignoreAllUnknown, anySetter, injectables);
/*      */   }
/*      */ 
/*      */   protected BeanDeserializer(AnnotatedClass forClass, JavaType type, BeanProperty property, ValueInstantiator valueInstantiator, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, SettableAnyProperty anySetter, List<ValueInjector> injectables)
/*      */   {
/*  221 */     super(type);
/*  222 */     this._forClass = forClass;
/*  223 */     this._beanType = type;
/*  224 */     this._property = property;
/*      */ 
/*  226 */     this._valueInstantiator = valueInstantiator;
/*  227 */     if (valueInstantiator.canCreateFromObjectWith())
/*  228 */       this._propertyBasedCreator = new PropertyBasedCreator(valueInstantiator);
/*      */     else {
/*  230 */       this._propertyBasedCreator = null;
/*      */     }
/*      */ 
/*  233 */     this._beanProperties = properties;
/*  234 */     this._backRefs = backRefs;
/*  235 */     this._ignorableProps = ignorableProps;
/*  236 */     this._ignoreAllUnknown = ignoreAllUnknown;
/*  237 */     this._anySetter = anySetter;
/*  238 */     this._injectables = ((injectables == null) || (injectables.isEmpty()) ? null : (ValueInjector[])injectables.toArray(new ValueInjector[injectables.size()]));
/*      */ 
/*  241 */     this._nonStandardCreation = ((valueInstantiator.canCreateUsingDelegate()) || (this._propertyBasedCreator != null) || (!valueInstantiator.canCreateUsingDefault()) || (this._unwrappedPropertyHandler != null));
/*      */   }
/*      */ 
/*      */   protected BeanDeserializer(BeanDeserializer src)
/*      */   {
/*  255 */     this(src, src._ignoreAllUnknown);
/*      */   }
/*      */ 
/*      */   protected BeanDeserializer(BeanDeserializer src, boolean ignoreAllUnknown)
/*      */   {
/*  263 */     super(src._beanType);
/*      */ 
/*  265 */     this._forClass = src._forClass;
/*  266 */     this._beanType = src._beanType;
/*  267 */     this._property = src._property;
/*      */ 
/*  269 */     this._valueInstantiator = src._valueInstantiator;
/*  270 */     this._delegateDeserializer = src._delegateDeserializer;
/*  271 */     this._propertyBasedCreator = src._propertyBasedCreator;
/*      */ 
/*  273 */     this._beanProperties = src._beanProperties;
/*  274 */     this._backRefs = src._backRefs;
/*  275 */     this._ignorableProps = src._ignorableProps;
/*  276 */     this._ignoreAllUnknown = ignoreAllUnknown;
/*  277 */     this._anySetter = src._anySetter;
/*  278 */     this._injectables = src._injectables;
/*      */ 
/*  280 */     this._nonStandardCreation = src._nonStandardCreation;
/*  281 */     this._unwrappedPropertyHandler = src._unwrappedPropertyHandler;
/*      */   }
/*      */ 
/*      */   public JsonDeserializer<Object> unwrappingDeserializer()
/*      */   {
/*  291 */     if (getClass() != BeanDeserializer.class) {
/*  292 */       return this;
/*      */     }
/*      */ 
/*  298 */     return new BeanDeserializer(this, true);
/*      */   }
/*      */ 
/*      */   public boolean hasProperty(String propertyName)
/*      */   {
/*  308 */     return this._beanProperties.find(propertyName) != null;
/*      */   }
/*      */ 
/*      */   public int getPropertyCount()
/*      */   {
/*  317 */     return this._beanProperties.size();
/*      */   }
/*      */   public final Class<?> getBeanClass() {
/*  320 */     return this._beanType.getRawClass();
/*      */   }
/*  322 */   public JavaType getValueType() { return this._beanType; }
/*      */ 
/*      */ 
/*      */   public Iterator<SettableBeanProperty> properties()
/*      */   {
/*  330 */     if (this._beanProperties == null) {
/*  331 */       throw new IllegalStateException("Can only call before BeanDeserializer has been resolved");
/*      */     }
/*  333 */     return this._beanProperties.allProperties();
/*      */   }
/*      */ 
/*      */   public SettableBeanProperty findBackReference(String logicalName)
/*      */   {
/*  342 */     if (this._backRefs == null) {
/*  343 */       return null;
/*      */     }
/*  345 */     return (SettableBeanProperty)this._backRefs.get(logicalName);
/*      */   }
/*      */ 
/*      */   public ValueInstantiator getValueInstantiator()
/*      */   {
/*  352 */     return this._valueInstantiator;
/*      */   }
/*      */ 
/*      */   public void resolve(DeserializationConfig config, DeserializerProvider provider)
/*      */     throws JsonMappingException
/*      */   {
/*  370 */     Iterator it = this._beanProperties.allProperties();
/*  371 */     UnwrappedPropertyHandler unwrapped = null;
/*  372 */     ExternalTypeHandler.Builder extTypes = null;
/*      */ 
/*  374 */     while (it.hasNext()) {
/*  375 */       SettableBeanProperty origProp = (SettableBeanProperty)it.next();
/*  376 */       SettableBeanProperty prop = origProp;
/*      */ 
/*  378 */       if (!prop.hasValueDeserializer()) {
/*  379 */         prop = prop.withValueDeserializer(findDeserializer(config, provider, prop.getType(), prop));
/*      */       }
/*      */ 
/*  382 */       prop = _resolveManagedReferenceProperty(config, prop);
/*      */ 
/*  384 */       SettableBeanProperty u = _resolveUnwrappedProperty(config, prop);
/*  385 */       if (u != null) {
/*  386 */         prop = u;
/*  387 */         if (unwrapped == null) {
/*  388 */           unwrapped = new UnwrappedPropertyHandler();
/*      */         }
/*  390 */         unwrapped.addProperty(prop);
/*      */       }
/*      */ 
/*  393 */       prop = _resolveInnerClassValuedProperty(config, prop);
/*  394 */       if (prop != origProp) {
/*  395 */         this._beanProperties.replace(prop);
/*      */       }
/*      */ 
/*  401 */       if (prop.hasValueTypeDeserializer()) {
/*  402 */         TypeDeserializer typeDeser = prop.getValueTypeDeserializer();
/*  403 */         if (typeDeser.getTypeInclusion() == JsonTypeInfo.As.EXTERNAL_PROPERTY) {
/*  404 */           if (extTypes == null) {
/*  405 */             extTypes = new ExternalTypeHandler.Builder();
/*      */           }
/*  407 */           extTypes.addExternal(prop, typeDeser.getPropertyName());
/*      */ 
/*  409 */           this._beanProperties.remove(prop);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  415 */     if ((this._anySetter != null) && (!this._anySetter.hasValueDeserializer())) {
/*  416 */       this._anySetter = this._anySetter.withValueDeserializer(findDeserializer(config, provider, this._anySetter.getType(), this._anySetter.getProperty()));
/*      */     }
/*      */ 
/*  420 */     if (this._valueInstantiator.canCreateUsingDelegate()) {
/*  421 */       JavaType delegateType = this._valueInstantiator.getDelegateType();
/*  422 */       if (delegateType == null) {
/*  423 */         throw new IllegalArgumentException("Invalid delegate-creator definition for " + this._beanType + ": value instantiator (" + this._valueInstantiator.getClass().getName() + ") returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'");
/*      */       }
/*      */ 
/*  427 */       AnnotatedWithParams delegateCreator = this._valueInstantiator.getDelegateCreator();
/*      */ 
/*  429 */       BeanProperty.Std property = new BeanProperty.Std(null, delegateType, this._forClass.getAnnotations(), delegateCreator);
/*      */ 
/*  431 */       this._delegateDeserializer = findDeserializer(config, provider, delegateType, property);
/*      */     }
/*      */ 
/*  435 */     if (this._propertyBasedCreator != null) {
/*  436 */       for (SettableBeanProperty prop : this._propertyBasedCreator.getCreatorProperties()) {
/*  437 */         if (!prop.hasValueDeserializer()) {
/*  438 */           this._propertyBasedCreator.assignDeserializer(prop, findDeserializer(config, provider, prop.getType(), prop));
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  443 */     if (extTypes != null) {
/*  444 */       this._externalTypeIdHandler = extTypes.build();
/*      */ 
/*  446 */       this._nonStandardCreation = true;
/*      */     }
/*      */ 
/*  449 */     this._unwrappedPropertyHandler = unwrapped;
/*  450 */     if (unwrapped != null)
/*  451 */       this._nonStandardCreation = true;
/*      */   }
/*      */ 
/*      */   protected SettableBeanProperty _resolveManagedReferenceProperty(DeserializationConfig config, SettableBeanProperty prop)
/*      */   {
/*  464 */     String refName = prop.getManagedReferenceName();
/*  465 */     if (refName == null) {
/*  466 */       return prop;
/*      */     }
/*  468 */     JsonDeserializer valueDeser = prop.getValueDeserializer();
/*  469 */     SettableBeanProperty backProp = null;
/*  470 */     boolean isContainer = false;
/*  471 */     if ((valueDeser instanceof BeanDeserializer)) {
/*  472 */       backProp = ((BeanDeserializer)valueDeser).findBackReference(refName);
/*  473 */     } else if ((valueDeser instanceof ContainerDeserializerBase)) {
/*  474 */       JsonDeserializer contentDeser = ((ContainerDeserializerBase)valueDeser).getContentDeserializer();
/*  475 */       if (!(contentDeser instanceof BeanDeserializer)) {
/*  476 */         throw new IllegalArgumentException("Can not handle managed/back reference '" + refName + "': value deserializer is of type ContainerDeserializerBase, but content type is not handled by a BeanDeserializer " + " (instead it's of type " + contentDeser.getClass().getName() + ")");
/*      */       }
/*      */ 
/*  480 */       backProp = ((BeanDeserializer)contentDeser).findBackReference(refName);
/*  481 */       isContainer = true; } else {
/*  482 */       if ((valueDeser instanceof AbstractDeserializer)) {
/*  483 */         throw new IllegalArgumentException("Can not handle managed/back reference for abstract types (property " + this._beanType.getRawClass().getName() + "." + prop.getName() + ")");
/*      */       }
/*  485 */       throw new IllegalArgumentException("Can not handle managed/back reference '" + refName + "': type for value deserializer is not BeanDeserializer or ContainerDeserializerBase, but " + valueDeser.getClass().getName());
/*      */     }
/*      */ 
/*  489 */     if (backProp == null) {
/*  490 */       throw new IllegalArgumentException("Can not handle managed/back reference '" + refName + "': no back reference property found from type " + prop.getType());
/*      */     }
/*      */ 
/*  494 */     JavaType referredType = this._beanType;
/*  495 */     JavaType backRefType = backProp.getType();
/*  496 */     if (!backRefType.getRawClass().isAssignableFrom(referredType.getRawClass())) {
/*  497 */       throw new IllegalArgumentException("Can not handle managed/back reference '" + refName + "': back reference type (" + backRefType.getRawClass().getName() + ") not compatible with managed type (" + referredType.getRawClass().getName() + ")");
/*      */     }
/*      */ 
/*  501 */     return new SettableBeanProperty.ManagedReferenceProperty(refName, prop, backProp, this._forClass.getAnnotations(), isContainer);
/*      */   }
/*      */ 
/*      */   protected SettableBeanProperty _resolveUnwrappedProperty(DeserializationConfig config, SettableBeanProperty prop)
/*      */   {
/*  514 */     AnnotatedMember am = prop.getMember();
/*  515 */     if ((am != null) && (config.getAnnotationIntrospector().shouldUnwrapProperty(am) == Boolean.TRUE)) {
/*  516 */       JsonDeserializer orig = prop.getValueDeserializer();
/*  517 */       JsonDeserializer unwrapping = orig.unwrappingDeserializer();
/*  518 */       if ((unwrapping != orig) && (unwrapping != null))
/*      */       {
/*  520 */         return prop.withValueDeserializer(unwrapping);
/*      */       }
/*      */     }
/*  523 */     return null;
/*      */   }
/*      */ 
/*      */   protected SettableBeanProperty _resolveInnerClassValuedProperty(DeserializationConfig config, SettableBeanProperty prop)
/*      */   {
/*  538 */     JsonDeserializer deser = prop.getValueDeserializer();
/*      */ 
/*  540 */     if ((deser instanceof BeanDeserializer)) {
/*  541 */       BeanDeserializer bd = (BeanDeserializer)deser;
/*  542 */       ValueInstantiator vi = bd.getValueInstantiator();
/*  543 */       if (!vi.canCreateUsingDefault()) {
/*  544 */         Class valueClass = prop.getType().getRawClass();
/*  545 */         Class enclosing = ClassUtil.getOuterClass(valueClass);
/*      */ 
/*  547 */         if ((enclosing != null) && (enclosing == this._beanType.getRawClass())) {
/*  548 */           for (Constructor ctor : valueClass.getConstructors()) {
/*  549 */             Class[] paramTypes = ctor.getParameterTypes();
/*  550 */             if ((paramTypes.length == 1) && (paramTypes[0] == enclosing)) {
/*  551 */               if (config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/*  552 */                 ClassUtil.checkAndFixAccess(ctor);
/*      */               }
/*  554 */               return new SettableBeanProperty.InnerClassProperty(prop, ctor);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  560 */     return prop;
/*      */   }
/*      */ 
/*      */   public final Object deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  576 */     JsonToken t = jp.getCurrentToken();
/*      */ 
/*  578 */     if (t == JsonToken.START_OBJECT) {
/*  579 */       jp.nextToken();
/*  580 */       return deserializeFromObject(jp, ctxt);
/*      */     }
/*      */ 
/*  583 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[t.ordinal()]) {
/*      */     case 1:
/*  585 */       return deserializeFromString(jp, ctxt);
/*      */     case 2:
/*  587 */       return deserializeFromNumber(jp, ctxt);
/*      */     case 3:
/*  589 */       return deserializeFromDouble(jp, ctxt);
/*      */     case 4:
/*  591 */       return jp.getEmbeddedObject();
/*      */     case 5:
/*      */     case 6:
/*  594 */       return deserializeFromBoolean(jp, ctxt);
/*      */     case 7:
/*  597 */       return deserializeFromArray(jp, ctxt);
/*      */     case 8:
/*      */     case 9:
/*  600 */       return deserializeFromObject(jp, ctxt);
/*      */     }
/*  602 */     throw ctxt.mappingException(getBeanClass());
/*      */   }
/*      */ 
/*      */   public Object deserialize(JsonParser jp, DeserializationContext ctxt, Object bean)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  614 */     if (this._injectables != null) {
/*  615 */       injectValues(ctxt, bean);
/*      */     }
/*  617 */     if (this._unwrappedPropertyHandler != null) {
/*  618 */       return deserializeWithUnwrapped(jp, ctxt, bean);
/*      */     }
/*  620 */     if (this._externalTypeIdHandler != null) {
/*  621 */       return deserializeWithExternalTypeId(jp, ctxt, bean);
/*      */     }
/*  623 */     JsonToken t = jp.getCurrentToken();
/*      */ 
/*  625 */     if (t == JsonToken.START_OBJECT);
/*  626 */     for (t = jp.nextToken(); 
/*  628 */       t == JsonToken.FIELD_NAME; t = jp.nextToken()) {
/*  629 */       String propName = jp.getCurrentName();
/*  630 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  631 */       jp.nextToken();
/*      */ 
/*  633 */       if (prop != null) {
/*      */         try {
/*  635 */           prop.deserializeAndSet(jp, ctxt, bean);
/*      */         } catch (Exception e) {
/*  637 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         }
/*      */ 
/*      */       }
/*  644 */       else if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))) {
/*  645 */         jp.skipChildren();
/*      */       }
/*  648 */       else if (this._anySetter != null) {
/*  649 */         this._anySetter.deserializeAndSet(jp, ctxt, bean, propName);
/*      */       }
/*      */       else
/*      */       {
/*  653 */         handleUnknownProperty(jp, ctxt, bean, propName);
/*      */       }
/*      */     }
/*  655 */     return bean;
/*      */   }
/*      */ 
/*      */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  664 */     return typeDeserializer.deserializeTypedFromObject(jp, ctxt);
/*      */   }
/*      */ 
/*      */   public Object deserializeFromObject(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  676 */     if (this._nonStandardCreation) {
/*  677 */       if (this._unwrappedPropertyHandler != null) {
/*  678 */         return deserializeWithUnwrapped(jp, ctxt);
/*      */       }
/*  680 */       if (this._externalTypeIdHandler != null) {
/*  681 */         return deserializeWithExternalTypeId(jp, ctxt);
/*      */       }
/*  683 */       return deserializeFromObjectUsingNonDefault(jp, ctxt);
/*      */     }
/*      */ 
/*  686 */     Object bean = this._valueInstantiator.createUsingDefault();
/*  687 */     if (this._injectables != null) {
/*  688 */       injectValues(ctxt, bean);
/*      */     }
/*  690 */     for (; jp.getCurrentToken() != JsonToken.END_OBJECT; jp.nextToken()) {
/*  691 */       String propName = jp.getCurrentName();
/*      */ 
/*  693 */       jp.nextToken();
/*  694 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  695 */       if (prop != null) {
/*      */         try {
/*  697 */           prop.deserializeAndSet(jp, ctxt, bean);
/*      */         } catch (Exception e) {
/*  699 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         }
/*      */ 
/*      */       }
/*  706 */       else if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName)))
/*  707 */         jp.skipChildren();
/*  708 */       else if (this._anySetter != null) {
/*      */         try {
/*  710 */           this._anySetter.deserializeAndSet(jp, ctxt, bean, propName);
/*      */         } catch (Exception e) {
/*  712 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  717 */         handleUnknownProperty(jp, ctxt, bean, propName);
/*      */       }
/*      */     }
/*  720 */     return bean;
/*      */   }
/*      */ 
/*      */   protected Object deserializeFromObjectUsingNonDefault(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  729 */     if (this._delegateDeserializer != null) {
/*  730 */       return this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*      */     }
/*  732 */     if (this._propertyBasedCreator != null) {
/*  733 */       return _deserializeUsingPropertyBased(jp, ctxt);
/*      */     }
/*      */ 
/*  736 */     if (this._beanType.isAbstract()) {
/*  737 */       throw JsonMappingException.from(jp, "Can not instantiate abstract type " + this._beanType + " (need to add/enable type information?)");
/*      */     }
/*      */ 
/*  740 */     throw JsonMappingException.from(jp, "No suitable constructor found for type " + this._beanType + ": can not instantiate from JSON object (need to add/enable type information?)");
/*      */   }
/*      */ 
/*      */   public Object deserializeFromString(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  750 */     if ((this._delegateDeserializer != null) && 
/*  751 */       (!this._valueInstantiator.canCreateFromString())) {
/*  752 */       Object bean = this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*  753 */       if (this._injectables != null) {
/*  754 */         injectValues(ctxt, bean);
/*      */       }
/*  756 */       return bean;
/*      */     }
/*      */ 
/*  759 */     return this._valueInstantiator.createFromString(jp.getText());
/*      */   }
/*      */ 
/*      */   public Object deserializeFromNumber(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  765 */     switch (jp.getNumberType()) {
/*      */     case INT:
/*  767 */       if ((this._delegateDeserializer != null) && 
/*  768 */         (!this._valueInstantiator.canCreateFromInt())) {
/*  769 */         Object bean = this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*  770 */         if (this._injectables != null) {
/*  771 */           injectValues(ctxt, bean);
/*      */         }
/*  773 */         return bean;
/*      */       }
/*      */ 
/*  776 */       return this._valueInstantiator.createFromInt(jp.getIntValue());
/*      */     case LONG:
/*  778 */       if ((this._delegateDeserializer != null) && 
/*  779 */         (!this._valueInstantiator.canCreateFromInt())) {
/*  780 */         Object bean = this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*  781 */         if (this._injectables != null) {
/*  782 */           injectValues(ctxt, bean);
/*      */         }
/*  784 */         return bean;
/*      */       }
/*      */ 
/*  787 */       return this._valueInstantiator.createFromLong(jp.getLongValue());
/*      */     }
/*      */ 
/*  790 */     if (this._delegateDeserializer != null) {
/*  791 */       Object bean = this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*  792 */       if (this._injectables != null) {
/*  793 */         injectValues(ctxt, bean);
/*      */       }
/*  795 */       return bean;
/*      */     }
/*  797 */     throw ctxt.instantiationException(getBeanClass(), "no suitable creator method found to deserialize from JSON integer number");
/*      */   }
/*      */ 
/*      */   public Object deserializeFromDouble(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  809 */     switch (jp.getNumberType()) {
/*      */     case FLOAT:
/*      */     case DOUBLE:
/*  812 */       if ((this._delegateDeserializer != null) && 
/*  813 */         (!this._valueInstantiator.canCreateFromDouble())) {
/*  814 */         Object bean = this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*  815 */         if (this._injectables != null) {
/*  816 */           injectValues(ctxt, bean);
/*      */         }
/*  818 */         return bean;
/*      */       }
/*      */ 
/*  821 */       return this._valueInstantiator.createFromDouble(jp.getDoubleValue());
/*      */     }
/*      */ 
/*  824 */     if (this._delegateDeserializer != null) {
/*  825 */       return this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*      */     }
/*  827 */     throw ctxt.instantiationException(getBeanClass(), "no suitable creator method found to deserialize from JSON floating-point number");
/*      */   }
/*      */ 
/*      */   public Object deserializeFromBoolean(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  839 */     if ((this._delegateDeserializer != null) && 
/*  840 */       (!this._valueInstantiator.canCreateFromBoolean())) {
/*  841 */       Object bean = this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*  842 */       if (this._injectables != null) {
/*  843 */         injectValues(ctxt, bean);
/*      */       }
/*  845 */       return bean;
/*      */     }
/*      */ 
/*  848 */     boolean value = jp.getCurrentToken() == JsonToken.VALUE_TRUE;
/*  849 */     return this._valueInstantiator.createFromBoolean(value);
/*      */   }
/*      */ 
/*      */   public Object deserializeFromArray(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  858 */     if (this._delegateDeserializer != null) {
/*      */       try {
/*  860 */         Object bean = this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*  861 */         if (this._injectables != null) {
/*  862 */           injectValues(ctxt, bean);
/*      */         }
/*  864 */         return bean;
/*      */       } catch (Exception e) {
/*  866 */         wrapInstantiationProblem(e, ctxt);
/*      */       }
/*      */     }
/*  869 */     throw ctxt.mappingException(getBeanClass());
/*      */   }
/*      */ 
/*      */   protected final Object _deserializeUsingPropertyBased(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  885 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*  886 */     PropertyValueBuffer buffer = creator.startBuilding(jp, ctxt);
/*      */ 
/*  889 */     TokenBuffer unknown = null;
/*      */ 
/*  891 */     for (JsonToken t = jp.getCurrentToken(); 
/*  892 */       t == JsonToken.FIELD_NAME; t = jp.nextToken()) {
/*  893 */       String propName = jp.getCurrentName();
/*  894 */       jp.nextToken();
/*      */ 
/*  896 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*  897 */       if (creatorProp != null)
/*      */       {
/*  899 */         Object value = creatorProp.deserialize(jp, ctxt);
/*  900 */         if (buffer.assignParameter(creatorProp.getPropertyIndex(), value)) { jp.nextToken();
/*      */           Object bean;
/*      */           try {
/*  904 */             bean = creator.build(buffer);
/*      */           } catch (Exception e) {
/*  906 */             wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*  907 */             continue;
/*      */           }
/*      */ 
/*  910 */           if (bean.getClass() != this._beanType.getRawClass()) {
/*  911 */             return handlePolymorphic(jp, ctxt, bean, unknown);
/*      */           }
/*  913 */           if (unknown != null) {
/*  914 */             bean = handleUnknownProperties(ctxt, bean, unknown);
/*      */           }
/*      */ 
/*  917 */           return deserialize(jp, ctxt, bean);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  922 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  923 */         if (prop != null) {
/*  924 */           buffer.bufferProperty(prop, prop.deserialize(jp, ctxt));
/*      */         }
/*  930 */         else if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))) {
/*  931 */           jp.skipChildren();
/*      */         }
/*  935 */         else if (this._anySetter != null) {
/*  936 */           buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(jp, ctxt));
/*      */         }
/*      */         else
/*      */         {
/*  940 */           if (unknown == null) {
/*  941 */             unknown = new TokenBuffer(jp.getCodec());
/*      */           }
/*  943 */           unknown.writeFieldName(propName);
/*  944 */           unknown.copyCurrentStructure(jp);
/*      */         }
/*      */       }
/*      */     }
/*      */     Object bean;
/*      */     try {
/*  950 */       bean = creator.build(buffer);
/*      */     } catch (Exception e) {
/*  952 */       wrapInstantiationProblem(e, ctxt);
/*  953 */       return null;
/*      */     }
/*  955 */     if (unknown != null)
/*      */     {
/*  957 */       if (bean.getClass() != this._beanType.getRawClass()) {
/*  958 */         return handlePolymorphic(null, ctxt, bean, unknown);
/*      */       }
/*      */ 
/*  961 */       return handleUnknownProperties(ctxt, bean, unknown);
/*      */     }
/*  963 */     return bean;
/*      */   }
/*      */ 
/*      */   protected Object handlePolymorphic(JsonParser jp, DeserializationContext ctxt, Object bean, TokenBuffer unknownTokens)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  982 */     JsonDeserializer subDeser = _findSubclassDeserializer(ctxt, bean, unknownTokens);
/*  983 */     if (subDeser != null) {
/*  984 */       if (unknownTokens != null)
/*      */       {
/*  986 */         unknownTokens.writeEndObject();
/*  987 */         JsonParser p2 = unknownTokens.asParser();
/*  988 */         p2.nextToken();
/*  989 */         bean = subDeser.deserialize(p2, ctxt, bean);
/*      */       }
/*      */ 
/*  992 */       if (jp != null) {
/*  993 */         bean = subDeser.deserialize(jp, ctxt, bean);
/*      */       }
/*  995 */       return bean;
/*      */     }
/*      */ 
/*  998 */     if (unknownTokens != null) {
/*  999 */       bean = handleUnknownProperties(ctxt, bean, unknownTokens);
/*      */     }
/*      */ 
/* 1002 */     if (jp != null) {
/* 1003 */       bean = deserialize(jp, ctxt, bean);
/*      */     }
/* 1005 */     return bean;
/*      */   }
/*      */ 
/*      */   protected Object deserializeWithUnwrapped(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1021 */     if (this._delegateDeserializer != null) {
/* 1022 */       return this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*      */     }
/* 1024 */     if (this._propertyBasedCreator != null) {
/* 1025 */       return deserializeUsingPropertyBasedWithUnwrapped(jp, ctxt);
/*      */     }
/*      */ 
/* 1028 */     TokenBuffer tokens = new TokenBuffer(jp.getCodec());
/* 1029 */     tokens.writeStartObject();
/* 1030 */     Object bean = this._valueInstantiator.createUsingDefault();
/*      */ 
/* 1032 */     if (this._injectables != null) {
/* 1033 */       injectValues(ctxt, bean);
/*      */     }
/*      */ 
/* 1036 */     for (; jp.getCurrentToken() != JsonToken.END_OBJECT; jp.nextToken()) {
/* 1037 */       String propName = jp.getCurrentName();
/* 1038 */       jp.nextToken();
/* 1039 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1040 */       if (prop != null) {
/*      */         try {
/* 1042 */           prop.deserializeAndSet(jp, ctxt, bean);
/*      */         } catch (Exception e) {
/* 1044 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         }
/*      */ 
/*      */       }
/* 1049 */       else if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))) {
/* 1050 */         jp.skipChildren();
/*      */       }
/*      */       else
/*      */       {
/* 1054 */         tokens.writeFieldName(propName);
/* 1055 */         tokens.copyCurrentStructure(jp);
/*      */ 
/* 1057 */         if (this._anySetter != null) {
/*      */           try {
/* 1059 */             this._anySetter.deserializeAndSet(jp, ctxt, bean, propName);
/*      */           } catch (Exception e) {
/* 1061 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1066 */     tokens.writeEndObject();
/* 1067 */     this._unwrappedPropertyHandler.processUnwrapped(jp, ctxt, bean, tokens);
/* 1068 */     return bean;
/*      */   }
/*      */ 
/*      */   protected Object deserializeWithUnwrapped(JsonParser jp, DeserializationContext ctxt, Object bean)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1074 */     JsonToken t = jp.getCurrentToken();
/* 1075 */     if (t == JsonToken.START_OBJECT) {
/* 1076 */       t = jp.nextToken();
/*      */     }
/* 1078 */     TokenBuffer tokens = new TokenBuffer(jp.getCodec());
/* 1079 */     tokens.writeStartObject();
/* 1080 */     for (; t == JsonToken.FIELD_NAME; t = jp.nextToken()) {
/* 1081 */       String propName = jp.getCurrentName();
/* 1082 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1083 */       jp.nextToken();
/* 1084 */       if (prop != null) {
/*      */         try {
/* 1086 */           prop.deserializeAndSet(jp, ctxt, bean);
/*      */         } catch (Exception e) {
/* 1088 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         }
/*      */ 
/*      */       }
/* 1092 */       else if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))) {
/* 1093 */         jp.skipChildren();
/*      */       }
/*      */       else
/*      */       {
/* 1097 */         tokens.writeFieldName(propName);
/* 1098 */         tokens.copyCurrentStructure(jp);
/*      */ 
/* 1100 */         if (this._anySetter != null)
/* 1101 */           this._anySetter.deserializeAndSet(jp, ctxt, bean, propName);
/*      */       }
/*      */     }
/* 1104 */     tokens.writeEndObject();
/* 1105 */     this._unwrappedPropertyHandler.processUnwrapped(jp, ctxt, bean, tokens);
/* 1106 */     return bean;
/*      */   }
/*      */ 
/*      */   protected Object deserializeUsingPropertyBasedWithUnwrapped(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1112 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 1113 */     PropertyValueBuffer buffer = creator.startBuilding(jp, ctxt);
/*      */ 
/* 1115 */     TokenBuffer tokens = new TokenBuffer(jp.getCodec());
/* 1116 */     tokens.writeStartObject();
/*      */ 
/* 1118 */     for (JsonToken t = jp.getCurrentToken(); 
/* 1119 */       t == JsonToken.FIELD_NAME; t = jp.nextToken()) {
/* 1120 */       String propName = jp.getCurrentName();
/* 1121 */       jp.nextToken();
/*      */ 
/* 1123 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/* 1124 */       if (creatorProp != null)
/*      */       {
/* 1126 */         Object value = creatorProp.deserialize(jp, ctxt);
/* 1127 */         if (buffer.assignParameter(creatorProp.getPropertyIndex(), value)) { t = jp.nextToken();
/*      */           Object bean;
/*      */           try {
/* 1131 */             bean = creator.build(buffer);
/*      */           } catch (Exception e) {
/* 1133 */             wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/* 1134 */             continue;
/*      */           }
/*      */ 
/* 1137 */           while (t == JsonToken.FIELD_NAME) {
/* 1138 */             jp.nextToken();
/* 1139 */             tokens.copyCurrentStructure(jp);
/* 1140 */             t = jp.nextToken();
/*      */           }
/* 1142 */           tokens.writeEndObject();
/* 1143 */           if (bean.getClass() != this._beanType.getRawClass())
/*      */           {
/* 1146 */             throw ctxt.mappingException("Can not create polymorphic instances with unwrapped values");
/*      */           }
/* 1148 */           return this._unwrappedPropertyHandler.processUnwrapped(jp, ctxt, bean, tokens);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1153 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1154 */         if (prop != null) {
/* 1155 */           buffer.bufferProperty(prop, prop.deserialize(jp, ctxt));
/*      */         }
/* 1161 */         else if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))) {
/* 1162 */           jp.skipChildren();
/*      */         }
/*      */         else {
/* 1165 */           tokens.writeFieldName(propName);
/* 1166 */           tokens.copyCurrentStructure(jp);
/*      */ 
/* 1168 */           if (this._anySetter != null)
/* 1169 */             buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(jp, ctxt));
/*      */         }
/*      */       }
/*      */     }
/*      */     Object bean;
/*      */     try
/*      */     {
/* 1176 */       bean = creator.build(buffer);
/*      */     } catch (Exception e) {
/* 1178 */       wrapInstantiationProblem(e, ctxt);
/* 1179 */       return null;
/*      */     }
/* 1181 */     return this._unwrappedPropertyHandler.processUnwrapped(jp, ctxt, bean, tokens);
/*      */   }
/*      */ 
/*      */   protected Object deserializeWithExternalTypeId(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1194 */     if (this._propertyBasedCreator != null) {
/* 1195 */       return deserializeUsingPropertyBasedWithExternalTypeId(jp, ctxt);
/*      */     }
/* 1197 */     return deserializeWithExternalTypeId(jp, ctxt, this._valueInstantiator.createUsingDefault());
/*      */   }
/*      */ 
/*      */   protected Object deserializeWithExternalTypeId(JsonParser jp, DeserializationContext ctxt, Object bean)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1204 */     ExternalTypeHandler ext = this._externalTypeIdHandler.start();
/* 1205 */     for (; jp.getCurrentToken() != JsonToken.END_OBJECT; jp.nextToken()) {
/* 1206 */       String propName = jp.getCurrentName();
/* 1207 */       jp.nextToken();
/* 1208 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1209 */       if (prop != null) {
/*      */         try {
/* 1211 */           prop.deserializeAndSet(jp, ctxt, bean);
/*      */         } catch (Exception e) {
/* 1213 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         }
/*      */ 
/*      */       }
/* 1218 */       else if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))) {
/* 1219 */         jp.skipChildren();
/*      */       }
/* 1223 */       else if (!ext.handleToken(jp, ctxt, propName, bean))
/*      */       {
/* 1227 */         if (this._anySetter != null) {
/*      */           try {
/* 1229 */             this._anySetter.deserializeAndSet(jp, ctxt, bean, propName);
/*      */           } catch (Exception e) {
/* 1231 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1236 */           handleUnknownProperty(jp, ctxt, bean, propName);
/*      */         }
/*      */       }
/*      */     }
/* 1240 */     return ext.complete(jp, ctxt, bean);
/*      */   }
/*      */ 
/*      */   protected Object deserializeUsingPropertyBasedWithExternalTypeId(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1246 */     ExternalTypeHandler ext = this._externalTypeIdHandler.start();
/* 1247 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 1248 */     PropertyValueBuffer buffer = creator.startBuilding(jp, ctxt);
/*      */ 
/* 1250 */     TokenBuffer tokens = new TokenBuffer(jp.getCodec());
/* 1251 */     tokens.writeStartObject();
/*      */ 
/* 1253 */     for (JsonToken t = jp.getCurrentToken(); 
/* 1254 */       t == JsonToken.FIELD_NAME; t = jp.nextToken()) {
/* 1255 */       String propName = jp.getCurrentName();
/* 1256 */       jp.nextToken();
/*      */ 
/* 1258 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/* 1259 */       if (creatorProp != null)
/*      */       {
/* 1261 */         Object value = creatorProp.deserialize(jp, ctxt);
/* 1262 */         if (buffer.assignParameter(creatorProp.getPropertyIndex(), value)) { t = jp.nextToken();
/*      */           Object bean;
/*      */           try {
/* 1266 */             bean = creator.build(buffer);
/*      */           } catch (Exception e) {
/* 1268 */             wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/* 1269 */             continue;
/*      */           }
/*      */ 
/* 1272 */           while (t == JsonToken.FIELD_NAME) {
/* 1273 */             jp.nextToken();
/* 1274 */             tokens.copyCurrentStructure(jp);
/* 1275 */             t = jp.nextToken();
/*      */           }
/* 1277 */           if (bean.getClass() != this._beanType.getRawClass())
/*      */           {
/* 1280 */             throw ctxt.mappingException("Can not create polymorphic instances with unwrapped values");
/*      */           }
/* 1282 */           return ext.complete(jp, ctxt, bean);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1287 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1288 */         if (prop != null) {
/* 1289 */           buffer.bufferProperty(prop, prop.deserialize(jp, ctxt));
/*      */         }
/* 1293 */         else if (!ext.handleToken(jp, ctxt, propName, null))
/*      */         {
/* 1299 */           if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))) {
/* 1300 */             jp.skipChildren();
/*      */           }
/* 1304 */           else if (this._anySetter != null)
/* 1305 */             buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(jp, ctxt));
/*      */         }
/*      */       }
/*      */     }
/*      */     Object bean;
/*      */     try
/*      */     {
/* 1312 */       bean = creator.build(buffer);
/*      */     } catch (Exception e) {
/* 1314 */       wrapInstantiationProblem(e, ctxt);
/* 1315 */       return null;
/*      */     }
/* 1317 */     return ext.complete(jp, ctxt, bean);
/*      */   }
/*      */ 
/*      */   protected void injectValues(DeserializationContext ctxt, Object bean)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1329 */     for (ValueInjector injector : this._injectables)
/* 1330 */       injector.inject(ctxt, bean);
/*      */   }
/*      */ 
/*      */   protected void handleUnknownProperty(JsonParser jp, DeserializationContext ctxt, Object beanOrClass, String propName)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1347 */     if ((this._ignoreAllUnknown) || ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))))
/*      */     {
/* 1349 */       jp.skipChildren();
/* 1350 */       return;
/*      */     }
/*      */ 
/* 1355 */     super.handleUnknownProperty(jp, ctxt, beanOrClass, propName);
/*      */   }
/*      */ 
/*      */   protected Object handleUnknownProperties(DeserializationContext ctxt, Object bean, TokenBuffer unknownTokens)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 1367 */     unknownTokens.writeEndObject();
/*      */ 
/* 1370 */     JsonParser bufferParser = unknownTokens.asParser();
/* 1371 */     while (bufferParser.nextToken() != JsonToken.END_OBJECT) {
/* 1372 */       String propName = bufferParser.getCurrentName();
/*      */ 
/* 1374 */       bufferParser.nextToken();
/* 1375 */       handleUnknownProperty(bufferParser, ctxt, bean, propName);
/*      */     }
/* 1377 */     return bean;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<Object> _findSubclassDeserializer(DeserializationContext ctxt, Object bean, TokenBuffer unknownTokens)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*      */     JsonDeserializer subDeser;
/* 1390 */     synchronized (this) {
/* 1391 */       subDeser = this._subDeserializers == null ? null : (JsonDeserializer)this._subDeserializers.get(new ClassKey(bean.getClass()));
/*      */     }
/* 1393 */     if (subDeser != null) {
/* 1394 */       return subDeser;
/*      */     }
/*      */ 
/* 1397 */     DeserializerProvider deserProv = ctxt.getDeserializerProvider();
/* 1398 */     if (deserProv != null) {
/* 1399 */       JavaType type = ctxt.constructType(bean.getClass());
/*      */ 
/* 1403 */       subDeser = deserProv.findValueDeserializer(ctxt.getConfig(), type, this._property);
/*      */ 
/* 1405 */       if (subDeser != null) {
/* 1406 */         synchronized (this) {
/* 1407 */           if (this._subDeserializers == null) {
/* 1408 */             this._subDeserializers = new HashMap();
/*      */           }
/* 1410 */           this._subDeserializers.put(new ClassKey(bean.getClass()), subDeser);
/*      */         }
/*      */       }
/*      */     }
/* 1414 */     return subDeser;
/*      */   }
/*      */ 
/*      */   public void wrapAndThrow(Throwable t, Object bean, String fieldName, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1443 */     while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 1444 */       t = t.getCause();
/*      */     }
/*      */ 
/* 1447 */     if ((t instanceof Error)) {
/* 1448 */       throw ((Error)t);
/*      */     }
/* 1450 */     boolean wrap = (ctxt == null) || (ctxt.isEnabled(DeserializationConfig.Feature.WRAP_EXCEPTIONS));
/*      */ 
/* 1452 */     if ((t instanceof IOException)) {
/* 1453 */       if ((!wrap) || (!(t instanceof JsonMappingException)))
/* 1454 */         throw ((IOException)t);
/*      */     }
/* 1456 */     else if ((!wrap) && 
/* 1457 */       ((t instanceof RuntimeException))) {
/* 1458 */       throw ((RuntimeException)t);
/*      */     }
/*      */ 
/* 1462 */     throw JsonMappingException.wrapWithPath(t, bean, fieldName);
/*      */   }
/*      */ 
/*      */   public void wrapAndThrow(Throwable t, Object bean, int index, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1468 */     while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 1469 */       t = t.getCause();
/*      */     }
/*      */ 
/* 1472 */     if ((t instanceof Error)) {
/* 1473 */       throw ((Error)t);
/*      */     }
/* 1475 */     boolean wrap = (ctxt == null) || (ctxt.isEnabled(DeserializationConfig.Feature.WRAP_EXCEPTIONS));
/*      */ 
/* 1477 */     if ((t instanceof IOException)) {
/* 1478 */       if ((!wrap) || (!(t instanceof JsonMappingException)))
/* 1479 */         throw ((IOException)t);
/*      */     }
/* 1481 */     else if ((!wrap) && 
/* 1482 */       ((t instanceof RuntimeException))) {
/* 1483 */       throw ((RuntimeException)t);
/*      */     }
/*      */ 
/* 1487 */     throw JsonMappingException.wrapWithPath(t, bean, index);
/*      */   }
/*      */ 
/*      */   protected void wrapInstantiationProblem(Throwable t, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1493 */     while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 1494 */       t = t.getCause();
/*      */     }
/*      */ 
/* 1497 */     if ((t instanceof Error)) {
/* 1498 */       throw ((Error)t);
/*      */     }
/* 1500 */     boolean wrap = (ctxt == null) || (ctxt.isEnabled(DeserializationConfig.Feature.WRAP_EXCEPTIONS));
/* 1501 */     if ((t instanceof IOException))
/*      */     {
/* 1503 */       throw ((IOException)t);
/* 1504 */     }if ((!wrap) && 
/* 1505 */       ((t instanceof RuntimeException))) {
/* 1506 */       throw ((RuntimeException)t);
/*      */     }
/*      */ 
/* 1509 */     throw ctxt.instantiationException(this._beanType.getRawClass(), t);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void wrapAndThrow(Throwable t, Object bean, String fieldName)
/*      */     throws IOException
/*      */   {
/* 1519 */     wrapAndThrow(t, bean, fieldName, null);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void wrapAndThrow(Throwable t, Object bean, int index)
/*      */     throws IOException
/*      */   {
/* 1529 */     wrapAndThrow(t, bean, index, null);
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.BeanDeserializer
 * JD-Core Version:    0.6.2
 */