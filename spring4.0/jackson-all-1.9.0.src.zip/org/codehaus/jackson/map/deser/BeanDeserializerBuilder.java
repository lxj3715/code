/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.deser.impl.BeanPropertyMap;
/*     */ import org.codehaus.jackson.map.deser.impl.ValueInjector;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*     */ import org.codehaus.jackson.map.util.Annotations;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class BeanDeserializerBuilder
/*     */ {
/*     */   protected final BasicBeanDescription _beanDesc;
/*  39 */   protected final HashMap<String, SettableBeanProperty> _properties = new HashMap();
/*     */   protected List<ValueInjector> _injectables;
/*     */   protected HashMap<String, SettableBeanProperty> _backRefProperties;
/*     */   protected HashSet<String> _ignorableProps;
/*     */   protected ValueInstantiator _valueInstantiator;
/*     */   protected SettableAnyProperty _anySetter;
/*     */   protected boolean _ignoreAllUnknown;
/*     */ 
/*     */   public BeanDeserializerBuilder(BasicBeanDescription beanDesc)
/*     */   {
/*  87 */     this._beanDesc = beanDesc;
/*     */   }
/*     */ 
/*     */   protected BeanDeserializerBuilder(BeanDeserializerBuilder src)
/*     */   {
/*  98 */     this._beanDesc = src._beanDesc;
/*  99 */     this._anySetter = src._anySetter;
/* 100 */     this._ignoreAllUnknown = src._ignoreAllUnknown;
/*     */ 
/* 103 */     this._properties.putAll(src._properties);
/*     */ 
/* 106 */     this._backRefProperties = src._backRefProperties;
/* 107 */     this._ignorableProps = src._ignorableProps;
/* 108 */     this._valueInstantiator = src._valueInstantiator;
/*     */   }
/*     */ 
/*     */   public void addOrReplaceProperty(SettableBeanProperty prop, boolean allowOverride)
/*     */   {
/* 116 */     this._properties.put(prop.getName(), prop);
/*     */   }
/*     */ 
/*     */   public void addProperty(SettableBeanProperty prop)
/*     */   {
/* 126 */     SettableBeanProperty old = (SettableBeanProperty)this._properties.put(prop.getName(), prop);
/* 127 */     if ((old != null) && (old != prop))
/* 128 */       throw new IllegalArgumentException("Duplicate property '" + prop.getName() + "' for " + this._beanDesc.getType());
/*     */   }
/*     */ 
/*     */   public void addBackReferenceProperty(String referenceName, SettableBeanProperty prop)
/*     */   {
/* 134 */     if (this._backRefProperties == null) {
/* 135 */       this._backRefProperties = new HashMap(4);
/*     */     }
/* 137 */     this._backRefProperties.put(referenceName, prop);
/*     */   }
/*     */ 
/*     */   public void addIgnorable(String propName)
/*     */   {
/* 146 */     if (this._ignorableProps == null) {
/* 147 */       this._ignorableProps = new HashSet();
/*     */     }
/* 149 */     this._ignorableProps.add(propName);
/*     */   }
/*     */ 
/*     */   public Iterator<SettableBeanProperty> getProperties()
/*     */   {
/* 159 */     return this._properties.values().iterator();
/*     */   }
/*     */ 
/*     */   public boolean hasProperty(String propertyName) {
/* 163 */     return this._properties.containsKey(propertyName);
/*     */   }
/*     */ 
/*     */   public SettableBeanProperty removeProperty(String name)
/*     */   {
/* 168 */     return (SettableBeanProperty)this._properties.remove(name);
/*     */   }
/*     */ 
/*     */   public void setAnySetter(SettableAnyProperty s)
/*     */   {
/* 173 */     if ((this._anySetter != null) && (s != null)) {
/* 174 */       throw new IllegalStateException("_anySetter already set to non-null");
/*     */     }
/* 176 */     this._anySetter = s;
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnknownProperties(boolean ignore) {
/* 180 */     this._ignoreAllUnknown = ignore;
/*     */   }
/*     */ 
/*     */   public void setValueInstantiator(ValueInstantiator inst)
/*     */   {
/* 187 */     this._valueInstantiator = inst;
/*     */   }
/*     */ 
/*     */   public ValueInstantiator getValueInstantiator()
/*     */   {
/* 194 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */   public void addInjectable(String propertyName, JavaType propertyType, Annotations contextAnnotations, AnnotatedMember member, Object valueId)
/*     */   {
/* 204 */     if (this._injectables == null) {
/* 205 */       this._injectables = new ArrayList();
/*     */     }
/* 207 */     this._injectables.add(new ValueInjector(propertyName, propertyType, contextAnnotations, member, valueId));
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> build(BeanProperty forProperty)
/*     */   {
/* 219 */     BeanPropertyMap propertyMap = new BeanPropertyMap(this._properties.values());
/* 220 */     propertyMap.assignIndexes();
/* 221 */     return new BeanDeserializer(this._beanDesc, forProperty, this._valueInstantiator, propertyMap, this._backRefProperties, this._ignorableProps, this._ignoreAllUnknown, this._anySetter, this._injectables);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.BeanDeserializerBuilder
 * JD-Core Version:    0.6.2
 */