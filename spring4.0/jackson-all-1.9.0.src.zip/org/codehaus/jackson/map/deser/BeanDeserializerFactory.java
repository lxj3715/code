/*      */ package org.codehaus.jackson.map.deser;
/*      */ 
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.codehaus.jackson.JsonNode;
/*      */ import org.codehaus.jackson.map.AbstractTypeResolver;
/*      */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*      */ import org.codehaus.jackson.map.AnnotationIntrospector.ReferenceProperty;
/*      */ import org.codehaus.jackson.map.BeanProperty;
/*      */ import org.codehaus.jackson.map.BeanProperty.Std;
/*      */ import org.codehaus.jackson.map.BeanPropertyDefinition;
/*      */ import org.codehaus.jackson.map.DeserializationConfig;
/*      */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*      */ import org.codehaus.jackson.map.DeserializerFactory;
/*      */ import org.codehaus.jackson.map.DeserializerFactory.Config;
/*      */ import org.codehaus.jackson.map.DeserializerProvider;
/*      */ import org.codehaus.jackson.map.Deserializers;
/*      */ import org.codehaus.jackson.map.JsonDeserializer;
/*      */ import org.codehaus.jackson.map.JsonMappingException;
/*      */ import org.codehaus.jackson.map.KeyDeserializer;
/*      */ import org.codehaus.jackson.map.KeyDeserializers;
/*      */ import org.codehaus.jackson.map.TypeDeserializer;
/*      */ import org.codehaus.jackson.map.deser.impl.CreatorCollector;
/*      */ import org.codehaus.jackson.map.deser.impl.CreatorProperty;
/*      */ import org.codehaus.jackson.map.deser.std.ThrowableDeserializer;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedConstructor;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedParameter;
/*      */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*      */ import org.codehaus.jackson.map.introspect.VisibilityChecker;
/*      */ import org.codehaus.jackson.map.type.ArrayType;
/*      */ import org.codehaus.jackson.map.type.CollectionLikeType;
/*      */ import org.codehaus.jackson.map.type.CollectionType;
/*      */ import org.codehaus.jackson.map.type.MapLikeType;
/*      */ import org.codehaus.jackson.map.type.MapType;
/*      */ import org.codehaus.jackson.map.type.TypeBindings;
/*      */ import org.codehaus.jackson.map.type.TypeFactory;
/*      */ import org.codehaus.jackson.map.util.ArrayBuilders;
/*      */ import org.codehaus.jackson.map.util.ClassUtil;
/*      */ import org.codehaus.jackson.type.JavaType;
/*      */ 
/*      */ public class BeanDeserializerFactory extends BasicDeserializerFactory
/*      */ {
/*   30 */   private static final Class<?>[] INIT_CAUSE_PARAMS = { Throwable.class };
/*      */ 
/*  225 */   public static final BeanDeserializerFactory instance = new BeanDeserializerFactory(null);
/*      */   protected final DeserializerFactory.Config _factoryConfig;
/*      */ 
/*      */   @Deprecated
/*      */   public BeanDeserializerFactory()
/*      */   {
/*  237 */     this(null);
/*      */   }
/*      */ 
/*      */   public BeanDeserializerFactory(DeserializerFactory.Config config)
/*      */   {
/*  244 */     if (config == null) {
/*  245 */       config = new ConfigImpl();
/*      */     }
/*  247 */     this._factoryConfig = config;
/*      */   }
/*      */ 
/*      */   public final DeserializerFactory.Config getConfig()
/*      */   {
/*  252 */     return this._factoryConfig;
/*      */   }
/*      */ 
/*      */   public DeserializerFactory withConfig(DeserializerFactory.Config config)
/*      */   {
/*  265 */     if (this._factoryConfig == config) {
/*  266 */       return this;
/*      */     }
/*      */ 
/*  275 */     if (getClass() != BeanDeserializerFactory.class) {
/*  276 */       throw new IllegalStateException("Subtype of BeanDeserializerFactory (" + getClass().getName() + ") has not properly overridden method 'withAdditionalDeserializers': can not instantiate subtype with " + "additional deserializer definitions");
/*      */     }
/*      */ 
/*  280 */     return new BeanDeserializerFactory(config);
/*      */   }
/*      */ 
/*      */   public KeyDeserializer createKeyDeserializer(DeserializationConfig config, JavaType type, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*      */     BasicBeanDescription beanDesc;
/*  295 */     if (this._factoryConfig.hasKeyDeserializers()) {
/*  296 */       beanDesc = (BasicBeanDescription)config.introspectClassAnnotations(type.getRawClass());
/*  297 */       for (KeyDeserializers d : this._factoryConfig.keyDeserializers()) {
/*  298 */         KeyDeserializer deser = d.findKeyDeserializer(type, config, beanDesc, property);
/*  299 */         if (deser != null) {
/*  300 */           return deser;
/*      */         }
/*      */       }
/*      */     }
/*  304 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomArrayDeserializer(ArrayType type, DeserializationConfig config, DeserializerProvider provider, BeanProperty property, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/*  314 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/*  315 */       JsonDeserializer deser = d.findArrayDeserializer(type, config, provider, property, elementTypeDeserializer, elementDeserializer);
/*      */ 
/*  317 */       if (deser != null) {
/*  318 */         return deser;
/*      */       }
/*      */     }
/*  321 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomCollectionDeserializer(CollectionType type, DeserializationConfig config, DeserializerProvider provider, BasicBeanDescription beanDesc, BeanProperty property, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/*  331 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/*  332 */       JsonDeserializer deser = d.findCollectionDeserializer(type, config, provider, beanDesc, property, elementTypeDeserializer, elementDeserializer);
/*      */ 
/*  334 */       if (deser != null) {
/*  335 */         return deser;
/*      */       }
/*      */     }
/*  338 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomCollectionLikeDeserializer(CollectionLikeType type, DeserializationConfig config, DeserializerProvider provider, BasicBeanDescription beanDesc, BeanProperty property, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/*  348 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/*  349 */       JsonDeserializer deser = d.findCollectionLikeDeserializer(type, config, provider, beanDesc, property, elementTypeDeserializer, elementDeserializer);
/*      */ 
/*  351 */       if (deser != null) {
/*  352 */         return deser;
/*      */       }
/*      */     }
/*  355 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomEnumDeserializer(Class<?> type, DeserializationConfig config, BasicBeanDescription beanDesc, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  363 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/*  364 */       JsonDeserializer deser = d.findEnumDeserializer(type, config, beanDesc, property);
/*  365 */       if (deser != null) {
/*  366 */         return deser;
/*      */       }
/*      */     }
/*  369 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomMapDeserializer(MapType type, DeserializationConfig config, DeserializerProvider provider, BasicBeanDescription beanDesc, BeanProperty property, KeyDeserializer keyDeserializer, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/*  380 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/*  381 */       JsonDeserializer deser = d.findMapDeserializer(type, config, provider, beanDesc, property, keyDeserializer, elementTypeDeserializer, elementDeserializer);
/*      */ 
/*  383 */       if (deser != null) {
/*  384 */         return deser;
/*      */       }
/*      */     }
/*  387 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomMapLikeDeserializer(MapLikeType type, DeserializationConfig config, DeserializerProvider provider, BasicBeanDescription beanDesc, BeanProperty property, KeyDeserializer keyDeserializer, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/*  398 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/*  399 */       JsonDeserializer deser = d.findMapLikeDeserializer(type, config, provider, beanDesc, property, keyDeserializer, elementTypeDeserializer, elementDeserializer);
/*      */ 
/*  401 */       if (deser != null) {
/*  402 */         return deser;
/*      */       }
/*      */     }
/*  405 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomTreeNodeDeserializer(Class<? extends JsonNode> type, DeserializationConfig config, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  413 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/*  414 */       JsonDeserializer deser = d.findTreeNodeDeserializer(type, config, property);
/*  415 */       if (deser != null) {
/*  416 */         return deser;
/*      */       }
/*      */     }
/*  419 */     return null;
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<Object> _findCustomBeanDeserializer(JavaType type, DeserializationConfig config, DeserializerProvider provider, BasicBeanDescription beanDesc, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  428 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/*  429 */       JsonDeserializer deser = d.findBeanDeserializer(type, config, provider, beanDesc, property);
/*  430 */       if (deser != null) {
/*  431 */         return deser;
/*      */       }
/*      */     }
/*  434 */     return null;
/*      */   }
/*      */ 
/*      */   public JavaType mapAbstractType(DeserializationConfig config, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*      */     while (true)
/*      */     {
/*  452 */       JavaType next = _mapAbstractType2(config, type);
/*  453 */       if (next == null) {
/*  454 */         return type;
/*      */       }
/*      */ 
/*  460 */       Class prevCls = type.getRawClass();
/*  461 */       Class nextCls = next.getRawClass();
/*  462 */       if ((prevCls == nextCls) || (!prevCls.isAssignableFrom(nextCls))) {
/*  463 */         throw new IllegalArgumentException("Invalid abstract type resolution from " + type + " to " + next + ": latter is not a subtype of former");
/*      */       }
/*  465 */       type = next;
/*      */     }
/*      */   }
/*      */ 
/*      */   public ValueInstantiator findValueInstantiator(DeserializationConfig config, BasicBeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  481 */     AnnotatedClass ac = beanDesc.getClassInfo();
/*  482 */     Object instDef = config.getAnnotationIntrospector().findValueInstantiator(ac);
/*      */     ValueInstantiator instantiator;
/*      */     ValueInstantiator instantiator;
/*  483 */     if (instDef != null)
/*      */     {
/*      */       ValueInstantiator instantiator;
/*  484 */       if ((instDef instanceof ValueInstantiator)) {
/*  485 */         instantiator = (ValueInstantiator)instDef;
/*      */       } else {
/*  487 */         if (!(instDef instanceof Class)) {
/*  488 */           throw new IllegalStateException("Invalid value instantiator returned for type " + beanDesc + ": neither a Class nor ValueInstantiator");
/*      */         }
/*  490 */         Class cls = (Class)instDef;
/*  491 */         if (!ValueInstantiator.class.isAssignableFrom(cls)) {
/*  492 */           throw new IllegalStateException("Invalid instantiator Class<?> returned for type " + beanDesc + ": " + cls.getName() + " not a ValueInstantiator");
/*      */         }
/*      */ 
/*  496 */         Class instClass = cls;
/*  497 */         instantiator = config.valueInstantiatorInstance(ac, instClass);
/*      */       }
/*      */     } else {
/*  500 */       instantiator = constructDefaultValueInstantiator(config, beanDesc);
/*      */     }
/*      */ 
/*  504 */     if (this._factoryConfig.hasValueInstantiators()) {
/*  505 */       for (ValueInstantiators insts : this._factoryConfig.valueInstantiators()) {
/*  506 */         instantiator = insts.findValueInstantiator(config, beanDesc, instantiator);
/*      */ 
/*  508 */         if (instantiator == null) {
/*  509 */           throw new JsonMappingException("Broken registered ValueInstantiators (of type " + insts.getClass().getName() + "): returned null ValueInstantiator");
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  515 */     return instantiator;
/*      */   }
/*      */ 
/*      */   public JsonDeserializer<Object> createBeanDeserializer(DeserializationConfig config, DeserializerProvider p, JavaType type, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  529 */     if (type.isAbstract()) {
/*  530 */       type = mapAbstractType(config, type);
/*      */     }
/*      */ 
/*  534 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspect(type);
/*  535 */     JsonDeserializer ad = findDeserializerFromAnnotation(config, beanDesc.getClassInfo(), property);
/*  536 */     if (ad != null) {
/*  537 */       return ad;
/*      */     }
/*      */ 
/*  540 */     JavaType newType = modifyTypeByAnnotation(config, beanDesc.getClassInfo(), type, null);
/*  541 */     if (newType.getRawClass() != type.getRawClass()) {
/*  542 */       type = newType;
/*  543 */       beanDesc = (BasicBeanDescription)config.introspect(type);
/*      */     }
/*      */ 
/*  546 */     JsonDeserializer custom = _findCustomBeanDeserializer(type, config, p, beanDesc, property);
/*  547 */     if (custom != null) {
/*  548 */       return custom;
/*      */     }
/*      */ 
/*  554 */     if (type.isThrowable()) {
/*  555 */       return buildThrowableDeserializer(config, type, beanDesc, property);
/*      */     }
/*      */ 
/*  560 */     if (type.isAbstract())
/*      */     {
/*  562 */       JavaType concreteType = materializeAbstractType(config, beanDesc);
/*  563 */       if (concreteType != null)
/*      */       {
/*  567 */         beanDesc = (BasicBeanDescription)config.introspect(concreteType);
/*  568 */         return buildBeanDeserializer(config, concreteType, beanDesc, property);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  573 */     JsonDeserializer deser = findStdBeanDeserializer(config, p, type, property);
/*  574 */     if (deser != null) {
/*  575 */       return deser;
/*      */     }
/*      */ 
/*  579 */     if (!isPotentialBeanType(type.getRawClass())) {
/*  580 */       return null;
/*      */     }
/*      */ 
/*  583 */     return buildBeanDeserializer(config, type, beanDesc, property);
/*      */   }
/*      */ 
/*      */   protected JavaType _mapAbstractType2(DeserializationConfig config, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*  593 */     Class currClass = type.getRawClass();
/*  594 */     if (this._factoryConfig.hasAbstractTypeResolvers()) {
/*  595 */       for (AbstractTypeResolver resolver : this._factoryConfig.abstractTypeResolvers()) {
/*  596 */         JavaType concrete = resolver.findTypeMapping(config, type);
/*  597 */         if ((concrete != null) && (concrete.getRawClass() != currClass)) {
/*  598 */           return concrete;
/*      */         }
/*      */       }
/*      */     }
/*  602 */     return null;
/*      */   }
/*      */ 
/*      */   protected JavaType materializeAbstractType(DeserializationConfig config, BasicBeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  609 */     JavaType abstractType = beanDesc.getType();
/*      */ 
/*  614 */     for (AbstractTypeResolver r : this._factoryConfig.abstractTypeResolvers()) {
/*  615 */       JavaType concrete = r.resolveAbstractType(config, abstractType);
/*  616 */       if (concrete != null) {
/*  617 */         return concrete;
/*      */       }
/*      */     }
/*  620 */     return null;
/*      */   }
/*      */ 
/*      */   public JsonDeserializer<Object> buildBeanDeserializer(DeserializationConfig config, JavaType type, BasicBeanDescription beanDesc, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  643 */     ValueInstantiator valueInstantiator = findValueInstantiator(config, beanDesc);
/*      */ 
/*  645 */     if ((type.isAbstract()) && 
/*  646 */       (!valueInstantiator.canInstantiate()))
/*      */     {
/*  648 */       return new AbstractDeserializer(type);
/*      */     }
/*      */ 
/*  651 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(beanDesc);
/*  652 */     builder.setValueInstantiator(valueInstantiator);
/*      */ 
/*  654 */     addBeanProps(config, beanDesc, builder);
/*      */ 
/*  656 */     addReferenceProperties(config, beanDesc, builder);
/*  657 */     addInjectables(config, beanDesc, builder);
/*      */ 
/*  660 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  661 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  662 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*      */       }
/*      */     }
/*  665 */     JsonDeserializer deserializer = builder.build(property);
/*      */ 
/*  668 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  669 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  670 */         deserializer = mod.modifyDeserializer(config, beanDesc, deserializer);
/*      */       }
/*      */     }
/*  673 */     return deserializer;
/*      */   }
/*      */ 
/*      */   public JsonDeserializer<Object> buildThrowableDeserializer(DeserializationConfig config, JavaType type, BasicBeanDescription beanDesc, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  683 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(beanDesc);
/*  684 */     builder.setValueInstantiator(findValueInstantiator(config, beanDesc));
/*      */ 
/*  686 */     addBeanProps(config, beanDesc, builder);
/*      */ 
/*  693 */     AnnotatedMethod am = beanDesc.findMethod("initCause", INIT_CAUSE_PARAMS);
/*  694 */     if (am != null) {
/*  695 */       SettableBeanProperty prop = constructSettableProperty(config, beanDesc, "cause", am);
/*  696 */       if (prop != null)
/*      */       {
/*  701 */         builder.addOrReplaceProperty(prop, true);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  706 */     builder.addIgnorable("localizedMessage");
/*      */ 
/*  710 */     builder.addIgnorable("message");
/*      */ 
/*  713 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  714 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  715 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*      */       }
/*      */     }
/*  718 */     JsonDeserializer deserializer = builder.build(property);
/*      */ 
/*  723 */     if ((deserializer instanceof BeanDeserializer)) {
/*  724 */       deserializer = new ThrowableDeserializer((BeanDeserializer)deserializer);
/*      */     }
/*      */ 
/*  728 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  729 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  730 */         deserializer = mod.modifyDeserializer(config, beanDesc, deserializer);
/*      */       }
/*      */     }
/*  733 */     return deserializer;
/*      */   }
/*      */ 
/*      */   protected BeanDeserializerBuilder constructBeanDeserializerBuilder(BasicBeanDescription beanDesc)
/*      */   {
/*  751 */     return new BeanDeserializerBuilder(beanDesc);
/*      */   }
/*      */ 
/*      */   protected ValueInstantiator constructDefaultValueInstantiator(DeserializationConfig config, BasicBeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  764 */     boolean fixAccess = config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS);
/*  765 */     CreatorCollector creators = new CreatorCollector(beanDesc, fixAccess);
/*  766 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*      */ 
/*  770 */     if (beanDesc.getType().isConcrete()) {
/*  771 */       AnnotatedConstructor defaultCtor = beanDesc.findDefaultConstructor();
/*  772 */       if (defaultCtor != null) {
/*  773 */         if (fixAccess) {
/*  774 */           ClassUtil.checkAndFixAccess(defaultCtor.getAnnotated());
/*      */         }
/*  776 */         creators.setDefaultConstructor(defaultCtor);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  781 */     VisibilityChecker vchecker = config.getDefaultVisibilityChecker();
/*  782 */     vchecker = config.getAnnotationIntrospector().findAutoDetectVisibility(beanDesc.getClassInfo(), vchecker);
/*      */ 
/*  787 */     _addDeserializerFactoryMethods(config, beanDesc, vchecker, intr, creators);
/*  788 */     _addDeserializerConstructors(config, beanDesc, vchecker, intr, creators);
/*      */ 
/*  790 */     return creators.constructValueInstantiator(config);
/*      */   }
/*      */ 
/*      */   protected void _addDeserializerConstructors(DeserializationConfig config, BasicBeanDescription beanDesc, VisibilityChecker<?> vchecker, AnnotationIntrospector intr, CreatorCollector creators)
/*      */     throws JsonMappingException
/*      */   {
/*  798 */     for (AnnotatedConstructor ctor : beanDesc.getConstructors()) {
/*  799 */       int argCount = ctor.getParameterCount();
/*  800 */       if (argCount >= 1)
/*      */       {
/*  803 */         boolean isCreator = intr.hasCreatorAnnotation(ctor);
/*  804 */         boolean isVisible = vchecker.isCreatorVisible(ctor);
/*      */ 
/*  806 */         if (argCount == 1)
/*      */         {
/*  808 */           AnnotatedParameter param = ctor.getParameter(0);
/*  809 */           String name = intr.findPropertyNameForParam(param);
/*  810 */           Object injectId = intr.findInjectableValueId(param);
/*      */ 
/*  812 */           if ((injectId != null) || ((name != null) && (name.length() > 0)))
/*      */           {
/*  814 */             CreatorProperty[] properties = new CreatorProperty[1];
/*  815 */             properties[0] = constructCreatorProperty(config, beanDesc, name, 0, param, injectId);
/*  816 */             creators.addPropertyCreator(ctor, properties);
/*      */           }
/*      */           else
/*      */           {
/*  821 */             Class type = ctor.getParameterClass(0);
/*  822 */             if (type == String.class) {
/*  823 */               if ((isCreator) || (isVisible)) {
/*  824 */                 creators.addStringCreator(ctor);
/*      */               }
/*      */ 
/*      */             }
/*  828 */             else if ((type == Integer.TYPE) || (type == Integer.class)) {
/*  829 */               if ((isCreator) || (isVisible)) {
/*  830 */                 creators.addIntCreator(ctor);
/*      */               }
/*      */ 
/*      */             }
/*  834 */             else if ((type == Long.TYPE) || (type == Long.class)) {
/*  835 */               if ((isCreator) || (isVisible)) {
/*  836 */                 creators.addLongCreator(ctor);
/*      */               }
/*      */ 
/*      */             }
/*  840 */             else if ((type == Double.TYPE) || (type == Double.class)) {
/*  841 */               if ((isCreator) || (isVisible)) {
/*  842 */                 creators.addDoubleCreator(ctor);
/*      */               }
/*      */ 
/*      */             }
/*  848 */             else if (isCreator) {
/*  849 */               creators.addDelegatingCreator(ctor);
/*      */             }
/*      */           }
/*      */         }
/*  853 */         else if ((isCreator) || (isVisible))
/*      */         {
/*  860 */           boolean annotationFound = false;
/*  861 */           boolean notAnnotatedParamFound = false;
/*  862 */           CreatorProperty[] properties = new CreatorProperty[argCount];
/*  863 */           for (int i = 0; i < argCount; i++) {
/*  864 */             AnnotatedParameter param = ctor.getParameter(i);
/*  865 */             String name = param == null ? null : intr.findPropertyNameForParam(param);
/*  866 */             Object injectId = intr.findInjectableValueId(param);
/*      */ 
/*  870 */             boolean hasName = (name != null) && (name.length() > 0);
/*  871 */             boolean hasInject = injectId != null;
/*      */ 
/*  873 */             notAnnotatedParamFound |= ((!hasName) && (!hasInject));
/*      */ 
/*  875 */             annotationFound |= !notAnnotatedParamFound;
/*  876 */             if ((notAnnotatedParamFound) && ((annotationFound) || (isCreator))) {
/*  877 */               throw new IllegalArgumentException("Argument #" + i + " of constructor " + ctor + " has no property name annotation; must have name when multiple-paramater constructor annotated as Creator");
/*      */             }
/*  879 */             if (!notAnnotatedParamFound) {
/*  880 */               properties[i] = constructCreatorProperty(config, beanDesc, name, i, param, injectId);
/*      */             }
/*      */           }
/*  883 */           if (annotationFound)
/*  884 */             creators.addPropertyCreator(ctor, properties);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _addDeserializerFactoryMethods(DeserializationConfig config, BasicBeanDescription beanDesc, VisibilityChecker<?> vchecker, AnnotationIntrospector intr, CreatorCollector creators)
/*      */     throws JsonMappingException
/*      */   {
/*  895 */     for (AnnotatedMethod factory : beanDesc.getFactoryMethods()) {
/*  896 */       int argCount = factory.getParameterCount();
/*  897 */       if (argCount >= 1)
/*      */       {
/*  900 */         boolean isCreator = intr.hasCreatorAnnotation(factory);
/*      */ 
/*  902 */         if (argCount == 1)
/*      */         {
/*  906 */           AnnotatedParameter param = factory.getParameter(0);
/*  907 */           String name = intr.findPropertyNameForParam(param);
/*  908 */           Object injectId = intr.findInjectableValueId(param);
/*      */ 
/*  910 */           if ((injectId == null) && ((name == null) || (name.length() == 0))) {
/*  911 */             Class type = factory.getParameterClass(0);
/*      */ 
/*  913 */             if (type == String.class) {
/*  914 */               if ((isCreator) || (vchecker.isCreatorVisible(factory))) {
/*  915 */                 creators.addStringCreator(factory);
/*      */               }
/*      */ 
/*      */             }
/*  919 */             else if ((type == Integer.TYPE) || (type == Integer.class)) {
/*  920 */               if ((isCreator) || (vchecker.isCreatorVisible(factory))) {
/*  921 */                 creators.addIntCreator(factory);
/*      */               }
/*      */ 
/*      */             }
/*  925 */             else if ((type == Long.TYPE) || (type == Long.class)) {
/*  926 */               if ((isCreator) || (vchecker.isCreatorVisible(factory))) {
/*  927 */                 creators.addLongCreator(factory);
/*      */               }
/*      */ 
/*      */             }
/*  931 */             else if ((type == Double.TYPE) || (type == Double.class)) {
/*  932 */               if ((isCreator) || (vchecker.isCreatorVisible(factory))) {
/*  933 */                 creators.addDoubleCreator(factory);
/*      */               }
/*      */ 
/*      */             }
/*  937 */             else if ((type == Boolean.TYPE) || (type == Boolean.class)) {
/*  938 */               if ((isCreator) || (vchecker.isCreatorVisible(factory))) {
/*  939 */                 creators.addBooleanCreator(factory);
/*      */               }
/*      */ 
/*      */             }
/*  943 */             else if (intr.hasCreatorAnnotation(factory)) {
/*  944 */               creators.addDelegatingCreator(factory);
/*      */             }
/*      */ 
/*      */           }
/*      */           else;
/*      */         }
/*  952 */         else if (intr.hasCreatorAnnotation(factory))
/*      */         {
/*  957 */           CreatorProperty[] properties = new CreatorProperty[argCount];
/*  958 */           for (int i = 0; i < argCount; i++) {
/*  959 */             AnnotatedParameter param = factory.getParameter(i);
/*  960 */             String name = intr.findPropertyNameForParam(param);
/*  961 */             Object injectableId = intr.findInjectableValueId(param);
/*      */ 
/*  963 */             if (((name == null) || (name.length() == 0)) && (injectableId == null)) {
/*  964 */               throw new IllegalArgumentException("Argument #" + i + " of factory method " + factory + " has no property name annotation; must have when multiple-paramater static method annotated as Creator");
/*      */             }
/*  966 */             properties[i] = constructCreatorProperty(config, beanDesc, name, i, param, injectableId);
/*      */           }
/*  968 */           creators.addPropertyCreator(factory, properties);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected CreatorProperty constructCreatorProperty(DeserializationConfig config, BasicBeanDescription beanDesc, String name, int index, AnnotatedParameter param, Object injectableValueId)
/*      */     throws JsonMappingException
/*      */   {
/*  983 */     JavaType t0 = config.getTypeFactory().constructType(param.getParameterType(), beanDesc.bindingsForBeanType());
/*  984 */     BeanProperty.Std property = new BeanProperty.Std(name, t0, beanDesc.getClassAnnotations(), param);
/*  985 */     JavaType type = resolveType(config, beanDesc, t0, param, property);
/*  986 */     if (type != t0) {
/*  987 */       property = property.withType(type);
/*      */     }
/*      */ 
/*  990 */     JsonDeserializer deser = findDeserializerFromAnnotation(config, param, property);
/*      */ 
/*  992 */     type = modifyTypeByAnnotation(config, param, type, name);
/*      */ 
/*  995 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */ 
/*  997 */     if (typeDeser == null) {
/*  998 */       typeDeser = findTypeDeserializer(config, type, property);
/*      */     }
/* 1000 */     CreatorProperty prop = new CreatorProperty(name, type, typeDeser, beanDesc.getClassAnnotations(), param, index, injectableValueId);
/*      */ 
/* 1002 */     if (deser != null) {
/* 1003 */       prop = prop.withValueDeserializer(deser);
/*      */     }
/* 1005 */     return prop;
/*      */   }
/*      */ 
/*      */   protected void addBeanProps(DeserializationConfig config, BasicBeanDescription beanDesc, BeanDeserializerBuilder builder)
/*      */     throws JsonMappingException
/*      */   {
/* 1019 */     List props = beanDesc.findProperties();
/*      */ 
/* 1021 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 1022 */     boolean ignoreAny = false;
/*      */ 
/* 1024 */     Boolean B = intr.findIgnoreUnknownProperties(beanDesc.getClassInfo());
/* 1025 */     if (B != null) {
/* 1026 */       ignoreAny = B.booleanValue();
/* 1027 */       builder.setIgnoreUnknownProperties(ignoreAny);
/*      */     }
/*      */ 
/* 1031 */     Set ignored = ArrayBuilders.arrayToSet(intr.findPropertiesToIgnore(beanDesc.getClassInfo()));
/* 1032 */     for (String propName : ignored) {
/* 1033 */       builder.addIgnorable(propName);
/*      */     }
/*      */ 
/* 1037 */     Collection ignored2 = beanDesc.getIgnoredPropertyNames();
/* 1038 */     if (ignored2 != null) {
/* 1039 */       for (String propName : ignored2)
/*      */       {
/* 1042 */         builder.addIgnorable(propName);
/*      */       }
/*      */     }
/*      */ 
/* 1046 */     HashMap ignoredTypes = new HashMap();
/*      */ 
/* 1049 */     for (BeanPropertyDefinition property : props) {
/* 1050 */       String name = property.getName();
/* 1051 */       if (!ignored.contains(name))
/*      */       {
/* 1055 */         if (property.hasSetter()) {
/* 1056 */           AnnotatedMethod setter = property.getSetter();
/*      */ 
/* 1058 */           Class type = setter.getParameterClass(0);
/* 1059 */           if (isIgnorableType(config, beanDesc, type, ignoredTypes))
/*      */           {
/* 1061 */             builder.addIgnorable(name);
/*      */           }
/*      */           else {
/* 1064 */             SettableBeanProperty prop = constructSettableProperty(config, beanDesc, name, setter);
/* 1065 */             if (prop != null) {
/* 1066 */               builder.addProperty(prop);
/*      */             }
/*      */           }
/*      */         }
/* 1070 */         else if (property.hasField()) {
/* 1071 */           AnnotatedField field = property.getField();
/*      */ 
/* 1073 */           Class type = field.getRawType();
/* 1074 */           if (isIgnorableType(config, beanDesc, type, ignoredTypes))
/*      */           {
/* 1076 */             builder.addIgnorable(name);
/*      */           }
/*      */           else {
/* 1079 */             SettableBeanProperty prop = constructSettableProperty(config, beanDesc, name, field);
/* 1080 */             if (prop != null)
/* 1081 */               builder.addProperty(prop);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1086 */     AnnotatedMethod anySetter = beanDesc.findAnySetter();
/* 1087 */     if (anySetter != null) {
/* 1088 */       builder.setAnySetter(constructAnySetter(config, beanDesc, anySetter));
/*      */     }
/*      */ 
/* 1097 */     if (config.isEnabled(DeserializationConfig.Feature.USE_GETTERS_AS_SETTERS))
/*      */     {
/* 1103 */       for (BeanPropertyDefinition property : props)
/* 1104 */         if (property.hasGetter()) {
/* 1105 */           String name = property.getName();
/* 1106 */           if ((!builder.hasProperty(name)) && (!ignored.contains(name)))
/*      */           {
/* 1109 */             AnnotatedMethod getter = property.getGetter();
/*      */ 
/* 1111 */             Class rt = getter.getRawType();
/* 1112 */             if (((Collection.class.isAssignableFrom(rt)) || (Map.class.isAssignableFrom(rt))) && 
/* 1113 */               (!ignored.contains(name)) && (!builder.hasProperty(name)))
/* 1114 */               builder.addProperty(constructSetterlessProperty(config, beanDesc, name, getter));
/*      */           }
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void addReferenceProperties(DeserializationConfig config, BasicBeanDescription beanDesc, BeanDeserializerBuilder builder)
/*      */     throws JsonMappingException
/*      */   {
/* 1133 */     Map refs = beanDesc.findBackReferenceProperties();
/* 1134 */     if (refs != null)
/* 1135 */       for (Map.Entry en : refs.entrySet()) {
/* 1136 */         String name = (String)en.getKey();
/* 1137 */         AnnotatedMember m = (AnnotatedMember)en.getValue();
/* 1138 */         if ((m instanceof AnnotatedMethod)) {
/* 1139 */           builder.addBackReferenceProperty(name, constructSettableProperty(config, beanDesc, m.getName(), (AnnotatedMethod)m));
/*      */         }
/*      */         else
/* 1142 */           builder.addBackReferenceProperty(name, constructSettableProperty(config, beanDesc, m.getName(), (AnnotatedField)m));
/*      */       }
/*      */   }
/*      */ 
/*      */   protected void addInjectables(DeserializationConfig config, BasicBeanDescription beanDesc, BeanDeserializerBuilder builder)
/*      */     throws JsonMappingException
/*      */   {
/* 1159 */     Map raw = beanDesc.findInjectables();
/*      */     boolean fixAccess;
/* 1160 */     if (raw != null) {
/* 1161 */       fixAccess = config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS);
/* 1162 */       for (Map.Entry entry : raw.entrySet()) {
/* 1163 */         AnnotatedMember m = (AnnotatedMember)entry.getValue();
/* 1164 */         if (fixAccess) {
/* 1165 */           m.fixAccess();
/*      */         }
/* 1167 */         builder.addInjectable(m.getName(), beanDesc.resolveType(m.getGenericType()), beanDesc.getClassAnnotations(), m, entry.getKey());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected SettableAnyProperty constructAnySetter(DeserializationConfig config, BasicBeanDescription beanDesc, AnnotatedMethod setter)
/*      */     throws JsonMappingException
/*      */   {
/* 1182 */     if (config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 1183 */       setter.fixAccess();
/*      */     }
/*      */ 
/* 1186 */     JavaType type = beanDesc.bindingsForBeanType().resolveType(setter.getParameterType(1));
/* 1187 */     BeanProperty.Std property = new BeanProperty.Std(setter.getName(), type, beanDesc.getClassAnnotations(), setter);
/* 1188 */     type = resolveType(config, beanDesc, type, setter, property);
/*      */ 
/* 1195 */     JsonDeserializer deser = findDeserializerFromAnnotation(config, setter, property);
/* 1196 */     if (deser != null) {
/* 1197 */       return new SettableAnyProperty(property, setter, type, deser);
/*      */     }
/*      */ 
/* 1202 */     type = modifyTypeByAnnotation(config, setter, type, property.getName());
/* 1203 */     return new SettableAnyProperty(property, setter, type, null);
/*      */   }
/*      */ 
/*      */   protected SettableBeanProperty constructSettableProperty(DeserializationConfig config, BasicBeanDescription beanDesc, String name, AnnotatedMethod setter)
/*      */     throws JsonMappingException
/*      */   {
/* 1222 */     if (config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 1223 */       setter.fixAccess();
/*      */     }
/*      */ 
/* 1227 */     JavaType t0 = beanDesc.bindingsForBeanType().resolveType(setter.getParameterType(0));
/* 1228 */     BeanProperty.Std property = new BeanProperty.Std(name, t0, beanDesc.getClassAnnotations(), setter);
/* 1229 */     JavaType type = resolveType(config, beanDesc, t0, setter, property);
/*      */ 
/* 1231 */     if (type != t0) {
/* 1232 */       property = property.withType(type);
/*      */     }
/*      */ 
/* 1238 */     JsonDeserializer propDeser = findDeserializerFromAnnotation(config, setter, property);
/* 1239 */     type = modifyTypeByAnnotation(config, setter, type, name);
/* 1240 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/* 1241 */     SettableBeanProperty prop = new SettableBeanProperty.MethodProperty(name, type, typeDeser, beanDesc.getClassAnnotations(), setter);
/*      */ 
/* 1243 */     if (propDeser != null) {
/* 1244 */       prop = prop.withValueDeserializer(propDeser);
/*      */     }
/*      */ 
/* 1247 */     AnnotationIntrospector.ReferenceProperty ref = config.getAnnotationIntrospector().findReferenceType(setter);
/* 1248 */     if ((ref != null) && (ref.isManagedReference())) {
/* 1249 */       prop.setManagedReferenceName(ref.getName());
/*      */     }
/* 1251 */     return prop;
/*      */   }
/*      */ 
/*      */   protected SettableBeanProperty constructSettableProperty(DeserializationConfig config, BasicBeanDescription beanDesc, String name, AnnotatedField field)
/*      */     throws JsonMappingException
/*      */   {
/* 1259 */     if (config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 1260 */       field.fixAccess();
/*      */     }
/* 1262 */     JavaType t0 = beanDesc.bindingsForBeanType().resolveType(field.getGenericType());
/* 1263 */     BeanProperty.Std property = new BeanProperty.Std(name, t0, beanDesc.getClassAnnotations(), field);
/* 1264 */     JavaType type = resolveType(config, beanDesc, t0, field, property);
/*      */ 
/* 1266 */     if (type != t0) {
/* 1267 */       property = property.withType(type);
/*      */     }
/*      */ 
/* 1272 */     JsonDeserializer propDeser = findDeserializerFromAnnotation(config, field, property);
/* 1273 */     type = modifyTypeByAnnotation(config, field, type, name);
/* 1274 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/* 1275 */     SettableBeanProperty prop = new SettableBeanProperty.FieldProperty(name, type, typeDeser, beanDesc.getClassAnnotations(), field);
/*      */ 
/* 1277 */     if (propDeser != null) {
/* 1278 */       prop = prop.withValueDeserializer(propDeser);
/*      */     }
/*      */ 
/* 1281 */     AnnotationIntrospector.ReferenceProperty ref = config.getAnnotationIntrospector().findReferenceType(field);
/* 1282 */     if ((ref != null) && (ref.isManagedReference())) {
/* 1283 */       prop.setManagedReferenceName(ref.getName());
/*      */     }
/* 1285 */     return prop;
/*      */   }
/*      */ 
/*      */   protected SettableBeanProperty constructSetterlessProperty(DeserializationConfig config, BasicBeanDescription beanDesc, String name, AnnotatedMethod getter)
/*      */     throws JsonMappingException
/*      */   {
/* 1300 */     if (config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 1301 */       getter.fixAccess();
/*      */     }
/*      */ 
/* 1304 */     JavaType type = getter.getType(beanDesc.bindingsForBeanType());
/*      */ 
/* 1308 */     BeanProperty.Std property = new BeanProperty.Std(name, type, beanDesc.getClassAnnotations(), getter);
/*      */ 
/* 1310 */     JsonDeserializer propDeser = findDeserializerFromAnnotation(config, getter, property);
/* 1311 */     type = modifyTypeByAnnotation(config, getter, type, name);
/* 1312 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/* 1313 */     SettableBeanProperty prop = new SettableBeanProperty.SetterlessProperty(name, type, typeDeser, beanDesc.getClassAnnotations(), getter);
/*      */ 
/* 1315 */     if (propDeser != null) {
/* 1316 */       prop = prop.withValueDeserializer(propDeser);
/*      */     }
/* 1318 */     return prop;
/*      */   }
/*      */ 
/*      */   protected boolean isPotentialBeanType(Class<?> type)
/*      */   {
/* 1337 */     String typeStr = ClassUtil.canBeABeanType(type);
/* 1338 */     if (typeStr != null) {
/* 1339 */       throw new IllegalArgumentException("Can not deserialize Class " + type.getName() + " (of type " + typeStr + ") as a Bean");
/*      */     }
/* 1341 */     if (ClassUtil.isProxyType(type)) {
/* 1342 */       throw new IllegalArgumentException("Can not deserialize Proxy class " + type.getName() + " as a Bean");
/*      */     }
/*      */ 
/* 1347 */     typeStr = ClassUtil.isLocalType(type, true);
/* 1348 */     if (typeStr != null) {
/* 1349 */       throw new IllegalArgumentException("Can not deserialize Class " + type.getName() + " (of type " + typeStr + ") as a Bean");
/*      */     }
/* 1351 */     return true;
/*      */   }
/*      */ 
/*      */   protected boolean isIgnorableType(DeserializationConfig config, BasicBeanDescription beanDesc, Class<?> type, Map<Class<?>, Boolean> ignoredTypes)
/*      */   {
/* 1361 */     Boolean status = (Boolean)ignoredTypes.get(type);
/* 1362 */     if (status == null) {
/* 1363 */       BasicBeanDescription desc = (BasicBeanDescription)config.introspectClassAnnotations(type);
/* 1364 */       status = config.getAnnotationIntrospector().isIgnorableType(desc.getClassInfo());
/*      */ 
/* 1366 */       if (status == null) {
/* 1367 */         status = Boolean.FALSE;
/*      */       }
/*      */     }
/* 1370 */     return status.booleanValue();
/*      */   }
/*      */ 
/*      */   public static class ConfigImpl extends DeserializerFactory.Config
/*      */   {
/*   45 */     protected static final KeyDeserializers[] NO_KEY_DESERIALIZERS = new KeyDeserializers[0];
/*   46 */     protected static final BeanDeserializerModifier[] NO_MODIFIERS = new BeanDeserializerModifier[0];
/*   47 */     protected static final AbstractTypeResolver[] NO_ABSTRACT_TYPE_RESOLVERS = new AbstractTypeResolver[0];
/*   48 */     protected static final ValueInstantiators[] NO_VALUE_INSTANTIATORS = new ValueInstantiators[0];
/*      */     protected final Deserializers[] _additionalDeserializers;
/*      */     protected final KeyDeserializers[] _additionalKeyDeserializers;
/*      */     protected final BeanDeserializerModifier[] _modifiers;
/*      */     protected final AbstractTypeResolver[] _abstractTypeResolvers;
/*      */     protected final ValueInstantiators[] _valueInstantiators;
/*      */ 
/*      */     public ConfigImpl()
/*      */     {
/*   97 */       this(null, null, null, null, null);
/*      */     }
/*      */ 
/*      */     protected ConfigImpl(Deserializers[] allAdditionalDeserializers, KeyDeserializers[] allAdditionalKeyDeserializers, BeanDeserializerModifier[] modifiers, AbstractTypeResolver[] atr, ValueInstantiators[] vi)
/*      */     {
/*  110 */       this._additionalDeserializers = (allAdditionalDeserializers == null ? BeanDeserializerFactory.NO_DESERIALIZERS : allAdditionalDeserializers);
/*      */ 
/*  112 */       this._additionalKeyDeserializers = (allAdditionalKeyDeserializers == null ? NO_KEY_DESERIALIZERS : allAdditionalKeyDeserializers);
/*      */ 
/*  114 */       this._modifiers = (modifiers == null ? NO_MODIFIERS : modifiers);
/*  115 */       this._abstractTypeResolvers = (atr == null ? NO_ABSTRACT_TYPE_RESOLVERS : atr);
/*  116 */       this._valueInstantiators = (vi == null ? NO_VALUE_INSTANTIATORS : vi);
/*      */     }
/*      */ 
/*      */     public DeserializerFactory.Config withAdditionalDeserializers(Deserializers additional)
/*      */     {
/*  122 */       if (additional == null) {
/*  123 */         throw new IllegalArgumentException("Can not pass null Deserializers");
/*      */       }
/*  125 */       Deserializers[] all = (Deserializers[])ArrayBuilders.insertInListNoDup(this._additionalDeserializers, additional);
/*  126 */       return new ConfigImpl(all, this._additionalKeyDeserializers, this._modifiers, this._abstractTypeResolvers, this._valueInstantiators);
/*      */     }
/*      */ 
/*      */     public DeserializerFactory.Config withAdditionalKeyDeserializers(KeyDeserializers additional)
/*      */     {
/*  133 */       if (additional == null) {
/*  134 */         throw new IllegalArgumentException("Can not pass null KeyDeserializers");
/*      */       }
/*  136 */       KeyDeserializers[] all = (KeyDeserializers[])ArrayBuilders.insertInListNoDup(this._additionalKeyDeserializers, additional);
/*  137 */       return new ConfigImpl(this._additionalDeserializers, all, this._modifiers, this._abstractTypeResolvers, this._valueInstantiators);
/*      */     }
/*      */ 
/*      */     public DeserializerFactory.Config withDeserializerModifier(BeanDeserializerModifier modifier)
/*      */     {
/*  144 */       if (modifier == null) {
/*  145 */         throw new IllegalArgumentException("Can not pass null modifier");
/*      */       }
/*  147 */       BeanDeserializerModifier[] all = (BeanDeserializerModifier[])ArrayBuilders.insertInListNoDup(this._modifiers, modifier);
/*  148 */       return new ConfigImpl(this._additionalDeserializers, this._additionalKeyDeserializers, all, this._abstractTypeResolvers, this._valueInstantiators);
/*      */     }
/*      */ 
/*      */     public DeserializerFactory.Config withAbstractTypeResolver(AbstractTypeResolver resolver)
/*      */     {
/*  155 */       if (resolver == null) {
/*  156 */         throw new IllegalArgumentException("Can not pass null resolver");
/*      */       }
/*  158 */       AbstractTypeResolver[] all = (AbstractTypeResolver[])ArrayBuilders.insertInListNoDup(this._abstractTypeResolvers, resolver);
/*  159 */       return new ConfigImpl(this._additionalDeserializers, this._additionalKeyDeserializers, this._modifiers, all, this._valueInstantiators);
/*      */     }
/*      */ 
/*      */     public DeserializerFactory.Config withValueInstantiators(ValueInstantiators instantiators)
/*      */     {
/*  166 */       if (instantiators == null) {
/*  167 */         throw new IllegalArgumentException("Can not pass null resolver");
/*      */       }
/*  169 */       ValueInstantiators[] all = (ValueInstantiators[])ArrayBuilders.insertInListNoDup(this._valueInstantiators, instantiators);
/*  170 */       return new ConfigImpl(this._additionalDeserializers, this._additionalKeyDeserializers, this._modifiers, this._abstractTypeResolvers, all);
/*      */     }
/*      */ 
/*      */     public boolean hasDeserializers()
/*      */     {
/*  175 */       return this._additionalDeserializers.length > 0;
/*      */     }
/*      */     public boolean hasKeyDeserializers() {
/*  178 */       return this._additionalKeyDeserializers.length > 0;
/*      */     }
/*      */     public boolean hasDeserializerModifiers() {
/*  181 */       return this._modifiers.length > 0;
/*      */     }
/*      */     public boolean hasAbstractTypeResolvers() {
/*  184 */       return this._abstractTypeResolvers.length > 0;
/*      */     }
/*      */     public boolean hasValueInstantiators() {
/*  187 */       return this._valueInstantiators.length > 0;
/*      */     }
/*      */ 
/*      */     public Iterable<Deserializers> deserializers() {
/*  191 */       return ArrayBuilders.arrayAsIterable(this._additionalDeserializers);
/*      */     }
/*      */ 
/*      */     public Iterable<KeyDeserializers> keyDeserializers()
/*      */     {
/*  196 */       return ArrayBuilders.arrayAsIterable(this._additionalKeyDeserializers);
/*      */     }
/*      */ 
/*      */     public Iterable<BeanDeserializerModifier> deserializerModifiers()
/*      */     {
/*  201 */       return ArrayBuilders.arrayAsIterable(this._modifiers);
/*      */     }
/*      */ 
/*      */     public Iterable<AbstractTypeResolver> abstractTypeResolvers()
/*      */     {
/*  206 */       return ArrayBuilders.arrayAsIterable(this._abstractTypeResolvers);
/*      */     }
/*      */ 
/*      */     public Iterable<ValueInstantiators> valueInstantiators()
/*      */     {
/*  211 */       return ArrayBuilders.arrayAsIterable(this._valueInstantiators);
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.BeanDeserializerFactory
 * JD-Core Version:    0.6.2
 */