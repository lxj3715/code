/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import org.codehaus.jackson.map.DeserializationConfig;
/*    */ import org.codehaus.jackson.map.JsonDeserializer;
/*    */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*    */ 
/*    */ public abstract class BeanDeserializerModifier
/*    */ {
/*    */   public BeanDeserializerBuilder updateBuilder(DeserializationConfig config, BasicBeanDescription beanDesc, BeanDeserializerBuilder builder)
/*    */   {
/* 43 */     return builder;
/*    */   }
/*    */ 
/*    */   public JsonDeserializer<?> modifyDeserializer(DeserializationConfig config, BasicBeanDescription beanDesc, JsonDeserializer<?> deserializer)
/*    */   {
/* 56 */     return deserializer;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.BeanDeserializerModifier
 * JD-Core Version:    0.6.2
 */