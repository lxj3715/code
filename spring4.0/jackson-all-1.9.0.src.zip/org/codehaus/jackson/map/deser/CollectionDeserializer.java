/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.Collection;
/*    */ import org.codehaus.jackson.map.JsonDeserializer;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ @Deprecated
/*    */ public class CollectionDeserializer extends org.codehaus.jackson.map.deser.std.CollectionDeserializer
/*    */ {
/*    */   @Deprecated
/*    */   public CollectionDeserializer(JavaType collectionType, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, Constructor<Collection<Object>> defCtor)
/*    */   {
/* 25 */     super(collectionType, valueDeser, valueTypeDeser, defCtor);
/*    */   }
/*    */ 
/*    */   public CollectionDeserializer(JavaType collectionType, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, ValueInstantiator valueInstantiator)
/*    */   {
/* 34 */     super(collectionType, valueDeser, valueTypeDeser, valueInstantiator);
/*    */   }
/*    */ 
/*    */   protected CollectionDeserializer(CollectionDeserializer src)
/*    */   {
/* 45 */     super(src);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.CollectionDeserializer
 * JD-Core Version:    0.6.2
 */