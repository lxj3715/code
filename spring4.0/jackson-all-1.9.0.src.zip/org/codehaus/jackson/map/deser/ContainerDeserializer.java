/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import org.codehaus.jackson.map.deser.std.ContainerDeserializerBase;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class ContainerDeserializer<T> extends ContainerDeserializerBase<T>
/*    */ {
/*    */   protected ContainerDeserializer(Class<?> selfType)
/*    */   {
/* 12 */     super(selfType);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.ContainerDeserializer
 * JD-Core Version:    0.6.2
 */