/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializerFactory;
/*     */ import org.codehaus.jackson.map.DeserializerFactory.Config;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.type.ArrayType;
/*     */ import org.codehaus.jackson.map.type.ClassKey;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ @Deprecated
/*     */ public class CustomDeserializerFactory extends BeanDeserializerFactory
/*     */ {
/*  57 */   protected HashMap<ClassKey, JsonDeserializer<Object>> _directClassMappings = null;
/*     */   protected HashMap<ClassKey, Class<?>> _mixInAnnotations;
/*     */ 
/*     */   public CustomDeserializerFactory()
/*     */   {
/*  87 */     this(null);
/*     */   }
/*     */ 
/*     */   protected CustomDeserializerFactory(DeserializerFactory.Config config)
/*     */   {
/*  92 */     super(config);
/*     */   }
/*     */ 
/*     */   public DeserializerFactory withConfig(DeserializerFactory.Config config)
/*     */   {
/*  99 */     if (getClass() != CustomDeserializerFactory.class) {
/* 100 */       throw new IllegalStateException("Subtype of CustomDeserializerFactory (" + getClass().getName() + ") has not properly overridden method 'withAdditionalDeserializers': can not instantiate subtype with " + "additional deserializer definitions");
/*     */     }
/*     */ 
/* 104 */     return new CustomDeserializerFactory(config);
/*     */   }
/*     */ 
/*     */   public <T> void addSpecificMapping(Class<T> forClass, JsonDeserializer<? extends T> deser)
/*     */   {
/* 132 */     ClassKey key = new ClassKey(forClass);
/* 133 */     if (this._directClassMappings == null) {
/* 134 */       this._directClassMappings = new HashMap();
/*     */     }
/* 136 */     this._directClassMappings.put(key, deser);
/*     */   }
/*     */ 
/*     */   public void addMixInAnnotationMapping(Class<?> destinationClass, Class<?> classWithMixIns)
/*     */   {
/* 157 */     if (this._mixInAnnotations == null) {
/* 158 */       this._mixInAnnotations = new HashMap();
/*     */     }
/* 160 */     this._mixInAnnotations.put(new ClassKey(destinationClass), classWithMixIns);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> createBeanDeserializer(DeserializationConfig config, DeserializerProvider p, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 174 */     Class cls = type.getRawClass();
/* 175 */     ClassKey key = new ClassKey(cls);
/*     */ 
/* 178 */     if (this._directClassMappings != null) {
/* 179 */       JsonDeserializer deser = (JsonDeserializer)this._directClassMappings.get(key);
/* 180 */       if (deser != null) {
/* 181 */         return deser;
/*     */       }
/*     */     }
/*     */ 
/* 185 */     return super.createBeanDeserializer(config, p, type, property);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> createArrayDeserializer(DeserializationConfig config, DeserializerProvider p, ArrayType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 193 */     ClassKey key = new ClassKey(type.getRawClass());
/* 194 */     if (this._directClassMappings != null) {
/* 195 */       JsonDeserializer deser = (JsonDeserializer)this._directClassMappings.get(key);
/* 196 */       if (deser != null) {
/* 197 */         return deser;
/*     */       }
/*     */     }
/* 200 */     return super.createArrayDeserializer(config, p, type, property);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> createEnumDeserializer(DeserializationConfig config, DeserializerProvider p, JavaType enumType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 214 */     if (this._directClassMappings != null) {
/* 215 */       ClassKey key = new ClassKey(enumType.getRawClass());
/* 216 */       JsonDeserializer deser = (JsonDeserializer)this._directClassMappings.get(key);
/* 217 */       if (deser != null) {
/* 218 */         return deser;
/*     */       }
/*     */     }
/* 221 */     return super.createEnumDeserializer(config, p, enumType, property);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.CustomDeserializerFactory
 * JD-Core Version:    0.6.2
 */