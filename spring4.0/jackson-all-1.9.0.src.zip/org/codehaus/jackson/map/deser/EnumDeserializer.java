/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import org.codehaus.jackson.map.util.EnumResolver;
/*    */ 
/*    */ @Deprecated
/*    */ public class EnumDeserializer extends org.codehaus.jackson.map.deser.std.EnumDeserializer
/*    */ {
/*    */   public EnumDeserializer(EnumResolver<?> res)
/*    */   {
/* 13 */     super(res);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.EnumDeserializer
 * JD-Core Version:    0.6.2
 */