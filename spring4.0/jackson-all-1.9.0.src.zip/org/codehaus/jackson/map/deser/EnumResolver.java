/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ @Deprecated
/*    */ public final class EnumResolver<T extends Enum<T>> extends org.codehaus.jackson.map.util.EnumResolver<T>
/*    */ {
/*    */   private EnumResolver(Class<T> enumClass, T[] enums, HashMap<String, T> map)
/*    */   {
/* 13 */     super(enumClass, enums, map);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.EnumResolver
 * JD-Core Version:    0.6.2
 */