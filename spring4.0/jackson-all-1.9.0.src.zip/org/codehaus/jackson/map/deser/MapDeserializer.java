/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.Map;
/*    */ import org.codehaus.jackson.map.JsonDeserializer;
/*    */ import org.codehaus.jackson.map.KeyDeserializer;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ @Deprecated
/*    */ public class MapDeserializer extends org.codehaus.jackson.map.deser.std.MapDeserializer
/*    */ {
/*    */   @Deprecated
/*    */   public MapDeserializer(JavaType mapType, Constructor<Map<Object, Object>> defCtor, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser)
/*    */   {
/* 25 */     super(mapType, defCtor, keyDeser, valueDeser, valueTypeDeser);
/*    */   }
/*    */ 
/*    */   public MapDeserializer(JavaType mapType, ValueInstantiator valueInstantiator, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser)
/*    */   {
/* 32 */     super(mapType, valueInstantiator, keyDeser, valueDeser, valueTypeDeser);
/*    */   }
/*    */ 
/*    */   protected MapDeserializer(MapDeserializer src)
/*    */   {
/* 42 */     super(src);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.MapDeserializer
 * JD-Core Version:    0.6.2
 */