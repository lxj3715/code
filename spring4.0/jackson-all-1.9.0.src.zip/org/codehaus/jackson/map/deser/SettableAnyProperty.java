/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class SettableAnyProperty
/*     */ {
/*     */   protected final BeanProperty _property;
/*     */   protected final Method _setter;
/*     */   protected final JavaType _type;
/*     */   protected JsonDeserializer<Object> _valueDeserializer;
/*     */ 
/*     */   @Deprecated
/*     */   public SettableAnyProperty(BeanProperty property, AnnotatedMethod setter, JavaType type)
/*     */   {
/*  52 */     this(property, setter, type, null);
/*     */   }
/*     */ 
/*     */   public SettableAnyProperty(BeanProperty property, AnnotatedMethod setter, JavaType type, JsonDeserializer<Object> valueDeser)
/*     */   {
/*  57 */     this(property, setter.getAnnotated(), type, valueDeser);
/*     */   }
/*     */ 
/*     */   public SettableAnyProperty(BeanProperty property, Method rawSetter, JavaType type, JsonDeserializer<Object> valueDeser)
/*     */   {
/*  62 */     this._property = property;
/*  63 */     this._type = type;
/*  64 */     this._setter = rawSetter;
/*  65 */     this._valueDeserializer = valueDeser;
/*     */   }
/*     */ 
/*     */   public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/*  69 */     return new SettableAnyProperty(this._property, this._setter, this._type, deser);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setValueDeserializer(JsonDeserializer<Object> deser)
/*     */   {
/*  78 */     if (this._valueDeserializer != null) {
/*  79 */       throw new IllegalStateException("Already had assigned deserializer for SettableAnyProperty");
/*     */     }
/*  81 */     this._valueDeserializer = deser;
/*     */   }
/*     */ 
/*     */   public BeanProperty getProperty()
/*     */   {
/*  90 */     return this._property;
/*     */   }
/*  92 */   public boolean hasValueDeserializer() { return this._valueDeserializer != null; } 
/*     */   public JavaType getType() {
/*  94 */     return this._type;
/*     */   }
/*     */ 
/*     */   public final void deserializeAndSet(JsonParser jp, DeserializationContext ctxt, Object instance, String propName)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 110 */     set(instance, propName, deserialize(jp, ctxt));
/*     */   }
/*     */ 
/*     */   public final Object deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 116 */     JsonToken t = jp.getCurrentToken();
/* 117 */     if (t == JsonToken.VALUE_NULL) {
/* 118 */       return null;
/*     */     }
/* 120 */     return this._valueDeserializer.deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   public final void set(Object instance, String propName, Object value) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 127 */       this._setter.invoke(instance, new Object[] { propName, value });
/*     */     } catch (Exception e) {
/* 129 */       _throwAsIOE(e, propName, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _throwAsIOE(Exception e, String propName, Object value)
/*     */     throws IOException
/*     */   {
/* 147 */     if ((e instanceof IllegalArgumentException)) {
/* 148 */       String actType = value == null ? "[NULL]" : value.getClass().getName();
/* 149 */       StringBuilder msg = new StringBuilder("Problem deserializing \"any\" property '").append(propName);
/* 150 */       msg.append("' of class " + getClassName() + " (expected type: ").append(this._type);
/* 151 */       msg.append("; actual type: ").append(actType).append(")");
/* 152 */       String origMsg = e.getMessage();
/* 153 */       if (origMsg != null)
/* 154 */         msg.append(", problem: ").append(origMsg);
/*     */       else {
/* 156 */         msg.append(" (no error message provided)");
/*     */       }
/* 158 */       throw new JsonMappingException(msg.toString(), null, e);
/*     */     }
/* 160 */     if ((e instanceof IOException)) {
/* 161 */       throw ((IOException)e);
/*     */     }
/* 163 */     if ((e instanceof RuntimeException)) {
/* 164 */       throw ((RuntimeException)e);
/*     */     }
/*     */ 
/* 167 */     Throwable t = e;
/* 168 */     while (t.getCause() != null) {
/* 169 */       t = t.getCause();
/*     */     }
/* 171 */     throw new JsonMappingException(t.getMessage(), null, t);
/*     */   }
/*     */   private String getClassName() {
/* 174 */     return this._setter.getDeclaringClass().getName();
/*     */   }
/* 176 */   public String toString() { return "[any property on class " + getClassName() + "]"; }
/*     */ 
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.SettableAnyProperty
 * JD-Core Version:    0.6.2
 */