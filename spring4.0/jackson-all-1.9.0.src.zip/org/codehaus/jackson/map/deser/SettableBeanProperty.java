/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ import org.codehaus.jackson.map.util.Annotations;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.codehaus.jackson.util.InternCache;
/*     */ 
/*     */ public abstract class SettableBeanProperty
/*     */   implements BeanProperty
/*     */ {
/*     */   protected final String _propName;
/*     */   protected final JavaType _type;
/*     */   protected final Annotations _contextAnnotations;
/*     */   protected JsonDeserializer<Object> _valueDeserializer;
/*     */   protected TypeDeserializer _valueTypeDeserializer;
/*     */   protected NullProvider _nullProvider;
/*     */   protected String _managedReferenceName;
/*  81 */   protected int _propertyIndex = -1;
/*     */ 
/*     */   protected SettableBeanProperty(String propName, JavaType type, TypeDeserializer typeDeser, Annotations contextAnnotations)
/*     */   {
/*  96 */     if ((propName == null) || (propName.length() == 0))
/*  97 */       this._propName = "";
/*     */     else {
/*  99 */       this._propName = InternCache.instance.intern(propName);
/*     */     }
/* 101 */     this._type = type;
/* 102 */     this._contextAnnotations = contextAnnotations;
/* 103 */     this._valueTypeDeserializer = typeDeser;
/*     */   }
/*     */ 
/*     */   protected SettableBeanProperty(SettableBeanProperty src)
/*     */   {
/* 113 */     this._propName = src._propName;
/* 114 */     this._type = src._type;
/* 115 */     this._contextAnnotations = src._contextAnnotations;
/* 116 */     this._valueDeserializer = src._valueDeserializer;
/* 117 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 118 */     this._nullProvider = src._nullProvider;
/* 119 */     this._managedReferenceName = src._managedReferenceName;
/* 120 */     this._propertyIndex = src._propertyIndex;
/*     */   }
/*     */ 
/*     */   protected SettableBeanProperty(SettableBeanProperty src, JsonDeserializer<Object> deser)
/*     */   {
/* 130 */     this._propName = src._propName;
/* 131 */     this._type = src._type;
/* 132 */     this._contextAnnotations = src._contextAnnotations;
/* 133 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 134 */     this._managedReferenceName = src._managedReferenceName;
/* 135 */     this._propertyIndex = src._propertyIndex;
/*     */ 
/* 137 */     this._valueDeserializer = deser;
/* 138 */     if (deser == null) {
/* 139 */       this._nullProvider = null;
/*     */     } else {
/* 141 */       Object nvl = deser.getNullValue();
/* 142 */       this._nullProvider = (nvl == null ? null : new NullProvider(this._type, nvl));
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setValueDeserializer(JsonDeserializer<Object> deser)
/*     */   {
/* 149 */     if (this._valueDeserializer != null) {
/* 150 */       throw new IllegalStateException("Already had assigned deserializer for property '" + getName() + "' (class " + getDeclaringClass().getName() + ")");
/*     */     }
/* 152 */     this._valueDeserializer = deser;
/* 153 */     Object nvl = this._valueDeserializer.getNullValue();
/* 154 */     this._nullProvider = (nvl == null ? null : new NullProvider(this._type, nvl));
/*     */   }
/*     */ 
/*     */   public abstract SettableBeanProperty withValueDeserializer(JsonDeserializer<Object> paramJsonDeserializer);
/*     */ 
/*     */   public void setManagedReferenceName(String n)
/*     */   {
/* 163 */     this._managedReferenceName = n;
/*     */   }
/*     */ 
/*     */   public void assignIndex(int index)
/*     */   {
/* 172 */     if (this._propertyIndex != -1) {
/* 173 */       throw new IllegalStateException("Property '" + getName() + "' already had index (" + this._propertyIndex + "), trying to assign " + index);
/*     */     }
/* 175 */     this._propertyIndex = index;
/*     */   }
/*     */ 
/*     */   public final String getName()
/*     */   {
/* 185 */     return this._propName;
/*     */   }
/*     */   public JavaType getType() {
/* 188 */     return this._type;
/*     */   }
/*     */ 
/*     */   public abstract <A extends Annotation> A getAnnotation(Class<A> paramClass);
/*     */ 
/*     */   public abstract AnnotatedMember getMember();
/*     */ 
/*     */   public <A extends Annotation> A getContextAnnotation(Class<A> acls)
/*     */   {
/* 198 */     return this._contextAnnotations.get(acls);
/*     */   }
/*     */ 
/*     */   protected final Class<?> getDeclaringClass()
/*     */   {
/* 208 */     return getMember().getDeclaringClass();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public String getPropertyName()
/*     */   {
/* 215 */     return this._propName;
/*     */   }
/* 217 */   public String getManagedReferenceName() { return this._managedReferenceName; } 
/*     */   public boolean hasValueDeserializer() {
/* 219 */     return this._valueDeserializer != null;
/*     */   }
/*     */ 
/*     */   public boolean hasValueTypeDeserializer()
/*     */   {
/* 224 */     return this._valueTypeDeserializer != null;
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> getValueDeserializer()
/*     */   {
/* 229 */     return this._valueDeserializer;
/*     */   }
/*     */ 
/*     */   public TypeDeserializer getValueTypeDeserializer()
/*     */   {
/* 234 */     return this._valueTypeDeserializer;
/*     */   }
/*     */ 
/*     */   public int getPropertyIndex()
/*     */   {
/* 245 */     return this._propertyIndex;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public int getProperytIndex()
/*     */   {
/* 251 */     return getPropertyIndex();
/*     */   }
/*     */ 
/*     */   public Object getInjectableValueId()
/*     */   {
/* 259 */     return null;
/*     */   }
/*     */ 
/*     */   public abstract void deserializeAndSet(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext, Object paramObject)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   public abstract void set(Object paramObject1, Object paramObject2)
/*     */     throws IOException;
/*     */ 
/*     */   public final Object deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 292 */     JsonToken t = jp.getCurrentToken();
/* 293 */     if (t == JsonToken.VALUE_NULL) {
/* 294 */       return this._nullProvider == null ? null : this._nullProvider.nullValue(ctxt);
/*     */     }
/* 296 */     if (this._valueTypeDeserializer != null) {
/* 297 */       return this._valueDeserializer.deserializeWithType(jp, ctxt, this._valueTypeDeserializer);
/*     */     }
/* 299 */     return this._valueDeserializer.deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   protected void _throwAsIOE(Exception e, Object value)
/*     */     throws IOException
/*     */   {
/* 315 */     if ((e instanceof IllegalArgumentException)) {
/* 316 */       String actType = value == null ? "[NULL]" : value.getClass().getName();
/* 317 */       StringBuilder msg = new StringBuilder("Problem deserializing property '").append(getPropertyName());
/* 318 */       msg.append("' (expected type: ").append(getType());
/* 319 */       msg.append("; actual type: ").append(actType).append(")");
/* 320 */       String origMsg = e.getMessage();
/* 321 */       if (origMsg != null)
/* 322 */         msg.append(", problem: ").append(origMsg);
/*     */       else {
/* 324 */         msg.append(" (no error message provided)");
/*     */       }
/* 326 */       throw new JsonMappingException(msg.toString(), null, e);
/*     */     }
/* 328 */     _throwAsIOE(e);
/*     */   }
/*     */ 
/*     */   protected IOException _throwAsIOE(Exception e)
/*     */     throws IOException
/*     */   {
/* 334 */     if ((e instanceof IOException)) {
/* 335 */       throw ((IOException)e);
/*     */     }
/* 337 */     if ((e instanceof RuntimeException)) {
/* 338 */       throw ((RuntimeException)e);
/*     */     }
/*     */ 
/* 341 */     Throwable th = e;
/* 342 */     while (th.getCause() != null) {
/* 343 */       th = th.getCause();
/*     */     }
/* 345 */     throw new JsonMappingException(th.getMessage(), null, th);
/*     */   }
/*     */   public String toString() {
/* 348 */     return "[property '" + getName() + "']";
/*     */   }
/*     */ 
/*     */   protected static final class NullProvider
/*     */   {
/*     */     private final Object _nullValue;
/*     */     private final boolean _isPrimitive;
/*     */     private final Class<?> _rawType;
/*     */ 
/*     */     protected NullProvider(JavaType type, Object nullValue)
/*     */     {
/* 812 */       this._nullValue = nullValue;
/*     */ 
/* 814 */       this._isPrimitive = type.isPrimitive();
/* 815 */       this._rawType = type.getRawClass();
/*     */     }
/*     */ 
/*     */     public Object nullValue(DeserializationContext ctxt) throws JsonProcessingException
/*     */     {
/* 820 */       if ((this._isPrimitive) && (ctxt.isEnabled(DeserializationConfig.Feature.FAIL_ON_NULL_FOR_PRIMITIVES))) {
/* 821 */         throw ctxt.mappingException("Can not map JSON null into type " + this._rawType.getName() + " (set DeserializationConfig.Feature.FAIL_ON_NULL_FOR_PRIMITIVES to 'false' to allow)");
/*     */       }
/*     */ 
/* 824 */       return this._nullValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class InnerClassProperty extends SettableBeanProperty
/*     */   {
/*     */     protected final SettableBeanProperty _delegate;
/*     */     protected final Constructor<?> _creator;
/*     */ 
/*     */     public InnerClassProperty(SettableBeanProperty delegate, Constructor<?> ctor)
/*     */     {
/* 733 */       super();
/* 734 */       this._delegate = delegate;
/* 735 */       this._creator = ctor;
/*     */     }
/*     */ 
/*     */     protected InnerClassProperty(InnerClassProperty src, JsonDeserializer<Object> deser)
/*     */     {
/* 740 */       super(deser);
/* 741 */       this._delegate = src._delegate.withValueDeserializer(deser);
/* 742 */       this._creator = src._creator;
/*     */     }
/*     */ 
/*     */     public InnerClassProperty withValueDeserializer(JsonDeserializer<Object> deser)
/*     */     {
/* 747 */       return new InnerClassProperty(this, deser);
/*     */     }
/*     */ 
/*     */     public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */     {
/* 754 */       return this._delegate.getAnnotation(acls);
/*     */     }
/*     */     public AnnotatedMember getMember() {
/* 757 */       return this._delegate.getMember();
/*     */     }
/*     */ 
/*     */     public void deserializeAndSet(JsonParser jp, DeserializationContext ctxt, Object bean)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 767 */       JsonToken t = jp.getCurrentToken();
/*     */       Object value;
/*     */       Object value;
/* 769 */       if (t == JsonToken.VALUE_NULL) {
/* 770 */         value = this._nullProvider == null ? null : this._nullProvider.nullValue(ctxt);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object value;
/* 771 */         if (this._valueTypeDeserializer != null) {
/* 772 */           value = this._valueDeserializer.deserializeWithType(jp, ctxt, this._valueTypeDeserializer);
/*     */         } else {
/*     */           try {
/* 775 */             value = this._creator.newInstance(new Object[] { bean });
/*     */           } catch (Exception e) {
/* 777 */             ClassUtil.unwrapAndThrowAsIAE(e, "Failed to instantiate class " + this._creator.getDeclaringClass().getName() + ", problem: " + e.getMessage());
/* 778 */             value = null;
/*     */           }
/* 780 */           this._valueDeserializer.deserialize(jp, ctxt, value);
/*     */         }
/*     */       }
/* 782 */       set(bean, value);
/*     */     }
/*     */ 
/*     */     public final void set(Object instance, Object value)
/*     */       throws IOException
/*     */     {
/* 788 */       this._delegate.set(instance, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class ManagedReferenceProperty extends SettableBeanProperty
/*     */   {
/*     */     protected final String _referenceName;
/*     */     protected final boolean _isContainer;
/*     */     protected final SettableBeanProperty _managedProperty;
/*     */     protected final SettableBeanProperty _backProperty;
/*     */ 
/*     */     public ManagedReferenceProperty(String refName, SettableBeanProperty forward, SettableBeanProperty backward, Annotations contextAnnotations, boolean isContainer)
/*     */     {
/* 621 */       super(forward.getType(), forward._valueTypeDeserializer, contextAnnotations);
/*     */ 
/* 623 */       this._referenceName = refName;
/* 624 */       this._managedProperty = forward;
/* 625 */       this._backProperty = backward;
/* 626 */       this._isContainer = isContainer;
/*     */     }
/*     */ 
/*     */     protected ManagedReferenceProperty(ManagedReferenceProperty src, JsonDeserializer<Object> deser)
/*     */     {
/* 631 */       super(deser);
/* 632 */       this._referenceName = src._referenceName;
/* 633 */       this._isContainer = src._isContainer;
/* 634 */       this._managedProperty = src._managedProperty;
/* 635 */       this._backProperty = src._backProperty;
/*     */     }
/*     */ 
/*     */     public ManagedReferenceProperty withValueDeserializer(JsonDeserializer<Object> deser)
/*     */     {
/* 640 */       return new ManagedReferenceProperty(this, deser);
/*     */     }
/*     */ 
/*     */     public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */     {
/* 651 */       return this._managedProperty.getAnnotation(acls);
/*     */     }
/*     */     public AnnotatedMember getMember() {
/* 654 */       return this._managedProperty.getMember();
/*     */     }
/*     */ 
/*     */     public void deserializeAndSet(JsonParser jp, DeserializationContext ctxt, Object instance)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 667 */       set(instance, this._managedProperty.deserialize(jp, ctxt));
/*     */     }
/*     */ 
/*     */     public final void set(Object instance, Object value)
/*     */       throws IOException
/*     */     {
/* 674 */       this._managedProperty.set(instance, value);
/*     */ 
/* 678 */       if (value != null)
/* 679 */         if (this._isContainer) {
/* 680 */           if ((value instanceof Object[])) {
/* 681 */             for (Object ob : (Object[])value)
/* 682 */               if (ob != null)
/* 683 */                 this._backProperty.set(ob, instance);
/*     */           }
/*     */           else
/*     */           {
/*     */             Iterator i$;
/* 686 */             if ((value instanceof Collection)) {
/* 687 */               for (i$ = ((Collection)value).iterator(); i$.hasNext(); ) { Object ob = i$.next();
/* 688 */                 if (ob != null)
/* 689 */                   this._backProperty.set(ob, instance);
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*     */               Iterator i$;
/* 692 */               if ((value instanceof Map)) {
/* 693 */                 for (i$ = ((Map)value).values().iterator(); i$.hasNext(); ) { Object ob = i$.next();
/* 694 */                   if (ob != null)
/* 695 */                     this._backProperty.set(ob, instance);
/*     */                 }
/*     */               }
/*     */               else
/* 699 */                 throw new IllegalStateException("Unsupported container type (" + value.getClass().getName() + ") when resolving reference '" + this._referenceName + "'");
/*     */             }
/*     */           }
/*     */         }
/* 703 */         else this._backProperty.set(value, instance);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class FieldProperty extends SettableBeanProperty
/*     */   {
/*     */     protected final AnnotatedField _annotated;
/*     */     protected final Field _field;
/*     */ 
/*     */     public FieldProperty(String name, JavaType type, TypeDeserializer typeDeser, Annotations contextAnnotations, AnnotatedField field)
/*     */     {
/* 539 */       super(type, typeDeser, contextAnnotations);
/* 540 */       this._annotated = field;
/* 541 */       this._field = field.getAnnotated();
/*     */     }
/*     */ 
/*     */     protected FieldProperty(FieldProperty src, JsonDeserializer<Object> deser) {
/* 545 */       super(deser);
/* 546 */       this._annotated = src._annotated;
/* 547 */       this._field = src._field;
/*     */     }
/*     */ 
/*     */     public FieldProperty withValueDeserializer(JsonDeserializer<Object> deser)
/*     */     {
/* 552 */       return new FieldProperty(this, deser);
/*     */     }
/*     */ 
/*     */     public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */     {
/* 563 */       return this._annotated.getAnnotation(acls);
/*     */     }
/*     */     public AnnotatedMember getMember() {
/* 566 */       return this._annotated;
/*     */     }
/*     */ 
/*     */     public void deserializeAndSet(JsonParser jp, DeserializationContext ctxt, Object instance)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 579 */       set(instance, deserialize(jp, ctxt));
/*     */     }
/*     */ 
/*     */     public final void set(Object instance, Object value)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 587 */         this._field.set(instance, value);
/*     */       } catch (Exception e) {
/* 589 */         _throwAsIOE(e, value);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class SetterlessProperty extends SettableBeanProperty
/*     */   {
/*     */     protected final AnnotatedMethod _annotated;
/*     */     protected final Method _getter;
/*     */ 
/*     */     public SetterlessProperty(String name, JavaType type, TypeDeserializer typeDeser, Annotations contextAnnotations, AnnotatedMethod method)
/*     */     {
/* 447 */       super(type, typeDeser, contextAnnotations);
/* 448 */       this._annotated = method;
/* 449 */       this._getter = method.getAnnotated();
/*     */     }
/*     */ 
/*     */     protected SetterlessProperty(SetterlessProperty src, JsonDeserializer<Object> deser) {
/* 453 */       super(deser);
/* 454 */       this._annotated = src._annotated;
/* 455 */       this._getter = src._getter;
/*     */     }
/*     */ 
/*     */     public SetterlessProperty withValueDeserializer(JsonDeserializer<Object> deser)
/*     */     {
/* 460 */       return new SetterlessProperty(this, deser);
/*     */     }
/*     */ 
/*     */     public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */     {
/* 471 */       return this._annotated.getAnnotation(acls);
/*     */     }
/*     */     public AnnotatedMember getMember() {
/* 474 */       return this._annotated;
/*     */     }
/*     */ 
/*     */     public final void deserializeAndSet(JsonParser jp, DeserializationContext ctxt, Object instance)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 487 */       JsonToken t = jp.getCurrentToken();
/* 488 */       if (t == JsonToken.VALUE_NULL)
/*     */       {
/*     */         return;
/*     */       }
/*     */ 
/*     */       Object toModify;
/*     */       try
/*     */       {
/* 498 */         toModify = this._getter.invoke(instance, new Object[0]);
/*     */       } catch (Exception e) {
/* 500 */         _throwAsIOE(e);
/* 501 */         return;
/*     */       }
/*     */ 
/* 508 */       if (toModify == null) {
/* 509 */         throw new JsonMappingException("Problem deserializing 'setterless' property '" + getName() + "': get method returned null");
/*     */       }
/* 511 */       this._valueDeserializer.deserialize(jp, ctxt, toModify);
/*     */     }
/*     */ 
/*     */     public final void set(Object instance, Object value)
/*     */       throws IOException
/*     */     {
/* 518 */       throw new UnsupportedOperationException("Should never call 'set' on setterless property");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class MethodProperty extends SettableBeanProperty
/*     */   {
/*     */     protected final AnnotatedMethod _annotated;
/*     */     protected final Method _setter;
/*     */ 
/*     */     public MethodProperty(String name, JavaType type, TypeDeserializer typeDeser, Annotations contextAnnotations, AnnotatedMethod method)
/*     */     {
/* 374 */       super(type, typeDeser, contextAnnotations);
/* 375 */       this._annotated = method;
/* 376 */       this._setter = method.getAnnotated();
/*     */     }
/*     */ 
/*     */     protected MethodProperty(MethodProperty src, JsonDeserializer<Object> deser) {
/* 380 */       super(deser);
/* 381 */       this._annotated = src._annotated;
/* 382 */       this._setter = src._setter;
/*     */     }
/*     */ 
/*     */     public MethodProperty withValueDeserializer(JsonDeserializer<Object> deser)
/*     */     {
/* 387 */       return new MethodProperty(this, deser);
/*     */     }
/*     */ 
/*     */     public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */     {
/* 398 */       return this._annotated.getAnnotation(acls);
/*     */     }
/*     */     public AnnotatedMember getMember() {
/* 401 */       return this._annotated;
/*     */     }
/*     */ 
/*     */     public void deserializeAndSet(JsonParser jp, DeserializationContext ctxt, Object instance)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 414 */       set(instance, deserialize(jp, ctxt));
/*     */     }
/*     */ 
/*     */     public final void set(Object instance, Object value)
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 422 */         this._setter.invoke(instance, new Object[] { value });
/*     */       } catch (Exception e) {
/* 424 */         _throwAsIOE(e, value);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.SettableBeanProperty
 * JD-Core Version:    0.6.2
 */