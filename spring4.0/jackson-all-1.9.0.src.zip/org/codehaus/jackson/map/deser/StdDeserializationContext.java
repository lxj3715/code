/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.DeserializationProblemHandler;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.InjectableValues;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.exc.UnrecognizedPropertyException;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.map.util.LinkedNode;
/*     */ import org.codehaus.jackson.map.util.ObjectBuffer;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class StdDeserializationContext extends DeserializationContext
/*     */ {
/*     */   static final int MAX_ERROR_STR_LEN = 500;
/*     */   protected JsonParser _parser;
/*     */   protected final DeserializerProvider _deserProvider;
/*     */   protected final InjectableValues _injectableValues;
/*     */   protected ArrayBuilders _arrayBuilders;
/*     */   protected ObjectBuffer _objectBuffer;
/*     */   protected DateFormat _dateFormat;
/*     */ 
/*     */   public StdDeserializationContext(DeserializationConfig config, JsonParser jp, DeserializerProvider prov, InjectableValues injectableValues)
/*     */   {
/*  68 */     super(config);
/*  69 */     this._parser = jp;
/*  70 */     this._deserProvider = prov;
/*  71 */     this._injectableValues = injectableValues;
/*     */   }
/*     */ 
/*     */   public DeserializerProvider getDeserializerProvider()
/*     */   {
/*  82 */     return this._deserProvider;
/*     */   }
/*     */ 
/*     */   public JsonParser getParser()
/*     */   {
/*  94 */     return this._parser;
/*     */   }
/*     */ 
/*     */   public Object findInjectableValue(Object valueId, BeanProperty forProperty, Object beanInstance)
/*     */   {
/* 100 */     if (this._injectableValues == null) {
/* 101 */       throw new IllegalStateException("No 'injectableValues' configured, can not inject value with id [" + valueId + "]");
/*     */     }
/* 103 */     return this._injectableValues.findInjectableValue(valueId, this, forProperty, beanInstance);
/*     */   }
/*     */ 
/*     */   public final ObjectBuffer leaseObjectBuffer()
/*     */   {
/* 115 */     ObjectBuffer buf = this._objectBuffer;
/* 116 */     if (buf == null)
/* 117 */       buf = new ObjectBuffer();
/*     */     else {
/* 119 */       this._objectBuffer = null;
/*     */     }
/* 121 */     return buf;
/*     */   }
/*     */ 
/*     */   public final void returnObjectBuffer(ObjectBuffer buf)
/*     */   {
/* 130 */     if ((this._objectBuffer == null) || (buf.initialCapacity() >= this._objectBuffer.initialCapacity()))
/*     */     {
/* 132 */       this._objectBuffer = buf;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final ArrayBuilders getArrayBuilders()
/*     */   {
/* 139 */     if (this._arrayBuilders == null) {
/* 140 */       this._arrayBuilders = new ArrayBuilders();
/*     */     }
/* 142 */     return this._arrayBuilders;
/*     */   }
/*     */ 
/*     */   public Date parseDate(String dateStr)
/*     */     throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 156 */       return getDateFormat().parse(dateStr);
/*     */     } catch (ParseException pex) {
/* 158 */       throw new IllegalArgumentException(pex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Calendar constructCalendar(Date d)
/*     */   {
/* 168 */     Calendar c = Calendar.getInstance();
/* 169 */     c.setTime(d);
/* 170 */     return c;
/*     */   }
/*     */ 
/*     */   public boolean handleUnknownProperty(JsonParser jp, JsonDeserializer<?> deser, Object instanceOrClass, String propName)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 188 */     LinkedNode h = this._config.getProblemHandlers();
/* 189 */     if (h != null)
/*     */     {
/* 193 */       JsonParser oldParser = this._parser;
/* 194 */       this._parser = jp;
/*     */       try {
/* 196 */         while (h != null)
/*     */         {
/* 198 */           if (((DeserializationProblemHandler)h.value()).handleUnknownProperty(this, deser, instanceOrClass, propName)) {
/* 199 */             return true;
/*     */           }
/* 201 */           h = h.next();
/*     */         }
/*     */       } finally {
/* 204 */         this._parser = oldParser;
/*     */       }
/*     */     }
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */   public JsonMappingException mappingException(Class<?> targetClass)
/*     */   {
/* 212 */     return mappingException(targetClass, this._parser.getCurrentToken());
/*     */   }
/*     */ 
/*     */   public JsonMappingException mappingException(Class<?> targetClass, JsonToken token)
/*     */   {
/* 218 */     String clsName = _calcName(targetClass);
/* 219 */     return JsonMappingException.from(this._parser, "Can not deserialize instance of " + clsName + " out of " + token + " token");
/*     */   }
/*     */ 
/*     */   public JsonMappingException instantiationException(Class<?> instClass, Throwable t)
/*     */   {
/* 225 */     return JsonMappingException.from(this._parser, "Can not construct instance of " + instClass.getName() + ", problem: " + t.getMessage(), t);
/*     */   }
/*     */ 
/*     */   public JsonMappingException instantiationException(Class<?> instClass, String msg)
/*     */   {
/* 233 */     return JsonMappingException.from(this._parser, "Can not construct instance of " + instClass.getName() + ", problem: " + msg);
/*     */   }
/*     */ 
/*     */   public JsonMappingException weirdStringException(Class<?> instClass, String msg)
/*     */   {
/* 243 */     return JsonMappingException.from(this._parser, "Can not construct instance of " + instClass.getName() + " from String value '" + _valueDesc() + "': " + msg);
/*     */   }
/*     */ 
/*     */   public JsonMappingException weirdNumberException(Class<?> instClass, String msg)
/*     */   {
/* 249 */     return JsonMappingException.from(this._parser, "Can not construct instance of " + instClass.getName() + " from number value (" + _valueDesc() + "): " + msg);
/*     */   }
/*     */ 
/*     */   public JsonMappingException weirdKeyException(Class<?> keyClass, String keyValue, String msg)
/*     */   {
/* 255 */     return JsonMappingException.from(this._parser, "Can not construct Map key of type " + keyClass.getName() + " from String \"" + _desc(keyValue) + "\": " + msg);
/*     */   }
/*     */ 
/*     */   public JsonMappingException wrongTokenException(JsonParser jp, JsonToken expToken, String msg)
/*     */   {
/* 261 */     return JsonMappingException.from(jp, "Unexpected token (" + jp.getCurrentToken() + "), expected " + expToken + ": " + msg);
/*     */   }
/*     */ 
/*     */   public JsonMappingException unknownFieldException(Object instanceOrClass, String fieldName)
/*     */   {
/* 267 */     return UnrecognizedPropertyException.from(this._parser, instanceOrClass, fieldName);
/*     */   }
/*     */ 
/*     */   public JsonMappingException unknownTypeException(JavaType type, String id)
/*     */   {
/* 273 */     return JsonMappingException.from(this._parser, "Could not resolve type id '" + id + "' into a subtype of " + type);
/*     */   }
/*     */ 
/*     */   protected DateFormat getDateFormat()
/*     */   {
/* 284 */     if (this._dateFormat == null)
/*     */     {
/* 286 */       this._dateFormat = ((DateFormat)this._config.getDateFormat().clone());
/*     */     }
/* 288 */     return this._dateFormat;
/*     */   }
/*     */ 
/*     */   protected String determineClassName(Object instance)
/*     */   {
/* 293 */     return ClassUtil.getClassDescription(instance);
/*     */   }
/*     */ 
/*     */   protected String _calcName(Class<?> cls)
/*     */   {
/* 304 */     if (cls.isArray()) {
/* 305 */       return _calcName(cls.getComponentType()) + "[]";
/*     */     }
/* 307 */     return cls.getName();
/*     */   }
/*     */ 
/*     */   protected String _valueDesc()
/*     */   {
/*     */     try {
/* 313 */       return _desc(this._parser.getText()); } catch (Exception e) {
/*     */     }
/* 315 */     return "[N/A]";
/*     */   }
/*     */ 
/*     */   protected String _desc(String desc)
/*     */   {
/* 321 */     if (desc.length() > 500) {
/* 322 */       desc = desc.substring(0, 500) + "]...[" + desc.substring(desc.length() - 500);
/*     */     }
/* 324 */     return desc;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.StdDeserializationContext
 * JD-Core Version:    0.6.2
 */