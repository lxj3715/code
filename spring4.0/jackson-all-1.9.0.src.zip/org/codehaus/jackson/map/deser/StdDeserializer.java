/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.Base64Variant;
/*    */ import org.codehaus.jackson.Base64Variants;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ import org.codehaus.jackson.map.deser.std.CalendarDeserializer;
/*    */ import org.codehaus.jackson.map.deser.std.ClassDeserializer;
/*    */ import org.codehaus.jackson.map.deser.std.StdScalarDeserializer;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class StdDeserializer<T> extends org.codehaus.jackson.map.deser.std.StdDeserializer<T>
/*    */ {
/*    */   protected StdDeserializer(Class<?> vc)
/*    */   {
/* 23 */     super(vc);
/*    */   }
/*    */ 
/*    */   protected StdDeserializer(JavaType valueType) {
/* 27 */     super(valueType);
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   @JacksonStdImpl
/*    */   public static final class StringDeserializer extends StdScalarDeserializer<String>
/*    */   {
/*    */     public StringDeserializer()
/*    */     {
/* 58 */       super();
/*    */     }
/*    */ 
/*    */     public String deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */       throws IOException, JsonProcessingException
/*    */     {
/* 64 */       JsonToken curr = jp.getCurrentToken();
/* 65 */       if (curr == JsonToken.VALUE_STRING) {
/* 66 */         return jp.getText();
/*    */       }
/* 68 */       if (curr == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 69 */         Object ob = jp.getEmbeddedObject();
/* 70 */         if (ob == null) {
/* 71 */           return null;
/*    */         }
/* 73 */         if ((ob instanceof byte[])) {
/* 74 */           return Base64Variants.getDefaultVariant().encode((byte[])ob, false);
/*    */         }
/* 76 */         return ob.toString();
/*    */       }
/* 78 */       if (curr.isScalarValue()) {
/* 79 */         return jp.getText();
/*    */       }
/* 81 */       throw ctxt.mappingException(this._valueClass, curr);
/*    */     }
/*    */ 
/*    */     public String deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*    */       throws IOException, JsonProcessingException
/*    */     {
/* 90 */       return deserialize(jp, ctxt);
/*    */     }
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   @JacksonStdImpl
/*    */   public class CalendarDeserializer extends CalendarDeserializer
/*    */   {
/*    */     public CalendarDeserializer()
/*    */     {
/*    */     }
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   @JacksonStdImpl
/*    */   public class ClassDeserializer extends ClassDeserializer
/*    */   {
/*    */     public ClassDeserializer()
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.StdDeserializer
 * JD-Core Version:    0.6.2
 */