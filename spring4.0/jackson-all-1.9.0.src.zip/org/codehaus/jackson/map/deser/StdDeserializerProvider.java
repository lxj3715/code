/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.io.SerializedString;
/*     */ import org.codehaus.jackson.map.AbstractTypeResolver;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.ContextualDeserializer;
/*     */ import org.codehaus.jackson.map.ContextualKeyDeserializer;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.DeserializerFactory;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.Deserializers;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.KeyDeserializer;
/*     */ import org.codehaus.jackson.map.KeyDeserializers;
/*     */ import org.codehaus.jackson.map.ResolvableDeserializer;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdKeyDeserializers;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*     */ import org.codehaus.jackson.map.type.ArrayType;
/*     */ import org.codehaus.jackson.map.type.CollectionLikeType;
/*     */ import org.codehaus.jackson.map.type.CollectionType;
/*     */ import org.codehaus.jackson.map.type.MapLikeType;
/*     */ import org.codehaus.jackson.map.type.MapType;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.map.util.RootNameLookup;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class StdDeserializerProvider extends DeserializerProvider
/*     */ {
/*  40 */   static final HashMap<JavaType, KeyDeserializer> _keyDeserializers = StdKeyDeserializers.constructAll();
/*     */ 
/*  52 */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _cachedDeserializers = new ConcurrentHashMap(64, 0.75F, 2);
/*     */ 
/*  60 */   protected final HashMap<JavaType, JsonDeserializer<Object>> _incompleteDeserializers = new HashMap(8);
/*     */   protected final RootNameLookup _rootNames;
/*     */   protected DeserializerFactory _factory;
/*     */ 
/*     */   public StdDeserializerProvider()
/*     */   {
/*  89 */     this(BeanDeserializerFactory.instance);
/*     */   }
/*     */   public StdDeserializerProvider(DeserializerFactory f) {
/*  92 */     this._factory = f;
/*  93 */     this._rootNames = new RootNameLookup();
/*     */   }
/*     */ 
/*     */   public DeserializerProvider withAdditionalDeserializers(Deserializers d)
/*     */   {
/*  98 */     return withFactory(this._factory.withAdditionalDeserializers(d));
/*     */   }
/*     */ 
/*     */   public DeserializerProvider withAdditionalKeyDeserializers(KeyDeserializers d)
/*     */   {
/* 103 */     return withFactory(this._factory.withAdditionalKeyDeserializers(d));
/*     */   }
/*     */ 
/*     */   public DeserializerProvider withDeserializerModifier(BeanDeserializerModifier modifier)
/*     */   {
/* 108 */     return withFactory(this._factory.withDeserializerModifier(modifier));
/*     */   }
/*     */ 
/*     */   public DeserializerProvider withAbstractTypeResolver(AbstractTypeResolver resolver)
/*     */   {
/* 113 */     return withFactory(this._factory.withAbstractTypeResolver(resolver));
/*     */   }
/*     */ 
/*     */   public DeserializerProvider withValueInstantiators(ValueInstantiators instantiators)
/*     */   {
/* 118 */     return withFactory(this._factory.withValueInstantiators(instantiators));
/*     */   }
/*     */ 
/*     */   public StdDeserializerProvider withFactory(DeserializerFactory factory)
/*     */   {
/* 124 */     if (getClass() != StdDeserializerProvider.class) {
/* 125 */       throw new IllegalStateException("DeserializerProvider of type " + getClass().getName() + " does not override 'withFactory()' method");
/*     */     }
/*     */ 
/* 128 */     return new StdDeserializerProvider(factory);
/*     */   }
/*     */ 
/*     */   public JavaType mapAbstractType(DeserializationConfig config, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 141 */     return this._factory.mapAbstractType(config, type);
/*     */   }
/*     */ 
/*     */   public SerializedString findExpectedRootName(DeserializationConfig config, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 148 */     return this._rootNames.findRootName(type, config);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> findValueDeserializer(DeserializationConfig config, JavaType propertyType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 157 */     JsonDeserializer deser = _findCachedDeserializer(propertyType);
/* 158 */     if (deser != null)
/*     */     {
/* 160 */       if ((deser instanceof ContextualDeserializer)) {
/* 161 */         JsonDeserializer d = ((ContextualDeserializer)deser).createContextual(config, property);
/* 162 */         deser = d;
/*     */       }
/* 164 */       return deser;
/*     */     }
/*     */ 
/* 167 */     deser = _createAndCacheValueDeserializer(config, propertyType, property);
/* 168 */     if (deser == null)
/*     */     {
/* 173 */       deser = _handleUnknownValueDeserializer(propertyType);
/*     */     }
/*     */ 
/* 176 */     if ((deser instanceof ContextualDeserializer)) {
/* 177 */       JsonDeserializer d = ((ContextualDeserializer)deser).createContextual(config, property);
/* 178 */       deser = d;
/*     */     }
/* 180 */     return deser;
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> findTypedValueDeserializer(DeserializationConfig config, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 188 */     JsonDeserializer deser = findValueDeserializer(config, type, property);
/* 189 */     TypeDeserializer typeDeser = this._factory.findTypeDeserializer(config, type, property);
/* 190 */     if (typeDeser != null) {
/* 191 */       return new WrappedDeserializer(typeDeser, deser);
/*     */     }
/* 193 */     return deser;
/*     */   }
/*     */ 
/*     */   public KeyDeserializer findKeyDeserializer(DeserializationConfig config, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 202 */     KeyDeserializer kd = this._factory.createKeyDeserializer(config, type, property);
/* 203 */     if (kd == null)
/*     */     {
/* 205 */       Class raw = type.getRawClass();
/* 206 */       if ((raw == String.class) || (raw == Object.class)) {
/* 207 */         return null;
/*     */       }
/*     */ 
/* 210 */       KeyDeserializer kdes = (KeyDeserializer)_keyDeserializers.get(type);
/* 211 */       if (kdes != null) {
/* 212 */         return kdes;
/*     */       }
/*     */ 
/* 215 */       if (type.isEnumType()) {
/* 216 */         return StdKeyDeserializers.constructEnumKeyDeserializer(config, type);
/*     */       }
/*     */ 
/* 219 */       kdes = StdKeyDeserializers.findStringBasedKeyDeserializer(config, type);
/* 220 */       if (kdes != null) {
/* 221 */         return kdes;
/*     */       }
/* 223 */       if (kd == null)
/*     */       {
/* 225 */         return _handleUnknownKeyDeserializer(type);
/*     */       }
/*     */     }
/*     */ 
/* 229 */     if ((kd instanceof ContextualKeyDeserializer)) {
/* 230 */       kd = ((ContextualKeyDeserializer)kd).createContextual(config, property);
/*     */     }
/* 232 */     return kd;
/*     */   }
/*     */ 
/*     */   public boolean hasValueDeserializerFor(DeserializationConfig config, JavaType type)
/*     */   {
/* 245 */     JsonDeserializer deser = _findCachedDeserializer(type);
/* 246 */     if (deser == null) {
/*     */       try {
/* 248 */         deser = _createAndCacheValueDeserializer(config, type, null);
/*     */       } catch (Exception e) {
/* 250 */         return false;
/*     */       }
/*     */     }
/* 253 */     return deser != null;
/*     */   }
/*     */ 
/*     */   public int cachedDeserializersCount()
/*     */   {
/* 258 */     return this._cachedDeserializers.size();
/*     */   }
/*     */ 
/*     */   public void flushCachedDeserializers()
/*     */   {
/* 272 */     this._cachedDeserializers.clear();
/*     */   }
/*     */ 
/*     */   protected JsonDeserializer<Object> _findCachedDeserializer(JavaType type)
/*     */   {
/* 283 */     if (type == null) {
/* 284 */       throw new IllegalArgumentException();
/*     */     }
/* 286 */     return (JsonDeserializer)this._cachedDeserializers.get(type);
/*     */   }
/*     */ 
/*     */   protected JsonDeserializer<Object> _createAndCacheValueDeserializer(DeserializationConfig config, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 305 */     synchronized (this._incompleteDeserializers)
/*     */     {
/* 307 */       JsonDeserializer deser = _findCachedDeserializer(type);
/* 308 */       if (deser != null) {
/* 309 */         return deser;
/*     */       }
/* 311 */       int count = this._incompleteDeserializers.size();
/*     */ 
/* 313 */       if (count > 0) {
/* 314 */         deser = (JsonDeserializer)this._incompleteDeserializers.get(type);
/* 315 */         if (deser != null) {
/* 316 */           return deser;
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 321 */         JsonDeserializer localJsonDeserializer1 = _createAndCache2(config, type, property);
/*     */ 
/* 324 */         if ((count == 0) && (this._incompleteDeserializers.size() > 0))
/* 325 */           this._incompleteDeserializers.clear(); return localJsonDeserializer1;
/*     */       }
/*     */       finally
/*     */       {
/* 324 */         if ((count == 0) && (this._incompleteDeserializers.size() > 0))
/* 325 */           this._incompleteDeserializers.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JsonDeserializer<Object> _createAndCache2(DeserializationConfig config, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/*     */     JsonDeserializer deser;
/*     */     try
/*     */     {
/* 341 */       deser = _createDeserializer(config, type, property);
/*     */     }
/*     */     catch (IllegalArgumentException iae)
/*     */     {
/* 346 */       throw new JsonMappingException(iae.getMessage(), null, iae);
/*     */     }
/* 348 */     if (deser == null) {
/* 349 */       return null;
/*     */     }
/*     */ 
/* 355 */     boolean isResolvable = deser instanceof ResolvableDeserializer;
/* 356 */     boolean addToCache = deser.getClass() == BeanDeserializer.class;
/* 357 */     if (!addToCache)
/*     */     {
/* 359 */       if (config.isEnabled(DeserializationConfig.Feature.USE_ANNOTATIONS)) {
/* 360 */         AnnotationIntrospector aintr = config.getAnnotationIntrospector();
/*     */ 
/* 362 */         AnnotatedClass ac = AnnotatedClass.construct(deser.getClass(), aintr, null);
/* 363 */         Boolean cacheAnn = aintr.findCachability(ac);
/* 364 */         if (cacheAnn != null) {
/* 365 */           addToCache = cacheAnn.booleanValue();
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 381 */     if (isResolvable) {
/* 382 */       this._incompleteDeserializers.put(type, deser);
/* 383 */       _resolveDeserializer(config, (ResolvableDeserializer)deser);
/* 384 */       this._incompleteDeserializers.remove(type);
/*     */     }
/* 386 */     if (addToCache) {
/* 387 */       this._cachedDeserializers.put(type, deser);
/*     */     }
/* 389 */     return deser;
/*     */   }
/*     */ 
/*     */   protected JsonDeserializer<Object> _createDeserializer(DeserializationConfig config, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 400 */     if (type.isEnumType()) {
/* 401 */       return this._factory.createEnumDeserializer(config, this, type, property);
/*     */     }
/* 403 */     if (type.isContainerType()) {
/* 404 */       if (type.isArrayType()) {
/* 405 */         return this._factory.createArrayDeserializer(config, this, (ArrayType)type, property);
/*     */       }
/*     */ 
/* 408 */       if (type.isMapLikeType()) {
/* 409 */         MapLikeType mlt = (MapLikeType)type;
/* 410 */         if (mlt.isTrueMapType()) {
/* 411 */           return this._factory.createMapDeserializer(config, this, (MapType)mlt, property);
/*     */         }
/*     */ 
/* 414 */         return this._factory.createMapLikeDeserializer(config, this, mlt, property);
/*     */       }
/*     */ 
/* 417 */       if (type.isCollectionLikeType()) {
/* 418 */         CollectionLikeType clt = (CollectionLikeType)type;
/* 419 */         if (clt.isTrueCollectionType()) {
/* 420 */           return this._factory.createCollectionDeserializer(config, this, (CollectionType)clt, property);
/*     */         }
/*     */ 
/* 423 */         return this._factory.createCollectionLikeDeserializer(config, this, clt, property);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 429 */     if (JsonNode.class.isAssignableFrom(type.getRawClass())) {
/* 430 */       return this._factory.createTreeDeserializer(config, this, type, property);
/*     */     }
/* 432 */     return this._factory.createBeanDeserializer(config, this, type, property);
/*     */   }
/*     */ 
/*     */   protected void _resolveDeserializer(DeserializationConfig config, ResolvableDeserializer ser)
/*     */     throws JsonMappingException
/*     */   {
/* 438 */     ser.resolve(config, this);
/*     */   }
/*     */ 
/*     */   protected JsonDeserializer<Object> _handleUnknownValueDeserializer(JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 453 */     Class rawClass = type.getRawClass();
/* 454 */     if (!ClassUtil.isConcrete(rawClass)) {
/* 455 */       throw new JsonMappingException("Can not find a Value deserializer for abstract type " + type);
/*     */     }
/* 457 */     throw new JsonMappingException("Can not find a Value deserializer for type " + type);
/*     */   }
/*     */ 
/*     */   protected KeyDeserializer _handleUnknownKeyDeserializer(JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 463 */     throw new JsonMappingException("Can not find a (Map) Key deserializer for type " + type);
/*     */   }
/*     */ 
/*     */   protected static final class WrappedDeserializer extends JsonDeserializer<Object>
/*     */   {
/*     */     final TypeDeserializer _typeDeserializer;
/*     */     final JsonDeserializer<Object> _deserializer;
/*     */ 
/*     */     public WrappedDeserializer(TypeDeserializer typeDeser, JsonDeserializer<Object> deser)
/*     */     {
/* 486 */       this._typeDeserializer = typeDeser;
/* 487 */       this._deserializer = deser;
/*     */     }
/*     */ 
/*     */     public Object deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 494 */       return this._deserializer.deserializeWithType(jp, ctxt, this._typeDeserializer);
/*     */     }
/*     */ 
/*     */     public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 503 */       throw new IllegalStateException("Type-wrapped deserializer's deserializeWithType should never get called");
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.StdDeserializerProvider
 * JD-Core Version:    0.6.2
 */