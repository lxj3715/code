/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.AtomicBooleanDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.CalendarDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.ClassDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.DateDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.FromStringDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.JavaTypeDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.BigDecimalDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.BigIntegerDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.BooleanDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.ByteDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.CharacterDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.DoubleDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.FloatDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.IntegerDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.LongDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.NumberDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.ShortDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.SqlDateDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer.StackTraceElementDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.StringDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.TimestampDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.TokenBufferDeserializer;
/*     */ import org.codehaus.jackson.map.deser.std.UntypedObjectDeserializer;
/*     */ import org.codehaus.jackson.map.type.ClassKey;
/*     */ 
/*     */ class StdDeserializers
/*     */ {
/*  28 */   final HashMap<ClassKey, JsonDeserializer<Object>> _deserializers = new HashMap();
/*     */ 
/*     */   private StdDeserializers()
/*     */   {
/*  34 */     add(new UntypedObjectDeserializer());
/*     */ 
/*  37 */     StdDeserializer strDeser = new StringDeserializer();
/*  38 */     add(strDeser, String.class);
/*  39 */     add(strDeser, CharSequence.class);
/*  40 */     add(new ClassDeserializer());
/*     */ 
/*  43 */     add(new StdDeserializer.BooleanDeserializer(Boolean.class, null));
/*  44 */     add(new StdDeserializer.ByteDeserializer(Byte.class, null));
/*  45 */     add(new StdDeserializer.ShortDeserializer(Short.class, null));
/*  46 */     add(new StdDeserializer.CharacterDeserializer(Character.class, null));
/*  47 */     add(new StdDeserializer.IntegerDeserializer(Integer.class, null));
/*  48 */     add(new StdDeserializer.LongDeserializer(Long.class, null));
/*  49 */     add(new StdDeserializer.FloatDeserializer(Float.class, null));
/*  50 */     add(new StdDeserializer.DoubleDeserializer(Double.class, null));
/*     */ 
/*  55 */     add(new StdDeserializer.BooleanDeserializer(Boolean.TYPE, Boolean.FALSE));
/*  56 */     add(new StdDeserializer.ByteDeserializer(Byte.TYPE, Byte.valueOf((byte)0)));
/*  57 */     add(new StdDeserializer.ShortDeserializer(Short.TYPE, Short.valueOf((short)0)));
/*  58 */     add(new StdDeserializer.CharacterDeserializer(Character.TYPE, Character.valueOf('\000')));
/*  59 */     add(new StdDeserializer.IntegerDeserializer(Integer.TYPE, Integer.valueOf(0)));
/*  60 */     add(new StdDeserializer.LongDeserializer(Long.TYPE, Long.valueOf(0L)));
/*  61 */     add(new StdDeserializer.FloatDeserializer(Float.TYPE, Float.valueOf(0.0F)));
/*  62 */     add(new StdDeserializer.DoubleDeserializer(Double.TYPE, Double.valueOf(0.0D)));
/*     */ 
/*  65 */     add(new StdDeserializer.NumberDeserializer());
/*  66 */     add(new StdDeserializer.BigDecimalDeserializer());
/*  67 */     add(new StdDeserializer.BigIntegerDeserializer());
/*     */ 
/*  69 */     add(new CalendarDeserializer());
/*  70 */     add(new DateDeserializer());
/*     */ 
/*  74 */     add(new CalendarDeserializer(GregorianCalendar.class), GregorianCalendar.class);
/*     */ 
/*  76 */     add(new StdDeserializer.SqlDateDeserializer());
/*  77 */     add(new TimestampDeserializer());
/*     */ 
/*  80 */     for (StdDeserializer deser : FromStringDeserializer.all()) {
/*  81 */       add(deser);
/*     */     }
/*     */ 
/*  87 */     add(new StdDeserializer.StackTraceElementDeserializer());
/*     */ 
/*  91 */     add(new AtomicBooleanDeserializer());
/*     */ 
/*  94 */     add(new TokenBufferDeserializer());
/*  95 */     add(new JavaTypeDeserializer());
/*     */   }
/*     */ 
/*     */   public static HashMap<ClassKey, JsonDeserializer<Object>> constructAll()
/*     */   {
/* 103 */     return new StdDeserializers()._deserializers;
/*     */   }
/*     */ 
/*     */   private void add(StdDeserializer<?> stdDeser)
/*     */   {
/* 108 */     add(stdDeser, stdDeser.getValueClass());
/*     */   }
/*     */ 
/*     */   private void add(StdDeserializer<?> stdDeser, Class<?> valueClass)
/*     */   {
/* 115 */     JsonDeserializer deser = stdDeser;
/*     */ 
/* 117 */     this._deserializers.put(new ClassKey(valueClass), deser);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.StdDeserializers
 * JD-Core Version:    0.6.2
 */