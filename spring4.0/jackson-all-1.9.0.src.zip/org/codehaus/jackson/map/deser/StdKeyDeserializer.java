/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class StdKeyDeserializer extends org.codehaus.jackson.map.deser.std.StdKeyDeserializer
/*    */ {
/*    */   protected StdKeyDeserializer(Class<?> cls)
/*    */   {
/* 10 */     super(cls);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.StdKeyDeserializer
 * JD-Core Version:    0.6.2
 */