/*    */ package org.codehaus.jackson.map.deser;
/*    */ 
/*    */ import org.codehaus.jackson.map.deser.std.StdDeserializer;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class StdScalarDeserializer<T> extends StdDeserializer<T>
/*    */ {
/*    */   protected StdScalarDeserializer(Class<?> vc)
/*    */   {
/* 11 */     super(vc);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.StdScalarDeserializer
 * JD-Core Version:    0.6.2
 */