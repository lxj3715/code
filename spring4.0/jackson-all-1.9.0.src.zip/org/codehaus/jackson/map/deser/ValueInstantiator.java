/*     */ package org.codehaus.jackson.map.deser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedWithParams;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class ValueInstantiator
/*     */ {
/*     */   public abstract String getValueTypeDesc();
/*     */ 
/*     */   public boolean canInstantiate()
/*     */   {
/*  53 */     return (canCreateUsingDefault()) || (canCreateUsingDelegate()) || (canCreateFromObjectWith()) || (canCreateFromString()) || (canCreateFromInt()) || (canCreateFromLong()) || (canCreateFromDouble()) || (canCreateFromBoolean());
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromString()
/*     */   {
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromInt()
/*     */   {
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromLong()
/*     */   {
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromDouble()
/*     */   {
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromBoolean()
/*     */   {
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canCreateUsingDefault()
/*     */   {
/* 111 */     return getDefaultCreator() != null;
/*     */   }
/*     */ 
/*     */   public boolean canCreateUsingDelegate()
/*     */   {
/* 120 */     return getDelegateType() != null;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromObjectWith()
/*     */   {
/* 129 */     return false;
/*     */   }
/*     */ 
/*     */   public SettableBeanProperty[] getFromObjectArguments()
/*     */   {
/* 143 */     return null;
/*     */   }
/*     */ 
/*     */   public JavaType getDelegateType()
/*     */   {
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   public Object createUsingDefault()
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 175 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + "; no default creator found");
/*     */   }
/*     */ 
/*     */   public Object createFromObjectWith(Object[] args)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 189 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " with arguments");
/*     */   }
/*     */ 
/*     */   public Object createUsingDelegate(Object delegate)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 200 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " using delegate");
/*     */   }
/*     */ 
/*     */   public Object createFromString(String value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 212 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON String");
/*     */   }
/*     */ 
/*     */   public Object createFromInt(int value) throws IOException, JsonProcessingException
/*     */   {
/* 217 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON int number");
/*     */   }
/*     */ 
/*     */   public Object createFromLong(long value) throws IOException, JsonProcessingException
/*     */   {
/* 222 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON long number");
/*     */   }
/*     */ 
/*     */   public Object createFromDouble(double value) throws IOException, JsonProcessingException
/*     */   {
/* 227 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON floating-point number");
/*     */   }
/*     */ 
/*     */   public Object createFromBoolean(boolean value) throws IOException, JsonProcessingException
/*     */   {
/* 232 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON boolean value");
/*     */   }
/*     */ 
/*     */   public AnnotatedWithParams getDefaultCreator()
/*     */   {
/* 253 */     return null;
/*     */   }
/*     */ 
/*     */   public AnnotatedWithParams getDelegateCreator()
/*     */   {
/* 265 */     return null;
/*     */   }
/*     */ 
/*     */   public AnnotatedWithParams getWithArgsCreator()
/*     */   {
/* 278 */     return null;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.ValueInstantiator
 * JD-Core Version:    0.6.2
 */