/*     */ package org.codehaus.jackson.map.deser.impl;
/*     */ 
/*     */ import java.lang.reflect.Member;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ import org.codehaus.jackson.map.deser.std.StdValueInstantiator;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedConstructor;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedWithParams;
/*     */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*     */ import org.codehaus.jackson.map.type.TypeBindings;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class CreatorCollector
/*     */ {
/*     */   final BasicBeanDescription _beanDesc;
/*     */   final boolean _canFixAccess;
/*     */   protected AnnotatedConstructor _defaultConstructor;
/*     */   protected AnnotatedWithParams _stringCreator;
/*     */   protected AnnotatedWithParams _intCreator;
/*     */   protected AnnotatedWithParams _longCreator;
/*     */   protected AnnotatedWithParams _doubleCreator;
/*     */   protected AnnotatedWithParams _booleanCreator;
/*     */   protected AnnotatedWithParams _delegateCreator;
/*     */   protected AnnotatedWithParams _propertyBasedCreator;
/*  32 */   protected CreatorProperty[] _propertyBasedArgs = null;
/*     */ 
/*     */   public CreatorCollector(BasicBeanDescription beanDesc, boolean canFixAccess)
/*     */   {
/*  42 */     this._beanDesc = beanDesc;
/*  43 */     this._canFixAccess = canFixAccess;
/*     */   }
/*     */ 
/*     */   public ValueInstantiator constructValueInstantiator(DeserializationConfig config)
/*     */   {
/*  51 */     StdValueInstantiator inst = new StdValueInstantiator(config, this._beanDesc.getType());
/*     */     JavaType delegateType;
/*     */     JavaType delegateType;
/*  55 */     if (this._delegateCreator == null) {
/*  56 */       delegateType = null;
/*     */     } else {
/*  58 */       TypeBindings bindings = this._beanDesc.bindingsForBeanType();
/*  59 */       delegateType = bindings.resolveType(this._delegateCreator.getParameterType(0));
/*     */     }
/*     */ 
/*  62 */     inst.configureFromObjectSettings(this._defaultConstructor, this._delegateCreator, delegateType, this._propertyBasedCreator, this._propertyBasedArgs);
/*     */ 
/*  65 */     inst.configureFromStringCreator(this._stringCreator);
/*  66 */     inst.configureFromIntCreator(this._intCreator);
/*  67 */     inst.configureFromLongCreator(this._longCreator);
/*  68 */     inst.configureFromDoubleCreator(this._doubleCreator);
/*  69 */     inst.configureFromBooleanCreator(this._booleanCreator);
/*  70 */     return inst;
/*     */   }
/*     */ 
/*     */   public void setDefaultConstructor(AnnotatedConstructor ctor)
/*     */   {
/*  80 */     this._defaultConstructor = ctor;
/*     */   }
/*     */ 
/*     */   public void addStringCreator(AnnotatedWithParams creator) {
/*  84 */     this._stringCreator = verifyNonDup(creator, this._stringCreator, "String");
/*     */   }
/*     */   public void addIntCreator(AnnotatedWithParams creator) {
/*  87 */     this._intCreator = verifyNonDup(creator, this._intCreator, "int");
/*     */   }
/*     */   public void addLongCreator(AnnotatedWithParams creator) {
/*  90 */     this._longCreator = verifyNonDup(creator, this._longCreator, "long");
/*     */   }
/*     */   public void addDoubleCreator(AnnotatedWithParams creator) {
/*  93 */     this._doubleCreator = verifyNonDup(creator, this._doubleCreator, "double");
/*     */   }
/*     */   public void addBooleanCreator(AnnotatedWithParams creator) {
/*  96 */     this._booleanCreator = verifyNonDup(creator, this._booleanCreator, "boolean");
/*     */   }
/*     */ 
/*     */   public void addDelegatingCreator(AnnotatedWithParams creator) {
/* 100 */     this._delegateCreator = verifyNonDup(creator, this._delegateCreator, "delegate");
/*     */   }
/*     */ 
/*     */   public void addPropertyCreator(AnnotatedWithParams creator, CreatorProperty[] properties)
/*     */   {
/* 105 */     this._propertyBasedCreator = verifyNonDup(creator, this._propertyBasedCreator, "property-based");
/*     */ 
/* 107 */     if (properties.length > 1) {
/* 108 */       HashMap names = new HashMap();
/* 109 */       int i = 0; for (int len = properties.length; i < len; i++) {
/* 110 */         String name = properties[i].getName();
/* 111 */         Integer old = (Integer)names.put(name, Integer.valueOf(i));
/* 112 */         if (old != null) {
/* 113 */           throw new IllegalArgumentException("Duplicate creator property \"" + name + "\" (index " + old + " vs " + i + ")");
/*     */         }
/*     */       }
/*     */     }
/* 117 */     this._propertyBasedArgs = properties;
/*     */   }
/*     */ 
/*     */   protected AnnotatedWithParams verifyNonDup(AnnotatedWithParams newOne, AnnotatedWithParams oldOne, String type)
/*     */   {
/* 129 */     if (oldOne != null)
/*     */     {
/* 131 */       if (oldOne.getClass() == newOne.getClass()) {
/* 132 */         throw new IllegalArgumentException("Conflicting " + type + " creators: already had " + oldOne + ", encountered " + newOne);
/*     */       }
/*     */     }
/* 135 */     if (this._canFixAccess) {
/* 136 */       ClassUtil.checkAndFixAccess((Member)newOne.getAnnotated());
/*     */     }
/* 138 */     return newOne;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.impl.CreatorCollector
 * JD-Core Version:    0.6.2
 */