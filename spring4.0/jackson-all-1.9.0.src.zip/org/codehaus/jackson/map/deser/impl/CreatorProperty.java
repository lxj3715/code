/*     */ package org.codehaus.jackson.map.deser.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedParameter;
/*     */ import org.codehaus.jackson.map.util.Annotations;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class CreatorProperty extends SettableBeanProperty
/*     */ {
/*     */   protected final AnnotatedParameter _annotated;
/*     */   protected final Object _injectableValueId;
/*     */ 
/*     */   public CreatorProperty(String name, JavaType type, TypeDeserializer typeDeser, Annotations contextAnnotations, AnnotatedParameter param, int index, Object injectableValueId)
/*     */   {
/*  65 */     super(name, type, typeDeser, contextAnnotations);
/*  66 */     this._annotated = param;
/*  67 */     this._propertyIndex = index;
/*  68 */     this._injectableValueId = injectableValueId;
/*     */   }
/*     */ 
/*     */   protected CreatorProperty(CreatorProperty src, JsonDeserializer<Object> deser) {
/*  72 */     super(src, deser);
/*  73 */     this._annotated = src._annotated;
/*  74 */     this._injectableValueId = src._injectableValueId;
/*     */   }
/*     */ 
/*     */   public CreatorProperty withValueDeserializer(JsonDeserializer<Object> deser)
/*     */   {
/*  79 */     return new CreatorProperty(this, deser);
/*     */   }
/*     */ 
/*     */   public Object findInjectableValue(DeserializationContext context, Object beanInstance)
/*     */   {
/*  90 */     if (this._injectableValueId == null) {
/*  91 */       throw new IllegalStateException("Property '" + getName() + "' (type " + getClass().getName() + ") has no injectable value id configured");
/*     */     }
/*     */ 
/*  94 */     return context.findInjectableValue(this._injectableValueId, this, beanInstance);
/*     */   }
/*     */ 
/*     */   public void inject(DeserializationContext context, Object beanInstance)
/*     */     throws IOException
/*     */   {
/* 105 */     set(beanInstance, findInjectableValue(context, beanInstance));
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */   {
/* 116 */     if (this._annotated == null) {
/* 117 */       return null;
/*     */     }
/* 119 */     return this._annotated.getAnnotation(acls);
/*     */   }
/*     */   public AnnotatedMember getMember() {
/* 122 */     return this._annotated;
/*     */   }
/*     */ 
/*     */   public void deserializeAndSet(JsonParser jp, DeserializationContext ctxt, Object instance)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 135 */     set(instance, deserialize(jp, ctxt));
/*     */   }
/*     */ 
/*     */   public void set(Object instance, Object value)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public Object getInjectableValueId()
/*     */   {
/* 150 */     return this._injectableValueId;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.impl.CreatorProperty
 * JD-Core Version:    0.6.2
 */