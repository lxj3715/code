/*     */ package org.codehaus.jackson.map.deser.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*     */ import org.codehaus.jackson.util.TokenBuffer;
/*     */ 
/*     */ public class ExternalTypeHandler
/*     */ {
/*     */   private final ExtTypedProperty[] _properties;
/*     */   private final HashMap<String, Integer> _nameToPropertyIndex;
/*     */   private final String[] _typeIds;
/*     */   private final TokenBuffer[] _tokens;
/*     */ 
/*     */   protected ExternalTypeHandler(ExtTypedProperty[] properties, HashMap<String, Integer> nameToPropertyIndex, String[] typeIds, TokenBuffer[] tokens)
/*     */   {
/*  33 */     this._properties = properties;
/*  34 */     this._nameToPropertyIndex = nameToPropertyIndex;
/*  35 */     this._typeIds = typeIds;
/*  36 */     this._tokens = tokens;
/*     */   }
/*     */ 
/*     */   protected ExternalTypeHandler(ExternalTypeHandler h)
/*     */   {
/*  41 */     this._properties = h._properties;
/*  42 */     this._nameToPropertyIndex = h._nameToPropertyIndex;
/*  43 */     int len = this._properties.length;
/*  44 */     this._typeIds = new String[len];
/*  45 */     this._tokens = new TokenBuffer[len];
/*     */   }
/*     */ 
/*     */   public ExternalTypeHandler start() {
/*  49 */     return new ExternalTypeHandler(this);
/*     */   }
/*     */ 
/*     */   public boolean handleToken(JsonParser jp, DeserializationContext ctxt, String propName, Object bean)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  59 */     Integer I = (Integer)this._nameToPropertyIndex.get(propName);
/*  60 */     if (I == null) {
/*  61 */       return false;
/*     */     }
/*  63 */     int index = I.intValue();
/*  64 */     ExtTypedProperty prop = this._properties[index];
/*     */     boolean canDeserialize;
/*     */     boolean canDeserialize;
/*  66 */     if (prop.hasTypePropertyName(propName)) {
/*  67 */       this._typeIds[index] = jp.getText();
/*  68 */       jp.skipChildren();
/*  69 */       canDeserialize = (bean != null) && (this._tokens[index] != null);
/*     */     } else {
/*  71 */       TokenBuffer tokens = new TokenBuffer(jp.getCodec());
/*  72 */       tokens.copyCurrentStructure(jp);
/*  73 */       this._tokens[index] = tokens;
/*  74 */       canDeserialize = (bean != null) && (this._typeIds[index] != null);
/*     */     }
/*     */ 
/*  79 */     if (canDeserialize) {
/*  80 */       _deserialize(jp, ctxt, bean, index);
/*     */ 
/*  82 */       this._typeIds[index] = null;
/*  83 */       this._tokens[index] = null;
/*     */     }
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */   public Object complete(JsonParser jp, DeserializationContext ctxt, Object bean)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  91 */     int i = 0; for (int len = this._properties.length; i < len; i++)
/*  92 */       if (this._typeIds[i] == null)
/*     */       {
/*  94 */         if (this._tokens[i] != null)
/*     */         {
/*  98 */           throw ctxt.mappingException("Missing external type id property '" + this._properties[i].getTypePropertyName());
/*     */         } } else { if (this._tokens[i] == null) {
/* 100 */           SettableBeanProperty prop = this._properties[i].getProperty();
/* 101 */           throw ctxt.mappingException("Missing property '" + prop.getName() + "' for external type id '" + this._properties[i].getTypePropertyName());
/*     */         }
/* 103 */         _deserialize(jp, ctxt, bean, i);
/*     */       }
/* 105 */     return bean;
/*     */   }
/*     */ 
/*     */   protected final void _deserialize(JsonParser jp, DeserializationContext ctxt, Object bean, int index)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 114 */     TokenBuffer merged = new TokenBuffer(jp.getCodec());
/* 115 */     merged.writeStartArray();
/* 116 */     merged.writeString(this._typeIds[index]);
/* 117 */     JsonParser p2 = this._tokens[index].asParser(jp);
/* 118 */     p2.nextToken();
/* 119 */     merged.copyCurrentStructure(p2);
/* 120 */     merged.writeEndArray();
/*     */ 
/* 122 */     p2 = merged.asParser(jp);
/* 123 */     p2.nextToken();
/* 124 */     this._properties[index].getProperty().deserializeAndSet(p2, ctxt, bean);
/*     */   }
/*     */ 
/*     */   private static final class ExtTypedProperty
/*     */   {
/*     */     private final SettableBeanProperty _property;
/*     */     private final String _typePropertyName;
/*     */ 
/*     */     public ExtTypedProperty(SettableBeanProperty property, String typePropertyName)
/*     */     {
/* 159 */       this._property = property;
/* 160 */       this._typePropertyName = typePropertyName;
/*     */     }
/*     */ 
/*     */     public boolean hasTypePropertyName(String n) {
/* 164 */       return n.equals(this._typePropertyName);
/*     */     }
/*     */     public String getTypePropertyName() {
/* 167 */       return this._typePropertyName;
/*     */     }
/*     */     public SettableBeanProperty getProperty() {
/* 170 */       return this._property;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Builder
/*     */   {
/* 135 */     private final ArrayList<ExternalTypeHandler.ExtTypedProperty> _properties = new ArrayList();
/* 136 */     private final HashMap<String, Integer> _nameToPropertyIndex = new HashMap();
/*     */ 
/*     */     public void addExternal(SettableBeanProperty property, String extPropName)
/*     */     {
/* 140 */       Integer index = Integer.valueOf(this._properties.size());
/* 141 */       this._properties.add(new ExternalTypeHandler.ExtTypedProperty(property, extPropName));
/* 142 */       this._nameToPropertyIndex.put(property.getName(), index);
/* 143 */       this._nameToPropertyIndex.put(extPropName, index);
/*     */     }
/*     */ 
/*     */     public ExternalTypeHandler build() {
/* 147 */       return new ExternalTypeHandler((ExternalTypeHandler.ExtTypedProperty[])this._properties.toArray(new ExternalTypeHandler.ExtTypedProperty[this._properties.size()]), this._nameToPropertyIndex, null, null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.impl.ExternalTypeHandler
 * JD-Core Version:    0.6.2
 */