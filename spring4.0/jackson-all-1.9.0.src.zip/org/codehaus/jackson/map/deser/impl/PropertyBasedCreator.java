/*     */ package org.codehaus.jackson.map.deser.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class PropertyBasedCreator
/*     */ {
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final HashMap<String, SettableBeanProperty> _properties;
/*     */   protected final Object[] _defaultValues;
/*     */   protected final SettableBeanProperty[] _propertiesWithInjectables;
/*     */ 
/*     */   public PropertyBasedCreator(ValueInstantiator valueInstantiator)
/*     */   {
/*  49 */     this._valueInstantiator = valueInstantiator;
/*  50 */     this._properties = new HashMap();
/*     */ 
/*  52 */     Object[] defValues = null;
/*  53 */     SettableBeanProperty[] creatorProps = valueInstantiator.getFromObjectArguments();
/*  54 */     SettableBeanProperty[] propertiesWithInjectables = null;
/*  55 */     int i = 0; for (int len = creatorProps.length; i < len; i++) {
/*  56 */       SettableBeanProperty prop = creatorProps[i];
/*  57 */       this._properties.put(prop.getName(), prop);
/*  58 */       if (prop.getType().isPrimitive()) {
/*  59 */         if (defValues == null) {
/*  60 */           defValues = new Object[len];
/*     */         }
/*  62 */         defValues[i] = ClassUtil.defaultValue(prop.getType().getRawClass());
/*     */       }
/*  64 */       Object injectableValueId = prop.getInjectableValueId();
/*  65 */       if (injectableValueId != null) {
/*  66 */         if (propertiesWithInjectables == null) {
/*  67 */           propertiesWithInjectables = new SettableBeanProperty[len];
/*     */         }
/*  69 */         propertiesWithInjectables[i] = prop;
/*     */       }
/*     */     }
/*  72 */     this._defaultValues = defValues;
/*  73 */     this._propertiesWithInjectables = propertiesWithInjectables;
/*     */   }
/*     */ 
/*     */   public Collection<SettableBeanProperty> getCreatorProperties() {
/*  77 */     return this._properties.values();
/*     */   }
/*     */ 
/*     */   public SettableBeanProperty findCreatorProperty(String name) {
/*  81 */     return (SettableBeanProperty)this._properties.get(name);
/*     */   }
/*     */ 
/*     */   public void assignDeserializer(SettableBeanProperty prop, JsonDeserializer<Object> deser) {
/*  85 */     prop = prop.withValueDeserializer(deser);
/*  86 */     this._properties.put(prop.getName(), prop);
/*     */   }
/*     */ 
/*     */   public PropertyValueBuffer startBuilding(JsonParser jp, DeserializationContext ctxt)
/*     */   {
/*  94 */     PropertyValueBuffer buffer = new PropertyValueBuffer(jp, ctxt, this._properties.size());
/*  95 */     if (this._propertiesWithInjectables != null) {
/*  96 */       buffer.inject(this._propertiesWithInjectables);
/*     */     }
/*  98 */     return buffer;
/*     */   }
/*     */ 
/*     */   public Object build(PropertyValueBuffer buffer) throws IOException
/*     */   {
/* 103 */     Object bean = this._valueInstantiator.createFromObjectWith(buffer.getParameters(this._defaultValues));
/*     */ 
/* 105 */     for (PropertyValue pv = buffer.buffered(); pv != null; pv = pv.next) {
/* 106 */       pv.assign(bean);
/*     */     }
/* 108 */     return bean;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.impl.PropertyBasedCreator
 * JD-Core Version:    0.6.2
 */