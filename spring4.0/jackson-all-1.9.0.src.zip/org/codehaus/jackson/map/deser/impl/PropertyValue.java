/*     */ package org.codehaus.jackson.map.deser.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.deser.SettableAnyProperty;
/*     */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*     */ 
/*     */ public abstract class PropertyValue
/*     */ {
/*     */   public final PropertyValue next;
/*     */   public final Object value;
/*     */ 
/*     */   protected PropertyValue(PropertyValue next, Object value)
/*     */   {
/*  23 */     this.next = next;
/*  24 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public abstract void assign(Object paramObject)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   static final class Map extends PropertyValue
/*     */   {
/*     */     final Object _key;
/*     */ 
/*     */     public Map(PropertyValue next, Object value, Object key)
/*     */     {
/* 104 */       super(value);
/* 105 */       this._key = key;
/*     */     }
/*     */ 
/*     */     public void assign(Object bean)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 113 */       ((Map)bean).put(this._key, this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class Any extends PropertyValue
/*     */   {
/*     */     final SettableAnyProperty _property;
/*     */     final String _propertyName;
/*     */ 
/*     */     public Any(PropertyValue next, Object value, SettableAnyProperty prop, String propName)
/*     */     {
/*  80 */       super(value);
/*  81 */       this._property = prop;
/*  82 */       this._propertyName = propName;
/*     */     }
/*     */ 
/*     */     public void assign(Object bean)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/*  89 */       this._property.set(bean, this._propertyName, this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class Regular extends PropertyValue
/*     */   {
/*     */     final SettableBeanProperty _property;
/*     */ 
/*     */     public Regular(PropertyValue next, Object value, SettableBeanProperty prop)
/*     */     {
/*  52 */       super(value);
/*  53 */       this._property = prop;
/*     */     }
/*     */ 
/*     */     public void assign(Object bean)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/*  60 */       this._property.set(bean, this.value);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.impl.PropertyValue
 * JD-Core Version:    0.6.2
 */