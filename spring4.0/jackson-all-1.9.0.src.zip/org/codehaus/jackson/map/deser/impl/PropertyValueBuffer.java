/*    */ package org.codehaus.jackson.map.deser.impl;
/*    */ 
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.deser.SettableAnyProperty;
/*    */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*    */ 
/*    */ public final class PropertyValueBuffer
/*    */ {
/*    */   final JsonParser _parser;
/*    */   final DeserializationContext _context;
/*    */   final Object[] _creatorParameters;
/*    */   private int _paramsNeeded;
/*    */   private PropertyValue _buffered;
/*    */ 
/*    */   public PropertyValueBuffer(JsonParser jp, DeserializationContext ctxt, int paramCount)
/*    */   {
/* 42 */     this._parser = jp;
/* 43 */     this._context = ctxt;
/* 44 */     this._paramsNeeded = paramCount;
/* 45 */     this._creatorParameters = new Object[paramCount];
/*    */   }
/*    */ 
/*    */   public void inject(SettableBeanProperty[] injectableProperties)
/*    */   {
/* 50 */     int i = 0; for (int len = injectableProperties.length; i < len; i++) {
/* 51 */       SettableBeanProperty prop = injectableProperties[i];
/* 52 */       if (prop != null)
/*    */       {
/* 54 */         this._creatorParameters[i] = this._context.findInjectableValue(prop.getInjectableValueId(), prop, null);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   protected final Object[] getParameters(Object[] defaults)
/*    */   {
/* 67 */     if (defaults != null) {
/* 68 */       int i = 0; for (int len = this._creatorParameters.length; i < len; i++) {
/* 69 */         if (this._creatorParameters[i] == null) {
/* 70 */           Object value = defaults[i];
/* 71 */           if (value != null) {
/* 72 */             this._creatorParameters[i] = value;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 77 */     return this._creatorParameters;
/*    */   }
/*    */   protected PropertyValue buffered() {
/* 80 */     return this._buffered;
/*    */   }
/*    */ 
/*    */   public boolean assignParameter(int index, Object value)
/*    */   {
/* 86 */     this._creatorParameters[index] = value;
/* 87 */     return --this._paramsNeeded <= 0;
/*    */   }
/*    */ 
/*    */   public void bufferProperty(SettableBeanProperty prop, Object value) {
/* 91 */     this._buffered = new PropertyValue.Regular(this._buffered, value, prop);
/*    */   }
/*    */ 
/*    */   public void bufferAnyProperty(SettableAnyProperty prop, String propName, Object value) {
/* 95 */     this._buffered = new PropertyValue.Any(this._buffered, value, prop, propName);
/*    */   }
/*    */ 
/*    */   public void bufferMapProperty(Object key, Object value) {
/* 99 */     this._buffered = new PropertyValue.Map(this._buffered, value, key);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.impl.PropertyValueBuffer
 * JD-Core Version:    0.6.2
 */