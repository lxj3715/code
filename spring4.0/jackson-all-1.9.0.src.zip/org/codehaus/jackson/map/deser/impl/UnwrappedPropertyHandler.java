/*    */ package org.codehaus.jackson.map.deser.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*    */ import org.codehaus.jackson.util.TokenBuffer;
/*    */ 
/*    */ public class UnwrappedPropertyHandler
/*    */ {
/* 21 */   protected final ArrayList<SettableBeanProperty> _properties = new ArrayList();
/*    */ 
/*    */   public void addProperty(SettableBeanProperty property)
/*    */   {
/* 26 */     this._properties.add(property);
/*    */   }
/*    */ 
/*    */   public Object processUnwrapped(JsonParser originalParser, DeserializationContext ctxt, Object bean, TokenBuffer buffered)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 33 */     int i = 0; for (int len = this._properties.size(); i < len; i++) {
/* 34 */       SettableBeanProperty prop = (SettableBeanProperty)this._properties.get(i);
/* 35 */       JsonParser jp = buffered.asParser();
/* 36 */       jp.nextToken();
/* 37 */       prop.deserializeAndSet(jp, ctxt, bean);
/*    */     }
/* 39 */     return bean;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.impl.UnwrappedPropertyHandler
 * JD-Core Version:    0.6.2
 */