/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.DeserializationConfig;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.DeserializerProvider;
/*    */ import org.codehaus.jackson.map.JsonDeserializer;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.ResolvableDeserializer;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class AtomicReferenceDeserializer extends StdScalarDeserializer<AtomicReference<?>>
/*    */   implements ResolvableDeserializer
/*    */ {
/*    */   protected final JavaType _referencedType;
/*    */   protected final BeanProperty _property;
/*    */   protected JsonDeserializer<?> _valueDeserializer;
/*    */ 
/*    */   public AtomicReferenceDeserializer(JavaType referencedType, BeanProperty property)
/*    */   {
/* 29 */     super(AtomicReference.class);
/* 30 */     this._referencedType = referencedType;
/* 31 */     this._property = property;
/*    */   }
/*    */ 
/*    */   public AtomicReference<?> deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 38 */     return new AtomicReference(this._valueDeserializer.deserialize(jp, ctxt));
/*    */   }
/*    */ 
/*    */   public void resolve(DeserializationConfig config, DeserializerProvider provider)
/*    */     throws JsonMappingException
/*    */   {
/* 45 */     this._valueDeserializer = provider.findValueDeserializer(config, this._referencedType, this._property);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.AtomicReferenceDeserializer
 * JD-Core Version:    0.6.2
 */