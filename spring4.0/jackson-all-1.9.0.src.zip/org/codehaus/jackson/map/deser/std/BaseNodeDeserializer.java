/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonParser.NumberType;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.node.ArrayNode;
/*     */ import org.codehaus.jackson.node.JsonNodeFactory;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ 
/*     */ abstract class BaseNodeDeserializer<N extends JsonNode> extends StdDeserializer<N>
/*     */ {
/*     */   public BaseNodeDeserializer(Class<N> nodeClass)
/*     */   {
/* 130 */     super(nodeClass);
/*     */   }
/*     */ 
/*     */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 141 */     return typeDeserializer.deserializeTypedFromAny(jp, ctxt);
/*     */   }
/*     */ 
/*     */   protected void _reportProblem(JsonParser jp, String msg)
/*     */     throws JsonMappingException
/*     */   {
/* 153 */     throw new JsonMappingException(msg, jp.getTokenLocation());
/*     */   }
/*     */ 
/*     */   protected void _handleDuplicateField(String fieldName, ObjectNode objectNode, JsonNode oldValue, JsonNode newValue)
/*     */     throws JsonProcessingException
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final ObjectNode deserializeObject(JsonParser jp, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 187 */     ObjectNode node = nodeFactory.objectNode();
/* 188 */     JsonToken t = jp.getCurrentToken();
/* 189 */     if (t == JsonToken.START_OBJECT);
/* 190 */     for (t = jp.nextToken(); 
/* 192 */       t == JsonToken.FIELD_NAME; t = jp.nextToken()) {
/* 193 */       String fieldName = jp.getCurrentName();
/*     */       JsonNode value;
/* 195 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[jp.nextToken().ordinal()]) {
/*     */       case 1:
/* 197 */         value = deserializeObject(jp, ctxt, nodeFactory);
/* 198 */         break;
/*     */       case 2:
/* 200 */         value = deserializeArray(jp, ctxt, nodeFactory);
/* 201 */         break;
/*     */       case 3:
/* 203 */         value = nodeFactory.textNode(jp.getText());
/* 204 */         break;
/*     */       default:
/* 206 */         value = deserializeAny(jp, ctxt, nodeFactory);
/*     */       }
/* 208 */       JsonNode old = node.put(fieldName, value);
/* 209 */       if (old != null) {
/* 210 */         _handleDuplicateField(fieldName, node, old, value);
/*     */       }
/*     */     }
/* 213 */     return node;
/*     */   }
/*     */ 
/*     */   protected final ArrayNode deserializeArray(JsonParser jp, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 220 */     ArrayNode node = nodeFactory.arrayNode();
/*     */     while (true)
/* 222 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[jp.nextToken().ordinal()]) {
/*     */       case 1:
/* 224 */         node.add(deserializeObject(jp, ctxt, nodeFactory));
/* 225 */         break;
/*     */       case 2:
/* 227 */         node.add(deserializeArray(jp, ctxt, nodeFactory));
/* 228 */         break;
/*     */       case 4:
/* 230 */         return node;
/*     */       case 3:
/* 232 */         node.add(nodeFactory.textNode(jp.getText()));
/* 233 */         break;
/*     */       default:
/* 235 */         node.add(deserializeAny(jp, ctxt, nodeFactory));
/*     */       }
/*     */   }
/*     */ 
/*     */   protected final JsonNode deserializeAny(JsonParser jp, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 245 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[jp.getCurrentToken().ordinal()]) {
/*     */     case 1:
/* 247 */       return deserializeObject(jp, ctxt, nodeFactory);
/*     */     case 2:
/* 250 */       return deserializeArray(jp, ctxt, nodeFactory);
/*     */     case 5:
/* 253 */       return deserializeObject(jp, ctxt, nodeFactory);
/*     */     case 6:
/* 256 */       return nodeFactory.POJONode(jp.getEmbeddedObject());
/*     */     case 3:
/* 259 */       return nodeFactory.textNode(jp.getText());
/*     */     case 7:
/* 263 */       JsonParser.NumberType nt = jp.getNumberType();
/* 264 */       if ((nt == JsonParser.NumberType.BIG_INTEGER) || (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_INTEGER_FOR_INTS)))
/*     */       {
/* 266 */         return nodeFactory.numberNode(jp.getBigIntegerValue());
/*     */       }
/* 268 */       if (nt == JsonParser.NumberType.INT) {
/* 269 */         return nodeFactory.numberNode(jp.getIntValue());
/*     */       }
/* 271 */       return nodeFactory.numberNode(jp.getLongValue());
/*     */     case 8:
/* 276 */       JsonParser.NumberType nt = jp.getNumberType();
/* 277 */       if ((nt == JsonParser.NumberType.BIG_DECIMAL) || (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_DECIMAL_FOR_FLOATS)))
/*     */       {
/* 279 */         return nodeFactory.numberNode(jp.getDecimalValue());
/*     */       }
/* 281 */       return nodeFactory.numberNode(jp.getDoubleValue());
/*     */     case 9:
/* 285 */       return nodeFactory.booleanNode(true);
/*     */     case 10:
/* 288 */       return nodeFactory.booleanNode(false);
/*     */     case 11:
/* 291 */       return nodeFactory.nullNode();
/*     */     case 4:
/*     */     }
/*     */ 
/* 299 */     throw ctxt.mappingException(getValueClass());
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.BaseNodeDeserializer
 * JD-Core Version:    0.6.2
 */