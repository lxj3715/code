/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class CalendarDeserializer extends StdScalarDeserializer<Calendar>
/*    */ {
/*    */   protected final Class<? extends Calendar> _calendarClass;
/*    */ 
/*    */   public CalendarDeserializer()
/*    */   {
/* 22 */     this(null);
/*    */   }
/* 24 */   public CalendarDeserializer(Class<? extends Calendar> cc) { super(Calendar.class);
/* 25 */     this._calendarClass = cc;
/*    */   }
/*    */ 
/*    */   public Calendar deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 32 */     Date d = _parseDate(jp, ctxt);
/* 33 */     if (d == null) {
/* 34 */       return null;
/*    */     }
/* 36 */     if (this._calendarClass == null)
/* 37 */       return ctxt.constructCalendar(d);
/*    */     try
/*    */     {
/* 40 */       Calendar c = (Calendar)this._calendarClass.newInstance();
/* 41 */       c.setTimeInMillis(d.getTime());
/* 42 */       return c;
/*    */     } catch (Exception e) {
/* 44 */       throw ctxt.instantiationException(this._calendarClass, e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.CalendarDeserializer
 * JD-Core Version:    0.6.2
 */