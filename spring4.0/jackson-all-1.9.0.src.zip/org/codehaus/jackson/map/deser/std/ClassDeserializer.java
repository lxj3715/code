/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class ClassDeserializer extends StdScalarDeserializer<Class<?>>
/*    */ {
/*    */   public ClassDeserializer()
/*    */   {
/* 19 */     super(Class.class);
/*    */   }
/*    */ 
/*    */   public Class<?> deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 25 */     JsonToken curr = jp.getCurrentToken();
/*    */ 
/* 27 */     if (curr == JsonToken.VALUE_STRING) {
/* 28 */       String className = jp.getText();
/*    */ 
/* 30 */       if (className.indexOf('.') < 0) {
/* 31 */         if ("int".equals(className)) return Integer.TYPE;
/* 32 */         if ("long".equals(className)) return Long.TYPE;
/* 33 */         if ("float".equals(className)) return Float.TYPE;
/* 34 */         if ("double".equals(className)) return Double.TYPE;
/* 35 */         if ("boolean".equals(className)) return Boolean.TYPE;
/* 36 */         if ("byte".equals(className)) return Byte.TYPE;
/* 37 */         if ("char".equals(className)) return Character.TYPE;
/* 38 */         if ("short".equals(className)) return Short.TYPE;
/* 39 */         if ("void".equals(className)) return Void.TYPE; 
/*    */       }
/*    */       try
/*    */       {
/* 42 */         return Class.forName(jp.getText());
/*    */       } catch (ClassNotFoundException e) {
/* 44 */         throw ctxt.instantiationException(this._valueClass, e);
/*    */       }
/*    */     }
/* 47 */     throw ctxt.mappingException(this._valueClass, curr);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.ClassDeserializer
 * JD-Core Version:    0.6.2
 */