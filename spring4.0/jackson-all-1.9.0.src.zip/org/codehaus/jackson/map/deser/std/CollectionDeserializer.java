/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Collection;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.BeanProperty.Std;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.ResolvableDeserializer;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedConstructor;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedWithParams;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class CollectionDeserializer extends ContainerDeserializerBase<Collection<Object>>
/*     */   implements ResolvableDeserializer
/*     */ {
/*     */   protected final JavaType _collectionType;
/*     */   protected final JsonDeserializer<Object> _valueDeserializer;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected JsonDeserializer<Object> _delegateDeserializer;
/*     */ 
/*     */   @Deprecated
/*     */   protected CollectionDeserializer(JavaType collectionType, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, Constructor<Collection<Object>> defCtor)
/*     */   {
/*  79 */     super(collectionType.getRawClass());
/*  80 */     this._collectionType = collectionType;
/*  81 */     this._valueDeserializer = valueDeser;
/*  82 */     this._valueTypeDeserializer = valueTypeDeser;
/*     */ 
/*  84 */     StdValueInstantiator inst = new StdValueInstantiator(null, collectionType);
/*  85 */     if (defCtor != null) {
/*  86 */       AnnotatedConstructor aCtor = new AnnotatedConstructor(defCtor, null, null);
/*     */ 
/*  88 */       inst.configureFromObjectSettings(aCtor, null, null, null, null);
/*     */     }
/*  90 */     this._valueInstantiator = inst;
/*     */   }
/*     */ 
/*     */   public CollectionDeserializer(JavaType collectionType, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, ValueInstantiator valueInstantiator)
/*     */   {
/*  99 */     super(collectionType.getRawClass());
/* 100 */     this._collectionType = collectionType;
/* 101 */     this._valueDeserializer = valueDeser;
/* 102 */     this._valueTypeDeserializer = valueTypeDeser;
/* 103 */     this._valueInstantiator = valueInstantiator;
/*     */   }
/*     */ 
/*     */   protected CollectionDeserializer(CollectionDeserializer src)
/*     */   {
/* 114 */     super(src._valueClass);
/* 115 */     this._collectionType = src._collectionType;
/* 116 */     this._valueDeserializer = src._valueDeserializer;
/* 117 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 118 */     this._valueInstantiator = src._valueInstantiator;
/* 119 */     this._delegateDeserializer = src._delegateDeserializer;
/*     */   }
/*     */ 
/*     */   public void resolve(DeserializationConfig config, DeserializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 138 */     if (this._valueInstantiator.canCreateUsingDelegate()) {
/* 139 */       JavaType delegateType = this._valueInstantiator.getDelegateType();
/* 140 */       if (delegateType == null) {
/* 141 */         throw new IllegalArgumentException("Invalid delegate-creator definition for " + this._collectionType + ": value instantiator (" + this._valueInstantiator.getClass().getName() + ") returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'");
/*     */       }
/*     */ 
/* 145 */       AnnotatedWithParams delegateCreator = this._valueInstantiator.getDelegateCreator();
/*     */ 
/* 148 */       BeanProperty.Std property = new BeanProperty.Std(null, delegateType, null, delegateCreator);
/*     */ 
/* 150 */       this._delegateDeserializer = findDeserializer(config, provider, delegateType, property);
/*     */     }
/*     */   }
/*     */ 
/*     */   public JavaType getContentType()
/*     */   {
/* 162 */     return this._collectionType.getContentType();
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> getContentDeserializer()
/*     */   {
/* 167 */     return this._valueDeserializer;
/*     */   }
/*     */ 
/*     */   public Collection<Object> deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 181 */     if (this._delegateDeserializer != null) {
/* 182 */       return (Collection)this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*     */     }
/*     */ 
/* 188 */     if (jp.getCurrentToken() == JsonToken.VALUE_STRING) {
/* 189 */       String str = jp.getText();
/* 190 */       if (str.length() == 0) {
/* 191 */         return (Collection)this._valueInstantiator.createFromString(str);
/*     */       }
/*     */     }
/* 194 */     return deserialize(jp, ctxt, (Collection)this._valueInstantiator.createUsingDefault());
/*     */   }
/*     */ 
/*     */   public Collection<Object> deserialize(JsonParser jp, DeserializationContext ctxt, Collection<Object> result)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 203 */     if (!jp.isExpectedStartArrayToken()) {
/* 204 */       return handleNonArray(jp, ctxt, result);
/*     */     }
/*     */ 
/* 207 */     JsonDeserializer valueDes = this._valueDeserializer;
/*     */ 
/* 209 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*     */     JsonToken t;
/* 211 */     while ((t = jp.nextToken()) != JsonToken.END_ARRAY)
/*     */     {
/*     */       Object value;
/*     */       Object value;
/* 214 */       if (t == JsonToken.VALUE_NULL) {
/* 215 */         value = null;
/*     */       }
/*     */       else
/*     */       {
/*     */         Object value;
/* 216 */         if (typeDeser == null)
/* 217 */           value = valueDes.deserialize(jp, ctxt);
/*     */         else
/* 219 */           value = valueDes.deserializeWithType(jp, ctxt, typeDeser);
/*     */       }
/* 221 */       result.add(value);
/*     */     }
/* 223 */     return result;
/*     */   }
/*     */ 
/*     */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 232 */     return typeDeserializer.deserializeTypedFromArray(jp, ctxt);
/*     */   }
/*     */ 
/*     */   private final Collection<Object> handleNonArray(JsonParser jp, DeserializationContext ctxt, Collection<Object> result)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 245 */     if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 246 */       throw ctxt.mappingException(this._collectionType.getRawClass());
/*     */     }
/* 248 */     JsonDeserializer valueDes = this._valueDeserializer;
/* 249 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/* 250 */     JsonToken t = jp.getCurrentToken();
/*     */     Object value;
/*     */     Object value;
/* 254 */     if (t == JsonToken.VALUE_NULL) {
/* 255 */       value = null;
/*     */     }
/*     */     else
/*     */     {
/*     */       Object value;
/* 256 */       if (typeDeser == null)
/* 257 */         value = valueDes.deserialize(jp, ctxt);
/*     */       else
/* 259 */         value = valueDes.deserializeWithType(jp, ctxt, typeDeser);
/*     */     }
/* 261 */     result.add(value);
/* 262 */     return result;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.CollectionDeserializer
 * JD-Core Version:    0.6.2
 */