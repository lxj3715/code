/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import org.codehaus.jackson.map.JsonDeserializer;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public abstract class ContainerDeserializerBase<T> extends StdDeserializer<T>
/*    */ {
/*    */   protected ContainerDeserializerBase(Class<?> selfType)
/*    */   {
/* 18 */     super(selfType);
/*    */   }
/*    */ 
/*    */   public abstract JavaType getContentType();
/*    */ 
/*    */   public abstract JsonDeserializer<Object> getContentDeserializer();
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.ContainerDeserializerBase
 * JD-Core Version:    0.6.2
 */