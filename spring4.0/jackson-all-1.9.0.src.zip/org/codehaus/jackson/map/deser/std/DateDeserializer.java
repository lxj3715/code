/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Date;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ 
/*    */ public class DateDeserializer extends StdScalarDeserializer<Date>
/*    */ {
/*    */   public DateDeserializer()
/*    */   {
/* 22 */     super(Date.class);
/*    */   }
/*    */ 
/*    */   public Date deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 28 */     return _parseDate(jp, ctxt);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.DateDeserializer
 * JD-Core Version:    0.6.2
 */