/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.annotate.JsonCachable;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.map.util.EnumResolver;
/*     */ 
/*     */ @JsonCachable
/*     */ public class EnumDeserializer extends StdScalarDeserializer<Enum<?>>
/*     */ {
/*     */   protected final EnumResolver<?> _resolver;
/*     */ 
/*     */   public EnumDeserializer(EnumResolver<?> res)
/*     */   {
/*  31 */     super(Enum.class);
/*  32 */     this._resolver = res;
/*     */   }
/*     */ 
/*     */   public static JsonDeserializer<?> deserializerForCreator(DeserializationConfig config, Class<?> enumClass, AnnotatedMethod factory)
/*     */   {
/*  48 */     if (factory.getParameterType(0) != String.class) {
/*  49 */       throw new IllegalArgumentException("Parameter #0 type for factory method (" + factory + ") not suitable, must be java.lang.String");
/*     */     }
/*  51 */     if (config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/*  52 */       ClassUtil.checkAndFixAccess(factory.getMember());
/*     */     }
/*  54 */     return new FactoryBasedDeserializer(enumClass, factory);
/*     */   }
/*     */ 
/*     */   public Enum<?> deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  67 */     JsonToken curr = jp.getCurrentToken();
/*     */ 
/*  70 */     if (curr == JsonToken.VALUE_STRING) {
/*  71 */       String name = jp.getText();
/*  72 */       Enum result = this._resolver.findEnum(name);
/*  73 */       if (result == null) {
/*  74 */         throw ctxt.weirdStringException(this._resolver.getEnumClass(), "value not one of declared Enum instance names");
/*     */       }
/*  76 */       return result;
/*     */     }
/*     */ 
/*  79 */     if (curr == JsonToken.VALUE_NUMBER_INT)
/*     */     {
/*  83 */       if (ctxt.isEnabled(DeserializationConfig.Feature.FAIL_ON_NUMBERS_FOR_ENUMS)) {
/*  84 */         throw ctxt.mappingException("Not allowed to deserialize Enum value out of JSON number (disable DeserializationConfig.Feature.FAIL_ON_NUMBERS_FOR_ENUMS to allow)");
/*     */       }
/*     */ 
/*  87 */       int index = jp.getIntValue();
/*  88 */       Enum result = this._resolver.getEnum(index);
/*  89 */       if (result == null) {
/*  90 */         throw ctxt.weirdNumberException(this._resolver.getEnumClass(), "index value outside legal index range [0.." + this._resolver.lastValidIndex() + "]");
/*     */       }
/*  92 */       return result;
/*     */     }
/*  94 */     throw ctxt.mappingException(this._resolver.getEnumClass());
/*     */   }
/*     */ 
/*     */   protected static class FactoryBasedDeserializer extends StdScalarDeserializer<Object>
/*     */   {
/*     */     protected final Class<?> _enumClass;
/*     */     protected final Method _factory;
/*     */ 
/*     */     public FactoryBasedDeserializer(Class<?> cls, AnnotatedMethod f)
/*     */     {
/* 115 */       super();
/* 116 */       this._enumClass = cls;
/* 117 */       this._factory = f.getAnnotated();
/*     */     }
/*     */ 
/*     */     public Object deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 124 */       JsonToken curr = jp.getCurrentToken();
/*     */ 
/* 127 */       if (curr != JsonToken.VALUE_STRING) {
/* 128 */         throw ctxt.mappingException(this._enumClass);
/*     */       }
/* 130 */       String value = jp.getText();
/*     */       try {
/* 132 */         return this._factory.invoke(this._enumClass, new Object[] { value });
/*     */       } catch (Exception e) {
/* 134 */         ClassUtil.unwrapAndThrowAsIAE(e);
/*     */       }
/* 136 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.EnumDeserializer
 * JD-Core Version:    0.6.2
 */