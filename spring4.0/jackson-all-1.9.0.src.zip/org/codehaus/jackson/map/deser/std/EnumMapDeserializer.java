/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.EnumMap;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.JsonDeserializer;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.map.util.EnumResolver;
/*    */ 
/*    */ public class EnumMapDeserializer extends StdDeserializer<EnumMap<?, ?>>
/*    */ {
/*    */   protected final EnumResolver<?> _enumResolver;
/*    */   protected final JsonDeserializer<Object> _valueDeserializer;
/*    */ 
/*    */   public EnumMapDeserializer(EnumResolver<?> enumRes, JsonDeserializer<Object> valueDes)
/*    */   {
/* 35 */     super(EnumMap.class);
/* 36 */     this._enumResolver = enumRes;
/* 37 */     this._valueDeserializer = valueDes;
/*    */   }
/*    */ 
/*    */   public EnumMap<?, ?> deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 45 */     if (jp.getCurrentToken() != JsonToken.START_OBJECT) {
/* 46 */       throw ctxt.mappingException(EnumMap.class);
/*    */     }
/* 48 */     EnumMap result = constructMap();
/*    */ 
/* 50 */     while (jp.nextToken() != JsonToken.END_OBJECT) {
/* 51 */       String fieldName = jp.getCurrentName();
/* 52 */       Enum key = this._enumResolver.findEnum(fieldName);
/* 53 */       if (key == null) {
/* 54 */         throw ctxt.weirdStringException(this._enumResolver.getEnumClass(), "value not one of declared Enum instance names");
/*    */       }
/*    */ 
/* 57 */       JsonToken t = jp.nextToken();
/*    */ 
/* 61 */       Object value = t == JsonToken.VALUE_NULL ? null : this._valueDeserializer.deserialize(jp, ctxt);
/*    */ 
/* 63 */       result.put(key, value);
/*    */     }
/* 65 */     return result;
/*    */   }
/*    */ 
/*    */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 74 */     return typeDeserializer.deserializeTypedFromObject(jp, ctxt);
/*    */   }
/*    */ 
/*    */   private EnumMap<?, ?> constructMap()
/*    */   {
/* 79 */     Class enumCls = this._enumResolver.getEnumClass();
/* 80 */     return new EnumMap(enumCls);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.EnumMapDeserializer
 * JD-Core Version:    0.6.2
 */