/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.EnumSet;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.map.util.EnumResolver;
/*    */ 
/*    */ public class EnumSetDeserializer extends StdDeserializer<EnumSet<?>>
/*    */ {
/*    */   protected final Class<Enum> _enumClass;
/*    */   protected final EnumDeserializer _enumDeserializer;
/*    */ 
/*    */   public EnumSetDeserializer(EnumResolver enumRes)
/*    */   {
/* 34 */     super(EnumSet.class);
/* 35 */     this._enumDeserializer = new EnumDeserializer(enumRes);
/*    */ 
/* 37 */     this._enumClass = enumRes.getEnumClass();
/*    */   }
/*    */ 
/*    */   public EnumSet<?> deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 46 */     if (!jp.isExpectedStartArrayToken()) {
/* 47 */       throw ctxt.mappingException(EnumSet.class);
/*    */     }
/* 49 */     EnumSet result = constructSet();
/*    */     JsonToken t;
/* 52 */     while ((t = jp.nextToken()) != JsonToken.END_ARRAY)
/*    */     {
/* 58 */       if (t == JsonToken.VALUE_NULL) {
/* 59 */         throw ctxt.mappingException(this._enumClass);
/*    */       }
/* 61 */       Enum value = this._enumDeserializer.deserialize(jp, ctxt);
/* 62 */       result.add(value);
/*    */     }
/* 64 */     return result;
/*    */   }
/*    */ 
/*    */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 72 */     return typeDeserializer.deserializeTypedFromArray(jp, ctxt);
/*    */   }
/*    */ 
/*    */   private EnumSet constructSet()
/*    */   {
/* 79 */     return EnumSet.noneOf(this._enumClass);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.EnumSetDeserializer
 * JD-Core Version:    0.6.2
 */