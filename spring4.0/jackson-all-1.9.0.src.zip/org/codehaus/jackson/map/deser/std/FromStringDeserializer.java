/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Currency;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.UUID;
/*     */ import java.util.regex.Pattern;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ 
/*     */ public abstract class FromStringDeserializer<T> extends StdScalarDeserializer<T>
/*     */ {
/*     */   protected FromStringDeserializer(Class<?> vc)
/*     */   {
/*  25 */     super(vc);
/*     */   }
/*     */ 
/*     */   public static Iterable<FromStringDeserializer<?>> all()
/*     */   {
/*  30 */     ArrayList all = new ArrayList();
/*     */ 
/*  32 */     all.add(new UUIDDeserializer());
/*  33 */     all.add(new URLDeserializer());
/*  34 */     all.add(new URIDeserializer());
/*  35 */     all.add(new CurrencyDeserializer());
/*  36 */     all.add(new PatternDeserializer());
/*     */ 
/*  38 */     all.add(new LocaleDeserializer());
/*     */ 
/*  40 */     all.add(new InetAddressDeserializer());
/*  41 */     all.add(new TimeZoneDeserializer());
/*     */ 
/*  43 */     return all;
/*     */   }
/*     */ 
/*     */   public final T deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  51 */     if (jp.getCurrentToken() == JsonToken.VALUE_STRING) {
/*  52 */       String text = jp.getText().trim();
/*     */ 
/*  54 */       if (text.length() == 0)
/*  55 */         return null;
/*     */       try
/*     */       {
/*  58 */         Object result = _deserialize(text, ctxt);
/*  59 */         if (result != null)
/*  60 */           return result;
/*     */       }
/*     */       catch (IllegalArgumentException iae)
/*     */       {
/*     */       }
/*  65 */       throw ctxt.weirdStringException(this._valueClass, "not a valid textual representation");
/*     */     }
/*  67 */     if (jp.getCurrentToken() == JsonToken.VALUE_EMBEDDED_OBJECT)
/*     */     {
/*  69 */       Object ob = jp.getEmbeddedObject();
/*  70 */       if (ob == null) {
/*  71 */         return null;
/*     */       }
/*  73 */       if (this._valueClass.isAssignableFrom(ob.getClass())) {
/*  74 */         return ob;
/*     */       }
/*  76 */       return _deserializeEmbedded(ob, ctxt);
/*     */     }
/*  78 */     throw ctxt.mappingException(this._valueClass);
/*     */   }
/*     */ 
/*     */   protected abstract T _deserialize(String paramString, DeserializationContext paramDeserializationContext)
/*     */     throws IOException, JsonProcessingException;
/*     */ 
/*     */   protected T _deserializeEmbedded(Object ob, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  88 */     throw ctxt.mappingException("Don't know how to convert embedded Object of type " + ob.getClass().getName() + " into " + this._valueClass.getName());
/*     */   }
/*     */ 
/*     */   protected static class TimeZoneDeserializer extends FromStringDeserializer<TimeZone>
/*     */   {
/*     */     public TimeZoneDeserializer()
/*     */     {
/* 239 */       super();
/*     */     }
/*     */ 
/*     */     protected TimeZone _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 245 */       return TimeZone.getTimeZone(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class InetAddressDeserializer extends FromStringDeserializer<InetAddress>
/*     */   {
/*     */     public InetAddressDeserializer()
/*     */     {
/* 221 */       super();
/*     */     }
/*     */ 
/*     */     protected InetAddress _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 227 */       return InetAddress.getByName(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class LocaleDeserializer extends FromStringDeserializer<Locale>
/*     */   {
/*     */     public LocaleDeserializer()
/*     */     {
/* 192 */       super();
/*     */     }
/*     */ 
/*     */     protected Locale _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 198 */       int ix = value.indexOf('_');
/* 199 */       if (ix < 0) {
/* 200 */         return new Locale(value);
/*     */       }
/* 202 */       String first = value.substring(0, ix);
/* 203 */       value = value.substring(ix + 1);
/* 204 */       ix = value.indexOf('_');
/* 205 */       if (ix < 0) {
/* 206 */         return new Locale(first, value);
/*     */       }
/* 208 */       String second = value.substring(0, ix);
/* 209 */       return new Locale(first, second, value.substring(ix + 1));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class PatternDeserializer extends FromStringDeserializer<Pattern>
/*     */   {
/*     */     public PatternDeserializer()
/*     */     {
/* 173 */       super();
/*     */     }
/*     */ 
/*     */     protected Pattern _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IllegalArgumentException
/*     */     {
/* 180 */       return Pattern.compile(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class CurrencyDeserializer extends FromStringDeserializer<Currency>
/*     */   {
/*     */     public CurrencyDeserializer()
/*     */     {
/* 159 */       super();
/*     */     }
/*     */ 
/*     */     protected Currency _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IllegalArgumentException
/*     */     {
/* 166 */       return Currency.getInstance(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class URIDeserializer extends FromStringDeserializer<URI>
/*     */   {
/*     */     public URIDeserializer()
/*     */     {
/* 146 */       super();
/*     */     }
/*     */ 
/*     */     protected URI _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IllegalArgumentException
/*     */     {
/* 152 */       return URI.create(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class URLDeserializer extends FromStringDeserializer<URL>
/*     */   {
/*     */     public URLDeserializer()
/*     */     {
/* 133 */       super();
/*     */     }
/*     */ 
/*     */     protected URL _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 139 */       return new URL(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class UUIDDeserializer extends FromStringDeserializer<UUID>
/*     */   {
/*     */     public UUIDDeserializer()
/*     */     {
/* 101 */       super();
/*     */     }
/*     */ 
/*     */     protected UUID _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 107 */       return UUID.fromString(value);
/*     */     }
/*     */ 
/*     */     protected UUID _deserializeEmbedded(Object ob, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 114 */       if ((ob instanceof byte[])) {
/* 115 */         byte[] bytes = (byte[])ob;
/* 116 */         if (bytes.length != 16) {
/* 117 */           ctxt.mappingException("Can only construct UUIDs from 16 byte arrays; got " + bytes.length + " bytes");
/*     */         }
/*     */ 
/* 120 */         DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes));
/* 121 */         long l1 = in.readLong();
/* 122 */         long l2 = in.readLong();
/* 123 */         return new UUID(l1, l2);
/*     */       }
/* 125 */       super._deserializeEmbedded(ob, ctxt);
/* 126 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.FromStringDeserializer
 * JD-Core Version:    0.6.2
 */