/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.type.TypeFactory;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class JavaTypeDeserializer extends StdScalarDeserializer<JavaType>
/*    */ {
/*    */   public JavaTypeDeserializer()
/*    */   {
/* 17 */     super(JavaType.class);
/*    */   }
/*    */ 
/*    */   public JavaType deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 23 */     JsonToken curr = jp.getCurrentToken();
/*    */ 
/* 25 */     if (curr == JsonToken.VALUE_STRING) {
/* 26 */       String str = jp.getText().trim();
/* 27 */       if (str.length() == 0) {
/* 28 */         return (JavaType)getEmptyValue();
/*    */       }
/* 30 */       return ctxt.getTypeFactory().constructFromCanonical(str);
/*    */     }
/*    */ 
/* 33 */     if (curr == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 34 */       return (JavaType)jp.getEmbeddedObject();
/*    */     }
/* 36 */     throw ctxt.mappingException(this._valueClass);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.JavaTypeDeserializer
 * JD-Core Version:    0.6.2
 */