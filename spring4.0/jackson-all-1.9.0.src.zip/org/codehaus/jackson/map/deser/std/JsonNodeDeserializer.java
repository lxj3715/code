/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.node.ArrayNode;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ 
/*     */ public class JsonNodeDeserializer extends BaseNodeDeserializer<JsonNode>
/*     */ {
/*  22 */   private static final JsonNodeDeserializer instance = new JsonNodeDeserializer();
/*     */ 
/*  24 */   protected JsonNodeDeserializer() { super(JsonNode.class); }
/*     */ 
/*     */ 
/*     */   public static JsonDeserializer<? extends JsonNode> getDeserializer(Class<?> nodeClass)
/*     */   {
/*  31 */     if (nodeClass == ObjectNode.class) {
/*  32 */       return ObjectDeserializer.getInstance();
/*     */     }
/*  34 */     if (nodeClass == ArrayNode.class) {
/*  35 */       return ArrayDeserializer.getInstance();
/*     */     }
/*     */ 
/*  38 */     return instance;
/*     */   }
/*     */ 
/*     */   public JsonNode deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  56 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[jp.getCurrentToken().ordinal()]) {
/*     */     case 1:
/*  58 */       return deserializeObject(jp, ctxt, ctxt.getNodeFactory());
/*     */     case 2:
/*  60 */       return deserializeArray(jp, ctxt, ctxt.getNodeFactory());
/*     */     }
/*  62 */     return deserializeAny(jp, ctxt, ctxt.getNodeFactory());
/*     */   }
/*     */ 
/*     */   static final class ArrayDeserializer extends BaseNodeDeserializer<ArrayNode>
/*     */   {
/* 101 */     protected static final ArrayDeserializer _instance = new ArrayDeserializer();
/*     */ 
/*     */     protected ArrayDeserializer() {
/* 104 */       super();
/*     */     }
/*     */     public static ArrayDeserializer getInstance() {
/* 107 */       return _instance;
/*     */     }
/*     */ 
/*     */     public ArrayNode deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 113 */       if (jp.isExpectedStartArrayToken()) {
/* 114 */         return deserializeArray(jp, ctxt, ctxt.getNodeFactory());
/*     */       }
/* 116 */       throw ctxt.mappingException(ArrayNode.class);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class ObjectDeserializer extends BaseNodeDeserializer<ObjectNode>
/*     */   {
/*  75 */     protected static final ObjectDeserializer _instance = new ObjectDeserializer();
/*     */ 
/*     */     protected ObjectDeserializer() {
/*  78 */       super();
/*     */     }
/*     */     public static ObjectDeserializer getInstance() {
/*  81 */       return _instance;
/*     */     }
/*     */ 
/*     */     public ObjectNode deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/*  87 */       if (jp.getCurrentToken() == JsonToken.START_OBJECT) {
/*  88 */         jp.nextToken();
/*  89 */         return deserializeObject(jp, ctxt, ctxt.getNodeFactory());
/*     */       }
/*  91 */       if (jp.getCurrentToken() == JsonToken.FIELD_NAME) {
/*  92 */         return deserializeObject(jp, ctxt, ctxt.getNodeFactory());
/*     */       }
/*  94 */       throw ctxt.mappingException(ObjectNode.class);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.JsonNodeDeserializer
 * JD-Core Version:    0.6.2
 */