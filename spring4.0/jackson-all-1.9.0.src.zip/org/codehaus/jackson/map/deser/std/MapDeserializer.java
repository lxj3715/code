/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.BeanProperty.Std;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.KeyDeserializer;
/*     */ import org.codehaus.jackson.map.ResolvableDeserializer;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ import org.codehaus.jackson.map.deser.impl.PropertyBasedCreator;
/*     */ import org.codehaus.jackson.map.deser.impl.PropertyValueBuffer;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedConstructor;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedWithParams;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class MapDeserializer extends ContainerDeserializerBase<Map<Object, Object>>
/*     */   implements ResolvableDeserializer
/*     */ {
/*     */   protected final JavaType _mapType;
/*     */   protected final KeyDeserializer _keyDeserializer;
/*     */   protected final JsonDeserializer<Object> _valueDeserializer;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final boolean _hasDefaultCreator;
/*     */   protected PropertyBasedCreator _propertyBasedCreator;
/*     */   protected JsonDeserializer<Object> _delegateDeserializer;
/*     */   protected HashSet<String> _ignorableProperties;
/*     */ 
/*     */   @Deprecated
/*     */   protected MapDeserializer(JavaType mapType, Constructor<Map<Object, Object>> defCtor, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser)
/*     */   {
/* 103 */     super(Map.class);
/* 104 */     this._mapType = mapType;
/* 105 */     this._keyDeserializer = keyDeser;
/* 106 */     this._valueDeserializer = valueDeser;
/* 107 */     this._valueTypeDeserializer = valueTypeDeser;
/*     */ 
/* 109 */     StdValueInstantiator inst = new StdValueInstantiator(null, mapType);
/* 110 */     if (defCtor != null) {
/* 111 */       AnnotatedConstructor aCtor = new AnnotatedConstructor(defCtor, null, null);
/*     */ 
/* 113 */       inst.configureFromObjectSettings(aCtor, null, null, null, null);
/*     */     }
/* 115 */     this._hasDefaultCreator = (defCtor != null);
/* 116 */     this._valueInstantiator = inst;
/*     */   }
/*     */ 
/*     */   public MapDeserializer(JavaType mapType, ValueInstantiator valueInstantiator, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser)
/*     */   {
/* 123 */     super(Map.class);
/* 124 */     this._mapType = mapType;
/* 125 */     this._keyDeserializer = keyDeser;
/* 126 */     this._valueDeserializer = valueDeser;
/* 127 */     this._valueTypeDeserializer = valueTypeDeser;
/* 128 */     this._valueInstantiator = valueInstantiator;
/* 129 */     if (valueInstantiator.canCreateFromObjectWith())
/* 130 */       this._propertyBasedCreator = new PropertyBasedCreator(valueInstantiator);
/*     */     else {
/* 132 */       this._propertyBasedCreator = null;
/*     */     }
/* 134 */     this._hasDefaultCreator = valueInstantiator.canCreateUsingDefault();
/*     */   }
/*     */ 
/*     */   protected MapDeserializer(MapDeserializer src)
/*     */   {
/* 145 */     super(src._valueClass);
/* 146 */     this._mapType = src._mapType;
/* 147 */     this._keyDeserializer = src._keyDeserializer;
/* 148 */     this._valueDeserializer = src._valueDeserializer;
/* 149 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 150 */     this._valueInstantiator = src._valueInstantiator;
/* 151 */     this._propertyBasedCreator = src._propertyBasedCreator;
/* 152 */     this._delegateDeserializer = src._delegateDeserializer;
/* 153 */     this._hasDefaultCreator = src._hasDefaultCreator;
/*     */ 
/* 155 */     this._ignorableProperties = src._ignorableProperties;
/*     */   }
/*     */ 
/*     */   public void setIgnorableProperties(String[] ignorable)
/*     */   {
/* 160 */     this._ignorableProperties = ((ignorable == null) || (ignorable.length == 0) ? null : ArrayBuilders.arrayToSet(ignorable));
/*     */   }
/*     */ 
/*     */   public void resolve(DeserializationConfig config, DeserializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 180 */     if (this._valueInstantiator.canCreateUsingDelegate()) {
/* 181 */       JavaType delegateType = this._valueInstantiator.getDelegateType();
/* 182 */       if (delegateType == null) {
/* 183 */         throw new IllegalArgumentException("Invalid delegate-creator definition for " + this._mapType + ": value instantiator (" + this._valueInstantiator.getClass().getName() + ") returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'");
/*     */       }
/*     */ 
/* 187 */       AnnotatedWithParams delegateCreator = this._valueInstantiator.getDelegateCreator();
/*     */ 
/* 190 */       BeanProperty.Std property = new BeanProperty.Std(null, delegateType, null, delegateCreator);
/*     */ 
/* 192 */       this._delegateDeserializer = findDeserializer(config, provider, delegateType, property);
/*     */     }
/* 194 */     if (this._propertyBasedCreator != null)
/* 195 */       for (SettableBeanProperty prop : this._propertyBasedCreator.getCreatorProperties())
/* 196 */         if (!prop.hasValueDeserializer())
/* 197 */           this._propertyBasedCreator.assignDeserializer(prop, findDeserializer(config, provider, prop.getType(), prop));
/*     */   }
/*     */ 
/*     */   public JavaType getContentType()
/*     */   {
/* 211 */     return this._mapType.getContentType();
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> getContentDeserializer()
/*     */   {
/* 216 */     return this._valueDeserializer;
/*     */   }
/*     */ 
/*     */   public Map<Object, Object> deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 230 */     if (this._propertyBasedCreator != null) {
/* 231 */       return _deserializeUsingCreator(jp, ctxt);
/*     */     }
/* 233 */     if (this._delegateDeserializer != null) {
/* 234 */       return (Map)this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*     */     }
/* 236 */     if (!this._hasDefaultCreator) {
/* 237 */       throw ctxt.instantiationException(getMapClass(), "No default constructor found");
/*     */     }
/*     */ 
/* 240 */     JsonToken t = jp.getCurrentToken();
/* 241 */     if ((t != JsonToken.START_OBJECT) && (t != JsonToken.FIELD_NAME) && (t != JsonToken.END_OBJECT))
/*     */     {
/* 243 */       if (t == JsonToken.VALUE_STRING) {
/* 244 */         return (Map)this._valueInstantiator.createFromString(jp.getText());
/*     */       }
/* 246 */       throw ctxt.mappingException(getMapClass());
/*     */     }
/* 248 */     Map result = (Map)this._valueInstantiator.createUsingDefault();
/* 249 */     _readAndBind(jp, ctxt, result);
/* 250 */     return result;
/*     */   }
/*     */ 
/*     */   public Map<Object, Object> deserialize(JsonParser jp, DeserializationContext ctxt, Map<Object, Object> result)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 259 */     JsonToken t = jp.getCurrentToken();
/* 260 */     if ((t != JsonToken.START_OBJECT) && (t != JsonToken.FIELD_NAME)) {
/* 261 */       throw ctxt.mappingException(getMapClass());
/*     */     }
/* 263 */     _readAndBind(jp, ctxt, result);
/* 264 */     return result;
/*     */   }
/*     */ 
/*     */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 273 */     return typeDeserializer.deserializeTypedFromObject(jp, ctxt);
/*     */   }
/*     */ 
/*     */   public final Class<?> getMapClass()
/*     */   {
/* 283 */     return this._mapType.getRawClass();
/*     */   }
/* 285 */   public JavaType getValueType() { return this._mapType; }
/*     */ 
/*     */ 
/*     */   protected final void _readAndBind(JsonParser jp, DeserializationContext ctxt, Map<Object, Object> result)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 297 */     JsonToken t = jp.getCurrentToken();
/* 298 */     if (t == JsonToken.START_OBJECT) {
/* 299 */       t = jp.nextToken();
/*     */     }
/* 301 */     KeyDeserializer keyDes = this._keyDeserializer;
/* 302 */     JsonDeserializer valueDes = this._valueDeserializer;
/* 303 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/* 304 */     for (; t == JsonToken.FIELD_NAME; t = jp.nextToken())
/*     */     {
/* 306 */       String fieldName = jp.getCurrentName();
/* 307 */       Object key = keyDes == null ? fieldName : keyDes.deserializeKey(fieldName, ctxt);
/*     */ 
/* 309 */       t = jp.nextToken();
/* 310 */       if ((this._ignorableProperties != null) && (this._ignorableProperties.contains(fieldName))) {
/* 311 */         jp.skipChildren();
/*     */       }
/*     */       else
/*     */       {
/*     */         Object value;
/*     */         Object value;
/* 316 */         if (t == JsonToken.VALUE_NULL) {
/* 317 */           value = null;
/*     */         }
/*     */         else
/*     */         {
/*     */           Object value;
/* 318 */           if (typeDeser == null)
/* 319 */             value = valueDes.deserialize(jp, ctxt);
/*     */           else {
/* 321 */             value = valueDes.deserializeWithType(jp, ctxt, typeDeser);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 327 */         result.put(key, value);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map<Object, Object> _deserializeUsingCreator(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 335 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 336 */     PropertyValueBuffer buffer = creator.startBuilding(jp, ctxt);
/*     */ 
/* 338 */     JsonToken t = jp.getCurrentToken();
/* 339 */     if (t == JsonToken.START_OBJECT) {
/* 340 */       t = jp.nextToken();
/*     */     }
/* 342 */     JsonDeserializer valueDes = this._valueDeserializer;
/* 343 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/* 344 */     for (; t == JsonToken.FIELD_NAME; t = jp.nextToken()) {
/* 345 */       String propName = jp.getCurrentName();
/* 346 */       t = jp.nextToken();
/* 347 */       if ((this._ignorableProperties != null) && (this._ignorableProperties.contains(propName))) {
/* 348 */         jp.skipChildren();
/*     */       }
/*     */       else
/*     */       {
/* 352 */         SettableBeanProperty prop = creator.findCreatorProperty(propName);
/* 353 */         if (prop != null)
/*     */         {
/* 355 */           Object value = prop.deserialize(jp, ctxt);
/* 356 */           if (buffer.assignParameter(prop.getPropertyIndex(), value)) { jp.nextToken();
/*     */             Map result;
/*     */             try {
/* 360 */               result = (Map)creator.build(buffer);
/*     */             } catch (Exception e) {
/* 362 */               wrapAndThrow(e, this._mapType.getRawClass());
/* 363 */               return null;
/*     */             }
/* 365 */             _readAndBind(jp, ctxt, result);
/* 366 */             return result;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 371 */           String fieldName = jp.getCurrentName();
/* 372 */           Object key = this._keyDeserializer == null ? fieldName : this._keyDeserializer.deserializeKey(fieldName, ctxt);
/*     */           Object value;
/*     */           Object value;
/* 374 */           if (t == JsonToken.VALUE_NULL) {
/* 375 */             value = null;
/*     */           }
/*     */           else
/*     */           {
/*     */             Object value;
/* 376 */             if (typeDeser == null)
/* 377 */               value = valueDes.deserialize(jp, ctxt);
/*     */             else
/* 379 */               value = valueDes.deserializeWithType(jp, ctxt, typeDeser);
/*     */           }
/* 381 */           buffer.bufferMapProperty(key, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     try {
/* 386 */       return (Map)creator.build(buffer);
/*     */     } catch (Exception e) {
/* 388 */       wrapAndThrow(e, this._mapType.getRawClass());
/* 389 */     }return null;
/*     */   }
/*     */ 
/*     */   protected void wrapAndThrow(Throwable t, Object ref)
/*     */     throws IOException
/*     */   {
/* 398 */     while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 399 */       t = t.getCause();
/*     */     }
/*     */ 
/* 402 */     if ((t instanceof Error)) {
/* 403 */       throw ((Error)t);
/*     */     }
/*     */ 
/* 406 */     if (((t instanceof IOException)) && (!(t instanceof JsonMappingException))) {
/* 407 */       throw ((IOException)t);
/*     */     }
/* 409 */     throw JsonMappingException.wrapWithPath(t, ref, null);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.MapDeserializer
 * JD-Core Version:    0.6.2
 */