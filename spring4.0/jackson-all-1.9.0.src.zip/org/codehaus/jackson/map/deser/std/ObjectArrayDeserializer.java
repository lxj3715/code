/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.type.ArrayType;
/*     */ import org.codehaus.jackson.map.util.ObjectBuffer;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class ObjectArrayDeserializer extends ContainerDeserializerBase<Object[]>
/*     */ {
/*     */   protected final JavaType _arrayType;
/*     */   protected final boolean _untyped;
/*     */   protected final Class<?> _elementClass;
/*     */   protected final JsonDeserializer<Object> _elementDeserializer;
/*     */   protected final TypeDeserializer _elementTypeDeserializer;
/*     */ 
/*     */   public ObjectArrayDeserializer(ArrayType arrayType, JsonDeserializer<Object> elemDeser, TypeDeserializer elemTypeDeser)
/*     */   {
/*  52 */     super([Ljava.lang.Object.class);
/*  53 */     this._arrayType = arrayType;
/*  54 */     this._elementClass = arrayType.getContentType().getRawClass();
/*  55 */     this._untyped = (this._elementClass == Object.class);
/*  56 */     this._elementDeserializer = elemDeser;
/*  57 */     this._elementTypeDeserializer = elemTypeDeser;
/*     */   }
/*     */ 
/*     */   public JavaType getContentType()
/*     */   {
/*  68 */     return this._arrayType.getContentType();
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> getContentDeserializer()
/*     */   {
/*  73 */     return this._elementDeserializer;
/*     */   }
/*     */ 
/*     */   public Object[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  87 */     if (!jp.isExpectedStartArrayToken()) {
/*  88 */       return handleNonArray(jp, ctxt);
/*     */     }
/*     */ 
/*  91 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/*  92 */     Object[] chunk = buffer.resetAndStart();
/*  93 */     int ix = 0;
/*     */ 
/*  95 */     TypeDeserializer typeDeser = this._elementTypeDeserializer;
/*     */     JsonToken t;
/*  97 */     while ((t = jp.nextToken()) != JsonToken.END_ARRAY)
/*     */     {
/*     */       Object value;
/*     */       Object value;
/* 101 */       if (t == JsonToken.VALUE_NULL) {
/* 102 */         value = null;
/*     */       }
/*     */       else
/*     */       {
/*     */         Object value;
/* 103 */         if (typeDeser == null)
/* 104 */           value = this._elementDeserializer.deserialize(jp, ctxt);
/*     */         else
/* 106 */           value = this._elementDeserializer.deserializeWithType(jp, ctxt, typeDeser);
/*     */       }
/* 108 */       if (ix >= chunk.length) {
/* 109 */         chunk = buffer.appendCompletedChunk(chunk);
/* 110 */         ix = 0;
/*     */       }
/* 112 */       chunk[(ix++)] = value;
/*     */     }
/*     */     Object[] result;
/*     */     Object[] result;
/* 117 */     if (this._untyped)
/* 118 */       result = buffer.completeAndClearBuffer(chunk, ix);
/*     */     else {
/* 120 */       result = buffer.completeAndClearBuffer(chunk, ix, this._elementClass);
/*     */     }
/* 122 */     ctxt.returnObjectBuffer(buffer);
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */   public Object[] deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 134 */     return (Object[])typeDeserializer.deserializeTypedFromArray(jp, ctxt);
/*     */   }
/*     */ 
/*     */   protected Byte[] deserializeFromBase64(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 147 */     byte[] b = jp.getBinaryValue(ctxt.getBase64Variant());
/*     */ 
/* 149 */     Byte[] result = new Byte[b.length];
/* 150 */     int i = 0; for (int len = b.length; i < len; i++) {
/* 151 */       result[i] = Byte.valueOf(b[i]);
/*     */     }
/* 153 */     return result;
/*     */   }
/*     */ 
/*     */   private final Object[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 160 */     if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */     {
/* 162 */       String str = jp.getText();
/* 163 */       if (str.length() == 0) {
/* 164 */         return null;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 169 */     if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY))
/*     */     {
/* 173 */       if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (this._elementClass == Byte.class))
/*     */       {
/* 175 */         return deserializeFromBase64(jp, ctxt);
/*     */       }
/* 177 */       throw ctxt.mappingException(this._arrayType.getRawClass());
/*     */     }
/* 179 */     JsonToken t = jp.getCurrentToken();
/*     */     Object value;
/*     */     Object value;
/* 182 */     if (t == JsonToken.VALUE_NULL) {
/* 183 */       value = null;
/*     */     }
/*     */     else
/*     */     {
/*     */       Object value;
/* 184 */       if (this._elementTypeDeserializer == null)
/* 185 */         value = this._elementDeserializer.deserialize(jp, ctxt);
/*     */       else
/* 187 */         value = this._elementDeserializer.deserializeWithType(jp, ctxt, this._elementTypeDeserializer);
/*     */     }
/*     */     Object[] result;
/*     */     Object[] result;
/* 192 */     if (this._untyped)
/* 193 */       result = new Object[1];
/*     */     else {
/* 195 */       result = (Object[])Array.newInstance(this._elementClass, 1);
/*     */     }
/* 197 */     result[0] = value;
/* 198 */     return result;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.ObjectArrayDeserializer
 * JD-Core Version:    0.6.2
 */