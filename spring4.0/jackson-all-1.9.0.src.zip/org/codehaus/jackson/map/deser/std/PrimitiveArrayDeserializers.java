/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.Base64Variant;
/*     */ import org.codehaus.jackson.Base64Variants;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders.BooleanBuilder;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders.ByteBuilder;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders.DoubleBuilder;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders.FloatBuilder;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders.IntBuilder;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders.LongBuilder;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders.ShortBuilder;
/*     */ import org.codehaus.jackson.map.util.ObjectBuffer;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class PrimitiveArrayDeserializers
/*     */ {
/*     */   HashMap<JavaType, JsonDeserializer<Object>> _allDeserializers;
/*  24 */   static final PrimitiveArrayDeserializers instance = new PrimitiveArrayDeserializers();
/*     */ 
/*     */   protected PrimitiveArrayDeserializers()
/*     */   {
/*  28 */     this._allDeserializers = new HashMap();
/*     */ 
/*  30 */     add(Boolean.TYPE, new BooleanDeser());
/*     */ 
/*  36 */     add(Byte.TYPE, new ByteDeser());
/*  37 */     add(Short.TYPE, new ShortDeser());
/*  38 */     add(Integer.TYPE, new IntDeser());
/*  39 */     add(Long.TYPE, new LongDeser());
/*     */ 
/*  41 */     add(Float.TYPE, new FloatDeser());
/*  42 */     add(Double.TYPE, new DoubleDeser());
/*     */ 
/*  44 */     add(String.class, new StringDeser());
/*     */ 
/*  48 */     add(Character.TYPE, new CharDeser());
/*     */   }
/*     */ 
/*     */   public static HashMap<JavaType, JsonDeserializer<Object>> getAll()
/*     */   {
/*  53 */     return instance._allDeserializers;
/*     */   }
/*     */ 
/*     */   private void add(Class<?> cls, JsonDeserializer<?> deser)
/*     */   {
/*  63 */     this._allDeserializers.put(TypeFactory.defaultInstance().constructType(cls), deser);
/*     */   }
/*     */ 
/*     */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  74 */     return typeDeserializer.deserializeTypedFromArray(jp, ctxt);
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class DoubleDeser extends PrimitiveArrayDeserializers.Base<double[]>
/*     */   {
/*     */     public DoubleDeser()
/*     */     {
/* 543 */       super();
/*     */     }
/*     */ 
/*     */     public double[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 549 */       if (!jp.isExpectedStartArrayToken()) {
/* 550 */         return handleNonArray(jp, ctxt);
/*     */       }
/* 552 */       ArrayBuilders.DoubleBuilder builder = ctxt.getArrayBuilders().getDoubleBuilder();
/* 553 */       double[] chunk = (double[])builder.resetAndStart();
/* 554 */       int ix = 0;
/*     */ 
/* 556 */       while (jp.nextToken() != JsonToken.END_ARRAY) {
/* 557 */         double value = _parseDoublePrimitive(jp, ctxt);
/* 558 */         if (ix >= chunk.length) {
/* 559 */           chunk = (double[])builder.appendCompletedChunk(chunk, ix);
/* 560 */           ix = 0;
/*     */         }
/* 562 */         chunk[(ix++)] = value;
/*     */       }
/* 564 */       return (double[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */     private final double[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 571 */       if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */       {
/* 573 */         if (jp.getText().length() == 0) {
/* 574 */           return null;
/*     */         }
/*     */       }
/* 577 */       if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 578 */         throw ctxt.mappingException(this._valueClass);
/*     */       }
/* 580 */       return new double[] { _parseDoublePrimitive(jp, ctxt) };
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class FloatDeser extends PrimitiveArrayDeserializers.Base<float[]>
/*     */   {
/*     */     public FloatDeser()
/*     */     {
/* 497 */       super();
/*     */     }
/*     */ 
/*     */     public float[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 503 */       if (!jp.isExpectedStartArrayToken()) {
/* 504 */         return handleNonArray(jp, ctxt);
/*     */       }
/* 506 */       ArrayBuilders.FloatBuilder builder = ctxt.getArrayBuilders().getFloatBuilder();
/* 507 */       float[] chunk = (float[])builder.resetAndStart();
/* 508 */       int ix = 0;
/*     */ 
/* 510 */       while (jp.nextToken() != JsonToken.END_ARRAY)
/*     */       {
/* 512 */         float value = _parseFloatPrimitive(jp, ctxt);
/* 513 */         if (ix >= chunk.length) {
/* 514 */           chunk = (float[])builder.appendCompletedChunk(chunk, ix);
/* 515 */           ix = 0;
/*     */         }
/* 517 */         chunk[(ix++)] = value;
/*     */       }
/* 519 */       return (float[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */     private final float[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 526 */       if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */       {
/* 528 */         if (jp.getText().length() == 0) {
/* 529 */           return null;
/*     */         }
/*     */       }
/* 532 */       if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 533 */         throw ctxt.mappingException(this._valueClass);
/*     */       }
/* 535 */       return new float[] { _parseFloatPrimitive(jp, ctxt) };
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class LongDeser extends PrimitiveArrayDeserializers.Base<long[]>
/*     */   {
/*     */     public LongDeser()
/*     */     {
/* 452 */       super();
/*     */     }
/*     */ 
/*     */     public long[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 458 */       if (!jp.isExpectedStartArrayToken()) {
/* 459 */         return handleNonArray(jp, ctxt);
/*     */       }
/* 461 */       ArrayBuilders.LongBuilder builder = ctxt.getArrayBuilders().getLongBuilder();
/* 462 */       long[] chunk = (long[])builder.resetAndStart();
/* 463 */       int ix = 0;
/*     */ 
/* 465 */       while (jp.nextToken() != JsonToken.END_ARRAY) {
/* 466 */         long value = _parseLongPrimitive(jp, ctxt);
/* 467 */         if (ix >= chunk.length) {
/* 468 */           chunk = (long[])builder.appendCompletedChunk(chunk, ix);
/* 469 */           ix = 0;
/*     */         }
/* 471 */         chunk[(ix++)] = value;
/*     */       }
/* 473 */       return (long[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */     private final long[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 480 */       if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */       {
/* 482 */         if (jp.getText().length() == 0) {
/* 483 */           return null;
/*     */         }
/*     */       }
/* 486 */       if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 487 */         throw ctxt.mappingException(this._valueClass);
/*     */       }
/* 489 */       return new long[] { _parseLongPrimitive(jp, ctxt) };
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class IntDeser extends PrimitiveArrayDeserializers.Base<int[]>
/*     */   {
/*     */     public IntDeser()
/*     */     {
/* 406 */       super();
/*     */     }
/*     */ 
/*     */     public int[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 412 */       if (!jp.isExpectedStartArrayToken()) {
/* 413 */         return handleNonArray(jp, ctxt);
/*     */       }
/* 415 */       ArrayBuilders.IntBuilder builder = ctxt.getArrayBuilders().getIntBuilder();
/* 416 */       int[] chunk = (int[])builder.resetAndStart();
/* 417 */       int ix = 0;
/*     */ 
/* 419 */       while (jp.nextToken() != JsonToken.END_ARRAY)
/*     */       {
/* 421 */         int value = _parseIntPrimitive(jp, ctxt);
/* 422 */         if (ix >= chunk.length) {
/* 423 */           chunk = (int[])builder.appendCompletedChunk(chunk, ix);
/* 424 */           ix = 0;
/*     */         }
/* 426 */         chunk[(ix++)] = value;
/*     */       }
/* 428 */       return (int[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */     private final int[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 435 */       if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */       {
/* 437 */         if (jp.getText().length() == 0) {
/* 438 */           return null;
/*     */         }
/*     */       }
/* 441 */       if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 442 */         throw ctxt.mappingException(this._valueClass);
/*     */       }
/* 444 */       return new int[] { _parseIntPrimitive(jp, ctxt) };
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class ShortDeser extends PrimitiveArrayDeserializers.Base<short[]>
/*     */   {
/*     */     public ShortDeser()
/*     */     {
/* 361 */       super();
/*     */     }
/*     */ 
/*     */     public short[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 367 */       if (!jp.isExpectedStartArrayToken()) {
/* 368 */         return handleNonArray(jp, ctxt);
/*     */       }
/* 370 */       ArrayBuilders.ShortBuilder builder = ctxt.getArrayBuilders().getShortBuilder();
/* 371 */       short[] chunk = (short[])builder.resetAndStart();
/* 372 */       int ix = 0;
/*     */ 
/* 374 */       while (jp.nextToken() != JsonToken.END_ARRAY) {
/* 375 */         short value = _parseShortPrimitive(jp, ctxt);
/* 376 */         if (ix >= chunk.length) {
/* 377 */           chunk = (short[])builder.appendCompletedChunk(chunk, ix);
/* 378 */           ix = 0;
/*     */         }
/* 380 */         chunk[(ix++)] = value;
/*     */       }
/* 382 */       return (short[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */     private final short[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 389 */       if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */       {
/* 391 */         if (jp.getText().length() == 0) {
/* 392 */           return null;
/*     */         }
/*     */       }
/* 395 */       if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 396 */         throw ctxt.mappingException(this._valueClass);
/*     */       }
/* 398 */       return new short[] { _parseShortPrimitive(jp, ctxt) };
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class ByteDeser extends PrimitiveArrayDeserializers.Base<byte[]>
/*     */   {
/*     */     public ByteDeser()
/*     */     {
/* 279 */       super();
/*     */     }
/*     */ 
/*     */     public byte[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 285 */       JsonToken t = jp.getCurrentToken();
/*     */ 
/* 288 */       if (t == JsonToken.VALUE_STRING) {
/* 289 */         return jp.getBinaryValue(ctxt.getBase64Variant());
/*     */       }
/*     */ 
/* 292 */       if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 293 */         Object ob = jp.getEmbeddedObject();
/* 294 */         if (ob == null) return null;
/* 295 */         if ((ob instanceof byte[])) {
/* 296 */           return (byte[])ob;
/*     */         }
/*     */       }
/* 299 */       if (!jp.isExpectedStartArrayToken()) {
/* 300 */         return handleNonArray(jp, ctxt);
/*     */       }
/* 302 */       ArrayBuilders.ByteBuilder builder = ctxt.getArrayBuilders().getByteBuilder();
/* 303 */       byte[] chunk = (byte[])builder.resetAndStart();
/* 304 */       int ix = 0;
/*     */ 
/* 306 */       while ((t = jp.nextToken()) != JsonToken.END_ARRAY)
/*     */       {
/*     */         byte value;
/*     */         byte value;
/* 309 */         if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT))
/*     */         {
/* 311 */           value = jp.getByteValue();
/*     */         }
/*     */         else {
/* 314 */           if (t != JsonToken.VALUE_NULL) {
/* 315 */             throw ctxt.mappingException(this._valueClass.getComponentType());
/*     */           }
/* 317 */           value = 0;
/*     */         }
/* 319 */         if (ix >= chunk.length) {
/* 320 */           chunk = (byte[])builder.appendCompletedChunk(chunk, ix);
/* 321 */           ix = 0;
/*     */         }
/* 323 */         chunk[(ix++)] = value;
/*     */       }
/* 325 */       return (byte[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */     private final byte[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 332 */       if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */       {
/* 334 */         if (jp.getText().length() == 0) {
/* 335 */           return null;
/*     */         }
/*     */       }
/* 338 */       if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 339 */         throw ctxt.mappingException(this._valueClass);
/*     */       }
/*     */ 
/* 342 */       JsonToken t = jp.getCurrentToken();
/*     */       byte value;
/*     */       byte value;
/* 343 */       if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT))
/*     */       {
/* 345 */         value = jp.getByteValue();
/*     */       }
/*     */       else {
/* 348 */         if (t != JsonToken.VALUE_NULL) {
/* 349 */           throw ctxt.mappingException(this._valueClass.getComponentType());
/*     */         }
/* 351 */         value = 0;
/*     */       }
/* 353 */       return new byte[] { value };
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class BooleanDeser extends PrimitiveArrayDeserializers.Base<boolean[]>
/*     */   {
/*     */     public BooleanDeser()
/*     */     {
/* 229 */       super();
/*     */     }
/*     */ 
/*     */     public boolean[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 235 */       if (!jp.isExpectedStartArrayToken()) {
/* 236 */         return handleNonArray(jp, ctxt);
/*     */       }
/* 238 */       ArrayBuilders.BooleanBuilder builder = ctxt.getArrayBuilders().getBooleanBuilder();
/* 239 */       boolean[] chunk = (boolean[])builder.resetAndStart();
/* 240 */       int ix = 0;
/*     */ 
/* 242 */       while (jp.nextToken() != JsonToken.END_ARRAY)
/*     */       {
/* 244 */         boolean value = _parseBooleanPrimitive(jp, ctxt);
/* 245 */         if (ix >= chunk.length) {
/* 246 */           chunk = (boolean[])builder.appendCompletedChunk(chunk, ix);
/* 247 */           ix = 0;
/*     */         }
/* 249 */         chunk[(ix++)] = value;
/*     */       }
/* 251 */       return (boolean[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */     private final boolean[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 258 */       if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */       {
/* 260 */         if (jp.getText().length() == 0) {
/* 261 */           return null;
/*     */         }
/*     */       }
/* 264 */       if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 265 */         throw ctxt.mappingException(this._valueClass);
/*     */       }
/* 267 */       return new boolean[] { _parseBooleanPrimitive(jp, ctxt) };
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class CharDeser extends PrimitiveArrayDeserializers.Base<char[]>
/*     */   {
/*     */     public CharDeser()
/*     */     {
/* 163 */       super();
/*     */     }
/*     */ 
/*     */     public char[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 173 */       JsonToken t = jp.getCurrentToken();
/* 174 */       if (t == JsonToken.VALUE_STRING)
/*     */       {
/* 176 */         char[] buffer = jp.getTextCharacters();
/* 177 */         int offset = jp.getTextOffset();
/* 178 */         int len = jp.getTextLength();
/*     */ 
/* 180 */         char[] result = new char[len];
/* 181 */         System.arraycopy(buffer, offset, result, 0, len);
/* 182 */         return result;
/*     */       }
/* 184 */       if (jp.isExpectedStartArrayToken())
/*     */       {
/* 186 */         StringBuilder sb = new StringBuilder(64);
/* 187 */         while ((t = jp.nextToken()) != JsonToken.END_ARRAY) {
/* 188 */           if (t != JsonToken.VALUE_STRING) {
/* 189 */             throw ctxt.mappingException(Character.TYPE);
/*     */           }
/* 191 */           String str = jp.getText();
/* 192 */           if (str.length() != 1) {
/* 193 */             throw JsonMappingException.from(jp, "Can not convert a JSON String of length " + str.length() + " into a char element of char array");
/*     */           }
/* 195 */           sb.append(str.charAt(0));
/*     */         }
/* 197 */         return sb.toString().toCharArray();
/*     */       }
/*     */ 
/* 200 */       if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 201 */         Object ob = jp.getEmbeddedObject();
/* 202 */         if (ob == null) return null;
/* 203 */         if ((ob instanceof char[])) {
/* 204 */           return (char[])ob;
/*     */         }
/* 206 */         if ((ob instanceof String)) {
/* 207 */           return ((String)ob).toCharArray();
/*     */         }
/*     */ 
/* 210 */         if ((ob instanceof byte[])) {
/* 211 */           return Base64Variants.getDefaultVariant().encode((byte[])ob, false).toCharArray();
/*     */         }
/*     */       }
/*     */ 
/* 215 */       throw ctxt.mappingException(this._valueClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   static final class StringDeser extends PrimitiveArrayDeserializers.Base<String[]>
/*     */   {
/*     */     public StringDeser()
/*     */     {
/* 111 */       super();
/*     */     }
/*     */ 
/*     */     public String[] deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 118 */       if (!jp.isExpectedStartArrayToken()) {
/* 119 */         return handleNonArray(jp, ctxt);
/*     */       }
/* 121 */       ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 122 */       Object[] chunk = buffer.resetAndStart();
/* 123 */       int ix = 0;
/*     */       JsonToken t;
/* 126 */       while ((t = jp.nextToken()) != JsonToken.END_ARRAY)
/*     */       {
/* 128 */         String value = t == JsonToken.VALUE_NULL ? null : jp.getText();
/* 129 */         if (ix >= chunk.length) {
/* 130 */           chunk = buffer.appendCompletedChunk(chunk);
/* 131 */           ix = 0;
/*     */         }
/* 133 */         chunk[(ix++)] = value;
/*     */       }
/* 135 */       String[] result = (String[])buffer.completeAndClearBuffer(chunk, ix, String.class);
/* 136 */       ctxt.returnObjectBuffer(buffer);
/* 137 */       return result;
/*     */     }
/*     */ 
/*     */     private final String[] handleNonArray(JsonParser jp, DeserializationContext ctxt)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 144 */       if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY))
/*     */       {
/* 146 */         if ((jp.getCurrentToken() == JsonToken.VALUE_STRING) && (ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)))
/*     */         {
/* 148 */           String str = jp.getText();
/* 149 */           if (str.length() == 0) {
/* 150 */             return null;
/*     */           }
/*     */         }
/* 153 */         throw ctxt.mappingException(this._valueClass);
/*     */       }
/* 155 */       return new String[] { jp.getCurrentToken() == JsonToken.VALUE_NULL ? null : jp.getText() };
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract class Base<T> extends StdDeserializer<T>
/*     */   {
/*     */     protected Base(Class<T> cls)
/*     */     {
/*  89 */       super();
/*     */     }
/*     */ 
/*     */     public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/*  97 */       return typeDeserializer.deserializeTypedFromArray(jp, ctxt);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.PrimitiveArrayDeserializers
 * JD-Core Version:    0.6.2
 */