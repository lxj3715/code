/*      */ package org.codehaus.jackson.map.deser.std;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import org.codehaus.jackson.JsonParser;
/*      */ import org.codehaus.jackson.JsonParser.NumberType;
/*      */ import org.codehaus.jackson.JsonProcessingException;
/*      */ import org.codehaus.jackson.JsonToken;
/*      */ import org.codehaus.jackson.io.NumberInput;
/*      */ import org.codehaus.jackson.map.BeanProperty;
/*      */ import org.codehaus.jackson.map.DeserializationConfig;
/*      */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*      */ import org.codehaus.jackson.map.DeserializationContext;
/*      */ import org.codehaus.jackson.map.DeserializerProvider;
/*      */ import org.codehaus.jackson.map.JsonDeserializer;
/*      */ import org.codehaus.jackson.map.JsonMappingException;
/*      */ import org.codehaus.jackson.map.TypeDeserializer;
/*      */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*      */ import org.codehaus.jackson.type.JavaType;
/*      */ 
/*      */ public abstract class StdDeserializer<T> extends JsonDeserializer<T>
/*      */ {
/*      */   protected final Class<?> _valueClass;
/*      */ 
/*      */   protected StdDeserializer(Class<?> vc)
/*      */   {
/*   35 */     this._valueClass = vc;
/*      */   }
/*      */ 
/*      */   protected StdDeserializer(JavaType valueType) {
/*   39 */     this._valueClass = (valueType == null ? null : valueType.getRawClass());
/*      */   }
/*      */ 
/*      */   public Class<?> getValueClass()
/*      */   {
/*   48 */     return this._valueClass;
/*      */   }
/*      */ 
/*      */   public JavaType getValueType()
/*      */   {
/*   55 */     return null;
/*      */   }
/*      */ 
/*      */   protected boolean isDefaultSerializer(JsonDeserializer<?> deserializer)
/*      */   {
/*   67 */     return (deserializer != null) && (deserializer.getClass().getAnnotation(JacksonStdImpl.class) != null);
/*      */   }
/*      */ 
/*      */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*   86 */     return typeDeserializer.deserializeTypedFromAny(jp, ctxt);
/*      */   }
/*      */ 
/*      */   protected final boolean _parseBooleanPrimitive(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*   98 */     JsonToken t = jp.getCurrentToken();
/*   99 */     if (t == JsonToken.VALUE_TRUE) {
/*  100 */       return true;
/*      */     }
/*  102 */     if (t == JsonToken.VALUE_FALSE) {
/*  103 */       return false;
/*      */     }
/*  105 */     if (t == JsonToken.VALUE_NULL) {
/*  106 */       return false;
/*      */     }
/*      */ 
/*  109 */     if (t == JsonToken.VALUE_NUMBER_INT) {
/*  110 */       return jp.getIntValue() != 0;
/*      */     }
/*      */ 
/*  113 */     if (t == JsonToken.VALUE_STRING) {
/*  114 */       String text = jp.getText().trim();
/*  115 */       if ("true".equals(text)) {
/*  116 */         return true;
/*      */       }
/*  118 */       if (("false".equals(text)) || (text.length() == 0)) {
/*  119 */         return Boolean.FALSE.booleanValue();
/*      */       }
/*  121 */       throw ctxt.weirdStringException(this._valueClass, "only \"true\" or \"false\" recognized");
/*      */     }
/*      */ 
/*  124 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final Boolean _parseBoolean(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  130 */     JsonToken t = jp.getCurrentToken();
/*  131 */     if (t == JsonToken.VALUE_TRUE) {
/*  132 */       return Boolean.TRUE;
/*      */     }
/*  134 */     if (t == JsonToken.VALUE_FALSE) {
/*  135 */       return Boolean.FALSE;
/*      */     }
/*      */ 
/*  138 */     if (t == JsonToken.VALUE_NUMBER_INT) {
/*  139 */       return jp.getIntValue() == 0 ? Boolean.FALSE : Boolean.TRUE;
/*      */     }
/*  141 */     if (t == JsonToken.VALUE_NULL) {
/*  142 */       return (Boolean)getNullValue();
/*      */     }
/*      */ 
/*  145 */     if (t == JsonToken.VALUE_STRING) {
/*  146 */       String text = jp.getText().trim();
/*  147 */       if ("true".equals(text)) {
/*  148 */         return Boolean.TRUE;
/*      */       }
/*  150 */       if ("false".equals(text)) {
/*  151 */         return Boolean.FALSE;
/*      */       }
/*  153 */       if (text.length() == 0) {
/*  154 */         return (Boolean)getEmptyValue();
/*      */       }
/*  156 */       throw ctxt.weirdStringException(this._valueClass, "only \"true\" or \"false\" recognized");
/*      */     }
/*      */ 
/*  159 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected Byte _parseByte(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  165 */     JsonToken t = jp.getCurrentToken();
/*  166 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  167 */       return Byte.valueOf(jp.getByteValue());
/*      */     }
/*  169 */     if (t == JsonToken.VALUE_STRING) { String text = jp.getText().trim();
/*      */       int value;
/*      */       try {
/*  173 */         int len = text.length();
/*  174 */         if (len == 0) {
/*  175 */           return (Byte)getEmptyValue();
/*      */         }
/*  177 */         value = NumberInput.parseInt(text);
/*      */       } catch (IllegalArgumentException iae) {
/*  179 */         throw ctxt.weirdStringException(this._valueClass, "not a valid Byte value");
/*      */       }
/*      */ 
/*  182 */       if ((value < -128) || (value > 127)) {
/*  183 */         throw ctxt.weirdStringException(this._valueClass, "overflow, value can not be represented as 8-bit value");
/*      */       }
/*  185 */       return Byte.valueOf((byte)value);
/*      */     }
/*  187 */     if (t == JsonToken.VALUE_NULL) {
/*  188 */       return (Byte)getNullValue();
/*      */     }
/*  190 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected Short _parseShort(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  196 */     JsonToken t = jp.getCurrentToken();
/*  197 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  198 */       return Short.valueOf(jp.getShortValue());
/*      */     }
/*  200 */     if (t == JsonToken.VALUE_STRING) { String text = jp.getText().trim();
/*      */       int value;
/*      */       try {
/*  204 */         int len = text.length();
/*  205 */         if (len == 0) {
/*  206 */           return (Short)getEmptyValue();
/*      */         }
/*  208 */         value = NumberInput.parseInt(text);
/*      */       } catch (IllegalArgumentException iae) {
/*  210 */         throw ctxt.weirdStringException(this._valueClass, "not a valid Short value");
/*      */       }
/*      */ 
/*  213 */       if ((value < -32768) || (value > 32767)) {
/*  214 */         throw ctxt.weirdStringException(this._valueClass, "overflow, value can not be represented as 16-bit value");
/*      */       }
/*  216 */       return Short.valueOf((short)value);
/*      */     }
/*  218 */     if (t == JsonToken.VALUE_NULL) {
/*  219 */       return (Short)getNullValue();
/*      */     }
/*  221 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final short _parseShortPrimitive(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  227 */     int value = _parseIntPrimitive(jp, ctxt);
/*      */ 
/*  229 */     if ((value < -32768) || (value > 32767)) {
/*  230 */       throw ctxt.weirdStringException(this._valueClass, "overflow, value can not be represented as 16-bit value");
/*      */     }
/*  232 */     return (short)value;
/*      */   }
/*      */ 
/*      */   protected final int _parseIntPrimitive(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  238 */     JsonToken t = jp.getCurrentToken();
/*      */ 
/*  241 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  242 */       return jp.getIntValue();
/*      */     }
/*  244 */     if (t == JsonToken.VALUE_STRING)
/*      */     {
/*  248 */       String text = jp.getText().trim();
/*      */       try {
/*  250 */         int len = text.length();
/*  251 */         if (len > 9) {
/*  252 */           long l = Long.parseLong(text);
/*  253 */           if ((l < -2147483648L) || (l > 2147483647L)) {
/*  254 */             throw ctxt.weirdStringException(this._valueClass, "Overflow: numeric value (" + text + ") out of range of int (" + -2147483648 + " - " + 2147483647 + ")");
/*      */           }
/*      */ 
/*  257 */           return (int)l;
/*      */         }
/*  259 */         if (len == 0) {
/*  260 */           return 0;
/*      */         }
/*  262 */         return NumberInput.parseInt(text);
/*      */       } catch (IllegalArgumentException iae) {
/*  264 */         throw ctxt.weirdStringException(this._valueClass, "not a valid int value");
/*      */       }
/*      */     }
/*  267 */     if (t == JsonToken.VALUE_NULL) {
/*  268 */       return 0;
/*      */     }
/*      */ 
/*  271 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final Integer _parseInteger(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  277 */     JsonToken t = jp.getCurrentToken();
/*  278 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  279 */       return Integer.valueOf(jp.getIntValue());
/*      */     }
/*  281 */     if (t == JsonToken.VALUE_STRING) {
/*  282 */       String text = jp.getText().trim();
/*      */       try {
/*  284 */         int len = text.length();
/*  285 */         if (len > 9) {
/*  286 */           long l = Long.parseLong(text);
/*  287 */           if ((l < -2147483648L) || (l > 2147483647L)) {
/*  288 */             throw ctxt.weirdStringException(this._valueClass, "Overflow: numeric value (" + text + ") out of range of Integer (" + -2147483648 + " - " + 2147483647 + ")");
/*      */           }
/*      */ 
/*  291 */           return Integer.valueOf((int)l);
/*      */         }
/*  293 */         if (len == 0) {
/*  294 */           return (Integer)getEmptyValue();
/*      */         }
/*  296 */         return Integer.valueOf(NumberInput.parseInt(text));
/*      */       } catch (IllegalArgumentException iae) {
/*  298 */         throw ctxt.weirdStringException(this._valueClass, "not a valid Integer value");
/*      */       }
/*      */     }
/*  301 */     if (t == JsonToken.VALUE_NULL) {
/*  302 */       return (Integer)getNullValue();
/*      */     }
/*      */ 
/*  305 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final Long _parseLong(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  311 */     JsonToken t = jp.getCurrentToken();
/*      */ 
/*  314 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  315 */       return Long.valueOf(jp.getLongValue());
/*      */     }
/*      */ 
/*  318 */     if (t == JsonToken.VALUE_STRING)
/*      */     {
/*  320 */       String text = jp.getText().trim();
/*  321 */       if (text.length() == 0)
/*  322 */         return (Long)getEmptyValue();
/*      */       try
/*      */       {
/*  325 */         return Long.valueOf(NumberInput.parseLong(text));
/*      */       } catch (IllegalArgumentException iae) {
/*  327 */         throw ctxt.weirdStringException(this._valueClass, "not a valid Long value");
/*      */       }
/*      */     }
/*  329 */     if (t == JsonToken.VALUE_NULL) {
/*  330 */       return (Long)getNullValue();
/*      */     }
/*      */ 
/*  333 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final long _parseLongPrimitive(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  339 */     JsonToken t = jp.getCurrentToken();
/*  340 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  341 */       return jp.getLongValue();
/*      */     }
/*  343 */     if (t == JsonToken.VALUE_STRING) {
/*  344 */       String text = jp.getText().trim();
/*  345 */       if (text.length() == 0)
/*  346 */         return 0L;
/*      */       try
/*      */       {
/*  349 */         return NumberInput.parseLong(text);
/*      */       } catch (IllegalArgumentException iae) {
/*  351 */         throw ctxt.weirdStringException(this._valueClass, "not a valid long value");
/*      */       }
/*      */     }
/*  353 */     if (t == JsonToken.VALUE_NULL) {
/*  354 */       return 0L;
/*      */     }
/*  356 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final Float _parseFloat(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  363 */     JsonToken t = jp.getCurrentToken();
/*      */ 
/*  365 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  366 */       return Float.valueOf(jp.getFloatValue());
/*      */     }
/*      */ 
/*  369 */     if (t == JsonToken.VALUE_STRING) {
/*  370 */       String text = jp.getText().trim();
/*  371 */       if (text.length() == 0) {
/*  372 */         return (Float)getEmptyValue();
/*      */       }
/*  374 */       switch (text.charAt(0)) {
/*      */       case 'I':
/*  376 */         if (("Infinity".equals(text)) || ("INF".equals(text))) {
/*  377 */           return Float.valueOf((1.0F / 1.0F));
/*      */         }
/*      */         break;
/*      */       case 'N':
/*  381 */         if ("NaN".equals(text)) {
/*  382 */           return Float.valueOf((0.0F / 0.0F));
/*      */         }
/*      */         break;
/*      */       case '-':
/*  386 */         if (("-Infinity".equals(text)) || ("-INF".equals(text)))
/*  387 */           return Float.valueOf((1.0F / -1.0F));
/*      */         break;
/*      */       }
/*      */       try
/*      */       {
/*  392 */         return Float.valueOf(Float.parseFloat(text));
/*      */       } catch (IllegalArgumentException iae) {
/*  394 */         throw ctxt.weirdStringException(this._valueClass, "not a valid Float value");
/*      */       }
/*      */     }
/*  396 */     if (t == JsonToken.VALUE_NULL) {
/*  397 */       return (Float)getNullValue();
/*      */     }
/*      */ 
/*  400 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final float _parseFloatPrimitive(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  406 */     JsonToken t = jp.getCurrentToken();
/*      */ 
/*  408 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  409 */       return jp.getFloatValue();
/*      */     }
/*  411 */     if (t == JsonToken.VALUE_STRING) {
/*  412 */       String text = jp.getText().trim();
/*  413 */       if (text.length() == 0) {
/*  414 */         return 0.0F;
/*      */       }
/*  416 */       switch (text.charAt(0)) {
/*      */       case 'I':
/*  418 */         if (("Infinity".equals(text)) || ("INF".equals(text))) {
/*  419 */           return (1.0F / 1.0F);
/*      */         }
/*      */         break;
/*      */       case 'N':
/*  423 */         if ("NaN".equals(text)) {
/*  424 */           return (0.0F / 0.0F);
/*      */         }
/*      */         break;
/*      */       case '-':
/*  428 */         if (("-Infinity".equals(text)) || ("-INF".equals(text)))
/*  429 */           return (1.0F / -1.0F);
/*      */         break;
/*      */       }
/*      */       try
/*      */       {
/*  434 */         return Float.parseFloat(text);
/*      */       } catch (IllegalArgumentException iae) {
/*  436 */         throw ctxt.weirdStringException(this._valueClass, "not a valid float value");
/*      */       }
/*      */     }
/*  438 */     if (t == JsonToken.VALUE_NULL) {
/*  439 */       return 0.0F;
/*      */     }
/*      */ 
/*  442 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final Double _parseDouble(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  448 */     JsonToken t = jp.getCurrentToken();
/*      */ 
/*  450 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  451 */       return Double.valueOf(jp.getDoubleValue());
/*      */     }
/*  453 */     if (t == JsonToken.VALUE_STRING) {
/*  454 */       String text = jp.getText().trim();
/*  455 */       if (text.length() == 0) {
/*  456 */         return (Double)getEmptyValue();
/*      */       }
/*  458 */       switch (text.charAt(0)) {
/*      */       case 'I':
/*  460 */         if (("Infinity".equals(text)) || ("INF".equals(text))) {
/*  461 */           return Double.valueOf((1.0D / 0.0D));
/*      */         }
/*      */         break;
/*      */       case 'N':
/*  465 */         if ("NaN".equals(text)) {
/*  466 */           return Double.valueOf((0.0D / 0.0D));
/*      */         }
/*      */         break;
/*      */       case '-':
/*  470 */         if (("-Infinity".equals(text)) || ("-INF".equals(text)))
/*  471 */           return Double.valueOf((-1.0D / 0.0D));
/*      */         break;
/*      */       }
/*      */       try
/*      */       {
/*  476 */         return Double.valueOf(parseDouble(text));
/*      */       } catch (IllegalArgumentException iae) {
/*  478 */         throw ctxt.weirdStringException(this._valueClass, "not a valid Double value");
/*      */       }
/*      */     }
/*  480 */     if (t == JsonToken.VALUE_NULL) {
/*  481 */       return (Double)getNullValue();
/*      */     }
/*      */ 
/*  484 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected final double _parseDoublePrimitive(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  491 */     JsonToken t = jp.getCurrentToken();
/*      */ 
/*  493 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  494 */       return jp.getDoubleValue();
/*      */     }
/*      */ 
/*  497 */     if (t == JsonToken.VALUE_STRING) {
/*  498 */       String text = jp.getText().trim();
/*  499 */       if (text.length() == 0) {
/*  500 */         return 0.0D;
/*      */       }
/*  502 */       switch (text.charAt(0)) {
/*      */       case 'I':
/*  504 */         if (("Infinity".equals(text)) || ("INF".equals(text))) {
/*  505 */           return (1.0D / 0.0D);
/*      */         }
/*      */         break;
/*      */       case 'N':
/*  509 */         if ("NaN".equals(text)) {
/*  510 */           return (0.0D / 0.0D);
/*      */         }
/*      */         break;
/*      */       case '-':
/*  514 */         if (("-Infinity".equals(text)) || ("-INF".equals(text)))
/*  515 */           return (-1.0D / 0.0D);
/*      */         break;
/*      */       }
/*      */       try
/*      */       {
/*  520 */         return parseDouble(text);
/*      */       } catch (IllegalArgumentException iae) {
/*  522 */         throw ctxt.weirdStringException(this._valueClass, "not a valid double value");
/*      */       }
/*      */     }
/*  524 */     if (t == JsonToken.VALUE_NULL) {
/*  525 */       return 0.0D;
/*      */     }
/*      */ 
/*  528 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected java.util.Date _parseDate(JsonParser jp, DeserializationContext ctxt)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  535 */     JsonToken t = jp.getCurrentToken();
/*  536 */     if (t == JsonToken.VALUE_NUMBER_INT) {
/*  537 */       return new java.util.Date(jp.getLongValue());
/*      */     }
/*  539 */     if (t == JsonToken.VALUE_NULL) {
/*  540 */       return (java.util.Date)getNullValue();
/*      */     }
/*  542 */     if (t == JsonToken.VALUE_STRING)
/*      */     {
/*      */       try
/*      */       {
/*  547 */         String str = jp.getText().trim();
/*  548 */         if (str.length() == 0) {
/*  549 */           return (java.util.Date)getEmptyValue();
/*      */         }
/*  551 */         return ctxt.parseDate(str);
/*      */       } catch (IllegalArgumentException iae) {
/*  553 */         throw ctxt.weirdStringException(this._valueClass, "not a valid representation (error: " + iae.getMessage() + ")");
/*      */       }
/*      */     }
/*  556 */     throw ctxt.mappingException(this._valueClass, t);
/*      */   }
/*      */ 
/*      */   protected static final double parseDouble(String numStr)
/*      */     throws NumberFormatException
/*      */   {
/*  569 */     if ("2.2250738585072012e-308".equals(numStr)) {
/*  570 */       return 2.225073858507201E-308D;
/*      */     }
/*  572 */     return Double.parseDouble(numStr);
/*      */   }
/*      */ 
/*      */   protected JsonDeserializer<Object> findDeserializer(DeserializationConfig config, DeserializerProvider provider, JavaType type, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  596 */     JsonDeserializer deser = provider.findValueDeserializer(config, type, property);
/*  597 */     return deser;
/*      */   }
/*      */ 
/*      */   protected void handleUnknownProperty(JsonParser jp, DeserializationContext ctxt, Object instanceOrClass, String propName)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  627 */     if (instanceOrClass == null) {
/*  628 */       instanceOrClass = getValueClass();
/*      */     }
/*      */ 
/*  631 */     if (ctxt.handleUnknownProperty(jp, this, instanceOrClass, propName)) {
/*  632 */       return;
/*      */     }
/*      */ 
/*  635 */     reportUnknownProperty(ctxt, instanceOrClass, propName);
/*      */ 
/*  640 */     jp.skipChildren();
/*      */   }
/*      */ 
/*      */   protected void reportUnknownProperty(DeserializationContext ctxt, Object instanceOrClass, String fieldName)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/*  648 */     if (ctxt.isEnabled(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES))
/*  649 */       throw ctxt.unknownFieldException(instanceOrClass, fieldName);
/*      */   }
/*      */ 
/*      */   public static class StackTraceElementDeserializer extends StdScalarDeserializer<StackTraceElement>
/*      */   {
/*      */     public StackTraceElementDeserializer()
/*      */     {
/* 1076 */       super();
/*      */     }
/*      */ 
/*      */     public StackTraceElement deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/* 1082 */       JsonToken t = jp.getCurrentToken();
/*      */ 
/* 1084 */       if (t == JsonToken.START_OBJECT) {
/* 1085 */         String className = ""; String methodName = ""; String fileName = "";
/* 1086 */         int lineNumber = -1;
/*      */ 
/* 1088 */         while ((t = jp.nextValue()) != JsonToken.END_OBJECT) {
/* 1089 */           String propName = jp.getCurrentName();
/* 1090 */           if ("className".equals(propName))
/* 1091 */             className = jp.getText();
/* 1092 */           else if ("fileName".equals(propName))
/* 1093 */             fileName = jp.getText();
/* 1094 */           else if ("lineNumber".equals(propName)) {
/* 1095 */             if (t.isNumeric())
/* 1096 */               lineNumber = jp.getIntValue();
/*      */             else
/* 1098 */               throw JsonMappingException.from(jp, "Non-numeric token (" + t + ") for property 'lineNumber'");
/*      */           }
/* 1100 */           else if ("methodName".equals(propName))
/* 1101 */             methodName = jp.getText();
/* 1102 */           else if (!"nativeMethod".equals(propName))
/*      */           {
/* 1105 */             handleUnknownProperty(jp, ctxt, this._valueClass, propName);
/*      */           }
/*      */         }
/* 1108 */         return new StackTraceElement(className, methodName, fileName, lineNumber);
/*      */       }
/* 1110 */       throw ctxt.mappingException(this._valueClass, t);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class SqlDateDeserializer extends StdScalarDeserializer<java.sql.Date>
/*      */   {
/*      */     public SqlDateDeserializer()
/*      */     {
/* 1056 */       super();
/*      */     }
/*      */ 
/*      */     public java.sql.Date deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/* 1062 */       java.util.Date d = _parseDate(jp, ctxt);
/* 1063 */       return d == null ? null : new java.sql.Date(d.getTime());
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static class BigIntegerDeserializer extends StdScalarDeserializer<BigInteger>
/*      */   {
/*      */     public BigIntegerDeserializer()
/*      */     {
/* 1007 */       super();
/*      */     }
/*      */ 
/*      */     public BigInteger deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/* 1013 */       JsonToken t = jp.getCurrentToken();
/*      */ 
/* 1016 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1017 */         switch (StdDeserializer.1.$SwitchMap$org$codehaus$jackson$JsonParser$NumberType[jp.getNumberType().ordinal()]) {
/*      */         case 1:
/*      */         case 2:
/* 1020 */           return BigInteger.valueOf(jp.getLongValue());
/*      */         }
/*      */       } else { if (t == JsonToken.VALUE_NUMBER_FLOAT)
/*      */         {
/* 1026 */           return jp.getDecimalValue().toBigInteger();
/* 1027 */         }if (t != JsonToken.VALUE_STRING)
/*      */         {
/* 1029 */           throw ctxt.mappingException(this._valueClass, t);
/*      */         } }
/* 1031 */       String text = jp.getText().trim();
/* 1032 */       if (text.length() == 0)
/* 1033 */         return null;
/*      */       try
/*      */       {
/* 1036 */         return new BigInteger(text); } catch (IllegalArgumentException iae) {
/*      */       }
/* 1038 */       throw ctxt.weirdStringException(this._valueClass, "not a valid representation");
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static class BigDecimalDeserializer extends StdScalarDeserializer<BigDecimal>
/*      */   {
/*      */     public BigDecimalDeserializer()
/*      */     {
/*  972 */       super();
/*      */     }
/*      */ 
/*      */     public BigDecimal deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  978 */       JsonToken t = jp.getCurrentToken();
/*  979 */       if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT)) {
/*  980 */         return jp.getDecimalValue();
/*      */       }
/*      */ 
/*  983 */       if (t == JsonToken.VALUE_STRING) {
/*  984 */         String text = jp.getText().trim();
/*  985 */         if (text.length() == 0)
/*  986 */           return null;
/*      */         try
/*      */         {
/*  989 */           return new BigDecimal(text);
/*      */         } catch (IllegalArgumentException iae) {
/*  991 */           throw ctxt.weirdStringException(this._valueClass, "not a valid representation");
/*      */         }
/*      */       }
/*      */ 
/*  995 */       throw ctxt.mappingException(this._valueClass, t);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class NumberDeserializer extends StdScalarDeserializer<Number>
/*      */   {
/*      */     public NumberDeserializer()
/*      */     {
/*  887 */       super();
/*      */     }
/*      */ 
/*      */     public Number deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  893 */       JsonToken t = jp.getCurrentToken();
/*  894 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  895 */         if (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_INTEGER_FOR_INTS)) {
/*  896 */           return jp.getBigIntegerValue();
/*      */         }
/*  898 */         return jp.getNumberValue();
/*  899 */       }if (t == JsonToken.VALUE_NUMBER_FLOAT)
/*      */       {
/*  903 */         if (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  904 */           return jp.getDecimalValue();
/*      */         }
/*  906 */         return Double.valueOf(jp.getDoubleValue());
/*      */       }
/*      */ 
/*  912 */       if (t == JsonToken.VALUE_STRING) {
/*  913 */         String text = jp.getText().trim();
/*      */         try {
/*  915 */           if (text.indexOf('.') >= 0)
/*      */           {
/*  917 */             if (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  918 */               return new BigDecimal(text);
/*      */             }
/*  920 */             return new Double(text);
/*      */           }
/*      */ 
/*  923 */           if (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_INTEGER_FOR_INTS)) {
/*  924 */             return new BigInteger(text);
/*      */           }
/*  926 */           long value = Long.parseLong(text);
/*  927 */           if ((value <= 2147483647L) && (value >= -2147483648L)) {
/*  928 */             return Integer.valueOf((int)value);
/*      */           }
/*  930 */           return Long.valueOf(value);
/*      */         } catch (IllegalArgumentException iae) {
/*  932 */           throw ctxt.weirdStringException(this._valueClass, "not a valid number");
/*      */         }
/*      */       }
/*      */ 
/*  936 */       throw ctxt.mappingException(this._valueClass, t);
/*      */     }
/*      */ 
/*      */     public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  950 */       switch (StdDeserializer.1.$SwitchMap$org$codehaus$jackson$JsonToken[jp.getCurrentToken().ordinal()])
/*      */       {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*  955 */         return deserialize(jp, ctxt);
/*      */       }
/*  957 */       return typeDeserializer.deserializeTypedFromScalar(jp, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class DoubleDeserializer extends StdDeserializer.PrimitiveOrWrapperDeserializer<Double>
/*      */   {
/*      */     public DoubleDeserializer(Class<Double> cls, Double nvl)
/*      */     {
/*  852 */       super(nvl);
/*      */     }
/*      */ 
/*      */     public Double deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  859 */       return _parseDouble(jp, ctxt);
/*      */     }
/*      */ 
/*      */     public Double deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  869 */       return _parseDouble(jp, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class FloatDeserializer extends StdDeserializer.PrimitiveOrWrapperDeserializer<Float>
/*      */   {
/*      */     public FloatDeserializer(Class<Float> cls, Float nvl)
/*      */     {
/*  832 */       super(nvl);
/*      */     }
/*      */ 
/*      */     public Float deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  842 */       return _parseFloat(jp, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class LongDeserializer extends StdDeserializer.PrimitiveOrWrapperDeserializer<Long>
/*      */   {
/*      */     public LongDeserializer(Class<Long> cls, Long nvl)
/*      */     {
/*  815 */       super(nvl);
/*      */     }
/*      */ 
/*      */     public Long deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  822 */       return _parseLong(jp, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class IntegerDeserializer extends StdDeserializer.PrimitiveOrWrapperDeserializer<Integer>
/*      */   {
/*      */     public IntegerDeserializer(Class<Integer> cls, Integer nvl)
/*      */     {
/*  788 */       super(nvl);
/*      */     }
/*      */ 
/*      */     public Integer deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  795 */       return _parseInteger(jp, ctxt);
/*      */     }
/*      */ 
/*      */     public Integer deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  805 */       return _parseInteger(jp, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class CharacterDeserializer extends StdDeserializer.PrimitiveOrWrapperDeserializer<Character>
/*      */   {
/*      */     public CharacterDeserializer(Class<Character> cls, Character nvl)
/*      */     {
/*  752 */       super(nvl);
/*      */     }
/*      */ 
/*      */     public Character deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  759 */       JsonToken t = jp.getCurrentToken();
/*      */ 
/*  762 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  763 */         int value = jp.getIntValue();
/*  764 */         if ((value >= 0) && (value <= 65535))
/*  765 */           return Character.valueOf((char)value);
/*      */       }
/*  767 */       else if (t == JsonToken.VALUE_STRING)
/*      */       {
/*  769 */         String text = jp.getText();
/*  770 */         if (text.length() == 1) {
/*  771 */           return Character.valueOf(text.charAt(0));
/*      */         }
/*      */ 
/*  774 */         if (text.length() == 0) {
/*  775 */           return (Character)getEmptyValue();
/*      */         }
/*      */       }
/*  778 */       throw ctxt.mappingException(this._valueClass, t);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class ShortDeserializer extends StdDeserializer.PrimitiveOrWrapperDeserializer<Short>
/*      */   {
/*      */     public ShortDeserializer(Class<Short> cls, Short nvl)
/*      */     {
/*  735 */       super(nvl);
/*      */     }
/*      */ 
/*      */     public Short deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  742 */       return _parseShort(jp, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class ByteDeserializer extends StdDeserializer.PrimitiveOrWrapperDeserializer<Byte>
/*      */   {
/*      */     public ByteDeserializer(Class<Byte> cls, Byte nvl)
/*      */     {
/*  718 */       super(nvl);
/*      */     }
/*      */ 
/*      */     public Byte deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  725 */       return _parseByte(jp, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static final class BooleanDeserializer extends StdDeserializer.PrimitiveOrWrapperDeserializer<Boolean>
/*      */   {
/*      */     public BooleanDeserializer(Class<Boolean> cls, Boolean nvl)
/*      */     {
/*  691 */       super(nvl);
/*      */     }
/*      */ 
/*      */     public Boolean deserialize(JsonParser jp, DeserializationContext ctxt)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  698 */       return _parseBoolean(jp, ctxt);
/*      */     }
/*      */ 
/*      */     public Boolean deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */       throws IOException, JsonProcessingException
/*      */     {
/*  708 */       return _parseBoolean(jp, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected static abstract class PrimitiveOrWrapperDeserializer<T> extends StdScalarDeserializer<T>
/*      */   {
/*      */     final T _nullValue;
/*      */ 
/*      */     protected PrimitiveOrWrapperDeserializer(Class<T> vc, T nvl)
/*      */     {
/*  669 */       super();
/*  670 */       this._nullValue = nvl;
/*      */     }
/*      */ 
/*      */     public final T getNullValue()
/*      */     {
/*  675 */       return this._nullValue;
/*      */     }
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.StdDeserializer
 * JD-Core Version:    0.6.2
 */