/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.io.NumberInput;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.KeyDeserializer;
/*     */ import org.codehaus.jackson.map.util.EnumResolver;
/*     */ 
/*     */ public abstract class StdKeyDeserializer extends KeyDeserializer
/*     */ {
/*     */   protected final Class<?> _keyClass;
/*     */ 
/*     */   protected StdKeyDeserializer(Class<?> cls)
/*     */   {
/*  22 */     this._keyClass = cls;
/*     */   }
/*     */ 
/*     */   public final Object deserializeKey(String key, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  28 */     if (key == null)
/*  29 */       return null;
/*     */     try
/*     */     {
/*  32 */       Object result = _parse(key, ctxt);
/*  33 */       if (result != null)
/*  34 */         return result;
/*     */     }
/*     */     catch (Exception re) {
/*  37 */       throw ctxt.weirdKeyException(this._keyClass, key, "not a valid representation: " + re.getMessage());
/*     */     }
/*  39 */     throw ctxt.weirdKeyException(this._keyClass, key, "not a valid representation");
/*     */   }
/*     */   public Class<?> getKeyClass() {
/*  42 */     return this._keyClass;
/*     */   }
/*     */ 
/*     */   protected abstract Object _parse(String paramString, DeserializationContext paramDeserializationContext)
/*     */     throws Exception;
/*     */ 
/*     */   protected int _parseInt(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  54 */     return Integer.parseInt(key);
/*     */   }
/*     */ 
/*     */   protected long _parseLong(String key) throws IllegalArgumentException
/*     */   {
/*  59 */     return Long.parseLong(key);
/*     */   }
/*     */ 
/*     */   protected double _parseDouble(String key) throws IllegalArgumentException
/*     */   {
/*  64 */     return NumberInput.parseDouble(key);
/*     */   }
/*     */ 
/*     */   static final class StringFactoryKeyDeserializer extends StdKeyDeserializer
/*     */   {
/*     */     final Method _factoryMethod;
/*     */ 
/*     */     public StringFactoryKeyDeserializer(Method fm)
/*     */     {
/* 241 */       super();
/* 242 */       this._factoryMethod = fm;
/*     */     }
/*     */ 
/*     */     public Object _parse(String key, DeserializationContext ctxt)
/*     */       throws Exception
/*     */     {
/* 248 */       return this._factoryMethod.invoke(null, new Object[] { key });
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class StringCtorKeyDeserializer extends StdKeyDeserializer
/*     */   {
/*     */     protected final Constructor<?> _ctor;
/*     */ 
/*     */     public StringCtorKeyDeserializer(Constructor<?> ctor)
/*     */     {
/* 221 */       super();
/* 222 */       this._ctor = ctor;
/*     */     }
/*     */ 
/*     */     public Object _parse(String key, DeserializationContext ctxt)
/*     */       throws Exception
/*     */     {
/* 228 */       return this._ctor.newInstance(new Object[] { key });
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class EnumKD extends StdKeyDeserializer
/*     */   {
/*     */     protected final EnumResolver<?> _resolver;
/*     */ 
/*     */     protected EnumKD(EnumResolver<?> er)
/*     */     {
/* 197 */       super();
/* 198 */       this._resolver = er;
/*     */     }
/*     */ 
/*     */     public Enum<?> _parse(String key, DeserializationContext ctxt)
/*     */       throws JsonMappingException
/*     */     {
/* 204 */       Enum e = this._resolver.findEnum(key);
/* 205 */       if (e == null) {
/* 206 */         throw ctxt.weirdKeyException(this._keyClass, key, "not one of values for Enum class");
/*     */       }
/* 208 */       return e;
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class FloatKD extends StdKeyDeserializer
/*     */   {
/*     */     FloatKD()
/*     */     {
/* 173 */       super();
/*     */     }
/*     */ 
/*     */     public Float _parse(String key, DeserializationContext ctxt)
/*     */       throws JsonMappingException
/*     */     {
/* 181 */       return Float.valueOf((float)_parseDouble(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class DoubleKD extends StdKeyDeserializer
/*     */   {
/*     */     DoubleKD()
/*     */     {
/* 162 */       super();
/*     */     }
/*     */ 
/*     */     public Double _parse(String key, DeserializationContext ctxt) throws JsonMappingException
/*     */     {
/* 167 */       return Double.valueOf(_parseDouble(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class LongKD extends StdKeyDeserializer
/*     */   {
/*     */     LongKD()
/*     */     {
/* 151 */       super();
/*     */     }
/*     */ 
/*     */     public Long _parse(String key, DeserializationContext ctxt) throws JsonMappingException
/*     */     {
/* 156 */       return Long.valueOf(_parseLong(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class IntKD extends StdKeyDeserializer
/*     */   {
/*     */     IntKD()
/*     */     {
/* 140 */       super();
/*     */     }
/*     */ 
/*     */     public Integer _parse(String key, DeserializationContext ctxt) throws JsonMappingException
/*     */     {
/* 145 */       return Integer.valueOf(_parseInt(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class CharKD extends StdKeyDeserializer
/*     */   {
/*     */     CharKD()
/*     */     {
/* 126 */       super();
/*     */     }
/*     */ 
/*     */     public Character _parse(String key, DeserializationContext ctxt) throws JsonMappingException
/*     */     {
/* 131 */       if (key.length() == 1) {
/* 132 */         return Character.valueOf(key.charAt(0));
/*     */       }
/* 134 */       throw ctxt.weirdKeyException(this._keyClass, key, "can only convert 1-character Strings");
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class ShortKD extends StdKeyDeserializer
/*     */   {
/*     */     ShortKD()
/*     */     {
/* 107 */       super();
/*     */     }
/*     */ 
/*     */     public Short _parse(String key, DeserializationContext ctxt) throws JsonMappingException
/*     */     {
/* 112 */       int value = _parseInt(key);
/* 113 */       if ((value < -32768) || (value > 32767)) {
/* 114 */         throw ctxt.weirdKeyException(this._keyClass, key, "overflow, value can not be represented as 16-bit value");
/*     */       }
/* 116 */       return Short.valueOf((short)value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class ByteKD extends StdKeyDeserializer
/*     */   {
/*     */     ByteKD()
/*     */     {
/*  92 */       super();
/*     */     }
/*     */ 
/*     */     public Byte _parse(String key, DeserializationContext ctxt) throws JsonMappingException
/*     */     {
/*  97 */       int value = _parseInt(key);
/*  98 */       if ((value < -128) || (value > 127)) {
/*  99 */         throw ctxt.weirdKeyException(this._keyClass, key, "overflow, value can not be represented as 8-bit value");
/*     */       }
/* 101 */       return Byte.valueOf((byte)value);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class BoolKD extends StdKeyDeserializer
/*     */   {
/*     */     BoolKD()
/*     */     {
/*  75 */       super();
/*     */     }
/*     */ 
/*     */     public Boolean _parse(String key, DeserializationContext ctxt) throws JsonMappingException
/*     */     {
/*  80 */       if ("true".equals(key)) {
/*  81 */         return Boolean.TRUE;
/*     */       }
/*  83 */       if ("false".equals(key)) {
/*  84 */         return Boolean.FALSE;
/*     */       }
/*  86 */       throw ctxt.weirdKeyException(this._keyClass, key, "value not 'true' or 'false'");
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.StdKeyDeserializer
 * JD-Core Version:    0.6.2
 */