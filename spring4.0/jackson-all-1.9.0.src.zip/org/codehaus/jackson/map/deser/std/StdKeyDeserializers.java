/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import org.codehaus.jackson.map.DeserializationConfig;
/*    */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*    */ import org.codehaus.jackson.map.KeyDeserializer;
/*    */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*    */ import org.codehaus.jackson.map.type.TypeFactory;
/*    */ import org.codehaus.jackson.map.util.ClassUtil;
/*    */ import org.codehaus.jackson.map.util.EnumResolver;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class StdKeyDeserializers
/*    */ {
/* 29 */   protected final HashMap<JavaType, KeyDeserializer> _keyDeserializers = new HashMap();
/*    */ 
/*    */   protected StdKeyDeserializers()
/*    */   {
/* 33 */     add(new StdKeyDeserializer.BoolKD());
/* 34 */     add(new StdKeyDeserializer.ByteKD());
/* 35 */     add(new StdKeyDeserializer.CharKD());
/* 36 */     add(new StdKeyDeserializer.ShortKD());
/* 37 */     add(new StdKeyDeserializer.IntKD());
/* 38 */     add(new StdKeyDeserializer.LongKD());
/* 39 */     add(new StdKeyDeserializer.FloatKD());
/* 40 */     add(new StdKeyDeserializer.DoubleKD());
/*    */   }
/*    */ 
/*    */   private void add(StdKeyDeserializer kdeser)
/*    */   {
/* 45 */     Class keyClass = kdeser.getKeyClass();
/*    */ 
/* 49 */     this._keyDeserializers.put(TypeFactory.defaultInstance().constructType(keyClass), kdeser);
/*    */   }
/*    */ 
/*    */   public static HashMap<JavaType, KeyDeserializer> constructAll()
/*    */   {
/* 54 */     return new StdKeyDeserializers()._keyDeserializers;
/*    */   }
/*    */ 
/*    */   public static KeyDeserializer constructEnumKeyDeserializer(DeserializationConfig config, JavaType type)
/*    */   {
/* 65 */     EnumResolver er = EnumResolver.constructUnsafe(type.getRawClass(), config.getAnnotationIntrospector());
/* 66 */     return new StdKeyDeserializer.EnumKD(er);
/*    */   }
/*    */ 
/*    */   public static KeyDeserializer findStringBasedKeyDeserializer(DeserializationConfig config, JavaType type)
/*    */   {
/* 74 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspect(type);
/*    */ 
/* 76 */     Constructor ctor = beanDesc.findSingleArgConstructor(new Class[] { String.class });
/* 77 */     if (ctor != null) {
/* 78 */       if (config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 79 */         ClassUtil.checkAndFixAccess(ctor);
/*    */       }
/* 81 */       return new StdKeyDeserializer.StringCtorKeyDeserializer(ctor);
/*    */     }
/*    */ 
/* 86 */     Method m = beanDesc.findFactoryMethod(new Class[] { String.class });
/* 87 */     if (m != null) {
/* 88 */       if (config.isEnabled(DeserializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 89 */         ClassUtil.checkAndFixAccess(m);
/*    */       }
/* 91 */       return new StdKeyDeserializer.StringFactoryKeyDeserializer(m);
/*    */     }
/*    */ 
/* 94 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.StdKeyDeserializers
 * JD-Core Version:    0.6.2
 */