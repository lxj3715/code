/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public abstract class StdScalarDeserializer<T> extends StdDeserializer<T>
/*    */ {
/*    */   protected StdScalarDeserializer(Class<?> vc)
/*    */   {
/* 20 */     super(vc);
/*    */   }
/*    */ 
/*    */   protected StdScalarDeserializer(JavaType valueType) {
/* 24 */     super(valueType);
/*    */   }
/*    */ 
/*    */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 32 */     return typeDeserializer.deserializeTypedFromScalar(jp, ctxt);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.StdScalarDeserializer
 * JD-Core Version:    0.6.2
 */