/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ import org.codehaus.jackson.map.deser.impl.CreatorProperty;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedWithParams;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class StdValueInstantiator extends ValueInstantiator
/*     */ {
/*     */   protected final String _valueTypeDesc;
/*     */   protected final boolean _cfgEmptyStringsAsObjects;
/*     */   protected AnnotatedWithParams _defaultCreator;
/*     */   protected CreatorProperty[] _constructorArguments;
/*     */   protected AnnotatedWithParams _withArgsCreator;
/*     */   protected JavaType _delegateType;
/*     */   protected AnnotatedWithParams _delegateCreator;
/*     */   protected AnnotatedWithParams _fromStringCreator;
/*     */   protected AnnotatedWithParams _fromIntCreator;
/*     */   protected AnnotatedWithParams _fromLongCreator;
/*     */   protected AnnotatedWithParams _fromDoubleCreator;
/*     */   protected AnnotatedWithParams _fromBooleanCreator;
/*     */ 
/*     */   public StdValueInstantiator(DeserializationConfig config, Class<?> valueType)
/*     */   {
/*  70 */     this._cfgEmptyStringsAsObjects = (config == null ? false : config.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
/*     */ 
/*  72 */     this._valueTypeDesc = (valueType == null ? "UNKNOWN TYPE" : valueType.getName());
/*     */   }
/*     */ 
/*     */   public StdValueInstantiator(DeserializationConfig config, JavaType valueType)
/*     */   {
/*  77 */     this._cfgEmptyStringsAsObjects = (config == null ? false : config.isEnabled(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
/*     */ 
/*  79 */     this._valueTypeDesc = (valueType == null ? "UNKNOWN TYPE" : valueType.toString());
/*     */   }
/*     */ 
/*     */   protected StdValueInstantiator(StdValueInstantiator src)
/*     */   {
/*  88 */     this._cfgEmptyStringsAsObjects = src._cfgEmptyStringsAsObjects;
/*  89 */     this._valueTypeDesc = src._valueTypeDesc;
/*     */ 
/*  91 */     this._defaultCreator = src._defaultCreator;
/*     */ 
/*  93 */     this._constructorArguments = src._constructorArguments;
/*  94 */     this._withArgsCreator = src._withArgsCreator;
/*     */ 
/*  96 */     this._delegateType = src._delegateType;
/*  97 */     this._delegateCreator = src._delegateCreator;
/*     */ 
/*  99 */     this._fromStringCreator = src._fromStringCreator;
/* 100 */     this._fromIntCreator = src._fromIntCreator;
/* 101 */     this._fromLongCreator = src._fromLongCreator;
/* 102 */     this._fromDoubleCreator = src._fromDoubleCreator;
/* 103 */     this._fromBooleanCreator = src._fromBooleanCreator;
/*     */   }
/*     */ 
/*     */   public void configureFromObjectSettings(AnnotatedWithParams defaultCreator, AnnotatedWithParams delegateCreator, JavaType delegateType, AnnotatedWithParams withArgsCreator, CreatorProperty[] constructorArgs)
/*     */   {
/* 115 */     this._defaultCreator = defaultCreator;
/* 116 */     this._delegateCreator = delegateCreator;
/* 117 */     this._delegateType = delegateType;
/* 118 */     this._withArgsCreator = withArgsCreator;
/* 119 */     this._constructorArguments = constructorArgs;
/*     */   }
/*     */ 
/*     */   public void configureFromStringCreator(AnnotatedWithParams creator) {
/* 123 */     this._fromStringCreator = creator;
/*     */   }
/*     */ 
/*     */   public void configureFromIntCreator(AnnotatedWithParams creator) {
/* 127 */     this._fromIntCreator = creator;
/*     */   }
/*     */ 
/*     */   public void configureFromLongCreator(AnnotatedWithParams creator) {
/* 131 */     this._fromLongCreator = creator;
/*     */   }
/*     */ 
/*     */   public void configureFromDoubleCreator(AnnotatedWithParams creator) {
/* 135 */     this._fromDoubleCreator = creator;
/*     */   }
/*     */ 
/*     */   public void configureFromBooleanCreator(AnnotatedWithParams creator) {
/* 139 */     this._fromBooleanCreator = creator;
/*     */   }
/*     */ 
/*     */   public String getValueTypeDesc()
/*     */   {
/* 150 */     return this._valueTypeDesc;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromString()
/*     */   {
/* 155 */     return this._fromStringCreator != null;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromInt()
/*     */   {
/* 160 */     return this._fromIntCreator != null;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromLong()
/*     */   {
/* 165 */     return this._fromLongCreator != null;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromDouble()
/*     */   {
/* 170 */     return this._fromDoubleCreator != null;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromBoolean()
/*     */   {
/* 175 */     return this._fromBooleanCreator != null;
/*     */   }
/*     */ 
/*     */   public boolean canCreateUsingDefault()
/*     */   {
/* 180 */     return this._defaultCreator != null;
/*     */   }
/*     */ 
/*     */   public boolean canCreateFromObjectWith()
/*     */   {
/* 185 */     return this._withArgsCreator != null;
/*     */   }
/*     */ 
/*     */   public JavaType getDelegateType()
/*     */   {
/* 190 */     return this._delegateType;
/*     */   }
/*     */ 
/*     */   public SettableBeanProperty[] getFromObjectArguments()
/*     */   {
/* 195 */     return this._constructorArguments;
/*     */   }
/*     */ 
/*     */   public Object createUsingDefault()
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 208 */     if (this._defaultCreator == null)
/* 209 */       throw new IllegalStateException("No default constructor for " + getValueTypeDesc());
/*     */     try
/*     */     {
/* 212 */       return this._defaultCreator.call();
/*     */     } catch (ExceptionInInitializerError e) {
/* 214 */       throw wrapException(e);
/*     */     } catch (Exception e) {
/* 216 */       throw wrapException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object createFromObjectWith(Object[] args)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 224 */     if (this._withArgsCreator == null)
/* 225 */       throw new IllegalStateException("No with-args constructor for " + getValueTypeDesc());
/*     */     try
/*     */     {
/* 228 */       return this._withArgsCreator.call(args);
/*     */     } catch (ExceptionInInitializerError e) {
/* 230 */       throw wrapException(e);
/*     */     } catch (Exception e) {
/* 232 */       throw wrapException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object createUsingDelegate(Object delegate)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 240 */     if (this._delegateCreator == null)
/* 241 */       throw new IllegalStateException("No delegate constructor for " + getValueTypeDesc());
/*     */     try
/*     */     {
/* 244 */       return this._delegateCreator.call1(delegate);
/*     */     } catch (ExceptionInInitializerError e) {
/* 246 */       throw wrapException(e);
/*     */     } catch (Exception e) {
/* 248 */       throw wrapException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object createFromString(String value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 261 */     if (this._fromStringCreator != null) {
/*     */       try {
/* 263 */         return this._fromStringCreator.call1(value);
/*     */       } catch (Exception e) {
/* 265 */         throw wrapException(e);
/*     */       }
/*     */     }
/* 268 */     return _createFromStringFallbacks(value);
/*     */   }
/*     */ 
/*     */   public Object createFromInt(int value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*     */     try
/*     */     {
/* 276 */       if (this._fromIntCreator != null) {
/* 277 */         return this._fromIntCreator.call1(Integer.valueOf(value));
/*     */       }
/*     */ 
/* 280 */       if (this._fromLongCreator != null)
/* 281 */         return this._fromLongCreator.call1(Long.valueOf(value));
/*     */     }
/*     */     catch (Exception e) {
/* 284 */       throw wrapException(e);
/*     */     }
/* 286 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON integral number; no single-int-arg constructor/factory method");
/*     */   }
/*     */ 
/*     */   public Object createFromLong(long value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*     */     try
/*     */     {
/* 294 */       if (this._fromLongCreator != null)
/* 295 */         return this._fromLongCreator.call1(Long.valueOf(value));
/*     */     }
/*     */     catch (Exception e) {
/* 298 */       throw wrapException(e);
/*     */     }
/* 300 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON long integral number; no single-long-arg constructor/factory method");
/*     */   }
/*     */ 
/*     */   public Object createFromDouble(double value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*     */     try
/*     */     {
/* 308 */       if (this._fromDoubleCreator != null)
/* 309 */         return this._fromDoubleCreator.call1(Double.valueOf(value));
/*     */     }
/*     */     catch (Exception e) {
/* 312 */       throw wrapException(e);
/*     */     }
/* 314 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON floating-point number; no one-double/Double-arg constructor/factory method");
/*     */   }
/*     */ 
/*     */   public Object createFromBoolean(boolean value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*     */     try
/*     */     {
/* 322 */       if (this._fromBooleanCreator != null)
/* 323 */         return this._fromBooleanCreator.call1(Boolean.valueOf(value));
/*     */     }
/*     */     catch (Exception e) {
/* 326 */       throw wrapException(e);
/*     */     }
/* 328 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON boolean value; no single-boolean/Boolean-arg constructor/factory method");
/*     */   }
/*     */ 
/*     */   public AnnotatedWithParams getDelegateCreator()
/*     */   {
/* 340 */     return this._delegateCreator;
/*     */   }
/*     */ 
/*     */   public AnnotatedWithParams getDefaultCreator()
/*     */   {
/* 345 */     return this._defaultCreator;
/*     */   }
/*     */ 
/*     */   public AnnotatedWithParams getWithArgsCreator()
/*     */   {
/* 350 */     return this._withArgsCreator;
/*     */   }
/*     */ 
/*     */   protected Object _createFromStringFallbacks(String value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 365 */     if (this._fromBooleanCreator != null) {
/* 366 */       String str = value.trim();
/* 367 */       if ("true".equals(str)) {
/* 368 */         return createFromBoolean(true);
/*     */       }
/* 370 */       if ("false".equals(str)) {
/* 371 */         return createFromBoolean(false);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 376 */     if ((this._cfgEmptyStringsAsObjects) && (value.length() == 0)) {
/* 377 */       return null;
/*     */     }
/* 379 */     throw new JsonMappingException("Can not instantiate value of type " + getValueTypeDesc() + " from JSON String; no single-String constructor/factory method");
/*     */   }
/*     */ 
/*     */   protected JsonMappingException wrapException(Throwable t)
/*     */   {
/* 385 */     while (t.getCause() != null) {
/* 386 */       t = t.getCause();
/*     */     }
/* 388 */     return new JsonMappingException("Instantiation of " + getValueTypeDesc() + " value failed: " + t.getMessage(), t);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.StdValueInstantiator
 * JD-Core Version:    0.6.2
 */