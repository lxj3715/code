/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.BeanProperty.Std;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.ResolvableDeserializer;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedWithParams;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public final class StringCollectionDeserializer extends ContainerDeserializerBase<Collection<String>>
/*     */   implements ResolvableDeserializer
/*     */ {
/*     */   protected final JavaType _collectionType;
/*     */   protected final JsonDeserializer<String> _valueDeserializer;
/*     */   protected final boolean _isDefaultDeserializer;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected JsonDeserializer<Object> _delegateDeserializer;
/*     */ 
/*     */   public StringCollectionDeserializer(JavaType collectionType, JsonDeserializer<?> valueDeser, ValueInstantiator valueInstantiator)
/*     */   {
/*  65 */     super(collectionType.getRawClass());
/*  66 */     this._collectionType = collectionType;
/*  67 */     this._valueDeserializer = valueDeser;
/*  68 */     this._valueInstantiator = valueInstantiator;
/*  69 */     this._isDefaultDeserializer = isDefaultSerializer(valueDeser);
/*     */   }
/*     */ 
/*     */   protected StringCollectionDeserializer(StringCollectionDeserializer src)
/*     */   {
/*  80 */     super(src._valueClass);
/*  81 */     this._collectionType = src._collectionType;
/*  82 */     this._valueDeserializer = src._valueDeserializer;
/*  83 */     this._valueInstantiator = src._valueInstantiator;
/*  84 */     this._isDefaultDeserializer = src._isDefaultDeserializer;
/*     */   }
/*     */ 
/*     */   public void resolve(DeserializationConfig config, DeserializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 103 */     AnnotatedWithParams delegateCreator = this._valueInstantiator.getDelegateCreator();
/* 104 */     if (delegateCreator != null) {
/* 105 */       JavaType delegateType = this._valueInstantiator.getDelegateType();
/*     */ 
/* 107 */       BeanProperty.Std property = new BeanProperty.Std(null, delegateType, null, delegateCreator);
/*     */ 
/* 109 */       this._delegateDeserializer = findDeserializer(config, provider, delegateType, property);
/*     */     }
/*     */   }
/*     */ 
/*     */   public JavaType getContentType()
/*     */   {
/* 121 */     return this._collectionType.getContentType();
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> getContentDeserializer()
/*     */   {
/* 127 */     JsonDeserializer deser = this._valueDeserializer;
/* 128 */     return deser;
/*     */   }
/*     */ 
/*     */   public Collection<String> deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 142 */     if (this._delegateDeserializer != null) {
/* 143 */       return (Collection)this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*     */     }
/* 145 */     Collection result = (Collection)this._valueInstantiator.createUsingDefault();
/* 146 */     return deserialize(jp, ctxt, result);
/*     */   }
/*     */ 
/*     */   public Collection<String> deserialize(JsonParser jp, DeserializationContext ctxt, Collection<String> result)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 155 */     if (!jp.isExpectedStartArrayToken()) {
/* 156 */       return handleNonArray(jp, ctxt, result);
/*     */     }
/*     */ 
/* 159 */     if (!this._isDefaultDeserializer)
/* 160 */       return deserializeUsingCustom(jp, ctxt, result);
/*     */     JsonToken t;
/* 164 */     while ((t = jp.nextToken()) != JsonToken.END_ARRAY) {
/* 165 */       result.add(t == JsonToken.VALUE_NULL ? null : jp.getText());
/*     */     }
/* 167 */     return result;
/*     */   }
/*     */ 
/*     */   private Collection<String> deserializeUsingCustom(JsonParser jp, DeserializationContext ctxt, Collection<String> result)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 175 */     JsonDeserializer deser = this._valueDeserializer;
/*     */     JsonToken t;
/* 177 */     while ((t = jp.nextToken()) != JsonToken.END_ARRAY)
/*     */     {
/*     */       String value;
/*     */       String value;
/* 180 */       if (t == JsonToken.VALUE_NULL)
/* 181 */         value = null;
/*     */       else {
/* 183 */         value = (String)deser.deserialize(jp, ctxt);
/*     */       }
/* 185 */       result.add(value);
/*     */     }
/* 187 */     return result;
/*     */   }
/*     */ 
/*     */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 196 */     return typeDeserializer.deserializeTypedFromArray(jp, ctxt);
/*     */   }
/*     */ 
/*     */   private final Collection<String> handleNonArray(JsonParser jp, DeserializationContext ctxt, Collection<String> result)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 209 */     if (!ctxt.isEnabled(DeserializationConfig.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)) {
/* 210 */       throw ctxt.mappingException(this._collectionType.getRawClass());
/*     */     }
/*     */ 
/* 213 */     JsonDeserializer valueDes = this._valueDeserializer;
/* 214 */     JsonToken t = jp.getCurrentToken();
/*     */     String value;
/*     */     String value;
/* 218 */     if (t == JsonToken.VALUE_NULL)
/* 219 */       value = null;
/*     */     else {
/* 221 */       value = valueDes == null ? jp.getText() : (String)valueDes.deserialize(jp, ctxt);
/*     */     }
/* 223 */     result.add(value);
/* 224 */     return result;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.StringCollectionDeserializer
 * JD-Core Version:    0.6.2
 */