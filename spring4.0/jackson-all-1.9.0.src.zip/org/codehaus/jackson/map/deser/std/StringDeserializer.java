/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.Base64Variant;
/*    */ import org.codehaus.jackson.Base64Variants;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class StringDeserializer extends StdScalarDeserializer<String>
/*    */ {
/*    */   public StringDeserializer()
/*    */   {
/* 17 */     super(String.class);
/*    */   }
/*    */ 
/*    */   public String deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 23 */     JsonToken curr = jp.getCurrentToken();
/*    */ 
/* 25 */     if (curr == JsonToken.VALUE_STRING) {
/* 26 */       return jp.getText();
/*    */     }
/*    */ 
/* 29 */     if (curr == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 30 */       Object ob = jp.getEmbeddedObject();
/* 31 */       if (ob == null) {
/* 32 */         return null;
/*    */       }
/* 34 */       if ((ob instanceof byte[])) {
/* 35 */         return Base64Variants.getDefaultVariant().encode((byte[])ob, false);
/*    */       }
/*    */ 
/* 38 */       return ob.toString();
/*    */     }
/*    */ 
/* 41 */     if (curr.isScalarValue()) {
/* 42 */       return jp.getText();
/*    */     }
/* 44 */     throw ctxt.mappingException(this._valueClass, curr);
/*    */   }
/*    */ 
/*    */   public String deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 54 */     return deserialize(jp, ctxt);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.StringDeserializer
 * JD-Core Version:    0.6.2
 */