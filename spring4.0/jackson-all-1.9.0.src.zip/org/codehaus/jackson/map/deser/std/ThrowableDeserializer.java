/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.deser.BeanDeserializer;
/*     */ import org.codehaus.jackson.map.deser.SettableAnyProperty;
/*     */ import org.codehaus.jackson.map.deser.SettableBeanProperty;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ import org.codehaus.jackson.map.deser.impl.BeanPropertyMap;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class ThrowableDeserializer extends BeanDeserializer
/*     */ {
/*     */   protected static final String PROP_NAME_MESSAGE = "message";
/*     */ 
/*     */   public ThrowableDeserializer(BeanDeserializer baseDeserializer)
/*     */   {
/*  32 */     super(baseDeserializer);
/*     */   }
/*     */ 
/*     */   protected ThrowableDeserializer(BeanDeserializer src, boolean ignoreAllUnknown)
/*     */   {
/*  42 */     super(src, ignoreAllUnknown);
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<Object> unwrappingDeserializer()
/*     */   {
/*  48 */     if (getClass() != ThrowableDeserializer.class) {
/*  49 */       return this;
/*     */     }
/*     */ 
/*  55 */     return new ThrowableDeserializer(this, true);
/*     */   }
/*     */ 
/*     */   public Object deserializeFromObject(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  70 */     if (this._propertyBasedCreator != null) {
/*  71 */       return _deserializeUsingPropertyBased(jp, ctxt);
/*     */     }
/*  73 */     if (this._delegateDeserializer != null) {
/*  74 */       return this._valueInstantiator.createUsingDelegate(this._delegateDeserializer.deserialize(jp, ctxt));
/*     */     }
/*  76 */     if (this._beanType.isAbstract()) {
/*  77 */       throw JsonMappingException.from(jp, "Can not instantiate abstract type " + this._beanType + " (need to add/enable type information?)");
/*     */     }
/*     */ 
/*  80 */     boolean hasStringCreator = this._valueInstantiator.canCreateFromString();
/*  81 */     boolean hasDefaultCtor = this._valueInstantiator.canCreateUsingDefault();
/*     */ 
/*  83 */     if ((!hasStringCreator) && (!hasDefaultCtor)) {
/*  84 */       throw new JsonMappingException("Can not deserialize Throwable of type " + this._beanType + " without having a default contructor, a single-String-arg constructor; or explicit @JsonCreator");
/*     */     }
/*     */ 
/*  88 */     Object throwable = null;
/*  89 */     Object[] pending = null;
/*  90 */     int pendingIx = 0;
/*     */ 
/*  92 */     for (; jp.getCurrentToken() != JsonToken.END_OBJECT; jp.nextToken()) {
/*  93 */       String propName = jp.getCurrentName();
/*  94 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  95 */       jp.nextToken();
/*     */ 
/*  97 */       if (prop != null) {
/*  98 */         if (throwable != null) {
/*  99 */           prop.deserializeAndSet(jp, ctxt, throwable);
/*     */         }
/*     */         else
/*     */         {
/* 103 */           if (pending == null) {
/* 104 */             int len = this._beanProperties.size();
/* 105 */             pending = new Object[len + len];
/*     */           }
/* 107 */           pending[(pendingIx++)] = prop;
/* 108 */           pending[(pendingIx++)] = prop.deserialize(jp, ctxt);
/*     */         }
/*     */ 
/*     */       }
/* 113 */       else if (("message".equals(propName)) && 
/* 114 */         (hasStringCreator)) {
/* 115 */         throwable = this._valueInstantiator.createFromString(jp.getText());
/*     */ 
/* 117 */         if (pending != null) {
/* 118 */           int i = 0; for (int len = pendingIx; i < len; i += 2) {
/* 119 */             prop = (SettableBeanProperty)pending[i];
/* 120 */             prop.set(throwable, pending[(i + 1)]);
/*     */           }
/* 122 */           pending = null;
/*     */         }
/*     */ 
/*     */       }
/* 130 */       else if ((this._ignorableProps != null) && (this._ignorableProps.contains(propName))) {
/* 131 */         jp.skipChildren();
/*     */       }
/* 134 */       else if (this._anySetter != null) {
/* 135 */         this._anySetter.deserializeAndSet(jp, ctxt, throwable, propName);
/*     */       }
/*     */       else
/*     */       {
/* 139 */         handleUnknownProperty(jp, ctxt, throwable, propName);
/*     */       }
/*     */     }
/* 142 */     if (throwable == null)
/*     */     {
/* 149 */       if (hasStringCreator)
/* 150 */         throwable = this._valueInstantiator.createFromString(null);
/*     */       else {
/* 152 */         throwable = this._valueInstantiator.createUsingDefault();
/*     */       }
/*     */ 
/* 155 */       if (pending != null) {
/* 156 */         int i = 0; for (int len = pendingIx; i < len; i += 2) {
/* 157 */           SettableBeanProperty prop = (SettableBeanProperty)pending[i];
/* 158 */           prop.set(throwable, pending[(i + 1)]);
/*     */         }
/*     */       }
/*     */     }
/* 162 */     return throwable;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.ThrowableDeserializer
 * JD-Core Version:    0.6.2
 */