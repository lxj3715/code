/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.Date;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ 
/*    */ public class TimestampDeserializer extends StdScalarDeserializer<Timestamp>
/*    */ {
/*    */   public TimestampDeserializer()
/*    */   {
/* 22 */     super(Timestamp.class);
/*    */   }
/*    */ 
/*    */   public Timestamp deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 28 */     return new Timestamp(_parseDate(jp, ctxt).getTime());
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.TimestampDeserializer
 * JD-Core Version:    0.6.2
 */