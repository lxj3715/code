/*    */ package org.codehaus.jackson.map.deser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ import org.codehaus.jackson.util.TokenBuffer;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class TokenBufferDeserializer extends StdScalarDeserializer<TokenBuffer>
/*    */ {
/*    */   public TokenBufferDeserializer()
/*    */   {
/* 25 */     super(TokenBuffer.class);
/*    */   }
/*    */ 
/*    */   public TokenBuffer deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 31 */     TokenBuffer tb = new TokenBuffer(jp.getCodec());
/*    */ 
/* 33 */     tb.copyCurrentStructure(jp);
/* 34 */     return tb;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.TokenBufferDeserializer
 * JD-Core Version:    0.6.2
 */