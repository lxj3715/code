/*     */ package org.codehaus.jackson.map.deser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.util.ObjectBuffer;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class UntypedObjectDeserializer extends StdDeserializer<Object>
/*     */ {
/*  31 */   private static final Object[] NO_OBJECTS = new Object[0];
/*     */ 
/*  33 */   public UntypedObjectDeserializer() { super(Object.class); }
/*     */ 
/*     */ 
/*     */   public Object deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  45 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[jp.getCurrentToken().ordinal()]) {
/*     */     case 1:
/*  47 */       return mapObject(jp, ctxt);
/*     */     case 2:
/*  49 */       break;
/*     */     case 3:
/*  51 */       return mapArray(jp, ctxt);
/*     */     case 4:
/*  53 */       break;
/*     */     case 5:
/*  55 */       return mapObject(jp, ctxt);
/*     */     case 6:
/*  57 */       return jp.getEmbeddedObject();
/*     */     case 7:
/*  59 */       return jp.getText();
/*     */     case 8:
/*  65 */       if (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_INTEGER_FOR_INTS)) {
/*  66 */         return jp.getBigIntegerValue();
/*     */       }
/*  68 */       return jp.getNumberValue();
/*     */     case 9:
/*  74 */       if (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  75 */         return jp.getDecimalValue();
/*     */       }
/*  77 */       return Double.valueOf(jp.getDoubleValue());
/*     */     case 10:
/*  80 */       return Boolean.TRUE;
/*     */     case 11:
/*  82 */       return Boolean.FALSE;
/*     */     case 12:
/*  85 */       return null;
/*     */     }
/*     */ 
/*  89 */     throw ctxt.mappingException(Object.class);
/*     */   }
/*     */ 
/*     */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  97 */     JsonToken t = jp.getCurrentToken();
/*  98 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[t.ordinal()])
/*     */     {
/*     */     case 1:
/*     */     case 3:
/*     */     case 5:
/* 106 */       return typeDeserializer.deserializeTypedFromAny(jp, ctxt);
/*     */     case 7:
/* 112 */       return jp.getText();
/*     */     case 8:
/* 116 */       if (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_INTEGER_FOR_INTS)) {
/* 117 */         return jp.getBigIntegerValue();
/*     */       }
/* 119 */       return Integer.valueOf(jp.getIntValue());
/*     */     case 9:
/* 123 */       if (ctxt.isEnabled(DeserializationConfig.Feature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 124 */         return jp.getDecimalValue();
/*     */       }
/* 126 */       return Double.valueOf(jp.getDoubleValue());
/*     */     case 10:
/* 129 */       return Boolean.TRUE;
/*     */     case 11:
/* 131 */       return Boolean.FALSE;
/*     */     case 6:
/* 133 */       return jp.getEmbeddedObject();
/*     */     case 12:
/* 136 */       return null;
/*     */     case 2:
/* 138 */     case 4: } throw ctxt.mappingException(Object.class);
/*     */   }
/*     */ 
/*     */   protected Object mapArray(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 153 */     if (ctxt.isEnabled(DeserializationConfig.Feature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/* 154 */       return mapArrayToArray(jp, ctxt);
/*     */     }
/*     */ 
/* 157 */     if (jp.nextToken() == JsonToken.END_ARRAY) {
/* 158 */       return new ArrayList(4);
/*     */     }
/* 160 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 161 */     Object[] values = buffer.resetAndStart();
/* 162 */     int ptr = 0;
/* 163 */     int totalSize = 0;
/*     */     do {
/* 165 */       Object value = deserialize(jp, ctxt);
/* 166 */       totalSize++;
/* 167 */       if (ptr >= values.length) {
/* 168 */         values = buffer.appendCompletedChunk(values);
/* 169 */         ptr = 0;
/*     */       }
/* 171 */       values[(ptr++)] = value;
/* 172 */     }while (jp.nextToken() != JsonToken.END_ARRAY);
/*     */ 
/* 174 */     ArrayList result = new ArrayList(totalSize + (totalSize >> 3) + 1);
/* 175 */     buffer.completeAndClearBuffer(values, ptr, result);
/* 176 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object mapObject(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 185 */     JsonToken t = jp.getCurrentToken();
/* 186 */     if (t == JsonToken.START_OBJECT) {
/* 187 */       t = jp.nextToken();
/*     */     }
/*     */ 
/* 190 */     if (t != JsonToken.FIELD_NAME)
/*     */     {
/* 192 */       return new LinkedHashMap(4);
/*     */     }
/* 194 */     String field1 = jp.getText();
/* 195 */     jp.nextToken();
/* 196 */     Object value1 = deserialize(jp, ctxt);
/* 197 */     if (jp.nextToken() != JsonToken.FIELD_NAME) {
/* 198 */       LinkedHashMap result = new LinkedHashMap(4);
/* 199 */       result.put(field1, value1);
/* 200 */       return result;
/*     */     }
/* 202 */     String field2 = jp.getText();
/* 203 */     jp.nextToken();
/* 204 */     Object value2 = deserialize(jp, ctxt);
/* 205 */     if (jp.nextToken() != JsonToken.FIELD_NAME) {
/* 206 */       LinkedHashMap result = new LinkedHashMap(4);
/* 207 */       result.put(field1, value1);
/* 208 */       result.put(field2, value2);
/* 209 */       return result;
/*     */     }
/*     */ 
/* 212 */     LinkedHashMap result = new LinkedHashMap();
/* 213 */     result.put(field1, value1);
/* 214 */     result.put(field2, value2);
/*     */     do {
/* 216 */       String fieldName = jp.getText();
/* 217 */       jp.nextToken();
/* 218 */       result.put(fieldName, deserialize(jp, ctxt));
/* 219 */     }while (jp.nextToken() != JsonToken.END_OBJECT);
/* 220 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object[] mapArrayToArray(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 232 */     if (jp.nextToken() == JsonToken.END_ARRAY) {
/* 233 */       return NO_OBJECTS;
/*     */     }
/* 235 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 236 */     Object[] values = buffer.resetAndStart();
/* 237 */     int ptr = 0;
/*     */     do {
/* 239 */       Object value = deserialize(jp, ctxt);
/* 240 */       if (ptr >= values.length) {
/* 241 */         values = buffer.appendCompletedChunk(values);
/* 242 */         ptr = 0;
/*     */       }
/* 244 */       values[(ptr++)] = value;
/* 245 */     }while (jp.nextToken() != JsonToken.END_ARRAY);
/* 246 */     return buffer.completeAndClearBuffer(values, ptr);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.std.UntypedObjectDeserializer
 * JD-Core Version:    0.6.2
 */