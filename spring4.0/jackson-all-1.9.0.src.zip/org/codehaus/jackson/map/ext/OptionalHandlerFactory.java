/*     */ package org.codehaus.jackson.map.ext;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map.Entry;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.deser.std.StdDeserializer;
/*     */ import org.codehaus.jackson.map.util.Provider;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class OptionalHandlerFactory
/*     */ {
/*     */   private static final String PACKAGE_PREFIX_JODA_DATETIME = "org.joda.time.";
/*     */   private static final String PACKAGE_PREFIX_JAVAX_XML = "javax.xml.";
/*     */   private static final String SERIALIZERS_FOR_JODA_DATETIME = "org.codehaus.jackson.map.ext.JodaSerializers";
/*     */   private static final String SERIALIZERS_FOR_JAVAX_XML = "org.codehaus.jackson.map.ext.CoreXMLSerializers";
/*     */   private static final String DESERIALIZERS_FOR_JODA_DATETIME = "org.codehaus.jackson.map.ext.JodaDeserializers";
/*     */   private static final String DESERIALIZERS_FOR_JAVAX_XML = "org.codehaus.jackson.map.ext.CoreXMLDeserializers";
/*     */   private static final String CLASS_NAME_DOM_NODE = "org.w3c.dom.Node";
/*     */   private static final String CLASS_NAME_DOM_DOCUMENT = "org.w3c.dom.Node";
/*     */   private static final String SERIALIZER_FOR_DOM_NODE = "org.codehaus.jackson.map.ext.DOMSerializer";
/*     */   private static final String DESERIALIZER_FOR_DOM_DOCUMENT = "org.codehaus.jackson.map.ext.DOMDeserializer$DocumentDeserializer";
/*     */   private static final String DESERIALIZER_FOR_DOM_NODE = "org.codehaus.jackson.map.ext.DOMDeserializer$NodeDeserializer";
/*  41 */   public static final OptionalHandlerFactory instance = new OptionalHandlerFactory();
/*     */ 
/*     */   public JsonSerializer<?> findSerializer(SerializationConfig config, JavaType type)
/*     */   {
/*  54 */     Class rawType = type.getRawClass();
/*  55 */     String className = rawType.getName();
/*     */     String factoryName;
/*  58 */     if (className.startsWith("org.joda.time.")) {
/*  59 */       factoryName = "org.codehaus.jackson.map.ext.JodaSerializers";
/*     */     }
/*     */     else
/*     */     {
/*     */       String factoryName;
/*  60 */       if ((className.startsWith("javax.xml.")) || (hasSupertypeStartingWith(rawType, "javax.xml.")))
/*     */       {
/*  62 */         factoryName = "org.codehaus.jackson.map.ext.CoreXMLSerializers"; } else {
/*  63 */         if (doesImplement(rawType, "org.w3c.dom.Node")) {
/*  64 */           return (JsonSerializer)instantiate("org.codehaus.jackson.map.ext.DOMSerializer");
/*     */         }
/*  66 */         return null;
/*     */       }
/*     */     }
/*     */     String factoryName;
/*  69 */     Object ob = instantiate(factoryName);
/*  70 */     if (ob == null) {
/*  71 */       return null;
/*     */     }
/*     */ 
/*  74 */     Provider prov = (Provider)ob;
/*  75 */     Collection entries = prov.provide();
/*     */ 
/*  78 */     for (Map.Entry entry : entries) {
/*  79 */       if (rawType == entry.getKey()) {
/*  80 */         return (JsonSerializer)entry.getValue();
/*     */       }
/*     */     }
/*     */ 
/*  84 */     for (Map.Entry entry : entries) {
/*  85 */       if (((Class)entry.getKey()).isAssignableFrom(rawType)) {
/*  86 */         return (JsonSerializer)entry.getValue();
/*     */       }
/*     */     }
/*     */ 
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */   public JsonDeserializer<?> findDeserializer(JavaType type, DeserializationConfig config, DeserializerProvider p)
/*     */   {
/*  95 */     Class rawType = type.getRawClass();
/*  96 */     String className = rawType.getName();
/*     */     String factoryName;
/*  99 */     if (className.startsWith("org.joda.time.")) {
/* 100 */       factoryName = "org.codehaus.jackson.map.ext.JodaDeserializers";
/*     */     }
/*     */     else
/*     */     {
/*     */       String factoryName;
/* 101 */       if ((className.startsWith("javax.xml.")) || (hasSupertypeStartingWith(rawType, "javax.xml.")))
/*     */       {
/* 103 */         factoryName = "org.codehaus.jackson.map.ext.CoreXMLDeserializers"; } else {
/* 104 */         if (doesImplement(rawType, "org.w3c.dom.Node"))
/* 105 */           return (JsonDeserializer)instantiate("org.codehaus.jackson.map.ext.DOMDeserializer$DocumentDeserializer");
/* 106 */         if (doesImplement(rawType, "org.w3c.dom.Node")) {
/* 107 */           return (JsonDeserializer)instantiate("org.codehaus.jackson.map.ext.DOMDeserializer$NodeDeserializer");
/*     */         }
/* 109 */         return null;
/*     */       }
/*     */     }
/*     */     String factoryName;
/* 111 */     Object ob = instantiate(factoryName);
/* 112 */     if (ob == null) {
/* 113 */       return null;
/*     */     }
/*     */ 
/* 116 */     Provider prov = (Provider)ob;
/* 117 */     Collection entries = prov.provide();
/*     */ 
/* 120 */     for (StdDeserializer deser : entries) {
/* 121 */       if (rawType == deser.getValueClass()) {
/* 122 */         return deser;
/*     */       }
/*     */     }
/*     */ 
/* 126 */     for (StdDeserializer deser : entries) {
/* 127 */       if (deser.getValueClass().isAssignableFrom(rawType)) {
/* 128 */         return deser;
/*     */       }
/*     */     }
/*     */ 
/* 132 */     return null;
/*     */   }
/*     */ 
/*     */   private Object instantiate(String className)
/*     */   {
/*     */     try
/*     */     {
/* 144 */       return Class.forName(className).newInstance();
/*     */     } catch (LinkageError e) {
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */   private boolean doesImplement(Class<?> actualType, String classNameToImplement)
/*     */   {
/* 154 */     for (Class type = actualType; type != null; type = type.getSuperclass()) {
/* 155 */       if (type.getName().equals(classNameToImplement)) {
/* 156 */         return true;
/*     */       }
/*     */ 
/* 159 */       if (hasInterface(type, classNameToImplement)) {
/* 160 */         return true;
/*     */       }
/*     */     }
/* 163 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean hasInterface(Class<?> type, String interfaceToImplement)
/*     */   {
/* 168 */     Class[] interfaces = type.getInterfaces();
/* 169 */     for (Class iface : interfaces) {
/* 170 */       if (iface.getName().equals(interfaceToImplement)) {
/* 171 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 175 */     for (Class iface : interfaces) {
/* 176 */       if (hasInterface(iface, interfaceToImplement)) {
/* 177 */         return true;
/*     */       }
/*     */     }
/* 180 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean hasSupertypeStartingWith(Class<?> rawType, String prefix)
/*     */   {
/* 186 */     for (Class supertype = rawType.getSuperclass(); supertype != null; supertype = supertype.getSuperclass()) {
/* 187 */       if (supertype.getName().startsWith(prefix)) {
/* 188 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 192 */     for (Class cls = rawType; cls != null; cls = cls.getSuperclass()) {
/* 193 */       if (hasInterfaceStartingWith(cls, prefix)) {
/* 194 */         return true;
/*     */       }
/*     */     }
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean hasInterfaceStartingWith(Class<?> type, String prefix)
/*     */   {
/* 202 */     Class[] interfaces = type.getInterfaces();
/* 203 */     for (Class iface : interfaces) {
/* 204 */       if (iface.getName().startsWith(prefix)) {
/* 205 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 209 */     for (Class iface : interfaces) {
/* 210 */       if (hasInterfaceStartingWith(iface, prefix)) {
/* 211 */         return true;
/*     */       }
/*     */     }
/* 214 */     return false;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ext.OptionalHandlerFactory
 * JD-Core Version:    0.6.2
 */