/*    */ package org.codehaus.jackson.map.introspect;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.map.type.TypeBindings;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public abstract class Annotated
/*    */ {
/*    */   public abstract <A extends Annotation> A getAnnotation(Class<A> paramClass);
/*    */ 
/*    */   public final <A extends Annotation> boolean hasAnnotation(Class<A> acls)
/*    */   {
/* 23 */     return getAnnotation(acls) != null;
/*    */   }
/*    */ 
/*    */   public abstract Annotated withAnnotations(AnnotationMap paramAnnotationMap);
/*    */ 
/*    */   public final Annotated withFallBackAnnotationsFrom(Annotated annotated)
/*    */   {
/* 41 */     return withAnnotations(AnnotationMap.merge(getAllAnnotations(), annotated.getAllAnnotations()));
/*    */   }
/*    */ 
/*    */   public abstract AnnotatedElement getAnnotated();
/*    */ 
/*    */   protected abstract int getModifiers();
/*    */ 
/*    */   public final boolean isPublic()
/*    */   {
/* 54 */     return Modifier.isPublic(getModifiers());
/*    */   }
/*    */ 
/*    */   public abstract String getName();
/*    */ 
/*    */   public JavaType getType(TypeBindings context)
/*    */   {
/* 64 */     return context.resolveType(getGenericType());
/*    */   }
/*    */ 
/*    */   public abstract Type getGenericType();
/*    */ 
/*    */   public abstract Class<?> getRawType();
/*    */ 
/*    */   protected abstract AnnotationMap getAllAnnotations();
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.Annotated
 * JD-Core Version:    0.6.2
 */