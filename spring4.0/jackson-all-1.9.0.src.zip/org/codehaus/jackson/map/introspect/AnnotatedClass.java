/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.ClassIntrospector.MixInResolver;
/*     */ import org.codehaus.jackson.map.util.Annotations;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ 
/*     */ public final class AnnotatedClass extends Annotated
/*     */ {
/*  15 */   private static final AnnotationMap[] NO_ANNOTATION_MAPS = new AnnotationMap[0];
/*     */   protected final Class<?> _class;
/*     */   protected final List<Class<?>> _superTypes;
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */   protected final ClassIntrospector.MixInResolver _mixInResolver;
/*     */   protected final Class<?> _primaryMixIn;
/*     */   protected AnnotationMap _classAnnotations;
/*     */   protected AnnotatedConstructor _defaultConstructor;
/*     */   protected List<AnnotatedConstructor> _constructors;
/*     */   protected List<AnnotatedMethod> _creatorMethods;
/*     */   protected AnnotatedMethodMap _memberMethods;
/*     */   protected List<AnnotatedField> _fields;
/*     */ 
/*     */   private AnnotatedClass(Class<?> cls, List<Class<?>> superTypes, AnnotationIntrospector aintr, ClassIntrospector.MixInResolver mir, AnnotationMap classAnnotations)
/*     */   {
/* 109 */     this._class = cls;
/* 110 */     this._superTypes = superTypes;
/* 111 */     this._annotationIntrospector = aintr;
/* 112 */     this._mixInResolver = mir;
/* 113 */     this._primaryMixIn = (this._mixInResolver == null ? null : this._mixInResolver.findMixInClassFor(this._class));
/*     */ 
/* 115 */     this._classAnnotations = classAnnotations;
/*     */   }
/*     */ 
/*     */   public AnnotatedClass withAnnotations(AnnotationMap ann)
/*     */   {
/* 120 */     return new AnnotatedClass(this._class, this._superTypes, this._annotationIntrospector, this._mixInResolver, ann);
/*     */   }
/*     */ 
/*     */   public static AnnotatedClass construct(Class<?> cls, AnnotationIntrospector aintr, ClassIntrospector.MixInResolver mir)
/*     */   {
/* 132 */     List st = ClassUtil.findSuperTypes(cls, null);
/* 133 */     AnnotatedClass ac = new AnnotatedClass(cls, st, aintr, mir, null);
/* 134 */     ac.resolveClassAnnotations();
/* 135 */     return ac;
/*     */   }
/*     */ 
/*     */   public static AnnotatedClass constructWithoutSuperTypes(Class<?> cls, AnnotationIntrospector aintr, ClassIntrospector.MixInResolver mir)
/*     */   {
/* 146 */     List empty = Collections.emptyList();
/* 147 */     AnnotatedClass ac = new AnnotatedClass(cls, empty, aintr, mir, null);
/* 148 */     ac.resolveClassAnnotations();
/* 149 */     return ac;
/*     */   }
/*     */ 
/*     */   public Class<?> getAnnotated()
/*     */   {
/* 159 */     return this._class;
/*     */   }
/*     */   public int getModifiers() {
/* 162 */     return this._class.getModifiers();
/*     */   }
/*     */   public String getName() {
/* 165 */     return this._class.getName();
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */   {
/* 170 */     if (this._classAnnotations == null) {
/* 171 */       return null;
/*     */     }
/* 173 */     return this._classAnnotations.get(acls);
/*     */   }
/*     */ 
/*     */   public Type getGenericType()
/*     */   {
/* 178 */     return this._class;
/*     */   }
/*     */ 
/*     */   public Class<?> getRawType()
/*     */   {
/* 183 */     return this._class;
/*     */   }
/*     */ 
/*     */   protected AnnotationMap getAllAnnotations()
/*     */   {
/* 188 */     return this._classAnnotations;
/*     */   }
/*     */ 
/*     */   public Annotations getAnnotations()
/*     */   {
/* 200 */     return this._classAnnotations;
/*     */   }
/* 202 */   public boolean hasAnnotations() { return this._classAnnotations.size() > 0; } 
/*     */   public AnnotatedConstructor getDefaultConstructor() {
/* 204 */     return this._defaultConstructor;
/*     */   }
/*     */ 
/*     */   public List<AnnotatedConstructor> getConstructors() {
/* 208 */     if (this._constructors == null) {
/* 209 */       return Collections.emptyList();
/*     */     }
/* 211 */     return this._constructors;
/*     */   }
/*     */ 
/*     */   public List<AnnotatedMethod> getStaticMethods()
/*     */   {
/* 216 */     if (this._creatorMethods == null) {
/* 217 */       return Collections.emptyList();
/*     */     }
/* 219 */     return this._creatorMethods;
/*     */   }
/*     */ 
/*     */   public Iterable<AnnotatedMethod> memberMethods()
/*     */   {
/* 224 */     return this._memberMethods;
/*     */   }
/*     */ 
/*     */   public int getMemberMethodCount()
/*     */   {
/* 229 */     return this._memberMethods.size();
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod findMethod(String name, Class<?>[] paramTypes)
/*     */   {
/* 234 */     return this._memberMethods.find(name, paramTypes);
/*     */   }
/*     */ 
/*     */   public int getFieldCount() {
/* 238 */     return this._fields == null ? 0 : this._fields.size();
/*     */   }
/*     */ 
/*     */   public Iterable<AnnotatedField> fields()
/*     */   {
/* 243 */     if (this._fields == null) {
/* 244 */       return Collections.emptyList();
/*     */     }
/* 246 */     return this._fields;
/*     */   }
/*     */ 
/*     */   public void resolveClassAnnotations()
/*     */   {
/* 265 */     this._classAnnotations = new AnnotationMap();
/*     */ 
/* 267 */     if (this._annotationIntrospector == null) {
/* 268 */       return;
/*     */     }
/*     */ 
/* 272 */     if (this._primaryMixIn != null) {
/* 273 */       _addClassMixIns(this._classAnnotations, this._class, this._primaryMixIn);
/*     */     }
/*     */ 
/* 276 */     for (Annotation a : this._class.getDeclaredAnnotations()) {
/* 277 */       if (this._annotationIntrospector.isHandled(a)) {
/* 278 */         this._classAnnotations.addIfNotPresent(a);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 283 */     for (Class cls : this._superTypes)
/*     */     {
/* 285 */       _addClassMixIns(this._classAnnotations, cls);
/* 286 */       for (Annotation a : cls.getDeclaredAnnotations()) {
/* 287 */         if (this._annotationIntrospector.isHandled(a)) {
/* 288 */           this._classAnnotations.addIfNotPresent(a);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 301 */     _addClassMixIns(this._classAnnotations, Object.class);
/*     */   }
/*     */ 
/*     */   public void resolveCreators(boolean includeAll)
/*     */   {
/* 317 */     this._constructors = null;
/* 318 */     Constructor[] declaredCtors = this._class.getDeclaredConstructors();
/* 319 */     for (Constructor ctor : declaredCtors) {
/* 320 */       if (ctor.getParameterTypes().length == 0) {
/* 321 */         this._defaultConstructor = _constructConstructor(ctor, true);
/*     */       }
/* 323 */       else if (includeAll) {
/* 324 */         if (this._constructors == null) {
/* 325 */           this._constructors = new ArrayList(Math.max(10, declaredCtors.length));
/*     */         }
/* 327 */         this._constructors.add(_constructConstructor(ctor, false));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 332 */     if ((this._primaryMixIn != null) && (
/* 333 */       (this._defaultConstructor != null) || (this._constructors != null))) {
/* 334 */       _addConstructorMixIns(this._primaryMixIn);
/*     */     }
/*     */ 
/* 343 */     if (this._annotationIntrospector != null) {
/* 344 */       if ((this._defaultConstructor != null) && 
/* 345 */         (this._annotationIntrospector.isIgnorableConstructor(this._defaultConstructor))) {
/* 346 */         this._defaultConstructor = null;
/*     */       }
/*     */ 
/* 349 */       if (this._constructors != null)
/*     */       {
/* 351 */         int i = this._constructors.size();
/*     */         while (true) { i--; if (i < 0) break;
/* 352 */           if (this._annotationIntrospector.isIgnorableConstructor((AnnotatedConstructor)this._constructors.get(i))) {
/* 353 */             this._constructors.remove(i);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 359 */     this._creatorMethods = null;
/*     */ 
/* 361 */     if (includeAll)
/*     */     {
/* 363 */       for (Method m : this._class.getDeclaredMethods())
/* 364 */         if (Modifier.isStatic(m.getModifiers()))
/*     */         {
/* 367 */           int argCount = m.getParameterTypes().length;
/*     */ 
/* 369 */           if (argCount >= 1)
/*     */           {
/* 372 */             if (this._creatorMethods == null) {
/* 373 */               this._creatorMethods = new ArrayList(8);
/*     */             }
/* 375 */             this._creatorMethods.add(_constructCreatorMethod(m));
/*     */           }
/*     */         }
/* 378 */       if ((this._primaryMixIn != null) && (this._creatorMethods != null)) {
/* 379 */         _addFactoryMixIns(this._primaryMixIn);
/*     */       }
/*     */ 
/* 382 */       if ((this._annotationIntrospector != null) && 
/* 383 */         (this._creatorMethods != null))
/*     */       {
/* 385 */         int i = this._creatorMethods.size();
/*     */         while (true) { i--; if (i < 0) break;
/* 386 */           if (this._annotationIntrospector.isIgnorableMethod((AnnotatedMethod)this._creatorMethods.get(i)))
/* 387 */             this._creatorMethods.remove(i);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resolveMemberMethods(MethodFilter methodFilter)
/*     */   {
/* 405 */     this._memberMethods = new AnnotatedMethodMap();
/* 406 */     AnnotatedMethodMap mixins = new AnnotatedMethodMap();
/*     */ 
/* 408 */     _addMemberMethods(this._class, methodFilter, this._memberMethods, this._primaryMixIn, mixins);
/*     */ 
/* 411 */     for (Class cls : this._superTypes) {
/* 412 */       Class mixin = this._mixInResolver == null ? null : this._mixInResolver.findMixInClassFor(cls);
/* 413 */       _addMemberMethods(cls, methodFilter, this._memberMethods, mixin, mixins);
/*     */     }
/*     */ 
/* 416 */     if (this._mixInResolver != null) {
/* 417 */       Class mixin = this._mixInResolver.findMixInClassFor(Object.class);
/* 418 */       if (mixin != null) {
/* 419 */         _addMethodMixIns(methodFilter, this._memberMethods, mixin, mixins);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 429 */     if ((this._annotationIntrospector != null) && 
/* 430 */       (!mixins.isEmpty())) {
/* 431 */       Iterator it = mixins.iterator();
/* 432 */       while (it.hasNext()) {
/* 433 */         AnnotatedMethod mixIn = (AnnotatedMethod)it.next();
/*     */         try {
/* 435 */           Method m = Object.class.getDeclaredMethod(mixIn.getName(), mixIn.getParameterClasses());
/* 436 */           if (m != null) {
/* 437 */             AnnotatedMethod am = _constructMethod(m);
/* 438 */             _addMixOvers(mixIn.getAnnotated(), am, false);
/* 439 */             this._memberMethods.add(am);
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resolveFields()
/*     */   {
/* 456 */     LinkedHashMap foundFields = new LinkedHashMap();
/* 457 */     _addFields(foundFields, this._class);
/* 458 */     if (foundFields.isEmpty()) {
/* 459 */       this._fields = Collections.emptyList();
/*     */     } else {
/* 461 */       this._fields = new ArrayList(foundFields.size());
/* 462 */       this._fields.addAll(foundFields.values());
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void resolveMemberMethods(MethodFilter methodFilter, boolean collectIgnored)
/*     */   {
/* 478 */     resolveMemberMethods(methodFilter);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void resolveFields(boolean collectIgnored)
/*     */   {
/* 487 */     resolveFields();
/*     */   }
/*     */ 
/*     */   protected void _addClassMixIns(AnnotationMap annotations, Class<?> toMask)
/*     */   {
/* 504 */     if (this._mixInResolver != null)
/* 505 */       _addClassMixIns(annotations, toMask, this._mixInResolver.findMixInClassFor(toMask));
/*     */   }
/*     */ 
/*     */   protected void _addClassMixIns(AnnotationMap annotations, Class<?> toMask, Class<?> mixin)
/*     */   {
/* 512 */     if (mixin == null) {
/* 513 */       return;
/*     */     }
/*     */ 
/* 516 */     for (Annotation a : mixin.getDeclaredAnnotations()) {
/* 517 */       if (this._annotationIntrospector.isHandled(a)) {
/* 518 */         annotations.addIfNotPresent(a);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 528 */     for (Class parent : ClassUtil.findSuperTypes(mixin, toMask))
/* 529 */       for (Annotation a : parent.getDeclaredAnnotations())
/* 530 */         if (this._annotationIntrospector.isHandled(a))
/* 531 */           annotations.addIfNotPresent(a);
/*     */   }
/*     */ 
/*     */   protected void _addConstructorMixIns(Class<?> mixin)
/*     */   {
/* 545 */     MemberKey[] ctorKeys = null;
/* 546 */     int ctorCount = this._constructors == null ? 0 : this._constructors.size();
/* 547 */     for (Constructor ctor : mixin.getDeclaredConstructors())
/* 548 */       if (ctor.getParameterTypes().length == 0) {
/* 549 */         if (this._defaultConstructor != null)
/* 550 */           _addMixOvers(ctor, this._defaultConstructor, false);
/*     */       }
/*     */       else {
/* 553 */         if (ctorKeys == null) {
/* 554 */           ctorKeys = new MemberKey[ctorCount];
/* 555 */           for (int i = 0; i < ctorCount; i++) {
/* 556 */             ctorKeys[i] = new MemberKey(((AnnotatedConstructor)this._constructors.get(i)).getAnnotated());
/*     */           }
/*     */         }
/* 559 */         MemberKey key = new MemberKey(ctor);
/*     */ 
/* 561 */         for (int i = 0; i < ctorCount; i++)
/* 562 */           if (key.equals(ctorKeys[i]))
/*     */           {
/* 565 */             _addMixOvers(ctor, (AnnotatedConstructor)this._constructors.get(i), true);
/* 566 */             break;
/*     */           }
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void _addFactoryMixIns(Class<?> mixin)
/*     */   {
/* 574 */     MemberKey[] methodKeys = null;
/* 575 */     int methodCount = this._creatorMethods.size();
/*     */ 
/* 577 */     for (Method m : mixin.getDeclaredMethods())
/* 578 */       if (Modifier.isStatic(m.getModifiers()))
/*     */       {
/* 581 */         if (m.getParameterTypes().length != 0)
/*     */         {
/* 584 */           if (methodKeys == null) {
/* 585 */             methodKeys = new MemberKey[methodCount];
/* 586 */             for (int i = 0; i < methodCount; i++) {
/* 587 */               methodKeys[i] = new MemberKey(((AnnotatedMethod)this._creatorMethods.get(i)).getAnnotated());
/*     */             }
/*     */           }
/* 590 */           MemberKey key = new MemberKey(m);
/* 591 */           for (int i = 0; i < methodCount; i++)
/* 592 */             if (key.equals(methodKeys[i]))
/*     */             {
/* 595 */               _addMixOvers(m, (AnnotatedMethod)this._creatorMethods.get(i), true);
/* 596 */               break;
/*     */             }
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void _addMemberMethods(Class<?> cls, MethodFilter methodFilter, AnnotatedMethodMap methods, Class<?> mixInCls, AnnotatedMethodMap mixIns)
/*     */   {
/* 612 */     if (mixInCls != null) {
/* 613 */       _addMethodMixIns(methodFilter, methods, mixInCls, mixIns);
/*     */     }
/*     */ 
/* 616 */     if (cls == null) {
/* 617 */       return;
/*     */     }
/*     */ 
/* 620 */     for (Method m : cls.getDeclaredMethods())
/* 621 */       if (_isIncludableMethod(m, methodFilter))
/*     */       {
/* 624 */         AnnotatedMethod old = methods.find(m);
/* 625 */         if (old == null) {
/* 626 */           AnnotatedMethod newM = _constructMethod(m);
/* 627 */           methods.add(newM);
/*     */ 
/* 629 */           old = mixIns.remove(m);
/* 630 */           if (old != null) {
/* 631 */             _addMixOvers(old.getAnnotated(), newM, false);
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 637 */           _addMixUnders(m, old);
/*     */ 
/* 646 */           if ((old.getDeclaringClass().isInterface()) && (!m.getDeclaringClass().isInterface()))
/* 647 */             methods.add(old.withMethod(m));
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void _addMethodMixIns(MethodFilter methodFilter, AnnotatedMethodMap methods, Class<?> mixInCls, AnnotatedMethodMap mixIns)
/*     */   {
/* 656 */     for (Method m : mixInCls.getDeclaredMethods())
/* 657 */       if (_isIncludableMethod(m, methodFilter))
/*     */       {
/* 660 */         AnnotatedMethod am = methods.find(m);
/*     */ 
/* 665 */         if (am != null) {
/* 666 */           _addMixUnders(m, am);
/*     */         }
/*     */         else
/*     */         {
/* 672 */           mixIns.add(_constructMethod(m));
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void _addFields(Map<String, AnnotatedField> fields, Class<?> c)
/*     */   {
/* 690 */     Class parent = c.getSuperclass();
/* 691 */     if (parent != null)
/*     */     {
/* 696 */       _addFields(fields, parent);
/* 697 */       for (Field f : c.getDeclaredFields())
/*     */       {
/* 699 */         if (_isIncludableField(f))
/*     */         {
/* 707 */           fields.put(f.getName(), _constructField(f));
/*     */         }
/*     */       }
/* 710 */       if (this._mixInResolver != null) {
/* 711 */         Class mixin = this._mixInResolver.findMixInClassFor(c);
/* 712 */         if (mixin != null)
/* 713 */           _addFieldMixIns(mixin, fields);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _addFieldMixIns(Class<?> mixin, Map<String, AnnotatedField> fields)
/*     */   {
/* 726 */     for (Field mixinField : mixin.getDeclaredFields())
/*     */     {
/* 730 */       if (_isIncludableField(mixinField))
/*     */       {
/* 733 */         String name = mixinField.getName();
/*     */ 
/* 735 */         AnnotatedField maskedField = (AnnotatedField)fields.get(name);
/* 736 */         if (maskedField != null)
/* 737 */           for (Annotation a : mixinField.getDeclaredAnnotations())
/* 738 */             if (this._annotationIntrospector.isHandled(a))
/* 739 */               maskedField.addOrOverride(a);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected AnnotatedMethod _constructMethod(Method m)
/*     */   {
/* 758 */     if (this._annotationIntrospector == null) {
/* 759 */       return new AnnotatedMethod(m, _emptyAnnotationMap(), null);
/*     */     }
/* 761 */     return new AnnotatedMethod(m, _collectRelevantAnnotations(m.getDeclaredAnnotations()), null);
/*     */   }
/*     */ 
/*     */   protected AnnotatedConstructor _constructConstructor(Constructor<?> ctor, boolean defaultCtor)
/*     */   {
/* 766 */     if (this._annotationIntrospector == null) {
/* 767 */       return new AnnotatedConstructor(ctor, _emptyAnnotationMap(), _emptyAnnotationMaps(ctor.getParameterTypes().length));
/*     */     }
/* 769 */     return new AnnotatedConstructor(ctor, _collectRelevantAnnotations(ctor.getDeclaredAnnotations()), defaultCtor ? null : _collectRelevantAnnotations(ctor.getParameterAnnotations()));
/*     */   }
/*     */ 
/*     */   protected AnnotatedMethod _constructCreatorMethod(Method m)
/*     */   {
/* 775 */     if (this._annotationIntrospector == null) {
/* 776 */       return new AnnotatedMethod(m, _emptyAnnotationMap(), _emptyAnnotationMaps(m.getParameterTypes().length));
/*     */     }
/* 778 */     return new AnnotatedMethod(m, _collectRelevantAnnotations(m.getDeclaredAnnotations()), _collectRelevantAnnotations(m.getParameterAnnotations()));
/*     */   }
/*     */ 
/*     */   protected AnnotatedField _constructField(Field f)
/*     */   {
/* 784 */     if (this._annotationIntrospector == null) {
/* 785 */       return new AnnotatedField(f, _emptyAnnotationMap());
/*     */     }
/* 787 */     return new AnnotatedField(f, _collectRelevantAnnotations(f.getDeclaredAnnotations()));
/*     */   }
/*     */ 
/*     */   protected AnnotationMap[] _collectRelevantAnnotations(Annotation[][] anns)
/*     */   {
/* 792 */     int len = anns.length;
/* 793 */     AnnotationMap[] result = new AnnotationMap[len];
/* 794 */     for (int i = 0; i < len; i++) {
/* 795 */       result[i] = _collectRelevantAnnotations(anns[i]);
/*     */     }
/* 797 */     return result;
/*     */   }
/*     */ 
/*     */   protected AnnotationMap _collectRelevantAnnotations(Annotation[] anns)
/*     */   {
/* 802 */     AnnotationMap annMap = new AnnotationMap();
/* 803 */     if (anns != null) {
/* 804 */       for (Annotation a : anns) {
/* 805 */         if (this._annotationIntrospector.isHandled(a)) {
/* 806 */           annMap.add(a);
/*     */         }
/*     */       }
/*     */     }
/* 810 */     return annMap;
/*     */   }
/*     */ 
/*     */   private AnnotationMap _emptyAnnotationMap() {
/* 814 */     return new AnnotationMap();
/*     */   }
/*     */ 
/*     */   private AnnotationMap[] _emptyAnnotationMaps(int count) {
/* 818 */     if (count == 0) {
/* 819 */       return NO_ANNOTATION_MAPS;
/*     */     }
/* 821 */     AnnotationMap[] maps = new AnnotationMap[count];
/* 822 */     for (int i = 0; i < count; i++) {
/* 823 */       maps[i] = _emptyAnnotationMap();
/*     */     }
/* 825 */     return maps;
/*     */   }
/*     */ 
/*     */   protected boolean _isIncludableMethod(Method m, MethodFilter filter)
/*     */   {
/* 836 */     if ((filter != null) && (!filter.includeMethod(m))) {
/* 837 */       return false;
/*     */     }
/*     */ 
/* 843 */     if ((m.isSynthetic()) || (m.isBridge())) {
/* 844 */       return false;
/*     */     }
/* 846 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean _isIncludableField(Field f)
/*     */   {
/* 854 */     if (f.isSynthetic()) {
/* 855 */       return false;
/*     */     }
/*     */ 
/* 858 */     int mods = f.getModifiers();
/* 859 */     if ((Modifier.isStatic(mods)) || (Modifier.isTransient(mods))) {
/* 860 */       return false;
/*     */     }
/* 862 */     return true;
/*     */   }
/*     */ 
/*     */   protected void _addMixOvers(Constructor<?> mixin, AnnotatedConstructor target, boolean addParamAnnotations)
/*     */   {
/* 878 */     for (Annotation a : mixin.getDeclaredAnnotations()) {
/* 879 */       if (this._annotationIntrospector.isHandled(a)) {
/* 880 */         target.addOrOverride(a);
/*     */       }
/*     */     }
/* 883 */     if (addParamAnnotations) {
/* 884 */       Annotation[][] pa = mixin.getParameterAnnotations();
/* 885 */       int i = 0; for (int len = pa.length; i < len; i++)
/* 886 */         for (Annotation a : pa[i])
/* 887 */           target.addOrOverrideParam(i, a);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _addMixOvers(Method mixin, AnnotatedMethod target, boolean addParamAnnotations)
/*     */   {
/* 900 */     for (Annotation a : mixin.getDeclaredAnnotations()) {
/* 901 */       if (this._annotationIntrospector.isHandled(a)) {
/* 902 */         target.addOrOverride(a);
/*     */       }
/*     */     }
/* 905 */     if (addParamAnnotations) {
/* 906 */       Annotation[][] pa = mixin.getParameterAnnotations();
/* 907 */       int i = 0; for (int len = pa.length; i < len; i++)
/* 908 */         for (Annotation a : pa[i])
/* 909 */           target.addOrOverrideParam(i, a);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _addMixUnders(Method src, AnnotatedMethod target)
/*     */   {
/* 921 */     for (Annotation a : src.getDeclaredAnnotations())
/* 922 */       if (this._annotationIntrospector.isHandled(a))
/* 923 */         target.addIfNotPresent(a);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 937 */     return "[AnnotedClass " + this._class.getName() + "]";
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.AnnotatedClass
 * JD-Core Version:    0.6.2
 */