/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Type;
/*     */ import org.codehaus.jackson.map.type.TypeBindings;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class AnnotatedConstructor extends AnnotatedWithParams
/*     */ {
/*     */   protected final Constructor<?> _constructor;
/*     */ 
/*     */   public AnnotatedConstructor(Constructor<?> constructor, AnnotationMap classAnn, AnnotationMap[] paramAnn)
/*     */   {
/*  24 */     super(classAnn, paramAnn);
/*  25 */     if (constructor == null) {
/*  26 */       throw new IllegalArgumentException("Null constructor not allowed");
/*     */     }
/*  28 */     this._constructor = constructor;
/*     */   }
/*     */ 
/*     */   public AnnotatedConstructor withAnnotations(AnnotationMap ann)
/*     */   {
/*  33 */     return new AnnotatedConstructor(this._constructor, ann, this._paramAnnotations);
/*     */   }
/*     */ 
/*     */   public Constructor<?> getAnnotated()
/*     */   {
/*  43 */     return this._constructor;
/*     */   }
/*     */   public int getModifiers() {
/*  46 */     return this._constructor.getModifiers();
/*     */   }
/*     */   public String getName() {
/*  49 */     return this._constructor.getName();
/*     */   }
/*     */ 
/*     */   public Type getGenericType() {
/*  53 */     return getRawType();
/*     */   }
/*     */ 
/*     */   public Class<?> getRawType()
/*     */   {
/*  58 */     return this._constructor.getDeclaringClass();
/*     */   }
/*     */ 
/*     */   public JavaType getType(TypeBindings bindings)
/*     */   {
/*  69 */     return getType(bindings, this._constructor.getTypeParameters());
/*     */   }
/*     */ 
/*     */   public int getParameterCount()
/*     */   {
/*  80 */     return this._constructor.getParameterTypes().length;
/*     */   }
/*     */ 
/*     */   public Class<?> getParameterClass(int index)
/*     */   {
/*  86 */     Class[] types = this._constructor.getParameterTypes();
/*  87 */     return index >= types.length ? null : types[index];
/*     */   }
/*     */ 
/*     */   public Type getParameterType(int index)
/*     */   {
/*  93 */     Type[] types = this._constructor.getGenericParameterTypes();
/*  94 */     return index >= types.length ? null : types[index];
/*     */   }
/*     */ 
/*     */   public final Object call() throws Exception
/*     */   {
/*  99 */     return this._constructor.newInstance(new Object[0]);
/*     */   }
/*     */ 
/*     */   public final Object call(Object[] args) throws Exception
/*     */   {
/* 104 */     return this._constructor.newInstance(args);
/*     */   }
/*     */ 
/*     */   public final Object call1(Object arg) throws Exception
/*     */   {
/* 109 */     return this._constructor.newInstance(new Object[] { arg });
/*     */   }
/*     */ 
/*     */   public Class<?> getDeclaringClass()
/*     */   {
/* 119 */     return this._constructor.getDeclaringClass();
/*     */   }
/*     */   public Member getMember() {
/* 122 */     return this._constructor;
/*     */   }
/*     */ 
/*     */   public void setValue(Object pojo, Object value)
/*     */     throws UnsupportedOperationException
/*     */   {
/* 128 */     throw new UnsupportedOperationException("Cannot call setValue() on constructor of " + getDeclaringClass().getName());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 140 */     return "[constructor for " + getName() + ", annotations: " + this._annotations + "]";
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.AnnotatedConstructor
 * JD-Core Version:    0.6.2
 */