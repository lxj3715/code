/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ public final class AnnotatedField extends AnnotatedMember
/*     */ {
/*     */   protected final Field _field;
/*     */ 
/*     */   public AnnotatedField(Field field, AnnotationMap annMap)
/*     */   {
/*  27 */     super(annMap);
/*  28 */     this._field = field;
/*     */   }
/*     */ 
/*     */   public AnnotatedField withAnnotations(AnnotationMap ann)
/*     */   {
/*  33 */     return new AnnotatedField(this._field, ann);
/*     */   }
/*     */ 
/*     */   public void addOrOverride(Annotation a)
/*     */   {
/*  43 */     this._annotations.add(a);
/*     */   }
/*     */ 
/*     */   public Field getAnnotated()
/*     */   {
/*  53 */     return this._field;
/*     */   }
/*     */   public int getModifiers() {
/*  56 */     return this._field.getModifiers();
/*     */   }
/*     */   public String getName() {
/*  59 */     return this._field.getName();
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */   {
/*  64 */     return this._annotations.get(acls);
/*     */   }
/*     */ 
/*     */   public Type getGenericType()
/*     */   {
/*  69 */     return this._field.getGenericType();
/*     */   }
/*     */ 
/*     */   public Class<?> getRawType()
/*     */   {
/*  74 */     return this._field.getType();
/*     */   }
/*     */ 
/*     */   public Class<?> getDeclaringClass()
/*     */   {
/*  84 */     return this._field.getDeclaringClass();
/*     */   }
/*     */   public Member getMember() {
/*  87 */     return this._field;
/*     */   }
/*     */ 
/*     */   public void setValue(Object pojo, Object value) throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       this._field.set(pojo, value);
/*     */     } catch (IllegalAccessException e) {
/*  96 */       throw new IllegalArgumentException("Failed to setValue() for field " + getFullName() + ": " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getFullName()
/*     */   {
/* 108 */     return getDeclaringClass().getName() + "#" + getName();
/*     */   }
/*     */   public int getAnnotationCount() {
/* 111 */     return this._annotations.size();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 116 */     return "[field " + getName() + ", annotations: " + this._annotations + "]";
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.AnnotatedField
 * JD-Core Version:    0.6.2
 */