/*    */ package org.codehaus.jackson.map.introspect;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ import org.codehaus.jackson.map.util.ClassUtil;
/*    */ 
/*    */ public abstract class AnnotatedMember extends Annotated
/*    */ {
/*    */   protected final AnnotationMap _annotations;
/*    */ 
/*    */   protected AnnotatedMember(AnnotationMap annotations)
/*    */   {
/* 22 */     this._annotations = annotations;
/*    */   }
/*    */ 
/*    */   public abstract Class<?> getDeclaringClass();
/*    */ 
/*    */   public abstract Member getMember();
/*    */ 
/*    */   protected AnnotationMap getAllAnnotations()
/*    */   {
/* 31 */     return this._annotations;
/*    */   }
/*    */ 
/*    */   public final void fixAccess()
/*    */   {
/* 40 */     ClassUtil.checkAndFixAccess(getMember());
/*    */   }
/*    */ 
/*    */   public abstract void setValue(Object paramObject1, Object paramObject2)
/*    */     throws UnsupportedOperationException, IllegalArgumentException;
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.AnnotatedMember
 * JD-Core Version:    0.6.2
 */