/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import org.codehaus.jackson.map.type.TypeBindings;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class AnnotatedMethod extends AnnotatedWithParams
/*     */ {
/*     */   protected final Method _method;
/*     */   protected Class<?>[] _paramTypes;
/*     */ 
/*     */   public AnnotatedMethod(Method method, AnnotationMap classAnn, AnnotationMap[] paramAnnotations)
/*     */   {
/*  25 */     super(classAnn, paramAnnotations);
/*  26 */     this._method = method;
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod withMethod(Method m)
/*     */   {
/*  37 */     return new AnnotatedMethod(m, this._annotations, this._paramAnnotations);
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod withAnnotations(AnnotationMap ann)
/*     */   {
/*  42 */     return new AnnotatedMethod(this._method, ann, this._paramAnnotations);
/*     */   }
/*     */ 
/*     */   public Method getAnnotated()
/*     */   {
/*  52 */     return this._method;
/*     */   }
/*     */   public int getModifiers() {
/*  55 */     return this._method.getModifiers();
/*     */   }
/*     */   public String getName() {
/*  58 */     return this._method.getName();
/*     */   }
/*     */ 
/*     */   public Type getGenericType()
/*     */   {
/*  67 */     return this._method.getGenericReturnType();
/*     */   }
/*     */ 
/*     */   public Class<?> getRawType()
/*     */   {
/*  77 */     return this._method.getReturnType();
/*     */   }
/*     */ 
/*     */   public JavaType getType(TypeBindings bindings)
/*     */   {
/*  86 */     return getType(bindings, this._method.getTypeParameters());
/*     */   }
/*     */ 
/*     */   public final Object call() throws Exception
/*     */   {
/*  91 */     return this._method.invoke(null, new Object[0]);
/*     */   }
/*     */ 
/*     */   public final Object call(Object[] args) throws Exception
/*     */   {
/*  96 */     return this._method.invoke(null, args);
/*     */   }
/*     */ 
/*     */   public final Object call1(Object arg) throws Exception
/*     */   {
/* 101 */     return this._method.invoke(null, new Object[] { arg });
/*     */   }
/*     */ 
/*     */   public Class<?> getDeclaringClass()
/*     */   {
/* 111 */     return this._method.getDeclaringClass();
/*     */   }
/*     */   public Member getMember() {
/* 114 */     return this._method;
/*     */   }
/*     */ 
/*     */   public void setValue(Object pojo, Object value) throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 121 */       this._method.invoke(pojo, new Object[] { value });
/*     */     } catch (IllegalAccessException e) {
/* 123 */       throw new IllegalArgumentException("Failed to setValue() with method " + getFullName() + ": " + e.getMessage(), e);
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 126 */       throw new IllegalArgumentException("Failed to setValue() with method " + getFullName() + ": " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getParameterCount()
/*     */   {
/* 139 */     return getParameterTypes().length;
/*     */   }
/*     */ 
/*     */   public Type[] getParameterTypes() {
/* 143 */     return this._method.getGenericParameterTypes();
/*     */   }
/*     */ 
/*     */   public Class<?> getParameterClass(int index)
/*     */   {
/* 149 */     Class[] types = this._method.getParameterTypes();
/* 150 */     return index >= types.length ? null : types[index];
/*     */   }
/*     */ 
/*     */   public Type getParameterType(int index)
/*     */   {
/* 156 */     Type[] types = this._method.getGenericParameterTypes();
/* 157 */     return index >= types.length ? null : types[index];
/*     */   }
/*     */ 
/*     */   public Class<?>[] getParameterClasses()
/*     */   {
/* 162 */     if (this._paramTypes == null) {
/* 163 */       this._paramTypes = this._method.getParameterTypes();
/*     */     }
/* 165 */     return this._paramTypes;
/*     */   }
/*     */ 
/*     */   public String getFullName()
/*     */   {
/* 173 */     return getDeclaringClass().getName() + "#" + getName() + "(" + getParameterCount() + " params)";
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 186 */     return "[method " + getName() + ", annotations: " + this._annotations + "]";
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.AnnotatedMethod
 * JD-Core Version:    0.6.2
 */