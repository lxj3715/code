/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Type;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class AnnotatedParameter extends AnnotatedMember
/*     */ {
/*     */   protected final AnnotatedWithParams _owner;
/*     */   protected final Type _type;
/*     */   protected final int _index;
/*     */ 
/*     */   public AnnotatedParameter(AnnotatedWithParams owner, Type type, AnnotationMap annotations, int index)
/*     */   {
/*  53 */     super(annotations);
/*  54 */     this._owner = owner;
/*  55 */     this._type = type;
/*  56 */     this._index = index;
/*     */   }
/*     */ 
/*     */   public AnnotatedParameter withAnnotations(AnnotationMap ann)
/*     */   {
/*  61 */     if (ann == this._annotations) {
/*  62 */       return this;
/*     */     }
/*  64 */     return this._owner.replaceParameterAnnotations(this._index, ann);
/*     */   }
/*     */ 
/*     */   public void addOrOverride(Annotation a)
/*     */   {
/*  69 */     this._annotations.add(a);
/*     */   }
/*     */ 
/*     */   public AnnotatedElement getAnnotated()
/*     */   {
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public int getModifiers()
/*     */   {
/*  90 */     return this._owner.getModifiers();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  97 */     return "";
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */   {
/* 106 */     return this._annotations.get(acls);
/*     */   }
/*     */ 
/*     */   public Type getGenericType()
/*     */   {
/* 111 */     return this._type;
/*     */   }
/*     */ 
/*     */   public Class<?> getRawType()
/*     */   {
/* 117 */     if ((this._type instanceof Class)) {
/* 118 */       return (Class)this._type;
/*     */     }
/*     */ 
/* 121 */     JavaType t = TypeFactory.defaultInstance().constructType(this._type);
/* 122 */     return t.getRawClass();
/*     */   }
/*     */ 
/*     */   public Class<?> getDeclaringClass()
/*     */   {
/* 133 */     return this._owner.getDeclaringClass();
/*     */   }
/*     */ 
/*     */   public Member getMember()
/*     */   {
/* 141 */     return this._owner.getMember();
/*     */   }
/*     */ 
/*     */   public void setValue(Object pojo, Object value)
/*     */     throws UnsupportedOperationException
/*     */   {
/* 148 */     throw new UnsupportedOperationException("Cannot call setValue() on constructor parameter of " + getDeclaringClass().getName());
/*     */   }
/*     */ 
/*     */   public Type getParameterType()
/*     */   {
/* 158 */     return this._type;
/*     */   }
/*     */ 
/*     */   public AnnotatedWithParams getOwner()
/*     */   {
/* 168 */     return this._owner;
/*     */   }
/*     */ 
/*     */   public int getIndex()
/*     */   {
/* 177 */     return this._index;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 188 */     return "[parameter #" + getIndex() + ", annotations: " + this._annotations + "]";
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.AnnotatedParameter
 * JD-Core Version:    0.6.2
 */