/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import org.codehaus.jackson.map.type.TypeBindings;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class AnnotatedWithParams extends AnnotatedMember
/*     */ {
/*     */   protected final AnnotationMap[] _paramAnnotations;
/*     */ 
/*     */   protected AnnotatedWithParams(AnnotationMap annotations, AnnotationMap[] paramAnnotations)
/*     */   {
/*  32 */     super(annotations);
/*  33 */     this._paramAnnotations = paramAnnotations;
/*     */   }
/*     */ 
/*     */   public final void addOrOverride(Annotation a)
/*     */   {
/*  42 */     this._annotations.add(a);
/*     */   }
/*     */ 
/*     */   public final void addOrOverrideParam(int paramIndex, Annotation a)
/*     */   {
/*  53 */     AnnotationMap old = this._paramAnnotations[paramIndex];
/*  54 */     if (old == null) {
/*  55 */       old = new AnnotationMap();
/*  56 */       this._paramAnnotations[paramIndex] = old;
/*     */     }
/*  58 */     old.add(a);
/*     */   }
/*     */ 
/*     */   public final void addIfNotPresent(Annotation a)
/*     */   {
/*  68 */     this._annotations.addIfNotPresent(a);
/*     */   }
/*     */ 
/*     */   protected AnnotatedParameter replaceParameterAnnotations(int index, AnnotationMap ann)
/*     */   {
/*  80 */     this._paramAnnotations[index] = ann;
/*  81 */     return getParameter(index);
/*     */   }
/*     */ 
/*     */   protected JavaType getType(TypeBindings bindings, TypeVariable<?>[] typeParams)
/*     */   {
/*  93 */     if ((typeParams != null) && (typeParams.length > 0)) {
/*  94 */       bindings = bindings.childInstance();
/*  95 */       for (TypeVariable var : typeParams) {
/*  96 */         String name = var.getName();
/*     */ 
/*  98 */         bindings._addPlaceholder(name);
/*     */ 
/* 100 */         Type lowerBound = var.getBounds()[0];
/* 101 */         JavaType type = lowerBound == null ? TypeFactory.unknownType() : bindings.resolveType(lowerBound);
/*     */ 
/* 103 */         bindings.addBinding(var.getName(), type);
/*     */       }
/*     */     }
/* 106 */     return bindings.resolveType(getGenericType());
/*     */   }
/*     */ 
/*     */   public final <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */   {
/* 118 */     return this._annotations.get(acls);
/*     */   }
/*     */ 
/*     */   public final AnnotationMap getParameterAnnotations(int index)
/*     */   {
/* 129 */     if ((this._paramAnnotations != null) && 
/* 130 */       (index >= 0) && (index <= this._paramAnnotations.length)) {
/* 131 */       return this._paramAnnotations[index];
/*     */     }
/*     */ 
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */   public final AnnotatedParameter getParameter(int index) {
/* 138 */     return new AnnotatedParameter(this, getParameterType(index), this._paramAnnotations[index], index);
/*     */   }
/*     */ 
/*     */   public abstract int getParameterCount();
/*     */ 
/*     */   public abstract Class<?> getParameterClass(int paramInt);
/*     */ 
/*     */   public abstract Type getParameterType(int paramInt);
/*     */ 
/*     */   public final JavaType resolveParameterType(int index, TypeBindings bindings)
/*     */   {
/* 155 */     return bindings.resolveType(getParameterType(index));
/*     */   }
/*     */   public final int getAnnotationCount() {
/* 158 */     return this._annotations.size();
/*     */   }
/*     */ 
/*     */   public abstract Object call()
/*     */     throws Exception;
/*     */ 
/*     */   public abstract Object call(Object[] paramArrayOfObject)
/*     */     throws Exception;
/*     */ 
/*     */   public abstract Object call1(Object paramObject)
/*     */     throws Exception;
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.AnnotatedWithParams
 * JD-Core Version:    0.6.2
 */