/*    */ package org.codehaus.jackson.map.introspect;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.HashMap;
/*    */ import org.codehaus.jackson.map.util.Annotations;
/*    */ 
/*    */ public final class AnnotationMap
/*    */   implements Annotations
/*    */ {
/*    */   protected HashMap<Class<? extends Annotation>, Annotation> _annotations;
/*    */ 
/*    */   public AnnotationMap()
/*    */   {
/*    */   }
/*    */ 
/*    */   private AnnotationMap(HashMap<Class<? extends Annotation>, Annotation> a)
/*    */   {
/* 20 */     this._annotations = a;
/*    */   }
/*    */ 
/*    */   public <A extends Annotation> A get(Class<A> cls)
/*    */   {
/* 27 */     if (this._annotations == null) {
/* 28 */       return null;
/*    */     }
/* 30 */     return (Annotation)this._annotations.get(cls);
/*    */   }
/*    */ 
/*    */   public static AnnotationMap merge(AnnotationMap primary, AnnotationMap secondary)
/*    */   {
/* 35 */     if ((primary == null) || (primary._annotations == null) || (primary._annotations.isEmpty())) {
/* 36 */       return secondary;
/*    */     }
/* 38 */     if ((secondary == null) || (secondary._annotations == null) || (secondary._annotations.isEmpty())) {
/* 39 */       return primary;
/*    */     }
/* 41 */     HashMap annotations = new HashMap();
/*    */ 
/* 44 */     for (Annotation ann : secondary._annotations.values()) {
/* 45 */       annotations.put(ann.annotationType(), ann);
/*    */     }
/*    */ 
/* 48 */     for (Annotation ann : primary._annotations.values()) {
/* 49 */       annotations.put(ann.annotationType(), ann);
/*    */     }
/* 51 */     return new AnnotationMap(annotations);
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 56 */     return this._annotations == null ? 0 : this._annotations.size();
/*    */   }
/*    */ 
/*    */   public void addIfNotPresent(Annotation ann)
/*    */   {
/* 65 */     if ((this._annotations == null) || (!this._annotations.containsKey(ann.annotationType())))
/* 66 */       _add(ann);
/*    */   }
/*    */ 
/*    */   public void add(Annotation ann)
/*    */   {
/* 74 */     _add(ann);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 80 */     if (this._annotations == null) {
/* 81 */       return "[null]";
/*    */     }
/* 83 */     return this._annotations.toString();
/*    */   }
/*    */ 
/*    */   protected final void _add(Annotation ann)
/*    */   {
/* 94 */     if (this._annotations == null) {
/* 95 */       this._annotations = new HashMap();
/*    */     }
/* 97 */     this._annotations.put(ann.annotationType(), ann);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.AnnotationMap
 * JD-Core Version:    0.6.2
 */