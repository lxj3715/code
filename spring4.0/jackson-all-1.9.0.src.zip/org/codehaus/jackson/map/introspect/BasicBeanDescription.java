/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector.ReferenceProperty;
/*     */ import org.codehaus.jackson.map.BeanDescription;
/*     */ import org.codehaus.jackson.map.BeanPropertyDefinition;
/*     */ import org.codehaus.jackson.map.MapperConfig;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
/*     */ import org.codehaus.jackson.map.type.TypeBindings;
/*     */ import org.codehaus.jackson.map.util.Annotations;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class BasicBeanDescription extends BeanDescription
/*     */ {
/*     */   protected final MapperConfig<?> _config;
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */   protected final AnnotatedClass _classInfo;
/*     */   protected TypeBindings _bindings;
/*     */   protected final List<BeanPropertyDefinition> _properties;
/*     */   protected AnnotatedMethod _anySetterMethod;
/*     */   protected Map<Object, AnnotatedMember> _injectables;
/*     */   protected Set<String> _ignoredPropertyNames;
/*     */   protected AnnotatedMethod _jsonValueMethod;
/*     */   protected AnnotatedMethod _anyGetterMethod;
/*     */ 
/*     */   @Deprecated
/*     */   public BasicBeanDescription(MapperConfig<?> config, JavaType type, AnnotatedClass ac)
/*     */   {
/*  83 */     this(config, type, ac, Collections.emptyList());
/*     */   }
/*     */ 
/*     */   protected BasicBeanDescription(MapperConfig<?> config, JavaType type, AnnotatedClass ac, List<BeanPropertyDefinition> properties)
/*     */   {
/*  92 */     super(type);
/*  93 */     this._config = config;
/*  94 */     this._annotationIntrospector = (config == null ? null : config.getAnnotationIntrospector());
/*  95 */     this._classInfo = ac;
/*  96 */     this._properties = properties;
/*     */   }
/*     */ 
/*     */   public static BasicBeanDescription forDeserialization(POJOPropertiesCollector coll)
/*     */   {
/* 107 */     BasicBeanDescription desc = new BasicBeanDescription(coll.getConfig(), coll.getType(), coll.getClassDef(), coll.getProperties());
/*     */ 
/* 109 */     desc._anySetterMethod = coll.getAnySetterMethod();
/* 110 */     desc._ignoredPropertyNames = coll.getIgnoredPropertyNames();
/* 111 */     desc._injectables = coll.getInjectables();
/* 112 */     return desc;
/*     */   }
/*     */ 
/*     */   public static BasicBeanDescription forSerialization(POJOPropertiesCollector coll)
/*     */   {
/* 123 */     BasicBeanDescription desc = new BasicBeanDescription(coll.getConfig(), coll.getType(), coll.getClassDef(), coll.getProperties());
/*     */ 
/* 125 */     desc._jsonValueMethod = coll.getJsonValueMethod();
/* 126 */     desc._anyGetterMethod = coll.getAnyGetterMethod();
/* 127 */     return desc;
/*     */   }
/*     */ 
/*     */   public static BasicBeanDescription forOtherUse(MapperConfig<?> config, JavaType type, AnnotatedClass ac)
/*     */   {
/* 140 */     return new BasicBeanDescription(config, type, ac, Collections.emptyList());
/*     */   }
/*     */ 
/*     */   public AnnotatedClass getClassInfo()
/*     */   {
/* 154 */     return this._classInfo;
/*     */   }
/*     */ 
/*     */   public List<BeanPropertyDefinition> findProperties() {
/* 158 */     return this._properties;
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod findJsonValueMethod()
/*     */   {
/* 170 */     return this._jsonValueMethod;
/*     */   }
/*     */ 
/*     */   public Set<String> getIgnoredPropertyNames()
/*     */   {
/* 175 */     if (this._ignoredPropertyNames == null) {
/* 176 */       return Collections.emptySet();
/*     */     }
/* 178 */     return this._ignoredPropertyNames;
/*     */   }
/*     */ 
/*     */   public boolean hasKnownClassAnnotations()
/*     */   {
/* 187 */     return this._classInfo.hasAnnotations();
/*     */   }
/*     */ 
/*     */   public Annotations getClassAnnotations()
/*     */   {
/* 192 */     return this._classInfo.getAnnotations();
/*     */   }
/*     */ 
/*     */   public TypeBindings bindingsForBeanType()
/*     */   {
/* 198 */     if (this._bindings == null) {
/* 199 */       this._bindings = new TypeBindings(this._config.getTypeFactory(), this._type);
/*     */     }
/* 201 */     return this._bindings;
/*     */   }
/*     */ 
/*     */   public JavaType resolveType(Type jdkType)
/*     */   {
/* 206 */     if (jdkType == null) {
/* 207 */       return null;
/*     */     }
/* 209 */     return bindingsForBeanType().resolveType(jdkType);
/*     */   }
/*     */ 
/*     */   public AnnotatedConstructor findDefaultConstructor()
/*     */   {
/* 222 */     return this._classInfo.getDefaultConstructor();
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod findAnySetter()
/*     */     throws IllegalArgumentException
/*     */   {
/* 237 */     if (this._anySetterMethod != null)
/*     */     {
/* 246 */       Class type = this._anySetterMethod.getParameterClass(0);
/* 247 */       if ((type != String.class) && (type != Object.class)) {
/* 248 */         throw new IllegalArgumentException("Invalid 'any-setter' annotation on method " + this._anySetterMethod.getName() + "(): first argument not of type String or Object, but " + type.getName());
/*     */       }
/*     */     }
/* 251 */     return this._anySetterMethod;
/*     */   }
/*     */ 
/*     */   public Map<Object, AnnotatedMember> findInjectables()
/*     */   {
/* 257 */     return this._injectables;
/*     */   }
/*     */ 
/*     */   public List<AnnotatedConstructor> getConstructors()
/*     */   {
/* 262 */     return this._classInfo.getConstructors();
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod findMethod(String name, Class<?>[] paramTypes)
/*     */   {
/* 273 */     return this._classInfo.findMethod(name, paramTypes);
/*     */   }
/*     */ 
/*     */   public Object instantiateBean(boolean fixAccess)
/*     */   {
/* 290 */     AnnotatedConstructor ac = this._classInfo.getDefaultConstructor();
/* 291 */     if (ac == null) {
/* 292 */       return null;
/*     */     }
/* 294 */     if (fixAccess)
/* 295 */       ac.fixAccess();
/*     */     try
/*     */     {
/* 298 */       return ac.getAnnotated().newInstance(new Object[0]);
/*     */     } catch (Exception e) {
/* 300 */       Throwable t = e;
/* 301 */       while (t.getCause() != null) {
/* 302 */         t = t.getCause();
/*     */       }
/* 304 */       if ((t instanceof Error)) throw ((Error)t);
/* 305 */       if ((t instanceof RuntimeException)) throw ((RuntimeException)t);
/* 306 */       throw new IllegalArgumentException("Failed to instantiate bean of type " + this._classInfo.getAnnotated().getName() + ": (" + t.getClass().getName() + ") " + t.getMessage(), t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<AnnotatedMethod> getFactoryMethods()
/*     */   {
/* 319 */     List candidates = this._classInfo.getStaticMethods();
/* 320 */     if (candidates.isEmpty()) {
/* 321 */       return candidates;
/*     */     }
/* 323 */     ArrayList result = new ArrayList();
/* 324 */     for (AnnotatedMethod am : candidates) {
/* 325 */       if (isFactoryMethod(am)) {
/* 326 */         result.add(am);
/*     */       }
/*     */     }
/* 329 */     return result;
/*     */   }
/*     */ 
/*     */   public Constructor<?> findSingleArgConstructor(Class<?>[] argTypes)
/*     */   {
/* 340 */     for (AnnotatedConstructor ac : this._classInfo.getConstructors())
/*     */     {
/* 345 */       if (ac.getParameterCount() == 1) {
/* 346 */         Class actArg = ac.getParameterClass(0);
/* 347 */         for (Class expArg : argTypes) {
/* 348 */           if (expArg == actArg) {
/* 349 */             return ac.getAnnotated();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 354 */     return null;
/*     */   }
/*     */ 
/*     */   public Method findFactoryMethod(Class<?>[] expArgTypes)
/*     */   {
/* 369 */     for (AnnotatedMethod am : this._classInfo.getStaticMethods()) {
/* 370 */       if (isFactoryMethod(am))
/*     */       {
/* 372 */         Class actualArgType = am.getParameterClass(0);
/* 373 */         for (Class expArgType : expArgTypes)
/*     */         {
/* 375 */           if (actualArgType.isAssignableFrom(expArgType)) {
/* 376 */             return am.getAnnotated();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 381 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean isFactoryMethod(AnnotatedMethod am)
/*     */   {
/* 390 */     Class rt = am.getRawType();
/* 391 */     if (!getBeanClass().isAssignableFrom(rt)) {
/* 392 */       return false;
/*     */     }
/*     */ 
/* 399 */     if (this._annotationIntrospector.hasCreatorAnnotation(am)) {
/* 400 */       return true;
/*     */     }
/* 402 */     if ("valueOf".equals(am.getName())) {
/* 403 */       return true;
/*     */     }
/* 405 */     return false;
/*     */   }
/*     */ 
/*     */   public List<String> findCreatorPropertyNames()
/*     */   {
/* 419 */     List names = null;
/*     */ 
/* 421 */     for (int i = 0; i < 2; i++) {
/* 422 */       List l = i == 0 ? getConstructors() : getFactoryMethods();
/*     */ 
/* 424 */       for (AnnotatedWithParams creator : l) {
/* 425 */         int argCount = creator.getParameterCount();
/* 426 */         if (argCount >= 1) {
/* 427 */           String name = this._annotationIntrospector.findPropertyNameForParam(creator.getParameter(0));
/* 428 */           if (name != null) {
/* 429 */             if (names == null) {
/* 430 */               names = new ArrayList();
/*     */             }
/* 432 */             names.add(name);
/* 433 */             for (int p = 1; p < argCount; p++)
/* 434 */               names.add(this._annotationIntrospector.findPropertyNameForParam(creator.getParameter(p))); 
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 438 */     if (names == null) {
/* 439 */       return Collections.emptyList();
/*     */     }
/* 441 */     return names;
/*     */   }
/*     */ 
/*     */   public JsonSerialize.Inclusion findSerializationInclusion(JsonSerialize.Inclusion defValue)
/*     */   {
/* 458 */     if (this._annotationIntrospector == null) {
/* 459 */       return defValue;
/*     */     }
/* 461 */     return this._annotationIntrospector.findSerializationInclusion(this._classInfo, defValue);
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod findAnyGetter()
/*     */     throws IllegalArgumentException
/*     */   {
/* 475 */     if (this._anyGetterMethod != null)
/*     */     {
/* 479 */       Class type = this._anyGetterMethod.getRawType();
/* 480 */       if (!Map.class.isAssignableFrom(type)) {
/* 481 */         throw new IllegalArgumentException("Invalid 'any-getter' annotation on method " + this._anyGetterMethod.getName() + "(): return type is not instance of java.util.Map");
/*     */       }
/*     */     }
/* 484 */     return this._anyGetterMethod;
/*     */   }
/*     */ 
/*     */   public Map<String, AnnotatedMember> findBackReferenceProperties()
/*     */   {
/* 494 */     HashMap result = null;
/*     */ 
/* 496 */     for (AnnotatedMethod am : this._classInfo.memberMethods()) {
/* 497 */       if (am.getParameterCount() == 1) {
/* 498 */         AnnotationIntrospector.ReferenceProperty prop = this._annotationIntrospector.findReferenceType(am);
/* 499 */         if ((prop != null) && (prop.isBackReference())) {
/* 500 */           if (result == null) {
/* 501 */             result = new HashMap();
/*     */           }
/* 503 */           if (result.put(prop.getName(), am) != null) {
/* 504 */             throw new IllegalArgumentException("Multiple back-reference properties with name '" + prop.getName() + "'");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 510 */     for (AnnotatedField af : this._classInfo.fields()) {
/* 511 */       AnnotationIntrospector.ReferenceProperty prop = this._annotationIntrospector.findReferenceType(af);
/* 512 */       if ((prop != null) && (prop.isBackReference())) {
/* 513 */         if (result == null) {
/* 514 */           result = new HashMap();
/*     */         }
/* 516 */         if (result.put(prop.getName(), af) != null) {
/* 517 */           throw new IllegalArgumentException("Multiple back-reference properties with name '" + prop.getName() + "'");
/*     */         }
/*     */       }
/*     */     }
/* 521 */     return result;
/*     */   }
/*     */ 
/*     */   public LinkedHashMap<String, AnnotatedField> _findPropertyFields(Collection<String> ignoredProperties, boolean forSerialization)
/*     */   {
/* 543 */     LinkedHashMap results = new LinkedHashMap();
/* 544 */     for (BeanPropertyDefinition property : this._properties) {
/* 545 */       AnnotatedField f = property.getField();
/* 546 */       if (f != null) {
/* 547 */         String name = property.getName();
/* 548 */         if ((ignoredProperties == null) || 
/* 549 */           (!ignoredProperties.contains(name)))
/*     */         {
/* 553 */           results.put(name, f);
/*     */         }
/*     */       }
/*     */     }
/* 556 */     return results;
/*     */   }
/*     */ 
/*     */   public LinkedHashMap<String, AnnotatedMethod> findGetters(VisibilityChecker<?> visibilityChecker, Collection<String> ignoredProperties)
/*     */   {
/* 570 */     LinkedHashMap results = new LinkedHashMap();
/* 571 */     for (BeanPropertyDefinition property : this._properties) {
/* 572 */       AnnotatedMethod m = property.getGetter();
/* 573 */       if (m != null) {
/* 574 */         String name = property.getName();
/* 575 */         if ((ignoredProperties == null) || 
/* 576 */           (!ignoredProperties.contains(name)))
/*     */         {
/* 580 */           results.put(name, m);
/*     */         }
/*     */       }
/*     */     }
/* 583 */     return results;
/*     */   }
/*     */ 
/*     */   public LinkedHashMap<String, AnnotatedMethod> findSetters(VisibilityChecker<?> visibilityChecker)
/*     */   {
/* 590 */     LinkedHashMap results = new LinkedHashMap();
/* 591 */     for (BeanPropertyDefinition property : this._properties) {
/* 592 */       AnnotatedMethod m = property.getSetter();
/* 593 */       if (m != null) {
/* 594 */         results.put(property.getName(), m);
/*     */       }
/*     */     }
/* 597 */     return results;
/*     */   }
/*     */ 
/*     */   public LinkedHashMap<String, AnnotatedField> findSerializableFields(VisibilityChecker<?> visibilityChecker, Collection<String> ignoredProperties)
/*     */   {
/* 605 */     return _findPropertyFields(ignoredProperties, true);
/*     */   }
/*     */ 
/*     */   public LinkedHashMap<String, AnnotatedField> findDeserializableFields(VisibilityChecker<?> visibilityChecker, Collection<String> ignoredProperties)
/*     */   {
/* 613 */     return _findPropertyFields(ignoredProperties, false);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.BasicBeanDescription
 * JD-Core Version:    0.6.2
 */