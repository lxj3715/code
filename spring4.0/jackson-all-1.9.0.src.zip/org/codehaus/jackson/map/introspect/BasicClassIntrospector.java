/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.ClassIntrospector;
/*     */ import org.codehaus.jackson.map.ClassIntrospector.MixInResolver;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.MapperConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.type.SimpleType;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class BasicClassIntrospector extends ClassIntrospector<BasicBeanDescription>
/*     */ {
/*     */   protected static final BasicBeanDescription STRING_DESC;
/*     */   protected static final BasicBeanDescription BOOLEAN_DESC;
/*     */   protected static final BasicBeanDescription INT_DESC;
/*  44 */   protected static final BasicBeanDescription LONG_DESC = BasicBeanDescription.forOtherUse(null, SimpleType.constructUnsafe(Long.TYPE), ac);
/*     */ 
/*     */   @Deprecated
/*  55 */   public static final GetterMethodFilter DEFAULT_GETTER_FILTER = new GetterMethodFilter(null);
/*     */ 
/*     */   @Deprecated
/*  62 */   public static final SetterMethodFilter DEFAULT_SETTER_FILTER = new SetterMethodFilter();
/*     */ 
/*     */   @Deprecated
/*  69 */   public static final SetterAndGetterMethodFilter DEFAULT_SETTER_AND_GETTER_FILTER = new SetterAndGetterMethodFilter();
/*     */ 
/*  71 */   protected static final MethodFilter MINIMAL_FILTER = new MinimalMethodFilter(null);
/*     */ 
/*  79 */   public static final BasicClassIntrospector instance = new BasicClassIntrospector();
/*     */ 
/*     */   public BasicBeanDescription forSerialization(SerializationConfig cfg, JavaType type, ClassIntrospector.MixInResolver r)
/*     */   {
/*  94 */     BasicBeanDescription desc = _findCachedDesc(type);
/*  95 */     if (desc == null) {
/*  96 */       desc = BasicBeanDescription.forSerialization(collectProperties(cfg, type, r, true));
/*     */     }
/*  98 */     return desc;
/*     */   }
/*     */ 
/*     */   public BasicBeanDescription forDeserialization(DeserializationConfig cfg, JavaType type, ClassIntrospector.MixInResolver r)
/*     */   {
/* 106 */     BasicBeanDescription desc = _findCachedDesc(type);
/* 107 */     if (desc == null) {
/* 108 */       desc = BasicBeanDescription.forDeserialization(collectProperties(cfg, type, r, false));
/*     */     }
/* 110 */     return desc;
/*     */   }
/*     */ 
/*     */   public BasicBeanDescription forCreation(DeserializationConfig cfg, JavaType type, ClassIntrospector.MixInResolver r)
/*     */   {
/* 117 */     BasicBeanDescription desc = _findCachedDesc(type);
/* 118 */     if (desc == null) {
/* 119 */       desc = BasicBeanDescription.forDeserialization(collectProperties(cfg, type, r, false));
/*     */     }
/* 121 */     return desc;
/*     */   }
/*     */ 
/*     */   public BasicBeanDescription forClassAnnotations(MapperConfig<?> cfg, JavaType type, ClassIntrospector.MixInResolver r)
/*     */   {
/* 128 */     boolean useAnnotations = cfg.isAnnotationProcessingEnabled();
/* 129 */     AnnotationIntrospector ai = cfg.getAnnotationIntrospector();
/* 130 */     AnnotatedClass ac = AnnotatedClass.construct(type.getRawClass(), useAnnotations ? ai : null, r);
/* 131 */     return BasicBeanDescription.forOtherUse(cfg, type, ac);
/*     */   }
/*     */ 
/*     */   public BasicBeanDescription forDirectClassAnnotations(MapperConfig<?> cfg, JavaType type, ClassIntrospector.MixInResolver r)
/*     */   {
/* 138 */     boolean useAnnotations = cfg.isAnnotationProcessingEnabled();
/* 139 */     AnnotationIntrospector ai = cfg.getAnnotationIntrospector();
/* 140 */     AnnotatedClass ac = AnnotatedClass.constructWithoutSuperTypes(type.getRawClass(), useAnnotations ? ai : null, r);
/*     */ 
/* 142 */     return BasicBeanDescription.forOtherUse(cfg, type, ac);
/*     */   }
/*     */ 
/*     */   public POJOPropertiesCollector collectProperties(MapperConfig<?> config, JavaType type, ClassIntrospector.MixInResolver r, boolean forSerialization)
/*     */   {
/* 157 */     AnnotatedClass ac = classWithCreators(config, type, r);
/* 158 */     ac.resolveMemberMethods(MINIMAL_FILTER);
/* 159 */     ac.resolveFields();
/* 160 */     return constructPropertyCollector(config, ac, type, forSerialization).collect();
/*     */   }
/*     */ 
/*     */   protected POJOPropertiesCollector constructPropertyCollector(MapperConfig<?> config, AnnotatedClass ac, JavaType type, boolean forSerialization)
/*     */   {
/* 173 */     return new POJOPropertiesCollector(config, forSerialization, type, ac);
/*     */   }
/*     */ 
/*     */   public AnnotatedClass classWithCreators(MapperConfig<?> config, JavaType type, ClassIntrospector.MixInResolver r)
/*     */   {
/* 182 */     boolean useAnnotations = config.isAnnotationProcessingEnabled();
/* 183 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 184 */     AnnotatedClass ac = AnnotatedClass.construct(type.getRawClass(), useAnnotations ? ai : null, r);
/* 185 */     ac.resolveMemberMethods(MINIMAL_FILTER);
/*     */ 
/* 187 */     ac.resolveCreators(true);
/* 188 */     return ac;
/*     */   }
/*     */ 
/*     */   protected BasicBeanDescription _findCachedDesc(JavaType type)
/*     */   {
/* 199 */     Class cls = type.getRawClass();
/* 200 */     if (cls == String.class) {
/* 201 */       return STRING_DESC;
/*     */     }
/* 203 */     if (cls == Boolean.TYPE) {
/* 204 */       return BOOLEAN_DESC;
/*     */     }
/* 206 */     if (cls == Integer.TYPE) {
/* 207 */       return INT_DESC;
/*     */     }
/* 209 */     if (cls == Long.TYPE) {
/* 210 */       return LONG_DESC;
/*     */     }
/* 212 */     return null;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected MethodFilter getSerializationMethodFilter(SerializationConfig cfg)
/*     */   {
/* 224 */     return DEFAULT_GETTER_FILTER;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected MethodFilter getDeserializationMethodFilter(DeserializationConfig cfg)
/*     */   {
/* 239 */     if (cfg.isEnabled(DeserializationConfig.Feature.USE_GETTERS_AS_SETTERS)) {
/* 240 */       return DEFAULT_SETTER_AND_GETTER_FILTER;
/*     */     }
/*     */ 
/* 243 */     return DEFAULT_SETTER_FILTER;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  28 */     AnnotatedClass ac = AnnotatedClass.constructWithoutSuperTypes(String.class, null, null);
/*  29 */     STRING_DESC = BasicBeanDescription.forOtherUse(null, SimpleType.constructUnsafe(String.class), ac);
/*     */ 
/*  33 */     AnnotatedClass ac = AnnotatedClass.constructWithoutSuperTypes(Boolean.TYPE, null, null);
/*  34 */     BOOLEAN_DESC = BasicBeanDescription.forOtherUse(null, SimpleType.constructUnsafe(Boolean.TYPE), ac);
/*     */ 
/*  38 */     AnnotatedClass ac = AnnotatedClass.constructWithoutSuperTypes(Integer.TYPE, null, null);
/*  39 */     INT_DESC = BasicBeanDescription.forOtherUse(null, SimpleType.constructUnsafe(Integer.TYPE), ac);
/*     */ 
/*  43 */     AnnotatedClass ac = AnnotatedClass.constructWithoutSuperTypes(Long.TYPE, null, null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static final class SetterAndGetterMethodFilter extends BasicClassIntrospector.SetterMethodFilter
/*     */   {
/*     */     public boolean includeMethod(Method m)
/*     */     {
/* 349 */       if (super.includeMethod(m)) {
/* 350 */         return true;
/*     */       }
/* 352 */       if (!ClassUtil.hasGetterSignature(m)) {
/* 353 */         return false;
/*     */       }
/*     */ 
/* 356 */       Class rt = m.getReturnType();
/* 357 */       if ((Collection.class.isAssignableFrom(rt)) || (Map.class.isAssignableFrom(rt)))
/*     */       {
/* 359 */         return true;
/*     */       }
/* 361 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static class SetterMethodFilter
/*     */     implements MethodFilter
/*     */   {
/*     */     public boolean includeMethod(Method m)
/*     */     {
/* 311 */       if (Modifier.isStatic(m.getModifiers())) {
/* 312 */         return false;
/*     */       }
/* 314 */       int pcount = m.getParameterTypes().length;
/*     */ 
/* 316 */       switch (pcount)
/*     */       {
/*     */       case 1:
/* 319 */         return true;
/*     */       case 2:
/* 329 */         return true;
/*     */       }
/* 331 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static class GetterMethodFilter
/*     */     implements MethodFilter
/*     */   {
/*     */     public boolean includeMethod(Method m)
/*     */     {
/* 288 */       return ClassUtil.hasGetterSignature(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MinimalMethodFilter
/*     */     implements MethodFilter
/*     */   {
/*     */     public boolean includeMethod(Method m)
/*     */     {
/* 264 */       if (Modifier.isStatic(m.getModifiers())) {
/* 265 */         return false;
/*     */       }
/* 267 */       int pcount = m.getParameterTypes().length;
/* 268 */       return pcount <= 2;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.BasicClassIntrospector
 * JD-Core Version:    0.6.2
 */