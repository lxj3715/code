/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.codehaus.jackson.annotate.JacksonAnnotation;
/*     */ import org.codehaus.jackson.annotate.JsonAnyGetter;
/*     */ import org.codehaus.jackson.annotate.JsonAnySetter;
/*     */ import org.codehaus.jackson.annotate.JsonAutoDetect;
/*     */ import org.codehaus.jackson.annotate.JsonBackReference;
/*     */ import org.codehaus.jackson.annotate.JsonCreator;
/*     */ import org.codehaus.jackson.annotate.JsonGetter;
/*     */ import org.codehaus.jackson.annotate.JsonIgnore;
/*     */ import org.codehaus.jackson.annotate.JsonIgnoreProperties;
/*     */ import org.codehaus.jackson.annotate.JsonIgnoreType;
/*     */ import org.codehaus.jackson.annotate.JsonManagedReference;
/*     */ import org.codehaus.jackson.annotate.JsonProperty;
/*     */ import org.codehaus.jackson.annotate.JsonPropertyOrder;
/*     */ import org.codehaus.jackson.annotate.JsonRawValue;
/*     */ import org.codehaus.jackson.annotate.JsonSetter;
/*     */ import org.codehaus.jackson.annotate.JsonSubTypes;
/*     */ import org.codehaus.jackson.annotate.JsonSubTypes.Type;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.Id;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.None;
/*     */ import org.codehaus.jackson.annotate.JsonTypeName;
/*     */ import org.codehaus.jackson.annotate.JsonUnwrapped;
/*     */ import org.codehaus.jackson.annotate.JsonValue;
/*     */ import org.codehaus.jackson.annotate.JsonWriteNullProperties;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector.ReferenceProperty;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonDeserializer.None;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.JsonSerializer.None;
/*     */ import org.codehaus.jackson.map.KeyDeserializer;
/*     */ import org.codehaus.jackson.map.KeyDeserializer.None;
/*     */ import org.codehaus.jackson.map.MapperConfig;
/*     */ import org.codehaus.jackson.map.annotate.JacksonInject;
/*     */ import org.codehaus.jackson.map.annotate.JsonCachable;
/*     */ import org.codehaus.jackson.map.annotate.JsonDeserialize;
/*     */ import org.codehaus.jackson.map.annotate.JsonFilter;
/*     */ import org.codehaus.jackson.map.annotate.JsonRootName;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Typing;
/*     */ import org.codehaus.jackson.map.annotate.JsonTypeIdResolver;
/*     */ import org.codehaus.jackson.map.annotate.JsonTypeResolver;
/*     */ import org.codehaus.jackson.map.annotate.JsonValueInstantiator;
/*     */ import org.codehaus.jackson.map.annotate.JsonView;
/*     */ import org.codehaus.jackson.map.annotate.NoClass;
/*     */ import org.codehaus.jackson.map.jsontype.NamedType;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*     */ import org.codehaus.jackson.map.jsontype.impl.StdTypeResolverBuilder;
/*     */ import org.codehaus.jackson.map.ser.std.RawSerializer;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class JacksonAnnotationIntrospector extends AnnotationIntrospector
/*     */ {
/*     */   public boolean isHandled(Annotation ann)
/*     */   {
/*  35 */     Class acls = ann.annotationType();
/*     */ 
/*  45 */     return acls.getAnnotation(JacksonAnnotation.class) != null;
/*     */   }
/*     */ 
/*     */   public String findEnumValue(Enum<?> value)
/*     */   {
/*  57 */     return value.name();
/*     */   }
/*     */ 
/*     */   public Boolean findCachability(AnnotatedClass ac)
/*     */   {
/*  69 */     JsonCachable ann = (JsonCachable)ac.getAnnotation(JsonCachable.class);
/*  70 */     if (ann == null) {
/*  71 */       return null;
/*     */     }
/*  73 */     return ann.value() ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ 
/*     */   public String findRootName(AnnotatedClass ac)
/*     */   {
/*  79 */     JsonRootName ann = (JsonRootName)ac.getAnnotation(JsonRootName.class);
/*  80 */     return ann == null ? null : ann.value();
/*     */   }
/*     */ 
/*     */   public String[] findPropertiesToIgnore(AnnotatedClass ac)
/*     */   {
/*  85 */     JsonIgnoreProperties ignore = (JsonIgnoreProperties)ac.getAnnotation(JsonIgnoreProperties.class);
/*  86 */     return ignore == null ? null : ignore.value();
/*     */   }
/*     */ 
/*     */   public Boolean findIgnoreUnknownProperties(AnnotatedClass ac)
/*     */   {
/*  91 */     JsonIgnoreProperties ignore = (JsonIgnoreProperties)ac.getAnnotation(JsonIgnoreProperties.class);
/*  92 */     return ignore == null ? null : Boolean.valueOf(ignore.ignoreUnknown());
/*     */   }
/*     */ 
/*     */   public Boolean isIgnorableType(AnnotatedClass ac)
/*     */   {
/*  97 */     JsonIgnoreType ignore = (JsonIgnoreType)ac.getAnnotation(JsonIgnoreType.class);
/*  98 */     return ignore == null ? null : Boolean.valueOf(ignore.value());
/*     */   }
/*     */ 
/*     */   public Object findFilterId(AnnotatedClass ac)
/*     */   {
/* 104 */     JsonFilter ann = (JsonFilter)ac.getAnnotation(JsonFilter.class);
/* 105 */     if (ann != null) {
/* 106 */       String id = ann.value();
/*     */ 
/* 108 */       if (id.length() > 0) {
/* 109 */         return id;
/*     */       }
/*     */     }
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   public VisibilityChecker<?> findAutoDetectVisibility(AnnotatedClass ac, VisibilityChecker<?> checker)
/*     */   {
/* 125 */     JsonAutoDetect ann = (JsonAutoDetect)ac.getAnnotation(JsonAutoDetect.class);
/* 126 */     return ann == null ? checker : checker.with(ann);
/*     */   }
/*     */ 
/*     */   public AnnotationIntrospector.ReferenceProperty findReferenceType(AnnotatedMember member)
/*     */   {
/* 139 */     JsonManagedReference ref1 = (JsonManagedReference)member.getAnnotation(JsonManagedReference.class);
/* 140 */     if (ref1 != null) {
/* 141 */       return AnnotationIntrospector.ReferenceProperty.managed(ref1.value());
/*     */     }
/* 143 */     JsonBackReference ref2 = (JsonBackReference)member.getAnnotation(JsonBackReference.class);
/* 144 */     if (ref2 != null) {
/* 145 */       return AnnotationIntrospector.ReferenceProperty.back(ref2.value());
/*     */     }
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */   public Boolean shouldUnwrapProperty(AnnotatedMember member)
/*     */   {
/* 153 */     JsonUnwrapped ann = (JsonUnwrapped)member.getAnnotation(JsonUnwrapped.class);
/*     */ 
/* 156 */     return (ann != null) && (ann.enabled()) ? Boolean.TRUE : null;
/*     */   }
/*     */ 
/*     */   public boolean hasIgnoreMarker(AnnotatedMember m)
/*     */   {
/* 161 */     return _isIgnorable(m);
/*     */   }
/*     */ 
/*     */   public Object findInjectableValueId(AnnotatedMember m)
/*     */   {
/* 167 */     JacksonInject ann = (JacksonInject)m.getAnnotation(JacksonInject.class);
/* 168 */     if (ann == null) {
/* 169 */       return null;
/*     */     }
/*     */ 
/* 174 */     String id = ann.value();
/* 175 */     if (id.length() == 0)
/*     */     {
/* 177 */       if (!(m instanceof AnnotatedMethod)) {
/* 178 */         return m.getRawType().getName();
/*     */       }
/* 180 */       AnnotatedMethod am = (AnnotatedMethod)m;
/* 181 */       if (am.getParameterCount() == 0) {
/* 182 */         return m.getRawType().getName();
/*     */       }
/* 184 */       return am.getParameterClass(0).getName();
/*     */     }
/* 186 */     return id;
/*     */   }
/*     */ 
/*     */   public TypeResolverBuilder<?> findTypeResolver(MapperConfig<?> config, AnnotatedClass ac, JavaType baseType)
/*     */   {
/* 199 */     return _findTypeResolver(config, ac, baseType);
/*     */   }
/*     */ 
/*     */   public TypeResolverBuilder<?> findPropertyTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType)
/*     */   {
/* 212 */     if (baseType.isContainerType()) return null;
/*     */ 
/* 214 */     return _findTypeResolver(config, am, baseType);
/*     */   }
/*     */ 
/*     */   public TypeResolverBuilder<?> findPropertyContentTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType containerType)
/*     */   {
/* 227 */     if (!containerType.isContainerType()) {
/* 228 */       throw new IllegalArgumentException("Must call method with a container type (got " + containerType + ")");
/*     */     }
/* 230 */     return _findTypeResolver(config, am, containerType);
/*     */   }
/*     */ 
/*     */   public List<NamedType> findSubtypes(Annotated a)
/*     */   {
/* 236 */     JsonSubTypes t = (JsonSubTypes)a.getAnnotation(JsonSubTypes.class);
/* 237 */     if (t == null) return null;
/* 238 */     JsonSubTypes.Type[] types = t.value();
/* 239 */     ArrayList result = new ArrayList(types.length);
/* 240 */     for (JsonSubTypes.Type type : types) {
/* 241 */       result.add(new NamedType(type.value(), type.name()));
/*     */     }
/* 243 */     return result;
/*     */   }
/*     */ 
/*     */   public String findTypeName(AnnotatedClass ac)
/*     */   {
/* 249 */     JsonTypeName tn = (JsonTypeName)ac.getAnnotation(JsonTypeName.class);
/* 250 */     return tn == null ? null : tn.value();
/*     */   }
/*     */ 
/*     */   public boolean isIgnorableMethod(AnnotatedMethod m)
/*     */   {
/* 261 */     return _isIgnorable(m);
/*     */   }
/*     */ 
/*     */   public boolean isIgnorableConstructor(AnnotatedConstructor c)
/*     */   {
/* 266 */     return _isIgnorable(c);
/*     */   }
/*     */ 
/*     */   public boolean isIgnorableField(AnnotatedField f)
/*     */   {
/* 277 */     return _isIgnorable(f);
/*     */   }
/*     */ 
/*     */   public Object findSerializer(Annotated a)
/*     */   {
/* 292 */     JsonSerialize ann = (JsonSerialize)a.getAnnotation(JsonSerialize.class);
/* 293 */     if (ann != null) {
/* 294 */       Class serClass = ann.using();
/* 295 */       if (serClass != JsonSerializer.None.class) {
/* 296 */         return serClass;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 304 */     JsonRawValue annRaw = (JsonRawValue)a.getAnnotation(JsonRawValue.class);
/* 305 */     if ((annRaw != null) && (annRaw.value()))
/*     */     {
/* 307 */       Class cls = a.getRawType();
/* 308 */       return new RawSerializer(cls);
/*     */     }
/* 310 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<? extends JsonSerializer<?>> findKeySerializer(Annotated a)
/*     */   {
/* 316 */     JsonSerialize ann = (JsonSerialize)a.getAnnotation(JsonSerialize.class);
/* 317 */     if (ann != null) {
/* 318 */       Class serClass = ann.keyUsing();
/* 319 */       if (serClass != JsonSerializer.None.class) {
/* 320 */         return serClass;
/*     */       }
/*     */     }
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<? extends JsonSerializer<?>> findContentSerializer(Annotated a)
/*     */   {
/* 329 */     JsonSerialize ann = (JsonSerialize)a.getAnnotation(JsonSerialize.class);
/* 330 */     if (ann != null) {
/* 331 */       Class serClass = ann.contentUsing();
/* 332 */       if (serClass != JsonSerializer.None.class) {
/* 333 */         return serClass;
/*     */       }
/*     */     }
/* 336 */     return null;
/*     */   }
/*     */ 
/*     */   public JsonSerialize.Inclusion findSerializationInclusion(Annotated a, JsonSerialize.Inclusion defValue)
/*     */   {
/* 343 */     JsonSerialize ann = (JsonSerialize)a.getAnnotation(JsonSerialize.class);
/* 344 */     if (ann != null) {
/* 345 */       return ann.include();
/*     */     }
/*     */ 
/* 350 */     JsonWriteNullProperties oldAnn = (JsonWriteNullProperties)a.getAnnotation(JsonWriteNullProperties.class);
/* 351 */     if (oldAnn != null) {
/* 352 */       boolean writeNulls = oldAnn.value();
/* 353 */       return writeNulls ? JsonSerialize.Inclusion.ALWAYS : JsonSerialize.Inclusion.NON_NULL;
/*     */     }
/* 355 */     return defValue;
/*     */   }
/*     */ 
/*     */   public Class<?> findSerializationType(Annotated am)
/*     */   {
/* 361 */     JsonSerialize ann = (JsonSerialize)am.getAnnotation(JsonSerialize.class);
/* 362 */     if (ann != null) {
/* 363 */       Class cls = ann.as();
/* 364 */       if (cls != NoClass.class) {
/* 365 */         return cls;
/*     */       }
/*     */     }
/* 368 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findSerializationKeyType(Annotated am, JavaType baseType)
/*     */   {
/* 374 */     JsonSerialize ann = (JsonSerialize)am.getAnnotation(JsonSerialize.class);
/* 375 */     if (ann != null) {
/* 376 */       Class cls = ann.keyAs();
/* 377 */       if (cls != NoClass.class) {
/* 378 */         return cls;
/*     */       }
/*     */     }
/* 381 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findSerializationContentType(Annotated am, JavaType baseType)
/*     */   {
/* 387 */     JsonSerialize ann = (JsonSerialize)am.getAnnotation(JsonSerialize.class);
/* 388 */     if (ann != null) {
/* 389 */       Class cls = ann.contentAs();
/* 390 */       if (cls != NoClass.class) {
/* 391 */         return cls;
/*     */       }
/*     */     }
/* 394 */     return null;
/*     */   }
/*     */ 
/*     */   public JsonSerialize.Typing findSerializationTyping(Annotated a)
/*     */   {
/* 400 */     JsonSerialize ann = (JsonSerialize)a.getAnnotation(JsonSerialize.class);
/* 401 */     return ann == null ? null : ann.typing();
/*     */   }
/*     */ 
/*     */   public Class<?>[] findSerializationViews(Annotated a)
/*     */   {
/* 407 */     JsonView ann = (JsonView)a.getAnnotation(JsonView.class);
/* 408 */     return ann == null ? null : ann.value();
/*     */   }
/*     */ 
/*     */   public String[] findSerializationPropertyOrder(AnnotatedClass ac)
/*     */   {
/* 419 */     JsonPropertyOrder order = (JsonPropertyOrder)ac.getAnnotation(JsonPropertyOrder.class);
/* 420 */     return order == null ? null : order.value();
/*     */   }
/*     */ 
/*     */   public Boolean findSerializationSortAlphabetically(AnnotatedClass ac)
/*     */   {
/* 425 */     JsonPropertyOrder order = (JsonPropertyOrder)ac.getAnnotation(JsonPropertyOrder.class);
/* 426 */     return order == null ? null : Boolean.valueOf(order.alphabetic());
/*     */   }
/*     */ 
/*     */   public String findGettablePropertyName(AnnotatedMethod am)
/*     */   {
/* 442 */     JsonProperty pann = (JsonProperty)am.getAnnotation(JsonProperty.class);
/* 443 */     if (pann != null) {
/* 444 */       return pann.value();
/*     */     }
/*     */ 
/* 449 */     JsonGetter ann = (JsonGetter)am.getAnnotation(JsonGetter.class);
/* 450 */     if (ann != null) {
/* 451 */       return ann.value();
/*     */     }
/*     */ 
/* 457 */     if ((am.hasAnnotation(JsonSerialize.class)) || (am.hasAnnotation(JsonView.class))) {
/* 458 */       return "";
/*     */     }
/* 460 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean hasAsValueAnnotation(AnnotatedMethod am)
/*     */   {
/* 466 */     JsonValue ann = (JsonValue)am.getAnnotation(JsonValue.class);
/*     */ 
/* 468 */     return (ann != null) && (ann.value());
/*     */   }
/*     */ 
/*     */   public String findSerializablePropertyName(AnnotatedField af)
/*     */   {
/* 480 */     JsonProperty pann = (JsonProperty)af.getAnnotation(JsonProperty.class);
/* 481 */     if (pann != null) {
/* 482 */       return pann.value();
/*     */     }
/*     */ 
/* 486 */     if ((af.hasAnnotation(JsonSerialize.class)) || (af.hasAnnotation(JsonView.class))) {
/* 487 */       return "";
/*     */     }
/* 489 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<? extends JsonDeserializer<?>> findDeserializer(Annotated a)
/*     */   {
/* 504 */     JsonDeserialize ann = (JsonDeserialize)a.getAnnotation(JsonDeserialize.class);
/* 505 */     if (ann != null) {
/* 506 */       Class deserClass = ann.using();
/* 507 */       if (deserClass != JsonDeserializer.None.class) {
/* 508 */         return deserClass;
/*     */       }
/*     */     }
/*     */ 
/* 512 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<? extends KeyDeserializer> findKeyDeserializer(Annotated a)
/*     */   {
/* 518 */     JsonDeserialize ann = (JsonDeserialize)a.getAnnotation(JsonDeserialize.class);
/* 519 */     if (ann != null) {
/* 520 */       Class deserClass = ann.keyUsing();
/* 521 */       if (deserClass != KeyDeserializer.None.class) {
/* 522 */         return deserClass;
/*     */       }
/*     */     }
/* 525 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<? extends JsonDeserializer<?>> findContentDeserializer(Annotated a)
/*     */   {
/* 531 */     JsonDeserialize ann = (JsonDeserialize)a.getAnnotation(JsonDeserialize.class);
/* 532 */     if (ann != null) {
/* 533 */       Class deserClass = ann.contentUsing();
/* 534 */       if (deserClass != JsonDeserializer.None.class) {
/* 535 */         return deserClass;
/*     */       }
/*     */     }
/* 538 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findDeserializationType(Annotated am, JavaType baseType, String propName)
/*     */   {
/* 546 */     JsonDeserialize ann = (JsonDeserialize)am.getAnnotation(JsonDeserialize.class);
/* 547 */     if (ann != null) {
/* 548 */       Class cls = ann.as();
/* 549 */       if (cls != NoClass.class) {
/* 550 */         return cls;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 556 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findDeserializationKeyType(Annotated am, JavaType baseKeyType, String propName)
/*     */   {
/* 564 */     JsonDeserialize ann = (JsonDeserialize)am.getAnnotation(JsonDeserialize.class);
/* 565 */     if (ann != null) {
/* 566 */       Class cls = ann.keyAs();
/* 567 */       if (cls != NoClass.class) {
/* 568 */         return cls;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 574 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findDeserializationContentType(Annotated am, JavaType baseContentType, String propName)
/*     */   {
/* 582 */     JsonDeserialize ann = (JsonDeserialize)am.getAnnotation(JsonDeserialize.class);
/* 583 */     if (ann != null) {
/* 584 */       Class cls = ann.contentAs();
/* 585 */       if (cls != NoClass.class) {
/* 586 */         return cls;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 592 */     return null;
/*     */   }
/*     */ 
/*     */   public Object findValueInstantiator(AnnotatedClass ac)
/*     */   {
/* 604 */     JsonValueInstantiator ann = (JsonValueInstantiator)ac.getAnnotation(JsonValueInstantiator.class);
/*     */ 
/* 606 */     return ann == null ? null : ann.value();
/*     */   }
/*     */ 
/*     */   public String findSettablePropertyName(AnnotatedMethod am)
/*     */   {
/* 624 */     JsonProperty pann = (JsonProperty)am.getAnnotation(JsonProperty.class);
/* 625 */     if (pann != null) {
/* 626 */       return pann.value();
/*     */     }
/* 628 */     JsonSetter ann = (JsonSetter)am.getAnnotation(JsonSetter.class);
/* 629 */     if (ann != null) {
/* 630 */       return ann.value();
/*     */     }
/*     */ 
/* 636 */     if ((am.hasAnnotation(JsonDeserialize.class)) || (am.hasAnnotation(JsonView.class))) {
/* 637 */       return "";
/*     */     }
/* 639 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean hasAnySetterAnnotation(AnnotatedMethod am)
/*     */   {
/* 649 */     return am.hasAnnotation(JsonAnySetter.class);
/*     */   }
/*     */ 
/*     */   public boolean hasAnyGetterAnnotation(AnnotatedMethod am)
/*     */   {
/* 658 */     return am.hasAnnotation(JsonAnyGetter.class);
/*     */   }
/*     */ 
/*     */   public boolean hasCreatorAnnotation(Annotated a)
/*     */   {
/* 668 */     return a.hasAnnotation(JsonCreator.class);
/*     */   }
/*     */ 
/*     */   public String findDeserializablePropertyName(AnnotatedField af)
/*     */   {
/* 680 */     JsonProperty pann = (JsonProperty)af.getAnnotation(JsonProperty.class);
/* 681 */     if (pann != null) {
/* 682 */       return pann.value();
/*     */     }
/*     */ 
/* 686 */     if ((af.hasAnnotation(JsonDeserialize.class)) || (af.hasAnnotation(JsonView.class))) {
/* 687 */       return "";
/*     */     }
/* 689 */     return null;
/*     */   }
/*     */ 
/*     */   public String findPropertyNameForParam(AnnotatedParameter param)
/*     */   {
/* 701 */     if (param != null) {
/* 702 */       JsonProperty pann = (JsonProperty)param.getAnnotation(JsonProperty.class);
/* 703 */       if (pann != null) {
/* 704 */         return pann.value();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 711 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean _isIgnorable(Annotated a)
/*     */   {
/* 722 */     JsonIgnore ann = (JsonIgnore)a.getAnnotation(JsonIgnore.class);
/* 723 */     return (ann != null) && (ann.value());
/*     */   }
/*     */ 
/*     */   protected TypeResolverBuilder<?> _findTypeResolver(MapperConfig<?> config, Annotated ann, JavaType baseType)
/*     */   {
/* 735 */     JsonTypeInfo info = (JsonTypeInfo)ann.getAnnotation(JsonTypeInfo.class);
/* 736 */     JsonTypeResolver resAnn = (JsonTypeResolver)ann.getAnnotation(JsonTypeResolver.class);
/*     */     TypeResolverBuilder b;
/* 737 */     if (resAnn != null)
/*     */     {
/* 741 */       if (info == null) {
/* 742 */         return null;
/*     */       }
/*     */ 
/* 748 */       b = config.typeResolverBuilderInstance(ann, resAnn.value());
/*     */     } else {
/* 750 */       if ((info == null) || (info.use() == JsonTypeInfo.Id.NONE)) {
/* 751 */         return null;
/*     */       }
/* 753 */       b = _constructStdTypeResolverBuilder();
/*     */     }
/*     */ 
/* 756 */     JsonTypeIdResolver idResInfo = (JsonTypeIdResolver)ann.getAnnotation(JsonTypeIdResolver.class);
/* 757 */     TypeIdResolver idRes = idResInfo == null ? null : config.typeIdResolverInstance(ann, idResInfo.value());
/*     */ 
/* 759 */     if (idRes != null) {
/* 760 */       idRes.init(baseType);
/*     */     }
/* 762 */     TypeResolverBuilder b = b.init(info.use(), idRes);
/*     */ 
/* 767 */     JsonTypeInfo.As inclusion = info.include();
/* 768 */     if ((inclusion == JsonTypeInfo.As.EXTERNAL_PROPERTY) && ((ann instanceof AnnotatedClass))) {
/* 769 */       inclusion = JsonTypeInfo.As.PROPERTY;
/*     */     }
/* 771 */     b = b.inclusion(inclusion);
/* 772 */     b = b.typeProperty(info.property());
/* 773 */     Class defaultImpl = info.defaultImpl();
/* 774 */     if (defaultImpl != JsonTypeInfo.None.class) {
/* 775 */       b = b.defaultImpl(defaultImpl);
/*     */     }
/* 777 */     return b;
/*     */   }
/*     */ 
/*     */   protected StdTypeResolverBuilder _constructStdTypeResolverBuilder()
/*     */   {
/* 788 */     return new StdTypeResolverBuilder();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.JacksonAnnotationIntrospector
 * JD-Core Version:    0.6.2
 */