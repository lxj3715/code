/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.KeyDeserializer;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Typing;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class NopAnnotationIntrospector extends AnnotationIntrospector
/*     */ {
/*  24 */   public static final NopAnnotationIntrospector instance = new NopAnnotationIntrospector();
/*     */ 
/*     */   public boolean isHandled(Annotation ann)
/*     */   {
/*  34 */     return false;
/*     */   }
/*     */ 
/*     */   public String findEnumValue(Enum<?> value)
/*     */   {
/*  45 */     return null;
/*     */   }
/*     */ 
/*     */   public String findRootName(AnnotatedClass ac)
/*     */   {
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */   public String[] findPropertiesToIgnore(AnnotatedClass ac)
/*     */   {
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */   public Boolean findIgnoreUnknownProperties(AnnotatedClass ac)
/*     */   {
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean hasIgnoreMarker(AnnotatedMember member)
/*     */   {
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isIgnorableConstructor(AnnotatedConstructor c)
/*     */   {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isIgnorableMethod(AnnotatedMethod m)
/*     */   {
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isIgnorableField(AnnotatedField f)
/*     */   {
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   public Object findSerializer(Annotated am)
/*     */   {
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findSerializationType(Annotated a)
/*     */   {
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   public JsonSerialize.Typing findSerializationTyping(Annotated a)
/*     */   {
/* 125 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?>[] findSerializationViews(Annotated a)
/*     */   {
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */   public String[] findSerializationPropertyOrder(AnnotatedClass ac)
/*     */   {
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */   public Boolean findSerializationSortAlphabetically(AnnotatedClass ac)
/*     */   {
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */   public String findGettablePropertyName(AnnotatedMethod am)
/*     */   {
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean hasAsValueAnnotation(AnnotatedMethod am)
/*     */   {
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */   public String findDeserializablePropertyName(AnnotatedField af)
/*     */   {
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findDeserializationContentType(Annotated am, JavaType t, String propName)
/*     */   {
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findDeserializationKeyType(Annotated am, JavaType t, String propName)
/*     */   {
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> findDeserializationType(Annotated am, JavaType t, String propName)
/*     */   {
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */   public Object findDeserializer(Annotated am) {
/* 186 */     return null;
/*     */   }
/*     */   public Class<KeyDeserializer> findKeyDeserializer(Annotated am) {
/* 189 */     return null;
/*     */   }
/*     */   public Class<JsonDeserializer<?>> findContentDeserializer(Annotated am) {
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */   public String findPropertyNameForParam(AnnotatedParameter param)
/*     */   {
/* 197 */     return null;
/*     */   }
/*     */ 
/*     */   public String findSerializablePropertyName(AnnotatedField af)
/*     */   {
/* 202 */     return null;
/*     */   }
/*     */ 
/*     */   public String findSettablePropertyName(AnnotatedMethod am)
/*     */   {
/* 207 */     return null;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.NopAnnotationIntrospector
 * JD-Core Version:    0.6.2
 */