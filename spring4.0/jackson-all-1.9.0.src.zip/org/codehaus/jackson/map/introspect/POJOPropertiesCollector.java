/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.BeanPropertyDefinition;
/*     */ import org.codehaus.jackson.map.MapperConfig;
/*     */ import org.codehaus.jackson.map.PropertyNamingStrategy;
/*     */ import org.codehaus.jackson.map.util.BeanUtil;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class POJOPropertiesCollector
/*     */ {
/*     */   protected final MapperConfig<?> _config;
/*     */   protected final boolean _forSerialization;
/*     */   protected final JavaType _type;
/*     */   protected final AnnotatedClass _classDef;
/*     */   protected final VisibilityChecker<?> _visibilityChecker;
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*  64 */   protected final LinkedHashMap<String, POJOPropertyBuilder> _properties = new LinkedHashMap();
/*     */ 
/*  67 */   protected LinkedList<POJOPropertyBuilder> _creatorProperties = null;
/*     */ 
/*  69 */   protected LinkedList<AnnotatedMethod> _anyGetters = null;
/*     */ 
/*  71 */   protected LinkedList<AnnotatedMethod> _anySetters = null;
/*     */ 
/*  76 */   protected LinkedList<AnnotatedMethod> _jsonValueGetters = null;
/*     */   protected HashSet<String> _ignoredPropertyNames;
/*     */   protected LinkedHashMap<Object, AnnotatedMember> _injectables;
/*     */ 
/*     */   protected POJOPropertiesCollector(MapperConfig<?> config, boolean forSerialization, JavaType type, AnnotatedClass classDef)
/*     */   {
/* 101 */     this._config = config;
/* 102 */     this._forSerialization = forSerialization;
/* 103 */     this._type = type;
/* 104 */     this._classDef = classDef;
/* 105 */     this._annotationIntrospector = (config.isAnnotationProcessingEnabled() ? this._config.getAnnotationIntrospector() : null);
/*     */ 
/* 107 */     if (this._annotationIntrospector == null)
/* 108 */       this._visibilityChecker = this._config.getDefaultVisibilityChecker();
/*     */     else
/* 110 */       this._visibilityChecker = this._annotationIntrospector.findAutoDetectVisibility(classDef, this._config.getDefaultVisibilityChecker());
/*     */   }
/*     */ 
/*     */   public MapperConfig<?> getConfig()
/*     */   {
/* 122 */     return this._config;
/*     */   }
/*     */ 
/*     */   public JavaType getType() {
/* 126 */     return this._type;
/*     */   }
/*     */ 
/*     */   public AnnotatedClass getClassDef() {
/* 130 */     return this._classDef;
/*     */   }
/*     */ 
/*     */   public AnnotationIntrospector getAnnotationIntrospector() {
/* 134 */     return this._annotationIntrospector;
/*     */   }
/*     */ 
/*     */   public List<BeanPropertyDefinition> getProperties()
/*     */   {
/* 139 */     return new ArrayList(this._properties.values());
/*     */   }
/*     */ 
/*     */   public Map<Object, AnnotatedMember> getInjectables() {
/* 143 */     return this._injectables;
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod getJsonValueMethod()
/*     */   {
/* 149 */     if (this._jsonValueGetters != null) {
/* 150 */       if (this._jsonValueGetters.size() > 1) {
/* 151 */         reportProblem("Multiple value properties defined (" + this._jsonValueGetters.get(0) + " vs " + this._jsonValueGetters.get(1) + ")");
/*     */       }
/*     */ 
/* 155 */       return (AnnotatedMethod)this._jsonValueGetters.get(0);
/*     */     }
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod getAnyGetterMethod()
/*     */   {
/* 162 */     if (this._anyGetters != null) {
/* 163 */       if (this._anyGetters.size() > 1) {
/* 164 */         reportProblem("Multiple 'any-getters' defined (" + this._anyGetters.get(0) + " vs " + this._anyGetters.get(1) + ")");
/*     */       }
/*     */ 
/* 167 */       return (AnnotatedMethod)this._anyGetters.getFirst();
/*     */     }
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod getAnySetterMethod()
/*     */   {
/* 174 */     if (this._anySetters != null) {
/* 175 */       if (this._anySetters.size() > 1) {
/* 176 */         reportProblem("Multiple 'any-setters' defined (" + this._anySetters.get(0) + " vs " + this._anySetters.get(1) + ")");
/*     */       }
/*     */ 
/* 179 */       return (AnnotatedMethod)this._anySetters.getFirst();
/*     */     }
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   public Set<String> getIgnoredPropertyNames() {
/* 185 */     return this._ignoredPropertyNames;
/*     */   }
/*     */ 
/*     */   protected Map<String, POJOPropertyBuilder> getPropertyMap()
/*     */   {
/* 190 */     return this._properties;
/*     */   }
/*     */ 
/*     */   public POJOPropertiesCollector collect()
/*     */   {
/* 205 */     this._properties.clear();
/*     */ 
/* 208 */     _addFields();
/* 209 */     _addMethods();
/* 210 */     _addCreators();
/* 211 */     _addInjectables();
/*     */ 
/* 214 */     _removeUnwantedProperties();
/*     */ 
/* 217 */     _renameProperties();
/*     */ 
/* 219 */     PropertyNamingStrategy naming = this._config.getPropertyNamingStrategy();
/* 220 */     if (naming != null) {
/* 221 */       _renameUsing(naming);
/*     */     }
/*     */ 
/* 228 */     for (POJOPropertyBuilder property : this._properties.values()) {
/* 229 */       property.trimByVisibility();
/*     */     }
/*     */ 
/* 233 */     for (POJOPropertyBuilder property : this._properties.values()) {
/* 234 */       property.mergeAnnotations(this._forSerialization);
/*     */     }
/*     */ 
/* 238 */     _sortProperties();
/* 239 */     return this;
/*     */   }
/*     */ 
/*     */   protected void _sortProperties()
/*     */   {
/* 254 */     AnnotationIntrospector intr = this._config.getAnnotationIntrospector();
/*     */ 
/* 256 */     Boolean alpha = intr.findSerializationSortAlphabetically(this._classDef);
/*     */     boolean sort;
/*     */     boolean sort;
/* 258 */     if (alpha == null)
/* 259 */       sort = this._config.shouldSortPropertiesAlphabetically();
/*     */     else {
/* 261 */       sort = alpha.booleanValue();
/*     */     }
/* 263 */     String[] propertyOrder = intr.findSerializationPropertyOrder(this._classDef);
/*     */ 
/* 266 */     if ((!sort) && (this._creatorProperties == null) && (propertyOrder == null)) {
/* 267 */       return;
/*     */     }
/* 269 */     int size = this._properties.size();
/*     */     Map all;
/*     */     Map all;
/* 272 */     if (sort)
/* 273 */       all = new TreeMap();
/*     */     else {
/* 275 */       all = new LinkedHashMap(size + size);
/*     */     }
/*     */ 
/* 278 */     for (POJOPropertyBuilder prop : this._properties.values()) {
/* 279 */       all.put(prop.getName(), prop);
/*     */     }
/* 281 */     Map ordered = new LinkedHashMap(size + size);
/*     */ 
/* 283 */     if (propertyOrder != null) {
/* 284 */       for (String name : propertyOrder) {
/* 285 */         POJOPropertyBuilder w = (POJOPropertyBuilder)all.get(name);
/* 286 */         if (w == null) {
/* 287 */           for (POJOPropertyBuilder prop : this._properties.values()) {
/* 288 */             if (name.equals(prop.getInternalName())) {
/* 289 */               w = prop;
/*     */ 
/* 291 */               name = prop.getName();
/* 292 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 296 */         if (w != null) {
/* 297 */           ordered.put(name, w);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 302 */     if (this._creatorProperties != null) {
/* 303 */       for (POJOPropertyBuilder prop : this._creatorProperties) {
/* 304 */         ordered.put(prop.getName(), prop);
/*     */       }
/*     */     }
/*     */ 
/* 308 */     ordered.putAll(all);
/*     */ 
/* 310 */     this._properties.clear();
/* 311 */     this._properties.putAll(ordered);
/*     */   }
/*     */ 
/*     */   protected void _addFields()
/*     */   {
/* 325 */     AnnotationIntrospector ai = this._annotationIntrospector;
/*     */ 
/* 327 */     for (AnnotatedField f : this._classDef.fields()) {
/* 328 */       String implName = f.getName();
/*     */       String explName;
/*     */       String explName;
/* 331 */       if (ai == null) {
/* 332 */         explName = null;
/*     */       }
/*     */       else
/*     */       {
/*     */         String explName;
/* 333 */         if (this._forSerialization)
/*     */         {
/* 339 */           explName = ai.findSerializablePropertyName(f);
/*     */         }
/* 341 */         else explName = ai.findDeserializablePropertyName(f);
/*     */       }
/* 343 */       if ("".equals(explName)) {
/* 344 */         explName = implName;
/*     */       }
/*     */ 
/* 347 */       boolean visible = explName != null;
/* 348 */       if (!visible) {
/* 349 */         visible = this._visibilityChecker.isFieldVisible(f);
/*     */       }
/*     */ 
/* 352 */       boolean ignored = (ai != null) && (ai.hasIgnoreMarker(f));
/* 353 */       _property(implName).addField(f, explName, visible, ignored);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _addCreators()
/*     */   {
/* 362 */     AnnotationIntrospector ai = this._annotationIntrospector;
/*     */ 
/* 364 */     if (ai == null) {
/* 365 */       return;
/*     */     }
/* 367 */     for (AnnotatedConstructor ctor : this._classDef.getConstructors()) {
/* 368 */       if (this._creatorProperties == null) {
/* 369 */         this._creatorProperties = new LinkedList();
/*     */       }
/* 371 */       int i = 0; for (int len = ctor.getParameterCount(); i < len; i++) {
/* 372 */         AnnotatedParameter param = ctor.getParameter(i);
/* 373 */         String name = ai.findPropertyNameForParam(param);
/*     */ 
/* 375 */         if (name != null)
/*     */         {
/* 377 */           POJOPropertyBuilder prop = _property(name);
/* 378 */           prop.addCtor(param, name, true, false);
/* 379 */           this._creatorProperties.add(prop);
/*     */         }
/*     */       }
/*     */     }
/* 383 */     for (AnnotatedMethod factory : this._classDef.getStaticMethods()) {
/* 384 */       if (this._creatorProperties == null) {
/* 385 */         this._creatorProperties = new LinkedList();
/*     */       }
/* 387 */       int i = 0; for (int len = factory.getParameterCount(); i < len; i++) {
/* 388 */         AnnotatedParameter param = factory.getParameter(i);
/* 389 */         String name = ai.findPropertyNameForParam(param);
/*     */ 
/* 391 */         if (name != null)
/*     */         {
/* 393 */           POJOPropertyBuilder prop = _property(name);
/* 394 */           prop.addCtor(param, name, true, false);
/* 395 */           this._creatorProperties.add(prop);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _addMethods()
/*     */   {
/* 406 */     AnnotationIntrospector ai = this._annotationIntrospector;
/*     */ 
/* 408 */     for (AnnotatedMethod m : this._classDef.memberMethods())
/*     */     {
/* 417 */       int argCount = m.getParameterCount();
/*     */ 
/* 420 */       if (argCount == 0)
/*     */       {
/* 422 */         if (ai != null) {
/* 423 */           if (ai.hasAnyGetterAnnotation(m)) {
/* 424 */             if (this._anyGetters == null) {
/* 425 */               this._anyGetters = new LinkedList();
/*     */             }
/* 427 */             this._anyGetters.add(m);
/*     */           }
/* 431 */           else if (ai.hasAsValueAnnotation(m)) {
/* 432 */             if (this._jsonValueGetters == null) {
/* 433 */               this._jsonValueGetters = new LinkedList();
/*     */             }
/* 435 */             this._jsonValueGetters.add(m);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 440 */           String explName = ai == null ? null : ai.findGettablePropertyName(m);
/* 441 */           if (explName == null) {
/* 442 */             String implName = BeanUtil.okNameForRegularGetter(m, m.getName());
/* 443 */             if (implName == null) {
/* 444 */               implName = BeanUtil.okNameForIsGetter(m, m.getName());
/* 445 */               if (implName != null)
/*     */               {
/* 448 */                 boolean visible = this._visibilityChecker.isIsGetterVisible(m);
/*     */               }
/*     */             } else { boolean visible = this._visibilityChecker.isGetterVisible(m); }
/*     */           }
/*     */           else
/*     */           {
/* 454 */             String implName = BeanUtil.okNameForGetter(m);
/*     */ 
/* 456 */             if (implName == null) {
/* 457 */               implName = m.getName();
/*     */             }
/* 459 */             if (explName.length() == 0) {
/* 460 */               explName = implName;
/*     */             }
/* 462 */             boolean visible = true;
/*     */ 
/* 464 */             boolean ignore = ai == null ? false : ai.hasIgnoreMarker(m);
/* 465 */             _property(implName).addGetter(m, explName, visible, ignore); } 
/*     */         } } else if (argCount == 1) {
/* 467 */         String explName = ai == null ? null : ai.findSettablePropertyName(m);
/* 468 */         if (explName == null) {
/* 469 */           String implName = BeanUtil.okNameForSetter(m);
/* 470 */           if (implName != null)
/*     */           {
/* 473 */             boolean visible = this._visibilityChecker.isSetterVisible(m);
/*     */           }
/*     */         } else {
/* 476 */           String implName = BeanUtil.okNameForSetter(m);
/*     */ 
/* 478 */           if (implName == null) {
/* 479 */             implName = m.getName();
/*     */           }
/* 481 */           if (explName.length() == 0) {
/* 482 */             explName = implName;
/*     */           }
/* 484 */           boolean visible = true;
/*     */ 
/* 486 */           boolean ignore = ai == null ? false : ai.hasIgnoreMarker(m);
/* 487 */           _property(implName).addSetter(m, explName, visible, ignore);
/*     */         }
/* 489 */       } else if ((argCount == 2) && 
/* 490 */         (ai != null) && (ai.hasAnySetterAnnotation(m))) {
/* 491 */         if (this._anySetters == null) {
/* 492 */           this._anySetters = new LinkedList();
/*     */         }
/* 494 */         this._anySetters.add(m);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _addInjectables()
/*     */   {
/* 502 */     AnnotationIntrospector ai = this._annotationIntrospector;
/* 503 */     if (ai == null) {
/* 504 */       return;
/*     */     }
/*     */ 
/* 508 */     for (AnnotatedField f : this._classDef.fields()) {
/* 509 */       _doAddInjectable(ai.findInjectableValueId(f), f);
/*     */     }
/*     */ 
/* 512 */     for (AnnotatedMethod m : this._classDef.memberMethods())
/*     */     {
/* 516 */       if (m.getParameterCount() == 1)
/*     */       {
/* 519 */         _doAddInjectable(ai.findInjectableValueId(m), m);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _doAddInjectable(Object id, AnnotatedMember m) {
/* 525 */     if (id == null) {
/* 526 */       return;
/*     */     }
/* 528 */     if (this._injectables == null) {
/* 529 */       this._injectables = new LinkedHashMap();
/*     */     }
/* 531 */     AnnotatedMember prev = (AnnotatedMember)this._injectables.put(id, m);
/* 532 */     if (prev != null) {
/* 533 */       String type = id == null ? "[null]" : id.getClass().getName();
/* 534 */       throw new IllegalArgumentException("Duplicate injectable value with id '" + String.valueOf(id) + "' (of type " + type + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _removeUnwantedProperties()
/*     */   {
/* 551 */     Iterator it = this._properties.entrySet().iterator();
/* 552 */     while (it.hasNext()) {
/* 553 */       Map.Entry entry = (Map.Entry)it.next();
/* 554 */       POJOPropertyBuilder prop = (POJOPropertyBuilder)entry.getValue();
/*     */ 
/* 557 */       if (!prop.anyVisible()) {
/* 558 */         it.remove();
/*     */       }
/* 562 */       else if (prop.anyIgnorals())
/*     */       {
/* 564 */         if (!prop.anyExplicitNames()) {
/* 565 */           it.remove();
/* 566 */           _addIgnored(prop.getName());
/*     */         }
/*     */         else
/*     */         {
/* 570 */           prop.removeIgnored();
/* 571 */           if ((!this._forSerialization) && (!prop.couldDeserialize()))
/* 572 */             _addIgnored(prop.getName());
/*     */         }
/*     */       }
/*     */       else
/* 576 */         prop.removeNonVisible();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void _addIgnored(String name)
/*     */   {
/* 582 */     if (!this._forSerialization) {
/* 583 */       if (this._ignoredPropertyNames == null) {
/* 584 */         this._ignoredPropertyNames = new HashSet();
/*     */       }
/* 586 */       this._ignoredPropertyNames.add(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _renameProperties()
/*     */   {
/* 599 */     Iterator it = this._properties.entrySet().iterator();
/* 600 */     LinkedList renamed = null;
/* 601 */     while (it.hasNext()) {
/* 602 */       Map.Entry entry = (Map.Entry)it.next();
/* 603 */       POJOPropertyBuilder prop = (POJOPropertyBuilder)entry.getValue();
/* 604 */       String newName = prop.findNewName();
/* 605 */       if (newName != null) {
/* 606 */         if (renamed == null) {
/* 607 */           renamed = new LinkedList();
/*     */         }
/* 609 */         prop = prop.withName(newName);
/* 610 */         renamed.add(prop);
/* 611 */         it.remove();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 616 */     if (renamed != null)
/* 617 */       for (POJOPropertyBuilder prop : renamed) {
/* 618 */         String name = prop.getName();
/* 619 */         POJOPropertyBuilder old = (POJOPropertyBuilder)this._properties.get(name);
/* 620 */         if (old == null)
/* 621 */           this._properties.put(name, prop);
/*     */         else
/* 623 */           old.addAll(prop);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void _renameUsing(PropertyNamingStrategy naming)
/*     */   {
/* 631 */     POJOPropertyBuilder[] props = (POJOPropertyBuilder[])this._properties.values().toArray(new POJOPropertyBuilder[this._properties.size()]);
/* 632 */     this._properties.clear();
/* 633 */     for (POJOPropertyBuilder prop : props) {
/* 634 */       String name = prop.getName();
/* 635 */       if (this._forSerialization) {
/* 636 */         if (prop.hasGetter())
/* 637 */           name = naming.nameForGetterMethod(this._config, prop.getGetter(), name);
/* 638 */         else if (prop.hasField()) {
/* 639 */           name = naming.nameForField(this._config, prop.getField(), name);
/*     */         }
/*     */       }
/* 642 */       else if (prop.hasSetter())
/* 643 */         name = naming.nameForSetterMethod(this._config, prop.getSetter(), name);
/* 644 */       else if (prop.hasConstructorParameter())
/* 645 */         name = naming.nameForConstructorParameter(this._config, prop.getConstructorParameter(), name);
/* 646 */       else if (prop.hasField())
/* 647 */         name = naming.nameForField(this._config, prop.getField(), name);
/* 648 */       else if (prop.hasGetter())
/*     */       {
/* 652 */         name = naming.nameForGetterMethod(this._config, prop.getGetter(), name);
/*     */       }
/*     */ 
/* 655 */       if (!name.equals(prop.getName())) {
/* 656 */         prop = prop.withName(name);
/*     */       }
/* 658 */       this._properties.put(name, prop);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void reportProblem(String msg)
/*     */   {
/* 669 */     throw new IllegalArgumentException("Problem with definition of " + this._classDef + ": " + msg);
/*     */   }
/*     */ 
/*     */   protected POJOPropertyBuilder _property(String implName)
/*     */   {
/* 674 */     POJOPropertyBuilder prop = (POJOPropertyBuilder)this._properties.get(implName);
/* 675 */     if (prop == null) {
/* 676 */       prop = new POJOPropertyBuilder(implName);
/* 677 */       this._properties.put(implName, prop);
/*     */     }
/* 679 */     return prop;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.POJOPropertiesCollector
 * JD-Core Version:    0.6.2
 */