/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import org.codehaus.jackson.map.BeanPropertyDefinition;
/*     */ 
/*     */ public class POJOPropertyBuilder extends BeanPropertyDefinition
/*     */   implements Comparable<POJOPropertyBuilder>
/*     */ {
/*     */   protected final String _name;
/*     */   protected final String _internalName;
/*     */   protected Node<AnnotatedField> _fields;
/*     */   protected Node<AnnotatedParameter> _ctorParameters;
/*     */   protected Node<AnnotatedMethod> _getters;
/*     */   protected Node<AnnotatedMethod> _setters;
/*     */ 
/*     */   public POJOPropertyBuilder(String internalName)
/*     */   {
/*  38 */     this._internalName = internalName;
/*  39 */     this._name = internalName;
/*     */   }
/*     */ 
/*     */   public POJOPropertyBuilder(POJOPropertyBuilder src, String newName)
/*     */   {
/*  44 */     this._internalName = src._internalName;
/*  45 */     this._name = newName;
/*  46 */     this._fields = src._fields;
/*  47 */     this._ctorParameters = src._ctorParameters;
/*  48 */     this._getters = src._getters;
/*  49 */     this._setters = src._setters;
/*     */   }
/*     */ 
/*     */   public POJOPropertyBuilder withName(String newName)
/*     */   {
/*  56 */     return new POJOPropertyBuilder(this, newName);
/*     */   }
/*     */ 
/*     */   public int compareTo(POJOPropertyBuilder other)
/*     */   {
/*  71 */     if (this._ctorParameters != null) {
/*  72 */       if (other._ctorParameters == null)
/*  73 */         return -1;
/*     */     }
/*  75 */     else if (other._ctorParameters != null) {
/*  76 */       return 1;
/*     */     }
/*     */ 
/*  81 */     return getName().compareTo(other.getName());
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  91 */     return this._name;
/*     */   }
/*     */   public String getInternalName() {
/*  94 */     return this._internalName;
/*     */   }
/*     */   public boolean hasGetter() {
/*  97 */     return this._getters != null;
/*     */   }
/*     */   public boolean hasSetter() {
/* 100 */     return this._setters != null;
/*     */   }
/*     */   public boolean hasField() {
/* 103 */     return this._fields != null;
/*     */   }
/*     */   public boolean hasConstructorParameter() {
/* 106 */     return this._ctorParameters != null;
/*     */   }
/*     */ 
/*     */   public AnnotatedMember getAccessor()
/*     */   {
/* 111 */     if (this._getters != null) {
/* 112 */       return (AnnotatedMember)this._getters.value;
/*     */     }
/* 114 */     if (this._fields != null) {
/* 115 */       return (AnnotatedMember)this._fields.value;
/*     */     }
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */   public AnnotatedMember getMutator()
/*     */   {
/* 123 */     if (this._ctorParameters != null) {
/* 124 */       return (AnnotatedMember)this._ctorParameters.value;
/*     */     }
/* 126 */     if (this._setters != null) {
/* 127 */       return (AnnotatedMember)this._setters.value;
/*     */     }
/* 129 */     if (this._fields != null) {
/* 130 */       return (AnnotatedMember)this._fields.value;
/*     */     }
/* 132 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean couldSerialize()
/*     */   {
/* 137 */     return (this._getters != null) || (this._fields != null);
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod getGetter()
/*     */   {
/* 143 */     if (this._getters == null) {
/* 144 */       return null;
/*     */     }
/*     */ 
/* 147 */     AnnotatedMethod getter = (AnnotatedMethod)this._getters.value;
/* 148 */     for (Node next = this._getters.next; 
/* 149 */       next != null; next = next.next)
/*     */     {
/* 154 */       AnnotatedMethod nextGetter = (AnnotatedMethod)next.value;
/* 155 */       Class getterClass = getter.getDeclaringClass();
/* 156 */       Class nextClass = nextGetter.getDeclaringClass();
/* 157 */       if (getterClass != nextClass) {
/* 158 */         if (getterClass.isAssignableFrom(nextClass)) {
/* 159 */           getter = nextGetter;
/*     */         }
/* 162 */         else if (nextClass.isAssignableFrom(getterClass));
/*     */       }
/*     */       else
/*     */       {
/* 166 */         throw new IllegalArgumentException("Conflicting getter definitions for property \"" + getName() + "\": " + getter.getFullName() + " vs " + nextGetter.getFullName());
/*     */       }
/*     */     }
/* 169 */     return getter;
/*     */   }
/*     */ 
/*     */   public AnnotatedMethod getSetter()
/*     */   {
/* 175 */     if (this._setters == null) {
/* 176 */       return null;
/*     */     }
/*     */ 
/* 179 */     AnnotatedMethod setter = (AnnotatedMethod)this._setters.value;
/* 180 */     for (Node next = this._setters.next; 
/* 181 */       next != null; next = next.next)
/*     */     {
/* 186 */       AnnotatedMethod nextSetter = (AnnotatedMethod)next.value;
/* 187 */       Class setterClass = setter.getDeclaringClass();
/* 188 */       Class nextClass = nextSetter.getDeclaringClass();
/* 189 */       if (setterClass != nextClass) {
/* 190 */         if (setterClass.isAssignableFrom(nextClass)) {
/* 191 */           setter = nextSetter;
/*     */         }
/* 194 */         else if (nextClass.isAssignableFrom(setterClass));
/*     */       }
/*     */       else
/*     */       {
/* 198 */         throw new IllegalArgumentException("Conflicting setter definitions for property \"" + getName() + "\": " + setter.getFullName() + " vs " + nextSetter.getFullName());
/*     */       }
/*     */     }
/* 201 */     return setter;
/*     */   }
/*     */ 
/*     */   public AnnotatedField getField()
/*     */   {
/* 207 */     if (this._fields == null) {
/* 208 */       return null;
/*     */     }
/*     */ 
/* 211 */     AnnotatedField field = (AnnotatedField)this._fields.value;
/* 212 */     for (Node next = this._fields.next; 
/* 213 */       next != null; next = next.next) {
/* 214 */       AnnotatedField nextField = (AnnotatedField)next.value;
/* 215 */       Class fieldClass = field.getDeclaringClass();
/* 216 */       Class nextClass = nextField.getDeclaringClass();
/* 217 */       if (fieldClass != nextClass) {
/* 218 */         if (fieldClass.isAssignableFrom(nextClass)) {
/* 219 */           field = nextField;
/*     */         }
/* 222 */         else if (nextClass.isAssignableFrom(fieldClass));
/*     */       }
/*     */       else
/*     */       {
/* 226 */         throw new IllegalArgumentException("Multiple fields representing property \"" + getName() + "\": " + field.getFullName() + " vs " + nextField.getFullName());
/*     */       }
/*     */     }
/* 229 */     return field;
/*     */   }
/*     */ 
/*     */   public AnnotatedParameter getConstructorParameter()
/*     */   {
/* 235 */     if (this._ctorParameters == null) {
/* 236 */       return null;
/*     */     }
/*     */ 
/* 239 */     AnnotatedParameter ctorParam = (AnnotatedParameter)this._ctorParameters.value;
/* 240 */     for (Node next = this._ctorParameters.next; 
/* 241 */       next != null; next = next.next)
/*     */     {
/* 246 */       AnnotatedParameter nextCtorParam = (AnnotatedParameter)next.value;
/* 247 */       Class ctorParamClass = ctorParam.getDeclaringClass();
/* 248 */       Class nextClass = nextCtorParam.getDeclaringClass();
/* 249 */       if (ctorParamClass != nextClass) {
/* 250 */         if (ctorParamClass.isAssignableFrom(nextClass)) {
/* 251 */           ctorParam = nextCtorParam;
/*     */         }
/* 254 */         else if (nextClass.isAssignableFrom(ctorParamClass));
/*     */       }
/*     */       else
/*     */       {
/* 258 */         throw new IllegalArgumentException("Conflicting constructor-parameter definitions for property \"" + getName() + "\": " + ctorParam + " vs " + nextCtorParam);
/*     */       }
/*     */     }
/* 261 */     return ctorParam;
/*     */   }
/*     */ 
/*     */   public void addField(AnnotatedField a, String ename, boolean visible, boolean ignored)
/*     */   {
/* 271 */     this._fields = new Node(a, this._fields, ename, visible, ignored);
/*     */   }
/*     */ 
/*     */   public void addCtor(AnnotatedParameter a, String ename, boolean visible, boolean ignored) {
/* 275 */     this._ctorParameters = new Node(a, this._ctorParameters, ename, visible, ignored);
/*     */   }
/*     */ 
/*     */   public void addGetter(AnnotatedMethod a, String ename, boolean visible, boolean ignored) {
/* 279 */     this._getters = new Node(a, this._getters, ename, visible, ignored);
/*     */   }
/*     */ 
/*     */   public void addSetter(AnnotatedMethod a, String ename, boolean visible, boolean ignored) {
/* 283 */     this._setters = new Node(a, this._setters, ename, visible, ignored);
/*     */   }
/*     */ 
/*     */   public void addAll(POJOPropertyBuilder src)
/*     */   {
/* 292 */     this._fields = merge(this._fields, src._fields);
/* 293 */     this._ctorParameters = merge(this._ctorParameters, src._ctorParameters);
/* 294 */     this._getters = merge(this._getters, src._getters);
/* 295 */     this._setters = merge(this._setters, src._setters);
/*     */   }
/*     */ 
/*     */   private static <T> Node<T> merge(Node<T> chain1, Node<T> chain2)
/*     */   {
/* 300 */     if (chain1 == null) {
/* 301 */       return chain2;
/*     */     }
/* 303 */     if (chain2 == null) {
/* 304 */       return chain1;
/*     */     }
/* 306 */     return chain1.append(chain2);
/*     */   }
/*     */ 
/*     */   public void removeIgnored()
/*     */   {
/* 321 */     this._fields = _removeIgnored(this._fields);
/* 322 */     this._getters = _removeIgnored(this._getters);
/* 323 */     this._setters = _removeIgnored(this._setters);
/* 324 */     this._ctorParameters = _removeIgnored(this._ctorParameters);
/*     */   }
/*     */ 
/*     */   public void removeNonVisible()
/*     */   {
/* 335 */     this._getters = _removeNonVisible(this._getters);
/* 336 */     this._ctorParameters = _removeNonVisible(this._ctorParameters);
/*     */ 
/* 338 */     if (this._getters == null) {
/* 339 */       this._fields = _removeNonVisible(this._fields);
/* 340 */       this._setters = _removeNonVisible(this._setters);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void trimByVisibility()
/*     */   {
/* 351 */     this._fields = _trimByVisibility(this._fields);
/* 352 */     this._getters = _trimByVisibility(this._getters);
/* 353 */     this._setters = _trimByVisibility(this._setters);
/* 354 */     this._ctorParameters = _trimByVisibility(this._ctorParameters);
/*     */   }
/*     */ 
/*     */   public void mergeAnnotations(boolean forSerialization)
/*     */   {
/* 360 */     if (forSerialization) {
/* 361 */       if (this._getters != null) {
/* 362 */         AnnotationMap ann = _mergeAnnotations(0, new Node[] { this._getters, this._fields, this._ctorParameters, this._setters });
/* 363 */         this._getters = this._getters.withValue(((AnnotatedMethod)this._getters.value).withAnnotations(ann));
/* 364 */       } else if (this._fields != null) {
/* 365 */         AnnotationMap ann = _mergeAnnotations(0, new Node[] { this._fields, this._ctorParameters, this._setters });
/* 366 */         this._fields = this._fields.withValue(((AnnotatedField)this._fields.value).withAnnotations(ann));
/*     */       }
/*     */     }
/* 369 */     else if (this._ctorParameters != null) {
/* 370 */       AnnotationMap ann = _mergeAnnotations(0, new Node[] { this._ctorParameters, this._setters, this._fields, this._getters });
/* 371 */       this._ctorParameters = this._ctorParameters.withValue(((AnnotatedParameter)this._ctorParameters.value).withAnnotations(ann));
/* 372 */     } else if (this._setters != null) {
/* 373 */       AnnotationMap ann = _mergeAnnotations(0, new Node[] { this._setters, this._fields, this._getters });
/* 374 */       this._setters = this._setters.withValue(((AnnotatedMethod)this._setters.value).withAnnotations(ann));
/* 375 */     } else if (this._fields != null) {
/* 376 */       AnnotationMap ann = _mergeAnnotations(0, new Node[] { this._fields, this._getters });
/* 377 */       this._fields = this._fields.withValue(((AnnotatedField)this._fields.value).withAnnotations(ann));
/*     */     }
/*     */   }
/*     */ 
/*     */   private AnnotationMap _mergeAnnotations(int index, Node<? extends AnnotatedMember>[] nodes)
/*     */   {
/* 384 */     AnnotationMap ann = ((AnnotatedMember)nodes[index].value).getAllAnnotations();
/* 385 */     index++;
/* 386 */     for (; index < nodes.length; index++) {
/* 387 */       if (nodes[index] != null) {
/* 388 */         return AnnotationMap.merge(ann, _mergeAnnotations(index, nodes));
/*     */       }
/*     */     }
/* 391 */     return ann;
/*     */   }
/*     */ 
/*     */   private <T> Node<T> _removeIgnored(Node<T> node)
/*     */   {
/* 396 */     if (node == null) {
/* 397 */       return node;
/*     */     }
/* 399 */     return node.withoutIgnored();
/*     */   }
/*     */ 
/*     */   private <T> Node<T> _removeNonVisible(Node<T> node)
/*     */   {
/* 404 */     if (node == null) {
/* 405 */       return node;
/*     */     }
/* 407 */     return node.withoutNonVisible();
/*     */   }
/*     */ 
/*     */   private <T> Node<T> _trimByVisibility(Node<T> node)
/*     */   {
/* 412 */     if (node == null) {
/* 413 */       return node;
/*     */     }
/* 415 */     return node.trimByVisibility();
/*     */   }
/*     */ 
/*     */   public boolean anyExplicitNames()
/*     */   {
/* 425 */     return (_anyExplicitNames(this._fields)) || (_anyExplicitNames(this._getters)) || (_anyExplicitNames(this._setters)) || (_anyExplicitNames(this._ctorParameters));
/*     */   }
/*     */ 
/*     */   private <T> boolean _anyExplicitNames(Node<T> n)
/*     */   {
/* 434 */     for (; n != null; n = n.next) {
/* 435 */       if ((n.explicitName != null) && (n.explicitName.length() > 0)) {
/* 436 */         return true;
/*     */       }
/*     */     }
/* 439 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean anyVisible() {
/* 443 */     return (_anyVisible(this._fields)) || (_anyVisible(this._getters)) || (_anyVisible(this._setters)) || (_anyVisible(this._ctorParameters));
/*     */   }
/*     */ 
/*     */   private <T> boolean _anyVisible(Node<T> n)
/*     */   {
/* 452 */     for (; n != null; n = n.next) {
/* 453 */       if (n.isVisible) {
/* 454 */         return true;
/*     */       }
/*     */     }
/* 457 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean anyIgnorals() {
/* 461 */     return (_anyIgnorals(this._fields)) || (_anyIgnorals(this._getters)) || (_anyIgnorals(this._setters)) || (_anyIgnorals(this._ctorParameters));
/*     */   }
/*     */ 
/*     */   private <T> boolean _anyIgnorals(Node<T> n)
/*     */   {
/* 470 */     for (; n != null; n = n.next) {
/* 471 */       if (n.isMarkedIgnored) {
/* 472 */         return true;
/*     */       }
/*     */     }
/* 475 */     return false;
/*     */   }
/*     */ 
/*     */   public String findNewName()
/*     */   {
/* 485 */     Node renamed = null;
/* 486 */     renamed = findRenamed(this._fields, renamed);
/* 487 */     renamed = findRenamed(this._getters, renamed);
/* 488 */     renamed = findRenamed(this._setters, renamed);
/* 489 */     renamed = findRenamed(this._ctorParameters, renamed);
/* 490 */     return renamed == null ? null : renamed.explicitName;
/*     */   }
/*     */ 
/*     */   private Node<? extends AnnotatedMember> findRenamed(Node<? extends AnnotatedMember> node, Node<? extends AnnotatedMember> renamed)
/*     */   {
/* 496 */     for (; node != null; node = node.next) {
/* 497 */       String explName = node.explicitName;
/* 498 */       if (explName != null)
/*     */       {
/* 502 */         if (!explName.equals(this._name))
/*     */         {
/* 505 */           if (renamed == null) {
/* 506 */             renamed = node;
/*     */           }
/* 509 */           else if (!explName.equals(renamed.explicitName)) {
/* 510 */             throw new IllegalStateException("Conflicting property name definitions: '" + renamed.explicitName + "' (for " + renamed.value + ") vs '" + node.explicitName + "' (for " + node.value + ")");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 516 */     return renamed;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 523 */     StringBuilder sb = new StringBuilder();
/* 524 */     sb.append("[Property '").append(this._name).append("'; ctors: ").append(this._ctorParameters).append(", field(s): ").append(this._fields).append(", getter(s): ").append(this._getters).append(", setter(s): ").append(this._setters);
/*     */ 
/* 530 */     sb.append("]");
/* 531 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static final class Node<T>
/*     */   {
/*     */     public final T value;
/*     */     public final Node<T> next;
/*     */     public final String explicitName;
/*     */     public final boolean isVisible;
/*     */     public final boolean isMarkedIgnored;
/*     */ 
/*     */     public Node(T v, Node<T> n, String explName, boolean visible, boolean ignored)
/*     */     {
/* 556 */       this.value = v;
/* 557 */       this.next = n;
/*     */ 
/* 559 */       if (explName == null)
/* 560 */         this.explicitName = null;
/*     */       else {
/* 562 */         this.explicitName = (explName.length() == 0 ? null : explName);
/*     */       }
/* 564 */       this.isVisible = visible;
/* 565 */       this.isMarkedIgnored = ignored;
/*     */     }
/*     */ 
/*     */     public Node<T> withValue(T newValue)
/*     */     {
/* 570 */       if (newValue == this.value) {
/* 571 */         return this;
/*     */       }
/* 573 */       return new Node(newValue, this.next, this.explicitName, this.isVisible, this.isMarkedIgnored);
/*     */     }
/*     */ 
/*     */     public Node<T> withNext(Node<T> newNext) {
/* 577 */       if (newNext == this.next) {
/* 578 */         return this;
/*     */       }
/* 580 */       return new Node(this.value, newNext, this.explicitName, this.isVisible, this.isMarkedIgnored);
/*     */     }
/*     */ 
/*     */     public Node<T> withoutIgnored()
/*     */     {
/* 585 */       if (this.isMarkedIgnored) {
/* 586 */         return this.next == null ? null : this.next.withoutIgnored();
/*     */       }
/* 588 */       if (this.next != null) {
/* 589 */         Node newNext = this.next.withoutIgnored();
/* 590 */         if (newNext != this.next) {
/* 591 */           return withNext(newNext);
/*     */         }
/*     */       }
/* 594 */       return this;
/*     */     }
/*     */ 
/*     */     public Node<T> withoutNonVisible()
/*     */     {
/* 599 */       Node newNext = this.next == null ? null : this.next.withoutNonVisible();
/* 600 */       return this.isVisible ? withNext(newNext) : newNext;
/*     */     }
/*     */ 
/*     */     private Node<T> append(Node<T> appendable)
/*     */     {
/* 609 */       if (this.next == null) {
/* 610 */         return withNext(appendable);
/*     */       }
/* 612 */       return withNext(this.next.append(appendable));
/*     */     }
/*     */ 
/*     */     public Node<T> trimByVisibility()
/*     */     {
/* 617 */       if (this.next == null) {
/* 618 */         return this;
/*     */       }
/* 620 */       Node newNext = this.next.trimByVisibility();
/* 621 */       if (this.explicitName != null) {
/* 622 */         if (newNext.explicitName == null) {
/* 623 */           return withNext(null);
/*     */         }
/*     */ 
/* 626 */         return withNext(newNext);
/*     */       }
/* 628 */       if (newNext.explicitName != null) {
/* 629 */         return newNext;
/*     */       }
/*     */ 
/* 632 */       if (this.isVisible == newNext.isVisible) {
/* 633 */         return withNext(newNext);
/*     */       }
/* 635 */       return this.isVisible ? withNext(null) : newNext;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 640 */       String msg = this.value.toString() + "[visible=" + this.isVisible + "]";
/* 641 */       if (this.next != null) {
/* 642 */         msg = msg + ", " + this.next.toString();
/*     */       }
/* 644 */       return msg;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.POJOPropertyBuilder
 * JD-Core Version:    0.6.2
 */