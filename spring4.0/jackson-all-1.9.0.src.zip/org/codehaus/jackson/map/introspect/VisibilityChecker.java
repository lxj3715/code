/*     */ package org.codehaus.jackson.map.introspect;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import org.codehaus.jackson.annotate.JsonAutoDetect;
/*     */ import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
/*     */ import org.codehaus.jackson.annotate.JsonMethod;
/*     */ 
/*     */ public abstract interface VisibilityChecker<T extends VisibilityChecker<T>>
/*     */ {
/*     */   public abstract T with(JsonAutoDetect paramJsonAutoDetect);
/*     */ 
/*     */   public abstract T with(JsonAutoDetect.Visibility paramVisibility);
/*     */ 
/*     */   public abstract T withVisibility(JsonMethod paramJsonMethod, JsonAutoDetect.Visibility paramVisibility);
/*     */ 
/*     */   public abstract T withGetterVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */ 
/*     */   public abstract T withIsGetterVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */ 
/*     */   public abstract T withSetterVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */ 
/*     */   public abstract T withCreatorVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */ 
/*     */   public abstract T withFieldVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */ 
/*     */   public abstract boolean isGetterVisible(Method paramMethod);
/*     */ 
/*     */   public abstract boolean isGetterVisible(AnnotatedMethod paramAnnotatedMethod);
/*     */ 
/*     */   public abstract boolean isIsGetterVisible(Method paramMethod);
/*     */ 
/*     */   public abstract boolean isIsGetterVisible(AnnotatedMethod paramAnnotatedMethod);
/*     */ 
/*     */   public abstract boolean isSetterVisible(Method paramMethod);
/*     */ 
/*     */   public abstract boolean isSetterVisible(AnnotatedMethod paramAnnotatedMethod);
/*     */ 
/*     */   public abstract boolean isCreatorVisible(Member paramMember);
/*     */ 
/*     */   public abstract boolean isCreatorVisible(AnnotatedMember paramAnnotatedMember);
/*     */ 
/*     */   public abstract boolean isFieldVisible(Field paramField);
/*     */ 
/*     */   public abstract boolean isFieldVisible(AnnotatedField paramAnnotatedField);
/*     */ 
/*     */   @JsonAutoDetect(getterVisibility=JsonAutoDetect.Visibility.PUBLIC_ONLY, isGetterVisibility=JsonAutoDetect.Visibility.PUBLIC_ONLY, setterVisibility=JsonAutoDetect.Visibility.ANY, creatorVisibility=JsonAutoDetect.Visibility.ANY, fieldVisibility=JsonAutoDetect.Visibility.PUBLIC_ONLY)
/*     */   public static class Std
/*     */     implements VisibilityChecker<Std>
/*     */   {
/* 178 */     protected static final Std DEFAULT = new Std((JsonAutoDetect)Std.class.getAnnotation(JsonAutoDetect.class));
/*     */     protected final JsonAutoDetect.Visibility _getterMinLevel;
/*     */     protected final JsonAutoDetect.Visibility _isGetterMinLevel;
/*     */     protected final JsonAutoDetect.Visibility _setterMinLevel;
/*     */     protected final JsonAutoDetect.Visibility _creatorMinLevel;
/*     */     protected final JsonAutoDetect.Visibility _fieldMinLevel;
/*     */ 
/*     */     public static Std defaultInstance()
/*     */     {
/* 186 */       return DEFAULT;
/*     */     }
/*     */ 
/*     */     public Std(JsonAutoDetect ann)
/*     */     {
/* 196 */       JsonMethod[] incl = ann.value();
/*     */ 
/* 198 */       this._getterMinLevel = (hasMethod(incl, JsonMethod.GETTER) ? ann.getterVisibility() : JsonAutoDetect.Visibility.NONE);
/* 199 */       this._isGetterMinLevel = (hasMethod(incl, JsonMethod.IS_GETTER) ? ann.isGetterVisibility() : JsonAutoDetect.Visibility.NONE);
/* 200 */       this._setterMinLevel = (hasMethod(incl, JsonMethod.SETTER) ? ann.setterVisibility() : JsonAutoDetect.Visibility.NONE);
/* 201 */       this._creatorMinLevel = (hasMethod(incl, JsonMethod.CREATOR) ? ann.creatorVisibility() : JsonAutoDetect.Visibility.NONE);
/* 202 */       this._fieldMinLevel = (hasMethod(incl, JsonMethod.FIELD) ? ann.fieldVisibility() : JsonAutoDetect.Visibility.NONE);
/*     */     }
/*     */ 
/*     */     public Std(JsonAutoDetect.Visibility getter, JsonAutoDetect.Visibility isGetter, JsonAutoDetect.Visibility setter, JsonAutoDetect.Visibility creator, JsonAutoDetect.Visibility field)
/*     */     {
/* 210 */       this._getterMinLevel = getter;
/* 211 */       this._isGetterMinLevel = isGetter;
/* 212 */       this._setterMinLevel = setter;
/* 213 */       this._creatorMinLevel = creator;
/* 214 */       this._fieldMinLevel = field;
/*     */     }
/*     */ 
/*     */     public Std(JsonAutoDetect.Visibility v)
/*     */     {
/* 228 */       if (v == JsonAutoDetect.Visibility.DEFAULT) {
/* 229 */         this._getterMinLevel = DEFAULT._getterMinLevel;
/* 230 */         this._isGetterMinLevel = DEFAULT._isGetterMinLevel;
/* 231 */         this._setterMinLevel = DEFAULT._setterMinLevel;
/* 232 */         this._creatorMinLevel = DEFAULT._creatorMinLevel;
/* 233 */         this._fieldMinLevel = DEFAULT._fieldMinLevel;
/*     */       } else {
/* 235 */         this._getterMinLevel = v;
/* 236 */         this._isGetterMinLevel = v;
/* 237 */         this._setterMinLevel = v;
/* 238 */         this._creatorMinLevel = v;
/* 239 */         this._fieldMinLevel = v;
/*     */       }
/*     */     }
/*     */ 
/*     */     public Std with(JsonAutoDetect ann)
/*     */     {
/* 253 */       if (ann == null) return this;
/* 254 */       Std curr = this;
/*     */ 
/* 256 */       JsonMethod[] incl = ann.value();
/*     */ 
/* 259 */       JsonAutoDetect.Visibility v = hasMethod(incl, JsonMethod.GETTER) ? ann.getterVisibility() : JsonAutoDetect.Visibility.NONE;
/* 260 */       curr = curr.withGetterVisibility(v);
/* 261 */       v = hasMethod(incl, JsonMethod.IS_GETTER) ? ann.isGetterVisibility() : JsonAutoDetect.Visibility.NONE;
/* 262 */       curr = curr.withIsGetterVisibility(v);
/* 263 */       v = hasMethod(incl, JsonMethod.SETTER) ? ann.setterVisibility() : JsonAutoDetect.Visibility.NONE;
/* 264 */       curr = curr.withSetterVisibility(v);
/* 265 */       v = hasMethod(incl, JsonMethod.CREATOR) ? ann.creatorVisibility() : JsonAutoDetect.Visibility.NONE;
/* 266 */       curr = curr.withCreatorVisibility(v);
/* 267 */       v = hasMethod(incl, JsonMethod.FIELD) ? ann.fieldVisibility() : JsonAutoDetect.Visibility.NONE;
/* 268 */       curr = curr.withFieldVisibility(v);
/* 269 */       return curr;
/*     */     }
/*     */ 
/*     */     public Std with(JsonAutoDetect.Visibility v)
/*     */     {
/* 275 */       if (v == JsonAutoDetect.Visibility.DEFAULT) {
/* 276 */         return DEFAULT;
/*     */       }
/* 278 */       return new Std(v);
/*     */     }
/*     */ 
/*     */     public Std withVisibility(JsonMethod method, JsonAutoDetect.Visibility v)
/*     */     {
/* 284 */       switch (VisibilityChecker.1.$SwitchMap$org$codehaus$jackson$annotate$JsonMethod[method.ordinal()]) {
/*     */       case 1:
/* 286 */         return withGetterVisibility(v);
/*     */       case 2:
/* 288 */         return withSetterVisibility(v);
/*     */       case 3:
/* 290 */         return withCreatorVisibility(v);
/*     */       case 4:
/* 292 */         return withFieldVisibility(v);
/*     */       case 5:
/* 294 */         return withIsGetterVisibility(v);
/*     */       case 6:
/* 296 */         return with(v);
/*     */       }
/*     */ 
/* 300 */       return this;
/*     */     }
/*     */ 
/*     */     public Std withGetterVisibility(JsonAutoDetect.Visibility v)
/*     */     {
/* 305 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._getterMinLevel;
/* 306 */       if (this._getterMinLevel == v) return this;
/* 307 */       return new Std(v, this._isGetterMinLevel, this._setterMinLevel, this._creatorMinLevel, this._fieldMinLevel);
/*     */     }
/*     */ 
/*     */     public Std withIsGetterVisibility(JsonAutoDetect.Visibility v)
/*     */     {
/* 312 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._isGetterMinLevel;
/* 313 */       if (this._isGetterMinLevel == v) return this;
/* 314 */       return new Std(this._getterMinLevel, v, this._setterMinLevel, this._creatorMinLevel, this._fieldMinLevel);
/*     */     }
/*     */ 
/*     */     public Std withSetterVisibility(JsonAutoDetect.Visibility v)
/*     */     {
/* 319 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._setterMinLevel;
/* 320 */       if (this._setterMinLevel == v) return this;
/* 321 */       return new Std(this._getterMinLevel, this._isGetterMinLevel, v, this._creatorMinLevel, this._fieldMinLevel);
/*     */     }
/*     */ 
/*     */     public Std withCreatorVisibility(JsonAutoDetect.Visibility v)
/*     */     {
/* 326 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._creatorMinLevel;
/* 327 */       if (this._creatorMinLevel == v) return this;
/* 328 */       return new Std(this._getterMinLevel, this._isGetterMinLevel, this._setterMinLevel, v, this._fieldMinLevel);
/*     */     }
/*     */ 
/*     */     public Std withFieldVisibility(JsonAutoDetect.Visibility v)
/*     */     {
/* 333 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._fieldMinLevel;
/* 334 */       if (this._fieldMinLevel == v) return this;
/* 335 */       return new Std(this._getterMinLevel, this._isGetterMinLevel, this._setterMinLevel, this._creatorMinLevel, v);
/*     */     }
/*     */ 
/*     */     public boolean isCreatorVisible(Member m)
/*     */     {
/* 346 */       return this._creatorMinLevel.isVisible(m);
/*     */     }
/*     */ 
/*     */     public boolean isCreatorVisible(AnnotatedMember m)
/*     */     {
/* 351 */       return isCreatorVisible(m.getMember());
/*     */     }
/*     */ 
/*     */     public boolean isFieldVisible(Field f)
/*     */     {
/* 356 */       return this._fieldMinLevel.isVisible(f);
/*     */     }
/*     */ 
/*     */     public boolean isFieldVisible(AnnotatedField f)
/*     */     {
/* 361 */       return isFieldVisible(f.getAnnotated());
/*     */     }
/*     */ 
/*     */     public boolean isGetterVisible(Method m)
/*     */     {
/* 366 */       return this._getterMinLevel.isVisible(m);
/*     */     }
/*     */ 
/*     */     public boolean isGetterVisible(AnnotatedMethod m)
/*     */     {
/* 371 */       return isGetterVisible(m.getAnnotated());
/*     */     }
/*     */ 
/*     */     public boolean isIsGetterVisible(Method m)
/*     */     {
/* 376 */       return this._isGetterMinLevel.isVisible(m);
/*     */     }
/*     */ 
/*     */     public boolean isIsGetterVisible(AnnotatedMethod m)
/*     */     {
/* 381 */       return isIsGetterVisible(m.getAnnotated());
/*     */     }
/*     */ 
/*     */     public boolean isSetterVisible(Method m)
/*     */     {
/* 386 */       return this._setterMinLevel.isVisible(m);
/*     */     }
/*     */ 
/*     */     public boolean isSetterVisible(AnnotatedMethod m)
/*     */     {
/* 391 */       return isSetterVisible(m.getAnnotated());
/*     */     }
/*     */ 
/*     */     private static boolean hasMethod(JsonMethod[] methods, JsonMethod method)
/*     */     {
/* 402 */       for (JsonMethod curr : methods) {
/* 403 */         if ((curr == method) || (curr == JsonMethod.ALL)) return true;
/*     */       }
/* 405 */       return false;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 415 */       return "[Visibility:" + " getter: " + this._getterMinLevel + ", isGetter: " + this._isGetterMinLevel + ", setter: " + this._setterMinLevel + ", creator: " + this._creatorMinLevel + ", field: " + this._fieldMinLevel + "]";
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.introspect.VisibilityChecker
 * JD-Core Version:    0.6.2
 */