/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ 
/*     */ public class AsArrayTypeSerializer extends TypeSerializerBase
/*     */ {
/*     */   public AsArrayTypeSerializer(TypeIdResolver idRes, BeanProperty property)
/*     */   {
/*  23 */     super(idRes, property);
/*     */   }
/*     */ 
/*     */   public JsonTypeInfo.As getTypeInclusion() {
/*  27 */     return JsonTypeInfo.As.WRAPPER_ARRAY;
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  33 */     jgen.writeStartArray();
/*  34 */     jgen.writeString(this._idResolver.idFromValue(value));
/*  35 */     jgen.writeStartObject();
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  43 */     jgen.writeStartArray();
/*  44 */     jgen.writeString(this._idResolver.idFromValueAndType(value, type));
/*  45 */     jgen.writeStartObject();
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  52 */     jgen.writeStartArray();
/*  53 */     jgen.writeString(this._idResolver.idFromValue(value));
/*  54 */     jgen.writeStartArray();
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  62 */     jgen.writeStartArray();
/*  63 */     jgen.writeString(this._idResolver.idFromValueAndType(value, type));
/*  64 */     jgen.writeStartArray();
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  72 */     jgen.writeStartArray();
/*  73 */     jgen.writeString(this._idResolver.idFromValue(value));
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  82 */     jgen.writeStartArray();
/*  83 */     jgen.writeString(this._idResolver.idFromValueAndType(value, type));
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForObject(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  90 */     jgen.writeEndObject();
/*  91 */     jgen.writeEndArray();
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForArray(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  99 */     jgen.writeEndArray();
/* 100 */     jgen.writeEndArray();
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForScalar(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 108 */     jgen.writeEndArray();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.AsArrayTypeSerializer
 * JD-Core Version:    0.6.2
 */