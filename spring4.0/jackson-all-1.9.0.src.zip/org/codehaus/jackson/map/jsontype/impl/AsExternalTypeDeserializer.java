/*    */ package org.codehaus.jackson.map.jsontype.impl;
/*    */ 
/*    */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class AsExternalTypeDeserializer extends AsArrayTypeDeserializer
/*    */ {
/*    */   protected final String _typePropertyName;
/*    */ 
/*    */   public AsExternalTypeDeserializer(JavaType bt, TypeIdResolver idRes, BeanProperty property, Class<?> defaultImpl, String typePropName)
/*    */   {
/* 26 */     super(bt, idRes, property, defaultImpl);
/* 27 */     this._typePropertyName = typePropName;
/*    */   }
/*    */ 
/*    */   public JsonTypeInfo.As getTypeInclusion()
/*    */   {
/* 32 */     return JsonTypeInfo.As.EXTERNAL_PROPERTY;
/*    */   }
/*    */ 
/*    */   public String getPropertyName() {
/* 36 */     return this._typePropertyName;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.AsExternalTypeDeserializer
 * JD-Core Version:    0.6.2
 */