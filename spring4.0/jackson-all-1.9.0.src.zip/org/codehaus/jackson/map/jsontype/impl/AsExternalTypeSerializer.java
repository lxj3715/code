/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ 
/*     */ public class AsExternalTypeSerializer extends TypeSerializerBase
/*     */ {
/*     */   protected final String _typePropertyName;
/*     */ 
/*     */   public AsExternalTypeSerializer(TypeIdResolver idRes, BeanProperty property, String propName)
/*     */   {
/*  32 */     super(idRes, property);
/*  33 */     this._typePropertyName = propName;
/*     */   }
/*     */ 
/*     */   public String getPropertyName() {
/*  37 */     return this._typePropertyName;
/*     */   }
/*     */   public JsonTypeInfo.As getTypeInclusion() {
/*  40 */     return JsonTypeInfo.As.EXTERNAL_PROPERTY;
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  46 */     _writePrefix(value, jgen);
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  53 */     _writePrefix(value, jgen, type);
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  60 */     _writePrefix(value, jgen);
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  67 */     _writePrefix(value, jgen, type);
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  74 */     _writePrefix(value, jgen);
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  81 */     _writePrefix(value, jgen, type);
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForObject(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  88 */     _writeSuffix(value, jgen);
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForArray(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  95 */     _writeSuffix(value, jgen);
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForScalar(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 102 */     _writeSuffix(value, jgen);
/*     */   }
/*     */ 
/*     */   protected final void _writePrefix(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 114 */     jgen.writeStartObject();
/*     */   }
/*     */ 
/*     */   protected final void _writePrefix(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 120 */     jgen.writeStartObject();
/*     */   }
/*     */ 
/*     */   protected final void _writeSuffix(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 126 */     jgen.writeEndObject();
/* 127 */     jgen.writeStringField(this._typePropertyName, this._idResolver.idFromValue(value));
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.AsExternalTypeSerializer
 * JD-Core Version:    0.6.2
 */