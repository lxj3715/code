/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.codehaus.jackson.util.JsonParserSequence;
/*     */ import org.codehaus.jackson.util.TokenBuffer;
/*     */ 
/*     */ public class AsPropertyTypeDeserializer extends AsArrayTypeDeserializer
/*     */ {
/*     */   protected final String _typePropertyName;
/*     */ 
/*     */   @Deprecated
/*     */   public AsPropertyTypeDeserializer(JavaType bt, TypeIdResolver idRes, BeanProperty property, String typePropName)
/*     */   {
/*  31 */     this(bt, idRes, property, null, typePropName);
/*     */   }
/*     */ 
/*     */   public AsPropertyTypeDeserializer(JavaType bt, TypeIdResolver idRes, BeanProperty property, Class<?> defaultImpl, String typePropName)
/*     */   {
/*  38 */     super(bt, idRes, property, defaultImpl);
/*  39 */     this._typePropertyName = typePropName;
/*     */   }
/*     */ 
/*     */   public JsonTypeInfo.As getTypeInclusion()
/*     */   {
/*  44 */     return JsonTypeInfo.As.PROPERTY;
/*     */   }
/*     */ 
/*     */   public String getPropertyName() {
/*  48 */     return this._typePropertyName;
/*     */   }
/*     */ 
/*     */   public Object deserializeTypedFromObject(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  59 */     JsonToken t = jp.getCurrentToken();
/*  60 */     if (t == JsonToken.START_OBJECT)
/*  61 */       t = jp.nextToken();
/*  62 */     else if (t != JsonToken.FIELD_NAME) {
/*  63 */       throw ctxt.wrongTokenException(jp, JsonToken.START_OBJECT, "need JSON Object to contain As.PROPERTY type information (for class " + baseTypeName() + ")");
/*     */     }
/*     */ 
/*  67 */     TokenBuffer tb = null;
/*     */ 
/*  69 */     for (; t == JsonToken.FIELD_NAME; t = jp.nextToken()) {
/*  70 */       String name = jp.getCurrentName();
/*  71 */       jp.nextToken();
/*  72 */       if (this._typePropertyName.equals(name)) {
/*  73 */         String typeId = jp.getText();
/*  74 */         JsonDeserializer deser = _findDeserializer(ctxt, typeId);
/*     */ 
/*  76 */         if (tb != null) {
/*  77 */           jp = JsonParserSequence.createFlattened(tb.asParser(jp), jp);
/*     */         }
/*     */ 
/*  82 */         jp.nextToken();
/*     */ 
/*  84 */         return deser.deserialize(jp, ctxt);
/*     */       }
/*  86 */       if (tb == null) {
/*  87 */         tb = new TokenBuffer(null);
/*     */       }
/*  89 */       tb.writeFieldName(name);
/*  90 */       tb.copyCurrentStructure(jp);
/*     */     }
/*  92 */     return _deserializeTypedUsingDefaultImpl(jp, ctxt, tb);
/*     */   }
/*     */ 
/*     */   protected Object _deserializeTypedUsingDefaultImpl(JsonParser jp, DeserializationContext ctxt, TokenBuffer tb)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 101 */     if (this._defaultImpl != null) {
/* 102 */       JsonDeserializer deser = _findDefaultImplDeserializer(ctxt);
/* 103 */       if (tb != null) {
/* 104 */         tb.writeEndObject();
/* 105 */         jp = tb.asParser(jp);
/*     */ 
/* 107 */         jp.nextToken();
/*     */       }
/* 109 */       return deser.deserialize(jp, ctxt);
/*     */     }
/*     */ 
/* 112 */     throw ctxt.wrongTokenException(jp, JsonToken.FIELD_NAME, "missing property '" + this._typePropertyName + "' that is to contain type id  (for class " + baseTypeName() + ")");
/*     */   }
/*     */ 
/*     */   public Object deserializeTypedFromAny(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 127 */     if (jp.getCurrentToken() == JsonToken.START_ARRAY) {
/* 128 */       return super.deserializeTypedFromArray(jp, ctxt);
/*     */     }
/* 130 */     return deserializeTypedFromObject(jp, ctxt);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.AsPropertyTypeDeserializer
 * JD-Core Version:    0.6.2
 */