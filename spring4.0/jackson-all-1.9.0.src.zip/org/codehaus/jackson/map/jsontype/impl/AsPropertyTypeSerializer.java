/*    */ package org.codehaus.jackson.map.jsontype.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*    */ 
/*    */ public class AsPropertyTypeSerializer extends AsArrayTypeSerializer
/*    */ {
/*    */   protected final String _typePropertyName;
/*    */ 
/*    */   public AsPropertyTypeSerializer(TypeIdResolver idRes, BeanProperty property, String propName)
/*    */   {
/* 29 */     super(idRes, property);
/* 30 */     this._typePropertyName = propName;
/*    */   }
/*    */ 
/*    */   public String getPropertyName() {
/* 34 */     return this._typePropertyName;
/*    */   }
/*    */   public JsonTypeInfo.As getTypeInclusion() {
/* 37 */     return JsonTypeInfo.As.PROPERTY;
/*    */   }
/*    */ 
/*    */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 43 */     jgen.writeStartObject();
/* 44 */     jgen.writeStringField(this._typePropertyName, this._idResolver.idFromValue(value));
/*    */   }
/*    */ 
/*    */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen, Class<?> type)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 51 */     jgen.writeStartObject();
/* 52 */     jgen.writeStringField(this._typePropertyName, this._idResolver.idFromValueAndType(value, type));
/*    */   }
/*    */ 
/*    */   public void writeTypeSuffixForObject(Object value, JsonGenerator jgen)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 64 */     jgen.writeEndObject();
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.AsPropertyTypeSerializer
 * JD-Core Version:    0.6.2
 */