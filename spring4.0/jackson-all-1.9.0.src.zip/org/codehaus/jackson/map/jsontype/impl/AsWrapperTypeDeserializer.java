/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class AsWrapperTypeDeserializer extends TypeDeserializerBase
/*     */ {
/*     */   @Deprecated
/*     */   public AsWrapperTypeDeserializer(JavaType bt, TypeIdResolver idRes, BeanProperty property)
/*     */   {
/*  24 */     this(bt, idRes, property, null);
/*     */   }
/*     */ 
/*     */   public AsWrapperTypeDeserializer(JavaType bt, TypeIdResolver idRes, BeanProperty property, Class<?> defaultImpl)
/*     */   {
/*  30 */     super(bt, idRes, property, null);
/*     */   }
/*     */ 
/*     */   public JsonTypeInfo.As getTypeInclusion()
/*     */   {
/*  35 */     return JsonTypeInfo.As.WRAPPER_OBJECT;
/*     */   }
/*     */ 
/*     */   public Object deserializeTypedFromObject(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  45 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   public Object deserializeTypedFromArray(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  52 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   public Object deserializeTypedFromScalar(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  59 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   public Object deserializeTypedFromAny(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  66 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   private final Object _deserialize(JsonParser jp, DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  84 */     if (jp.getCurrentToken() != JsonToken.START_OBJECT) {
/*  85 */       throw ctxt.wrongTokenException(jp, JsonToken.START_OBJECT, "need JSON Object to contain As.WRAPPER_OBJECT type information for class " + baseTypeName());
/*     */     }
/*     */ 
/*  89 */     if (jp.nextToken() != JsonToken.FIELD_NAME) {
/*  90 */       throw ctxt.wrongTokenException(jp, JsonToken.FIELD_NAME, "need JSON String that contains type id (for subtype of " + baseTypeName() + ")");
/*     */     }
/*     */ 
/*  93 */     JsonDeserializer deser = _findDeserializer(ctxt, jp.getText());
/*  94 */     jp.nextToken();
/*  95 */     Object value = deser.deserialize(jp, ctxt);
/*     */ 
/*  97 */     if (jp.nextToken() != JsonToken.END_OBJECT) {
/*  98 */       throw ctxt.wrongTokenException(jp, JsonToken.END_OBJECT, "expected closing END_OBJECT after type information and deserialized value");
/*     */     }
/*     */ 
/* 101 */     return value;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.AsWrapperTypeDeserializer
 * JD-Core Version:    0.6.2
 */