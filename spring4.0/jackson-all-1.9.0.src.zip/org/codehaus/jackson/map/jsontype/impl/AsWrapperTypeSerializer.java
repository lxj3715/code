/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ 
/*     */ public class AsWrapperTypeSerializer extends TypeSerializerBase
/*     */ {
/*     */   public AsWrapperTypeSerializer(TypeIdResolver idRes, BeanProperty property)
/*     */   {
/*  27 */     super(idRes, property);
/*     */   }
/*     */ 
/*     */   public JsonTypeInfo.As getTypeInclusion() {
/*  31 */     return JsonTypeInfo.As.WRAPPER_OBJECT;
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  38 */     jgen.writeStartObject();
/*     */ 
/*  40 */     jgen.writeObjectFieldStart(this._idResolver.idFromValue(value));
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  49 */     jgen.writeStartObject();
/*     */ 
/*  51 */     jgen.writeObjectFieldStart(this._idResolver.idFromValueAndType(value, type));
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  59 */     jgen.writeStartObject();
/*     */ 
/*  61 */     jgen.writeArrayFieldStart(this._idResolver.idFromValue(value));
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  70 */     jgen.writeStartObject();
/*     */ 
/*  72 */     jgen.writeArrayFieldStart(this._idResolver.idFromValueAndType(value, type));
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  80 */     jgen.writeStartObject();
/*  81 */     jgen.writeFieldName(this._idResolver.idFromValue(value));
/*     */   }
/*     */ 
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator jgen, Class<?> type)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  90 */     jgen.writeStartObject();
/*  91 */     jgen.writeFieldName(this._idResolver.idFromValueAndType(value, type));
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForObject(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  99 */     jgen.writeEndObject();
/*     */ 
/* 101 */     jgen.writeEndObject();
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForArray(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 109 */     jgen.writeEndArray();
/*     */ 
/* 111 */     jgen.writeEndObject();
/*     */   }
/*     */ 
/*     */   public void writeTypeSuffixForScalar(Object value, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 119 */     jgen.writeEndObject();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.AsWrapperTypeSerializer
 * JD-Core Version:    0.6.2
 */