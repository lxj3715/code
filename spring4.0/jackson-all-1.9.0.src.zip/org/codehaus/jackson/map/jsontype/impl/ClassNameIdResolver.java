/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.Id;
/*     */ import org.codehaus.jackson.map.type.CollectionType;
/*     */ import org.codehaus.jackson.map.type.MapType;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class ClassNameIdResolver extends TypeIdResolverBase
/*     */ {
/*     */   public ClassNameIdResolver(JavaType baseType, TypeFactory typeFactory)
/*     */   {
/*  19 */     super(baseType, typeFactory);
/*     */   }
/*     */ 
/*     */   public JsonTypeInfo.Id getMechanism() {
/*  23 */     return JsonTypeInfo.Id.CLASS;
/*     */   }
/*     */ 
/*     */   public void registerSubtype(Class<?> type, String name)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String idFromValue(Object value)
/*     */   {
/*  32 */     return _idFrom(value, value.getClass());
/*     */   }
/*     */ 
/*     */   public String idFromValueAndType(Object value, Class<?> type)
/*     */   {
/*  38 */     return _idFrom(value, type);
/*     */   }
/*     */ 
/*     */   public JavaType typeFromId(String id)
/*     */   {
/*  48 */     if (id.indexOf('<') > 0) {
/*  49 */       JavaType t = TypeFactory.fromCanonical(id);
/*     */ 
/*  51 */       return t;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  58 */       ClassLoader loader = Thread.currentThread().getContextClassLoader();
/*  59 */       Class cls = Class.forName(id, true, loader);
/*  60 */       return this._typeFactory.constructSpecializedType(this._baseType, cls);
/*     */     } catch (ClassNotFoundException e) {
/*  62 */       throw new IllegalArgumentException("Invalid type id '" + id + "' (for id type 'Id.class'): no such class found");
/*     */     } catch (Exception e) {
/*  64 */       throw new IllegalArgumentException("Invalid type id '" + id + "' (for id type 'Id.class'): " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final String _idFrom(Object value, Class<?> cls)
/*     */   {
/*  77 */     if ((Enum.class.isAssignableFrom(cls)) && 
/*  78 */       (!cls.isEnum())) {
/*  79 */       cls = cls.getSuperclass();
/*     */     }
/*     */ 
/*  82 */     String str = cls.getName();
/*  83 */     if (str.startsWith("java.util"))
/*     */     {
/*  92 */       if ((value instanceof EnumSet)) {
/*  93 */         Class enumClass = ClassUtil.findEnumType((EnumSet)value);
/*     */ 
/*  95 */         str = TypeFactory.defaultInstance().constructCollectionType(EnumSet.class, enumClass).toCanonical();
/*  96 */       } else if ((value instanceof EnumMap)) {
/*  97 */         Class enumClass = ClassUtil.findEnumType((EnumMap)value);
/*  98 */         Class valueClass = Object.class;
/*     */ 
/* 100 */         str = TypeFactory.defaultInstance().constructMapType(EnumMap.class, enumClass, valueClass).toCanonical();
/*     */       } else {
/* 102 */         String end = str.substring(9);
/* 103 */         if (((end.startsWith(".Arrays$")) || (end.startsWith(".Collections$"))) && (str.indexOf("List") >= 0))
/*     */         {
/* 111 */           str = "java.util.ArrayList";
/*     */         }
/*     */       }
/* 114 */     } else if (str.indexOf('$') >= 0)
/*     */     {
/* 122 */       Class outer = ClassUtil.getOuterClass(cls);
/* 123 */       if (outer != null)
/*     */       {
/* 128 */         Class staticType = this._baseType.getRawClass();
/* 129 */         if (ClassUtil.getOuterClass(staticType) == null)
/*     */         {
/* 131 */           cls = this._baseType.getRawClass();
/* 132 */           str = cls.getName();
/*     */         }
/*     */       }
/*     */     }
/* 136 */     return str;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.ClassNameIdResolver
 * JD-Core Version:    0.6.2
 */