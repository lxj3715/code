/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.MapperConfig;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.jsontype.NamedType;
/*     */ import org.codehaus.jackson.map.jsontype.SubtypeResolver;
/*     */ 
/*     */ public class StdSubtypeResolver extends SubtypeResolver
/*     */ {
/*     */   protected LinkedHashSet<NamedType> _registeredSubtypes;
/*     */ 
/*     */   public void registerSubtypes(NamedType[] types)
/*     */   {
/*  29 */     if (this._registeredSubtypes == null) {
/*  30 */       this._registeredSubtypes = new LinkedHashSet();
/*     */     }
/*  32 */     for (NamedType type : types)
/*  33 */       this._registeredSubtypes.add(type);
/*     */   }
/*     */ 
/*     */   public void registerSubtypes(Class<?>[] classes)
/*     */   {
/*  40 */     NamedType[] types = new NamedType[classes.length];
/*  41 */     int i = 0; for (int len = classes.length; i < len; i++) {
/*  42 */       types[i] = new NamedType(classes[i]);
/*     */     }
/*  44 */     registerSubtypes(types);
/*     */   }
/*     */ 
/*     */   public Collection<NamedType> collectAndResolveSubtypes(AnnotatedMember property, MapperConfig<?> config, AnnotationIntrospector ai)
/*     */   {
/*  56 */     HashMap collected = new HashMap();
/*     */     Class rawBase;
/*  58 */     if (this._registeredSubtypes != null) {
/*  59 */       rawBase = property.getRawType();
/*  60 */       for (NamedType subtype : this._registeredSubtypes)
/*     */       {
/*  62 */         if (rawBase.isAssignableFrom(subtype.getType())) {
/*  63 */           AnnotatedClass curr = AnnotatedClass.constructWithoutSuperTypes(subtype.getType(), ai, config);
/*  64 */           _collectAndResolve(curr, subtype, config, ai, collected);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  70 */     Collection st = ai.findSubtypes(property);
/*  71 */     if (st != null) {
/*  72 */       for (NamedType nt : st) {
/*  73 */         AnnotatedClass ac = AnnotatedClass.constructWithoutSuperTypes(nt.getType(), ai, config);
/*  74 */         _collectAndResolve(ac, nt, config, ai, collected);
/*     */       }
/*     */     }
/*  77 */     NamedType rootType = new NamedType(property.getRawType(), null);
/*  78 */     AnnotatedClass ac = AnnotatedClass.constructWithoutSuperTypes(property.getRawType(), ai, config);
/*     */ 
/*  81 */     _collectAndResolve(ac, rootType, config, ai, collected);
/*  82 */     return new ArrayList(collected.values());
/*     */   }
/*     */ 
/*     */   public Collection<NamedType> collectAndResolveSubtypes(AnnotatedClass type, MapperConfig<?> config, AnnotationIntrospector ai)
/*     */   {
/*  89 */     HashMap subtypes = new HashMap();
/*     */     Class rawBase;
/*  91 */     if (this._registeredSubtypes != null) {
/*  92 */       rawBase = type.getRawType();
/*  93 */       for (NamedType subtype : this._registeredSubtypes)
/*     */       {
/*  95 */         if (rawBase.isAssignableFrom(subtype.getType())) {
/*  96 */           AnnotatedClass curr = AnnotatedClass.constructWithoutSuperTypes(subtype.getType(), ai, config);
/*  97 */           _collectAndResolve(curr, subtype, config, ai, subtypes);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 102 */     NamedType rootType = new NamedType(type.getRawType(), null);
/* 103 */     _collectAndResolve(type, rootType, config, ai, subtypes);
/* 104 */     return new ArrayList(subtypes.values());
/*     */   }
/*     */ 
/*     */   protected void _collectAndResolve(AnnotatedClass annotatedType, NamedType namedType, MapperConfig<?> config, AnnotationIntrospector ai, HashMap<NamedType, NamedType> collectedSubtypes)
/*     */   {
/* 119 */     if (!namedType.hasName()) {
/* 120 */       String name = ai.findTypeName(annotatedType);
/* 121 */       if (name != null) {
/* 122 */         namedType = new NamedType(namedType.getType(), name);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 127 */     if (collectedSubtypes.containsKey(namedType))
/*     */     {
/* 129 */       if (namedType.hasName()) {
/* 130 */         NamedType prev = (NamedType)collectedSubtypes.get(namedType);
/* 131 */         if (!prev.hasName()) {
/* 132 */           collectedSubtypes.put(namedType, namedType);
/*     */         }
/*     */       }
/* 135 */       return;
/*     */     }
/*     */ 
/* 138 */     collectedSubtypes.put(namedType, namedType);
/* 139 */     Collection st = ai.findSubtypes(annotatedType);
/* 140 */     if ((st != null) && (!st.isEmpty()))
/* 141 */       for (NamedType subtype : st) {
/* 142 */         AnnotatedClass subtypeClass = AnnotatedClass.constructWithoutSuperTypes(subtype.getType(), ai, config);
/*     */ 
/* 144 */         if (!subtype.hasName()) {
/* 145 */           subtype = new NamedType(subtype.getType(), ai.findTypeName(subtypeClass));
/*     */         }
/* 147 */         _collectAndResolve(subtypeClass, subtype, config, ai, collectedSubtypes);
/*     */       }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.StdSubtypeResolver
 * JD-Core Version:    0.6.2
 */