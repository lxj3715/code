/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.Id;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.MapperConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.jsontype.NamedType;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class StdTypeResolverBuilder
/*     */   implements TypeResolverBuilder<StdTypeResolverBuilder>
/*     */ {
/*     */   protected JsonTypeInfo.Id _idType;
/*     */   protected JsonTypeInfo.As _includeAs;
/*     */   protected String _typeProperty;
/*     */   protected Class<?> _defaultImpl;
/*     */   protected TypeIdResolver _customIdResolver;
/*     */ 
/*     */   public Class<?> getDefaultImpl()
/*     */   {
/*  46 */     return this._defaultImpl;
/*     */   }
/*     */ 
/*     */   public StdTypeResolverBuilder init(JsonTypeInfo.Id idType, TypeIdResolver idRes)
/*     */   {
/*  61 */     if (idType == null) {
/*  62 */       throw new IllegalArgumentException("idType can not be null");
/*     */     }
/*  64 */     this._idType = idType;
/*  65 */     this._customIdResolver = idRes;
/*     */ 
/*  67 */     this._typeProperty = idType.getDefaultPropertyName();
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */   public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes, BeanProperty property)
/*     */   {
/*  75 */     TypeIdResolver idRes = idResolver(config, baseType, subtypes, true, false);
/*  76 */     switch (1.$SwitchMap$org$codehaus$jackson$annotate$JsonTypeInfo$As[this._includeAs.ordinal()]) {
/*     */     case 1:
/*  78 */       return new AsArrayTypeSerializer(idRes, property);
/*     */     case 2:
/*  80 */       return new AsPropertyTypeSerializer(idRes, property, this._typeProperty);
/*     */     case 3:
/*  82 */       return new AsWrapperTypeSerializer(idRes, property);
/*     */     case 4:
/*  84 */       return new AsExternalTypeSerializer(idRes, property, this._typeProperty);
/*     */     }
/*  86 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */ 
/*     */   public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes, BeanProperty property)
/*     */   {
/*  93 */     TypeIdResolver idRes = idResolver(config, baseType, subtypes, false, true);
/*     */ 
/*  96 */     switch (1.$SwitchMap$org$codehaus$jackson$annotate$JsonTypeInfo$As[this._includeAs.ordinal()]) {
/*     */     case 1:
/*  98 */       return new AsArrayTypeDeserializer(baseType, idRes, property, this._defaultImpl);
/*     */     case 2:
/* 100 */       return new AsPropertyTypeDeserializer(baseType, idRes, property, this._defaultImpl, this._typeProperty);
/*     */     case 3:
/* 103 */       return new AsWrapperTypeDeserializer(baseType, idRes, property, this._defaultImpl);
/*     */     case 4:
/* 105 */       return new AsExternalTypeDeserializer(baseType, idRes, property, this._defaultImpl, this._typeProperty);
/*     */     }
/*     */ 
/* 108 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */ 
/*     */   public StdTypeResolverBuilder inclusion(JsonTypeInfo.As includeAs)
/*     */   {
/* 119 */     if (includeAs == null) {
/* 120 */       throw new IllegalArgumentException("includeAs can not be null");
/*     */     }
/* 122 */     this._includeAs = includeAs;
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   public StdTypeResolverBuilder typeProperty(String typeIdPropName)
/*     */   {
/* 134 */     if ((typeIdPropName == null) || (typeIdPropName.length() == 0)) {
/* 135 */       typeIdPropName = this._idType.getDefaultPropertyName();
/*     */     }
/* 137 */     this._typeProperty = typeIdPropName;
/* 138 */     return this;
/*     */   }
/*     */ 
/*     */   public StdTypeResolverBuilder defaultImpl(Class<?> defaultImpl)
/*     */   {
/* 144 */     this._defaultImpl = defaultImpl;
/* 145 */     return this;
/*     */   }
/*     */ 
/*     */   public String getTypeProperty()
/*     */   {
/* 154 */     return this._typeProperty;
/*     */   }
/*     */ 
/*     */   protected TypeIdResolver idResolver(MapperConfig<?> config, JavaType baseType, Collection<NamedType> subtypes, boolean forSer, boolean forDeser)
/*     */   {
/* 172 */     if (this._customIdResolver != null) {
/* 173 */       return this._customIdResolver;
/*     */     }
/* 175 */     if (this._idType == null) {
/* 176 */       throw new IllegalStateException("Can not build, 'init()' not yet called");
/*     */     }
/* 178 */     switch (1.$SwitchMap$org$codehaus$jackson$annotate$JsonTypeInfo$Id[this._idType.ordinal()]) {
/*     */     case 1:
/* 180 */       return new ClassNameIdResolver(baseType, config.getTypeFactory());
/*     */     case 2:
/* 182 */       return new MinimalClassNameIdResolver(baseType, config.getTypeFactory());
/*     */     case 3:
/* 184 */       return TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
/*     */     case 4:
/*     */     case 5:
/*     */     }
/*     */ 
/* 189 */     throw new IllegalStateException("Do not know how to construct standard type id resolver for idType: " + this._idType);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.StdTypeResolverBuilder
 * JD-Core Version:    0.6.2
 */