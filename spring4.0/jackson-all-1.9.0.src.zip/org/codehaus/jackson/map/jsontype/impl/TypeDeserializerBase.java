/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.DeserializationContext;
/*     */ import org.codehaus.jackson.map.DeserializerProvider;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.TypeDeserializer;
/*     */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class TypeDeserializerBase extends TypeDeserializer
/*     */ {
/*     */   protected final TypeIdResolver _idResolver;
/*     */   protected final JavaType _baseType;
/*     */   protected final BeanProperty _property;
/*     */   protected final JavaType _defaultImpl;
/*     */   protected final HashMap<String, JsonDeserializer<Object>> _deserializers;
/*     */   protected JsonDeserializer<Object> _defaultImplDeserializer;
/*     */ 
/*     */   @Deprecated
/*     */   protected TypeDeserializerBase(JavaType baseType, TypeIdResolver idRes, BeanProperty property)
/*     */   {
/*  51 */     this(baseType, idRes, property, null);
/*     */   }
/*     */ 
/*     */   protected TypeDeserializerBase(JavaType baseType, TypeIdResolver idRes, BeanProperty property, Class<?> defaultImpl)
/*     */   {
/*  57 */     this._baseType = baseType;
/*  58 */     this._idResolver = idRes;
/*  59 */     this._property = property;
/*  60 */     this._deserializers = new HashMap();
/*  61 */     if (defaultImpl == null)
/*  62 */       this._defaultImpl = null;
/*     */     else
/*  64 */       this._defaultImpl = baseType.forcedNarrowBy(defaultImpl);
/*     */   }
/*     */ 
/*     */   public abstract JsonTypeInfo.As getTypeInclusion();
/*     */ 
/*     */   public String baseTypeName()
/*     */   {
/*  71 */     return this._baseType.getRawClass().getName();
/*     */   }
/*     */   public String getPropertyName() {
/*  74 */     return null;
/*     */   }
/*     */   public TypeIdResolver getTypeIdResolver() {
/*  77 */     return this._idResolver;
/*     */   }
/*     */ 
/*     */   public Class<?> getDefaultImpl() {
/*  81 */     return this._defaultImpl == null ? null : this._defaultImpl.getRawClass();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  87 */     StringBuilder sb = new StringBuilder();
/*  88 */     sb.append('[').append(getClass().getName());
/*  89 */     sb.append("; base-type:").append(this._baseType);
/*  90 */     sb.append("; id-resolver: ").append(this._idResolver);
/*  91 */     sb.append(']');
/*  92 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected final JsonDeserializer<Object> _findDeserializer(DeserializationContext ctxt, String typeId)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*     */     JsonDeserializer deser;
/* 106 */     synchronized (this._deserializers) {
/* 107 */       deser = (JsonDeserializer)this._deserializers.get(typeId);
/* 108 */       if (deser == null) {
/* 109 */         JavaType type = this._idResolver.typeFromId(typeId);
/* 110 */         if (type == null)
/*     */         {
/* 112 */           if (this._defaultImpl == null) {
/* 113 */             throw ctxt.unknownTypeException(this._baseType, typeId);
/*     */           }
/* 115 */           deser = _findDefaultImplDeserializer(ctxt);
/*     */         }
/*     */         else
/*     */         {
/* 125 */           if ((this._baseType != null) && (this._baseType.getClass() == type.getClass())) {
/* 126 */             type = this._baseType.narrowBy(type.getRawClass());
/*     */           }
/* 128 */           deser = ctxt.getDeserializerProvider().findValueDeserializer(ctxt.getConfig(), type, this._property);
/*     */         }
/* 130 */         this._deserializers.put(typeId, deser);
/*     */       }
/*     */     }
/* 133 */     return deser;
/*     */   }
/*     */ 
/*     */   protected final JsonDeserializer<Object> _findDefaultImplDeserializer(DeserializationContext ctxt)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 139 */     if (this._defaultImpl == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     synchronized (this._defaultImpl) {
/* 143 */       if (this._defaultImplDeserializer == null) {
/* 144 */         this._defaultImplDeserializer = ctxt.getDeserializerProvider().findValueDeserializer(ctxt.getConfig(), this._defaultImpl, this._property);
/*     */       }
/*     */ 
/* 147 */       return this._defaultImplDeserializer;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.TypeDeserializerBase
 * JD-Core Version:    0.6.2
 */