/*    */ package org.codehaus.jackson.map.jsontype.impl;
/*    */ 
/*    */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*    */ import org.codehaus.jackson.map.type.TypeFactory;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public abstract class TypeIdResolverBase
/*    */   implements TypeIdResolver
/*    */ {
/*    */   protected final TypeFactory _typeFactory;
/*    */   protected final JavaType _baseType;
/*    */ 
/*    */   protected TypeIdResolverBase(JavaType baseType, TypeFactory typeFactory)
/*    */   {
/* 19 */     this._baseType = baseType;
/* 20 */     this._typeFactory = typeFactory;
/*    */   }
/*    */ 
/*    */   public void init(JavaType bt)
/*    */   {
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.TypeIdResolverBase
 * JD-Core Version:    0.6.2
 */