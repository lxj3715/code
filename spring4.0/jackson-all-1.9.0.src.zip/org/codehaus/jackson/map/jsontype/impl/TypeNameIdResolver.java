/*     */ package org.codehaus.jackson.map.jsontype.impl;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.annotate.JsonTypeInfo.Id;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.MapperConfig;
/*     */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*     */ import org.codehaus.jackson.map.jsontype.NamedType;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class TypeNameIdResolver extends TypeIdResolverBase
/*     */ {
/*     */   protected final MapperConfig<?> _config;
/*     */   protected final HashMap<String, String> _typeToId;
/*     */   protected final HashMap<String, JavaType> _idToType;
/*     */ 
/*     */   protected TypeNameIdResolver(MapperConfig<?> config, JavaType baseType, HashMap<String, String> typeToId, HashMap<String, JavaType> idToType)
/*     */   {
/*  32 */     super(baseType, config.getTypeFactory());
/*  33 */     this._config = config;
/*  34 */     this._typeToId = typeToId;
/*  35 */     this._idToType = idToType;
/*     */   }
/*     */ 
/*     */   public static TypeNameIdResolver construct(MapperConfig<?> config, JavaType baseType, Collection<NamedType> subtypes, boolean forSer, boolean forDeser)
/*     */   {
/*  43 */     if (forSer == forDeser) throw new IllegalArgumentException();
/*  44 */     HashMap typeToId = null;
/*  45 */     HashMap idToType = null;
/*     */ 
/*  47 */     if (forSer) {
/*  48 */       typeToId = new HashMap();
/*     */     }
/*  50 */     if (forDeser) {
/*  51 */       idToType = new HashMap();
/*     */     }
/*  53 */     if (subtypes != null)
/*  54 */       for (NamedType t : subtypes)
/*     */       {
/*  58 */         Class cls = t.getType();
/*  59 */         String id = t.hasName() ? t.getName() : _defaultTypeId(cls);
/*  60 */         if (forSer) {
/*  61 */           typeToId.put(cls.getName(), id);
/*     */         }
/*  63 */         if (forDeser)
/*     */         {
/*  68 */           JavaType prev = (JavaType)idToType.get(id);
/*  69 */           if ((prev == null) || 
/*  70 */             (!cls.isAssignableFrom(prev.getRawClass())))
/*     */           {
/*  74 */             idToType.put(id, config.constructType(cls));
/*     */           }
/*     */         }
/*     */       }
/*  78 */     return new TypeNameIdResolver(config, baseType, typeToId, idToType);
/*     */   }
/*     */ 
/*     */   public JsonTypeInfo.Id getMechanism() {
/*  82 */     return JsonTypeInfo.Id.NAME;
/*     */   }
/*     */ 
/*     */   public String idFromValue(Object value)
/*     */   {
/*  87 */     Class cls = value.getClass();
/*  88 */     String key = cls.getName();
/*     */     String name;
/*  90 */     synchronized (this._typeToId) {
/*  91 */       name = (String)this._typeToId.get(key);
/*  92 */       if (name == null)
/*     */       {
/*  95 */         if (this._config.isAnnotationProcessingEnabled()) {
/*  96 */           BasicBeanDescription beanDesc = (BasicBeanDescription)this._config.introspectClassAnnotations(cls);
/*  97 */           name = this._config.getAnnotationIntrospector().findTypeName(beanDesc.getClassInfo());
/*     */         }
/*  99 */         if (name == null)
/*     */         {
/* 101 */           name = _defaultTypeId(cls);
/*     */         }
/* 103 */         this._typeToId.put(key, name);
/*     */       }
/*     */     }
/* 106 */     return name;
/*     */   }
/*     */ 
/*     */   public String idFromValueAndType(Object value, Class<?> type)
/*     */   {
/* 112 */     return idFromValue(value);
/*     */   }
/*     */ 
/*     */   public JavaType typeFromId(String id)
/*     */     throws IllegalArgumentException
/*     */   {
/* 119 */     JavaType t = (JavaType)this._idToType.get(id);
/*     */ 
/* 125 */     return t;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 131 */     StringBuilder sb = new StringBuilder();
/* 132 */     sb.append('[').append(getClass().getName());
/* 133 */     sb.append("; id-to-type=").append(this._idToType);
/* 134 */     sb.append(']');
/* 135 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected static String _defaultTypeId(Class<?> cls)
/*     */   {
/* 150 */     String n = cls.getName();
/* 151 */     int ix = n.lastIndexOf('.');
/* 152 */     return ix < 0 ? n : n.substring(ix + 1);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.TypeNameIdResolver
 * JD-Core Version:    0.6.2
 */