/*    */ package org.codehaus.jackson.map.jsontype.impl;
/*    */ 
/*    */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.jsontype.TypeIdResolver;
/*    */ 
/*    */ public abstract class TypeSerializerBase extends TypeSerializer
/*    */ {
/*    */   protected final TypeIdResolver _idResolver;
/*    */   protected final BeanProperty _property;
/*    */ 
/*    */   protected TypeSerializerBase(TypeIdResolver idRes, BeanProperty property)
/*    */   {
/* 19 */     this._idResolver = idRes;
/* 20 */     this._property = property;
/*    */   }
/*    */ 
/*    */   public abstract JsonTypeInfo.As getTypeInclusion();
/*    */ 
/*    */   public String getPropertyName()
/*    */   {
/* 27 */     return null;
/*    */   }
/*    */   public TypeIdResolver getTypeIdResolver() {
/* 30 */     return this._idResolver;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.jsontype.impl.TypeSerializerBase
 * JD-Core Version:    0.6.2
 */