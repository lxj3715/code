/*    */ package org.codehaus.jackson.map.module;
/*    */ 
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.util.HashMap;
/*    */ import org.codehaus.jackson.map.AbstractTypeResolver;
/*    */ import org.codehaus.jackson.map.DeserializationConfig;
/*    */ import org.codehaus.jackson.map.type.ClassKey;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class SimpleAbstractTypeResolver extends AbstractTypeResolver
/*    */ {
/* 35 */   protected final HashMap<ClassKey, Class<?>> _mappings = new HashMap();
/*    */ 
/*    */   public <T> SimpleAbstractTypeResolver addMapping(Class<T> superType, Class<? extends T> subType)
/*    */   {
/* 52 */     if (superType == subType) {
/* 53 */       throw new IllegalArgumentException("Can not add mapping from class to itself");
/*    */     }
/* 55 */     if (!superType.isAssignableFrom(subType)) {
/* 56 */       throw new IllegalArgumentException("Can not add mapping from class " + superType.getName() + " to " + subType.getName() + ", as latter is not a subtype of former");
/*    */     }
/*    */ 
/* 59 */     if (!Modifier.isAbstract(superType.getModifiers())) {
/* 60 */       throw new IllegalArgumentException("Can not add mapping from class " + superType.getName() + " since it is not abstract");
/*    */     }
/*    */ 
/* 63 */     this._mappings.put(new ClassKey(superType), subType);
/* 64 */     return this;
/*    */   }
/*    */ 
/*    */   public JavaType findTypeMapping(DeserializationConfig config, JavaType type)
/*    */   {
/* 71 */     Class src = type.getRawClass();
/* 72 */     Class dst = (Class)this._mappings.get(new ClassKey(src));
/* 73 */     if (dst == null) {
/* 74 */       return null;
/*    */     }
/* 76 */     return type.narrowBy(dst);
/*    */   }
/*    */ 
/*    */   public JavaType resolveAbstractType(DeserializationConfig config, JavaType type)
/*    */   {
/* 84 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.module.SimpleAbstractTypeResolver
 * JD-Core Version:    0.6.2
 */