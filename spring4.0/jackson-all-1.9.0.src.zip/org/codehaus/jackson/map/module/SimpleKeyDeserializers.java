/*    */ package org.codehaus.jackson.map.module;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import org.codehaus.jackson.map.BeanDescription;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.DeserializationConfig;
/*    */ import org.codehaus.jackson.map.KeyDeserializer;
/*    */ import org.codehaus.jackson.map.KeyDeserializers;
/*    */ import org.codehaus.jackson.map.type.ClassKey;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class SimpleKeyDeserializers
/*    */   implements KeyDeserializers
/*    */ {
/* 25 */   protected HashMap<ClassKey, KeyDeserializer> _classMappings = null;
/*    */ 
/*    */   public SimpleKeyDeserializers addDeserializer(Class<?> forClass, KeyDeserializer deser)
/*    */   {
/* 37 */     if (this._classMappings == null) {
/* 38 */       this._classMappings = new HashMap();
/*    */     }
/* 40 */     this._classMappings.put(new ClassKey(forClass), deser);
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */   public KeyDeserializer findKeyDeserializer(JavaType type, DeserializationConfig config, BeanDescription beanDesc, BeanProperty property)
/*    */   {
/* 54 */     if (this._classMappings == null) {
/* 55 */       return null;
/*    */     }
/* 57 */     return (KeyDeserializer)this._classMappings.get(new ClassKey(type.getRawClass()));
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.module.SimpleKeyDeserializers
 * JD-Core Version:    0.6.2
 */