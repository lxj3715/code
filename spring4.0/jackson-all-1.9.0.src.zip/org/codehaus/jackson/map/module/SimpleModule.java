/*     */ package org.codehaus.jackson.map.module;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import org.codehaus.jackson.Version;
/*     */ import org.codehaus.jackson.map.JsonDeserializer;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.KeyDeserializer;
/*     */ import org.codehaus.jackson.map.Module;
/*     */ import org.codehaus.jackson.map.Module.SetupContext;
/*     */ import org.codehaus.jackson.map.deser.ValueInstantiator;
/*     */ 
/*     */ public class SimpleModule extends Module
/*     */ {
/*     */   protected final String _name;
/*     */   protected final Version _version;
/*  22 */   protected SimpleSerializers _serializers = null;
/*  23 */   protected SimpleDeserializers _deserializers = null;
/*     */ 
/*  25 */   protected SimpleSerializers _keySerializers = null;
/*  26 */   protected SimpleKeyDeserializers _keyDeserializers = null;
/*     */ 
/*  33 */   protected SimpleAbstractTypeResolver _abstractTypes = null;
/*     */ 
/*  40 */   protected SimpleValueInstantiators _valueInstantiators = null;
/*     */ 
/*  48 */   protected HashMap<Class<?>, Class<?>> _mixins = null;
/*     */ 
/*     */   public SimpleModule(String name, Version version)
/*     */   {
/*  58 */     this._name = name;
/*  59 */     this._version = version;
/*     */   }
/*     */ 
/*     */   public void setSerializers(SimpleSerializers s)
/*     */   {
/*  74 */     this._serializers = s;
/*     */   }
/*     */ 
/*     */   public void setDeserializers(SimpleDeserializers d)
/*     */   {
/*  83 */     this._deserializers = d;
/*     */   }
/*     */ 
/*     */   public void setKeySerializers(SimpleSerializers ks)
/*     */   {
/*  92 */     this._keySerializers = ks;
/*     */   }
/*     */ 
/*     */   public void setKeyDeserializers(SimpleKeyDeserializers kd)
/*     */   {
/* 101 */     this._keyDeserializers = kd;
/*     */   }
/*     */ 
/*     */   public void setAbstractTypes(SimpleAbstractTypeResolver atr)
/*     */   {
/* 110 */     this._abstractTypes = atr;
/*     */   }
/*     */ 
/*     */   public void setValueInstantiators(SimpleValueInstantiators svi)
/*     */   {
/* 119 */     this._valueInstantiators = svi;
/*     */   }
/*     */ 
/*     */   public SimpleModule addSerializer(JsonSerializer<?> ser)
/*     */   {
/* 130 */     if (this._serializers == null) {
/* 131 */       this._serializers = new SimpleSerializers();
/*     */     }
/* 133 */     this._serializers.addSerializer(ser);
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */   public <T> SimpleModule addSerializer(Class<? extends T> type, JsonSerializer<T> ser)
/*     */   {
/* 139 */     if (this._serializers == null) {
/* 140 */       this._serializers = new SimpleSerializers();
/*     */     }
/* 142 */     this._serializers.addSerializer(type, ser);
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */   public <T> SimpleModule addKeySerializer(Class<? extends T> type, JsonSerializer<T> ser)
/*     */   {
/* 148 */     if (this._keySerializers == null) {
/* 149 */       this._keySerializers = new SimpleSerializers();
/*     */     }
/* 151 */     this._keySerializers.addSerializer(type, ser);
/* 152 */     return this;
/*     */   }
/*     */ 
/*     */   public <T> SimpleModule addDeserializer(Class<T> type, JsonDeserializer<? extends T> deser)
/*     */   {
/* 157 */     if (this._deserializers == null) {
/* 158 */       this._deserializers = new SimpleDeserializers();
/*     */     }
/* 160 */     this._deserializers.addDeserializer(type, deser);
/* 161 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleModule addKeyDeserializer(Class<?> type, KeyDeserializer deser)
/*     */   {
/* 166 */     if (this._keyDeserializers == null) {
/* 167 */       this._keyDeserializers = new SimpleKeyDeserializers();
/*     */     }
/* 169 */     this._keyDeserializers.addDeserializer(type, deser);
/* 170 */     return this;
/*     */   }
/*     */ 
/*     */   public <T> SimpleModule addAbstractTypeMapping(Class<T> superType, Class<? extends T> subType)
/*     */   {
/* 181 */     if (this._abstractTypes == null) {
/* 182 */       this._abstractTypes = new SimpleAbstractTypeResolver();
/*     */     }
/*     */ 
/* 185 */     this._abstractTypes = this._abstractTypes.addMapping(superType, subType);
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleModule addValueInstantiator(Class<?> beanType, ValueInstantiator inst)
/*     */   {
/* 198 */     if (this._valueInstantiators == null) {
/* 199 */       this._valueInstantiators = new SimpleValueInstantiators();
/*     */     }
/* 201 */     this._valueInstantiators = this._valueInstantiators.addValueInstantiator(beanType, inst);
/* 202 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleModule setMixInAnnotation(Class<?> targetType, Class<?> mixinClass)
/*     */   {
/* 215 */     if (this._mixins == null) {
/* 216 */       this._mixins = new HashMap();
/*     */     }
/* 218 */     this._mixins.put(targetType, mixinClass);
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */   public String getModuleName()
/*     */   {
/* 230 */     return this._name;
/*     */   }
/*     */ 
/*     */   public void setupModule(Module.SetupContext context)
/*     */   {
/* 236 */     if (this._serializers != null) {
/* 237 */       context.addSerializers(this._serializers);
/*     */     }
/* 239 */     if (this._deserializers != null) {
/* 240 */       context.addDeserializers(this._deserializers);
/*     */     }
/* 242 */     if (this._keySerializers != null) {
/* 243 */       context.addKeySerializers(this._keySerializers);
/*     */     }
/* 245 */     if (this._keyDeserializers != null) {
/* 246 */       context.addKeyDeserializers(this._keyDeserializers);
/*     */     }
/* 248 */     if (this._abstractTypes != null) {
/* 249 */       context.addAbstractTypeResolver(this._abstractTypes);
/*     */     }
/* 251 */     if (this._valueInstantiators != null) {
/* 252 */       context.addValueInstantiators(this._valueInstantiators);
/*     */     }
/* 254 */     if (this._mixins != null)
/* 255 */       for (Map.Entry entry : this._mixins.entrySet())
/* 256 */         context.setMixInAnnotations((Class)entry.getKey(), (Class)entry.getValue());
/*     */   }
/*     */ 
/*     */   public Version version()
/*     */   {
/* 263 */     return this._version;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.module.SimpleModule
 * JD-Core Version:    0.6.2
 */