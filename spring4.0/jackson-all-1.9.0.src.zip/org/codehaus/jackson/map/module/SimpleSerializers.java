/*     */ package org.codehaus.jackson.map.module;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.map.BeanDescription;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.Serializers.Base;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.type.ArrayType;
/*     */ import org.codehaus.jackson.map.type.ClassKey;
/*     */ import org.codehaus.jackson.map.type.CollectionLikeType;
/*     */ import org.codehaus.jackson.map.type.CollectionType;
/*     */ import org.codehaus.jackson.map.type.MapLikeType;
/*     */ import org.codehaus.jackson.map.type.MapType;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class SimpleSerializers extends Serializers.Base
/*     */ {
/*  33 */   protected HashMap<ClassKey, JsonSerializer<?>> _classMappings = null;
/*     */ 
/*  38 */   protected HashMap<ClassKey, JsonSerializer<?>> _interfaceMappings = null;
/*     */ 
/*     */   public void addSerializer(JsonSerializer<?> ser)
/*     */   {
/*  60 */     Class cls = ser.handledType();
/*  61 */     if ((cls == null) || (cls == Object.class)) {
/*  62 */       throw new IllegalArgumentException("JsonSerializer of type " + ser.getClass().getName() + " does not define valid handledType() -- must either register with method that takes type argument " + " or make serializer extend 'org.codehaus.jackson.map.ser.std.SerializerBase'");
/*     */     }
/*     */ 
/*  66 */     _addSerializer(cls, ser);
/*     */   }
/*     */ 
/*     */   public <T> void addSerializer(Class<? extends T> type, JsonSerializer<T> ser)
/*     */   {
/*  71 */     _addSerializer(type, ser);
/*     */   }
/*     */ 
/*     */   private void _addSerializer(Class<?> cls, JsonSerializer<?> ser)
/*     */   {
/*  76 */     ClassKey key = new ClassKey(cls);
/*     */ 
/*  78 */     if (cls.isInterface()) {
/*  79 */       if (this._interfaceMappings == null) {
/*  80 */         this._interfaceMappings = new HashMap();
/*     */       }
/*  82 */       this._interfaceMappings.put(key, ser);
/*     */     } else {
/*  84 */       if (this._classMappings == null) {
/*  85 */         this._classMappings = new HashMap();
/*     */       }
/*  87 */       this._classMappings.put(key, ser);
/*     */     }
/*     */   }
/*     */ 
/*     */   public JsonSerializer<?> findSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc, BeanProperty property)
/*     */   {
/* 101 */     Class cls = type.getRawClass();
/* 102 */     ClassKey key = new ClassKey(cls);
/* 103 */     JsonSerializer ser = null;
/*     */ 
/* 106 */     if (cls.isInterface()) {
/* 107 */       if (this._interfaceMappings != null) {
/* 108 */         ser = (JsonSerializer)this._interfaceMappings.get(key);
/* 109 */         if (ser != null) {
/* 110 */           return ser;
/*     */         }
/*     */       }
/*     */     }
/* 114 */     else if (this._classMappings != null) {
/* 115 */       ser = (JsonSerializer)this._classMappings.get(key);
/* 116 */       if (ser != null) {
/* 117 */         return ser;
/*     */       }
/*     */ 
/* 120 */       for (Class curr = cls; curr != null; curr = curr.getSuperclass()) {
/* 121 */         key.reset(curr);
/* 122 */         ser = (JsonSerializer)this._classMappings.get(key);
/* 123 */         if (ser != null) {
/* 124 */           return ser;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 130 */     if (this._interfaceMappings != null) {
/* 131 */       ser = _findInterfaceMapping(cls, key);
/* 132 */       if (ser != null) {
/* 133 */         return ser;
/*     */       }
/*     */ 
/* 136 */       if (!cls.isInterface()) {
/* 137 */         while ((cls = cls.getSuperclass()) != null) {
/* 138 */           ser = _findInterfaceMapping(cls, key);
/* 139 */           if (ser != null) {
/* 140 */             return ser;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<?> findArraySerializer(SerializationConfig config, ArrayType type, BeanDescription beanDesc, BeanProperty property, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 152 */     return findSerializer(config, type, beanDesc, property);
/*     */   }
/*     */ 
/*     */   public JsonSerializer<?> findCollectionSerializer(SerializationConfig config, CollectionType type, BeanDescription beanDesc, BeanProperty property, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 159 */     return findSerializer(config, type, beanDesc, property);
/*     */   }
/*     */ 
/*     */   public JsonSerializer<?> findCollectionLikeSerializer(SerializationConfig config, CollectionLikeType type, BeanDescription beanDesc, BeanProperty property, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 166 */     return findSerializer(config, type, beanDesc, property);
/*     */   }
/*     */ 
/*     */   public JsonSerializer<?> findMapSerializer(SerializationConfig config, MapType type, BeanDescription beanDesc, BeanProperty property, JsonSerializer<Object> keySerializer, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 174 */     return findSerializer(config, type, beanDesc, property);
/*     */   }
/*     */ 
/*     */   public JsonSerializer<?> findMapLikeSerializer(SerializationConfig config, MapLikeType type, BeanDescription beanDesc, BeanProperty property, JsonSerializer<Object> keySerializer, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 182 */     return findSerializer(config, type, beanDesc, property);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> _findInterfaceMapping(Class<?> cls, ClassKey key)
/*     */   {
/* 193 */     for (Class iface : cls.getInterfaces()) {
/* 194 */       key.reset(iface);
/* 195 */       JsonSerializer ser = (JsonSerializer)this._interfaceMappings.get(key);
/* 196 */       if (ser != null) {
/* 197 */         return ser;
/*     */       }
/* 199 */       ser = _findInterfaceMapping(iface, key);
/* 200 */       if (ser != null) {
/* 201 */         return ser;
/*     */       }
/*     */     }
/* 204 */     return null;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.module.SimpleSerializers
 * JD-Core Version:    0.6.2
 */