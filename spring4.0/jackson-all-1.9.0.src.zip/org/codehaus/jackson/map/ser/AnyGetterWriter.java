/*    */ package org.codehaus.jackson.map.ser;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Map;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*    */ import org.codehaus.jackson.map.ser.std.MapSerializer;
/*    */ 
/*    */ public class AnyGetterWriter
/*    */ {
/*    */   protected final Method _anyGetter;
/*    */   protected final MapSerializer _serializer;
/*    */ 
/*    */   public AnyGetterWriter(AnnotatedMethod anyGetter, MapSerializer serializer)
/*    */   {
/* 26 */     this._anyGetter = anyGetter.getAnnotated();
/* 27 */     this._serializer = serializer;
/*    */   }
/*    */ 
/*    */   public void getAndSerialize(Object bean, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws Exception
/*    */   {
/* 33 */     Object value = this._anyGetter.invoke(bean, new Object[0]);
/* 34 */     if (value == null) {
/* 35 */       return;
/*    */     }
/* 37 */     if (!(value instanceof Map)) {
/* 38 */       throw new JsonMappingException("Value returned by 'any-getter' (" + this._anyGetter.getName() + "()) not java.util.Map but " + value.getClass().getName());
/*    */     }
/*    */ 
/* 41 */     this._serializer.serializeFields((Map)value, jgen, provider);
/*    */   }
/*    */ 
/*    */   public void resolve(SerializerProvider provider) throws JsonMappingException
/*    */   {
/* 46 */     this._serializer.resolve(provider);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.AnyGetterWriter
 * JD-Core Version:    0.6.2
 */