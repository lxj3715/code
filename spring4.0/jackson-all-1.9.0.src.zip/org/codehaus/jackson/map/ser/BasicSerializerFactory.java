/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.InetAddress;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.RandomAccess;
/*     */ import java.util.TimeZone;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.ContextualSerializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializable;
/*     */ import org.codehaus.jackson.map.JsonSerializableWithType;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.JsonSerializer.None;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.SerializerFactory;
/*     */ import org.codehaus.jackson.map.Serializers;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Typing;
/*     */ import org.codehaus.jackson.map.ext.OptionalHandlerFactory;
/*     */ import org.codehaus.jackson.map.introspect.Annotated;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*     */ import org.codehaus.jackson.map.jsontype.SubtypeResolver;
/*     */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*     */ import org.codehaus.jackson.map.ser.std.CalendarSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.DateSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.EnumMapSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.EnumSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.IndexedStringListSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.InetAddressSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.JsonValueSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.MapSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.NullSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.ObjectArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.SerializableSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.SerializableWithTypeSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.BooleanArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.ByteArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.CharArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.DoubleArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.FloatArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.IntArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.LongArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.ShortArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdArraySerializers.StringArraySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdContainerSerializers;
/*     */ import org.codehaus.jackson.map.ser.std.StdJdkSerializers;
/*     */ import org.codehaus.jackson.map.ser.std.StringCollectionSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StringSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.TimeZoneSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.ToStringSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.TokenBufferSerializer;
/*     */ import org.codehaus.jackson.map.type.ArrayType;
/*     */ import org.codehaus.jackson.map.type.CollectionLikeType;
/*     */ import org.codehaus.jackson.map.type.CollectionType;
/*     */ import org.codehaus.jackson.map.type.MapLikeType;
/*     */ import org.codehaus.jackson.map.type.MapType;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.map.util.EnumValues;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.codehaus.jackson.util.TokenBuffer;
/*     */ 
/*     */ public abstract class BasicSerializerFactory extends SerializerFactory
/*     */ {
/*  65 */   protected static final HashMap<String, JsonSerializer<?>> _concrete = new HashMap();
/*     */ 
/*  75 */   protected static final HashMap<String, Class<? extends JsonSerializer<?>>> _concreteLazy = new HashMap();
/*     */   protected static final HashMap<String, JsonSerializer<?>> _arraySerializers;
/* 160 */   protected OptionalHandlerFactory optionalHandlers = OptionalHandlerFactory.instance;
/*     */ 
/*     */   public abstract JsonSerializer<Object> createSerializer(SerializationConfig paramSerializationConfig, JavaType paramJavaType, BeanProperty paramBeanProperty)
/*     */     throws JsonMappingException;
/*     */ 
/*     */   public TypeSerializer createTypeSerializer(SerializationConfig config, JavaType baseType, BeanProperty property)
/*     */   {
/* 196 */     BasicBeanDescription bean = (BasicBeanDescription)config.introspectClassAnnotations(baseType.getRawClass());
/* 197 */     AnnotatedClass ac = bean.getClassInfo();
/* 198 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 199 */     TypeResolverBuilder b = ai.findTypeResolver(config, ac, baseType);
/*     */ 
/* 203 */     Collection subtypes = null;
/* 204 */     if (b == null)
/* 205 */       b = config.getDefaultTyper(baseType);
/*     */     else {
/* 207 */       subtypes = config.getSubtypeResolver().collectAndResolveSubtypes(ac, config, ai);
/*     */     }
/* 209 */     return b == null ? null : b.buildTypeSerializer(config, baseType, subtypes, property);
/*     */   }
/*     */ 
/*     */   public final JsonSerializer<?> getNullSerializer()
/*     */   {
/* 220 */     return NullSerializer.instance;
/*     */   }
/*     */ 
/*     */   protected abstract Iterable<Serializers> customSerializers();
/*     */ 
/*     */   public final JsonSerializer<?> findSerializerByLookup(JavaType type, SerializationConfig config, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping)
/*     */   {
/* 239 */     Class raw = type.getRawClass();
/* 240 */     String clsName = raw.getName();
/* 241 */     JsonSerializer ser = (JsonSerializer)_concrete.get(clsName);
/* 242 */     if (ser != null) {
/* 243 */       return ser;
/*     */     }
/* 245 */     Class serClass = (Class)_concreteLazy.get(clsName);
/* 246 */     if (serClass != null) {
/*     */       try {
/* 248 */         return (JsonSerializer)serClass.newInstance();
/*     */       } catch (Exception e) {
/* 250 */         throw new IllegalStateException("Failed to instantiate standard serializer (of type " + serClass.getName() + "): " + e.getMessage(), e);
/*     */       }
/*     */     }
/*     */ 
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   public final JsonSerializer<?> findSerializerByPrimaryType(JavaType type, SerializationConfig config, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping)
/*     */     throws JsonMappingException
/*     */   {
/* 270 */     Class raw = type.getRawClass();
/*     */ 
/* 272 */     if (JsonSerializable.class.isAssignableFrom(raw)) {
/* 273 */       if (JsonSerializableWithType.class.isAssignableFrom(raw)) {
/* 274 */         return SerializableWithTypeSerializer.instance;
/*     */       }
/* 276 */       return SerializableSerializer.instance;
/*     */     }
/*     */ 
/* 279 */     AnnotatedMethod valueMethod = beanDesc.findJsonValueMethod();
/* 280 */     if (valueMethod != null)
/*     */     {
/* 282 */       Method m = valueMethod.getAnnotated();
/* 283 */       if (config.isEnabled(SerializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 284 */         ClassUtil.checkAndFixAccess(m);
/*     */       }
/* 286 */       JsonSerializer ser = findSerializerFromAnnotation(config, valueMethod, property);
/* 287 */       return new JsonValueSerializer(m, ser, property);
/*     */     }
/*     */ 
/* 291 */     if (InetAddress.class.isAssignableFrom(raw)) {
/* 292 */       return InetAddressSerializer.instance;
/*     */     }
/*     */ 
/* 295 */     if (TimeZone.class.isAssignableFrom(raw)) {
/* 296 */       return TimeZoneSerializer.instance;
/*     */     }
/*     */ 
/* 300 */     JsonSerializer ser = this.optionalHandlers.findSerializer(config, type);
/* 301 */     if (ser != null) {
/* 302 */       return ser;
/*     */     }
/*     */ 
/* 305 */     if (Number.class.isAssignableFrom(raw)) {
/* 306 */       return StdSerializers.NumberSerializer.instance;
/*     */     }
/* 308 */     if (Enum.class.isAssignableFrom(raw))
/*     */     {
/* 310 */       Class enumClass = raw;
/* 311 */       return EnumSerializer.construct(enumClass, config, beanDesc);
/*     */     }
/* 313 */     if (Calendar.class.isAssignableFrom(raw)) {
/* 314 */       return CalendarSerializer.instance;
/*     */     }
/* 316 */     if (java.util.Date.class.isAssignableFrom(raw)) {
/* 317 */       return DateSerializer.instance;
/*     */     }
/* 319 */     return null;
/*     */   }
/*     */ 
/*     */   public final JsonSerializer<?> findSerializerByAddonType(SerializationConfig config, JavaType javaType, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping)
/*     */     throws JsonMappingException
/*     */   {
/* 335 */     Class type = javaType.getRawClass();
/*     */ 
/* 338 */     if (Iterator.class.isAssignableFrom(type)) {
/* 339 */       return buildIteratorSerializer(config, javaType, beanDesc, property, staticTyping);
/*     */     }
/* 341 */     if (Iterable.class.isAssignableFrom(type)) {
/* 342 */       return buildIterableSerializer(config, javaType, beanDesc, property, staticTyping);
/*     */     }
/* 344 */     if (CharSequence.class.isAssignableFrom(type)) {
/* 345 */       return ToStringSerializer.instance;
/*     */     }
/* 347 */     return null;
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<Object> findSerializerFromAnnotation(SerializationConfig config, Annotated a, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 362 */     Object serDef = config.getAnnotationIntrospector().findSerializer(a);
/* 363 */     if (serDef == null) {
/* 364 */       return null;
/*     */     }
/* 366 */     if ((serDef instanceof JsonSerializer)) {
/* 367 */       JsonSerializer ser = (JsonSerializer)serDef;
/* 368 */       if ((ser instanceof ContextualSerializer)) {
/* 369 */         return ((ContextualSerializer)ser).createContextual(config, property);
/*     */       }
/* 371 */       return ser;
/*     */     }
/*     */ 
/* 376 */     if (!(serDef instanceof Class)) {
/* 377 */       throw new IllegalStateException("AnnotationIntrospector returned value of type " + serDef.getClass().getName() + "; expected type JsonSerializer or Class<JsonSerializer> instead");
/*     */     }
/* 379 */     Class cls = (Class)serDef;
/* 380 */     if (!JsonSerializer.class.isAssignableFrom(cls)) {
/* 381 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + cls.getName() + "; expected Class<JsonSerializer>");
/*     */     }
/* 383 */     JsonSerializer ser = config.serializerInstance(a, cls);
/* 384 */     if ((ser instanceof ContextualSerializer)) {
/* 385 */       return ((ContextualSerializer)ser).createContextual(config, property);
/*     */     }
/* 387 */     return ser;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<?> buildContainerSerializer(SerializationConfig config, JavaType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping)
/*     */   {
/* 400 */     JavaType elementType = type.getContentType();
/* 401 */     TypeSerializer elementTypeSerializer = createTypeSerializer(config, elementType, property);
/*     */ 
/* 404 */     if (elementTypeSerializer != null)
/* 405 */       staticTyping = false;
/* 406 */     else if (!staticTyping) {
/* 407 */       staticTyping = usesStaticTyping(config, beanDesc, elementTypeSerializer, property);
/*     */     }
/* 409 */     JsonSerializer elementValueSerializer = findContentSerializer(config, beanDesc.getClassInfo(), property);
/*     */ 
/* 412 */     if (type.isMapLikeType()) {
/* 413 */       MapLikeType mlt = (MapLikeType)type;
/* 414 */       JsonSerializer keySerializer = findKeySerializer(config, beanDesc.getClassInfo(), property);
/* 415 */       if (mlt.isTrueMapType()) {
/* 416 */         return buildMapSerializer(config, (MapType)mlt, beanDesc, property, staticTyping, keySerializer, elementTypeSerializer, elementValueSerializer);
/*     */       }
/*     */ 
/* 419 */       return buildMapLikeSerializer(config, mlt, beanDesc, property, staticTyping, keySerializer, elementTypeSerializer, elementValueSerializer);
/*     */     }
/*     */ 
/* 422 */     if (type.isCollectionLikeType()) {
/* 423 */       CollectionLikeType clt = (CollectionLikeType)type;
/* 424 */       if (clt.isTrueCollectionType()) {
/* 425 */         return buildCollectionSerializer(config, (CollectionType)clt, beanDesc, property, staticTyping, elementTypeSerializer, elementValueSerializer);
/*     */       }
/*     */ 
/* 428 */       return buildCollectionLikeSerializer(config, clt, beanDesc, property, staticTyping, elementTypeSerializer, elementValueSerializer);
/*     */     }
/*     */ 
/* 431 */     if (type.isArrayType()) {
/* 432 */       return buildArraySerializer(config, (ArrayType)type, beanDesc, property, staticTyping, elementTypeSerializer, elementValueSerializer);
/*     */     }
/*     */ 
/* 435 */     return null;
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildCollectionLikeSerializer(SerializationConfig config, CollectionLikeType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 450 */     for (Serializers serializers : customSerializers()) {
/* 451 */       JsonSerializer ser = serializers.findCollectionLikeSerializer(config, type, beanDesc, property, elementTypeSerializer, elementValueSerializer);
/*     */ 
/* 453 */       if (ser != null) {
/* 454 */         return ser;
/*     */       }
/*     */     }
/* 457 */     return null;
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildCollectionSerializer(SerializationConfig config, CollectionType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 473 */     for (Serializers serializers : customSerializers()) {
/* 474 */       JsonSerializer ser = serializers.findCollectionSerializer(config, type, beanDesc, property, elementTypeSerializer, elementValueSerializer);
/*     */ 
/* 476 */       if (ser != null) {
/* 477 */         return ser;
/*     */       }
/*     */     }
/* 480 */     Class raw = type.getRawClass();
/* 481 */     if (EnumSet.class.isAssignableFrom(raw)) {
/* 482 */       return buildEnumSetSerializer(config, type, beanDesc, property, staticTyping, elementTypeSerializer, elementValueSerializer);
/*     */     }
/*     */ 
/* 485 */     Class elementRaw = type.getContentType().getRawClass();
/* 486 */     if (isIndexedList(raw)) {
/* 487 */       if (elementRaw == String.class) {
/* 488 */         return new IndexedStringListSerializer(property);
/*     */       }
/* 490 */       return StdContainerSerializers.indexedListSerializer(type.getContentType(), staticTyping, elementTypeSerializer, property, elementValueSerializer);
/*     */     }
/*     */ 
/* 493 */     if (elementRaw == String.class) {
/* 494 */       return new StringCollectionSerializer(property);
/*     */     }
/* 496 */     return StdContainerSerializers.collectionSerializer(type.getContentType(), staticTyping, elementTypeSerializer, property, elementValueSerializer);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildEnumSetSerializer(SerializationConfig config, JavaType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 506 */     JavaType enumType = type.getContentType();
/*     */ 
/* 508 */     if (!enumType.isEnumType()) {
/* 509 */       enumType = null;
/*     */     }
/* 511 */     return StdContainerSerializers.enumSetSerializer(enumType, property);
/*     */   }
/*     */ 
/*     */   protected boolean isIndexedList(Class<?> cls)
/*     */   {
/* 519 */     return RandomAccess.class.isAssignableFrom(cls);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildMapLikeSerializer(SerializationConfig config, MapLikeType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping, JsonSerializer<Object> keySerializer, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 541 */     for (Serializers serializers : customSerializers()) {
/* 542 */       JsonSerializer ser = serializers.findMapLikeSerializer(config, type, beanDesc, property, keySerializer, elementTypeSerializer, elementValueSerializer);
/*     */ 
/* 544 */       if (ser != null) {
/* 545 */         return ser;
/*     */       }
/*     */     }
/* 548 */     return null;
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildMapSerializer(SerializationConfig config, MapType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping, JsonSerializer<Object> keySerializer, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 563 */     for (Serializers serializers : customSerializers()) {
/* 564 */       JsonSerializer ser = serializers.findMapSerializer(config, type, beanDesc, property, keySerializer, elementTypeSerializer, elementValueSerializer);
/*     */ 
/* 566 */       if (ser != null) {
/* 567 */         return ser;
/*     */       }
/*     */     }
/* 570 */     if (EnumMap.class.isAssignableFrom(type.getRawClass())) {
/* 571 */       return buildEnumMapSerializer(config, type, beanDesc, property, staticTyping, elementTypeSerializer, elementValueSerializer);
/*     */     }
/*     */ 
/* 574 */     return MapSerializer.construct(config.getAnnotationIntrospector().findPropertiesToIgnore(beanDesc.getClassInfo()), type, staticTyping, elementTypeSerializer, property, keySerializer, elementValueSerializer);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildEnumMapSerializer(SerializationConfig config, JavaType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 590 */     JavaType keyType = type.getKeyType();
/*     */ 
/* 592 */     EnumValues enums = null;
/* 593 */     if (keyType.isEnumType())
/*     */     {
/* 595 */       Class enumClass = keyType.getRawClass();
/* 596 */       enums = EnumValues.construct(enumClass, config.getAnnotationIntrospector());
/*     */     }
/* 598 */     return new EnumMapSerializer(type.getContentType(), staticTyping, enums, elementTypeSerializer, property, elementValueSerializer);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildArraySerializer(SerializationConfig config, ArrayType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer)
/*     */   {
/* 617 */     Class raw = type.getRawClass();
/* 618 */     if ([Ljava.lang.String.class == raw) {
/* 619 */       return new StdArraySerializers.StringArraySerializer(property);
/*     */     }
/*     */ 
/* 622 */     JsonSerializer ser = (JsonSerializer)_arraySerializers.get(raw.getName());
/* 623 */     if (ser != null) {
/* 624 */       return ser;
/*     */     }
/* 626 */     return new ObjectArraySerializer(type.getContentType(), staticTyping, elementTypeSerializer, property, elementValueSerializer);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildIteratorSerializer(SerializationConfig config, JavaType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping)
/*     */   {
/* 641 */     JavaType valueType = type.containedType(0);
/* 642 */     if (valueType == null) {
/* 643 */       valueType = TypeFactory.unknownType();
/*     */     }
/* 645 */     TypeSerializer vts = createTypeSerializer(config, valueType, property);
/* 646 */     return StdContainerSerializers.iteratorSerializer(valueType, usesStaticTyping(config, beanDesc, vts, property), vts, property);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> buildIterableSerializer(SerializationConfig config, JavaType type, BasicBeanDescription beanDesc, BeanProperty property, boolean staticTyping)
/*     */   {
/* 655 */     JavaType valueType = type.containedType(0);
/* 656 */     if (valueType == null) {
/* 657 */       valueType = TypeFactory.unknownType();
/*     */     }
/* 659 */     TypeSerializer vts = createTypeSerializer(config, valueType, property);
/* 660 */     return StdContainerSerializers.iterableSerializer(valueType, usesStaticTyping(config, beanDesc, vts, property), vts, property);
/*     */   }
/*     */ 
/*     */   protected <T extends JavaType> T modifyTypeByAnnotation(SerializationConfig config, Annotated a, T type)
/*     */   {
/* 680 */     Class superclass = config.getAnnotationIntrospector().findSerializationType(a);
/* 681 */     if (superclass != null) {
/*     */       try {
/* 683 */         type = type.widenBy(superclass);
/*     */       } catch (IllegalArgumentException iae) {
/* 685 */         throw new IllegalArgumentException("Failed to widen type " + type + " with concrete-type annotation (value " + superclass.getName() + "), method '" + a.getName() + "': " + iae.getMessage());
/*     */       }
/*     */     }
/* 688 */     return modifySecondaryTypesByAnnotation(config, a, type);
/*     */   }
/*     */ 
/*     */   protected static <T extends JavaType> T modifySecondaryTypesByAnnotation(SerializationConfig config, Annotated a, T type)
/*     */   {
/* 697 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*     */ 
/* 699 */     if (type.isContainerType()) {
/* 700 */       Class keyClass = intr.findSerializationKeyType(a, type.getKeyType());
/* 701 */       if (keyClass != null)
/*     */       {
/* 703 */         if (!(type instanceof MapType))
/* 704 */           throw new IllegalArgumentException("Illegal key-type annotation: type " + type + " is not a Map type");
/*     */         try
/*     */         {
/* 707 */           type = ((MapType)type).widenKey(keyClass);
/*     */         } catch (IllegalArgumentException iae) {
/* 709 */           throw new IllegalArgumentException("Failed to narrow key type " + type + " with key-type annotation (" + keyClass.getName() + "): " + iae.getMessage());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 714 */       Class cc = intr.findSerializationContentType(a, type.getContentType());
/* 715 */       if (cc != null) {
/*     */         try {
/* 717 */           type = type.widenContentsBy(cc);
/*     */         } catch (IllegalArgumentException iae) {
/* 719 */           throw new IllegalArgumentException("Failed to narrow content type " + type + " with content-type annotation (" + cc.getName() + "): " + iae.getMessage());
/*     */         }
/*     */       }
/*     */     }
/* 723 */     return type;
/*     */   }
/*     */ 
/*     */   protected static JsonSerializer<Object> findKeySerializer(SerializationConfig config, Annotated a, BeanProperty property)
/*     */   {
/* 729 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 730 */     Class serClass = intr.findKeySerializer(a);
/* 731 */     if (((serClass == null) || (serClass == JsonSerializer.None.class)) && 
/* 732 */       (property != null)) {
/* 733 */       serClass = intr.findKeySerializer(property.getMember());
/*     */     }
/*     */ 
/* 736 */     if ((serClass != null) && (serClass != JsonSerializer.None.class)) {
/* 737 */       return config.serializerInstance(a, serClass);
/*     */     }
/* 739 */     return null;
/*     */   }
/*     */ 
/*     */   protected static JsonSerializer<Object> findContentSerializer(SerializationConfig config, Annotated a, BeanProperty property)
/*     */   {
/* 745 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 746 */     Class serClass = intr.findContentSerializer(a);
/* 747 */     if (((serClass == null) || (serClass == JsonSerializer.None.class)) && 
/* 748 */       (property != null)) {
/* 749 */       serClass = intr.findContentSerializer(property.getMember());
/*     */     }
/*     */ 
/* 752 */     if ((serClass != null) && (serClass != JsonSerializer.None.class)) {
/* 753 */       return config.serializerInstance(a, serClass);
/*     */     }
/* 755 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean usesStaticTyping(SerializationConfig config, BasicBeanDescription beanDesc, TypeSerializer typeSer, BeanProperty property)
/*     */   {
/* 770 */     if (typeSer != null) {
/* 771 */       return false;
/*     */     }
/* 773 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 774 */     JsonSerialize.Typing t = intr.findSerializationTyping(beanDesc.getClassInfo());
/* 775 */     if (t != null) {
/* 776 */       if (t == JsonSerialize.Typing.STATIC) {
/* 777 */         return true;
/*     */       }
/*     */     }
/* 780 */     else if (config.isEnabled(SerializationConfig.Feature.USE_STATIC_TYPING)) {
/* 781 */       return true;
/*     */     }
/*     */ 
/* 787 */     if (property != null) {
/* 788 */       JavaType type = property.getType();
/* 789 */       if (type.isContainerType()) {
/* 790 */         if (intr.findSerializationContentType(property.getMember(), property.getType()) != null) {
/* 791 */           return true;
/*     */         }
/* 793 */         if (((type instanceof MapType)) && 
/* 794 */           (intr.findSerializationKeyType(property.getMember(), property.getType()) != null)) {
/* 795 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 800 */     return false;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  82 */     _concrete.put(String.class.getName(), new StringSerializer());
/*  83 */     ToStringSerializer sls = ToStringSerializer.instance;
/*  84 */     _concrete.put(StringBuffer.class.getName(), sls);
/*  85 */     _concrete.put(StringBuilder.class.getName(), sls);
/*  86 */     _concrete.put(Character.class.getName(), sls);
/*  87 */     _concrete.put(Character.TYPE.getName(), sls);
/*     */ 
/*  90 */     _concrete.put(Boolean.TYPE.getName(), new StdSerializers.BooleanSerializer(true));
/*  91 */     _concrete.put(Boolean.class.getName(), new StdSerializers.BooleanSerializer(false));
/*  92 */     JsonSerializer intS = new StdSerializers.IntegerSerializer();
/*  93 */     _concrete.put(Integer.class.getName(), intS);
/*  94 */     _concrete.put(Integer.TYPE.getName(), intS);
/*  95 */     _concrete.put(Long.class.getName(), StdSerializers.LongSerializer.instance);
/*  96 */     _concrete.put(Long.TYPE.getName(), StdSerializers.LongSerializer.instance);
/*  97 */     _concrete.put(Byte.class.getName(), StdSerializers.IntLikeSerializer.instance);
/*  98 */     _concrete.put(Byte.TYPE.getName(), StdSerializers.IntLikeSerializer.instance);
/*  99 */     _concrete.put(Short.class.getName(), StdSerializers.IntLikeSerializer.instance);
/* 100 */     _concrete.put(Short.TYPE.getName(), StdSerializers.IntLikeSerializer.instance);
/*     */ 
/* 103 */     _concrete.put(Float.class.getName(), StdSerializers.FloatSerializer.instance);
/* 104 */     _concrete.put(Float.TYPE.getName(), StdSerializers.FloatSerializer.instance);
/* 105 */     _concrete.put(Double.class.getName(), StdSerializers.DoubleSerializer.instance);
/* 106 */     _concrete.put(Double.TYPE.getName(), StdSerializers.DoubleSerializer.instance);
/*     */ 
/* 109 */     JsonSerializer ns = new StdSerializers.NumberSerializer();
/* 110 */     _concrete.put(BigInteger.class.getName(), ns);
/* 111 */     _concrete.put(BigDecimal.class.getName(), ns);
/*     */ 
/* 115 */     _concrete.put(Calendar.class.getName(), CalendarSerializer.instance);
/* 116 */     DateSerializer dateSer = DateSerializer.instance;
/* 117 */     _concrete.put(java.util.Date.class.getName(), dateSer);
/*     */ 
/* 119 */     _concrete.put(Timestamp.class.getName(), dateSer);
/* 120 */     _concrete.put(java.sql.Date.class.getName(), new StdSerializers.SqlDateSerializer());
/* 121 */     _concrete.put(Time.class.getName(), new StdSerializers.SqlTimeSerializer());
/*     */ 
/* 124 */     for (Map.Entry en : new StdJdkSerializers().provide()) {
/* 125 */       Object value = en.getValue();
/* 126 */       if ((value instanceof JsonSerializer)) {
/* 127 */         _concrete.put(((Class)en.getKey()).getName(), (JsonSerializer)value);
/* 128 */       } else if ((value instanceof Class))
/*     */       {
/* 130 */         Class cls = (Class)value;
/* 131 */         _concreteLazy.put(((Class)en.getKey()).getName(), cls);
/*     */       } else {
/* 133 */         throw new IllegalStateException("Internal error: unrecognized value of type " + en.getClass().getName());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 139 */     _concreteLazy.put(TokenBuffer.class.getName(), TokenBufferSerializer.class);
/*     */ 
/* 142 */     _arraySerializers = new HashMap();
/*     */ 
/* 146 */     _arraySerializers.put([Z.class.getName(), new StdArraySerializers.BooleanArraySerializer());
/* 147 */     _arraySerializers.put([B.class.getName(), new StdArraySerializers.ByteArraySerializer());
/* 148 */     _arraySerializers.put([C.class.getName(), new StdArraySerializers.CharArraySerializer());
/* 149 */     _arraySerializers.put([S.class.getName(), new StdArraySerializers.ShortArraySerializer());
/* 150 */     _arraySerializers.put([I.class.getName(), new StdArraySerializers.IntArraySerializer());
/* 151 */     _arraySerializers.put([J.class.getName(), new StdArraySerializers.LongArraySerializer());
/* 152 */     _arraySerializers.put([F.class.getName(), new StdArraySerializers.FloatArraySerializer());
/* 153 */     _arraySerializers.put([D.class.getName(), new StdArraySerializers.DoubleArraySerializer());
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.BasicSerializerFactory
 * JD-Core Version:    0.6.2
 */