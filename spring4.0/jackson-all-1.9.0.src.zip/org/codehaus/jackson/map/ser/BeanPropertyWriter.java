/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.io.SerializedString;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap.SerializerAndMapResult;
/*     */ import org.codehaus.jackson.map.ser.impl.UnwrappingBeanPropertyWriter;
/*     */ import org.codehaus.jackson.map.util.Annotations;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class BeanPropertyWriter
/*     */   implements BeanProperty
/*     */ {
/*     */   protected final AnnotatedMember _member;
/*     */   protected final Annotations _contextAnnotations;
/*     */   protected final JavaType _declaredType;
/*     */   protected final Method _accessorMethod;
/*     */   protected final Field _field;
/*     */   protected HashMap<Object, Object> _internalSettings;
/*     */   protected final SerializedString _name;
/*     */   protected final JavaType _cfgSerializationType;
/*     */   protected final JsonSerializer<Object> _serializer;
/*     */   protected PropertySerializerMap _dynamicSerializers;
/*     */   protected final boolean _suppressNulls;
/*     */   protected final Object _suppressableValue;
/*     */   protected Class<?>[] _includeInViews;
/*     */   protected TypeSerializer _typeSerializer;
/*     */   protected JavaType _nonTrivialBaseType;
/*     */ 
/*     */   public BeanPropertyWriter(AnnotatedMember member, Annotations contextAnnotations, String name, JavaType declaredType, JsonSerializer<Object> ser, TypeSerializer typeSer, JavaType serType, Method m, Field f, boolean suppressNulls, Object suppressableValue)
/*     */   {
/* 167 */     this(member, contextAnnotations, new SerializedString(name), declaredType, ser, typeSer, serType, m, f, suppressNulls, suppressableValue);
/*     */   }
/*     */ 
/*     */   public BeanPropertyWriter(AnnotatedMember member, Annotations contextAnnotations, SerializedString name, JavaType declaredType, JsonSerializer<Object> ser, TypeSerializer typeSer, JavaType serType, Method m, Field f, boolean suppressNulls, Object suppressableValue)
/*     */   {
/* 177 */     this._member = member;
/* 178 */     this._contextAnnotations = contextAnnotations;
/* 179 */     this._name = name;
/* 180 */     this._declaredType = declaredType;
/* 181 */     this._serializer = ser;
/* 182 */     this._dynamicSerializers = (ser == null ? PropertySerializerMap.emptyMap() : null);
/* 183 */     this._typeSerializer = typeSer;
/* 184 */     this._cfgSerializationType = serType;
/* 185 */     this._accessorMethod = m;
/* 186 */     this._field = f;
/* 187 */     this._suppressNulls = suppressNulls;
/* 188 */     this._suppressableValue = suppressableValue;
/*     */   }
/*     */ 
/*     */   protected BeanPropertyWriter(BeanPropertyWriter base)
/*     */   {
/* 196 */     this(base, base._serializer);
/*     */   }
/*     */ 
/*     */   protected BeanPropertyWriter(BeanPropertyWriter base, JsonSerializer<Object> ser)
/*     */   {
/* 204 */     this._serializer = ser;
/*     */ 
/* 206 */     this._member = base._member;
/* 207 */     this._contextAnnotations = base._contextAnnotations;
/* 208 */     this._declaredType = base._declaredType;
/* 209 */     this._accessorMethod = base._accessorMethod;
/* 210 */     this._field = base._field;
/*     */ 
/* 212 */     if (base._internalSettings != null) {
/* 213 */       this._internalSettings = new HashMap(base._internalSettings);
/*     */     }
/* 215 */     this._name = base._name;
/* 216 */     this._cfgSerializationType = base._cfgSerializationType;
/* 217 */     this._dynamicSerializers = base._dynamicSerializers;
/* 218 */     this._suppressNulls = base._suppressNulls;
/* 219 */     this._suppressableValue = base._suppressableValue;
/* 220 */     this._includeInViews = base._includeInViews;
/* 221 */     this._typeSerializer = base._typeSerializer;
/* 222 */     this._nonTrivialBaseType = base._nonTrivialBaseType;
/*     */   }
/*     */ 
/*     */   public BeanPropertyWriter withSerializer(JsonSerializer<Object> ser)
/*     */   {
/* 233 */     if (getClass() != BeanPropertyWriter.class) {
/* 234 */       throw new IllegalStateException("BeanPropertyWriter sub-class does not override 'withSerializer()'; needs to!");
/*     */     }
/* 236 */     return new BeanPropertyWriter(this, ser);
/*     */   }
/*     */ 
/*     */   public BeanPropertyWriter unwrappingWriter()
/*     */   {
/* 246 */     return new UnwrappingBeanPropertyWriter(this);
/*     */   }
/*     */ 
/*     */   public void setViews(Class<?>[] views)
/*     */   {
/* 257 */     this._includeInViews = views;
/*     */   }
/*     */ 
/*     */   public void setNonTrivialBaseType(JavaType t)
/*     */   {
/* 267 */     this._nonTrivialBaseType = t;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 278 */     return this._name.getValue();
/*     */   }
/*     */ 
/*     */   public JavaType getType()
/*     */   {
/* 283 */     return this._declaredType;
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getAnnotation(Class<A> acls)
/*     */   {
/* 288 */     return this._member.getAnnotation(acls);
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getContextAnnotation(Class<A> acls)
/*     */   {
/* 293 */     return this._contextAnnotations.get(acls);
/*     */   }
/*     */ 
/*     */   public AnnotatedMember getMember()
/*     */   {
/* 298 */     return this._member;
/*     */   }
/*     */ 
/*     */   public Object getInternalSetting(Object key)
/*     */   {
/* 317 */     if (this._internalSettings == null) {
/* 318 */       return null;
/*     */     }
/* 320 */     return this._internalSettings.get(key);
/*     */   }
/*     */ 
/*     */   public Object setInternalSetting(Object key, Object value)
/*     */   {
/* 332 */     if (this._internalSettings == null) {
/* 333 */       this._internalSettings = new HashMap();
/*     */     }
/* 335 */     return this._internalSettings.put(key, value);
/*     */   }
/*     */ 
/*     */   public Object removeInternalSetting(Object key)
/*     */   {
/* 347 */     Object removed = null;
/* 348 */     if (this._internalSettings != null) {
/* 349 */       removed = this._internalSettings.remove(key);
/*     */ 
/* 351 */       if (this._internalSettings.size() == 0) {
/* 352 */         this._internalSettings = null;
/*     */       }
/*     */     }
/* 355 */     return removed;
/*     */   }
/*     */ 
/*     */   public SerializedString getSerializedName()
/*     */   {
/* 364 */     return this._name;
/*     */   }
/* 366 */   public boolean hasSerializer() { return this._serializer != null; }
/*     */ 
/*     */   public JsonSerializer<Object> getSerializer()
/*     */   {
/* 370 */     return this._serializer;
/*     */   }
/*     */ 
/*     */   public JavaType getSerializationType() {
/* 374 */     return this._cfgSerializationType;
/*     */   }
/*     */ 
/*     */   public Class<?> getRawSerializationType() {
/* 378 */     return this._cfgSerializationType == null ? null : this._cfgSerializationType.getRawClass();
/*     */   }
/*     */ 
/*     */   public Class<?> getPropertyType()
/*     */   {
/* 383 */     if (this._accessorMethod != null) {
/* 384 */       return this._accessorMethod.getReturnType();
/*     */     }
/* 386 */     return this._field.getType();
/*     */   }
/*     */ 
/*     */   public Type getGenericPropertyType()
/*     */   {
/* 396 */     if (this._accessorMethod != null) {
/* 397 */       return this._accessorMethod.getGenericReturnType();
/*     */     }
/* 399 */     return this._field.getGenericType();
/*     */   }
/*     */   public Class<?>[] getViews() {
/* 402 */     return this._includeInViews;
/*     */   }
/*     */ 
/*     */   public void serializeAsField(Object bean, JsonGenerator jgen, SerializerProvider prov)
/*     */     throws Exception
/*     */   {
/* 418 */     Object value = get(bean);
/*     */ 
/* 420 */     if (value == null) {
/* 421 */       if (!this._suppressNulls) {
/* 422 */         jgen.writeFieldName(this._name);
/* 423 */         prov.defaultSerializeNull(jgen);
/*     */       }
/* 425 */       return;
/*     */     }
/*     */ 
/* 428 */     if (value == bean) {
/* 429 */       _reportSelfReference(bean);
/*     */     }
/* 431 */     if ((this._suppressableValue != null) && (this._suppressableValue.equals(value))) {
/* 432 */       return;
/*     */     }
/*     */ 
/* 435 */     JsonSerializer ser = this._serializer;
/* 436 */     if (ser == null) {
/* 437 */       Class cls = value.getClass();
/* 438 */       PropertySerializerMap map = this._dynamicSerializers;
/* 439 */       ser = map.serializerFor(cls);
/* 440 */       if (ser == null) {
/* 441 */         ser = _findAndAddDynamic(map, cls, prov);
/*     */       }
/*     */     }
/* 444 */     jgen.writeFieldName(this._name);
/* 445 */     if (this._typeSerializer == null)
/* 446 */       ser.serialize(value, jgen, prov);
/*     */     else
/* 448 */       ser.serializeWithType(value, jgen, prov, this._typeSerializer);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/*     */     PropertySerializerMap.SerializerAndMapResult result;
/*     */     PropertySerializerMap.SerializerAndMapResult result;
/* 459 */     if (this._nonTrivialBaseType != null) {
/* 460 */       JavaType t = this._nonTrivialBaseType.forcedNarrowBy(type);
/* 461 */       result = map.findAndAddSerializer(t, provider, this);
/*     */     } else {
/* 463 */       result = map.findAndAddSerializer(type, provider, this);
/*     */     }
/*     */ 
/* 466 */     if (map != result.map) {
/* 467 */       this._dynamicSerializers = result.map;
/*     */     }
/* 469 */     return result.serializer;
/*     */   }
/*     */ 
/*     */   public final Object get(Object bean)
/*     */     throws Exception
/*     */   {
/* 482 */     if (this._accessorMethod != null) {
/* 483 */       return this._accessorMethod.invoke(bean, new Object[0]);
/*     */     }
/* 485 */     return this._field.get(bean);
/*     */   }
/*     */ 
/*     */   protected void _reportSelfReference(Object bean)
/*     */     throws JsonMappingException
/*     */   {
/* 491 */     throw new JsonMappingException("Direct self-reference leading to cycle");
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 497 */     StringBuilder sb = new StringBuilder(40);
/* 498 */     sb.append("property '").append(getName()).append("' (");
/* 499 */     if (this._accessorMethod != null)
/* 500 */       sb.append("via method ").append(this._accessorMethod.getDeclaringClass().getName()).append("#").append(this._accessorMethod.getName());
/*     */     else {
/* 502 */       sb.append("field \"").append(this._field.getDeclaringClass().getName()).append("#").append(this._field.getName());
/*     */     }
/* 504 */     if (this._serializer == null)
/* 505 */       sb.append(", no static serializer");
/*     */     else {
/* 507 */       sb.append(", static serializer of type " + this._serializer.getClass().getName());
/*     */     }
/* 509 */     sb.append(')');
/* 510 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.BeanPropertyWriter
 * JD-Core Version:    0.6.2
 */