/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.ser.impl.UnwrappingBeanSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.BeanSerializerBase;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class BeanSerializer extends BeanSerializerBase
/*     */ {
/*     */   public BeanSerializer(JavaType type, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties, AnyGetterWriter anyGetterWriter, Object filterId)
/*     */   {
/*  41 */     super(type, properties, filteredProperties, anyGetterWriter, filterId);
/*     */   }
/*     */ 
/*     */   public BeanSerializer(Class<?> rawType, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties, AnyGetterWriter anyGetterWriter, Object filterId)
/*     */   {
/*  49 */     super(rawType, properties, filteredProperties, anyGetterWriter, filterId);
/*     */   }
/*     */ 
/*     */   protected BeanSerializer(BeanSerializer src)
/*     */   {
/*  59 */     super(src);
/*     */   }
/*     */ 
/*     */   protected BeanSerializer(BeanSerializerBase src)
/*     */   {
/*  70 */     super(src);
/*     */   }
/*     */ 
/*     */   public static BeanSerializer createDummy(Class<?> forType)
/*     */   {
/*  85 */     return new BeanSerializer(forType, NO_PROPS, null, null, null);
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> unwrappingSerializer()
/*     */   {
/*  90 */     return new UnwrappingBeanSerializer(this);
/*     */   }
/*     */ 
/*     */   public final void serialize(Object bean, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 108 */     jgen.writeStartObject();
/* 109 */     if (this._propertyFilterId != null)
/* 110 */       serializeFieldsFiltered(bean, jgen, provider);
/*     */     else {
/* 112 */       serializeFields(bean, jgen, provider);
/*     */     }
/* 114 */     jgen.writeEndObject();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 124 */     return "BeanSerializer for " + handledType().getName();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.BeanSerializer
 * JD-Core Version:    0.6.2
 */