/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*     */ 
/*     */ public class BeanSerializerBuilder
/*     */ {
/*  19 */   private static final BeanPropertyWriter[] NO_PROPERTIES = new BeanPropertyWriter[0];
/*     */   protected final BasicBeanDescription _beanDesc;
/*     */   protected List<BeanPropertyWriter> _properties;
/*     */   protected BeanPropertyWriter[] _filteredProperties;
/*     */   protected AnyGetterWriter _anyGetter;
/*     */   protected Object _filterId;
/*     */ 
/*     */   public BeanSerializerBuilder(BasicBeanDescription beanDesc)
/*     */   {
/*  63 */     this._beanDesc = beanDesc;
/*     */   }
/*     */ 
/*     */   protected BeanSerializerBuilder(BeanSerializerBuilder src)
/*     */   {
/*  70 */     this._beanDesc = src._beanDesc;
/*  71 */     this._properties = src._properties;
/*  72 */     this._filteredProperties = src._filteredProperties;
/*  73 */     this._anyGetter = src._anyGetter;
/*  74 */     this._filterId = src._filterId;
/*     */   }
/*     */   public BasicBeanDescription getBeanDescription() {
/*  77 */     return this._beanDesc; } 
/*  78 */   public List<BeanPropertyWriter> getProperties() { return this._properties; } 
/*  79 */   public BeanPropertyWriter[] getFilteredProperties() { return this._filteredProperties; }
/*     */ 
/*     */ 
/*     */   public boolean hasProperties()
/*     */   {
/*  85 */     return (this._properties != null) && (this._properties.size() > 0);
/*     */   }
/*     */ 
/*     */   public void setProperties(List<BeanPropertyWriter> properties) {
/*  89 */     this._properties = properties;
/*     */   }
/*     */ 
/*     */   public void setFilteredProperties(BeanPropertyWriter[] properties) {
/*  93 */     this._filteredProperties = properties;
/*     */   }
/*     */ 
/*     */   public void setAnyGetter(AnyGetterWriter anyGetter) {
/*  97 */     this._anyGetter = anyGetter;
/*     */   }
/*     */ 
/*     */   public void setFilterId(Object filterId) {
/* 101 */     this._filterId = filterId;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<?> build()
/*     */   {
/*     */     BeanPropertyWriter[] properties;
/*     */     BeanPropertyWriter[] properties;
/* 119 */     if ((this._properties == null) || (this._properties.isEmpty())) {
/* 120 */       if (this._anyGetter == null) {
/* 121 */         return null;
/*     */       }
/* 123 */       properties = NO_PROPERTIES;
/*     */     } else {
/* 125 */       properties = (BeanPropertyWriter[])this._properties.toArray(new BeanPropertyWriter[this._properties.size()]);
/*     */     }
/*     */ 
/* 128 */     return new BeanSerializer(this._beanDesc.getType(), properties, this._filteredProperties, this._anyGetter, this._filterId);
/*     */   }
/*     */ 
/*     */   public BeanSerializer createDummy()
/*     */   {
/* 137 */     return BeanSerializer.createDummy(this._beanDesc.getBeanClass());
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.BeanSerializerBuilder
 * JD-Core Version:    0.6.2
 */