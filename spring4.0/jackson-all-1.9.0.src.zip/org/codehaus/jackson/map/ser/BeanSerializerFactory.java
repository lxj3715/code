/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector.ReferenceProperty;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.BeanProperty.Std;
/*     */ import org.codehaus.jackson.map.BeanPropertyDefinition;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.SerializerFactory;
/*     */ import org.codehaus.jackson.map.SerializerFactory.Config;
/*     */ import org.codehaus.jackson.map.Serializers;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*     */ import org.codehaus.jackson.map.jsontype.SubtypeResolver;
/*     */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*     */ import org.codehaus.jackson.map.ser.std.MapSerializer;
/*     */ import org.codehaus.jackson.map.type.TypeBindings;
/*     */ import org.codehaus.jackson.map.util.ArrayBuilders;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class BeanSerializerFactory extends BasicSerializerFactory
/*     */ {
/*  56 */   public static final BeanSerializerFactory instance = new BeanSerializerFactory(null);
/*     */   protected final SerializerFactory.Config _factoryConfig;
/*     */ 
/*     */   protected BeanSerializerFactory(SerializerFactory.Config config)
/*     */   {
/* 187 */     if (config == null) {
/* 188 */       config = new ConfigImpl();
/*     */     }
/* 190 */     this._factoryConfig = config;
/*     */   }
/*     */   public SerializerFactory.Config getConfig() {
/* 193 */     return this._factoryConfig;
/*     */   }
/*     */ 
/*     */   public SerializerFactory withConfig(SerializerFactory.Config config)
/*     */   {
/* 206 */     if (this._factoryConfig == config) {
/* 207 */       return this;
/*     */     }
/*     */ 
/* 215 */     if (getClass() != BeanSerializerFactory.class) {
/* 216 */       throw new IllegalStateException("Subtype of BeanSerializerFactory (" + getClass().getName() + ") has not properly overridden method 'withAdditionalSerializers': can not instantiate subtype with " + "additional serializer definitions");
/*     */     }
/*     */ 
/* 220 */     return new BeanSerializerFactory(config);
/*     */   }
/*     */ 
/*     */   protected Iterable<Serializers> customSerializers()
/*     */   {
/* 225 */     return this._factoryConfig.serializers();
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> createSerializer(SerializationConfig config, JavaType origType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 251 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspect(origType);
/* 252 */     JsonSerializer ser = findSerializerFromAnnotation(config, beanDesc.getClassInfo(), property);
/* 253 */     if (ser != null) {
/* 254 */       return ser;
/*     */     }
/*     */ 
/* 258 */     JavaType type = modifyTypeByAnnotation(config, beanDesc.getClassInfo(), origType);
/*     */ 
/* 260 */     boolean staticTyping = type != origType;
/*     */ 
/* 263 */     if (origType.isContainerType()) {
/* 264 */       return buildContainerSerializer(config, type, beanDesc, property, staticTyping);
/*     */     }
/*     */ 
/* 268 */     for (Serializers serializers : this._factoryConfig.serializers()) {
/* 269 */       ser = serializers.findSerializer(config, type, beanDesc, property);
/* 270 */       if (ser != null) {
/* 271 */         return ser;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 279 */     ser = findSerializerByLookup(type, config, beanDesc, property, staticTyping);
/* 280 */     if (ser == null) {
/* 281 */       ser = findSerializerByPrimaryType(type, config, beanDesc, property, staticTyping);
/* 282 */       if (ser == null)
/*     */       {
/* 287 */         ser = findBeanSerializer(config, type, beanDesc, property);
/*     */ 
/* 291 */         if (ser == null) {
/* 292 */           ser = findSerializerByAddonType(config, type, beanDesc, property, staticTyping);
/*     */         }
/*     */       }
/*     */     }
/* 296 */     return ser;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> createKeySerializer(SerializationConfig config, JavaType type, BeanProperty property)
/*     */   {
/* 305 */     if (!this._factoryConfig.hasKeySerializers()) {
/* 306 */       return null;
/*     */     }
/*     */ 
/* 310 */     BasicBeanDescription beanDesc = (BasicBeanDescription)config.introspectClassAnnotations(type.getRawClass());
/* 311 */     JsonSerializer ser = null;
/*     */ 
/* 314 */     for (Serializers serializers : this._factoryConfig.keySerializers()) {
/* 315 */       ser = serializers.findSerializer(config, type, beanDesc, property);
/* 316 */       if (ser != null) {
/*     */         break;
/*     */       }
/*     */     }
/* 320 */     return ser;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> findBeanSerializer(SerializationConfig config, JavaType type, BasicBeanDescription beanDesc, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 340 */     if (!isPotentialBeanType(type.getRawClass())) {
/* 341 */       return null;
/*     */     }
/* 343 */     JsonSerializer serializer = constructBeanSerializer(config, beanDesc, property);
/*     */ 
/* 345 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 346 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 347 */         serializer = mod.modifySerializer(config, beanDesc, serializer);
/*     */       }
/*     */     }
/* 350 */     return serializer;
/*     */   }
/*     */ 
/*     */   public TypeSerializer findPropertyTypeSerializer(JavaType baseType, SerializationConfig config, AnnotatedMember accessor, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 369 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 370 */     TypeResolverBuilder b = ai.findPropertyTypeResolver(config, accessor, baseType);
/*     */ 
/* 372 */     if (b == null) {
/* 373 */       return createTypeSerializer(config, baseType, property);
/*     */     }
/* 375 */     Collection subtypes = config.getSubtypeResolver().collectAndResolveSubtypes(accessor, config, ai);
/* 376 */     return b.buildTypeSerializer(config, baseType, subtypes, property);
/*     */   }
/*     */ 
/*     */   public TypeSerializer findPropertyContentTypeSerializer(JavaType containerType, SerializationConfig config, AnnotatedMember accessor, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 395 */     JavaType contentType = containerType.getContentType();
/* 396 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 397 */     TypeResolverBuilder b = ai.findPropertyContentTypeResolver(config, accessor, containerType);
/*     */ 
/* 399 */     if (b == null) {
/* 400 */       return createTypeSerializer(config, contentType, property);
/*     */     }
/* 402 */     Collection subtypes = config.getSubtypeResolver().collectAndResolveSubtypes(accessor, config, ai);
/* 403 */     return b.buildTypeSerializer(config, contentType, subtypes, property);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<Object> constructBeanSerializer(SerializationConfig config, BasicBeanDescription beanDesc, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 423 */     if (beanDesc.getBeanClass() == Object.class) {
/* 424 */       throw new IllegalArgumentException("Can not create bean serializer for Object.class");
/*     */     }
/*     */ 
/* 427 */     BeanSerializerBuilder builder = constructBeanSerializerBuilder(beanDesc);
/*     */ 
/* 430 */     List props = findBeanProperties(config, beanDesc);
/* 431 */     AnnotatedMethod anyGetter = beanDesc.findAnyGetter();
/*     */ 
/* 433 */     if (props == null) {
/* 434 */       props = new ArrayList();
/*     */     }
/*     */ 
/* 437 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 438 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 439 */         props = mod.changeProperties(config, beanDesc, props);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 444 */     props = filterBeanProperties(config, beanDesc, props);
/*     */ 
/* 446 */     props = sortBeanProperties(config, beanDesc, props);
/*     */ 
/* 449 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 450 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 451 */         props = mod.orderProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */ 
/* 455 */     builder.setProperties(props);
/* 456 */     builder.setFilterId(findFilterId(config, beanDesc));
/*     */ 
/* 458 */     if (anyGetter != null) {
/* 459 */       JavaType type = anyGetter.getType(beanDesc.bindingsForBeanType());
/*     */ 
/* 461 */       boolean staticTyping = config.isEnabled(SerializationConfig.Feature.USE_STATIC_TYPING);
/* 462 */       JavaType valueType = type.getContentType();
/* 463 */       TypeSerializer typeSer = createTypeSerializer(config, valueType, property);
/*     */ 
/* 465 */       MapSerializer mapSer = MapSerializer.construct(null, type, staticTyping, typeSer, property, null, null);
/*     */ 
/* 467 */       builder.setAnyGetter(new AnyGetterWriter(anyGetter, mapSer));
/*     */     }
/*     */ 
/* 470 */     processViews(config, builder);
/*     */ 
/* 472 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 473 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 474 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*     */       }
/*     */     }
/* 477 */     JsonSerializer ser = builder.build();
/*     */ 
/* 482 */     if (ser == null)
/*     */     {
/* 487 */       if (beanDesc.hasKnownClassAnnotations()) {
/* 488 */         return builder.createDummy();
/*     */       }
/*     */     }
/* 491 */     return ser;
/*     */   }
/*     */ 
/*     */   protected BeanPropertyWriter constructFilteredBeanWriter(BeanPropertyWriter writer, Class<?>[] inViews)
/*     */   {
/* 501 */     return FilteredBeanPropertyWriter.constructViewBased(writer, inViews);
/*     */   }
/*     */ 
/*     */   protected PropertyBuilder constructPropertyBuilder(SerializationConfig config, BasicBeanDescription beanDesc)
/*     */   {
/* 507 */     return new PropertyBuilder(config, beanDesc);
/*     */   }
/*     */ 
/*     */   protected BeanSerializerBuilder constructBeanSerializerBuilder(BasicBeanDescription beanDesc) {
/* 511 */     return new BeanSerializerBuilder(beanDesc);
/*     */   }
/*     */ 
/*     */   protected Object findFilterId(SerializationConfig config, BasicBeanDescription beanDesc)
/*     */   {
/* 522 */     return config.getAnnotationIntrospector().findFilterId(beanDesc.getClassInfo());
/*     */   }
/*     */ 
/*     */   protected boolean isPotentialBeanType(Class<?> type)
/*     */   {
/* 541 */     return (ClassUtil.canBeABeanType(type) == null) && (!ClassUtil.isProxyType(type));
/*     */   }
/*     */ 
/*     */   protected List<BeanPropertyWriter> findBeanProperties(SerializationConfig config, BasicBeanDescription beanDesc)
/*     */     throws JsonMappingException
/*     */   {
/* 551 */     List properties = beanDesc.findProperties();
/* 552 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*     */ 
/* 555 */     removeIgnorableTypes(config, beanDesc, properties);
/*     */ 
/* 558 */     if (config.isEnabled(SerializationConfig.Feature.REQUIRE_SETTERS_FOR_GETTERS)) {
/* 559 */       removeSetterlessGetters(config, beanDesc, properties);
/*     */     }
/*     */ 
/* 563 */     if (properties.isEmpty()) {
/* 564 */       return null;
/*     */     }
/*     */ 
/* 568 */     boolean staticTyping = usesStaticTyping(config, beanDesc, null, null);
/* 569 */     PropertyBuilder pb = constructPropertyBuilder(config, beanDesc);
/*     */ 
/* 571 */     ArrayList result = new ArrayList(properties.size());
/* 572 */     TypeBindings typeBind = beanDesc.bindingsForBeanType();
/*     */ 
/* 574 */     for (BeanPropertyDefinition property : properties) {
/* 575 */       AnnotatedMember accessor = property.getAccessor();
/*     */ 
/* 577 */       AnnotationIntrospector.ReferenceProperty prop = intr.findReferenceType(accessor);
/* 578 */       if ((prop == null) || (!prop.isBackReference()))
/*     */       {
/* 581 */         String name = property.getName();
/* 582 */         if ((accessor instanceof AnnotatedMethod))
/* 583 */           result.add(_constructWriter(config, typeBind, pb, staticTyping, name, (AnnotatedMethod)accessor));
/*     */         else
/* 585 */           result.add(_constructWriter(config, typeBind, pb, staticTyping, name, (AnnotatedField)accessor));
/*     */       }
/*     */     }
/* 588 */     return result;
/*     */   }
/*     */ 
/*     */   protected List<BeanPropertyWriter> filterBeanProperties(SerializationConfig config, BasicBeanDescription beanDesc, List<BeanPropertyWriter> props)
/*     */   {
/* 604 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 605 */     AnnotatedClass ac = beanDesc.getClassInfo();
/* 606 */     String[] ignored = intr.findPropertiesToIgnore(ac);
/* 607 */     if ((ignored != null) && (ignored.length > 0)) {
/* 608 */       HashSet ignoredSet = ArrayBuilders.arrayToSet(ignored);
/* 609 */       Iterator it = props.iterator();
/* 610 */       while (it.hasNext()) {
/* 611 */         if (ignoredSet.contains(((BeanPropertyWriter)it.next()).getName())) {
/* 612 */           it.remove();
/*     */         }
/*     */       }
/*     */     }
/* 616 */     return props;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected List<BeanPropertyWriter> sortBeanProperties(SerializationConfig config, BasicBeanDescription beanDesc, List<BeanPropertyWriter> props)
/*     */   {
/* 642 */     return props;
/*     */   }
/*     */ 
/*     */   protected void processViews(SerializationConfig config, BeanSerializerBuilder builder)
/*     */   {
/* 660 */     List props = builder.getProperties();
/* 661 */     boolean includeByDefault = config.isEnabled(SerializationConfig.Feature.DEFAULT_VIEW_INCLUSION);
/* 662 */     int propCount = props.size();
/* 663 */     int viewsFound = 0;
/* 664 */     BeanPropertyWriter[] filtered = new BeanPropertyWriter[propCount];
/*     */ 
/* 666 */     for (int i = 0; i < propCount; i++) {
/* 667 */       BeanPropertyWriter bpw = (BeanPropertyWriter)props.get(i);
/* 668 */       Class[] views = bpw.getViews();
/* 669 */       if (views == null) {
/* 670 */         if (includeByDefault)
/* 671 */           filtered[i] = bpw;
/*     */       }
/*     */       else {
/* 674 */         viewsFound++;
/* 675 */         filtered[i] = constructFilteredBeanWriter(bpw, views);
/*     */       }
/*     */     }
/*     */ 
/* 679 */     if ((includeByDefault) && (viewsFound == 0)) {
/* 680 */       return;
/*     */     }
/* 682 */     builder.setFilteredProperties(filtered);
/*     */   }
/*     */ 
/*     */   protected void removeIgnorableTypes(SerializationConfig config, BasicBeanDescription beanDesc, List<BeanPropertyDefinition> properties)
/*     */   {
/* 693 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 694 */     HashMap ignores = new HashMap();
/* 695 */     Iterator it = properties.iterator();
/* 696 */     while (it.hasNext()) {
/* 697 */       BeanPropertyDefinition property = (BeanPropertyDefinition)it.next();
/* 698 */       AnnotatedMember accessor = property.getAccessor();
/* 699 */       if (accessor == null) {
/* 700 */         it.remove();
/*     */       }
/*     */       else {
/* 703 */         Class type = accessor.getRawType();
/* 704 */         Boolean result = (Boolean)ignores.get(type);
/* 705 */         if (result == null) {
/* 706 */           BasicBeanDescription desc = (BasicBeanDescription)config.introspectClassAnnotations(type);
/* 707 */           AnnotatedClass ac = desc.getClassInfo();
/* 708 */           result = intr.isIgnorableType(ac);
/*     */ 
/* 710 */           if (result == null) {
/* 711 */             result = Boolean.FALSE;
/*     */           }
/* 713 */           ignores.put(type, result);
/*     */         }
/*     */ 
/* 716 */         if (result.booleanValue())
/* 717 */           it.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void removeSetterlessGetters(SerializationConfig config, BasicBeanDescription beanDesc, List<BeanPropertyDefinition> properties)
/*     */   {
/* 731 */     Iterator it = properties.iterator();
/* 732 */     while (it.hasNext()) {
/* 733 */       BeanPropertyDefinition property = (BeanPropertyDefinition)it.next();
/* 734 */       if (!property.couldDeserialize())
/* 735 */         it.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected BeanPropertyWriter _constructWriter(SerializationConfig config, TypeBindings typeContext, PropertyBuilder pb, boolean staticTyping, String name, AnnotatedMember accessor)
/*     */     throws JsonMappingException
/*     */   {
/* 754 */     if (config.isEnabled(SerializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 755 */       accessor.fixAccess();
/*     */     }
/* 757 */     JavaType type = accessor.getType(typeContext);
/* 758 */     BeanProperty.Std property = new BeanProperty.Std(name, type, pb.getClassAnnotations(), accessor);
/*     */ 
/* 761 */     JsonSerializer annotatedSerializer = findSerializerFromAnnotation(config, accessor, property);
/*     */ 
/* 763 */     TypeSerializer contentTypeSer = null;
/* 764 */     if (ClassUtil.isCollectionMapOrArray(type.getRawClass())) {
/* 765 */       contentTypeSer = findPropertyContentTypeSerializer(type, config, accessor, property);
/*     */     }
/*     */ 
/* 769 */     TypeSerializer typeSer = findPropertyTypeSerializer(type, config, accessor, property);
/* 770 */     BeanPropertyWriter pbw = pb.buildWriter(name, type, annotatedSerializer, typeSer, contentTypeSer, accessor, staticTyping);
/*     */ 
/* 773 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 774 */     pbw.setViews(intr.findSerializationViews(accessor));
/* 775 */     return pbw;
/*     */   }
/*     */ 
/*     */   public static class ConfigImpl extends SerializerFactory.Config
/*     */   {
/*  83 */     protected static final Serializers[] NO_SERIALIZERS = new Serializers[0];
/*     */ 
/*  85 */     protected static final BeanSerializerModifier[] NO_MODIFIERS = new BeanSerializerModifier[0];
/*     */     protected final Serializers[] _additionalSerializers;
/*     */     protected final Serializers[] _additionalKeySerializers;
/*     */     protected final BeanSerializerModifier[] _modifiers;
/*     */ 
/*     */     public ConfigImpl()
/*     */     {
/* 107 */       this(null, null, null);
/*     */     }
/*     */ 
/*     */     protected ConfigImpl(Serializers[] allAdditionalSerializers, Serializers[] allAdditionalKeySerializers, BeanSerializerModifier[] modifiers)
/*     */     {
/* 114 */       this._additionalSerializers = (allAdditionalSerializers == null ? NO_SERIALIZERS : allAdditionalSerializers);
/*     */ 
/* 116 */       this._additionalKeySerializers = (allAdditionalKeySerializers == null ? NO_SERIALIZERS : allAdditionalKeySerializers);
/*     */ 
/* 118 */       this._modifiers = (modifiers == null ? NO_MODIFIERS : modifiers);
/*     */     }
/*     */ 
/*     */     public SerializerFactory.Config withAdditionalSerializers(Serializers additional)
/*     */     {
/* 124 */       if (additional == null) {
/* 125 */         throw new IllegalArgumentException("Can not pass null Serializers");
/*     */       }
/* 127 */       Serializers[] all = (Serializers[])ArrayBuilders.insertInListNoDup(this._additionalSerializers, additional);
/* 128 */       return new ConfigImpl(all, this._additionalKeySerializers, this._modifiers);
/*     */     }
/*     */ 
/*     */     public SerializerFactory.Config withAdditionalKeySerializers(Serializers additional)
/*     */     {
/* 134 */       if (additional == null) {
/* 135 */         throw new IllegalArgumentException("Can not pass null Serializers");
/*     */       }
/* 137 */       Serializers[] all = (Serializers[])ArrayBuilders.insertInListNoDup(this._additionalKeySerializers, additional);
/* 138 */       return new ConfigImpl(this._additionalSerializers, all, this._modifiers);
/*     */     }
/*     */ 
/*     */     public SerializerFactory.Config withSerializerModifier(BeanSerializerModifier modifier)
/*     */     {
/* 144 */       if (modifier == null) {
/* 145 */         throw new IllegalArgumentException("Can not pass null modifier");
/*     */       }
/* 147 */       BeanSerializerModifier[] modifiers = (BeanSerializerModifier[])ArrayBuilders.insertInListNoDup(this._modifiers, modifier);
/* 148 */       return new ConfigImpl(this._additionalSerializers, this._additionalKeySerializers, modifiers);
/*     */     }
/*     */ 
/*     */     public boolean hasSerializers() {
/* 152 */       return this._additionalSerializers.length > 0;
/*     */     }
/*     */     public boolean hasKeySerializers() {
/* 155 */       return this._additionalKeySerializers.length > 0;
/*     */     }
/*     */     public boolean hasSerializerModifiers() {
/* 158 */       return this._modifiers.length > 0;
/*     */     }
/*     */ 
/*     */     public Iterable<Serializers> serializers() {
/* 162 */       return ArrayBuilders.arrayAsIterable(this._additionalSerializers);
/*     */     }
/*     */ 
/*     */     public Iterable<Serializers> keySerializers()
/*     */     {
/* 167 */       return ArrayBuilders.arrayAsIterable(this._additionalKeySerializers);
/*     */     }
/*     */ 
/*     */     public Iterable<BeanSerializerModifier> serializerModifiers()
/*     */     {
/* 172 */       return ArrayBuilders.arrayAsIterable(this._modifiers);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.BeanSerializerFactory
 * JD-Core Version:    0.6.2
 */