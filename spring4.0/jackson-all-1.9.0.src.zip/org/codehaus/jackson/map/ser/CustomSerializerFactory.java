/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializerFactory;
/*     */ import org.codehaus.jackson.map.SerializerFactory.Config;
/*     */ import org.codehaus.jackson.map.type.ClassKey;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class CustomSerializerFactory extends BeanSerializerFactory
/*     */ {
/*  56 */   protected HashMap<ClassKey, JsonSerializer<?>> _directClassMappings = null;
/*     */   protected JsonSerializer<?> _enumSerializerOverride;
/*  75 */   protected HashMap<ClassKey, JsonSerializer<?>> _transitiveClassMappings = null;
/*     */ 
/*  80 */   protected HashMap<ClassKey, JsonSerializer<?>> _interfaceMappings = null;
/*     */ 
/*     */   public CustomSerializerFactory()
/*     */   {
/*  89 */     this(null);
/*     */   }
/*     */ 
/*     */   public CustomSerializerFactory(SerializerFactory.Config config) {
/*  93 */     super(config);
/*     */   }
/*     */ 
/*     */   public SerializerFactory withConfig(SerializerFactory.Config config)
/*     */   {
/* 102 */     if (getClass() != CustomSerializerFactory.class) {
/* 103 */       throw new IllegalStateException("Subtype of CustomSerializerFactory (" + getClass().getName() + ") has not properly overridden method 'withAdditionalSerializers': can not instantiate subtype with " + "additional serializer definitions");
/*     */     }
/*     */ 
/* 107 */     return new CustomSerializerFactory(config);
/*     */   }
/*     */ 
/*     */   public <T> void addGenericMapping(Class<? extends T> type, JsonSerializer<T> ser)
/*     */   {
/* 137 */     ClassKey key = new ClassKey(type);
/* 138 */     if (type.isInterface()) {
/* 139 */       if (this._interfaceMappings == null) {
/* 140 */         this._interfaceMappings = new HashMap();
/*     */       }
/* 142 */       this._interfaceMappings.put(key, ser);
/*     */     } else {
/* 144 */       if (this._transitiveClassMappings == null) {
/* 145 */         this._transitiveClassMappings = new HashMap();
/*     */       }
/* 147 */       this._transitiveClassMappings.put(key, ser);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> void addSpecificMapping(Class<? extends T> forClass, JsonSerializer<T> ser)
/*     */   {
/* 165 */     ClassKey key = new ClassKey(forClass);
/*     */ 
/* 171 */     if (forClass.isInterface()) {
/* 172 */       throw new IllegalArgumentException("Can not add specific mapping for an interface (" + forClass.getName() + ")");
/*     */     }
/* 174 */     if (Modifier.isAbstract(forClass.getModifiers())) {
/* 175 */       throw new IllegalArgumentException("Can not add specific mapping for an abstract class (" + forClass.getName() + ")");
/*     */     }
/*     */ 
/* 178 */     if (this._directClassMappings == null) {
/* 179 */       this._directClassMappings = new HashMap();
/*     */     }
/* 181 */     this._directClassMappings.put(key, ser);
/*     */   }
/*     */ 
/*     */   public void setEnumSerializer(JsonSerializer<?> enumSer)
/*     */   {
/* 198 */     this._enumSerializerOverride = enumSer;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> createSerializer(SerializationConfig config, JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 213 */     JsonSerializer ser = findCustomSerializer(type.getRawClass(), config);
/* 214 */     if (ser != null) {
/* 215 */       return ser;
/*     */     }
/* 217 */     return super.createSerializer(config, type, property);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> findCustomSerializer(Class<?> type, SerializationConfig config)
/*     */   {
/* 228 */     JsonSerializer ser = null;
/* 229 */     ClassKey key = new ClassKey(type);
/*     */ 
/* 232 */     if (this._directClassMappings != null) {
/* 233 */       ser = (JsonSerializer)this._directClassMappings.get(key);
/* 234 */       if (ser != null) {
/* 235 */         return ser;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 240 */     if ((type.isEnum()) && 
/* 241 */       (this._enumSerializerOverride != null)) {
/* 242 */       return this._enumSerializerOverride;
/*     */     }
/*     */ 
/* 248 */     if (this._transitiveClassMappings != null) {
/* 249 */       for (Class curr = type; curr != null; curr = curr.getSuperclass()) {
/* 250 */         key.reset(curr);
/* 251 */         ser = (JsonSerializer)this._transitiveClassMappings.get(key);
/* 252 */         if (ser != null) {
/* 253 */           return ser;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 259 */     if (this._interfaceMappings != null)
/*     */     {
/* 261 */       key.reset(type);
/* 262 */       ser = (JsonSerializer)this._interfaceMappings.get(key);
/* 263 */       if (ser != null) {
/* 264 */         return ser;
/*     */       }
/* 266 */       for (Class curr = type; curr != null; curr = curr.getSuperclass()) {
/* 267 */         ser = _findInterfaceMapping(curr, key);
/* 268 */         if (ser != null) {
/* 269 */           return ser;
/*     */         }
/*     */       }
/*     */     }
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<?> _findInterfaceMapping(Class<?> cls, ClassKey key)
/*     */   {
/* 278 */     for (Class iface : cls.getInterfaces()) {
/* 279 */       key.reset(iface);
/* 280 */       JsonSerializer ser = (JsonSerializer)this._interfaceMappings.get(key);
/* 281 */       if (ser != null) {
/* 282 */         return ser;
/*     */       }
/*     */ 
/* 285 */       ser = _findInterfaceMapping(iface, key);
/* 286 */       if (ser != null) {
/* 287 */         return ser;
/*     */       }
/*     */     }
/* 290 */     return null;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.CustomSerializerFactory
 * JD-Core Version:    0.6.2
 */