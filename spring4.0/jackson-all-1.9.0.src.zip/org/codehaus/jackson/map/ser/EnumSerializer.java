/*    */ package org.codehaus.jackson.map.ser;
/*    */ 
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ import org.codehaus.jackson.map.util.EnumValues;
/*    */ 
/*    */ @Deprecated
/*    */ @JacksonStdImpl
/*    */ public class EnumSerializer extends org.codehaus.jackson.map.ser.std.EnumSerializer
/*    */ {
/*    */   public EnumSerializer(EnumValues v)
/*    */   {
/* 15 */     super(v);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.EnumSerializer
 * JD-Core Version:    0.6.2
 */