/*    */ package org.codehaus.jackson.map.ser;
/*    */ 
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.JsonSerializer;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ 
/*    */ public abstract class FilteredBeanPropertyWriter
/*    */ {
/*    */   public static BeanPropertyWriter constructViewBased(BeanPropertyWriter base, Class<?>[] viewsToIncludeIn)
/*    */   {
/* 18 */     if (viewsToIncludeIn.length == 1) {
/* 19 */       return new SingleView(base, viewsToIncludeIn[0]);
/*    */     }
/* 21 */     return new MultiView(base, viewsToIncludeIn);
/*    */   }
/*    */ 
/*    */   private static final class MultiView extends BeanPropertyWriter
/*    */   {
/*    */     protected final BeanPropertyWriter _delegate;
/*    */     protected final Class<?>[] _views;
/*    */ 
/*    */     protected MultiView(BeanPropertyWriter delegate, Class<?>[] views)
/*    */     {
/* 68 */       super();
/* 69 */       this._delegate = delegate;
/* 70 */       this._views = views;
/*    */     }
/*    */ 
/*    */     public BeanPropertyWriter withSerializer(JsonSerializer<Object> ser)
/*    */     {
/* 75 */       return new MultiView(this._delegate.withSerializer(ser), this._views);
/*    */     }
/*    */ 
/*    */     public void serializeAsField(Object bean, JsonGenerator jgen, SerializerProvider prov)
/*    */       throws Exception
/*    */     {
/* 82 */       Class activeView = prov.getSerializationView();
/* 83 */       if (activeView != null) {
/* 84 */         int i = 0; int len = this._views.length;
/* 85 */         while ((i < len) && 
/* 86 */           (!this._views[i].isAssignableFrom(activeView))) {
/* 85 */           i++;
/*    */         }
/*    */ 
/* 89 */         if (i == len) {
/* 90 */           return;
/*    */         }
/*    */       }
/* 93 */       this._delegate.serializeAsField(bean, jgen, prov);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static final class SingleView extends BeanPropertyWriter
/*    */   {
/*    */     protected final BeanPropertyWriter _delegate;
/*    */     protected final Class<?> _view;
/*    */ 
/*    */     protected SingleView(BeanPropertyWriter delegate, Class<?> view)
/*    */     {
/* 39 */       super();
/* 40 */       this._delegate = delegate;
/* 41 */       this._view = view;
/*    */     }
/*    */ 
/*    */     public BeanPropertyWriter withSerializer(JsonSerializer<Object> ser)
/*    */     {
/* 46 */       return new SingleView(this._delegate.withSerializer(ser), this._view);
/*    */     }
/*    */ 
/*    */     public void serializeAsField(Object bean, JsonGenerator jgen, SerializerProvider prov)
/*    */       throws Exception
/*    */     {
/* 53 */       Class activeView = prov.getSerializationView();
/* 54 */       if ((activeView == null) || (this._view.isAssignableFrom(activeView)))
/* 55 */         this._delegate.serializeAsField(bean, jgen, prov);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.FilteredBeanPropertyWriter
 * JD-Core Version:    0.6.2
 */