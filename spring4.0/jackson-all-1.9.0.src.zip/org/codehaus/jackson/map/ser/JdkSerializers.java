package org.codehaus.jackson.map.ser;

import org.codehaus.jackson.map.ser.std.StdJdkSerializers;

@Deprecated
public class JdkSerializers extends StdJdkSerializers
{
}

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.JdkSerializers
 * JD-Core Version:    0.6.2
 */