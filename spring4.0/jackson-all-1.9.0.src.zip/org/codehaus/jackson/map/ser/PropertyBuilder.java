/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
/*     */ import org.codehaus.jackson.map.annotate.JsonSerialize.Typing;
/*     */ import org.codehaus.jackson.map.introspect.Annotated;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*     */ import org.codehaus.jackson.map.util.Annotations;
/*     */ import org.codehaus.jackson.map.util.Comparators;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class PropertyBuilder
/*     */ {
/*     */   protected final SerializationConfig _config;
/*     */   protected final BasicBeanDescription _beanDesc;
/*     */   protected final JsonSerialize.Inclusion _outputProps;
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */   protected Object _defaultBean;
/*     */ 
/*     */   public PropertyBuilder(SerializationConfig config, BasicBeanDescription beanDesc)
/*     */   {
/*  39 */     this._config = config;
/*  40 */     this._beanDesc = beanDesc;
/*  41 */     this._outputProps = beanDesc.findSerializationInclusion(config.getSerializationInclusion());
/*  42 */     this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */   }
/*     */ 
/*     */   public Annotations getClassAnnotations()
/*     */   {
/*  52 */     return this._beanDesc.getClassAnnotations();
/*     */   }
/*     */ 
/*     */   protected BeanPropertyWriter buildWriter(String name, JavaType declaredType, JsonSerializer<Object> ser, TypeSerializer typeSer, TypeSerializer contentTypeSer, AnnotatedMember am, boolean defaultUseStaticTyping)
/*     */   {
/*     */     Field f;
/*     */     Method m;
/*     */     Field f;
/*  67 */     if ((am instanceof AnnotatedField)) {
/*  68 */       Method m = null;
/*  69 */       f = ((AnnotatedField)am).getAnnotated();
/*     */     } else {
/*  71 */       m = ((AnnotatedMethod)am).getAnnotated();
/*  72 */       f = null;
/*     */     }
/*     */ 
/*  76 */     JavaType serializationType = findSerializationType(am, defaultUseStaticTyping, declaredType);
/*     */ 
/*  79 */     if (contentTypeSer != null)
/*     */     {
/*  84 */       if (serializationType == null)
/*     */       {
/*  86 */         serializationType = declaredType;
/*     */       }
/*  88 */       JavaType ct = serializationType.getContentType();
/*     */ 
/*  93 */       if (ct == null) {
/*  94 */         throw new IllegalStateException("Problem trying to create BeanPropertyWriter for property '" + name + "' (of type " + this._beanDesc.getType() + "); serialization type " + serializationType + " has no content");
/*     */       }
/*     */ 
/*  97 */       serializationType = serializationType.withContentTypeHandler(contentTypeSer);
/*  98 */       ct = serializationType.getContentType();
/*     */     }
/*     */ 
/* 101 */     Object valueToSuppress = null;
/* 102 */     boolean suppressNulls = false;
/*     */ 
/* 104 */     JsonSerialize.Inclusion methodProps = this._annotationIntrospector.findSerializationInclusion(am, this._outputProps);
/*     */ 
/* 106 */     if (methodProps != null) {
/* 107 */       switch (1.$SwitchMap$org$codehaus$jackson$map$annotate$JsonSerialize$Inclusion[methodProps.ordinal()]) {
/*     */       case 1:
/* 109 */         valueToSuppress = getDefaultValue(name, m, f);
/* 110 */         if (valueToSuppress == null) {
/* 111 */           suppressNulls = true;
/*     */         }
/* 114 */         else if (valueToSuppress.getClass().isArray())
/* 115 */           valueToSuppress = Comparators.getArrayComparator(valueToSuppress); break;
/*     */       case 2:
/* 121 */         suppressNulls = true;
/*     */ 
/* 123 */         valueToSuppress = getEmptyValueChecker(name, declaredType);
/* 124 */         break;
/*     */       case 3:
/* 126 */         suppressNulls = true;
/*     */       case 4:
/* 130 */         if (declaredType.isContainerType()) {
/* 131 */           valueToSuppress = getContainerValueChecker(name, declaredType);
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*     */ 
/* 137 */     BeanPropertyWriter bpw = new BeanPropertyWriter(am, this._beanDesc.getClassAnnotations(), name, declaredType, ser, typeSer, serializationType, m, f, suppressNulls, valueToSuppress);
/*     */ 
/* 141 */     Boolean unwrapped = this._annotationIntrospector.shouldUnwrapProperty(am);
/* 142 */     if ((unwrapped != null) && (unwrapped.booleanValue())) {
/* 143 */       bpw = bpw.unwrappingWriter();
/*     */     }
/* 145 */     return bpw;
/*     */   }
/*     */ 
/*     */   protected JavaType findSerializationType(Annotated a, boolean useStaticTyping, JavaType declaredType)
/*     */   {
/* 163 */     Class serClass = this._annotationIntrospector.findSerializationType(a);
/* 164 */     if (serClass != null)
/*     */     {
/* 166 */       Class rawDeclared = declaredType.getRawClass();
/* 167 */       if (serClass.isAssignableFrom(rawDeclared)) {
/* 168 */         declaredType = declaredType.widenBy(serClass);
/*     */       }
/*     */       else
/*     */       {
/* 176 */         if (!rawDeclared.isAssignableFrom(serClass)) {
/* 177 */           throw new IllegalArgumentException("Illegal concrete-type annotation for method '" + a.getName() + "': class " + serClass.getName() + " not a super-type of (declared) class " + rawDeclared.getName());
/*     */         }
/*     */ 
/* 183 */         declaredType = declaredType.forcedNarrowBy(serClass);
/*     */       }
/* 185 */       useStaticTyping = true;
/*     */     }
/*     */ 
/* 188 */     JavaType secondary = BeanSerializerFactory.modifySecondaryTypesByAnnotation(this._config, a, declaredType);
/* 189 */     if (secondary != declaredType) {
/* 190 */       useStaticTyping = true;
/* 191 */       declaredType = secondary;
/*     */     }
/*     */ 
/* 197 */     if (!useStaticTyping) {
/* 198 */       JsonSerialize.Typing typing = this._annotationIntrospector.findSerializationTyping(a);
/* 199 */       if (typing != null) {
/* 200 */         useStaticTyping = typing == JsonSerialize.Typing.STATIC;
/*     */       }
/*     */     }
/* 203 */     return useStaticTyping ? declaredType : null;
/*     */   }
/*     */ 
/*     */   protected Object getDefaultBean()
/*     */   {
/* 214 */     if (this._defaultBean == null)
/*     */     {
/* 218 */       this._defaultBean = this._beanDesc.instantiateBean(this._config.isEnabled(SerializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS));
/* 219 */       if (this._defaultBean == null) {
/* 220 */         Class cls = this._beanDesc.getClassInfo().getAnnotated();
/* 221 */         throw new IllegalArgumentException("Class " + cls.getName() + " has no default constructor; can not instantiate default bean value to support 'properties=JsonSerialize.Inclusion.NON_DEFAULT' annotation");
/*     */       }
/*     */     }
/* 224 */     return this._defaultBean;
/*     */   }
/*     */ 
/*     */   protected Object getDefaultValue(String name, Method m, Field f)
/*     */   {
/* 229 */     Object defaultBean = getDefaultBean();
/*     */     try {
/* 231 */       if (m != null) {
/* 232 */         return m.invoke(defaultBean, new Object[0]);
/*     */       }
/* 234 */       return f.get(defaultBean);
/*     */     } catch (Exception e) {
/* 236 */       return _throwWrapped(e, name, defaultBean);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object getContainerValueChecker(String propertyName, JavaType propertyType)
/*     */   {
/* 256 */     if (!this._config.isEnabled(SerializationConfig.Feature.WRITE_EMPTY_JSON_ARRAYS)) {
/* 257 */       if (propertyType.isArrayType()) {
/* 258 */         return new EmptyArrayChecker();
/*     */       }
/* 260 */       if (Collection.class.isAssignableFrom(propertyType.getRawClass())) {
/* 261 */         return new EmptyCollectionChecker();
/*     */       }
/*     */     }
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object getEmptyValueChecker(String propertyName, JavaType propertyType)
/*     */   {
/* 284 */     Class rawType = propertyType.getRawClass();
/* 285 */     if (rawType == String.class) {
/* 286 */       return new EmptyStringChecker();
/*     */     }
/* 288 */     if (propertyType.isArrayType()) {
/* 289 */       return new EmptyArrayChecker();
/*     */     }
/* 291 */     if (Collection.class.isAssignableFrom(rawType)) {
/* 292 */       return new EmptyCollectionChecker();
/*     */     }
/* 294 */     if (Map.class.isAssignableFrom(rawType)) {
/* 295 */       return new EmptyMapChecker();
/*     */     }
/* 297 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object _throwWrapped(Exception e, String propName, Object defaultBean)
/*     */   {
/* 308 */     Throwable t = e;
/* 309 */     while (t.getCause() != null) {
/* 310 */       t = t.getCause();
/*     */     }
/* 312 */     if ((t instanceof Error)) throw ((Error)t);
/* 313 */     if ((t instanceof RuntimeException)) throw ((RuntimeException)t);
/* 314 */     throw new IllegalArgumentException("Failed to get property '" + propName + "' of default " + defaultBean.getClass().getName() + " instance");
/*     */   }
/*     */ 
/*     */   public static class EmptyStringChecker
/*     */   {
/*     */     public boolean equals(Object other)
/*     */     {
/* 369 */       return (other == null) || (((String)other).length() == 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class EmptyArrayChecker
/*     */   {
/*     */     public boolean equals(Object other)
/*     */     {
/* 356 */       return (other == null) || (Array.getLength(other) == 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class EmptyMapChecker
/*     */   {
/*     */     public boolean equals(Object other)
/*     */     {
/* 343 */       return (other == null) || (((Map)other).size() == 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class EmptyCollectionChecker
/*     */   {
/*     */     public boolean equals(Object other)
/*     */     {
/* 331 */       return (other == null) || (((Collection)other).size() == 0);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.PropertyBuilder
 * JD-Core Version:    0.6.2
 */