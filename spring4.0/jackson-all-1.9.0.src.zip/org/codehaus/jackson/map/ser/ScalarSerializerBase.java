/*    */ package org.codehaus.jackson.map.ser;
/*    */ 
/*    */ import org.codehaus.jackson.map.ser.std.SerializerBase;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class ScalarSerializerBase<T> extends SerializerBase<T>
/*    */ {
/*    */   protected ScalarSerializerBase(Class<T> t)
/*    */   {
/* 11 */     super(t);
/*    */   }
/*    */ 
/*    */   protected ScalarSerializerBase(Class<?> t, boolean dummy)
/*    */   {
/* 16 */     super(t);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.ScalarSerializerBase
 * JD-Core Version:    0.6.2
 */