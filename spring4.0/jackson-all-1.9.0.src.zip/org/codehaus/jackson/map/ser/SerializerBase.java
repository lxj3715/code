/*    */ package org.codehaus.jackson.map.ser;
/*    */ 
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class SerializerBase<T> extends org.codehaus.jackson.map.ser.std.SerializerBase<T>
/*    */ {
/*    */   protected SerializerBase(Class<T> t)
/*    */   {
/* 13 */     super(t);
/*    */   }
/*    */ 
/*    */   protected SerializerBase(JavaType type) {
/* 17 */     super(type);
/*    */   }
/*    */ 
/*    */   protected SerializerBase(Class<?> t, boolean dummy) {
/* 21 */     super(t, dummy);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.SerializerBase
 * JD-Core Version:    0.6.2
 */