/*    */ package org.codehaus.jackson.map.ser;
/*    */ 
/*    */ @Deprecated
/*    */ public final class StdKeySerializer extends org.codehaus.jackson.map.ser.std.StdKeySerializer
/*    */ {
/* 10 */   static final StdKeySerializer instace = new StdKeySerializer();
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.StdKeySerializer
 * JD-Core Version:    0.6.2
 */