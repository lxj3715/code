/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.ContextualSerializer;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.ResolvableSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.SerializerFactory;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.ser.impl.FailingSerializer;
/*     */ import org.codehaus.jackson.map.ser.impl.ReadOnlyClassToSerializerMap;
/*     */ import org.codehaus.jackson.map.ser.impl.SerializerCache;
/*     */ import org.codehaus.jackson.map.ser.impl.UnknownSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.NullSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdKeySerializer;
/*     */ import org.codehaus.jackson.map.ser.std.StdKeySerializers;
/*     */ import org.codehaus.jackson.map.util.ClassUtil;
/*     */ import org.codehaus.jackson.map.util.RootNameLookup;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ import org.codehaus.jackson.schema.JsonSchema;
/*     */ import org.codehaus.jackson.schema.SchemaAware;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class StdSerializerProvider extends SerializerProvider
/*     */ {
/*     */   static final boolean CACHE_UNKNOWN_MAPPINGS = false;
/*  54 */   public static final JsonSerializer<Object> DEFAULT_NULL_KEY_SERIALIZER = new FailingSerializer("Null key for a Map not allowed in JSON (use a converting NullKeySerializer?)");
/*     */ 
/*     */   @Deprecated
/*  61 */   public static final JsonSerializer<Object> DEFAULT_KEY_SERIALIZER = new StdKeySerializer();
/*     */ 
/*  63 */   public static final JsonSerializer<Object> DEFAULT_UNKNOWN_SERIALIZER = new UnknownSerializer();
/*     */   protected final SerializerFactory _serializerFactory;
/*     */   protected final SerializerCache _serializerCache;
/*     */   protected final RootNameLookup _rootNames;
/*  97 */   protected JsonSerializer<Object> _unknownTypeSerializer = DEFAULT_UNKNOWN_SERIALIZER;
/*     */   protected JsonSerializer<Object> _keySerializer;
/* 110 */   protected JsonSerializer<Object> _nullValueSerializer = NullSerializer.instance;
/*     */ 
/* 119 */   protected JsonSerializer<Object> _nullKeySerializer = DEFAULT_NULL_KEY_SERIALIZER;
/*     */   protected final ReadOnlyClassToSerializerMap _knownSerializers;
/*     */   protected DateFormat _dateFormat;
/*     */ 
/*     */   public StdSerializerProvider()
/*     */   {
/* 153 */     super(null);
/* 154 */     this._serializerFactory = null;
/* 155 */     this._serializerCache = new SerializerCache();
/*     */ 
/* 157 */     this._knownSerializers = null;
/* 158 */     this._rootNames = new RootNameLookup();
/*     */   }
/*     */ 
/*     */   protected StdSerializerProvider(SerializationConfig config, StdSerializerProvider src, SerializerFactory f)
/*     */   {
/* 170 */     super(config);
/* 171 */     if (config == null) {
/* 172 */       throw new NullPointerException();
/*     */     }
/* 174 */     this._serializerFactory = f;
/*     */ 
/* 176 */     this._serializerCache = src._serializerCache;
/* 177 */     this._unknownTypeSerializer = src._unknownTypeSerializer;
/* 178 */     this._keySerializer = src._keySerializer;
/* 179 */     this._nullValueSerializer = src._nullValueSerializer;
/* 180 */     this._nullKeySerializer = src._nullKeySerializer;
/* 181 */     this._rootNames = src._rootNames;
/*     */ 
/* 186 */     this._knownSerializers = this._serializerCache.getReadOnlyLookupMap();
/*     */   }
/*     */ 
/*     */   protected StdSerializerProvider createInstance(SerializationConfig config, SerializerFactory jsf)
/*     */   {
/* 195 */     return new StdSerializerProvider(config, this, jsf);
/*     */   }
/*     */ 
/*     */   public void setDefaultKeySerializer(JsonSerializer<Object> ks)
/*     */   {
/* 207 */     if (ks == null) {
/* 208 */       throw new IllegalArgumentException("Can not pass null JsonSerializer");
/*     */     }
/* 210 */     this._keySerializer = ks;
/*     */   }
/*     */ 
/*     */   public void setNullValueSerializer(JsonSerializer<Object> nvs)
/*     */   {
/* 216 */     if (nvs == null) {
/* 217 */       throw new IllegalArgumentException("Can not pass null JsonSerializer");
/*     */     }
/* 219 */     this._nullValueSerializer = nvs;
/*     */   }
/*     */ 
/*     */   public void setNullKeySerializer(JsonSerializer<Object> nks)
/*     */   {
/* 225 */     if (nks == null) {
/* 226 */       throw new IllegalArgumentException("Can not pass null JsonSerializer");
/*     */     }
/* 228 */     this._nullKeySerializer = nks;
/*     */   }
/*     */ 
/*     */   public final void serializeValue(SerializationConfig config, JsonGenerator jgen, Object value, SerializerFactory jsf)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 242 */     if (jsf == null) {
/* 243 */       throw new IllegalArgumentException("Can not pass null serializerFactory");
/*     */     }
/*     */ 
/* 250 */     StdSerializerProvider inst = createInstance(config, jsf);
/*     */ 
/* 252 */     if (inst.getClass() != getClass()) {
/* 253 */       throw new IllegalStateException("Broken serializer provider: createInstance returned instance of type " + inst.getClass() + "; blueprint of type " + getClass());
/*     */     }
/*     */ 
/* 256 */     inst._serializeValue(jgen, value);
/*     */   }
/*     */ 
/*     */   public final void serializeValue(SerializationConfig config, JsonGenerator jgen, Object value, JavaType rootType, SerializerFactory jsf)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 264 */     if (jsf == null) {
/* 265 */       throw new IllegalArgumentException("Can not pass null serializerFactory");
/*     */     }
/* 267 */     StdSerializerProvider inst = createInstance(config, jsf);
/* 268 */     if (inst.getClass() != getClass()) {
/* 269 */       throw new IllegalStateException("Broken serializer provider: createInstance returned instance of type " + inst.getClass() + "; blueprint of type " + getClass());
/*     */     }
/* 271 */     inst._serializeValue(jgen, value, rootType);
/*     */   }
/*     */ 
/*     */   public JsonSchema generateJsonSchema(Class<?> type, SerializationConfig config, SerializerFactory jsf)
/*     */     throws JsonMappingException
/*     */   {
/* 278 */     if (type == null) {
/* 279 */       throw new IllegalArgumentException("A class must be provided");
/*     */     }
/*     */ 
/* 286 */     StdSerializerProvider inst = createInstance(config, jsf);
/*     */ 
/* 288 */     if (inst.getClass() != getClass()) {
/* 289 */       throw new IllegalStateException("Broken serializer provider: createInstance returned instance of type " + inst.getClass() + "; blueprint of type " + getClass());
/*     */     }
/*     */ 
/* 294 */     JsonSerializer ser = inst.findValueSerializer(type, null);
/* 295 */     JsonNode schemaNode = (ser instanceof SchemaAware) ? ((SchemaAware)ser).getSchema(inst, null) : JsonSchema.getDefaultSchemaNode();
/*     */ 
/* 298 */     if (!(schemaNode instanceof ObjectNode)) {
/* 299 */       throw new IllegalArgumentException("Class " + type.getName() + " would not be serialized as a JSON object and therefore has no schema");
/*     */     }
/*     */ 
/* 303 */     return new JsonSchema((ObjectNode)schemaNode);
/*     */   }
/*     */ 
/*     */   public boolean hasSerializerFor(SerializationConfig config, Class<?> cls, SerializerFactory jsf)
/*     */   {
/* 310 */     return createInstance(config, jsf)._findExplicitUntypedSerializer(cls, null) != null;
/*     */   }
/*     */ 
/*     */   public int cachedSerializersCount()
/*     */   {
/* 315 */     return this._serializerCache.size();
/*     */   }
/*     */ 
/*     */   public void flushCachedSerializers()
/*     */   {
/* 320 */     this._serializerCache.flush();
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> findValueSerializer(Class<?> valueType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 335 */     JsonSerializer ser = this._knownSerializers.untypedValueSerializer(valueType);
/* 336 */     if (ser == null)
/*     */     {
/* 338 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/* 339 */       if (ser == null)
/*     */       {
/* 341 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/* 342 */         if (ser == null)
/*     */         {
/* 344 */           ser = _createAndCacheUntypedSerializer(valueType, property);
/*     */ 
/* 350 */           if (ser == null) {
/* 351 */             ser = getUnknownTypeSerializer(valueType);
/*     */ 
/* 356 */             return ser;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 361 */     return _handleContextualResolvable(ser, property);
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> findValueSerializer(JavaType valueType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 374 */     JsonSerializer ser = this._knownSerializers.untypedValueSerializer(valueType);
/* 375 */     if (ser == null)
/*     */     {
/* 377 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/* 378 */       if (ser == null)
/*     */       {
/* 380 */         ser = _createAndCacheUntypedSerializer(valueType, property);
/*     */ 
/* 386 */         if (ser == null) {
/* 387 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*     */ 
/* 392 */           return ser;
/*     */         }
/*     */       }
/*     */     }
/* 396 */     return _handleContextualResolvable(ser, property);
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> findTypedValueSerializer(Class<?> valueType, boolean cache, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 409 */     JsonSerializer ser = this._knownSerializers.typedValueSerializer(valueType);
/* 410 */     if (ser != null) {
/* 411 */       return ser;
/*     */     }
/*     */ 
/* 414 */     ser = this._serializerCache.typedValueSerializer(valueType);
/* 415 */     if (ser != null) {
/* 416 */       return ser;
/*     */     }
/*     */ 
/* 420 */     ser = findValueSerializer(valueType, property);
/* 421 */     TypeSerializer typeSer = this._serializerFactory.createTypeSerializer(this._config, this._config.constructType(valueType), property);
/*     */ 
/* 423 */     if (typeSer != null) {
/* 424 */       ser = new WrappedSerializer(typeSer, ser);
/*     */     }
/* 426 */     if (cache) {
/* 427 */       this._serializerCache.addTypedSerializer(valueType, ser);
/*     */     }
/* 429 */     return ser;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> findTypedValueSerializer(JavaType valueType, boolean cache, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 438 */     JsonSerializer ser = this._knownSerializers.typedValueSerializer(valueType);
/* 439 */     if (ser != null) {
/* 440 */       return ser;
/*     */     }
/*     */ 
/* 443 */     ser = this._serializerCache.typedValueSerializer(valueType);
/* 444 */     if (ser != null) {
/* 445 */       return ser;
/*     */     }
/*     */ 
/* 449 */     ser = findValueSerializer(valueType, property);
/* 450 */     TypeSerializer typeSer = this._serializerFactory.createTypeSerializer(this._config, valueType, property);
/* 451 */     if (typeSer != null) {
/* 452 */       ser = new WrappedSerializer(typeSer, ser);
/*     */     }
/* 454 */     if (cache) {
/* 455 */       this._serializerCache.addTypedSerializer(valueType, ser);
/*     */     }
/* 457 */     return ser;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> findKeySerializer(JavaType keyType, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 471 */     JsonSerializer ser = this._serializerFactory.createKeySerializer(this._config, keyType, property);
/*     */ 
/* 475 */     if (ser == null) {
/* 476 */       if (this._keySerializer == null)
/* 477 */         ser = StdKeySerializers.getStdKeySerializer(keyType);
/*     */       else {
/* 479 */         ser = this._keySerializer;
/*     */       }
/*     */     }
/*     */ 
/* 483 */     if ((ser instanceof ContextualSerializer)) {
/* 484 */       ContextualSerializer contextual = (ContextualSerializer)ser;
/* 485 */       ser = contextual.createContextual(this._config, property);
/*     */     }
/* 487 */     return ser;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> getNullKeySerializer()
/*     */   {
/* 492 */     return this._nullKeySerializer;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> getNullValueSerializer()
/*     */   {
/* 497 */     return this._nullValueSerializer;
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> getUnknownTypeSerializer(Class<?> unknownType)
/*     */   {
/* 502 */     return this._unknownTypeSerializer;
/*     */   }
/*     */ 
/*     */   public final void defaultSerializeDateValue(long timestamp, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 519 */     if (isEnabled(SerializationConfig.Feature.WRITE_DATES_AS_TIMESTAMPS)) {
/* 520 */       jgen.writeNumber(timestamp);
/*     */     } else {
/* 522 */       if (this._dateFormat == null)
/*     */       {
/* 524 */         this._dateFormat = ((DateFormat)this._config.getDateFormat().clone());
/*     */       }
/* 526 */       jgen.writeString(this._dateFormat.format(new Date(timestamp)));
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void defaultSerializeDateValue(Date date, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 535 */     if (isEnabled(SerializationConfig.Feature.WRITE_DATES_AS_TIMESTAMPS)) {
/* 536 */       jgen.writeNumber(date.getTime());
/*     */     } else {
/* 538 */       if (this._dateFormat == null) {
/* 539 */         DateFormat blueprint = this._config.getDateFormat();
/*     */ 
/* 541 */         this._dateFormat = ((DateFormat)blueprint.clone());
/*     */       }
/* 543 */       jgen.writeString(this._dateFormat.format(date));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void defaultSerializeDateKey(long timestamp, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 551 */     if (isEnabled(SerializationConfig.Feature.WRITE_DATE_KEYS_AS_TIMESTAMPS)) {
/* 552 */       jgen.writeFieldName(String.valueOf(timestamp));
/*     */     } else {
/* 554 */       if (this._dateFormat == null) {
/* 555 */         DateFormat blueprint = this._config.getDateFormat();
/*     */ 
/* 557 */         this._dateFormat = ((DateFormat)blueprint.clone());
/*     */       }
/* 559 */       jgen.writeFieldName(this._dateFormat.format(new Date(timestamp)));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void defaultSerializeDateKey(Date date, JsonGenerator jgen)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 567 */     if (isEnabled(SerializationConfig.Feature.WRITE_DATE_KEYS_AS_TIMESTAMPS)) {
/* 568 */       jgen.writeFieldName(String.valueOf(date.getTime()));
/*     */     } else {
/* 570 */       if (this._dateFormat == null) {
/* 571 */         DateFormat blueprint = this._config.getDateFormat();
/*     */ 
/* 573 */         this._dateFormat = ((DateFormat)blueprint.clone());
/*     */       }
/* 575 */       jgen.writeFieldName(this._dateFormat.format(date));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _serializeValue(JsonGenerator jgen, Object value)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*     */     boolean wrap;
/*     */     JsonSerializer ser;
/*     */     boolean wrap;
/* 595 */     if (value == null) {
/* 596 */       JsonSerializer ser = getNullValueSerializer();
/* 597 */       wrap = false;
/*     */     } else {
/* 599 */       Class cls = value.getClass();
/*     */ 
/* 601 */       ser = findTypedValueSerializer(cls, true, null);
/*     */ 
/* 603 */       wrap = this._config.isEnabled(SerializationConfig.Feature.WRAP_ROOT_VALUE);
/* 604 */       if (wrap) {
/* 605 */         jgen.writeStartObject();
/* 606 */         jgen.writeFieldName(this._rootNames.findRootName(value.getClass(), this._config));
/*     */       }
/*     */     }
/*     */     try {
/* 610 */       ser.serialize(value, jgen, this);
/* 611 */       if (wrap) {
/* 612 */         jgen.writeEndObject();
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 618 */       throw ioe;
/*     */     }
/*     */     catch (Exception e) {
/* 621 */       String msg = e.getMessage();
/* 622 */       if (msg == null) {
/* 623 */         msg = "[no message for " + e.getClass().getName() + "]";
/*     */       }
/* 625 */       throw new JsonMappingException(msg, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _serializeValue(JsonGenerator jgen, Object value, JavaType rootType)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*     */     boolean wrap;
/*     */     JsonSerializer ser;
/*     */     boolean wrap;
/* 641 */     if (value == null) {
/* 642 */       JsonSerializer ser = getNullValueSerializer();
/* 643 */       wrap = false;
/*     */     }
/*     */     else {
/* 646 */       if (!rootType.getRawClass().isAssignableFrom(value.getClass())) {
/* 647 */         _reportIncompatibleRootType(value, rootType);
/*     */       }
/*     */ 
/* 650 */       ser = findTypedValueSerializer(rootType, true, null);
/*     */ 
/* 652 */       wrap = this._config.isEnabled(SerializationConfig.Feature.WRAP_ROOT_VALUE);
/* 653 */       if (wrap) {
/* 654 */         jgen.writeStartObject();
/* 655 */         jgen.writeFieldName(this._rootNames.findRootName(rootType, this._config));
/*     */       }
/*     */     }
/*     */     try {
/* 659 */       ser.serialize(value, jgen, this);
/* 660 */       if (wrap)
/* 661 */         jgen.writeEndObject();
/*     */     }
/*     */     catch (IOException ioe) {
/* 664 */       throw ioe;
/*     */     } catch (Exception e) {
/* 666 */       String msg = e.getMessage();
/* 667 */       if (msg == null) {
/* 668 */         msg = "[no message for " + e.getClass().getName() + "]";
/*     */       }
/* 670 */       throw new JsonMappingException(msg, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void _reportIncompatibleRootType(Object value, JavaType rootType)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 680 */     if (rootType.isPrimitive()) {
/* 681 */       Class wrapperType = ClassUtil.wrapperType(rootType.getRawClass());
/*     */ 
/* 683 */       if (wrapperType.isAssignableFrom(value.getClass())) {
/* 684 */         return;
/*     */       }
/*     */     }
/* 687 */     throw new JsonMappingException("Incompatible types: declared root type (" + rootType + ") vs " + value.getClass().getName());
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<Object> _findExplicitUntypedSerializer(Class<?> runtimeType, BeanProperty property)
/*     */   {
/* 702 */     JsonSerializer ser = this._knownSerializers.untypedValueSerializer(runtimeType);
/* 703 */     if (ser != null) {
/* 704 */       return ser;
/*     */     }
/*     */ 
/* 707 */     ser = this._serializerCache.untypedValueSerializer(runtimeType);
/* 708 */     if (ser != null)
/* 709 */       return ser;
/*     */     try
/*     */     {
/* 712 */       return _createAndCacheUntypedSerializer(runtimeType, property); } catch (Exception e) {
/*     */     }
/* 714 */     return null;
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<Object> _createAndCacheUntypedSerializer(Class<?> type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/*     */     JsonSerializer ser;
/*     */     try
/*     */     {
/* 735 */       ser = _createUntypedSerializer(this._config.constructType(type), property);
/*     */     }
/*     */     catch (IllegalArgumentException iae)
/*     */     {
/* 740 */       throw new JsonMappingException(iae.getMessage(), null, iae);
/*     */     }
/*     */ 
/* 743 */     if (ser != null) {
/* 744 */       this._serializerCache.addAndResolveNonTypedSerializer(type, ser, this);
/*     */     }
/* 746 */     return ser;
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<Object> _createAndCacheUntypedSerializer(JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/*     */     JsonSerializer ser;
/*     */     try
/*     */     {
/* 758 */       ser = _createUntypedSerializer(type, property);
/*     */     }
/*     */     catch (IllegalArgumentException iae)
/*     */     {
/* 763 */       throw new JsonMappingException(iae.getMessage(), null, iae);
/*     */     }
/*     */ 
/* 766 */     if (ser != null) {
/* 767 */       this._serializerCache.addAndResolveNonTypedSerializer(type, ser, this);
/*     */     }
/* 769 */     return ser;
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<Object> _createUntypedSerializer(JavaType type, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 782 */     return this._serializerFactory.createSerializer(this._config, type, property);
/*     */   }
/*     */ 
/*     */   protected JsonSerializer<Object> _handleContextualResolvable(JsonSerializer<Object> ser, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 793 */     if (!(ser instanceof ContextualSerializer)) {
/* 794 */       return ser;
/*     */     }
/* 796 */     JsonSerializer ctxtSer = ((ContextualSerializer)ser).createContextual(this._config, property);
/* 797 */     if (ctxtSer != ser)
/*     */     {
/* 799 */       if ((ctxtSer instanceof ResolvableSerializer)) {
/* 800 */         ((ResolvableSerializer)ctxtSer).resolve(this);
/*     */       }
/* 802 */       ser = ctxtSer;
/*     */     }
/* 804 */     return ser;
/*     */   }
/*     */ 
/*     */   private static final class WrappedSerializer extends JsonSerializer<Object>
/*     */   {
/*     */     protected final TypeSerializer _typeSerializer;
/*     */     protected final JsonSerializer<Object> _serializer;
/*     */ 
/*     */     public WrappedSerializer(TypeSerializer typeSer, JsonSerializer<Object> ser)
/*     */     {
/* 827 */       this._typeSerializer = typeSer;
/* 828 */       this._serializer = ser;
/*     */     }
/*     */ 
/*     */     public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 835 */       this._serializer.serializeWithType(value, jgen, provider, this._typeSerializer);
/*     */     }
/*     */ 
/*     */     public void serializeWithType(Object value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */       throws IOException, JsonProcessingException
/*     */     {
/* 846 */       this._serializer.serializeWithType(value, jgen, provider, typeSer);
/*     */     }
/*     */ 
/*     */     public Class<Object> handledType() {
/* 850 */       return Object.class;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.StdSerializerProvider
 * JD-Core Version:    0.6.2
 */