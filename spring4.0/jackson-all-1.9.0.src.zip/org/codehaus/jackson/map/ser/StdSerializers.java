/*     */ package org.codehaus.jackson.map.ser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.ser.std.CalendarSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.DateSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.NonTypedScalarSerializerBase;
/*     */ import org.codehaus.jackson.map.ser.std.ScalarSerializerBase;
/*     */ import org.codehaus.jackson.map.ser.std.SerializableSerializer;
/*     */ import org.codehaus.jackson.map.ser.std.SerializableWithTypeSerializer;
/*     */ 
/*     */ public class StdSerializers
/*     */ {
/*     */   @Deprecated
/*     */   @JacksonStdImpl
/*     */   public static final class SerializableWithTypeSerializer extends SerializableWithTypeSerializer
/*     */   {
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   @JacksonStdImpl
/*     */   public static final class SerializableSerializer extends SerializableSerializer
/*     */   {
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class SqlTimeSerializer extends ScalarSerializerBase<Time>
/*     */   {
/*     */     public SqlTimeSerializer()
/*     */     {
/* 333 */       super();
/*     */     }
/*     */ 
/*     */     public void serialize(Time value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 339 */       jgen.writeString(value.toString());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 345 */       return createSchemaNode("string", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class SqlDateSerializer extends ScalarSerializerBase<Date>
/*     */   {
/*     */     public SqlDateSerializer()
/*     */     {
/* 312 */       super();
/*     */     }
/*     */ 
/*     */     public void serialize(Date value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 318 */       jgen.writeString(value.toString());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 325 */       return createSchemaNode("string", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   @JacksonStdImpl
/*     */   public static final class UtilDateSerializer extends DateSerializer
/*     */   {
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   @Deprecated
/*     */   public static final class CalendarSerializer extends CalendarSerializer
/*     */   {
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class NumberSerializer extends ScalarSerializerBase<Number>
/*     */   {
/* 239 */     public static final NumberSerializer instance = new NumberSerializer();
/*     */ 
/* 241 */     public NumberSerializer() { super(); }
/*     */ 
/*     */ 
/*     */     public void serialize(Number value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 248 */       if ((value instanceof BigDecimal))
/* 249 */         jgen.writeNumber((BigDecimal)value);
/* 250 */       else if ((value instanceof BigInteger)) {
/* 251 */         jgen.writeNumber((BigInteger)value);
/*     */       }
/* 256 */       else if ((value instanceof Integer))
/* 257 */         jgen.writeNumber(value.intValue());
/* 258 */       else if ((value instanceof Long))
/* 259 */         jgen.writeNumber(value.longValue());
/* 260 */       else if ((value instanceof Double))
/* 261 */         jgen.writeNumber(value.doubleValue());
/* 262 */       else if ((value instanceof Float))
/* 263 */         jgen.writeNumber(value.floatValue());
/* 264 */       else if (((value instanceof Byte)) || ((value instanceof Short))) {
/* 265 */         jgen.writeNumber(value.intValue());
/*     */       }
/*     */       else
/* 268 */         jgen.writeNumber(value.toString());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 275 */       return createSchemaNode("number", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class DoubleSerializer extends NonTypedScalarSerializerBase<Double>
/*     */   {
/* 213 */     static final DoubleSerializer instance = new DoubleSerializer();
/*     */ 
/* 215 */     public DoubleSerializer() { super(); }
/*     */ 
/*     */ 
/*     */     public void serialize(Double value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 221 */       jgen.writeNumber(value.doubleValue());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 227 */       return createSchemaNode("number", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class FloatSerializer extends ScalarSerializerBase<Float>
/*     */   {
/* 184 */     static final FloatSerializer instance = new FloatSerializer();
/*     */ 
/* 186 */     public FloatSerializer() { super(); }
/*     */ 
/*     */ 
/*     */     public void serialize(Float value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 192 */       jgen.writeNumber(value.floatValue());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 198 */       return createSchemaNode("number", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class LongSerializer extends ScalarSerializerBase<Long>
/*     */   {
/* 162 */     static final LongSerializer instance = new LongSerializer();
/*     */ 
/* 164 */     public LongSerializer() { super(); }
/*     */ 
/*     */ 
/*     */     public void serialize(Long value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 170 */       jgen.writeNumber(value.longValue());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 176 */       return createSchemaNode("number", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class IntLikeSerializer extends ScalarSerializerBase<Number>
/*     */   {
/* 140 */     static final IntLikeSerializer instance = new IntLikeSerializer();
/*     */ 
/* 142 */     public IntLikeSerializer() { super(); }
/*     */ 
/*     */ 
/*     */     public void serialize(Number value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 148 */       jgen.writeNumber(value.intValue());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 154 */       return createSchemaNode("integer", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class IntegerSerializer extends NonTypedScalarSerializerBase<Integer>
/*     */   {
/*     */     public IntegerSerializer()
/*     */     {
/* 115 */       super();
/*     */     }
/*     */ 
/*     */     public void serialize(Integer value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 121 */       jgen.writeNumber(value.intValue());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 127 */       return createSchemaNode("integer", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   @JacksonStdImpl
/*     */   public static final class StringSerializer extends NonTypedScalarSerializerBase<String>
/*     */   {
/*     */     public StringSerializer()
/*     */     {
/*  82 */       super();
/*     */     }
/*     */ 
/*     */     public void serialize(String value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/*  88 */       jgen.writeString(value);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/*  94 */       return createSchemaNode("string", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class BooleanSerializer extends NonTypedScalarSerializerBase<Boolean>
/*     */   {
/*     */     final boolean _forPrimitive;
/*     */ 
/*     */     public BooleanSerializer(boolean forPrimitive)
/*     */     {
/*  50 */       super();
/*  51 */       this._forPrimitive = forPrimitive;
/*     */     }
/*     */ 
/*     */     public void serialize(Boolean value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/*  58 */       jgen.writeBoolean(value.booleanValue());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/*  70 */       return createSchemaNode("boolean", !this._forPrimitive);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.StdSerializers
 * JD-Core Version:    0.6.2
 */