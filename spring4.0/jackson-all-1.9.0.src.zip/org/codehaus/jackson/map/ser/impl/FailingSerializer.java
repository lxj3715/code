/*    */ package org.codehaus.jackson.map.ser.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.ser.std.SerializerBase;
/*    */ 
/*    */ public final class FailingSerializer extends SerializerBase<Object>
/*    */ {
/*    */   final String _msg;
/*    */ 
/*    */   public FailingSerializer(String msg)
/*    */   {
/* 26 */     super(Object.class);
/* 27 */     this._msg = msg;
/*    */   }
/*    */ 
/*    */   public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 34 */     throw new JsonGenerationException(this._msg);
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 41 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.impl.FailingSerializer
 * JD-Core Version:    0.6.2
 */