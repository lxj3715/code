/*     */ package org.codehaus.jackson.map.ser.impl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.ResolvableSerializer;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class SerializerCache
/*     */ {
/*  34 */   private HashMap<TypeKey, JsonSerializer<Object>> _sharedMap = new HashMap(64);
/*     */ 
/*  39 */   private ReadOnlyClassToSerializerMap _readOnlyMap = null;
/*     */ 
/*     */   public ReadOnlyClassToSerializerMap getReadOnlyLookupMap()
/*     */   {
/*     */     ReadOnlyClassToSerializerMap m;
/*  51 */     synchronized (this) {
/*  52 */       m = this._readOnlyMap;
/*  53 */       if (m == null) {
/*  54 */         this._readOnlyMap = (m = ReadOnlyClassToSerializerMap.from(this._sharedMap));
/*     */       }
/*     */     }
/*  57 */     return m.instance();
/*     */   }
/*     */ 
/*     */   public synchronized int size()
/*     */   {
/*  70 */     return this._sharedMap.size();
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> untypedValueSerializer(Class<?> type)
/*     */   {
/*  79 */     synchronized (this) {
/*  80 */       return (JsonSerializer)this._sharedMap.get(new TypeKey(type, false));
/*     */     }
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> untypedValueSerializer(JavaType type)
/*     */   {
/*  89 */     synchronized (this) {
/*  90 */       return (JsonSerializer)this._sharedMap.get(new TypeKey(type, false));
/*     */     }
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> typedValueSerializer(JavaType type)
/*     */   {
/*  96 */     synchronized (this) {
/*  97 */       return (JsonSerializer)this._sharedMap.get(new TypeKey(type, true));
/*     */     }
/*     */   }
/*     */ 
/*     */   public JsonSerializer<Object> typedValueSerializer(Class<?> cls)
/*     */   {
/* 103 */     synchronized (this) {
/* 104 */       return (JsonSerializer)this._sharedMap.get(new TypeKey(cls, true));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTypedSerializer(JavaType type, JsonSerializer<Object> ser)
/*     */   {
/* 121 */     synchronized (this) {
/* 122 */       if (this._sharedMap.put(new TypeKey(type, true), ser) == null)
/*     */       {
/* 124 */         this._readOnlyMap = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTypedSerializer(Class<?> cls, JsonSerializer<Object> ser)
/*     */   {
/* 131 */     synchronized (this) {
/* 132 */       if (this._sharedMap.put(new TypeKey(cls, true), ser) == null)
/*     */       {
/* 134 */         this._readOnlyMap = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addAndResolveNonTypedSerializer(Class<?> type, JsonSerializer<Object> ser, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 146 */     synchronized (this) {
/* 147 */       if (this._sharedMap.put(new TypeKey(type, false), ser) == null)
/*     */       {
/* 149 */         this._readOnlyMap = null;
/*     */       }
/*     */ 
/* 158 */       if ((ser instanceof ResolvableSerializer))
/* 159 */         ((ResolvableSerializer)ser).resolve(provider);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addAndResolveNonTypedSerializer(JavaType type, JsonSerializer<Object> ser, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 171 */     synchronized (this) {
/* 172 */       if (this._sharedMap.put(new TypeKey(type, false), ser) == null)
/*     */       {
/* 174 */         this._readOnlyMap = null;
/*     */       }
/*     */ 
/* 183 */       if ((ser instanceof ResolvableSerializer))
/* 184 */         ((ResolvableSerializer)ser).resolve(provider);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void flush()
/*     */   {
/* 194 */     this._sharedMap.clear();
/*     */   }
/*     */ 
/*     */   public static final class TypeKey
/*     */   {
/*     */     protected int _hashCode;
/*     */     protected Class<?> _class;
/*     */     protected JavaType _type;
/*     */     protected boolean _isTyped;
/*     */ 
/*     */     public TypeKey(Class<?> key, boolean typed)
/*     */     {
/* 224 */       this._class = key;
/* 225 */       this._type = null;
/* 226 */       this._isTyped = typed;
/* 227 */       this._hashCode = hash(key, typed);
/*     */     }
/*     */ 
/*     */     public TypeKey(JavaType key, boolean typed) {
/* 231 */       this._type = key;
/* 232 */       this._class = null;
/* 233 */       this._isTyped = typed;
/* 234 */       this._hashCode = hash(key, typed);
/*     */     }
/*     */ 
/*     */     private static final int hash(Class<?> cls, boolean typed) {
/* 238 */       int hash = cls.getName().hashCode();
/* 239 */       if (typed) {
/* 240 */         hash++;
/*     */       }
/* 242 */       return hash;
/*     */     }
/*     */ 
/*     */     private static final int hash(JavaType type, boolean typed) {
/* 246 */       int hash = type.hashCode() - 1;
/* 247 */       if (typed) {
/* 248 */         hash--;
/*     */       }
/* 250 */       return hash;
/*     */     }
/*     */ 
/*     */     public void resetTyped(Class<?> cls) {
/* 254 */       this._type = null;
/* 255 */       this._class = cls;
/* 256 */       this._isTyped = true;
/* 257 */       this._hashCode = hash(cls, true);
/*     */     }
/*     */ 
/*     */     public void resetUntyped(Class<?> cls) {
/* 261 */       this._type = null;
/* 262 */       this._class = cls;
/* 263 */       this._isTyped = false;
/* 264 */       this._hashCode = hash(cls, false);
/*     */     }
/*     */ 
/*     */     public void resetTyped(JavaType type) {
/* 268 */       this._type = type;
/* 269 */       this._class = null;
/* 270 */       this._isTyped = true;
/* 271 */       this._hashCode = hash(type, true);
/*     */     }
/*     */ 
/*     */     public void resetUntyped(JavaType type) {
/* 275 */       this._type = type;
/* 276 */       this._class = null;
/* 277 */       this._isTyped = false;
/* 278 */       this._hashCode = hash(type, false);
/*     */     }
/*     */     public final int hashCode() {
/* 281 */       return this._hashCode;
/*     */     }
/*     */     public final String toString() {
/* 284 */       if (this._class != null) {
/* 285 */         return "{class: " + this._class.getName() + ", typed? " + this._isTyped + "}";
/*     */       }
/* 287 */       return "{type: " + this._type + ", typed? " + this._isTyped + "}";
/*     */     }
/*     */ 
/*     */     public final boolean equals(Object o)
/*     */     {
/* 293 */       if (o == this) return true;
/* 294 */       TypeKey other = (TypeKey)o;
/* 295 */       if (other._isTyped == this._isTyped) {
/* 296 */         if (this._class != null) {
/* 297 */           return other._class == this._class;
/*     */         }
/* 299 */         return this._type.equals(other._type);
/*     */       }
/* 301 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.impl.SerializerCache
 * JD-Core Version:    0.6.2
 */