/*     */ package org.codehaus.jackson.map.ser.impl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.map.ser.BeanPropertyFilter;
/*     */ import org.codehaus.jackson.map.ser.FilterProvider;
/*     */ 
/*     */ public class SimpleFilterProvider extends FilterProvider
/*     */ {
/*     */   protected final Map<String, BeanPropertyFilter> _filtersById;
/*     */   protected BeanPropertyFilter _defaultFilter;
/*  33 */   protected boolean _cfgFailOnUnknownId = true;
/*     */ 
/*     */   public SimpleFilterProvider()
/*     */   {
/*  42 */     this._filtersById = new HashMap();
/*     */   }
/*     */ 
/*     */   public SimpleFilterProvider(Map<String, BeanPropertyFilter> mapping)
/*     */   {
/*  49 */     this._filtersById = new HashMap();
/*     */   }
/*     */ 
/*     */   public SimpleFilterProvider setDefaultFilter(BeanPropertyFilter f)
/*     */   {
/*  60 */     this._defaultFilter = f;
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanPropertyFilter getDefaultFilter()
/*     */   {
/*  68 */     return this._defaultFilter;
/*     */   }
/*     */ 
/*     */   public SimpleFilterProvider setFailOnUnknownId(boolean state)
/*     */   {
/*  75 */     this._cfgFailOnUnknownId = state;
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean willFailOnUnknownId()
/*     */   {
/*  83 */     return this._cfgFailOnUnknownId;
/*     */   }
/*     */ 
/*     */   public SimpleFilterProvider addFilter(String id, BeanPropertyFilter filter) {
/*  87 */     this._filtersById.put(id, filter);
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanPropertyFilter removeFilter(String id) {
/*  92 */     return (BeanPropertyFilter)this._filtersById.remove(id);
/*     */   }
/*     */ 
/*     */   public BeanPropertyFilter findFilter(Object filterId)
/*     */   {
/* 104 */     BeanPropertyFilter f = (BeanPropertyFilter)this._filtersById.get(filterId);
/* 105 */     if (f == null) {
/* 106 */       f = this._defaultFilter;
/* 107 */       if ((f == null) && (this._cfgFailOnUnknownId)) {
/* 108 */         throw new IllegalArgumentException("No filter configured with id '" + filterId + "' (type " + filterId.getClass().getName() + ")");
/*     */       }
/*     */     }
/*     */ 
/* 112 */     return f;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.impl.SimpleFilterProvider
 * JD-Core Version:    0.6.2
 */