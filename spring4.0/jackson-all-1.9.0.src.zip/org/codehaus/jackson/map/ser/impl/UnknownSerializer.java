/*    */ package org.codehaus.jackson.map.ser.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.ser.std.SerializerBase;
/*    */ 
/*    */ public class UnknownSerializer extends SerializerBase<Object>
/*    */ {
/*    */   public UnknownSerializer()
/*    */   {
/* 16 */     super(Object.class);
/*    */   }
/*    */ 
/*    */   public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonMappingException
/*    */   {
/* 24 */     if (provider.isEnabled(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS)) {
/* 25 */       failForEmpty(value);
/*    */     }
/*    */ 
/* 28 */     jgen.writeStartObject();
/* 29 */     jgen.writeEndObject();
/*    */   }
/*    */ 
/*    */   public final void serializeWithType(Object value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 38 */     if (provider.isEnabled(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS)) {
/* 39 */       failForEmpty(value);
/*    */     }
/* 41 */     typeSer.writeTypePrefixForObject(value, jgen);
/* 42 */     typeSer.writeTypeSuffixForObject(value, jgen);
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) throws JsonMappingException
/*    */   {
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   protected void failForEmpty(Object value) throws JsonMappingException
/*    */   {
/* 52 */     throw new JsonMappingException("No serializer found for class " + value.getClass().getName() + " and no properties discovered to create BeanSerializer (to avoid exception, disable SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS) )");
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.impl.UnknownSerializer
 * JD-Core Version:    0.6.2
 */