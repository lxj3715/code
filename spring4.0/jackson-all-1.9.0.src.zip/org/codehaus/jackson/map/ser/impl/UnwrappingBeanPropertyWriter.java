/*    */ package org.codehaus.jackson.map.ser.impl;
/*    */ 
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.JsonSerializer;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.ser.BeanPropertyWriter;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class UnwrappingBeanPropertyWriter extends BeanPropertyWriter
/*    */ {
/*    */   public UnwrappingBeanPropertyWriter(BeanPropertyWriter base)
/*    */   {
/* 21 */     super(base);
/*    */   }
/*    */ 
/*    */   public UnwrappingBeanPropertyWriter(BeanPropertyWriter base, JsonSerializer<Object> ser) {
/* 25 */     super(base, ser);
/*    */   }
/*    */ 
/*    */   public BeanPropertyWriter withSerializer(JsonSerializer<Object> ser)
/*    */   {
/* 31 */     if (getClass() != UnwrappingBeanPropertyWriter.class) {
/* 32 */       throw new IllegalStateException("UnwrappingBeanPropertyWriter sub-class does not override 'withSerializer()'; needs to!");
/*    */     }
/*    */ 
/* 35 */     if (!ser.isUnwrappingSerializer()) {
/* 36 */       ser = ser.unwrappingSerializer();
/*    */     }
/* 38 */     return new UnwrappingBeanPropertyWriter(this, ser);
/*    */   }
/*    */ 
/*    */   public void serializeAsField(Object bean, JsonGenerator jgen, SerializerProvider prov)
/*    */     throws Exception
/*    */   {
/* 45 */     Object value = get(bean);
/* 46 */     if (value == null)
/*    */     {
/* 50 */       return;
/*    */     }
/*    */ 
/* 53 */     if (value == bean) {
/* 54 */       _reportSelfReference(bean);
/*    */     }
/* 56 */     if ((this._suppressableValue != null) && (this._suppressableValue.equals(value))) {
/* 57 */       return;
/*    */     }
/* 59 */     JsonSerializer ser = this._serializer;
/* 60 */     if (ser == null) {
/* 61 */       Class cls = value.getClass();
/* 62 */       PropertySerializerMap map = this._dynamicSerializers;
/* 63 */       ser = map.serializerFor(cls);
/* 64 */       if (ser == null) {
/* 65 */         ser = _findAndAddDynamic(map, cls, prov);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 70 */     if (!ser.isUnwrappingSerializer()) {
/* 71 */       jgen.writeFieldName(this._name);
/*    */     }
/*    */ 
/* 74 */     if (this._typeSerializer == null)
/* 75 */       ser.serialize(value, jgen, prov);
/*    */     else
/* 77 */       ser.serializeWithType(value, jgen, prov, this._typeSerializer);
/*    */   }
/*    */ 
/*    */   protected JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider)
/*    */     throws JsonMappingException
/*    */   {
/*    */     JsonSerializer serializer;
/*    */     JsonSerializer serializer;
/* 87 */     if (this._nonTrivialBaseType != null) {
/* 88 */       JavaType t = this._nonTrivialBaseType.forcedNarrowBy(type);
/* 89 */       serializer = provider.findValueSerializer(t, this);
/*    */     } else {
/* 91 */       serializer = provider.findValueSerializer(type, this);
/*    */     }
/* 93 */     if (!serializer.isUnwrappingSerializer()) {
/* 94 */       serializer = serializer.unwrappingSerializer();
/*    */     }
/* 96 */     this._dynamicSerializers = this._dynamicSerializers.newWith(type, serializer);
/* 97 */     return serializer;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.impl.UnwrappingBeanPropertyWriter
 * JD-Core Version:    0.6.2
 */