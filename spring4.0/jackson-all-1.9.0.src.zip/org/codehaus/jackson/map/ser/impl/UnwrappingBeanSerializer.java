/*    */ package org.codehaus.jackson.map.ser.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.JsonSerializer;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.ser.std.BeanSerializerBase;
/*    */ 
/*    */ public class UnwrappingBeanSerializer extends BeanSerializerBase
/*    */ {
/*    */   public UnwrappingBeanSerializer(BeanSerializerBase src)
/*    */   {
/* 25 */     super(src);
/*    */   }
/*    */ 
/*    */   public JsonSerializer<Object> unwrappingSerializer()
/*    */   {
/* 37 */     return this;
/*    */   }
/*    */ 
/*    */   public boolean isUnwrappingSerializer()
/*    */   {
/* 42 */     return true;
/*    */   }
/*    */ 
/*    */   public final void serialize(Object bean, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 60 */     if (this._propertyFilterId != null)
/* 61 */       serializeFieldsFiltered(bean, jgen, provider);
/*    */     else
/* 63 */       serializeFields(bean, jgen, provider);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 74 */     return "UnwrappingBeanSerializer for " + handledType().getName();
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.impl.UnwrappingBeanSerializer
 * JD-Core Version:    0.6.2
 */