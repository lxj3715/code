/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.ResolvableSerializer;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap.SerializerAndMapResult;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ import org.codehaus.jackson.schema.JsonSchema;
/*     */ import org.codehaus.jackson.schema.SchemaAware;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class AsArraySerializerBase<T> extends ContainerSerializerBase<T>
/*     */   implements ResolvableSerializer
/*     */ {
/*     */   protected final boolean _staticTyping;
/*     */   protected final JavaType _elementType;
/*     */   protected final TypeSerializer _valueTypeSerializer;
/*     */   protected JsonSerializer<Object> _elementSerializer;
/*     */   protected final BeanProperty _property;
/*     */   protected PropertySerializerMap _dynamicSerializers;
/*     */ 
/*     */   @Deprecated
/*     */   protected AsArraySerializerBase(Class<?> cls, JavaType et, boolean staticTyping, TypeSerializer vts, BeanProperty property)
/*     */   {
/*  64 */     this(cls, et, staticTyping, vts, property, null);
/*     */   }
/*     */ 
/*     */   protected AsArraySerializerBase(Class<?> cls, JavaType et, boolean staticTyping, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> elementSerializer)
/*     */   {
/*  71 */     super(cls, false);
/*  72 */     this._elementType = et;
/*     */ 
/*  74 */     this._staticTyping = ((staticTyping) || ((et != null) && (et.isFinal())));
/*  75 */     this._valueTypeSerializer = vts;
/*  76 */     this._property = property;
/*  77 */     this._elementSerializer = elementSerializer;
/*  78 */     this._dynamicSerializers = PropertySerializerMap.emptyMap();
/*     */   }
/*     */ 
/*     */   public final void serialize(T value, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/*  85 */     jgen.writeStartArray();
/*  86 */     serializeContents(value, jgen, provider);
/*  87 */     jgen.writeEndArray();
/*     */   }
/*     */ 
/*     */   public final void serializeWithType(T value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/*  95 */     typeSer.writeTypePrefixForArray(value, jgen);
/*  96 */     serializeContents(value, jgen, provider);
/*  97 */     typeSer.writeTypeSuffixForArray(value, jgen);
/*     */   }
/*     */ 
/*     */   protected abstract void serializeContents(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider)
/*     */     throws IOException, JsonGenerationException;
/*     */ 
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 112 */     ObjectNode o = createSchemaNode("array", true);
/* 113 */     JavaType contentType = null;
/* 114 */     if (typeHint != null) {
/* 115 */       JavaType javaType = provider.constructType(typeHint);
/* 116 */       contentType = javaType.getContentType();
/* 117 */       if ((contentType == null) && 
/* 118 */         ((typeHint instanceof ParameterizedType))) {
/* 119 */         Type[] typeArgs = ((ParameterizedType)typeHint).getActualTypeArguments();
/* 120 */         if (typeArgs.length == 1) {
/* 121 */           contentType = provider.constructType(typeArgs[0]);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 126 */     if ((contentType == null) && (this._elementType != null)) {
/* 127 */       contentType = this._elementType;
/*     */     }
/* 129 */     if (contentType != null) {
/* 130 */       JsonNode schemaNode = null;
/*     */ 
/* 132 */       if (contentType.getRawClass() != Object.class) {
/* 133 */         JsonSerializer ser = provider.findValueSerializer(contentType, this._property);
/* 134 */         if ((ser instanceof SchemaAware)) {
/* 135 */           schemaNode = ((SchemaAware)ser).getSchema(provider, null);
/*     */         }
/*     */       }
/* 138 */       if (schemaNode == null) {
/* 139 */         schemaNode = JsonSchema.getDefaultSchemaNode();
/*     */       }
/* 141 */       o.put("items", schemaNode);
/*     */     }
/* 143 */     return o;
/*     */   }
/*     */ 
/*     */   public void resolve(SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 154 */     if ((this._staticTyping) && (this._elementType != null) && (this._elementSerializer == null))
/* 155 */       this._elementSerializer = provider.findValueSerializer(this._elementType, this._property);
/*     */   }
/*     */ 
/*     */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 165 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSerializer(type, provider, this._property);
/*     */ 
/* 167 */     if (map != result.map) {
/* 168 */       this._dynamicSerializers = result.map;
/*     */     }
/* 170 */     return result.serializer;
/*     */   }
/*     */ 
/*     */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, JavaType type, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 179 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSerializer(type, provider, this._property);
/* 180 */     if (map != result.map) {
/* 181 */       this._dynamicSerializers = result.map;
/*     */     }
/* 183 */     return result.serializer;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.AsArraySerializerBase
 * JD-Core Version:    0.6.2
 */