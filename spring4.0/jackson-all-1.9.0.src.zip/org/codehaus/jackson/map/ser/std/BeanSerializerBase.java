/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonMappingException.Reference;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.ResolvableSerializer;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.ser.AnyGetterWriter;
/*     */ import org.codehaus.jackson.map.ser.BeanPropertyFilter;
/*     */ import org.codehaus.jackson.map.ser.BeanPropertyWriter;
/*     */ import org.codehaus.jackson.map.ser.FilterProvider;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ import org.codehaus.jackson.schema.JsonSchema;
/*     */ import org.codehaus.jackson.schema.SchemaAware;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class BeanSerializerBase extends SerializerBase<Object>
/*     */   implements ResolvableSerializer, SchemaAware
/*     */ {
/*  28 */   protected static final BeanPropertyWriter[] NO_PROPS = new BeanPropertyWriter[0];
/*     */   protected final BeanPropertyWriter[] _props;
/*     */   protected final BeanPropertyWriter[] _filteredProps;
/*     */   protected final AnyGetterWriter _anyGetterWriter;
/*     */   protected final Object _propertyFilterId;
/*     */ 
/*     */   protected BeanSerializerBase(JavaType type, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties, AnyGetterWriter anyGetterWriter, Object filterId)
/*     */   {
/*  75 */     super(type);
/*  76 */     this._props = properties;
/*  77 */     this._filteredProps = filteredProperties;
/*  78 */     this._anyGetterWriter = anyGetterWriter;
/*  79 */     this._propertyFilterId = filterId;
/*     */   }
/*     */ 
/*     */   public BeanSerializerBase(Class<?> rawType, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties, AnyGetterWriter anyGetterWriter, Object filterId)
/*     */   {
/*  88 */     super(rawType);
/*  89 */     this._props = properties;
/*  90 */     this._filteredProps = filteredProperties;
/*  91 */     this._anyGetterWriter = anyGetterWriter;
/*  92 */     this._propertyFilterId = filterId;
/*     */   }
/*     */ 
/*     */   protected BeanSerializerBase(BeanSerializerBase src)
/*     */   {
/* 100 */     this(src._handledType, src._props, src._filteredProps, src._anyGetterWriter, src._propertyFilterId);
/*     */   }
/*     */ 
/*     */   public abstract void serialize(Object paramObject, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider)
/*     */     throws IOException, JsonGenerationException;
/*     */ 
/*     */   public void serializeWithType(Object bean, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 121 */     typeSer.writeTypePrefixForObject(bean, jgen);
/* 122 */     if (this._propertyFilterId != null)
/* 123 */       serializeFieldsFiltered(bean, jgen, provider);
/*     */     else {
/* 125 */       serializeFields(bean, jgen, provider);
/*     */     }
/* 127 */     typeSer.writeTypeSuffixForObject(bean, jgen);
/*     */   }
/*     */ 
/*     */   protected void serializeFields(Object bean, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/*     */     BeanPropertyWriter[] props;
/*     */     BeanPropertyWriter[] props;
/* 140 */     if ((this._filteredProps != null) && (provider.getSerializationView() != null))
/* 141 */       props = this._filteredProps;
/*     */     else {
/* 143 */       props = this._props;
/*     */     }
/* 145 */     int i = 0;
/*     */     try {
/* 147 */       for (int len = props.length; i < len; i++) {
/* 148 */         BeanPropertyWriter prop = props[i];
/* 149 */         if (prop != null) {
/* 150 */           prop.serializeAsField(bean, jgen, provider);
/*     */         }
/*     */       }
/* 153 */       if (this._anyGetterWriter != null)
/* 154 */         this._anyGetterWriter.getAndSerialize(bean, jgen, provider);
/*     */     }
/*     */     catch (Exception e) {
/* 157 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 158 */       wrapAndThrow(provider, e, bean, name);
/*     */     }
/*     */     catch (StackOverflowError e)
/*     */     {
/* 164 */       JsonMappingException mapE = new JsonMappingException("Infinite recursion (StackOverflowError)");
/* 165 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 166 */       mapE.prependPath(new JsonMappingException.Reference(bean, name));
/* 167 */       throw mapE;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void serializeFieldsFiltered(Object bean, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/*     */     BeanPropertyWriter[] props;
/*     */     BeanPropertyWriter[] props;
/* 186 */     if ((this._filteredProps != null) && (provider.getSerializationView() != null))
/* 187 */       props = this._filteredProps;
/*     */     else {
/* 189 */       props = this._props;
/*     */     }
/* 191 */     BeanPropertyFilter filter = findFilter(provider);
/*     */ 
/* 193 */     if (filter == null) {
/* 194 */       serializeFields(bean, jgen, provider);
/* 195 */       return;
/*     */     }
/*     */ 
/* 198 */     int i = 0;
/*     */     try {
/* 200 */       for (int len = props.length; i < len; i++) {
/* 201 */         BeanPropertyWriter prop = props[i];
/* 202 */         if (prop != null) {
/* 203 */           filter.serializeAsField(bean, jgen, provider, prop);
/*     */         }
/*     */       }
/* 206 */       if (this._anyGetterWriter != null)
/* 207 */         this._anyGetterWriter.getAndSerialize(bean, jgen, provider);
/*     */     }
/*     */     catch (Exception e) {
/* 210 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 211 */       wrapAndThrow(provider, e, bean, name);
/*     */     } catch (StackOverflowError e) {
/* 213 */       JsonMappingException mapE = new JsonMappingException("Infinite recursion (StackOverflowError)");
/* 214 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 215 */       mapE.prependPath(new JsonMappingException.Reference(bean, name));
/* 216 */       throw mapE;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected BeanPropertyFilter findFilter(SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 229 */     Object filterId = this._propertyFilterId;
/* 230 */     FilterProvider filters = provider.getFilterProvider();
/*     */ 
/* 232 */     if (filters == null) {
/* 233 */       throw new JsonMappingException("Can not resolve BeanPropertyFilter with id '" + filterId + "'; no FilterProvider configured");
/*     */     }
/* 235 */     BeanPropertyFilter filter = filters.findFilter(filterId);
/*     */ 
/* 237 */     return filter;
/*     */   }
/*     */ 
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 244 */     ObjectNode o = createSchemaNode("object", true);
/*     */ 
/* 247 */     ObjectNode propertiesNode = o.objectNode();
/* 248 */     for (int i = 0; i < this._props.length; i++) {
/* 249 */       BeanPropertyWriter prop = this._props[i];
/* 250 */       JavaType propType = prop.getSerializationType();
/*     */ 
/* 252 */       Type hint = propType == null ? prop.getGenericPropertyType() : propType.getRawClass();
/*     */ 
/* 254 */       JsonSerializer ser = prop.getSerializer();
/* 255 */       if (ser == null) {
/* 256 */         Class serType = prop.getRawSerializationType();
/* 257 */         if (serType == null) {
/* 258 */           serType = prop.getPropertyType();
/*     */         }
/* 260 */         ser = provider.findValueSerializer(serType, prop);
/*     */       }
/* 262 */       JsonNode schemaNode = (ser instanceof SchemaAware) ? ((SchemaAware)ser).getSchema(provider, hint) : JsonSchema.getDefaultSchemaNode();
/*     */ 
/* 265 */       propertiesNode.put(prop.getName(), schemaNode);
/*     */     }
/* 267 */     o.put("properties", propertiesNode);
/* 268 */     return o;
/*     */   }
/*     */ 
/*     */   public void resolve(SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 281 */     int filteredCount = this._filteredProps == null ? 0 : this._filteredProps.length;
/* 282 */     int i = 0; for (int len = this._props.length; i < len; i++) {
/* 283 */       BeanPropertyWriter prop = this._props[i];
/* 284 */       if (!prop.hasSerializer())
/*     */       {
/* 288 */         JavaType type = prop.getSerializationType();
/*     */ 
/* 294 */         if (type == null) {
/* 295 */           type = provider.constructType(prop.getGenericPropertyType());
/* 296 */           if (!type.isFinal())
/*     */           {
/* 301 */             if ((!type.isContainerType()) && (type.containedTypeCount() <= 0)) continue;
/* 302 */             prop.setNonTrivialBaseType(type); continue;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 307 */         JsonSerializer ser = provider.findValueSerializer(type, prop);
/*     */ 
/* 311 */         if (type.isContainerType()) {
/* 312 */           TypeSerializer typeSer = (TypeSerializer)type.getContentType().getTypeHandler();
/* 313 */           if (typeSer != null)
/*     */           {
/* 315 */             if ((ser instanceof ContainerSerializerBase))
/*     */             {
/* 318 */               JsonSerializer ser2 = ((ContainerSerializerBase)ser).withValueTypeSerializer(typeSer);
/* 319 */               ser = ser2;
/*     */             }
/*     */           }
/*     */         }
/* 323 */         prop = prop.withSerializer(ser);
/* 324 */         this._props[i] = prop;
/*     */ 
/* 326 */         if (i < filteredCount) {
/* 327 */           BeanPropertyWriter w2 = this._filteredProps[i];
/* 328 */           if (w2 != null) {
/* 329 */             this._filteredProps[i] = w2.withSerializer(ser);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 335 */     if (this._anyGetterWriter != null)
/* 336 */       this._anyGetterWriter.resolve(provider);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.BeanSerializerBase
 * JD-Core Version:    0.6.2
 */