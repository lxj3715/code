/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.JsonSerializer;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class CollectionSerializer extends AsArraySerializerBase<Collection<?>>
/*    */ {
/*    */   public CollectionSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> valueSerializer)
/*    */   {
/* 29 */     super(Collection.class, elemType, staticTyping, vts, property, valueSerializer);
/*    */   }
/*    */ 
/*    */   public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*    */   {
/* 34 */     return new CollectionSerializer(this._elementType, this._staticTyping, vts, this._property, this._elementSerializer);
/*    */   }
/*    */ 
/*    */   public void serializeContents(Collection<?> value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 41 */     if (this._elementSerializer != null) {
/* 42 */       serializeContentsUsing(value, jgen, provider, this._elementSerializer);
/* 43 */       return;
/*    */     }
/* 45 */     Iterator it = value.iterator();
/* 46 */     if (!it.hasNext()) {
/* 47 */       return;
/*    */     }
/* 49 */     PropertySerializerMap serializers = this._dynamicSerializers;
/* 50 */     TypeSerializer typeSer = this._valueTypeSerializer;
/*    */ 
/* 52 */     int i = 0;
/*    */     try {
/*    */       do {
/* 55 */         Object elem = it.next();
/* 56 */         if (elem == null) {
/* 57 */           provider.defaultSerializeNull(jgen);
/*    */         } else {
/* 59 */           Class cc = elem.getClass();
/* 60 */           JsonSerializer serializer = serializers.serializerFor(cc);
/* 61 */           if (serializer == null)
/*    */           {
/* 63 */             if (this._elementType.hasGenericTypes())
/* 64 */               serializer = _findAndAddDynamic(serializers, this._elementType.forcedNarrowBy(cc), provider);
/*    */             else {
/* 66 */               serializer = _findAndAddDynamic(serializers, cc, provider);
/*    */             }
/* 68 */             serializers = this._dynamicSerializers;
/*    */           }
/* 70 */           if (typeSer == null)
/* 71 */             serializer.serialize(elem, jgen, provider);
/*    */           else {
/* 73 */             serializer.serializeWithType(elem, jgen, provider, typeSer);
/*    */           }
/*    */         }
/* 76 */         i++;
/* 77 */       }while (it.hasNext());
/*    */     }
/*    */     catch (Exception e) {
/* 80 */       wrapAndThrow(provider, e, value, i);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void serializeContentsUsing(Collection<?> value, JsonGenerator jgen, SerializerProvider provider, JsonSerializer<Object> ser)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 88 */     Iterator it = value.iterator();
/* 89 */     if (it.hasNext()) {
/* 90 */       TypeSerializer typeSer = this._valueTypeSerializer;
/* 91 */       int i = 0;
/*    */       do {
/* 93 */         Object elem = it.next();
/*    */         try {
/* 95 */           if (elem == null) {
/* 96 */             provider.defaultSerializeNull(jgen);
/*    */           }
/* 98 */           else if (typeSer == null)
/* 99 */             ser.serialize(elem, jgen, provider);
/*    */           else {
/* 101 */             ser.serializeWithType(elem, jgen, provider, typeSer);
/*    */           }
/*    */ 
/* 104 */           i++;
/*    */         }
/*    */         catch (Exception e) {
/* 107 */           wrapAndThrow(provider, e, value, i);
/*    */         }
/*    */       }
/* 109 */       while (it.hasNext());
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.CollectionSerializer
 * JD-Core Version:    0.6.2
 */