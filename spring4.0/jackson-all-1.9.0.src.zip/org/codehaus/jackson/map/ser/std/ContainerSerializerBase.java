/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ 
/*    */ public abstract class ContainerSerializerBase<T> extends SerializerBase<T>
/*    */ {
/*    */   protected ContainerSerializerBase(Class<T> t)
/*    */   {
/* 22 */     super(t);
/*    */   }
/*    */ 
/*    */   protected ContainerSerializerBase(Class<?> t, boolean dummy)
/*    */   {
/* 32 */     super(t, dummy);
/*    */   }
/*    */ 
/*    */   public ContainerSerializerBase<?> withValueTypeSerializer(TypeSerializer vts)
/*    */   {
/* 46 */     if (vts == null) return this;
/* 47 */     return _withValueTypeSerializer(vts);
/*    */   }
/*    */ 
/*    */   public abstract ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer paramTypeSerializer);
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.ContainerSerializerBase
 * JD-Core Version:    0.6.2
 */