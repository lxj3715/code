/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Map.Entry;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.ResolvableSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.util.EnumValues;
/*     */ import org.codehaus.jackson.node.JsonNodeFactory;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ import org.codehaus.jackson.schema.JsonSchema;
/*     */ import org.codehaus.jackson.schema.SchemaAware;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class EnumMapSerializer extends ContainerSerializerBase<EnumMap<? extends Enum<?>, ?>>
/*     */   implements ResolvableSerializer
/*     */ {
/*     */   protected final boolean _staticTyping;
/*     */   protected final EnumValues _keyEnums;
/*     */   protected final JavaType _valueType;
/*     */   protected final BeanProperty _property;
/*     */   protected JsonSerializer<Object> _valueSerializer;
/*     */   protected final TypeSerializer _valueTypeSerializer;
/*     */ 
/*     */   @Deprecated
/*     */   public EnumMapSerializer(JavaType valueType, boolean staticTyping, EnumValues keyEnums, TypeSerializer vts, BeanProperty property)
/*     */   {
/*  64 */     this(valueType, staticTyping, keyEnums, vts, property, null);
/*     */   }
/*     */ 
/*     */   public EnumMapSerializer(JavaType valueType, boolean staticTyping, EnumValues keyEnums, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> valueSerializer)
/*     */   {
/*  70 */     super(EnumMap.class, false);
/*  71 */     this._staticTyping = ((staticTyping) || ((valueType != null) && (valueType.isFinal())));
/*  72 */     this._valueType = valueType;
/*  73 */     this._keyEnums = keyEnums;
/*  74 */     this._valueTypeSerializer = vts;
/*  75 */     this._property = property;
/*  76 */     this._valueSerializer = valueSerializer;
/*     */   }
/*     */ 
/*     */   public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */   {
/*  82 */     return new EnumMapSerializer(this._valueType, this._staticTyping, this._keyEnums, vts, this._property);
/*     */   }
/*     */ 
/*     */   public void serialize(EnumMap<? extends Enum<?>, ?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/*  89 */     jgen.writeStartObject();
/*  90 */     if (!value.isEmpty()) {
/*  91 */       serializeContents(value, jgen, provider);
/*     */     }
/*  93 */     jgen.writeEndObject();
/*     */   }
/*     */ 
/*     */   public void serializeWithType(EnumMap<? extends Enum<?>, ?> value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 101 */     typeSer.writeTypePrefixForObject(value, jgen);
/* 102 */     if (!value.isEmpty()) {
/* 103 */       serializeContents(value, jgen, provider);
/*     */     }
/* 105 */     typeSer.writeTypeSuffixForObject(value, jgen);
/*     */   }
/*     */ 
/*     */   protected void serializeContents(EnumMap<? extends Enum<?>, ?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 111 */     if (this._valueSerializer != null) {
/* 112 */       serializeContentsUsing(value, jgen, provider, this._valueSerializer);
/* 113 */       return;
/*     */     }
/* 115 */     JsonSerializer prevSerializer = null;
/* 116 */     Class prevClass = null;
/* 117 */     EnumValues keyEnums = this._keyEnums;
/*     */ 
/* 119 */     for (Map.Entry entry : value.entrySet())
/*     */     {
/* 121 */       Enum key = (Enum)entry.getKey();
/* 122 */       if (keyEnums == null)
/*     */       {
/* 128 */         SerializerBase ser = (SerializerBase)provider.findValueSerializer(key.getDeclaringClass(), this._property);
/*     */ 
/* 130 */         keyEnums = ((EnumSerializer)ser).getEnumValues();
/*     */       }
/* 132 */       jgen.writeFieldName(keyEnums.serializedValueFor(key));
/*     */ 
/* 134 */       Object valueElem = entry.getValue();
/* 135 */       if (valueElem == null) {
/* 136 */         provider.defaultSerializeNull(jgen);
/*     */       } else {
/* 138 */         Class cc = valueElem.getClass();
/*     */         JsonSerializer currSerializer;
/*     */         JsonSerializer currSerializer;
/* 140 */         if (cc == prevClass) {
/* 141 */           currSerializer = prevSerializer;
/*     */         } else {
/* 143 */           currSerializer = provider.findValueSerializer(cc, this._property);
/* 144 */           prevSerializer = currSerializer;
/* 145 */           prevClass = cc;
/*     */         }
/*     */         try {
/* 148 */           currSerializer.serialize(valueElem, jgen, provider);
/*     */         }
/*     */         catch (Exception e) {
/* 151 */           wrapAndThrow(provider, e, value, ((Enum)entry.getKey()).name());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void serializeContentsUsing(EnumMap<? extends Enum<?>, ?> value, JsonGenerator jgen, SerializerProvider provider, JsonSerializer<Object> valueSer)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 161 */     EnumValues keyEnums = this._keyEnums;
/* 162 */     for (Map.Entry entry : value.entrySet()) {
/* 163 */       Enum key = (Enum)entry.getKey();
/* 164 */       if (keyEnums == null)
/*     */       {
/* 166 */         SerializerBase ser = (SerializerBase)provider.findValueSerializer(key.getDeclaringClass(), this._property);
/*     */ 
/* 168 */         keyEnums = ((EnumSerializer)ser).getEnumValues();
/*     */       }
/* 170 */       jgen.writeFieldName(keyEnums.serializedValueFor(key));
/* 171 */       Object valueElem = entry.getValue();
/* 172 */       if (valueElem == null)
/* 173 */         provider.defaultSerializeNull(jgen);
/*     */       else
/*     */         try {
/* 176 */           valueSer.serialize(valueElem, jgen, provider);
/*     */         } catch (Exception e) {
/* 178 */           wrapAndThrow(provider, e, value, ((Enum)entry.getKey()).name());
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resolve(SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 188 */     if ((this._staticTyping) && (this._valueSerializer == null))
/* 189 */       this._valueSerializer = provider.findValueSerializer(this._valueType, this._property);
/*     */   }
/*     */ 
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 198 */     ObjectNode o = createSchemaNode("object", true);
/* 199 */     if ((typeHint instanceof ParameterizedType)) {
/* 200 */       Type[] typeArgs = ((ParameterizedType)typeHint).getActualTypeArguments();
/* 201 */       if (typeArgs.length == 2) {
/* 202 */         JavaType enumType = provider.constructType(typeArgs[0]);
/* 203 */         JavaType valueType = provider.constructType(typeArgs[1]);
/* 204 */         ObjectNode propsNode = JsonNodeFactory.instance.objectNode();
/* 205 */         Class enumClass = enumType.getRawClass();
/* 206 */         for (Enum enumValue : (Enum[])enumClass.getEnumConstants()) {
/* 207 */           JsonSerializer ser = provider.findValueSerializer(valueType.getRawClass(), this._property);
/* 208 */           JsonNode schemaNode = (ser instanceof SchemaAware) ? ((SchemaAware)ser).getSchema(provider, null) : JsonSchema.getDefaultSchemaNode();
/*     */ 
/* 211 */           propsNode.put(provider.getConfig().getAnnotationIntrospector().findEnumValue(enumValue), schemaNode);
/*     */         }
/* 213 */         o.put("properties", propsNode);
/*     */       }
/*     */     }
/* 216 */     return o;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.EnumMapSerializer
 * JD-Core Version:    0.6.2
 */