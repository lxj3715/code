/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.io.SerializedString;
/*    */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*    */ import org.codehaus.jackson.map.SerializationConfig;
/*    */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ import org.codehaus.jackson.map.introspect.BasicBeanDescription;
/*    */ import org.codehaus.jackson.map.util.EnumValues;
/*    */ import org.codehaus.jackson.node.ArrayNode;
/*    */ import org.codehaus.jackson.node.ObjectNode;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class EnumSerializer extends ScalarSerializerBase<Enum<?>>
/*    */ {
/*    */   protected final EnumValues _values;
/*    */ 
/*    */   public EnumSerializer(EnumValues v)
/*    */   {
/* 36 */     super(Enum.class, false);
/* 37 */     this._values = v;
/*    */   }
/*    */ 
/*    */   public static EnumSerializer construct(Class<Enum<?>> enumClass, SerializationConfig config, BasicBeanDescription beanDesc)
/*    */   {
/* 44 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 45 */     EnumValues v = config.isEnabled(SerializationConfig.Feature.WRITE_ENUMS_USING_TO_STRING) ? EnumValues.constructFromToString(enumClass, intr) : EnumValues.constructFromName(enumClass, intr);
/*    */ 
/* 47 */     return new EnumSerializer(v);
/*    */   }
/*    */ 
/*    */   public final void serialize(Enum<?> en, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 55 */     if (provider.isEnabled(SerializationConfig.Feature.WRITE_ENUMS_USING_INDEX)) {
/* 56 */       jgen.writeNumber(en.ordinal());
/* 57 */       return;
/*    */     }
/* 59 */     jgen.writeString(this._values.serializedValueFor(en));
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */   {
/* 66 */     if (provider.isEnabled(SerializationConfig.Feature.WRITE_ENUMS_USING_INDEX)) {
/* 67 */       return createSchemaNode("integer", true);
/*    */     }
/* 69 */     ObjectNode objectNode = createSchemaNode("string", true);
/*    */     ArrayNode enumNode;
/* 70 */     if (typeHint != null) {
/* 71 */       JavaType type = provider.constructType(typeHint);
/* 72 */       if (type.isEnumType()) {
/* 73 */         enumNode = objectNode.putArray("enum");
/* 74 */         for (SerializedString value : this._values.values()) {
/* 75 */           enumNode.add(value.getValue());
/*    */         }
/*    */       }
/*    */     }
/* 79 */     return objectNode;
/*    */   }
/*    */   public EnumValues getEnumValues() {
/* 82 */     return this._values;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.EnumSerializer
 * JD-Core Version:    0.6.2
 */