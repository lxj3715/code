/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.EnumSet;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.JsonSerializer;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class EnumSetSerializer extends AsArraySerializerBase<EnumSet<? extends Enum<?>>>
/*    */ {
/*    */   public EnumSetSerializer(JavaType elemType, BeanProperty property)
/*    */   {
/* 19 */     super(EnumSet.class, elemType, true, null, property, null);
/*    */   }
/*    */ 
/*    */   public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*    */   {
/* 25 */     return this;
/*    */   }
/*    */ 
/*    */   public void serializeContents(EnumSet<? extends Enum<?>> value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 32 */     JsonSerializer enumSer = this._elementSerializer;
/*    */ 
/* 37 */     for (Enum en : value) {
/* 38 */       if (enumSer == null)
/*    */       {
/* 42 */         enumSer = provider.findValueSerializer(en.getDeclaringClass(), this._property);
/*    */       }
/* 44 */       enumSer.serialize(en, jgen, provider);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.EnumSetSerializer
 * JD-Core Version:    0.6.2
 */