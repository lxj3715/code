/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ 
/*    */ public class InetAddressSerializer extends ScalarSerializerBase<InetAddress>
/*    */ {
/* 20 */   public static final InetAddressSerializer instance = new InetAddressSerializer();
/*    */ 
/* 22 */   public InetAddressSerializer() { super(InetAddress.class); }
/*    */ 
/*    */ 
/*    */   public void serialize(InetAddress value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 29 */     String str = value.toString().trim();
/* 30 */     int ix = str.indexOf('/');
/* 31 */     if (ix >= 0) {
/* 32 */       if (ix == 0)
/* 33 */         str = str.substring(1);
/*    */       else {
/* 35 */         str = str.substring(0, ix);
/*    */       }
/*    */     }
/* 38 */     jgen.writeString(str);
/*    */   }
/*    */ 
/*    */   public void serializeWithType(InetAddress value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 47 */     typeSer.writeTypePrefixForScalar(value, jgen, InetAddress.class);
/* 48 */     serialize(value, jgen, provider);
/* 49 */     typeSer.writeTypeSuffixForScalar(value, jgen);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.InetAddressSerializer
 * JD-Core Version:    0.6.2
 */