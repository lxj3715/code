/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.JsonSerializer;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class IterableSerializer extends AsArraySerializerBase<Iterable<?>>
/*    */ {
/*    */   public IterableSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property)
/*    */   {
/* 21 */     super(Iterable.class, elemType, staticTyping, vts, property, null);
/*    */   }
/*    */ 
/*    */   public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*    */   {
/* 26 */     return new IterableSerializer(this._elementType, this._staticTyping, vts, this._property);
/*    */   }
/*    */ 
/*    */   public void serializeContents(Iterable<?> value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 33 */     Iterator it = value.iterator();
/* 34 */     if (it.hasNext()) {
/* 35 */       TypeSerializer typeSer = this._valueTypeSerializer;
/* 36 */       JsonSerializer prevSerializer = null;
/* 37 */       Class prevClass = null;
/*    */       do
/*    */       {
/* 40 */         Object elem = it.next();
/* 41 */         if (elem == null) {
/* 42 */           provider.defaultSerializeNull(jgen);
/*    */         }
/*    */         else {
/* 45 */           Class cc = elem.getClass();
/*    */           JsonSerializer currSerializer;
/*    */           JsonSerializer currSerializer;
/* 47 */           if (cc == prevClass) {
/* 48 */             currSerializer = prevSerializer;
/*    */           } else {
/* 50 */             currSerializer = provider.findValueSerializer(cc, this._property);
/* 51 */             prevSerializer = currSerializer;
/* 52 */             prevClass = cc;
/*    */           }
/* 54 */           if (typeSer == null)
/* 55 */             currSerializer.serialize(elem, jgen, provider);
/*    */           else
/* 57 */             currSerializer.serializeWithType(elem, jgen, provider, typeSer);
/*    */         }
/*    */       }
/* 60 */       while (it.hasNext());
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.IterableSerializer
 * JD-Core Version:    0.6.2
 */