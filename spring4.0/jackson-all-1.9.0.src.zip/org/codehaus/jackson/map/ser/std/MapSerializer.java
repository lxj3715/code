/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.ResolvableSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap.SerializerAndMapResult;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class MapSerializer extends ContainerSerializerBase<Map<?, ?>>
/*     */   implements ResolvableSerializer
/*     */ {
/*  28 */   protected static final JavaType UNSPECIFIED_TYPE = TypeFactory.unknownType();
/*     */   protected final BeanProperty _property;
/*     */   protected final HashSet<String> _ignoredEntries;
/*     */   protected final boolean _valueTypeIsStatic;
/*     */   protected final JavaType _keyType;
/*     */   protected final JavaType _valueType;
/*     */   protected JsonSerializer<Object> _keySerializer;
/*     */   protected JsonSerializer<Object> _valueSerializer;
/*     */   protected final TypeSerializer _valueTypeSerializer;
/*     */   protected PropertySerializerMap _dynamicValueSerializers;
/*     */ 
/*     */   protected MapSerializer()
/*     */   {
/*  88 */     this((HashSet)null, null, null, false, null, null, null, null);
/*     */   }
/*     */ 
/*     */   protected MapSerializer(HashSet<String> ignoredEntries, JavaType keyType, JavaType valueType, boolean valueTypeIsStatic, TypeSerializer vts, JsonSerializer<Object> keySerializer, JsonSerializer<Object> valueSerializer, BeanProperty property)
/*     */   {
/*  97 */     super(Map.class, false);
/*  98 */     this._property = property;
/*  99 */     this._ignoredEntries = ignoredEntries;
/* 100 */     this._keyType = keyType;
/* 101 */     this._valueType = valueType;
/* 102 */     this._valueTypeIsStatic = valueTypeIsStatic;
/* 103 */     this._valueTypeSerializer = vts;
/* 104 */     this._keySerializer = keySerializer;
/* 105 */     this._valueSerializer = valueSerializer;
/* 106 */     this._dynamicValueSerializers = PropertySerializerMap.emptyMap();
/*     */   }
/*     */ 
/*     */   public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */   {
/* 112 */     MapSerializer ms = new MapSerializer(this._ignoredEntries, this._keyType, this._valueType, this._valueTypeIsStatic, vts, this._keySerializer, this._valueSerializer, this._property);
/*     */ 
/* 114 */     if (this._valueSerializer != null) {
/* 115 */       ms._valueSerializer = this._valueSerializer;
/*     */     }
/* 117 */     return ms;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static MapSerializer construct(String[] ignoredList, JavaType mapType, boolean staticValueType, TypeSerializer vts, BeanProperty property)
/*     */   {
/* 136 */     return construct(ignoredList, mapType, staticValueType, vts, property, null, null);
/*     */   }
/*     */ 
/*     */   public static MapSerializer construct(String[] ignoredList, JavaType mapType, boolean staticValueType, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> keySerializer, JsonSerializer<Object> valueSerializer)
/*     */   {
/* 143 */     HashSet ignoredEntries = toSet(ignoredList);
/*     */     JavaType keyType;
/*     */     JavaType keyType;
/*     */     JavaType valueType;
/* 146 */     if (mapType == null)
/*     */     {
/*     */       JavaType valueType;
/* 147 */       keyType = valueType = UNSPECIFIED_TYPE;
/*     */     } else {
/* 149 */       keyType = mapType.getKeyType();
/* 150 */       valueType = mapType.getContentType();
/*     */     }
/*     */ 
/* 153 */     if (!staticValueType) {
/* 154 */       staticValueType = (valueType != null) && (valueType.isFinal());
/*     */     }
/* 156 */     return new MapSerializer(ignoredEntries, keyType, valueType, staticValueType, vts, keySerializer, valueSerializer, property);
/*     */   }
/*     */ 
/*     */   private static HashSet<String> toSet(String[] ignoredEntries)
/*     */   {
/* 161 */     if ((ignoredEntries == null) || (ignoredEntries.length == 0)) {
/* 162 */       return null;
/*     */     }
/* 164 */     HashSet result = new HashSet(ignoredEntries.length);
/* 165 */     for (String prop : ignoredEntries) {
/* 166 */       result.add(prop);
/*     */     }
/* 168 */     return result;
/*     */   }
/*     */ 
/*     */   public void serialize(Map<?, ?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 181 */     jgen.writeStartObject();
/* 182 */     if (!value.isEmpty()) {
/* 183 */       if (this._valueSerializer != null)
/* 184 */         serializeFieldsUsing(value, jgen, provider, this._valueSerializer);
/*     */       else {
/* 186 */         serializeFields(value, jgen, provider);
/*     */       }
/*     */     }
/* 189 */     jgen.writeEndObject();
/*     */   }
/*     */ 
/*     */   public void serializeWithType(Map<?, ?> value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 197 */     typeSer.writeTypePrefixForObject(value, jgen);
/* 198 */     if (!value.isEmpty()) {
/* 199 */       if (this._valueSerializer != null)
/* 200 */         serializeFieldsUsing(value, jgen, provider, this._valueSerializer);
/*     */       else {
/* 202 */         serializeFields(value, jgen, provider);
/*     */       }
/*     */     }
/* 205 */     typeSer.writeTypeSuffixForObject(value, jgen);
/*     */   }
/*     */ 
/*     */   public void serializeFields(Map<?, ?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 221 */     if (this._valueTypeSerializer != null) {
/* 222 */       serializeTypedFields(value, jgen, provider);
/* 223 */       return;
/*     */     }
/* 225 */     JsonSerializer keySerializer = this._keySerializer;
/*     */ 
/* 227 */     HashSet ignored = this._ignoredEntries;
/* 228 */     boolean skipNulls = !provider.isEnabled(SerializationConfig.Feature.WRITE_NULL_MAP_VALUES);
/*     */ 
/* 230 */     PropertySerializerMap serializers = this._dynamicValueSerializers;
/*     */ 
/* 232 */     for (Map.Entry entry : value.entrySet()) {
/* 233 */       Object valueElem = entry.getValue();
/*     */ 
/* 235 */       Object keyElem = entry.getKey();
/* 236 */       if (keyElem == null) {
/* 237 */         provider.getNullKeySerializer().serialize(null, jgen, provider);
/*     */       }
/*     */       else {
/* 240 */         if (((skipNulls) && (valueElem == null)) || (
/* 242 */           (ignored != null) && (ignored.contains(keyElem)))) continue;
/* 243 */         keySerializer.serialize(keyElem, jgen, provider);
/*     */       }
/*     */ 
/* 247 */       if (valueElem == null) {
/* 248 */         provider.defaultSerializeNull(jgen);
/*     */       } else {
/* 250 */         Class cc = valueElem.getClass();
/* 251 */         JsonSerializer serializer = serializers.serializerFor(cc);
/* 252 */         if (serializer == null) {
/* 253 */           if (this._valueType.hasGenericTypes())
/* 254 */             serializer = _findAndAddDynamic(serializers, this._valueType.forcedNarrowBy(cc), provider);
/*     */           else {
/* 256 */             serializer = _findAndAddDynamic(serializers, cc, provider);
/*     */           }
/* 258 */           serializers = this._dynamicValueSerializers;
/*     */         }
/*     */         try {
/* 261 */           serializer.serialize(valueElem, jgen, provider);
/*     */         }
/*     */         catch (Exception e) {
/* 264 */           String keyDesc = "" + keyElem;
/* 265 */           wrapAndThrow(provider, e, value, keyDesc);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void serializeFieldsUsing(Map<?, ?> value, JsonGenerator jgen, SerializerProvider provider, JsonSerializer<Object> ser)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 280 */     JsonSerializer keySerializer = this._keySerializer;
/* 281 */     HashSet ignored = this._ignoredEntries;
/* 282 */     TypeSerializer typeSer = this._valueTypeSerializer;
/* 283 */     boolean skipNulls = !provider.isEnabled(SerializationConfig.Feature.WRITE_NULL_MAP_VALUES);
/*     */ 
/* 285 */     for (Map.Entry entry : value.entrySet()) {
/* 286 */       Object valueElem = entry.getValue();
/* 287 */       Object keyElem = entry.getKey();
/* 288 */       if (keyElem == null) {
/* 289 */         provider.getNullKeySerializer().serialize(null, jgen, provider);
/*     */       }
/*     */       else {
/* 292 */         if (((skipNulls) && (valueElem == null)) || (
/* 293 */           (ignored != null) && (ignored.contains(keyElem)))) continue;
/* 294 */         keySerializer.serialize(keyElem, jgen, provider);
/*     */       }
/* 296 */       if (valueElem == null)
/* 297 */         provider.defaultSerializeNull(jgen);
/*     */       else
/*     */         try {
/* 300 */           if (typeSer == null)
/* 301 */             ser.serialize(valueElem, jgen, provider);
/*     */           else
/* 303 */             ser.serializeWithType(valueElem, jgen, provider, typeSer);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 307 */           String keyDesc = "" + keyElem;
/* 308 */           wrapAndThrow(provider, e, value, keyDesc);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void serializeTypedFields(Map<?, ?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 317 */     JsonSerializer keySerializer = this._keySerializer;
/* 318 */     JsonSerializer prevValueSerializer = null;
/* 319 */     Class prevValueClass = null;
/* 320 */     HashSet ignored = this._ignoredEntries;
/* 321 */     boolean skipNulls = !provider.isEnabled(SerializationConfig.Feature.WRITE_NULL_MAP_VALUES);
/*     */ 
/* 323 */     for (Map.Entry entry : value.entrySet()) {
/* 324 */       Object valueElem = entry.getValue();
/*     */ 
/* 326 */       Object keyElem = entry.getKey();
/* 327 */       if (keyElem == null) {
/* 328 */         provider.getNullKeySerializer().serialize(null, jgen, provider);
/*     */       }
/*     */       else {
/* 331 */         if (((skipNulls) && (valueElem == null)) || (
/* 333 */           (ignored != null) && (ignored.contains(keyElem)))) continue;
/* 334 */         keySerializer.serialize(keyElem, jgen, provider);
/*     */       }
/*     */ 
/* 338 */       if (valueElem == null) {
/* 339 */         provider.defaultSerializeNull(jgen);
/*     */       } else {
/* 341 */         Class cc = valueElem.getClass();
/*     */         JsonSerializer currSerializer;
/*     */         JsonSerializer currSerializer;
/* 343 */         if (cc == prevValueClass) {
/* 344 */           currSerializer = prevValueSerializer;
/*     */         } else {
/* 346 */           currSerializer = provider.findValueSerializer(cc, this._property);
/* 347 */           prevValueSerializer = currSerializer;
/* 348 */           prevValueClass = cc;
/*     */         }
/*     */         try {
/* 351 */           currSerializer.serializeWithType(valueElem, jgen, provider, this._valueTypeSerializer);
/*     */         }
/*     */         catch (Exception e) {
/* 354 */           String keyDesc = "" + keyElem;
/* 355 */           wrapAndThrow(provider, e, value, keyDesc);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */   {
/* 364 */     ObjectNode o = createSchemaNode("object", true);
/*     */ 
/* 367 */     return o;
/*     */   }
/*     */ 
/*     */   public void resolve(SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 378 */     if ((this._valueTypeIsStatic) && (this._valueSerializer == null)) {
/* 379 */       this._valueSerializer = provider.findValueSerializer(this._valueType, this._property);
/*     */     }
/*     */ 
/* 388 */     if (this._keySerializer == null)
/* 389 */       this._keySerializer = provider.findKeySerializer(this._keyType, this._property);
/*     */   }
/*     */ 
/*     */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 402 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSerializer(type, provider, this._property);
/*     */ 
/* 404 */     if (map != result.map) {
/* 405 */       this._dynamicValueSerializers = result.map;
/*     */     }
/* 407 */     return result.serializer;
/*     */   }
/*     */ 
/*     */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, JavaType type, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 413 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSerializer(type, provider, this._property);
/* 414 */     if (map != result.map) {
/* 415 */       this._dynamicValueSerializers = result.map;
/*     */     }
/* 417 */     return result.serializer;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.MapSerializer
 * JD-Core Version:    0.6.2
 */