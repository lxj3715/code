/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ 
/*    */ public abstract class NonTypedScalarSerializerBase<T> extends ScalarSerializerBase<T>
/*    */ {
/*    */   protected NonTypedScalarSerializerBase(Class<T> t)
/*    */   {
/* 23 */     super(t);
/*    */   }
/*    */ 
/*    */   public final void serializeWithType(T value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 32 */     serialize(value, jgen, provider);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.NonTypedScalarSerializerBase
 * JD-Core Version:    0.6.2
 */