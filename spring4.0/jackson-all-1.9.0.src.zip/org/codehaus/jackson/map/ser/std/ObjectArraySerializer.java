/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Type;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.ResolvableSerializer;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap.SerializerAndMapResult;
/*     */ import org.codehaus.jackson.map.type.ArrayType;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ import org.codehaus.jackson.schema.JsonSchema;
/*     */ import org.codehaus.jackson.schema.SchemaAware;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class ObjectArraySerializer extends StdArraySerializers.ArraySerializerBase<Object[]>
/*     */   implements ResolvableSerializer
/*     */ {
/*     */   protected final boolean _staticTyping;
/*     */   protected final JavaType _elementType;
/*     */   protected JsonSerializer<Object> _elementSerializer;
/*     */   protected PropertySerializerMap _dynamicSerializers;
/*     */ 
/*     */   @Deprecated
/*     */   public ObjectArraySerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property)
/*     */   {
/*  67 */     this(elemType, staticTyping, vts, property, null);
/*     */   }
/*     */ 
/*     */   public ObjectArraySerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> elementSerializer)
/*     */   {
/*  73 */     super([Ljava.lang.Object.class, vts, property);
/*  74 */     this._elementType = elemType;
/*  75 */     this._staticTyping = staticTyping;
/*  76 */     this._dynamicSerializers = PropertySerializerMap.emptyMap();
/*  77 */     this._elementSerializer = elementSerializer;
/*     */   }
/*     */ 
/*     */   public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */   {
/*  83 */     return new ObjectArraySerializer(this._elementType, this._staticTyping, vts, this._property, this._elementSerializer);
/*     */   }
/*     */ 
/*     */   public void serializeContents(Object[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/*  90 */     int len = value.length;
/*  91 */     if (len == 0) {
/*  92 */       return;
/*     */     }
/*  94 */     if (this._elementSerializer != null) {
/*  95 */       serializeContentsUsing(value, jgen, provider, this._elementSerializer);
/*  96 */       return;
/*     */     }
/*  98 */     if (this._valueTypeSerializer != null) {
/*  99 */       serializeTypedContents(value, jgen, provider);
/* 100 */       return;
/*     */     }
/* 102 */     int i = 0;
/* 103 */     Object elem = null;
/*     */     try {
/* 105 */       PropertySerializerMap serializers = this._dynamicSerializers;
/* 106 */       for (; i < len; i++) {
/* 107 */         elem = value[i];
/* 108 */         if (elem == null) {
/* 109 */           provider.defaultSerializeNull(jgen);
/*     */         }
/*     */         else {
/* 112 */           Class cc = elem.getClass();
/* 113 */           JsonSerializer serializer = serializers.serializerFor(cc);
/* 114 */           if (serializer == null)
/*     */           {
/* 116 */             if (this._elementType.hasGenericTypes())
/* 117 */               serializer = _findAndAddDynamic(serializers, this._elementType.forcedNarrowBy(cc), provider);
/*     */             else {
/* 119 */               serializer = _findAndAddDynamic(serializers, cc, provider);
/*     */             }
/*     */           }
/* 122 */           serializer.serialize(elem, jgen, provider);
/*     */         }
/*     */       }
/*     */     } catch (IOException ioe) { throw ioe; }
/*     */     catch (Exception e)
/*     */     {
/* 132 */       Throwable t = e;
/* 133 */       while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 134 */         t = t.getCause();
/*     */       }
/* 136 */       if ((t instanceof Error)) {
/* 137 */         throw ((Error)t);
/*     */       }
/* 139 */       throw JsonMappingException.wrapWithPath(t, elem, i);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void serializeContentsUsing(Object[] value, JsonGenerator jgen, SerializerProvider provider, JsonSerializer<Object> ser)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 147 */     int len = value.length;
/* 148 */     TypeSerializer typeSer = this._valueTypeSerializer;
/*     */ 
/* 150 */     int i = 0;
/* 151 */     Object elem = null;
/*     */     try {
/* 153 */       for (; i < len; i++) {
/* 154 */         elem = value[i];
/* 155 */         if (elem == null) {
/* 156 */           provider.defaultSerializeNull(jgen);
/*     */         }
/* 159 */         else if (typeSer == null)
/* 160 */           ser.serialize(elem, jgen, provider);
/*     */         else
/* 162 */           ser.serializeWithType(elem, jgen, provider, typeSer);
/*     */       }
/*     */     }
/*     */     catch (IOException ioe) {
/* 166 */       throw ioe;
/*     */     } catch (Exception e) {
/* 168 */       Throwable t = e;
/* 169 */       while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 170 */         t = t.getCause();
/*     */       }
/* 172 */       if ((t instanceof Error)) {
/* 173 */         throw ((Error)t);
/*     */       }
/* 175 */       throw JsonMappingException.wrapWithPath(t, elem, i);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void serializeTypedContents(Object[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonGenerationException
/*     */   {
/* 182 */     int len = value.length;
/* 183 */     TypeSerializer typeSer = this._valueTypeSerializer;
/* 184 */     int i = 0;
/* 185 */     Object elem = null;
/*     */     try {
/* 187 */       PropertySerializerMap serializers = this._dynamicSerializers;
/* 188 */       for (; i < len; i++) {
/* 189 */         elem = value[i];
/* 190 */         if (elem == null) {
/* 191 */           provider.defaultSerializeNull(jgen);
/*     */         }
/*     */         else {
/* 194 */           Class cc = elem.getClass();
/* 195 */           JsonSerializer serializer = serializers.serializerFor(cc);
/* 196 */           if (serializer == null) {
/* 197 */             serializer = _findAndAddDynamic(serializers, cc, provider);
/*     */           }
/* 199 */           serializer.serializeWithType(elem, jgen, provider, typeSer);
/*     */         }
/*     */       }
/*     */     } catch (IOException ioe) { throw ioe;
/*     */     } catch (Exception e) {
/* 204 */       Throwable t = e;
/* 205 */       while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 206 */         t = t.getCause();
/*     */       }
/* 208 */       if ((t instanceof Error)) {
/* 209 */         throw ((Error)t);
/*     */       }
/* 211 */       throw JsonMappingException.wrapWithPath(t, elem, i);
/*     */     }
/*     */   }
/*     */ 
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 219 */     ObjectNode o = createSchemaNode("array", true);
/* 220 */     if (typeHint != null) {
/* 221 */       JavaType javaType = provider.constructType(typeHint);
/* 222 */       if (javaType.isArrayType()) {
/* 223 */         Class componentType = ((ArrayType)javaType).getContentType().getRawClass();
/*     */ 
/* 225 */         if (componentType == Object.class) {
/* 226 */           o.put("items", JsonSchema.getDefaultSchemaNode());
/*     */         } else {
/* 228 */           JsonSerializer ser = provider.findValueSerializer(componentType, this._property);
/* 229 */           JsonNode schemaNode = (ser instanceof SchemaAware) ? ((SchemaAware)ser).getSchema(provider, null) : JsonSchema.getDefaultSchemaNode();
/*     */ 
/* 232 */           o.put("items", schemaNode);
/*     */         }
/*     */       }
/*     */     }
/* 236 */     return o;
/*     */   }
/*     */ 
/*     */   public void resolve(SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 247 */     if ((this._staticTyping) && (this._elementSerializer == null))
/* 248 */       this._elementSerializer = provider.findValueSerializer(this._elementType, this._property);
/*     */   }
/*     */ 
/*     */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 258 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSerializer(type, provider, this._property);
/*     */ 
/* 260 */     if (map != result.map) {
/* 261 */       this._dynamicSerializers = result.map;
/*     */     }
/* 263 */     return result.serializer;
/*     */   }
/*     */ 
/*     */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, JavaType type, SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 272 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSerializer(type, provider, this._property);
/*     */ 
/* 274 */     if (map != result.map) {
/* 275 */       this._dynamicSerializers = result.map;
/*     */     }
/* 277 */     return result.serializer;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.ObjectArraySerializer
 * JD-Core Version:    0.6.2
 */