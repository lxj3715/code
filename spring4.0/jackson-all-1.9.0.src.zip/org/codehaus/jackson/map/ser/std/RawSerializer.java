/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class RawSerializer<T> extends SerializerBase<T>
/*    */ {
/*    */   public RawSerializer(Class<?> cls)
/*    */   {
/* 26 */     super(cls, false);
/*    */   }
/*    */ 
/*    */   public void serialize(T value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 33 */     jgen.writeRawValue(value.toString());
/*    */   }
/*    */ 
/*    */   public void serializeWithType(T value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 41 */     typeSer.writeTypePrefixForScalar(value, jgen);
/* 42 */     serialize(value, jgen, provider);
/* 43 */     typeSer.writeTypeSuffixForScalar(value, jgen);
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */   {
/* 50 */     return createSchemaNode("string", true);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.RawSerializer
 * JD-Core Version:    0.6.2
 */