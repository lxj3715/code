/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ 
/*    */ public abstract class ScalarSerializerBase<T> extends SerializerBase<T>
/*    */ {
/*    */   protected ScalarSerializerBase(Class<T> t)
/*    */   {
/* 17 */     super(t);
/*    */   }
/*    */ 
/*    */   protected ScalarSerializerBase(Class<?> t, boolean dummy)
/*    */   {
/* 26 */     super(t);
/*    */   }
/*    */ 
/*    */   public void serializeWithType(T value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 41 */     typeSer.writeTypePrefixForScalar(value, jgen);
/* 42 */     serialize(value, jgen, provider);
/* 43 */     typeSer.writeTypeSuffixForScalar(value, jgen);
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 50 */     return createSchemaNode("string", true);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.ScalarSerializerBase
 * JD-Core Version:    0.6.2
 */