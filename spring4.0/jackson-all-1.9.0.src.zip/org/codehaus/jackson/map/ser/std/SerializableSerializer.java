/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.JsonSerializable;
/*    */ import org.codehaus.jackson.map.JsonSerializableWithType;
/*    */ import org.codehaus.jackson.map.ObjectMapper;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ import org.codehaus.jackson.map.ser.SerializerBase;
/*    */ import org.codehaus.jackson.map.type.TypeFactory;
/*    */ import org.codehaus.jackson.node.ObjectNode;
/*    */ import org.codehaus.jackson.schema.JsonSerializableSchema;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class SerializableSerializer extends SerializerBase<JsonSerializable>
/*    */ {
/* 32 */   public static final SerializableSerializer instance = new SerializableSerializer();
/*    */ 
/* 34 */   protected SerializableSerializer() { super(JsonSerializable.class); }
/*    */ 
/*    */ 
/*    */   public void serialize(JsonSerializable value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 40 */     value.serialize(jgen, provider);
/*    */   }
/*    */ 
/*    */   public final void serializeWithType(JsonSerializable value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 52 */     if ((value instanceof JsonSerializableWithType))
/* 53 */       ((JsonSerializableWithType)value).serializeWithType(jgen, provider, typeSer);
/*    */     else
/* 55 */       serialize(value, jgen, provider);
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 63 */     ObjectNode objectNode = createObjectNode();
/* 64 */     String schemaType = "any";
/* 65 */     String objectProperties = null;
/* 66 */     String itemDefinition = null;
/* 67 */     if (typeHint != null) {
/* 68 */       Class rawClass = TypeFactory.type(typeHint).getRawClass();
/* 69 */       if (rawClass.isAnnotationPresent(JsonSerializableSchema.class)) {
/* 70 */         JsonSerializableSchema schemaInfo = (JsonSerializableSchema)rawClass.getAnnotation(JsonSerializableSchema.class);
/* 71 */         schemaType = schemaInfo.schemaType();
/* 72 */         if (!"##irrelevant".equals(schemaInfo.schemaObjectPropertiesDefinition())) {
/* 73 */           objectProperties = schemaInfo.schemaObjectPropertiesDefinition();
/*    */         }
/* 75 */         if (!"##irrelevant".equals(schemaInfo.schemaItemDefinition())) {
/* 76 */           itemDefinition = schemaInfo.schemaItemDefinition();
/*    */         }
/*    */       }
/*    */     }
/* 80 */     objectNode.put("type", schemaType);
/* 81 */     if (objectProperties != null) {
/*    */       try {
/* 83 */         objectNode.put("properties", (JsonNode)new ObjectMapper().readValue(objectProperties, JsonNode.class));
/*    */       } catch (IOException e) {
/* 85 */         throw new IllegalStateException(e);
/*    */       }
/*    */     }
/* 88 */     if (itemDefinition != null) {
/*    */       try {
/* 90 */         objectNode.put("items", (JsonNode)new ObjectMapper().readValue(itemDefinition, JsonNode.class));
/*    */       } catch (IOException e) {
/* 92 */         throw new IllegalStateException(e);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 97 */     return objectNode;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.SerializableSerializer
 * JD-Core Version:    0.6.2
 */