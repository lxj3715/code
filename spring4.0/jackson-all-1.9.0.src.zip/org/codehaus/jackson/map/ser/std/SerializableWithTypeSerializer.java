/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.JsonSerializableWithType;
/*    */ import org.codehaus.jackson.map.ObjectMapper;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ import org.codehaus.jackson.map.type.TypeFactory;
/*    */ import org.codehaus.jackson.node.ObjectNode;
/*    */ import org.codehaus.jackson.schema.JsonSerializableSchema;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class SerializableWithTypeSerializer extends SerializerBase<JsonSerializableWithType>
/*    */ {
/* 29 */   public static final SerializableWithTypeSerializer instance = new SerializableWithTypeSerializer();
/*    */ 
/* 31 */   protected SerializableWithTypeSerializer() { super(JsonSerializableWithType.class); }
/*    */ 
/*    */ 
/*    */   public void serialize(JsonSerializableWithType value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 38 */     value.serialize(jgen, provider);
/*    */   }
/*    */ 
/*    */   public final void serializeWithType(JsonSerializableWithType value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 46 */     value.serializeWithType(jgen, provider, typeSer);
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 54 */     ObjectNode objectNode = createObjectNode();
/* 55 */     String schemaType = "any";
/* 56 */     String objectProperties = null;
/* 57 */     String itemDefinition = null;
/* 58 */     if (typeHint != null) {
/* 59 */       Class rawClass = TypeFactory.rawClass(typeHint);
/* 60 */       if (rawClass.isAnnotationPresent(JsonSerializableSchema.class)) {
/* 61 */         JsonSerializableSchema schemaInfo = (JsonSerializableSchema)rawClass.getAnnotation(JsonSerializableSchema.class);
/* 62 */         schemaType = schemaInfo.schemaType();
/* 63 */         if (!"##irrelevant".equals(schemaInfo.schemaObjectPropertiesDefinition())) {
/* 64 */           objectProperties = schemaInfo.schemaObjectPropertiesDefinition();
/*    */         }
/* 66 */         if (!"##irrelevant".equals(schemaInfo.schemaItemDefinition())) {
/* 67 */           itemDefinition = schemaInfo.schemaItemDefinition();
/*    */         }
/*    */       }
/*    */     }
/* 71 */     objectNode.put("type", schemaType);
/* 72 */     if (objectProperties != null) {
/*    */       try {
/* 74 */         objectNode.put("properties", (JsonNode)new ObjectMapper().readValue(objectProperties, JsonNode.class));
/*    */       } catch (IOException e) {
/* 76 */         throw new IllegalStateException(e);
/*    */       }
/*    */     }
/* 79 */     if (itemDefinition != null) {
/*    */       try {
/* 81 */         objectNode.put("items", (JsonNode)new ObjectMapper().readValue(itemDefinition, JsonNode.class));
/*    */       } catch (IOException e) {
/* 83 */         throw new IllegalStateException(e);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 88 */     return objectNode;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.SerializableWithTypeSerializer
 * JD-Core Version:    0.6.2
 */