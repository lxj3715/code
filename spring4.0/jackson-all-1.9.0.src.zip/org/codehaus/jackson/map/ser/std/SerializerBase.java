/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Type;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.node.JsonNodeFactory;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ import org.codehaus.jackson.schema.SchemaAware;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class SerializerBase<T> extends JsonSerializer<T>
/*     */   implements SchemaAware
/*     */ {
/*     */   protected final Class<T> _handledType;
/*     */ 
/*     */   protected SerializerBase(Class<T> t)
/*     */   {
/*  30 */     this._handledType = t;
/*     */   }
/*     */ 
/*     */   protected SerializerBase(JavaType type)
/*     */   {
/*  38 */     this._handledType = type.getRawClass();
/*     */   }
/*     */ 
/*     */   protected SerializerBase(Class<?> t, boolean dummy)
/*     */   {
/*  47 */     this._handledType = t;
/*     */   }
/*     */ 
/*     */   public final Class<T> handledType() {
/*  51 */     return this._handledType;
/*     */   }
/*     */ 
/*     */   public abstract void serialize(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider)
/*     */     throws IOException, JsonGenerationException;
/*     */ 
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     throws JsonMappingException
/*     */   {
/*  64 */     return createSchemaNode("string");
/*     */   }
/*     */ 
/*     */   protected ObjectNode createObjectNode() {
/*  68 */     return JsonNodeFactory.instance.objectNode();
/*     */   }
/*     */ 
/*     */   protected ObjectNode createSchemaNode(String type)
/*     */   {
/*  73 */     ObjectNode schema = createObjectNode();
/*  74 */     schema.put("type", type);
/*  75 */     return schema;
/*     */   }
/*     */ 
/*     */   protected ObjectNode createSchemaNode(String type, boolean isOptional)
/*     */   {
/*  80 */     ObjectNode schema = createSchemaNode(type);
/*     */ 
/*  82 */     if (!isOptional) {
/*  83 */       schema.put("required", !isOptional);
/*     */     }
/*  85 */     return schema;
/*     */   }
/*     */ 
/*     */   protected boolean isDefaultSerializer(JsonSerializer<?> serializer)
/*     */   {
/*  98 */     return (serializer != null) && (serializer.getClass().getAnnotation(JacksonStdImpl.class) != null);
/*     */   }
/*     */ 
/*     */   public void wrapAndThrow(SerializerProvider provider, Throwable t, Object bean, String fieldName)
/*     */     throws IOException
/*     */   {
/* 121 */     while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 122 */       t = t.getCause();
/*     */     }
/*     */ 
/* 125 */     if ((t instanceof Error)) {
/* 126 */       throw ((Error)t);
/*     */     }
/*     */ 
/* 129 */     boolean wrap = (provider == null) || (provider.isEnabled(SerializationConfig.Feature.WRAP_EXCEPTIONS));
/* 130 */     if ((t instanceof IOException)) {
/* 131 */       if ((!wrap) || (!(t instanceof JsonMappingException)))
/* 132 */         throw ((IOException)t);
/*     */     }
/* 134 */     else if ((!wrap) && 
/* 135 */       ((t instanceof RuntimeException))) {
/* 136 */       throw ((RuntimeException)t);
/*     */     }
/*     */ 
/* 140 */     throw JsonMappingException.wrapWithPath(t, bean, fieldName);
/*     */   }
/*     */ 
/*     */   public void wrapAndThrow(SerializerProvider provider, Throwable t, Object bean, int index)
/*     */     throws IOException
/*     */   {
/* 147 */     while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 148 */       t = t.getCause();
/*     */     }
/*     */ 
/* 151 */     if ((t instanceof Error)) {
/* 152 */       throw ((Error)t);
/*     */     }
/*     */ 
/* 155 */     boolean wrap = (provider == null) || (provider.isEnabled(SerializationConfig.Feature.WRAP_EXCEPTIONS));
/* 156 */     if ((t instanceof IOException)) {
/* 157 */       if ((!wrap) || (!(t instanceof JsonMappingException)))
/* 158 */         throw ((IOException)t);
/*     */     }
/* 160 */     else if ((!wrap) && 
/* 161 */       ((t instanceof RuntimeException))) {
/* 162 */       throw ((RuntimeException)t);
/*     */     }
/*     */ 
/* 166 */     throw JsonMappingException.wrapWithPath(t, bean, index);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void wrapAndThrow(Throwable t, Object bean, String fieldName)
/*     */     throws IOException
/*     */   {
/* 174 */     wrapAndThrow(null, t, bean, fieldName);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void wrapAndThrow(Throwable t, Object bean, int index)
/*     */     throws IOException
/*     */   {
/* 182 */     wrapAndThrow(null, t, bean, index);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.SerializerBase
 * JD-Core Version:    0.6.2
 */