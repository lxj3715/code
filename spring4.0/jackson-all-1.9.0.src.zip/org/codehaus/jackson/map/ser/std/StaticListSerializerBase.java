/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.BeanProperty;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.node.ObjectNode;
/*    */ 
/*    */ public abstract class StaticListSerializerBase<T extends Collection<?>> extends SerializerBase<T>
/*    */ {
/*    */   protected final BeanProperty _property;
/*    */ 
/*    */   protected StaticListSerializerBase(Class<?> cls, BeanProperty property)
/*    */   {
/* 27 */     super(cls, false);
/* 28 */     this._property = property;
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */   {
/* 34 */     ObjectNode o = createSchemaNode("array", true);
/* 35 */     o.put("items", contentSchema());
/* 36 */     return o;
/*    */   }
/*    */ 
/*    */   protected abstract JsonNode contentSchema();
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.StaticListSerializerBase
 * JD-Core Version:    0.6.2
 */