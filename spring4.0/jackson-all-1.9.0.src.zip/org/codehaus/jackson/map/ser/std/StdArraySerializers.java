/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonMappingException;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.ResolvableSerializer;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.node.ObjectNode;
/*     */ 
/*     */ public class StdArraySerializers
/*     */ {
/*     */   @JacksonStdImpl
/*     */   public static final class DoubleArraySerializer extends StdArraySerializers.ArraySerializerBase<double[]>
/*     */   {
/*     */     public DoubleArraySerializer()
/*     */     {
/* 447 */       super(null, null);
/*     */     }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/* 456 */       return this;
/*     */     }
/*     */ 
/*     */     public void serializeContents(double[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 463 */       int i = 0; for (int len = value.length; i < len; i++)
/* 464 */         jgen.writeNumber(value[i]);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 471 */       ObjectNode o = createSchemaNode("array", true);
/* 472 */       o.put("items", createSchemaNode("number"));
/* 473 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class FloatArraySerializer extends StdArraySerializers.ArraySerializerBase<float[]>
/*     */   {
/*     */     public FloatArraySerializer()
/*     */     {
/* 417 */       this(null); } 
/* 418 */     public FloatArraySerializer(TypeSerializer vts) { super(vts, null); }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/* 422 */       return new FloatArraySerializer(vts);
/*     */     }
/*     */ 
/*     */     public void serializeContents(float[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 429 */       int i = 0; for (int len = value.length; i < len; i++)
/* 430 */         jgen.writeNumber(value[i]);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 437 */       ObjectNode o = createSchemaNode("array", true);
/* 438 */       o.put("items", createSchemaNode("number"));
/* 439 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class LongArraySerializer extends StdArraySerializers.ArraySerializerBase<long[]>
/*     */   {
/*     */     public LongArraySerializer()
/*     */     {
/* 387 */       this(null); } 
/* 388 */     public LongArraySerializer(TypeSerializer vts) { super(vts, null); }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/* 392 */       return new LongArraySerializer(vts);
/*     */     }
/*     */ 
/*     */     public void serializeContents(long[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 399 */       int i = 0; for (int len = value.length; i < len; i++)
/* 400 */         jgen.writeNumber(value[i]);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 407 */       ObjectNode o = createSchemaNode("array", true);
/* 408 */       o.put("items", createSchemaNode("number", true));
/* 409 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class IntArraySerializer extends StdArraySerializers.ArraySerializerBase<int[]>
/*     */   {
/*     */     public IntArraySerializer()
/*     */     {
/* 353 */       super(null, null);
/*     */     }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/* 362 */       return this;
/*     */     }
/*     */ 
/*     */     public void serializeContents(int[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 369 */       int i = 0; for (int len = value.length; i < len; i++)
/* 370 */         jgen.writeNumber(value[i]);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 377 */       ObjectNode o = createSchemaNode("array", true);
/* 378 */       o.put("items", createSchemaNode("integer"));
/* 379 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class CharArraySerializer extends SerializerBase<char[]>
/*     */   {
/*     */     public CharArraySerializer()
/*     */     {
/* 297 */       super();
/*     */     }
/*     */ 
/*     */     public void serialize(char[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 304 */       if (provider.isEnabled(SerializationConfig.Feature.WRITE_CHAR_ARRAYS_AS_JSON_ARRAYS)) {
/* 305 */         jgen.writeStartArray();
/* 306 */         _writeArrayContents(jgen, value);
/* 307 */         jgen.writeEndArray();
/*     */       } else {
/* 309 */         jgen.writeString(value, 0, value.length);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void serializeWithType(char[] value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 319 */       if (provider.isEnabled(SerializationConfig.Feature.WRITE_CHAR_ARRAYS_AS_JSON_ARRAYS)) {
/* 320 */         typeSer.writeTypePrefixForArray(value, jgen);
/* 321 */         _writeArrayContents(jgen, value);
/* 322 */         typeSer.writeTypeSuffixForArray(value, jgen);
/*     */       } else {
/* 324 */         typeSer.writeTypePrefixForScalar(value, jgen);
/* 325 */         jgen.writeString(value, 0, value.length);
/* 326 */         typeSer.writeTypeSuffixForScalar(value, jgen);
/*     */       }
/*     */     }
/*     */ 
/*     */     private final void _writeArrayContents(JsonGenerator jgen, char[] value)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 333 */       int i = 0; for (int len = value.length; i < len; i++)
/* 334 */         jgen.writeString(value, i, 1);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 341 */       ObjectNode o = createSchemaNode("array", true);
/* 342 */       ObjectNode itemSchema = createSchemaNode("string");
/* 343 */       itemSchema.put("type", "string");
/* 344 */       o.put("items", itemSchema);
/* 345 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class ShortArraySerializer extends StdArraySerializers.ArraySerializerBase<short[]>
/*     */   {
/*     */     public ShortArraySerializer()
/*     */     {
/* 258 */       this(null); } 
/* 259 */     public ShortArraySerializer(TypeSerializer vts) { super(vts, null); }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/* 263 */       return new ShortArraySerializer(vts);
/*     */     }
/*     */ 
/*     */     public void serializeContents(short[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 271 */       int i = 0; for (int len = value.length; i < len; i++)
/* 272 */         jgen.writeNumber(value[i]);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 280 */       ObjectNode o = createSchemaNode("array", true);
/* 281 */       o.put("items", createSchemaNode("integer"));
/* 282 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class ByteArraySerializer extends SerializerBase<byte[]>
/*     */   {
/*     */     public ByteArraySerializer()
/*     */     {
/* 224 */       super();
/*     */     }
/*     */ 
/*     */     public void serialize(byte[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 231 */       jgen.writeBinary(value);
/*     */     }
/*     */ 
/*     */     public void serializeWithType(byte[] value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 239 */       typeSer.writeTypePrefixForScalar(value, jgen);
/* 240 */       jgen.writeBinary(value);
/* 241 */       typeSer.writeTypeSuffixForScalar(value, jgen);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 247 */       ObjectNode o = createSchemaNode("array", true);
/* 248 */       ObjectNode itemSchema = createSchemaNode("string");
/* 249 */       o.put("items", itemSchema);
/* 250 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class BooleanArraySerializer extends StdArraySerializers.ArraySerializerBase<boolean[]>
/*     */   {
/*     */     public BooleanArraySerializer()
/*     */     {
/* 182 */       super(null, null);
/*     */     }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/* 191 */       return this;
/*     */     }
/*     */ 
/*     */     public void serializeContents(boolean[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 198 */       int i = 0; for (int len = value.length; i < len; i++)
/* 199 */         jgen.writeBoolean(value[i]);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 206 */       ObjectNode o = createSchemaNode("array", true);
/* 207 */       o.put("items", createSchemaNode("boolean"));
/* 208 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static final class StringArraySerializer extends StdArraySerializers.ArraySerializerBase<String[]>
/*     */     implements ResolvableSerializer
/*     */   {
/*     */     protected JsonSerializer<Object> _elementSerializer;
/*     */ 
/*     */     public StringArraySerializer(BeanProperty prop)
/*     */     {
/*  97 */       super(null, prop);
/*     */     }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/* 106 */       return this;
/*     */     }
/*     */ 
/*     */     public void serializeContents(String[] value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 113 */       int len = value.length;
/* 114 */       if (len == 0) {
/* 115 */         return;
/*     */       }
/* 117 */       if (this._elementSerializer != null) {
/* 118 */         serializeContentsSlow(value, jgen, provider, this._elementSerializer);
/* 119 */         return;
/*     */       }
/*     */ 
/* 129 */       for (int i = 0; i < len; i++) {
/* 130 */         String str = value[i];
/* 131 */         if (str == null) {
/* 132 */           jgen.writeNull();
/*     */         }
/*     */         else
/* 135 */           jgen.writeString(value[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */     private void serializeContentsSlow(String[] value, JsonGenerator jgen, SerializerProvider provider, JsonSerializer<Object> ser)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 144 */       int i = 0; for (int len = value.length; i < len; i++) {
/* 145 */         String str = value[i];
/* 146 */         if (str == null)
/* 147 */           provider.defaultSerializeNull(jgen);
/*     */         else
/* 149 */           ser.serialize(value[i], jgen, provider);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void resolve(SerializerProvider provider)
/*     */       throws JsonMappingException
/*     */     {
/* 162 */       JsonSerializer ser = provider.findValueSerializer(String.class, this._property);
/*     */ 
/* 164 */       if ((ser != null) && (ser.getClass().getAnnotation(JacksonStdImpl.class) == null))
/* 165 */         this._elementSerializer = ser;
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 172 */       ObjectNode o = createSchemaNode("array", true);
/* 173 */       o.put("items", createSchemaNode("string"));
/* 174 */       return o;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class ArraySerializerBase<T> extends ContainerSerializerBase<T>
/*     */   {
/*     */     protected final TypeSerializer _valueTypeSerializer;
/*     */     protected final BeanProperty _property;
/*     */ 
/*     */     protected ArraySerializerBase(Class<T> cls, TypeSerializer vts, BeanProperty property)
/*     */     {
/*  46 */       super();
/*  47 */       this._valueTypeSerializer = vts;
/*  48 */       this._property = property;
/*     */     }
/*     */ 
/*     */     public final void serialize(T value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/*  55 */       jgen.writeStartArray();
/*  56 */       serializeContents(value, jgen, provider);
/*  57 */       jgen.writeEndArray();
/*     */     }
/*     */ 
/*     */     public final void serializeWithType(T value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/*  65 */       typeSer.writeTypePrefixForArray(value, jgen);
/*  66 */       serializeContents(value, jgen, provider);
/*  67 */       typeSer.writeTypeSuffixForArray(value, jgen);
/*     */     }
/*     */ 
/*     */     protected abstract void serializeContents(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider)
/*     */       throws IOException, JsonGenerationException;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.StdArraySerializers
 * JD-Core Version:    0.6.2
 */