/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.map.BeanProperty;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*     */ import org.codehaus.jackson.map.ser.impl.PropertySerializerMap;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class StdContainerSerializers
/*     */ {
/*     */   public static ContainerSerializerBase<?> indexedListSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> valueSerializer)
/*     */   {
/*  33 */     return new IndexedListSerializer(elemType, staticTyping, vts, property, valueSerializer);
/*     */   }
/*     */ 
/*     */   public static ContainerSerializerBase<?> collectionSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> valueSerializer)
/*     */   {
/*  40 */     return new CollectionSerializer(elemType, staticTyping, vts, property, valueSerializer);
/*     */   }
/*     */ 
/*     */   public static ContainerSerializerBase<?> iteratorSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property)
/*     */   {
/*  46 */     return new IteratorSerializer(elemType, staticTyping, vts, property);
/*     */   }
/*     */ 
/*     */   public static ContainerSerializerBase<?> iterableSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property)
/*     */   {
/*  52 */     return new IterableSerializer(elemType, staticTyping, vts, property);
/*     */   }
/*     */ 
/*     */   public static JsonSerializer<?> enumSetSerializer(JavaType enumType, BeanProperty property)
/*     */   {
/*  57 */     return new EnumSetSerializer(enumType, property);
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static class IteratorSerializer extends AsArraySerializerBase<Iterator<?>>
/*     */   {
/*     */     public IteratorSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property)
/*     */     {
/* 200 */       super(elemType, staticTyping, vts, property, null);
/*     */     }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/* 205 */       return new IteratorSerializer(this._elementType, this._staticTyping, vts, this._property);
/*     */     }
/*     */ 
/*     */     public void serializeContents(Iterator<?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 212 */       if (value.hasNext()) {
/* 213 */         TypeSerializer typeSer = this._valueTypeSerializer;
/* 214 */         JsonSerializer prevSerializer = null;
/* 215 */         Class prevClass = null;
/*     */         do {
/* 217 */           Object elem = value.next();
/* 218 */           if (elem == null) {
/* 219 */             provider.defaultSerializeNull(jgen);
/*     */           }
/*     */           else {
/* 222 */             Class cc = elem.getClass();
/*     */             JsonSerializer currSerializer;
/*     */             JsonSerializer currSerializer;
/* 224 */             if (cc == prevClass) {
/* 225 */               currSerializer = prevSerializer;
/*     */             } else {
/* 227 */               currSerializer = provider.findValueSerializer(cc, this._property);
/* 228 */               prevSerializer = currSerializer;
/* 229 */               prevClass = cc;
/*     */             }
/* 231 */             if (typeSer == null)
/* 232 */               currSerializer.serialize(elem, jgen, provider);
/*     */             else
/* 234 */               currSerializer.serializeWithType(elem, jgen, provider, typeSer);
/*     */           }
/*     */         }
/* 237 */         while (value.hasNext());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static class IndexedListSerializer extends AsArraySerializerBase<List<?>>
/*     */   {
/*     */     public IndexedListSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> valueSerializer)
/*     */     {
/*  78 */       super(elemType, staticTyping, vts, property, valueSerializer);
/*     */     }
/*     */ 
/*     */     public ContainerSerializerBase<?> _withValueTypeSerializer(TypeSerializer vts)
/*     */     {
/*  83 */       return new IndexedListSerializer(this._elementType, this._staticTyping, vts, this._property, this._elementSerializer);
/*     */     }
/*     */ 
/*     */     public void serializeContents(List<?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/*  90 */       if (this._elementSerializer != null) {
/*  91 */         serializeContentsUsing(value, jgen, provider, this._elementSerializer);
/*  92 */         return;
/*     */       }
/*  94 */       if (this._valueTypeSerializer != null) {
/*  95 */         serializeTypedContents(value, jgen, provider);
/*  96 */         return;
/*     */       }
/*  98 */       int len = value.size();
/*  99 */       if (len == 0) {
/* 100 */         return;
/*     */       }
/* 102 */       int i = 0;
/*     */       try {
/* 104 */         PropertySerializerMap serializers = this._dynamicSerializers;
/* 105 */         for (; i < len; i++) {
/* 106 */           Object elem = value.get(i);
/* 107 */           if (elem == null) {
/* 108 */             provider.defaultSerializeNull(jgen);
/*     */           } else {
/* 110 */             Class cc = elem.getClass();
/* 111 */             JsonSerializer serializer = serializers.serializerFor(cc);
/* 112 */             if (serializer == null)
/*     */             {
/* 114 */               if (this._elementType.hasGenericTypes())
/* 115 */                 serializer = _findAndAddDynamic(serializers, this._elementType.forcedNarrowBy(cc), provider);
/*     */               else {
/* 117 */                 serializer = _findAndAddDynamic(serializers, cc, provider);
/*     */               }
/* 119 */               serializers = this._dynamicSerializers;
/*     */             }
/* 121 */             serializer.serialize(elem, jgen, provider);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 126 */         wrapAndThrow(provider, e, value, i);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void serializeContentsUsing(List<?> value, JsonGenerator jgen, SerializerProvider provider, JsonSerializer<Object> ser)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 134 */       int len = value.size();
/* 135 */       if (len == 0) {
/* 136 */         return;
/*     */       }
/* 138 */       TypeSerializer typeSer = this._valueTypeSerializer;
/* 139 */       for (int i = 0; i < len; i++) {
/* 140 */         Object elem = value.get(i);
/*     */         try {
/* 142 */           if (elem == null)
/* 143 */             provider.defaultSerializeNull(jgen);
/* 144 */           else if (typeSer == null)
/* 145 */             ser.serialize(elem, jgen, provider);
/*     */           else
/* 147 */             ser.serializeWithType(elem, jgen, provider, typeSer);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 151 */           wrapAndThrow(provider, e, value, i);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void serializeTypedContents(List<?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 159 */       int len = value.size();
/* 160 */       if (len == 0) {
/* 161 */         return;
/*     */       }
/* 163 */       int i = 0;
/*     */       try {
/* 165 */         TypeSerializer typeSer = this._valueTypeSerializer;
/* 166 */         PropertySerializerMap serializers = this._dynamicSerializers;
/* 167 */         for (; i < len; i++) {
/* 168 */           Object elem = value.get(i);
/* 169 */           if (elem == null) {
/* 170 */             provider.defaultSerializeNull(jgen);
/*     */           } else {
/* 172 */             Class cc = elem.getClass();
/* 173 */             JsonSerializer serializer = serializers.serializerFor(cc);
/* 174 */             if (serializer == null)
/*     */             {
/* 176 */               if (this._elementType.hasGenericTypes())
/* 177 */                 serializer = _findAndAddDynamic(serializers, this._elementType.forcedNarrowBy(cc), provider);
/*     */               else {
/* 179 */                 serializer = _findAndAddDynamic(serializers, cc, provider);
/*     */               }
/* 181 */               serializers = this._dynamicSerializers;
/*     */             }
/* 183 */             serializer.serializeWithType(elem, jgen, provider, typeSer);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 188 */         wrapAndThrow(provider, e, value, i);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.StdContainerSerializers
 * JD-Core Version:    0.6.2
 */