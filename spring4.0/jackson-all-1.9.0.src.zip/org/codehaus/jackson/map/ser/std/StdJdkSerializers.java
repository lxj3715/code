/*     */ package org.codehaus.jackson.map.ser.std;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Currency;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.regex.Pattern;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.util.Provider;
/*     */ 
/*     */ public class StdJdkSerializers
/*     */   implements Provider<Map.Entry<Class<?>, Object>>
/*     */ {
/*     */   public Collection<Map.Entry<Class<?>, Object>> provide()
/*     */   {
/*  30 */     HashMap sers = new HashMap();
/*     */ 
/*  33 */     ToStringSerializer sls = ToStringSerializer.instance;
/*     */ 
/*  35 */     sers.put(URL.class, sls);
/*  36 */     sers.put(URI.class, sls);
/*     */ 
/*  38 */     sers.put(Currency.class, sls);
/*  39 */     sers.put(UUID.class, sls);
/*  40 */     sers.put(Pattern.class, sls);
/*  41 */     sers.put(Locale.class, sls);
/*     */ 
/*  44 */     sers.put(Locale.class, sls);
/*     */ 
/*  47 */     sers.put(AtomicReference.class, AtomicReferenceSerializer.class);
/*  48 */     sers.put(AtomicBoolean.class, AtomicBooleanSerializer.class);
/*  49 */     sers.put(AtomicInteger.class, AtomicIntegerSerializer.class);
/*  50 */     sers.put(AtomicLong.class, AtomicLongSerializer.class);
/*     */ 
/*  53 */     sers.put(File.class, FileSerializer.class);
/*  54 */     sers.put(Class.class, ClassSerializer.class);
/*     */ 
/*  57 */     sers.put(Void.TYPE, NullSerializer.class);
/*     */ 
/*  59 */     return sers.entrySet();
/*     */   }
/*     */ 
/*     */   public static final class ClassSerializer extends ScalarSerializerBase<Class<?>>
/*     */   {
/*     */     public ClassSerializer()
/*     */     {
/* 180 */       super(false);
/*     */     }
/*     */ 
/*     */     public void serialize(Class<?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 186 */       jgen.writeString(value.getName());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 192 */       return createSchemaNode("string", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class FileSerializer extends ScalarSerializerBase<File>
/*     */   {
/*     */     public FileSerializer()
/*     */     {
/* 157 */       super();
/*     */     }
/*     */ 
/*     */     public void serialize(File value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 163 */       jgen.writeString(value.getAbsolutePath());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 169 */       return createSchemaNode("string", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class AtomicReferenceSerializer extends SerializerBase<AtomicReference<?>>
/*     */   {
/*     */     public AtomicReferenceSerializer()
/*     */     {
/* 128 */       super(false);
/*     */     }
/*     */ 
/*     */     public void serialize(AtomicReference<?> value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 134 */       provider.defaultSerializeValue(value.get(), jgen);
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 140 */       return createSchemaNode("any", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class AtomicLongSerializer extends ScalarSerializerBase<AtomicLong>
/*     */   {
/*     */     public AtomicLongSerializer()
/*     */     {
/* 109 */       super(false);
/*     */     }
/*     */ 
/*     */     public void serialize(AtomicLong value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/* 115 */       jgen.writeNumber(value.get());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 121 */       return createSchemaNode("integer", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class AtomicIntegerSerializer extends ScalarSerializerBase<AtomicInteger>
/*     */   {
/*     */     public AtomicIntegerSerializer()
/*     */     {
/*  90 */       super(false);
/*     */     }
/*     */ 
/*     */     public void serialize(AtomicInteger value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/*  96 */       jgen.writeNumber(value.get());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/* 102 */       return createSchemaNode("integer", true);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class AtomicBooleanSerializer extends ScalarSerializerBase<AtomicBoolean>
/*     */   {
/*     */     public AtomicBooleanSerializer()
/*     */     {
/*  71 */       super(false);
/*     */     }
/*     */ 
/*     */     public void serialize(AtomicBoolean value, JsonGenerator jgen, SerializerProvider provider)
/*     */       throws IOException, JsonGenerationException
/*     */     {
/*  77 */       jgen.writeBoolean(value.get());
/*     */     }
/*     */ 
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     {
/*  83 */       return createSchemaNode("boolean", true);
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.StdJdkSerializers
 * JD-Core Version:    0.6.2
 */