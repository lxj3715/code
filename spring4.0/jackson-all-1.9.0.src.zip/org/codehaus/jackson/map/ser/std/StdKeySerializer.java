/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Date;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ 
/*    */ public class StdKeySerializer extends SerializerBase<Object>
/*    */ {
/* 22 */   static final StdKeySerializer instace = new StdKeySerializer();
/*    */ 
/* 24 */   public StdKeySerializer() { super(Object.class); }
/*    */ 
/*    */ 
/*    */   public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 30 */     if ((value instanceof Date))
/* 31 */       provider.defaultSerializeDateKey((Date)value, jgen);
/*    */     else
/* 33 */       jgen.writeFieldName(value.toString());
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 41 */     return createSchemaNode("string");
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.StdKeySerializer
 * JD-Core Version:    0.6.2
 */