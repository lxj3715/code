/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.JsonSerializer;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class StdKeySerializers
/*    */ {
/* 15 */   protected static final JsonSerializer<Object> DEFAULT_KEY_SERIALIZER = new StdKeySerializer();
/*    */ 
/* 18 */   protected static final JsonSerializer<Object> DEFAULT_STRING_SERIALIZER = new StringKeySerializer();
/*    */ 
/*    */   public static JsonSerializer<Object> getStdKeySerializer(JavaType keyType)
/*    */   {
/* 26 */     if (keyType == null) {
/* 27 */       return DEFAULT_KEY_SERIALIZER;
/*    */     }
/* 29 */     Class cls = keyType.getRawClass();
/* 30 */     if (cls == String.class) {
/* 31 */       return DEFAULT_STRING_SERIALIZER;
/*    */     }
/* 33 */     if (cls == Object.class) {
/* 34 */       return DEFAULT_KEY_SERIALIZER;
/*    */     }
/*    */ 
/* 37 */     if (Date.class.isAssignableFrom(cls)) {
/* 38 */       return DateKeySerializer.instance;
/*    */     }
/* 40 */     if (Calendar.class.isAssignableFrom(cls)) {
/* 41 */       return CalendarKeySerializer.instance;
/*    */     }
/*    */ 
/* 44 */     return DEFAULT_KEY_SERIALIZER;
/*    */   }
/*    */ 
/*    */   public static class CalendarKeySerializer extends SerializerBase<Calendar>
/*    */   {
/* 84 */     protected static final JsonSerializer<?> instance = new CalendarKeySerializer();
/*    */ 
/* 86 */     public CalendarKeySerializer() { super(); }
/*    */ 
/*    */ 
/*    */     public void serialize(Calendar value, JsonGenerator jgen, SerializerProvider provider)
/*    */       throws IOException, JsonGenerationException
/*    */     {
/* 92 */       provider.defaultSerializeDateKey(value.getTimeInMillis(), jgen);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static class DateKeySerializer extends SerializerBase<Date>
/*    */   {
/* 69 */     protected static final JsonSerializer<?> instance = new DateKeySerializer();
/*    */ 
/* 71 */     public DateKeySerializer() { super(); }
/*    */ 
/*    */ 
/*    */     public void serialize(Date value, JsonGenerator jgen, SerializerProvider provider)
/*    */       throws IOException, JsonGenerationException
/*    */     {
/* 77 */       provider.defaultSerializeDateKey(value, jgen);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static class StringKeySerializer extends SerializerBase<String>
/*    */   {
/*    */     public StringKeySerializer()
/*    */     {
/* 56 */       super();
/*    */     }
/*    */ 
/*    */     public void serialize(String value, JsonGenerator jgen, SerializerProvider provider)
/*    */       throws IOException, JsonGenerationException
/*    */     {
/* 62 */       jgen.writeFieldName(value);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.StdKeySerializers
 * JD-Core Version:    0.6.2
 */