/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.TimeZone;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ 
/*    */ public class TimeZoneSerializer extends ScalarSerializerBase<TimeZone>
/*    */ {
/* 17 */   public static final TimeZoneSerializer instance = new TimeZoneSerializer();
/*    */ 
/* 19 */   public TimeZoneSerializer() { super(TimeZone.class); }
/*    */ 
/*    */ 
/*    */   public void serialize(TimeZone value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 25 */     jgen.writeString(value.getID());
/*    */   }
/*    */ 
/*    */   public void serializeWithType(TimeZone value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 34 */     typeSer.writeTypePrefixForScalar(value, jgen, TimeZone.class);
/* 35 */     serialize(value, jgen, provider);
/* 36 */     typeSer.writeTypeSuffixForScalar(value, jgen);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.TimeZoneSerializer
 * JD-Core Version:    0.6.2
 */