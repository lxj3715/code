/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class ToStringSerializer extends SerializerBase<Object>
/*    */ {
/* 26 */   public static final ToStringSerializer instance = new ToStringSerializer();
/*    */ 
/*    */   public ToStringSerializer()
/*    */   {
/* 36 */     super(Object.class);
/*    */   }
/*    */ 
/*    */   public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 42 */     jgen.writeString(value.toString());
/*    */   }
/*    */ 
/*    */   public void serializeWithType(Object value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 61 */     typeSer.writeTypePrefixForScalar(value, jgen);
/* 62 */     serialize(value, jgen, provider);
/* 63 */     typeSer.writeTypeSuffixForScalar(value, jgen);
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 70 */     return createSchemaNode("string", true);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.ToStringSerializer
 * JD-Core Version:    0.6.2
 */