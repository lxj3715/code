/*    */ package org.codehaus.jackson.map.ser.std;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ import org.codehaus.jackson.map.annotate.JacksonStdImpl;
/*    */ import org.codehaus.jackson.util.TokenBuffer;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class TokenBufferSerializer extends SerializerBase<TokenBuffer>
/*    */ {
/*    */   public TokenBufferSerializer()
/*    */   {
/* 26 */     super(TokenBuffer.class);
/*    */   }
/*    */ 
/*    */   public void serialize(TokenBuffer value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 32 */     value.serialize(jgen);
/*    */   }
/*    */ 
/*    */   public final void serializeWithType(TokenBuffer value, JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 52 */     typeSer.writeTypePrefixForScalar(value, jgen);
/* 53 */     serialize(value, jgen, provider);
/* 54 */     typeSer.writeTypeSuffixForScalar(value, jgen);
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */   {
/* 64 */     return createSchemaNode("any", true);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.ser.std.TokenBufferSerializer
 * JD-Core Version:    0.6.2
 */