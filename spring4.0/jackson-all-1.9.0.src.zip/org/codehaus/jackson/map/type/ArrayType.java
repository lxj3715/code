/*     */ package org.codehaus.jackson.map.type;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class ArrayType extends TypeBase
/*     */ {
/*     */   protected final JavaType _componentType;
/*     */   protected final Object _emptyArray;
/*     */ 
/*     */   private ArrayType(JavaType componentType, Object emptyInstance, Object valueHandler, Object typeHandler)
/*     */   {
/*  30 */     super(emptyInstance.getClass(), componentType.hashCode(), valueHandler, typeHandler);
/*     */ 
/*  32 */     this._componentType = componentType;
/*  33 */     this._emptyArray = emptyInstance;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static ArrayType construct(JavaType componentType)
/*     */   {
/*  43 */     return construct(componentType, null, null);
/*     */   }
/*     */ 
/*     */   public static ArrayType construct(JavaType componentType, Object valueHandler, Object typeHandler)
/*     */   {
/*  55 */     Object emptyInstance = Array.newInstance(componentType.getRawClass(), 0);
/*  56 */     return new ArrayType(componentType, emptyInstance, null, null);
/*     */   }
/*     */ 
/*     */   public ArrayType withTypeHandler(Object h)
/*     */   {
/*  63 */     if (h == this._typeHandler) {
/*  64 */       return this;
/*     */     }
/*  66 */     return new ArrayType(this._componentType, this._emptyArray, this._valueHandler, h);
/*     */   }
/*     */ 
/*     */   public ArrayType withContentTypeHandler(Object h)
/*     */   {
/*  73 */     if (h == this._componentType.getTypeHandler()) {
/*  74 */       return this;
/*     */     }
/*  76 */     return new ArrayType(this._componentType.withTypeHandler(h), this._emptyArray, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public ArrayType withValueHandler(Object h)
/*     */   {
/*  83 */     if (h == this._valueHandler) {
/*  84 */       return this;
/*     */     }
/*  86 */     return new ArrayType(this._componentType, this._emptyArray, h, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public ArrayType withContentValueHandler(Object h)
/*     */   {
/*  92 */     if (h == this._componentType.getValueHandler()) {
/*  93 */       return this;
/*     */     }
/*  95 */     return new ArrayType(this._componentType.withValueHandler(h), this._emptyArray, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   protected String buildCanonicalName()
/*     */   {
/* 101 */     return this._class.getName();
/*     */   }
/*     */ 
/*     */   protected JavaType _narrow(Class<?> subclass)
/*     */   {
/* 120 */     if (!subclass.isArray()) {
/* 121 */       throw new IllegalArgumentException("Incompatible narrowing operation: trying to narrow " + toString() + " to class " + subclass.getName());
/*     */     }
/*     */ 
/* 126 */     Class newCompClass = subclass.getComponentType();
/*     */ 
/* 134 */     JavaType newCompType = TypeFactory.defaultInstance().constructType(newCompClass);
/* 135 */     return construct(newCompType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType narrowContentsBy(Class<?> contentClass)
/*     */   {
/* 146 */     if (contentClass == this._componentType.getRawClass()) {
/* 147 */       return this;
/*     */     }
/* 149 */     return construct(this._componentType.narrowBy(contentClass), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType widenContentsBy(Class<?> contentClass)
/*     */   {
/* 157 */     if (contentClass == this._componentType.getRawClass()) {
/* 158 */       return this;
/*     */     }
/* 160 */     return construct(this._componentType.widenBy(contentClass), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public boolean isArrayType()
/*     */   {
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isAbstract()
/*     */   {
/* 179 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isConcrete()
/*     */   {
/* 187 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean hasGenericTypes()
/*     */   {
/* 192 */     return this._componentType.hasGenericTypes();
/*     */   }
/*     */ 
/*     */   public String containedTypeName(int index)
/*     */   {
/* 203 */     if (index == 0) return "E";
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isContainerType()
/*     */   {
/* 214 */     return true;
/*     */   }
/*     */   public JavaType getContentType() {
/* 217 */     return this._componentType;
/*     */   }
/*     */   public int containedTypeCount() {
/* 220 */     return 1;
/*     */   }
/*     */   public JavaType containedType(int index) {
/* 223 */     return index == 0 ? this._componentType : null;
/*     */   }
/*     */ 
/*     */   public StringBuilder getGenericSignature(StringBuilder sb)
/*     */   {
/* 228 */     sb.append('[');
/* 229 */     return this._componentType.getGenericSignature(sb);
/*     */   }
/*     */ 
/*     */   public StringBuilder getErasedSignature(StringBuilder sb)
/*     */   {
/* 234 */     sb.append('[');
/* 235 */     return this._componentType.getErasedSignature(sb);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 247 */     return "[array type, component type: " + this._componentType + "]";
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 253 */     if (o == this) return true;
/* 254 */     if (o == null) return false;
/* 255 */     if (o.getClass() != getClass()) return false;
/*     */ 
/* 257 */     ArrayType other = (ArrayType)o;
/* 258 */     return this._componentType.equals(other._componentType);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.ArrayType
 * JD-Core Version:    0.6.2
 */