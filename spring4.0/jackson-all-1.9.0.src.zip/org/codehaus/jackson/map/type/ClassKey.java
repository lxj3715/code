/*    */ package org.codehaus.jackson.map.type;
/*    */ 
/*    */ public final class ClassKey
/*    */   implements Comparable<ClassKey>
/*    */ {
/*    */   private String _className;
/*    */   private Class<?> _class;
/*    */   private int _hashCode;
/*    */ 
/*    */   public ClassKey()
/*    */   {
/* 34 */     this._class = null;
/* 35 */     this._className = null;
/* 36 */     this._hashCode = 0;
/*    */   }
/*    */ 
/*    */   public ClassKey(Class<?> clz)
/*    */   {
/* 41 */     this._class = clz;
/* 42 */     this._className = clz.getName();
/* 43 */     this._hashCode = this._className.hashCode();
/*    */   }
/*    */ 
/*    */   public void reset(Class<?> clz)
/*    */   {
/* 48 */     this._class = clz;
/* 49 */     this._className = clz.getName();
/* 50 */     this._hashCode = this._className.hashCode();
/*    */   }
/*    */ 
/*    */   public int compareTo(ClassKey other)
/*    */   {
/* 63 */     return this._className.compareTo(other._className);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 75 */     if (o == this) return true;
/* 76 */     if (o == null) return false;
/* 77 */     if (o.getClass() != getClass()) return false;
/* 78 */     ClassKey other = (ClassKey)o;
/*    */ 
/* 87 */     return other._class == this._class;
/*    */   }
/*    */   public int hashCode() {
/* 90 */     return this._hashCode;
/*    */   }
/* 92 */   public String toString() { return this._className; }
/*    */ 
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.ClassKey
 * JD-Core Version:    0.6.2
 */