/*     */ package org.codehaus.jackson.map.type;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class CollectionLikeType extends TypeBase
/*     */ {
/*     */   protected final JavaType _elementType;
/*     */ 
/*     */   @Deprecated
/*     */   protected CollectionLikeType(Class<?> collT, JavaType elemT)
/*     */   {
/*  32 */     super(collT, elemT.hashCode(), null, null);
/*  33 */     this._elementType = elemT;
/*     */   }
/*     */ 
/*     */   protected CollectionLikeType(Class<?> collT, JavaType elemT, Object valueHandler, Object typeHandler)
/*     */   {
/*  39 */     super(collT, elemT.hashCode(), valueHandler, typeHandler);
/*  40 */     this._elementType = elemT;
/*     */   }
/*     */ 
/*     */   protected JavaType _narrow(Class<?> subclass)
/*     */   {
/*  45 */     return new CollectionLikeType(subclass, this._elementType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType narrowContentsBy(Class<?> contentClass)
/*     */   {
/*  53 */     if (contentClass == this._elementType.getRawClass()) {
/*  54 */       return this;
/*     */     }
/*  56 */     return new CollectionLikeType(this._class, this._elementType.narrowBy(contentClass), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType widenContentsBy(Class<?> contentClass)
/*     */   {
/*  63 */     if (contentClass == this._elementType.getRawClass()) {
/*  64 */       return this;
/*     */     }
/*  66 */     return new CollectionLikeType(this._class, this._elementType.widenBy(contentClass), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public static CollectionLikeType construct(Class<?> rawType, JavaType elemT)
/*     */   {
/*  73 */     return new CollectionLikeType(rawType, elemT, null, null);
/*     */   }
/*     */ 
/*     */   public CollectionLikeType withTypeHandler(Object h)
/*     */   {
/*  80 */     return new CollectionLikeType(this._class, this._elementType, this._valueHandler, h);
/*     */   }
/*     */ 
/*     */   public CollectionLikeType withContentTypeHandler(Object h)
/*     */   {
/*  87 */     return new CollectionLikeType(this._class, this._elementType.withTypeHandler(h), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public CollectionLikeType withValueHandler(Object h)
/*     */   {
/*  94 */     return new CollectionLikeType(this._class, this._elementType, h, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public CollectionLikeType withContentValueHandler(Object h)
/*     */   {
/* 100 */     return new CollectionLikeType(this._class, this._elementType.withValueHandler(h), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public boolean isContainerType()
/*     */   {
/* 111 */     return true;
/*     */   }
/*     */   public boolean isCollectionLikeType() {
/* 114 */     return true;
/*     */   }
/*     */   public JavaType getContentType() {
/* 117 */     return this._elementType;
/*     */   }
/*     */   public int containedTypeCount() {
/* 120 */     return 1;
/*     */   }
/*     */ 
/*     */   public JavaType containedType(int index) {
/* 124 */     return index == 0 ? this._elementType : null;
/*     */   }
/*     */ 
/*     */   public String containedTypeName(int index)
/*     */   {
/* 133 */     if (index == 0) return "E";
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */   public StringBuilder getErasedSignature(StringBuilder sb)
/*     */   {
/* 139 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */   public StringBuilder getGenericSignature(StringBuilder sb)
/*     */   {
/* 144 */     _classSignature(this._class, sb, false);
/* 145 */     sb.append('<');
/* 146 */     this._elementType.getGenericSignature(sb);
/* 147 */     sb.append(">;");
/* 148 */     return sb;
/*     */   }
/*     */ 
/*     */   protected String buildCanonicalName()
/*     */   {
/* 153 */     StringBuilder sb = new StringBuilder();
/* 154 */     sb.append(this._class.getName());
/* 155 */     if (this._elementType != null) {
/* 156 */       sb.append('<');
/* 157 */       sb.append(this._elementType.toCanonical());
/* 158 */       sb.append('>');
/*     */     }
/* 160 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean isTrueCollectionType()
/*     */   {
/* 178 */     return Collection.class.isAssignableFrom(this._class);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 190 */     if (o == this) return true;
/* 191 */     if (o == null) return false;
/* 192 */     if (o.getClass() != getClass()) return false;
/*     */ 
/* 194 */     CollectionLikeType other = (CollectionLikeType)o;
/* 195 */     return (this._class == other._class) && (this._elementType.equals(other._elementType));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 201 */     return "[collection-like type; class " + this._class.getName() + ", contains " + this._elementType + "]";
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.CollectionLikeType
 * JD-Core Version:    0.6.2
 */