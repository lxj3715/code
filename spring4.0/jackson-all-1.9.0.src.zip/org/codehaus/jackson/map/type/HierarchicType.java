/*    */ package org.codehaus.jackson.map.type;
/*    */ 
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class HierarchicType
/*    */ {
/*    */   protected final Type _actualType;
/*    */   protected final Class<?> _rawClass;
/*    */   protected final ParameterizedType _genericType;
/*    */   protected HierarchicType _superType;
/*    */   protected HierarchicType _subType;
/*    */ 
/*    */   public HierarchicType(Type type)
/*    */   {
/* 32 */     this._actualType = type;
/* 33 */     if ((type instanceof Class)) {
/* 34 */       this._rawClass = ((Class)type);
/* 35 */       this._genericType = null;
/* 36 */     } else if ((type instanceof ParameterizedType)) {
/* 37 */       this._genericType = ((ParameterizedType)type);
/* 38 */       this._rawClass = ((Class)this._genericType.getRawType());
/*    */     } else {
/* 40 */       throw new IllegalArgumentException("Type " + type.getClass().getName() + " can not be used to construct HierarchicType");
/*    */     }
/*    */   }
/*    */ 
/*    */   private HierarchicType(Type actualType, Class<?> rawClass, ParameterizedType genericType, HierarchicType superType, HierarchicType subType)
/*    */   {
/* 47 */     this._actualType = actualType;
/* 48 */     this._rawClass = rawClass;
/* 49 */     this._genericType = genericType;
/* 50 */     this._superType = superType;
/* 51 */     this._subType = subType;
/*    */   }
/*    */ 
/*    */   public HierarchicType deepCloneWithoutSubtype()
/*    */   {
/* 62 */     HierarchicType sup = this._superType == null ? null : this._superType.deepCloneWithoutSubtype();
/* 63 */     HierarchicType result = new HierarchicType(this._actualType, this._rawClass, this._genericType, sup, null);
/* 64 */     if (sup != null) {
/* 65 */       sup.setSubType(result);
/*    */     }
/* 67 */     return result;
/*    */   }
/*    */   public void setSuperType(HierarchicType sup) {
/* 70 */     this._superType = sup; } 
/* 71 */   public final HierarchicType getSuperType() { return this._superType; } 
/* 72 */   public void setSubType(HierarchicType sub) { this._subType = sub; } 
/* 73 */   public final HierarchicType getSubType() { return this._subType; } 
/*    */   public final boolean isGeneric() {
/* 75 */     return this._genericType != null; } 
/* 76 */   public final ParameterizedType asGeneric() { return this._genericType; } 
/*    */   public final Class<?> getRawClass() {
/* 78 */     return this._rawClass;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 82 */     if (this._genericType != null) {
/* 83 */       return this._genericType.toString();
/*    */     }
/* 85 */     return this._rawClass.getName();
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.HierarchicType
 * JD-Core Version:    0.6.2
 */