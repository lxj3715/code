/*     */ package org.codehaus.jackson.map.type;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class MapLikeType extends TypeBase
/*     */ {
/*     */   protected final JavaType _keyType;
/*     */   protected final JavaType _valueType;
/*     */ 
/*     */   @Deprecated
/*     */   protected MapLikeType(Class<?> mapType, JavaType keyT, JavaType valueT)
/*     */   {
/*  38 */     super(mapType, keyT.hashCode() ^ valueT.hashCode(), null, null);
/*  39 */     this._keyType = keyT;
/*  40 */     this._valueType = valueT;
/*     */   }
/*     */ 
/*     */   protected MapLikeType(Class<?> mapType, JavaType keyT, JavaType valueT, Object valueHandler, Object typeHandler)
/*     */   {
/*  46 */     super(mapType, keyT.hashCode() ^ valueT.hashCode(), valueHandler, typeHandler);
/*  47 */     this._keyType = keyT;
/*  48 */     this._valueType = valueT;
/*     */   }
/*     */ 
/*     */   public static MapLikeType construct(Class<?> rawType, JavaType keyT, JavaType valueT)
/*     */   {
/*  54 */     return new MapLikeType(rawType, keyT, valueT, null, null);
/*     */   }
/*     */ 
/*     */   protected JavaType _narrow(Class<?> subclass)
/*     */   {
/*  60 */     return new MapLikeType(subclass, this._keyType, this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType narrowContentsBy(Class<?> contentClass)
/*     */   {
/*  67 */     if (contentClass == this._valueType.getRawClass()) {
/*  68 */       return this;
/*     */     }
/*  70 */     return new MapLikeType(this._class, this._keyType, this._valueType.narrowBy(contentClass), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType widenContentsBy(Class<?> contentClass)
/*     */   {
/*  77 */     if (contentClass == this._valueType.getRawClass()) {
/*  78 */       return this;
/*     */     }
/*  80 */     return new MapLikeType(this._class, this._keyType, this._valueType.widenBy(contentClass), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType narrowKey(Class<?> keySubclass)
/*     */   {
/*  87 */     if (keySubclass == this._keyType.getRawClass()) {
/*  88 */       return this;
/*     */     }
/*  90 */     return new MapLikeType(this._class, this._keyType.narrowBy(keySubclass), this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType widenKey(Class<?> keySubclass)
/*     */   {
/* 100 */     if (keySubclass == this._keyType.getRawClass()) {
/* 101 */       return this;
/*     */     }
/* 103 */     return new MapLikeType(this._class, this._keyType.widenBy(keySubclass), this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapLikeType withTypeHandler(Object h)
/*     */   {
/* 111 */     return new MapLikeType(this._class, this._keyType, this._valueType, this._valueHandler, h);
/*     */   }
/*     */ 
/*     */   public MapLikeType withContentTypeHandler(Object h)
/*     */   {
/* 118 */     return new MapLikeType(this._class, this._keyType, this._valueType.withTypeHandler(h), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapLikeType withValueHandler(Object h)
/*     */   {
/* 125 */     return new MapLikeType(this._class, this._keyType, this._valueType, h, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapLikeType withContentValueHandler(Object h)
/*     */   {
/* 131 */     return new MapLikeType(this._class, this._keyType, this._valueType.withValueHandler(h), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   protected String buildCanonicalName()
/*     */   {
/* 137 */     StringBuilder sb = new StringBuilder();
/* 138 */     sb.append(this._class.getName());
/* 139 */     if (this._keyType != null) {
/* 140 */       sb.append('<');
/* 141 */       sb.append(this._keyType.toCanonical());
/* 142 */       sb.append(',');
/* 143 */       sb.append(this._valueType.toCanonical());
/* 144 */       sb.append('>');
/*     */     }
/* 146 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean isContainerType()
/*     */   {
/* 156 */     return true;
/*     */   }
/*     */   public boolean isMapLikeType() {
/* 159 */     return true;
/*     */   }
/*     */   public JavaType getKeyType() {
/* 162 */     return this._keyType;
/*     */   }
/*     */   public JavaType getContentType() {
/* 165 */     return this._valueType;
/*     */   }
/*     */   public int containedTypeCount() {
/* 168 */     return 2;
/*     */   }
/*     */ 
/*     */   public JavaType containedType(int index) {
/* 172 */     if (index == 0) return this._keyType;
/* 173 */     if (index == 1) return this._valueType;
/* 174 */     return null;
/*     */   }
/*     */ 
/*     */   public String containedTypeName(int index)
/*     */   {
/* 184 */     if (index == 0) return "K";
/* 185 */     if (index == 1) return "V";
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */   public StringBuilder getErasedSignature(StringBuilder sb)
/*     */   {
/* 191 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */   public StringBuilder getGenericSignature(StringBuilder sb)
/*     */   {
/* 197 */     _classSignature(this._class, sb, false);
/* 198 */     sb.append('<');
/* 199 */     this._keyType.getGenericSignature(sb);
/* 200 */     this._valueType.getGenericSignature(sb);
/* 201 */     sb.append(">;");
/* 202 */     return sb;
/*     */   }
/*     */ 
/*     */   public MapLikeType withKeyTypeHandler(Object h)
/*     */   {
/* 216 */     return new MapLikeType(this._class, this._keyType.withTypeHandler(h), this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapLikeType withKeyValueHandler(Object h)
/*     */   {
/* 224 */     return new MapLikeType(this._class, this._keyType.withValueHandler(h), this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public boolean isTrueMapType()
/*     */   {
/* 237 */     return Map.class.isAssignableFrom(this._class);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 249 */     return "[map-like type; class " + this._class.getName() + ", " + this._keyType + " -> " + this._valueType + "]";
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 255 */     if (o == this) return true;
/* 256 */     if (o == null) return false;
/* 257 */     if (o.getClass() != getClass()) return false;
/*     */ 
/* 259 */     MapLikeType other = (MapLikeType)o;
/* 260 */     return (this._class == other._class) && (this._keyType.equals(other._keyType)) && (this._valueType.equals(other._valueType));
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.MapLikeType
 * JD-Core Version:    0.6.2
 */