/*     */ package org.codehaus.jackson.map.type;
/*     */ 
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class MapType extends MapLikeType
/*     */ {
/*     */   @Deprecated
/*     */   private MapType(Class<?> mapType, JavaType keyT, JavaType valueT)
/*     */   {
/*  18 */     this(mapType, keyT, valueT, null, null);
/*     */   }
/*     */ 
/*     */   private MapType(Class<?> mapType, JavaType keyT, JavaType valueT, Object valueHandler, Object typeHandler)
/*     */   {
/*  23 */     super(mapType, keyT, valueT, valueHandler, typeHandler);
/*     */   }
/*     */ 
/*     */   public static MapType construct(Class<?> rawType, JavaType keyT, JavaType valueT)
/*     */   {
/*  28 */     return new MapType(rawType, keyT, valueT, null, null);
/*     */   }
/*     */ 
/*     */   protected JavaType _narrow(Class<?> subclass)
/*     */   {
/*  33 */     return new MapType(subclass, this._keyType, this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType narrowContentsBy(Class<?> contentClass)
/*     */   {
/*  41 */     if (contentClass == this._valueType.getRawClass()) {
/*  42 */       return this;
/*     */     }
/*  44 */     return new MapType(this._class, this._keyType, this._valueType.narrowBy(contentClass), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType widenContentsBy(Class<?> contentClass)
/*     */   {
/*  51 */     if (contentClass == this._valueType.getRawClass()) {
/*  52 */       return this;
/*     */     }
/*  54 */     return new MapType(this._class, this._keyType, this._valueType.widenBy(contentClass), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType narrowKey(Class<?> keySubclass)
/*     */   {
/*  62 */     if (keySubclass == this._keyType.getRawClass()) {
/*  63 */       return this;
/*     */     }
/*  65 */     return new MapType(this._class, this._keyType.narrowBy(keySubclass), this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType widenKey(Class<?> keySubclass)
/*     */   {
/*  76 */     if (keySubclass == this._keyType.getRawClass()) {
/*  77 */       return this;
/*     */     }
/*  79 */     return new MapType(this._class, this._keyType.widenBy(keySubclass), this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapType withTypeHandler(Object h)
/*     */   {
/*  86 */     return new MapType(this._class, this._keyType, this._valueType, this._valueHandler, h);
/*     */   }
/*     */ 
/*     */   public MapType withContentTypeHandler(Object h)
/*     */   {
/*  93 */     return new MapType(this._class, this._keyType, this._valueType.withTypeHandler(h), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapType withValueHandler(Object h)
/*     */   {
/* 100 */     return new MapType(this._class, this._keyType, this._valueType, h, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapType withContentValueHandler(Object h)
/*     */   {
/* 106 */     return new MapType(this._class, this._keyType, this._valueType.withValueHandler(h), this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapType withKeyTypeHandler(Object h)
/*     */   {
/* 122 */     return new MapType(this._class, this._keyType.withTypeHandler(h), this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public MapType withKeyValueHandler(Object h)
/*     */   {
/* 131 */     return new MapType(this._class, this._keyType.withValueHandler(h), this._valueType, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 144 */     return "[map type; class " + this._class.getName() + ", " + this._keyType + " -> " + this._valueType + "]";
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.MapType
 * JD-Core Version:    0.6.2
 */