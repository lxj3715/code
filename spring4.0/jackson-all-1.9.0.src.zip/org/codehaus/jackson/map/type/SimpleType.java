/*     */ package org.codehaus.jackson.map.type;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public final class SimpleType extends TypeBase
/*     */ {
/*     */   protected final JavaType[] _typeParameters;
/*     */   protected final String[] _typeNames;
/*     */ 
/*     */   protected SimpleType(Class<?> cls)
/*     */   {
/*  34 */     this(cls, null, null, null, null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected SimpleType(Class<?> cls, String[] typeNames, JavaType[] typeParams)
/*     */   {
/*  40 */     this(cls, typeNames, typeParams, null, null);
/*     */   }
/*     */ 
/*     */   protected SimpleType(Class<?> cls, String[] typeNames, JavaType[] typeParams, Object valueHandler, Object typeHandler)
/*     */   {
/*  46 */     super(cls, 0, valueHandler, typeHandler);
/*  47 */     if ((typeNames == null) || (typeNames.length == 0)) {
/*  48 */       this._typeNames = null;
/*  49 */       this._typeParameters = null;
/*     */     } else {
/*  51 */       this._typeNames = typeNames;
/*  52 */       this._typeParameters = typeParams;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static SimpleType constructUnsafe(Class<?> raw)
/*     */   {
/*  63 */     return new SimpleType(raw, null, null, null, null);
/*     */   }
/*     */ 
/*     */   protected JavaType _narrow(Class<?> subclass)
/*     */   {
/*  70 */     return new SimpleType(subclass, this._typeNames, this._typeParameters, this._valueHandler, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public JavaType narrowContentsBy(Class<?> subclass)
/*     */   {
/*  77 */     throw new IllegalArgumentException("Internal error: SimpleType.narrowContentsBy() should never be called");
/*     */   }
/*     */ 
/*     */   public JavaType widenContentsBy(Class<?> subclass)
/*     */   {
/*  84 */     throw new IllegalArgumentException("Internal error: SimpleType.widenContentsBy() should never be called");
/*     */   }
/*     */ 
/*     */   public static SimpleType construct(Class<?> cls)
/*     */   {
/*  92 */     if (Map.class.isAssignableFrom(cls)) {
/*  93 */       throw new IllegalArgumentException("Can not construct SimpleType for a Map (class: " + cls.getName() + ")");
/*     */     }
/*  95 */     if (Collection.class.isAssignableFrom(cls)) {
/*  96 */       throw new IllegalArgumentException("Can not construct SimpleType for a Collection (class: " + cls.getName() + ")");
/*     */     }
/*     */ 
/*  99 */     if (cls.isArray()) {
/* 100 */       throw new IllegalArgumentException("Can not construct SimpleType for an array (class: " + cls.getName() + ")");
/*     */     }
/* 102 */     return new SimpleType(cls);
/*     */   }
/*     */ 
/*     */   public SimpleType withTypeHandler(Object h)
/*     */   {
/* 109 */     return new SimpleType(this._class, this._typeNames, this._typeParameters, this._valueHandler, h);
/*     */   }
/*     */ 
/*     */   public JavaType withContentTypeHandler(Object h)
/*     */   {
/* 116 */     throw new IllegalArgumentException("Simple types have no content types; can not call withContenTypeHandler()");
/*     */   }
/*     */ 
/*     */   public SimpleType withValueHandler(Object h)
/*     */   {
/* 122 */     if (h == this._valueHandler) {
/* 123 */       return this;
/*     */     }
/* 125 */     return new SimpleType(this._class, this._typeNames, this._typeParameters, h, this._typeHandler);
/*     */   }
/*     */ 
/*     */   public SimpleType withContentValueHandler(Object h)
/*     */   {
/* 132 */     throw new IllegalArgumentException("Simple types have no content types; can not call withContenValueHandler()");
/*     */   }
/*     */ 
/*     */   protected String buildCanonicalName()
/*     */   {
/* 138 */     StringBuilder sb = new StringBuilder();
/* 139 */     sb.append(this._class.getName());
/* 140 */     if ((this._typeParameters != null) && (this._typeParameters.length > 0)) {
/* 141 */       sb.append('<');
/* 142 */       boolean first = true;
/* 143 */       for (JavaType t : this._typeParameters) {
/* 144 */         if (first)
/* 145 */           first = false;
/*     */         else {
/* 147 */           sb.append(',');
/*     */         }
/* 149 */         sb.append(t.toCanonical());
/*     */       }
/* 151 */       sb.append('>');
/*     */     }
/* 153 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean isContainerType()
/*     */   {
/* 163 */     return false;
/*     */   }
/*     */ 
/*     */   public int containedTypeCount() {
/* 167 */     return this._typeParameters == null ? 0 : this._typeParameters.length;
/*     */   }
/*     */ 
/*     */   public JavaType containedType(int index)
/*     */   {
/* 173 */     if ((index < 0) || (this._typeParameters == null) || (index >= this._typeParameters.length)) {
/* 174 */       return null;
/*     */     }
/* 176 */     return this._typeParameters[index];
/*     */   }
/*     */ 
/*     */   public String containedTypeName(int index)
/*     */   {
/* 182 */     if ((index < 0) || (this._typeNames == null) || (index >= this._typeNames.length)) {
/* 183 */       return null;
/*     */     }
/* 185 */     return this._typeNames[index];
/*     */   }
/*     */ 
/*     */   public StringBuilder getErasedSignature(StringBuilder sb)
/*     */   {
/* 190 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */   public StringBuilder getGenericSignature(StringBuilder sb)
/*     */   {
/* 196 */     _classSignature(this._class, sb, false);
/* 197 */     if (this._typeParameters != null) {
/* 198 */       sb.append('<');
/* 199 */       for (JavaType param : this._typeParameters) {
/* 200 */         sb = param.getGenericSignature(sb);
/*     */       }
/* 202 */       sb.append('>');
/*     */     }
/* 204 */     sb.append(';');
/* 205 */     return sb;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 217 */     StringBuilder sb = new StringBuilder(40);
/* 218 */     sb.append("[simple type, class ").append(buildCanonicalName()).append(']');
/* 219 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 225 */     if (o == this) return true;
/* 226 */     if (o == null) return false;
/* 227 */     if (o.getClass() != getClass()) return false;
/*     */ 
/* 229 */     SimpleType other = (SimpleType)o;
/*     */ 
/* 232 */     if (other._class != this._class) return false;
/*     */ 
/* 235 */     JavaType[] p1 = this._typeParameters;
/* 236 */     JavaType[] p2 = other._typeParameters;
/* 237 */     if (p1 == null) {
/* 238 */       return (p2 == null) || (p2.length == 0);
/*     */     }
/* 240 */     if (p2 == null) return false;
/*     */ 
/* 242 */     if (p1.length != p2.length) return false;
/* 243 */     int i = 0; for (int len = p1.length; i < len; i++) {
/* 244 */       if (!p1[i].equals(p2[i])) {
/* 245 */         return false;
/*     */       }
/*     */     }
/* 248 */     return true;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.SimpleType
 * JD-Core Version:    0.6.2
 */