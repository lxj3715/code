/*     */ package org.codehaus.jackson.map.type;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.JsonSerializableWithType;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public abstract class TypeBase extends JavaType
/*     */   implements JsonSerializableWithType
/*     */ {
/*     */   volatile String _canonicalName;
/*     */ 
/*     */   @Deprecated
/*     */   protected TypeBase(Class<?> raw, int hash)
/*     */   {
/*  23 */     super(raw, hash);
/*     */   }
/*     */ 
/*     */   protected TypeBase(Class<?> raw, int hash, Object valueHandler, Object typeHandler)
/*     */   {
/*  34 */     super(raw, hash);
/*     */ 
/*  39 */     this._valueHandler = valueHandler;
/*  40 */     this._typeHandler = typeHandler;
/*     */   }
/*     */ 
/*     */   public String toCanonical()
/*     */   {
/*  46 */     String str = this._canonicalName;
/*  47 */     if (str == null) {
/*  48 */       str = buildCanonicalName();
/*     */     }
/*  50 */     return str;
/*     */   }
/*     */ 
/*     */   protected abstract String buildCanonicalName();
/*     */ 
/*     */   public abstract StringBuilder getGenericSignature(StringBuilder paramStringBuilder);
/*     */ 
/*     */   public abstract StringBuilder getErasedSignature(StringBuilder paramStringBuilder);
/*     */ 
/*     */   public <T> T getValueHandler()
/*     */   {
/*  63 */     return this._valueHandler;
/*     */   }
/*     */ 
/*     */   public <T> T getTypeHandler() {
/*  67 */     return this._typeHandler;
/*     */   }
/*     */ 
/*     */   public void serializeWithType(JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  80 */     typeSer.writeTypePrefixForScalar(this, jgen);
/*  81 */     serialize(jgen, provider);
/*  82 */     typeSer.writeTypeSuffixForScalar(this, jgen);
/*     */   }
/*     */ 
/*     */   public void serialize(JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  89 */     jgen.writeString(toCanonical());
/*     */   }
/*     */ 
/*     */   protected static StringBuilder _classSignature(Class<?> cls, StringBuilder sb, boolean trailingSemicolon)
/*     */   {
/* 105 */     if (cls.isPrimitive()) {
/* 106 */       if (cls == Boolean.TYPE)
/* 107 */         sb.append('Z');
/* 108 */       else if (cls == Byte.TYPE) {
/* 109 */         sb.append('B');
/*     */       }
/* 111 */       else if (cls == Short.TYPE) {
/* 112 */         sb.append('S');
/*     */       }
/* 114 */       else if (cls == Character.TYPE) {
/* 115 */         sb.append('C');
/*     */       }
/* 117 */       else if (cls == Integer.TYPE) {
/* 118 */         sb.append('I');
/*     */       }
/* 120 */       else if (cls == Long.TYPE) {
/* 121 */         sb.append('J');
/*     */       }
/* 123 */       else if (cls == Float.TYPE) {
/* 124 */         sb.append('F');
/*     */       }
/* 126 */       else if (cls == Double.TYPE) {
/* 127 */         sb.append('D');
/*     */       }
/* 129 */       else if (cls == Void.TYPE)
/* 130 */         sb.append('V');
/*     */       else
/* 132 */         throw new IllegalStateException("Unrecognized primitive type: " + cls.getName());
/*     */     }
/*     */     else {
/* 135 */       sb.append('L');
/* 136 */       String name = cls.getName();
/* 137 */       int i = 0; for (int len = name.length(); i < len; i++) {
/* 138 */         char c = name.charAt(i);
/* 139 */         if (c == '.') c = '/';
/* 140 */         sb.append(c);
/*     */       }
/* 142 */       if (trailingSemicolon) {
/* 143 */         sb.append(';');
/*     */       }
/*     */     }
/* 146 */     return sb;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.TypeBase
 * JD-Core Version:    0.6.2
 */