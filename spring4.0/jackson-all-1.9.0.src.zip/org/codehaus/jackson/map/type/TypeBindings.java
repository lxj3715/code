/*     */ package org.codehaus.jackson.map.type;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class TypeBindings
/*     */ {
/*  15 */   private static final JavaType[] NO_TYPES = new JavaType[0];
/*     */ 
/*  20 */   public static final JavaType UNBOUND = new SimpleType(Object.class);
/*     */   protected final TypeFactory _typeFactory;
/*     */   protected final JavaType _contextType;
/*     */   protected final Class<?> _contextClass;
/*     */   protected Map<String, JavaType> _bindings;
/*     */   protected HashSet<String> _placeholders;
/*     */   private final TypeBindings _parentBindings;
/*     */ 
/*     */   public TypeBindings(TypeFactory typeFactory, Class<?> cc)
/*     */   {
/*  68 */     this(typeFactory, null, cc, null);
/*     */   }
/*     */ 
/*     */   public TypeBindings(TypeFactory typeFactory, JavaType type)
/*     */   {
/*  73 */     this(typeFactory, null, type.getRawClass(), type);
/*     */   }
/*     */ 
/*     */   public TypeBindings childInstance()
/*     */   {
/*  85 */     return new TypeBindings(this._typeFactory, this, this._contextClass, this._contextType);
/*     */   }
/*     */ 
/*     */   private TypeBindings(TypeFactory tf, TypeBindings parent, Class<?> cc, JavaType type)
/*     */   {
/*  93 */     this._typeFactory = tf;
/*  94 */     this._parentBindings = parent;
/*  95 */     this._contextClass = cc;
/*  96 */     this._contextType = type;
/*     */   }
/*     */ 
/*     */   public JavaType resolveType(Class<?> cls)
/*     */   {
/* 106 */     return this._typeFactory._constructType(cls, this);
/*     */   }
/*     */ 
/*     */   public JavaType resolveType(Type type) {
/* 110 */     return this._typeFactory._constructType(type, this);
/*     */   }
/*     */ 
/*     */   public int getBindingCount()
/*     */   {
/* 129 */     if (this._bindings == null) {
/* 130 */       _resolve();
/*     */     }
/* 132 */     return this._bindings.size();
/*     */   }
/*     */ 
/*     */   public JavaType findType(String name)
/*     */   {
/* 137 */     if (this._bindings == null) {
/* 138 */       _resolve();
/*     */     }
/* 140 */     JavaType t = (JavaType)this._bindings.get(name);
/* 141 */     if (t != null) {
/* 142 */       return t;
/*     */     }
/* 144 */     if ((this._placeholders != null) && (this._placeholders.contains(name))) {
/* 145 */       return UNBOUND;
/*     */     }
/*     */ 
/* 148 */     if (this._parentBindings != null) {
/* 149 */       return this._parentBindings.findType(name);
/*     */     }
/*     */ 
/* 158 */     if (this._contextClass != null) {
/* 159 */       Class enclosing = this._contextClass.getEnclosingClass();
/* 160 */       if (enclosing != null)
/*     */       {
/* 163 */         if (!Modifier.isStatic(this._contextClass.getModifiers()))
/* 164 */           return UNBOUND;
/*     */       }
/*     */     }
/*     */     String className;
/*     */     String className;
/* 181 */     if (this._contextClass != null) {
/* 182 */       className = this._contextClass.getName();
/*     */     }
/*     */     else
/*     */     {
/*     */       String className;
/* 183 */       if (this._contextType != null)
/* 184 */         className = this._contextType.toString();
/*     */       else
/* 186 */         className = "UNKNOWN";
/*     */     }
/* 188 */     throw new IllegalArgumentException("Type variable '" + name + "' can not be resolved (with context of class " + className + ")");
/*     */   }
/*     */ 
/*     */   public void addBinding(String name, JavaType type)
/*     */   {
/* 196 */     if ((this._bindings == null) || (this._bindings.size() == 0)) {
/* 197 */       this._bindings = new LinkedHashMap();
/*     */     }
/* 199 */     this._bindings.put(name, type);
/*     */   }
/*     */ 
/*     */   public JavaType[] typesAsArray()
/*     */   {
/* 204 */     if (this._bindings == null) {
/* 205 */       _resolve();
/*     */     }
/* 207 */     if (this._bindings.size() == 0) {
/* 208 */       return NO_TYPES;
/*     */     }
/* 210 */     return (JavaType[])this._bindings.values().toArray(new JavaType[this._bindings.size()]);
/*     */   }
/*     */ 
/*     */   protected void _resolve()
/*     */   {
/* 221 */     _resolveBindings(this._contextClass);
/*     */ 
/* 224 */     if (this._contextType != null) {
/* 225 */       int count = this._contextType.containedTypeCount();
/* 226 */       if (count > 0) {
/* 227 */         if (this._bindings == null) {
/* 228 */           this._bindings = new LinkedHashMap();
/*     */         }
/* 230 */         for (int i = 0; i < count; i++) {
/* 231 */           String name = this._contextType.containedTypeName(i);
/* 232 */           JavaType type = this._contextType.containedType(i);
/* 233 */           this._bindings.put(name, type);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 239 */     if (this._bindings == null)
/* 240 */       this._bindings = Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   public void _addPlaceholder(String name)
/*     */   {
/* 245 */     if (this._placeholders == null) {
/* 246 */       this._placeholders = new HashSet();
/*     */     }
/* 248 */     this._placeholders.add(name);
/*     */   }
/*     */ 
/*     */   protected void _resolveBindings(Type t)
/*     */   {
/* 253 */     if (t == null)
/*     */       return;
/*     */     Class raw;
/* 256 */     if ((t instanceof ParameterizedType)) {
/* 257 */       ParameterizedType pt = (ParameterizedType)t;
/* 258 */       Type[] args = pt.getActualTypeArguments();
/* 259 */       if ((args != null) && (args.length > 0)) {
/* 260 */         Class rawType = (Class)pt.getRawType();
/* 261 */         TypeVariable[] vars = rawType.getTypeParameters();
/* 262 */         if (vars.length != args.length) {
/* 263 */           throw new IllegalArgumentException("Strange parametrized type (in class " + rawType.getName() + "): number of type arguments != number of type parameters (" + args.length + " vs " + vars.length + ")");
/*     */         }
/* 265 */         int i = 0; for (int len = args.length; i < len; i++) {
/* 266 */           TypeVariable var = vars[i];
/* 267 */           String name = var.getName();
/* 268 */           if (this._bindings == null) {
/* 269 */             this._bindings = new LinkedHashMap();
/*     */           }
/*     */           else
/*     */           {
/* 274 */             if (this._bindings.containsKey(name))
/*     */               continue;
/*     */           }
/* 277 */           _addPlaceholder(name);
/*     */ 
/* 279 */           this._bindings.put(name, this._typeFactory._constructType(args[i], this));
/*     */         }
/*     */       }
/* 282 */       raw = (Class)pt.getRawType();
/* 283 */     } else if ((t instanceof Class)) {
/* 284 */       Class raw = (Class)t;
/*     */ 
/* 290 */       _resolveBindings(raw.getDeclaringClass());
/*     */ 
/* 294 */       TypeVariable[] vars = raw.getTypeParameters();
/* 295 */       if ((vars != null) && (vars.length > 0))
/* 296 */         for (TypeVariable var : vars) {
/* 297 */           String name = var.getName();
/* 298 */           Type varType = var.getBounds()[0];
/* 299 */           if (varType != null) {
/* 300 */             if (this._bindings == null)
/* 301 */               this._bindings = new LinkedHashMap();
/*     */             else
/* 303 */               if (this._bindings.containsKey(name))
/*     */                 continue;
/* 305 */             _addPlaceholder(name);
/* 306 */             this._bindings.put(name, this._typeFactory._constructType(varType, this));
/*     */           }
/*     */         }
/*     */     }
/*     */     else
/*     */     {
/*     */       return;
/*     */     }
/*     */     Class raw;
/* 317 */     _resolveBindings(raw.getGenericSuperclass());
/* 318 */     for (Type intType : raw.getGenericInterfaces())
/* 319 */       _resolveBindings(intType);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 326 */     if (this._bindings == null) {
/* 327 */       _resolve();
/*     */     }
/* 329 */     StringBuilder sb = new StringBuilder("[TypeBindings for ");
/* 330 */     if (this._contextType != null)
/* 331 */       sb.append(this._contextType.toString());
/*     */     else {
/* 333 */       sb.append(this._contextClass.getName());
/*     */     }
/* 335 */     sb.append(": ").append(this._bindings).append("]");
/* 336 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.TypeBindings
 * JD-Core Version:    0.6.2
 */