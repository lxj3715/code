/*      */ package org.codehaus.jackson.map.type;
/*      */ 
/*      */ import java.lang.reflect.GenericArrayType;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.lang.reflect.WildcardType;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.codehaus.jackson.map.util.ArrayBuilders;
/*      */ import org.codehaus.jackson.type.JavaType;
/*      */ import org.codehaus.jackson.type.TypeReference;
/*      */ 
/*      */ public final class TypeFactory
/*      */ {
/*      */ 
/*      */   @Deprecated
/*   51 */   public static final TypeFactory instance = new TypeFactory();
/*      */ 
/*   53 */   private static final JavaType[] NO_TYPES = new JavaType[0];
/*      */   protected final TypeModifier[] _modifiers;
/*      */   protected final TypeParser _parser;
/*      */   protected HierarchicType _cachedHashMapType;
/*      */   protected HierarchicType _cachedArrayListType;
/*      */ 
/*      */   private TypeFactory()
/*      */   {
/*   94 */     this._parser = new TypeParser(this);
/*   95 */     this._modifiers = null;
/*      */   }
/*      */ 
/*      */   protected TypeFactory(TypeParser p, TypeModifier[] mods) {
/*   99 */     this._parser = p;
/*  100 */     this._modifiers = mods;
/*      */   }
/*      */ 
/*      */   public TypeFactory withModifier(TypeModifier mod)
/*      */   {
/*  105 */     if (this._modifiers == null) {
/*  106 */       return new TypeFactory(this._parser, new TypeModifier[] { mod });
/*      */     }
/*  108 */     return new TypeFactory(this._parser, (TypeModifier[])ArrayBuilders.insertInListNoDup(this._modifiers, mod));
/*      */   }
/*      */ 
/*      */   public static TypeFactory defaultInstance()
/*      */   {
/*  118 */     return instance;
/*      */   }
/*      */ 
/*      */   public static JavaType unknownType()
/*      */   {
/*  134 */     return defaultInstance()._unknownType();
/*      */   }
/*      */ 
/*      */   public static Class<?> rawClass(Type t) {
/*  138 */     if ((t instanceof Class)) {
/*  139 */       return (Class)t;
/*      */     }
/*      */ 
/*  142 */     return defaultInstance().constructType(t).getRawClass();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType type(Type t)
/*      */   {
/*  153 */     return instance._constructType(t, null);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType type(Type type, Class<?> context) {
/*  158 */     return instance.constructType(type, context);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType type(Type type, JavaType context) {
/*  163 */     return instance.constructType(type, context);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType type(Type type, TypeBindings bindings) {
/*  168 */     return instance._constructType(type, bindings);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType type(TypeReference<?> ref) {
/*  173 */     return instance.constructType(ref.getType());
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType arrayType(Class<?> elementType) {
/*  178 */     return instance.constructArrayType(instance.constructType(elementType));
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType arrayType(JavaType elementType) {
/*  183 */     return instance.constructArrayType(elementType);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType collectionType(Class<? extends Collection> collectionType, Class<?> elementType) {
/*  188 */     return instance.constructCollectionType(collectionType, instance.constructType(elementType));
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType collectionType(Class<? extends Collection> collectionType, JavaType elementType) {
/*  193 */     return instance.constructCollectionType(collectionType, elementType);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType mapType(Class<? extends Map> mapClass, Class<?> keyType, Class<?> valueType)
/*      */   {
/*  199 */     return instance.constructMapType(mapClass, type(keyType), instance.constructType(valueType));
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType mapType(Class<? extends Map> mapType, JavaType keyType, JavaType valueType) {
/*  204 */     return instance.constructMapType(mapType, keyType, valueType);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType parametricType(Class<?> parametrized, Class<?>[] parameterClasses) {
/*  209 */     return instance.constructParametricType(parametrized, parameterClasses);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType parametricType(Class<?> parametrized, JavaType[] parameterTypes) {
/*  214 */     return instance.constructParametricType(parametrized, parameterTypes);
/*      */   }
/*      */ 
/*      */   public static JavaType fromCanonical(String canonical) throws IllegalArgumentException {
/*  218 */     return instance.constructFromCanonical(canonical);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType specialize(JavaType baseType, Class<?> subclass) {
/*  223 */     return instance.constructSpecializedType(baseType, subclass);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType fastSimpleType(Class<?> cls) {
/*  228 */     return instance.uncheckedSimpleType(cls);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType[] findParameterTypes(Class<?> clz, Class<?> expType) {
/*  233 */     return instance.findTypeParameters(clz, expType);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType[] findParameterTypes(Class<?> clz, Class<?> expType, TypeBindings bindings) {
/*  238 */     return instance.findTypeParameters(clz, expType, bindings);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType[] findParameterTypes(JavaType type, Class<?> expType) {
/*  243 */     return instance.findTypeParameters(type, expType);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType fromClass(Class<?> clz)
/*      */   {
/*  266 */     return instance._fromClass(clz, null);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType fromTypeReference(TypeReference<?> ref)
/*      */   {
/*  280 */     return type(ref.getType());
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static JavaType fromType(Type type)
/*      */   {
/*  293 */     return instance._constructType(type, null);
/*      */   }
/*      */ 
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass)
/*      */   {
/*  312 */     if ((baseType instanceof SimpleType))
/*      */     {
/*  314 */       if ((subclass.isArray()) || (Map.class.isAssignableFrom(subclass)) || (Collection.class.isAssignableFrom(subclass)))
/*      */       {
/*  318 */         if (!baseType.getRawClass().isAssignableFrom(subclass)) {
/*  319 */           throw new IllegalArgumentException("Class " + subclass.getClass().getName() + " not subtype of " + baseType);
/*      */         }
/*      */ 
/*  322 */         JavaType subtype = _fromClass(subclass, new TypeBindings(this, baseType.getRawClass()));
/*      */ 
/*  324 */         Object h = baseType.getValueHandler();
/*  325 */         if (h != null)
/*      */         {
/*  327 */           subtype = subtype.withValueHandler(h);
/*      */         }
/*  329 */         h = baseType.getTypeHandler();
/*  330 */         if (h != null) {
/*  331 */           subtype = subtype.withTypeHandler(h);
/*      */         }
/*  333 */         return subtype;
/*      */       }
/*      */     }
/*      */ 
/*  337 */     return baseType.narrowBy(subclass);
/*      */   }
/*      */ 
/*      */   public JavaType constructFromCanonical(String canonical)
/*      */     throws IllegalArgumentException
/*      */   {
/*  354 */     return this._parser.parse(canonical);
/*      */   }
/*      */ 
/*      */   public JavaType[] findTypeParameters(JavaType type, Class<?> expType)
/*      */   {
/*  378 */     Class raw = type.getRawClass();
/*  379 */     if (raw == expType)
/*      */     {
/*  381 */       int count = type.containedTypeCount();
/*  382 */       if (count == 0) return null;
/*  383 */       JavaType[] result = new JavaType[count];
/*  384 */       for (int i = 0; i < count; i++) {
/*  385 */         result[i] = type.containedType(i);
/*      */       }
/*  387 */       return result;
/*      */     }
/*      */ 
/*  395 */     return findTypeParameters(raw, expType, new TypeBindings(this, type));
/*      */   }
/*      */ 
/*      */   public JavaType[] findTypeParameters(Class<?> clz, Class<?> expType) {
/*  399 */     return findTypeParameters(clz, expType, new TypeBindings(this, clz));
/*      */   }
/*      */ 
/*      */   public JavaType[] findTypeParameters(Class<?> clz, Class<?> expType, TypeBindings bindings)
/*      */   {
/*  405 */     HierarchicType subType = _findSuperTypeChain(clz, expType);
/*      */ 
/*  407 */     if (subType == null) {
/*  408 */       throw new IllegalArgumentException("Class " + clz.getName() + " is not a subtype of " + expType.getName());
/*      */     }
/*      */ 
/*  411 */     HierarchicType superType = subType;
/*  412 */     while (superType.getSuperType() != null) {
/*  413 */       superType = superType.getSuperType();
/*  414 */       Class raw = superType.getRawClass();
/*  415 */       TypeBindings newBindings = new TypeBindings(this, raw);
/*  416 */       if (superType.isGeneric()) {
/*  417 */         ParameterizedType pt = superType.asGeneric();
/*  418 */         Type[] actualTypes = pt.getActualTypeArguments();
/*  419 */         TypeVariable[] vars = raw.getTypeParameters();
/*  420 */         int len = actualTypes.length;
/*  421 */         for (int i = 0; i < len; i++) {
/*  422 */           String name = vars[i].getName();
/*  423 */           JavaType type = instance._constructType(actualTypes[i], bindings);
/*  424 */           newBindings.addBinding(name, type);
/*      */         }
/*      */       }
/*  427 */       bindings = newBindings;
/*      */     }
/*      */ 
/*  431 */     if (!superType.isGeneric()) {
/*  432 */       return null;
/*      */     }
/*  434 */     return bindings.typesAsArray();
/*      */   }
/*      */ 
/*      */   public JavaType constructType(Type type)
/*      */   {
/*  444 */     return _constructType(type, null);
/*      */   }
/*      */ 
/*      */   public JavaType constructType(Type type, TypeBindings bindings) {
/*  448 */     return _constructType(type, bindings);
/*      */   }
/*      */ 
/*      */   public JavaType constructType(TypeReference<?> typeRef) {
/*  452 */     return _constructType(typeRef.getType(), null);
/*      */   }
/*      */ 
/*      */   public JavaType constructType(Type type, Class<?> context) {
/*  456 */     TypeBindings b = context == null ? null : new TypeBindings(this, context);
/*  457 */     return _constructType(type, b);
/*      */   }
/*      */ 
/*      */   public JavaType constructType(Type type, JavaType context) {
/*  461 */     TypeBindings b = context == null ? null : new TypeBindings(this, context);
/*  462 */     return _constructType(type, b);
/*      */   }
/*      */ 
/*      */   public JavaType _constructType(Type type, TypeBindings context)
/*      */   {
/*      */     JavaType resultType;
/*  475 */     if ((type instanceof Class)) {
/*  476 */       Class cls = (Class)type;
/*      */ 
/*  480 */       if (context == null) {
/*  481 */         context = new TypeBindings(this, cls);
/*      */       }
/*  483 */       resultType = _fromClass(cls, context);
/*      */     }
/*      */     else
/*      */     {
/*      */       JavaType resultType;
/*  486 */       if ((type instanceof ParameterizedType)) {
/*  487 */         resultType = _fromParamType((ParameterizedType)type, context);
/*      */       }
/*      */       else
/*      */       {
/*      */         JavaType resultType;
/*  489 */         if ((type instanceof GenericArrayType)) {
/*  490 */           resultType = _fromArrayType((GenericArrayType)type, context);
/*      */         }
/*      */         else
/*      */         {
/*      */           JavaType resultType;
/*  492 */           if ((type instanceof TypeVariable)) {
/*  493 */             resultType = _fromVariable((TypeVariable)type, context);
/*      */           }
/*      */           else
/*      */           {
/*      */             JavaType resultType;
/*  495 */             if ((type instanceof WildcardType)) {
/*  496 */               resultType = _fromWildcard((WildcardType)type, context);
/*      */             }
/*      */             else
/*  499 */               throw new IllegalArgumentException("Unrecognized Type: " + type.toString());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     JavaType resultType;
/*  505 */     if ((this._modifiers != null) && (!resultType.isContainerType())) {
/*  506 */       for (TypeModifier mod : this._modifiers) {
/*  507 */         resultType = mod.modifyType(resultType, type, context, this);
/*      */       }
/*      */     }
/*  510 */     return resultType;
/*      */   }
/*      */ 
/*      */   public ArrayType constructArrayType(Class<?> elementType)
/*      */   {
/*  526 */     return ArrayType.construct(_constructType(elementType, null), null, null);
/*      */   }
/*      */ 
/*      */   public ArrayType constructArrayType(JavaType elementType)
/*      */   {
/*  536 */     return ArrayType.construct(elementType, null, null);
/*      */   }
/*      */ 
/*      */   public CollectionType constructCollectionType(Class<? extends Collection> collectionClass, Class<?> elementClass)
/*      */   {
/*  546 */     return CollectionType.construct(collectionClass, constructType(elementClass));
/*      */   }
/*      */ 
/*      */   public CollectionType constructCollectionType(Class<? extends Collection> collectionClass, JavaType elementType)
/*      */   {
/*  556 */     return CollectionType.construct(collectionClass, elementType);
/*      */   }
/*      */ 
/*      */   public CollectionLikeType constructCollectionLikeType(Class<?> collectionClass, Class<?> elementClass)
/*      */   {
/*  568 */     return CollectionLikeType.construct(collectionClass, constructType(elementClass));
/*      */   }
/*      */ 
/*      */   public CollectionLikeType constructCollectionLikeType(Class<?> collectionClass, JavaType elementType)
/*      */   {
/*  580 */     return CollectionLikeType.construct(collectionClass, elementType);
/*      */   }
/*      */ 
/*      */   public MapType constructMapType(Class<? extends Map> mapClass, JavaType keyType, JavaType valueType)
/*      */   {
/*  592 */     return MapType.construct(mapClass, keyType, valueType);
/*      */   }
/*      */ 
/*      */   public MapType constructMapType(Class<? extends Map> mapClass, Class<?> keyClass, Class<?> valueClass)
/*      */   {
/*  604 */     return MapType.construct(mapClass, constructType(keyClass), constructType(valueClass));
/*      */   }
/*      */ 
/*      */   public MapLikeType constructMapLikeType(Class<?> mapClass, JavaType keyType, JavaType valueType)
/*      */   {
/*  616 */     return MapLikeType.construct(mapClass, keyType, valueType);
/*      */   }
/*      */ 
/*      */   public MapLikeType constructMapLikeType(Class<?> mapClass, Class<?> keyClass, Class<?> valueClass)
/*      */   {
/*  628 */     return MapType.construct(mapClass, constructType(keyClass), constructType(valueClass));
/*      */   }
/*      */ 
/*      */   public JavaType constructSimpleType(Class<?> rawType, JavaType[] parameterTypes)
/*      */   {
/*  639 */     TypeVariable[] typeVars = rawType.getTypeParameters();
/*  640 */     if (typeVars.length != parameterTypes.length) {
/*  641 */       throw new IllegalArgumentException("Parameter type mismatch for " + rawType.getName() + ": expected " + typeVars.length + " parameters, was given " + parameterTypes.length);
/*      */     }
/*      */ 
/*  644 */     String[] names = new String[typeVars.length];
/*  645 */     int i = 0; for (int len = typeVars.length; i < len; i++) {
/*  646 */       names[i] = typeVars[i].getName();
/*      */     }
/*  648 */     JavaType resultType = new SimpleType(rawType, names, parameterTypes, null, null);
/*  649 */     return resultType;
/*      */   }
/*      */ 
/*      */   public JavaType uncheckedSimpleType(Class<?> cls)
/*      */   {
/*  662 */     return new SimpleType(cls);
/*      */   }
/*      */ 
/*      */   public JavaType constructParametricType(Class<?> parametrized, Class<?>[] parameterClasses)
/*      */   {
/*  681 */     int len = parameterClasses.length;
/*  682 */     JavaType[] pt = new JavaType[len];
/*  683 */     for (int i = 0; i < len; i++) {
/*  684 */       pt[i] = _fromClass(parameterClasses[i], null);
/*      */     }
/*  686 */     return constructParametricType(parametrized, pt);
/*      */   }
/*      */ 
/*      */   public JavaType constructParametricType(Class<?> parametrized, JavaType[] parameterTypes)
/*      */   {
/*      */     JavaType resultType;
/*      */     JavaType resultType;
/*  709 */     if (parametrized.isArray())
/*      */     {
/*  711 */       if (parameterTypes.length != 1) {
/*  712 */         throw new IllegalArgumentException("Need exactly 1 parameter type for arrays (" + parametrized.getName() + ")");
/*      */       }
/*  714 */       resultType = constructArrayType(parameterTypes[0]);
/*      */     }
/*      */     else
/*      */     {
/*      */       JavaType resultType;
/*  716 */       if (Map.class.isAssignableFrom(parametrized)) {
/*  717 */         if (parameterTypes.length != 2) {
/*  718 */           throw new IllegalArgumentException("Need exactly 2 parameter types for Map types (" + parametrized.getName() + ")");
/*      */         }
/*  720 */         resultType = constructMapType(parametrized, parameterTypes[0], parameterTypes[1]);
/*      */       }
/*      */       else
/*      */       {
/*      */         JavaType resultType;
/*  722 */         if (Collection.class.isAssignableFrom(parametrized)) {
/*  723 */           if (parameterTypes.length != 1) {
/*  724 */             throw new IllegalArgumentException("Need exactly 1 parameter type for Collection types (" + parametrized.getName() + ")");
/*      */           }
/*  726 */           resultType = constructCollectionType(parametrized, parameterTypes[0]);
/*      */         } else {
/*  728 */           resultType = constructSimpleType(parametrized, parameterTypes);
/*      */         }
/*      */       }
/*      */     }
/*  730 */     return resultType;
/*      */   }
/*      */ 
/*      */   public CollectionType constructRawCollectionType(Class<? extends Collection> collectionClass)
/*      */   {
/*  754 */     return CollectionType.construct(collectionClass, unknownType());
/*      */   }
/*      */ 
/*      */   public CollectionLikeType constructRawCollectionLikeType(Class<?> collectionClass)
/*      */   {
/*  771 */     return CollectionLikeType.construct(collectionClass, unknownType());
/*      */   }
/*      */ 
/*      */   public MapType constructRawMapType(Class<? extends Map> mapClass)
/*      */   {
/*  788 */     return MapType.construct(mapClass, unknownType(), unknownType());
/*      */   }
/*      */ 
/*      */   public MapLikeType constructRawMapLikeType(Class<?> mapClass)
/*      */   {
/*  805 */     return MapLikeType.construct(mapClass, unknownType(), unknownType());
/*      */   }
/*      */ 
/*      */   protected JavaType _fromClass(Class<?> clz, TypeBindings context)
/*      */   {
/*  821 */     if (clz.isArray()) {
/*  822 */       return ArrayType.construct(_constructType(clz.getComponentType(), null), null, null);
/*      */     }
/*      */ 
/*  827 */     if (clz.isEnum()) {
/*  828 */       return new SimpleType(clz);
/*      */     }
/*      */ 
/*  834 */     if (Map.class.isAssignableFrom(clz)) {
/*  835 */       return _mapType(clz);
/*      */     }
/*  837 */     if (Collection.class.isAssignableFrom(clz)) {
/*  838 */       return _collectionType(clz);
/*      */     }
/*  840 */     return new SimpleType(clz);
/*      */   }
/*      */ 
/*      */   protected JavaType _fromParameterizedClass(Class<?> clz, List<JavaType> paramTypes)
/*      */   {
/*  849 */     if (clz.isArray()) {
/*  850 */       return ArrayType.construct(_constructType(clz.getComponentType(), null), null, null);
/*      */     }
/*  852 */     if (clz.isEnum()) {
/*  853 */       return new SimpleType(clz);
/*      */     }
/*  855 */     if (Map.class.isAssignableFrom(clz))
/*      */     {
/*  858 */       if (paramTypes.size() > 0) {
/*  859 */         JavaType keyType = (JavaType)paramTypes.get(0);
/*  860 */         JavaType contentType = paramTypes.size() >= 2 ? (JavaType)paramTypes.get(1) : _unknownType();
/*      */ 
/*  862 */         return MapType.construct(clz, keyType, contentType);
/*      */       }
/*  864 */       return _mapType(clz);
/*      */     }
/*  866 */     if (Collection.class.isAssignableFrom(clz)) {
/*  867 */       if (paramTypes.size() >= 1) {
/*  868 */         return CollectionType.construct(clz, (JavaType)paramTypes.get(0));
/*      */       }
/*  870 */       return _collectionType(clz);
/*      */     }
/*  872 */     if (paramTypes.size() == 0) {
/*  873 */       return new SimpleType(clz);
/*      */     }
/*  875 */     JavaType[] pt = (JavaType[])paramTypes.toArray(new JavaType[paramTypes.size()]);
/*  876 */     return constructSimpleType(clz, pt);
/*      */   }
/*      */ 
/*      */   protected JavaType _fromParamType(ParameterizedType type, TypeBindings context)
/*      */   {
/*  894 */     Class rawType = (Class)type.getRawType();
/*  895 */     Type[] args = type.getActualTypeArguments();
/*  896 */     int paramCount = args == null ? 0 : args.length;
/*      */     JavaType[] pt;
/*      */     JavaType[] pt;
/*  900 */     if (paramCount == 0) {
/*  901 */       pt = NO_TYPES;
/*      */     } else {
/*  903 */       pt = new JavaType[paramCount];
/*  904 */       for (int i = 0; i < paramCount; i++) {
/*  905 */         pt[i] = _constructType(args[i], context);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  910 */     if (Map.class.isAssignableFrom(rawType)) {
/*  911 */       JavaType subtype = constructSimpleType(rawType, pt);
/*  912 */       JavaType[] mapParams = findTypeParameters(subtype, Map.class);
/*  913 */       if (mapParams.length != 2) {
/*  914 */         throw new IllegalArgumentException("Could not find 2 type parameters for Map class " + rawType.getName() + " (found " + mapParams.length + ")");
/*      */       }
/*  916 */       return MapType.construct(rawType, mapParams[0], mapParams[1]);
/*      */     }
/*  918 */     if (Collection.class.isAssignableFrom(rawType)) {
/*  919 */       JavaType subtype = constructSimpleType(rawType, pt);
/*  920 */       JavaType[] collectionParams = findTypeParameters(subtype, Collection.class);
/*  921 */       if (collectionParams.length != 1) {
/*  922 */         throw new IllegalArgumentException("Could not find 1 type parameter for Collection class " + rawType.getName() + " (found " + collectionParams.length + ")");
/*      */       }
/*  924 */       return CollectionType.construct(rawType, collectionParams[0]);
/*      */     }
/*  926 */     if (paramCount == 0) {
/*  927 */       return new SimpleType(rawType);
/*      */     }
/*  929 */     return constructSimpleType(rawType, pt);
/*      */   }
/*      */ 
/*      */   protected JavaType _fromArrayType(GenericArrayType type, TypeBindings context)
/*      */   {
/*  935 */     JavaType compType = _constructType(type.getGenericComponentType(), context);
/*  936 */     return ArrayType.construct(compType, null, null);
/*      */   }
/*      */ 
/*      */   protected JavaType _fromVariable(TypeVariable<?> type, TypeBindings context)
/*      */   {
/*  945 */     if (context == null) {
/*  946 */       return _unknownType();
/*      */     }
/*      */ 
/*  950 */     String name = type.getName();
/*  951 */     JavaType actualType = context.findType(name);
/*  952 */     if (actualType != null) {
/*  953 */       return actualType;
/*      */     }
/*      */ 
/*  961 */     Type[] bounds = type.getBounds();
/*      */ 
/*  976 */     context._addPlaceholder(name);
/*  977 */     return _constructType(bounds[0], context);
/*      */   }
/*      */ 
/*      */   protected JavaType _fromWildcard(WildcardType type, TypeBindings context)
/*      */   {
/*  990 */     return _constructType(type.getUpperBounds()[0], context);
/*      */   }
/*      */ 
/*      */   private JavaType _mapType(Class<?> rawClass)
/*      */   {
/*  995 */     JavaType[] typeParams = findTypeParameters(rawClass, Map.class);
/*      */ 
/*  997 */     if (typeParams == null) {
/*  998 */       return MapType.construct(rawClass, _unknownType(), _unknownType());
/*      */     }
/*      */ 
/* 1001 */     if (typeParams.length != 2) {
/* 1002 */       throw new IllegalArgumentException("Strange Map type " + rawClass.getName() + ": can not determine type parameters");
/*      */     }
/* 1004 */     return MapType.construct(rawClass, typeParams[0], typeParams[1]);
/*      */   }
/*      */ 
/*      */   private JavaType _collectionType(Class<?> rawClass)
/*      */   {
/* 1009 */     JavaType[] typeParams = findTypeParameters(rawClass, Collection.class);
/*      */ 
/* 1011 */     if (typeParams == null) {
/* 1012 */       return CollectionType.construct(rawClass, _unknownType());
/*      */     }
/*      */ 
/* 1015 */     if (typeParams.length != 1) {
/* 1016 */       throw new IllegalArgumentException("Strange Collection type " + rawClass.getName() + ": can not determine type parameters");
/*      */     }
/* 1018 */     return CollectionType.construct(rawClass, typeParams[0]);
/*      */   }
/*      */ 
/*      */   protected JavaType _resolveVariableViaSubTypes(HierarchicType leafType, String variableName, TypeBindings bindings)
/*      */   {
/* 1024 */     if ((leafType != null) && (leafType.isGeneric())) {
/* 1025 */       TypeVariable[] typeVariables = leafType.getRawClass().getTypeParameters();
/* 1026 */       int i = 0; for (int len = typeVariables.length; i < len; i++) {
/* 1027 */         TypeVariable tv = typeVariables[i];
/* 1028 */         if (variableName.equals(tv.getName()))
/*      */         {
/* 1030 */           Type type = leafType.asGeneric().getActualTypeArguments()[i];
/* 1031 */           if ((type instanceof TypeVariable)) {
/* 1032 */             return _resolveVariableViaSubTypes(leafType.getSubType(), ((TypeVariable)type).getName(), bindings);
/*      */           }
/*      */ 
/* 1035 */           return _constructType(type, bindings);
/*      */         }
/*      */       }
/*      */     }
/* 1039 */     return _unknownType();
/*      */   }
/*      */ 
/*      */   protected JavaType _unknownType() {
/* 1043 */     return new SimpleType(Object.class);
/*      */   }
/*      */ 
/*      */   protected HierarchicType _findSuperTypeChain(Class<?> subtype, Class<?> supertype)
/*      */   {
/* 1061 */     if (supertype.isInterface()) {
/* 1062 */       return _findSuperInterfaceChain(subtype, supertype);
/*      */     }
/* 1064 */     return _findSuperClassChain(subtype, supertype);
/*      */   }
/*      */ 
/*      */   protected HierarchicType _findSuperClassChain(Type currentType, Class<?> target)
/*      */   {
/* 1069 */     HierarchicType current = new HierarchicType(currentType);
/* 1070 */     Class raw = current.getRawClass();
/* 1071 */     if (raw == target) {
/* 1072 */       return current;
/*      */     }
/*      */ 
/* 1075 */     Type parent = raw.getGenericSuperclass();
/* 1076 */     if (parent != null) {
/* 1077 */       HierarchicType sup = _findSuperClassChain(parent, target);
/* 1078 */       if (sup != null) {
/* 1079 */         sup.setSubType(current);
/* 1080 */         current.setSuperType(sup);
/* 1081 */         return current;
/*      */       }
/*      */     }
/* 1084 */     return null;
/*      */   }
/*      */ 
/*      */   protected HierarchicType _findSuperInterfaceChain(Type currentType, Class<?> target)
/*      */   {
/* 1089 */     HierarchicType current = new HierarchicType(currentType);
/* 1090 */     Class raw = current.getRawClass();
/* 1091 */     if (raw == target) {
/* 1092 */       return new HierarchicType(currentType);
/*      */     }
/*      */ 
/* 1098 */     if ((raw == HashMap.class) && 
/* 1099 */       (target == Map.class)) {
/* 1100 */       return _hashMapSuperInterfaceChain(current);
/*      */     }
/*      */ 
/* 1103 */     if ((raw == ArrayList.class) && 
/* 1104 */       (target == List.class)) {
/* 1105 */       return _arrayListSuperInterfaceChain(current);
/*      */     }
/*      */ 
/* 1108 */     return _doFindSuperInterfaceChain(current, target);
/*      */   }
/*      */ 
/*      */   protected HierarchicType _doFindSuperInterfaceChain(HierarchicType current, Class<?> target)
/*      */   {
/* 1113 */     Class raw = current.getRawClass();
/* 1114 */     Type[] parents = raw.getGenericInterfaces();
/*      */ 
/* 1117 */     if (parents != null) {
/* 1118 */       for (Type parent : parents) {
/* 1119 */         HierarchicType sup = _findSuperInterfaceChain(parent, target);
/* 1120 */         if (sup != null) {
/* 1121 */           sup.setSubType(current);
/* 1122 */           current.setSuperType(sup);
/* 1123 */           return current;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1128 */     Type parent = raw.getGenericSuperclass();
/* 1129 */     if (parent != null) {
/* 1130 */       HierarchicType sup = _findSuperInterfaceChain(parent, target);
/* 1131 */       if (sup != null) {
/* 1132 */         sup.setSubType(current);
/* 1133 */         current.setSuperType(sup);
/* 1134 */         return current;
/*      */       }
/*      */     }
/* 1137 */     return null;
/*      */   }
/*      */ 
/*      */   protected synchronized HierarchicType _hashMapSuperInterfaceChain(HierarchicType current)
/*      */   {
/* 1142 */     if (this._cachedHashMapType == null) {
/* 1143 */       HierarchicType base = current.deepCloneWithoutSubtype();
/* 1144 */       _doFindSuperInterfaceChain(base, Map.class);
/* 1145 */       this._cachedHashMapType = base.getSuperType();
/*      */     }
/* 1147 */     HierarchicType t = this._cachedHashMapType.deepCloneWithoutSubtype();
/* 1148 */     current.setSuperType(t);
/* 1149 */     t.setSubType(current);
/* 1150 */     return current;
/*      */   }
/*      */ 
/*      */   protected synchronized HierarchicType _arrayListSuperInterfaceChain(HierarchicType current)
/*      */   {
/* 1155 */     if (this._cachedArrayListType == null) {
/* 1156 */       HierarchicType base = current.deepCloneWithoutSubtype();
/* 1157 */       _doFindSuperInterfaceChain(base, List.class);
/* 1158 */       this._cachedArrayListType = base.getSuperType();
/*      */     }
/* 1160 */     HierarchicType t = this._cachedArrayListType.deepCloneWithoutSubtype();
/* 1161 */     current.setSuperType(t);
/* 1162 */     t.setSubType(current);
/* 1163 */     return current;
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.type.TypeFactory
 * JD-Core Version:    0.6.2
 */