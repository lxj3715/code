/*     */ package org.codehaus.jackson.map.util;
/*     */ 
/*     */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*     */ 
/*     */ public class BeanUtil
/*     */ {
/*     */   public static String okNameForGetter(AnnotatedMethod am)
/*     */   {
/*  90 */     String name = am.getName();
/*  91 */     String str = okNameForIsGetter(am, name);
/*  92 */     if (str == null) {
/*  93 */       str = okNameForRegularGetter(am, name);
/*     */     }
/*  95 */     return str;
/*     */   }
/*     */ 
/*     */   public static String okNameForRegularGetter(AnnotatedMethod am, String name)
/*     */   {
/* 100 */     if (name.startsWith("get"))
/*     */     {
/* 108 */       if ("getCallbacks".equals(name)) {
/* 109 */         if (isCglibGetCallbacks(am))
/* 110 */           return null;
/*     */       }
/* 112 */       else if ("getMetaClass".equals(name))
/*     */       {
/* 116 */         if (isGroovyMetaClassGetter(am)) {
/* 117 */           return null;
/*     */         }
/*     */       }
/* 120 */       return manglePropertyName(name.substring(3));
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */   public static String okNameForIsGetter(AnnotatedMethod am, String name)
/*     */   {
/* 127 */     if (name.startsWith("is"))
/*     */     {
/* 129 */       Class rt = am.getRawType();
/* 130 */       if ((rt != Boolean.class) && (rt != Boolean.TYPE)) {
/* 131 */         return null;
/*     */       }
/* 133 */       return manglePropertyName(name.substring(2));
/*     */     }
/*     */ 
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   public static String okNameForSetter(AnnotatedMethod am)
/*     */   {
/* 141 */     String name = am.getName();
/* 142 */     if (name.startsWith("set")) {
/* 143 */       name = manglePropertyName(name.substring(3));
/* 144 */       if (name == null) {
/* 145 */         return null;
/*     */       }
/* 147 */       if ("metaClass".equals(name))
/*     */       {
/* 149 */         if (isGroovyMetaClassSetter(am)) {
/* 150 */           return null;
/*     */         }
/*     */       }
/* 153 */       return name;
/*     */     }
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */   protected static boolean isCglibGetCallbacks(AnnotatedMethod am)
/*     */   {
/* 177 */     Class rt = am.getRawType();
/*     */ 
/* 179 */     if ((rt == null) || (!rt.isArray())) {
/* 180 */       return false;
/*     */     }
/*     */ 
/* 186 */     Class compType = rt.getComponentType();
/*     */ 
/* 188 */     Package pkg = compType.getPackage();
/* 189 */     if (pkg != null) {
/* 190 */       String pname = pkg.getName();
/* 191 */       if ((pname.startsWith("net.sf.cglib")) || (pname.startsWith("org.hibernate.repackage.cglib")))
/*     */       {
/* 194 */         return true;
/*     */       }
/*     */     }
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */   protected static boolean isGroovyMetaClassSetter(AnnotatedMethod am)
/*     */   {
/* 206 */     Class argType = am.getParameterClass(0);
/* 207 */     Package pkg = argType.getPackage();
/* 208 */     if ((pkg != null) && (pkg.getName().startsWith("groovy.lang"))) {
/* 209 */       return true;
/*     */     }
/* 211 */     return false;
/*     */   }
/*     */ 
/*     */   protected static boolean isGroovyMetaClassGetter(AnnotatedMethod am)
/*     */   {
/* 219 */     Class rt = am.getRawType();
/* 220 */     if ((rt == null) || (rt.isArray())) {
/* 221 */       return false;
/*     */     }
/* 223 */     Package pkg = rt.getPackage();
/* 224 */     if ((pkg != null) && (pkg.getName().startsWith("groovy.lang"))) {
/* 225 */       return true;
/*     */     }
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */   protected static String manglePropertyName(String basename)
/*     */   {
/* 239 */     int len = basename.length();
/*     */ 
/* 242 */     if (len == 0) {
/* 243 */       return null;
/*     */     }
/*     */ 
/* 246 */     StringBuilder sb = null;
/* 247 */     for (int i = 0; i < len; i++) {
/* 248 */       char upper = basename.charAt(i);
/* 249 */       char lower = Character.toLowerCase(upper);
/* 250 */       if (upper == lower) {
/*     */         break;
/*     */       }
/* 253 */       if (sb == null) {
/* 254 */         sb = new StringBuilder(basename);
/*     */       }
/* 256 */       sb.setCharAt(i, lower);
/*     */     }
/* 258 */     return sb == null ? basename : sb.toString();
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.util.BeanUtil
 * JD-Core Version:    0.6.2
 */