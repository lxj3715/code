/*     */ package org.codehaus.jackson.map.util;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public final class ClassUtil
/*     */ {
/*     */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore)
/*     */   {
/*  28 */     return findSuperTypes(cls, endBefore, new ArrayList(8));
/*     */   }
/*     */ 
/*     */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore, List<Class<?>> result)
/*     */   {
/*  33 */     _addSuperTypes(cls, endBefore, result, false);
/*  34 */     return result;
/*     */   }
/*     */ 
/*     */   private static void _addSuperTypes(Class<?> cls, Class<?> endBefore, Collection<Class<?>> result, boolean addClassItself)
/*     */   {
/*  39 */     if ((cls == endBefore) || (cls == null) || (cls == Object.class)) {
/*  40 */       return;
/*     */     }
/*  42 */     if (addClassItself) {
/*  43 */       if (result.contains(cls)) {
/*  44 */         return;
/*     */       }
/*  46 */       result.add(cls);
/*     */     }
/*  48 */     for (Class intCls : cls.getInterfaces()) {
/*  49 */       _addSuperTypes(intCls, endBefore, result, true);
/*     */     }
/*  51 */     _addSuperTypes(cls.getSuperclass(), endBefore, result, true);
/*     */   }
/*     */ 
/*     */   public static String canBeABeanType(Class<?> type)
/*     */   {
/*  67 */     if (type.isAnnotation()) {
/*  68 */       return "annotation";
/*     */     }
/*  70 */     if (type.isArray()) {
/*  71 */       return "array";
/*     */     }
/*  73 */     if (type.isEnum()) {
/*  74 */       return "enum";
/*     */     }
/*  76 */     if (type.isPrimitive()) {
/*  77 */       return "primitive";
/*     */     }
/*     */ 
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static String isLocalType(Class<?> type)
/*     */   {
/*  89 */     return isLocalType(type, false);
/*     */   }
/*     */ 
/*     */   public static String isLocalType(Class<?> type, boolean allowNonStatic)
/*     */   {
/*     */     try
/*     */     {
/* 103 */       if (type.getEnclosingMethod() != null) {
/* 104 */         return "local/anonymous";
/*     */       }
/*     */ 
/* 111 */       if ((!allowNonStatic) && 
/* 112 */         (type.getEnclosingClass() != null) && 
/* 113 */         (!Modifier.isStatic(type.getModifiers())))
/* 114 */         return "non-static member class";
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */     catch (NullPointerException e) {
/*     */     }
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */   public static Class<?> getOuterClass(Class<?> type)
/*     */   {
/*     */     try
/*     */     {
/* 134 */       if (type.getEnclosingMethod() != null) {
/* 135 */         return null;
/*     */       }
/* 137 */       if (!Modifier.isStatic(type.getModifiers()))
/* 138 */         return type.getEnclosingClass();
/*     */     } catch (SecurityException e) {
/*     */     } catch (NullPointerException e) {
/*     */     }
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean isProxyType(Class<?> type)
/*     */   {
/* 154 */     if (Proxy.isProxyClass(type)) {
/* 155 */       return true;
/*     */     }
/* 157 */     String name = type.getName();
/*     */ 
/* 159 */     if ((name.startsWith("net.sf.cglib.proxy.")) || (name.startsWith("org.hibernate.proxy.")))
/*     */     {
/* 161 */       return true;
/*     */     }
/*     */ 
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isConcrete(Class<?> type)
/*     */   {
/* 173 */     int mod = type.getModifiers();
/* 174 */     return (mod & 0x600) == 0;
/*     */   }
/*     */ 
/*     */   public static boolean isConcrete(Member member)
/*     */   {
/* 182 */     int mod = member.getModifiers();
/* 183 */     return (mod & 0x600) == 0;
/*     */   }
/*     */ 
/*     */   public static boolean isCollectionMapOrArray(Class<?> type)
/*     */   {
/* 188 */     if (type.isArray()) return true;
/* 189 */     if (Collection.class.isAssignableFrom(type)) return true;
/* 190 */     if (Map.class.isAssignableFrom(type)) return true;
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */   public static String getClassDescription(Object classOrInstance)
/*     */   {
/* 207 */     if (classOrInstance == null) {
/* 208 */       return "unknown";
/*     */     }
/* 210 */     Class cls = (classOrInstance instanceof Class) ? (Class)classOrInstance : classOrInstance.getClass();
/*     */ 
/* 212 */     return cls.getName();
/*     */   }
/*     */ 
/*     */   public static boolean hasGetterSignature(Method m)
/*     */   {
/* 224 */     if (Modifier.isStatic(m.getModifiers())) {
/* 225 */       return false;
/*     */     }
/*     */ 
/* 228 */     Class[] pts = m.getParameterTypes();
/* 229 */     if ((pts != null) && (pts.length != 0)) {
/* 230 */       return false;
/*     */     }
/*     */ 
/* 233 */     if (Void.TYPE == m.getReturnType()) {
/* 234 */       return false;
/*     */     }
/*     */ 
/* 237 */     return true;
/*     */   }
/*     */ 
/*     */   public static Throwable getRootCause(Throwable t)
/*     */   {
/* 252 */     while (t.getCause() != null) {
/* 253 */       t = t.getCause();
/*     */     }
/* 255 */     return t;
/*     */   }
/*     */ 
/*     */   public static void throwRootCause(Throwable t)
/*     */     throws Exception
/*     */   {
/* 268 */     t = getRootCause(t);
/* 269 */     if ((t instanceof Exception)) {
/* 270 */       throw ((Exception)t);
/*     */     }
/* 272 */     throw ((Error)t);
/*     */   }
/*     */ 
/*     */   public static void throwAsIAE(Throwable t)
/*     */   {
/* 281 */     throwAsIAE(t, t.getMessage());
/*     */   }
/*     */ 
/*     */   public static void throwAsIAE(Throwable t, String msg)
/*     */   {
/* 291 */     if ((t instanceof RuntimeException)) {
/* 292 */       throw ((RuntimeException)t);
/*     */     }
/* 294 */     if ((t instanceof Error)) {
/* 295 */       throw ((Error)t);
/*     */     }
/* 297 */     throw new IllegalArgumentException(msg, t);
/*     */   }
/*     */ 
/*     */   public static void unwrapAndThrowAsIAE(Throwable t)
/*     */   {
/* 307 */     throwAsIAE(getRootCause(t));
/*     */   }
/*     */ 
/*     */   public static void unwrapAndThrowAsIAE(Throwable t, String msg)
/*     */   {
/* 317 */     throwAsIAE(getRootCause(t), msg);
/*     */   }
/*     */ 
/*     */   public static <T> T createInstance(Class<T> cls, boolean canFixAccess)
/*     */     throws IllegalArgumentException
/*     */   {
/* 342 */     Constructor ctor = findConstructor(cls, canFixAccess);
/* 343 */     if (ctor == null)
/* 344 */       throw new IllegalArgumentException("Class " + cls.getName() + " has no default (no arg) constructor");
/*     */     try
/*     */     {
/* 347 */       return ctor.newInstance(new Object[0]);
/*     */     } catch (Exception e) {
/* 349 */       unwrapAndThrowAsIAE(e, "Failed to instantiate class " + cls.getName() + ", problem: " + e.getMessage());
/* 350 */     }return null;
/*     */   }
/*     */ 
/*     */   public static <T> Constructor<T> findConstructor(Class<T> cls, boolean canFixAccess)
/*     */     throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 358 */       Constructor ctor = cls.getDeclaredConstructor(new Class[0]);
/* 359 */       if (canFixAccess) {
/* 360 */         checkAndFixAccess(ctor);
/*     */       }
/* 363 */       else if (!Modifier.isPublic(ctor.getModifiers())) {
/* 364 */         throw new IllegalArgumentException("Default constructor for " + cls.getName() + " is not accessible (non-public?): not allowed to try modify access via Reflection: can not instantiate type");
/*     */       }
/*     */ 
/* 367 */       return ctor;
/*     */     } catch (NoSuchMethodException e) {
/*     */     }
/*     */     catch (Exception e) {
/* 371 */       unwrapAndThrowAsIAE(e, "Failed to find default constructor of class " + cls.getName() + ", problem: " + e.getMessage());
/*     */     }
/* 373 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object defaultValue(Class<?> cls)
/*     */   {
/* 390 */     if (cls == Integer.TYPE) {
/* 391 */       return Integer.valueOf(0);
/*     */     }
/* 393 */     if (cls == Long.TYPE) {
/* 394 */       return Long.valueOf(0L);
/*     */     }
/* 396 */     if (cls == Boolean.TYPE) {
/* 397 */       return Boolean.FALSE;
/*     */     }
/* 399 */     if (cls == Double.TYPE) {
/* 400 */       return Double.valueOf(0.0D);
/*     */     }
/* 402 */     if (cls == Float.TYPE) {
/* 403 */       return Float.valueOf(0.0F);
/*     */     }
/* 405 */     if (cls == Byte.TYPE) {
/* 406 */       return Byte.valueOf((byte)0);
/*     */     }
/* 408 */     if (cls == Short.TYPE) {
/* 409 */       return Short.valueOf((short)0);
/*     */     }
/* 411 */     if (cls == Character.TYPE) {
/* 412 */       return Character.valueOf('\000');
/*     */     }
/* 414 */     throw new IllegalArgumentException("Class " + cls.getName() + " is not a primitive type");
/*     */   }
/*     */ 
/*     */   public static Class<?> wrapperType(Class<?> primitiveType)
/*     */   {
/* 425 */     if (primitiveType == Integer.TYPE) {
/* 426 */       return Integer.class;
/*     */     }
/* 428 */     if (primitiveType == Long.TYPE) {
/* 429 */       return Long.class;
/*     */     }
/* 431 */     if (primitiveType == Boolean.TYPE) {
/* 432 */       return Boolean.class;
/*     */     }
/* 434 */     if (primitiveType == Double.TYPE) {
/* 435 */       return Double.class;
/*     */     }
/* 437 */     if (primitiveType == Float.TYPE) {
/* 438 */       return Float.class;
/*     */     }
/* 440 */     if (primitiveType == Byte.TYPE) {
/* 441 */       return Byte.class;
/*     */     }
/* 443 */     if (primitiveType == Short.TYPE) {
/* 444 */       return Short.class;
/*     */     }
/* 446 */     if (primitiveType == Character.TYPE) {
/* 447 */       return Character.class;
/*     */     }
/* 449 */     throw new IllegalArgumentException("Class " + primitiveType.getName() + " is not a primitive type");
/*     */   }
/*     */ 
/*     */   public static void checkAndFixAccess(Member member)
/*     */   {
/* 467 */     AccessibleObject ao = (AccessibleObject)member;
/*     */     try
/*     */     {
/* 475 */       ao.setAccessible(true);
/*     */     }
/*     */     catch (SecurityException se)
/*     */     {
/* 481 */       if (!ao.isAccessible()) {
/* 482 */         Class declClass = member.getDeclaringClass();
/* 483 */         throw new IllegalArgumentException("Can not access " + member + " (from class " + declClass.getName() + "; failed to set access: " + se.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Class<? extends Enum<?>> findEnumType(EnumSet<?> s)
/*     */   {
/* 506 */     if (!s.isEmpty()) {
/* 507 */       return findEnumType((Enum)s.iterator().next());
/*     */     }
/*     */ 
/* 510 */     return EnumTypeLocator.instance.enumTypeFor(s);
/*     */   }
/*     */ 
/*     */   public static Class<? extends Enum<?>> findEnumType(EnumMap<?, ?> m)
/*     */   {
/* 523 */     if (!m.isEmpty()) {
/* 524 */       return findEnumType((Enum)m.keySet().iterator().next());
/*     */     }
/*     */ 
/* 527 */     return EnumTypeLocator.instance.enumTypeFor(m);
/*     */   }
/*     */ 
/*     */   public static Class<? extends Enum<?>> findEnumType(Enum<?> en)
/*     */   {
/* 540 */     Class ec = en.getClass();
/* 541 */     if (ec.getSuperclass() != Enum.class) {
/* 542 */       ec = ec.getSuperclass();
/*     */     }
/* 544 */     return ec;
/*     */   }
/*     */ 
/*     */   public static Class<? extends Enum<?>> findEnumType(Class<?> cls)
/*     */   {
/* 557 */     if (cls.getSuperclass() != Enum.class) {
/* 558 */       cls = cls.getSuperclass();
/*     */     }
/* 560 */     return cls;
/*     */   }
/*     */ 
/*     */   private static class EnumTypeLocator
/*     */   {
/* 575 */     static final EnumTypeLocator instance = new EnumTypeLocator();
/*     */     private final Field enumSetTypeField;
/*     */     private final Field enumMapTypeField;
/*     */ 
/*     */     private EnumTypeLocator()
/*     */     {
/* 584 */       this.enumSetTypeField = locateField(EnumSet.class, "elementType", Class.class);
/* 585 */       this.enumMapTypeField = locateField(EnumMap.class, "elementType", Class.class);
/*     */     }
/*     */ 
/*     */     public Class<? extends Enum<?>> enumTypeFor(EnumSet<?> set)
/*     */     {
/* 591 */       if (this.enumSetTypeField != null) {
/* 592 */         return (Class)get(set, this.enumSetTypeField);
/*     */       }
/* 594 */       throw new IllegalStateException("Can not figure out type for EnumSet (odd JDK platform?)");
/*     */     }
/*     */ 
/*     */     public Class<? extends Enum<?>> enumTypeFor(EnumMap<?, ?> set)
/*     */     {
/* 600 */       if (this.enumMapTypeField != null) {
/* 601 */         return (Class)get(set, this.enumMapTypeField);
/*     */       }
/* 603 */       throw new IllegalStateException("Can not figure out type for EnumMap (odd JDK platform?)");
/*     */     }
/*     */ 
/*     */     private Object get(Object bean, Field field)
/*     */     {
/*     */       try
/*     */       {
/* 610 */         return field.get(bean);
/*     */       } catch (Exception e) {
/* 612 */         throw new IllegalArgumentException(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     private static Field locateField(Class<?> fromClass, String expectedName, Class<?> type)
/*     */     {
/* 618 */       Field found = null;
/*     */ 
/* 620 */       Field[] fields = fromClass.getDeclaredFields();
/* 621 */       for (Field f : fields) {
/* 622 */         if ((expectedName.equals(f.getName())) && (f.getType() == type)) {
/* 623 */           found = f;
/* 624 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 628 */       if (found == null) {
/* 629 */         for (Field f : fields) {
/* 630 */           if (f.getType() == type)
/*     */           {
/* 632 */             if (found != null) return null;
/* 633 */             found = f;
/*     */           }
/*     */         }
/*     */       }
/* 637 */       if (found != null)
/*     */         try {
/* 639 */           found.setAccessible(true);
/*     */         } catch (Throwable t) {
/*     */         }
/* 642 */       return found;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.util.ClassUtil
 * JD-Core Version:    0.6.2
 */