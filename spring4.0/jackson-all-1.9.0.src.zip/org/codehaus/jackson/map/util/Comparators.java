/*    */ package org.codehaus.jackson.map.util;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ 
/*    */ public class Comparators
/*    */ {
/*    */   public static Object getArrayComparator(Object defaultValue)
/*    */   {
/* 24 */     final int length = Array.getLength(defaultValue);
/* 25 */     return new Object()
/*    */     {
/*    */       public boolean equals(Object other) {
/* 28 */         if (other == this) return true;
/* 29 */         if ((other == null) || (other.getClass() != this.val$defaultValue.getClass())) {
/* 30 */           return false;
/*    */         }
/* 32 */         if (Array.getLength(other) != length) return false;
/*    */ 
/* 34 */         for (int i = 0; i < length; i++) {
/* 35 */           Object value1 = Array.get(this.val$defaultValue, i);
/* 36 */           Object value2 = Array.get(other, i);
/* 37 */           if ((value1 != value2) && 
/* 38 */             (value1 != null) && 
/* 39 */             (!value1.equals(value2))) {
/* 40 */             return false;
/*    */           }
/*    */         }
/*    */ 
/* 44 */         return true;
/*    */       }
/*    */     };
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.util.Comparators
 * JD-Core Version:    0.6.2
 */