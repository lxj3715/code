/*     */ package org.codehaus.jackson.map.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ 
/*     */ public class EnumResolver<T extends Enum<T>>
/*     */ {
/*     */   protected final Class<T> _enumClass;
/*     */   protected final T[] _enums;
/*     */   protected final HashMap<String, T> _enumsById;
/*     */ 
/*     */   protected EnumResolver(Class<T> enumClass, T[] enums, HashMap<String, T> map)
/*     */   {
/*  23 */     this._enumClass = enumClass;
/*  24 */     this._enums = enums;
/*  25 */     this._enumsById = map;
/*     */   }
/*     */ 
/*     */   public static <ET extends Enum<ET>> EnumResolver<ET> constructFor(Class<ET> enumCls, AnnotationIntrospector ai)
/*     */   {
/*  34 */     Enum[] enumValues = (Enum[])enumCls.getEnumConstants();
/*  35 */     if (enumValues == null) {
/*  36 */       throw new IllegalArgumentException("No enum constants for class " + enumCls.getName());
/*     */     }
/*  38 */     HashMap map = new HashMap();
/*  39 */     for (Enum e : enumValues) {
/*  40 */       map.put(ai.findEnumValue(e), e);
/*     */     }
/*  42 */     return new EnumResolver(enumCls, enumValues, map);
/*     */   }
/*     */ 
/*     */   public static <ET extends Enum<ET>> EnumResolver<ET> constructUsingToString(Class<ET> enumCls)
/*     */   {
/*  53 */     Enum[] enumValues = (Enum[])enumCls.getEnumConstants();
/*  54 */     HashMap map = new HashMap();
/*     */ 
/*  56 */     int i = enumValues.length;
/*     */     while (true) { i--; if (i < 0) break;
/*  57 */       Enum e = enumValues[i];
/*  58 */       map.put(e.toString(), e);
/*     */     }
/*  60 */     return new EnumResolver(enumCls, enumValues, map);
/*     */   }
/*     */ 
/*     */   public static EnumResolver<?> constructUnsafe(Class<?> rawEnumCls, AnnotationIntrospector ai)
/*     */   {
/*  73 */     Class enumCls = rawEnumCls;
/*  74 */     return constructFor(enumCls, ai);
/*     */   }
/*     */ 
/*     */   public static EnumResolver<?> constructUnsafeUsingToString(Class<?> rawEnumCls)
/*     */   {
/*  87 */     Class enumCls = rawEnumCls;
/*  88 */     return constructUsingToString(enumCls);
/*     */   }
/*     */ 
/*     */   public T findEnum(String key)
/*     */   {
/*  93 */     return (Enum)this._enumsById.get(key);
/*     */   }
/*     */ 
/*     */   public T getEnum(int index)
/*     */   {
/*  98 */     if ((index < 0) || (index >= this._enums.length)) {
/*  99 */       return null;
/*     */     }
/* 101 */     return this._enums[index];
/*     */   }
/*     */   public Class<T> getEnumClass() {
/* 104 */     return this._enumClass;
/*     */   }
/* 106 */   public int lastValidIndex() { return this._enums.length - 1; }
/*     */ 
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.util.EnumResolver
 * JD-Core Version:    0.6.2
 */