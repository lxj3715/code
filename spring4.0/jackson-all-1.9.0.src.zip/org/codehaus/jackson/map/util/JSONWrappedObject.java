/*     */ package org.codehaus.jackson.map.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.JsonSerializableWithType;
/*     */ import org.codehaus.jackson.map.JsonSerializer;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class JSONWrappedObject
/*     */   implements JsonSerializableWithType
/*     */ {
/*     */   protected final String _prefix;
/*     */   protected final String _suffix;
/*     */   protected final Object _value;
/*     */   protected final JavaType _serializationType;
/*     */ 
/*     */   public JSONWrappedObject(String prefix, String suffix, Object value)
/*     */   {
/*  51 */     this(prefix, suffix, value, (JavaType)null);
/*     */   }
/*     */ 
/*     */   public JSONWrappedObject(String prefix, String suffix, Object value, JavaType asType)
/*     */   {
/*  56 */     this._prefix = prefix;
/*  57 */     this._suffix = suffix;
/*  58 */     this._value = value;
/*  59 */     this._serializationType = asType;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public JSONWrappedObject(String prefix, String suffix, Object value, Class<?> rawType)
/*     */   {
/*  68 */     this._prefix = prefix;
/*  69 */     this._suffix = suffix;
/*  70 */     this._value = value;
/*  71 */     this._serializationType = (rawType == null ? null : TypeFactory.defaultInstance().constructType(rawType));
/*     */   }
/*     */ 
/*     */   public void serializeWithType(JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  85 */     serialize(jgen, provider);
/*     */   }
/*     */ 
/*     */   public void serialize(JsonGenerator jgen, SerializerProvider provider)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  94 */     if (this._prefix != null) jgen.writeRaw(this._prefix);
/*  95 */     if (this._value == null) {
/*  96 */       provider.defaultSerializeNull(jgen);
/*  97 */     } else if (this._serializationType != null) {
/*  98 */       provider.findTypedValueSerializer(this._serializationType, true, null).serialize(this._value, jgen, provider);
/*     */     } else {
/* 100 */       Class cls = this._value.getClass();
/* 101 */       provider.findTypedValueSerializer(cls, true, null).serialize(this._value, jgen, provider);
/*     */     }
/* 103 */     if (this._suffix != null) jgen.writeRaw(this._suffix);
/*     */   }
/*     */ 
/*     */   public String getPrefix()
/*     */   {
/* 112 */     return this._prefix; } 
/* 113 */   public String getSuffix() { return this._suffix; } 
/* 114 */   public Object getValue() { return this._value; } 
/* 115 */   public JavaType getSerializationType() { return this._serializationType; }
/*     */ 
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.util.JSONWrappedObject
 * JD-Core Version:    0.6.2
 */