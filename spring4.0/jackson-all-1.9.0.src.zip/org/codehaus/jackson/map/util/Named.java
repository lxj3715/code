package org.codehaus.jackson.map.util;

public abstract interface Named
{
  public abstract String getName();
}

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.map.util.Named
 * JD-Core Version:    0.6.2
 */