/*     */ package org.codehaus.jackson.mrbean;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.codehaus.jackson.Version;
/*     */ import org.codehaus.jackson.Versioned;
/*     */ import org.codehaus.jackson.map.AbstractTypeResolver;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.codehaus.jackson.util.VersionUtil;
/*     */ 
/*     */ public class AbstractTypeMaterializer extends AbstractTypeResolver
/*     */   implements Versioned
/*     */ {
/*  72 */   protected static final int DEFAULT_FEATURE_FLAGS = Feature.collectDefaults();
/*     */   public static final String DEFAULT_PACKAGE_FOR_GENERATED = "org.codehaus.jackson.generated.";
/*     */   protected final MyClassLoader _classLoader;
/*  89 */   protected int _featureFlags = DEFAULT_FEATURE_FLAGS;
/*     */ 
/*  94 */   protected String _defaultPackage = "org.codehaus.jackson.generated.";
/*     */ 
/*     */   public AbstractTypeMaterializer()
/*     */   {
/* 103 */     this(null);
/*     */   }
/*     */ 
/*     */   public AbstractTypeMaterializer(ClassLoader parentClassLoader)
/*     */   {
/* 108 */     if (parentClassLoader == null) {
/* 109 */       parentClassLoader = getClass().getClassLoader();
/*     */     }
/* 111 */     this._classLoader = new MyClassLoader(parentClassLoader);
/*     */   }
/*     */ 
/*     */   public Version version()
/*     */   {
/* 122 */     return VersionUtil.versionFor(getClass());
/*     */   }
/*     */ 
/*     */   public final boolean isEnabled(Feature f)
/*     */   {
/* 129 */     return (this._featureFlags & f.getMask()) != 0;
/*     */   }
/*     */ 
/*     */   public void enable(Feature f)
/*     */   {
/* 136 */     this._featureFlags |= f.getMask();
/*     */   }
/*     */ 
/*     */   public void disable(Feature f)
/*     */   {
/* 143 */     this._featureFlags &= (f.getMask() ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   public void set(Feature f, boolean state)
/*     */   {
/* 151 */     if (state)
/* 152 */       enable(f);
/*     */     else
/* 154 */       disable(f);
/*     */   }
/*     */ 
/*     */   public void setDefaultPackage(String defPkg)
/*     */   {
/* 160 */     if (!defPkg.endsWith(".")) {
/* 161 */       defPkg = defPkg + ".";
/*     */     }
/* 163 */     this._defaultPackage = defPkg;
/*     */   }
/*     */ 
/*     */   public JavaType resolveAbstractType(DeserializationConfig config, JavaType type)
/*     */   {
/* 182 */     if ((type.isContainerType()) || (type.isPrimitive()) || (type.isEnumType()) || (type.isThrowable())) {
/* 183 */       return null;
/*     */     }
/* 185 */     Class cls = type.getRawClass();
/*     */ 
/* 190 */     if (!Modifier.isPublic(cls.getModifiers())) {
/* 191 */       if (isEnabled(Feature.FAIL_ON_NON_PUBLIC_TYPES)) {
/* 192 */         throw new IllegalArgumentException("Can not materialize implementation of " + cls + " since it is not public ");
/*     */       }
/* 194 */       return null;
/*     */     }
/*     */ 
/* 199 */     return config.constructType(materializeClass(config, cls));
/*     */   }
/*     */ 
/*     */   protected Class<?> materializeClass(DeserializationConfig config, Class<?> cls)
/*     */   {
/* 211 */     String newName = this._defaultPackage + cls.getName();
/* 212 */     BeanBuilder builder = new BeanBuilder(config, cls);
/* 213 */     byte[] bytecode = builder.implement(isEnabled(Feature.FAIL_ON_UNMATERIALIZED_METHOD)).build(newName);
/* 214 */     Class result = this._classLoader.loadAndResolve(newName, bytecode, cls);
/* 215 */     return result;
/*     */   }
/*     */ 
/*     */   private static class MyClassLoader extends ClassLoader
/*     */   {
/*     */     public MyClassLoader(ClassLoader parent)
/*     */     {
/* 232 */       super();
/*     */     }
/*     */ 
/*     */     public Class<?> loadAndResolve(String className, byte[] byteCode, Class<?> targetClass)
/*     */       throws IllegalArgumentException
/*     */     {
/* 243 */       Class old = findLoadedClass(className);
/* 244 */       if ((old != null) && (targetClass.isAssignableFrom(old))) {
/* 245 */         return old;
/*     */       }
/*     */       Class impl;
/*     */       try
/*     */       {
/* 250 */         impl = defineClass(className, byteCode, 0, byteCode.length);
/*     */       } catch (LinkageError e) {
/* 252 */         throw new IllegalArgumentException("Failed to load class '" + className + "': " + e.getMessage(), e);
/*     */       }
/*     */ 
/* 255 */       resolveClass(impl);
/* 256 */       return impl;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum Feature
/*     */   {
/*  37 */     FAIL_ON_UNMATERIALIZED_METHOD(false), 
/*     */ 
/*  47 */     FAIL_ON_NON_PUBLIC_TYPES(true);
/*     */ 
/*     */     final boolean _defaultState;
/*     */ 
/*     */     protected static int collectDefaults()
/*     */     {
/*  54 */       int flags = 0;
/*  55 */       for (Feature f : values()) {
/*  56 */         if (f.enabledByDefault()) {
/*  57 */           flags |= f.getMask();
/*     */         }
/*     */       }
/*  60 */       return flags;
/*     */     }
/*     */     private Feature(boolean defaultState) {
/*  63 */       this._defaultState = defaultState; } 
/*  64 */     public boolean enabledByDefault() { return this._defaultState; } 
/*  65 */     public int getMask() { return 1 << ordinal(); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.mrbean.AbstractTypeMaterializer
 * JD-Core Version:    0.6.2
 */