/*     */ package org.codehaus.jackson.mrbean;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.org.objectweb.asm.ClassWriter;
/*     */ import org.codehaus.jackson.org.objectweb.asm.FieldVisitor;
/*     */ import org.codehaus.jackson.org.objectweb.asm.MethodVisitor;
/*     */ import org.codehaus.jackson.org.objectweb.asm.Type;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ 
/*     */ public class BeanBuilder
/*     */ {
/*  22 */   protected Map<String, Property> _beanProperties = new LinkedHashMap();
/*  23 */   protected LinkedHashMap<String, Method> _unsupportedMethods = new LinkedHashMap();
/*     */   protected final Class<?> _implementedType;
/*     */   protected final TypeFactory _typeFactory;
/*     */ 
/*     */   public BeanBuilder(DeserializationConfig config, Class<?> implType)
/*     */   {
/*  34 */     this._implementedType = implType;
/*  35 */     this._typeFactory = config.getTypeFactory();
/*     */   }
/*     */ 
/*     */   public BeanBuilder implement(boolean failOnUnrecognized)
/*     */   {
/*  52 */     ArrayList implTypes = new ArrayList();
/*     */ 
/*  54 */     implTypes.add(this._implementedType);
/*  55 */     BeanUtil.findSuperTypes(this._implementedType, Object.class, implTypes);
/*     */ 
/*  57 */     for (Class impl : implTypes)
/*     */     {
/*  59 */       for (Method m : impl.getDeclaredMethods()) {
/*  60 */         String methodName = m.getName();
/*  61 */         int argCount = m.getParameterTypes().length;
/*     */ 
/*  63 */         if (argCount == 0) {
/*  64 */           if ((methodName.startsWith("get")) || ((methodName.startsWith("is")) && (returnsBoolean(m)))) {
/*  65 */             addGetter(m);
/*  66 */             continue;
/*     */           }
/*  68 */         } else if ((argCount == 1) && (methodName.startsWith("set"))) {
/*  69 */           addSetter(m);
/*  70 */           continue;
/*     */         }
/*     */ 
/*  74 */         if ((!BeanUtil.isConcrete(m)) && (!this._unsupportedMethods.containsKey(methodName)))
/*     */         {
/*  77 */           if (failOnUnrecognized) {
/*  78 */             throw new IllegalArgumentException("Unrecognized abstract method '" + methodName + "' (not a getter or setter) -- to avoid exception, disable AbstractTypeMaterializer.Feature.FAIL_ON_UNMATERIALIZED_METHOD");
/*     */           }
/*     */ 
/*  81 */           this._unsupportedMethods.put(methodName, m);
/*     */         }
/*     */       }
/*     */     }
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   public byte[] build(String className)
/*     */   {
/*  97 */     ClassWriter cw = new ClassWriter(1);
/*  98 */     String internalClass = getInternalClassName(className);
/*  99 */     String implName = getInternalClassName(this._implementedType.getName());
/*     */     String superName;
/* 104 */     if (this._implementedType.isInterface()) {
/* 105 */       String superName = "java/lang/Object";
/* 106 */       cw.visit(49, 33, internalClass, null, superName, new String[] { implName });
/*     */     }
/*     */     else {
/* 109 */       superName = implName;
/* 110 */       cw.visit(49, 33, internalClass, null, implName, null);
/*     */     }
/*     */ 
/* 113 */     cw.visitSource(className + ".java", null);
/* 114 */     generateDefaultConstructor(cw, superName);
/* 115 */     for (Property prop : this._beanProperties.values())
/*     */     {
/* 117 */       TypeDescription type = prop.selectType(this._typeFactory);
/* 118 */       createField(cw, prop, type);
/*     */ 
/* 120 */       if (!prop.hasConcreteGetter()) {
/* 121 */         createGetter(cw, internalClass, prop, type);
/*     */       }
/* 123 */       if (!prop.hasConcreteSetter()) {
/* 124 */         createSetter(cw, internalClass, prop, type);
/*     */       }
/*     */     }
/* 127 */     for (Method m : this._unsupportedMethods.values()) {
/* 128 */       createUnimplementedMethod(cw, internalClass, m);
/*     */     }
/* 130 */     cw.visitEnd();
/* 131 */     return cw.toByteArray();
/*     */   }
/*     */ 
/*     */   private static String getPropertyName(String methodName)
/*     */   {
/* 142 */     int prefixLen = methodName.startsWith("is") ? 2 : 3;
/* 143 */     String body = methodName.substring(prefixLen);
/* 144 */     StringBuilder sb = new StringBuilder(body);
/* 145 */     sb.setCharAt(0, Character.toLowerCase(body.charAt(0)));
/* 146 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static String buildGetterName(String fieldName) {
/* 150 */     return "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
/*     */   }
/*     */ 
/*     */   private static String buildSetterName(String fieldName) {
/* 154 */     return "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
/*     */   }
/*     */ 
/*     */   private static String getInternalClassName(String className) {
/* 158 */     return className.replace(".", "/");
/*     */   }
/*     */ 
/*     */   private void addGetter(Method m)
/*     */   {
/* 163 */     Property prop = findProperty(getPropertyName(m.getName()));
/*     */ 
/* 165 */     if (prop.getGetter() == null)
/* 166 */       prop.setGetter(m);
/*     */   }
/*     */ 
/*     */   private void addSetter(Method m)
/*     */   {
/* 172 */     Property prop = findProperty(getPropertyName(m.getName()));
/* 173 */     if (prop.getSetter() == null)
/* 174 */       prop.setSetter(m);
/*     */   }
/*     */ 
/*     */   private Property findProperty(String propName)
/*     */   {
/* 180 */     Property prop = (Property)this._beanProperties.get(propName);
/* 181 */     if (prop == null) {
/* 182 */       prop = new Property(propName);
/* 183 */       this._beanProperties.put(propName, prop);
/*     */     }
/* 185 */     return prop;
/*     */   }
/*     */ 
/*     */   private static final boolean returnsBoolean(Method m)
/*     */   {
/* 190 */     Class rt = m.getReturnType();
/* 191 */     return (rt == Boolean.class) || (rt == Boolean.TYPE);
/*     */   }
/*     */ 
/*     */   private static void generateDefaultConstructor(ClassWriter cw, String superName)
/*     */   {
/* 202 */     MethodVisitor mv = cw.visitMethod(1, "<init>", "()V", null, null);
/* 203 */     mv.visitCode();
/* 204 */     mv.visitVarInsn(25, 0);
/* 205 */     mv.visitMethodInsn(183, superName, "<init>", "()V");
/* 206 */     mv.visitInsn(177);
/* 207 */     mv.visitMaxs(0, 0);
/* 208 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   private static void createField(ClassWriter cw, Property prop, TypeDescription type)
/*     */   {
/* 213 */     String sig = type.hasGenerics() ? type.genericSignature() : null;
/* 214 */     String desc = type.erasedSignature();
/* 215 */     FieldVisitor fv = cw.visitField(1, prop.getFieldName(), desc, sig, null);
/* 216 */     fv.visitEnd();
/*     */   }
/*     */ 
/*     */   private static void createSetter(ClassWriter cw, String internalClassName, Property prop, TypeDescription propertyType)
/*     */   {
/* 224 */     Method setter = prop.getSetter();
/*     */     String methodName;
/*     */     String desc;
/*     */     String methodName;
/* 225 */     if (setter != null) {
/* 226 */       String desc = Type.getMethodDescriptor(setter);
/* 227 */       methodName = setter.getName();
/*     */     } else {
/* 229 */       desc = "(" + propertyType.erasedSignature() + ")V";
/* 230 */       methodName = buildSetterName(prop.getName());
/*     */     }
/* 232 */     String sig = propertyType.hasGenerics() ? "(" + propertyType.genericSignature() + ")V" : null;
/* 233 */     MethodVisitor mv = cw.visitMethod(1, methodName, desc, sig, null);
/* 234 */     mv.visitCode();
/* 235 */     mv.visitVarInsn(25, 0);
/* 236 */     mv.visitVarInsn(propertyType.getLoadOpcode(), 1);
/* 237 */     mv.visitFieldInsn(181, internalClassName, prop.getFieldName(), propertyType.erasedSignature());
/*     */ 
/* 239 */     mv.visitInsn(177);
/* 240 */     mv.visitMaxs(0, 0);
/* 241 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   private static void createGetter(ClassWriter cw, String internalClassName, Property prop, TypeDescription propertyType)
/*     */   {
/* 249 */     Method getter = prop.getGetter();
/*     */     String methodName;
/*     */     String desc;
/*     */     String methodName;
/* 250 */     if (getter != null) {
/* 251 */       String desc = Type.getMethodDescriptor(getter);
/* 252 */       methodName = getter.getName();
/*     */     } else {
/* 254 */       desc = "()" + propertyType.erasedSignature();
/* 255 */       methodName = buildGetterName(prop.getName());
/*     */     }
/*     */ 
/* 258 */     String sig = propertyType.hasGenerics() ? "()" + propertyType.genericSignature() : null;
/* 259 */     MethodVisitor mv = cw.visitMethod(1, methodName, desc, sig, null);
/* 260 */     mv.visitCode();
/* 261 */     mv.visitVarInsn(25, 0);
/* 262 */     mv.visitFieldInsn(180, internalClassName, prop.getFieldName(), propertyType.erasedSignature());
/* 263 */     mv.visitInsn(propertyType.getReturnOpcode());
/* 264 */     mv.visitMaxs(0, 0);
/* 265 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   private static void createUnimplementedMethod(ClassWriter cw, String internalClassName, Method method)
/*     */   {
/* 275 */     String exceptionName = getInternalClassName(UnsupportedOperationException.class.getName());
/* 276 */     String sig = Type.getMethodDescriptor(method);
/* 277 */     String name = method.getName();
/*     */ 
/* 279 */     MethodVisitor mv = cw.visitMethod(1, name, sig, null, null);
/* 280 */     mv.visitTypeInsn(187, exceptionName);
/* 281 */     mv.visitInsn(89);
/* 282 */     mv.visitLdcInsn("Unimplemented method '" + name + "' (not a setter/getter, could not materialize)");
/* 283 */     mv.visitMethodInsn(183, exceptionName, "<init>", "(Ljava/lang/String;)V");
/* 284 */     mv.visitInsn(191);
/* 285 */     mv.visitMaxs(0, 0);
/* 286 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   private static class TypeDescription
/*     */   {
/*     */     private final Type _asmType;
/*     */     private JavaType _jacksonType;
/*     */ 
/*     */     public TypeDescription(JavaType type)
/*     */     {
/* 396 */       this._jacksonType = type;
/* 397 */       this._asmType = Type.getType(type.getRawClass());
/*     */     }
/*     */ 
/*     */     public Class<?> getRawClass()
/*     */     {
/* 406 */       return this._jacksonType.getRawClass();
/*     */     }
/*     */     public String erasedSignature() {
/* 409 */       return this._jacksonType.getErasedSignature();
/*     */     }
/*     */ 
/*     */     public String genericSignature() {
/* 413 */       return this._jacksonType.getGenericSignature();
/*     */     }
/*     */ 
/*     */     public boolean hasGenerics()
/*     */     {
/* 421 */       return this._jacksonType.hasGenericTypes();
/*     */     }
/*     */ 
/*     */     public int getLoadOpcode()
/*     */     {
/* 437 */       return this._asmType.getOpcode(21);
/*     */     }
/*     */ 
/*     */     public int getReturnOpcode() {
/* 441 */       return this._asmType.getOpcode(172);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 446 */       return this._jacksonType.toString();
/*     */     }
/*     */ 
/*     */     public static TypeDescription moreSpecificType(TypeDescription desc1, TypeDescription desc2)
/*     */     {
/* 458 */       Class c1 = desc1.getRawClass();
/* 459 */       Class c2 = desc2.getRawClass();
/*     */ 
/* 461 */       if (c1.isAssignableFrom(c2)) {
/* 462 */         return desc2;
/*     */       }
/* 464 */       if (c2.isAssignableFrom(c1)) {
/* 465 */         return desc1;
/*     */       }
/*     */ 
/* 468 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Property
/*     */   {
/*     */     protected final String _name;
/*     */     protected final String _fieldName;
/*     */     protected Method _getter;
/*     */     protected Method _setter;
/*     */ 
/*     */     public Property(String name)
/*     */     {
/* 311 */       this._name = name;
/*     */ 
/* 313 */       this._fieldName = ("_" + name);
/*     */     }
/*     */     public String getName() {
/* 316 */       return this._name;
/*     */     }
/* 318 */     public void setGetter(Method m) { this._getter = m; } 
/* 319 */     public void setSetter(Method m) { this._setter = m; } 
/*     */     public Method getGetter() {
/* 321 */       return this._getter; } 
/* 322 */     public Method getSetter() { return this._setter; }
/*     */ 
/*     */     public String getFieldName() {
/* 325 */       return this._fieldName;
/*     */     }
/*     */ 
/*     */     public boolean hasConcreteGetter()
/*     */     {
/* 336 */       return (this._getter != null) && (BeanUtil.isConcrete(this._getter));
/*     */     }
/*     */ 
/*     */     public boolean hasConcreteSetter() {
/* 340 */       return (this._setter != null) && (BeanUtil.isConcrete(this._setter));
/*     */     }
/*     */ 
/*     */     private BeanBuilder.TypeDescription getterType(TypeFactory tf)
/*     */     {
/* 345 */       Class context = this._getter.getDeclaringClass();
/* 346 */       return new BeanBuilder.TypeDescription(tf.constructType(this._getter.getGenericReturnType(), context));
/*     */     }
/*     */ 
/*     */     private BeanBuilder.TypeDescription setterType(TypeFactory tf)
/*     */     {
/* 351 */       Class context = this._setter.getDeclaringClass();
/* 352 */       return new BeanBuilder.TypeDescription(tf.constructType(this._setter.getGenericParameterTypes()[0], context));
/*     */     }
/*     */ 
/*     */     public BeanBuilder.TypeDescription selectType(TypeFactory tf)
/*     */     {
/* 358 */       if (this._getter == null) {
/* 359 */         return setterType(tf);
/*     */       }
/* 361 */       if (this._setter == null) {
/* 362 */         return getterType(tf);
/*     */       }
/*     */ 
/* 367 */       BeanBuilder.TypeDescription st = setterType(tf);
/* 368 */       BeanBuilder.TypeDescription gt = getterType(tf);
/* 369 */       BeanBuilder.TypeDescription specificType = BeanBuilder.TypeDescription.moreSpecificType(st, gt);
/* 370 */       if (specificType == null) {
/* 371 */         throw new IllegalArgumentException("Invalid property '" + getName() + "': incompatible types for getter/setter (" + gt + " vs " + st + ")");
/*     */       }
/*     */ 
/* 376 */       return specificType;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.mrbean.BeanBuilder
 * JD-Core Version:    0.6.2
 */