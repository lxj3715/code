/*    */ package org.codehaus.jackson.mrbean;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BeanUtil
/*    */ {
/*    */   protected static boolean isConcrete(Member member)
/*    */   {
/* 13 */     int mod = member.getModifiers();
/* 14 */     return (mod & 0x600) == 0;
/*    */   }
/*    */ 
/*    */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore)
/*    */   {
/* 31 */     return findSuperTypes(cls, endBefore, new ArrayList());
/*    */   }
/*    */ 
/*    */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore, List<Class<?>> result)
/*    */   {
/* 36 */     _addSuperTypes(cls, endBefore, result, false);
/* 37 */     return result;
/*    */   }
/*    */ 
/*    */   private static void _addSuperTypes(Class<?> cls, Class<?> endBefore, Collection<Class<?>> result, boolean addClassItself)
/*    */   {
/* 42 */     if ((cls == endBefore) || (cls == null) || (cls == Object.class)) {
/* 43 */       return;
/*    */     }
/* 45 */     if (addClassItself) {
/* 46 */       if (result.contains(cls)) {
/* 47 */         return;
/*    */       }
/* 49 */       result.add(cls);
/*    */     }
/* 51 */     for (Class intCls : cls.getInterfaces()) {
/* 52 */       _addSuperTypes(intCls, endBefore, result, true);
/*    */     }
/* 54 */     _addSuperTypes(cls.getSuperclass(), endBefore, result, true);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.mrbean.BeanUtil
 * JD-Core Version:    0.6.2
 */