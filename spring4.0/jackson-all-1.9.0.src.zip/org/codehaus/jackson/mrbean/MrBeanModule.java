/*    */ package org.codehaus.jackson.mrbean;
/*    */ 
/*    */ import org.codehaus.jackson.Version;
/*    */ import org.codehaus.jackson.map.Module;
/*    */ import org.codehaus.jackson.map.Module.SetupContext;
/*    */ 
/*    */ public class MrBeanModule extends Module
/*    */ {
/*  9 */   private final String NAME = "MrBeanModule";
/*    */ 
/* 12 */   private static final Version VERSION = new Version(1, 8, 0, null);
/*    */   protected AbstractTypeMaterializer _materializer;
/*    */ 
/*    */   public MrBeanModule()
/*    */   {
/* 26 */     this(new AbstractTypeMaterializer());
/*    */   }
/*    */ 
/*    */   public MrBeanModule(AbstractTypeMaterializer materializer) {
/* 30 */     this._materializer = materializer;
/*    */   }
/*    */   public String getModuleName() {
/* 33 */     return "MrBeanModule"; } 
/* 34 */   public Version version() { return VERSION; }
/*    */ 
/*    */ 
/*    */   public void setupModule(Module.SetupContext context)
/*    */   {
/* 40 */     context.addAbstractTypeResolver(this._materializer);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.mrbean.MrBeanModule
 * JD-Core Version:    0.6.2
 */