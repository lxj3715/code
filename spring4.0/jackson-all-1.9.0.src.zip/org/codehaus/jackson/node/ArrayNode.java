/*     */ package org.codehaus.jackson.node;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ 
/*     */ public final class ArrayNode extends ContainerNode
/*     */ {
/*     */   protected ArrayList<JsonNode> _children;
/*     */ 
/*     */   public ArrayNode(JsonNodeFactory nc)
/*     */   {
/*  19 */     super(nc);
/*     */   }
/*     */ 
/*     */   public JsonToken asToken()
/*     */   {
/*  27 */     return JsonToken.START_ARRAY;
/*     */   }
/*     */   public boolean isArray() {
/*  30 */     return true;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*  35 */     return this._children == null ? 0 : this._children.size();
/*     */   }
/*     */ 
/*     */   public Iterator<JsonNode> getElements()
/*     */   {
/*  41 */     return this._children == null ? ContainerNode.NoNodesIterator.instance() : this._children.iterator();
/*     */   }
/*     */ 
/*     */   public JsonNode get(int index)
/*     */   {
/*  47 */     if ((index >= 0) && (this._children != null) && (index < this._children.size())) {
/*  48 */       return (JsonNode)this._children.get(index);
/*     */     }
/*  50 */     return null;
/*     */   }
/*     */ 
/*     */   public JsonNode get(String fieldName) {
/*  54 */     return null;
/*     */   }
/*     */   public JsonNode path(String fieldName) {
/*  57 */     return MissingNode.getInstance();
/*     */   }
/*     */ 
/*     */   public JsonNode path(int index)
/*     */   {
/*  62 */     if ((index >= 0) && (this._children != null) && (index < this._children.size())) {
/*  63 */       return (JsonNode)this._children.get(index);
/*     */     }
/*  65 */     return MissingNode.getInstance();
/*     */   }
/*     */ 
/*     */   public final void serialize(JsonGenerator jg, SerializerProvider provider)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  78 */     jg.writeStartArray();
/*  79 */     if (this._children != null) {
/*  80 */       for (JsonNode n : this._children)
/*     */       {
/*  86 */         ((BaseJsonNode)n).serialize(jg, provider);
/*     */       }
/*     */     }
/*  89 */     jg.writeEndArray();
/*     */   }
/*     */ 
/*     */   public void serializeWithType(JsonGenerator jg, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  97 */     typeSer.writeTypePrefixForArray(this, jg);
/*  98 */     if (this._children != null) {
/*  99 */       for (JsonNode n : this._children) {
/* 100 */         ((BaseJsonNode)n).serialize(jg, provider);
/*     */       }
/*     */     }
/* 103 */     typeSer.writeTypeSuffixForArray(this, jg);
/*     */   }
/*     */ 
/*     */   public JsonNode findValue(String fieldName)
/*     */   {
/* 115 */     if (this._children != null) {
/* 116 */       for (JsonNode node : this._children) {
/* 117 */         JsonNode value = node.findValue(fieldName);
/* 118 */         if (value != null) {
/* 119 */           return value;
/*     */         }
/*     */       }
/*     */     }
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */   public List<JsonNode> findValues(String fieldName, List<JsonNode> foundSoFar)
/*     */   {
/* 129 */     if (this._children != null) {
/* 130 */       for (JsonNode node : this._children) {
/* 131 */         foundSoFar = node.findValues(fieldName, foundSoFar);
/*     */       }
/*     */     }
/* 134 */     return foundSoFar;
/*     */   }
/*     */ 
/*     */   public List<String> findValuesAsText(String fieldName, List<String> foundSoFar)
/*     */   {
/* 140 */     if (this._children != null) {
/* 141 */       for (JsonNode node : this._children) {
/* 142 */         foundSoFar = node.findValuesAsText(fieldName, foundSoFar);
/*     */       }
/*     */     }
/* 145 */     return foundSoFar;
/*     */   }
/*     */ 
/*     */   public ObjectNode findParent(String fieldName)
/*     */   {
/* 151 */     if (this._children != null) {
/* 152 */       for (JsonNode node : this._children) {
/* 153 */         JsonNode parent = node.findParent(fieldName);
/* 154 */         if (parent != null) {
/* 155 */           return (ObjectNode)parent;
/*     */         }
/*     */       }
/*     */     }
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */   public List<JsonNode> findParents(String fieldName, List<JsonNode> foundSoFar)
/*     */   {
/* 165 */     if (this._children != null) {
/* 166 */       for (JsonNode node : this._children) {
/* 167 */         foundSoFar = node.findParents(fieldName, foundSoFar);
/*     */       }
/*     */     }
/* 170 */     return foundSoFar;
/*     */   }
/*     */ 
/*     */   public JsonNode set(int index, JsonNode value)
/*     */   {
/* 192 */     if (value == null) {
/* 193 */       value = nullNode();
/*     */     }
/* 195 */     return _set(index, value);
/*     */   }
/*     */ 
/*     */   public void add(JsonNode value)
/*     */   {
/* 200 */     if (value == null) {
/* 201 */       value = nullNode();
/*     */     }
/* 203 */     _add(value);
/*     */   }
/*     */ 
/*     */   public JsonNode addAll(ArrayNode other)
/*     */   {
/* 218 */     int len = other.size();
/* 219 */     if (len > 0) {
/* 220 */       if (this._children == null) {
/* 221 */         this._children = new ArrayList(len + 2);
/*     */       }
/* 223 */       other.addContentsTo(this._children);
/*     */     }
/* 225 */     return this;
/*     */   }
/*     */ 
/*     */   public JsonNode addAll(Collection<JsonNode> nodes)
/*     */   {
/* 239 */     int len = nodes.size();
/* 240 */     if (len > 0) {
/* 241 */       if (this._children == null)
/* 242 */         this._children = new ArrayList(nodes);
/*     */       else {
/* 244 */         this._children.addAll(nodes);
/*     */       }
/*     */     }
/* 247 */     return this;
/*     */   }
/*     */ 
/*     */   public void insert(int index, JsonNode value)
/*     */   {
/* 259 */     if (value == null) {
/* 260 */       value = nullNode();
/*     */     }
/* 262 */     _insert(index, value);
/*     */   }
/*     */ 
/*     */   public JsonNode remove(int index)
/*     */   {
/* 272 */     if ((index >= 0) && (this._children != null) && (index < this._children.size())) {
/* 273 */       return (JsonNode)this._children.remove(index);
/*     */     }
/* 275 */     return null;
/*     */   }
/*     */ 
/*     */   public ArrayNode removeAll()
/*     */   {
/* 281 */     this._children = null;
/* 282 */     return this;
/*     */   }
/*     */ 
/*     */   public ArrayNode addArray()
/*     */   {
/* 299 */     ArrayNode n = arrayNode();
/* 300 */     _add(n);
/* 301 */     return n;
/*     */   }
/*     */ 
/*     */   public ObjectNode addObject()
/*     */   {
/* 312 */     ObjectNode n = objectNode();
/* 313 */     _add(n);
/* 314 */     return n;
/*     */   }
/*     */ 
/*     */   public void addPOJO(Object value)
/*     */   {
/* 323 */     if (value == null)
/* 324 */       addNull();
/*     */     else
/* 326 */       _add(POJONode(value));
/*     */   }
/*     */ 
/*     */   public void addNull()
/*     */   {
/* 332 */     _add(nullNode());
/*     */   }
/*     */ 
/*     */   public void add(int v)
/*     */   {
/* 338 */     _add(numberNode(v));
/*     */   }
/*     */ 
/*     */   public void add(Integer value)
/*     */   {
/* 347 */     if (value == null)
/* 348 */       addNull();
/*     */     else
/* 350 */       _add(numberNode(value.intValue()));
/*     */   }
/*     */ 
/*     */   public void add(long v)
/*     */   {
/* 357 */     _add(numberNode(v));
/*     */   }
/*     */ 
/*     */   public void add(Long value)
/*     */   {
/* 366 */     if (value == null)
/* 367 */       addNull();
/*     */     else
/* 369 */       _add(numberNode(value.longValue()));
/*     */   }
/*     */ 
/*     */   public void add(float v)
/*     */   {
/* 376 */     _add(numberNode(v));
/*     */   }
/*     */ 
/*     */   public void add(Float value)
/*     */   {
/* 385 */     if (value == null)
/* 386 */       addNull();
/*     */     else
/* 388 */       _add(numberNode(value.floatValue()));
/*     */   }
/*     */ 
/*     */   public void add(double v)
/*     */   {
/* 395 */     _add(numberNode(v));
/*     */   }
/*     */ 
/*     */   public void add(Double value)
/*     */   {
/* 404 */     if (value == null)
/* 405 */       addNull();
/*     */     else
/* 407 */       _add(numberNode(value.doubleValue()));
/*     */   }
/*     */ 
/*     */   public void add(BigDecimal v)
/*     */   {
/* 415 */     if (v == null)
/* 416 */       addNull();
/*     */     else
/* 418 */       _add(numberNode(v));
/*     */   }
/*     */ 
/*     */   public void add(String v)
/*     */   {
/* 426 */     if (v == null)
/* 427 */       addNull();
/*     */     else
/* 429 */       _add(textNode(v));
/*     */   }
/*     */ 
/*     */   public void add(boolean v)
/*     */   {
/* 436 */     _add(booleanNode(v));
/*     */   }
/*     */ 
/*     */   public void add(Boolean value)
/*     */   {
/* 445 */     if (value == null)
/* 446 */       addNull();
/*     */     else
/* 448 */       _add(booleanNode(value.booleanValue()));
/*     */   }
/*     */ 
/*     */   public void add(byte[] v)
/*     */   {
/* 456 */     if (v == null)
/* 457 */       addNull();
/*     */     else
/* 459 */       _add(binaryNode(v));
/*     */   }
/*     */ 
/*     */   public ArrayNode insertArray(int index)
/*     */   {
/* 465 */     ArrayNode n = arrayNode();
/* 466 */     _insert(index, n);
/* 467 */     return n;
/*     */   }
/*     */ 
/*     */   public ObjectNode insertObject(int index)
/*     */   {
/* 478 */     ObjectNode n = objectNode();
/* 479 */     _insert(index, n);
/* 480 */     return n;
/*     */   }
/*     */ 
/*     */   public void insertPOJO(int index, Object value)
/*     */   {
/* 489 */     if (value == null)
/* 490 */       insertNull(index);
/*     */     else
/* 492 */       _insert(index, POJONode(value));
/*     */   }
/*     */ 
/*     */   public void insertNull(int index)
/*     */   {
/* 498 */     _insert(index, nullNode());
/*     */   }
/*     */ 
/*     */   public void insert(int index, int v)
/*     */   {
/* 504 */     _insert(index, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void insert(int index, Integer value)
/*     */   {
/* 513 */     if (value == null)
/* 514 */       insertNull(index);
/*     */     else
/* 516 */       _insert(index, numberNode(value.intValue()));
/*     */   }
/*     */ 
/*     */   public void insert(int index, long v)
/*     */   {
/* 523 */     _insert(index, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void insert(int index, Long value)
/*     */   {
/* 532 */     if (value == null)
/* 533 */       insertNull(index);
/*     */     else
/* 535 */       _insert(index, numberNode(value.longValue()));
/*     */   }
/*     */ 
/*     */   public void insert(int index, float v)
/*     */   {
/* 542 */     _insert(index, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void insert(int index, Float value)
/*     */   {
/* 551 */     if (value == null)
/* 552 */       insertNull(index);
/*     */     else
/* 554 */       _insert(index, numberNode(value.floatValue()));
/*     */   }
/*     */ 
/*     */   public void insert(int index, double v)
/*     */   {
/* 561 */     _insert(index, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void insert(int index, Double value)
/*     */   {
/* 570 */     if (value == null)
/* 571 */       insertNull(index);
/*     */     else
/* 573 */       _insert(index, numberNode(value.doubleValue()));
/*     */   }
/*     */ 
/*     */   public void insert(int index, BigDecimal v)
/*     */   {
/* 581 */     if (v == null)
/* 582 */       insertNull(index);
/*     */     else
/* 584 */       _insert(index, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void insert(int index, String v)
/*     */   {
/* 592 */     if (v == null)
/* 593 */       insertNull(index);
/*     */     else
/* 595 */       _insert(index, textNode(v));
/*     */   }
/*     */ 
/*     */   public void insert(int index, boolean v)
/*     */   {
/* 602 */     _insert(index, booleanNode(v));
/*     */   }
/*     */ 
/*     */   public void insert(int index, Boolean value)
/*     */   {
/* 611 */     if (value == null)
/* 612 */       insertNull(index);
/*     */     else
/* 614 */       _insert(index, booleanNode(value.booleanValue()));
/*     */   }
/*     */ 
/*     */   public void insert(int index, byte[] v)
/*     */   {
/* 622 */     if (v == null)
/* 623 */       insertNull(index);
/*     */     else
/* 625 */       _insert(index, binaryNode(v));
/*     */   }
/*     */ 
/*     */   protected void addContentsTo(List<JsonNode> dst)
/*     */   {
/* 640 */     if (this._children != null)
/* 641 */       for (JsonNode n : this._children)
/* 642 */         dst.add(n);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 656 */     if (o == this) return true;
/* 657 */     if (o == null) return false;
/* 658 */     if (o.getClass() != getClass()) {
/* 659 */       return false;
/*     */     }
/* 661 */     ArrayNode other = (ArrayNode)o;
/* 662 */     if ((this._children == null) || (this._children.size() == 0)) {
/* 663 */       return other.size() == 0;
/*     */     }
/* 665 */     return other._sameChildren(this._children);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*     */     int hash;
/*     */     int hash;
/* 672 */     if (this._children == null) {
/* 673 */       hash = 1;
/*     */     } else {
/* 675 */       hash = this._children.size();
/* 676 */       for (JsonNode n : this._children) {
/* 677 */         if (n != null) {
/* 678 */           hash ^= n.hashCode();
/*     */         }
/*     */       }
/*     */     }
/* 682 */     return hash;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 689 */     StringBuilder sb = new StringBuilder(16 + (size() << 4));
/* 690 */     sb.append('[');
/* 691 */     if (this._children != null) {
/* 692 */       int i = 0; for (int len = this._children.size(); i < len; i++) {
/* 693 */         if (i > 0) {
/* 694 */           sb.append(',');
/*     */         }
/* 696 */         sb.append(((JsonNode)this._children.get(i)).toString());
/*     */       }
/*     */     }
/* 699 */     sb.append(']');
/* 700 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public JsonNode _set(int index, JsonNode value)
/*     */   {
/* 711 */     if ((this._children == null) || (index < 0) || (index >= this._children.size())) {
/* 712 */       throw new IndexOutOfBoundsException("Illegal index " + index + ", array size " + size());
/*     */     }
/* 714 */     return (JsonNode)this._children.set(index, value);
/*     */   }
/*     */ 
/*     */   private void _add(JsonNode node)
/*     */   {
/* 719 */     if (this._children == null) {
/* 720 */       this._children = new ArrayList();
/*     */     }
/* 722 */     this._children.add(node);
/*     */   }
/*     */ 
/*     */   private void _insert(int index, JsonNode node)
/*     */   {
/* 727 */     if (this._children == null) {
/* 728 */       this._children = new ArrayList();
/* 729 */       this._children.add(node);
/* 730 */       return;
/*     */     }
/* 732 */     if (index < 0)
/* 733 */       this._children.add(0, node);
/* 734 */     else if (index >= this._children.size())
/* 735 */       this._children.add(node);
/*     */     else
/* 737 */       this._children.add(index, node);
/*     */   }
/*     */ 
/*     */   private boolean _sameChildren(ArrayList<JsonNode> otherChildren)
/*     */   {
/* 747 */     int len = otherChildren.size();
/* 748 */     if (size() != len) {
/* 749 */       return false;
/*     */     }
/* 751 */     for (int i = 0; i < len; i++) {
/* 752 */       if (!((JsonNode)this._children.get(i)).equals(otherChildren.get(i))) {
/* 753 */         return false;
/*     */       }
/*     */     }
/* 756 */     return true;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.node.ArrayNode
 * JD-Core Version:    0.6.2
 */