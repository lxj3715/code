/*     */ package org.codehaus.jackson.node;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ 
/*     */ public abstract class ContainerNode extends BaseJsonNode
/*     */ {
/*     */   JsonNodeFactory _nodeFactory;
/*     */ 
/*     */   protected ContainerNode(JsonNodeFactory nc)
/*     */   {
/*  27 */     this._nodeFactory = nc;
/*     */   }
/*     */ 
/*     */   public boolean isContainerNode() {
/*  31 */     return true;
/*     */   }
/*     */ 
/*     */   public abstract JsonToken asToken();
/*     */ 
/*     */   public String getValueAsText()
/*     */   {
/*  43 */     return null;
/*     */   }
/*     */ 
/*     */   public String asText() {
/*  47 */     return "";
/*     */   }
/*     */ 
/*     */   public abstract JsonNode findValue(String paramString);
/*     */ 
/*     */   public abstract ObjectNode findParent(String paramString);
/*     */ 
/*     */   public abstract List<JsonNode> findValues(String paramString, List<JsonNode> paramList);
/*     */ 
/*     */   public abstract List<JsonNode> findParents(String paramString, List<JsonNode> paramList);
/*     */ 
/*     */   public abstract List<String> findValuesAsText(String paramString, List<String> paramList);
/*     */ 
/*     */   public abstract int size();
/*     */ 
/*     */   public abstract JsonNode get(int paramInt);
/*     */ 
/*     */   public abstract JsonNode get(String paramString);
/*     */ 
/*     */   public final ArrayNode arrayNode()
/*     */   {
/*  96 */     return this._nodeFactory.arrayNode();
/*     */   }
/*     */ 
/*     */   public final ObjectNode objectNode()
/*     */   {
/* 102 */     return this._nodeFactory.objectNode();
/*     */   }
/* 104 */   public final NullNode nullNode() { return this._nodeFactory.nullNode(); } 
/*     */   public final BooleanNode booleanNode(boolean v) {
/* 106 */     return this._nodeFactory.booleanNode(v);
/*     */   }
/* 108 */   public final NumericNode numberNode(byte v) { return this._nodeFactory.numberNode(v); } 
/* 109 */   public final NumericNode numberNode(short v) { return this._nodeFactory.numberNode(v); } 
/* 110 */   public final NumericNode numberNode(int v) { return this._nodeFactory.numberNode(v); } 
/* 111 */   public final NumericNode numberNode(long v) { return this._nodeFactory.numberNode(v); } 
/* 112 */   public final NumericNode numberNode(float v) { return this._nodeFactory.numberNode(v); } 
/* 113 */   public final NumericNode numberNode(double v) { return this._nodeFactory.numberNode(v); } 
/* 114 */   public final NumericNode numberNode(BigDecimal v) { return this._nodeFactory.numberNode(v); } 
/*     */   public final TextNode textNode(String text) {
/* 116 */     return this._nodeFactory.textNode(text);
/*     */   }
/* 118 */   public final BinaryNode binaryNode(byte[] data) { return this._nodeFactory.binaryNode(data); } 
/* 119 */   public final BinaryNode binaryNode(byte[] data, int offset, int length) { return this._nodeFactory.binaryNode(data, offset, length); } 
/*     */   public final POJONode POJONode(Object pojo) {
/* 121 */     return this._nodeFactory.POJONode(pojo);
/*     */   }
/*     */ 
/*     */   public abstract ContainerNode removeAll();
/*     */ 
/*     */   protected static class NoStringsIterator
/*     */     implements Iterator<String>
/*     */   {
/* 168 */     static final NoStringsIterator instance = new NoStringsIterator();
/*     */ 
/*     */     public static NoStringsIterator instance()
/*     */     {
/* 172 */       return instance;
/*     */     }
/*     */     public boolean hasNext() {
/* 175 */       return false;
/*     */     }
/* 177 */     public String next() { throw new NoSuchElementException(); }
/*     */ 
/*     */ 
/*     */     public void remove()
/*     */     {
/* 182 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class NoNodesIterator
/*     */     implements Iterator<JsonNode>
/*     */   {
/* 147 */     static final NoNodesIterator instance = new NoNodesIterator();
/*     */ 
/*     */     public static NoNodesIterator instance()
/*     */     {
/* 151 */       return instance;
/*     */     }
/*     */     public boolean hasNext() {
/* 154 */       return false;
/*     */     }
/* 156 */     public JsonNode next() { throw new NoSuchElementException(); }
/*     */ 
/*     */ 
/*     */     public void remove()
/*     */     {
/* 161 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.node.ContainerNode
 * JD-Core Version:    0.6.2
 */