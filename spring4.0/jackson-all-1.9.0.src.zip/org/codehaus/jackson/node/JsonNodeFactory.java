/*     */ package org.codehaus.jackson.node;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ public class JsonNodeFactory
/*     */ {
/*  20 */   public static final JsonNodeFactory instance = new JsonNodeFactory();
/*     */ 
/*     */   public BooleanNode booleanNode(boolean v)
/*     */   {
/*  35 */     return v ? BooleanNode.getTrue() : BooleanNode.getFalse();
/*     */   }
/*     */ 
/*     */   public NullNode nullNode()
/*     */   {
/*  42 */     return NullNode.getInstance();
/*     */   }
/*     */ 
/*     */   public NumericNode numberNode(byte v)
/*     */   {
/*  54 */     return IntNode.valueOf(v);
/*     */   }
/*     */ 
/*     */   public ValueNode numberNode(Byte value)
/*     */   {
/*  65 */     return value == null ? nullNode() : IntNode.valueOf(value.intValue());
/*     */   }
/*     */ 
/*     */   public NumericNode numberNode(short v)
/*     */   {
/*  72 */     return IntNode.valueOf(v);
/*     */   }
/*     */ 
/*     */   public ValueNode numberNode(Short value)
/*     */   {
/*  83 */     return value == null ? nullNode() : IntNode.valueOf(value.shortValue());
/*     */   }
/*     */ 
/*     */   public NumericNode numberNode(int v)
/*     */   {
/*  90 */     return IntNode.valueOf(v);
/*     */   }
/*     */ 
/*     */   public ValueNode numberNode(Integer value)
/*     */   {
/* 101 */     return value == null ? nullNode() : IntNode.valueOf(value.intValue());
/*     */   }
/*     */ 
/*     */   public NumericNode numberNode(long v)
/*     */   {
/* 108 */     return LongNode.valueOf(v);
/*     */   }
/*     */ 
/*     */   public ValueNode numberNode(Long value)
/*     */   {
/* 119 */     return value == null ? nullNode() : LongNode.valueOf(value.longValue());
/*     */   }
/*     */ 
/*     */   public NumericNode numberNode(BigInteger v)
/*     */   {
/* 126 */     return BigIntegerNode.valueOf(v);
/*     */   }
/*     */ 
/*     */   public NumericNode numberNode(float v)
/*     */   {
/* 132 */     return DoubleNode.valueOf(v);
/*     */   }
/*     */ 
/*     */   public ValueNode numberNode(Float value)
/*     */   {
/* 143 */     return value == null ? nullNode() : DoubleNode.valueOf(value.doubleValue());
/*     */   }
/*     */ 
/*     */   public NumericNode numberNode(double v)
/*     */   {
/* 150 */     return DoubleNode.valueOf(v);
/*     */   }
/*     */ 
/*     */   public ValueNode numberNode(Double value)
/*     */   {
/* 161 */     return value == null ? nullNode() : DoubleNode.valueOf(value.doubleValue());
/*     */   }
/*     */ 
/*     */   public NumericNode numberNode(BigDecimal v)
/*     */   {
/* 168 */     return DecimalNode.valueOf(v);
/*     */   }
/*     */ 
/*     */   public TextNode textNode(String text)
/*     */   {
/* 180 */     return TextNode.valueOf(text);
/*     */   }
/*     */ 
/*     */   public BinaryNode binaryNode(byte[] data)
/*     */   {
/* 187 */     return BinaryNode.valueOf(data);
/*     */   }
/*     */ 
/*     */   public BinaryNode binaryNode(byte[] data, int offset, int length)
/*     */   {
/* 195 */     return BinaryNode.valueOf(data, offset, length);
/*     */   }
/*     */ 
/*     */   public ArrayNode arrayNode()
/*     */   {
/* 207 */     return new ArrayNode(this);
/*     */   }
/*     */ 
/*     */   public ObjectNode objectNode()
/*     */   {
/* 212 */     return new ObjectNode(this);
/*     */   }
/*     */ 
/*     */   public POJONode POJONode(Object pojo)
/*     */   {
/* 220 */     return new POJONode(pojo);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.node.JsonNodeFactory
 * JD-Core Version:    0.6.2
 */