/*    */ package org.codehaus.jackson.node;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ 
/*    */ public final class MissingNode extends BaseJsonNode
/*    */ {
/* 24 */   private static final MissingNode instance = new MissingNode();
/*    */ 
/*    */   public static MissingNode getInstance()
/*    */   {
/* 28 */     return instance;
/*    */   }
/* 30 */   public JsonToken asToken() { return JsonToken.NOT_AVAILABLE; }
/*    */ 
/*    */   public boolean isMissingNode() {
/* 33 */     return true;
/*    */   }
/*    */   public String asText() {
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   public int asInt(int defaultValue) {
/* 40 */     return 0;
/*    */   }
/*    */ 
/*    */   public long asLong(long defaultValue) {
/* 44 */     return 0L;
/*    */   }
/*    */ 
/*    */   public double asDouble(double defaultValue) {
/* 48 */     return 0.0D;
/*    */   }
/*    */ 
/*    */   public JsonNode path(String fieldName) {
/* 52 */     return this;
/*    */   }
/*    */   public JsonNode path(int index) {
/* 55 */     return this;
/*    */   }
/*    */ 
/*    */   public final void serialize(JsonGenerator jg, SerializerProvider provider)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 65 */     jg.writeNull();
/*    */   }
/*    */ 
/*    */   public void serializeWithType(JsonGenerator jg, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 73 */     jg.writeNull();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 87 */     return o == this;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 94 */     return "";
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.node.MissingNode
 * JD-Core Version:    0.6.2
 */