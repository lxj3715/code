/*    */ package org.codehaus.jackson.node;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import org.codehaus.jackson.JsonParser.NumberType;
/*    */ 
/*    */ public abstract class NumericNode extends ValueNode
/*    */ {
/*    */   public final boolean isNumber()
/*    */   {
/* 17 */     return true;
/*    */   }
/*    */ 
/*    */   public abstract JsonParser.NumberType getNumberType();
/*    */ 
/*    */   public abstract Number getNumberValue();
/*    */ 
/*    */   public abstract int getIntValue();
/*    */ 
/*    */   public abstract long getLongValue();
/*    */ 
/*    */   public abstract double getDoubleValue();
/*    */ 
/*    */   public abstract BigDecimal getDecimalValue();
/*    */ 
/*    */   public abstract BigInteger getBigIntegerValue();
/*    */ 
/*    */   public abstract String asText();
/*    */ 
/*    */   public int asInt()
/*    */   {
/* 48 */     return getIntValue();
/*    */   }
/*    */ 
/*    */   public int asInt(int defaultValue) {
/* 52 */     return getIntValue();
/*    */   }
/*    */ 
/*    */   public long asLong()
/*    */   {
/* 57 */     return getLongValue();
/*    */   }
/*    */ 
/*    */   public long asLong(long defaultValue) {
/* 61 */     return getLongValue();
/*    */   }
/*    */ 
/*    */   public double asDouble()
/*    */   {
/* 66 */     return getDoubleValue();
/*    */   }
/*    */ 
/*    */   public double asDouble(double defaultValue) {
/* 70 */     return getDoubleValue();
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.node.NumericNode
 * JD-Core Version:    0.6.2
 */