/*     */ package org.codehaus.jackson.node;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonNode;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.map.TypeSerializer;
/*     */ 
/*     */ public class ObjectNode extends ContainerNode
/*     */ {
/*  17 */   protected LinkedHashMap<String, JsonNode> _children = null;
/*     */ 
/*  19 */   public ObjectNode(JsonNodeFactory nc) { super(nc); }
/*     */ 
/*     */ 
/*     */   public JsonToken asToken()
/*     */   {
/*  27 */     return JsonToken.START_OBJECT;
/*     */   }
/*     */   public boolean isObject() {
/*  30 */     return true;
/*     */   }
/*     */ 
/*     */   public int size() {
/*  34 */     return this._children == null ? 0 : this._children.size();
/*     */   }
/*     */ 
/*     */   public Iterator<JsonNode> getElements()
/*     */   {
/*  40 */     return this._children == null ? ContainerNode.NoNodesIterator.instance() : this._children.values().iterator();
/*     */   }
/*     */ 
/*     */   public JsonNode get(int index) {
/*  44 */     return null;
/*     */   }
/*     */ 
/*     */   public JsonNode get(String fieldName)
/*     */   {
/*  49 */     if (this._children != null) {
/*  50 */       return (JsonNode)this._children.get(fieldName);
/*     */     }
/*  52 */     return null;
/*     */   }
/*     */ 
/*     */   public Iterator<String> getFieldNames()
/*     */   {
/*  58 */     return this._children == null ? ContainerNode.NoStringsIterator.instance() : this._children.keySet().iterator();
/*     */   }
/*     */ 
/*     */   public JsonNode path(int index)
/*     */   {
/*  64 */     return MissingNode.getInstance();
/*     */   }
/*     */ 
/*     */   public JsonNode path(String fieldName)
/*     */   {
/*  70 */     if (this._children != null) {
/*  71 */       JsonNode n = (JsonNode)this._children.get(fieldName);
/*  72 */       if (n != null) {
/*  73 */         return n;
/*     */       }
/*     */     }
/*  76 */     return MissingNode.getInstance();
/*     */   }
/*     */ 
/*     */   public Iterator<Map.Entry<String, JsonNode>> getFields()
/*     */   {
/*  86 */     if (this._children == null) {
/*  87 */       return NoFieldsIterator.instance;
/*     */     }
/*  89 */     return this._children.entrySet().iterator();
/*     */   }
/*     */ 
/*     */   public ObjectNode with(String propertyName)
/*     */   {
/*  95 */     if (this._children == null) {
/*  96 */       this._children = new LinkedHashMap();
/*     */     } else {
/*  98 */       JsonNode n = (JsonNode)this._children.get(propertyName);
/*  99 */       if (n != null) {
/* 100 */         if ((n instanceof ObjectNode)) {
/* 101 */           return (ObjectNode)n;
/*     */         }
/* 103 */         throw new UnsupportedOperationException("Property '" + propertyName + "' has value that is not of type ObjectNode (but " + n.getClass().getName() + ")");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 108 */     ObjectNode result = objectNode();
/* 109 */     this._children.put(propertyName, result);
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */   public JsonNode findValue(String fieldName)
/*     */   {
/* 122 */     if (this._children != null) {
/* 123 */       for (Map.Entry entry : this._children.entrySet()) {
/* 124 */         if (fieldName.equals(entry.getKey())) {
/* 125 */           return (JsonNode)entry.getValue();
/*     */         }
/* 127 */         JsonNode value = ((JsonNode)entry.getValue()).findValue(fieldName);
/* 128 */         if (value != null) {
/* 129 */           return value;
/*     */         }
/*     */       }
/*     */     }
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   public List<JsonNode> findValues(String fieldName, List<JsonNode> foundSoFar)
/*     */   {
/* 139 */     if (this._children != null) {
/* 140 */       for (Map.Entry entry : this._children.entrySet()) {
/* 141 */         if (fieldName.equals(entry.getKey())) {
/* 142 */           if (foundSoFar == null) {
/* 143 */             foundSoFar = new ArrayList();
/*     */           }
/* 145 */           foundSoFar.add(entry.getValue());
/*     */         } else {
/* 147 */           foundSoFar = ((JsonNode)entry.getValue()).findValues(fieldName, foundSoFar);
/*     */         }
/*     */       }
/*     */     }
/* 151 */     return foundSoFar;
/*     */   }
/*     */ 
/*     */   public List<String> findValuesAsText(String fieldName, List<String> foundSoFar)
/*     */   {
/* 157 */     if (this._children != null) {
/* 158 */       for (Map.Entry entry : this._children.entrySet()) {
/* 159 */         if (fieldName.equals(entry.getKey())) {
/* 160 */           if (foundSoFar == null) {
/* 161 */             foundSoFar = new ArrayList();
/*     */           }
/* 163 */           foundSoFar.add(((JsonNode)entry.getValue()).asText());
/*     */         } else {
/* 165 */           foundSoFar = ((JsonNode)entry.getValue()).findValuesAsText(fieldName, foundSoFar);
/*     */         }
/*     */       }
/*     */     }
/* 169 */     return foundSoFar;
/*     */   }
/*     */ 
/*     */   public ObjectNode findParent(String fieldName)
/*     */   {
/* 175 */     if (this._children != null) {
/* 176 */       for (Map.Entry entry : this._children.entrySet()) {
/* 177 */         if (fieldName.equals(entry.getKey())) {
/* 178 */           return this;
/*     */         }
/* 180 */         JsonNode value = ((JsonNode)entry.getValue()).findParent(fieldName);
/* 181 */         if (value != null) {
/* 182 */           return (ObjectNode)value;
/*     */         }
/*     */       }
/*     */     }
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */   public List<JsonNode> findParents(String fieldName, List<JsonNode> foundSoFar)
/*     */   {
/* 192 */     if (this._children != null) {
/* 193 */       for (Map.Entry entry : this._children.entrySet()) {
/* 194 */         if (fieldName.equals(entry.getKey())) {
/* 195 */           if (foundSoFar == null) {
/* 196 */             foundSoFar = new ArrayList();
/*     */           }
/* 198 */           foundSoFar.add(this);
/*     */         } else {
/* 200 */           foundSoFar = ((JsonNode)entry.getValue()).findParents(fieldName, foundSoFar);
/*     */         }
/*     */       }
/*     */     }
/* 204 */     return foundSoFar;
/*     */   }
/*     */ 
/*     */   public final void serialize(JsonGenerator jg, SerializerProvider provider)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 221 */     jg.writeStartObject();
/* 222 */     if (this._children != null) {
/* 223 */       for (Map.Entry en : this._children.entrySet()) {
/* 224 */         jg.writeFieldName((String)en.getKey());
/*     */ 
/* 230 */         ((BaseJsonNode)en.getValue()).serialize(jg, provider);
/*     */       }
/*     */     }
/* 233 */     jg.writeEndObject();
/*     */   }
/*     */ 
/*     */   public void serializeWithType(JsonGenerator jg, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 241 */     typeSer.writeTypePrefixForObject(this, jg);
/* 242 */     if (this._children != null) {
/* 243 */       for (Map.Entry en : this._children.entrySet()) {
/* 244 */         jg.writeFieldName((String)en.getKey());
/* 245 */         ((BaseJsonNode)en.getValue()).serialize(jg, provider);
/*     */       }
/*     */     }
/* 248 */     typeSer.writeTypeSuffixForObject(this, jg);
/*     */   }
/*     */ 
/*     */   public JsonNode put(String fieldName, JsonNode value)
/*     */   {
/* 270 */     if (value == null) {
/* 271 */       value = nullNode();
/*     */     }
/* 273 */     return _put(fieldName, value);
/*     */   }
/*     */ 
/*     */   public JsonNode remove(String fieldName)
/*     */   {
/* 283 */     if (this._children != null) {
/* 284 */       return (JsonNode)this._children.remove(fieldName);
/*     */     }
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */   public ObjectNode remove(Collection<String> fieldNames)
/*     */   {
/* 301 */     if (this._children != null) {
/* 302 */       for (String fieldName : fieldNames) {
/* 303 */         this._children.remove(fieldName);
/*     */       }
/*     */     }
/* 306 */     return this;
/*     */   }
/*     */ 
/*     */   public ObjectNode removeAll()
/*     */   {
/* 316 */     this._children = null;
/* 317 */     return this;
/*     */   }
/*     */ 
/*     */   public JsonNode putAll(Map<String, JsonNode> properties)
/*     */   {
/* 332 */     if (this._children == null)
/* 333 */       this._children = new LinkedHashMap(properties);
/*     */     else {
/* 335 */       for (Map.Entry en : properties.entrySet()) {
/* 336 */         JsonNode n = (JsonNode)en.getValue();
/* 337 */         if (n == null) {
/* 338 */           n = nullNode();
/*     */         }
/* 340 */         this._children.put(en.getKey(), n);
/*     */       }
/*     */     }
/* 343 */     return this;
/*     */   }
/*     */ 
/*     */   public JsonNode putAll(ObjectNode other)
/*     */   {
/* 358 */     int len = other.size();
/* 359 */     if (len > 0) {
/* 360 */       if (this._children == null) {
/* 361 */         this._children = new LinkedHashMap(len);
/*     */       }
/* 363 */       other.putContentsTo(this._children);
/*     */     }
/* 365 */     return this;
/*     */   }
/*     */ 
/*     */   public ObjectNode retain(Collection<String> fieldNames)
/*     */   {
/* 380 */     if (this._children != null) {
/* 381 */       Iterator entries = this._children.entrySet().iterator();
/* 382 */       while (entries.hasNext()) {
/* 383 */         Map.Entry entry = (Map.Entry)entries.next();
/* 384 */         if (!fieldNames.contains(entry.getKey())) {
/* 385 */           entries.remove();
/*     */         }
/*     */       }
/*     */     }
/* 389 */     return this;
/*     */   }
/*     */ 
/*     */   public ObjectNode retain(String[] fieldNames)
/*     */   {
/* 403 */     return retain(Arrays.asList(fieldNames));
/*     */   }
/*     */ 
/*     */   public ArrayNode putArray(String fieldName)
/*     */   {
/* 421 */     ArrayNode n = arrayNode();
/* 422 */     _put(fieldName, n);
/* 423 */     return n;
/*     */   }
/*     */ 
/*     */   public ObjectNode putObject(String fieldName)
/*     */   {
/* 435 */     ObjectNode n = objectNode();
/* 436 */     _put(fieldName, n);
/* 437 */     return n;
/*     */   }
/*     */ 
/*     */   public void putPOJO(String fieldName, Object pojo)
/*     */   {
/* 442 */     _put(fieldName, POJONode(pojo));
/*     */   }
/*     */ 
/*     */   public void putNull(String fieldName)
/*     */   {
/* 447 */     _put(fieldName, nullNode());
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, int v)
/*     */   {
/* 453 */     _put(fieldName, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, Integer value)
/*     */   {
/* 462 */     if (value == null)
/* 463 */       _put(fieldName, nullNode());
/*     */     else
/* 465 */       _put(fieldName, numberNode(value.intValue()));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, long v)
/*     */   {
/* 472 */     _put(fieldName, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, Long value)
/*     */   {
/* 481 */     if (value == null)
/* 482 */       _put(fieldName, nullNode());
/*     */     else
/* 484 */       _put(fieldName, numberNode(value.longValue()));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, float v)
/*     */   {
/* 491 */     _put(fieldName, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, Float value)
/*     */   {
/* 500 */     if (value == null)
/* 501 */       _put(fieldName, nullNode());
/*     */     else
/* 503 */       _put(fieldName, numberNode(value.floatValue()));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, double v)
/*     */   {
/* 510 */     _put(fieldName, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, Double value)
/*     */   {
/* 519 */     if (value == null)
/* 520 */       _put(fieldName, nullNode());
/*     */     else
/* 522 */       _put(fieldName, numberNode(value.doubleValue()));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, BigDecimal v)
/*     */   {
/* 530 */     if (v == null)
/* 531 */       putNull(fieldName);
/*     */     else
/* 533 */       _put(fieldName, numberNode(v));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, String v)
/*     */   {
/* 541 */     if (v == null)
/* 542 */       putNull(fieldName);
/*     */     else
/* 544 */       _put(fieldName, textNode(v));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, boolean v)
/*     */   {
/* 551 */     _put(fieldName, booleanNode(v));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, Boolean value)
/*     */   {
/* 560 */     if (value == null)
/* 561 */       _put(fieldName, nullNode());
/*     */     else
/* 563 */       _put(fieldName, booleanNode(value.booleanValue()));
/*     */   }
/*     */ 
/*     */   public void put(String fieldName, byte[] v)
/*     */   {
/* 571 */     if (v == null)
/* 572 */       _put(fieldName, nullNode());
/*     */     else
/* 574 */       _put(fieldName, binaryNode(v));
/*     */   }
/*     */ 
/*     */   protected void putContentsTo(Map<String, JsonNode> dst)
/*     */   {
/* 589 */     if (this._children != null)
/* 590 */       for (Map.Entry en : this._children.entrySet())
/* 591 */         dst.put(en.getKey(), en.getValue());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 605 */     if (o == this) return true;
/* 606 */     if (o == null) return false;
/* 607 */     if (o.getClass() != getClass()) {
/* 608 */       return false;
/*     */     }
/* 610 */     ObjectNode other = (ObjectNode)o;
/* 611 */     if (other.size() != size()) {
/* 612 */       return false;
/*     */     }
/* 614 */     if (this._children != null) {
/* 615 */       for (Map.Entry en : this._children.entrySet()) {
/* 616 */         String key = (String)en.getKey();
/* 617 */         JsonNode value = (JsonNode)en.getValue();
/*     */ 
/* 619 */         JsonNode otherValue = other.get(key);
/*     */ 
/* 621 */         if ((otherValue == null) || (!otherValue.equals(value))) {
/* 622 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 626 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 632 */     return this._children == null ? -1 : this._children.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 638 */     StringBuilder sb = new StringBuilder(32 + (size() << 4));
/* 639 */     sb.append("{");
/*     */     int count;
/* 640 */     if (this._children != null) {
/* 641 */       count = 0;
/* 642 */       for (Map.Entry en : this._children.entrySet()) {
/* 643 */         if (count > 0) {
/* 644 */           sb.append(",");
/*     */         }
/* 646 */         count++;
/* 647 */         TextNode.appendQuoted(sb, (String)en.getKey());
/* 648 */         sb.append(':');
/* 649 */         sb.append(((JsonNode)en.getValue()).toString());
/*     */       }
/*     */     }
/* 652 */     sb.append("}");
/* 653 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private final JsonNode _put(String fieldName, JsonNode value)
/*     */   {
/* 664 */     if (this._children == null) {
/* 665 */       this._children = new LinkedHashMap();
/*     */     }
/* 667 */     return (JsonNode)this._children.put(fieldName, value);
/*     */   }
/*     */ 
/*     */   protected static class NoFieldsIterator
/*     */     implements Iterator<Map.Entry<String, JsonNode>>
/*     */   {
/* 682 */     static final NoFieldsIterator instance = new NoFieldsIterator();
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 687 */       return false;
/*     */     }
/* 689 */     public Map.Entry<String, JsonNode> next() { throw new NoSuchElementException(); }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 693 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.node.ObjectNode
 * JD-Core Version:    0.6.2
 */