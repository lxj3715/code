/*     */ package org.codehaus.jackson.node;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.codehaus.jackson.Base64Variant;
/*     */ import org.codehaus.jackson.Base64Variants;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonLocation;
/*     */ import org.codehaus.jackson.JsonParseException;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ import org.codehaus.jackson.io.NumberInput;
/*     */ import org.codehaus.jackson.map.SerializerProvider;
/*     */ import org.codehaus.jackson.util.ByteArrayBuilder;
/*     */ import org.codehaus.jackson.util.CharTypes;
/*     */ 
/*     */ public final class TextNode extends ValueNode
/*     */ {
/*     */   static final int INT_SPACE = 32;
/*  19 */   static final TextNode EMPTY_STRING_NODE = new TextNode("");
/*     */   final String _value;
/*     */ 
/*     */   public TextNode(String v)
/*     */   {
/*  23 */     this._value = v;
/*     */   }
/*     */ 
/*     */   public static TextNode valueOf(String v)
/*     */   {
/*  36 */     if (v == null) {
/*  37 */       return null;
/*     */     }
/*  39 */     if (v.length() == 0) {
/*  40 */       return EMPTY_STRING_NODE;
/*     */     }
/*  42 */     return new TextNode(v);
/*     */   }
/*     */   public JsonToken asToken() {
/*  45 */     return JsonToken.VALUE_STRING;
/*     */   }
/*     */ 
/*     */   public boolean isTextual()
/*     */   {
/*  51 */     return true;
/*     */   }
/*     */ 
/*     */   public String getTextValue() {
/*  55 */     return this._value;
/*     */   }
/*     */ 
/*     */   public byte[] getBinaryValue(Base64Variant b64variant)
/*     */     throws IOException
/*     */   {
/*  66 */     ByteArrayBuilder builder = new ByteArrayBuilder(100);
/*  67 */     String str = this._value;
/*  68 */     int ptr = 0;
/*  69 */     int len = str.length();
/*     */ 
/*  72 */     while (ptr < len)
/*     */     {
/*     */       do
/*     */       {
/*  76 */         ch = str.charAt(ptr++);
/*  77 */         if (ptr >= len)
/*     */           break;
/*     */       }
/*  80 */       while (ch <= ' ');
/*  81 */       int bits = b64variant.decodeBase64Char(ch);
/*  82 */       if (bits < 0) {
/*  83 */         _reportInvalidBase64(b64variant, ch, 0);
/*     */       }
/*  85 */       int decodedData = bits;
/*     */ 
/*  87 */       if (ptr >= len) {
/*  88 */         _reportBase64EOF();
/*     */       }
/*  90 */       char ch = str.charAt(ptr++);
/*  91 */       bits = b64variant.decodeBase64Char(ch);
/*  92 */       if (bits < 0) {
/*  93 */         _reportInvalidBase64(b64variant, ch, 1);
/*     */       }
/*  95 */       decodedData = decodedData << 6 | bits;
/*     */ 
/*  97 */       if (ptr >= len)
/*     */       {
/*  99 */         if (!b64variant.usesPadding())
/*     */         {
/* 101 */           decodedData >>= 4;
/* 102 */           builder.append(decodedData);
/* 103 */           break;
/*     */         }
/* 105 */         _reportBase64EOF();
/*     */       }
/* 107 */       ch = str.charAt(ptr++);
/* 108 */       bits = b64variant.decodeBase64Char(ch);
/*     */ 
/* 111 */       if (bits < 0) {
/* 112 */         if (bits != -2) {
/* 113 */           _reportInvalidBase64(b64variant, ch, 2);
/*     */         }
/*     */ 
/* 116 */         if (ptr >= len) {
/* 117 */           _reportBase64EOF();
/*     */         }
/* 119 */         ch = str.charAt(ptr++);
/* 120 */         if (!b64variant.usesPaddingChar(ch)) {
/* 121 */           _reportInvalidBase64(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*     */         }
/*     */ 
/* 124 */         decodedData >>= 4;
/* 125 */         builder.append(decodedData);
/*     */       }
/*     */       else
/*     */       {
/* 129 */         decodedData = decodedData << 6 | bits;
/*     */ 
/* 131 */         if (ptr >= len)
/*     */         {
/* 133 */           if (!b64variant.usesPadding()) {
/* 134 */             decodedData >>= 2;
/* 135 */             builder.appendTwoBytes(decodedData);
/* 136 */             break;
/*     */           }
/* 138 */           _reportBase64EOF();
/*     */         }
/* 140 */         ch = str.charAt(ptr++);
/* 141 */         bits = b64variant.decodeBase64Char(ch);
/* 142 */         if (bits < 0) {
/* 143 */           if (bits != -2) {
/* 144 */             _reportInvalidBase64(b64variant, ch, 3);
/*     */           }
/* 146 */           decodedData >>= 2;
/* 147 */           builder.appendTwoBytes(decodedData);
/*     */         }
/*     */         else {
/* 150 */           decodedData = decodedData << 6 | bits;
/* 151 */           builder.appendThreeBytes(decodedData);
/*     */         }
/*     */       }
/*     */     }
/* 154 */     return builder.toByteArray();
/*     */   }
/*     */ 
/*     */   public byte[] getBinaryValue()
/*     */     throws IOException
/*     */   {
/* 160 */     return getBinaryValue(Base64Variants.getDefaultVariant());
/*     */   }
/*     */ 
/*     */   public String asText()
/*     */   {
/* 171 */     return this._value;
/*     */   }
/*     */ 
/*     */   public boolean asBoolean(boolean defaultValue)
/*     */   {
/* 178 */     if ((this._value != null) && 
/* 179 */       ("true".equals(this._value.trim()))) {
/* 180 */       return true;
/*     */     }
/*     */ 
/* 183 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   public int asInt(int defaultValue)
/*     */   {
/* 188 */     return NumberInput.parseAsInt(this._value, defaultValue);
/*     */   }
/*     */ 
/*     */   public long asLong(long defaultValue)
/*     */   {
/* 193 */     return NumberInput.parseAsLong(this._value, defaultValue);
/*     */   }
/*     */ 
/*     */   public double asDouble(double defaultValue)
/*     */   {
/* 198 */     return NumberInput.parseAsDouble(this._value, defaultValue);
/*     */   }
/*     */ 
/*     */   public final void serialize(JsonGenerator jg, SerializerProvider provider)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/* 211 */     if (this._value == null)
/* 212 */       jg.writeNull();
/*     */     else
/* 214 */       jg.writeString(this._value);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 227 */     if (o == this) return true;
/* 228 */     if (o == null) return false;
/* 229 */     if (o.getClass() != getClass()) {
/* 230 */       return false;
/*     */     }
/* 232 */     return ((TextNode)o)._value.equals(this._value);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 236 */     return this._value.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 244 */     int len = this._value.length();
/* 245 */     len = len + 2 + (len >> 4);
/* 246 */     StringBuilder sb = new StringBuilder(len);
/* 247 */     appendQuoted(sb, this._value);
/* 248 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected static void appendQuoted(StringBuilder sb, String content)
/*     */   {
/* 253 */     sb.append('"');
/* 254 */     CharTypes.appendQuoted(sb, content);
/* 255 */     sb.append('"');
/*     */   }
/*     */ 
/*     */   protected void _reportInvalidBase64(Base64Variant b64variant, char ch, int bindex)
/*     */     throws JsonParseException
/*     */   {
/* 267 */     _reportInvalidBase64(b64variant, ch, bindex, null);
/*     */   }
/*     */ 
/*     */   protected void _reportInvalidBase64(Base64Variant b64variant, char ch, int bindex, String msg)
/*     */     throws JsonParseException
/*     */   {
/*     */     String base;
/*     */     String base;
/* 278 */     if (ch <= ' ') {
/* 279 */       base = "Illegal white space character (code 0x" + Integer.toHexString(ch) + ") as character #" + (bindex + 1) + " of 4-char base64 unit: can only used between units";
/*     */     }
/*     */     else
/*     */     {
/*     */       String base;
/* 280 */       if (b64variant.usesPaddingChar(ch)) {
/* 281 */         base = "Unexpected padding character ('" + b64variant.getPaddingChar() + "') as character #" + (bindex + 1) + " of 4-char base64 unit: padding only legal as 3rd or 4th character";
/*     */       }
/*     */       else
/*     */       {
/*     */         String base;
/* 282 */         if ((!Character.isDefined(ch)) || (Character.isISOControl(ch)))
/*     */         {
/* 284 */           base = "Illegal character (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*     */         }
/* 286 */         else base = "Illegal character '" + ch + "' (code 0x" + Integer.toHexString(ch) + ") in base64 content"; 
/*     */       }
/*     */     }
/* 288 */     if (msg != null) {
/* 289 */       base = base + ": " + msg;
/*     */     }
/* 291 */     throw new JsonParseException(base, JsonLocation.NA);
/*     */   }
/*     */ 
/*     */   protected void _reportBase64EOF()
/*     */     throws JsonParseException
/*     */   {
/* 297 */     throw new JsonParseException("Unexpected end-of-String when base64 content", JsonLocation.NA);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.node.TextNode
 * JD-Core Version:    0.6.2
 */