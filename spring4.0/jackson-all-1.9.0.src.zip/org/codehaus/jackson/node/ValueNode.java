/*    */ package org.codehaus.jackson.node;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.JsonToken;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.TypeSerializer;
/*    */ 
/*    */ public abstract class ValueNode extends BaseJsonNode
/*    */ {
/*    */   public boolean isValueNode()
/*    */   {
/* 23 */     return true;
/*    */   }
/*    */ 
/*    */   public abstract JsonToken asToken();
/*    */ 
/*    */   public void serializeWithType(JsonGenerator jg, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 33 */     typeSer.writeTypePrefixForScalar(this, jg);
/* 34 */     serialize(jg, provider);
/* 35 */     typeSer.writeTypeSuffixForScalar(this, jg);
/*    */   }
/*    */ 
/*    */   public JsonNode path(String fieldName)
/*    */   {
/* 45 */     return MissingNode.getInstance();
/*    */   }
/*    */   public JsonNode path(int index) {
/* 48 */     return MissingNode.getInstance();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 57 */     return asText();
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.node.ValueNode
 * JD-Core Version:    0.6.2
 */