package org.codehaus.jackson.org.objectweb.asm;

class Edge
{
  int a;
  Label b;
  Edge c;
}

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.org.objectweb.asm.Edge
 * JD-Core Version:    0.6.2
 */