/*    */ package org.codehaus.jackson.schema;
/*    */ 
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.annotate.JsonCreator;
/*    */ import org.codehaus.jackson.annotate.JsonValue;
/*    */ import org.codehaus.jackson.node.JsonNodeFactory;
/*    */ import org.codehaus.jackson.node.ObjectNode;
/*    */ 
/*    */ public class JsonSchema
/*    */ {
/*    */   private final ObjectNode schema;
/*    */ 
/*    */   @JsonCreator
/*    */   public JsonSchema(ObjectNode schema)
/*    */   {
/* 30 */     this.schema = schema;
/*    */   }
/*    */ 
/*    */   @JsonValue
/*    */   public ObjectNode getSchemaNode()
/*    */   {
/* 45 */     return this.schema;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return this.schema.toString();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 57 */     if (o == this) return true;
/* 58 */     if (o == null) return false;
/* 59 */     if (!(o instanceof JsonSchema)) return false;
/*    */ 
/* 61 */     JsonSchema other = (JsonSchema)o;
/* 62 */     if (this.schema == null) {
/* 63 */       return other.schema == null;
/*    */     }
/* 65 */     return this.schema.equals(other.schema);
/*    */   }
/*    */ 
/*    */   public static JsonNode getDefaultSchemaNode()
/*    */   {
/* 75 */     ObjectNode objectNode = JsonNodeFactory.instance.objectNode();
/* 76 */     objectNode.put("type", "any");
/*    */ 
/* 79 */     return objectNode;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.schema.JsonSchema
 * JD-Core Version:    0.6.2
 */