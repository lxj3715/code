/*    */ package org.codehaus.jackson.smile;
/*    */ 
/*    */ public class SmileBufferRecycler<T>
/*    */ {
/*    */   public static final int DEFAULT_NAME_BUFFER_LENGTH = 64;
/*    */   public static final int DEFAULT_STRING_VALUE_BUFFER_LENGTH = 64;
/*    */   protected T[] _seenNamesBuffer;
/*    */   protected T[] _seenStringValuesBuffer;
/*    */ 
/*    */   public T[] allocSeenNamesBuffer()
/*    */   {
/* 26 */     Object[] result = this._seenNamesBuffer;
/* 27 */     if (result != null)
/*    */     {
/* 29 */       this._seenNamesBuffer = null;
/*    */     }
/*    */ 
/* 32 */     return result;
/*    */   }
/*    */ 
/*    */   public T[] allocSeenStringValuesBuffer()
/*    */   {
/* 38 */     Object[] result = this._seenStringValuesBuffer;
/* 39 */     if (result != null) {
/* 40 */       this._seenStringValuesBuffer = null;
/*    */     }
/*    */ 
/* 43 */     return result;
/*    */   }
/*    */ 
/*    */   public void releaseSeenNamesBuffer(T[] buffer) {
/* 47 */     this._seenNamesBuffer = buffer;
/*    */   }
/*    */ 
/*    */   public void releaseSeenStringValuesBuffer(T[] buffer) {
/* 51 */     this._seenStringValuesBuffer = buffer;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.smile.SmileBufferRecycler
 * JD-Core Version:    0.6.2
 */