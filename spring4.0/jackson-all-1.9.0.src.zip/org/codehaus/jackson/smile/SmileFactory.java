/*     */ package org.codehaus.jackson.smile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.net.URL;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerationException;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonParseException;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.ObjectCodec;
/*     */ import org.codehaus.jackson.format.InputAccessor;
/*     */ import org.codehaus.jackson.format.MatchStrength;
/*     */ import org.codehaus.jackson.io.IOContext;
/*     */ 
/*     */ public class SmileFactory extends JsonFactory
/*     */ {
/*     */   public static final String FORMAT_NAME_SMILE = "Smile";
/*  41 */   static final int DEFAULT_SMILE_PARSER_FEATURE_FLAGS = SmileParser.Feature.collectDefaults();
/*     */ 
/*  47 */   static final int DEFAULT_SMILE_GENERATOR_FEATURE_FLAGS = SmileGenerator.Feature.collectDefaults();
/*     */   protected boolean _cfgDelegateToTextual;
/*  64 */   protected int _smileParserFeatures = DEFAULT_SMILE_PARSER_FEATURE_FLAGS;
/*     */ 
/*  66 */   protected int _smileGeneratorFeatures = DEFAULT_SMILE_GENERATOR_FEATURE_FLAGS;
/*     */ 
/*     */   public SmileFactory()
/*     */   {
/*  84 */     this(null);
/*     */   }
/*  86 */   public SmileFactory(ObjectCodec oc) { super(oc); }
/*     */ 
/*     */   public void delegateToTextual(boolean state) {
/*  89 */     this._cfgDelegateToTextual = state;
/*     */   }
/*     */ 
/*     */   public String getFormatName()
/*     */   {
/* 101 */     return "Smile";
/*     */   }
/*     */ 
/*     */   public MatchStrength hasFormat(InputAccessor acc)
/*     */     throws IOException
/*     */   {
/* 110 */     return SmileParserBootstrapper.hasSmileFormat(acc);
/*     */   }
/*     */ 
/*     */   public final SmileFactory configure(SmileParser.Feature f, boolean state)
/*     */   {
/* 125 */     if (state)
/* 126 */       enable(f);
/*     */     else {
/* 128 */       disable(f);
/*     */     }
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   public SmileFactory enable(SmileParser.Feature f)
/*     */   {
/* 138 */     this._smileParserFeatures |= f.getMask();
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */   public SmileFactory disable(SmileParser.Feature f)
/*     */   {
/* 147 */     this._smileParserFeatures &= (f.getMask() ^ 0xFFFFFFFF);
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */   public final boolean isEnabled(SmileParser.Feature f)
/*     */   {
/* 155 */     return (this._smileParserFeatures & f.getMask()) != 0;
/*     */   }
/*     */ 
/*     */   public final SmileFactory configure(SmileGenerator.Feature f, boolean state)
/*     */   {
/* 171 */     if (state)
/* 172 */       enable(f);
/*     */     else {
/* 174 */       disable(f);
/*     */     }
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */   public SmileFactory enable(SmileGenerator.Feature f)
/*     */   {
/* 185 */     this._smileGeneratorFeatures |= f.getMask();
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */   public SmileFactory disable(SmileGenerator.Feature f)
/*     */   {
/* 194 */     this._smileGeneratorFeatures &= (f.getMask() ^ 0xFFFFFFFF);
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */   public final boolean isEnabled(SmileGenerator.Feature f)
/*     */   {
/* 202 */     return (this._smileGeneratorFeatures & f.getMask()) != 0;
/*     */   }
/*     */ 
/*     */   public SmileParser createJsonParser(File f)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 215 */     return _createJsonParser(new FileInputStream(f), _createContext(f, true));
/*     */   }
/*     */ 
/*     */   public SmileParser createJsonParser(URL url)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 222 */     return _createJsonParser(_optimizedStreamFromURL(url), _createContext(url, true));
/*     */   }
/*     */ 
/*     */   public SmileParser createJsonParser(InputStream in)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 229 */     return _createJsonParser(in, _createContext(in, false));
/*     */   }
/*     */ 
/*     */   public SmileParser createJsonParser(byte[] data)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 238 */     IOContext ctxt = _createContext(data, true);
/* 239 */     return _createJsonParser(data, 0, data.length, ctxt);
/*     */   }
/*     */ 
/*     */   public SmileParser createJsonParser(byte[] data, int offset, int len)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 246 */     return _createJsonParser(data, offset, len, _createContext(data, true));
/*     */   }
/*     */ 
/*     */   public SmileGenerator createJsonGenerator(OutputStream out, JsonEncoding enc)
/*     */     throws IOException
/*     */   {
/* 263 */     return createJsonGenerator(out);
/*     */   }
/*     */ 
/*     */   public SmileGenerator createJsonGenerator(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 274 */     IOContext ctxt = _createContext(out, false);
/* 275 */     return _createJsonGenerator(out, ctxt);
/*     */   }
/*     */ 
/*     */   protected SmileParser _createJsonParser(InputStream in, IOContext ctxt)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 294 */     return new SmileParserBootstrapper(ctxt, in).constructParser(this._parserFeatures, this._smileParserFeatures, this._objectCodec, this._rootByteSymbols);
/*     */   }
/*     */ 
/*     */   protected JsonParser _createJsonParser(Reader r, IOContext ctxt)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 306 */     if (this._cfgDelegateToTextual) {
/* 307 */       return super._createJsonParser(r, ctxt);
/*     */     }
/* 309 */     throw new UnsupportedOperationException("Can not create generator for non-byte-based target");
/*     */   }
/*     */ 
/*     */   protected SmileParser _createJsonParser(byte[] data, int offset, int len, IOContext ctxt)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 320 */     return new SmileParserBootstrapper(ctxt, data, offset, len).constructParser(this._parserFeatures, this._smileParserFeatures, this._objectCodec, this._rootByteSymbols);
/*     */   }
/*     */ 
/*     */   protected JsonGenerator _createJsonGenerator(Writer out, IOContext ctxt)
/*     */     throws IOException
/*     */   {
/* 332 */     if (this._cfgDelegateToTextual) {
/* 333 */       return super._createJsonGenerator(out, ctxt);
/*     */     }
/* 335 */     throw new UnsupportedOperationException("Can not create generator for non-byte-based target");
/*     */   }
/*     */ 
/*     */   protected Writer _createWriter(OutputStream out, JsonEncoding enc, IOContext ctxt)
/*     */     throws IOException
/*     */   {
/* 343 */     if (this._cfgDelegateToTextual) {
/* 344 */       return super._createWriter(out, enc, ctxt);
/*     */     }
/* 346 */     throw new UnsupportedOperationException("Can not create generator for non-byte-based target");
/*     */   }
/*     */ 
/*     */   protected SmileGenerator _createJsonGenerator(OutputStream out, IOContext ctxt)
/*     */     throws IOException
/*     */   {
/* 358 */     int feats = this._smileGeneratorFeatures;
/*     */ 
/* 364 */     SmileGenerator gen = new SmileGenerator(ctxt, this._generatorFeatures, feats, this._objectCodec, out);
/* 365 */     if ((feats & SmileGenerator.Feature.WRITE_HEADER.getMask()) != 0) {
/* 366 */       gen.writeHeader();
/*     */     } else {
/* 368 */       if ((feats & SmileGenerator.Feature.CHECK_SHARED_STRING_VALUES.getMask()) != 0) {
/* 369 */         throw new JsonGenerationException("Inconsistent settings: WRITE_HEADER disabled, but CHECK_SHARED_STRING_VALUES enabled; can not construct generator due to possible data loss (either enable WRITE_HEADER, or disable CHECK_SHARED_STRING_VALUES to resolve)");
/*     */       }
/*     */ 
/* 373 */       if ((feats & SmileGenerator.Feature.ENCODE_BINARY_AS_7BIT.getMask()) == 0) {
/* 374 */         throw new JsonGenerationException("Inconsistent settings: WRITE_HEADER disabled, but ENCODE_BINARY_AS_7BIT disabled; can not construct generator due to possible data loss (either enable WRITE_HEADER, or ENCODE_BINARY_AS_7BIT to resolve)");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 379 */     return gen;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.smile.SmileFactory
 * JD-Core Version:    0.6.2
 */