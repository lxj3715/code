/*      */ package org.codehaus.jackson.smile;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Arrays;
/*      */ import org.codehaus.jackson.Base64Variant;
/*      */ import org.codehaus.jackson.JsonGenerationException;
/*      */ import org.codehaus.jackson.JsonGenerator;
/*      */ import org.codehaus.jackson.JsonGenerator.Feature;
/*      */ import org.codehaus.jackson.JsonStreamContext;
/*      */ import org.codehaus.jackson.ObjectCodec;
/*      */ import org.codehaus.jackson.PrettyPrinter;
/*      */ import org.codehaus.jackson.SerializableString;
/*      */ import org.codehaus.jackson.impl.JsonGeneratorBase;
/*      */ import org.codehaus.jackson.impl.JsonWriteContext;
/*      */ import org.codehaus.jackson.io.IOContext;
/*      */ import org.codehaus.jackson.io.SerializedString;
/*      */ 
/*      */ public class SmileGenerator extends JsonGeneratorBase
/*      */ {
/*      */   private static final int MIN_BUFFER_LENGTH = 770;
/*      */   protected static final byte TOKEN_BYTE_LONG_STRING_ASCII = -32;
/*      */   protected static final byte TOKEN_BYTE_LONG_STRING_UNICODE = -28;
/*      */   protected static final byte TOKEN_BYTE_INT_32 = 36;
/*      */   protected static final byte TOKEN_BYTE_INT_64 = 37;
/*      */   protected static final byte TOKEN_BYTE_BIG_INTEGER = 38;
/*      */   protected static final byte TOKEN_BYTE_FLOAT_32 = 40;
/*      */   protected static final byte TOKEN_BYTE_FLOAT_64 = 41;
/*      */   protected static final byte TOKEN_BYTE_BIG_DECIMAL = 42;
/*      */   protected static final int SURR1_FIRST = 55296;
/*      */   protected static final int SURR1_LAST = 56319;
/*      */   protected static final int SURR2_FIRST = 56320;
/*      */   protected static final int SURR2_LAST = 57343;
/*      */   protected static final long MIN_INT_AS_LONG = -2147483648L;
/*      */   protected static final long MAX_INT_AS_LONG = 2147483647L;
/*      */   protected final IOContext _ioContext;
/*      */   protected final OutputStream _out;
/*      */   protected int _smileFeatures;
/*      */   protected final SmileBufferRecycler<SharedStringNode> _smileBufferRecycler;
/*      */   protected byte[] _outputBuffer;
/*  203 */   protected int _outputTail = 0;
/*      */   protected final int _outputEnd;
/*      */   protected char[] _charBuffer;
/*      */   protected final int _charBufferLength;
/*      */   protected int _bytesWritten;
/*      */   protected SharedStringNode[] _seenNames;
/*      */   protected int _seenNameCount;
/*      */   protected SharedStringNode[] _seenStringValues;
/*      */   protected int _seenStringValueCount;
/*      */   protected boolean _bufferRecyclable;
/*  274 */   protected static final ThreadLocal<SoftReference<SmileBufferRecycler<SharedStringNode>>> _smileRecyclerRef = new ThreadLocal();
/*      */ 
/*      */   public SmileGenerator(IOContext ctxt, int jsonFeatures, int smileFeatures, ObjectCodec codec, OutputStream out)
/*      */   {
/*  286 */     super(jsonFeatures, codec);
/*  287 */     this._smileFeatures = smileFeatures;
/*  288 */     this._ioContext = ctxt;
/*  289 */     this._smileBufferRecycler = _smileBufferRecycler();
/*  290 */     this._out = out;
/*  291 */     this._bufferRecyclable = true;
/*  292 */     this._outputBuffer = ctxt.allocWriteEncodingBuffer();
/*  293 */     this._outputEnd = this._outputBuffer.length;
/*  294 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  295 */     this._charBufferLength = this._charBuffer.length;
/*      */ 
/*  297 */     if (this._outputEnd < 770) {
/*  298 */       throw new IllegalStateException("Internal encoding buffer length (" + this._outputEnd + ") too short, must be at least " + 770);
/*      */     }
/*      */ 
/*  301 */     if ((smileFeatures & Feature.CHECK_SHARED_NAMES.getMask()) == 0) {
/*  302 */       this._seenNames = null;
/*  303 */       this._seenNameCount = -1;
/*      */     } else {
/*  305 */       this._seenNames = ((SharedStringNode[])this._smileBufferRecycler.allocSeenNamesBuffer());
/*  306 */       if (this._seenNames == null) {
/*  307 */         this._seenNames = new SharedStringNode[64];
/*      */       }
/*  309 */       this._seenNameCount = 0;
/*      */     }
/*      */ 
/*  312 */     if ((smileFeatures & Feature.CHECK_SHARED_STRING_VALUES.getMask()) == 0) {
/*  313 */       this._seenStringValues = null;
/*  314 */       this._seenStringValueCount = -1;
/*      */     } else {
/*  316 */       this._seenStringValues = ((SharedStringNode[])this._smileBufferRecycler.allocSeenStringValuesBuffer());
/*  317 */       if (this._seenStringValues == null) {
/*  318 */         this._seenStringValues = new SharedStringNode[64];
/*      */       }
/*  320 */       this._seenStringValueCount = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   public SmileGenerator(IOContext ctxt, int jsonFeatures, int smileFeatures, ObjectCodec codec, OutputStream out, byte[] outputBuffer, int offset, boolean bufferRecyclable)
/*      */   {
/*  327 */     super(jsonFeatures, codec);
/*  328 */     this._smileFeatures = smileFeatures;
/*  329 */     this._ioContext = ctxt;
/*  330 */     this._smileBufferRecycler = _smileBufferRecycler();
/*  331 */     this._out = out;
/*  332 */     this._bufferRecyclable = bufferRecyclable;
/*  333 */     this._outputTail = offset;
/*  334 */     this._outputBuffer = outputBuffer;
/*  335 */     this._outputEnd = this._outputBuffer.length;
/*  336 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  337 */     this._charBufferLength = this._charBuffer.length;
/*      */ 
/*  339 */     if (this._outputEnd < 770) {
/*  340 */       throw new IllegalStateException("Internal encoding buffer length (" + this._outputEnd + ") too short, must be at least " + 770);
/*      */     }
/*      */ 
/*  343 */     if ((smileFeatures & Feature.CHECK_SHARED_NAMES.getMask()) == 0) {
/*  344 */       this._seenNames = null;
/*  345 */       this._seenNameCount = -1;
/*      */     } else {
/*  347 */       this._seenNames = ((SharedStringNode[])this._smileBufferRecycler.allocSeenNamesBuffer());
/*  348 */       if (this._seenNames == null) {
/*  349 */         this._seenNames = new SharedStringNode[64];
/*      */       }
/*  351 */       this._seenNameCount = 0;
/*      */     }
/*      */ 
/*  354 */     if ((smileFeatures & Feature.CHECK_SHARED_STRING_VALUES.getMask()) == 0) {
/*  355 */       this._seenStringValues = null;
/*  356 */       this._seenStringValueCount = -1;
/*      */     } else {
/*  358 */       this._seenStringValues = ((SharedStringNode[])this._smileBufferRecycler.allocSeenStringValuesBuffer());
/*  359 */       if (this._seenStringValues == null) {
/*  360 */         this._seenStringValues = new SharedStringNode[64];
/*      */       }
/*  362 */       this._seenStringValueCount = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeHeader()
/*      */     throws IOException
/*      */   {
/*  375 */     int last = 0;
/*  376 */     if ((this._smileFeatures & Feature.CHECK_SHARED_NAMES.getMask()) != 0) {
/*  377 */       last |= 1;
/*      */     }
/*  379 */     if ((this._smileFeatures & Feature.CHECK_SHARED_STRING_VALUES.getMask()) != 0) {
/*  380 */       last |= 2;
/*      */     }
/*  382 */     if ((this._smileFeatures & Feature.ENCODE_BINARY_AS_7BIT.getMask()) == 0) {
/*  383 */       last |= 4;
/*      */     }
/*  385 */     _writeBytes((byte)58, (byte)41, (byte)10, (byte)last);
/*      */   }
/*      */ 
/*      */   protected static final SmileBufferRecycler<SharedStringNode> _smileBufferRecycler()
/*      */   {
/*  390 */     SoftReference ref = (SoftReference)_smileRecyclerRef.get();
/*  391 */     SmileBufferRecycler br = ref == null ? null : (SmileBufferRecycler)ref.get();
/*      */ 
/*  393 */     if (br == null) {
/*  394 */       br = new SmileBufferRecycler();
/*  395 */       _smileRecyclerRef.set(new SoftReference(br));
/*      */     }
/*  397 */     return br;
/*      */   }
/*      */ 
/*      */   public JsonGenerator useDefaultPrettyPrinter()
/*      */   {
/*  413 */     return this;
/*      */   }
/*      */ 
/*      */   public JsonGenerator setPrettyPrinter(PrettyPrinter pp)
/*      */   {
/*  422 */     return this;
/*      */   }
/*      */ 
/*      */   public Object getOutputTarget()
/*      */   {
/*  427 */     return this._out;
/*      */   }
/*      */ 
/*      */   public final void writeFieldName(String name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  443 */     if (this._writeContext.writeFieldName(name) == 4) {
/*  444 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  446 */     _writeFieldName(name);
/*      */   }
/*      */ 
/*      */   public final void writeFieldName(SerializedString name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  454 */     if (this._writeContext.writeFieldName(name.getValue()) == 4) {
/*  455 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  457 */     _writeFieldName(name);
/*      */   }
/*      */ 
/*      */   public final void writeFieldName(SerializableString name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  465 */     if (this._writeContext.writeFieldName(name.getValue()) == 4) {
/*  466 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  468 */     _writeFieldName(name);
/*      */   }
/*      */ 
/*      */   public final void writeStringField(String fieldName, String value)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  475 */     if (this._writeContext.writeFieldName(fieldName) == 4) {
/*  476 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  478 */     _writeFieldName(fieldName);
/*  479 */     writeString(value);
/*      */   }
/*      */ 
/*      */   public SmileGenerator enable(Feature f)
/*      */   {
/*  489 */     this._smileFeatures |= f.getMask();
/*  490 */     return this;
/*      */   }
/*      */ 
/*      */   public SmileGenerator disable(Feature f) {
/*  494 */     this._smileFeatures &= (f.getMask() ^ 0xFFFFFFFF);
/*  495 */     return this;
/*      */   }
/*      */ 
/*      */   public final boolean isEnabled(Feature f) {
/*  499 */     return (this._smileFeatures & f.getMask()) != 0;
/*      */   }
/*      */ 
/*      */   public SmileGenerator configure(Feature f, boolean state) {
/*  503 */     if (state)
/*  504 */       enable(f);
/*      */     else {
/*  506 */       disable(f);
/*      */     }
/*  508 */     return this;
/*      */   }
/*      */ 
/*      */   public void writeRaw(byte b)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  525 */     _writeByte((byte)-8);
/*      */   }
/*      */ 
/*      */   public void writeBytes(byte[] data, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  536 */     _writeBytes(data, offset, len);
/*      */   }
/*      */ 
/*      */   public final void writeStartArray()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  548 */     _verifyValueWrite("start an array");
/*  549 */     this._writeContext = this._writeContext.createChildArrayContext();
/*  550 */     _writeByte((byte)-8);
/*      */   }
/*      */ 
/*      */   public final void writeEndArray()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  556 */     if (!this._writeContext.inArray()) {
/*  557 */       _reportError("Current context not an ARRAY but " + this._writeContext.getTypeDesc());
/*      */     }
/*  559 */     _writeByte((byte)-7);
/*  560 */     this._writeContext = this._writeContext.getParent();
/*      */   }
/*      */ 
/*      */   public final void writeStartObject()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  566 */     _verifyValueWrite("start an object");
/*  567 */     this._writeContext = this._writeContext.createChildObjectContext();
/*  568 */     _writeByte((byte)-6);
/*      */   }
/*      */ 
/*      */   public final void writeEndObject()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  574 */     if (!this._writeContext.inObject()) {
/*  575 */       _reportError("Current context not an object but " + this._writeContext.getTypeDesc());
/*      */     }
/*  577 */     this._writeContext = this._writeContext.getParent();
/*  578 */     _writeByte((byte)-5);
/*      */   }
/*      */ 
/*      */   private final void _writeFieldName(String name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  584 */     int len = name.length();
/*  585 */     if (len == 0) {
/*  586 */       _writeByte((byte)32);
/*  587 */       return;
/*      */     }
/*      */ 
/*  590 */     if (this._seenNameCount >= 0) {
/*  591 */       int ix = _findSeenName(name);
/*  592 */       if (ix >= 0) {
/*  593 */         _writeSharedNameReference(ix);
/*  594 */         return;
/*      */       }
/*      */     }
/*  597 */     if (len > 56) {
/*  598 */       _writeNonShortFieldName(name, len);
/*  599 */       return;
/*      */     }
/*      */ 
/*  603 */     if (this._outputTail + 196 >= this._outputEnd) {
/*  604 */       _flushBuffer();
/*      */     }
/*      */ 
/*  607 */     name.getChars(0, len, this._charBuffer, 0);
/*  608 */     int origOffset = this._outputTail;
/*  609 */     this._outputTail += 1;
/*  610 */     int byteLen = _shortUTF8Encode(this._charBuffer, 0, len);
/*      */     byte typeToken;
/*  614 */     if (byteLen == len)
/*      */     {
/*      */       byte typeToken;
/*  615 */       if (byteLen <= 64) {
/*  616 */         typeToken = (byte)(127 + byteLen);
/*      */       } else {
/*  618 */         byte typeToken = 52;
/*      */ 
/*  620 */         this._outputBuffer[(this._outputTail++)] = -4;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*      */       byte typeToken;
/*  623 */       if (byteLen <= 56)
/*      */       {
/*  625 */         typeToken = (byte)(190 + byteLen);
/*      */       } else {
/*  627 */         typeToken = 52;
/*      */ 
/*  629 */         this._outputBuffer[(this._outputTail++)] = -4;
/*      */       }
/*      */     }
/*      */ 
/*  633 */     this._outputBuffer[origOffset] = typeToken;
/*      */ 
/*  635 */     if (this._seenNameCount >= 0)
/*  636 */       _addSeenName(name);
/*      */   }
/*      */ 
/*      */   private final void _writeNonShortFieldName(String name, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  643 */     _writeByte((byte)52);
/*      */ 
/*  645 */     if (len > this._charBufferLength) {
/*  646 */       _slowUTF8Encode(name);
/*      */     } else {
/*  648 */       name.getChars(0, len, this._charBuffer, 0);
/*      */ 
/*  650 */       int maxLen = len + len + len;
/*  651 */       if (maxLen <= this._outputBuffer.length) {
/*  652 */         if (this._outputTail + maxLen >= this._outputEnd) {
/*  653 */           _flushBuffer();
/*      */         }
/*  655 */         _shortUTF8Encode(this._charBuffer, 0, len);
/*      */       } else {
/*  657 */         _mediumUTF8Encode(this._charBuffer, 0, len);
/*      */       }
/*      */     }
/*  660 */     if (this._seenNameCount >= 0) {
/*  661 */       _addSeenName(name);
/*      */     }
/*  663 */     if (this._outputTail >= this._outputEnd) {
/*  664 */       _flushBuffer();
/*      */     }
/*  666 */     this._outputBuffer[(this._outputTail++)] = -4;
/*      */   }
/*      */ 
/*      */   protected final void _writeFieldName(SerializableString name)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  672 */     int charLen = name.charLength();
/*  673 */     if (charLen == 0) {
/*  674 */       _writeByte((byte)32);
/*  675 */       return;
/*      */     }
/*  677 */     byte[] bytes = name.asUnquotedUTF8();
/*  678 */     int byteLen = bytes.length;
/*  679 */     if (byteLen != charLen) {
/*  680 */       _writeFieldNameUnicode(name, bytes);
/*  681 */       return;
/*      */     }
/*      */ 
/*  684 */     if (this._seenNameCount >= 0) {
/*  685 */       int ix = _findSeenName(name.getValue());
/*  686 */       if (ix >= 0) {
/*  687 */         _writeSharedNameReference(ix);
/*  688 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  693 */     if (byteLen <= 64)
/*      */     {
/*  695 */       if (this._outputTail + byteLen >= this._outputEnd) {
/*  696 */         _flushBuffer();
/*      */       }
/*  698 */       this._outputBuffer[(this._outputTail++)] = ((byte)(127 + byteLen));
/*  699 */       System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, byteLen);
/*  700 */       this._outputTail += byteLen;
/*      */     } else {
/*  702 */       _writeLongAsciiFieldName(bytes);
/*      */     }
/*      */ 
/*  705 */     if (this._seenNameCount >= 0)
/*  706 */       _addSeenName(name.getValue());
/*      */   }
/*      */ 
/*      */   private final void _writeLongAsciiFieldName(byte[] bytes)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  713 */     int byteLen = bytes.length;
/*  714 */     if (this._outputTail >= this._outputEnd) {
/*  715 */       _flushBuffer();
/*      */     }
/*  717 */     this._outputBuffer[(this._outputTail++)] = 52;
/*      */ 
/*  719 */     if (this._outputTail + byteLen + 1 < this._outputEnd) {
/*  720 */       System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, byteLen);
/*  721 */       this._outputTail += byteLen;
/*      */     } else {
/*  723 */       _flushBuffer();
/*      */ 
/*  726 */       if (byteLen < 770) {
/*  727 */         System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, byteLen);
/*  728 */         this._outputTail += byteLen;
/*      */       }
/*      */       else {
/*  731 */         if (this._outputTail > 0) {
/*  732 */           _flushBuffer();
/*      */         }
/*  734 */         this._out.write(bytes, 0, byteLen);
/*      */       }
/*      */     }
/*  737 */     this._outputBuffer[(this._outputTail++)] = -4;
/*      */   }
/*      */ 
/*      */   protected final void _writeFieldNameUnicode(SerializableString name, byte[] bytes)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  744 */     if (this._seenNameCount >= 0) {
/*  745 */       int ix = _findSeenName(name.getValue());
/*  746 */       if (ix >= 0) {
/*  747 */         _writeSharedNameReference(ix);
/*  748 */         return;
/*      */       }
/*      */     }
/*      */ 
/*  752 */     int byteLen = bytes.length;
/*      */ 
/*  755 */     if (byteLen <= 56) {
/*  756 */       if (this._outputTail + byteLen >= this._outputEnd) {
/*  757 */         _flushBuffer();
/*      */       }
/*      */ 
/*  760 */       this._outputBuffer[(this._outputTail++)] = ((byte)(190 + byteLen));
/*      */ 
/*  762 */       System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, byteLen);
/*  763 */       this._outputTail += byteLen;
/*      */ 
/*  765 */       if (this._seenNameCount >= 0) {
/*  766 */         _addSeenName(name.getValue());
/*      */       }
/*  768 */       return;
/*      */     }
/*  770 */     if (this._outputTail >= this._outputEnd) {
/*  771 */       _flushBuffer();
/*      */     }
/*  773 */     this._outputBuffer[(this._outputTail++)] = 52;
/*      */ 
/*  775 */     if (this._outputTail + byteLen + 1 < this._outputEnd) {
/*  776 */       System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, byteLen);
/*  777 */       this._outputTail += byteLen;
/*      */     } else {
/*  779 */       _flushBuffer();
/*      */ 
/*  782 */       if (byteLen < 770) {
/*  783 */         System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, byteLen);
/*  784 */         this._outputTail += byteLen;
/*      */       }
/*      */       else {
/*  787 */         if (this._outputTail > 0) {
/*  788 */           _flushBuffer();
/*      */         }
/*  790 */         this._out.write(bytes, 0, byteLen);
/*      */       }
/*      */     }
/*  793 */     this._outputBuffer[(this._outputTail++)] = -4;
/*      */ 
/*  795 */     if (this._seenNameCount >= 0)
/*  796 */       _addSeenName(name.getValue());
/*      */   }
/*      */ 
/*      */   private final void _writeSharedNameReference(int ix)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  804 */     if (ix >= this._seenNameCount) {
/*  805 */       throw new IllegalArgumentException("Internal error: trying to write shared name with index " + ix + "; but have only seen " + this._seenNameCount + " so far!");
/*      */     }
/*      */ 
/*  808 */     if (ix < 64)
/*  809 */       _writeByte((byte)(64 + ix));
/*      */     else
/*  811 */       _writeBytes((byte)(48 + (ix >> 8)), (byte)ix);
/*      */   }
/*      */ 
/*      */   public void writeString(String text)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  824 */     if (text == null) {
/*  825 */       writeNull();
/*  826 */       return;
/*      */     }
/*  828 */     _verifyValueWrite("write String value");
/*  829 */     int len = text.length();
/*  830 */     if (len == 0) {
/*  831 */       _writeByte((byte)32);
/*  832 */       return;
/*      */     }
/*      */ 
/*  835 */     if (len > 65) {
/*  836 */       _writeNonSharedString(text, len);
/*  837 */       return;
/*      */     }
/*      */ 
/*  840 */     if (this._seenStringValueCount >= 0) {
/*  841 */       int ix = _findSeenStringValue(text);
/*  842 */       if (ix >= 0) {
/*  843 */         _writeSharedStringValueReference(ix);
/*  844 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  850 */     if (this._outputTail + 196 >= this._outputEnd) {
/*  851 */       _flushBuffer();
/*      */     }
/*      */ 
/*  854 */     text.getChars(0, len, this._charBuffer, 0);
/*  855 */     int origOffset = this._outputTail;
/*  856 */     this._outputTail += 1;
/*  857 */     int byteLen = _shortUTF8Encode(this._charBuffer, 0, len);
/*  858 */     if (byteLen <= 64)
/*      */     {
/*  860 */       if (this._seenStringValueCount >= 0) {
/*  861 */         _addSeenStringValue(text);
/*      */       }
/*  863 */       if (byteLen == len) {
/*  864 */         this._outputBuffer[origOffset] = ((byte)(63 + byteLen));
/*      */       }
/*      */       else
/*  867 */         this._outputBuffer[origOffset] = ((byte)(126 + byteLen));
/*      */     }
/*      */     else {
/*  870 */       this._outputBuffer[origOffset] = (byteLen == len ? -32 : -28);
/*      */ 
/*  872 */       this._outputBuffer[(this._outputTail++)] = -4;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _writeSharedStringValueReference(int ix)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  880 */     if (ix >= this._seenStringValueCount) {
/*  881 */       throw new IllegalArgumentException("Internal error: trying to write shared String value with index " + ix + "; but have only seen " + this._seenStringValueCount + " so far!");
/*      */     }
/*      */ 
/*  884 */     if (ix < 31)
/*  885 */       _writeByte((byte)(1 + ix));
/*      */     else
/*  887 */       _writeBytes((byte)(236 + (ix >> 8)), (byte)ix);
/*      */   }
/*      */ 
/*      */   private final void _writeNonSharedString(String text, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  899 */     if (len > this._charBufferLength) {
/*  900 */       _writeByte((byte)-28);
/*  901 */       _slowUTF8Encode(text);
/*  902 */       _writeByte((byte)-4);
/*  903 */       return;
/*      */     }
/*  905 */     text.getChars(0, len, this._charBuffer, 0);
/*      */ 
/*  907 */     int maxLen = len + len + len + 2;
/*      */ 
/*  909 */     if (maxLen > this._outputBuffer.length)
/*      */     {
/*  911 */       _writeByte((byte)-28);
/*  912 */       _mediumUTF8Encode(this._charBuffer, 0, len);
/*  913 */       _writeByte((byte)-4);
/*  914 */       return;
/*      */     }
/*      */ 
/*  917 */     if (this._outputTail + maxLen >= this._outputEnd) {
/*  918 */       _flushBuffer();
/*      */     }
/*  920 */     int origOffset = this._outputTail;
/*      */ 
/*  922 */     _writeByte((byte)-32);
/*  923 */     int byteLen = _shortUTF8Encode(this._charBuffer, 0, len);
/*      */ 
/*  925 */     if (byteLen > len) {
/*  926 */       this._outputBuffer[origOffset] = -28;
/*      */     }
/*  928 */     this._outputBuffer[(this._outputTail++)] = -4;
/*      */   }
/*      */ 
/*      */   public void writeString(char[] text, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  935 */     if ((len <= 65) && (this._seenStringValueCount >= 0) && (len > 0)) {
/*  936 */       writeString(new String(text, offset, len));
/*  937 */       return;
/*      */     }
/*  939 */     _verifyValueWrite("write String value");
/*  940 */     if (len == 0) {
/*  941 */       _writeByte((byte)32);
/*  942 */       return;
/*      */     }
/*  944 */     if (len <= 64)
/*      */     {
/*  946 */       if (this._outputTail + 196 >= this._outputEnd) {
/*  947 */         _flushBuffer();
/*      */       }
/*  949 */       int origOffset = this._outputTail;
/*  950 */       this._outputTail += 1;
/*  951 */       int byteLen = _shortUTF8Encode(text, offset, offset + len);
/*      */       byte typeToken;
/*      */       byte typeToken;
/*  953 */       if (byteLen <= 64)
/*      */       {
/*      */         byte typeToken;
/*  954 */         if (byteLen == len)
/*  955 */           typeToken = (byte)(63 + byteLen);
/*      */         else
/*  957 */           typeToken = (byte)(126 + byteLen);
/*      */       }
/*      */       else {
/*  960 */         typeToken = -28;
/*      */ 
/*  962 */         this._outputBuffer[(this._outputTail++)] = -4;
/*      */       }
/*      */ 
/*  965 */       this._outputBuffer[origOffset] = typeToken;
/*      */     }
/*      */     else {
/*  968 */       int maxLen = len + len + len + 2;
/*  969 */       if (maxLen <= this._outputBuffer.length) {
/*  970 */         if (this._outputTail + maxLen >= this._outputEnd) {
/*  971 */           _flushBuffer();
/*      */         }
/*  973 */         int origOffset = this._outputTail;
/*  974 */         _writeByte((byte)-28);
/*  975 */         int byteLen = _shortUTF8Encode(text, offset, offset + len);
/*      */ 
/*  977 */         if (byteLen == len) {
/*  978 */           this._outputBuffer[origOffset] = -32;
/*      */         }
/*  980 */         this._outputBuffer[(this._outputTail++)] = -4;
/*      */       } else {
/*  982 */         _writeByte((byte)-28);
/*  983 */         _mediumUTF8Encode(text, offset, offset + len);
/*  984 */         _writeByte((byte)-4);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void writeString(SerializableString sstr)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  993 */     _verifyValueWrite("write String value");
/*      */ 
/*  995 */     String str = sstr.getValue();
/*  996 */     int len = str.length();
/*  997 */     if (len == 0) {
/*  998 */       _writeByte((byte)32);
/*  999 */       return;
/*      */     }
/*      */ 
/* 1002 */     if ((len <= 65) && (this._seenStringValueCount >= 0)) {
/* 1003 */       int ix = _findSeenStringValue(str);
/* 1004 */       if (ix >= 0) {
/* 1005 */         _writeSharedStringValueReference(ix);
/* 1006 */         return;
/*      */       }
/*      */     }
/*      */ 
/* 1010 */     byte[] raw = sstr.asUnquotedUTF8();
/* 1011 */     int byteLen = raw.length;
/*      */ 
/* 1013 */     if (byteLen <= 64)
/*      */     {
/* 1015 */       if (this._outputTail + byteLen + 1 >= this._outputEnd) {
/* 1016 */         _flushBuffer();
/*      */       }
/*      */ 
/* 1019 */       int typeToken = byteLen == len ? 63 + byteLen : 126 + byteLen;
/*      */ 
/* 1023 */       this._outputBuffer[(this._outputTail++)] = ((byte)typeToken);
/* 1024 */       System.arraycopy(raw, 0, this._outputBuffer, this._outputTail, byteLen);
/* 1025 */       this._outputTail += byteLen;
/*      */ 
/* 1027 */       if (this._seenStringValueCount >= 0)
/* 1028 */         _addSeenStringValue(sstr.getValue());
/*      */     }
/*      */     else
/*      */     {
/* 1032 */       byte typeToken = byteLen == len ? -32 : -28;
/* 1033 */       _writeByte(typeToken);
/* 1034 */       _writeBytes(raw, 0, raw.length);
/* 1035 */       _writeByte((byte)-4);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeRawUTF8String(byte[] text, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1043 */     _verifyValueWrite("write String value");
/*      */ 
/* 1045 */     if (len == 0) {
/* 1046 */       _writeByte((byte)32);
/* 1047 */       return;
/*      */     }
/*      */ 
/* 1050 */     if (this._seenStringValueCount >= 0) {
/* 1051 */       throw new UnsupportedOperationException("Can not use direct UTF-8 write methods when 'Feature.CHECK_SHARED_STRING_VALUES' enabled");
/*      */     }
/*      */ 
/* 1057 */     if (len <= 65)
/*      */     {
/* 1059 */       if (this._outputTail + len >= this._outputEnd) {
/* 1060 */         _flushBuffer();
/*      */       }
/*      */ 
/* 1065 */       if (len == 1) {
/* 1066 */         this._outputBuffer[(this._outputTail++)] = 64;
/* 1067 */         this._outputBuffer[(this._outputTail++)] = text[offset];
/*      */       } else {
/* 1069 */         this._outputBuffer[(this._outputTail++)] = ((byte)(126 + len));
/* 1070 */         System.arraycopy(text, offset, this._outputBuffer, this._outputTail, len);
/* 1071 */         this._outputTail += len;
/*      */       }
/*      */     }
/*      */     else {
/* 1075 */       int maxLen = len + len + len + 2;
/* 1076 */       if (maxLen <= this._outputBuffer.length) {
/* 1077 */         if (this._outputTail + maxLen >= this._outputEnd) {
/* 1078 */           _flushBuffer();
/*      */         }
/* 1080 */         this._outputBuffer[(this._outputTail++)] = -28;
/* 1081 */         System.arraycopy(text, offset, this._outputBuffer, this._outputTail, len);
/* 1082 */         this._outputTail += len;
/* 1083 */         this._outputBuffer[(this._outputTail++)] = -4;
/*      */       } else {
/* 1085 */         _writeByte((byte)-28);
/* 1086 */         _writeBytes(text, offset, len);
/* 1087 */         _writeByte((byte)-4);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void writeUTF8String(byte[] text, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1097 */     writeRawUTF8String(text, offset, len);
/*      */   }
/*      */ 
/*      */   public void writeRaw(String text)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1108 */     throw _notSupported();
/*      */   }
/*      */ 
/*      */   public void writeRaw(String text, int offset, int len) throws IOException, JsonGenerationException
/*      */   {
/* 1113 */     throw _notSupported();
/*      */   }
/*      */ 
/*      */   public void writeRaw(char[] text, int offset, int len) throws IOException, JsonGenerationException
/*      */   {
/* 1118 */     throw _notSupported();
/*      */   }
/*      */ 
/*      */   public void writeRaw(char c) throws IOException, JsonGenerationException
/*      */   {
/* 1123 */     throw _notSupported();
/*      */   }
/*      */ 
/*      */   public void writeRawValue(String text) throws IOException, JsonGenerationException
/*      */   {
/* 1128 */     throw _notSupported();
/*      */   }
/*      */ 
/*      */   public void writeRawValue(String text, int offset, int len) throws IOException, JsonGenerationException
/*      */   {
/* 1133 */     throw _notSupported();
/*      */   }
/*      */ 
/*      */   public void writeRawValue(char[] text, int offset, int len) throws IOException, JsonGenerationException
/*      */   {
/* 1138 */     throw _notSupported();
/*      */   }
/*      */ 
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1150 */     if (data == null) {
/* 1151 */       writeNull();
/* 1152 */       return;
/*      */     }
/* 1154 */     _verifyValueWrite("write Binary value");
/* 1155 */     if (isEnabled(Feature.ENCODE_BINARY_AS_7BIT)) {
/* 1156 */       _writeByte((byte)-24);
/* 1157 */       _write7BitBinaryWithLength(data, offset, len);
/*      */     } else {
/* 1159 */       _writeByte((byte)-3);
/* 1160 */       _writePositiveVInt(len);
/*      */ 
/* 1162 */       _writeBytes(data, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeBoolean(boolean state)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1175 */     _verifyValueWrite("write boolean value");
/* 1176 */     if (state)
/* 1177 */       _writeByte((byte)35);
/*      */     else
/* 1179 */       _writeByte((byte)34);
/*      */   }
/*      */ 
/*      */   public void writeNull()
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1186 */     _verifyValueWrite("write null value");
/* 1187 */     _writeByte((byte)33);
/*      */   }
/*      */ 
/*      */   public void writeNumber(int i)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1193 */     _verifyValueWrite("write number");
/*      */ 
/* 1195 */     i = SmileUtil.zigzagEncode(i);
/*      */ 
/* 1197 */     if ((i <= 63) && (i >= 0)) {
/* 1198 */       if (i <= 31) {
/* 1199 */         _writeByte((byte)(192 + i));
/* 1200 */         return;
/*      */       }
/*      */ 
/* 1203 */       _writeBytes((byte)36, (byte)(128 + i));
/* 1204 */       return;
/*      */     }
/*      */ 
/* 1207 */     byte b0 = (byte)(128 + (i & 0x3F));
/* 1208 */     i >>>= 6;
/* 1209 */     if (i <= 127) {
/* 1210 */       _writeBytes((byte)36, (byte)i, b0);
/* 1211 */       return;
/*      */     }
/* 1213 */     byte b1 = (byte)(i & 0x7F);
/* 1214 */     i >>= 7;
/* 1215 */     if (i <= 127) {
/* 1216 */       _writeBytes((byte)36, (byte)i, b1, b0);
/* 1217 */       return;
/*      */     }
/* 1219 */     byte b2 = (byte)(i & 0x7F);
/* 1220 */     i >>= 7;
/* 1221 */     if (i <= 127) {
/* 1222 */       _writeBytes((byte)36, (byte)i, b2, b1, b0);
/* 1223 */       return;
/*      */     }
/*      */ 
/* 1226 */     byte b3 = (byte)(i & 0x7F);
/* 1227 */     _writeBytes((byte)36, (byte)(i >> 7), b3, b2, b1, b0);
/*      */   }
/*      */ 
/*      */   public void writeNumber(long l)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1234 */     if ((l <= 2147483647L) && (l >= -2147483648L)) {
/* 1235 */       writeNumber((int)l);
/* 1236 */       return;
/*      */     }
/* 1238 */     _verifyValueWrite("write number");
/*      */ 
/* 1241 */     l = SmileUtil.zigzagEncode(l);
/*      */ 
/* 1243 */     int i = (int)l;
/*      */ 
/* 1245 */     byte b0 = (byte)(128 + (i & 0x3F));
/* 1246 */     byte b1 = (byte)(i >> 6 & 0x7F);
/* 1247 */     byte b2 = (byte)(i >> 13 & 0x7F);
/* 1248 */     byte b3 = (byte)(i >> 20 & 0x7F);
/*      */ 
/* 1250 */     l >>>= 27;
/* 1251 */     byte b4 = (byte)((int)l & 0x7F);
/*      */ 
/* 1254 */     i = (int)(l >> 7);
/* 1255 */     if (i == 0) {
/* 1256 */       _writeBytes((byte)37, b4, b3, b2, b1, b0);
/* 1257 */       return;
/*      */     }
/*      */ 
/* 1260 */     if (i <= 127) {
/* 1261 */       _writeBytes((byte)37, (byte)i);
/* 1262 */       _writeBytes(b4, b3, b2, b1, b0);
/* 1263 */       return;
/*      */     }
/* 1265 */     byte b5 = (byte)(i & 0x7F);
/* 1266 */     i >>= 7;
/* 1267 */     if (i <= 127) {
/* 1268 */       _writeBytes((byte)37, (byte)i);
/* 1269 */       _writeBytes(b5, b4, b3, b2, b1, b0);
/* 1270 */       return;
/*      */     }
/* 1272 */     byte b6 = (byte)(i & 0x7F);
/* 1273 */     i >>= 7;
/* 1274 */     if (i <= 127) {
/* 1275 */       _writeBytes((byte)37, (byte)i, b6);
/* 1276 */       _writeBytes(b5, b4, b3, b2, b1, b0);
/* 1277 */       return;
/*      */     }
/* 1279 */     byte b7 = (byte)(i & 0x7F);
/* 1280 */     i >>= 7;
/* 1281 */     if (i <= 127) {
/* 1282 */       _writeBytes((byte)37, (byte)i, b7, b6);
/* 1283 */       _writeBytes(b5, b4, b3, b2, b1, b0);
/* 1284 */       return;
/*      */     }
/* 1286 */     byte b8 = (byte)(i & 0x7F);
/* 1287 */     i >>= 7;
/*      */ 
/* 1289 */     _writeBytes((byte)37, (byte)i, b8, b7, b6);
/* 1290 */     _writeBytes(b5, b4, b3, b2, b1, b0);
/*      */   }
/*      */ 
/*      */   public void writeNumber(BigInteger v)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1296 */     if (v == null) {
/* 1297 */       writeNull();
/* 1298 */       return;
/*      */     }
/* 1300 */     _verifyValueWrite("write number");
/*      */ 
/* 1302 */     _writeByte((byte)38);
/* 1303 */     byte[] data = v.toByteArray();
/* 1304 */     _write7BitBinaryWithLength(data, 0, data.length);
/*      */   }
/*      */ 
/*      */   public void writeNumber(double d)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1311 */     _ensureRoomForOutput(11);
/* 1312 */     _verifyValueWrite("write number");
/*      */ 
/* 1318 */     long l = Double.doubleToRawLongBits(d);
/* 1319 */     this._outputBuffer[(this._outputTail++)] = 41;
/*      */ 
/* 1321 */     int hi5 = (int)(l >>> 35);
/* 1322 */     this._outputBuffer[(this._outputTail + 4)] = ((byte)(hi5 & 0x7F));
/* 1323 */     hi5 >>= 7;
/* 1324 */     this._outputBuffer[(this._outputTail + 3)] = ((byte)(hi5 & 0x7F));
/* 1325 */     hi5 >>= 7;
/* 1326 */     this._outputBuffer[(this._outputTail + 2)] = ((byte)(hi5 & 0x7F));
/* 1327 */     hi5 >>= 7;
/* 1328 */     this._outputBuffer[(this._outputTail + 1)] = ((byte)(hi5 & 0x7F));
/* 1329 */     hi5 >>= 7;
/* 1330 */     this._outputBuffer[this._outputTail] = ((byte)hi5);
/* 1331 */     this._outputTail += 5;
/*      */ 
/* 1334 */     int mid = (int)(l >> 28);
/* 1335 */     this._outputBuffer[(this._outputTail++)] = ((byte)(mid & 0x7F));
/*      */ 
/* 1338 */     int lo4 = (int)l;
/* 1339 */     this._outputBuffer[(this._outputTail + 3)] = ((byte)(lo4 & 0x7F));
/* 1340 */     lo4 >>= 7;
/* 1341 */     this._outputBuffer[(this._outputTail + 2)] = ((byte)(lo4 & 0x7F));
/* 1342 */     lo4 >>= 7;
/* 1343 */     this._outputBuffer[(this._outputTail + 1)] = ((byte)(lo4 & 0x7F));
/* 1344 */     lo4 >>= 7;
/* 1345 */     this._outputBuffer[this._outputTail] = ((byte)(lo4 & 0x7F));
/* 1346 */     this._outputTail += 4;
/*      */   }
/*      */ 
/*      */   public void writeNumber(float f)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1353 */     _ensureRoomForOutput(6);
/* 1354 */     _verifyValueWrite("write number");
/*      */ 
/* 1361 */     int i = Float.floatToRawIntBits(f);
/* 1362 */     this._outputBuffer[(this._outputTail++)] = 40;
/* 1363 */     this._outputBuffer[(this._outputTail + 4)] = ((byte)(i & 0x7F));
/* 1364 */     i >>= 7;
/* 1365 */     this._outputBuffer[(this._outputTail + 3)] = ((byte)(i & 0x7F));
/* 1366 */     i >>= 7;
/* 1367 */     this._outputBuffer[(this._outputTail + 2)] = ((byte)(i & 0x7F));
/* 1368 */     i >>= 7;
/* 1369 */     this._outputBuffer[(this._outputTail + 1)] = ((byte)(i & 0x7F));
/* 1370 */     i >>= 7;
/* 1371 */     this._outputBuffer[this._outputTail] = ((byte)(i & 0x7F));
/* 1372 */     this._outputTail += 5;
/*      */   }
/*      */ 
/*      */   public void writeNumber(BigDecimal dec)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1378 */     if (dec == null) {
/* 1379 */       writeNull();
/* 1380 */       return;
/*      */     }
/* 1382 */     _verifyValueWrite("write number");
/* 1383 */     _writeByte((byte)42);
/* 1384 */     int scale = dec.scale();
/*      */ 
/* 1386 */     _writeSignedVInt(scale);
/* 1387 */     BigInteger unscaled = dec.unscaledValue();
/* 1388 */     byte[] data = unscaled.toByteArray();
/*      */ 
/* 1390 */     _write7BitBinaryWithLength(data, 0, data.length);
/*      */   }
/*      */ 
/*      */   public void writeNumber(String encodedValue)
/*      */     throws IOException, JsonGenerationException, UnsupportedOperationException
/*      */   {
/* 1399 */     throw _notSupported();
/*      */   }
/*      */ 
/*      */   protected final void _verifyValueWrite(String typeMsg)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1412 */     int status = this._writeContext.writeValue();
/* 1413 */     if (status == 5)
/* 1414 */       _reportError("Can not " + typeMsg + ", expecting field name");
/*      */   }
/*      */ 
/*      */   public final void flush()
/*      */     throws IOException
/*      */   {
/* 1427 */     _flushBuffer();
/* 1428 */     if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM))
/* 1429 */       this._out.flush();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/* 1440 */     if ((this._outputBuffer != null) && (isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT))) {
/*      */       while (true)
/*      */       {
/* 1443 */         JsonStreamContext ctxt = getOutputContext();
/* 1444 */         if (ctxt.inArray()) {
/* 1445 */           writeEndArray(); } else {
/* 1446 */           if (!ctxt.inObject()) break;
/* 1447 */           writeEndObject();
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1453 */     boolean wasClosed = this._closed;
/* 1454 */     super.close();
/*      */ 
/* 1456 */     if ((!wasClosed) && (isEnabled(Feature.WRITE_END_MARKER))) {
/* 1457 */       _writeByte((byte)-1);
/*      */     }
/* 1459 */     _flushBuffer();
/*      */ 
/* 1461 */     if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET))) {
/* 1462 */       this._out.close();
/*      */     }
/*      */     else {
/* 1465 */       this._out.flush();
/*      */     }
/*      */ 
/* 1468 */     _releaseBuffers();
/*      */   }
/*      */ 
/*      */   private final int _shortUTF8Encode(char[] str, int i, int end)
/*      */   {
/* 1484 */     int ptr = this._outputTail;
/* 1485 */     byte[] outBuf = this._outputBuffer;
/*      */     do {
/* 1487 */       int c = str[i];
/* 1488 */       if (c > 127) {
/* 1489 */         return _shortUTF8Encode2(str, i, end, ptr);
/*      */       }
/* 1491 */       outBuf[(ptr++)] = ((byte)c);
/* 1492 */       i++; } while (i < end);
/* 1493 */     int codedLen = ptr - this._outputTail;
/* 1494 */     this._outputTail = ptr;
/* 1495 */     return codedLen;
/*      */   }
/*      */ 
/*      */   private final int _shortUTF8Encode2(char[] str, int i, int end, int outputPtr)
/*      */   {
/* 1505 */     byte[] outBuf = this._outputBuffer;
/* 1506 */     while (i < end) {
/* 1507 */       int c = str[(i++)];
/* 1508 */       if (c <= 127) {
/* 1509 */         outBuf[(outputPtr++)] = ((byte)c);
/*      */       }
/* 1513 */       else if (c < 2048) {
/* 1514 */         outBuf[(outputPtr++)] = ((byte)(0xC0 | c >> 6));
/* 1515 */         outBuf[(outputPtr++)] = ((byte)(0x80 | c & 0x3F));
/*      */       }
/* 1520 */       else if ((c < 55296) || (c > 57343)) {
/* 1521 */         outBuf[(outputPtr++)] = ((byte)(0xE0 | c >> 12));
/* 1522 */         outBuf[(outputPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 1523 */         outBuf[(outputPtr++)] = ((byte)(0x80 | c & 0x3F));
/*      */       }
/*      */       else
/*      */       {
/* 1527 */         if (c > 56319) {
/* 1528 */           _throwIllegalSurrogate(c);
/*      */         }
/*      */ 
/* 1531 */         if (i >= end) {
/* 1532 */           _throwIllegalSurrogate(c);
/*      */         }
/* 1534 */         c = _convertSurrogate(c, str[(i++)]);
/* 1535 */         if (c > 1114111) {
/* 1536 */           _throwIllegalSurrogate(c);
/*      */         }
/* 1538 */         outBuf[(outputPtr++)] = ((byte)(0xF0 | c >> 18));
/* 1539 */         outBuf[(outputPtr++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 1540 */         outBuf[(outputPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 1541 */         outBuf[(outputPtr++)] = ((byte)(0x80 | c & 0x3F));
/*      */       }
/*      */     }
/* 1543 */     int codedLen = outputPtr - this._outputTail;
/* 1544 */     this._outputTail = outputPtr;
/* 1545 */     return codedLen;
/*      */   }
/*      */ 
/*      */   private void _slowUTF8Encode(String str) throws IOException
/*      */   {
/* 1550 */     int len = str.length();
/* 1551 */     int inputPtr = 0;
/* 1552 */     int bufferEnd = this._outputEnd - 4;
/*      */ 
/* 1555 */     while (inputPtr < len)
/*      */     {
/* 1559 */       if (this._outputTail >= bufferEnd) {
/* 1560 */         _flushBuffer();
/*      */       }
/* 1562 */       int c = str.charAt(inputPtr++);
/*      */ 
/* 1564 */       if (c <= 127) {
/* 1565 */         this._outputBuffer[(this._outputTail++)] = ((byte)c);
/*      */ 
/* 1567 */         int maxInCount = len - inputPtr;
/* 1568 */         int maxOutCount = bufferEnd - this._outputTail;
/*      */ 
/* 1570 */         if (maxInCount > maxOutCount) {
/* 1571 */           maxInCount = maxOutCount;
/*      */         }
/* 1573 */         maxInCount += inputPtr;
/*      */ 
/* 1576 */         while (inputPtr < maxInCount)
/*      */         {
/* 1579 */           c = str.charAt(inputPtr++);
/* 1580 */           if (c > 127) {
/*      */             break label151;
/*      */           }
/* 1583 */           this._outputBuffer[(this._outputTail++)] = ((byte)c);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1588 */         label151: if (c < 2048) {
/* 1589 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0xC0 | c >> 6));
/* 1590 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c & 0x3F));
/*      */         }
/* 1593 */         else if ((c < 55296) || (c > 57343)) {
/* 1594 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0xE0 | c >> 12));
/* 1595 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 1596 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c & 0x3F));
/*      */         }
/*      */         else
/*      */         {
/* 1600 */           if (c > 56319) {
/* 1601 */             _throwIllegalSurrogate(c);
/*      */           }
/*      */ 
/* 1604 */           if (inputPtr >= len) {
/* 1605 */             _throwIllegalSurrogate(c);
/*      */           }
/* 1607 */           c = _convertSurrogate(c, str.charAt(inputPtr++));
/* 1608 */           if (c > 1114111) {
/* 1609 */             _throwIllegalSurrogate(c);
/*      */           }
/* 1611 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0xF0 | c >> 18));
/* 1612 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 1613 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 1614 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c & 0x3F));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void _mediumUTF8Encode(char[] str, int inputPtr, int inputEnd) throws IOException {
/* 1621 */     int bufferEnd = this._outputEnd - 4;
/*      */ 
/* 1624 */     while (inputPtr < inputEnd)
/*      */     {
/* 1628 */       if (this._outputTail >= bufferEnd) {
/* 1629 */         _flushBuffer();
/*      */       }
/* 1631 */       int c = str[(inputPtr++)];
/*      */ 
/* 1633 */       if (c <= 127) {
/* 1634 */         this._outputBuffer[(this._outputTail++)] = ((byte)c);
/*      */ 
/* 1636 */         int maxInCount = inputEnd - inputPtr;
/* 1637 */         int maxOutCount = bufferEnd - this._outputTail;
/*      */ 
/* 1639 */         if (maxInCount > maxOutCount) {
/* 1640 */           maxInCount = maxOutCount;
/*      */         }
/* 1642 */         maxInCount += inputPtr;
/*      */ 
/* 1645 */         while (inputPtr < maxInCount)
/*      */         {
/* 1648 */           c = str[(inputPtr++)];
/* 1649 */           if (c > 127) {
/*      */             break label140;
/*      */           }
/* 1652 */           this._outputBuffer[(this._outputTail++)] = ((byte)c);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1657 */         label140: if (c < 2048) {
/* 1658 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0xC0 | c >> 6));
/* 1659 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c & 0x3F));
/*      */         }
/* 1662 */         else if ((c < 55296) || (c > 57343)) {
/* 1663 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0xE0 | c >> 12));
/* 1664 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 1665 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c & 0x3F));
/*      */         }
/*      */         else
/*      */         {
/* 1669 */           if (c > 56319) {
/* 1670 */             _throwIllegalSurrogate(c);
/*      */           }
/*      */ 
/* 1673 */           if (inputPtr >= inputEnd) {
/* 1674 */             _throwIllegalSurrogate(c);
/*      */           }
/* 1676 */           c = _convertSurrogate(c, str[(inputPtr++)]);
/* 1677 */           if (c > 1114111) {
/* 1678 */             _throwIllegalSurrogate(c);
/*      */           }
/* 1680 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0xF0 | c >> 18));
/* 1681 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 1682 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 1683 */           this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | c & 0x3F));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private int _convertSurrogate(int firstPart, int secondPart)
/*      */   {
/* 1694 */     if ((secondPart < 56320) || (secondPart > 57343)) {
/* 1695 */       throw new IllegalArgumentException("Broken surrogate pair: first char 0x" + Integer.toHexString(firstPart) + ", second 0x" + Integer.toHexString(secondPart) + "; illegal combination");
/*      */     }
/* 1697 */     return 65536 + (firstPart - 55296 << 10) + (secondPart - 56320);
/*      */   }
/*      */ 
/*      */   private void _throwIllegalSurrogate(int code)
/*      */   {
/* 1702 */     if (code > 1114111) {
/* 1703 */       throw new IllegalArgumentException("Illegal character point (0x" + Integer.toHexString(code) + ") to output; max is 0x10FFFF as per RFC 4627");
/*      */     }
/* 1705 */     if (code >= 55296) {
/* 1706 */       if (code <= 56319) {
/* 1707 */         throw new IllegalArgumentException("Unmatched first part of surrogate pair (0x" + Integer.toHexString(code) + ")");
/*      */       }
/* 1709 */       throw new IllegalArgumentException("Unmatched second part of surrogate pair (0x" + Integer.toHexString(code) + ")");
/*      */     }
/*      */ 
/* 1712 */     throw new IllegalArgumentException("Illegal character point (0x" + Integer.toHexString(code) + ") to output");
/*      */   }
/*      */ 
/*      */   private final void _ensureRoomForOutput(int needed)
/*      */     throws IOException
/*      */   {
/* 1723 */     if (this._outputTail + needed >= this._outputEnd)
/* 1724 */       _flushBuffer();
/*      */   }
/*      */ 
/*      */   private final void _writeByte(byte b)
/*      */     throws IOException
/*      */   {
/* 1730 */     if (this._outputTail >= this._outputEnd) {
/* 1731 */       _flushBuffer();
/*      */     }
/* 1733 */     this._outputBuffer[(this._outputTail++)] = b;
/*      */   }
/*      */ 
/*      */   private final void _writeBytes(byte b1, byte b2) throws IOException
/*      */   {
/* 1738 */     if (this._outputTail + 1 >= this._outputEnd) {
/* 1739 */       _flushBuffer();
/*      */     }
/* 1741 */     this._outputBuffer[(this._outputTail++)] = b1;
/* 1742 */     this._outputBuffer[(this._outputTail++)] = b2;
/*      */   }
/*      */ 
/*      */   private final void _writeBytes(byte b1, byte b2, byte b3) throws IOException
/*      */   {
/* 1747 */     if (this._outputTail + 2 >= this._outputEnd) {
/* 1748 */       _flushBuffer();
/*      */     }
/* 1750 */     this._outputBuffer[(this._outputTail++)] = b1;
/* 1751 */     this._outputBuffer[(this._outputTail++)] = b2;
/* 1752 */     this._outputBuffer[(this._outputTail++)] = b3;
/*      */   }
/*      */ 
/*      */   private final void _writeBytes(byte b1, byte b2, byte b3, byte b4) throws IOException
/*      */   {
/* 1757 */     if (this._outputTail + 3 >= this._outputEnd) {
/* 1758 */       _flushBuffer();
/*      */     }
/* 1760 */     this._outputBuffer[(this._outputTail++)] = b1;
/* 1761 */     this._outputBuffer[(this._outputTail++)] = b2;
/* 1762 */     this._outputBuffer[(this._outputTail++)] = b3;
/* 1763 */     this._outputBuffer[(this._outputTail++)] = b4;
/*      */   }
/*      */ 
/*      */   private final void _writeBytes(byte b1, byte b2, byte b3, byte b4, byte b5) throws IOException
/*      */   {
/* 1768 */     if (this._outputTail + 4 >= this._outputEnd) {
/* 1769 */       _flushBuffer();
/*      */     }
/* 1771 */     this._outputBuffer[(this._outputTail++)] = b1;
/* 1772 */     this._outputBuffer[(this._outputTail++)] = b2;
/* 1773 */     this._outputBuffer[(this._outputTail++)] = b3;
/* 1774 */     this._outputBuffer[(this._outputTail++)] = b4;
/* 1775 */     this._outputBuffer[(this._outputTail++)] = b5;
/*      */   }
/*      */ 
/*      */   private final void _writeBytes(byte b1, byte b2, byte b3, byte b4, byte b5, byte b6) throws IOException
/*      */   {
/* 1780 */     if (this._outputTail + 5 >= this._outputEnd) {
/* 1781 */       _flushBuffer();
/*      */     }
/* 1783 */     this._outputBuffer[(this._outputTail++)] = b1;
/* 1784 */     this._outputBuffer[(this._outputTail++)] = b2;
/* 1785 */     this._outputBuffer[(this._outputTail++)] = b3;
/* 1786 */     this._outputBuffer[(this._outputTail++)] = b4;
/* 1787 */     this._outputBuffer[(this._outputTail++)] = b5;
/* 1788 */     this._outputBuffer[(this._outputTail++)] = b6;
/*      */   }
/*      */ 
/*      */   private final void _writeBytes(byte[] data, int offset, int len) throws IOException
/*      */   {
/* 1793 */     if (len == 0) {
/* 1794 */       return;
/*      */     }
/* 1796 */     if (this._outputTail + len >= this._outputEnd) {
/* 1797 */       _writeBytesLong(data, offset, len);
/* 1798 */       return;
/*      */     }
/*      */ 
/* 1801 */     System.arraycopy(data, offset, this._outputBuffer, this._outputTail, len);
/* 1802 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   private final void _writeBytesLong(byte[] data, int offset, int len) throws IOException
/*      */   {
/* 1807 */     if (this._outputTail >= this._outputEnd)
/* 1808 */       _flushBuffer();
/*      */     while (true)
/*      */     {
/* 1811 */       int currLen = Math.min(len, this._outputEnd - this._outputTail);
/* 1812 */       System.arraycopy(data, offset, this._outputBuffer, this._outputTail, currLen);
/* 1813 */       this._outputTail += currLen;
/* 1814 */       if (len -= currLen == 0) {
/*      */         break;
/*      */       }
/* 1817 */       offset += currLen;
/* 1818 */       _flushBuffer();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void _writePositiveVInt(int i)
/*      */     throws IOException
/*      */   {
/* 1829 */     _ensureRoomForOutput(5);
/* 1830 */     byte b0 = (byte)(128 + (i & 0x3F));
/* 1831 */     i >>= 6;
/* 1832 */     if (i <= 127) {
/* 1833 */       if (i > 0) {
/* 1834 */         this._outputBuffer[(this._outputTail++)] = ((byte)i);
/*      */       }
/* 1836 */       this._outputBuffer[(this._outputTail++)] = b0;
/* 1837 */       return;
/*      */     }
/* 1839 */     byte b1 = (byte)(i & 0x7F);
/* 1840 */     i >>= 7;
/* 1841 */     if (i <= 127) {
/* 1842 */       this._outputBuffer[(this._outputTail++)] = ((byte)i);
/* 1843 */       this._outputBuffer[(this._outputTail++)] = b1;
/* 1844 */       this._outputBuffer[(this._outputTail++)] = b0;
/*      */     } else {
/* 1846 */       byte b2 = (byte)(i & 0x7F);
/* 1847 */       i >>= 7;
/* 1848 */       if (i <= 127) {
/* 1849 */         this._outputBuffer[(this._outputTail++)] = ((byte)i);
/* 1850 */         this._outputBuffer[(this._outputTail++)] = b2;
/* 1851 */         this._outputBuffer[(this._outputTail++)] = b1;
/* 1852 */         this._outputBuffer[(this._outputTail++)] = b0;
/*      */       } else {
/* 1854 */         byte b3 = (byte)(i & 0x7F);
/* 1855 */         this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 7));
/* 1856 */         this._outputBuffer[(this._outputTail++)] = b3;
/* 1857 */         this._outputBuffer[(this._outputTail++)] = b2;
/* 1858 */         this._outputBuffer[(this._outputTail++)] = b1;
/* 1859 */         this._outputBuffer[(this._outputTail++)] = b0;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void _writeSignedVInt(int input)
/*      */     throws IOException
/*      */   {
/* 1872 */     _writePositiveVInt(SmileUtil.zigzagEncode(input));
/*      */   }
/*      */ 
/*      */   protected void _write7BitBinaryWithLength(byte[] data, int offset, int len) throws IOException
/*      */   {
/* 1877 */     _writePositiveVInt(len);
/*      */ 
/* 1879 */     while (len >= 7) {
/* 1880 */       if (this._outputTail + 8 >= this._outputEnd) {
/* 1881 */         _flushBuffer();
/*      */       }
/* 1883 */       int i = data[(offset++)];
/* 1884 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 1 & 0x7F));
/* 1885 */       i = i << 8 | data[(offset++)] & 0xFF;
/* 1886 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 2 & 0x7F));
/* 1887 */       i = i << 8 | data[(offset++)] & 0xFF;
/* 1888 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 3 & 0x7F));
/* 1889 */       i = i << 8 | data[(offset++)] & 0xFF;
/* 1890 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 4 & 0x7F));
/* 1891 */       i = i << 8 | data[(offset++)] & 0xFF;
/* 1892 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 5 & 0x7F));
/* 1893 */       i = i << 8 | data[(offset++)] & 0xFF;
/* 1894 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 6 & 0x7F));
/* 1895 */       i = i << 8 | data[(offset++)] & 0xFF;
/* 1896 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 7 & 0x7F));
/* 1897 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i & 0x7F));
/* 1898 */       len -= 7;
/*      */     }
/*      */ 
/* 1901 */     if (len > 0)
/*      */     {
/* 1903 */       if (this._outputTail + 7 >= this._outputEnd) {
/* 1904 */         _flushBuffer();
/*      */       }
/* 1906 */       int i = data[(offset++)];
/* 1907 */       this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 1 & 0x7F));
/* 1908 */       if (len > 1) {
/* 1909 */         i = (i & 0x1) << 8 | data[(offset++)] & 0xFF;
/* 1910 */         this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 2 & 0x7F));
/* 1911 */         if (len > 2) {
/* 1912 */           i = (i & 0x3) << 8 | data[(offset++)] & 0xFF;
/* 1913 */           this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 3 & 0x7F));
/* 1914 */           if (len > 3) {
/* 1915 */             i = (i & 0x7) << 8 | data[(offset++)] & 0xFF;
/* 1916 */             this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 4 & 0x7F));
/* 1917 */             if (len > 4) {
/* 1918 */               i = (i & 0xF) << 8 | data[(offset++)] & 0xFF;
/* 1919 */               this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 5 & 0x7F));
/* 1920 */               if (len > 5) {
/* 1921 */                 i = (i & 0x1F) << 8 | data[(offset++)] & 0xFF;
/* 1922 */                 this._outputBuffer[(this._outputTail++)] = ((byte)(i >> 6 & 0x7F));
/* 1923 */                 this._outputBuffer[(this._outputTail++)] = ((byte)(i & 0x3F));
/*      */               } else {
/* 1925 */                 this._outputBuffer[(this._outputTail++)] = ((byte)(i & 0x1F));
/*      */               }
/*      */             } else {
/* 1928 */               this._outputBuffer[(this._outputTail++)] = ((byte)(i & 0xF));
/*      */             }
/*      */           } else {
/* 1931 */             this._outputBuffer[(this._outputTail++)] = ((byte)(i & 0x7));
/*      */           }
/*      */         } else {
/* 1934 */           this._outputBuffer[(this._outputTail++)] = ((byte)(i & 0x3));
/*      */         }
/*      */       } else {
/* 1937 */         this._outputBuffer[(this._outputTail++)] = ((byte)(i & 0x1));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */   {
/* 1951 */     byte[] buf = this._outputBuffer;
/* 1952 */     if ((buf != null) && (this._bufferRecyclable)) {
/* 1953 */       this._outputBuffer = null;
/* 1954 */       this._ioContext.releaseWriteEncodingBuffer(buf);
/*      */     }
/* 1956 */     char[] cbuf = this._charBuffer;
/* 1957 */     if (cbuf != null) {
/* 1958 */       this._charBuffer = null;
/* 1959 */       this._ioContext.releaseConcatBuffer(cbuf);
/*      */     }
/*      */ 
/* 1965 */     SharedStringNode[] nameBuf = this._seenNames;
/* 1966 */     if ((nameBuf != null) && (nameBuf.length == 64)) {
/* 1967 */       this._seenNames = null;
/*      */ 
/* 1971 */       if (this._seenNameCount > 0) {
/* 1972 */         Arrays.fill(nameBuf, null);
/*      */       }
/* 1974 */       this._smileBufferRecycler.releaseSeenNamesBuffer(nameBuf);
/*      */     }
/*      */ 
/* 1978 */     SharedStringNode[] valueBuf = this._seenStringValues;
/* 1979 */     if ((valueBuf != null) && (valueBuf.length == 64)) {
/* 1980 */       this._seenStringValues = null;
/*      */ 
/* 1984 */       if (this._seenStringValueCount > 0) {
/* 1985 */         Arrays.fill(valueBuf, null);
/*      */       }
/* 1987 */       this._smileBufferRecycler.releaseSeenStringValuesBuffer(valueBuf);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void _flushBuffer()
/*      */     throws IOException
/*      */   {
/* 1994 */     if (this._outputTail > 0) {
/* 1995 */       this._bytesWritten += this._outputTail;
/* 1996 */       this._out.write(this._outputBuffer, 0, this._outputTail);
/* 1997 */       this._outputTail = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final int _findSeenName(String name)
/*      */   {
/* 2009 */     int hash = name.hashCode();
/* 2010 */     SharedStringNode head = this._seenNames[(hash & this._seenNames.length - 1)];
/* 2011 */     if (head == null) {
/* 2012 */       return -1;
/*      */     }
/* 2014 */     SharedStringNode node = head;
/*      */ 
/* 2017 */     if (node.value == name) {
/* 2018 */       return node.index;
/*      */     }
/* 2020 */     while ((node = node.next) != null) {
/* 2021 */       if (node.value == name) {
/* 2022 */         return node.index;
/*      */       }
/*      */     }
/*      */ 
/* 2026 */     node = head;
/*      */     do {
/* 2028 */       String value = node.value;
/* 2029 */       if ((value.hashCode() == hash) && (value.equals(name))) {
/* 2030 */         return node.index;
/*      */       }
/* 2032 */       node = node.next;
/* 2033 */     }while (node != null);
/* 2034 */     return -1;
/*      */   }
/*      */ 
/*      */   private final void _addSeenName(String name)
/*      */   {
/* 2040 */     if (this._seenNameCount == this._seenNames.length) {
/* 2041 */       if (this._seenNameCount == 1024) {
/* 2042 */         Arrays.fill(this._seenNames, null);
/* 2043 */         this._seenNameCount = 0;
/*      */       } else {
/* 2045 */         SharedStringNode[] old = this._seenNames;
/* 2046 */         this._seenNames = new SharedStringNode[1024];
/* 2047 */         int mask = 1023;
/* 2048 */         SharedStringNode[] arr$ = old; int len$ = arr$.length; for (int i$ = 0; i$ < len$; i$++) for (SharedStringNode node = arr$[i$]; 
/* 2049 */             node != null; node = node.next) {
/* 2050 */             int ix = node.value.hashCode() & 0x3FF;
/* 2051 */             node.next = this._seenNames[ix];
/* 2052 */             this._seenNames[ix] = node;
/*      */           }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2058 */     int ix = name.hashCode() & this._seenNames.length - 1;
/* 2059 */     this._seenNames[ix] = new SharedStringNode(name, this._seenNameCount, this._seenNames[ix]);
/* 2060 */     this._seenNameCount += 1;
/*      */   }
/*      */ 
/*      */   private final int _findSeenStringValue(String text)
/*      */   {
/* 2065 */     int hash = text.hashCode();
/* 2066 */     SharedStringNode head = this._seenStringValues[(hash & this._seenStringValues.length - 1)];
/* 2067 */     if (head != null) {
/* 2068 */       SharedStringNode node = head;
/*      */       do
/*      */       {
/* 2071 */         if (node.value == text) {
/* 2072 */           return node.index;
/*      */         }
/* 2074 */         node = node.next;
/* 2075 */       }while (node != null);
/*      */ 
/* 2077 */       node = head;
/*      */       do {
/* 2079 */         String value = node.value;
/* 2080 */         if ((value.hashCode() == hash) && (value.equals(text))) {
/* 2081 */           return node.index;
/*      */         }
/* 2083 */         node = node.next;
/* 2084 */       }while (node != null);
/*      */     }
/* 2086 */     return -1;
/*      */   }
/*      */ 
/*      */   private final void _addSeenStringValue(String text)
/*      */   {
/* 2092 */     if (this._seenStringValueCount == this._seenStringValues.length) {
/* 2093 */       if (this._seenStringValueCount == 1024) {
/* 2094 */         Arrays.fill(this._seenStringValues, null);
/* 2095 */         this._seenStringValueCount = 0;
/*      */       } else {
/* 2097 */         SharedStringNode[] old = this._seenStringValues;
/* 2098 */         this._seenStringValues = new SharedStringNode[1024];
/* 2099 */         int mask = 1023;
/* 2100 */         SharedStringNode[] arr$ = old; int len$ = arr$.length; for (int i$ = 0; i$ < len$; i$++) for (SharedStringNode node = arr$[i$]; 
/* 2101 */             node != null; node = node.next) {
/* 2102 */             int ix = node.value.hashCode() & 0x3FF;
/* 2103 */             node.next = this._seenStringValues[ix];
/* 2104 */             this._seenStringValues[ix] = node;
/*      */           }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2110 */     int ix = text.hashCode() & this._seenStringValues.length - 1;
/* 2111 */     this._seenStringValues[ix] = new SharedStringNode(text, this._seenStringValueCount, this._seenStringValues[ix]);
/* 2112 */     this._seenStringValueCount += 1;
/*      */   }
/*      */ 
/*      */   protected long outputOffset()
/*      */   {
/* 2126 */     return this._bytesWritten + this._outputTail;
/*      */   }
/*      */ 
/*      */   protected UnsupportedOperationException _notSupported() {
/* 2130 */     return new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   protected static final class SharedStringNode
/*      */   {
/*      */     public final String value;
/*      */     public final int index;
/*      */     public SharedStringNode next;
/*      */ 
/*      */     public SharedStringNode(String value, int index, SharedStringNode next)
/*      */     {
/*  126 */       this.value = value;
/*  127 */       this.index = index;
/*  128 */       this.next = next;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum Feature
/*      */   {
/*   38 */     WRITE_HEADER(true), 
/*      */ 
/*   49 */     WRITE_END_MARKER(false), 
/*      */ 
/*   61 */     ENCODE_BINARY_AS_7BIT(true), 
/*      */ 
/*   71 */     CHECK_SHARED_NAMES(true), 
/*      */ 
/*   84 */     CHECK_SHARED_STRING_VALUES(false);
/*      */ 
/*      */     protected final boolean _defaultState;
/*      */     protected final int _mask;
/*      */ 
/*      */     public static int collectDefaults()
/*      */     {
/*   96 */       int flags = 0;
/*   97 */       for (Feature f : values()) {
/*   98 */         if (f.enabledByDefault()) {
/*   99 */           flags |= f.getMask();
/*      */         }
/*      */       }
/*  102 */       return flags;
/*      */     }
/*      */ 
/*      */     private Feature(boolean defaultState) {
/*  106 */       this._defaultState = defaultState;
/*  107 */       this._mask = (1 << ordinal());
/*      */     }
/*      */     public boolean enabledByDefault() {
/*  110 */       return this._defaultState; } 
/*  111 */     public int getMask() { return this._mask; }
/*      */ 
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.smile.SmileGenerator
 * JD-Core Version:    0.6.2
 */