/*      */ package org.codehaus.jackson.smile;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Arrays;
/*      */ import org.codehaus.jackson.Base64Variant;
/*      */ import org.codehaus.jackson.JsonLocation;
/*      */ import org.codehaus.jackson.JsonParseException;
/*      */ import org.codehaus.jackson.JsonParser.Feature;
/*      */ import org.codehaus.jackson.JsonParser.NumberType;
/*      */ import org.codehaus.jackson.JsonToken;
/*      */ import org.codehaus.jackson.ObjectCodec;
/*      */ import org.codehaus.jackson.SerializableString;
/*      */ import org.codehaus.jackson.impl.JsonParserBase;
/*      */ import org.codehaus.jackson.impl.JsonReadContext;
/*      */ import org.codehaus.jackson.io.IOContext;
/*      */ import org.codehaus.jackson.sym.BytesToNameCanonicalizer;
/*      */ import org.codehaus.jackson.sym.Name;
/*      */ import org.codehaus.jackson.util.TextBuffer;
/*      */ 
/*      */ public class SmileParser extends JsonParserBase
/*      */ {
/*   62 */   private static final int[] NO_INTS = new int[0];
/*      */ 
/*   64 */   private static final String[] NO_STRINGS = new String[0];
/*      */   protected ObjectCodec _objectCodec;
/*      */   protected boolean _mayContainRawBinary;
/*      */   protected final SmileBufferRecycler<String> _smileBufferRecycler;
/*      */   protected InputStream _inputStream;
/*      */   protected byte[] _inputBuffer;
/*      */   protected boolean _bufferRecyclable;
/*  134 */   protected boolean _tokenIncomplete = false;
/*      */   protected int _typeByte;
/*      */   protected boolean _got32BitFloat;
/*      */   protected final BytesToNameCanonicalizer _symbols;
/*  163 */   protected int[] _quadBuffer = NO_INTS;
/*      */   protected int _quad1;
/*      */   protected int _quad2;
/*  175 */   protected String[] _seenNames = NO_STRINGS;
/*      */ 
/*  177 */   protected int _seenNameCount = 0;
/*      */ 
/*  184 */   protected String[] _seenStringValues = null;
/*      */ 
/*  186 */   protected int _seenStringValueCount = -1;
/*      */ 
/*  199 */   protected static final ThreadLocal<SoftReference<SmileBufferRecycler<String>>> _smileRecyclerRef = new ThreadLocal();
/*      */ 
/*      */   public SmileParser(IOContext ctxt, int parserFeatures, int smileFeatures, ObjectCodec codec, BytesToNameCanonicalizer sym, InputStream in, byte[] inputBuffer, int start, int end, boolean bufferRecyclable)
/*      */   {
/*  214 */     super(ctxt, parserFeatures);
/*  215 */     this._objectCodec = codec;
/*  216 */     this._symbols = sym;
/*      */ 
/*  218 */     this._inputStream = in;
/*  219 */     this._inputBuffer = inputBuffer;
/*  220 */     this._inputPtr = start;
/*  221 */     this._inputEnd = end;
/*  222 */     this._bufferRecyclable = bufferRecyclable;
/*      */ 
/*  224 */     this._tokenInputRow = -1;
/*  225 */     this._tokenInputCol = -1;
/*  226 */     this._smileBufferRecycler = _smileBufferRecycler();
/*      */   }
/*      */ 
/*      */   public ObjectCodec getCodec()
/*      */   {
/*  231 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   public void setCodec(ObjectCodec c)
/*      */   {
/*  236 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */   protected boolean handleSignature(boolean consumeFirstByte, boolean throwException)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  249 */     if (consumeFirstByte) {
/*  250 */       this._inputPtr += 1;
/*      */     }
/*  252 */     if (this._inputPtr >= this._inputEnd) {
/*  253 */       loadMoreGuaranteed();
/*      */     }
/*  255 */     if (this._inputBuffer[this._inputPtr] != 41) {
/*  256 */       if (throwException) {
/*  257 */         _reportError("Malformed content: signature not valid, starts with 0x3a but followed by 0x" + Integer.toHexString(this._inputBuffer[this._inputPtr]) + ", not 0x29");
/*      */       }
/*      */ 
/*  260 */       return false;
/*      */     }
/*  262 */     if (++this._inputPtr >= this._inputEnd) {
/*  263 */       loadMoreGuaranteed();
/*      */     }
/*  265 */     if (this._inputBuffer[this._inputPtr] != 10) {
/*  266 */       if (throwException) {
/*  267 */         _reportError("Malformed content: signature not valid, starts with 0x3a, 0x29, but followed by 0x" + Integer.toHexString(this._inputBuffer[this._inputPtr]) + ", not 0xA");
/*      */       }
/*      */ 
/*  270 */       return false;
/*      */     }
/*      */ 
/*  273 */     if (++this._inputPtr >= this._inputEnd) {
/*  274 */       loadMoreGuaranteed();
/*      */     }
/*  276 */     int ch = this._inputBuffer[(this._inputPtr++)];
/*  277 */     int versionBits = ch >> 4 & 0xF;
/*      */ 
/*  279 */     if (versionBits != 0) {
/*  280 */       _reportError("Header version number bits (0x" + Integer.toHexString(versionBits) + ") indicate unrecognized version; only 0x0 handled by parser");
/*      */     }
/*      */ 
/*  284 */     if ((ch & 0x1) == 0) {
/*  285 */       this._seenNames = null;
/*  286 */       this._seenNameCount = -1;
/*      */     }
/*      */ 
/*  289 */     if ((ch & 0x2) != 0) {
/*  290 */       this._seenStringValues = NO_STRINGS;
/*  291 */       this._seenStringValueCount = 0;
/*      */     }
/*  293 */     this._mayContainRawBinary = ((ch & 0x4) != 0);
/*  294 */     return true;
/*      */   }
/*      */ 
/*      */   protected static final SmileBufferRecycler<String> _smileBufferRecycler()
/*      */   {
/*  302 */     SoftReference ref = (SoftReference)_smileRecyclerRef.get();
/*  303 */     SmileBufferRecycler br = ref == null ? null : (SmileBufferRecycler)ref.get();
/*      */ 
/*  305 */     if (br == null) {
/*  306 */       br = new SmileBufferRecycler();
/*  307 */       _smileRecyclerRef.set(new SoftReference(br));
/*      */     }
/*  309 */     return br;
/*      */   }
/*      */ 
/*      */   public int releaseBuffered(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  321 */     int count = this._inputEnd - this._inputPtr;
/*  322 */     if (count < 1) {
/*  323 */       return 0;
/*      */     }
/*      */ 
/*  326 */     int origPtr = this._inputPtr;
/*  327 */     out.write(this._inputBuffer, origPtr, count);
/*  328 */     return count;
/*      */   }
/*      */ 
/*      */   public Object getInputSource()
/*      */   {
/*  333 */     return this._inputStream;
/*      */   }
/*      */ 
/*      */   public JsonLocation getTokenLocation()
/*      */   {
/*  343 */     return new JsonLocation(this._ioContext.getSourceReference(), this._tokenInputTotal, -1L, -1, -1);
/*      */   }
/*      */ 
/*      */   public JsonLocation getCurrentLocation()
/*      */   {
/*  355 */     return new JsonLocation(this._ioContext.getSourceReference(), this._currInputProcessed + this._inputPtr, -1L, -1, -1);
/*      */   }
/*      */ 
/*      */   protected final boolean loadMore()
/*      */     throws IOException
/*      */   {
/*  370 */     this._currInputProcessed += this._inputEnd;
/*      */ 
/*  373 */     if (this._inputStream != null) {
/*  374 */       int count = this._inputStream.read(this._inputBuffer, 0, this._inputBuffer.length);
/*  375 */       if (count > 0) {
/*  376 */         this._inputPtr = 0;
/*  377 */         this._inputEnd = count;
/*  378 */         return true;
/*      */       }
/*      */ 
/*  381 */       _closeInput();
/*      */ 
/*  383 */       if (count == 0) {
/*  384 */         throw new IOException("InputStream.read() returned 0 characters when trying to read " + this._inputBuffer.length + " bytes");
/*      */       }
/*      */     }
/*  387 */     return false;
/*      */   }
/*      */ 
/*      */   protected final boolean _loadToHaveAtLeast(int minAvailable)
/*      */     throws IOException
/*      */   {
/*  400 */     if (this._inputStream == null) {
/*  401 */       return false;
/*      */     }
/*      */ 
/*  404 */     int amount = this._inputEnd - this._inputPtr;
/*  405 */     if ((amount > 0) && (this._inputPtr > 0)) {
/*  406 */       this._currInputProcessed += this._inputPtr;
/*      */ 
/*  408 */       System.arraycopy(this._inputBuffer, this._inputPtr, this._inputBuffer, 0, amount);
/*  409 */       this._inputEnd = amount;
/*      */     } else {
/*  411 */       this._inputEnd = 0;
/*      */     }
/*  413 */     this._inputPtr = 0;
/*  414 */     while (this._inputEnd < minAvailable) {
/*  415 */       int count = this._inputStream.read(this._inputBuffer, this._inputEnd, this._inputBuffer.length - this._inputEnd);
/*  416 */       if (count < 1)
/*      */       {
/*  418 */         _closeInput();
/*      */ 
/*  420 */         if (count == 0) {
/*  421 */           throw new IOException("InputStream.read() returned 0 characters when trying to read " + amount + " bytes");
/*      */         }
/*  423 */         return false;
/*      */       }
/*  425 */       this._inputEnd += count;
/*      */     }
/*  427 */     return true;
/*      */   }
/*      */ 
/*      */   protected void _closeInput()
/*      */     throws IOException
/*      */   {
/*  437 */     if (this._inputStream != null) {
/*  438 */       if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE))) {
/*  439 */         this._inputStream.close();
/*      */       }
/*  441 */       this._inputStream = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _finishString()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  455 */     _throwInternal();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  461 */     super.close();
/*      */ 
/*  463 */     this._symbols.release();
/*      */   }
/*      */ 
/*      */   public boolean hasTextCharacters()
/*      */   {
/*  469 */     if (this._currToken == JsonToken.VALUE_STRING)
/*      */     {
/*  471 */       return this._textBuffer.hasTextAsCharacters();
/*      */     }
/*  473 */     if (this._currToken == JsonToken.FIELD_NAME)
/*      */     {
/*  475 */       return this._nameCopied;
/*      */     }
/*      */ 
/*  478 */     return false;
/*      */   }
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */     throws IOException
/*      */   {
/*  490 */     super._releaseBuffers();
/*  491 */     if (this._bufferRecyclable) {
/*  492 */       byte[] buf = this._inputBuffer;
/*  493 */       if (buf != null) {
/*  494 */         this._inputBuffer = null;
/*  495 */         this._ioContext.releaseReadIOBuffer(buf);
/*      */       }
/*      */     }
/*      */ 
/*  499 */     String[] nameBuf = this._seenNames;
/*  500 */     if ((nameBuf != null) && (nameBuf.length > 0)) {
/*  501 */       this._seenNames = null;
/*      */ 
/*  505 */       if (this._seenNameCount > 0) {
/*  506 */         Arrays.fill(nameBuf, 0, this._seenNameCount, null);
/*      */       }
/*  508 */       this._smileBufferRecycler.releaseSeenNamesBuffer(nameBuf);
/*      */     }
/*      */ 
/*  512 */     String[] valueBuf = this._seenStringValues;
/*  513 */     if ((valueBuf != null) && (valueBuf.length > 0)) {
/*  514 */       this._seenStringValues = null;
/*      */ 
/*  518 */       if (this._seenStringValueCount > 0) {
/*  519 */         Arrays.fill(valueBuf, 0, this._seenStringValueCount, null);
/*      */       }
/*  521 */       this._smileBufferRecycler.releaseSeenStringValuesBuffer(valueBuf);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean mayContainRawBinary()
/*      */   {
/*  533 */     return this._mayContainRawBinary;
/*      */   }
/*      */ 
/*      */   public JsonToken nextToken()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  545 */     this._numTypesValid = 0;
/*      */ 
/*  547 */     if (this._tokenIncomplete) {
/*  548 */       _skipIncomplete();
/*      */     }
/*  550 */     this._tokenInputTotal = (this._currInputProcessed + this._inputPtr);
/*      */ 
/*  552 */     this._binaryValue = null;
/*      */ 
/*  554 */     if ((this._parsingContext.inObject()) && (this._currToken != JsonToken.FIELD_NAME)) {
/*  555 */       return this._currToken = _handleFieldName();
/*      */     }
/*  557 */     if ((this._inputPtr >= this._inputEnd) && 
/*  558 */       (!loadMore())) {
/*  559 */       _handleEOF();
/*      */ 
/*  564 */       close();
/*  565 */       return this._currToken = null;
/*      */     }
/*      */ 
/*  568 */     int ch = this._inputBuffer[(this._inputPtr++)];
/*  569 */     this._typeByte = ch;
/*  570 */     switch (ch >> 5 & 0x7) {
/*      */     case 0:
/*  572 */       if (ch == 0) {
/*  573 */         _reportError("Invalid token byte 0x00");
/*      */       }
/*  575 */       return _handleSharedString(ch - 1);
/*      */     case 1:
/*  579 */       int typeBits = ch & 0x1F;
/*  580 */       if (typeBits < 4) {
/*  581 */         switch (typeBits) {
/*      */         case 0:
/*  583 */           this._textBuffer.resetWithEmpty();
/*  584 */           return this._currToken = JsonToken.VALUE_STRING;
/*      */         case 1:
/*  586 */           return this._currToken = JsonToken.VALUE_NULL;
/*      */         case 2:
/*  588 */           return this._currToken = JsonToken.VALUE_FALSE;
/*      */         }
/*  590 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       }
/*      */ 
/*  594 */       if (typeBits < 8) {
/*  595 */         if ((typeBits & 0x3) <= 2) {
/*  596 */           this._tokenIncomplete = true;
/*  597 */           this._numTypesValid = 0;
/*  598 */           return this._currToken = JsonToken.VALUE_NUMBER_INT;
/*      */         }
/*      */ 
/*      */       }
/*  602 */       else if (typeBits < 12) {
/*  603 */         int subtype = typeBits & 0x3;
/*  604 */         if (subtype <= 2) {
/*  605 */           this._tokenIncomplete = true;
/*  606 */           this._numTypesValid = 0;
/*  607 */           this._got32BitFloat = (subtype == 0);
/*  608 */           return this._currToken = JsonToken.VALUE_NUMBER_FLOAT;
/*      */         }
/*      */       }
/*      */       else {
/*  612 */         if ((typeBits == 26) && 
/*  613 */           (handleSignature(false, false)))
/*      */         {
/*  619 */           if (this._currToken == null) {
/*  620 */             return nextToken();
/*      */           }
/*  622 */           return this._currToken = null;
/*      */         }
/*      */ 
/*  625 */         _reportError("Unrecognized token byte 0x3A (malformed segment header?");
/*      */       }
/*      */ 
/*  628 */       break;
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*  637 */       this._currToken = JsonToken.VALUE_STRING;
/*  638 */       if (this._seenStringValueCount >= 0)
/*  639 */         _addSeenStringValue();
/*      */       else {
/*  641 */         this._tokenIncomplete = true;
/*      */       }
/*  643 */       return this._currToken;
/*      */     case 6:
/*  645 */       this._numberInt = SmileUtil.zigzagDecode(ch & 0x1F);
/*  646 */       this._numTypesValid = 1;
/*  647 */       return this._currToken = JsonToken.VALUE_NUMBER_INT;
/*      */     case 7:
/*  649 */       switch (ch & 0x1F) {
/*      */       case 0:
/*      */       case 4:
/*  652 */         this._tokenIncomplete = true;
/*  653 */         return this._currToken = JsonToken.VALUE_STRING;
/*      */       case 8:
/*  655 */         this._tokenIncomplete = true;
/*  656 */         return this._currToken = JsonToken.VALUE_EMBEDDED_OBJECT;
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*  661 */         if (this._inputPtr >= this._inputEnd) {
/*  662 */           loadMoreGuaranteed();
/*      */         }
/*  664 */         return _handleSharedString(((ch & 0x3) << 8) + (this._inputBuffer[(this._inputPtr++)] & 0xFF));
/*      */       case 24:
/*  666 */         this._parsingContext = this._parsingContext.createChildArrayContext(-1, -1);
/*  667 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 25:
/*  669 */         if (!this._parsingContext.inArray()) {
/*  670 */           _reportMismatchedEndMarker(93, '}');
/*      */         }
/*  672 */         this._parsingContext = this._parsingContext.getParent();
/*  673 */         return this._currToken = JsonToken.END_ARRAY;
/*      */       case 26:
/*  675 */         this._parsingContext = this._parsingContext.createChildObjectContext(-1, -1);
/*  676 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 27:
/*  678 */         _reportError("Invalid type marker byte 0xFB in value mode (would be END_OBJECT in key mode)");
/*      */       case 29:
/*  680 */         this._tokenIncomplete = true;
/*  681 */         return this._currToken = JsonToken.VALUE_EMBEDDED_OBJECT;
/*      */       case 31:
/*  683 */         return this._currToken = null;
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/*      */       case 28:
/*  688 */       case 30: } break; } _reportError("Invalid type marker byte 0x" + Integer.toHexString(ch & 0xFF) + " for expected value token");
/*  689 */     return null;
/*      */   }
/*      */ 
/*      */   private final JsonToken _handleSharedString(int index)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  695 */     if (index >= this._seenStringValueCount) {
/*  696 */       _reportInvalidSharedStringValue(index);
/*      */     }
/*  698 */     this._textBuffer.resetWithString(this._seenStringValues[index]);
/*  699 */     return this._currToken = JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */   private final void _addSeenStringValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  705 */     _finishToken();
/*  706 */     if (this._seenStringValueCount < this._seenStringValues.length)
/*      */     {
/*  708 */       this._seenStringValues[(this._seenStringValueCount++)] = this._textBuffer.contentsAsString();
/*  709 */       return;
/*      */     }
/*  711 */     _expandSeenStringValues();
/*      */   }
/*      */ 
/*      */   private final void _expandSeenStringValues()
/*      */   {
/*  716 */     String[] oldShared = this._seenStringValues;
/*  717 */     int len = oldShared.length;
/*      */     String[] newShared;
/*  719 */     if (len == 0) {
/*  720 */       String[] newShared = (String[])this._smileBufferRecycler.allocSeenStringValuesBuffer();
/*  721 */       if (newShared == null)
/*  722 */         newShared = new String[64];
/*      */     }
/*  724 */     else if (len == 1024) {
/*  725 */       String[] newShared = oldShared;
/*  726 */       this._seenStringValueCount = 0;
/*      */     } else {
/*  728 */       int newSize = len == 64 ? 256 : 1024;
/*  729 */       newShared = new String[newSize];
/*  730 */       System.arraycopy(oldShared, 0, newShared, 0, oldShared.length);
/*      */     }
/*  732 */     this._seenStringValues = newShared;
/*  733 */     this._seenStringValues[(this._seenStringValueCount++)] = this._textBuffer.contentsAsString();
/*      */   }
/*      */ 
/*      */   public String getCurrentName()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  739 */     return this._parsingContext.getCurrentName();
/*      */   }
/*      */ 
/*      */   public JsonParser.NumberType getNumberType()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  746 */     if (this._got32BitFloat) {
/*  747 */       return JsonParser.NumberType.FLOAT;
/*      */     }
/*  749 */     return super.getNumberType();
/*      */   }
/*      */ 
/*      */   public boolean nextFieldName(SerializableString str)
/*      */     throws IOException, JsonParseException
/*      */   {
/*  763 */     if ((this._parsingContext.inObject()) && (this._currToken != JsonToken.FIELD_NAME)) {
/*  764 */       byte[] nameBytes = str.asQuotedUTF8();
/*  765 */       int byteLen = nameBytes.length;
/*      */ 
/*  767 */       if (this._inputPtr + byteLen + 1 < this._inputEnd) {
/*  768 */         int ptr = this._inputPtr;
/*  769 */         int ch = this._inputBuffer[(ptr++)];
/*  770 */         this._typeByte = ch;
/*      */ 
/*  772 */         switch (ch >> 6 & 0x3) {
/*      */         case 0:
/*  774 */           switch (ch) {
/*      */           case 32:
/*  776 */             this._currToken = JsonToken.FIELD_NAME;
/*  777 */             this._inputPtr = ptr;
/*  778 */             this._parsingContext.setCurrentName("");
/*  779 */             return byteLen == 0;
/*      */           case 48:
/*      */           case 49:
/*      */           case 50:
/*      */           case 51:
/*  785 */             int index = ((ch & 0x3) << 8) + (this._inputBuffer[(ptr++)] & 0xFF);
/*  786 */             if (index >= this._seenNameCount) {
/*  787 */               _reportInvalidSharedName(index);
/*      */             }
/*  789 */             String name = this._seenNames[index];
/*  790 */             this._parsingContext.setCurrentName(name);
/*  791 */             this._inputPtr = ptr;
/*  792 */             this._currToken = JsonToken.FIELD_NAME;
/*  793 */             return name.equals(str.getValue());
/*      */           }
/*      */ 
/*  797 */           break;
/*      */         case 1:
/*  800 */           int index = ch & 0x3F;
/*  801 */           if (index >= this._seenNameCount) {
/*  802 */             _reportInvalidSharedName(index);
/*      */           }
/*  804 */           this._parsingContext.setCurrentName(this._seenNames[index]);
/*  805 */           String name = this._seenNames[index];
/*  806 */           this._parsingContext.setCurrentName(name);
/*  807 */           this._inputPtr = ptr;
/*  808 */           this._currToken = JsonToken.FIELD_NAME;
/*  809 */           return name.equals(str.getValue());
/*      */         case 2:
/*  813 */           int len = 1 + (ch & 0x3F);
/*  814 */           if (len == byteLen) {
/*  815 */             for (int i = 0; 
/*  816 */               i < len; i++) {
/*  817 */               if (nameBytes[i] != this._inputBuffer[(ptr + i)])
/*      */               {
/*      */                 break label688;
/*      */               }
/*      */             }
/*  822 */             this._inputPtr = (ptr + len);
/*  823 */             String name = str.getValue();
/*  824 */             if (this._seenNames != null) {
/*  825 */               if (this._seenNameCount >= this._seenNames.length) {
/*  826 */                 this._seenNames = _expandSeenNames(this._seenNames);
/*      */               }
/*  828 */               this._seenNames[(this._seenNameCount++)] = name;
/*      */             }
/*  830 */             this._parsingContext.setCurrentName(name);
/*  831 */             this._currToken = JsonToken.FIELD_NAME;
/*  832 */             return true;
/*      */           }
/*      */ 
/*  835 */           break;
/*      */         case 3:
/*  839 */           int len = ch & 0x3F;
/*  840 */           if (len > 55) {
/*  841 */             if (len == 59) {
/*  842 */               this._currToken = JsonToken.END_OBJECT;
/*  843 */               if (!this._parsingContext.inObject()) {
/*  844 */                 _reportMismatchedEndMarker(125, ']');
/*      */               }
/*  846 */               this._inputPtr = ptr;
/*  847 */               this._parsingContext = this._parsingContext.getParent();
/*  848 */               return false;
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/*  853 */             len += 2;
/*  854 */             if (len == byteLen) {
/*  855 */               for (int i = 0; 
/*  856 */                 i < len; i++) {
/*  857 */                 if (nameBytes[i] != this._inputBuffer[(ptr + i)])
/*      */                 {
/*      */                   break label688;
/*      */                 }
/*      */               }
/*  862 */               this._inputPtr = (ptr + len);
/*  863 */               String name = str.getValue();
/*  864 */               if (this._seenNames != null) {
/*  865 */                 if (this._seenNameCount >= this._seenNames.length) {
/*  866 */                   this._seenNames = _expandSeenNames(this._seenNames);
/*      */                 }
/*  868 */                 this._seenNames[(this._seenNameCount++)] = name;
/*      */               }
/*  870 */               this._parsingContext.setCurrentName(name);
/*  871 */               this._currToken = JsonToken.FIELD_NAME;
/*  872 */               return true;
/*      */             }
/*      */           }
/*      */           break;
/*      */         }
/*      */       }
/*      */ 
/*  879 */       label688: JsonToken t = _handleFieldName();
/*  880 */       this._currToken = t;
/*  881 */       return (t == JsonToken.FIELD_NAME) && (str.getValue().equals(this._parsingContext.getCurrentName()));
/*      */     }
/*      */ 
/*  884 */     return (nextToken() == JsonToken.FIELD_NAME) && (str.getValue().equals(getCurrentName()));
/*      */   }
/*      */ 
/*      */   public String nextTextValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/*  892 */     if ((!this._parsingContext.inObject()) || (this._currToken == JsonToken.FIELD_NAME)) {
/*  893 */       if (this._tokenIncomplete) {
/*  894 */         _skipIncomplete();
/*      */       }
/*  896 */       int ptr = this._inputPtr;
/*  897 */       if (ptr >= this._inputEnd) {
/*  898 */         if (!loadMore()) {
/*  899 */           _handleEOF();
/*  900 */           close();
/*  901 */           this._currToken = null;
/*  902 */           return null;
/*      */         }
/*  904 */         ptr = this._inputPtr;
/*      */       }
/*  906 */       int ch = this._inputBuffer[(ptr++)];
/*  907 */       this._tokenInputTotal = (this._currInputProcessed + this._inputPtr);
/*      */ 
/*  910 */       this._binaryValue = null;
/*  911 */       this._typeByte = ch;
/*      */ 
/*  913 */       switch (ch >> 5 & 0x7) {
/*      */       case 0:
/*  915 */         if (ch == 0) {
/*  916 */           _reportError("Invalid token byte 0x00");
/*      */         }
/*      */ 
/*  920 */         ch--;
/*  921 */         if (ch >= this._seenStringValueCount) {
/*  922 */           _reportInvalidSharedStringValue(ch);
/*      */         }
/*  924 */         this._inputPtr = ptr;
/*  925 */         String text = this._seenStringValues[ch];
/*  926 */         this._textBuffer.resetWithString(text);
/*  927 */         this._currToken = JsonToken.VALUE_STRING;
/*  928 */         return text;
/*      */       case 1:
/*  933 */         int typeBits = ch & 0x1F;
/*  934 */         if (typeBits == 0) {
/*  935 */           this._inputPtr = ptr;
/*  936 */           this._textBuffer.resetWithEmpty();
/*  937 */           this._currToken = JsonToken.VALUE_STRING;
/*  938 */           return "";
/*      */         }
/*      */ 
/*  941 */         break;
/*      */       case 2:
/*      */       case 3:
/*  945 */         this._currToken = JsonToken.VALUE_STRING;
/*  946 */         this._inputPtr = ptr;
/*  947 */         _decodeShortAsciiValue(1 + (ch & 0x3F));
/*      */         String text;
/*      */         String text;
/*  951 */         if (this._seenStringValueCount >= 0) {
/*  952 */           if (this._seenStringValueCount < this._seenStringValues.length) {
/*  953 */             String text = this._textBuffer.contentsAsString();
/*  954 */             this._seenStringValues[(this._seenStringValueCount++)] = text;
/*      */           } else {
/*  956 */             _expandSeenStringValues();
/*  957 */             text = this._textBuffer.contentsAsString();
/*      */           }
/*      */         }
/*  960 */         else text = this._textBuffer.contentsAsString();
/*      */ 
/*  962 */         return text;
/*      */       case 4:
/*      */       case 5:
/*  968 */         this._currToken = JsonToken.VALUE_STRING;
/*  969 */         this._inputPtr = ptr;
/*  970 */         _decodeShortUnicodeValue(2 + (ch & 0x3F));
/*      */         String text;
/*      */         String text;
/*  974 */         if (this._seenStringValueCount >= 0) {
/*  975 */           if (this._seenStringValueCount < this._seenStringValues.length) {
/*  976 */             String text = this._textBuffer.contentsAsString();
/*  977 */             this._seenStringValues[(this._seenStringValueCount++)] = text;
/*      */           } else {
/*  979 */             _expandSeenStringValues();
/*  980 */             text = this._textBuffer.contentsAsString();
/*      */           }
/*      */         }
/*  983 */         else text = this._textBuffer.contentsAsString();
/*      */ 
/*  985 */         return text;
/*      */       case 6:
/*  988 */         break;
/*      */       case 7:
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1014 */     return nextToken() == JsonToken.VALUE_STRING ? getText() : null;
/*      */   }
/*      */ 
/*      */   public int nextIntValue(int defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1021 */     if (nextToken() == JsonToken.VALUE_NUMBER_INT) {
/* 1022 */       return getIntValue();
/*      */     }
/* 1024 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public long nextLongValue(long defaultValue)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1031 */     if (nextToken() == JsonToken.VALUE_NUMBER_INT) {
/* 1032 */       return getLongValue();
/*      */     }
/* 1034 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public Boolean nextBooleanValue()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1041 */     switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[nextToken().ordinal()]) {
/*      */     case 1:
/* 1043 */       return Boolean.TRUE;
/*      */     case 2:
/* 1045 */       return Boolean.FALSE;
/*      */     }
/* 1047 */     return null;
/*      */   }
/*      */ 
/*      */   public String getText()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1066 */     if (this._tokenIncomplete) {
/* 1067 */       this._tokenIncomplete = false;
/*      */ 
/* 1069 */       int tb = this._typeByte;
/* 1070 */       int type = tb >> 5 & 0x7;
/* 1071 */       if ((type == 2) || (type == 3)) {
/* 1072 */         _decodeShortAsciiValue(1 + (tb & 0x3F));
/* 1073 */         return this._textBuffer.contentsAsString();
/*      */       }
/* 1075 */       if ((type == 4) || (type == 5))
/*      */       {
/* 1077 */         _decodeShortUnicodeValue(2 + (tb & 0x3F));
/* 1078 */         return this._textBuffer.contentsAsString();
/*      */       }
/* 1080 */       _finishToken();
/*      */     }
/* 1082 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 1083 */       return this._textBuffer.contentsAsString();
/*      */     }
/* 1085 */     JsonToken t = this._currToken;
/* 1086 */     if (t == null) {
/* 1087 */       return null;
/*      */     }
/* 1089 */     if (t == JsonToken.FIELD_NAME) {
/* 1090 */       return this._parsingContext.getCurrentName();
/*      */     }
/* 1092 */     if (t.isNumeric())
/*      */     {
/* 1094 */       return getNumberValue().toString();
/*      */     }
/* 1096 */     return this._currToken.asString();
/*      */   }
/*      */ 
/*      */   public char[] getTextCharacters()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1103 */     if (this._currToken != null) {
/* 1104 */       if (this._tokenIncomplete) {
/* 1105 */         _finishToken();
/*      */       }
/* 1107 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[this._currToken.ordinal()]) {
/*      */       case 3:
/* 1109 */         return this._textBuffer.getTextBuffer();
/*      */       case 4:
/* 1111 */         if (!this._nameCopied) {
/* 1112 */           String name = this._parsingContext.getCurrentName();
/* 1113 */           int nameLen = name.length();
/* 1114 */           if (this._nameCopyBuffer == null)
/* 1115 */             this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/* 1116 */           else if (this._nameCopyBuffer.length < nameLen) {
/* 1117 */             this._nameCopyBuffer = new char[nameLen];
/*      */           }
/* 1119 */           name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/* 1120 */           this._nameCopied = true;
/*      */         }
/* 1122 */         return this._nameCopyBuffer;
/*      */       case 5:
/*      */       case 6:
/* 1128 */         return getNumberValue().toString().toCharArray();
/*      */       }
/*      */ 
/* 1131 */       return this._currToken.asCharArray();
/*      */     }
/*      */ 
/* 1134 */     return null;
/*      */   }
/*      */ 
/*      */   public int getTextLength()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1141 */     if (this._currToken != null) {
/* 1142 */       if (this._tokenIncomplete) {
/* 1143 */         _finishToken();
/*      */       }
/* 1145 */       switch (1.$SwitchMap$org$codehaus$jackson$JsonToken[this._currToken.ordinal()]) {
/*      */       case 3:
/* 1147 */         return this._textBuffer.size();
/*      */       case 4:
/* 1149 */         return this._parsingContext.getCurrentName().length();
/*      */       case 5:
/*      */       case 6:
/* 1154 */         return getNumberValue().toString().length();
/*      */       }
/*      */ 
/* 1157 */       return this._currToken.asCharArray().length;
/*      */     }
/*      */ 
/* 1160 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getTextOffset()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1166 */     return 0;
/*      */   }
/*      */ 
/*      */   public byte[] getBinaryValue(Base64Variant b64variant)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1179 */     if (this._tokenIncomplete) {
/* 1180 */       _finishToken();
/*      */     }
/* 1182 */     if (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT)
/*      */     {
/* 1184 */       _reportError("Current token (" + this._currToken + ") not VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/* 1186 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */   protected byte[] _decodeBase64(Base64Variant b64variant)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1194 */     _throwInternal();
/* 1195 */     return null;
/*      */   }
/*      */ 
/*      */   protected final JsonToken _handleFieldName()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1210 */     if (this._inputPtr >= this._inputEnd) {
/* 1211 */       loadMoreGuaranteed();
/*      */     }
/* 1213 */     int ch = this._inputBuffer[(this._inputPtr++)];
/*      */ 
/* 1215 */     this._typeByte = ch;
/* 1216 */     switch (ch >> 6 & 0x3) {
/*      */     case 0:
/* 1218 */       switch (ch) {
/*      */       case 32:
/* 1220 */         this._parsingContext.setCurrentName("");
/* 1221 */         return JsonToken.FIELD_NAME;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/* 1227 */         if (this._inputPtr >= this._inputEnd) {
/* 1228 */           loadMoreGuaranteed();
/*      */         }
/* 1230 */         int index = ((ch & 0x3) << 8) + (this._inputBuffer[(this._inputPtr++)] & 0xFF);
/* 1231 */         if (index >= this._seenNameCount) {
/* 1232 */           _reportInvalidSharedName(index);
/*      */         }
/* 1234 */         this._parsingContext.setCurrentName(this._seenNames[index]);
/*      */ 
/* 1236 */         return JsonToken.FIELD_NAME;
/*      */       case 52:
/* 1238 */         _handleLongFieldName();
/* 1239 */         return JsonToken.FIELD_NAME;
/*      */       }
/* 1241 */       break;
/*      */     case 1:
/* 1244 */       int index = ch & 0x3F;
/* 1245 */       if (index >= this._seenNameCount) {
/* 1246 */         _reportInvalidSharedName(index);
/*      */       }
/* 1248 */       this._parsingContext.setCurrentName(this._seenNames[index]);
/*      */ 
/* 1250 */       return JsonToken.FIELD_NAME;
/*      */     case 2:
/* 1253 */       int len = 1 + (ch & 0x3F);
/*      */ 
/* 1255 */       Name n = _findDecodedFromSymbols(len);
/*      */       String name;
/* 1256 */       if (n != null) {
/* 1257 */         String name = n.getName();
/* 1258 */         this._inputPtr += len;
/*      */       } else {
/* 1260 */         name = _decodeShortAsciiName(len);
/* 1261 */         name = _addDecodedToSymbols(len, name);
/*      */       }
/* 1263 */       if (this._seenNames != null) {
/* 1264 */         if (this._seenNameCount >= this._seenNames.length) {
/* 1265 */           this._seenNames = _expandSeenNames(this._seenNames);
/*      */         }
/* 1267 */         this._seenNames[(this._seenNameCount++)] = name;
/*      */       }
/* 1269 */       this._parsingContext.setCurrentName(name);
/*      */ 
/* 1271 */       return JsonToken.FIELD_NAME;
/*      */     case 3:
/* 1274 */       ch &= 63;
/*      */ 
/* 1276 */       if (ch > 55) {
/* 1277 */         if (ch == 59) {
/* 1278 */           if (!this._parsingContext.inObject()) {
/* 1279 */             _reportMismatchedEndMarker(125, ']');
/*      */           }
/* 1281 */           this._parsingContext = this._parsingContext.getParent();
/* 1282 */           return JsonToken.END_OBJECT;
/*      */         }
/*      */       } else {
/* 1285 */         int len = ch + 2;
/*      */ 
/* 1287 */         Name n = _findDecodedFromSymbols(len);
/*      */         String name;
/* 1288 */         if (n != null) {
/* 1289 */           String name = n.getName();
/* 1290 */           this._inputPtr += len;
/*      */         } else {
/* 1292 */           name = _decodeShortUnicodeName(len);
/* 1293 */           name = _addDecodedToSymbols(len, name);
/*      */         }
/* 1295 */         if (this._seenNames != null) {
/* 1296 */           if (this._seenNameCount >= this._seenNames.length) {
/* 1297 */             this._seenNames = _expandSeenNames(this._seenNames);
/*      */           }
/* 1299 */           this._seenNames[(this._seenNameCount++)] = name;
/*      */         }
/* 1301 */         this._parsingContext.setCurrentName(name);
/* 1302 */         return JsonToken.FIELD_NAME;
/*      */       }
/*      */ 
/*      */       break;
/*      */     }
/*      */ 
/* 1308 */     _reportError("Invalid type marker byte 0x" + Integer.toHexString(this._typeByte) + " for expected field name (or END_OBJECT marker)");
/* 1309 */     return null;
/*      */   }
/*      */ 
/*      */   private final String[] _expandSeenNames(String[] oldShared)
/*      */   {
/* 1319 */     int len = oldShared.length;
/*      */     String[] newShared;
/* 1321 */     if (len == 0) {
/* 1322 */       String[] newShared = (String[])this._smileBufferRecycler.allocSeenNamesBuffer();
/* 1323 */       if (newShared == null)
/* 1324 */         newShared = new String[64];
/*      */     }
/* 1326 */     else if (len == 1024) {
/* 1327 */       String[] newShared = oldShared;
/* 1328 */       this._seenNameCount = 0;
/*      */     } else {
/* 1330 */       int newSize = len == 64 ? 256 : 1024;
/* 1331 */       newShared = new String[newSize];
/* 1332 */       System.arraycopy(oldShared, 0, newShared, 0, oldShared.length);
/*      */     }
/* 1334 */     return newShared;
/*      */   }
/*      */ 
/*      */   private final String _addDecodedToSymbols(int len, String name)
/*      */   {
/* 1339 */     if (len < 5) {
/* 1340 */       return this._symbols.addName(name, this._quad1, 0).getName();
/*      */     }
/* 1342 */     if (len < 9) {
/* 1343 */       return this._symbols.addName(name, this._quad1, this._quad2).getName();
/*      */     }
/* 1345 */     int qlen = len + 3 >> 2;
/* 1346 */     return this._symbols.addName(name, this._quadBuffer, qlen).getName();
/*      */   }
/*      */ 
/*      */   private final String _decodeShortAsciiName(int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1353 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1354 */     int outPtr = 0;
/* 1355 */     byte[] inBuf = this._inputBuffer;
/* 1356 */     int inPtr = this._inputPtr;
/*      */ 
/* 1359 */     for (int inEnd = inPtr + len - 3; inPtr < inEnd; ) {
/* 1360 */       outBuf[(outPtr++)] = ((char)inBuf[(inPtr++)]);
/* 1361 */       outBuf[(outPtr++)] = ((char)inBuf[(inPtr++)]);
/* 1362 */       outBuf[(outPtr++)] = ((char)inBuf[(inPtr++)]);
/* 1363 */       outBuf[(outPtr++)] = ((char)inBuf[(inPtr++)]);
/*      */     }
/* 1365 */     int left = len & 0x3;
/* 1366 */     if (left > 0) {
/* 1367 */       outBuf[(outPtr++)] = ((char)inBuf[(inPtr++)]);
/* 1368 */       if (left > 1) {
/* 1369 */         outBuf[(outPtr++)] = ((char)inBuf[(inPtr++)]);
/* 1370 */         if (left > 2) {
/* 1371 */           outBuf[(outPtr++)] = ((char)inBuf[(inPtr++)]);
/*      */         }
/*      */       }
/*      */     }
/* 1375 */     this._inputPtr = inPtr;
/* 1376 */     this._textBuffer.setCurrentLength(len);
/* 1377 */     return this._textBuffer.contentsAsString();
/*      */   }
/*      */ 
/*      */   private final String _decodeShortUnicodeName(int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1390 */     int outPtr = 0;
/* 1391 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1392 */     int inPtr = this._inputPtr;
/* 1393 */     this._inputPtr += len;
/* 1394 */     int[] codes = SmileConstants.sUtf8UnitLengths;
/* 1395 */     byte[] inBuf = this._inputBuffer;
/* 1396 */     for (int end = inPtr + len; inPtr < end; ) {
/* 1397 */       int i = inBuf[(inPtr++)] & 0xFF;
/* 1398 */       int code = codes[i];
/* 1399 */       if (code != 0)
/*      */       {
/* 1401 */         switch (code) {
/*      */         case 1:
/* 1403 */           i = (i & 0x1F) << 6 | inBuf[(inPtr++)] & 0x3F;
/* 1404 */           break;
/*      */         case 2:
/* 1406 */           i = (i & 0xF) << 12 | (inBuf[(inPtr++)] & 0x3F) << 6 | inBuf[(inPtr++)] & 0x3F;
/*      */ 
/* 1409 */           break;
/*      */         case 3:
/* 1411 */           i = (i & 0x7) << 18 | (inBuf[(inPtr++)] & 0x3F) << 12 | (inBuf[(inPtr++)] & 0x3F) << 6 | inBuf[(inPtr++)] & 0x3F;
/*      */ 
/* 1416 */           i -= 65536;
/* 1417 */           outBuf[(outPtr++)] = ((char)(0xD800 | i >> 10));
/* 1418 */           i = 0xDC00 | i & 0x3FF;
/* 1419 */           break;
/*      */         default:
/* 1421 */           _reportError("Invalid byte " + Integer.toHexString(i) + " in short Unicode text block");
/*      */         }
/*      */       }
/* 1424 */       outBuf[(outPtr++)] = ((char)i);
/*      */     }
/* 1426 */     this._textBuffer.setCurrentLength(outPtr);
/* 1427 */     return this._textBuffer.contentsAsString();
/*      */   }
/*      */ 
/*      */   private final Name _decodeLongUnicodeName(int[] quads, int byteLen, int quadLen)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1434 */     int lastQuadBytes = byteLen & 0x3;
/*      */     int lastQuad;
/* 1443 */     if (lastQuadBytes < 4) {
/* 1444 */       int lastQuad = quads[(quadLen - 1)];
/*      */ 
/* 1446 */       quads[(quadLen - 1)] = (lastQuad << (4 - lastQuadBytes << 3));
/*      */     } else {
/* 1448 */       lastQuad = 0;
/*      */     }
/*      */ 
/* 1451 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1452 */     int cix = 0;
/*      */ 
/* 1454 */     for (int ix = 0; ix < byteLen; ) {
/* 1455 */       int ch = quads[(ix >> 2)];
/* 1456 */       int byteIx = ix & 0x3;
/* 1457 */       ch = ch >> (3 - byteIx << 3) & 0xFF;
/* 1458 */       ix++;
/*      */ 
/* 1460 */       if (ch > 127)
/*      */       {
/*      */         int needed;
/*      */         int needed;
/* 1462 */         if ((ch & 0xE0) == 192) {
/* 1463 */           ch &= 31;
/* 1464 */           needed = 1;
/*      */         }
/*      */         else
/*      */         {
/*      */           int needed;
/* 1465 */           if ((ch & 0xF0) == 224) {
/* 1466 */             ch &= 15;
/* 1467 */             needed = 2;
/*      */           }
/*      */           else
/*      */           {
/*      */             int needed;
/* 1468 */             if ((ch & 0xF8) == 240) {
/* 1469 */               ch &= 7;
/* 1470 */               needed = 3;
/*      */             } else {
/* 1472 */               _reportInvalidInitial(ch);
/* 1473 */               needed = ch = 1;
/*      */             }
/*      */           }
/*      */         }
/* 1475 */         if (ix + needed > byteLen) {
/* 1476 */           _reportInvalidEOF(" in long field name");
/*      */         }
/*      */ 
/* 1480 */         int ch2 = quads[(ix >> 2)];
/* 1481 */         byteIx = ix & 0x3;
/* 1482 */         ch2 >>= 3 - byteIx << 3;
/* 1483 */         ix++;
/*      */ 
/* 1485 */         if ((ch2 & 0xC0) != 128) {
/* 1486 */           _reportInvalidOther(ch2);
/*      */         }
/* 1488 */         ch = ch << 6 | ch2 & 0x3F;
/* 1489 */         if (needed > 1) {
/* 1490 */           ch2 = quads[(ix >> 2)];
/* 1491 */           byteIx = ix & 0x3;
/* 1492 */           ch2 >>= 3 - byteIx << 3;
/* 1493 */           ix++;
/*      */ 
/* 1495 */           if ((ch2 & 0xC0) != 128) {
/* 1496 */             _reportInvalidOther(ch2);
/*      */           }
/* 1498 */           ch = ch << 6 | ch2 & 0x3F;
/* 1499 */           if (needed > 2) {
/* 1500 */             ch2 = quads[(ix >> 2)];
/* 1501 */             byteIx = ix & 0x3;
/* 1502 */             ch2 >>= 3 - byteIx << 3;
/* 1503 */             ix++;
/* 1504 */             if ((ch2 & 0xC0) != 128) {
/* 1505 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 1507 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           }
/*      */         }
/* 1510 */         if (needed > 2) {
/* 1511 */           ch -= 65536;
/* 1512 */           if (cix >= cbuf.length) {
/* 1513 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 1515 */           cbuf[(cix++)] = ((char)(55296 + (ch >> 10)));
/* 1516 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         }
/*      */       }
/* 1519 */       if (cix >= cbuf.length) {
/* 1520 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1522 */       cbuf[(cix++)] = ((char)ch);
/*      */     }
/*      */ 
/* 1526 */     String baseName = new String(cbuf, 0, cix);
/*      */ 
/* 1528 */     if (lastQuadBytes < 4) {
/* 1529 */       quads[(quadLen - 1)] = lastQuad;
/*      */     }
/* 1531 */     return this._symbols.addName(baseName, quads, quadLen);
/*      */   }
/*      */ 
/*      */   private final void _handleLongFieldName()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1537 */     byte[] inBuf = this._inputBuffer;
/* 1538 */     int quads = 0;
/* 1539 */     int bytes = 0;
/* 1540 */     int q = 0;
/*      */     while (true)
/*      */     {
/* 1543 */       byte b = inBuf[(this._inputPtr++)];
/* 1544 */       if (-4 == b) {
/* 1545 */         bytes = 0;
/* 1546 */         break;
/*      */       }
/* 1548 */       q = b & 0xFF;
/* 1549 */       b = inBuf[(this._inputPtr++)];
/* 1550 */       if (-4 == b) {
/* 1551 */         bytes = 1;
/* 1552 */         break;
/*      */       }
/* 1554 */       q = q << 8 | b & 0xFF;
/* 1555 */       b = inBuf[(this._inputPtr++)];
/* 1556 */       if (-4 == b) {
/* 1557 */         bytes = 2;
/* 1558 */         break;
/*      */       }
/* 1560 */       q = q << 8 | b & 0xFF;
/* 1561 */       b = inBuf[(this._inputPtr++)];
/* 1562 */       if (-4 == b) {
/* 1563 */         bytes = 3;
/* 1564 */         break;
/*      */       }
/* 1566 */       q = q << 8 | b & 0xFF;
/* 1567 */       if (quads >= this._quadBuffer.length) {
/* 1568 */         this._quadBuffer = _growArrayTo(this._quadBuffer, this._quadBuffer.length + 256);
/*      */       }
/* 1570 */       this._quadBuffer[(quads++)] = q;
/*      */     }
/*      */ 
/* 1573 */     int byteLen = quads << 2;
/* 1574 */     if (bytes > 0) {
/* 1575 */       if (quads >= this._quadBuffer.length) {
/* 1576 */         this._quadBuffer = _growArrayTo(this._quadBuffer, this._quadBuffer.length + 256);
/*      */       }
/* 1578 */       this._quadBuffer[(quads++)] = q;
/* 1579 */       byteLen += bytes;
/*      */     }
/*      */ 
/* 1584 */     Name n = this._symbols.findName(this._quadBuffer, quads);
/*      */     String name;
/*      */     String name;
/* 1585 */     if (n != null)
/* 1586 */       name = n.getName();
/*      */     else {
/* 1588 */       name = _decodeLongUnicodeName(this._quadBuffer, byteLen, quads).getName();
/*      */     }
/* 1590 */     if (this._seenNames != null) {
/* 1591 */       if (this._seenNameCount >= this._seenNames.length) {
/* 1592 */         this._seenNames = _expandSeenNames(this._seenNames);
/*      */       }
/* 1594 */       this._seenNames[(this._seenNameCount++)] = name;
/*      */     }
/* 1596 */     this._parsingContext.setCurrentName(name);
/*      */   }
/*      */ 
/*      */   private final Name _findDecodedFromSymbols(int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1606 */     if (this._inputEnd - this._inputPtr < len) {
/* 1607 */       _loadToHaveAtLeast(len);
/*      */     }
/*      */ 
/* 1610 */     if (len < 5) {
/* 1611 */       int inPtr = this._inputPtr;
/* 1612 */       byte[] inBuf = this._inputBuffer;
/* 1613 */       int q = inBuf[inPtr] & 0xFF;
/* 1614 */       len--; if (len > 0) {
/* 1615 */         q = (q << 8) + (inBuf[(++inPtr)] & 0xFF);
/* 1616 */         len--; if (len > 0) {
/* 1617 */           q = (q << 8) + (inBuf[(++inPtr)] & 0xFF);
/* 1618 */           len--; if (len > 0) {
/* 1619 */             q = (q << 8) + (inBuf[(++inPtr)] & 0xFF);
/*      */           }
/*      */         }
/*      */       }
/* 1623 */       this._quad1 = q;
/* 1624 */       return this._symbols.findName(q);
/*      */     }
/* 1626 */     if (len < 9) {
/* 1627 */       int inPtr = this._inputPtr;
/* 1628 */       byte[] inBuf = this._inputBuffer;
/*      */ 
/* 1630 */       int q1 = (inBuf[inPtr] & 0xFF) << 8;
/* 1631 */       q1 += (inBuf[(++inPtr)] & 0xFF);
/* 1632 */       q1 <<= 8;
/* 1633 */       q1 += (inBuf[(++inPtr)] & 0xFF);
/* 1634 */       q1 <<= 8;
/* 1635 */       q1 += (inBuf[(++inPtr)] & 0xFF);
/* 1636 */       int q2 = inBuf[(++inPtr)] & 0xFF;
/* 1637 */       len -= 5;
/* 1638 */       if (len > 0) {
/* 1639 */         q2 = (q2 << 8) + (inBuf[(++inPtr)] & 0xFF);
/* 1640 */         len--; if (len > 0) {
/* 1641 */           q2 = (q2 << 8) + (inBuf[(++inPtr)] & 0xFF);
/* 1642 */           len--; if (len > 0) {
/* 1643 */             q2 = (q2 << 8) + (inBuf[(++inPtr)] & 0xFF);
/*      */           }
/*      */         }
/*      */       }
/* 1647 */       this._quad1 = q1;
/* 1648 */       this._quad2 = q2;
/* 1649 */       return this._symbols.findName(q1, q2);
/*      */     }
/* 1651 */     return _findDecodedMedium(len);
/*      */   }
/*      */ 
/*      */   private final Name _findDecodedMedium(int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1662 */     int bufLen = len + 3 >> 2;
/* 1663 */     if (bufLen > this._quadBuffer.length) {
/* 1664 */       this._quadBuffer = _growArrayTo(this._quadBuffer, bufLen);
/*      */     }
/*      */ 
/* 1668 */     int offset = 0;
/* 1669 */     int inPtr = this._inputPtr;
/* 1670 */     byte[] inBuf = this._inputBuffer;
/*      */     do {
/* 1672 */       int q = (inBuf[(inPtr++)] & 0xFF) << 8;
/* 1673 */       q |= inBuf[(inPtr++)] & 0xFF;
/* 1674 */       q <<= 8;
/* 1675 */       q |= inBuf[(inPtr++)] & 0xFF;
/* 1676 */       q <<= 8;
/* 1677 */       q |= inBuf[(inPtr++)] & 0xFF;
/* 1678 */       this._quadBuffer[(offset++)] = q;
/* 1679 */       len -= 4; } while (len > 3);
/*      */ 
/* 1681 */     if (len > 0) {
/* 1682 */       int q = inBuf[inPtr] & 0xFF;
/* 1683 */       len--; if (len > 0) {
/* 1684 */         q = (q << 8) + (inBuf[(++inPtr)] & 0xFF);
/* 1685 */         len--; if (len > 0) {
/* 1686 */           q = (q << 8) + (inBuf[(++inPtr)] & 0xFF);
/*      */         }
/*      */       }
/* 1689 */       this._quadBuffer[(offset++)] = q;
/*      */     }
/* 1691 */     return this._symbols.findName(this._quadBuffer, offset);
/*      */   }
/*      */ 
/*      */   private static int[] _growArrayTo(int[] arr, int minSize)
/*      */   {
/* 1696 */     int[] newArray = new int[minSize + 4];
/* 1697 */     if (arr != null)
/*      */     {
/* 1699 */       System.arraycopy(arr, 0, newArray, 0, arr.length);
/*      */     }
/* 1701 */     return newArray;
/*      */   }
/*      */ 
/*      */   protected void _parseNumericValue(int expType)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1714 */     if (this._tokenIncomplete) {
/* 1715 */       int tb = this._typeByte;
/*      */ 
/* 1717 */       if ((tb >> 5 & 0x7) != 1) {
/* 1718 */         _reportError("Current token (" + this._currToken + ") not numeric, can not use numeric value accessors");
/*      */       }
/* 1720 */       this._tokenIncomplete = false;
/* 1721 */       _finishNumberToken(tb);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _finishToken()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1732 */     this._tokenIncomplete = false;
/* 1733 */     int tb = this._typeByte;
/*      */ 
/* 1735 */     int type = tb >> 5 & 0x7;
/* 1736 */     if (type == 1) {
/* 1737 */       _finishNumberToken(tb);
/* 1738 */       return;
/*      */     }
/* 1740 */     if (type <= 3) {
/* 1741 */       _decodeShortAsciiValue(1 + (tb & 0x3F));
/* 1742 */       return;
/*      */     }
/* 1744 */     if (type <= 5)
/*      */     {
/* 1746 */       _decodeShortUnicodeValue(2 + (tb & 0x3F));
/* 1747 */       return;
/*      */     }
/* 1749 */     if (type == 7) {
/* 1750 */       tb &= 31;
/*      */ 
/* 1752 */       switch (tb >> 2) {
/*      */       case 0:
/* 1754 */         _decodeLongAscii();
/* 1755 */         return;
/*      */       case 1:
/* 1757 */         _decodeLongUnicode();
/* 1758 */         return;
/*      */       case 2:
/* 1760 */         this._binaryValue = _read7BitBinaryWithLength();
/* 1761 */         return;
/*      */       case 7:
/* 1763 */         _finishRawBinary();
/* 1764 */         return;
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/* 1768 */       case 6: }  } _throwInternal();
/*      */   }
/*      */ 
/*      */   protected final void _finishNumberToken(int tb)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1774 */     tb &= 31;
/* 1775 */     int type = tb >> 2;
/* 1776 */     if (type == 1) {
/* 1777 */       int subtype = tb & 0x3;
/* 1778 */       if (subtype == 0)
/* 1779 */         _finishInt();
/* 1780 */       else if (subtype == 1)
/* 1781 */         _finishLong();
/* 1782 */       else if (subtype == 2)
/* 1783 */         _finishBigInteger();
/*      */       else {
/* 1785 */         _throwInternal();
/*      */       }
/* 1787 */       return;
/*      */     }
/* 1789 */     if (type == 2) {
/* 1790 */       switch (tb & 0x3) {
/*      */       case 0:
/* 1792 */         _finishFloat();
/* 1793 */         return;
/*      */       case 1:
/* 1795 */         _finishDouble();
/* 1796 */         return;
/*      */       case 2:
/* 1798 */         _finishBigDecimal();
/* 1799 */         return;
/*      */       }
/*      */     }
/* 1802 */     _throwInternal();
/*      */   }
/*      */ 
/*      */   private final void _finishInt()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1813 */     if (this._inputPtr >= this._inputEnd) {
/* 1814 */       loadMoreGuaranteed();
/*      */     }
/* 1816 */     int value = this._inputBuffer[(this._inputPtr++)];
/*      */ 
/* 1818 */     if (value < 0) {
/* 1819 */       value &= 63;
/*      */     } else {
/* 1821 */       if (this._inputPtr >= this._inputEnd) {
/* 1822 */         loadMoreGuaranteed();
/*      */       }
/* 1824 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 1825 */       if (i >= 0) {
/* 1826 */         value = (value << 7) + i;
/* 1827 */         if (this._inputPtr >= this._inputEnd) {
/* 1828 */           loadMoreGuaranteed();
/*      */         }
/* 1830 */         i = this._inputBuffer[(this._inputPtr++)];
/* 1831 */         if (i >= 0) {
/* 1832 */           value = (value << 7) + i;
/* 1833 */           if (this._inputPtr >= this._inputEnd) {
/* 1834 */             loadMoreGuaranteed();
/*      */           }
/* 1836 */           i = this._inputBuffer[(this._inputPtr++)];
/* 1837 */           if (i >= 0) {
/* 1838 */             value = (value << 7) + i;
/*      */ 
/* 1840 */             if (this._inputPtr >= this._inputEnd) {
/* 1841 */               loadMoreGuaranteed();
/*      */             }
/* 1843 */             i = this._inputBuffer[(this._inputPtr++)];
/* 1844 */             if (i >= 0) {
/* 1845 */               _reportError("Corrupt input; 32-bit VInt extends beyond 5 data bytes");
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1850 */       value = (value << 6) + (i & 0x3F);
/*      */     }
/* 1852 */     this._numberInt = SmileUtil.zigzagDecode(value);
/* 1853 */     this._numTypesValid = 1;
/*      */   }
/*      */ 
/*      */   private final void _finishLong()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1860 */     long l = _fourBytesToInt();
/*      */     while (true)
/*      */     {
/* 1863 */       if (this._inputPtr >= this._inputEnd) {
/* 1864 */         loadMoreGuaranteed();
/*      */       }
/* 1866 */       int value = this._inputBuffer[(this._inputPtr++)];
/* 1867 */       if (value < 0) {
/* 1868 */         l = (l << 6) + (value & 0x3F);
/* 1869 */         this._numberLong = SmileUtil.zigzagDecode(l);
/* 1870 */         this._numTypesValid = 2;
/* 1871 */         return;
/*      */       }
/* 1873 */       l = (l << 7) + value;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void _finishBigInteger()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1880 */     byte[] raw = _read7BitBinaryWithLength();
/* 1881 */     this._numberBigInt = new BigInteger(raw);
/* 1882 */     this._numTypesValid = 4;
/*      */   }
/*      */ 
/*      */   private final void _finishFloat()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1889 */     int i = _fourBytesToInt();
/* 1890 */     if (this._inputPtr >= this._inputEnd) {
/* 1891 */       loadMoreGuaranteed();
/*      */     }
/* 1893 */     i = (i << 7) + this._inputBuffer[(this._inputPtr++)];
/* 1894 */     float f = Float.intBitsToFloat(i);
/* 1895 */     this._numberDouble = f;
/* 1896 */     this._numTypesValid = 8;
/*      */   }
/*      */ 
/*      */   private final void _finishDouble()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1903 */     long hi = _fourBytesToInt();
/* 1904 */     long value = (hi << 28) + _fourBytesToInt();
/*      */ 
/* 1906 */     if (this._inputPtr >= this._inputEnd) {
/* 1907 */       loadMoreGuaranteed();
/*      */     }
/* 1909 */     value = (value << 7) + this._inputBuffer[(this._inputPtr++)];
/* 1910 */     if (this._inputPtr >= this._inputEnd) {
/* 1911 */       loadMoreGuaranteed();
/*      */     }
/* 1913 */     value = (value << 7) + this._inputBuffer[(this._inputPtr++)];
/* 1914 */     this._numberDouble = Double.longBitsToDouble(value);
/* 1915 */     this._numTypesValid = 8;
/*      */   }
/*      */ 
/*      */   private final int _fourBytesToInt()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1921 */     if (this._inputPtr >= this._inputEnd) {
/* 1922 */       loadMoreGuaranteed();
/*      */     }
/* 1924 */     int i = this._inputBuffer[(this._inputPtr++)];
/* 1925 */     if (this._inputPtr >= this._inputEnd) {
/* 1926 */       loadMoreGuaranteed();
/*      */     }
/* 1928 */     i = (i << 7) + this._inputBuffer[(this._inputPtr++)];
/* 1929 */     if (this._inputPtr >= this._inputEnd) {
/* 1930 */       loadMoreGuaranteed();
/*      */     }
/* 1932 */     i = (i << 7) + this._inputBuffer[(this._inputPtr++)];
/* 1933 */     if (this._inputPtr >= this._inputEnd) {
/* 1934 */       loadMoreGuaranteed();
/*      */     }
/* 1936 */     return (i << 7) + this._inputBuffer[(this._inputPtr++)];
/*      */   }
/*      */ 
/*      */   private final void _finishBigDecimal()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1942 */     int scale = SmileUtil.zigzagDecode(_readUnsignedVInt());
/* 1943 */     byte[] raw = _read7BitBinaryWithLength();
/* 1944 */     this._numberBigDecimal = new BigDecimal(new BigInteger(raw), scale);
/* 1945 */     this._numTypesValid = 16;
/*      */   }
/*      */ 
/*      */   private final int _readUnsignedVInt()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1951 */     int value = 0;
/*      */     while (true) {
/* 1953 */       if (this._inputPtr >= this._inputEnd) {
/* 1954 */         loadMoreGuaranteed();
/*      */       }
/* 1956 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 1957 */       if (i < 0) {
/* 1958 */         value = (value << 6) + (i & 0x3F);
/* 1959 */         return value;
/*      */       }
/* 1961 */       value = (value << 7) + i;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final byte[] _read7BitBinaryWithLength()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1968 */     int byteLen = _readUnsignedVInt();
/* 1969 */     byte[] result = new byte[byteLen];
/* 1970 */     int ptr = 0;
/* 1971 */     int lastOkPtr = byteLen - 7;
/*      */ 
/* 1974 */     while (ptr <= lastOkPtr) {
/* 1975 */       if (this._inputEnd - this._inputPtr < 8) {
/* 1976 */         _loadToHaveAtLeast(8);
/*      */       }
/* 1978 */       int i1 = (this._inputBuffer[(this._inputPtr++)] << 25) + (this._inputBuffer[(this._inputPtr++)] << 18) + (this._inputBuffer[(this._inputPtr++)] << 11) + (this._inputBuffer[(this._inputPtr++)] << 4);
/*      */ 
/* 1982 */       int x = this._inputBuffer[(this._inputPtr++)];
/* 1983 */       i1 += (x >> 3);
/* 1984 */       int i2 = ((x & 0x7) << 21) + (this._inputBuffer[(this._inputPtr++)] << 14) + (this._inputBuffer[(this._inputPtr++)] << 7) + this._inputBuffer[(this._inputPtr++)];
/*      */ 
/* 1989 */       result[(ptr++)] = ((byte)(i1 >> 24));
/* 1990 */       result[(ptr++)] = ((byte)(i1 >> 16));
/* 1991 */       result[(ptr++)] = ((byte)(i1 >> 8));
/* 1992 */       result[(ptr++)] = ((byte)i1);
/* 1993 */       result[(ptr++)] = ((byte)(i2 >> 16));
/* 1994 */       result[(ptr++)] = ((byte)(i2 >> 8));
/* 1995 */       result[(ptr++)] = ((byte)i2);
/*      */     }
/*      */ 
/* 1998 */     int toDecode = result.length - ptr;
/* 1999 */     if (toDecode > 0) {
/* 2000 */       if (this._inputEnd - this._inputPtr < toDecode + 1) {
/* 2001 */         _loadToHaveAtLeast(toDecode + 1);
/*      */       }
/* 2003 */       int value = this._inputBuffer[(this._inputPtr++)];
/* 2004 */       for (int i = 1; i < toDecode; i++) {
/* 2005 */         value = (value << 7) + this._inputBuffer[(this._inputPtr++)];
/* 2006 */         result[(ptr++)] = ((byte)(value >> 7 - i));
/*      */       }
/*      */ 
/* 2009 */       value <<= toDecode;
/* 2010 */       result[ptr] = ((byte)(value + this._inputBuffer[(this._inputPtr++)]));
/*      */     }
/* 2012 */     return result;
/*      */   }
/*      */ 
/*      */   protected final void _decodeShortAsciiValue(int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2024 */     if (this._inputEnd - this._inputPtr < len) {
/* 2025 */       _loadToHaveAtLeast(len);
/*      */     }
/*      */ 
/* 2028 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2029 */     int outPtr = 0;
/* 2030 */     byte[] inBuf = this._inputBuffer;
/* 2031 */     int inPtr = this._inputPtr;
/*      */ 
/* 2055 */     for (int end = inPtr + len; inPtr < end; inPtr++) {
/* 2056 */       outBuf[(outPtr++)] = ((char)inBuf[inPtr]);
/*      */     }
/*      */ 
/* 2059 */     this._inputPtr = inPtr;
/* 2060 */     this._textBuffer.setCurrentLength(len);
/*      */   }
/*      */ 
/*      */   protected final void _decodeShortUnicodeValue(int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2066 */     if (this._inputEnd - this._inputPtr < len) {
/* 2067 */       _loadToHaveAtLeast(len);
/*      */     }
/* 2069 */     int outPtr = 0;
/* 2070 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2071 */     int inPtr = this._inputPtr;
/* 2072 */     this._inputPtr += len;
/* 2073 */     int[] codes = SmileConstants.sUtf8UnitLengths;
/* 2074 */     byte[] inputBuf = this._inputBuffer;
/* 2075 */     for (int end = inPtr + len; inPtr < end; ) {
/* 2076 */       int i = inputBuf[(inPtr++)] & 0xFF;
/* 2077 */       int code = codes[i];
/* 2078 */       if (code != 0)
/*      */       {
/* 2080 */         switch (code) {
/*      */         case 1:
/* 2082 */           i = (i & 0x1F) << 6 | inputBuf[(inPtr++)] & 0x3F;
/* 2083 */           break;
/*      */         case 2:
/* 2085 */           i = (i & 0xF) << 12 | (inputBuf[(inPtr++)] & 0x3F) << 6 | inputBuf[(inPtr++)] & 0x3F;
/*      */ 
/* 2088 */           break;
/*      */         case 3:
/* 2090 */           i = (i & 0x7) << 18 | (inputBuf[(inPtr++)] & 0x3F) << 12 | (inputBuf[(inPtr++)] & 0x3F) << 6 | inputBuf[(inPtr++)] & 0x3F;
/*      */ 
/* 2095 */           i -= 65536;
/* 2096 */           outBuf[(outPtr++)] = ((char)(0xD800 | i >> 10));
/* 2097 */           i = 0xDC00 | i & 0x3FF;
/* 2098 */           break;
/*      */         default:
/* 2100 */           _reportError("Invalid byte " + Integer.toHexString(i) + " in short Unicode text block");
/*      */         }
/*      */       }
/* 2103 */       outBuf[(outPtr++)] = ((char)i);
/*      */     }
/* 2105 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */   private final void _decodeLongAscii()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2111 */     int outPtr = 0;
/* 2112 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     while (true)
/*      */     {
/* 2115 */       if (this._inputPtr >= this._inputEnd) {
/* 2116 */         loadMoreGuaranteed();
/*      */       }
/* 2118 */       int inPtr = this._inputPtr;
/* 2119 */       int left = this._inputEnd - inPtr;
/* 2120 */       if (outPtr >= outBuf.length) {
/* 2121 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2122 */         outPtr = 0;
/*      */       }
/* 2124 */       left = Math.min(left, outBuf.length - outPtr);
/*      */       do {
/* 2126 */         byte b = this._inputBuffer[(inPtr++)];
/* 2127 */         if (b == -4) {
/* 2128 */           this._inputPtr = inPtr;
/* 2129 */           break;
/*      */         }
/* 2131 */         outBuf[(outPtr++)] = ((char)b);
/* 2132 */         left--; } while (left > 0);
/* 2133 */       this._inputPtr = inPtr;
/*      */     }
/* 2135 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */   private final void _decodeLongUnicode()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2141 */     int outPtr = 0;
/* 2142 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2143 */     int[] codes = SmileConstants.sUtf8UnitLengths;
/*      */ 
/* 2145 */     byte[] inputBuffer = this._inputBuffer;
/*      */     while (true)
/*      */     {
/* 2152 */       int ptr = this._inputPtr;
/* 2153 */       if (ptr >= this._inputEnd) {
/* 2154 */         loadMoreGuaranteed();
/* 2155 */         ptr = this._inputPtr;
/*      */       }
/* 2157 */       if (outPtr >= outBuf.length) {
/* 2158 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2159 */         outPtr = 0;
/*      */       }
/* 2161 */       int max = this._inputEnd;
/*      */ 
/* 2163 */       int max2 = ptr + (outBuf.length - outPtr);
/* 2164 */       if (max2 < max) {
/* 2165 */         max = max2;
/*      */       }
/*      */ 
/* 2168 */       while (ptr < max) {
/* 2169 */         int c = inputBuffer[(ptr++)] & 0xFF;
/* 2170 */         if (codes[c] != 0) {
/* 2171 */           this._inputPtr = ptr;
/* 2172 */           break label145;
/*      */         }
/* 2174 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/* 2176 */       this._inputPtr = ptr;
/* 2177 */       continue;
/*      */       label145: int c;
/* 2179 */       if (c == 252)
/*      */       {
/*      */         break;
/*      */       }
/* 2183 */       switch (codes[c]) {
/*      */       case 1:
/* 2185 */         c = _decodeUtf8_2(c);
/* 2186 */         break;
/*      */       case 2:
/* 2188 */         if (this._inputEnd - this._inputPtr >= 2)
/* 2189 */           c = _decodeUtf8_3fast(c);
/*      */         else {
/* 2191 */           c = _decodeUtf8_3(c);
/*      */         }
/* 2193 */         break;
/*      */       case 4:
/* 2195 */         c = _decodeUtf8_4(c);
/*      */ 
/* 2197 */         outBuf[(outPtr++)] = ((char)(0xD800 | c >> 10));
/* 2198 */         if (outPtr >= outBuf.length) {
/* 2199 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2200 */           outPtr = 0;
/*      */         }
/* 2202 */         c = 0xDC00 | c & 0x3FF;
/*      */ 
/* 2204 */         break;
/*      */       case 3:
/*      */       default:
/* 2207 */         _reportInvalidChar(c);
/*      */       }
/*      */ 
/* 2210 */       if (outPtr >= outBuf.length) {
/* 2211 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2212 */         outPtr = 0;
/*      */       }
/*      */ 
/* 2215 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 2217 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */   private final void _finishRawBinary()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2223 */     int byteLen = _readUnsignedVInt();
/* 2224 */     this._binaryValue = new byte[byteLen];
/* 2225 */     if (this._inputPtr >= this._inputEnd) {
/* 2226 */       loadMoreGuaranteed();
/*      */     }
/* 2228 */     int ptr = 0;
/*      */     while (true) {
/* 2230 */       int toAdd = Math.min(byteLen, this._inputEnd - this._inputPtr);
/* 2231 */       System.arraycopy(this._inputBuffer, this._inputPtr, this._binaryValue, ptr, toAdd);
/* 2232 */       this._inputPtr += toAdd;
/* 2233 */       ptr += toAdd;
/* 2234 */       byteLen -= toAdd;
/* 2235 */       if (byteLen <= 0) {
/* 2236 */         return;
/*      */       }
/* 2238 */       loadMoreGuaranteed();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _skipIncomplete()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2254 */     this._tokenIncomplete = false;
/* 2255 */     int tb = this._typeByte;
/* 2256 */     switch (tb >> 5 & 0x7) {
/*      */     case 1:
/* 2258 */       tb &= 31;
/*      */ 
/* 2260 */       switch (tb >> 2)
/*      */       {
/*      */       case 1:
/* 2263 */         switch (tb & 0x3) {
/*      */         case 1:
/* 2265 */           _skipBytes(4);
/*      */         case 0:
/*      */           while (true)
/*      */           {
/* 2269 */             int end = this._inputEnd;
/* 2270 */             byte[] buf = this._inputBuffer;
/* 2271 */             while (this._inputPtr < end) {
/* 2272 */               if (buf[(this._inputPtr++)] < 0) {
/* 2273 */                 return;
/*      */               }
/*      */             }
/* 2276 */             loadMoreGuaranteed();
/*      */           }
/*      */ 
/*      */         case 2:
/* 2280 */           _skip7BitBinary();
/* 2281 */           return;
/*      */         }
/* 2283 */         break;
/*      */       case 2:
/* 2285 */         switch (tb & 0x3) {
/*      */         case 0:
/* 2287 */           _skipBytes(5);
/* 2288 */           return;
/*      */         case 1:
/* 2290 */           _skipBytes(10);
/* 2291 */           return;
/*      */         case 2:
/* 2294 */           _readUnsignedVInt();
/*      */ 
/* 2296 */           _skip7BitBinary();
/*      */           return;
/*      */         }break;
/*      */       }
/* 2301 */       break;
/*      */     case 2:
/*      */     case 3:
/* 2305 */       _skipBytes(1 + (tb & 0x3F));
/* 2306 */       return;
/*      */     case 4:
/*      */     case 5:
/* 2310 */       _skipBytes(2 + (tb & 0x3F));
/* 2311 */       return;
/*      */     case 7:
/* 2313 */       tb &= 31;
/*      */ 
/* 2315 */       switch (tb >> 2)
/*      */       {
/*      */       case 0:
/*      */       case 1:
/*      */         while (true)
/*      */         {
/* 2322 */           int end = this._inputEnd;
/* 2323 */           byte[] buf = this._inputBuffer;
/* 2324 */           while (this._inputPtr < end) {
/* 2325 */             if (buf[(this._inputPtr++)] == -4) {
/* 2326 */               return;
/*      */             }
/*      */           }
/* 2329 */           loadMoreGuaranteed();
/*      */         }
/*      */ 
/*      */       case 2:
/* 2333 */         _skip7BitBinary();
/* 2334 */         return;
/*      */       case 7:
/* 2336 */         _skipBytes(_readUnsignedVInt());
/*      */         return;
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6: } break;
/* 2340 */     case 6: } _throwInternal();
/*      */   }
/*      */ 
/*      */   protected void _skipBytes(int len) throws IOException, JsonParseException
/*      */   {
/*      */     while (true)
/*      */     {
/* 2347 */       int toAdd = Math.min(len, this._inputEnd - this._inputPtr);
/* 2348 */       this._inputPtr += toAdd;
/* 2349 */       len -= toAdd;
/* 2350 */       if (len <= 0) {
/* 2351 */         return;
/*      */       }
/* 2353 */       loadMoreGuaranteed();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void _skip7BitBinary()
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2364 */     int origBytes = _readUnsignedVInt();
/*      */ 
/* 2366 */     int chunks = origBytes / 7;
/* 2367 */     int encBytes = chunks * 8;
/*      */ 
/* 2369 */     origBytes -= 7 * chunks;
/* 2370 */     if (origBytes > 0) {
/* 2371 */       encBytes += 1 + origBytes;
/*      */     }
/* 2373 */     _skipBytes(encBytes);
/*      */   }
/*      */ 
/*      */   private final int _decodeUtf8_2(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2385 */     if (this._inputPtr >= this._inputEnd) {
/* 2386 */       loadMoreGuaranteed();
/*      */     }
/* 2388 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2389 */     if ((d & 0xC0) != 128) {
/* 2390 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2392 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   private final int _decodeUtf8_3(int c1)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2398 */     if (this._inputPtr >= this._inputEnd) {
/* 2399 */       loadMoreGuaranteed();
/*      */     }
/* 2401 */     c1 &= 15;
/* 2402 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2403 */     if ((d & 0xC0) != 128) {
/* 2404 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2406 */     int c = c1 << 6 | d & 0x3F;
/* 2407 */     if (this._inputPtr >= this._inputEnd) {
/* 2408 */       loadMoreGuaranteed();
/*      */     }
/* 2410 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2411 */     if ((d & 0xC0) != 128) {
/* 2412 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2414 */     c = c << 6 | d & 0x3F;
/* 2415 */     return c;
/*      */   }
/*      */ 
/*      */   private final int _decodeUtf8_3fast(int c1)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2421 */     c1 &= 15;
/* 2422 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2423 */     if ((d & 0xC0) != 128) {
/* 2424 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2426 */     int c = c1 << 6 | d & 0x3F;
/* 2427 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2428 */     if ((d & 0xC0) != 128) {
/* 2429 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2431 */     c = c << 6 | d & 0x3F;
/* 2432 */     return c;
/*      */   }
/*      */ 
/*      */   private final int _decodeUtf8_4(int c)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 2442 */     if (this._inputPtr >= this._inputEnd) {
/* 2443 */       loadMoreGuaranteed();
/*      */     }
/* 2445 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 2446 */     if ((d & 0xC0) != 128) {
/* 2447 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2449 */     c = (c & 0x7) << 6 | d & 0x3F;
/*      */ 
/* 2451 */     if (this._inputPtr >= this._inputEnd) {
/* 2452 */       loadMoreGuaranteed();
/*      */     }
/* 2454 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2455 */     if ((d & 0xC0) != 128) {
/* 2456 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2458 */     c = c << 6 | d & 0x3F;
/* 2459 */     if (this._inputPtr >= this._inputEnd) {
/* 2460 */       loadMoreGuaranteed();
/*      */     }
/* 2462 */     d = this._inputBuffer[(this._inputPtr++)];
/* 2463 */     if ((d & 0xC0) != 128) {
/* 2464 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */ 
/* 2470 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidSharedName(int index)
/*      */     throws IOException
/*      */   {
/* 2481 */     if (this._seenNames == null) {
/* 2482 */       _reportError("Encountered shared name reference, even though document header explicitly declared no shared name references are included");
/*      */     }
/* 2484 */     _reportError("Invalid shared name reference " + index + "; only got " + this._seenNameCount + " names in buffer (invalid content)");
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidSharedStringValue(int index) throws IOException
/*      */   {
/* 2489 */     if (this._seenStringValues == null) {
/* 2490 */       _reportError("Encountered shared text value reference, even though document header did not declared shared text value references may be included");
/*      */     }
/* 2492 */     _reportError("Invalid shared text value reference " + index + "; only got " + this._seenStringValueCount + " names in buffer (invalid content)");
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidChar(int c)
/*      */     throws JsonParseException
/*      */   {
/* 2498 */     if (c < 32) {
/* 2499 */       _throwInvalidSpace(c);
/*      */     }
/* 2501 */     _reportInvalidInitial(c);
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidInitial(int mask)
/*      */     throws JsonParseException
/*      */   {
/* 2507 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidOther(int mask)
/*      */     throws JsonParseException
/*      */   {
/* 2513 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */   protected void _reportInvalidOther(int mask, int ptr)
/*      */     throws JsonParseException
/*      */   {
/* 2519 */     this._inputPtr = ptr;
/* 2520 */     _reportInvalidOther(mask);
/*      */   }
/*      */ 
/*      */   public static enum Feature
/*      */   {
/*   32 */     REQUIRE_HEADER(true);
/*      */ 
/*      */     final boolean _defaultState;
/*      */     final int _mask;
/*      */ 
/*      */     public static int collectDefaults()
/*      */     {
/*   44 */       int flags = 0;
/*   45 */       for (Feature f : values()) {
/*   46 */         if (f.enabledByDefault()) {
/*   47 */           flags |= f.getMask();
/*      */         }
/*      */       }
/*   50 */       return flags;
/*      */     }
/*      */ 
/*      */     private Feature(boolean defaultState) {
/*   54 */       this._defaultState = defaultState;
/*   55 */       this._mask = (1 << ordinal());
/*      */     }
/*      */     public boolean enabledByDefault() {
/*   58 */       return this._defaultState; } 
/*   59 */     public int getMask() { return this._mask; }
/*      */ 
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.smile.SmileParser
 * JD-Core Version:    0.6.2
 */