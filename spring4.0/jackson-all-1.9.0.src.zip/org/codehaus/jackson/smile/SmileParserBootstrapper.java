/*     */ package org.codehaus.jackson.smile;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.codehaus.jackson.JsonLocation;
/*     */ import org.codehaus.jackson.JsonParseException;
/*     */ import org.codehaus.jackson.JsonParser.Feature;
/*     */ import org.codehaus.jackson.ObjectCodec;
/*     */ import org.codehaus.jackson.format.InputAccessor;
/*     */ import org.codehaus.jackson.format.MatchStrength;
/*     */ import org.codehaus.jackson.io.IOContext;
/*     */ import org.codehaus.jackson.sym.BytesToNameCanonicalizer;
/*     */ 
/*     */ public class SmileParserBootstrapper
/*     */ {
/*     */   final IOContext _context;
/*     */   final InputStream _in;
/*     */   final byte[] _inputBuffer;
/*     */   private int _inputPtr;
/*     */   private int _inputEnd;
/*     */   private final boolean _bufferRecyclable;
/*     */   protected int _inputProcessed;
/*     */ 
/*     */   public SmileParserBootstrapper(IOContext ctxt, InputStream in)
/*     */   {
/*  78 */     this._context = ctxt;
/*  79 */     this._in = in;
/*  80 */     this._inputBuffer = ctxt.allocReadIOBuffer();
/*  81 */     this._inputEnd = (this._inputPtr = 0);
/*  82 */     this._inputProcessed = 0;
/*  83 */     this._bufferRecyclable = true;
/*     */   }
/*     */ 
/*     */   public SmileParserBootstrapper(IOContext ctxt, byte[] inputBuffer, int inputStart, int inputLen)
/*     */   {
/*  88 */     this._context = ctxt;
/*  89 */     this._in = null;
/*  90 */     this._inputBuffer = inputBuffer;
/*  91 */     this._inputPtr = inputStart;
/*  92 */     this._inputEnd = (inputStart + inputLen);
/*     */ 
/*  94 */     this._inputProcessed = (-inputStart);
/*  95 */     this._bufferRecyclable = false;
/*     */   }
/*     */ 
/*     */   public SmileParser constructParser(int generalParserFeatures, int smileFeatures, ObjectCodec codec, BytesToNameCanonicalizer rootByteSymbols)
/*     */     throws IOException, JsonParseException
/*     */   {
/* 102 */     boolean intern = JsonParser.Feature.INTERN_FIELD_NAMES.enabledIn(generalParserFeatures);
/* 103 */     BytesToNameCanonicalizer can = rootByteSymbols.makeChild(true, intern);
/*     */ 
/* 105 */     ensureLoaded(1);
/* 106 */     SmileParser p = new SmileParser(this._context, generalParserFeatures, smileFeatures, codec, can, this._in, this._inputBuffer, this._inputPtr, this._inputEnd, this._bufferRecyclable);
/*     */ 
/* 109 */     boolean hadSig = false;
/* 110 */     if ((this._inputPtr < this._inputEnd) && 
/* 111 */       (this._inputBuffer[this._inputPtr] == 58))
/*     */     {
/* 113 */       hadSig = p.handleSignature(true, true);
/*     */     }
/*     */ 
/* 116 */     if ((!hadSig) && ((smileFeatures & SmileParser.Feature.REQUIRE_HEADER.getMask()) != 0))
/*     */     {
/* 120 */       byte firstByte = this._inputPtr < this._inputEnd ? this._inputBuffer[this._inputPtr] : 0;
/*     */       String msg;
/*     */       String msg;
/* 121 */       if ((firstByte == 123) || (firstByte == 91)) {
/* 122 */         msg = "Input does not start with Smile format header (first byte = 0x" + Integer.toHexString(firstByte & 0xFF) + ") -- rather, it starts with '" + (char)firstByte + "' (plain JSON input?) -- can not parse";
/*     */       }
/*     */       else
/*     */       {
/* 126 */         msg = "Input does not start with Smile format header (first byte = 0x" + Integer.toHexString(firstByte & 0xFF) + ") and parser has REQUIRE_HEADER enabled: can not parse";
/*     */       }
/*     */ 
/* 129 */       throw new JsonParseException(msg, JsonLocation.NA);
/*     */     }
/* 131 */     return p;
/*     */   }
/*     */ 
/*     */   public static MatchStrength hasSmileFormat(InputAccessor acc)
/*     */     throws IOException
/*     */   {
/* 148 */     if (!acc.hasMoreBytes()) {
/* 149 */       return MatchStrength.INCONCLUSIVE;
/*     */     }
/*     */ 
/* 152 */     byte b1 = acc.nextByte();
/* 153 */     if (!acc.hasMoreBytes()) {
/* 154 */       return MatchStrength.INCONCLUSIVE;
/*     */     }
/* 156 */     byte b2 = acc.nextByte();
/*     */ 
/* 159 */     if (b1 == 58) {
/* 160 */       if (b2 != 41) {
/* 161 */         return MatchStrength.NO_MATCH;
/*     */       }
/* 163 */       if (!acc.hasMoreBytes()) {
/* 164 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/* 166 */       return acc.nextByte() == 10 ? MatchStrength.FULL_MATCH : MatchStrength.NO_MATCH;
/*     */     }
/*     */ 
/* 170 */     if (b1 == -6)
/*     */     {
/* 174 */       if (b2 == 52) {
/* 175 */         return MatchStrength.SOLID_MATCH;
/*     */       }
/* 177 */       int ch = b2 & 0xFF;
/* 178 */       if ((ch >= 128) && (ch < 248)) {
/* 179 */         return MatchStrength.SOLID_MATCH;
/*     */       }
/* 181 */       return MatchStrength.NO_MATCH;
/*     */     }
/*     */ 
/* 184 */     if (b1 == -8) {
/* 185 */       if (!acc.hasMoreBytes()) {
/* 186 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/*     */ 
/* 191 */       if ((likelySmileValue(b2)) || (possibleSmileValue(b2, true))) {
/* 192 */         return MatchStrength.SOLID_MATCH;
/*     */       }
/* 194 */       return MatchStrength.NO_MATCH;
/*     */     }
/*     */ 
/* 197 */     if ((likelySmileValue(b1)) || (possibleSmileValue(b2, false))) {
/* 198 */       return MatchStrength.SOLID_MATCH;
/*     */     }
/* 200 */     return MatchStrength.NO_MATCH;
/*     */   }
/*     */ 
/*     */   private static boolean likelySmileValue(byte b)
/*     */   {
/* 205 */     int ch = b & 0xFF;
/* 206 */     if (ch >= 224) {
/* 207 */       switch (ch) {
/*     */       case -8:
/*     */       case -6:
/*     */       case 224:
/*     */       case 228:
/*     */       case 232:
/* 213 */         return true;
/*     */       }
/*     */ 
/* 216 */       return false;
/*     */     }
/*     */ 
/* 219 */     if ((ch >= 128) && (ch <= 159)) {
/* 220 */       return true;
/*     */     }
/* 222 */     return false;
/*     */   }
/*     */ 
/*     */   private static boolean possibleSmileValue(byte b, boolean lenient)
/*     */   {
/* 231 */     int ch = b & 0xFF;
/*     */ 
/* 233 */     if (ch >= 128) {
/* 234 */       return ch <= 224;
/*     */     }
/* 236 */     if (lenient) {
/* 237 */       if (ch >= 64) {
/* 238 */         return true;
/*     */       }
/* 240 */       if (ch > -32) {
/* 241 */         return ch < 44;
/*     */       }
/*     */     }
/* 244 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean ensureLoaded(int minimum)
/*     */     throws IOException
/*     */   {
/* 256 */     if (this._in == null) {
/* 257 */       return false;
/*     */     }
/*     */ 
/* 263 */     int gotten = this._inputEnd - this._inputPtr;
/* 264 */     while (gotten < minimum) {
/* 265 */       int count = this._in.read(this._inputBuffer, this._inputEnd, this._inputBuffer.length - this._inputEnd);
/* 266 */       if (count < 1) {
/* 267 */         return false;
/*     */       }
/* 269 */       this._inputEnd += count;
/* 270 */       gotten += count;
/*     */     }
/* 272 */     return true;
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.smile.SmileParserBootstrapper
 * JD-Core Version:    0.6.2
 */