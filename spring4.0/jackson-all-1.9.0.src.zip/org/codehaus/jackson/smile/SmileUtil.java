/*    */ package org.codehaus.jackson.smile;
/*    */ 
/*    */ public class SmileUtil
/*    */ {
/*    */   public static int zigzagEncode(int input)
/*    */   {
/* 12 */     if (input < 0) {
/* 13 */       return input << 1 ^ 0xFFFFFFFF;
/*    */     }
/* 15 */     return input << 1;
/*    */   }
/*    */ 
/*    */   public static int zigzagDecode(int encoded)
/*    */   {
/* 21 */     if ((encoded & 0x1) == 0) {
/* 22 */       return encoded >>> 1;
/*    */     }
/*    */ 
/* 25 */     return encoded >>> 1 ^ 0xFFFFFFFF;
/*    */   }
/*    */ 
/*    */   public static long zigzagEncode(long input)
/*    */   {
/* 31 */     if (input < 0L) {
/* 32 */       return input << 1 ^ 0xFFFFFFFF;
/*    */     }
/* 34 */     return input << 1;
/*    */   }
/*    */ 
/*    */   public static long zigzagDecode(long encoded)
/*    */   {
/* 40 */     if ((encoded & 1L) == 0L) {
/* 41 */       return encoded >>> 1;
/*    */     }
/*    */ 
/* 44 */     return encoded >>> 1 ^ 0xFFFFFFFF;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.smile.SmileUtil
 * JD-Core Version:    0.6.2
 */