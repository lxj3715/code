/*     */ package org.codehaus.jackson.smile;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonParser;
/*     */ import org.codehaus.jackson.JsonToken;
/*     */ 
/*     */ public class Tool
/*     */ {
/*     */   public static final String SUFFIX = ".lzf";
/*     */   public final JsonFactory jsonFactory;
/*     */   public final SmileFactory smileFactory;
/*     */ 
/*     */   public Tool()
/*     */   {
/*  26 */     this.jsonFactory = new JsonFactory();
/*  27 */     this.smileFactory = new SmileFactory();
/*     */ 
/*  29 */     this.smileFactory.configure(SmileGenerator.Feature.CHECK_SHARED_NAMES, true);
/*  30 */     this.smileFactory.configure(SmileGenerator.Feature.CHECK_SHARED_STRING_VALUES, true);
/*  31 */     this.smileFactory.configure(SmileGenerator.Feature.ENCODE_BINARY_AS_7BIT, true);
/*  32 */     this.smileFactory.configure(SmileGenerator.Feature.WRITE_HEADER, true);
/*  33 */     this.smileFactory.configure(SmileGenerator.Feature.WRITE_END_MARKER, false);
/*     */ 
/*  35 */     this.smileFactory.configure(SmileParser.Feature.REQUIRE_HEADER, false);
/*     */   }
/*     */ 
/*     */   private void process(String[] args) throws IOException
/*     */   {
/*  40 */     String oper = null;
/*  41 */     String filename = null;
/*     */ 
/*  43 */     if (args.length == 2) {
/*  44 */       oper = args[0];
/*  45 */       filename = args[1];
/*  46 */     } else if (args.length == 1) {
/*  47 */       oper = args[0];
/*     */     } else {
/*  49 */       showUsage();
/*     */     }
/*     */ 
/*  52 */     boolean encode = "-e".equals(oper);
/*  53 */     if (encode)
/*  54 */       encode(inputStream(filename));
/*  55 */     else if ("-d".equals(oper))
/*  56 */       decode(inputStream(filename));
/*  57 */     else if ("-v".equals(oper))
/*     */     {
/*  59 */       verify(inputStream(filename), inputStream(filename));
/*     */     }
/*  61 */     else showUsage();
/*     */   }
/*     */ 
/*     */   private InputStream inputStream(String filename)
/*     */     throws IOException
/*     */   {
/*  68 */     if (filename == null) {
/*  69 */       return System.in;
/*     */     }
/*  71 */     File src = new File(filename);
/*  72 */     if (!src.exists()) {
/*  73 */       System.err.println("File '" + filename + "' does not exist.");
/*  74 */       System.exit(1);
/*     */     }
/*  76 */     return new FileInputStream(src);
/*     */   }
/*     */ 
/*     */   private void decode(InputStream in) throws IOException
/*     */   {
/*  81 */     JsonParser jp = this.smileFactory.createJsonParser(in);
/*  82 */     JsonGenerator jg = this.jsonFactory.createJsonGenerator(System.out, JsonEncoding.UTF8);
/*     */ 
/*  88 */     while ((jp.nextToken() != null) || 
/*  89 */       (jp.nextToken() != null))
/*     */     {
/*  93 */       jg.copyCurrentEvent(jp);
/*     */     }
/*  95 */     jp.close();
/*  96 */     jg.close();
/*     */   }
/*     */ 
/*     */   private void encode(InputStream in) throws IOException
/*     */   {
/* 101 */     JsonParser jp = this.jsonFactory.createJsonParser(in);
/* 102 */     JsonGenerator jg = this.smileFactory.createJsonGenerator(System.out, JsonEncoding.UTF8);
/* 103 */     while (jp.nextToken() != null) {
/* 104 */       jg.copyCurrentEvent(jp);
/*     */     }
/* 106 */     jp.close();
/* 107 */     jg.close();
/*     */   }
/*     */ 
/*     */   private void verify(InputStream in, InputStream in2) throws IOException
/*     */   {
/* 112 */     JsonParser jp = this.jsonFactory.createJsonParser(in);
/* 113 */     ByteArrayOutputStream bytes = new ByteArrayOutputStream(4000);
/* 114 */     JsonGenerator jg = this.smileFactory.createJsonGenerator(bytes, JsonEncoding.UTF8);
/*     */ 
/* 117 */     while (jp.nextToken() != null) {
/* 118 */       jg.copyCurrentEvent(jp);
/*     */     }
/* 120 */     jp.close();
/* 121 */     jg.close();
/*     */ 
/* 124 */     jp = this.jsonFactory.createJsonParser(in2);
/* 125 */     byte[] smile = bytes.toByteArray();
/* 126 */     JsonParser jp2 = this.smileFactory.createJsonParser(smile);
/*     */ 
/* 129 */     int count = 0;
/*     */     JsonToken t;
/* 130 */     while ((t = jp.nextToken()) != null) {
/* 131 */       JsonToken t2 = jp2.nextToken();
/* 132 */       count++;
/* 133 */       if (t != t2) {
/* 134 */         throw new IOException("Input and encoded differ, token #" + count + "; expected " + t + ", got " + t2);
/*     */       }
/*     */ 
/* 137 */       String text1 = jp.getText();
/* 138 */       String text2 = jp2.getText();
/* 139 */       if (!text1.equals(text2)) {
/* 140 */         throw new IOException("Input and encoded differ, token #" + count + "; expected text '" + text1 + "', got '" + text2 + "'");
/*     */       }
/*     */     }
/*     */ 
/* 144 */     System.out.println("OK: verified " + count + " tokens (from " + smile.length + " bytes of Smile encoded data), input and encoded contents are identical");
/*     */   }
/*     */ 
/*     */   protected void showUsage()
/*     */   {
/* 149 */     System.err.println("Usage: java " + getClass().getName() + " -e/-d [file]");
/* 150 */     System.err.println(" (if no file given, reads from stdin -- always writes to stdout)");
/* 151 */     System.err.println(" -d: decode Smile encoded input as JSON");
/* 152 */     System.err.println(" -e: encode JSON (text) input as Smile");
/* 153 */     System.err.println(" -v: encode JSON (text) input as Smile; read back, verify, do not write out");
/* 154 */     System.exit(1);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws IOException {
/* 158 */     new Tool().process(args);
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.smile.Tool
 * JD-Core Version:    0.6.2
 */