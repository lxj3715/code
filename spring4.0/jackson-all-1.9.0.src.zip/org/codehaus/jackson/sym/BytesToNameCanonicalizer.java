/*     */ package org.codehaus.jackson.sym;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.codehaus.jackson.util.InternCache;
/*     */ 
/*     */ public final class BytesToNameCanonicalizer
/*     */ {
/*     */   protected static final int DEFAULT_TABLE_SIZE = 64;
/*     */   protected static final int MAX_TABLE_SIZE = 65536;
/*     */   static final int MAX_ENTRIES_FOR_REUSE = 6000;
/*     */   static final int MIN_HASH_SIZE = 16;
/*     */   static final int INITIAL_COLLISION_LEN = 32;
/*     */   static final int LAST_VALID_BUCKET = 254;
/*     */   final BytesToNameCanonicalizer _parent;
/*     */   final boolean _intern;
/*     */   private int _count;
/*     */   private int _mainHashMask;
/*     */   private int[] _mainHash;
/*     */   private Name[] _mainNames;
/*     */   private Bucket[] _collList;
/*     */   private int _collCount;
/*     */   private int _collEnd;
/*     */   private transient boolean _needRehash;
/*     */   private boolean _mainHashShared;
/*     */   private boolean _mainNamesShared;
/*     */   private boolean _collListShared;
/*     */ 
/*     */   public static BytesToNameCanonicalizer createRoot()
/*     */   {
/* 167 */     return new BytesToNameCanonicalizer(64, true);
/*     */   }
/*     */ 
/*     */   public synchronized BytesToNameCanonicalizer makeChild(boolean canonicalize, boolean intern)
/*     */   {
/* 177 */     return new BytesToNameCanonicalizer(this, intern);
/*     */   }
/*     */ 
/*     */   public void release()
/*     */   {
/* 189 */     if ((maybeDirty()) && (this._parent != null)) {
/* 190 */       this._parent.mergeChild(this);
/*     */ 
/* 195 */       markAsShared();
/*     */     }
/*     */   }
/*     */ 
/*     */   private BytesToNameCanonicalizer(int hashSize, boolean intern)
/*     */   {
/* 201 */     this._parent = null;
/* 202 */     this._intern = intern;
/*     */ 
/* 206 */     if (hashSize < 16) {
/* 207 */       hashSize = 16;
/*     */     }
/* 212 */     else if ((hashSize & hashSize - 1) != 0) {
/* 213 */       int curr = 16;
/* 214 */       while (curr < hashSize) {
/* 215 */         curr += curr;
/*     */       }
/* 217 */       hashSize = curr;
/*     */     }
/*     */ 
/* 220 */     initTables(hashSize);
/*     */   }
/*     */ 
/*     */   private BytesToNameCanonicalizer(BytesToNameCanonicalizer parent, boolean intern)
/*     */   {
/* 228 */     this._parent = parent;
/* 229 */     this._intern = intern;
/*     */ 
/* 232 */     this._count = parent._count;
/* 233 */     this._mainHashMask = parent._mainHashMask;
/* 234 */     this._mainHash = parent._mainHash;
/* 235 */     this._mainNames = parent._mainNames;
/* 236 */     this._collList = parent._collList;
/* 237 */     this._collCount = parent._collCount;
/* 238 */     this._collEnd = parent._collEnd;
/* 239 */     this._needRehash = false;
/*     */ 
/* 241 */     this._mainHashShared = true;
/* 242 */     this._mainNamesShared = true;
/* 243 */     this._collListShared = true;
/*     */   }
/*     */ 
/*     */   private void initTables(int hashSize)
/*     */   {
/* 248 */     this._count = 0;
/* 249 */     this._mainHash = new int[hashSize];
/* 250 */     this._mainNames = new Name[hashSize];
/* 251 */     this._mainHashShared = false;
/* 252 */     this._mainNamesShared = false;
/* 253 */     this._mainHashMask = (hashSize - 1);
/*     */ 
/* 255 */     this._collListShared = true;
/* 256 */     this._collList = null;
/* 257 */     this._collEnd = 0;
/*     */ 
/* 259 */     this._needRehash = false;
/*     */   }
/*     */ 
/*     */   private synchronized void mergeChild(BytesToNameCanonicalizer child)
/*     */   {
/* 265 */     int childCount = child._count;
/* 266 */     if (childCount <= this._count) {
/* 267 */       return;
/*     */     }
/*     */ 
/* 276 */     if (child.size() > 6000)
/*     */     {
/* 282 */       initTables(64);
/*     */     } else {
/* 284 */       this._count = child._count;
/* 285 */       this._mainHash = child._mainHash;
/* 286 */       this._mainNames = child._mainNames;
/* 287 */       this._mainHashShared = true;
/* 288 */       this._mainNamesShared = true;
/* 289 */       this._mainHashMask = child._mainHashMask;
/* 290 */       this._collList = child._collList;
/* 291 */       this._collCount = child._collCount;
/* 292 */       this._collEnd = child._collEnd;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void markAsShared()
/*     */   {
/* 298 */     this._mainHashShared = true;
/* 299 */     this._mainNamesShared = true;
/* 300 */     this._collListShared = true;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 309 */     return this._count;
/*     */   }
/*     */ 
/*     */   public boolean maybeDirty()
/*     */   {
/* 318 */     return !this._mainHashShared;
/*     */   }
/*     */ 
/*     */   public static Name getEmptyName()
/*     */   {
/* 323 */     return Name1.getEmptyName();
/*     */   }
/*     */ 
/*     */   public Name findName(int firstQuad)
/*     */   {
/* 343 */     int hash = calcHash(firstQuad);
/* 344 */     int ix = hash & this._mainHashMask;
/* 345 */     int val = this._mainHash[ix];
/*     */ 
/* 350 */     if ((val >> 8 ^ hash) << 8 == 0)
/*     */     {
/* 352 */       Name name = this._mainNames[ix];
/* 353 */       if (name == null) {
/* 354 */         return null;
/*     */       }
/* 356 */       if (name.equals(firstQuad))
/* 357 */         return name;
/*     */     }
/* 359 */     else if (val == 0) {
/* 360 */       return null;
/*     */     }
/*     */ 
/* 363 */     val &= 255;
/* 364 */     if (val > 0) {
/* 365 */       val--;
/* 366 */       Bucket bucket = this._collList[val];
/* 367 */       if (bucket != null) {
/* 368 */         return bucket.find(hash, firstQuad, 0);
/*     */       }
/*     */     }
/*     */ 
/* 372 */     return null;
/*     */   }
/*     */ 
/*     */   public Name findName(int firstQuad, int secondQuad)
/*     */   {
/* 393 */     int hash = calcHash(firstQuad, secondQuad);
/* 394 */     int ix = hash & this._mainHashMask;
/* 395 */     int val = this._mainHash[ix];
/*     */ 
/* 400 */     if ((val >> 8 ^ hash) << 8 == 0)
/*     */     {
/* 402 */       Name name = this._mainNames[ix];
/* 403 */       if (name == null) {
/* 404 */         return null;
/*     */       }
/* 406 */       if (name.equals(firstQuad, secondQuad))
/* 407 */         return name;
/*     */     }
/* 409 */     else if (val == 0) {
/* 410 */       return null;
/*     */     }
/*     */ 
/* 413 */     val &= 255;
/* 414 */     if (val > 0) {
/* 415 */       val--;
/* 416 */       Bucket bucket = this._collList[val];
/* 417 */       if (bucket != null) {
/* 418 */         return bucket.find(hash, firstQuad, secondQuad);
/*     */       }
/*     */     }
/*     */ 
/* 422 */     return null;
/*     */   }
/*     */ 
/*     */   public Name findName(int[] quads, int qlen)
/*     */   {
/* 449 */     int hash = calcHash(quads, qlen);
/*     */ 
/* 451 */     int ix = hash & this._mainHashMask;
/* 452 */     int val = this._mainHash[ix];
/* 453 */     if ((val >> 8 ^ hash) << 8 == 0) {
/* 454 */       Name name = this._mainNames[ix];
/* 455 */       if ((name == null) || (name.equals(quads, qlen)))
/*     */       {
/* 457 */         return name;
/*     */       }
/* 459 */     } else if (val == 0) {
/* 460 */       return null;
/*     */     }
/* 462 */     val &= 255;
/* 463 */     if (val > 0) {
/* 464 */       val--;
/* 465 */       Bucket bucket = this._collList[val];
/* 466 */       if (bucket != null) {
/* 467 */         return bucket.find(hash, quads, qlen);
/*     */       }
/*     */     }
/* 470 */     return null;
/*     */   }
/*     */ 
/*     */   public Name addName(String symbolStr, int q1, int q2)
/*     */   {
/* 484 */     if (this._intern) {
/* 485 */       symbolStr = InternCache.instance.intern(symbolStr);
/*     */     }
/* 487 */     int hash = q2 == 0 ? calcHash(q1) : calcHash(q1, q2);
/* 488 */     Name symbol = constructName(hash, symbolStr, q1, q2);
/* 489 */     _addSymbol(hash, symbol);
/* 490 */     return symbol;
/*     */   }
/*     */ 
/*     */   public Name addName(String symbolStr, int[] quads, int qlen)
/*     */   {
/* 495 */     if (this._intern) {
/* 496 */       symbolStr = InternCache.instance.intern(symbolStr);
/*     */     }
/* 498 */     int hash = calcHash(quads, qlen);
/* 499 */     Name symbol = constructName(hash, symbolStr, quads, qlen);
/* 500 */     _addSymbol(hash, symbol);
/* 501 */     return symbol;
/*     */   }
/*     */ 
/*     */   public static final int calcHash(int firstQuad)
/*     */   {
/* 512 */     int hash = firstQuad;
/* 513 */     hash ^= hash >>> 16;
/* 514 */     hash ^= hash >>> 8;
/* 515 */     return hash;
/*     */   }
/*     */ 
/*     */   public static final int calcHash(int firstQuad, int secondQuad)
/*     */   {
/* 520 */     int hash = firstQuad * 31 + secondQuad;
/*     */ 
/* 525 */     hash ^= hash >>> 16;
/* 526 */     hash ^= hash >>> 8;
/* 527 */     return hash;
/*     */   }
/*     */ 
/*     */   public static final int calcHash(int[] quads, int qlen)
/*     */   {
/* 533 */     int hash = quads[0];
/* 534 */     for (int i = 1; i < qlen; i++) {
/* 535 */       hash = hash * 31 + quads[i];
/*     */     }
/*     */ 
/* 538 */     hash ^= hash >>> 16;
/* 539 */     hash ^= hash >>> 8;
/*     */ 
/* 541 */     return hash;
/*     */   }
/*     */ 
/*     */   private void _addSymbol(int hash, Name symbol)
/*     */   {
/* 623 */     if (this._mainHashShared) {
/* 624 */       unshareMain();
/*     */     }
/*     */ 
/* 627 */     if (this._needRehash) {
/* 628 */       rehash();
/*     */     }
/*     */ 
/* 631 */     this._count += 1;
/*     */ 
/* 636 */     int ix = hash & this._mainHashMask;
/* 637 */     if (this._mainNames[ix] == null) {
/* 638 */       this._mainHash[ix] = (hash << 8);
/* 639 */       if (this._mainNamesShared) {
/* 640 */         unshareNames();
/*     */       }
/* 642 */       this._mainNames[ix] = symbol;
/*     */     }
/*     */     else
/*     */     {
/* 647 */       if (this._collListShared) {
/* 648 */         unshareCollision();
/*     */       }
/*     */ 
/* 651 */       this._collCount += 1;
/* 652 */       int entryValue = this._mainHash[ix];
/* 653 */       int bucket = entryValue & 0xFF;
/* 654 */       if (bucket == 0) {
/* 655 */         if (this._collEnd <= 254) {
/* 656 */           bucket = this._collEnd;
/* 657 */           this._collEnd += 1;
/*     */ 
/* 659 */           if (bucket >= this._collList.length)
/* 660 */             expandCollision();
/*     */         }
/*     */         else {
/* 663 */           bucket = findBestBucket();
/*     */         }
/*     */ 
/* 666 */         this._mainHash[ix] = (entryValue & 0xFFFFFF00 | bucket + 1);
/*     */       } else {
/* 668 */         bucket--;
/*     */       }
/*     */ 
/* 672 */       this._collList[bucket] = new Bucket(symbol, this._collList[bucket]);
/*     */     }
/*     */ 
/* 679 */     int hashSize = this._mainHash.length;
/* 680 */     if (this._count > hashSize >> 1) {
/* 681 */       int hashQuarter = hashSize >> 2;
/*     */ 
/* 685 */       if (this._count > hashSize - hashQuarter)
/* 686 */         this._needRehash = true;
/* 687 */       else if (this._collCount >= hashQuarter)
/* 688 */         this._needRehash = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void rehash()
/*     */   {
/* 696 */     this._needRehash = false;
/*     */ 
/* 698 */     this._mainNamesShared = false;
/*     */ 
/* 704 */     int[] oldMainHash = this._mainHash;
/* 705 */     int len = oldMainHash.length;
/* 706 */     int newLen = len + len;
/*     */ 
/* 711 */     if (newLen > 65536) {
/* 712 */       nukeSymbols();
/* 713 */       return;
/*     */     }
/*     */ 
/* 716 */     this._mainHash = new int[newLen];
/* 717 */     this._mainHashMask = (newLen - 1);
/* 718 */     Name[] oldNames = this._mainNames;
/* 719 */     this._mainNames = new Name[newLen];
/* 720 */     int symbolsSeen = 0;
/* 721 */     for (int i = 0; i < len; i++) {
/* 722 */       Name symbol = oldNames[i];
/* 723 */       if (symbol != null) {
/* 724 */         symbolsSeen++;
/* 725 */         int hash = symbol.hashCode();
/* 726 */         int ix = hash & this._mainHashMask;
/* 727 */         this._mainNames[ix] = symbol;
/* 728 */         this._mainHash[ix] = (hash << 8);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 736 */     int oldEnd = this._collEnd;
/* 737 */     if (oldEnd == 0) {
/* 738 */       return;
/*     */     }
/*     */ 
/* 741 */     this._collCount = 0;
/* 742 */     this._collEnd = 0;
/* 743 */     this._collListShared = false;
/*     */ 
/* 745 */     Bucket[] oldBuckets = this._collList;
/* 746 */     this._collList = new Bucket[oldBuckets.length];
/* 747 */     for (int i = 0; i < oldEnd; i++) {
/* 748 */       for (Bucket curr = oldBuckets[i]; curr != null; curr = curr._next) {
/* 749 */         symbolsSeen++;
/* 750 */         Name symbol = curr._name;
/* 751 */         int hash = symbol.hashCode();
/* 752 */         int ix = hash & this._mainHashMask;
/* 753 */         int val = this._mainHash[ix];
/* 754 */         if (this._mainNames[ix] == null) {
/* 755 */           this._mainHash[ix] = (hash << 8);
/* 756 */           this._mainNames[ix] = symbol;
/*     */         } else {
/* 758 */           this._collCount += 1;
/* 759 */           int bucket = val & 0xFF;
/* 760 */           if (bucket == 0) {
/* 761 */             if (this._collEnd <= 254) {
/* 762 */               bucket = this._collEnd;
/* 763 */               this._collEnd += 1;
/*     */ 
/* 765 */               if (bucket >= this._collList.length)
/* 766 */                 expandCollision();
/*     */             }
/*     */             else {
/* 769 */               bucket = findBestBucket();
/*     */             }
/*     */ 
/* 772 */             this._mainHash[ix] = (val & 0xFFFFFF00 | bucket + 1);
/*     */           } else {
/* 774 */             bucket--;
/*     */           }
/*     */ 
/* 777 */           this._collList[bucket] = new Bucket(symbol, this._collList[bucket]);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 782 */     if (symbolsSeen != this._count)
/* 783 */       throw new RuntimeException("Internal error: count after rehash " + symbolsSeen + "; should be " + this._count);
/*     */   }
/*     */ 
/*     */   private void nukeSymbols()
/*     */   {
/* 793 */     this._count = 0;
/* 794 */     Arrays.fill(this._mainHash, 0);
/* 795 */     Arrays.fill(this._mainNames, null);
/* 796 */     Arrays.fill(this._collList, null);
/* 797 */     this._collCount = 0;
/* 798 */     this._collEnd = 0;
/*     */   }
/*     */ 
/*     */   private int findBestBucket()
/*     */   {
/* 808 */     Bucket[] buckets = this._collList;
/* 809 */     int bestCount = 2147483647;
/* 810 */     int bestIx = -1;
/*     */ 
/* 812 */     int i = 0; for (int len = this._collEnd; i < len; i++) {
/* 813 */       int count = buckets[i].length();
/* 814 */       if (count < bestCount) {
/* 815 */         if (count == 1) {
/* 816 */           return i;
/*     */         }
/* 818 */         bestCount = count;
/* 819 */         bestIx = i;
/*     */       }
/*     */     }
/* 822 */     return bestIx;
/*     */   }
/*     */ 
/*     */   private void unshareMain()
/*     */   {
/* 833 */     int[] old = this._mainHash;
/* 834 */     int len = this._mainHash.length;
/*     */ 
/* 836 */     this._mainHash = new int[len];
/* 837 */     System.arraycopy(old, 0, this._mainHash, 0, len);
/* 838 */     this._mainHashShared = false;
/*     */   }
/*     */ 
/*     */   private void unshareCollision()
/*     */   {
/* 843 */     Bucket[] old = this._collList;
/* 844 */     if (old == null) {
/* 845 */       this._collList = new Bucket[32];
/*     */     } else {
/* 847 */       int len = old.length;
/* 848 */       this._collList = new Bucket[len];
/* 849 */       System.arraycopy(old, 0, this._collList, 0, len);
/*     */     }
/* 851 */     this._collListShared = false;
/*     */   }
/*     */ 
/*     */   private void unshareNames()
/*     */   {
/* 856 */     Name[] old = this._mainNames;
/* 857 */     int len = old.length;
/* 858 */     this._mainNames = new Name[len];
/* 859 */     System.arraycopy(old, 0, this._mainNames, 0, len);
/* 860 */     this._mainNamesShared = false;
/*     */   }
/*     */ 
/*     */   private void expandCollision()
/*     */   {
/* 865 */     Bucket[] old = this._collList;
/* 866 */     int len = old.length;
/* 867 */     this._collList = new Bucket[len + len];
/* 868 */     System.arraycopy(old, 0, this._collList, 0, len);
/*     */   }
/*     */ 
/*     */   private static Name constructName(int hash, String name, int q1, int q2)
/*     */   {
/* 880 */     if (q2 == 0) {
/* 881 */       return new Name1(name, hash, q1);
/*     */     }
/* 883 */     return new Name2(name, hash, q1, q2);
/*     */   }
/*     */ 
/*     */   private static Name constructName(int hash, String name, int[] quads, int qlen)
/*     */   {
/* 888 */     if (qlen < 4) {
/* 889 */       switch (qlen) {
/*     */       case 1:
/* 891 */         return new Name1(name, hash, quads[0]);
/*     */       case 2:
/* 893 */         return new Name2(name, hash, quads[0], quads[1]);
/*     */       case 3:
/* 895 */         return new Name3(name, hash, quads[0], quads[1], quads[2]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 900 */     int[] buf = new int[qlen];
/* 901 */     for (int i = 0; i < qlen; i++) {
/* 902 */       buf[i] = quads[i];
/*     */     }
/* 904 */     return new NameN(name, hash, buf, qlen);
/*     */   }
/*     */ 
/*     */   static final class Bucket
/*     */   {
/*     */     protected final Name _name;
/*     */     protected final Bucket _next;
/*     */ 
/*     */     Bucket(Name name, Bucket next)
/*     */     {
/* 920 */       this._name = name;
/* 921 */       this._next = next;
/*     */     }
/*     */ 
/*     */     public int length()
/*     */     {
/* 926 */       int len = 1;
/* 927 */       for (Bucket curr = this._next; curr != null; curr = curr._next) {
/* 928 */         len++;
/*     */       }
/* 930 */       return len;
/*     */     }
/*     */ 
/*     */     public Name find(int hash, int firstQuad, int secondQuad)
/*     */     {
/* 935 */       if ((this._name.hashCode() == hash) && 
/* 936 */         (this._name.equals(firstQuad, secondQuad))) {
/* 937 */         return this._name;
/*     */       }
/*     */ 
/* 940 */       for (Bucket curr = this._next; curr != null; curr = curr._next) {
/* 941 */         Name currName = curr._name;
/* 942 */         if ((currName.hashCode() == hash) && 
/* 943 */           (currName.equals(firstQuad, secondQuad))) {
/* 944 */           return currName;
/*     */         }
/*     */       }
/*     */ 
/* 948 */       return null;
/*     */     }
/*     */ 
/*     */     public Name find(int hash, int[] quads, int qlen)
/*     */     {
/* 953 */       if ((this._name.hashCode() == hash) && 
/* 954 */         (this._name.equals(quads, qlen))) {
/* 955 */         return this._name;
/*     */       }
/*     */ 
/* 958 */       for (Bucket curr = this._next; curr != null; curr = curr._next) {
/* 959 */         Name currName = curr._name;
/* 960 */         if ((currName.hashCode() == hash) && 
/* 961 */           (currName.equals(quads, qlen))) {
/* 962 */           return currName;
/*     */         }
/*     */       }
/*     */ 
/* 966 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.sym.BytesToNameCanonicalizer
 * JD-Core Version:    0.6.2
 */