/*    */ package org.codehaus.jackson.xc;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.activation.DataHandler;
/*    */ import javax.activation.DataSource;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.deser.std.StdScalarDeserializer;
/*    */ 
/*    */ public class DataHandlerJsonDeserializer extends StdScalarDeserializer<DataHandler>
/*    */ {
/*    */   public DataHandlerJsonDeserializer()
/*    */   {
/* 22 */     super(DataHandler.class);
/*    */   }
/*    */ 
/*    */   public DataHandler deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 28 */     final byte[] value = jp.getBinaryValue();
/* 29 */     return new DataHandler(new DataSource()
/*    */     {
/*    */       public InputStream getInputStream()
/*    */         throws IOException
/*    */       {
/* 34 */         return new ByteArrayInputStream(value);
/*    */       }
/*    */ 
/*    */       public OutputStream getOutputStream()
/*    */         throws IOException
/*    */       {
/* 40 */         throw new IOException();
/*    */       }
/*    */ 
/*    */       public String getContentType()
/*    */       {
/* 46 */         return "application/octet-stream";
/*    */       }
/*    */ 
/*    */       public String getName()
/*    */       {
/* 52 */         return "json-binary-data";
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.xc.DataHandlerJsonDeserializer
 * JD-Core Version:    0.6.2
 */