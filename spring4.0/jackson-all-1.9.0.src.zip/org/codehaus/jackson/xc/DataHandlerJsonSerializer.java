/*    */ package org.codehaus.jackson.xc;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.activation.DataHandler;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.ser.std.SerializerBase;
/*    */ import org.codehaus.jackson.node.ObjectNode;
/*    */ 
/*    */ public class DataHandlerJsonSerializer extends SerializerBase<DataHandler>
/*    */ {
/*    */   public DataHandlerJsonSerializer()
/*    */   {
/* 22 */     super(DataHandler.class);
/*    */   }
/*    */ 
/*    */   public void serialize(DataHandler value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 28 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*    */ 
/* 37 */     byte[] buffer = new byte[4096];
/* 38 */     InputStream in = value.getInputStream();
/* 39 */     int len = in.read(buffer);
/* 40 */     while (len > 0) {
/* 41 */       out.write(buffer, 0, len);
/* 42 */       len = in.read(buffer);
/*    */     }
/* 44 */     jgen.writeBinary(out.toByteArray());
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */   {
/* 50 */     ObjectNode o = createSchemaNode("array", true);
/* 51 */     ObjectNode itemSchema = createSchemaNode("string");
/* 52 */     o.put("items", itemSchema);
/* 53 */     return o;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.xc.DataHandlerJsonSerializer
 * JD-Core Version:    0.6.2
 */