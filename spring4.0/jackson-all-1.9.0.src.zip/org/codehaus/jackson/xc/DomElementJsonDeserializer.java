/*    */ package org.codehaus.jackson.xc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import javax.xml.parsers.ParserConfigurationException;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.deser.std.StdDeserializer;
/*    */ import org.codehaus.jackson.node.ArrayNode;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class DomElementJsonDeserializer extends StdDeserializer<Element>
/*    */ {
/*    */   private final DocumentBuilder builder;
/*    */ 
/*    */   public DomElementJsonDeserializer()
/*    */   {
/* 29 */     super(Element.class);
/*    */     try {
/* 31 */       DocumentBuilderFactory bf = DocumentBuilderFactory.newInstance();
/* 32 */       bf.setNamespaceAware(true);
/* 33 */       this.builder = bf.newDocumentBuilder();
/*    */     } catch (ParserConfigurationException e) {
/* 35 */       throw new RuntimeException();
/*    */     }
/*    */   }
/*    */ 
/*    */   public DomElementJsonDeserializer(DocumentBuilder builder)
/*    */   {
/* 41 */     super(Element.class);
/* 42 */     this.builder = builder;
/*    */   }
/*    */ 
/*    */   public Element deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 49 */     Document document = this.builder.newDocument();
/* 50 */     return fromNode(document, jp.readValueAsTree());
/*    */   }
/*    */ 
/*    */   protected Element fromNode(Document document, JsonNode jsonNode)
/*    */     throws IOException
/*    */   {
/* 56 */     String ns = jsonNode.get("namespace") != null ? jsonNode.get("namespace").asText() : null;
/* 57 */     String name = jsonNode.get("name") != null ? jsonNode.get("name").asText() : null;
/* 58 */     if (name == null) {
/* 59 */       throw new JsonMappingException("No name for DOM element was provided in the JSON object.");
/*    */     }
/* 61 */     Element element = document.createElementNS(ns, name);
/*    */ 
/* 63 */     JsonNode attributesNode = jsonNode.get("attributes");
/* 64 */     if ((attributesNode != null) && ((attributesNode instanceof ArrayNode))) {
/* 65 */       Iterator atts = attributesNode.getElements();
/* 66 */       while (atts.hasNext()) {
/* 67 */         JsonNode node = (JsonNode)atts.next();
/* 68 */         ns = node.get("namespace") != null ? node.get("namespace").asText() : null;
/* 69 */         name = node.get("name") != null ? node.get("name").asText() : null;
/* 70 */         String value = node.get("$") != null ? node.get("$").asText() : null;
/*    */ 
/* 72 */         if (name != null) {
/* 73 */           element.setAttributeNS(ns, name, value);
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 78 */     JsonNode childsNode = jsonNode.get("children");
/* 79 */     if ((childsNode != null) && ((childsNode instanceof ArrayNode))) {
/* 80 */       Iterator els = childsNode.getElements();
/* 81 */       while (els.hasNext()) {
/* 82 */         JsonNode node = (JsonNode)els.next();
/* 83 */         name = node.get("name") != null ? node.get("name").asText() : null;
/* 84 */         String value = node.get("$") != null ? node.get("$").asText() : null;
/*    */ 
/* 86 */         if (value != null) {
/* 87 */           element.appendChild(document.createTextNode(value));
/*    */         }
/* 89 */         else if (name != null) {
/* 90 */           element.appendChild(fromNode(document, node));
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 95 */     return element;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.xc.DomElementJsonDeserializer
 * JD-Core Version:    0.6.2
 */