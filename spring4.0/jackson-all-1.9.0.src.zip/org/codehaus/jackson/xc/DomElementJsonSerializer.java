/*    */ package org.codehaus.jackson.xc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import org.codehaus.jackson.JsonGenerationException;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.ser.std.SerializerBase;
/*    */ import org.codehaus.jackson.node.ObjectNode;
/*    */ import org.w3c.dom.Attr;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.NamedNodeMap;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ public class DomElementJsonSerializer extends SerializerBase<Element>
/*    */ {
/*    */   public DomElementJsonSerializer()
/*    */   {
/* 21 */     super(Element.class);
/*    */   }
/*    */ 
/*    */   public void serialize(Element value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException, JsonGenerationException
/*    */   {
/* 27 */     jgen.writeStartObject();
/* 28 */     jgen.writeStringField("name", value.getTagName());
/* 29 */     if (value.getNamespaceURI() != null) {
/* 30 */       jgen.writeStringField("namespace", value.getNamespaceURI());
/*    */     }
/* 32 */     NamedNodeMap attributes = value.getAttributes();
/* 33 */     if ((attributes != null) && (attributes.getLength() > 0)) {
/* 34 */       jgen.writeArrayFieldStart("attributes");
/* 35 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 36 */         Attr attribute = (Attr)attributes.item(i);
/* 37 */         jgen.writeStartObject();
/* 38 */         jgen.writeStringField("$", attribute.getValue());
/* 39 */         jgen.writeStringField("name", attribute.getName());
/* 40 */         String ns = attribute.getNamespaceURI();
/* 41 */         if (ns != null) {
/* 42 */           jgen.writeStringField("namespace", ns);
/*    */         }
/* 44 */         jgen.writeEndObject();
/*    */       }
/* 46 */       jgen.writeEndArray();
/*    */     }
/*    */ 
/* 49 */     NodeList children = value.getChildNodes();
/* 50 */     if ((children != null) && (children.getLength() > 0)) {
/* 51 */       jgen.writeArrayFieldStart("children");
/* 52 */       for (int i = 0; i < children.getLength(); i++) {
/* 53 */         Node child = children.item(i);
/* 54 */         switch (child.getNodeType()) {
/*    */         case 3:
/*    */         case 4:
/* 57 */           jgen.writeStartObject();
/* 58 */           jgen.writeStringField("$", child.getNodeValue());
/* 59 */           jgen.writeEndObject();
/* 60 */           break;
/*    */         case 1:
/* 62 */           serialize((Element)child, jgen, provider);
/*    */         case 2:
/*    */         }
/*    */       }
/* 66 */       jgen.writeEndArray();
/*    */     }
/* 68 */     jgen.writeEndObject();
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 75 */     ObjectNode o = createSchemaNode("object", true);
/* 76 */     o.put("name", createSchemaNode("string"));
/* 77 */     o.put("namespace", createSchemaNode("string", true));
/* 78 */     o.put("attributes", createSchemaNode("array", true));
/* 79 */     o.put("children", createSchemaNode("array", true));
/* 80 */     return o;
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.xc.DomElementJsonSerializer
 * JD-Core Version:    0.6.2
 */