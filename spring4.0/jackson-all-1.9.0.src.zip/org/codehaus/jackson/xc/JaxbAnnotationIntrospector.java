/*      */ package org.codehaus.jackson.xc;
/*      */ 
/*      */ import java.beans.Introspector;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.bind.JAXBElement;
/*      */ import javax.xml.bind.annotation.XmlAccessOrder;
/*      */ import javax.xml.bind.annotation.XmlAccessType;
/*      */ import javax.xml.bind.annotation.XmlAccessorOrder;
/*      */ import javax.xml.bind.annotation.XmlAccessorType;
/*      */ import javax.xml.bind.annotation.XmlAttribute;
/*      */ import javax.xml.bind.annotation.XmlElement;
/*      */ import javax.xml.bind.annotation.XmlElement.DEFAULT;
/*      */ import javax.xml.bind.annotation.XmlElementRef;
/*      */ import javax.xml.bind.annotation.XmlElementRefs;
/*      */ import javax.xml.bind.annotation.XmlElementWrapper;
/*      */ import javax.xml.bind.annotation.XmlElements;
/*      */ import javax.xml.bind.annotation.XmlEnumValue;
/*      */ import javax.xml.bind.annotation.XmlRootElement;
/*      */ import javax.xml.bind.annotation.XmlTransient;
/*      */ import javax.xml.bind.annotation.XmlType;
/*      */ import javax.xml.bind.annotation.XmlValue;
/*      */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*      */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*      */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter.DEFAULT;
/*      */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapters;
/*      */ import org.codehaus.jackson.Version;
/*      */ import org.codehaus.jackson.Versioned;
/*      */ import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
/*      */ import org.codehaus.jackson.annotate.JsonTypeInfo.As;
/*      */ import org.codehaus.jackson.annotate.JsonTypeInfo.Id;
/*      */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*      */ import org.codehaus.jackson.map.JsonDeserializer;
/*      */ import org.codehaus.jackson.map.JsonSerializer;
/*      */ import org.codehaus.jackson.map.KeyDeserializer;
/*      */ import org.codehaus.jackson.map.MapperConfig;
/*      */ import org.codehaus.jackson.map.annotate.JsonCachable;
/*      */ import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
/*      */ import org.codehaus.jackson.map.annotate.JsonSerialize.Typing;
/*      */ import org.codehaus.jackson.map.introspect.Annotated;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedClass;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedConstructor;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedField;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedMember;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedMethod;
/*      */ import org.codehaus.jackson.map.introspect.AnnotatedParameter;
/*      */ import org.codehaus.jackson.map.introspect.VisibilityChecker;
/*      */ import org.codehaus.jackson.map.jsontype.NamedType;
/*      */ import org.codehaus.jackson.map.jsontype.TypeResolverBuilder;
/*      */ import org.codehaus.jackson.map.jsontype.impl.StdTypeResolverBuilder;
/*      */ import org.codehaus.jackson.map.util.BeanUtil;
/*      */ import org.codehaus.jackson.map.util.ClassUtil;
/*      */ import org.codehaus.jackson.type.JavaType;
/*      */ import org.codehaus.jackson.util.VersionUtil;
/*      */ 
/*      */ public class JaxbAnnotationIntrospector extends AnnotationIntrospector
/*      */   implements Versioned
/*      */ {
/*      */   protected static final String MARKER_FOR_DEFAULT = "##default";
/*      */   protected final String _jaxbPackageName;
/*      */   protected final JsonSerializer<?> _dataHandlerSerializer;
/*      */   protected final JsonDeserializer<?> _dataHandlerDeserializer;
/*      */ 
/*      */   public JaxbAnnotationIntrospector()
/*      */   {
/*   80 */     this._jaxbPackageName = XmlElement.class.getPackage().getName();
/*      */ 
/*   82 */     JsonSerializer dataHandlerSerializer = null;
/*   83 */     JsonDeserializer dataHandlerDeserializer = null;
/*      */     try
/*      */     {
/*   88 */       dataHandlerSerializer = (JsonSerializer)Class.forName("org.codehaus.jackson.xc.DataHandlerJsonSerializer").newInstance();
/*   89 */       dataHandlerDeserializer = (JsonDeserializer)Class.forName("org.codehaus.jackson.xc.DataHandlerJsonDeserializer").newInstance();
/*      */     }
/*      */     catch (Throwable e) {
/*      */     }
/*   93 */     this._dataHandlerSerializer = dataHandlerSerializer;
/*   94 */     this._dataHandlerDeserializer = dataHandlerDeserializer;
/*      */   }
/*      */ 
/*      */   public Version version()
/*      */   {
/*  105 */     return VersionUtil.versionFor(getClass());
/*      */   }
/*      */ 
/*      */   public boolean isHandled(Annotation ann)
/*      */   {
/*  127 */     Class cls = ann.annotationType();
/*  128 */     Package pkg = cls.getPackage();
/*  129 */     String pkgName = pkg != null ? pkg.getName() : cls.getName();
/*  130 */     if (pkgName.startsWith(this._jaxbPackageName)) {
/*  131 */       return true;
/*      */     }
/*      */ 
/*  134 */     if (cls == JsonCachable.class) {
/*  135 */       return true;
/*      */     }
/*  137 */     return false;
/*      */   }
/*      */ 
/*      */   public Boolean findCachability(AnnotatedClass ac)
/*      */   {
/*  153 */     JsonCachable ann = (JsonCachable)ac.getAnnotation(JsonCachable.class);
/*  154 */     if (ann != null) {
/*  155 */       return ann.value() ? Boolean.TRUE : Boolean.FALSE;
/*      */     }
/*  157 */     return null;
/*      */   }
/*      */ 
/*      */   public String findRootName(AnnotatedClass ac)
/*      */   {
/*  163 */     XmlRootElement elem = findRootElementAnnotation(ac);
/*  164 */     if (elem != null) {
/*  165 */       String name = elem.name();
/*      */ 
/*  167 */       return "##default".equals(name) ? "" : name;
/*      */     }
/*  169 */     return null;
/*      */   }
/*      */ 
/*      */   public String[] findPropertiesToIgnore(AnnotatedClass ac)
/*      */   {
/*  175 */     return null;
/*      */   }
/*      */ 
/*      */   public Boolean findIgnoreUnknownProperties(AnnotatedClass ac)
/*      */   {
/*  186 */     return null;
/*      */   }
/*      */ 
/*      */   public Boolean isIgnorableType(AnnotatedClass ac)
/*      */   {
/*  192 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean hasIgnoreMarker(AnnotatedMember m)
/*      */   {
/*  203 */     return m.getAnnotation(XmlTransient.class) != null;
/*      */   }
/*      */ 
/*      */   public VisibilityChecker<?> findAutoDetectVisibility(AnnotatedClass ac, VisibilityChecker<?> checker)
/*      */   {
/*  216 */     XmlAccessType at = findAccessType(ac);
/*  217 */     if (at == null)
/*      */     {
/*  224 */       return checker;
/*      */     }
/*      */ 
/*  228 */     switch (1.$SwitchMap$javax$xml$bind$annotation$XmlAccessType[at.ordinal()]) {
/*      */     case 1:
/*  230 */       return checker.withFieldVisibility(JsonAutoDetect.Visibility.ANY).withSetterVisibility(JsonAutoDetect.Visibility.NONE).withGetterVisibility(JsonAutoDetect.Visibility.NONE).withIsGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*      */     case 2:
/*  236 */       return checker.withFieldVisibility(JsonAutoDetect.Visibility.NONE).withSetterVisibility(JsonAutoDetect.Visibility.NONE).withGetterVisibility(JsonAutoDetect.Visibility.NONE).withIsGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*      */     case 3:
/*  242 */       return checker.withFieldVisibility(JsonAutoDetect.Visibility.NONE).withSetterVisibility(JsonAutoDetect.Visibility.PUBLIC_ONLY).withGetterVisibility(JsonAutoDetect.Visibility.PUBLIC_ONLY).withIsGetterVisibility(JsonAutoDetect.Visibility.PUBLIC_ONLY);
/*      */     case 4:
/*  248 */       return checker.withFieldVisibility(JsonAutoDetect.Visibility.PUBLIC_ONLY).withSetterVisibility(JsonAutoDetect.Visibility.PUBLIC_ONLY).withGetterVisibility(JsonAutoDetect.Visibility.PUBLIC_ONLY).withIsGetterVisibility(JsonAutoDetect.Visibility.PUBLIC_ONLY);
/*      */     }
/*      */ 
/*  254 */     return checker;
/*      */   }
/*      */ 
/*      */   protected XmlAccessType findAccessType(Annotated ac)
/*      */   {
/*  265 */     XmlAccessorType at = (XmlAccessorType)findAnnotation(XmlAccessorType.class, ac, true, true, true);
/*  266 */     return at == null ? null : at.value();
/*      */   }
/*      */ 
/*      */   public TypeResolverBuilder<?> findTypeResolver(MapperConfig<?> config, AnnotatedClass ac, JavaType baseType)
/*      */   {
/*  280 */     return null;
/*      */   }
/*      */ 
/*      */   public TypeResolverBuilder<?> findPropertyTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType)
/*      */   {
/*  290 */     if (baseType.isContainerType()) return null;
/*  291 */     return _typeResolverFromXmlElements(am);
/*      */   }
/*      */ 
/*      */   public TypeResolverBuilder<?> findPropertyContentTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType containerType)
/*      */   {
/*  301 */     if (!containerType.isContainerType()) {
/*  302 */       throw new IllegalArgumentException("Must call method with a container type (got " + containerType + ")");
/*      */     }
/*  304 */     return _typeResolverFromXmlElements(am);
/*      */   }
/*      */ 
/*      */   protected TypeResolverBuilder<?> _typeResolverFromXmlElements(AnnotatedMember am)
/*      */   {
/*  314 */     XmlElements elems = (XmlElements)findAnnotation(XmlElements.class, am, false, false, false);
/*  315 */     XmlElementRefs elemRefs = (XmlElementRefs)findAnnotation(XmlElementRefs.class, am, false, false, false);
/*  316 */     if ((elems == null) && (elemRefs == null)) {
/*  317 */       return null;
/*      */     }
/*      */ 
/*  320 */     TypeResolverBuilder b = new StdTypeResolverBuilder();
/*      */ 
/*  322 */     b = b.init(JsonTypeInfo.Id.NAME, null);
/*      */ 
/*  324 */     b = b.inclusion(JsonTypeInfo.As.WRAPPER_OBJECT);
/*  325 */     return b;
/*      */   }
/*      */ 
/*      */   public List<NamedType> findSubtypes(Annotated a)
/*      */   {
/*  332 */     XmlElements elems = (XmlElements)findAnnotation(XmlElements.class, a, false, false, false);
/*  333 */     if (elems != null) {
/*  334 */       ArrayList result = new ArrayList();
/*  335 */       for (XmlElement elem : elems.value()) {
/*  336 */         String name = elem.name();
/*  337 */         if ("##default".equals(name)) name = null;
/*  338 */         result.add(new NamedType(elem.type(), name));
/*      */       }
/*  340 */       return result;
/*      */     }
/*      */ 
/*  343 */     XmlElementRefs elemRefs = (XmlElementRefs)findAnnotation(XmlElementRefs.class, a, false, false, false);
/*  344 */     if (elemRefs != null) {
/*  345 */       ArrayList result = new ArrayList();
/*  346 */       for (XmlElementRef elemRef : elemRefs.value()) {
/*  347 */         Class refType = elemRef.type();
/*      */ 
/*  349 */         if (!JAXBElement.class.isAssignableFrom(refType))
/*      */         {
/*  351 */           String name = elemRef.name();
/*  352 */           if ((name == null) || ("##default".equals(name))) {
/*  353 */             XmlRootElement rootElement = (XmlRootElement)refType.getAnnotation(XmlRootElement.class);
/*  354 */             if (rootElement != null) {
/*  355 */               name = rootElement.name();
/*      */             }
/*      */           }
/*  358 */           if ((name == null) || ("##default".equals(name))) {
/*  359 */             name = Introspector.decapitalize(refType.getSimpleName());
/*      */           }
/*  361 */           result.add(new NamedType(refType, name));
/*      */         }
/*      */       }
/*  364 */       return result;
/*      */     }
/*      */ 
/*  367 */     return null;
/*      */   }
/*      */ 
/*      */   public String findTypeName(AnnotatedClass ac)
/*      */   {
/*  372 */     XmlType type = (XmlType)findAnnotation(XmlType.class, ac, false, false, false);
/*  373 */     if (type != null) {
/*  374 */       String name = type.name();
/*  375 */       if (!"##default".equals(name)) return name;
/*      */     }
/*  377 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isIgnorableMethod(AnnotatedMethod m)
/*      */   {
/*  389 */     return m.getAnnotation(XmlTransient.class) != null;
/*      */   }
/*      */ 
/*      */   public boolean isIgnorableConstructor(AnnotatedConstructor c)
/*      */   {
/*  399 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isIgnorableField(AnnotatedField f)
/*      */   {
/*  411 */     return f.getAnnotation(XmlTransient.class) != null;
/*      */   }
/*      */ 
/*      */   public JsonSerializer<?> findSerializer(Annotated am)
/*      */   {
/*  423 */     XmlAdapter adapter = findAdapter(am, true);
/*  424 */     if (adapter != null) {
/*  425 */       return new XmlAdapterJsonSerializer(adapter);
/*      */     }
/*      */ 
/*  428 */     Class type = am.getRawType();
/*  429 */     if ((type != null) && 
/*  430 */       (this._dataHandlerSerializer != null) && (isDataHandler(type))) {
/*  431 */       return this._dataHandlerSerializer;
/*      */     }
/*      */ 
/*  434 */     return null;
/*      */   }
/*      */ 
/*      */   private boolean isDataHandler(Class<?> type)
/*      */   {
/*  446 */     return (type != null) && (Object.class != type) && (("javax.activation.DataHandler".equals(type.getName())) || (isDataHandler(type.getSuperclass())));
/*      */   }
/*      */ 
/*      */   public Class<?> findSerializationType(Annotated a)
/*      */   {
/*  458 */     XmlElement annotation = (XmlElement)findAnnotation(XmlElement.class, a, false, false, false);
/*  459 */     if ((annotation == null) || (annotation.type() == XmlElement.DEFAULT.class)) {
/*  460 */       return null;
/*      */     }
/*      */ 
/*  467 */     Class rawPropType = a.getRawType();
/*  468 */     if (isIndexedType(rawPropType)) {
/*  469 */       return null;
/*      */     }
/*      */ 
/*  478 */     Class allegedType = annotation.type();
/*  479 */     if (a.getAnnotation(XmlJavaTypeAdapter.class) != null) {
/*  480 */       return null;
/*      */     }
/*  482 */     return allegedType;
/*      */   }
/*      */ 
/*      */   public JsonSerialize.Inclusion findSerializationInclusion(Annotated a, JsonSerialize.Inclusion defValue)
/*      */   {
/*  493 */     XmlElementWrapper w = (XmlElementWrapper)a.getAnnotation(XmlElementWrapper.class);
/*  494 */     if (w != null) {
/*  495 */       return w.nillable() ? JsonSerialize.Inclusion.ALWAYS : JsonSerialize.Inclusion.NON_NULL;
/*      */     }
/*  497 */     XmlElement e = (XmlElement)a.getAnnotation(XmlElement.class);
/*  498 */     if (e != null) {
/*  499 */       return e.nillable() ? JsonSerialize.Inclusion.ALWAYS : JsonSerialize.Inclusion.NON_NULL;
/*      */     }
/*      */ 
/*  504 */     return defValue;
/*      */   }
/*      */ 
/*      */   public JsonSerialize.Typing findSerializationTyping(Annotated a)
/*      */   {
/*  510 */     return null;
/*      */   }
/*      */ 
/*      */   public Class<?>[] findSerializationViews(Annotated a)
/*      */   {
/*  517 */     return null;
/*      */   }
/*      */ 
/*      */   public String[] findSerializationPropertyOrder(AnnotatedClass ac)
/*      */   {
/*  530 */     XmlType type = (XmlType)findAnnotation(XmlType.class, ac, true, true, true);
/*  531 */     if (type == null) {
/*  532 */       return null;
/*      */     }
/*  534 */     String[] order = type.propOrder();
/*  535 */     if ((order == null) || (order.length == 0)) {
/*  536 */       return null;
/*      */     }
/*  538 */     return order;
/*      */   }
/*      */ 
/*      */   public Boolean findSerializationSortAlphabetically(AnnotatedClass ac)
/*      */   {
/*  544 */     XmlAccessorOrder order = (XmlAccessorOrder)findAnnotation(XmlAccessorOrder.class, ac, true, true, true);
/*  545 */     return order == null ? null : Boolean.valueOf(order.value() == XmlAccessOrder.ALPHABETICAL);
/*      */   }
/*      */ 
/*      */   public String findGettablePropertyName(AnnotatedMethod am)
/*      */   {
/*  557 */     if (!isVisible(am)) {
/*  558 */       return null;
/*      */     }
/*  560 */     String name = findJaxbPropertyName(am, am.getRawType(), BeanUtil.okNameForGetter(am));
/*      */ 
/*  562 */     if (name == null);
/*  564 */     return name;
/*      */   }
/*      */ 
/*      */   public boolean hasAsValueAnnotation(AnnotatedMethod am)
/*      */   {
/*  571 */     return false;
/*      */   }
/*      */ 
/*      */   public String findEnumValue(Enum<?> e)
/*      */   {
/*  583 */     Class enumClass = e.getDeclaringClass();
/*  584 */     String enumValue = e.name();
/*      */     try {
/*  586 */       XmlEnumValue xmlEnumValue = (XmlEnumValue)enumClass.getDeclaredField(enumValue).getAnnotation(XmlEnumValue.class);
/*  587 */       return xmlEnumValue != null ? xmlEnumValue.value() : enumValue;
/*      */     } catch (NoSuchFieldException e1) {
/*  589 */       throw new IllegalStateException("Could not locate Enum entry '" + enumValue + "' (Enum class " + enumClass.getName() + ")", e1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String findSerializablePropertyName(AnnotatedField af)
/*      */   {
/*  602 */     if (!isVisible(af)) {
/*  603 */       return null;
/*      */     }
/*  605 */     String name = findJaxbPropertyName(af, af.getRawType(), null);
/*      */ 
/*  610 */     return name == null ? af.getName() : name;
/*      */   }
/*      */ 
/*      */   public JsonDeserializer<?> findDeserializer(Annotated am)
/*      */   {
/*  622 */     XmlAdapter adapter = findAdapter(am, false);
/*  623 */     if (adapter != null) {
/*  624 */       return new XmlAdapterJsonDeserializer(adapter);
/*      */     }
/*      */ 
/*  630 */     Class type = am.getRawType();
/*  631 */     if ((type != null) && 
/*  632 */       (this._dataHandlerDeserializer != null) && (isDataHandler(type))) {
/*  633 */       return this._dataHandlerDeserializer;
/*      */     }
/*      */ 
/*  637 */     return null;
/*      */   }
/*      */ 
/*      */   public Class<KeyDeserializer> findKeyDeserializer(Annotated am)
/*      */   {
/*  644 */     return null;
/*      */   }
/*      */ 
/*      */   public Class<JsonDeserializer<?>> findContentDeserializer(Annotated am)
/*      */   {
/*  651 */     return null;
/*      */   }
/*      */ 
/*      */   public Class<?> findDeserializationType(Annotated a, JavaType baseType, String propName)
/*      */   {
/*  664 */     if (!baseType.isContainerType()) {
/*  665 */       return _doFindDeserializationType(a, baseType, propName);
/*      */     }
/*  667 */     return null;
/*      */   }
/*      */ 
/*      */   public Class<?> findDeserializationKeyType(Annotated am, JavaType baseKeyType, String propName)
/*      */   {
/*  674 */     return null;
/*      */   }
/*      */ 
/*      */   public Class<?> findDeserializationContentType(Annotated a, JavaType baseContentType, String propName)
/*      */   {
/*  686 */     return _doFindDeserializationType(a, baseContentType, propName);
/*      */   }
/*      */ 
/*      */   protected Class<?> _doFindDeserializationType(Annotated a, JavaType baseType, String propName)
/*      */   {
/*  695 */     if (a.hasAnnotation(XmlJavaTypeAdapter.class)) {
/*  696 */       return null;
/*      */     }
/*      */ 
/*  702 */     XmlElement annotation = (XmlElement)findAnnotation(XmlElement.class, a, false, false, false);
/*  703 */     if (annotation != null) {
/*  704 */       Class type = annotation.type();
/*  705 */       if (type != XmlElement.DEFAULT.class) {
/*  706 */         return type;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  712 */     if (((a instanceof AnnotatedMethod)) && (propName != null)) {
/*  713 */       AnnotatedMethod am = (AnnotatedMethod)a;
/*  714 */       annotation = (XmlElement)findFieldAnnotation(XmlElement.class, am.getDeclaringClass(), propName);
/*  715 */       if ((annotation != null) && (annotation.type() != XmlElement.DEFAULT.class)) {
/*  716 */         return annotation.type();
/*      */       }
/*      */     }
/*  719 */     return null;
/*      */   }
/*      */ 
/*      */   public String findSettablePropertyName(AnnotatedMethod am)
/*      */   {
/*  725 */     if (!isVisible(am)) {
/*  726 */       return null;
/*      */     }
/*  728 */     Class rawType = am.getParameterClass(0);
/*  729 */     String name = findJaxbPropertyName(am, rawType, BeanUtil.okNameForSetter(am));
/*  730 */     return name;
/*      */   }
/*      */ 
/*      */   public boolean hasAnySetterAnnotation(AnnotatedMethod am)
/*      */   {
/*  740 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean hasCreatorAnnotation(Annotated am)
/*      */   {
/*  746 */     return false;
/*      */   }
/*      */ 
/*      */   public String findDeserializablePropertyName(AnnotatedField af)
/*      */   {
/*  752 */     if (!isVisible(af)) {
/*  753 */       return null;
/*      */     }
/*  755 */     String name = findJaxbPropertyName(af, af.getRawType(), null);
/*      */ 
/*  760 */     return name == null ? af.getName() : name;
/*      */   }
/*      */ 
/*      */   public String findPropertyNameForParam(AnnotatedParameter param)
/*      */   {
/*  773 */     return null;
/*      */   }
/*      */ 
/*      */   private boolean isVisible(AnnotatedField f)
/*      */   {
/*  791 */     for (Annotation annotation : f.getAnnotated().getDeclaredAnnotations()) {
/*  792 */       if (isHandled(annotation)) {
/*  793 */         return true;
/*      */       }
/*      */     }
/*  796 */     XmlAccessType accessType = XmlAccessType.PUBLIC_MEMBER;
/*  797 */     XmlAccessorType at = (XmlAccessorType)findAnnotation(XmlAccessorType.class, f, true, true, true);
/*  798 */     if (at != null) {
/*  799 */       accessType = at.value();
/*      */     }
/*  801 */     if (accessType == XmlAccessType.FIELD) {
/*  802 */       return true;
/*      */     }
/*  804 */     if (accessType == XmlAccessType.PUBLIC_MEMBER) {
/*  805 */       return Modifier.isPublic(f.getAnnotated().getModifiers());
/*      */     }
/*  807 */     return false;
/*      */   }
/*      */ 
/*      */   private boolean isVisible(AnnotatedMethod m)
/*      */   {
/*  813 */     for (Annotation annotation : m.getAnnotated().getDeclaredAnnotations()) {
/*  814 */       if (isHandled(annotation)) {
/*  815 */         return true;
/*      */       }
/*      */     }
/*  818 */     XmlAccessType accessType = XmlAccessType.PUBLIC_MEMBER;
/*  819 */     XmlAccessorType at = (XmlAccessorType)findAnnotation(XmlAccessorType.class, m, true, true, true);
/*  820 */     if (at != null) {
/*  821 */       accessType = at.value();
/*      */     }
/*  823 */     if ((accessType == XmlAccessType.PROPERTY) || (accessType == XmlAccessType.PUBLIC_MEMBER)) {
/*  824 */       return Modifier.isPublic(m.getModifiers());
/*      */     }
/*  826 */     return false;
/*      */   }
/*      */ 
/*      */   private <A extends Annotation> A findAnnotation(Class<A> annotationClass, Annotated annotated, boolean includePackage, boolean includeClass, boolean includeSuperclasses)
/*      */   {
/*  844 */     Annotation annotation = annotated.getAnnotation(annotationClass);
/*  845 */     if (annotation != null) {
/*  846 */       return annotation;
/*      */     }
/*  848 */     Class memberClass = null;
/*      */ 
/*  853 */     if ((annotated instanceof AnnotatedParameter)) {
/*  854 */       memberClass = ((AnnotatedParameter)annotated).getDeclaringClass();
/*      */     } else {
/*  856 */       AnnotatedElement annType = annotated.getAnnotated();
/*  857 */       if ((annType instanceof Member)) {
/*  858 */         memberClass = ((Member)annType).getDeclaringClass();
/*  859 */         if (includeClass) {
/*  860 */           annotation = memberClass.getAnnotation(annotationClass);
/*  861 */           if (annotation != null)
/*  862 */             return annotation;
/*      */         }
/*      */       }
/*  865 */       else if ((annType instanceof Class)) {
/*  866 */         memberClass = (Class)annType;
/*      */       } else {
/*  868 */         throw new IllegalStateException("Unsupported annotated member: " + annotated.getClass().getName());
/*      */       }
/*      */     }
/*  871 */     if (memberClass != null) {
/*  872 */       if (includeSuperclasses) {
/*  873 */         Class superclass = memberClass.getSuperclass();
/*  874 */         while ((superclass != null) && (superclass != Object.class)) {
/*  875 */           annotation = superclass.getAnnotation(annotationClass);
/*  876 */           if (annotation != null) {
/*  877 */             return annotation;
/*      */           }
/*  879 */           superclass = superclass.getSuperclass();
/*      */         }
/*      */       }
/*  882 */       if (includePackage) {
/*  883 */         Package pkg = memberClass.getPackage();
/*  884 */         if (pkg != null) {
/*  885 */           return memberClass.getPackage().getAnnotation(annotationClass);
/*      */         }
/*      */       }
/*      */     }
/*  889 */     return null;
/*      */   }
/*      */ 
/*      */   private <A extends Annotation> A findFieldAnnotation(Class<A> annotationType, Class<?> cls, String fieldName)
/*      */   {
/*      */     do
/*      */     {
/*  902 */       for (Field f : cls.getDeclaredFields()) {
/*  903 */         if (fieldName.equals(f.getName())) {
/*  904 */           return f.getAnnotation(annotationType);
/*      */         }
/*      */       }
/*  907 */       if ((cls.isInterface()) || (cls == Object.class)) {
/*      */         break;
/*      */       }
/*  910 */       cls = cls.getSuperclass();
/*  911 */     }while (cls != null);
/*  912 */     return null;
/*      */   }
/*      */ 
/*      */   private static String findJaxbPropertyName(Annotated ae, Class<?> aeType, String defaultName)
/*      */   {
/*  923 */     XmlElementWrapper elementWrapper = (XmlElementWrapper)ae.getAnnotation(XmlElementWrapper.class);
/*  924 */     if (elementWrapper != null) {
/*  925 */       String name = elementWrapper.name();
/*  926 */       if (!"##default".equals(name)) {
/*  927 */         return name;
/*      */       }
/*  929 */       return defaultName;
/*      */     }
/*      */ 
/*  932 */     XmlAttribute attribute = (XmlAttribute)ae.getAnnotation(XmlAttribute.class);
/*  933 */     if (attribute != null) {
/*  934 */       String name = attribute.name();
/*  935 */       if (!"##default".equals(name)) {
/*  936 */         return name;
/*      */       }
/*  938 */       return defaultName;
/*      */     }
/*  940 */     XmlElement element = (XmlElement)ae.getAnnotation(XmlElement.class);
/*  941 */     if (element != null) {
/*  942 */       String name = element.name();
/*  943 */       if (!"##default".equals(name)) {
/*  944 */         return name;
/*      */       }
/*  946 */       return defaultName;
/*      */     }
/*  948 */     XmlElementRef elementRef = (XmlElementRef)ae.getAnnotation(XmlElementRef.class);
/*  949 */     if (elementRef != null) {
/*  950 */       String name = elementRef.name();
/*  951 */       if (!"##default".equals(name)) {
/*  952 */         return name;
/*      */       }
/*  954 */       if (aeType != null) {
/*  955 */         XmlRootElement rootElement = (XmlRootElement)aeType.getAnnotation(XmlRootElement.class);
/*  956 */         if (rootElement != null) {
/*  957 */           name = rootElement.name();
/*  958 */           if (!"##default".equals(name)) {
/*  959 */             return name;
/*      */           }
/*  961 */           return Introspector.decapitalize(aeType.getSimpleName());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  966 */     XmlValue valueInfo = (XmlValue)ae.getAnnotation(XmlValue.class);
/*  967 */     if (valueInfo != null) {
/*  968 */       return "value";
/*      */     }
/*      */ 
/*  971 */     return null;
/*      */   }
/*      */ 
/*      */   private XmlRootElement findRootElementAnnotation(AnnotatedClass ac)
/*      */   {
/*  977 */     return (XmlRootElement)findAnnotation(XmlRootElement.class, ac, true, false, true);
/*      */   }
/*      */ 
/*      */   private XmlAdapter<Object, Object> findAdapter(Annotated am, boolean forSerialization)
/*      */   {
/*  991 */     if ((am instanceof AnnotatedClass)) {
/*  992 */       return findAdapterForClass((AnnotatedClass)am, forSerialization);
/*      */     }
/*      */ 
/*  995 */     Class memberType = am.getRawType();
/*      */ 
/*  997 */     if ((memberType == Void.TYPE) && ((am instanceof AnnotatedMethod))) {
/*  998 */       memberType = ((AnnotatedMethod)am).getParameterClass(0);
/*      */     }
/*      */ 
/* 1002 */     Member member = (Member)am.getAnnotated();
/*      */ 
/* 1004 */     if (member != null) {
/* 1005 */       Class potentialAdaptee = member.getDeclaringClass();
/* 1006 */       if (potentialAdaptee != null) {
/* 1007 */         XmlJavaTypeAdapter adapterInfo = (XmlJavaTypeAdapter)potentialAdaptee.getAnnotation(XmlJavaTypeAdapter.class);
/* 1008 */         if (adapterInfo != null) {
/* 1009 */           XmlAdapter adapter = checkAdapter(adapterInfo, memberType);
/* 1010 */           if (adapter != null) {
/* 1011 */             return adapter;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1017 */     XmlJavaTypeAdapter adapterInfo = (XmlJavaTypeAdapter)findAnnotation(XmlJavaTypeAdapter.class, am, true, false, false);
/* 1018 */     if (adapterInfo != null) {
/* 1019 */       XmlAdapter adapter = checkAdapter(adapterInfo, memberType);
/* 1020 */       if (adapter != null) {
/* 1021 */         return adapter;
/*      */       }
/*      */     }
/* 1024 */     XmlJavaTypeAdapters adapters = (XmlJavaTypeAdapters)findAnnotation(XmlJavaTypeAdapters.class, am, true, false, false);
/* 1025 */     if (adapters != null) {
/* 1026 */       for (XmlJavaTypeAdapter info : adapters.value()) {
/* 1027 */         XmlAdapter adapter = checkAdapter(info, memberType);
/* 1028 */         if (adapter != null) {
/* 1029 */           return adapter;
/*      */         }
/*      */       }
/*      */     }
/* 1033 */     return null;
/*      */   }
/*      */ 
/*      */   private final XmlAdapter<Object, Object> checkAdapter(XmlJavaTypeAdapter adapterInfo, Class<?> typeNeeded)
/*      */   {
/* 1040 */     Class adaptedType = adapterInfo.type();
/* 1041 */     if ((adaptedType == XmlJavaTypeAdapter.DEFAULT.class) || (adaptedType.isAssignableFrom(typeNeeded)))
/*      */     {
/* 1044 */       Class cls = adapterInfo.value();
/* 1045 */       return (XmlAdapter)ClassUtil.createInstance(cls, false);
/*      */     }
/* 1047 */     return null;
/*      */   }
/*      */ 
/*      */   private XmlAdapter<Object, Object> findAdapterForClass(AnnotatedClass ac, boolean forSerialization)
/*      */   {
/* 1058 */     XmlJavaTypeAdapter adapterInfo = (XmlJavaTypeAdapter)ac.getAnnotated().getAnnotation(XmlJavaTypeAdapter.class);
/* 1059 */     if (adapterInfo != null)
/*      */     {
/* 1061 */       Class cls = adapterInfo.value();
/* 1062 */       return (XmlAdapter)ClassUtil.createInstance(cls, false);
/*      */     }
/* 1064 */     return null;
/*      */   }
/*      */ 
/*      */   private boolean isIndexedType(Class<?> raw)
/*      */   {
/* 1073 */     return (raw.isArray()) || (Collection.class.isAssignableFrom(raw)) || (Map.class.isAssignableFrom(raw));
/*      */   }
/*      */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.xc.JaxbAnnotationIntrospector
 * JD-Core Version:    0.6.2
 */