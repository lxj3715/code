/*    */ package org.codehaus.jackson.xc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.codehaus.jackson.JsonParser;
/*    */ import org.codehaus.jackson.JsonProcessingException;
/*    */ import org.codehaus.jackson.map.DeserializationConfig;
/*    */ import org.codehaus.jackson.map.DeserializationContext;
/*    */ import org.codehaus.jackson.map.DeserializerProvider;
/*    */ import org.codehaus.jackson.map.JsonDeserializer;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.TypeDeserializer;
/*    */ import org.codehaus.jackson.map.deser.std.StdDeserializer;
/*    */ import org.codehaus.jackson.map.type.TypeFactory;
/*    */ import org.codehaus.jackson.type.JavaType;
/*    */ 
/*    */ public class XmlAdapterJsonDeserializer extends StdDeserializer<Object>
/*    */ {
/* 20 */   protected static final JavaType ADAPTER_TYPE = TypeFactory.defaultInstance().uncheckedSimpleType(XmlAdapter.class);
/*    */   protected final XmlAdapter<Object, Object> _xmlAdapter;
/*    */   protected final JavaType _valueType;
/*    */   protected JsonDeserializer<?> _deserializer;
/*    */ 
/*    */   public XmlAdapterJsonDeserializer(XmlAdapter<Object, Object> xmlAdapter)
/*    */   {
/* 29 */     super(Object.class);
/* 30 */     this._xmlAdapter = xmlAdapter;
/*    */ 
/* 37 */     TypeFactory typeFactory = TypeFactory.defaultInstance();
/*    */ 
/* 39 */     JavaType type = typeFactory.constructType(xmlAdapter.getClass());
/* 40 */     JavaType[] rawTypes = typeFactory.findTypeParameters(type, XmlAdapter.class);
/* 41 */     this._valueType = ((rawTypes == null) || (rawTypes.length == 0) ? TypeFactory.unknownType() : rawTypes[0]);
/*    */   }
/*    */ 
/*    */   public Object deserialize(JsonParser jp, DeserializationContext ctxt)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 53 */     JsonDeserializer deser = this._deserializer;
/* 54 */     if (deser == null) {
/* 55 */       DeserializationConfig config = ctxt.getConfig();
/* 56 */       this._deserializer = (deser = ctxt.getDeserializerProvider().findValueDeserializer(config, this._valueType, null));
/*    */     }
/*    */ 
/* 59 */     Object boundObject = deser.deserialize(jp, ctxt);
/*    */     try {
/* 61 */       return this._xmlAdapter.unmarshal(boundObject);
/*    */     } catch (Exception e) {
/* 63 */       throw new JsonMappingException("Unable to unmarshal (to type " + this._valueType + "): " + e.getMessage(), e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 73 */     return typeDeserializer.deserializeTypedFromAny(jp, ctxt);
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.xc.XmlAdapterJsonDeserializer
 * JD-Core Version:    0.6.2
 */