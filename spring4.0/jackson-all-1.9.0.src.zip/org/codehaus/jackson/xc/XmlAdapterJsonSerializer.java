/*    */ package org.codehaus.jackson.xc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.codehaus.jackson.JsonGenerator;
/*    */ import org.codehaus.jackson.JsonNode;
/*    */ import org.codehaus.jackson.map.JsonMappingException;
/*    */ import org.codehaus.jackson.map.JsonSerializer;
/*    */ import org.codehaus.jackson.map.SerializerProvider;
/*    */ import org.codehaus.jackson.map.ser.std.SerializerBase;
/*    */ import org.codehaus.jackson.schema.JsonSchema;
/*    */ import org.codehaus.jackson.schema.SchemaAware;
/*    */ 
/*    */ public class XmlAdapterJsonSerializer extends SerializerBase<Object>
/*    */   implements SchemaAware
/*    */ {
/*    */   private final XmlAdapter<Object, Object> xmlAdapter;
/*    */ 
/*    */   public XmlAdapterJsonSerializer(XmlAdapter<Object, Object> xmlAdapter)
/*    */   {
/* 28 */     super(Object.class);
/* 29 */     this.xmlAdapter = xmlAdapter;
/*    */   }
/*    */ 
/*    */   public void serialize(Object value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException
/*    */   {
/*    */     Object adapted;
/*    */     try
/*    */     {
/* 38 */       adapted = this.xmlAdapter.marshal(value);
/*    */     } catch (Exception e) {
/* 40 */       throw new JsonMappingException("Unable to marshal: " + e.getMessage(), e);
/*    */     }
/* 42 */     if (adapted == null) {
/* 43 */       provider.getNullValueSerializer().serialize(null, jgen, provider);
/*    */     } else {
/* 45 */       Class c = adapted.getClass();
/*    */ 
/* 47 */       provider.findTypedValueSerializer(c, true, null).serialize(adapted, jgen, provider);
/*    */     }
/*    */   }
/*    */ 
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 56 */     JsonSerializer ser = provider.findValueSerializer(findValueClass(), null);
/* 57 */     JsonNode schemaNode = (ser instanceof SchemaAware) ? ((SchemaAware)ser).getSchema(provider, null) : JsonSchema.getDefaultSchemaNode();
/*    */ 
/* 60 */     return schemaNode;
/*    */   }
/*    */ 
/*    */   private Class<?> findValueClass()
/*    */   {
/* 65 */     Type superClass = this.xmlAdapter.getClass().getGenericSuperclass();
/* 66 */     while (((superClass instanceof ParameterizedType)) && (XmlAdapter.class != ((ParameterizedType)superClass).getRawType())) {
/* 67 */       superClass = ((Class)((ParameterizedType)superClass).getRawType()).getGenericSuperclass();
/*    */     }
/* 69 */     return (Class)((ParameterizedType)superClass).getActualTypeArguments()[0];
/*    */   }
/*    */ }

/* Location:           F:\workspace6.5\policy_vhl_comabcommit1\WebRoot\WEB-INF\lib\jackson-all-1.9.0.jar
 * Qualified Name:     org.codehaus.jackson.xc.XmlAdapterJsonSerializer
 * JD-Core Version:    0.6.2
 */