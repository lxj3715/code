package org.springframework.aop;

import org.aopalliance.aop.Advice;

public abstract interface Advisor
{
  public abstract Advice getAdvice();

  public abstract boolean isPerInstance();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.Advisor
 * JD-Core Version:    0.6.2
 */