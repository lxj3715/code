package org.springframework.aop;

import java.lang.reflect.Method;

public abstract interface AfterReturningAdvice extends AfterAdvice
{
  public abstract void afterReturning(Object paramObject1, Method paramMethod, Object[] paramArrayOfObject, Object paramObject2)
    throws Throwable;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.AfterReturningAdvice
 * JD-Core Version:    0.6.2
 */