package org.springframework.aop;

import org.aopalliance.aop.Advice;

public abstract interface BeforeAdvice extends Advice
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.BeforeAdvice
 * JD-Core Version:    0.6.2
 */