/*    */ package org.springframework.aop;
/*    */ 
/*    */ public abstract interface ClassFilter
/*    */ {
/* 43 */   public static final ClassFilter TRUE = TrueClassFilter.INSTANCE;
/*    */ 
/*    */   public abstract boolean matches(Class<?> paramClass);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.ClassFilter
 * JD-Core Version:    0.6.2
 */