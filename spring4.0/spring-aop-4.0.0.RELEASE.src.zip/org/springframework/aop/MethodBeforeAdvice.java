package org.springframework.aop;

import java.lang.reflect.Method;

public abstract interface MethodBeforeAdvice extends BeforeAdvice
{
  public abstract void before(Method paramMethod, Object[] paramArrayOfObject, Object paramObject)
    throws Throwable;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.MethodBeforeAdvice
 * JD-Core Version:    0.6.2
 */