/*    */ package org.springframework.aop;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public abstract interface MethodMatcher
/*    */ {
/* 95 */   public static final MethodMatcher TRUE = TrueMethodMatcher.INSTANCE;
/*    */ 
/*    */   public abstract boolean matches(Method paramMethod, Class<?> paramClass);
/*    */ 
/*    */   public abstract boolean isRuntime();
/*    */ 
/*    */   public abstract boolean matches(Method paramMethod, Class<?> paramClass, Object[] paramArrayOfObject);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.MethodMatcher
 * JD-Core Version:    0.6.2
 */