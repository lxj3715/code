package org.springframework.aop;

public abstract interface PointcutAdvisor extends Advisor
{
  public abstract Pointcut getPointcut();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.PointcutAdvisor
 * JD-Core Version:    0.6.2
 */