package org.springframework.aop;

import org.aopalliance.intercept.MethodInvocation;

public abstract interface ProxyMethodInvocation extends MethodInvocation
{
  public abstract Object getProxy();

  public abstract MethodInvocation invocableClone();

  public abstract MethodInvocation invocableClone(Object[] paramArrayOfObject);

  public abstract void setArguments(Object[] paramArrayOfObject);

  public abstract void setUserAttribute(String paramString, Object paramObject);

  public abstract Object getUserAttribute(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.ProxyMethodInvocation
 * JD-Core Version:    0.6.2
 */