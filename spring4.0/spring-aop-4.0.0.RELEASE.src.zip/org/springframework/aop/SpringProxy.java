package org.springframework.aop;

public abstract interface SpringProxy
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.SpringProxy
 * JD-Core Version:    0.6.2
 */