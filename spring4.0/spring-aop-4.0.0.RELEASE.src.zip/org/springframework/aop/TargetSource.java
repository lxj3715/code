package org.springframework.aop;

public abstract interface TargetSource extends TargetClassAware
{
  public abstract Class<?> getTargetClass();

  public abstract boolean isStatic();

  public abstract Object getTarget()
    throws Exception;

  public abstract void releaseTarget(Object paramObject)
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.TargetSource
 * JD-Core Version:    0.6.2
 */