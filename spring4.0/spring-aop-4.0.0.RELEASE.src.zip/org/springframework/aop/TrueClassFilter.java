/*    */ package org.springframework.aop;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ class TrueClassFilter
/*    */   implements ClassFilter, Serializable
/*    */ {
/* 29 */   public static final TrueClassFilter INSTANCE = new TrueClassFilter();
/*    */ 
/*    */   public boolean matches(Class<?> clazz)
/*    */   {
/* 39 */     return true;
/*    */   }
/*    */ 
/*    */   private Object readResolve()
/*    */   {
/* 48 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 53 */     return "ClassFilter.TRUE";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.TrueClassFilter
 * JD-Core Version:    0.6.2
 */