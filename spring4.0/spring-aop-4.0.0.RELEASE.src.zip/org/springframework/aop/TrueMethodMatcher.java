/*    */ package org.springframework.aop;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ class TrueMethodMatcher
/*    */   implements MethodMatcher, Serializable
/*    */ {
/* 30 */   public static final TrueMethodMatcher INSTANCE = new TrueMethodMatcher();
/*    */ 
/*    */   public boolean isRuntime()
/*    */   {
/* 40 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean matches(Method method, Class<?> targetClass)
/*    */   {
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean matches(Method method, Class<?> targetClass, Object[] args)
/*    */   {
/* 51 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   private Object readResolve()
/*    */   {
/* 60 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 65 */     return "MethodMatcher.TRUE";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.TrueMethodMatcher
 * JD-Core Version:    0.6.2
 */