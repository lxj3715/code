/*    */ package org.springframework.aop;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ class TruePointcut
/*    */   implements Pointcut, Serializable
/*    */ {
/* 29 */   public static final TruePointcut INSTANCE = new TruePointcut();
/*    */ 
/*    */   public ClassFilter getClassFilter()
/*    */   {
/* 39 */     return ClassFilter.TRUE;
/*    */   }
/*    */ 
/*    */   public MethodMatcher getMethodMatcher()
/*    */   {
/* 44 */     return MethodMatcher.TRUE;
/*    */   }
/*    */ 
/*    */   private Object readResolve()
/*    */   {
/* 53 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 58 */     return "Pointcut.TRUE";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.TruePointcut
 * JD-Core Version:    0.6.2
 */