/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.JoinPoint.StaticPart;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.weaver.tools.JoinPointMatch;
/*     */ import org.aspectj.weaver.tools.PointcutParameter;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*     */ import org.springframework.aop.support.ComposablePointcut;
/*     */ import org.springframework.aop.support.MethodMatchers;
/*     */ import org.springframework.aop.support.StaticMethodMatcher;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractAspectJAdvice
/*     */   implements Advice, AspectJPrecedenceInformation
/*     */ {
/*  63 */   protected static final String JOIN_POINT_KEY = JoinPoint.class.getName();
/*     */   protected final Method aspectJAdviceMethod;
/*     */   private final int adviceInvocationArgumentCount;
/*     */   private final AspectJExpressionPointcut pointcut;
/*     */   private final AspectInstanceFactory aspectInstanceFactory;
/*     */   private String aspectName;
/*     */   private int declarationOrder;
/* 114 */   private String[] argumentNames = null;
/*     */ 
/* 117 */   private String throwingName = null;
/*     */ 
/* 120 */   private String returningName = null;
/*     */ 
/* 122 */   private Class<?> discoveredReturningType = Object.class;
/*     */ 
/* 124 */   private Class<?> discoveredThrowingType = Object.class;
/*     */ 
/* 130 */   private int joinPointArgumentIndex = -1;
/*     */ 
/* 136 */   private int joinPointStaticPartArgumentIndex = -1;
/*     */ 
/* 138 */   private Map<String, Integer> argumentBindings = null;
/*     */ 
/* 140 */   private boolean argumentsIntrospected = false;
/*     */   private Type discoveredReturningGenericType;
/*     */ 
/*     */   public static JoinPoint currentJoinPoint()
/*     */   {
/*  75 */     MethodInvocation mi = ExposeInvocationInterceptor.currentInvocation();
/*  76 */     if (!(mi instanceof ProxyMethodInvocation)) {
/*  77 */       throw new IllegalStateException(new StringBuilder().append("MethodInvocation is not a Spring ProxyMethodInvocation: ").append(mi).toString());
/*     */     }
/*  79 */     ProxyMethodInvocation pmi = (ProxyMethodInvocation)mi;
/*  80 */     JoinPoint jp = (JoinPoint)pmi.getUserAttribute(JOIN_POINT_KEY);
/*  81 */     if (jp == null) {
/*  82 */       jp = new MethodInvocationProceedingJoinPoint(pmi);
/*  83 */       pmi.setUserAttribute(JOIN_POINT_KEY, jp);
/*     */     }
/*  85 */     return jp;
/*     */   }
/*     */ 
/*     */   public AbstractAspectJAdvice(Method aspectJAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aspectInstanceFactory)
/*     */   {
/* 156 */     Assert.notNull(aspectJAdviceMethod, "Advice method must not be null");
/* 157 */     this.aspectJAdviceMethod = aspectJAdviceMethod;
/* 158 */     this.adviceInvocationArgumentCount = this.aspectJAdviceMethod.getParameterTypes().length;
/* 159 */     this.pointcut = pointcut;
/* 160 */     this.aspectInstanceFactory = aspectInstanceFactory;
/*     */   }
/*     */ 
/*     */   public final Method getAspectJAdviceMethod()
/*     */   {
/* 168 */     return this.aspectJAdviceMethod;
/*     */   }
/*     */ 
/*     */   public final AspectJExpressionPointcut getPointcut()
/*     */   {
/* 175 */     calculateArgumentBindings();
/* 176 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   public final Pointcut buildSafePointcut()
/*     */   {
/* 185 */     Pointcut pc = getPointcut();
/* 186 */     MethodMatcher safeMethodMatcher = MethodMatchers.intersection(new AdviceExcludingMethodMatcher(this.aspectJAdviceMethod), pc
/* 187 */       .getMethodMatcher());
/* 188 */     return new ComposablePointcut(pc.getClassFilter(), safeMethodMatcher);
/*     */   }
/*     */ 
/*     */   public final AspectInstanceFactory getAspectInstanceFactory()
/*     */   {
/* 195 */     return this.aspectInstanceFactory;
/*     */   }
/*     */ 
/*     */   public final ClassLoader getAspectClassLoader()
/*     */   {
/* 202 */     return this.aspectInstanceFactory.getAspectClassLoader();
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 207 */     return this.aspectInstanceFactory.getOrder();
/*     */   }
/*     */ 
/*     */   public void setAspectName(String name)
/*     */   {
/* 212 */     this.aspectName = name;
/*     */   }
/*     */ 
/*     */   public String getAspectName()
/*     */   {
/* 217 */     return this.aspectName;
/*     */   }
/*     */ 
/*     */   public void setDeclarationOrder(int order)
/*     */   {
/* 224 */     this.declarationOrder = order;
/*     */   }
/*     */ 
/*     */   public int getDeclarationOrder()
/*     */   {
/* 229 */     return this.declarationOrder;
/*     */   }
/*     */ 
/*     */   public void setArgumentNames(String argNames)
/*     */   {
/* 239 */     String[] tokens = StringUtils.commaDelimitedListToStringArray(argNames);
/* 240 */     setArgumentNamesFromStringArray(tokens);
/*     */   }
/*     */ 
/*     */   public void setArgumentNamesFromStringArray(String[] args) {
/* 244 */     this.argumentNames = new String[args.length];
/* 245 */     for (int i = 0; i < args.length; i++) {
/* 246 */       this.argumentNames[i] = StringUtils.trimWhitespace(args[i]);
/* 247 */       if (!isVariableName(this.argumentNames[i])) {
/* 248 */         throw new IllegalArgumentException(new StringBuilder().append("'argumentNames' property of AbstractAspectJAdvice contains an argument name '").append(this.argumentNames[i]).append("' that is not a valid Java identifier").toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 253 */     if ((this.argumentNames != null) && 
/* 254 */       (this.aspectJAdviceMethod.getParameterTypes().length == this.argumentNames.length + 1))
/*     */     {
/* 256 */       Class firstArgType = this.aspectJAdviceMethod.getParameterTypes()[0];
/* 257 */       if ((firstArgType == JoinPoint.class) || (firstArgType == ProceedingJoinPoint.class) || (firstArgType == JoinPoint.StaticPart.class))
/*     */       {
/* 260 */         String[] oldNames = this.argumentNames;
/* 261 */         this.argumentNames = new String[oldNames.length + 1];
/* 262 */         this.argumentNames[0] = "THIS_JOIN_POINT";
/* 263 */         System.arraycopy(oldNames, 0, this.argumentNames, 1, oldNames.length);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setReturningName(String name)
/*     */   {
/* 270 */     throw new UnsupportedOperationException("Only afterReturning advice can be used to bind a return value");
/*     */   }
/*     */ 
/*     */   protected void setReturningNameNoCheck(String name)
/*     */   {
/* 279 */     if (isVariableName(name)) {
/* 280 */       this.returningName = name;
/*     */     }
/*     */     else
/*     */       try
/*     */       {
/* 285 */         this.discoveredReturningType = ClassUtils.forName(name, getAspectClassLoader());
/*     */       }
/*     */       catch (Throwable ex) {
/* 288 */         throw new IllegalArgumentException(new StringBuilder().append("Returning name '").append(name).append("' is neither a valid argument name nor the fully-qualified name of a Java type on the classpath. ").append("Root cause: ").append(ex).toString());
/*     */       }
/*     */   }
/*     */ 
/*     */   protected Class<?> getDiscoveredReturningType()
/*     */   {
/* 296 */     return this.discoveredReturningType;
/*     */   }
/*     */ 
/*     */   protected Type getDiscoveredReturningGenericType() {
/* 300 */     return this.discoveredReturningGenericType;
/*     */   }
/*     */ 
/*     */   public void setThrowingName(String name) {
/* 304 */     throw new UnsupportedOperationException("Only afterThrowing advice can be used to bind a thrown exception");
/*     */   }
/*     */ 
/*     */   protected void setThrowingNameNoCheck(String name)
/*     */   {
/* 313 */     if (isVariableName(name)) {
/* 314 */       this.throwingName = name;
/*     */     }
/*     */     else
/*     */       try
/*     */       {
/* 319 */         this.discoveredThrowingType = ClassUtils.forName(name, getAspectClassLoader());
/*     */       }
/*     */       catch (Throwable ex) {
/* 322 */         throw new IllegalArgumentException(new StringBuilder().append("Throwing name '").append(name).append("' is neither a valid argument name nor the fully-qualified name of a Java type on the classpath. ").append("Root cause: ").append(ex).toString());
/*     */       }
/*     */   }
/*     */ 
/*     */   protected Class<?> getDiscoveredThrowingType()
/*     */   {
/* 330 */     return this.discoveredThrowingType;
/*     */   }
/*     */ 
/*     */   private boolean isVariableName(String name) {
/* 334 */     char[] chars = name.toCharArray();
/* 335 */     if (!Character.isJavaIdentifierStart(chars[0])) {
/* 336 */       return false;
/*     */     }
/* 338 */     for (int i = 1; i < chars.length; i++) {
/* 339 */       if (!Character.isJavaIdentifierPart(chars[i])) {
/* 340 */         return false;
/*     */       }
/*     */     }
/* 343 */     return true;
/*     */   }
/*     */ 
/*     */   public final synchronized void calculateArgumentBindings()
/*     */   {
/* 362 */     if ((this.argumentsIntrospected) || (this.adviceInvocationArgumentCount == 0)) {
/* 363 */       return;
/*     */     }
/*     */ 
/* 366 */     int numUnboundArgs = this.adviceInvocationArgumentCount;
/* 367 */     Class[] parameterTypes = this.aspectJAdviceMethod.getParameterTypes();
/* 368 */     if ((maybeBindJoinPoint(parameterTypes[0])) || (maybeBindProceedingJoinPoint(parameterTypes[0]))) {
/* 369 */       numUnboundArgs--;
/*     */     }
/* 371 */     else if (maybeBindJoinPointStaticPart(parameterTypes[0])) {
/* 372 */       numUnboundArgs--;
/*     */     }
/*     */ 
/* 375 */     if (numUnboundArgs > 0)
/*     */     {
/* 377 */       bindArgumentsByName(numUnboundArgs);
/*     */     }
/*     */ 
/* 380 */     this.argumentsIntrospected = true;
/*     */   }
/*     */ 
/*     */   private boolean maybeBindJoinPoint(Class<?> candidateParameterType) {
/* 384 */     if (candidateParameterType.equals(JoinPoint.class)) {
/* 385 */       this.joinPointArgumentIndex = 0;
/* 386 */       return true;
/*     */     }
/*     */ 
/* 389 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean maybeBindProceedingJoinPoint(Class<?> candidateParameterType)
/*     */   {
/* 394 */     if (candidateParameterType.equals(ProceedingJoinPoint.class)) {
/* 395 */       if (!supportsProceedingJoinPoint()) {
/* 396 */         throw new IllegalArgumentException("ProceedingJoinPoint is only supported for around advice");
/*     */       }
/* 398 */       this.joinPointArgumentIndex = 0;
/* 399 */       return true;
/*     */     }
/*     */ 
/* 402 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean supportsProceedingJoinPoint()
/*     */   {
/* 407 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean maybeBindJoinPointStaticPart(Class<?> candidateParameterType) {
/* 411 */     if (candidateParameterType.equals(JoinPoint.StaticPart.class)) {
/* 412 */       this.joinPointStaticPartArgumentIndex = 0;
/* 413 */       return true;
/*     */     }
/*     */ 
/* 416 */     return false;
/*     */   }
/*     */ 
/*     */   private void bindArgumentsByName(int numArgumentsExpectingToBind)
/*     */   {
/* 421 */     if (this.argumentNames == null) {
/* 422 */       this.argumentNames = createParameterNameDiscoverer().getParameterNames(this.aspectJAdviceMethod);
/*     */     }
/* 424 */     if (this.argumentNames != null)
/*     */     {
/* 426 */       bindExplicitArguments(numArgumentsExpectingToBind);
/*     */     }
/*     */     else
/* 429 */       throw new IllegalStateException(new StringBuilder().append("Advice method [").append(this.aspectJAdviceMethod.getName()).append("] ").append("requires ").append(numArgumentsExpectingToBind).append(" arguments to be bound by name, but ").append("the argument names were not specified and could not be discovered.").toString());
/*     */   }
/*     */ 
/*     */   protected ParameterNameDiscoverer createParameterNameDiscoverer()
/*     */   {
/* 443 */     DefaultParameterNameDiscoverer discoverer = new DefaultParameterNameDiscoverer();
/*     */ 
/* 445 */     AspectJAdviceParameterNameDiscoverer adviceParameterNameDiscoverer = new AspectJAdviceParameterNameDiscoverer(this.pointcut
/* 445 */       .getExpression());
/* 446 */     adviceParameterNameDiscoverer.setReturningName(this.returningName);
/* 447 */     adviceParameterNameDiscoverer.setThrowingName(this.throwingName);
/*     */ 
/* 449 */     adviceParameterNameDiscoverer.setRaiseExceptions(true);
/* 450 */     discoverer.addDiscoverer(adviceParameterNameDiscoverer);
/* 451 */     return discoverer;
/*     */   }
/*     */ 
/*     */   private void bindExplicitArguments(int numArgumentsLeftToBind) {
/* 455 */     this.argumentBindings = new HashMap();
/*     */ 
/* 457 */     int numExpectedArgumentNames = this.aspectJAdviceMethod.getParameterTypes().length;
/* 458 */     if (this.argumentNames.length != numExpectedArgumentNames) {
/* 459 */       throw new IllegalStateException(new StringBuilder().append("Expecting to find ").append(numExpectedArgumentNames).append(" arguments to bind by name in advice, but actually found ").append(this.argumentNames.length).append(" arguments.").toString());
/*     */     }
/*     */ 
/* 465 */     int argumentIndexOffset = this.adviceInvocationArgumentCount - numArgumentsLeftToBind;
/* 466 */     for (int i = argumentIndexOffset; i < this.argumentNames.length; i++) {
/* 467 */       this.argumentBindings.put(this.argumentNames[i], Integer.valueOf(i));
/*     */     }
/*     */ 
/* 472 */     if (this.returningName != null) {
/* 473 */       if (!this.argumentBindings.containsKey(this.returningName)) {
/* 474 */         throw new IllegalStateException(new StringBuilder().append("Returning argument name '").append(this.returningName).append("' was not bound in advice arguments").toString());
/*     */       }
/*     */ 
/* 478 */       Integer index = (Integer)this.argumentBindings.get(this.returningName);
/* 479 */       this.discoveredReturningType = this.aspectJAdviceMethod.getParameterTypes()[index.intValue()];
/* 480 */       this.discoveredReturningGenericType = this.aspectJAdviceMethod.getGenericParameterTypes()[index.intValue()];
/*     */     }
/*     */ 
/* 483 */     if (this.throwingName != null) {
/* 484 */       if (!this.argumentBindings.containsKey(this.throwingName)) {
/* 485 */         throw new IllegalStateException(new StringBuilder().append("Throwing argument name '").append(this.throwingName).append("' was not bound in advice arguments").toString());
/*     */       }
/*     */ 
/* 489 */       Integer index = (Integer)this.argumentBindings.get(this.throwingName);
/* 490 */       this.discoveredThrowingType = this.aspectJAdviceMethod.getParameterTypes()[index.intValue()];
/*     */     }
/*     */ 
/* 495 */     configurePointcutParameters(argumentIndexOffset);
/*     */   }
/*     */ 
/*     */   private void configurePointcutParameters(int argumentIndexOffset)
/*     */   {
/* 504 */     int numParametersToRemove = argumentIndexOffset;
/* 505 */     if (this.returningName != null) {
/* 506 */       numParametersToRemove++;
/*     */     }
/* 508 */     if (this.throwingName != null) {
/* 509 */       numParametersToRemove++;
/*     */     }
/* 511 */     String[] pointcutParameterNames = new String[this.argumentNames.length - numParametersToRemove];
/* 512 */     Class[] pointcutParameterTypes = new Class[pointcutParameterNames.length];
/* 513 */     Class[] methodParameterTypes = this.aspectJAdviceMethod.getParameterTypes();
/*     */ 
/* 515 */     int index = 0;
/* 516 */     for (int i = 0; i < this.argumentNames.length; i++)
/* 517 */       if (i >= argumentIndexOffset)
/*     */       {
/* 520 */         if ((!this.argumentNames[i].equals(this.returningName)) && 
/* 521 */           (!this.argumentNames[i]
/* 521 */           .equals(this.throwingName)))
/*     */         {
/* 524 */           pointcutParameterNames[index] = this.argumentNames[i];
/* 525 */           pointcutParameterTypes[index] = methodParameterTypes[i];
/* 526 */           index++;
/*     */         }
/*     */       }
/* 529 */     this.pointcut.setParameterNames(pointcutParameterNames);
/* 530 */     this.pointcut.setParameterTypes(pointcutParameterTypes);
/*     */   }
/*     */ 
/*     */   protected Object[] argBinding(JoinPoint jp, JoinPointMatch jpMatch, Object returnValue, Throwable ex)
/*     */   {
/* 543 */     calculateArgumentBindings();
/*     */ 
/* 546 */     Object[] adviceInvocationArgs = new Object[this.adviceInvocationArgumentCount];
/* 547 */     int numBound = 0;
/*     */ 
/* 549 */     if (this.joinPointArgumentIndex != -1) {
/* 550 */       adviceInvocationArgs[this.joinPointArgumentIndex] = jp;
/* 551 */       numBound++;
/*     */     }
/* 553 */     else if (this.joinPointStaticPartArgumentIndex != -1) {
/* 554 */       adviceInvocationArgs[this.joinPointStaticPartArgumentIndex] = jp.getStaticPart();
/* 555 */       numBound++;
/*     */     }
/*     */ 
/* 558 */     if (!CollectionUtils.isEmpty(this.argumentBindings))
/*     */     {
/* 560 */       if (jpMatch != null) {
/* 561 */         PointcutParameter[] parameterBindings = jpMatch.getParameterBindings();
/* 562 */         for (PointcutParameter parameter : parameterBindings) {
/* 563 */           String name = parameter.getName();
/* 564 */           Integer index = (Integer)this.argumentBindings.get(name);
/* 565 */           adviceInvocationArgs[index.intValue()] = parameter.getBinding();
/* 566 */           numBound++;
/*     */         }
/*     */       }
/*     */ 
/* 570 */       if (this.returningName != null) {
/* 571 */         Integer index = (Integer)this.argumentBindings.get(this.returningName);
/* 572 */         adviceInvocationArgs[index.intValue()] = returnValue;
/* 573 */         numBound++;
/*     */       }
/*     */ 
/* 576 */       if (this.throwingName != null) {
/* 577 */         Integer index = (Integer)this.argumentBindings.get(this.throwingName);
/* 578 */         adviceInvocationArgs[index.intValue()] = ex;
/* 579 */         numBound++;
/*     */       }
/*     */     }
/*     */ 
/* 583 */     if (numBound != this.adviceInvocationArgumentCount) {
/* 584 */       throw new IllegalStateException(new StringBuilder().append("Required to bind ").append(this.adviceInvocationArgumentCount).append(" arguments, but only bound ").append(numBound).append(" (JoinPointMatch ").append(jpMatch == null ? "was NOT" : "WAS").append(" bound in invocation)").toString());
/*     */     }
/*     */ 
/* 590 */     return adviceInvocationArgs;
/*     */   }
/*     */ 
/*     */   protected Object invokeAdviceMethod(JoinPointMatch jpMatch, Object returnValue, Throwable ex)
/*     */     throws Throwable
/*     */   {
/* 603 */     return invokeAdviceMethodWithGivenArgs(argBinding(getJoinPoint(), jpMatch, returnValue, ex));
/*     */   }
/*     */ 
/*     */   protected Object invokeAdviceMethod(JoinPoint jp, JoinPointMatch jpMatch, Object returnValue, Throwable t)
/*     */     throws Throwable
/*     */   {
/* 610 */     return invokeAdviceMethodWithGivenArgs(argBinding(jp, jpMatch, returnValue, t));
/*     */   }
/*     */ 
/*     */   protected Object invokeAdviceMethodWithGivenArgs(Object[] args) throws Throwable {
/* 614 */     Object[] actualArgs = args;
/* 615 */     if (this.aspectJAdviceMethod.getParameterTypes().length == 0)
/* 616 */       actualArgs = null;
/*     */     try
/*     */     {
/* 619 */       ReflectionUtils.makeAccessible(this.aspectJAdviceMethod);
/*     */ 
/* 621 */       return this.aspectJAdviceMethod.invoke(this.aspectInstanceFactory.getAspectInstance(), actualArgs);
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 626 */       throw new AopInvocationException(new StringBuilder().append("Mismatch on arguments to advice method [").append(this.aspectJAdviceMethod).append("]; pointcut expression [")
/* 626 */         .append(this.pointcut
/* 626 */         .getPointcutExpression()).append("]").toString(), ex);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 629 */       throw ex.getTargetException();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JoinPoint getJoinPoint()
/*     */   {
/* 637 */     return currentJoinPoint();
/*     */   }
/*     */ 
/*     */   protected JoinPointMatch getJoinPointMatch()
/*     */   {
/* 644 */     MethodInvocation mi = ExposeInvocationInterceptor.currentInvocation();
/* 645 */     if (!(mi instanceof ProxyMethodInvocation)) {
/* 646 */       throw new IllegalStateException(new StringBuilder().append("MethodInvocation is not a Spring ProxyMethodInvocation: ").append(mi).toString());
/*     */     }
/* 648 */     return getJoinPointMatch((ProxyMethodInvocation)mi);
/*     */   }
/*     */ 
/*     */   protected JoinPointMatch getJoinPointMatch(ProxyMethodInvocation pmi)
/*     */   {
/* 658 */     return (JoinPointMatch)pmi.getUserAttribute(this.pointcut.getExpression());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 664 */     return new StringBuilder().append(getClass().getName()).append(": advice method [").append(this.aspectJAdviceMethod).append("]; ").append("aspect name '").append(this.aspectName).append("'").toString();
/*     */   }
/*     */ 
/*     */   private static class AdviceExcludingMethodMatcher extends StaticMethodMatcher
/*     */   {
/*     */     private final Method adviceMethod;
/*     */ 
/*     */     public AdviceExcludingMethodMatcher(Method adviceMethod)
/*     */     {
/* 678 */       this.adviceMethod = adviceMethod;
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 683 */       return !this.adviceMethod.equals(method);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 688 */       if (this == other) {
/* 689 */         return true;
/*     */       }
/* 691 */       if (!(other instanceof AdviceExcludingMethodMatcher)) {
/* 692 */         return false;
/*     */       }
/* 694 */       AdviceExcludingMethodMatcher otherMm = (AdviceExcludingMethodMatcher)other;
/* 695 */       return this.adviceMethod.equals(otherMm.adviceMethod);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 700 */       return this.adviceMethod.hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AbstractAspectJAdvice
 * JD-Core Version:    0.6.2
 */