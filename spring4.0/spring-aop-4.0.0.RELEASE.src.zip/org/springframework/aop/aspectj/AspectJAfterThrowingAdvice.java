/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.aop.AfterAdvice;
/*    */ 
/*    */ public class AspectJAfterThrowingAdvice extends AbstractAspectJAdvice
/*    */   implements MethodInterceptor, AfterAdvice
/*    */ {
/*    */   public AspectJAfterThrowingAdvice(Method aspectJBeforeAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aif)
/*    */   {
/* 37 */     super(aspectJBeforeAdviceMethod, pointcut, aif);
/*    */   }
/*    */ 
/*    */   public boolean isBeforeAdvice()
/*    */   {
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isAfterAdvice()
/*    */   {
/* 47 */     return true;
/*    */   }
/*    */ 
/*    */   public void setThrowingName(String name)
/*    */   {
/* 52 */     setThrowingNameNoCheck(name);
/*    */   }
/*    */ 
/*    */   public Object invoke(MethodInvocation mi) throws Throwable
/*    */   {
/*    */     try {
/* 58 */       return mi.proceed();
/*    */     }
/*    */     catch (Throwable t) {
/* 61 */       if (shouldInvokeOnThrowing(t)) {
/* 62 */         invokeAdviceMethod(getJoinPointMatch(), null, t);
/*    */       }
/* 64 */       throw t;
/*    */     }
/*    */   }
/*    */ 
/*    */   private boolean shouldInvokeOnThrowing(Throwable t)
/*    */   {
/* 73 */     return getDiscoveredThrowingType().isAssignableFrom(t.getClass());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJAfterThrowingAdvice
 * JD-Core Version:    0.6.2
 */