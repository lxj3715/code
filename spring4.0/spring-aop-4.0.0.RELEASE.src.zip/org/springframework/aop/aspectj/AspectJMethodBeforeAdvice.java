/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.MethodBeforeAdvice;
/*    */ 
/*    */ public class AspectJMethodBeforeAdvice extends AbstractAspectJAdvice
/*    */   implements MethodBeforeAdvice
/*    */ {
/*    */   public AspectJMethodBeforeAdvice(Method aspectJBeforeAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aif)
/*    */   {
/* 35 */     super(aspectJBeforeAdviceMethod, pointcut, aif);
/*    */   }
/*    */ 
/*    */   public void before(Method method, Object[] args, Object target) throws Throwable
/*    */   {
/* 40 */     invokeAdviceMethod(getJoinPointMatch(), null, null);
/*    */   }
/*    */ 
/*    */   public boolean isBeforeAdvice()
/*    */   {
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean isAfterAdvice()
/*    */   {
/* 50 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.AspectJMethodBeforeAdvice
 * JD-Core Version:    0.6.2
 */