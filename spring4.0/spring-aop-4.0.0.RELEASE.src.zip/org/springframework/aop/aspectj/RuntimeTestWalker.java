/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.ast.And;
/*     */ import org.aspectj.weaver.ast.Call;
/*     */ import org.aspectj.weaver.ast.FieldGetCall;
/*     */ import org.aspectj.weaver.ast.HasAnnotation;
/*     */ import org.aspectj.weaver.ast.ITestVisitor;
/*     */ import org.aspectj.weaver.ast.Instanceof;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Not;
/*     */ import org.aspectj.weaver.ast.Or;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.internal.tools.MatchingContextBasedTest;
/*     */ import org.aspectj.weaver.reflect.ReflectionVar;
/*     */ import org.aspectj.weaver.reflect.ShadowMatchImpl;
/*     */ import org.aspectj.weaver.tools.ShadowMatch;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ class RuntimeTestWalker
/*     */ {
/*     */   private final Test runtimeTest;
/*     */ 
/*     */   public RuntimeTestWalker(ShadowMatch shadowMatch)
/*     */   {
/*  62 */     ShadowMatchImpl shadowMatchImplementation = (ShadowMatchImpl)shadowMatch;
/*     */     try {
/*  64 */       Field testField = shadowMatchImplementation.getClass().getDeclaredField("residualTest");
/*  65 */       ReflectionUtils.makeAccessible(testField);
/*  66 */       this.runtimeTest = ((Test)testField.get(shadowMatch));
/*     */     }
/*     */     catch (NoSuchFieldException noSuchFieldEx) {
/*  69 */       throw new IllegalStateException("The version of aspectjtools.jar / aspectjweaver.jar on the classpath is incompatible with this version of Spring: Expected field 'runtimeTest' is not present on ShadowMatchImpl class.");
/*     */     }
/*     */     catch (IllegalAccessException illegalAccessEx)
/*     */     {
/*  76 */       throw new IllegalStateException("Unable to access ShadowMatchImpl.residualTest field");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean testsSubtypeSensitiveVars()
/*     */   {
/*  87 */     return (this.runtimeTest != null) && 
/*  87 */       (new SubtypeSensitiveVarTypeTestVisitor(null)
/*  87 */       .testsSubtypeSensitiveVars(this.runtimeTest));
/*     */   }
/*     */ 
/*     */   public boolean testThisInstanceOfResidue(Class<?> thisClass)
/*     */   {
/*  92 */     return (this.runtimeTest != null) && 
/*  92 */       (new ThisInstanceOfResidueTestVisitor(thisClass)
/*  92 */       .thisInstanceOfMatches(this.runtimeTest));
/*     */   }
/*     */ 
/*     */   public boolean testTargetInstanceOfResidue(Class<?> targetClass)
/*     */   {
/*  97 */     return (this.runtimeTest != null) && 
/*  97 */       (new TargetInstanceOfResidueTestVisitor(targetClass)
/*  97 */       .targetInstanceOfMatches(this.runtimeTest));
/*     */   }
/*     */ 
/*     */   private static class SubtypeSensitiveVarTypeTestVisitor extends RuntimeTestWalker.TestVisitorAdapter
/*     */   {
/* 239 */     private final Object thisObj = new Object();
/* 240 */     private final Object targetObj = new Object();
/* 241 */     private final Object[] argsObjs = new Object[0];
/* 242 */     private boolean testsSubtypeSensitiveVars = false;
/*     */ 
/*     */     private SubtypeSensitiveVarTypeTestVisitor()
/*     */     {
/* 237 */       super();
/*     */     }
/*     */ 
/*     */     public boolean testsSubtypeSensitiveVars(Test aTest)
/*     */     {
/* 245 */       aTest.accept(this);
/* 246 */       return this.testsSubtypeSensitiveVars;
/*     */     }
/*     */ 
/*     */     public void visit(Instanceof i)
/*     */     {
/* 251 */       ReflectionVar v = (ReflectionVar)i.getVar();
/* 252 */       Object varUnderTest = v.getBindingAtJoinPoint(this.thisObj, this.targetObj, this.argsObjs);
/* 253 */       if ((varUnderTest == this.thisObj) || (varUnderTest == this.targetObj))
/* 254 */         this.testsSubtypeSensitiveVars = true;
/*     */     }
/*     */ 
/*     */     public void visit(HasAnnotation hasAnn)
/*     */     {
/* 261 */       ReflectionVar v = (ReflectionVar)hasAnn.getVar();
/* 262 */       int varType = getVarType(v);
/* 263 */       if ((varType == 3) || (varType == 4) || (varType == 8))
/* 264 */         this.testsSubtypeSensitiveVars = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ThisInstanceOfResidueTestVisitor extends RuntimeTestWalker.InstanceOfResidueTestVisitor
/*     */   {
/*     */     public ThisInstanceOfResidueTestVisitor(Class<?> thisClass)
/*     */     {
/* 227 */       super(true, 0);
/*     */     }
/*     */ 
/*     */     public boolean thisInstanceOfMatches(Test test)
/*     */     {
/* 232 */       return instanceOfMatches(test);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TargetInstanceOfResidueTestVisitor extends RuntimeTestWalker.InstanceOfResidueTestVisitor
/*     */   {
/*     */     public TargetInstanceOfResidueTestVisitor(Class<?> targetClass)
/*     */     {
/* 212 */       super(false, 1);
/*     */     }
/*     */ 
/*     */     public boolean targetInstanceOfMatches(Test test) {
/* 216 */       return instanceOfMatches(test);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract class InstanceOfResidueTestVisitor extends RuntimeTestWalker.TestVisitorAdapter
/*     */   {
/*     */     private Class<?> matchClass;
/*     */     private boolean matches;
/*     */     private int matchVarType;
/*     */ 
/*     */     public InstanceOfResidueTestVisitor(Class<?> matchClass, boolean defaultMatches, int matchVarType)
/*     */     {
/* 176 */       super();
/* 177 */       this.matchClass = matchClass;
/* 178 */       this.matches = defaultMatches;
/* 179 */       this.matchVarType = matchVarType;
/*     */     }
/*     */ 
/*     */     public boolean instanceOfMatches(Test test) {
/* 183 */       test.accept(this);
/* 184 */       return this.matches;
/*     */     }
/*     */ 
/*     */     public void visit(Instanceof i)
/*     */     {
/* 189 */       ResolvedType type = (ResolvedType)i.getType();
/* 190 */       int varType = getVarType((ReflectionVar)i.getVar());
/* 191 */       if (varType != this.matchVarType)
/* 192 */         return;
/*     */       try
/*     */       {
/* 195 */         Class typeClass = ClassUtils.forName(type.getName(), this.matchClass.getClassLoader());
/*     */ 
/* 197 */         this.matches = typeClass.isAssignableFrom(this.matchClass);
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 200 */         this.matches = false;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TestVisitorAdapter
/*     */     implements ITestVisitor
/*     */   {
/*     */     protected static final int THIS_VAR = 0;
/*     */     protected static final int TARGET_VAR = 1;
/*     */     protected static final int AT_THIS_VAR = 3;
/*     */     protected static final int AT_TARGET_VAR = 4;
/*     */     protected static final int AT_ANNOTATION_VAR = 8;
/*     */ 
/*     */     public void visit(And e)
/*     */     {
/* 111 */       e.getLeft().accept(this);
/* 112 */       e.getRight().accept(this);
/*     */     }
/*     */ 
/*     */     public void visit(Or e)
/*     */     {
/* 117 */       e.getLeft().accept(this);
/* 118 */       e.getRight().accept(this);
/*     */     }
/*     */ 
/*     */     public void visit(Not e)
/*     */     {
/* 123 */       e.getBody().accept(this);
/*     */     }
/*     */ 
/*     */     public void visit(Instanceof i)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void visit(Literal literal)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void visit(Call call)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void visit(FieldGetCall fieldGetCall)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void visit(HasAnnotation hasAnnotation)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void visit(MatchingContextBasedTest matchingContextTest)
/*     */     {
/*     */     }
/*     */ 
/*     */     protected int getVarType(ReflectionVar v) {
/*     */       try {
/* 152 */         Field varTypeField = ReflectionVar.class.getDeclaredField("varType");
/* 153 */         ReflectionUtils.makeAccessible(varTypeField);
/* 154 */         return ((Integer)varTypeField.get(v)).intValue();
/*     */       }
/*     */       catch (NoSuchFieldException noSuchFieldEx) {
/* 157 */         throw new IllegalStateException("the version of aspectjtools.jar / aspectjweaver.jar on the classpath is incompatible with this version of Spring:- expected field 'varType' is not present on ReflectionVar class");
/*     */       }
/*     */       catch (IllegalAccessException illegalAccessEx)
/*     */       {
/*     */       }
/*     */ 
/* 164 */       throw new IllegalStateException("Unable to access ReflectionVar.varType field");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.RuntimeTestWalker
 * JD-Core Version:    0.6.2
 */