/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.aspectj.lang.annotation.After;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.AfterThrowing;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.annotation.Before;
/*     */ import org.aspectj.lang.annotation.Pointcut;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.AjTypeSystem;
/*     */ import org.aspectj.lang.reflect.PerClause;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractAspectJAdvisorFactory
/*     */   implements AspectJAdvisorFactory
/*     */ {
/*     */   private static final String AJC_MAGIC = "ajc$";
/*     */   protected final Log logger;
/*     */   protected final ParameterNameDiscoverer parameterNameDiscoverer;
/*     */ 
/*     */   public AbstractAspectJAdvisorFactory()
/*     */   {
/*  92 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  94 */     this.parameterNameDiscoverer = new AspectJAnnotationParameterNameDiscoverer(null);
/*     */   }
/*     */ 
/*     */   protected static AspectJAnnotation<?> findAspectJAnnotationOnMethod(Method method)
/*     */   {
/*  69 */     Class[] classesToLookFor = { Before.class, Around.class, After.class, AfterReturning.class, AfterThrowing.class, Pointcut.class };
/*     */ 
/*  71 */     for (Class c : classesToLookFor) {
/*  72 */       AspectJAnnotation foundAnnotation = findAnnotation(method, c);
/*  73 */       if (foundAnnotation != null) {
/*  74 */         return foundAnnotation;
/*     */       }
/*     */     }
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   private static <A extends Annotation> AspectJAnnotation<A> findAnnotation(Method method, Class<A> toLookFor) {
/*  81 */     Annotation result = AnnotationUtils.findAnnotation(method, toLookFor);
/*  82 */     if (result != null) {
/*  83 */       return new AspectJAnnotation(result);
/*     */     }
/*     */ 
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isAspect(Class<?> clazz)
/*     */   {
/* 105 */     return (hasAspectAnnotation(clazz)) && (!compiledByAjc(clazz));
/*     */   }
/*     */ 
/*     */   private boolean hasAspectAnnotation(Class<?> clazz) {
/* 109 */     return AnnotationUtils.findAnnotation(clazz, Aspect.class) != null;
/*     */   }
/*     */ 
/*     */   private boolean compiledByAjc(Class<?> clazz)
/*     */   {
/* 120 */     for (Field field : clazz.getDeclaredFields()) {
/* 121 */       if (field.getName().startsWith("ajc$")) {
/* 122 */         return true;
/*     */       }
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   public void validate(Class<?> aspectClass)
/*     */     throws AopConfigException
/*     */   {
/* 131 */     if ((aspectClass.getSuperclass().getAnnotation(Aspect.class) != null) && 
/* 132 */       (!Modifier.isAbstract(aspectClass
/* 132 */       .getSuperclass().getModifiers())))
/*     */     {
/* 134 */       throw new AopConfigException("[" + aspectClass.getName() + "] cannot extend concrete aspect [" + aspectClass
/* 134 */         .getSuperclass().getName() + "]");
/*     */     }
/*     */ 
/* 137 */     AjType ajType = AjTypeSystem.getAjType(aspectClass);
/* 138 */     if (!ajType.isAspect()) {
/* 139 */       throw new NotAnAtAspectException(aspectClass);
/*     */     }
/* 141 */     if (ajType.getPerClause().getKind() == PerClauseKind.PERCFLOW) {
/* 142 */       throw new AopConfigException(aspectClass.getName() + " uses percflow instantiation model: " + "This is not supported in Spring AOP.");
/*     */     }
/*     */ 
/* 145 */     if (ajType.getPerClause().getKind() == PerClauseKind.PERCFLOWBELOW)
/* 146 */       throw new AopConfigException(aspectClass.getName() + " uses percflowbelow instantiation model: " + "This is not supported in Spring AOP.");
/*     */   }
/*     */ 
/*     */   protected AspectJExpressionPointcut createPointcutExpression(Method annotatedMethod, Class<?> declarationScope, String[] pointcutParameterNames)
/*     */   {
/* 159 */     Class[] pointcutParameterTypes = new Class[0];
/* 160 */     if (pointcutParameterNames != null) {
/* 161 */       pointcutParameterTypes = extractPointcutParameterTypes(pointcutParameterNames, annotatedMethod);
/*     */     }
/*     */ 
/* 164 */     AspectJExpressionPointcut ajexp = new AspectJExpressionPointcut(declarationScope, pointcutParameterNames, pointcutParameterTypes);
/*     */ 
/* 166 */     ajexp.setLocation(annotatedMethod.toString());
/* 167 */     return ajexp;
/*     */   }
/*     */ 
/*     */   private Class<?>[] extractPointcutParameterTypes(String[] argNames, Method adviceMethod)
/*     */   {
/* 177 */     Class[] ret = new Class[argNames.length];
/* 178 */     Class[] paramTypes = adviceMethod.getParameterTypes();
/* 179 */     if (argNames.length > paramTypes.length) {
/* 180 */       throw new IllegalStateException("Expecting at least " + argNames.length + " arguments in the advice declaration, but only found " + paramTypes.length);
/*     */     }
/*     */ 
/* 185 */     int typeOffset = paramTypes.length - argNames.length;
/* 186 */     for (int i = 0; i < ret.length; i++) {
/* 187 */       ret[i] = paramTypes[(i + typeOffset)];
/*     */     }
/* 189 */     return ret;
/*     */   }
/*     */ 
/*     */   private static class AspectJAnnotationParameterNameDiscoverer
/*     */     implements ParameterNameDiscoverer
/*     */   {
/*     */     public String[] getParameterNames(Method method)
/*     */     {
/* 305 */       if (method.getParameterTypes().length == 0) {
/* 306 */         return new String[0];
/*     */       }
/* 308 */       AbstractAspectJAdvisorFactory.AspectJAnnotation annotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(method);
/* 309 */       if (annotation == null) {
/* 310 */         return null;
/*     */       }
/* 312 */       StringTokenizer strTok = new StringTokenizer(annotation.getArgumentNames(), ",");
/* 313 */       if (strTok.countTokens() > 0) {
/* 314 */         String[] names = new String[strTok.countTokens()];
/* 315 */         for (int i = 0; i < names.length; i++) {
/* 316 */           names[i] = strTok.nextToken();
/*     */         }
/* 318 */         return names;
/*     */       }
/*     */ 
/* 321 */       return null;
/*     */     }
/*     */ 
/*     */     public String[] getParameterNames(Constructor<?> ctor)
/*     */     {
/* 327 */       throw new UnsupportedOperationException("Spring AOP cannot handle constructor advice");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class AspectJAnnotation<A extends Annotation>
/*     */   {
/* 209 */     private static final String[] EXPRESSION_PROPERTIES = { "value", "pointcut" };
/*     */ 
/* 211 */     private static Map<Class<?>, AbstractAspectJAdvisorFactory.AspectJAnnotationType> annotationTypes = new HashMap();
/*     */     private final A annotation;
/*     */     private final AbstractAspectJAdvisorFactory.AspectJAnnotationType annotationType;
/*     */     private final String pointcutExpression;
/*     */     private final String argumentNames;
/*     */ 
/*     */     public AspectJAnnotation(A annotation)
/*     */     {
/* 232 */       this.annotation = annotation;
/* 233 */       this.annotationType = determineAnnotationType(annotation);
/*     */       try
/*     */       {
/* 237 */         this.pointcutExpression = resolveExpression(annotation);
/* 238 */         this.argumentNames = ((String)annotation.getClass().getMethod("argNames", new Class[0]).invoke(annotation, new Object[0]));
/*     */       }
/*     */       catch (Exception ex) {
/* 241 */         throw new IllegalArgumentException(annotation + " cannot be an AspectJ annotation", ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     private AbstractAspectJAdvisorFactory.AspectJAnnotationType determineAnnotationType(A annotation) {
/* 246 */       for (Class type : annotationTypes.keySet()) {
/* 247 */         if (type.isInstance(annotation)) {
/* 248 */           return (AbstractAspectJAdvisorFactory.AspectJAnnotationType)annotationTypes.get(type);
/*     */         }
/*     */       }
/* 251 */       throw new IllegalStateException("Unknown annotation type: " + annotation.toString());
/*     */     }
/*     */ 
/*     */     private String resolveExpression(A annotation) throws Exception {
/* 255 */       String expression = null;
/* 256 */       for (String methodName : EXPRESSION_PROPERTIES) {
/*     */         Method method;
/*     */         try {
/* 259 */           method = annotation.getClass().getDeclaredMethod(methodName, new Class[0]);
/*     */         }
/*     */         catch (NoSuchMethodException ex)
/*     */         {
/*     */           Method method;
/* 262 */           method = null;
/*     */         }
/* 264 */         if (method != null) {
/* 265 */           String candidate = (String)method.invoke(annotation, new Object[0]);
/* 266 */           if (StringUtils.hasText(candidate)) {
/* 267 */             expression = candidate;
/*     */           }
/*     */         }
/*     */       }
/* 271 */       return expression;
/*     */     }
/*     */ 
/*     */     public AbstractAspectJAdvisorFactory.AspectJAnnotationType getAnnotationType() {
/* 275 */       return this.annotationType;
/*     */     }
/*     */ 
/*     */     public A getAnnotation() {
/* 279 */       return this.annotation;
/*     */     }
/*     */ 
/*     */     public String getPointcutExpression() {
/* 283 */       return this.pointcutExpression;
/*     */     }
/*     */ 
/*     */     public String getArgumentNames() {
/* 287 */       return this.argumentNames;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 292 */       return this.annotation.toString();
/*     */     }
/*     */ 
/*     */     static
/*     */     {
/* 215 */       annotationTypes.put(Pointcut.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtPointcut);
/* 216 */       annotationTypes.put(After.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfter);
/* 217 */       annotationTypes.put(AfterReturning.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfterReturning);
/* 218 */       annotationTypes.put(AfterThrowing.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfterThrowing);
/* 219 */       annotationTypes.put(Around.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAround);
/* 220 */       annotationTypes.put(Before.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtBefore);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static enum AspectJAnnotationType
/*     */   {
/* 194 */     AtPointcut, 
/* 195 */     AtBefore, 
/* 196 */     AtAfter, 
/* 197 */     AtAfterReturning, 
/* 198 */     AtAfterThrowing, 
/* 199 */     AtAround;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.AbstractAspectJAdvisorFactory
 * JD-Core Version:    0.6.2
 */