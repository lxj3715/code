/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.AjTypeSystem;
/*     */ import org.aspectj.lang.reflect.PerClause;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.TypePatternClassFilter;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.aop.support.ComposablePointcut;
/*     */ 
/*     */ public class AspectMetadata
/*     */ {
/*     */   private final AjType<?> ajType;
/*     */   private final Pointcut perClausePointcut;
/*     */   private String aspectName;
/*     */ 
/*     */   public AspectMetadata(Class<?> aspectClass, String aspectName)
/*     */   {
/*  71 */     this.aspectName = aspectName;
/*     */ 
/*  73 */     Class currClass = aspectClass;
/*  74 */     AjType ajType = null;
/*  75 */     while (!currClass.equals(Object.class)) {
/*  76 */       AjType ajTypeToCheck = AjTypeSystem.getAjType(currClass);
/*  77 */       if (ajTypeToCheck.isAspect()) {
/*  78 */         ajType = ajTypeToCheck;
/*  79 */         break;
/*     */       }
/*  81 */       currClass = currClass.getSuperclass();
/*     */     }
/*  83 */     if (ajType == null) {
/*  84 */       throw new IllegalArgumentException("Class '" + aspectClass.getName() + "' is not an @AspectJ aspect");
/*     */     }
/*  86 */     this.ajType = ajType;
/*  87 */     if (this.ajType.getDeclarePrecedence().length > 0) {
/*  88 */       throw new IllegalArgumentException("DeclarePrecendence not presently supported in Spring AOP");
/*     */     }
/*     */ 
/*  91 */     switch (1.$SwitchMap$org$aspectj$lang$reflect$PerClauseKind[this.ajType.getPerClause().getKind().ordinal()]) {
/*     */     case 1:
/*  93 */       this.perClausePointcut = Pointcut.TRUE;
/*  94 */       return;
/*     */     case 2:
/*     */     case 3:
/*  96 */       AspectJExpressionPointcut ajexp = new AspectJExpressionPointcut();
/*  97 */       ajexp.setLocation("@Aspect annotation on " + aspectClass.getName());
/*  98 */       ajexp.setExpression(findPerClause(aspectClass));
/*  99 */       this.perClausePointcut = ajexp;
/* 100 */       return;
/*     */     case 4:
/* 103 */       this.perClausePointcut = new ComposablePointcut(new TypePatternClassFilter(findPerClause(aspectClass)));
/* 104 */       return;
/*     */     }
/*     */ 
/* 107 */     throw new AopConfigException("PerClause " + ajType
/* 107 */       .getPerClause().getKind() + " not supported by Spring AOP for " + aspectClass);
/*     */   }
/*     */ 
/*     */   private String findPerClause(Class<?> aspectClass)
/*     */   {
/* 117 */     String str = ((Aspect)aspectClass.getAnnotation(Aspect.class)).value();
/* 118 */     str = str.substring(str.indexOf("(") + 1);
/* 119 */     str = str.substring(0, str.length() - 1);
/* 120 */     return str;
/*     */   }
/*     */ 
/*     */   public AjType<?> getAjType()
/*     */   {
/* 128 */     return this.ajType;
/*     */   }
/*     */ 
/*     */   public Class<?> getAspectClass()
/*     */   {
/* 135 */     return this.ajType.getJavaClass();
/*     */   }
/*     */ 
/*     */   public String getAspectName()
/*     */   {
/* 142 */     return this.aspectName;
/*     */   }
/*     */ 
/*     */   public Pointcut getPerClausePointcut()
/*     */   {
/* 150 */     return this.perClausePointcut;
/*     */   }
/*     */ 
/*     */   public boolean isPerThisOrPerTarget()
/*     */   {
/* 157 */     PerClauseKind kind = getAjType().getPerClause().getKind();
/* 158 */     return (kind == PerClauseKind.PERTARGET) || (kind == PerClauseKind.PERTHIS);
/*     */   }
/*     */ 
/*     */   public boolean isPerTypeWithin()
/*     */   {
/* 165 */     PerClauseKind kind = getAjType().getPerClause().getKind();
/* 166 */     return kind == PerClauseKind.PERTYPEWITHIN;
/*     */   }
/*     */ 
/*     */   public boolean isLazilyInstantiated()
/*     */   {
/* 173 */     return (isPerThisOrPerTarget()) || (isPerTypeWithin());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.AspectMetadata
 * JD-Core Version:    0.6.2
 */