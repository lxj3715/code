/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class BeanFactoryAspectInstanceFactory
/*     */   implements MetadataAwareAspectInstanceFactory
/*     */ {
/*     */   private final BeanFactory beanFactory;
/*     */   private final String name;
/*     */   private final AspectMetadata aspectMetadata;
/*     */ 
/*     */   public BeanFactoryAspectInstanceFactory(BeanFactory beanFactory, String name)
/*     */   {
/*  58 */     this(beanFactory, name, beanFactory.getType(name));
/*     */   }
/*     */ 
/*     */   public BeanFactoryAspectInstanceFactory(BeanFactory beanFactory, String name, Class<?> type)
/*     */   {
/*  70 */     this.beanFactory = beanFactory;
/*  71 */     this.name = name;
/*  72 */     this.aspectMetadata = new AspectMetadata(type, name);
/*     */   }
/*     */ 
/*     */   public Object getAspectInstance()
/*     */   {
/*  78 */     return this.beanFactory.getBean(this.name);
/*     */   }
/*     */ 
/*     */   public ClassLoader getAspectClassLoader()
/*     */   {
/*  83 */     if ((this.beanFactory instanceof ConfigurableBeanFactory)) {
/*  84 */       return ((ConfigurableBeanFactory)this.beanFactory).getBeanClassLoader();
/*     */     }
/*     */ 
/*  87 */     return ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   public AspectMetadata getAspectMetadata()
/*     */   {
/*  93 */     return this.aspectMetadata;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 108 */     Class type = this.beanFactory.getType(this.name);
/* 109 */     if (type != null) {
/* 110 */       if ((Ordered.class.isAssignableFrom(type)) && (this.beanFactory.isSingleton(this.name))) {
/* 111 */         return ((Ordered)this.beanFactory.getBean(this.name)).getOrder();
/*     */       }
/* 113 */       Order order = (Order)AnnotationUtils.findAnnotation(type, Order.class);
/* 114 */       if (order != null) {
/* 115 */         return order.value();
/*     */       }
/*     */     }
/* 118 */     return 2147483647;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 124 */     return getClass().getSimpleName() + ": bean name '" + this.name + "'";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.BeanFactoryAspectInstanceFactory
 * JD-Core Version:    0.6.2
 */