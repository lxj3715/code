package org.springframework.aop.aspectj.annotation;

import org.springframework.aop.aspectj.AspectInstanceFactory;

public abstract interface MetadataAwareAspectInstanceFactory extends AspectInstanceFactory
{
  public abstract AspectMetadata getAspectMetadata();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.annotation.MetadataAwareAspectInstanceFactory
 * JD-Core Version:    0.6.2
 */