/*     */ package org.springframework.aop.aspectj.autoproxy;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.aspectj.AspectJAopUtils;
/*     */ import org.springframework.aop.aspectj.AspectJPrecedenceInformation;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ class AspectJPrecedenceComparator
/*     */   implements Comparator<Advisor>
/*     */ {
/*     */   private static final int HIGHER_PRECEDENCE = -1;
/*     */   private static final int SAME_PRECEDENCE = 0;
/*     */   private static final int LOWER_PRECEDENCE = 1;
/*     */   private final Comparator<? super Advisor> advisorComparator;
/*     */ 
/*     */   public AspectJPrecedenceComparator()
/*     */   {
/*  64 */     this.advisorComparator = OrderComparator.INSTANCE;
/*     */   }
/*     */ 
/*     */   public AspectJPrecedenceComparator(Comparator<? super Advisor> advisorComparator)
/*     */   {
/*  73 */     Assert.notNull(advisorComparator, "Advisor comparator must not be null");
/*  74 */     this.advisorComparator = advisorComparator;
/*     */   }
/*     */ 
/*     */   public int compare(Advisor o1, Advisor o2)
/*     */   {
/*  80 */     int advisorPrecedence = this.advisorComparator.compare(o1, o2);
/*  81 */     if ((advisorPrecedence == 0) && (declaredInSameAspect(o1, o2))) {
/*  82 */       advisorPrecedence = comparePrecedenceWithinAspect(o1, o2);
/*     */     }
/*  84 */     return advisorPrecedence;
/*     */   }
/*     */ 
/*     */   private int comparePrecedenceWithinAspect(Advisor advisor1, Advisor advisor2)
/*     */   {
/*  89 */     boolean oneOrOtherIsAfterAdvice = (AspectJAopUtils.isAfterAdvice(advisor1)) || 
/*  89 */       (AspectJAopUtils.isAfterAdvice(advisor2));
/*  90 */     int adviceDeclarationOrderDelta = getAspectDeclarationOrder(advisor1) - getAspectDeclarationOrder(advisor2);
/*     */ 
/*  92 */     if (oneOrOtherIsAfterAdvice)
/*     */     {
/*  94 */       if (adviceDeclarationOrderDelta < 0)
/*     */       {
/*  97 */         return 1;
/*     */       }
/*  99 */       if (adviceDeclarationOrderDelta == 0) {
/* 100 */         return 0;
/*     */       }
/*     */ 
/* 103 */       return -1;
/*     */     }
/*     */ 
/* 108 */     if (adviceDeclarationOrderDelta < 0)
/*     */     {
/* 111 */       return -1;
/*     */     }
/* 113 */     if (adviceDeclarationOrderDelta == 0) {
/* 114 */       return 0;
/*     */     }
/*     */ 
/* 117 */     return 1;
/*     */   }
/*     */ 
/*     */   private boolean declaredInSameAspect(Advisor advisor1, Advisor advisor2)
/*     */   {
/* 124 */     return (hasAspectName(advisor1)) && (hasAspectName(advisor2)) && 
/* 124 */       (getAspectName(advisor1)
/* 124 */       .equals(getAspectName(advisor2)));
/*     */   }
/*     */ 
/*     */   private boolean hasAspectName(Advisor anAdvisor)
/*     */   {
/* 129 */     return ((anAdvisor instanceof AspectJPrecedenceInformation)) || 
/* 129 */       ((anAdvisor
/* 129 */       .getAdvice() instanceof AspectJPrecedenceInformation));
/*     */   }
/*     */ 
/*     */   private String getAspectName(Advisor anAdvisor)
/*     */   {
/* 134 */     return AspectJAopUtils.getAspectJPrecedenceInformationFor(anAdvisor).getAspectName();
/*     */   }
/*     */ 
/*     */   private int getAspectDeclarationOrder(Advisor anAdvisor)
/*     */   {
/* 139 */     AspectJPrecedenceInformation precedenceInfo = AspectJAopUtils.getAspectJPrecedenceInformationFor(anAdvisor);
/*     */ 
/* 140 */     if (precedenceInfo != null) {
/* 141 */       return precedenceInfo.getDeclarationOrder();
/*     */     }
/*     */ 
/* 144 */     return 0;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.aspectj.autoproxy.AspectJPrecedenceComparator
 * JD-Core Version:    0.6.2
 */