/*    */ package org.springframework.aop.config;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.ParseState.Entry;
/*    */ 
/*    */ public class AdviceEntry
/*    */   implements ParseState.Entry
/*    */ {
/*    */   private final String kind;
/*    */ 
/*    */   public AdviceEntry(String kind)
/*    */   {
/* 37 */     this.kind = kind;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 42 */     return "Advice (" + this.kind + ")";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.config.AdviceEntry
 * JD-Core Version:    0.6.2
 */