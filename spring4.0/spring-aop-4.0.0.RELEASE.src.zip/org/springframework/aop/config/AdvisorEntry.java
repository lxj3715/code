/*    */ package org.springframework.aop.config;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.ParseState.Entry;
/*    */ 
/*    */ public class AdvisorEntry
/*    */   implements ParseState.Entry
/*    */ {
/*    */   private final String name;
/*    */ 
/*    */   public AdvisorEntry(String name)
/*    */   {
/* 37 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 42 */     return "Advisor '" + this.name + "'";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.config.AdvisorEntry
 * JD-Core Version:    0.6.2
 */