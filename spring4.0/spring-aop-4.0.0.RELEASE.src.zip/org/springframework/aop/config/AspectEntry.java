/*    */ package org.springframework.aop.config;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.ParseState.Entry;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class AspectEntry
/*    */   implements ParseState.Entry
/*    */ {
/*    */   private final String id;
/*    */   private final String ref;
/*    */ 
/*    */   public AspectEntry(String id, String ref)
/*    */   {
/* 42 */     this.id = id;
/* 43 */     this.ref = ref;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 48 */     return new StringBuilder().append("Aspect: ").append(StringUtils.hasLength(this.id) ? new StringBuilder().append("id='").append(this.id).append("'").toString() : new StringBuilder().append("ref='").append(this.ref).append("'").toString()).toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.config.AspectEntry
 * JD-Core Version:    0.6.2
 */