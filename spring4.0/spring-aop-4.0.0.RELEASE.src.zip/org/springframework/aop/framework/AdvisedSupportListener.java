package org.springframework.aop.framework;

public abstract interface AdvisedSupportListener
{
  public abstract void activated(AdvisedSupport paramAdvisedSupport);

  public abstract void adviceChanged(AdvisedSupport paramAdvisedSupport);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.AdvisedSupportListener
 * JD-Core Version:    0.6.2
 */