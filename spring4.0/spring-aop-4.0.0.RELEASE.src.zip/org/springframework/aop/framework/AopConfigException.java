/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class AopConfigException extends NestedRuntimeException
/*    */ {
/*    */   public AopConfigException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ 
/*    */   public AopConfigException(String msg, Throwable cause)
/*    */   {
/* 44 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.AopConfigException
 * JD-Core Version:    0.6.2
 */