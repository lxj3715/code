package org.springframework.aop.framework;

public abstract interface AopInfrastructureBean
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.AopInfrastructureBean
 * JD-Core Version:    0.6.2
 */