package org.springframework.aop.framework;

public abstract interface AopProxy
{
  public abstract Object getProxy();

  public abstract Object getProxy(ClassLoader paramClassLoader);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.AopProxy
 * JD-Core Version:    0.6.2
 */