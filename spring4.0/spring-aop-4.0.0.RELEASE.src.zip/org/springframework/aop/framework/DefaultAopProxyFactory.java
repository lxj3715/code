/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.aop.SpringProxy;
/*    */ 
/*    */ public class DefaultAopProxyFactory
/*    */   implements AopProxyFactory, Serializable
/*    */ {
/*    */   public AopProxy createAopProxy(AdvisedSupport config)
/*    */     throws AopConfigException
/*    */   {
/* 53 */     if ((config.isOptimize()) || (config.isProxyTargetClass()) || (hasNoUserSuppliedProxyInterfaces(config))) {
/* 54 */       Class targetClass = config.getTargetClass();
/* 55 */       if (targetClass == null) {
/* 56 */         throw new AopConfigException("TargetSource cannot determine target class: Either an interface or a target is required for proxy creation.");
/*    */       }
/*    */ 
/* 59 */       if (targetClass.isInterface()) {
/* 60 */         return new JdkDynamicAopProxy(config);
/*    */       }
/* 62 */       return new ObjenesisCglibAopProxy(config);
/*    */     }
/*    */ 
/* 65 */     return new JdkDynamicAopProxy(config);
/*    */   }
/*    */ 
/*    */   private boolean hasNoUserSuppliedProxyInterfaces(AdvisedSupport config)
/*    */   {
/* 75 */     Class[] interfaces = config.getProxiedInterfaces();
/* 76 */     return (interfaces.length == 0) || ((interfaces.length == 1) && (SpringProxy.class.equals(interfaces[0])));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.DefaultAopProxyFactory
 * JD-Core Version:    0.6.2
 */