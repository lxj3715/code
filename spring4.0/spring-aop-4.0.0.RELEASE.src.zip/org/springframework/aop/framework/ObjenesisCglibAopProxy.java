/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.cglib.proxy.Callback;
/*    */ import org.springframework.cglib.proxy.Enhancer;
/*    */ import org.springframework.cglib.proxy.Factory;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.ObjenesisStd;
/*    */ 
/*    */ class ObjenesisCglibAopProxy extends CglibAopProxy
/*    */ {
/* 38 */   private static final Log logger = LogFactory.getLog(ObjenesisCglibAopProxy.class);
/*    */   private final ObjenesisStd objenesis;
/*    */ 
/*    */   public ObjenesisCglibAopProxy(AdvisedSupport config)
/*    */   {
/* 48 */     super(config);
/* 49 */     this.objenesis = new ObjenesisStd(true);
/*    */   }
/*    */ 
/*    */   protected Object createProxyClassAndInstance(Enhancer enhancer, Callback[] callbacks)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       Factory factory = (Factory)this.objenesis.newInstance(enhancer.createClass());
/* 58 */       factory.setCallbacks(callbacks);
/* 59 */       return factory;
/*    */     }
/*    */     catch (ObjenesisException ex)
/*    */     {
/* 63 */       if (logger.isDebugEnabled()) {
/* 64 */         logger.debug("Unable to instantiate proxy using Objenesis, falling back to regular proxy construction", ex);
/*    */       }
/*    */     }
/* 67 */     return super.createProxyClassAndInstance(enhancer, callbacks);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.ObjenesisCglibAopProxy
 * JD-Core Version:    0.6.2
 */