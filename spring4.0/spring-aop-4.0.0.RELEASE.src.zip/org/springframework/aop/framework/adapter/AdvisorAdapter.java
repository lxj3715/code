package org.springframework.aop.framework.adapter;

import org.aopalliance.aop.Advice;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.Advisor;

public abstract interface AdvisorAdapter
{
  public abstract boolean supportsAdvice(Advice paramAdvice);

  public abstract MethodInterceptor getInterceptor(Advisor paramAdvisor);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.adapter.AdvisorAdapter
 * JD-Core Version:    0.6.2
 */