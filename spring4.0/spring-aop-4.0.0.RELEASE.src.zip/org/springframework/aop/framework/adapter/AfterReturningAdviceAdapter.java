/*    */ package org.springframework.aop.framework.adapter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.aop.AfterReturningAdvice;
/*    */ 
/*    */ class AfterReturningAdviceAdapter
/*    */   implements AdvisorAdapter, Serializable
/*    */ {
/*    */   public boolean supportsAdvice(Advice advice)
/*    */   {
/* 39 */     return advice instanceof AfterReturningAdvice;
/*    */   }
/*    */ 
/*    */   public MethodInterceptor getInterceptor(Advisor advisor)
/*    */   {
/* 44 */     AfterReturningAdvice advice = (AfterReturningAdvice)advisor.getAdvice();
/* 45 */     return new AfterReturningAdviceInterceptor(advice);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.adapter.AfterReturningAdviceAdapter
 * JD-Core Version:    0.6.2
 */