/*     */ package org.springframework.aop.framework.autoproxy;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.aop.framework.ProxyConfig;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.framework.adapter.AdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public abstract class AbstractAutoProxyCreator extends ProxyConfig
/*     */   implements SmartInstantiationAwareBeanPostProcessor, BeanClassLoaderAware, BeanFactoryAware, Ordered, AopInfrastructureBean
/*     */ {
/* 101 */   protected static final Object[] DO_NOT_PROXY = null;
/*     */ 
/* 108 */   protected static final Object[] PROXY_WITHOUT_ADDITIONAL_INTERCEPTORS = new Object[0];
/*     */ 
/* 112 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/* 115 */   private int order = 2147483647;
/*     */ 
/* 118 */   private AdvisorAdapterRegistry advisorAdapterRegistry = GlobalAdvisorAdapterRegistry.getInstance();
/*     */ 
/* 124 */   private boolean freezeProxy = false;
/*     */ 
/* 127 */   private String[] interceptorNames = new String[0];
/*     */ 
/* 129 */   private boolean applyCommonInterceptorsFirst = true;
/*     */   private TargetSourceCreator[] customTargetSourceCreators;
/* 133 */   private ClassLoader proxyClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/* 135 */   private boolean classLoaderConfigured = false;
/*     */   private BeanFactory beanFactory;
/* 139 */   private final Map<Object, Boolean> advisedBeans = new ConcurrentHashMap(64);
/*     */ 
/* 142 */   private final Set<String> targetSourcedBeans = Collections.newSetFromMap(new ConcurrentHashMap(16))
/* 142 */     ;
/*     */ 
/* 145 */   private final Set<Object> earlyProxyReferences = Collections.newSetFromMap(new ConcurrentHashMap(16))
/* 145 */     ;
/*     */ 
/* 147 */   private final Map<Object, Class<?>> proxyTypes = new ConcurrentHashMap(16);
/*     */ 
/*     */   public final void setOrder(int order)
/*     */   {
/* 157 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public final int getOrder()
/*     */   {
/* 162 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void setFrozen(boolean frozen)
/*     */   {
/* 173 */     this.freezeProxy = frozen;
/*     */   }
/*     */ 
/*     */   public boolean isFrozen()
/*     */   {
/* 178 */     return this.freezeProxy;
/*     */   }
/*     */ 
/*     */   public void setAdvisorAdapterRegistry(AdvisorAdapterRegistry advisorAdapterRegistry)
/*     */   {
/* 187 */     this.advisorAdapterRegistry = advisorAdapterRegistry;
/*     */   }
/*     */ 
/*     */   public void setCustomTargetSourceCreators(TargetSourceCreator[] targetSourceCreators)
/*     */   {
/* 205 */     this.customTargetSourceCreators = targetSourceCreators;
/*     */   }
/*     */ 
/*     */   public void setInterceptorNames(String[] interceptorNames)
/*     */   {
/* 216 */     this.interceptorNames = interceptorNames;
/*     */   }
/*     */ 
/*     */   public void setApplyCommonInterceptorsFirst(boolean applyCommonInterceptorsFirst)
/*     */   {
/* 224 */     this.applyCommonInterceptorsFirst = applyCommonInterceptorsFirst;
/*     */   }
/*     */ 
/*     */   public void setProxyClassLoader(ClassLoader classLoader)
/*     */   {
/* 234 */     this.proxyClassLoader = classLoader;
/* 235 */     this.classLoaderConfigured = (classLoader != null);
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 240 */     if (!this.classLoaderConfigured)
/* 241 */       this.proxyClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 247 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   protected BeanFactory getBeanFactory()
/*     */   {
/* 255 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   public Class<?> predictBeanType(Class<?> beanClass, String beanName)
/*     */   {
/* 261 */     Object cacheKey = getCacheKey(beanClass, beanName);
/* 262 */     return (Class)this.proxyTypes.get(cacheKey);
/*     */   }
/*     */ 
/*     */   public Constructor<?>[] determineCandidateConstructors(Class<?> beanClass, String beanName) throws BeansException
/*     */   {
/* 267 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getEarlyBeanReference(Object bean, String beanName) throws BeansException
/*     */   {
/* 272 */     Object cacheKey = getCacheKey(bean.getClass(), beanName);
/* 273 */     this.earlyProxyReferences.add(cacheKey);
/* 274 */     return wrapIfNecessary(bean, beanName, cacheKey);
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException
/*     */   {
/* 279 */     Object cacheKey = getCacheKey(beanClass, beanName);
/*     */ 
/* 281 */     if ((beanName == null) || (!this.targetSourcedBeans.contains(beanName))) {
/* 282 */       if (this.advisedBeans.containsKey(cacheKey)) {
/* 283 */         return null;
/*     */       }
/* 285 */       if ((isInfrastructureClass(beanClass)) || (shouldSkip(beanClass, beanName))) {
/* 286 */         this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 287 */         return null;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 294 */     if (beanName != null) {
/* 295 */       TargetSource targetSource = getCustomTargetSource(beanClass, beanName);
/* 296 */       if (targetSource != null) {
/* 297 */         this.targetSourcedBeans.add(beanName);
/* 298 */         Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(beanClass, beanName, targetSource);
/* 299 */         Object proxy = createProxy(beanClass, beanName, specificInterceptors, targetSource);
/* 300 */         this.proxyTypes.put(cacheKey, proxy.getClass());
/* 301 */         return proxy;
/*     */       }
/*     */     }
/*     */ 
/* 305 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean postProcessAfterInstantiation(Object bean, String beanName)
/*     */   {
/* 310 */     return true;
/*     */   }
/*     */ 
/*     */   public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean, String beanName)
/*     */   {
/* 317 */     return pvs;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */   {
/* 322 */     return bean;
/*     */   }
/*     */ 
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 332 */     if (bean != null) {
/* 333 */       Object cacheKey = getCacheKey(bean.getClass(), beanName);
/* 334 */       if (!this.earlyProxyReferences.contains(cacheKey)) {
/* 335 */         return wrapIfNecessary(bean, beanName, cacheKey);
/*     */       }
/*     */     }
/* 338 */     return bean;
/*     */   }
/*     */ 
/*     */   protected Object getCacheKey(Class<?> beanClass, String beanName)
/*     */   {
/* 349 */     return beanClass.getName() + "_" + beanName;
/*     */   }
/*     */ 
/*     */   protected Object wrapIfNecessary(Object bean, String beanName, Object cacheKey)
/*     */   {
/* 360 */     if ((beanName != null) && (this.targetSourcedBeans.contains(beanName))) {
/* 361 */       return bean;
/*     */     }
/* 363 */     if (Boolean.FALSE.equals(this.advisedBeans.get(cacheKey))) {
/* 364 */       return bean;
/*     */     }
/* 366 */     if ((isInfrastructureClass(bean.getClass())) || (shouldSkip(bean.getClass(), beanName))) {
/* 367 */       this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 368 */       return bean;
/*     */     }
/*     */ 
/* 372 */     Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(bean.getClass(), beanName, null);
/* 373 */     if (specificInterceptors != DO_NOT_PROXY) {
/* 374 */       this.advisedBeans.put(cacheKey, Boolean.TRUE);
/* 375 */       Object proxy = createProxy(bean.getClass(), beanName, specificInterceptors, new SingletonTargetSource(bean));
/* 376 */       this.proxyTypes.put(cacheKey, proxy.getClass());
/* 377 */       return proxy;
/*     */     }
/*     */ 
/* 380 */     this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 381 */     return bean;
/*     */   }
/*     */ 
/*     */   protected boolean isInfrastructureClass(Class<?> beanClass)
/*     */   {
/* 399 */     boolean retVal = (Advice.class.isAssignableFrom(beanClass)) || 
/* 398 */       (Advisor.class
/* 398 */       .isAssignableFrom(beanClass)) || 
/* 399 */       (AopInfrastructureBean.class
/* 399 */       .isAssignableFrom(beanClass));
/*     */ 
/* 400 */     if ((retVal) && (this.logger.isTraceEnabled())) {
/* 401 */       this.logger.trace("Did not attempt to auto-proxy infrastructure class [" + beanClass.getName() + "]");
/*     */     }
/* 403 */     return retVal;
/*     */   }
/*     */ 
/*     */   protected boolean shouldSkip(Class<?> beanClass, String beanName)
/*     */   {
/* 416 */     return false;
/*     */   }
/*     */ 
/*     */   protected TargetSource getCustomTargetSource(Class<?> beanClass, String beanName)
/*     */   {
/* 431 */     if ((this.customTargetSourceCreators != null) && (this.beanFactory != null) && 
/* 432 */       (this.beanFactory
/* 432 */       .containsBean(beanName)))
/*     */     {
/* 433 */       for (TargetSourceCreator tsc : this.customTargetSourceCreators) {
/* 434 */         TargetSource ts = tsc.getTargetSource(beanClass, beanName);
/* 435 */         if (ts != null)
/*     */         {
/* 437 */           if (this.logger.isDebugEnabled()) {
/* 438 */             this.logger.debug("TargetSourceCreator [" + tsc + " found custom TargetSource for bean with name '" + beanName + "'");
/*     */           }
/*     */ 
/* 441 */           return ts;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 447 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object createProxy(Class<?> beanClass, String beanName, Object[] specificInterceptors, TargetSource targetSource)
/*     */   {
/* 464 */     ProxyFactory proxyFactory = new ProxyFactory();
/*     */ 
/* 466 */     proxyFactory.copyFrom(this);
/*     */ 
/* 468 */     if (!shouldProxyTargetClass(beanClass, beanName))
/*     */     {
/* 471 */       Class[] targetInterfaces = ClassUtils.getAllInterfacesForClass(beanClass, this.proxyClassLoader);
/* 472 */       for (Class targetInterface : targetInterfaces) {
/* 473 */         proxyFactory.addInterface(targetInterface);
/*     */       }
/*     */     }
/*     */ 
/* 477 */     Advisor[] advisors = buildAdvisors(beanName, specificInterceptors);
/* 478 */     for (Advisor advisor : advisors) {
/* 479 */       proxyFactory.addAdvisor(advisor);
/*     */     }
/*     */ 
/* 482 */     proxyFactory.setTargetSource(targetSource);
/* 483 */     customizeProxyFactory(proxyFactory);
/*     */ 
/* 485 */     proxyFactory.setFrozen(this.freezeProxy);
/* 486 */     if (advisorsPreFiltered()) {
/* 487 */       proxyFactory.setPreFiltered(true);
/*     */     }
/*     */ 
/* 490 */     return proxyFactory.getProxy(this.proxyClassLoader);
/*     */   }
/*     */ 
/*     */   protected boolean shouldProxyTargetClass(Class<?> beanClass, String beanName)
/*     */   {
/* 505 */     if (!isProxyTargetClass()) if (!(this.beanFactory instanceof ConfigurableListableBeanFactory))
/*     */         break label35;
/* 507 */     label35: return AutoProxyUtils.shouldProxyTargetClass((ConfigurableListableBeanFactory)this.beanFactory, beanName);
/*     */   }
/*     */ 
/*     */   protected boolean advisorsPreFiltered()
/*     */   {
/* 521 */     return false;
/*     */   }
/*     */ 
/*     */   protected Advisor[] buildAdvisors(String beanName, Object[] specificInterceptors)
/*     */   {
/* 534 */     Advisor[] commonInterceptors = resolveInterceptorNames();
/*     */ 
/* 536 */     List allInterceptors = new ArrayList();
/* 537 */     if (specificInterceptors != null) {
/* 538 */       allInterceptors.addAll(Arrays.asList(specificInterceptors));
/* 539 */       if (commonInterceptors != null) {
/* 540 */         if (this.applyCommonInterceptorsFirst) {
/* 541 */           allInterceptors.addAll(0, Arrays.asList(commonInterceptors));
/*     */         }
/*     */         else {
/* 544 */           allInterceptors.addAll(Arrays.asList(commonInterceptors));
/*     */         }
/*     */       }
/*     */     }
/* 548 */     if (this.logger.isDebugEnabled()) {
/* 549 */       int nrOfCommonInterceptors = commonInterceptors != null ? commonInterceptors.length : 0;
/* 550 */       int nrOfSpecificInterceptors = specificInterceptors != null ? specificInterceptors.length : 0;
/* 551 */       this.logger.debug("Creating implicit proxy for bean '" + beanName + "' with " + nrOfCommonInterceptors + " common interceptors and " + nrOfSpecificInterceptors + " specific interceptors");
/*     */     }
/*     */ 
/* 555 */     Advisor[] advisors = new Advisor[allInterceptors.size()];
/* 556 */     for (int i = 0; i < allInterceptors.size(); i++) {
/* 557 */       advisors[i] = this.advisorAdapterRegistry.wrap(allInterceptors.get(i));
/*     */     }
/* 559 */     return advisors;
/*     */   }
/*     */ 
/*     */   private Advisor[] resolveInterceptorNames()
/*     */   {
/* 567 */     ConfigurableBeanFactory cbf = (this.beanFactory instanceof ConfigurableBeanFactory) ? (ConfigurableBeanFactory)this.beanFactory : null;
/*     */ 
/* 569 */     List advisors = new ArrayList();
/* 570 */     for (String beanName : this.interceptorNames) {
/* 571 */       if ((cbf == null) || (!cbf.isCurrentlyInCreation(beanName))) {
/* 572 */         Object next = this.beanFactory.getBean(beanName);
/* 573 */         advisors.add(this.advisorAdapterRegistry.wrap(next));
/*     */       }
/*     */     }
/* 576 */     return (Advisor[])advisors.toArray(new Advisor[advisors.size()]);
/*     */   }
/*     */ 
/*     */   protected void customizeProxyFactory(ProxyFactory proxyFactory)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected abstract Object[] getAdvicesAndAdvisorsForBean(Class<?> paramClass, String paramString, TargetSource paramTargetSource)
/*     */     throws BeansException;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.autoproxy.AbstractAutoProxyCreator
 * JD-Core Version:    0.6.2
 */