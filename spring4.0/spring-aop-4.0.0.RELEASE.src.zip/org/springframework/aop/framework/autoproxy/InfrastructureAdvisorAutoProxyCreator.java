/*    */ package org.springframework.aop.framework.autoproxy;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ 
/*    */ public class InfrastructureAdvisorAutoProxyCreator extends AbstractAdvisorAutoProxyCreator
/*    */ {
/*    */   private ConfigurableListableBeanFactory beanFactory;
/*    */ 
/*    */   protected void initBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*    */   {
/* 37 */     super.initBeanFactory(beanFactory);
/* 38 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */   protected boolean isEligibleAdvisorBean(String beanName)
/*    */   {
/* 44 */     return (this.beanFactory.containsBeanDefinition(beanName)) && 
/* 44 */       (this.beanFactory
/* 44 */       .getBeanDefinition(beanName)
/* 44 */       .getRole() == 2);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.framework.autoproxy.InfrastructureAdvisorAutoProxyCreator
 * JD-Core Version:    0.6.2
 */