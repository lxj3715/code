/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.support.TaskExecutorAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AsyncExecutionAspectSupport
/*     */   implements BeanFactoryAware
/*     */ {
/*  48 */   private final Map<Method, AsyncTaskExecutor> executors = new ConcurrentHashMap(16);
/*     */   private Executor defaultExecutor;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public AsyncExecutionAspectSupport(Executor defaultExecutor)
/*     */   {
/*  62 */     this.defaultExecutor = defaultExecutor;
/*     */   }
/*     */ 
/*     */   public void setExecutor(Executor defaultExecutor)
/*     */   {
/*  77 */     this.defaultExecutor = defaultExecutor;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */     throws BeansException
/*     */   {
/*  85 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   protected AsyncTaskExecutor determineAsyncExecutor(Method method)
/*     */   {
/*  94 */     AsyncTaskExecutor executor = (AsyncTaskExecutor)this.executors.get(method);
/*  95 */     if (executor == null) {
/*  96 */       Executor executorToUse = this.defaultExecutor;
/*  97 */       String qualifier = getExecutorQualifier(method);
/*  98 */       if (StringUtils.hasLength(qualifier)) {
/*  99 */         Assert.notNull(this.beanFactory, "BeanFactory must be set on " + getClass().getSimpleName() + " to access qualified executor '" + qualifier + "'");
/*     */ 
/* 101 */         executorToUse = (Executor)BeanFactoryAnnotationUtils.qualifiedBeanOfType(this.beanFactory, Executor.class, qualifier);
/*     */       }
/* 104 */       else if (executorToUse == null) {
/* 105 */         return null;
/*     */       }
/* 107 */       executor = (executorToUse instanceof AsyncTaskExecutor) ? (AsyncTaskExecutor)executorToUse : new TaskExecutorAdapter(executorToUse);
/*     */ 
/* 109 */       this.executors.put(method, executor);
/*     */     }
/* 111 */     return executor;
/*     */   }
/*     */ 
/*     */   protected abstract String getExecutorQualifier(Method paramMethod);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.interceptor.AsyncExecutionAspectSupport
 * JD-Core Version:    0.6.2
 */