/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Future;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class AsyncExecutionInterceptor extends AsyncExecutionAspectSupport
/*     */   implements MethodInterceptor, Ordered
/*     */ {
/*     */   public AsyncExecutionInterceptor(Executor executor)
/*     */   {
/*  69 */     super(executor);
/*     */   }
/*     */ 
/*     */   public Object invoke(final MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  82 */     Class targetClass = invocation.getThis() != null ? AopUtils.getTargetClass(invocation.getThis()) : null;
/*  83 */     Method specificMethod = ClassUtils.getMostSpecificMethod(invocation.getMethod(), targetClass);
/*  84 */     specificMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/*     */ 
/*  86 */     AsyncTaskExecutor executor = determineAsyncExecutor(specificMethod);
/*  87 */     if (executor == null) {
/*  88 */       throw new IllegalStateException("No executor specified and no default executor set on AsyncExecutionInterceptor either");
/*     */     }
/*     */ 
/*  92 */     Future result = executor.submit(new Callable()
/*     */     {
/*     */       public Object call() throws Exception
/*     */       {
/*     */         try {
/*  97 */           Object result = invocation.proceed();
/*  98 */           if ((result instanceof Future))
/*  99 */             return ((Future)result).get();
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/* 103 */           ReflectionUtils.rethrowException(ex);
/*     */         }
/* 105 */         return null;
/*     */       }
/*     */     });
/* 109 */     if (Future.class.isAssignableFrom(invocation.getMethod().getReturnType())) {
/* 110 */       return result;
/*     */     }
/*     */ 
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   protected String getExecutorQualifier(Method method)
/*     */   {
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 132 */     return -2147483648;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.interceptor.AsyncExecutionInterceptor
 * JD-Core Version:    0.6.2
 */