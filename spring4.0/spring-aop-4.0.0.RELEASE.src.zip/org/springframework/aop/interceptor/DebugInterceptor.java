/*    */ package org.springframework.aop.interceptor;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ 
/*    */ public class DebugInterceptor extends SimpleTraceInterceptor
/*    */ {
/*    */   private volatile long count;
/*    */ 
/*    */   public DebugInterceptor()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DebugInterceptor(boolean useDynamicLogger)
/*    */   {
/* 54 */     setUseDynamicLogger(useDynamicLogger);
/*    */   }
/*    */ 
/*    */   public Object invoke(MethodInvocation invocation)
/*    */     throws Throwable
/*    */   {
/* 60 */     synchronized (this) {
/* 61 */       this.count += 1L;
/*    */     }
/* 63 */     return super.invoke(invocation);
/*    */   }
/*    */ 
/*    */   protected String getInvocationDescription(MethodInvocation invocation)
/*    */   {
/* 68 */     return invocation + "; count=" + this.count;
/*    */   }
/*    */ 
/*    */   public long getCount()
/*    */   {
/* 76 */     return this.count;
/*    */   }
/*    */ 
/*    */   public synchronized void resetCount()
/*    */   {
/* 83 */     this.count = 0L;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.interceptor.DebugInterceptor
 * JD-Core Version:    0.6.2
 */