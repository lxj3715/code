/*    */ package org.springframework.aop.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ public class SimpleTraceInterceptor extends AbstractTraceInterceptor
/*    */ {
/*    */   public SimpleTraceInterceptor()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SimpleTraceInterceptor(boolean useDynamicLogger)
/*    */   {
/* 51 */     setUseDynamicLogger(useDynamicLogger);
/*    */   }
/*    */ 
/*    */   protected Object invokeUnderTrace(MethodInvocation invocation, Log logger)
/*    */     throws Throwable
/*    */   {
/* 57 */     String invocationDescription = getInvocationDescription(invocation);
/* 58 */     logger.trace("Entering " + invocationDescription);
/*    */     try {
/* 60 */       Object rval = invocation.proceed();
/* 61 */       logger.trace("Exiting " + invocationDescription);
/* 62 */       return rval;
/*    */     }
/*    */     catch (Throwable ex) {
/* 65 */       logger.trace("Exception thrown in " + invocationDescription, ex);
/* 66 */       throw ex;
/*    */     }
/*    */   }
/*    */ 
/*    */   protected String getInvocationDescription(MethodInvocation invocation)
/*    */   {
/* 77 */     return "method '" + invocation.getMethod().getName() + "' of class [" + invocation
/* 77 */       .getThis().getClass().getName() + "]";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.interceptor.SimpleTraceInterceptor
 * JD-Core Version:    0.6.2
 */