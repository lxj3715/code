/*    */ package org.springframework.aop.scope;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class DefaultScopedObject
/*    */   implements ScopedObject, Serializable
/*    */ {
/*    */   private final ConfigurableBeanFactory beanFactory;
/*    */   private final String targetBeanName;
/*    */ 
/*    */   public DefaultScopedObject(ConfigurableBeanFactory beanFactory, String targetBeanName)
/*    */   {
/* 51 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 52 */     Assert.hasText(targetBeanName, "'targetBeanName' must not be empty");
/* 53 */     this.beanFactory = beanFactory;
/* 54 */     this.targetBeanName = targetBeanName;
/*    */   }
/*    */ 
/*    */   public Object getTargetObject()
/*    */   {
/* 60 */     return this.beanFactory.getBean(this.targetBeanName);
/*    */   }
/*    */ 
/*    */   public void removeFromScope()
/*    */   {
/* 65 */     this.beanFactory.destroyScopedBean(this.targetBeanName);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.scope.DefaultScopedObject
 * JD-Core Version:    0.6.2
 */