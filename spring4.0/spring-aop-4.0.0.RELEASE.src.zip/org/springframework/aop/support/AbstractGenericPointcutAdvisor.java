/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import org.aopalliance.aop.Advice;
/*    */ 
/*    */ public abstract class AbstractGenericPointcutAdvisor extends AbstractPointcutAdvisor
/*    */ {
/*    */   private Advice advice;
/*    */ 
/*    */   public void setAdvice(Advice advice)
/*    */   {
/* 39 */     this.advice = advice;
/*    */   }
/*    */ 
/*    */   public Advice getAdvice()
/*    */   {
/* 44 */     return this.advice;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 50 */     return getClass().getName() + ": advice [" + getAdvice() + "]";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.AbstractGenericPointcutAdvisor
 * JD-Core Version:    0.6.2
 */