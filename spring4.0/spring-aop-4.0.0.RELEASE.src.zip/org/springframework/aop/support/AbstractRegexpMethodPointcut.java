/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractRegexpMethodPointcut extends StaticMethodMatcherPointcut
/*     */   implements Serializable
/*     */ {
/*  55 */   private String[] patterns = new String[0];
/*     */ 
/*  58 */   private String[] excludedPatterns = new String[0];
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/*  67 */     setPatterns(new String[] { pattern });
/*     */   }
/*     */ 
/*     */   public void setPatterns(String[] patterns)
/*     */   {
/*  76 */     Assert.notEmpty(patterns, "'patterns' must not be empty");
/*  77 */     this.patterns = new String[patterns.length];
/*  78 */     for (int i = 0; i < patterns.length; i++) {
/*  79 */       this.patterns[i] = StringUtils.trimWhitespace(patterns[i]);
/*     */     }
/*  81 */     initPatternRepresentation(this.patterns);
/*     */   }
/*     */ 
/*     */   public String[] getPatterns()
/*     */   {
/*  88 */     return this.patterns;
/*     */   }
/*     */ 
/*     */   public void setExcludedPattern(String excludedPattern)
/*     */   {
/*  97 */     setExcludedPatterns(new String[] { excludedPattern });
/*     */   }
/*     */ 
/*     */   public void setExcludedPatterns(String[] excludedPatterns)
/*     */   {
/* 106 */     Assert.notEmpty(excludedPatterns, "'excludedPatterns' must not be empty");
/* 107 */     this.excludedPatterns = new String[excludedPatterns.length];
/* 108 */     for (int i = 0; i < excludedPatterns.length; i++) {
/* 109 */       this.excludedPatterns[i] = StringUtils.trimWhitespace(excludedPatterns[i]);
/*     */     }
/* 111 */     initExcludedPatternRepresentation(this.excludedPatterns);
/*     */   }
/*     */ 
/*     */   public String[] getExcludedPatterns()
/*     */   {
/* 118 */     return this.excludedPatterns;
/*     */   }
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass)
/*     */   {
/* 130 */     return ((targetClass != null) && (matchesPattern(targetClass.getName() + "." + method.getName()))) || 
/* 130 */       (matchesPattern(method
/* 130 */       .getDeclaringClass().getName() + "." + method.getName()));
/*     */   }
/*     */ 
/*     */   protected boolean matchesPattern(String signatureString)
/*     */   {
/* 139 */     for (int i = 0; i < this.patterns.length; i++) {
/* 140 */       boolean matched = matches(signatureString, i);
/* 141 */       if (matched) {
/* 142 */         for (int j = 0; j < this.excludedPatterns.length; j++) {
/* 143 */           boolean excluded = matchesExclusion(signatureString, j);
/* 144 */           if (excluded) {
/* 145 */             return false;
/*     */           }
/*     */         }
/* 148 */         return true;
/*     */       }
/*     */     }
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   protected abstract void initPatternRepresentation(String[] paramArrayOfString)
/*     */     throws IllegalArgumentException;
/*     */ 
/*     */   protected abstract void initExcludedPatternRepresentation(String[] paramArrayOfString)
/*     */     throws IllegalArgumentException;
/*     */ 
/*     */   protected abstract boolean matches(String paramString, int paramInt);
/*     */ 
/*     */   protected abstract boolean matchesExclusion(String paramString, int paramInt);
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 194 */     if (this == other) {
/* 195 */       return true;
/*     */     }
/* 197 */     if (!(other instanceof AbstractRegexpMethodPointcut)) {
/* 198 */       return false;
/*     */     }
/* 200 */     AbstractRegexpMethodPointcut otherPointcut = (AbstractRegexpMethodPointcut)other;
/*     */ 
/* 202 */     return (Arrays.equals(this.patterns, otherPointcut.patterns)) && 
/* 202 */       (Arrays.equals(this.excludedPatterns, otherPointcut.excludedPatterns));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 207 */     int result = 27;
/* 208 */     for (String pattern : this.patterns) {
/* 209 */       result = 13 * result + pattern.hashCode();
/*     */     }
/* 211 */     for (String excludedPattern : this.excludedPatterns) {
/* 212 */       result = 13 * result + excludedPattern.hashCode();
/*     */     }
/* 214 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 220 */     return getClass().getName() + ": patterns " + ObjectUtils.nullSafeToString(this.patterns) + ", excluded patterns " + 
/* 220 */       ObjectUtils.nullSafeToString(this.excludedPatterns);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.AbstractRegexpMethodPointcut
 * JD-Core Version:    0.6.2
 */