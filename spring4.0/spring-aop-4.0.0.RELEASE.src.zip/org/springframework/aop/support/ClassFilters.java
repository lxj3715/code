/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class ClassFilters
/*     */ {
/*     */   public static ClassFilter union(ClassFilter cf1, ClassFilter cf2)
/*     */   {
/*  46 */     Assert.notNull(cf1, "First ClassFilter must not be null");
/*  47 */     Assert.notNull(cf2, "Second ClassFilter must not be null");
/*  48 */     return new UnionClassFilter(new ClassFilter[] { cf1, cf2 });
/*     */   }
/*     */ 
/*     */   public static ClassFilter union(ClassFilter[] classFilters)
/*     */   {
/*  58 */     Assert.notEmpty(classFilters, "ClassFilter array must not be empty");
/*  59 */     return new UnionClassFilter(classFilters);
/*     */   }
/*     */ 
/*     */   public static ClassFilter intersection(ClassFilter cf1, ClassFilter cf2)
/*     */   {
/*  70 */     Assert.notNull(cf1, "First ClassFilter must not be null");
/*  71 */     Assert.notNull(cf2, "Second ClassFilter must not be null");
/*  72 */     return new IntersectionClassFilter(new ClassFilter[] { cf1, cf2 });
/*     */   }
/*     */ 
/*     */   public static ClassFilter intersection(ClassFilter[] classFilters)
/*     */   {
/*  82 */     Assert.notEmpty(classFilters, "ClassFilter array must not be empty");
/*  83 */     return new IntersectionClassFilter(classFilters);
/*     */   }
/*     */ 
/*     */   private static class IntersectionClassFilter
/*     */     implements ClassFilter, Serializable
/*     */   {
/*     */     private ClassFilter[] filters;
/*     */ 
/*     */     public IntersectionClassFilter(ClassFilter[] filters)
/*     */     {
/* 131 */       this.filters = filters;
/*     */     }
/*     */ 
/*     */     public boolean matches(Class<?> clazz)
/*     */     {
/* 136 */       for (int i = 0; i < this.filters.length; i++) {
/* 137 */         if (!this.filters[i].matches(clazz)) {
/* 138 */           return false;
/*     */         }
/*     */       }
/* 141 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 147 */       return (this == other) || (((other instanceof IntersectionClassFilter)) && 
/* 147 */         (ObjectUtils.nullSafeEquals(this.filters, ((IntersectionClassFilter)other).filters)));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 152 */       return ObjectUtils.nullSafeHashCode(this.filters);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class UnionClassFilter
/*     */     implements ClassFilter, Serializable
/*     */   {
/*     */     private ClassFilter[] filters;
/*     */ 
/*     */     public UnionClassFilter(ClassFilter[] filters)
/*     */     {
/*  96 */       this.filters = filters;
/*     */     }
/*     */ 
/*     */     public boolean matches(Class<?> clazz)
/*     */     {
/* 101 */       for (int i = 0; i < this.filters.length; i++) {
/* 102 */         if (this.filters[i].matches(clazz)) {
/* 103 */           return true;
/*     */         }
/*     */       }
/* 106 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 112 */       return (this == other) || (((other instanceof UnionClassFilter)) && 
/* 112 */         (ObjectUtils.nullSafeEquals(this.filters, ((UnionClassFilter)other).filters)));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 117 */       return ObjectUtils.nullSafeHashCode(this.filters);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.ClassFilters
 * JD-Core Version:    0.6.2
 */