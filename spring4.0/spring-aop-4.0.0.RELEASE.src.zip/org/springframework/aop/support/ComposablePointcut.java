/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class ComposablePointcut
/*     */   implements Pointcut, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -2743223737633663832L;
/*     */   private ClassFilter classFilter;
/*     */   private MethodMatcher methodMatcher;
/*     */ 
/*     */   public ComposablePointcut()
/*     */   {
/*  56 */     this.classFilter = ClassFilter.TRUE;
/*  57 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut(Pointcut pointcut)
/*     */   {
/*  65 */     Assert.notNull(pointcut, "Pointcut must not be null");
/*  66 */     this.classFilter = pointcut.getClassFilter();
/*  67 */     this.methodMatcher = pointcut.getMethodMatcher();
/*     */   }
/*     */ 
/*     */   public ComposablePointcut(ClassFilter classFilter)
/*     */   {
/*  76 */     Assert.notNull(classFilter, "ClassFilter must not be null");
/*  77 */     this.classFilter = classFilter;
/*  78 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut(MethodMatcher methodMatcher)
/*     */   {
/*  87 */     Assert.notNull(methodMatcher, "MethodMatcher must not be null");
/*  88 */     this.classFilter = ClassFilter.TRUE;
/*  89 */     this.methodMatcher = methodMatcher;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut(ClassFilter classFilter, MethodMatcher methodMatcher)
/*     */   {
/*  98 */     Assert.notNull(classFilter, "ClassFilter must not be null");
/*  99 */     Assert.notNull(methodMatcher, "MethodMatcher must not be null");
/* 100 */     this.classFilter = classFilter;
/* 101 */     this.methodMatcher = methodMatcher;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut union(ClassFilter other)
/*     */   {
/* 111 */     this.classFilter = ClassFilters.union(this.classFilter, other);
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut intersection(ClassFilter other)
/*     */   {
/* 121 */     this.classFilter = ClassFilters.intersection(this.classFilter, other);
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut union(MethodMatcher other)
/*     */   {
/* 131 */     this.methodMatcher = MethodMatchers.union(this.methodMatcher, other);
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut intersection(MethodMatcher other)
/*     */   {
/* 141 */     this.methodMatcher = MethodMatchers.intersection(this.methodMatcher, other);
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut union(Pointcut other)
/*     */   {
/* 155 */     this.methodMatcher = MethodMatchers.union(this.methodMatcher, this.classFilter, other
/* 156 */       .getMethodMatcher(), other.getClassFilter());
/* 157 */     this.classFilter = ClassFilters.union(this.classFilter, other.getClassFilter());
/* 158 */     return this;
/*     */   }
/*     */ 
/*     */   public ComposablePointcut intersection(Pointcut other)
/*     */   {
/* 167 */     this.classFilter = ClassFilters.intersection(this.classFilter, other.getClassFilter());
/* 168 */     this.methodMatcher = MethodMatchers.intersection(this.methodMatcher, other.getMethodMatcher());
/* 169 */     return this;
/*     */   }
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/* 175 */     return this.classFilter;
/*     */   }
/*     */ 
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 180 */     return this.methodMatcher;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 186 */     if (this == other) {
/* 187 */       return true;
/*     */     }
/* 189 */     if (!(other instanceof ComposablePointcut)) {
/* 190 */       return false;
/*     */     }
/*     */ 
/* 193 */     ComposablePointcut that = (ComposablePointcut)other;
/*     */ 
/* 195 */     return (ObjectUtils.nullSafeEquals(that.classFilter, this.classFilter)) && 
/* 195 */       (ObjectUtils.nullSafeEquals(that.methodMatcher, this.methodMatcher));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 200 */     int code = 17;
/* 201 */     if (this.classFilter != null) {
/* 202 */       code = 37 * code + this.classFilter.hashCode();
/*     */     }
/* 204 */     if (this.methodMatcher != null) {
/* 205 */       code = 37 * code + this.methodMatcher.hashCode();
/*     */     }
/* 207 */     return code;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 212 */     return "ComposablePointcut: ClassFilter [" + this.classFilter + "], MethodMatcher [" + this.methodMatcher + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.ComposablePointcut
 * JD-Core Version:    0.6.2
 */