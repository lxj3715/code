/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.MethodMatcher;
/*    */ import org.springframework.aop.Pointcut;
/*    */ 
/*    */ public abstract class DynamicMethodMatcherPointcut extends DynamicMethodMatcher
/*    */   implements Pointcut
/*    */ {
/*    */   public ClassFilter getClassFilter()
/*    */   {
/* 35 */     return ClassFilter.TRUE;
/*    */   }
/*    */ 
/*    */   public final MethodMatcher getMethodMatcher()
/*    */   {
/* 40 */     return this;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.DynamicMethodMatcherPointcut
 * JD-Core Version:    0.6.2
 */