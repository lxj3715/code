/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class MethodMatchers
/*     */ {
/*     */   public static MethodMatcher union(MethodMatcher mm1, MethodMatcher mm2)
/*     */   {
/*  52 */     return new UnionMethodMatcher(mm1, mm2);
/*     */   }
/*     */ 
/*     */   static MethodMatcher union(MethodMatcher mm1, ClassFilter cf1, MethodMatcher mm2, ClassFilter cf2)
/*     */   {
/*  65 */     return new ClassFilterAwareUnionMethodMatcher(mm1, cf1, mm2, cf2);
/*     */   }
/*     */ 
/*     */   public static MethodMatcher intersection(MethodMatcher mm1, MethodMatcher mm2)
/*     */   {
/*  76 */     return new IntersectionMethodMatcher(mm1, mm2);
/*     */   }
/*     */ 
/*     */   public static boolean matches(MethodMatcher mm, Method method, Class<?> targetClass, boolean hasIntroductions)
/*     */   {
/*  92 */     Assert.notNull(mm, "MethodMatcher must not be null");
/*     */ 
/*  95 */     return (((mm instanceof IntroductionAwareMethodMatcher)) && 
/*  94 */       (((IntroductionAwareMethodMatcher)mm)
/*  94 */       .matches(method, targetClass, hasIntroductions))) || 
/*  95 */       (mm
/*  95 */       .matches(method, targetClass));
/*     */   }
/*     */ 
/*     */   private static class IntersectionMethodMatcher
/*     */     implements IntroductionAwareMethodMatcher, Serializable
/*     */   {
/*     */     private final MethodMatcher mm1;
/*     */     private final MethodMatcher mm2;
/*     */ 
/*     */     public IntersectionMethodMatcher(MethodMatcher mm1, MethodMatcher mm2)
/*     */     {
/* 226 */       Assert.notNull(mm1, "First MethodMatcher must not be null");
/* 227 */       Assert.notNull(mm2, "Second MethodMatcher must not be null");
/* 228 */       this.mm1 = mm1;
/* 229 */       this.mm2 = mm2;
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions)
/*     */     {
/* 235 */       return (MethodMatchers.matches(this.mm1, method, targetClass, hasIntroductions)) && 
/* 235 */         (MethodMatchers.matches(this.mm2, method, targetClass, hasIntroductions));
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 240 */       return (this.mm1.matches(method, targetClass)) && (this.mm2.matches(method, targetClass));
/*     */     }
/*     */ 
/*     */     public boolean isRuntime()
/*     */     {
/* 245 */       return (this.mm1.isRuntime()) || (this.mm2.isRuntime());
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass, Object[] args)
/*     */     {
/* 254 */       boolean aMatches = this.mm1.isRuntime() ? this.mm1
/* 254 */         .matches(method, targetClass, args) : 
/* 254 */         this.mm1.matches(method, targetClass);
/*     */ 
/* 256 */       boolean bMatches = this.mm2.isRuntime() ? this.mm2
/* 256 */         .matches(method, targetClass, args) : 
/* 256 */         this.mm2.matches(method, targetClass);
/* 257 */       return (aMatches) && (bMatches);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 262 */       if (this == other) {
/* 263 */         return true;
/*     */       }
/* 265 */       if (!(other instanceof IntersectionMethodMatcher)) {
/* 266 */         return false;
/*     */       }
/* 268 */       IntersectionMethodMatcher that = (IntersectionMethodMatcher)other;
/* 269 */       return (this.mm1.equals(that.mm1)) && (this.mm2.equals(that.mm2));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 274 */       int hashCode = 17;
/* 275 */       hashCode = 37 * hashCode + this.mm1.hashCode();
/* 276 */       hashCode = 37 * hashCode + this.mm2.hashCode();
/* 277 */       return hashCode;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ClassFilterAwareUnionMethodMatcher extends MethodMatchers.UnionMethodMatcher
/*     */   {
/*     */     private final ClassFilter cf1;
/*     */     private final ClassFilter cf2;
/*     */ 
/*     */     public ClassFilterAwareUnionMethodMatcher(MethodMatcher mm1, ClassFilter cf1, MethodMatcher mm2, ClassFilter cf2)
/*     */     {
/* 180 */       super(mm2);
/* 181 */       this.cf1 = cf1;
/* 182 */       this.cf2 = cf2;
/*     */     }
/*     */ 
/*     */     protected boolean matchesClass1(Class<?> targetClass)
/*     */     {
/* 187 */       return this.cf1.matches(targetClass);
/*     */     }
/*     */ 
/*     */     protected boolean matchesClass2(Class<?> targetClass)
/*     */     {
/* 192 */       return this.cf2.matches(targetClass);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 197 */       if (this == other) {
/* 198 */         return true;
/*     */       }
/* 200 */       if (!super.equals(other)) {
/* 201 */         return false;
/*     */       }
/* 203 */       ClassFilter otherCf1 = ClassFilter.TRUE;
/* 204 */       ClassFilter otherCf2 = ClassFilter.TRUE;
/* 205 */       if ((other instanceof ClassFilterAwareUnionMethodMatcher)) {
/* 206 */         ClassFilterAwareUnionMethodMatcher cfa = (ClassFilterAwareUnionMethodMatcher)other;
/* 207 */         otherCf1 = cfa.cf1;
/* 208 */         otherCf2 = cfa.cf2;
/*     */       }
/* 210 */       return (this.cf1.equals(otherCf1)) && (this.cf2.equals(otherCf2));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class UnionMethodMatcher
/*     */     implements IntroductionAwareMethodMatcher, Serializable
/*     */   {
/*     */     private final MethodMatcher mm1;
/*     */     private final MethodMatcher mm2;
/*     */ 
/*     */     public UnionMethodMatcher(MethodMatcher mm1, MethodMatcher mm2)
/*     */     {
/* 110 */       Assert.notNull(mm1, "First MethodMatcher must not be null");
/* 111 */       Assert.notNull(mm2, "Second MethodMatcher must not be null");
/* 112 */       this.mm1 = mm1;
/* 113 */       this.mm2 = mm2;
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions)
/*     */     {
/* 119 */       return ((matchesClass1(targetClass)) && (MethodMatchers.matches(this.mm1, method, targetClass, hasIntroductions))) || (
/* 119 */         (matchesClass2(targetClass)) && 
/* 119 */         (MethodMatchers.matches(this.mm2, method, targetClass, hasIntroductions)));
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 125 */       return ((matchesClass1(targetClass)) && (this.mm1.matches(method, targetClass))) || (
/* 125 */         (matchesClass2(targetClass)) && 
/* 125 */         (this.mm2.matches(method, targetClass)));
/*     */     }
/*     */ 
/*     */     protected boolean matchesClass1(Class<?> targetClass) {
/* 129 */       return true;
/*     */     }
/*     */ 
/*     */     protected boolean matchesClass2(Class<?> targetClass) {
/* 133 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean isRuntime()
/*     */     {
/* 138 */       return (this.mm1.isRuntime()) || (this.mm2.isRuntime());
/*     */     }
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass, Object[] args)
/*     */     {
/* 143 */       return (this.mm1.matches(method, targetClass, args)) || (this.mm2.matches(method, targetClass, args));
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 148 */       if (this == obj) {
/* 149 */         return true;
/*     */       }
/* 151 */       if (!(obj instanceof UnionMethodMatcher)) {
/* 152 */         return false;
/*     */       }
/* 154 */       UnionMethodMatcher that = (UnionMethodMatcher)obj;
/* 155 */       return (this.mm1.equals(that.mm1)) && (this.mm2.equals(that.mm2));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 160 */       int hashCode = 17;
/* 161 */       hashCode = 37 * hashCode + this.mm1.hashCode();
/* 162 */       hashCode = 37 * hashCode + this.mm2.hashCode();
/* 163 */       return hashCode;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.MethodMatchers
 * JD-Core Version:    0.6.2
 */