/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ 
/*    */ public class RootClassFilter
/*    */   implements ClassFilter, Serializable
/*    */ {
/*    */   private Class<?> clazz;
/*    */ 
/*    */   public RootClassFilter(Class<?> clazz)
/*    */   {
/* 34 */     this.clazz = clazz;
/*    */   }
/*    */ 
/*    */   public boolean matches(Class<?> candidate)
/*    */   {
/* 40 */     return this.clazz.isAssignableFrom(candidate);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.RootClassFilter
 * JD-Core Version:    0.6.2
 */