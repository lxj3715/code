/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.MethodMatcher;
/*    */ 
/*    */ public abstract class StaticMethodMatcher
/*    */   implements MethodMatcher
/*    */ {
/*    */   public final boolean isRuntime()
/*    */   {
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */   public final boolean matches(Method method, Class<?> targetClass, Object[] args)
/*    */   {
/* 37 */     throw new UnsupportedOperationException("Illegal MethodMatcher usage");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.StaticMethodMatcher
 * JD-Core Version:    0.6.2
 */