/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.MethodMatcher;
/*    */ import org.springframework.aop.Pointcut;
/*    */ 
/*    */ public abstract class StaticMethodMatcherPointcut extends StaticMethodMatcher
/*    */   implements Pointcut
/*    */ {
/* 35 */   private ClassFilter classFilter = ClassFilter.TRUE;
/*    */ 
/*    */   public void setClassFilter(ClassFilter classFilter)
/*    */   {
/* 43 */     this.classFilter = classFilter;
/*    */   }
/*    */ 
/*    */   public ClassFilter getClassFilter()
/*    */   {
/* 48 */     return this.classFilter;
/*    */   }
/*    */ 
/*    */   public final MethodMatcher getMethodMatcher()
/*    */   {
/* 54 */     return this;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aop-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.aop.support.StaticMethodMatcherPointcut
 * JD-Core Version:    0.6.2
 */