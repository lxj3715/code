/*    */ package org.springframework.beans.factory.aspectj;
/*    */ 
/*    */ import org.aspectj.lang.annotation.AfterReturning;
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.aspectj.lang.annotation.Before;
/*    */ import org.aspectj.lang.annotation.SuppressAjWarnings;
/*    */ import org.springframework.beans.factory.wiring.BeanConfigurerSupport;
/*    */ 
/*    */ /** @deprecated */
/*    */ @Aspect
/*    */ public abstract class AbstractBeanConfigurerAspect extends BeanConfigurerSupport
/*    */ {
/*    */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*    */   @Before(value="beanInitialization(beanInstance)", argNames="beanInstance")
/*    */   public void ajc$before$org_springframework_beans_factory_aspectj_AbstractBeanConfigurerAspect$1$1d6451ac(Object beanInstance)
/*    */   {
/* 47 */     if (preConstructionConfiguration(beanInstance))
/* 48 */       configureBean(beanInstance);
/*    */   }
/*    */ 
/*    */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*    */   @AfterReturning(pointcut="beanCreation(beanInstance)", returning="", argNames="beanInstance")
/*    */   public void ajc$afterReturning$org_springframework_beans_factory_aspectj_AbstractBeanConfigurerAspect$2$6b4509ab(Object beanInstance)
/*    */   {
/* 57 */     if (!preConstructionConfiguration(beanInstance))
/* 58 */       configureBean(beanInstance);
/*    */   }
/*    */ 
/*    */   protected boolean preConstructionConfiguration(Object beanInstance)
/*    */   {
/* 82 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.aspectj.AbstractBeanConfigurerAspect
 * JD-Core Version:    0.6.2
 */