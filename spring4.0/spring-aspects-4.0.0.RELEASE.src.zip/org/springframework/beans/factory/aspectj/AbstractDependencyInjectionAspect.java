/*     */ package org.springframework.beans.factory.aspectj;
/*     */ 
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.Signature;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.annotation.Before;
/*     */ import org.aspectj.lang.annotation.SuppressAjWarnings;
/*     */ 
/*     */ @Aspect
/*     */ public abstract class AbstractDependencyInjectionAspect
/*     */ {
/*     */   public abstract void configureBean(Object paramObject);
/*     */ 
/*     */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*     */   @Before(value="(beanConstruction(bean) && (preConstructionCondition() && inConfigurableBean()))", argNames="bean")
/*     */   public void ajc$before$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$1$e854fa65(Object bean)
/*     */   {
/*  82 */     configureBean(bean);
/*     */   }
/*     */ 
/*     */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*     */   @AfterReturning(pointcut="(beanConstruction(bean) && (postConstructionCondition() && inConfigurableBean()))", returning="", argNames="bean")
/*     */   public void ajc$afterReturning$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$2$1ea6722c(Object bean)
/*     */   {
/*  91 */     configureBean(bean);
/*     */   }
/*     */ 
/*     */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*     */   @AfterReturning(pointcut="(beanDeserialization(bean) && inConfigurableBean())", returning="", argNames="bean")
/*     */   public void ajc$afterReturning$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$3$6aa27052(Object bean)
/*     */   {
/* 100 */     configureBean(bean);
/*     */   }
/*     */ 
/*     */   public static final boolean ajc$if$6f1(JoinPoint thisJoinPoint)
/*     */   {
/*   1 */     return thisJoinPoint.getSignature().getDeclaringType() == thisJoinPoint.getThis().getClass();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.aspectj.AbstractDependencyInjectionAspect
 * JD-Core Version:    0.6.2
 */