/*     */ package org.springframework.beans.factory.aspectj;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.springframework.beans.factory.annotation.Configurable;
/*     */ 
/*     */ @Aspect
/*     */ public abstract class AbstractInterfaceDrivenDependencyInjectionAspect extends AbstractDependencyInjectionAspect
/*     */ {
/*     */   public static Object ajc$interMethod$org_springframework_beans_factory_aspectj_AbstractInterfaceDrivenDependencyInjectionAspect$org_springframework_beans_factory_aspectj_AbstractInterfaceDrivenDependencyInjectionAspect$ConfigurableDeserializationSupport$readResolve(ConfigurableDeserializationSupport ajc$this_)
/*     */     throws ObjectStreamException
/*     */   {
/* 121 */     ConfigurableDeserializationSupport localConfigurableDeserializationSupport = ajc$this_; if ((ajc$this_ != null) && (ajc$this_.getClass().isAnnotationPresent(Configurable.class))) AnnotationBeanConfigurerAspect.aspectOf().ajc$afterReturning$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$3$6aa27052(ajc$this_); return localConfigurableDeserializationSupport;
/*     */   }
/*     */ 
/*     */   static abstract interface ConfigurableDeserializationSupport extends Serializable
/*     */   {
/*     */     public abstract Object readResolve()
/*     */       throws ObjectStreamException;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.aspectj.AbstractInterfaceDrivenDependencyInjectionAspect
 * JD-Core Version:    0.6.2
 */