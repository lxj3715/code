/*    */ package org.springframework.beans.factory.aspectj;
/*    */ 
/*    */ import org.aspectj.lang.NoAspectBoundException;
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.beans.factory.annotation.AnnotationBeanWiringInfoResolver;
/*    */ import org.springframework.beans.factory.annotation.Configurable;
/*    */ import org.springframework.beans.factory.wiring.BeanConfigurerSupport;
/*    */ 
/*    */ @Aspect
/*    */ public class AnnotationBeanConfigurerAspect extends AbstractInterfaceDrivenDependencyInjectionAspect
/*    */   implements BeanFactoryAware, InitializingBean, DisposableBean
/*    */ {
/* 51 */   private BeanConfigurerSupport beanConfigurerSupport = new BeanConfigurerSupport();
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 47 */       ajc$postClinit(); } catch (Throwable localThrowable) { ajc$initFailureCause = localThrowable; }
/*    */ 
/*    */   }
/*    */ 
/*    */   public void configureBean(Object bean)
/*    */   {
/* 60 */     this.beanConfigurerSupport.configureBean(bean);
/*    */   }
/*    */ 
/*    */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*    */   {
/* 65 */     this.beanConfigurerSupport.setBeanFactory(beanFactory);
/* 66 */     this.beanConfigurerSupport.setBeanWiringInfoResolver(new AnnotationBeanWiringInfoResolver());
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() throws Exception {
/* 70 */     this.beanConfigurerSupport.afterPropertiesSet();
/*    */   }
/*    */ 
/*    */   public void destroy() throws Exception {
/* 74 */     this.beanConfigurerSupport.destroy();
/*    */   }
/*    */ 
/*    */   public static final boolean ajc$if$bb0(Configurable c)
/*    */   {
/*  1 */     return c.preConstruction(); } 
/*  1 */   public static AnnotationBeanConfigurerAspect aspectOf() { if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_beans_factory_aspectj_AnnotationBeanConfigurerAspect", ajc$initFailureCause); return ajc$perSingletonInstance; } 
/*  1 */   public static boolean hasAspect() { return ajc$perSingletonInstance != null; }
/*    */ 
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect
 * JD-Core Version:    0.6.2
 */