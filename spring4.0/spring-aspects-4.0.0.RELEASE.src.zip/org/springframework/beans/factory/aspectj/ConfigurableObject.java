package org.springframework.beans.factory.aspectj;

public abstract interface ConfigurableObject
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.aspectj.ConfigurableObject
 * JD-Core Version:    0.6.2
 */