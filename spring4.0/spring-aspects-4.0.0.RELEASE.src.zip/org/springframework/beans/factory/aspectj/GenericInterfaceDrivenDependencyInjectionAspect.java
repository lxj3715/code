/*    */ package org.springframework.beans.factory.aspectj;
/*    */ 
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ 
/*    */ @Aspect
/*    */ public abstract class GenericInterfaceDrivenDependencyInjectionAspect<I> extends AbstractInterfaceDrivenDependencyInjectionAspect
/*    */ {
/*    */   public final void configureBean(Object bean)
/*    */   {
/* 49 */     configure(bean);
/*    */   }
/*    */ 
/*    */   protected abstract void configure(I paramI);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.aspectj.GenericInterfaceDrivenDependencyInjectionAspect
 * JD-Core Version:    0.6.2
 */