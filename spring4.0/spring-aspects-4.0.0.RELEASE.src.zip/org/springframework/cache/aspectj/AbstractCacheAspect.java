/*    */ package org.springframework.cache.aspectj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aspectj.lang.JoinPoint;
/*    */ import org.aspectj.lang.annotation.Around;
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.aspectj.lang.annotation.SuppressAjWarnings;
/*    */ import org.aspectj.lang.reflect.MethodSignature;
/*    */ import org.aspectj.runtime.internal.AroundClosure;
/*    */ import org.springframework.cache.interceptor.CacheAspectSupport;
/*    */ import org.springframework.cache.interceptor.CacheAspectSupport.Invoker;
/*    */ import org.springframework.cache.interceptor.CacheOperationSource;
/*    */ 
/*    */ @Aspect
/*    */ public abstract class AbstractCacheAspect extends CacheAspectSupport
/*    */ {
/*    */   protected AbstractCacheAspect()
/*    */   {
/*    */   }
/*    */ 
/*    */   protected AbstractCacheAspect(CacheOperationSource[] cos)
/*    */   {
/* 51 */     setCacheOperationSources(cos);
/*    */   }
/* 56 */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*    */   @Around(value="cacheMethodExecution(cachedObject)", argNames="cachedObject,ajc$aroundClosure")
/*    */   public Object ajc$around$org_springframework_cache_aspectj_AbstractCacheAspect$1$2bc714b5(final Object cachedObject, final AroundClosure ajc$aroundClosure, JoinPoint thisJoinPoint) { MethodSignature methodSignature = (MethodSignature)thisJoinPoint.getSignature();
/* 57 */     Method method = methodSignature.getMethod();
/*    */ 
/* 59 */     CacheAspectSupport.Invoker aspectJInvoker = new CacheAspectSupport.Invoker() {
/*    */       public Object invoke() {
/* 61 */         return AbstractCacheAspect.ajc$around$org_springframework_cache_aspectj_AbstractCacheAspect$1$2bc714b5proceed(cachedObject, ajc$aroundClosure);
/*    */       }
/*    */     };
/* 65 */     return execute(aspectJInvoker, thisJoinPoint.getTarget(), method, thisJoinPoint.getArgs());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.aspectj.AbstractCacheAspect
 * JD-Core Version:    0.6.2
 */