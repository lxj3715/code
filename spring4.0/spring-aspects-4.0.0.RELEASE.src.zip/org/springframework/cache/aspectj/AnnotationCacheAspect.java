/*     */ package org.springframework.cache.aspectj;
/*     */ 
/*     */ import org.aspectj.lang.NoAspectBoundException;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.springframework.cache.annotation.AnnotationCacheOperationSource;
/*     */ import org.springframework.cache.interceptor.CacheOperationSource;
/*     */ 
/*     */ @Aspect
/*     */ public class AnnotationCacheAspect extends AbstractCacheAspect
/*     */ {
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  44 */       ajc$postClinit(); } catch (Throwable localThrowable) { ajc$initFailureCause = localThrowable; } 
/*     */   }
/*     */ 
/*  47 */   public AnnotationCacheAspect() { super(new CacheOperationSource[] { new AnnotationCacheOperationSource(false) }); }
/*     */ 
/*     */ 
/*     */   public static AnnotationCacheAspect aspectOf()
/*     */   {
/*   1 */     if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_cache_aspectj_AnnotationCacheAspect", ajc$initFailureCause); return ajc$perSingletonInstance; } 
/*   1 */   public static boolean hasAspect() { return ajc$perSingletonInstance != null; }
/*     */ 
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.aspectj.AnnotationCacheAspect
 * JD-Core Version:    0.6.2
 */