/*    */ package org.springframework.cache.aspectj;
/*    */ 
/*    */ import org.springframework.cache.annotation.AbstractCachingConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ 
/*    */ @Configuration
/*    */ public class AspectJCachingConfiguration extends AbstractCachingConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.cache.config.internalCacheAspect"})
/*    */   @Role(2)
/*    */   public AnnotationCacheAspect cacheAspect()
/*    */   {
/* 41 */     AnnotationCacheAspect cacheAspect = AnnotationCacheAspect.aspectOf();
/* 42 */     if (this.cacheManager != null) {
/* 43 */       cacheAspect.setCacheManager(this.cacheManager);
/*    */     }
/* 45 */     if (this.keyGenerator != null) {
/* 46 */       cacheAspect.setKeyGenerator(this.keyGenerator);
/*    */     }
/* 48 */     return cacheAspect;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.aspectj.AspectJCachingConfiguration
 * JD-Core Version:    0.6.2
 */