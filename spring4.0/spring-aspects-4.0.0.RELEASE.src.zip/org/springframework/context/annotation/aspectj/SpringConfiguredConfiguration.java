/*    */ package org.springframework.context.annotation.aspectj;
/*    */ 
/*    */ import org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ 
/*    */ @Configuration
/*    */ public class SpringConfiguredConfiguration
/*    */ {
/*    */   public static final String BEAN_CONFIGURER_ASPECT_BEAN_NAME = "org.springframework.context.config.internalBeanConfigurerAspect";
/*    */ 
/*    */   @Bean(name={"org.springframework.context.config.internalBeanConfigurerAspect"})
/*    */   @Role(2)
/*    */   public AnnotationBeanConfigurerAspect beanConfigurerAspect()
/*    */   {
/* 48 */     return AnnotationBeanConfigurerAspect.aspectOf();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.aspectj.SpringConfiguredConfiguration
 * JD-Core Version:    0.6.2
 */