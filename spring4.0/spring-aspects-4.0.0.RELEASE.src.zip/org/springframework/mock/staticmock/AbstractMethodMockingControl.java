/*     */ package org.springframework.mock.staticmock;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.JoinPoint.StaticPart;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.runtime.internal.AroundClosure;
/*     */ 
/*     */ @Aspect("percflow(mockStaticsTestMethod())")
/*     */ public abstract class AbstractMethodMockingControl
/*     */ {
/*  38 */   private boolean recording = true;
/*     */ 
/* 156 */   private Expectations expectations = new Expectations();
/*     */ 
/* 159 */   @AfterReturning(pointcut="mockStaticsTestMethod()", returning="", argNames="")
/*     */   public void ajc$afterReturning$org_springframework_mock_staticmock_AbstractMethodMockingControl$1$94476acf() { if ((this.recording) && (this.expectations.hasCalls())) {
/* 160 */       throw new IllegalStateException(
/* 161 */         "Calls recorded, yet playback state never reached: Create expectations then call " + 
/* 162 */         getClass().getSimpleName() + ".playback()");
/*     */     }
/* 164 */     this.expectations.verify(); }
/*     */ 
/*     */   @Around(value="(methodToMock() && cflowbelow(mockStaticsTestMethod()))", argNames="ajc$aroundClosure")
/*     */   public Object ajc$around$org_springframework_mock_staticmock_AbstractMethodMockingControl$2$9cfbb496(AroundClosure ajc$aroundClosure, JoinPoint.StaticPart thisJoinPointStaticPart, JoinPoint thisJoinPoint) {
/* 168 */     if (ajc$inlineAccessFieldGet$org_springframework_mock_staticmock_AbstractMethodMockingControl$org_springframework_mock_staticmock_AbstractMethodMockingControl$recording(this)) {
/* 169 */       ajc$inlineAccessFieldGet$org_springframework_mock_staticmock_AbstractMethodMockingControl$org_springframework_mock_staticmock_AbstractMethodMockingControl$expectations(this).expectCall(thisJoinPointStaticPart.toLongString(), thisJoinPoint.getArgs());
/*     */ 
/* 171 */       return null;
/*     */     }
/*     */ 
/* 174 */     return ajc$inlineAccessFieldGet$org_springframework_mock_staticmock_AbstractMethodMockingControl$org_springframework_mock_staticmock_AbstractMethodMockingControl$expectations(this).respond(thisJoinPointStaticPart.toLongString(), thisJoinPoint.getArgs());
/*     */   }
/*     */ 
/*     */   public void expectReturnInternal(Object retVal)
/*     */   {
/* 179 */     if (!this.recording) {
/* 180 */       throw new IllegalStateException("Not recording: Cannot set return value");
/*     */     }
/* 182 */     this.expectations.expectReturn(retVal);
/*     */   }
/*     */ 
/*     */   public void expectThrowInternal(Throwable throwable) {
/* 186 */     if (!this.recording) {
/* 187 */       throw new IllegalStateException("Not recording: Cannot set throwable value");
/*     */     }
/* 189 */     this.expectations.expectThrow(throwable);
/*     */   }
/*     */ 
/*     */   public void playbackInternal() {
/* 193 */     this.recording = false;
/*     */   }
/*     */ 
/*     */   static enum CallResponse
/*     */   {
/*  40 */     nothing, return_, throw_;
/*     */   }
/*     */ 
/*     */   public class Expectations
/*     */   {
/*  93 */     private List<Call> calls = new LinkedList();
/*     */     private int verified;
/*     */ 
/*     */     public Expectations()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void verify()
/*     */     {
/*  99 */       if (this.verified != this.calls.size())
/* 100 */         throw new IllegalStateException("Expected " + this.calls.size() + " calls, received " + this.verified);
/*     */     }
/*     */ 
/*     */     public Object respond(String lastSig, Object[] args)
/*     */     {
/* 108 */       Call call = nextCall();
/* 109 */       AbstractMethodMockingControl.CallResponse responseType = call.responseType;
/* 110 */       if (responseType == AbstractMethodMockingControl.CallResponse.return_) {
/* 111 */         return call.returnValue(lastSig, args);
/*     */       }
/* 113 */       if (responseType == AbstractMethodMockingControl.CallResponse.throw_) {
/* 114 */         return call.throwException(lastSig, args);
/*     */       }
/*     */ 
/* 119 */       throw new IllegalStateException("Behavior of " + call + " not specified");
/*     */     }
/*     */ 
/*     */     private Call nextCall() {
/* 123 */       this.verified += 1;
/* 124 */       if (this.verified > this.calls.size()) {
/* 125 */         throw new IllegalStateException("Expected " + this.calls.size() + " calls, received " + this.verified);
/*     */       }
/* 127 */       return (Call)this.calls.get(this.verified);
/*     */     }
/*     */ 
/*     */     public void expectCall(String lastSig, Object[] lastArgs) {
/* 131 */       Call call = new Call(lastSig, lastArgs);
/* 132 */       this.calls.add(call);
/*     */     }
/*     */ 
/*     */     public boolean hasCalls() {
/* 136 */       return !this.calls.isEmpty();
/*     */     }
/*     */ 
/*     */     public void expectReturn(Object retVal) {
/* 140 */       Call call = (Call)this.calls.get(this.calls.size() - 1);
/* 141 */       if (call.hasResponseSpecified()) {
/* 142 */         throw new IllegalStateException("No static method invoked before setting return value");
/*     */       }
/* 144 */       call.setReturnVal(retVal);
/*     */     }
/*     */ 
/*     */     public void expectThrow(Throwable throwable) {
/* 148 */       Call call = (Call)this.calls.get(this.calls.size() - 1);
/* 149 */       if (call.hasResponseSpecified()) {
/* 150 */         throw new IllegalStateException("No static method invoked before setting throwable");
/*     */       }
/* 152 */       call.setThrow(throwable);
/*     */     }
/*     */ 
/*     */     private class Call
/*     */     {
/*     */       private final String signature;
/*     */       private final Object[] args;
/*     */       private Object responseObject;
/*  52 */       private AbstractMethodMockingControl.CallResponse responseType = AbstractMethodMockingControl.CallResponse.nothing;
/*     */ 
/*     */       public Call(String name, Object[] args) {
/*  55 */         this.signature = name;
/*  56 */         this.args = args;
/*     */       }
/*     */ 
/*     */       public boolean hasResponseSpecified() {
/*  60 */         return this.responseType != AbstractMethodMockingControl.CallResponse.nothing;
/*     */       }
/*     */ 
/*     */       public void setReturnVal(Object retVal) {
/*  64 */         this.responseObject = retVal;
/*  65 */         this.responseType = AbstractMethodMockingControl.CallResponse.return_;
/*     */       }
/*     */ 
/*     */       public void setThrow(Throwable throwable) {
/*  69 */         this.responseObject = throwable;
/*  70 */         this.responseType = AbstractMethodMockingControl.CallResponse.throw_;
/*     */       }
/*     */ 
/*     */       public Object returnValue(String lastSig, Object[] args) {
/*  74 */         checkSignature(lastSig, args);
/*  75 */         return this.responseObject;
/*     */       }
/*     */ 
/*     */       public Object throwException(String lastSig, Object[] args) {
/*  79 */         checkSignature(lastSig, args);
/*  80 */         throw ((RuntimeException)this.responseObject);
/*     */       }
/*     */ 
/*     */       private void checkSignature(String lastSig, Object[] args) {
/*  84 */         if (!this.signature.equals(lastSig)) {
/*  85 */           throw new IllegalArgumentException("Signature doesn't match");
/*     */         }
/*  87 */         if (!Arrays.equals(this.args, args))
/*  88 */           throw new IllegalArgumentException("Arguments don't match");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.mock.staticmock.AbstractMethodMockingControl
 * JD-Core Version:    0.6.2
 */