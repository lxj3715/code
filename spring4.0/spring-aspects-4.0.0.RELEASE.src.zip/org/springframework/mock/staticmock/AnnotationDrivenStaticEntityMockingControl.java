/*    */ package org.springframework.mock.staticmock;
/*    */ 
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.aspectj.runtime.internal.CFlowStack;
/*    */ 
/*    */ @Aspect
/*    */ public class AnnotationDrivenStaticEntityMockingControl extends AbstractMethodMockingControl
/*    */ {
/*    */   static
/*    */   {
/* 45 */     ajc$preClinit();
/*    */   }
/*    */ 
/*    */   public static void playback()
/*    */   {
/* 51 */     aspectOf().playbackInternal();
/*    */   }
/*    */ 
/*    */   public static void expectReturn(Object retVal) {
/* 55 */     aspectOf().expectReturnInternal(retVal);
/*    */   }
/*    */ 
/*    */   public static void expectThrow(Throwable throwable) {
/* 59 */     aspectOf().expectThrowInternal(throwable);
/*    */   }
/*    */ 
/*    */   public static AnnotationDrivenStaticEntityMockingControl aspectOf()
/*    */   {
/*  1 */     return (AnnotationDrivenStaticEntityMockingControl)ajc$perCflowStack.peekInstance(); } 
/*  1 */   public static boolean hasAspect() { return ajc$perCflowStack.isValid(); }
/*    */ 
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.mock.staticmock.AnnotationDrivenStaticEntityMockingControl
 * JD-Core Version:    0.6.2
 */