/*    */ package org.springframework.orm.jpa.aspectj;
/*    */ 
/*    */ import org.aspectj.lang.NoAspectBoundException;
/*    */ import org.aspectj.lang.annotation.AfterThrowing;
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.orm.jpa.EntityManagerFactoryUtils;
/*    */ 
/*    */ @Aspect
/*    */ public class JpaExceptionTranslatorAspect
/*    */ {
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 27 */       ajc$postClinit(); } catch (Throwable localThrowable) { ajc$initFailureCause = localThrowable; }
/*    */   }
/*    */ 
/*    */   @AfterThrowing(pointcut="entityManagerCall()", throwing="re", argNames="re")
/*    */   public void ajc$afterThrowing$org_springframework_orm_jpa_aspectj_JpaExceptionTranslatorAspect$1$18a1ac9(RuntimeException re)
/*    */   {
/* 33 */     DataAccessException dex = EntityManagerFactoryUtils.convertJpaAccessExceptionIfPossible(re);
/* 34 */     if (dex != null) {
/* 35 */       throw dex;
/*    */     }
/*    */ 
/* 38 */     throw re;
/*    */   }
/*    */ 
/*    */   public static JpaExceptionTranslatorAspect aspectOf()
/*    */   {
/*  1 */     if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_orm_jpa_aspectj_JpaExceptionTranslatorAspect", ajc$initFailureCause); return ajc$perSingletonInstance; } 
/*  1 */   public static boolean hasAspect() { return ajc$perSingletonInstance != null; }
/*    */ 
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.orm.jpa.aspectj.JpaExceptionTranslatorAspect
 * JD-Core Version:    0.6.2
 */