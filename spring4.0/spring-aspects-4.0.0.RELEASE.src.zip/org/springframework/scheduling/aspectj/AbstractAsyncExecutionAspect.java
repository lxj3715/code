/*    */ package org.springframework.scheduling.aspectj;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.Future;
/*    */ import org.aspectj.lang.JoinPoint.StaticPart;
/*    */ import org.aspectj.lang.annotation.Around;
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.aspectj.lang.reflect.MethodSignature;
/*    */ import org.aspectj.runtime.internal.AroundClosure;
/*    */ import org.springframework.aop.interceptor.AsyncExecutionAspectSupport;
/*    */ import org.springframework.core.task.AsyncTaskExecutor;
/*    */ 
/*    */ @Aspect
/*    */ public abstract class AbstractAsyncExecutionAspect extends AsyncExecutionAspectSupport
/*    */ {
/*    */   public AbstractAsyncExecutionAspect()
/*    */   {
/* 48 */     super(null);
/*    */   }
/*    */ 
/*    */   @Around(value="asyncMethod()", argNames="ajc$aroundClosure")
/*    */   public Object ajc$around$org_springframework_scheduling_aspectj_AbstractAsyncExecutionAspect$1$6c004c3e(final AroundClosure ajc$aroundClosure, JoinPoint.StaticPart thisJoinPointStaticPart)
/*    */   {
/* 59 */     MethodSignature methodSignature = (MethodSignature)thisJoinPointStaticPart.getSignature();
/* 60 */     AsyncTaskExecutor executor = determineAsyncExecutor(methodSignature.getMethod());
/* 61 */     if (executor == null) {
/* 62 */       return ajc$around$org_springframework_scheduling_aspectj_AbstractAsyncExecutionAspect$1$6c004c3eproceed(ajc$aroundClosure);
/*    */     }
/* 64 */     Callable callable = new Callable() {
/*    */       public Object call() throws Exception {
/* 66 */         Object result = AbstractAsyncExecutionAspect.ajc$around$org_springframework_scheduling_aspectj_AbstractAsyncExecutionAspect$1$6c004c3eproceed(ajc$aroundClosure);
/* 67 */         if ((result instanceof Future)) {
/* 68 */           return ((Future)result).get();
/*    */         }
/* 70 */         return null;
/*    */       }
/*    */     };
/* 72 */     Future result = executor.submit(callable);
/* 73 */     if (Future.class.isAssignableFrom(methodSignature.getReturnType())) {
/* 74 */       return result;
/*    */     }
/*    */ 
/* 77 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.aspectj.AbstractAsyncExecutionAspect
 * JD-Core Version:    0.6.2
 */