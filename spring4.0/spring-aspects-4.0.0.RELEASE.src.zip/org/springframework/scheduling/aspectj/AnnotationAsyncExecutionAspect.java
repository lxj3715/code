/*    */ package org.springframework.scheduling.aspectj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aspectj.lang.NoAspectBoundException;
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.scheduling.annotation.Async;
/*    */ 
/*    */ @Aspect
/*    */ public class AnnotationAsyncExecutionAspect extends AbstractAsyncExecutionAspect
/*    */ {
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 41 */       ajc$postClinit(); } catch (Throwable localThrowable) { ajc$initFailureCause = localThrowable; }
/*    */ 
/*    */   }
/*    */ 
/*    */   protected String getExecutorQualifier(Method method)
/*    */   {
/* 66 */     Async async = (Async)AnnotationUtils.findAnnotation(method, Async.class);
/* 67 */     if (async == null) {
/* 68 */       async = (Async)AnnotationUtils.findAnnotation(method.getDeclaringClass(), Async.class);
/*    */     }
/* 70 */     return async == null ? null : async.value();
/*    */   }
/*    */ 
/*    */   public static AnnotationAsyncExecutionAspect aspectOf()
/*    */   {
/*  1 */     if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_scheduling_aspectj_AnnotationAsyncExecutionAspect", ajc$initFailureCause); return ajc$perSingletonInstance; } 
/*  1 */   public static boolean hasAspect() { return ajc$perSingletonInstance != null; }
/*    */ 
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.aspectj.AnnotationAsyncExecutionAspect
 * JD-Core Version:    0.6.2
 */