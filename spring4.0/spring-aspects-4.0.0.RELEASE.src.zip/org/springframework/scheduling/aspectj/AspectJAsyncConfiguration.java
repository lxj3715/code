/*    */ package org.springframework.scheduling.aspectj;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.scheduling.annotation.AbstractAsyncConfiguration;
/*    */ 
/*    */ @Configuration
/*    */ public class AspectJAsyncConfiguration extends AbstractAsyncConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.scheduling.config.internalAsyncExecutionAspect"})
/*    */   @Role(2)
/*    */   public AnnotationAsyncExecutionAspect asyncAdvisor()
/*    */   {
/* 42 */     AnnotationAsyncExecutionAspect asyncAspect = AnnotationAsyncExecutionAspect.aspectOf();
/* 43 */     if (this.executor != null) {
/* 44 */       asyncAspect.setExecutor(this.executor);
/*    */     }
/* 46 */     return asyncAspect;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.aspectj.AspectJAsyncConfiguration
 * JD-Core Version:    0.6.2
 */