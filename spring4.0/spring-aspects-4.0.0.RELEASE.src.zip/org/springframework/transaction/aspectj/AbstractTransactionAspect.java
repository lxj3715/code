/*     */ package org.springframework.transaction.aspectj;
/*     */ 
/*     */ import org.aspectj.lang.JoinPoint.StaticPart;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.annotation.SuppressAjWarnings;
/*     */ import org.aspectj.lang.reflect.MethodSignature;
/*     */ import org.aspectj.runtime.internal.AroundClosure;
/*     */ import org.springframework.transaction.interceptor.TransactionAspectSupport;
/*     */ import org.springframework.transaction.interceptor.TransactionAspectSupport.InvocationCallback;
/*     */ import org.springframework.transaction.interceptor.TransactionAttributeSource;
/*     */ 
/*     */ @Aspect
/*     */ public abstract class AbstractTransactionAspect extends TransactionAspectSupport
/*     */ {
/*     */   protected AbstractTransactionAspect(TransactionAttributeSource tas)
/*     */   {
/*  55 */     setTransactionAttributeSource(tas);
/*     */   }
/*  60 */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*     */   @Around(value="transactionalMethodExecution(txObject)", argNames="txObject,ajc$aroundClosure")
/*     */   public Object ajc$around$org_springframework_transaction_aspectj_AbstractTransactionAspect$1$2a73e96c(final Object txObject, final AroundClosure ajc$aroundClosure, JoinPoint.StaticPart thisJoinPointStaticPart) { MethodSignature methodSignature = (MethodSignature)thisJoinPointStaticPart.getSignature();
/*     */     try
/*     */     {
/*  63 */       return invokeWithinTransaction(methodSignature.getMethod(), txObject.getClass(), new TransactionAspectSupport.InvocationCallback() {
/*     */         public Object proceedWithInvocation() throws Throwable {
/*  65 */           return AbstractTransactionAspect.ajc$around$org_springframework_transaction_aspectj_AbstractTransactionAspect$1$2a73e96cproceed(txObject, ajc$aroundClosure);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (RuntimeException ex) {
/*  70 */       throw ex;
/*     */     }
/*     */     catch (Error err) {
/*  73 */       throw err;
/*     */     }
/*     */     catch (Throwable thr) {
/*  76 */       Rethrower.rethrow(thr);
/*  77 */       throw new IllegalStateException("Should never get here", thr);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Rethrower
/*     */   {
/*     */     public static void rethrow(Throwable exception)
/*     */     {
/* 102 */       new Object()
/*     */       {
/*     */         private void rethrow(Throwable exception)
/*     */           throws Throwable
/*     */         {
/*  99 */           throw exception;
/*     */         }
/*     */       }
/* 102 */       .rethrow(exception);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.aspectj.AbstractTransactionAspect
 * JD-Core Version:    0.6.2
 */