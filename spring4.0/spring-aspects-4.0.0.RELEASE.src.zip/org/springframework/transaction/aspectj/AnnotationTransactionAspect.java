/*    */ package org.springframework.transaction.aspectj;
/*    */ 
/*    */ import org.aspectj.lang.NoAspectBoundException;
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.springframework.transaction.annotation.AnnotationTransactionAttributeSource;
/*    */ 
/*    */ @Aspect
/*    */ public class AnnotationTransactionAspect extends AbstractTransactionAspect
/*    */ {
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 45 */       ajc$postClinit(); } catch (Throwable localThrowable) { ajc$initFailureCause = localThrowable; } 
/*    */   }
/*    */ 
/* 48 */   public AnnotationTransactionAspect() { super(new AnnotationTransactionAttributeSource(false)); }
/*    */ 
/*    */ 
/*    */   public static AnnotationTransactionAspect aspectOf()
/*    */   {
/*  1 */     if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_transaction_aspectj_AnnotationTransactionAspect", ajc$initFailureCause); return ajc$perSingletonInstance; } 
/*  1 */   public static boolean hasAspect() { return ajc$perSingletonInstance != null; }
/*    */ 
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.aspectj.AnnotationTransactionAspect
 * JD-Core Version:    0.6.2
 */