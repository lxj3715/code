/*    */ package org.springframework.transaction.aspectj;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.transaction.annotation.AbstractTransactionManagementConfiguration;
/*    */ 
/*    */ @Configuration
/*    */ public class AspectJTransactionManagementConfiguration extends AbstractTransactionManagementConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.transaction.config.internalTransactionAspect"})
/*    */   @Role(2)
/*    */   public AnnotationTransactionAspect transactionAspect()
/*    */   {
/* 43 */     AnnotationTransactionAspect txAspect = AnnotationTransactionAspect.aspectOf();
/* 44 */     if (this.txManager != null) {
/* 45 */       txAspect.setTransactionManager(this.txManager);
/*    */     }
/* 47 */     return txAspect;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-aspects-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.aspectj.AspectJTransactionManagementConfiguration
 * JD-Core Version:    0.6.2
 */