/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class AbstractPropertyAccessor extends TypeConverterSupport
/*     */   implements ConfigurablePropertyAccessor
/*     */ {
/*  36 */   private boolean extractOldValueForEditor = false;
/*     */ 
/*     */   public void setExtractOldValueForEditor(boolean extractOldValueForEditor)
/*     */   {
/*  41 */     this.extractOldValueForEditor = extractOldValueForEditor;
/*     */   }
/*     */ 
/*     */   public boolean isExtractOldValueForEditor()
/*     */   {
/*  46 */     return this.extractOldValueForEditor;
/*     */   }
/*     */ 
/*     */   public void setPropertyValue(PropertyValue pv)
/*     */     throws BeansException
/*     */   {
/*  52 */     setPropertyValue(pv.getName(), pv.getValue());
/*     */   }
/*     */ 
/*     */   public void setPropertyValues(Map<?, ?> map) throws BeansException
/*     */   {
/*  57 */     setPropertyValues(new MutablePropertyValues(map));
/*     */   }
/*     */ 
/*     */   public void setPropertyValues(PropertyValues pvs) throws BeansException
/*     */   {
/*  62 */     setPropertyValues(pvs, false, false);
/*     */   }
/*     */ 
/*     */   public void setPropertyValues(PropertyValues pvs, boolean ignoreUnknown) throws BeansException
/*     */   {
/*  67 */     setPropertyValues(pvs, ignoreUnknown, false);
/*     */   }
/*     */ 
/*     */   public void setPropertyValues(PropertyValues pvs, boolean ignoreUnknown, boolean ignoreInvalid)
/*     */     throws BeansException
/*     */   {
/*  74 */     List propertyAccessExceptions = null;
/*     */ 
/*  76 */     List propertyValues = (pvs instanceof MutablePropertyValues) ? ((MutablePropertyValues)pvs)
/*  76 */       .getPropertyValueList() : Arrays.asList(pvs.getPropertyValues());
/*  77 */     for (PropertyValue pv : propertyValues)
/*     */     {
/*     */       try
/*     */       {
/*  82 */         setPropertyValue(pv);
/*     */       }
/*     */       catch (NotWritablePropertyException ex) {
/*  85 */         if (!ignoreUnknown) {
/*  86 */           throw ex;
/*     */         }
/*     */       }
/*     */       catch (NullValueInNestedPathException ex)
/*     */       {
/*  91 */         if (!ignoreInvalid) {
/*  92 */           throw ex;
/*     */         }
/*     */       }
/*     */       catch (PropertyAccessException ex)
/*     */       {
/*  97 */         if (propertyAccessExceptions == null) {
/*  98 */           propertyAccessExceptions = new LinkedList();
/*     */         }
/* 100 */         propertyAccessExceptions.add(ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 105 */     if (propertyAccessExceptions != null)
/*     */     {
/* 107 */       PropertyAccessException[] paeArray = (PropertyAccessException[])propertyAccessExceptions
/* 107 */         .toArray(new PropertyAccessException[propertyAccessExceptions
/* 107 */         .size()]);
/* 108 */       throw new PropertyBatchUpdateException(paeArray);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<?> getPropertyType(String propertyPath)
/*     */   {
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */   public abstract Object getPropertyValue(String paramString)
/*     */     throws BeansException;
/*     */ 
/*     */   public abstract void setPropertyValue(String paramString, Object paramObject)
/*     */     throws BeansException;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.AbstractPropertyAccessor
 * JD-Core Version:    0.6.2
 */