/*    */ package org.springframework.beans;
/*    */ 
/*    */ public class BeanInstantiationException extends FatalBeanException
/*    */ {
/*    */   private Class<?> beanClass;
/*    */ 
/*    */   public BeanInstantiationException(Class<?> beanClass, String msg)
/*    */   {
/* 38 */     this(beanClass, msg, null);
/*    */   }
/*    */ 
/*    */   public BeanInstantiationException(Class<?> beanClass, String msg, Throwable cause)
/*    */   {
/* 48 */     super("Could not instantiate bean class [" + beanClass.getName() + "]: " + msg, cause);
/* 49 */     this.beanClass = beanClass;
/*    */   }
/*    */ 
/*    */   public Class<?> getBeanClass()
/*    */   {
/* 56 */     return this.beanClass;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.BeanInstantiationException
 * JD-Core Version:    0.6.2
 */