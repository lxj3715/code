package org.springframework.beans;

public abstract interface BeanMetadataElement
{
  public abstract Object getSource();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.BeanMetadataElement
 * JD-Core Version:    0.6.2
 */