/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class BeanUtils
/*     */ {
/*  58 */   private static final Log logger = LogFactory.getLog(BeanUtils.class);
/*     */ 
/*  62 */   private static final Map<Class<?>, Boolean> unknownEditorTypes = Collections.synchronizedMap(new WeakHashMap())
/*  62 */     ;
/*     */ 
/*     */   public static <T> T instantiate(Class<T> clazz)
/*     */     throws BeanInstantiationException
/*     */   {
/*  74 */     Assert.notNull(clazz, "Class must not be null");
/*  75 */     if (clazz.isInterface())
/*  76 */       throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */     try
/*     */     {
/*  79 */       return clazz.newInstance();
/*     */     }
/*     */     catch (InstantiationException ex) {
/*  82 */       throw new BeanInstantiationException(clazz, "Is it an abstract class?", ex);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/*  85 */       throw new BeanInstantiationException(clazz, "Is the constructor accessible?", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <T> T instantiateClass(Class<T> clazz)
/*     */     throws BeanInstantiationException
/*     */   {
/* 100 */     Assert.notNull(clazz, "Class must not be null");
/* 101 */     if (clazz.isInterface())
/* 102 */       throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */     try
/*     */     {
/* 105 */       return instantiateClass(clazz.getDeclaredConstructor(new Class[0]), new Object[0]);
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 108 */       throw new BeanInstantiationException(clazz, "No default constructor found", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <T> T instantiateClass(Class<?> clazz, Class<T> assignableTo)
/*     */     throws BeanInstantiationException
/*     */   {
/* 129 */     Assert.isAssignable(assignableTo, clazz);
/* 130 */     return instantiateClass(clazz);
/*     */   }
/*     */ 
/*     */   public static <T> T instantiateClass(Constructor<T> ctor, Object[] args)
/*     */     throws BeanInstantiationException
/*     */   {
/* 145 */     Assert.notNull(ctor, "Constructor must not be null");
/*     */     try {
/* 147 */       ReflectionUtils.makeAccessible(ctor);
/* 148 */       return ctor.newInstance(args);
/*     */     }
/*     */     catch (InstantiationException ex) {
/* 151 */       throw new BeanInstantiationException(ctor.getDeclaringClass(), "Is it an abstract class?", ex);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 155 */       throw new BeanInstantiationException(ctor.getDeclaringClass(), "Is the constructor accessible?", ex);
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 159 */       throw new BeanInstantiationException(ctor.getDeclaringClass(), "Illegal arguments for constructor", ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 164 */       throw new BeanInstantiationException(ctor.getDeclaringClass(), "Constructor threw exception", ex
/* 164 */         .getTargetException());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Method findMethod(Class<?> clazz, String methodName, Class<?>[] paramTypes)
/*     */   {
/*     */     try
/*     */     {
/* 184 */       return clazz.getMethod(methodName, paramTypes);
/*     */     } catch (NoSuchMethodException ex) {
/*     */     }
/* 187 */     return findDeclaredMethod(clazz, methodName, paramTypes);
/*     */   }
/*     */ 
/*     */   public static Method findDeclaredMethod(Class<?> clazz, String methodName, Class<?>[] paramTypes)
/*     */   {
/*     */     try
/*     */     {
/* 204 */       return clazz.getDeclaredMethod(methodName, paramTypes);
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 207 */       if (clazz.getSuperclass() != null)
/* 208 */         return findDeclaredMethod(clazz.getSuperclass(), methodName, paramTypes);
/*     */     }
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */   public static Method findMethodWithMinimalParameters(Class<?> clazz, String methodName)
/*     */     throws IllegalArgumentException
/*     */   {
/* 232 */     Method targetMethod = findMethodWithMinimalParameters(clazz.getMethods(), methodName);
/* 233 */     if (targetMethod == null) {
/* 234 */       targetMethod = findDeclaredMethodWithMinimalParameters(clazz, methodName);
/*     */     }
/* 236 */     return targetMethod;
/*     */   }
/*     */ 
/*     */   public static Method findDeclaredMethodWithMinimalParameters(Class<?> clazz, String methodName)
/*     */     throws IllegalArgumentException
/*     */   {
/* 254 */     Method targetMethod = findMethodWithMinimalParameters(clazz.getDeclaredMethods(), methodName);
/* 255 */     if ((targetMethod == null) && (clazz.getSuperclass() != null)) {
/* 256 */       targetMethod = findDeclaredMethodWithMinimalParameters(clazz.getSuperclass(), methodName);
/*     */     }
/* 258 */     return targetMethod;
/*     */   }
/*     */ 
/*     */   public static Method findMethodWithMinimalParameters(Method[] methods, String methodName)
/*     */     throws IllegalArgumentException
/*     */   {
/* 273 */     Method targetMethod = null;
/* 274 */     int numMethodsFoundWithCurrentMinimumArgs = 0;
/* 275 */     for (Method method : methods) {
/* 276 */       if (method.getName().equals(methodName)) {
/* 277 */         int numParams = method.getParameterTypes().length;
/* 278 */         if ((targetMethod == null) || (numParams < targetMethod.getParameterTypes().length)) {
/* 279 */           targetMethod = method;
/* 280 */           numMethodsFoundWithCurrentMinimumArgs = 1;
/*     */         }
/* 283 */         else if (targetMethod.getParameterTypes().length == numParams)
/*     */         {
/* 285 */           numMethodsFoundWithCurrentMinimumArgs++;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 290 */     if (numMethodsFoundWithCurrentMinimumArgs > 1) {
/* 291 */       throw new IllegalArgumentException("Cannot resolve method '" + methodName + "' to a unique method. Attempted to resolve to overloaded method with " + "the least number of parameters, but there were " + numMethodsFoundWithCurrentMinimumArgs + " candidates.");
/*     */     }
/*     */ 
/* 296 */     return targetMethod;
/*     */   }
/*     */ 
/*     */   public static Method resolveSignature(String signature, Class<?> clazz)
/*     */   {
/* 318 */     Assert.hasText(signature, "'signature' must not be empty");
/* 319 */     Assert.notNull(clazz, "Class must not be null");
/* 320 */     int firstParen = signature.indexOf("(");
/* 321 */     int lastParen = signature.indexOf(")");
/* 322 */     if ((firstParen > -1) && (lastParen == -1)) {
/* 323 */       throw new IllegalArgumentException("Invalid method signature '" + signature + "': expected closing ')' for args list");
/*     */     }
/*     */ 
/* 326 */     if ((lastParen > -1) && (firstParen == -1)) {
/* 327 */       throw new IllegalArgumentException("Invalid method signature '" + signature + "': expected opening '(' for args list");
/*     */     }
/*     */ 
/* 330 */     if ((firstParen == -1) && (lastParen == -1)) {
/* 331 */       return findMethodWithMinimalParameters(clazz, signature);
/*     */     }
/*     */ 
/* 334 */     String methodName = signature.substring(0, firstParen);
/*     */ 
/* 336 */     String[] parameterTypeNames = StringUtils.commaDelimitedListToStringArray(signature
/* 336 */       .substring(firstParen + 1, lastParen));
/*     */ 
/* 337 */     Class[] parameterTypes = new Class[parameterTypeNames.length];
/* 338 */     for (int i = 0; i < parameterTypeNames.length; i++) {
/* 339 */       String parameterTypeName = parameterTypeNames[i].trim();
/*     */       try {
/* 341 */         parameterTypes[i] = ClassUtils.forName(parameterTypeName, clazz.getClassLoader());
/*     */       }
/*     */       catch (Throwable ex) {
/* 344 */         throw new IllegalArgumentException("Invalid method signature: unable to resolve type [" + parameterTypeName + "] for argument " + i + ". Root cause: " + ex);
/*     */       }
/*     */     }
/*     */ 
/* 348 */     return findMethod(clazz, methodName, parameterTypes);
/*     */   }
/*     */ 
/*     */   public static PropertyDescriptor[] getPropertyDescriptors(Class<?> clazz)
/*     */     throws BeansException
/*     */   {
/* 360 */     CachedIntrospectionResults cr = CachedIntrospectionResults.forClass(clazz);
/* 361 */     return cr.getPropertyDescriptors();
/*     */   }
/*     */ 
/*     */   public static PropertyDescriptor getPropertyDescriptor(Class<?> clazz, String propertyName)
/*     */     throws BeansException
/*     */   {
/* 374 */     CachedIntrospectionResults cr = CachedIntrospectionResults.forClass(clazz);
/* 375 */     return cr.getPropertyDescriptor(propertyName);
/*     */   }
/*     */ 
/*     */   public static PropertyDescriptor findPropertyForMethod(Method method)
/*     */     throws BeansException
/*     */   {
/* 387 */     Assert.notNull(method, "Method must not be null");
/* 388 */     PropertyDescriptor[] pds = getPropertyDescriptors(method.getDeclaringClass());
/* 389 */     for (PropertyDescriptor pd : pds) {
/* 390 */       if ((method.equals(pd.getReadMethod())) || (method.equals(pd.getWriteMethod()))) {
/* 391 */         return pd;
/*     */       }
/*     */     }
/* 394 */     return null;
/*     */   }
/*     */ 
/*     */   public static PropertyEditor findEditorByConvention(Class<?> targetType)
/*     */   {
/* 407 */     if ((targetType == null) || (targetType.isArray()) || (unknownEditorTypes.containsKey(targetType))) {
/* 408 */       return null;
/*     */     }
/* 410 */     ClassLoader cl = targetType.getClassLoader();
/* 411 */     if (cl == null) {
/*     */       try {
/* 413 */         cl = ClassLoader.getSystemClassLoader();
/* 414 */         if (cl == null) {
/* 415 */           return null;
/*     */         }
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 420 */         if (logger.isDebugEnabled()) {
/* 421 */           logger.debug("Could not access system ClassLoader: " + ex);
/*     */         }
/* 423 */         return null;
/*     */       }
/*     */     }
/* 426 */     String editorName = targetType.getName() + "Editor";
/*     */     try {
/* 428 */       Class editorClass = cl.loadClass(editorName);
/* 429 */       if (!PropertyEditor.class.isAssignableFrom(editorClass)) {
/* 430 */         if (logger.isWarnEnabled()) {
/* 431 */           logger.warn("Editor class [" + editorName + "] does not implement [java.beans.PropertyEditor] interface");
/*     */         }
/*     */ 
/* 434 */         unknownEditorTypes.put(targetType, Boolean.TRUE);
/* 435 */         return null;
/*     */       }
/* 437 */       return (PropertyEditor)instantiateClass(editorClass);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 440 */       if (logger.isDebugEnabled()) {
/* 441 */         logger.debug("No property editor [" + editorName + "] found for type " + targetType
/* 442 */           .getName() + " according to 'Editor' suffix convention");
/*     */       }
/* 444 */       unknownEditorTypes.put(targetType, Boolean.TRUE);
/* 445 */     }return null;
/*     */   }
/*     */ 
/*     */   public static Class<?> findPropertyType(String propertyName, Class<?>[] beanClasses)
/*     */   {
/* 457 */     if (beanClasses != null) {
/* 458 */       for (Class beanClass : beanClasses) {
/* 459 */         PropertyDescriptor pd = getPropertyDescriptor(beanClass, propertyName);
/* 460 */         if (pd != null) {
/* 461 */           return pd.getPropertyType();
/*     */         }
/*     */       }
/*     */     }
/* 465 */     return Object.class;
/*     */   }
/*     */ 
/*     */   public static MethodParameter getWriteMethodParameter(PropertyDescriptor pd)
/*     */   {
/* 475 */     if ((pd instanceof GenericTypeAwarePropertyDescriptor)) {
/* 476 */       return new MethodParameter(((GenericTypeAwarePropertyDescriptor)pd).getWriteMethodParameter());
/*     */     }
/*     */ 
/* 479 */     return new MethodParameter(pd.getWriteMethod(), 0);
/*     */   }
/*     */ 
/*     */   public static boolean isSimpleProperty(Class<?> clazz)
/*     */   {
/* 494 */     Assert.notNull(clazz, "Class must not be null");
/* 495 */     return (isSimpleValueType(clazz)) || ((clazz.isArray()) && (isSimpleValueType(clazz.getComponentType())));
/*     */   }
/*     */ 
/*     */   public static boolean isSimpleValueType(Class<?> clazz)
/*     */   {
/* 511 */     return (ClassUtils.isPrimitiveOrWrapper(clazz)) || (clazz.isEnum()) || 
/* 507 */       (CharSequence.class
/* 507 */       .isAssignableFrom(clazz)) || 
/* 508 */       (Number.class
/* 508 */       .isAssignableFrom(clazz)) || 
/* 509 */       (Date.class
/* 509 */       .isAssignableFrom(clazz)) || 
/* 510 */       (clazz
/* 510 */       .equals(URI.class)) || 
/* 510 */       (clazz.equals(URL.class)) || 
/* 511 */       (clazz
/* 511 */       .equals(Locale.class)) || 
/* 511 */       (clazz.equals(Class.class));
/*     */   }
/*     */ 
/*     */   public static void copyProperties(Object source, Object target)
/*     */     throws BeansException
/*     */   {
/* 528 */     copyProperties(source, target, null, (String[])null);
/*     */   }
/*     */ 
/*     */   public static void copyProperties(Object source, Object target, Class<?> editable)
/*     */     throws BeansException
/*     */   {
/* 546 */     copyProperties(source, target, editable, (String[])null);
/*     */   }
/*     */ 
/*     */   public static void copyProperties(Object source, Object target, String[] ignoreProperties)
/*     */     throws BeansException
/*     */   {
/* 564 */     copyProperties(source, target, null, ignoreProperties);
/*     */   }
/*     */ 
/*     */   private static void copyProperties(Object source, Object target, Class<?> editable, String[] ignoreProperties)
/*     */     throws BeansException
/*     */   {
/* 582 */     Assert.notNull(source, "Source must not be null");
/* 583 */     Assert.notNull(target, "Target must not be null");
/*     */ 
/* 585 */     Class actualEditable = target.getClass();
/* 586 */     if (editable != null) {
/* 587 */       if (!editable.isInstance(target))
/*     */       {
/* 589 */         throw new IllegalArgumentException("Target class [" + target.getClass().getName() + "] not assignable to Editable class [" + editable
/* 589 */           .getName() + "]");
/*     */       }
/* 591 */       actualEditable = editable;
/*     */     }
/* 593 */     PropertyDescriptor[] targetPds = getPropertyDescriptors(actualEditable);
/* 594 */     List ignoreList = ignoreProperties != null ? Arrays.asList(ignoreProperties) : null;
/*     */ 
/* 596 */     for (PropertyDescriptor targetPd : targetPds) {
/* 597 */       Method writeMethod = targetPd.getWriteMethod();
/* 598 */       if ((writeMethod != null) && ((ignoreProperties == null) || (!ignoreList.contains(targetPd.getName())))) {
/* 599 */         PropertyDescriptor sourcePd = getPropertyDescriptor(source.getClass(), targetPd.getName());
/* 600 */         if (sourcePd != null) {
/* 601 */           Method readMethod = sourcePd.getReadMethod();
/* 602 */           if ((readMethod != null) && 
/* 603 */             (writeMethod
/* 603 */             .getParameterTypes()[0].isAssignableFrom(readMethod.getReturnType())))
/*     */             try {
/* 605 */               if (!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) {
/* 606 */                 readMethod.setAccessible(true);
/*     */               }
/* 608 */               Object value = readMethod.invoke(source, new Object[0]);
/* 609 */               if (!Modifier.isPublic(writeMethod.getDeclaringClass().getModifiers())) {
/* 610 */                 writeMethod.setAccessible(true);
/*     */               }
/* 612 */               writeMethod.invoke(target, new Object[] { value });
/*     */             }
/*     */             catch (Throwable ex)
/*     */             {
/* 616 */               throw new FatalBeanException("Could not copy property '" + targetPd
/* 616 */                 .getName() + "' from source to target", ex);
/*     */             }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.BeanUtils
 * JD-Core Version:    0.6.2
 */