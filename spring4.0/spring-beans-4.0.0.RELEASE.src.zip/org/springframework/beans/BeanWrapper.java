package org.springframework.beans;

import java.beans.PropertyDescriptor;

public abstract interface BeanWrapper extends ConfigurablePropertyAccessor
{
  public abstract Object getWrappedInstance();

  public abstract Class<?> getWrappedClass();

  public abstract PropertyDescriptor[] getPropertyDescriptors();

  public abstract PropertyDescriptor getPropertyDescriptor(String paramString)
    throws InvalidPropertyException;

  public abstract void setAutoGrowNestedPaths(boolean paramBoolean);

  public abstract boolean isAutoGrowNestedPaths();

  public abstract void setAutoGrowCollectionLimit(int paramInt);

  public abstract int getAutoGrowCollectionLimit();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.BeanWrapper
 * JD-Core Version:    0.6.2
 */