/*      */ package org.springframework.beans;
/*      */ 
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.core.CollectionFactory;
/*      */ import org.springframework.core.GenericCollectionTypeResolver;
/*      */ import org.springframework.core.convert.ConversionException;
/*      */ import org.springframework.core.convert.ConverterNotFoundException;
/*      */ import org.springframework.core.convert.Property;
/*      */ import org.springframework.core.convert.TypeDescriptor;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public class BeanWrapperImpl extends AbstractPropertyAccessor
/*      */   implements BeanWrapper
/*      */ {
/*   91 */   private static final Log logger = LogFactory.getLog(BeanWrapperImpl.class);
/*      */   private Object object;
/*   97 */   private String nestedPath = "";
/*      */   private Object rootObject;
/*      */   private AccessControlContext acc;
/*      */   private CachedIntrospectionResults cachedIntrospectionResults;
/*      */   private Map<String, BeanWrapperImpl> nestedBeanWrappers;
/*  117 */   private boolean autoGrowNestedPaths = false;
/*      */ 
/*  119 */   private int autoGrowCollectionLimit = 2147483647;
/*      */ 
/*      */   public BeanWrapperImpl()
/*      */   {
/*  128 */     this(true);
/*      */   }
/*      */ 
/*      */   public BeanWrapperImpl(boolean registerDefaultEditors)
/*      */   {
/*  138 */     if (registerDefaultEditors) {
/*  139 */       registerDefaultEditors();
/*      */     }
/*  141 */     this.typeConverterDelegate = new TypeConverterDelegate(this);
/*      */   }
/*      */ 
/*      */   public BeanWrapperImpl(Object object)
/*      */   {
/*  149 */     registerDefaultEditors();
/*  150 */     setWrappedInstance(object);
/*      */   }
/*      */ 
/*      */   public BeanWrapperImpl(Class<?> clazz)
/*      */   {
/*  158 */     registerDefaultEditors();
/*  159 */     setWrappedInstance(BeanUtils.instantiateClass(clazz));
/*      */   }
/*      */ 
/*      */   public BeanWrapperImpl(Object object, String nestedPath, Object rootObject)
/*      */   {
/*  170 */     registerDefaultEditors();
/*  171 */     setWrappedInstance(object, nestedPath, rootObject);
/*      */   }
/*      */ 
/*      */   private BeanWrapperImpl(Object object, String nestedPath, BeanWrapperImpl superBw)
/*      */   {
/*  182 */     setWrappedInstance(object, nestedPath, superBw.getWrappedInstance());
/*  183 */     setExtractOldValueForEditor(superBw.isExtractOldValueForEditor());
/*  184 */     setAutoGrowNestedPaths(superBw.isAutoGrowNestedPaths());
/*  185 */     setAutoGrowCollectionLimit(superBw.getAutoGrowCollectionLimit());
/*  186 */     setConversionService(superBw.getConversionService());
/*  187 */     setSecurityContext(superBw.acc);
/*      */   }
/*      */ 
/*      */   public void setWrappedInstance(Object object)
/*      */   {
/*  201 */     setWrappedInstance(object, "", null);
/*      */   }
/*      */ 
/*      */   public void setWrappedInstance(Object object, String nestedPath, Object rootObject)
/*      */   {
/*  212 */     Assert.notNull(object, "Bean object must not be null");
/*  213 */     this.object = object;
/*  214 */     this.nestedPath = (nestedPath != null ? nestedPath : "");
/*  215 */     this.rootObject = (!"".equals(this.nestedPath) ? rootObject : object);
/*  216 */     this.nestedBeanWrappers = null;
/*  217 */     this.typeConverterDelegate = new TypeConverterDelegate(this, object);
/*  218 */     setIntrospectionClass(object.getClass());
/*      */   }
/*      */ 
/*      */   public final Object getWrappedInstance()
/*      */   {
/*  223 */     return this.object;
/*      */   }
/*      */ 
/*      */   public final Class<?> getWrappedClass()
/*      */   {
/*  228 */     return this.object != null ? this.object.getClass() : null;
/*      */   }
/*      */ 
/*      */   public final String getNestedPath()
/*      */   {
/*  235 */     return this.nestedPath;
/*      */   }
/*      */ 
/*      */   public final Object getRootInstance()
/*      */   {
/*  243 */     return this.rootObject;
/*      */   }
/*      */ 
/*      */   public final Class<?> getRootClass()
/*      */   {
/*  251 */     return this.rootObject != null ? this.rootObject.getClass() : null;
/*      */   }
/*      */ 
/*      */   public void setAutoGrowNestedPaths(boolean autoGrowNestedPaths)
/*      */   {
/*  263 */     this.autoGrowNestedPaths = autoGrowNestedPaths;
/*      */   }
/*      */ 
/*      */   public boolean isAutoGrowNestedPaths()
/*      */   {
/*  271 */     return this.autoGrowNestedPaths;
/*      */   }
/*      */ 
/*      */   public void setAutoGrowCollectionLimit(int autoGrowCollectionLimit)
/*      */   {
/*  280 */     this.autoGrowCollectionLimit = autoGrowCollectionLimit;
/*      */   }
/*      */ 
/*      */   public int getAutoGrowCollectionLimit()
/*      */   {
/*  288 */     return this.autoGrowCollectionLimit;
/*      */   }
/*      */ 
/*      */   public void setSecurityContext(AccessControlContext acc)
/*      */   {
/*  296 */     this.acc = acc;
/*      */   }
/*      */ 
/*      */   public AccessControlContext getSecurityContext()
/*      */   {
/*  304 */     return this.acc;
/*      */   }
/*      */ 
/*      */   protected void setIntrospectionClass(Class<?> clazz)
/*      */   {
/*  313 */     if ((this.cachedIntrospectionResults != null) && 
/*  314 */       (!clazz
/*  314 */       .equals(this.cachedIntrospectionResults
/*  314 */       .getBeanClass())))
/*  315 */       this.cachedIntrospectionResults = null;
/*      */   }
/*      */ 
/*      */   private CachedIntrospectionResults getCachedIntrospectionResults()
/*      */   {
/*  324 */     Assert.state(this.object != null, "BeanWrapper does not hold a bean instance");
/*  325 */     if (this.cachedIntrospectionResults == null) {
/*  326 */       this.cachedIntrospectionResults = CachedIntrospectionResults.forClass(getWrappedClass());
/*      */     }
/*  328 */     return this.cachedIntrospectionResults;
/*      */   }
/*      */ 
/*      */   public PropertyDescriptor[] getPropertyDescriptors()
/*      */   {
/*  334 */     return getCachedIntrospectionResults().getPropertyDescriptors();
/*      */   }
/*      */ 
/*      */   public PropertyDescriptor getPropertyDescriptor(String propertyName) throws BeansException
/*      */   {
/*  339 */     PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);
/*  340 */     if (pd == null) {
/*  341 */       throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("No property '").append(propertyName).append("' found").toString());
/*      */     }
/*      */ 
/*  344 */     return pd;
/*      */   }
/*      */ 
/*      */   protected PropertyDescriptor getPropertyDescriptorInternal(String propertyName)
/*      */     throws BeansException
/*      */   {
/*  356 */     Assert.notNull(propertyName, "Property name must not be null");
/*  357 */     BeanWrapperImpl nestedBw = getBeanWrapperForPropertyPath(propertyName);
/*  358 */     return nestedBw.getCachedIntrospectionResults().getPropertyDescriptor(getFinalPath(nestedBw, propertyName));
/*      */   }
/*      */ 
/*      */   public Class<?> getPropertyType(String propertyName) throws BeansException
/*      */   {
/*      */     try {
/*  364 */       PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);
/*  365 */       if (pd != null) {
/*  366 */         return pd.getPropertyType();
/*      */       }
/*      */ 
/*  370 */       Object value = getPropertyValue(propertyName);
/*  371 */       if (value != null) {
/*  372 */         return value.getClass();
/*      */       }
/*      */ 
/*  376 */       Class editorType = guessPropertyTypeFromEditors(propertyName);
/*  377 */       if (editorType != null) {
/*  378 */         return editorType;
/*      */       }
/*      */     }
/*      */     catch (InvalidPropertyException ex)
/*      */     {
/*      */     }
/*      */ 
/*  385 */     return null;
/*      */   }
/*      */ 
/*      */   public TypeDescriptor getPropertyTypeDescriptor(String propertyName) throws BeansException
/*      */   {
/*      */     try {
/*  391 */       BeanWrapperImpl nestedBw = getBeanWrapperForPropertyPath(propertyName);
/*  392 */       String finalPath = getFinalPath(nestedBw, propertyName);
/*  393 */       PropertyTokenHolder tokens = getPropertyNameTokens(finalPath);
/*  394 */       PropertyDescriptor pd = nestedBw.getCachedIntrospectionResults().getPropertyDescriptor(tokens.actualName);
/*  395 */       if (pd != null) {
/*  396 */         if (tokens.keys != null) {
/*  397 */           if ((pd.getReadMethod() != null) || (pd.getWriteMethod() != null)) {
/*  398 */             return TypeDescriptor.nested(property(pd), tokens.keys.length);
/*      */           }
/*      */         }
/*  401 */         else if ((pd.getReadMethod() != null) || (pd.getWriteMethod() != null)) {
/*  402 */           return new TypeDescriptor(property(pd));
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (InvalidPropertyException ex)
/*      */     {
/*      */     }
/*      */ 
/*  410 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isReadableProperty(String propertyName)
/*      */   {
/*      */     try {
/*  416 */       PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);
/*  417 */       if (pd != null) {
/*  418 */         if (pd.getReadMethod() != null) {
/*  419 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  424 */         getPropertyValue(propertyName);
/*  425 */         return true;
/*      */       }
/*      */     }
/*      */     catch (InvalidPropertyException ex)
/*      */     {
/*      */     }
/*  431 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isWritableProperty(String propertyName)
/*      */   {
/*      */     try {
/*  437 */       PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);
/*  438 */       if (pd != null) {
/*  439 */         if (pd.getWriteMethod() != null) {
/*  440 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  445 */         getPropertyValue(propertyName);
/*  446 */         return true;
/*      */       }
/*      */     }
/*      */     catch (InvalidPropertyException ex)
/*      */     {
/*      */     }
/*  452 */     return false;
/*      */   }
/*      */ 
/*      */   private Object convertIfNecessary(String propertyName, Object oldValue, Object newValue, Class<?> requiredType, TypeDescriptor td) throws TypeMismatchException
/*      */   {
/*      */     try {
/*  458 */       return this.typeConverterDelegate.convertIfNecessary(propertyName, oldValue, newValue, requiredType, td);
/*      */     }
/*      */     catch (ConverterNotFoundException ex) {
/*  461 */       PropertyChangeEvent pce = new PropertyChangeEvent(this.rootObject, new StringBuilder().append(this.nestedPath).append(propertyName).toString(), oldValue, newValue);
/*      */ 
/*  463 */       throw new ConversionNotSupportedException(pce, td.getType(), ex);
/*      */     }
/*      */     catch (ConversionException ex) {
/*  466 */       PropertyChangeEvent pce = new PropertyChangeEvent(this.rootObject, new StringBuilder().append(this.nestedPath).append(propertyName).toString(), oldValue, newValue);
/*      */ 
/*  468 */       throw new TypeMismatchException(pce, requiredType, ex);
/*      */     }
/*      */     catch (IllegalStateException ex) {
/*  471 */       PropertyChangeEvent pce = new PropertyChangeEvent(this.rootObject, new StringBuilder().append(this.nestedPath).append(propertyName).toString(), oldValue, newValue);
/*      */ 
/*  473 */       throw new ConversionNotSupportedException(pce, requiredType, ex);
/*      */     }
/*      */     catch (IllegalArgumentException ex) {
/*  476 */       PropertyChangeEvent pce = new PropertyChangeEvent(this.rootObject, new StringBuilder().append(this.nestedPath).append(propertyName).toString(), oldValue, newValue);
/*      */ 
/*  478 */       throw new TypeMismatchException(pce, requiredType, ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Object convertForProperty(Object value, String propertyName)
/*      */     throws TypeMismatchException
/*      */   {
/*  493 */     CachedIntrospectionResults cachedIntrospectionResults = getCachedIntrospectionResults();
/*  494 */     PropertyDescriptor pd = cachedIntrospectionResults.getPropertyDescriptor(propertyName);
/*  495 */     TypeDescriptor td = cachedIntrospectionResults.getTypeDescriptor(pd);
/*  496 */     if (pd == null) {
/*  497 */       throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("No property '").append(propertyName).append("' found").toString());
/*      */     }
/*      */ 
/*  500 */     if (td == null) {
/*  501 */       td = new TypeDescriptor(property(pd));
/*  502 */       cachedIntrospectionResults.putTypeDescriptor(pd, td);
/*      */     }
/*  504 */     return convertForProperty(propertyName, null, value, pd, td);
/*      */   }
/*      */ 
/*      */   private Object convertForProperty(String propertyName, Object oldValue, Object newValue, PropertyDescriptor pd, TypeDescriptor td) throws TypeMismatchException
/*      */   {
/*  509 */     return convertIfNecessary(propertyName, oldValue, newValue, pd.getPropertyType(), td);
/*      */   }
/*      */ 
/*      */   private Property property(PropertyDescriptor pd) {
/*  513 */     GenericTypeAwarePropertyDescriptor typeAware = (GenericTypeAwarePropertyDescriptor)pd;
/*  514 */     return new Property(typeAware.getBeanClass(), typeAware.getReadMethod(), typeAware.getWriteMethod(), typeAware.getName());
/*      */   }
/*      */ 
/*      */   private String getFinalPath(BeanWrapper bw, String nestedPath)
/*      */   {
/*  529 */     if (bw == this) {
/*  530 */       return nestedPath;
/*      */     }
/*  532 */     return nestedPath.substring(PropertyAccessorUtils.getLastNestedPropertySeparatorIndex(nestedPath) + 1);
/*      */   }
/*      */ 
/*      */   protected BeanWrapperImpl getBeanWrapperForPropertyPath(String propertyPath)
/*      */   {
/*  541 */     int pos = PropertyAccessorUtils.getFirstNestedPropertySeparatorIndex(propertyPath);
/*      */ 
/*  543 */     if (pos > -1) {
/*  544 */       String nestedProperty = propertyPath.substring(0, pos);
/*  545 */       String nestedPath = propertyPath.substring(pos + 1);
/*  546 */       BeanWrapperImpl nestedBw = getNestedBeanWrapper(nestedProperty);
/*  547 */       return nestedBw.getBeanWrapperForPropertyPath(nestedPath);
/*      */     }
/*      */ 
/*  550 */     return this;
/*      */   }
/*      */ 
/*      */   private BeanWrapperImpl getNestedBeanWrapper(String nestedProperty)
/*      */   {
/*  563 */     if (this.nestedBeanWrappers == null) {
/*  564 */       this.nestedBeanWrappers = new HashMap();
/*      */     }
/*      */ 
/*  567 */     PropertyTokenHolder tokens = getPropertyNameTokens(nestedProperty);
/*  568 */     String canonicalName = tokens.canonicalName;
/*  569 */     Object propertyValue = getPropertyValue(tokens);
/*  570 */     if (propertyValue == null) {
/*  571 */       if (this.autoGrowNestedPaths) {
/*  572 */         propertyValue = setDefaultValue(tokens);
/*      */       }
/*      */       else {
/*  575 */         throw new NullValueInNestedPathException(getRootClass(), new StringBuilder().append(this.nestedPath).append(canonicalName).toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  580 */     BeanWrapperImpl nestedBw = (BeanWrapperImpl)this.nestedBeanWrappers.get(canonicalName);
/*  581 */     if ((nestedBw == null) || (nestedBw.getWrappedInstance() != propertyValue)) {
/*  582 */       if (logger.isTraceEnabled()) {
/*  583 */         logger.trace(new StringBuilder().append("Creating new nested BeanWrapper for property '").append(canonicalName).append("'").toString());
/*      */       }
/*  585 */       nestedBw = newNestedBeanWrapper(propertyValue, new StringBuilder().append(this.nestedPath).append(canonicalName).append(".").toString());
/*      */ 
/*  587 */       copyDefaultEditorsTo(nestedBw);
/*  588 */       copyCustomEditorsTo(nestedBw, canonicalName);
/*  589 */       this.nestedBeanWrappers.put(canonicalName, nestedBw);
/*      */     }
/*  592 */     else if (logger.isTraceEnabled()) {
/*  593 */       logger.trace(new StringBuilder().append("Using cached nested BeanWrapper for property '").append(canonicalName).append("'").toString());
/*      */     }
/*      */ 
/*  596 */     return nestedBw;
/*      */   }
/*      */ 
/*      */   private Object setDefaultValue(String propertyName) {
/*  600 */     PropertyTokenHolder tokens = new PropertyTokenHolder(null);
/*  601 */     tokens.actualName = propertyName;
/*  602 */     tokens.canonicalName = propertyName;
/*  603 */     return setDefaultValue(tokens);
/*      */   }
/*      */ 
/*      */   private Object setDefaultValue(PropertyTokenHolder tokens) {
/*  607 */     PropertyValue pv = createDefaultPropertyValue(tokens);
/*  608 */     setPropertyValue(tokens, pv);
/*  609 */     return getPropertyValue(tokens);
/*      */   }
/*      */ 
/*      */   private PropertyValue createDefaultPropertyValue(PropertyTokenHolder tokens) {
/*  613 */     Class type = getPropertyTypeDescriptor(tokens.canonicalName).getType();
/*  614 */     if (type == null) {
/*  615 */       throw new NullValueInNestedPathException(getRootClass(), new StringBuilder().append(this.nestedPath).append(tokens.canonicalName).toString(), "Could not determine property type for auto-growing a default value");
/*      */     }
/*      */ 
/*  618 */     Object defaultValue = newValue(type, tokens.canonicalName);
/*  619 */     return new PropertyValue(tokens.canonicalName, defaultValue);
/*      */   }
/*      */ 
/*      */   private Object newValue(Class<?> type, String name) {
/*      */     try {
/*  624 */       if (type.isArray()) {
/*  625 */         Class componentType = type.getComponentType();
/*      */ 
/*  627 */         if (componentType.isArray()) {
/*  628 */           Object array = Array.newInstance(componentType, 1);
/*  629 */           Array.set(array, 0, Array.newInstance(componentType.getComponentType(), 0));
/*  630 */           return array;
/*      */         }
/*      */ 
/*  633 */         return Array.newInstance(componentType, 0);
/*      */       }
/*      */ 
/*  636 */       if (Collection.class.isAssignableFrom(type)) {
/*  637 */         return CollectionFactory.createCollection(type, 16);
/*      */       }
/*  639 */       if (Map.class.isAssignableFrom(type)) {
/*  640 */         return CollectionFactory.createMap(type, 16);
/*      */       }
/*      */ 
/*  643 */       return type.newInstance();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  649 */       throw new NullValueInNestedPathException(getRootClass(), new StringBuilder().append(this.nestedPath).append(name).toString(), new StringBuilder().append("Could not instantiate property type [")
/*  649 */         .append(type
/*  649 */         .getName()).append("] to auto-grow nested property path: ").append(ex).toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected BeanWrapperImpl newNestedBeanWrapper(Object object, String nestedPath)
/*      */   {
/*  662 */     return new BeanWrapperImpl(object, nestedPath, this);
/*      */   }
/*      */ 
/*      */   private PropertyTokenHolder getPropertyNameTokens(String propertyName)
/*      */   {
/*  671 */     PropertyTokenHolder tokens = new PropertyTokenHolder(null);
/*  672 */     String actualName = null;
/*  673 */     List keys = new ArrayList(2);
/*  674 */     int searchIndex = 0;
/*  675 */     while (searchIndex != -1) {
/*  676 */       int keyStart = propertyName.indexOf("[", searchIndex);
/*  677 */       searchIndex = -1;
/*  678 */       if (keyStart != -1) {
/*  679 */         int keyEnd = propertyName.indexOf("]", keyStart + "[".length());
/*  680 */         if (keyEnd != -1) {
/*  681 */           if (actualName == null) {
/*  682 */             actualName = propertyName.substring(0, keyStart);
/*      */           }
/*  684 */           String key = propertyName.substring(keyStart + "[".length(), keyEnd);
/*  685 */           if (((key.startsWith("'")) && (key.endsWith("'"))) || ((key.startsWith("\"")) && (key.endsWith("\"")))) {
/*  686 */             key = key.substring(1, key.length() - 1);
/*      */           }
/*  688 */           keys.add(key);
/*  689 */           searchIndex = keyEnd + "]".length();
/*      */         }
/*      */       }
/*      */     }
/*  693 */     tokens.actualName = (actualName != null ? actualName : propertyName);
/*  694 */     tokens.canonicalName = tokens.actualName;
/*  695 */     if (!keys.isEmpty())
/*      */     {
/*      */       PropertyTokenHolder tmp216_215 = tokens; tmp216_215.canonicalName = new StringBuilder().append(tmp216_215.canonicalName).append("[")
/*  698 */         .append(StringUtils.collectionToDelimitedString(keys, "]["))
/*  698 */         .append("]").toString();
/*      */ 
/*  700 */       tokens.keys = StringUtils.toStringArray(keys);
/*      */     }
/*  702 */     return tokens;
/*      */   }
/*      */ 
/*      */   public Object getPropertyValue(String propertyName)
/*      */     throws BeansException
/*      */   {
/*  712 */     BeanWrapperImpl nestedBw = getBeanWrapperForPropertyPath(propertyName);
/*  713 */     PropertyTokenHolder tokens = getPropertyNameTokens(getFinalPath(nestedBw, propertyName));
/*  714 */     return nestedBw.getPropertyValue(tokens);
/*      */   }
/*      */ 
/*      */   private Object getPropertyValue(PropertyTokenHolder tokens) throws BeansException
/*      */   {
/*  719 */     String propertyName = tokens.canonicalName;
/*  720 */     String actualName = tokens.actualName;
/*  721 */     PropertyDescriptor pd = getCachedIntrospectionResults().getPropertyDescriptor(actualName);
/*  722 */     if ((pd == null) || (pd.getReadMethod() == null)) {
/*  723 */       throw new NotReadablePropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString());
/*      */     }
/*  725 */     final Method readMethod = pd.getReadMethod();
/*      */     try {
/*  727 */       if ((!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) && (!readMethod.isAccessible()))
/*  728 */         if (System.getSecurityManager() != null) {
/*  729 */           AccessController.doPrivileged(new PrivilegedAction()
/*      */           {
/*      */             public Object run() {
/*  732 */               readMethod.setAccessible(true);
/*  733 */               return null;
/*      */             }
/*      */           });
/*      */         }
/*      */         else
/*  738 */           readMethod.setAccessible(true);
/*      */       Object value;
/*  743 */       if (System.getSecurityManager() != null) {
/*      */         try {
/*  745 */           value = AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */           {
/*      */             public Object run() throws Exception {
/*  748 */               return readMethod.invoke(BeanWrapperImpl.this.object, (Object[])null);
/*      */             }
/*      */           }
/*      */           , this.acc);
/*      */         }
/*      */         catch (PrivilegedActionException pae)
/*      */         {
/*      */           Object value;
/*  753 */           throw pae.getException();
/*      */         }
/*      */       }
/*      */       else {
/*  757 */         value = readMethod.invoke(this.object, (Object[])null);
/*      */       }
/*      */ 
/*  760 */       if (tokens.keys != null) {
/*  761 */         if (value == null) {
/*  762 */           if (this.autoGrowNestedPaths) {
/*  763 */             value = setDefaultValue(tokens.actualName);
/*      */           }
/*      */           else {
/*  766 */             throw new NullValueInNestedPathException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Cannot access indexed value of property referenced in indexed property path '").append(propertyName).append("': returned null").toString());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  771 */         String indexedPropertyName = tokens.actualName;
/*      */ 
/*  773 */         for (int i = 0; i < tokens.keys.length; i++) {
/*  774 */           String key = tokens.keys[i];
/*  775 */           if (value == null) {
/*  776 */             throw new NullValueInNestedPathException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Cannot access indexed value of property referenced in indexed property path '").append(propertyName).append("': returned null").toString());
/*      */           }
/*      */ 
/*  780 */           if (value.getClass().isArray()) {
/*  781 */             int index = Integer.parseInt(key);
/*  782 */             value = growArrayIfNecessary(value, index, indexedPropertyName);
/*  783 */             value = Array.get(value, index);
/*      */           }
/*  785 */           else if ((value instanceof List)) {
/*  786 */             int index = Integer.parseInt(key);
/*  787 */             List list = (List)value;
/*  788 */             growCollectionIfNecessary(list, index, indexedPropertyName, pd, i + 1);
/*  789 */             value = list.get(index);
/*      */           }
/*  791 */           else if ((value instanceof Set))
/*      */           {
/*  793 */             Set set = (Set)value;
/*  794 */             int index = Integer.parseInt(key);
/*  795 */             if ((index < 0) || (index >= set.size()))
/*      */             {
/*  798 */               throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Cannot get element with index ").append(index).append(" from Set of size ")
/*  798 */                 .append(set
/*  798 */                 .size()).append(", accessed using property path '").append(propertyName).append("'").toString());
/*      */             }
/*  800 */             Iterator it = set.iterator();
/*  801 */             for (int j = 0; it.hasNext(); j++) {
/*  802 */               Object elem = it.next();
/*  803 */               if (j == index) {
/*  804 */                 value = elem;
/*  805 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*  809 */           else if ((value instanceof Map)) {
/*  810 */             Map map = (Map)value;
/*  811 */             Class mapKeyType = GenericCollectionTypeResolver.getMapKeyReturnType(pd.getReadMethod(), i + 1);
/*      */ 
/*  814 */             TypeDescriptor typeDescriptor = mapKeyType != null ? TypeDescriptor.valueOf(mapKeyType) : TypeDescriptor.valueOf(Object.class);
/*  815 */             Object convertedMapKey = convertIfNecessary(null, null, key, mapKeyType, typeDescriptor);
/*  816 */             value = map.get(convertedMapKey);
/*      */           }
/*      */           else {
/*  819 */             throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Property referenced in indexed property path '").append(propertyName).append("' is neither an array nor a List nor a Set nor a Map; returned value was [").append(value).append("]").toString());
/*      */           }
/*      */ 
/*  823 */           indexedPropertyName = new StringBuilder().append(indexedPropertyName).append("[").append(key).append("]").toString();
/*      */         }
/*      */       }
/*  826 */       return value;
/*      */     }
/*      */     catch (IndexOutOfBoundsException ex) {
/*  829 */       throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Index of out of bounds in property path '").append(propertyName).append("'").toString(), ex);
/*      */     }
/*      */     catch (NumberFormatException ex)
/*      */     {
/*  833 */       throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Invalid index in property path '").append(propertyName).append("'").toString(), ex);
/*      */     }
/*      */     catch (TypeMismatchException ex)
/*      */     {
/*  837 */       throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Invalid index in property path '").append(propertyName).append("'").toString(), ex);
/*      */     }
/*      */     catch (InvocationTargetException ex)
/*      */     {
/*  841 */       throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Getter for property '").append(actualName).append("' threw exception").toString(), ex);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  845 */       throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Illegal attempt to get property '").append(actualName).append("' threw exception").toString(), ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Object growArrayIfNecessary(Object array, int index, String name)
/*      */   {
/*  851 */     if (!this.autoGrowNestedPaths) {
/*  852 */       return array;
/*      */     }
/*  854 */     int length = Array.getLength(array);
/*  855 */     if ((index >= length) && (index < this.autoGrowCollectionLimit)) {
/*  856 */       Class componentType = array.getClass().getComponentType();
/*  857 */       Object newArray = Array.newInstance(componentType, index + 1);
/*  858 */       System.arraycopy(array, 0, newArray, 0, length);
/*  859 */       for (int i = length; i < Array.getLength(newArray); i++) {
/*  860 */         Array.set(newArray, i, newValue(componentType, name));
/*      */       }
/*      */ 
/*  863 */       setPropertyValue(name, newArray);
/*  864 */       return getPropertyValue(name);
/*      */     }
/*      */ 
/*  867 */     return array;
/*      */   }
/*      */ 
/*      */   private void growCollectionIfNecessary(Collection<Object> collection, int index, String name, PropertyDescriptor pd, int nestingLevel)
/*      */   {
/*  873 */     if (!this.autoGrowNestedPaths) {
/*  874 */       return;
/*      */     }
/*  876 */     int size = collection.size();
/*  877 */     if ((index >= size) && (index < this.autoGrowCollectionLimit)) {
/*  878 */       Class elementType = GenericCollectionTypeResolver.getCollectionReturnType(pd.getReadMethod(), nestingLevel);
/*  879 */       if (elementType != null)
/*  880 */         for (int i = collection.size(); i < index + 1; i++)
/*  881 */           collection.add(newValue(elementType, name));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setPropertyValue(String propertyName, Object value)
/*      */     throws BeansException
/*      */   {
/*      */     try
/*      */     {
/*  891 */       nestedBw = getBeanWrapperForPropertyPath(propertyName);
/*      */     }
/*      */     catch (NotReadablePropertyException ex)
/*      */     {
/*      */       BeanWrapperImpl nestedBw;
/*  894 */       throw new NotWritablePropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Nested property in path '").append(propertyName).append("' does not exist").toString(), ex);
/*      */     }
/*      */     BeanWrapperImpl nestedBw;
/*  897 */     PropertyTokenHolder tokens = getPropertyNameTokens(getFinalPath(nestedBw, propertyName));
/*  898 */     nestedBw.setPropertyValue(tokens, new PropertyValue(propertyName, value));
/*      */   }
/*      */ 
/*      */   public void setPropertyValue(PropertyValue pv) throws BeansException
/*      */   {
/*  903 */     PropertyTokenHolder tokens = (PropertyTokenHolder)pv.resolvedTokens;
/*  904 */     if (tokens == null) {
/*  905 */       String propertyName = pv.getName();
/*      */       try
/*      */       {
/*  908 */         nestedBw = getBeanWrapperForPropertyPath(propertyName);
/*      */       }
/*      */       catch (NotReadablePropertyException ex)
/*      */       {
/*      */         BeanWrapperImpl nestedBw;
/*  911 */         throw new NotWritablePropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Nested property in path '").append(propertyName).append("' does not exist").toString(), ex);
/*      */       }
/*      */       BeanWrapperImpl nestedBw;
/*  914 */       tokens = getPropertyNameTokens(getFinalPath(nestedBw, propertyName));
/*  915 */       if (nestedBw == this) {
/*  916 */         pv.getOriginalPropertyValue().resolvedTokens = tokens;
/*      */       }
/*  918 */       nestedBw.setPropertyValue(tokens, pv);
/*      */     }
/*      */     else {
/*  921 */       setPropertyValue(tokens, pv);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setPropertyValue(PropertyTokenHolder tokens, PropertyValue pv) throws BeansException
/*      */   {
/*  927 */     String propertyName = tokens.canonicalName;
/*  928 */     String actualName = tokens.actualName;
/*      */ 
/*  930 */     if (tokens.keys != null)
/*      */     {
/*  932 */       PropertyTokenHolder getterTokens = new PropertyTokenHolder(null);
/*  933 */       getterTokens.canonicalName = tokens.canonicalName;
/*  934 */       getterTokens.actualName = tokens.actualName;
/*  935 */       getterTokens.keys = new String[tokens.keys.length - 1];
/*  936 */       System.arraycopy(tokens.keys, 0, getterTokens.keys, 0, tokens.keys.length - 1);
/*      */       try
/*      */       {
/*  939 */         propValue = getPropertyValue(getterTokens);
/*      */       }
/*      */       catch (NotReadablePropertyException ex)
/*      */       {
/*      */         Object propValue;
/*  942 */         throw new NotWritablePropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Cannot access indexed value in property referenced in indexed property path '").append(propertyName).append("'").toString(), ex);
/*      */       }
/*      */       Object propValue;
/*  947 */       String key = tokens.keys[(tokens.keys.length - 1)];
/*  948 */       if (propValue == null)
/*      */       {
/*  950 */         if (this.autoGrowNestedPaths)
/*      */         {
/*  952 */           int lastKeyIndex = tokens.canonicalName.lastIndexOf(91);
/*  953 */           getterTokens.canonicalName = tokens.canonicalName.substring(0, lastKeyIndex);
/*  954 */           propValue = setDefaultValue(getterTokens);
/*      */         }
/*      */         else {
/*  957 */           throw new NullValueInNestedPathException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Cannot access indexed value in property referenced in indexed property path '").append(propertyName).append("': returned null").toString());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  962 */       if (propValue.getClass().isArray()) {
/*  963 */         PropertyDescriptor pd = getCachedIntrospectionResults().getPropertyDescriptor(actualName);
/*  964 */         Class requiredType = propValue.getClass().getComponentType();
/*  965 */         int arrayIndex = Integer.parseInt(key);
/*  966 */         Object oldValue = null;
/*      */         try {
/*  968 */           if ((isExtractOldValueForEditor()) && (arrayIndex < Array.getLength(propValue))) {
/*  969 */             oldValue = Array.get(propValue, arrayIndex);
/*      */           }
/*  971 */           Object convertedValue = convertIfNecessary(propertyName, oldValue, pv.getValue(), requiredType, 
/*  972 */             TypeDescriptor.nested(property(pd), 
/*  972 */             tokens.keys.length));
/*  973 */           Array.set(propValue, arrayIndex, convertedValue);
/*      */         }
/*      */         catch (IndexOutOfBoundsException ex) {
/*  976 */           throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Invalid array index in property path '").append(propertyName).append("'").toString(), ex);
/*      */         }
/*      */ 
/*      */       }
/*  980 */       else if ((propValue instanceof List)) {
/*  981 */         PropertyDescriptor pd = getCachedIntrospectionResults().getPropertyDescriptor(actualName);
/*  982 */         Class requiredType = GenericCollectionTypeResolver.getCollectionReturnType(pd
/*  983 */           .getReadMethod(), tokens.keys.length);
/*  984 */         List list = (List)propValue;
/*  985 */         int index = Integer.parseInt(key);
/*  986 */         Object oldValue = null;
/*  987 */         if ((isExtractOldValueForEditor()) && (index < list.size())) {
/*  988 */           oldValue = list.get(index);
/*      */         }
/*  990 */         Object convertedValue = convertIfNecessary(propertyName, oldValue, pv.getValue(), requiredType, 
/*  991 */           TypeDescriptor.nested(property(pd), 
/*  991 */           tokens.keys.length));
/*  992 */         int size = list.size();
/*  993 */         if ((index >= size) && (index < this.autoGrowCollectionLimit)) {
/*  994 */           for (int i = size; i < index; i++) {
/*      */             try {
/*  996 */               list.add(null);
/*      */             }
/*      */             catch (NullPointerException ex) {
/*  999 */               throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Cannot set element with index ").append(index).append(" in List of size ").append(size).append(", accessed using property path '").append(propertyName).append("': List does not support filling up gaps with null elements").toString());
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 1005 */           list.add(convertedValue);
/*      */         }
/*      */         else {
/*      */           try {
/* 1009 */             list.set(index, convertedValue);
/*      */           }
/*      */           catch (IndexOutOfBoundsException ex) {
/* 1012 */             throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Invalid list index in property path '").append(propertyName).append("'").toString(), ex);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/* 1017 */       else if ((propValue instanceof Map)) {
/* 1018 */         PropertyDescriptor pd = getCachedIntrospectionResults().getPropertyDescriptor(actualName);
/* 1019 */         Class mapKeyType = GenericCollectionTypeResolver.getMapKeyReturnType(pd
/* 1020 */           .getReadMethod(), tokens.keys.length);
/* 1021 */         Class mapValueType = GenericCollectionTypeResolver.getMapValueReturnType(pd
/* 1022 */           .getReadMethod(), tokens.keys.length);
/* 1023 */         Map map = (Map)propValue;
/*      */ 
/* 1027 */         TypeDescriptor typeDescriptor = mapKeyType != null ? 
/* 1027 */           TypeDescriptor.valueOf(mapKeyType) : 
/* 1027 */           TypeDescriptor.valueOf(Object.class);
/* 1028 */         Object convertedMapKey = convertIfNecessary(null, null, key, mapKeyType, typeDescriptor);
/* 1029 */         Object oldValue = null;
/* 1030 */         if (isExtractOldValueForEditor()) {
/* 1031 */           oldValue = map.get(convertedMapKey);
/*      */         }
/*      */ 
/* 1035 */         Object convertedMapValue = convertIfNecessary(propertyName, oldValue, pv.getValue(), mapValueType, 
/* 1036 */           TypeDescriptor.nested(property(pd), 
/* 1036 */           tokens.keys.length));
/* 1037 */         map.put(convertedMapKey, convertedMapValue);
/*      */       }
/*      */       else
/*      */       {
/* 1042 */         throw new InvalidPropertyException(getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), new StringBuilder().append("Property referenced in indexed property path '").append(propertyName).append("' is neither an array nor a List nor a Map; returned value was [")
/* 1042 */           .append(pv
/* 1042 */           .getValue()).append("]").toString());
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1047 */       PropertyDescriptor pd = pv.resolvedDescriptor;
/* 1048 */       if ((pd == null) || (!pd.getWriteMethod().getDeclaringClass().isInstance(this.object))) {
/* 1049 */         pd = getCachedIntrospectionResults().getPropertyDescriptor(actualName);
/* 1050 */         if ((pd == null) || (pd.getWriteMethod() == null)) {
/* 1051 */           if (pv.isOptional()) {
/* 1052 */             logger.debug(new StringBuilder().append("Ignoring optional value for property '").append(actualName).append("' - property not found on bean class [")
/* 1053 */               .append(getRootClass().getName()).append("]").toString());
/* 1054 */             return;
/*      */           }
/*      */ 
/* 1057 */           PropertyMatches matches = PropertyMatches.forProperty(propertyName, getRootClass());
/*      */ 
/* 1060 */           throw new NotWritablePropertyException(
/* 1059 */             getRootClass(), new StringBuilder().append(this.nestedPath).append(propertyName).toString(), matches
/* 1060 */             .buildErrorMessage(), matches.getPossibleMatches());
/*      */         }
/*      */ 
/* 1063 */         pv.getOriginalPropertyValue().resolvedDescriptor = pd;
/*      */       }
/*      */ 
/* 1066 */       Object oldValue = null;
/*      */       try {
/* 1068 */         Object originalValue = pv.getValue();
/* 1069 */         Object valueToApply = originalValue;
/* 1070 */         if (!Boolean.FALSE.equals(pv.conversionNecessary)) {
/* 1071 */           if (pv.isConverted()) {
/* 1072 */             valueToApply = pv.getConvertedValue();
/*      */           }
/*      */           else {
/* 1075 */             if ((isExtractOldValueForEditor()) && (pd.getReadMethod() != null)) {
/* 1076 */               final Method readMethod = pd.getReadMethod();
/* 1077 */               if ((!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) && 
/* 1078 */                 (!readMethod
/* 1078 */                 .isAccessible())) {
/* 1079 */                 if (System.getSecurityManager() != null) {
/* 1080 */                   AccessController.doPrivileged(new PrivilegedAction()
/*      */                   {
/*      */                     public Object run() {
/* 1083 */                       readMethod.setAccessible(true);
/* 1084 */                       return null;
/*      */                     }
/*      */                   });
/*      */                 }
/*      */                 else
/* 1089 */                   readMethod.setAccessible(true);
/*      */               }
/*      */               try
/*      */               {
/* 1093 */                 if (System.getSecurityManager() != null) {
/* 1094 */                   oldValue = AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */                   {
/*      */                     public Object run() throws Exception {
/* 1097 */                       return readMethod.invoke(BeanWrapperImpl.this.object, new Object[0]);
/*      */                     }
/*      */                   }
/*      */                   , this.acc);
/*      */                 }
/*      */                 else
/*      */                 {
/* 1102 */                   oldValue = readMethod.invoke(this.object, new Object[0]);
/*      */                 }
/*      */               }
/*      */               catch (Exception ex) {
/* 1106 */                 if ((ex instanceof PrivilegedActionException)) {
/* 1107 */                   ex = ((PrivilegedActionException)ex).getException();
/*      */                 }
/* 1109 */                 if (logger.isDebugEnabled()) {
/* 1110 */                   logger.debug(new StringBuilder().append("Could not read previous value of property '").append(this.nestedPath).append(propertyName).append("'").toString(), ex);
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/* 1115 */             valueToApply = convertForProperty(propertyName, oldValue, originalValue, pd, new TypeDescriptor(property(pd)));
/*      */           }
/* 1117 */           pv.getOriginalPropertyValue().conversionNecessary = Boolean.valueOf(valueToApply != originalValue);
/*      */         }
/*      */ 
/* 1121 */         final Method writeMethod = (pd instanceof GenericTypeAwarePropertyDescriptor) ? ((GenericTypeAwarePropertyDescriptor)pd)
/* 1120 */           .getWriteMethodForActualAccess() : pd
/* 1121 */           .getWriteMethod();
/* 1122 */         if ((!Modifier.isPublic(writeMethod.getDeclaringClass().getModifiers())) && (!writeMethod.isAccessible())) {
/* 1123 */           if (System.getSecurityManager() != null) {
/* 1124 */             AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               public Object run() {
/* 1127 */                 writeMethod.setAccessible(true);
/* 1128 */                 return null;
/*      */               }
/*      */             });
/*      */           }
/*      */           else {
/* 1133 */             writeMethod.setAccessible(true);
/*      */           }
/*      */         }
/* 1136 */         final Object value = valueToApply;
/* 1137 */         if (System.getSecurityManager() != null) {
/*      */           try {
/* 1139 */             AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */             {
/*      */               public Object run() throws Exception {
/* 1142 */                 writeMethod.invoke(BeanWrapperImpl.this.object, new Object[] { value });
/* 1143 */                 return null;
/*      */               }
/*      */             }
/*      */             , this.acc);
/*      */           }
/*      */           catch (PrivilegedActionException ex)
/*      */           {
/* 1148 */             throw ex.getException();
/*      */           }
/*      */         }
/*      */         else
/* 1152 */           writeMethod.invoke(this.object, new Object[] { value });
/*      */       }
/*      */       catch (TypeMismatchException ex)
/*      */       {
/* 1156 */         throw ex;
/*      */       }
/*      */       catch (InvocationTargetException ex)
/*      */       {
/* 1160 */         PropertyChangeEvent propertyChangeEvent = new PropertyChangeEvent(this.rootObject, new StringBuilder().append(this.nestedPath).append(propertyName).toString(), oldValue, pv
/* 1160 */           .getValue());
/* 1161 */         if ((ex.getTargetException() instanceof ClassCastException)) {
/* 1162 */           throw new TypeMismatchException(propertyChangeEvent, pd.getPropertyType(), ex.getTargetException());
/*      */         }
/*      */ 
/* 1165 */         throw new MethodInvocationException(propertyChangeEvent, ex.getTargetException());
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/* 1170 */         PropertyChangeEvent pce = new PropertyChangeEvent(this.rootObject, new StringBuilder().append(this.nestedPath).append(propertyName).toString(), oldValue, pv
/* 1170 */           .getValue());
/* 1171 */         throw new MethodInvocationException(pce, ex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1179 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 1180 */     if (this.object != null) {
/* 1181 */       sb.append(": wrapping object [").append(ObjectUtils.identityToString(this.object)).append("]");
/*      */     }
/*      */     else {
/* 1184 */       sb.append(": no wrapped object set");
/*      */     }
/* 1186 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private static class PropertyTokenHolder
/*      */   {
/*      */     public String canonicalName;
/*      */     public String actualName;
/*      */     public String[] keys;
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.BeanWrapperImpl
 * JD-Core Version:    0.6.2
 */