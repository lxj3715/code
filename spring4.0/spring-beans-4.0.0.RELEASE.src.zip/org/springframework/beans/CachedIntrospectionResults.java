/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.BeanDescriptor;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CachedIntrospectionResults
/*     */ {
/*  64 */   private static final Log logger = LogFactory.getLog(CachedIntrospectionResults.class);
/*     */ 
/*  68 */   private static List<BeanInfoFactory> beanInfoFactories = SpringFactoriesLoader.loadFactories(BeanInfoFactory.class, CachedIntrospectionResults.class
/*  68 */     .getClassLoader());
/*     */ 
/*  74 */   static final Set<ClassLoader> acceptedClassLoaders = new HashSet();
/*     */ 
/*  81 */   static final Map<Class<?>, Object> classCache = new WeakHashMap();
/*     */   private final BeanInfo beanInfo;
/*     */   private final Map<String, PropertyDescriptor> propertyDescriptorCache;
/*     */   private final Map<PropertyDescriptor, TypeDescriptor> typeDescriptorCache;
/*     */ 
/*     */   public static void acceptClassLoader(ClassLoader classLoader)
/*     */   {
/*  97 */     if (classLoader != null)
/*  98 */       synchronized (acceptedClassLoaders) {
/*  99 */         acceptedClassLoaders.add(classLoader);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void clearClassLoader(ClassLoader classLoader)
/*     */   {
/*     */     Iterator it;
/* 111 */     synchronized (classCache) {
/* 112 */       for (it = classCache.keySet().iterator(); it.hasNext(); ) {
/* 113 */         Class beanClass = (Class)it.next();
/* 114 */         if (isUnderneathClassLoader(beanClass.getClassLoader(), classLoader))
/* 115 */           it.remove();
/*     */       }
/*     */     }
/*     */     Iterator it;
/* 119 */     synchronized (acceptedClassLoaders) {
/* 120 */       for (it = acceptedClassLoaders.iterator(); it.hasNext(); ) {
/* 121 */         ClassLoader registeredLoader = (ClassLoader)it.next();
/* 122 */         if (isUnderneathClassLoader(registeredLoader, classLoader))
/* 123 */           it.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static CachedIntrospectionResults forClass(Class<?> beanClass)
/*     */     throws BeansException
/*     */   {
/*     */     Object value;
/* 139 */     synchronized (classCache) {
/* 140 */       value = classCache.get(beanClass);
/*     */     }
/*     */     CachedIntrospectionResults results;
/*     */     CachedIntrospectionResults results;
/* 142 */     if ((value instanceof Reference)) {
/* 143 */       Reference ref = (Reference)value;
/* 144 */       results = (CachedIntrospectionResults)ref.get();
/*     */     }
/*     */     else {
/* 147 */       results = (CachedIntrospectionResults)value;
/*     */     }
/* 149 */     if (results == null) {
/* 150 */       if ((ClassUtils.isCacheSafe(beanClass, CachedIntrospectionResults.class.getClassLoader())) || 
/* 151 */         (isClassLoaderAccepted(beanClass
/* 151 */         .getClassLoader()))) {
/* 152 */         results = new CachedIntrospectionResults(beanClass);
/* 153 */         synchronized (classCache) {
/* 154 */           classCache.put(beanClass, results);
/*     */         }
/*     */       }
/*     */       else {
/* 158 */         if (logger.isDebugEnabled()) {
/* 159 */           logger.debug(new StringBuilder().append("Not strongly caching class [").append(beanClass.getName()).append("] because it is not cache-safe").toString());
/*     */         }
/* 161 */         results = new CachedIntrospectionResults(beanClass);
/* 162 */         synchronized (classCache) {
/* 163 */           classCache.put(beanClass, new WeakReference(results));
/*     */         }
/*     */       }
/*     */     }
/* 167 */     return results;
/*     */   }
/*     */ 
/*     */   private static boolean isClassLoaderAccepted(ClassLoader classLoader)
/*     */   {
/*     */     ClassLoader[] acceptedLoaderArray;
/* 181 */     synchronized (acceptedClassLoaders) {
/* 182 */       acceptedLoaderArray = (ClassLoader[])acceptedClassLoaders.toArray(new ClassLoader[acceptedClassLoaders.size()]);
/*     */     }
/* 184 */     for (ClassLoader registeredLoader : acceptedLoaderArray) {
/* 185 */       if (isUnderneathClassLoader(classLoader, registeredLoader)) {
/* 186 */         return true;
/*     */       }
/*     */     }
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */   private static boolean isUnderneathClassLoader(ClassLoader candidate, ClassLoader parent)
/*     */   {
/* 199 */     if (candidate == parent) {
/* 200 */       return true;
/*     */     }
/* 202 */     if (candidate == null) {
/* 203 */       return false;
/*     */     }
/* 205 */     ClassLoader classLoaderToCheck = candidate;
/* 206 */     while (classLoaderToCheck != null) {
/* 207 */       classLoaderToCheck = classLoaderToCheck.getParent();
/* 208 */       if (classLoaderToCheck == parent) {
/* 209 */         return true;
/*     */       }
/*     */     }
/* 212 */     return false;
/*     */   }
/*     */ 
/*     */   private CachedIntrospectionResults(Class<?> beanClass)
/*     */     throws BeansException
/*     */   {
/*     */     try
/*     */     {
/* 233 */       if (logger.isTraceEnabled()) {
/* 234 */         logger.trace(new StringBuilder().append("Getting BeanInfo for class [").append(beanClass.getName()).append("]").toString());
/*     */       }
/*     */ 
/* 237 */       BeanInfo beanInfo = null;
/* 238 */       for (BeanInfoFactory beanInfoFactory : beanInfoFactories) {
/* 239 */         beanInfo = beanInfoFactory.getBeanInfo(beanClass);
/* 240 */         if (beanInfo != null) {
/*     */           break;
/*     */         }
/*     */       }
/* 244 */       if (beanInfo == null)
/*     */       {
/* 246 */         beanInfo = Introspector.getBeanInfo(beanClass);
/*     */       }
/* 248 */       this.beanInfo = beanInfo;
/*     */ 
/* 254 */       Class classToFlush = beanClass;
/*     */       do {
/* 256 */         Introspector.flushFromCaches(classToFlush);
/* 257 */         classToFlush = classToFlush.getSuperclass();
/*     */       }
/* 259 */       while (classToFlush != null);
/*     */ 
/* 261 */       if (logger.isTraceEnabled()) {
/* 262 */         logger.trace(new StringBuilder().append("Caching PropertyDescriptors for class [").append(beanClass.getName()).append("]").toString());
/*     */       }
/* 264 */       this.propertyDescriptorCache = new LinkedHashMap();
/*     */ 
/* 267 */       PropertyDescriptor[] pds = this.beanInfo.getPropertyDescriptors();
/* 268 */       for (PropertyDescriptor pd : pds) {
/* 269 */         if ((!Class.class.equals(beanClass)) || (
/* 270 */           (!"classLoader"
/* 270 */           .equals(pd
/* 270 */           .getName())) && (!"protectionDomain".equals(pd.getName()))))
/*     */         {
/* 274 */           if (logger.isTraceEnabled()) {
/* 275 */             logger.trace(new StringBuilder().append("Found bean property '").append(pd.getName()).append("'")
/* 276 */               .append(pd
/* 276 */               .getPropertyType() != null ? new StringBuilder().append(" of type [").append(pd.getPropertyType().getName()).append("]").toString() : "")
/* 278 */               .append(pd
/* 277 */               .getPropertyEditorClass() != null ? new StringBuilder().append("; editor [")
/* 278 */               .append(pd
/* 278 */               .getPropertyEditorClass().getName()).append("]").toString() : "").toString());
/*     */           }
/* 280 */           pd = buildGenericTypeAwarePropertyDescriptor(beanClass, pd);
/* 281 */           this.propertyDescriptorCache.put(pd.getName(), pd);
/*     */         }
/*     */       }
/* 284 */       this.typeDescriptorCache = new HashMap();
/*     */     }
/*     */     catch (IntrospectionException ex) {
/* 287 */       throw new FatalBeanException(new StringBuilder().append("Failed to obtain BeanInfo for class [").append(beanClass.getName()).append("]").toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   BeanInfo getBeanInfo() {
/* 292 */     return this.beanInfo;
/*     */   }
/*     */ 
/*     */   Class<?> getBeanClass() {
/* 296 */     return this.beanInfo.getBeanDescriptor().getBeanClass();
/*     */   }
/*     */ 
/*     */   PropertyDescriptor getPropertyDescriptor(String name) {
/* 300 */     PropertyDescriptor pd = (PropertyDescriptor)this.propertyDescriptorCache.get(name);
/* 301 */     if ((pd == null) && (StringUtils.hasLength(name)))
/*     */     {
/* 303 */       pd = (PropertyDescriptor)this.propertyDescriptorCache.get(new StringBuilder().append(name.substring(0, 1).toLowerCase()).append(name.substring(1)).toString());
/* 304 */       if (pd == null) {
/* 305 */         pd = (PropertyDescriptor)this.propertyDescriptorCache.get(new StringBuilder().append(name.substring(0, 1).toUpperCase()).append(name.substring(1)).toString());
/*     */       }
/*     */     }
/*     */ 
/* 309 */     return (pd == null) || ((pd instanceof GenericTypeAwarePropertyDescriptor)) ? pd : 
/* 309 */       buildGenericTypeAwarePropertyDescriptor(getBeanClass(), pd);
/*     */   }
/*     */ 
/*     */   PropertyDescriptor[] getPropertyDescriptors() {
/* 313 */     PropertyDescriptor[] pds = new PropertyDescriptor[this.propertyDescriptorCache.size()];
/* 314 */     int i = 0;
/* 315 */     for (PropertyDescriptor pd : this.propertyDescriptorCache.values()) {
/* 316 */       pds[i] = ((pd instanceof GenericTypeAwarePropertyDescriptor) ? pd : 
/* 317 */         buildGenericTypeAwarePropertyDescriptor(getBeanClass(), pd));
/* 318 */       i++;
/*     */     }
/* 320 */     return pds;
/*     */   }
/*     */ 
/*     */   private PropertyDescriptor buildGenericTypeAwarePropertyDescriptor(Class<?> beanClass, PropertyDescriptor pd)
/*     */   {
/*     */     try {
/* 326 */       return new GenericTypeAwarePropertyDescriptor(beanClass, pd.getName(), pd.getReadMethod(), pd
/* 326 */         .getWriteMethod(), pd.getPropertyEditorClass());
/*     */     }
/*     */     catch (IntrospectionException ex) {
/* 329 */       throw new FatalBeanException(new StringBuilder().append("Failed to re-introspect class [").append(beanClass.getName()).append("]").toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   TypeDescriptor getTypeDescriptor(PropertyDescriptor pd) {
/* 334 */     return (TypeDescriptor)this.typeDescriptorCache.get(pd);
/*     */   }
/*     */ 
/*     */   void putTypeDescriptor(PropertyDescriptor pd, TypeDescriptor td) {
/* 338 */     this.typeDescriptorCache.put(pd, td);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.CachedIntrospectionResults
 * JD-Core Version:    0.6.2
 */