/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.beans.PropertyChangeEvent;
/*    */ 
/*    */ public class ConversionNotSupportedException extends TypeMismatchException
/*    */ {
/*    */   public ConversionNotSupportedException(PropertyChangeEvent propertyChangeEvent, Class<?> requiredType, Throwable cause)
/*    */   {
/* 39 */     super(propertyChangeEvent, requiredType, cause);
/*    */   }
/*    */ 
/*    */   public ConversionNotSupportedException(Object value, Class<?> requiredType, Throwable cause)
/*    */   {
/* 49 */     super(value, requiredType, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.ConversionNotSupportedException
 * JD-Core Version:    0.6.2
 */