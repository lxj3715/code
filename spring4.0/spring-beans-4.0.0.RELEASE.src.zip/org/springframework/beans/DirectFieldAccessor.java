/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.core.convert.ConverterNotFoundException;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.FieldCallback;
/*     */ 
/*     */ public class DirectFieldAccessor extends AbstractPropertyAccessor
/*     */ {
/*     */   private final Object target;
/*  51 */   private final Map<String, Field> fieldMap = new HashMap();
/*     */ 
/*     */   public DirectFieldAccessor(Object target)
/*     */   {
/*  59 */     Assert.notNull(target, "Target object must not be null");
/*  60 */     this.target = target;
/*  61 */     ReflectionUtils.doWithFields(this.target.getClass(), new ReflectionUtils.FieldCallback()
/*     */     {
/*     */       public void doWith(Field field) {
/*  64 */         if (!DirectFieldAccessor.this.fieldMap.containsKey(field.getName()))
/*     */         {
/*  68 */           DirectFieldAccessor.this.fieldMap.put(field.getName(), field);
/*     */         }
/*     */       }
/*     */     });
/*  72 */     this.typeConverterDelegate = new TypeConverterDelegate(this, target);
/*  73 */     registerDefaultEditors();
/*  74 */     setExtractOldValueForEditor(true);
/*     */   }
/*     */ 
/*     */   public boolean isReadableProperty(String propertyName)
/*     */     throws BeansException
/*     */   {
/*  80 */     return this.fieldMap.containsKey(propertyName);
/*     */   }
/*     */ 
/*     */   public boolean isWritableProperty(String propertyName) throws BeansException
/*     */   {
/*  85 */     return this.fieldMap.containsKey(propertyName);
/*     */   }
/*     */ 
/*     */   public Class<?> getPropertyType(String propertyName) throws BeansException
/*     */   {
/*  90 */     Field field = (Field)this.fieldMap.get(propertyName);
/*  91 */     if (field != null) {
/*  92 */       return field.getType();
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   public TypeDescriptor getPropertyTypeDescriptor(String propertyName) throws BeansException
/*     */   {
/*  99 */     Field field = (Field)this.fieldMap.get(propertyName);
/* 100 */     if (field != null) {
/* 101 */       return new TypeDescriptor(field);
/*     */     }
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getPropertyValue(String propertyName) throws BeansException
/*     */   {
/* 108 */     Field field = (Field)this.fieldMap.get(propertyName);
/* 109 */     if (field == null)
/*     */     {
/* 111 */       throw new NotReadablePropertyException(this.target
/* 111 */         .getClass(), propertyName, "Field '" + propertyName + "' does not exist");
/*     */     }
/*     */     try {
/* 114 */       ReflectionUtils.makeAccessible(field);
/* 115 */       return field.get(this.target);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 118 */       throw new InvalidPropertyException(this.target.getClass(), propertyName, "Field is not accessible", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setPropertyValue(String propertyName, Object newValue) throws BeansException
/*     */   {
/* 124 */     Field field = (Field)this.fieldMap.get(propertyName);
/* 125 */     if (field == null)
/*     */     {
/* 127 */       throw new NotWritablePropertyException(this.target
/* 127 */         .getClass(), propertyName, "Field '" + propertyName + "' does not exist");
/*     */     }
/* 129 */     Object oldValue = null;
/*     */     try {
/* 131 */       ReflectionUtils.makeAccessible(field);
/* 132 */       oldValue = field.get(this.target);
/* 133 */       Object convertedValue = this.typeConverterDelegate.convertIfNecessary(field
/* 134 */         .getName(), oldValue, newValue, field.getType(), new TypeDescriptor(field));
/* 135 */       field.set(this.target, convertedValue);
/*     */     }
/*     */     catch (ConverterNotFoundException ex) {
/* 138 */       PropertyChangeEvent pce = new PropertyChangeEvent(this.target, propertyName, oldValue, newValue);
/* 139 */       throw new ConversionNotSupportedException(pce, field.getType(), ex);
/*     */     }
/*     */     catch (ConversionException ex) {
/* 142 */       PropertyChangeEvent pce = new PropertyChangeEvent(this.target, propertyName, oldValue, newValue);
/* 143 */       throw new TypeMismatchException(pce, field.getType(), ex);
/*     */     }
/*     */     catch (IllegalStateException ex) {
/* 146 */       PropertyChangeEvent pce = new PropertyChangeEvent(this.target, propertyName, oldValue, newValue);
/* 147 */       throw new ConversionNotSupportedException(pce, field.getType(), ex);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 150 */       PropertyChangeEvent pce = new PropertyChangeEvent(this.target, propertyName, oldValue, newValue);
/* 151 */       throw new TypeMismatchException(pce, field.getType(), ex);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 154 */       throw new InvalidPropertyException(this.target.getClass(), propertyName, "Field is not accessible", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.DirectFieldAccessor
 * JD-Core Version:    0.6.2
 */