/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.beans.BeanDescriptor;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.EventSetDescriptor;
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.MethodDescriptor;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ class ExtendedBeanInfo
/*     */   implements BeanInfo
/*     */ {
/*     */   private final BeanInfo delegate;
/*  78 */   private final Set<PropertyDescriptor> propertyDescriptors = new TreeSet(new PropertyDescriptorComparator());
/*     */ 
/*     */   public ExtendedBeanInfo(BeanInfo delegate)
/*     */     throws IntrospectionException
/*     */   {
/*  95 */     this.delegate = delegate;
/*  96 */     for (PropertyDescriptor pd : delegate.getPropertyDescriptors()) {
/*  97 */       this.propertyDescriptors.add((pd instanceof IndexedPropertyDescriptor) ? new SimpleIndexedPropertyDescriptor((IndexedPropertyDescriptor)pd) : new SimplePropertyDescriptor(pd));
/*     */     }
/*     */ 
/* 101 */     MethodDescriptor[] methodDescriptors = delegate.getMethodDescriptors();
/* 102 */     if (methodDescriptors != null)
/* 103 */       for (Method method : findCandidateWriteMethods(methodDescriptors))
/* 104 */         handleCandidateWriteMethod(method);
/*     */   }
/*     */ 
/*     */   private List<Method> findCandidateWriteMethods(MethodDescriptor[] methodDescriptors)
/*     */   {
/* 111 */     List matches = new ArrayList();
/* 112 */     for (MethodDescriptor methodDescriptor : methodDescriptors) {
/* 113 */       Method method = methodDescriptor.getMethod();
/* 114 */       if (isCandidateWriteMethod(method)) {
/* 115 */         matches.add(method);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 121 */     Collections.sort(matches, new Comparator()
/*     */     {
/*     */       public int compare(Method m1, Method m2) {
/* 124 */         return m2.toString().compareTo(m1.toString());
/*     */       }
/*     */     });
/* 127 */     return matches;
/*     */   }
/*     */ 
/*     */   public static boolean isCandidateWriteMethod(Method method) {
/* 131 */     String methodName = method.getName();
/* 132 */     Class[] parameterTypes = method.getParameterTypes();
/* 133 */     int nParams = parameterTypes.length;
/*     */ 
/* 136 */     return (methodName.length() > 3) && (methodName.startsWith("set")) && (Modifier.isPublic(method.getModifiers())) && 
/* 135 */       ((!Void.TYPE
/* 135 */       .isAssignableFrom(method
/* 135 */       .getReturnType())) || (Modifier.isStatic(method.getModifiers()))) && (
/* 135 */       (nParams == 1) || ((nParams == 2) && 
/* 136 */       (parameterTypes[0]
/* 136 */       .equals(Integer.TYPE))));
/*     */   }
/*     */ 
/*     */   private void handleCandidateWriteMethod(Method method) throws IntrospectionException
/*     */   {
/* 140 */     int nParams = method.getParameterTypes().length;
/* 141 */     String propertyName = propertyNameFor(method);
/* 142 */     Class propertyType = method.getParameterTypes()[(nParams - 1)];
/* 143 */     PropertyDescriptor existingPd = findExistingPropertyDescriptor(propertyName, propertyType);
/* 144 */     if (nParams == 1) {
/* 145 */       if (existingPd == null) {
/* 146 */         this.propertyDescriptors.add(new SimplePropertyDescriptor(propertyName, null, method));
/*     */       }
/*     */       else {
/* 149 */         existingPd.setWriteMethod(method);
/*     */       }
/*     */     }
/* 152 */     else if (nParams == 2) {
/* 153 */       if (existingPd == null) {
/* 154 */         this.propertyDescriptors.add(new SimpleIndexedPropertyDescriptor(propertyName, null, null, null, method));
/*     */       }
/* 157 */       else if ((existingPd instanceof IndexedPropertyDescriptor)) {
/* 158 */         ((IndexedPropertyDescriptor)existingPd).setIndexedWriteMethod(method);
/*     */       }
/*     */       else {
/* 161 */         this.propertyDescriptors.remove(existingPd);
/* 162 */         this.propertyDescriptors.add(new SimpleIndexedPropertyDescriptor(propertyName, existingPd
/* 163 */           .getReadMethod(), existingPd.getWriteMethod(), null, method));
/*     */       }
/*     */     }
/*     */     else
/* 167 */       throw new IllegalArgumentException("Write method must have exactly 1 or 2 parameters: " + method);
/*     */   }
/*     */ 
/*     */   private PropertyDescriptor findExistingPropertyDescriptor(String propertyName, Class<?> propertyType)
/*     */   {
/* 172 */     for (PropertyDescriptor pd : this.propertyDescriptors)
/*     */     {
/* 174 */       String candidateName = pd.getName();
/* 175 */       if ((pd instanceof IndexedPropertyDescriptor)) {
/* 176 */         IndexedPropertyDescriptor ipd = (IndexedPropertyDescriptor)pd;
/* 177 */         Class candidateType = ipd.getIndexedPropertyType();
/* 178 */         if ((candidateName.equals(propertyName)) && (
/* 179 */           (candidateType
/* 179 */           .equals(propertyType)) || 
/* 179 */           (candidateType.equals(propertyType.getComponentType()))))
/* 180 */           return pd;
/*     */       }
/*     */       else
/*     */       {
/* 184 */         Class candidateType = pd.getPropertyType();
/* 185 */         if ((candidateName.equals(propertyName)) && (
/* 186 */           (candidateType
/* 186 */           .equals(propertyType)) || 
/* 186 */           (propertyType.equals(candidateType.getComponentType())))) {
/* 187 */           return pd;
/*     */         }
/*     */       }
/*     */     }
/* 191 */     return null;
/*     */   }
/*     */ 
/*     */   private String propertyNameFor(Method method) {
/* 195 */     return Introspector.decapitalize(method.getName().substring(3, method.getName().length()));
/*     */   }
/*     */ 
/*     */   public PropertyDescriptor[] getPropertyDescriptors()
/*     */   {
/* 207 */     return (PropertyDescriptor[])this.propertyDescriptors.toArray(new PropertyDescriptor[this.propertyDescriptors.size()]);
/*     */   }
/*     */ 
/*     */   public BeanInfo[] getAdditionalBeanInfo()
/*     */   {
/* 212 */     return this.delegate.getAdditionalBeanInfo();
/*     */   }
/*     */ 
/*     */   public BeanDescriptor getBeanDescriptor()
/*     */   {
/* 217 */     return this.delegate.getBeanDescriptor();
/*     */   }
/*     */ 
/*     */   public int getDefaultEventIndex()
/*     */   {
/* 222 */     return this.delegate.getDefaultEventIndex();
/*     */   }
/*     */ 
/*     */   public int getDefaultPropertyIndex()
/*     */   {
/* 227 */     return this.delegate.getDefaultPropertyIndex();
/*     */   }
/*     */ 
/*     */   public EventSetDescriptor[] getEventSetDescriptors()
/*     */   {
/* 232 */     return this.delegate.getEventSetDescriptors();
/*     */   }
/*     */ 
/*     */   public Image getIcon(int iconKind)
/*     */   {
/* 237 */     return this.delegate.getIcon(iconKind);
/*     */   }
/*     */ 
/*     */   public MethodDescriptor[] getMethodDescriptors()
/*     */   {
/* 242 */     return this.delegate.getMethodDescriptors();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.ExtendedBeanInfo
 * JD-Core Version:    0.6.2
 */