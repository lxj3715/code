/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.beans.BeanInfo;
/*    */ import java.beans.IntrospectionException;
/*    */ import java.beans.Introspector;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ public class ExtendedBeanInfoFactory
/*    */   implements Ordered, BeanInfoFactory
/*    */ {
/*    */   public BeanInfo getBeanInfo(Class<?> beanClass)
/*    */     throws IntrospectionException
/*    */   {
/* 46 */     return supports(beanClass) ? new ExtendedBeanInfo(
/* 46 */       Introspector.getBeanInfo(beanClass)) : 
/* 46 */       null;
/*    */   }
/*    */ 
/*    */   private boolean supports(Class<?> beanClass)
/*    */   {
/* 54 */     for (Method method : beanClass.getMethods()) {
/* 55 */       if (ExtendedBeanInfo.isCandidateWriteMethod(method)) {
/* 56 */         return true;
/*    */       }
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 64 */     return 2147483647;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.ExtendedBeanInfoFactory
 * JD-Core Version:    0.6.2
 */