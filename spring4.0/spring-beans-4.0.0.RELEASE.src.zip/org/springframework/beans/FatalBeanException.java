/*    */ package org.springframework.beans;
/*    */ 
/*    */ public class FatalBeanException extends BeansException
/*    */ {
/*    */   public FatalBeanException(String msg)
/*    */   {
/* 33 */     super(msg);
/*    */   }
/*    */ 
/*    */   public FatalBeanException(String msg, Throwable cause)
/*    */   {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.FatalBeanException
 * JD-Core Version:    0.6.2
 */