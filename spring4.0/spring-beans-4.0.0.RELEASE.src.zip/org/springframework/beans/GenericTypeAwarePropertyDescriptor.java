/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class GenericTypeAwarePropertyDescriptor extends PropertyDescriptor
/*     */ {
/*     */   private final Class<?> beanClass;
/*     */   private final Method readMethod;
/*     */   private final Method writeMethod;
/*     */   private final Class<?> propertyEditorClass;
/*     */   private volatile Set<Method> ambiguousWriteMethods;
/*     */   private Class<?> propertyType;
/*     */   private MethodParameter writeMethodParameter;
/*     */ 
/*     */   public GenericTypeAwarePropertyDescriptor(Class<?> beanClass, String propertyName, Method readMethod, Method writeMethod, Class<?> propertyEditorClass)
/*     */     throws IntrospectionException
/*     */   {
/*  62 */     super(propertyName, null, null);
/*  63 */     this.beanClass = beanClass;
/*  64 */     this.propertyEditorClass = propertyEditorClass;
/*     */ 
/*  66 */     Method readMethodToUse = BridgeMethodResolver.findBridgedMethod(readMethod);
/*  67 */     Method writeMethodToUse = BridgeMethodResolver.findBridgedMethod(writeMethod);
/*  68 */     if ((writeMethodToUse == null) && (readMethodToUse != null))
/*     */     {
/*  72 */       Method candidate = ClassUtils.getMethodIfAvailable(this.beanClass, "set" + 
/*  73 */         StringUtils.capitalize(getName()), (Class[])null);
/*  74 */       if ((candidate != null) && (candidate.getParameterTypes().length == 1)) {
/*  75 */         writeMethodToUse = candidate;
/*     */       }
/*     */     }
/*  78 */     this.readMethod = readMethodToUse;
/*  79 */     this.writeMethod = writeMethodToUse;
/*     */ 
/*  81 */     if ((this.writeMethod != null) && (this.readMethod == null))
/*     */     {
/*  85 */       Set ambiguousCandidates = new HashSet();
/*  86 */       for (Method method : beanClass.getMethods()) {
/*  87 */         if ((method.getName().equals(writeMethodToUse.getName())) && 
/*  88 */           (!method
/*  88 */           .equals(writeMethodToUse)) && 
/*  88 */           (!method.isBridge())) {
/*  89 */           ambiguousCandidates.add(method);
/*     */         }
/*     */       }
/*  92 */       if (!ambiguousCandidates.isEmpty())
/*  93 */         this.ambiguousWriteMethods = ambiguousCandidates;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanClass()
/*     */   {
/*  99 */     return this.beanClass;
/*     */   }
/*     */ 
/*     */   public Method getReadMethod()
/*     */   {
/* 104 */     return this.readMethod;
/*     */   }
/*     */ 
/*     */   public Method getWriteMethod()
/*     */   {
/* 109 */     return this.writeMethod;
/*     */   }
/*     */ 
/*     */   public Method getWriteMethodForActualAccess() {
/* 113 */     Set ambiguousCandidates = this.ambiguousWriteMethods;
/* 114 */     if (ambiguousCandidates != null) {
/* 115 */       this.ambiguousWriteMethods = null;
/* 116 */       LogFactory.getLog(GenericTypeAwarePropertyDescriptor.class).warn("Invalid JavaBean property '" + 
/* 117 */         getName() + "' being accessed! Ambiguous write methods found next to actually used [" + this.writeMethod + "]: " + ambiguousCandidates);
/*     */     }
/*     */ 
/* 120 */     return this.writeMethod;
/*     */   }
/*     */ 
/*     */   public Class<?> getPropertyEditorClass()
/*     */   {
/* 125 */     return this.propertyEditorClass;
/*     */   }
/*     */ 
/*     */   public synchronized Class<?> getPropertyType()
/*     */   {
/* 130 */     if (this.propertyType == null) {
/* 131 */       if (this.readMethod != null) {
/* 132 */         this.propertyType = GenericTypeResolver.resolveReturnType(this.readMethod, this.beanClass);
/*     */       }
/*     */       else {
/* 135 */         MethodParameter writeMethodParam = getWriteMethodParameter();
/* 136 */         if (writeMethodParam != null) {
/* 137 */           this.propertyType = writeMethodParam.getParameterType();
/*     */         }
/*     */         else {
/* 140 */           this.propertyType = super.getPropertyType();
/*     */         }
/*     */       }
/*     */     }
/* 144 */     return this.propertyType;
/*     */   }
/*     */ 
/*     */   public synchronized MethodParameter getWriteMethodParameter() {
/* 148 */     if (this.writeMethod == null) {
/* 149 */       return null;
/*     */     }
/* 151 */     if (this.writeMethodParameter == null) {
/* 152 */       this.writeMethodParameter = new MethodParameter(this.writeMethod, 0);
/* 153 */       GenericTypeResolver.resolveParameterType(this.writeMethodParameter, this.beanClass);
/*     */     }
/* 155 */     return this.writeMethodParameter;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.GenericTypeAwarePropertyDescriptor
 * JD-Core Version:    0.6.2
 */