/*    */ package org.springframework.beans;
/*    */ 
/*    */ public class NotReadablePropertyException extends InvalidPropertyException
/*    */ {
/*    */   public NotReadablePropertyException(Class<?> beanClass, String propertyName)
/*    */   {
/* 35 */     super(beanClass, propertyName, "Bean property '" + propertyName + "' is not readable or has an invalid getter method: " + "Does the return type of the getter match the parameter type of the setter?");
/*    */   }
/*    */ 
/*    */   public NotReadablePropertyException(Class<?> beanClass, String propertyName, String msg)
/*    */   {
/* 47 */     super(beanClass, propertyName, msg);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.NotReadablePropertyException
 * JD-Core Version:    0.6.2
 */