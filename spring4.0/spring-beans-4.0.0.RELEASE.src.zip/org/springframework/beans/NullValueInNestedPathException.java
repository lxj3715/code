/*    */ package org.springframework.beans;
/*    */ 
/*    */ public class NullValueInNestedPathException extends InvalidPropertyException
/*    */ {
/*    */   public NullValueInNestedPathException(Class<?> beanClass, String propertyName)
/*    */   {
/* 37 */     super(beanClass, propertyName, "Value of nested property '" + propertyName + "' is null");
/*    */   }
/*    */ 
/*    */   public NullValueInNestedPathException(Class<?> beanClass, String propertyName, String msg)
/*    */   {
/* 47 */     super(beanClass, propertyName, msg);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.NullValueInNestedPathException
 * JD-Core Version:    0.6.2
 */