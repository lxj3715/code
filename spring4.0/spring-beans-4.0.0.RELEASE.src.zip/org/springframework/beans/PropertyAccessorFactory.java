/*    */ package org.springframework.beans;
/*    */ 
/*    */ public abstract class PropertyAccessorFactory
/*    */ {
/*    */   public static BeanWrapper forBeanPropertyAccess(Object target)
/*    */   {
/* 37 */     return new BeanWrapperImpl(target);
/*    */   }
/*    */ 
/*    */   public static ConfigurablePropertyAccessor forDirectFieldAccess(Object target)
/*    */   {
/* 48 */     return new DirectFieldAccessor(target);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.PropertyAccessorFactory
 * JD-Core Version:    0.6.2
 */