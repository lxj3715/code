/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ class PropertyDescriptorComparator
/*     */   implements Comparator<PropertyDescriptor>
/*     */ {
/*     */   public int compare(PropertyDescriptor desc1, PropertyDescriptor desc2)
/*     */   {
/* 645 */     String left = desc1.getName();
/* 646 */     String right = desc2.getName();
/* 647 */     for (int i = 0; i < left.length(); i++) {
/* 648 */       if (right.length() == i) {
/* 649 */         return 1;
/*     */       }
/* 651 */       int result = left.getBytes()[i] - right.getBytes()[i];
/* 652 */       if (result != 0) {
/* 653 */         return result;
/*     */       }
/*     */     }
/* 656 */     return left.length() - right.length();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.PropertyDescriptorComparator
 * JD-Core Version:    0.6.2
 */