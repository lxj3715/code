/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ class PropertyDescriptorUtils
/*     */ {
/*     */   public static void copyNonMethodProperties(PropertyDescriptor source, PropertyDescriptor target)
/*     */     throws IntrospectionException
/*     */   {
/* 478 */     target.setExpert(source.isExpert());
/* 479 */     target.setHidden(source.isHidden());
/* 480 */     target.setPreferred(source.isPreferred());
/* 481 */     target.setName(source.getName());
/* 482 */     target.setShortDescription(source.getShortDescription());
/* 483 */     target.setDisplayName(source.getDisplayName());
/*     */ 
/* 486 */     Enumeration keys = source.attributeNames();
/* 487 */     while (keys.hasMoreElements()) {
/* 488 */       String key = (String)keys.nextElement();
/* 489 */       target.setValue(key, source.getValue(key));
/*     */     }
/*     */ 
/* 493 */     target.setPropertyEditorClass(source.getPropertyEditorClass());
/* 494 */     target.setBound(source.isBound());
/* 495 */     target.setConstrained(source.isConstrained());
/*     */   }
/*     */ 
/*     */   public static Class<?> findPropertyType(Method readMethod, Method writeMethod)
/*     */     throws IntrospectionException
/*     */   {
/* 502 */     Class propertyType = null;
/* 503 */     if (readMethod != null) {
/* 504 */       Class[] params = readMethod.getParameterTypes();
/* 505 */       if (params.length != 0) {
/* 506 */         throw new IntrospectionException("Bad read method arg count: " + readMethod);
/*     */       }
/* 508 */       propertyType = readMethod.getReturnType();
/* 509 */       if (propertyType == Void.TYPE) {
/* 510 */         throw new IntrospectionException("Read method returns void: " + readMethod);
/*     */       }
/*     */     }
/* 513 */     if (writeMethod != null) {
/* 514 */       Class[] params = writeMethod.getParameterTypes();
/* 515 */       if (params.length != 1) {
/* 516 */         throw new IntrospectionException("Bad write method arg count: " + writeMethod);
/*     */       }
/* 518 */       if (propertyType != null) {
/* 519 */         if (propertyType.isAssignableFrom(params[0]))
/*     */         {
/* 521 */           propertyType = params[0];
/*     */         }
/* 523 */         else if (!params[0].isAssignableFrom(propertyType))
/*     */         {
/* 527 */           throw new IntrospectionException("Type mismatch between read and write methods: " + readMethod + " - " + writeMethod);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 532 */         propertyType = params[0];
/*     */       }
/*     */     }
/* 535 */     return propertyType;
/*     */   }
/*     */ 
/*     */   public static Class<?> findIndexedPropertyType(String name, Class<?> propertyType, Method indexedReadMethod, Method indexedWriteMethod)
/*     */     throws IntrospectionException
/*     */   {
/* 544 */     Class indexedPropertyType = null;
/* 545 */     if (indexedReadMethod != null) {
/* 546 */       Class[] params = indexedReadMethod.getParameterTypes();
/* 547 */       if (params.length != 1) {
/* 548 */         throw new IntrospectionException("Bad indexed read method arg count: " + indexedReadMethod);
/*     */       }
/* 550 */       if (params[0] != Integer.TYPE) {
/* 551 */         throw new IntrospectionException("Non int index to indexed read method: " + indexedReadMethod);
/*     */       }
/* 553 */       indexedPropertyType = indexedReadMethod.getReturnType();
/* 554 */       if (indexedPropertyType == Void.TYPE) {
/* 555 */         throw new IntrospectionException("Indexed read method returns void: " + indexedReadMethod);
/*     */       }
/*     */     }
/* 558 */     if (indexedWriteMethod != null) {
/* 559 */       Class[] params = indexedWriteMethod.getParameterTypes();
/* 560 */       if (params.length != 2) {
/* 561 */         throw new IntrospectionException("Bad indexed write method arg count: " + indexedWriteMethod);
/*     */       }
/* 563 */       if (params[0] != Integer.TYPE) {
/* 564 */         throw new IntrospectionException("Non int index to indexed write method: " + indexedWriteMethod);
/*     */       }
/* 566 */       if (indexedPropertyType != null) {
/* 567 */         if (indexedPropertyType.isAssignableFrom(params[1]))
/*     */         {
/* 569 */           indexedPropertyType = params[1];
/*     */         }
/* 571 */         else if (!params[1].isAssignableFrom(indexedPropertyType))
/*     */         {
/* 575 */           throw new IntrospectionException("Type mismatch between indexed read and write methods: " + indexedReadMethod + " - " + indexedWriteMethod);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 580 */         indexedPropertyType = params[1];
/*     */       }
/*     */     }
/* 583 */     if ((propertyType != null) && ((!propertyType.isArray()) || 
/* 584 */       (propertyType
/* 584 */       .getComponentType() != indexedPropertyType))) {
/* 585 */       throw new IntrospectionException("Type mismatch between indexed and non-indexed methods: " + indexedReadMethod + " - " + indexedWriteMethod);
/*     */     }
/*     */ 
/* 588 */     return indexedPropertyType;
/*     */   }
/*     */ 
/*     */   public static boolean equals(PropertyDescriptor pd1, Object obj)
/*     */   {
/* 599 */     if (pd1 == obj) {
/* 600 */       return true;
/*     */     }
/* 602 */     if ((obj != null) && ((obj instanceof PropertyDescriptor))) {
/* 603 */       PropertyDescriptor pd2 = (PropertyDescriptor)obj;
/* 604 */       if (!compareMethods(pd1.getReadMethod(), pd2.getReadMethod())) {
/* 605 */         return false;
/*     */       }
/* 607 */       if (!compareMethods(pd1.getWriteMethod(), pd2.getWriteMethod())) {
/* 608 */         return false;
/*     */       }
/* 610 */       if ((pd1.getPropertyType() == pd2.getPropertyType()) && 
/* 611 */         (pd1
/* 611 */         .getPropertyEditorClass() == pd2.getPropertyEditorClass()) && 
/* 612 */         (pd1
/* 612 */         .isBound() == pd2.isBound()) && (pd1.isConstrained() == pd2.isConstrained())) {
/* 613 */         return true;
/*     */       }
/*     */     }
/* 616 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean compareMethods(Method a, Method b)
/*     */   {
/* 623 */     if ((a == null ? 1 : 0) != (b == null ? 1 : 0)) {
/* 624 */       return false;
/*     */     }
/* 626 */     if ((a != null) && 
/* 627 */       (!a.equals(b))) {
/* 628 */       return false;
/*     */     }
/*     */ 
/* 631 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.PropertyDescriptorUtils
 * JD-Core Version:    0.6.2
 */