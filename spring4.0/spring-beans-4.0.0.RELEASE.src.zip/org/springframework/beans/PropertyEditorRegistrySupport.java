/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collection;
/*     */ import java.util.Currency;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TimeZone;
/*     */ import java.util.UUID;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.propertyeditors.ByteArrayPropertyEditor;
/*     */ import org.springframework.beans.propertyeditors.CharArrayPropertyEditor;
/*     */ import org.springframework.beans.propertyeditors.CharacterEditor;
/*     */ import org.springframework.beans.propertyeditors.CharsetEditor;
/*     */ import org.springframework.beans.propertyeditors.ClassArrayEditor;
/*     */ import org.springframework.beans.propertyeditors.ClassEditor;
/*     */ import org.springframework.beans.propertyeditors.CurrencyEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomBooleanEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomCollectionEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomMapEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomNumberEditor;
/*     */ import org.springframework.beans.propertyeditors.FileEditor;
/*     */ import org.springframework.beans.propertyeditors.InputSourceEditor;
/*     */ import org.springframework.beans.propertyeditors.InputStreamEditor;
/*     */ import org.springframework.beans.propertyeditors.LocaleEditor;
/*     */ import org.springframework.beans.propertyeditors.PatternEditor;
/*     */ import org.springframework.beans.propertyeditors.PropertiesEditor;
/*     */ import org.springframework.beans.propertyeditors.StringArrayPropertyEditor;
/*     */ import org.springframework.beans.propertyeditors.TimeZoneEditor;
/*     */ import org.springframework.beans.propertyeditors.URIEditor;
/*     */ import org.springframework.beans.propertyeditors.URLEditor;
/*     */ import org.springframework.beans.propertyeditors.UUIDEditor;
/*     */ import org.springframework.beans.propertyeditors.ZoneIdEditor;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourceArrayPropertyEditor;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public class PropertyEditorRegistrySupport
/*     */   implements PropertyEditorRegistry
/*     */ {
/*     */   private static Class<?> zoneIdClass;
/*     */   private ConversionService conversionService;
/*     */   private boolean defaultEditorsActive;
/*     */   private boolean configValueEditorsActive;
/*     */   private Map<Class<?>, PropertyEditor> defaultEditors;
/*     */   private Map<Class<?>, PropertyEditor> overriddenDefaultEditors;
/*     */   private Map<Class<?>, PropertyEditor> customEditors;
/*     */   private Map<String, CustomEditorHolder> customEditorsForPath;
/*     */   private Map<Class<?>, PropertyEditor> customEditorCache;
/*     */ 
/*     */   public PropertyEditorRegistrySupport()
/*     */   {
/* 103 */     this.defaultEditorsActive = false;
/*     */ 
/* 105 */     this.configValueEditorsActive = false;
/*     */   }
/*     */ 
/*     */   public void setConversionService(ConversionService conversionService)
/*     */   {
/* 123 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   public ConversionService getConversionService()
/*     */   {
/* 130 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */   protected void registerDefaultEditors()
/*     */   {
/* 143 */     this.defaultEditorsActive = true;
/*     */   }
/*     */ 
/*     */   public void useConfigValueEditors()
/*     */   {
/* 154 */     this.configValueEditorsActive = true;
/*     */   }
/*     */ 
/*     */   public void overrideDefaultEditor(Class<?> requiredType, PropertyEditor propertyEditor)
/*     */   {
/* 167 */     if (this.overriddenDefaultEditors == null) {
/* 168 */       this.overriddenDefaultEditors = new HashMap();
/*     */     }
/* 170 */     this.overriddenDefaultEditors.put(requiredType, propertyEditor);
/*     */   }
/*     */ 
/*     */   public PropertyEditor getDefaultEditor(Class<?> requiredType)
/*     */   {
/* 181 */     if (!this.defaultEditorsActive) {
/* 182 */       return null;
/*     */     }
/* 184 */     if (this.overriddenDefaultEditors != null) {
/* 185 */       PropertyEditor editor = (PropertyEditor)this.overriddenDefaultEditors.get(requiredType);
/* 186 */       if (editor != null) {
/* 187 */         return editor;
/*     */       }
/*     */     }
/* 190 */     if (this.defaultEditors == null) {
/* 191 */       createDefaultEditors();
/*     */     }
/* 193 */     return (PropertyEditor)this.defaultEditors.get(requiredType);
/*     */   }
/*     */ 
/*     */   private void createDefaultEditors()
/*     */   {
/* 200 */     this.defaultEditors = new HashMap(64);
/*     */ 
/* 204 */     this.defaultEditors.put(Charset.class, new CharsetEditor());
/* 205 */     this.defaultEditors.put(Class.class, new ClassEditor());
/* 206 */     this.defaultEditors.put([Ljava.lang.Class.class, new ClassArrayEditor());
/* 207 */     this.defaultEditors.put(Currency.class, new CurrencyEditor());
/* 208 */     this.defaultEditors.put(File.class, new FileEditor());
/* 209 */     this.defaultEditors.put(InputStream.class, new InputStreamEditor());
/* 210 */     this.defaultEditors.put(InputSource.class, new InputSourceEditor());
/* 211 */     this.defaultEditors.put(Locale.class, new LocaleEditor());
/* 212 */     this.defaultEditors.put(Pattern.class, new PatternEditor());
/* 213 */     this.defaultEditors.put(Properties.class, new PropertiesEditor());
/* 214 */     this.defaultEditors.put([Lorg.springframework.core.io.Resource.class, new ResourceArrayPropertyEditor());
/* 215 */     this.defaultEditors.put(TimeZone.class, new TimeZoneEditor());
/* 216 */     this.defaultEditors.put(URI.class, new URIEditor());
/* 217 */     this.defaultEditors.put(URL.class, new URLEditor());
/* 218 */     this.defaultEditors.put(UUID.class, new UUIDEditor());
/* 219 */     if (zoneIdClass != null) {
/* 220 */       this.defaultEditors.put(zoneIdClass, new ZoneIdEditor());
/*     */     }
/*     */ 
/* 225 */     this.defaultEditors.put(Collection.class, new CustomCollectionEditor(Collection.class));
/* 226 */     this.defaultEditors.put(Set.class, new CustomCollectionEditor(Set.class));
/* 227 */     this.defaultEditors.put(SortedSet.class, new CustomCollectionEditor(SortedSet.class));
/* 228 */     this.defaultEditors.put(List.class, new CustomCollectionEditor(List.class));
/* 229 */     this.defaultEditors.put(SortedMap.class, new CustomMapEditor(SortedMap.class));
/*     */ 
/* 232 */     this.defaultEditors.put([B.class, new ByteArrayPropertyEditor());
/* 233 */     this.defaultEditors.put([C.class, new CharArrayPropertyEditor());
/*     */ 
/* 236 */     this.defaultEditors.put(Character.TYPE, new CharacterEditor(false));
/* 237 */     this.defaultEditors.put(Character.class, new CharacterEditor(true));
/*     */ 
/* 240 */     this.defaultEditors.put(Boolean.TYPE, new CustomBooleanEditor(false));
/* 241 */     this.defaultEditors.put(Boolean.class, new CustomBooleanEditor(true));
/*     */ 
/* 245 */     this.defaultEditors.put(Byte.TYPE, new CustomNumberEditor(Byte.class, false));
/* 246 */     this.defaultEditors.put(Byte.class, new CustomNumberEditor(Byte.class, true));
/* 247 */     this.defaultEditors.put(Short.TYPE, new CustomNumberEditor(Short.class, false));
/* 248 */     this.defaultEditors.put(Short.class, new CustomNumberEditor(Short.class, true));
/* 249 */     this.defaultEditors.put(Integer.TYPE, new CustomNumberEditor(Integer.class, false));
/* 250 */     this.defaultEditors.put(Integer.class, new CustomNumberEditor(Integer.class, true));
/* 251 */     this.defaultEditors.put(Long.TYPE, new CustomNumberEditor(Long.class, false));
/* 252 */     this.defaultEditors.put(Long.class, new CustomNumberEditor(Long.class, true));
/* 253 */     this.defaultEditors.put(Float.TYPE, new CustomNumberEditor(Float.class, false));
/* 254 */     this.defaultEditors.put(Float.class, new CustomNumberEditor(Float.class, true));
/* 255 */     this.defaultEditors.put(Double.TYPE, new CustomNumberEditor(Double.class, false));
/* 256 */     this.defaultEditors.put(Double.class, new CustomNumberEditor(Double.class, true));
/* 257 */     this.defaultEditors.put(BigDecimal.class, new CustomNumberEditor(BigDecimal.class, true));
/* 258 */     this.defaultEditors.put(BigInteger.class, new CustomNumberEditor(BigInteger.class, true));
/*     */ 
/* 261 */     if (this.configValueEditorsActive) {
/* 262 */       StringArrayPropertyEditor sae = new StringArrayPropertyEditor();
/* 263 */       this.defaultEditors.put([Ljava.lang.String.class, sae);
/* 264 */       this.defaultEditors.put([S.class, sae);
/* 265 */       this.defaultEditors.put([I.class, sae);
/* 266 */       this.defaultEditors.put([J.class, sae);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void copyDefaultEditorsTo(PropertyEditorRegistrySupport target)
/*     */   {
/* 275 */     target.defaultEditorsActive = this.defaultEditorsActive;
/* 276 */     target.configValueEditorsActive = this.configValueEditorsActive;
/* 277 */     target.defaultEditors = this.defaultEditors;
/* 278 */     target.overriddenDefaultEditors = this.overriddenDefaultEditors;
/*     */   }
/*     */ 
/*     */   public void registerCustomEditor(Class<?> requiredType, PropertyEditor propertyEditor)
/*     */   {
/* 288 */     registerCustomEditor(requiredType, null, propertyEditor);
/*     */   }
/*     */ 
/*     */   public void registerCustomEditor(Class<?> requiredType, String propertyPath, PropertyEditor propertyEditor)
/*     */   {
/* 293 */     if ((requiredType == null) && (propertyPath == null)) {
/* 294 */       throw new IllegalArgumentException("Either requiredType or propertyPath is required");
/*     */     }
/* 296 */     if (propertyPath != null) {
/* 297 */       if (this.customEditorsForPath == null) {
/* 298 */         this.customEditorsForPath = new LinkedHashMap(16);
/*     */       }
/* 300 */       this.customEditorsForPath.put(propertyPath, new CustomEditorHolder(propertyEditor, requiredType, null));
/*     */     }
/*     */     else {
/* 303 */       if (this.customEditors == null) {
/* 304 */         this.customEditors = new LinkedHashMap(16);
/*     */       }
/* 306 */       this.customEditors.put(requiredType, propertyEditor);
/* 307 */       this.customEditorCache = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public PropertyEditor findCustomEditor(Class<?> requiredType, String propertyPath)
/*     */   {
/* 313 */     Class requiredTypeToUse = requiredType;
/* 314 */     if (propertyPath != null) {
/* 315 */       if (this.customEditorsForPath != null)
/*     */       {
/* 317 */         PropertyEditor editor = getCustomEditor(propertyPath, requiredType);
/*     */         Iterator it;
/* 318 */         if (editor == null) {
/* 319 */           List strippedPaths = new LinkedList();
/* 320 */           addStrippedPropertyPaths(strippedPaths, "", propertyPath);
/* 321 */           for (it = strippedPaths.iterator(); (it.hasNext()) && (editor == null); ) {
/* 322 */             String strippedPath = (String)it.next();
/* 323 */             editor = getCustomEditor(strippedPath, requiredType);
/*     */           }
/*     */         }
/* 326 */         if (editor != null) {
/* 327 */           return editor;
/*     */         }
/*     */       }
/* 330 */       if (requiredType == null) {
/* 331 */         requiredTypeToUse = getPropertyType(propertyPath);
/*     */       }
/*     */     }
/*     */ 
/* 335 */     return getCustomEditor(requiredTypeToUse);
/*     */   }
/*     */ 
/*     */   public boolean hasCustomEditorForElement(Class<?> elementType, String propertyPath)
/*     */   {
/* 348 */     if ((propertyPath != null) && (this.customEditorsForPath != null)) {
/* 349 */       for (Map.Entry entry : this.customEditorsForPath.entrySet()) {
/* 350 */         if ((PropertyAccessorUtils.matchesProperty((String)entry.getKey(), propertyPath)) && 
/* 351 */           (((CustomEditorHolder)entry.getValue()).getPropertyEditor(elementType) != null)) {
/* 352 */           return true;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 358 */     return (elementType != null) && (this.customEditors != null) && (this.customEditors.containsKey(elementType));
/*     */   }
/*     */ 
/*     */   protected Class<?> getPropertyType(String propertyPath)
/*     */   {
/* 373 */     return null;
/*     */   }
/*     */ 
/*     */   private PropertyEditor getCustomEditor(String propertyName, Class<?> requiredType)
/*     */   {
/* 383 */     CustomEditorHolder holder = (CustomEditorHolder)this.customEditorsForPath.get(propertyName);
/* 384 */     return holder != null ? holder.getPropertyEditor(requiredType) : null;
/*     */   }
/*     */ 
/*     */   private PropertyEditor getCustomEditor(Class<?> requiredType)
/*     */   {
/* 396 */     if ((requiredType == null) || (this.customEditors == null)) {
/* 397 */       return null;
/*     */     }
/*     */ 
/* 400 */     PropertyEditor editor = (PropertyEditor)this.customEditors.get(requiredType);
/*     */     Iterator it;
/* 401 */     if (editor == null)
/*     */     {
/* 403 */       if (this.customEditorCache != null) {
/* 404 */         editor = (PropertyEditor)this.customEditorCache.get(requiredType);
/*     */       }
/* 406 */       if (editor == null)
/*     */       {
/* 408 */         for (it = this.customEditors.keySet().iterator(); (it.hasNext()) && (editor == null); ) {
/* 409 */           Class key = (Class)it.next();
/* 410 */           if (key.isAssignableFrom(requiredType)) {
/* 411 */             editor = (PropertyEditor)this.customEditors.get(key);
/*     */ 
/* 414 */             if (this.customEditorCache == null) {
/* 415 */               this.customEditorCache = new HashMap();
/*     */             }
/* 417 */             this.customEditorCache.put(requiredType, editor);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 422 */     return editor;
/*     */   }
/*     */ 
/*     */   protected Class<?> guessPropertyTypeFromEditors(String propertyName)
/*     */   {
/* 432 */     if (this.customEditorsForPath != null) {
/* 433 */       CustomEditorHolder editorHolder = (CustomEditorHolder)this.customEditorsForPath.get(propertyName);
/*     */       Iterator it;
/* 434 */       if (editorHolder == null) {
/* 435 */         List strippedPaths = new LinkedList();
/* 436 */         addStrippedPropertyPaths(strippedPaths, "", propertyName);
/* 437 */         for (it = strippedPaths.iterator(); (it.hasNext()) && (editorHolder == null); ) {
/* 438 */           String strippedName = (String)it.next();
/* 439 */           editorHolder = (CustomEditorHolder)this.customEditorsForPath.get(strippedName);
/*     */         }
/*     */       }
/* 442 */       if (editorHolder != null) {
/* 443 */         return editorHolder.getRegisteredType();
/*     */       }
/*     */     }
/* 446 */     return null;
/*     */   }
/*     */ 
/*     */   protected void copyCustomEditorsTo(PropertyEditorRegistry target, String nestedProperty)
/*     */   {
/* 458 */     String actualPropertyName = nestedProperty != null ? 
/* 458 */       PropertyAccessorUtils.getPropertyName(nestedProperty) : 
/* 458 */       null;
/* 459 */     if (this.customEditors != null) {
/* 460 */       for (Map.Entry entry : this.customEditors.entrySet()) {
/* 461 */         target.registerCustomEditor((Class)entry.getKey(), (PropertyEditor)entry.getValue());
/*     */       }
/*     */     }
/* 464 */     if (this.customEditorsForPath != null)
/* 465 */       for (Map.Entry entry : this.customEditorsForPath.entrySet()) {
/* 466 */         String editorPath = (String)entry.getKey();
/* 467 */         CustomEditorHolder editorHolder = (CustomEditorHolder)entry.getValue();
/* 468 */         if (nestedProperty != null) {
/* 469 */           int pos = PropertyAccessorUtils.getFirstNestedPropertySeparatorIndex(editorPath);
/* 470 */           if (pos != -1) {
/* 471 */             String editorNestedProperty = editorPath.substring(0, pos);
/* 472 */             String editorNestedPath = editorPath.substring(pos + 1);
/* 473 */             if ((editorNestedProperty.equals(nestedProperty)) || (editorNestedProperty.equals(actualPropertyName)))
/* 474 */               target.registerCustomEditor(editorHolder
/* 475 */                 .getRegisteredType(), editorNestedPath, editorHolder.getPropertyEditor());
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 480 */           target.registerCustomEditor(editorHolder
/* 481 */             .getRegisteredType(), editorPath, editorHolder.getPropertyEditor());
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   private void addStrippedPropertyPaths(List<String> strippedPaths, String nestedPath, String propertyPath)
/*     */   {
/* 496 */     int startIndex = propertyPath.indexOf(91);
/* 497 */     if (startIndex != -1) {
/* 498 */       int endIndex = propertyPath.indexOf(93);
/* 499 */       if (endIndex != -1) {
/* 500 */         String prefix = propertyPath.substring(0, startIndex);
/* 501 */         String key = propertyPath.substring(startIndex, endIndex + 1);
/* 502 */         String suffix = propertyPath.substring(endIndex + 1, propertyPath.length());
/*     */ 
/* 504 */         strippedPaths.add(nestedPath + prefix + suffix);
/*     */ 
/* 506 */         addStrippedPropertyPaths(strippedPaths, nestedPath + prefix, suffix);
/*     */ 
/* 508 */         addStrippedPropertyPaths(strippedPaths, nestedPath + prefix + key, suffix);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  92 */       zoneIdClass = PropertyEditorRegistrySupport.class.getClassLoader().loadClass("java.time.ZoneId");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*  96 */       zoneIdClass = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CustomEditorHolder
/*     */   {
/*     */     private final PropertyEditor propertyEditor;
/*     */     private final Class<?> registeredType;
/*     */ 
/*     */     private CustomEditorHolder(PropertyEditor propertyEditor, Class<?> registeredType)
/*     */     {
/* 525 */       this.propertyEditor = propertyEditor;
/* 526 */       this.registeredType = registeredType;
/*     */     }
/*     */ 
/*     */     private PropertyEditor getPropertyEditor() {
/* 530 */       return this.propertyEditor;
/*     */     }
/*     */ 
/*     */     private Class<?> getRegisteredType() {
/* 534 */       return this.registeredType;
/*     */     }
/*     */ 
/*     */     private PropertyEditor getPropertyEditor(Class<?> requiredType)
/*     */     {
/* 544 */       if ((this.registeredType != null) && ((requiredType == null) || (
/* 546 */         (!ClassUtils.isAssignable(this.registeredType, requiredType)) && 
/* 547 */         (!ClassUtils.isAssignable(requiredType, this.registeredType))))) {
/* 547 */         if (requiredType == null) { if ((Collection.class
/* 549 */             .isAssignableFrom(this.registeredType)) || 
/* 549 */             (this.registeredType.isArray())); } } else return this.propertyEditor;
/*     */ 
/* 553 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.PropertyEditorRegistrySupport
 * JD-Core Version:    0.6.2
 */