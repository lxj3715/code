/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ final class PropertyMatches
/*     */ {
/*     */   public static final int DEFAULT_MAX_DISTANCE = 2;
/*     */   private final String propertyName;
/*     */   private String[] possibleMatches;
/*     */ 
/*     */   public static PropertyMatches forProperty(String propertyName, Class<?> beanClass)
/*     */   {
/*  53 */     return forProperty(propertyName, beanClass, 2);
/*     */   }
/*     */ 
/*     */   public static PropertyMatches forProperty(String propertyName, Class<?> beanClass, int maxDistance)
/*     */   {
/*  63 */     return new PropertyMatches(propertyName, beanClass, maxDistance);
/*     */   }
/*     */ 
/*     */   private PropertyMatches(String propertyName, Class<?> beanClass, int maxDistance)
/*     */   {
/*  80 */     this.propertyName = propertyName;
/*  81 */     this.possibleMatches = calculateMatches(BeanUtils.getPropertyDescriptors(beanClass), maxDistance);
/*     */   }
/*     */ 
/*     */   public String[] getPossibleMatches()
/*     */   {
/*  89 */     return this.possibleMatches;
/*     */   }
/*     */ 
/*     */   public String buildErrorMessage()
/*     */   {
/*  97 */     StringBuilder msg = new StringBuilder();
/*  98 */     msg.append("Bean property '");
/*  99 */     msg.append(this.propertyName);
/* 100 */     msg.append("' is not writable or has an invalid setter method. ");
/*     */ 
/* 102 */     if (ObjectUtils.isEmpty(this.possibleMatches)) {
/* 103 */       msg.append("Does the parameter type of the setter match the return type of the getter?");
/*     */     }
/*     */     else {
/* 106 */       msg.append("Did you mean ");
/* 107 */       for (int i = 0; i < this.possibleMatches.length; i++) {
/* 108 */         msg.append('\'');
/* 109 */         msg.append(this.possibleMatches[i]);
/* 110 */         if (i < this.possibleMatches.length - 2) {
/* 111 */           msg.append("', ");
/*     */         }
/* 113 */         else if (i == this.possibleMatches.length - 2) {
/* 114 */           msg.append("', or ");
/*     */         }
/*     */       }
/* 117 */       msg.append("'?");
/*     */     }
/* 119 */     return msg.toString();
/*     */   }
/*     */ 
/*     */   private String[] calculateMatches(PropertyDescriptor[] propertyDescriptors, int maxDistance)
/*     */   {
/* 132 */     List candidates = new ArrayList();
/* 133 */     for (PropertyDescriptor pd : propertyDescriptors) {
/* 134 */       if (pd.getWriteMethod() != null) {
/* 135 */         String possibleAlternative = pd.getName();
/* 136 */         if (calculateStringDistance(this.propertyName, possibleAlternative) <= maxDistance) {
/* 137 */           candidates.add(possibleAlternative);
/*     */         }
/*     */       }
/*     */     }
/* 141 */     Collections.sort(candidates);
/* 142 */     return StringUtils.toStringArray(candidates);
/*     */   }
/*     */ 
/*     */   private int calculateStringDistance(String s1, String s2)
/*     */   {
/* 153 */     if (s1.length() == 0) {
/* 154 */       return s2.length();
/*     */     }
/* 156 */     if (s2.length() == 0) {
/* 157 */       return s1.length();
/*     */     }
/* 159 */     int[][] d = new int[s1.length() + 1][s2.length() + 1];
/*     */ 
/* 161 */     for (int i = 0; i <= s1.length(); i++) {
/* 162 */       d[i][0] = i;
/*     */     }
/* 164 */     for (int j = 0; j <= s2.length(); j++) {
/* 165 */       d[0][j] = j;
/*     */     }
/*     */ 
/* 168 */     for (int i = 1; i <= s1.length(); i++) {
/* 169 */       char s_i = s1.charAt(i - 1);
/* 170 */       for (int j = 1; j <= s2.length(); j++)
/*     */       {
/* 172 */         char t_j = s2.charAt(j - 1);
/*     */         int cost;
/*     */         int cost;
/* 173 */         if (s_i == t_j)
/* 174 */           cost = 0;
/*     */         else {
/* 176 */           cost = 1;
/*     */         }
/* 178 */         d[i][j] = Math.min(Math.min(d[(i - 1)][j] + 1, d[i][(j - 1)] + 1), d[(i - 1)][(j - 1)] + cost);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 183 */     return d[s1.length()][s2.length()];
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.PropertyMatches
 * JD-Core Version:    0.6.2
 */