/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.Serializable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class PropertyValue extends BeanMetadataAttributeAccessor
/*     */   implements Serializable
/*     */ {
/*     */   private final String name;
/*     */   private final Object value;
/*     */   private Object source;
/*  51 */   private boolean optional = false;
/*     */ 
/*  53 */   private boolean converted = false;
/*     */   private Object convertedValue;
/*     */   volatile Boolean conversionNecessary;
/*     */   volatile Object resolvedTokens;
/*     */   volatile PropertyDescriptor resolvedDescriptor;
/*     */ 
/*     */   public PropertyValue(String name, Object value)
/*     */   {
/*  73 */     this.name = name;
/*  74 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public PropertyValue(PropertyValue original)
/*     */   {
/*  82 */     Assert.notNull(original, "Original must not be null");
/*  83 */     this.name = original.getName();
/*  84 */     this.value = original.getValue();
/*  85 */     this.source = original.getSource();
/*  86 */     this.optional = original.isOptional();
/*  87 */     this.converted = original.converted;
/*  88 */     this.convertedValue = original.convertedValue;
/*  89 */     this.conversionNecessary = original.conversionNecessary;
/*  90 */     this.resolvedTokens = original.resolvedTokens;
/*  91 */     this.resolvedDescriptor = original.resolvedDescriptor;
/*  92 */     copyAttributesFrom(original);
/*     */   }
/*     */ 
/*     */   public PropertyValue(PropertyValue original, Object newValue)
/*     */   {
/* 102 */     Assert.notNull(original, "Original must not be null");
/* 103 */     this.name = original.getName();
/* 104 */     this.value = newValue;
/* 105 */     this.source = original;
/* 106 */     this.optional = original.isOptional();
/* 107 */     this.conversionNecessary = original.conversionNecessary;
/* 108 */     this.resolvedTokens = original.resolvedTokens;
/* 109 */     this.resolvedDescriptor = original.resolvedDescriptor;
/* 110 */     copyAttributesFrom(original);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 118 */     return this.name;
/*     */   }
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 128 */     return this.value;
/*     */   }
/*     */ 
/*     */   public PropertyValue getOriginalPropertyValue()
/*     */   {
/* 137 */     PropertyValue original = this;
/* 138 */     while (((original.source instanceof PropertyValue)) && (original.source != original)) {
/* 139 */       original = (PropertyValue)original.source;
/*     */     }
/* 141 */     return original;
/*     */   }
/*     */ 
/*     */   public void setOptional(boolean optional) {
/* 145 */     this.optional = optional;
/*     */   }
/*     */ 
/*     */   public boolean isOptional() {
/* 149 */     return this.optional;
/*     */   }
/*     */ 
/*     */   public synchronized boolean isConverted()
/*     */   {
/* 157 */     return this.converted;
/*     */   }
/*     */ 
/*     */   public synchronized void setConvertedValue(Object value)
/*     */   {
/* 165 */     this.converted = true;
/* 166 */     this.convertedValue = value;
/*     */   }
/*     */ 
/*     */   public synchronized Object getConvertedValue()
/*     */   {
/* 174 */     return this.convertedValue;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 180 */     if (this == other) {
/* 181 */       return true;
/*     */     }
/* 183 */     if (!(other instanceof PropertyValue)) {
/* 184 */       return false;
/*     */     }
/* 186 */     PropertyValue otherPv = (PropertyValue)other;
/*     */ 
/* 189 */     return (this.name.equals(otherPv.name)) && 
/* 188 */       (ObjectUtils.nullSafeEquals(this.value, otherPv.value)) && 
/* 189 */       (ObjectUtils.nullSafeEquals(this.source, otherPv.source));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 194 */     return this.name.hashCode() * 29 + ObjectUtils.nullSafeHashCode(this.value);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 199 */     return "bean property '" + this.name + "'";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.PropertyValue
 * JD-Core Version:    0.6.2
 */