/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ class SimpleIndexedPropertyDescriptor extends IndexedPropertyDescriptor
/*     */ {
/*     */   private Method readMethod;
/*     */   private Method writeMethod;
/*     */   private Class<?> propertyType;
/*     */   private Method indexedReadMethod;
/*     */   private Method indexedWriteMethod;
/*     */   private Class<?> indexedPropertyType;
/*     */   private Class<?> propertyEditorClass;
/*     */ 
/*     */   public SimpleIndexedPropertyDescriptor(IndexedPropertyDescriptor original)
/*     */     throws IntrospectionException
/*     */   {
/* 342 */     this(original.getName(), original.getReadMethod(), original.getWriteMethod(), original
/* 343 */       .getIndexedReadMethod(), original.getIndexedWriteMethod());
/* 344 */     PropertyDescriptorUtils.copyNonMethodProperties(original, this);
/*     */   }
/*     */ 
/*     */   public SimpleIndexedPropertyDescriptor(String propertyName, Method readMethod, Method writeMethod, Method indexedReadMethod, Method indexedWriteMethod)
/*     */     throws IntrospectionException
/*     */   {
/* 350 */     super(propertyName, null, null, null, null);
/* 351 */     this.readMethod = readMethod;
/* 352 */     this.writeMethod = writeMethod;
/* 353 */     this.propertyType = PropertyDescriptorUtils.findPropertyType(readMethod, writeMethod);
/* 354 */     this.indexedReadMethod = indexedReadMethod;
/* 355 */     this.indexedWriteMethod = indexedWriteMethod;
/* 356 */     this.indexedPropertyType = PropertyDescriptorUtils.findIndexedPropertyType(propertyName, this.propertyType, indexedReadMethod, indexedWriteMethod);
/*     */   }
/*     */ 
/*     */   public Method getReadMethod()
/*     */   {
/* 361 */     return this.readMethod;
/*     */   }
/*     */ 
/*     */   public void setReadMethod(Method readMethod)
/*     */   {
/* 366 */     this.readMethod = readMethod;
/*     */   }
/*     */ 
/*     */   public Method getWriteMethod()
/*     */   {
/* 371 */     return this.writeMethod;
/*     */   }
/*     */ 
/*     */   public void setWriteMethod(Method writeMethod)
/*     */   {
/* 376 */     this.writeMethod = writeMethod;
/*     */   }
/*     */ 
/*     */   public Class<?> getPropertyType()
/*     */   {
/* 381 */     if (this.propertyType == null) {
/*     */       try {
/* 383 */         this.propertyType = PropertyDescriptorUtils.findPropertyType(this.readMethod, this.writeMethod);
/*     */       }
/*     */       catch (IntrospectionException ex)
/*     */       {
/*     */       }
/*     */     }
/* 389 */     return this.propertyType;
/*     */   }
/*     */ 
/*     */   public Method getIndexedReadMethod()
/*     */   {
/* 394 */     return this.indexedReadMethod;
/*     */   }
/*     */ 
/*     */   public void setIndexedReadMethod(Method indexedReadMethod) throws IntrospectionException
/*     */   {
/* 399 */     this.indexedReadMethod = indexedReadMethod;
/*     */   }
/*     */ 
/*     */   public Method getIndexedWriteMethod()
/*     */   {
/* 404 */     return this.indexedWriteMethod;
/*     */   }
/*     */ 
/*     */   public void setIndexedWriteMethod(Method indexedWriteMethod) throws IntrospectionException
/*     */   {
/* 409 */     this.indexedWriteMethod = indexedWriteMethod;
/*     */   }
/*     */ 
/*     */   public Class<?> getIndexedPropertyType()
/*     */   {
/* 414 */     if (this.indexedPropertyType == null) {
/*     */       try {
/* 416 */         this.indexedPropertyType = PropertyDescriptorUtils.findIndexedPropertyType(
/* 417 */           getName(), getPropertyType(), this.indexedReadMethod, this.indexedWriteMethod);
/*     */       }
/*     */       catch (IntrospectionException ex)
/*     */       {
/*     */       }
/*     */     }
/* 423 */     return this.indexedPropertyType;
/*     */   }
/*     */ 
/*     */   public Class<?> getPropertyEditorClass()
/*     */   {
/* 428 */     return this.propertyEditorClass;
/*     */   }
/*     */ 
/*     */   public void setPropertyEditorClass(Class<?> propertyEditorClass)
/*     */   {
/* 433 */     this.propertyEditorClass = propertyEditorClass;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 441 */     if (this == obj) {
/* 442 */       return true;
/*     */     }
/* 444 */     if ((obj != null) && ((obj instanceof IndexedPropertyDescriptor))) {
/* 445 */       IndexedPropertyDescriptor other = (IndexedPropertyDescriptor)obj;
/* 446 */       if (!PropertyDescriptorUtils.compareMethods(getIndexedReadMethod(), other.getIndexedReadMethod())) {
/* 447 */         return false;
/*     */       }
/* 449 */       if (!PropertyDescriptorUtils.compareMethods(getIndexedWriteMethod(), other.getIndexedWriteMethod())) {
/* 450 */         return false;
/*     */       }
/* 452 */       if (getIndexedPropertyType() != other.getIndexedPropertyType()) {
/* 453 */         return false;
/*     */       }
/* 455 */       return PropertyDescriptorUtils.equals(this, obj);
/*     */     }
/* 457 */     return false;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 462 */     return String.format("%s[name=%s, propertyType=%s, indexedPropertyType=%s, readMethod=%s, writeMethod=%s, indexedReadMethod=%s, indexedWriteMethod=%s]", new Object[] { 
/* 464 */       getClass().getSimpleName(), getName(), getPropertyType(), getIndexedPropertyType(), this.readMethod, this.writeMethod, this.indexedReadMethod, this.indexedWriteMethod });
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.SimpleIndexedPropertyDescriptor
 * JD-Core Version:    0.6.2
 */