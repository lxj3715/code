/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ class SimplePropertyDescriptor extends PropertyDescriptor
/*     */ {
/*     */   private Method readMethod;
/*     */   private Method writeMethod;
/*     */   private Class<?> propertyType;
/*     */   private Class<?> propertyEditorClass;
/*     */ 
/*     */   public SimplePropertyDescriptor(PropertyDescriptor original)
/*     */     throws IntrospectionException
/*     */   {
/* 258 */     this(original.getName(), original.getReadMethod(), original.getWriteMethod());
/* 259 */     PropertyDescriptorUtils.copyNonMethodProperties(original, this);
/*     */   }
/*     */ 
/*     */   public SimplePropertyDescriptor(String propertyName, Method readMethod, Method writeMethod) throws IntrospectionException {
/* 263 */     super(propertyName, null, null);
/* 264 */     this.readMethod = readMethod;
/* 265 */     this.writeMethod = writeMethod;
/* 266 */     this.propertyType = PropertyDescriptorUtils.findPropertyType(readMethod, writeMethod);
/*     */   }
/*     */ 
/*     */   public Method getReadMethod()
/*     */   {
/* 271 */     return this.readMethod;
/*     */   }
/*     */ 
/*     */   public void setReadMethod(Method readMethod)
/*     */   {
/* 276 */     this.readMethod = readMethod;
/*     */   }
/*     */ 
/*     */   public Method getWriteMethod()
/*     */   {
/* 281 */     return this.writeMethod;
/*     */   }
/*     */ 
/*     */   public void setWriteMethod(Method writeMethod)
/*     */   {
/* 286 */     this.writeMethod = writeMethod;
/*     */   }
/*     */ 
/*     */   public Class<?> getPropertyType()
/*     */   {
/* 291 */     if (this.propertyType == null) {
/*     */       try {
/* 293 */         this.propertyType = PropertyDescriptorUtils.findPropertyType(this.readMethod, this.writeMethod);
/*     */       }
/*     */       catch (IntrospectionException ex)
/*     */       {
/*     */       }
/*     */     }
/* 299 */     return this.propertyType;
/*     */   }
/*     */ 
/*     */   public Class<?> getPropertyEditorClass()
/*     */   {
/* 304 */     return this.propertyEditorClass;
/*     */   }
/*     */ 
/*     */   public void setPropertyEditorClass(Class<?> propertyEditorClass)
/*     */   {
/* 309 */     this.propertyEditorClass = propertyEditorClass;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 314 */     return PropertyDescriptorUtils.equals(this, obj);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 319 */     return String.format("%s[name=%s, propertyType=%s, readMethod=%s, writeMethod=%s]", new Object[] { 
/* 320 */       getClass().getSimpleName(), getName(), getPropertyType(), this.readMethod, this.writeMethod });
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.SimplePropertyDescriptor
 * JD-Core Version:    0.6.2
 */