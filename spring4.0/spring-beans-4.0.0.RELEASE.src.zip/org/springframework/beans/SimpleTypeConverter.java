/*    */ package org.springframework.beans;
/*    */ 
/*    */ public class SimpleTypeConverter extends TypeConverterSupport
/*    */ {
/*    */   public SimpleTypeConverter()
/*    */   {
/* 36 */     this.typeConverterDelegate = new TypeConverterDelegate(this);
/* 37 */     registerDefaultEditors();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.SimpleTypeConverter
 * JD-Core Version:    0.6.2
 */