/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class TypeConverterDelegate
/*     */ {
/*  54 */   private static final Log logger = LogFactory.getLog(TypeConverterDelegate.class);
/*     */   private final PropertyEditorRegistrySupport propertyEditorRegistry;
/*     */   private final Object targetObject;
/*     */ 
/*     */   public TypeConverterDelegate(PropertyEditorRegistrySupport propertyEditorRegistry)
/*     */   {
/*  66 */     this(propertyEditorRegistry, null);
/*     */   }
/*     */ 
/*     */   public TypeConverterDelegate(PropertyEditorRegistrySupport propertyEditorRegistry, Object targetObject)
/*     */   {
/*  75 */     this.propertyEditorRegistry = propertyEditorRegistry;
/*  76 */     this.targetObject = targetObject;
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(Object newValue, Class<T> requiredType, MethodParameter methodParam)
/*     */     throws IllegalArgumentException
/*     */   {
/*  93 */     return convertIfNecessary(null, null, newValue, requiredType, methodParam != null ? new TypeDescriptor(methodParam) : 
/*  94 */       TypeDescriptor.valueOf(requiredType));
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(Object newValue, Class<T> requiredType, Field field)
/*     */     throws IllegalArgumentException
/*     */   {
/* 110 */     return convertIfNecessary(null, null, newValue, requiredType, field != null ? new TypeDescriptor(field) : 
/* 111 */       TypeDescriptor.valueOf(requiredType));
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(String propertyName, Object oldValue, Object newValue, Class<T> requiredType)
/*     */     throws IllegalArgumentException
/*     */   {
/* 128 */     return convertIfNecessary(propertyName, oldValue, newValue, requiredType, TypeDescriptor.valueOf(requiredType));
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(String propertyName, Object oldValue, Object newValue, Class<T> requiredType, TypeDescriptor typeDescriptor)
/*     */     throws IllegalArgumentException
/*     */   {
/* 147 */     Object convertedValue = newValue;
/*     */ 
/* 150 */     PropertyEditor editor = this.propertyEditorRegistry.findCustomEditor(requiredType, propertyName);
/*     */ 
/* 152 */     ConversionFailedException firstAttemptEx = null;
/*     */ 
/* 155 */     ConversionService conversionService = this.propertyEditorRegistry.getConversionService();
/* 156 */     if ((editor == null) && (conversionService != null) && (convertedValue != null) && (typeDescriptor != null)) {
/* 157 */       TypeDescriptor sourceTypeDesc = TypeDescriptor.forObject(newValue);
/* 158 */       TypeDescriptor targetTypeDesc = typeDescriptor;
/* 159 */       if (conversionService.canConvert(sourceTypeDesc, targetTypeDesc)) {
/*     */         try {
/* 161 */           return conversionService.convert(convertedValue, sourceTypeDesc, targetTypeDesc);
/*     */         }
/*     */         catch (ConversionFailedException ex)
/*     */         {
/* 165 */           firstAttemptEx = ex;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 171 */     if ((editor != null) || ((requiredType != null) && (!ClassUtils.isAssignableValue(requiredType, convertedValue)))) {
/* 172 */       if ((requiredType != null) && (Collection.class.isAssignableFrom(requiredType)) && ((convertedValue instanceof String))) {
/* 173 */         TypeDescriptor elementType = typeDescriptor.getElementTypeDescriptor();
/* 174 */         if ((elementType != null) && (Enum.class.isAssignableFrom(elementType.getType()))) {
/* 175 */           convertedValue = StringUtils.commaDelimitedListToStringArray((String)convertedValue);
/*     */         }
/*     */       }
/* 178 */       if (editor == null) {
/* 179 */         editor = findDefaultEditor(requiredType);
/*     */       }
/* 181 */       convertedValue = doConvertValue(oldValue, convertedValue, requiredType, editor);
/*     */     }
/*     */ 
/* 184 */     boolean standardConversion = false;
/*     */ 
/* 186 */     if (requiredType != null)
/*     */     {
/* 189 */       if (convertedValue != null) {
/* 190 */         if (Object.class.equals(requiredType)) {
/* 191 */           return convertedValue;
/*     */         }
/* 193 */         if (requiredType.isArray())
/*     */         {
/* 195 */           if (((convertedValue instanceof String)) && (Enum.class.isAssignableFrom(requiredType.getComponentType()))) {
/* 196 */             convertedValue = StringUtils.commaDelimitedListToStringArray((String)convertedValue);
/*     */           }
/* 198 */           return convertToTypedArray(convertedValue, propertyName, requiredType.getComponentType());
/*     */         }
/* 200 */         if ((convertedValue instanceof Collection))
/*     */         {
/* 202 */           convertedValue = convertToTypedCollection((Collection)convertedValue, propertyName, requiredType, typeDescriptor);
/*     */ 
/* 204 */           standardConversion = true;
/*     */         }
/* 206 */         else if ((convertedValue instanceof Map))
/*     */         {
/* 208 */           convertedValue = convertToTypedMap((Map)convertedValue, propertyName, requiredType, typeDescriptor);
/*     */ 
/* 210 */           standardConversion = true;
/*     */         }
/* 212 */         if ((convertedValue.getClass().isArray()) && (Array.getLength(convertedValue) == 1)) {
/* 213 */           convertedValue = Array.get(convertedValue, 0);
/* 214 */           standardConversion = true;
/*     */         }
/* 216 */         if ((String.class.equals(requiredType)) && (ClassUtils.isPrimitiveOrWrapper(convertedValue.getClass())))
/*     */         {
/* 218 */           return convertedValue.toString();
/*     */         }
/* 220 */         if (((convertedValue instanceof String)) && (!requiredType.isInstance(convertedValue))) {
/* 221 */           if ((firstAttemptEx == null) && (!requiredType.isInterface()) && (!requiredType.isEnum())) {
/*     */             try {
/* 223 */               Constructor strCtor = requiredType.getConstructor(new Class[] { String.class });
/* 224 */               return BeanUtils.instantiateClass(strCtor, new Object[] { convertedValue });
/*     */             }
/*     */             catch (NoSuchMethodException ex)
/*     */             {
/* 228 */               if (logger.isTraceEnabled())
/* 229 */                 logger.trace(new StringBuilder().append("No String constructor found on type [").append(requiredType.getName()).append("]").toString(), ex);
/*     */             }
/*     */             catch (Exception ex)
/*     */             {
/* 233 */               if (logger.isDebugEnabled()) {
/* 234 */                 logger.debug(new StringBuilder().append("Construction via String failed for type [").append(requiredType.getName()).append("]").toString(), ex);
/*     */               }
/*     */             }
/*     */           }
/* 238 */           String trimmedValue = ((String)convertedValue).trim();
/* 239 */           if ((requiredType.isEnum()) && ("".equals(trimmedValue)))
/*     */           {
/* 241 */             return null;
/*     */           }
/* 243 */           convertedValue = attemptToConvertStringToEnum(requiredType, trimmedValue, convertedValue);
/* 244 */           standardConversion = true;
/*     */         }
/*     */       }
/*     */ 
/* 248 */       if (!ClassUtils.isAssignableValue(requiredType, convertedValue)) {
/* 249 */         if (firstAttemptEx != null) {
/* 250 */           throw firstAttemptEx;
/*     */         }
/*     */ 
/* 253 */         StringBuilder msg = new StringBuilder();
/* 254 */         msg.append("Cannot convert value of type [").append(ClassUtils.getDescriptiveType(newValue));
/* 255 */         msg.append("] to required type [").append(ClassUtils.getQualifiedName(requiredType)).append("]");
/* 256 */         if (propertyName != null) {
/* 257 */           msg.append(" for property '").append(propertyName).append("'");
/*     */         }
/* 259 */         if (editor != null) {
/* 260 */           msg.append(": PropertyEditor [").append(editor.getClass().getName()).append("] returned inappropriate value of type [")
/* 261 */             .append(
/* 262 */             ClassUtils.getDescriptiveType(convertedValue))
/* 262 */             .append("]");
/*     */ 
/* 263 */           throw new IllegalArgumentException(msg.toString());
/*     */         }
/*     */ 
/* 266 */         msg.append(": no matching editors or conversion strategy found");
/* 267 */         throw new IllegalStateException(msg.toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 272 */     if (firstAttemptEx != null) {
/* 273 */       if ((editor == null) && (!standardConversion) && (requiredType != null) && (!Object.class.equals(requiredType))) {
/* 274 */         throw firstAttemptEx;
/*     */       }
/* 276 */       logger.debug("Original ConversionService attempt failed - ignored since PropertyEditor based conversion eventually succeeded", firstAttemptEx);
/*     */     }
/*     */ 
/* 280 */     return convertedValue;
/*     */   }
/*     */ 
/*     */   private Object attemptToConvertStringToEnum(Class<?> requiredType, String trimmedValue, Object currentConvertedValue) {
/* 284 */     Object convertedValue = currentConvertedValue;
/*     */ 
/* 286 */     if (Enum.class.equals(requiredType))
/*     */     {
/* 288 */       int index = trimmedValue.lastIndexOf(".");
/* 289 */       if (index > -1) {
/* 290 */         String enumType = trimmedValue.substring(0, index);
/* 291 */         String fieldName = trimmedValue.substring(index + 1);
/* 292 */         ClassLoader loader = this.targetObject.getClass().getClassLoader();
/*     */         try {
/* 294 */           Class enumValueType = loader.loadClass(enumType);
/* 295 */           Field enumField = enumValueType.getField(fieldName);
/* 296 */           convertedValue = enumField.get(null);
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 299 */           if (logger.isTraceEnabled())
/* 300 */             logger.trace(new StringBuilder().append("Enum class [").append(enumType).append("] cannot be loaded from [").append(loader).append("]").toString(), ex);
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/* 304 */           if (logger.isTraceEnabled()) {
/* 305 */             logger.trace(new StringBuilder().append("Field [").append(fieldName).append("] isn't an enum value for type [").append(enumType).append("]").toString(), ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 311 */     if (convertedValue == currentConvertedValue)
/*     */     {
/*     */       try
/*     */       {
/* 316 */         Field enumField = requiredType.getField(trimmedValue);
/* 317 */         convertedValue = enumField.get(null);
/*     */       }
/*     */       catch (Throwable ex) {
/* 320 */         if (logger.isTraceEnabled()) {
/* 321 */           logger.trace(new StringBuilder().append("Field [").append(convertedValue).append("] isn't an enum value").toString(), ex);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 327 */     return convertedValue;
/*     */   }
/*     */ 
/*     */   private PropertyEditor findDefaultEditor(Class<?> requiredType)
/*     */   {
/* 335 */     PropertyEditor editor = null;
/* 336 */     if (requiredType != null)
/*     */     {
/* 338 */       editor = this.propertyEditorRegistry.getDefaultEditor(requiredType);
/* 339 */       if ((editor == null) && (!String.class.equals(requiredType)))
/*     */       {
/* 341 */         editor = BeanUtils.findEditorByConvention(requiredType);
/*     */       }
/*     */     }
/* 344 */     return editor;
/*     */   }
/*     */ 
/*     */   private Object doConvertValue(Object oldValue, Object newValue, Class<?> requiredType, PropertyEditor editor)
/*     */   {
/* 359 */     Object convertedValue = newValue;
/*     */ 
/* 361 */     if ((editor != null) && (!(convertedValue instanceof String)))
/*     */     {
/*     */       try
/*     */       {
/* 367 */         editor.setValue(convertedValue);
/* 368 */         Object newConvertedValue = editor.getValue();
/* 369 */         if (newConvertedValue != convertedValue) {
/* 370 */           convertedValue = newConvertedValue;
/*     */ 
/* 373 */           editor = null;
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 377 */         if (logger.isDebugEnabled()) {
/* 378 */           logger.debug(new StringBuilder().append("PropertyEditor [").append(editor.getClass().getName()).append("] does not support setValue call").toString(), ex);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 384 */     Object returnValue = convertedValue;
/*     */ 
/* 386 */     if ((requiredType != null) && (!requiredType.isArray()) && ((convertedValue instanceof String[])))
/*     */     {
/* 390 */       if (logger.isTraceEnabled()) {
/* 391 */         logger.trace(new StringBuilder().append("Converting String array to comma-delimited String [").append(convertedValue).append("]").toString());
/*     */       }
/* 393 */       convertedValue = StringUtils.arrayToCommaDelimitedString((String[])convertedValue);
/*     */     }
/*     */ 
/* 396 */     if ((convertedValue instanceof String)) {
/* 397 */       if (editor != null)
/*     */       {
/* 399 */         if (logger.isTraceEnabled()) {
/* 400 */           logger.trace(new StringBuilder().append("Converting String to [").append(requiredType).append("] using property editor [").append(editor).append("]").toString());
/*     */         }
/* 402 */         String newTextValue = (String)convertedValue;
/* 403 */         return doConvertTextValue(oldValue, newTextValue, editor);
/*     */       }
/* 405 */       if (String.class.equals(requiredType)) {
/* 406 */         returnValue = convertedValue;
/*     */       }
/*     */     }
/*     */ 
/* 410 */     return returnValue;
/*     */   }
/*     */ 
/*     */   private Object doConvertTextValue(Object oldValue, String newTextValue, PropertyEditor editor)
/*     */   {
/*     */     try
/*     */     {
/* 422 */       editor.setValue(oldValue);
/*     */     }
/*     */     catch (Exception ex) {
/* 425 */       if (logger.isDebugEnabled()) {
/* 426 */         logger.debug(new StringBuilder().append("PropertyEditor [").append(editor.getClass().getName()).append("] does not support setValue call").toString(), ex);
/*     */       }
/*     */     }
/*     */ 
/* 430 */     editor.setAsText(newTextValue);
/* 431 */     return editor.getValue();
/*     */   }
/*     */ 
/*     */   private Object convertToTypedArray(Object input, String propertyName, Class<?> componentType) {
/* 435 */     if ((input instanceof Collection))
/*     */     {
/* 437 */       Collection coll = (Collection)input;
/* 438 */       Object result = Array.newInstance(componentType, coll.size());
/* 439 */       int i = 0;
/* 440 */       for (Iterator it = coll.iterator(); it.hasNext(); i++) {
/* 441 */         Object value = convertIfNecessary(
/* 442 */           buildIndexedPropertyName(propertyName, i), 
/* 442 */           null, it.next(), componentType);
/* 443 */         Array.set(result, i, value);
/*     */       }
/* 445 */       return result;
/*     */     }
/* 447 */     if (input.getClass().isArray())
/*     */     {
/* 449 */       if ((componentType.equals(input.getClass().getComponentType())) && 
/* 450 */         (!this.propertyEditorRegistry
/* 450 */         .hasCustomEditorForElement(componentType, propertyName)))
/*     */       {
/* 451 */         return input;
/*     */       }
/* 453 */       int arrayLength = Array.getLength(input);
/* 454 */       Object result = Array.newInstance(componentType, arrayLength);
/* 455 */       for (int i = 0; i < arrayLength; i++) {
/* 456 */         Object value = convertIfNecessary(
/* 457 */           buildIndexedPropertyName(propertyName, i), 
/* 457 */           null, Array.get(input, i), componentType);
/* 458 */         Array.set(result, i, value);
/*     */       }
/* 460 */       return result;
/*     */     }
/*     */ 
/* 464 */     Object result = Array.newInstance(componentType, 1);
/* 465 */     Object value = convertIfNecessary(
/* 466 */       buildIndexedPropertyName(propertyName, 0), 
/* 466 */       null, input, componentType);
/* 467 */     Array.set(result, 0, value);
/* 468 */     return result;
/*     */   }
/*     */ 
/*     */   private Collection<?> convertToTypedCollection(Collection<?> original, String propertyName, Class<?> requiredType, TypeDescriptor typeDescriptor)
/*     */   {
/* 476 */     if (!Collection.class.isAssignableFrom(requiredType)) {
/* 477 */       return original;
/*     */     }
/*     */ 
/* 480 */     boolean approximable = CollectionFactory.isApproximableCollectionType(requiredType);
/* 481 */     if ((!approximable) && (!canCreateCopy(requiredType))) {
/* 482 */       if (logger.isDebugEnabled()) {
/* 483 */         logger.debug(new StringBuilder().append("Custom Collection type [").append(original.getClass().getName()).append("] does not allow for creating a copy - injecting original Collection as-is").toString());
/*     */       }
/*     */ 
/* 486 */       return original;
/*     */     }
/*     */ 
/* 489 */     boolean originalAllowed = requiredType.isInstance(original);
/* 490 */     typeDescriptor = typeDescriptor.narrow(original);
/* 491 */     TypeDescriptor elementType = typeDescriptor.getElementTypeDescriptor();
/* 492 */     if ((elementType == null) && (originalAllowed) && 
/* 493 */       (!this.propertyEditorRegistry
/* 493 */       .hasCustomEditorForElement(null, propertyName)))
/*     */     {
/* 494 */       return original;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 499 */       Iterator it = original.iterator();
/* 500 */       if (it == null) {
/* 501 */         if (logger.isDebugEnabled()) {
/* 502 */           logger.debug(new StringBuilder().append("Collection of type [").append(original.getClass().getName()).append("] returned null Iterator - injecting original Collection as-is").toString());
/*     */         }
/*     */ 
/* 505 */         return original;
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 509 */       if (logger.isDebugEnabled()) {
/* 510 */         logger.debug(new StringBuilder().append("Cannot access Collection of type [").append(original.getClass().getName()).append("] - injecting original Collection as-is: ").append(ex).toString());
/*     */       }
/*     */ 
/* 513 */       return original;
/*     */     }
/*     */     Iterator it;
/*     */     try
/*     */     {
/*     */       Collection convertedCopy;
/* 518 */       if (approximable) {
/* 519 */         convertedCopy = CollectionFactory.createApproximateCollection(original, original.size());
/*     */       }
/*     */       else
/* 522 */         convertedCopy = (Collection)requiredType.newInstance();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*     */       Collection convertedCopy;
/* 526 */       if (logger.isDebugEnabled()) {
/* 527 */         logger.debug(new StringBuilder().append("Cannot create copy of Collection type [").append(original.getClass().getName()).append("] - injecting original Collection as-is: ").append(ex).toString());
/*     */       }
/*     */ 
/* 530 */       return original;
/*     */     }
/*     */     Collection convertedCopy;
/* 533 */     for (int i = 0; 
/* 534 */       it.hasNext(); i++) {
/* 535 */       Object element = it.next();
/* 536 */       String indexedPropertyName = buildIndexedPropertyName(propertyName, i);
/* 537 */       Object convertedElement = convertIfNecessary(indexedPropertyName, null, element, elementType != null ? elementType
/* 538 */         .getType() : null, elementType);
/*     */       try {
/* 540 */         convertedCopy.add(convertedElement);
/*     */       }
/*     */       catch (Throwable ex) {
/* 543 */         if (logger.isDebugEnabled()) {
/* 544 */           logger.debug(new StringBuilder().append("Collection type [").append(original.getClass().getName()).append("] seems to be read-only - injecting original Collection as-is: ").append(ex).toString());
/*     */         }
/*     */ 
/* 547 */         return original;
/*     */       }
/* 549 */       originalAllowed = (originalAllowed) && (element == convertedElement);
/*     */     }
/* 551 */     return originalAllowed ? original : convertedCopy;
/*     */   }
/*     */ 
/*     */   private Map<?, ?> convertToTypedMap(Map<?, ?> original, String propertyName, Class<?> requiredType, TypeDescriptor typeDescriptor)
/*     */   {
/* 558 */     if (!Map.class.isAssignableFrom(requiredType)) {
/* 559 */       return original;
/*     */     }
/*     */ 
/* 562 */     boolean approximable = CollectionFactory.isApproximableMapType(requiredType);
/* 563 */     if ((!approximable) && (!canCreateCopy(requiredType))) {
/* 564 */       if (logger.isDebugEnabled()) {
/* 565 */         logger.debug(new StringBuilder().append("Custom Map type [").append(original.getClass().getName()).append("] does not allow for creating a copy - injecting original Map as-is").toString());
/*     */       }
/*     */ 
/* 568 */       return original;
/*     */     }
/*     */ 
/* 571 */     boolean originalAllowed = requiredType.isInstance(original);
/* 572 */     typeDescriptor = typeDescriptor.narrow(original);
/* 573 */     TypeDescriptor keyType = typeDescriptor.getMapKeyTypeDescriptor();
/* 574 */     TypeDescriptor valueType = typeDescriptor.getMapValueTypeDescriptor();
/* 575 */     if ((keyType == null) && (valueType == null) && (originalAllowed) && 
/* 576 */       (!this.propertyEditorRegistry
/* 576 */       .hasCustomEditorForElement(null, propertyName)))
/*     */     {
/* 577 */       return original;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 582 */       Iterator it = original.entrySet().iterator();
/* 583 */       if (it == null) {
/* 584 */         if (logger.isDebugEnabled()) {
/* 585 */           logger.debug(new StringBuilder().append("Map of type [").append(original.getClass().getName()).append("] returned null Iterator - injecting original Map as-is").toString());
/*     */         }
/*     */ 
/* 588 */         return original;
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 592 */       if (logger.isDebugEnabled()) {
/* 593 */         logger.debug(new StringBuilder().append("Cannot access Map of type [").append(original.getClass().getName()).append("] - injecting original Map as-is: ").append(ex).toString());
/*     */       }
/*     */ 
/* 596 */       return original;
/*     */     }
/*     */     Iterator it;
/*     */     try
/*     */     {
/*     */       Map convertedCopy;
/* 601 */       if (approximable) {
/* 602 */         convertedCopy = CollectionFactory.createApproximateMap(original, original.size());
/*     */       }
/*     */       else
/* 605 */         convertedCopy = (Map)requiredType.newInstance();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*     */       Map convertedCopy;
/* 609 */       if (logger.isDebugEnabled()) {
/* 610 */         logger.debug(new StringBuilder().append("Cannot create copy of Map type [").append(original.getClass().getName()).append("] - injecting original Map as-is: ").append(ex).toString());
/*     */       }
/*     */ 
/* 613 */       return original;
/*     */     }
/*     */     Map convertedCopy;
/* 616 */     while (it.hasNext()) {
/* 617 */       Map.Entry entry = (Map.Entry)it.next();
/* 618 */       Object key = entry.getKey();
/* 619 */       Object value = entry.getValue();
/* 620 */       String keyedPropertyName = buildKeyedPropertyName(propertyName, key);
/* 621 */       Object convertedKey = convertIfNecessary(keyedPropertyName, null, key, keyType != null ? keyType
/* 622 */         .getType() : null, keyType);
/* 623 */       Object convertedValue = convertIfNecessary(keyedPropertyName, null, value, valueType != null ? valueType
/* 624 */         .getType() : null, valueType);
/*     */       try {
/* 626 */         convertedCopy.put(convertedKey, convertedValue);
/*     */       }
/*     */       catch (Throwable ex) {
/* 629 */         if (logger.isDebugEnabled()) {
/* 630 */           logger.debug(new StringBuilder().append("Map type [").append(original.getClass().getName()).append("] seems to be read-only - injecting original Map as-is: ").append(ex).toString());
/*     */         }
/*     */ 
/* 633 */         return original;
/*     */       }
/* 635 */       originalAllowed = (originalAllowed) && (key == convertedKey) && (value == convertedValue);
/*     */     }
/* 637 */     return originalAllowed ? original : convertedCopy;
/*     */   }
/*     */ 
/*     */   private String buildIndexedPropertyName(String propertyName, int index) {
/* 641 */     return propertyName != null ? new StringBuilder().append(propertyName).append("[").append(index).append("]").toString() : null;
/*     */   }
/*     */ 
/*     */   private String buildKeyedPropertyName(String propertyName, Object key)
/*     */   {
/* 647 */     return propertyName != null ? new StringBuilder().append(propertyName).append("[").append(key).append("]").toString() : null;
/*     */   }
/*     */ 
/*     */   private boolean canCreateCopy(Class<?> requiredType)
/*     */   {
/* 654 */     return (!requiredType.isInterface()) && (!Modifier.isAbstract(requiredType.getModifiers())) && 
/* 654 */       (Modifier.isPublic(requiredType
/* 654 */       .getModifiers())) && (ClassUtils.hasConstructor(requiredType, new Class[0]));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.TypeConverterDelegate
 * JD-Core Version:    0.6.2
 */