package org.springframework.beans.factory;

public abstract interface Aware
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.Aware
 * JD-Core Version:    0.6.2
 */