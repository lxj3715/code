/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class BeanFactoryUtils
/*     */ {
/*     */   public static final String GENERATED_BEAN_NAME_SEPARATOR = "#";
/*     */ 
/*     */   public static boolean isFactoryDereference(String name)
/*     */   {
/*  61 */     return (name != null) && (name.startsWith("&"));
/*     */   }
/*     */ 
/*     */   public static String transformedBeanName(String name)
/*     */   {
/*  72 */     Assert.notNull(name, "'name' must not be null");
/*  73 */     String beanName = name;
/*  74 */     while (beanName.startsWith("&")) {
/*  75 */       beanName = beanName.substring("&".length());
/*     */     }
/*  77 */     return beanName;
/*     */   }
/*     */ 
/*     */   public static boolean isGeneratedBeanName(String name)
/*     */   {
/*  90 */     return (name != null) && (name.contains("#"));
/*     */   }
/*     */ 
/*     */   public static String originalBeanName(String name)
/*     */   {
/* 101 */     Assert.notNull(name, "'name' must not be null");
/* 102 */     int separatorIndex = name.indexOf("#");
/* 103 */     return separatorIndex != -1 ? name.substring(0, separatorIndex) : name;
/*     */   }
/*     */ 
/*     */   public static int countBeansIncludingAncestors(ListableBeanFactory lbf)
/*     */   {
/* 116 */     return beanNamesIncludingAncestors(lbf).length;
/*     */   }
/*     */ 
/*     */   public static String[] beanNamesIncludingAncestors(ListableBeanFactory lbf)
/*     */   {
/* 126 */     return beanNamesForTypeIncludingAncestors(lbf, Object.class);
/*     */   }
/*     */ 
/*     */   public static String[] beanNamesForTypeIncludingAncestors(ListableBeanFactory lbf, Class<?> type)
/*     */   {
/* 143 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 144 */     String[] result = lbf.getBeanNamesForType(type);
/* 145 */     if ((lbf instanceof HierarchicalBeanFactory)) {
/* 146 */       HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 147 */       if ((hbf.getParentBeanFactory() instanceof ListableBeanFactory)) {
/* 148 */         String[] parentResult = beanNamesForTypeIncludingAncestors(
/* 149 */           (ListableBeanFactory)hbf
/* 149 */           .getParentBeanFactory(), type);
/* 150 */         List resultList = new ArrayList();
/* 151 */         resultList.addAll(Arrays.asList(result));
/* 152 */         for (String beanName : parentResult) {
/* 153 */           if ((!resultList.contains(beanName)) && (!hbf.containsLocalBean(beanName))) {
/* 154 */             resultList.add(beanName);
/*     */           }
/*     */         }
/* 157 */         result = StringUtils.toStringArray(resultList);
/*     */       }
/*     */     }
/* 160 */     return result;
/*     */   }
/*     */ 
/*     */   public static String[] beanNamesForTypeIncludingAncestors(ListableBeanFactory lbf, Class<?> type, boolean includeNonSingletons, boolean allowEagerInit)
/*     */   {
/* 186 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 187 */     String[] result = lbf.getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/* 188 */     if ((lbf instanceof HierarchicalBeanFactory)) {
/* 189 */       HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 190 */       if ((hbf.getParentBeanFactory() instanceof ListableBeanFactory)) {
/* 191 */         String[] parentResult = beanNamesForTypeIncludingAncestors(
/* 192 */           (ListableBeanFactory)hbf
/* 192 */           .getParentBeanFactory(), type, includeNonSingletons, allowEagerInit);
/* 193 */         List resultList = new ArrayList();
/* 194 */         resultList.addAll(Arrays.asList(result));
/* 195 */         for (String beanName : parentResult) {
/* 196 */           if ((!resultList.contains(beanName)) && (!hbf.containsLocalBean(beanName))) {
/* 197 */             resultList.add(beanName);
/*     */           }
/*     */         }
/* 200 */         result = StringUtils.toStringArray(resultList);
/*     */       }
/*     */     }
/* 203 */     return result;
/*     */   }
/*     */ 
/*     */   public static <T> Map<String, T> beansOfTypeIncludingAncestors(ListableBeanFactory lbf, Class<T> type)
/*     */     throws BeansException
/*     */   {
/* 226 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 227 */     Map result = new LinkedHashMap(4);
/* 228 */     result.putAll(lbf.getBeansOfType(type));
/*     */     HierarchicalBeanFactory hbf;
/* 229 */     if ((lbf instanceof HierarchicalBeanFactory)) {
/* 230 */       hbf = (HierarchicalBeanFactory)lbf;
/* 231 */       if ((hbf.getParentBeanFactory() instanceof ListableBeanFactory)) {
/* 232 */         Map parentResult = beansOfTypeIncludingAncestors(
/* 233 */           (ListableBeanFactory)hbf
/* 233 */           .getParentBeanFactory(), type);
/* 234 */         for (Map.Entry entry : parentResult.entrySet()) {
/* 235 */           String beanName = (String)entry.getKey();
/* 236 */           if ((!result.containsKey(beanName)) && (!hbf.containsLocalBean(beanName))) {
/* 237 */             result.put(beanName, entry.getValue());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 242 */     return result;
/*     */   }
/*     */ 
/*     */   public static <T> Map<String, T> beansOfTypeIncludingAncestors(ListableBeanFactory lbf, Class<T> type, boolean includeNonSingletons, boolean allowEagerInit)
/*     */     throws BeansException
/*     */   {
/* 275 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 276 */     Map result = new LinkedHashMap(4);
/* 277 */     result.putAll(lbf.getBeansOfType(type, includeNonSingletons, allowEagerInit));
/*     */     HierarchicalBeanFactory hbf;
/* 278 */     if ((lbf instanceof HierarchicalBeanFactory)) {
/* 279 */       hbf = (HierarchicalBeanFactory)lbf;
/* 280 */       if ((hbf.getParentBeanFactory() instanceof ListableBeanFactory)) {
/* 281 */         Map parentResult = beansOfTypeIncludingAncestors(
/* 282 */           (ListableBeanFactory)hbf
/* 282 */           .getParentBeanFactory(), type, includeNonSingletons, allowEagerInit);
/* 283 */         for (Map.Entry entry : parentResult.entrySet()) {
/* 284 */           String beanName = (String)entry.getKey();
/* 285 */           if ((!result.containsKey(beanName)) && (!hbf.containsLocalBean(beanName))) {
/* 286 */             result.put(beanName, entry.getValue());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 291 */     return result;
/*     */   }
/*     */ 
/*     */   public static <T> T beanOfTypeIncludingAncestors(ListableBeanFactory lbf, Class<T> type)
/*     */     throws BeansException
/*     */   {
/* 320 */     Map beansOfType = beansOfTypeIncludingAncestors(lbf, type);
/* 321 */     return uniqueBean(type, beansOfType);
/*     */   }
/*     */ 
/*     */   public static <T> T beanOfTypeIncludingAncestors(ListableBeanFactory lbf, Class<T> type, boolean includeNonSingletons, boolean allowEagerInit)
/*     */     throws BeansException
/*     */   {
/* 357 */     Map beansOfType = beansOfTypeIncludingAncestors(lbf, type, includeNonSingletons, allowEagerInit);
/* 358 */     return uniqueBean(type, beansOfType);
/*     */   }
/*     */ 
/*     */   public static <T> T beanOfType(ListableBeanFactory lbf, Class<T> type)
/*     */     throws BeansException
/*     */   {
/* 378 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 379 */     Map beansOfType = lbf.getBeansOfType(type);
/* 380 */     return uniqueBean(type, beansOfType);
/*     */   }
/*     */ 
/*     */   public static <T> T beanOfType(ListableBeanFactory lbf, Class<T> type, boolean includeNonSingletons, boolean allowEagerInit)
/*     */     throws BeansException
/*     */   {
/* 411 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 412 */     Map beansOfType = lbf.getBeansOfType(type, includeNonSingletons, allowEagerInit);
/* 413 */     return uniqueBean(type, beansOfType);
/*     */   }
/*     */ 
/*     */   private static <T> T uniqueBean(Class<T> type, Map<String, T> matchingBeans)
/*     */   {
/* 425 */     int nrFound = matchingBeans.size();
/* 426 */     if (nrFound == 1) {
/* 427 */       return matchingBeans.values().iterator().next();
/*     */     }
/* 429 */     if (nrFound > 1) {
/* 430 */       throw new NoUniqueBeanDefinitionException(type, matchingBeans.keySet());
/*     */     }
/*     */ 
/* 433 */     throw new NoSuchBeanDefinitionException(type);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.BeanFactoryUtils
 * JD-Core Version:    0.6.2
 */