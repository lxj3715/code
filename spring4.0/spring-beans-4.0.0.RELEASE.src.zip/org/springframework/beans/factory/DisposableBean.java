package org.springframework.beans.factory;

public abstract interface DisposableBean
{
  public abstract void destroy()
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.DisposableBean
 * JD-Core Version:    0.6.2
 */