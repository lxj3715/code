/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class NoSuchBeanDefinitionException extends BeansException
/*     */ {
/*     */   private String beanName;
/*     */   private Class<?> beanType;
/*     */ 
/*     */   public NoSuchBeanDefinitionException(String name)
/*     */   {
/*  46 */     super(new StringBuilder().append("No bean named '").append(name).append("' is defined").toString());
/*  47 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */   public NoSuchBeanDefinitionException(String name, String message)
/*     */   {
/*  56 */     super(new StringBuilder().append("No bean named '").append(name).append("' is defined: ").append(message).toString());
/*  57 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */   public NoSuchBeanDefinitionException(Class<?> type)
/*     */   {
/*  65 */     super(new StringBuilder().append("No qualifying bean of type [").append(type.getName()).append("] is defined").toString());
/*  66 */     this.beanType = type;
/*     */   }
/*     */ 
/*     */   public NoSuchBeanDefinitionException(Class<?> type, String message)
/*     */   {
/*  75 */     super(new StringBuilder().append("No qualifying bean of type [").append(type.getName()).append("] is defined: ").append(message).toString());
/*  76 */     this.beanType = type;
/*     */   }
/*     */ 
/*     */   public NoSuchBeanDefinitionException(Class<?> type, String dependencyDescription, String message)
/*     */   {
/*  86 */     super(new StringBuilder().append("No qualifying bean of type [").append(type.getName()).append("] found for dependency")
/*  87 */       .append(StringUtils.hasLength(dependencyDescription) ? 
/*  87 */       new StringBuilder().append(" [").append(dependencyDescription).append("]").toString() : "").append(": ").append(message).toString());
/*     */ 
/*  89 */     this.beanType = type;
/*     */   }
/*     */ 
/*     */   public String getBeanName()
/*     */   {
/*  97 */     return this.beanName;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 104 */     return this.beanType;
/*     */   }
/*     */ 
/*     */   public int getNumberOfBeansFound()
/*     */   {
/* 113 */     return 0;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.NoSuchBeanDefinitionException
 * JD-Core Version:    0.6.2
 */