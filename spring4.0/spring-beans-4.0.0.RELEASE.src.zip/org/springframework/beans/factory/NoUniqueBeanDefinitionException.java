/*    */ package org.springframework.beans.factory;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class NoUniqueBeanDefinitionException extends NoSuchBeanDefinitionException
/*    */ {
/*    */   private int numberOfBeansFound;
/*    */ 
/*    */   public NoUniqueBeanDefinitionException(Class<?> type, int numberOfBeansFound, String message)
/*    */   {
/* 45 */     super(type, message);
/* 46 */     this.numberOfBeansFound = numberOfBeansFound;
/*    */   }
/*    */ 
/*    */   public NoUniqueBeanDefinitionException(Class<?> type, Collection<String> beanNamesFound)
/*    */   {
/* 55 */     this(type, beanNamesFound.size(), "expected single matching bean but found " + beanNamesFound.size() + ": " + 
/* 56 */       StringUtils.collectionToCommaDelimitedString(beanNamesFound));
/*    */   }
/*    */ 
/*    */   public NoUniqueBeanDefinitionException(Class<?> type, String[] beanNamesFound)
/*    */   {
/* 65 */     this(type, Arrays.asList(beanNamesFound));
/*    */   }
/*    */ 
/*    */   public int getNumberOfBeansFound()
/*    */   {
/* 76 */     return this.numberOfBeansFound;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.NoUniqueBeanDefinitionException
 * JD-Core Version:    0.6.2
 */