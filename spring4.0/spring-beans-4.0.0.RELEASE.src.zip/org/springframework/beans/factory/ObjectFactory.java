package org.springframework.beans.factory;

import org.springframework.beans.BeansException;

public abstract interface ObjectFactory<T>
{
  public abstract T getObject()
    throws BeansException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.ObjectFactory
 * JD-Core Version:    0.6.2
 */