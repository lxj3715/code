package org.springframework.beans.factory;

public abstract interface SmartFactoryBean<T> extends FactoryBean<T>
{
  public abstract boolean isPrototype();

  public abstract boolean isEagerInit();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.SmartFactoryBean
 * JD-Core Version:    0.6.2
 */