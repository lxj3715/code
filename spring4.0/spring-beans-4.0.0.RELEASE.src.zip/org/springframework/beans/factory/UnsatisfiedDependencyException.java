/*    */ package org.springframework.beans.factory;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class UnsatisfiedDependencyException extends BeanCreationException
/*    */ {
/*    */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, String propertyName, String msg)
/*    */   {
/* 44 */     super(resourceDescription, beanName, new StringBuilder().append("Unsatisfied dependency expressed through bean property '").append(propertyName).append("'").append(msg != null ? new StringBuilder().append(": ").append(msg).toString() : "").toString());
/*    */   }
/*    */ 
/*    */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, String propertyName, BeansException ex)
/*    */   {
/* 59 */     this(resourceDescription, beanName, propertyName, ex != null ? new StringBuilder().append(": ").append(ex.getMessage()).toString() : "");
/* 60 */     initCause(ex);
/*    */   }
/*    */ 
/*    */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, int ctorArgIndex, Class<?> ctorArgType, String msg)
/*    */   {
/* 74 */     super(resourceDescription, beanName, new StringBuilder().append("Unsatisfied dependency expressed through constructor argument with index ").append(ctorArgIndex).append(" of type [")
/* 76 */       .append(ClassUtils.getQualifiedName(ctorArgType))
/* 76 */       .append("]").append(msg != null ? new StringBuilder().append(": ").append(msg).toString() : "").toString());
/*    */   }
/*    */ 
/*    */   public UnsatisfiedDependencyException(String resourceDescription, String beanName, int ctorArgIndex, Class<?> ctorArgType, BeansException ex)
/*    */   {
/* 91 */     this(resourceDescription, beanName, ctorArgIndex, ctorArgType, ex != null ? new StringBuilder().append(": ").append(ex.getMessage()).toString() : "");
/* 92 */     initCause(ex);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.UnsatisfiedDependencyException
 * JD-Core Version:    0.6.2
 */