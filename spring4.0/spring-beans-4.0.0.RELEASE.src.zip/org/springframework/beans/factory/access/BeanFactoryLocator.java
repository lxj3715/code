package org.springframework.beans.factory.access;

import org.springframework.beans.BeansException;

public abstract interface BeanFactoryLocator
{
  public abstract BeanFactoryReference useBeanFactory(String paramString)
    throws BeansException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.access.BeanFactoryLocator
 * JD-Core Version:    0.6.2
 */