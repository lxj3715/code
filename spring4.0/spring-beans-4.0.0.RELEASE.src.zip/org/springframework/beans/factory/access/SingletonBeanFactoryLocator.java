/*     */ package org.springframework.beans.factory.access;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ 
/*     */ public class SingletonBeanFactoryLocator
/*     */   implements BeanFactoryLocator
/*     */ {
/*     */   private static final String DEFAULT_RESOURCE_LOCATION = "classpath*:beanRefFactory.xml";
/* 274 */   protected static final Log logger = LogFactory.getLog(SingletonBeanFactoryLocator.class);
/*     */ 
/* 277 */   private static final Map<String, BeanFactoryLocator> instances = new HashMap();
/*     */ 
/* 335 */   private final Map<String, BeanFactoryGroup> bfgInstancesByKey = new HashMap();
/*     */ 
/* 337 */   private final Map<BeanFactory, BeanFactoryGroup> bfgInstancesByObj = new HashMap();
/*     */   private final String resourceLocation;
/*     */ 
/*     */   public static BeanFactoryLocator getInstance()
/*     */     throws BeansException
/*     */   {
/* 289 */     return getInstance(null);
/*     */   }
/*     */ 
/*     */   public static BeanFactoryLocator getInstance(String selector)
/*     */     throws BeansException
/*     */   {
/* 308 */     String resourceLocation = selector;
/* 309 */     if (resourceLocation == null) {
/* 310 */       resourceLocation = "classpath*:beanRefFactory.xml";
/*     */     }
/*     */ 
/* 315 */     if (!ResourcePatternUtils.isUrl(resourceLocation)) {
/* 316 */       resourceLocation = "classpath*:" + resourceLocation;
/*     */     }
/*     */ 
/* 319 */     synchronized (instances) {
/* 320 */       if (logger.isTraceEnabled()) {
/* 321 */         logger.trace("SingletonBeanFactoryLocator.getInstance(): instances.hashCode=" + instances
/* 322 */           .hashCode() + ", instances=" + instances);
/*     */       }
/* 324 */       BeanFactoryLocator bfl = (BeanFactoryLocator)instances.get(resourceLocation);
/* 325 */       if (bfl == null) {
/* 326 */         bfl = new SingletonBeanFactoryLocator(resourceLocation);
/* 327 */         instances.put(resourceLocation, bfl);
/*     */       }
/* 329 */       return bfl;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected SingletonBeanFactoryLocator(String resourceLocation)
/*     */   {
/* 349 */     this.resourceLocation = resourceLocation;
/*     */   }
/*     */ 
/*     */   public BeanFactoryReference useBeanFactory(String factoryKey) throws BeansException
/*     */   {
/* 354 */     synchronized (this.bfgInstancesByKey) {
/* 355 */       BeanFactoryGroup bfg = (BeanFactoryGroup)this.bfgInstancesByKey.get(this.resourceLocation);
/*     */ 
/* 357 */       if (bfg != null) {
/* 358 */         BeanFactoryGroup.access$008(bfg);
/*     */       }
/*     */       else
/*     */       {
/* 362 */         if (logger.isTraceEnabled()) {
/* 363 */           logger.trace("Factory group with resource name [" + this.resourceLocation + "] requested. Creating new instance.");
/*     */         }
/*     */ 
/* 368 */         BeanFactory groupContext = createDefinition(this.resourceLocation, factoryKey);
/*     */ 
/* 371 */         bfg = new BeanFactoryGroup(null);
/* 372 */         bfg.definition = groupContext;
/* 373 */         bfg.refCount = 1;
/* 374 */         this.bfgInstancesByKey.put(this.resourceLocation, bfg);
/* 375 */         this.bfgInstancesByObj.put(groupContext, bfg);
/*     */         try
/*     */         {
/* 382 */           initializeDefinition(groupContext);
/*     */         }
/*     */         catch (BeansException ex) {
/* 385 */           this.bfgInstancesByKey.remove(this.resourceLocation);
/* 386 */           this.bfgInstancesByObj.remove(groupContext);
/* 387 */           throw new BootstrapException("Unable to initialize group definition. Group resource name [" + this.resourceLocation + "], factory key [" + factoryKey + "]", ex);
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/*     */         BeanFactory beanFactory;
/*     */         BeanFactory beanFactory;
/* 394 */         if (factoryKey != null) {
/* 395 */           beanFactory = (BeanFactory)bfg.definition.getBean(factoryKey, BeanFactory.class);
/*     */         }
/*     */         else {
/* 398 */           beanFactory = (BeanFactory)bfg.definition.getBean(BeanFactory.class);
/*     */         }
/* 400 */         return new CountingBeanFactoryReference(beanFactory, bfg.definition);
/*     */       }
/*     */       catch (BeansException ex) {
/* 403 */         throw new BootstrapException("Unable to return specified BeanFactory instance: factory key [" + factoryKey + "], from group with resource name [" + this.resourceLocation + "]", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected BeanFactory createDefinition(String resourceLocation, String factoryKey)
/*     */   {
/* 427 */     DefaultListableBeanFactory factory = new DefaultListableBeanFactory();
/* 428 */     XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(factory);
/* 429 */     ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
/*     */     try
/*     */     {
/* 432 */       Resource[] configResources = resourcePatternResolver.getResources(resourceLocation);
/* 433 */       if (configResources.length == 0) {
/* 434 */         throw new FatalBeanException("Unable to find resource for specified definition. Group resource name [" + this.resourceLocation + "], factory key [" + factoryKey + "]");
/*     */       }
/*     */ 
/* 437 */       reader.loadBeanDefinitions(configResources);
/*     */     }
/*     */     catch (IOException ex) {
/* 440 */       throw new BeanDefinitionStoreException("Error accessing bean definition resource [" + this.resourceLocation + "]", ex);
/*     */     }
/*     */     catch (BeanDefinitionStoreException ex)
/*     */     {
/* 444 */       throw new FatalBeanException("Unable to load group definition: group resource name [" + this.resourceLocation + "], factory key [" + factoryKey + "]", ex);
/*     */     }
/*     */ 
/* 448 */     return factory;
/*     */   }
/*     */ 
/*     */   protected void initializeDefinition(BeanFactory groupDef)
/*     */   {
/* 458 */     if ((groupDef instanceof ConfigurableListableBeanFactory))
/* 459 */       ((ConfigurableListableBeanFactory)groupDef).preInstantiateSingletons();
/*     */   }
/*     */ 
/*     */   protected void destroyDefinition(BeanFactory groupDef, String selector)
/*     */   {
/* 469 */     if ((groupDef instanceof ConfigurableBeanFactory)) {
/* 470 */       if (logger.isTraceEnabled()) {
/* 471 */         logger.trace("Factory group with selector '" + selector + "' being released, as there are no more references to it");
/*     */       }
/*     */ 
/* 474 */       ((ConfigurableBeanFactory)groupDef).destroySingletons();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class CountingBeanFactoryReference
/*     */     implements BeanFactoryReference
/*     */   {
/*     */     private BeanFactory beanFactory;
/*     */     private BeanFactory groupContextRef;
/*     */ 
/*     */     public CountingBeanFactoryReference(BeanFactory beanFactory, BeanFactory groupContext)
/*     */     {
/* 500 */       this.beanFactory = beanFactory;
/* 501 */       this.groupContextRef = groupContext;
/*     */     }
/*     */ 
/*     */     public BeanFactory getFactory()
/*     */     {
/* 506 */       return this.beanFactory;
/*     */     }
/*     */ 
/*     */     public void release()
/*     */       throws FatalBeanException
/*     */     {
/* 512 */       synchronized (SingletonBeanFactoryLocator.this.bfgInstancesByKey) {
/* 513 */         BeanFactory savedRef = this.groupContextRef;
/* 514 */         if (savedRef != null) {
/* 515 */           this.groupContextRef = null;
/* 516 */           SingletonBeanFactoryLocator.BeanFactoryGroup bfg = (SingletonBeanFactoryLocator.BeanFactoryGroup)SingletonBeanFactoryLocator.this.bfgInstancesByObj.get(savedRef);
/* 517 */           if (bfg != null) {
/* 518 */             SingletonBeanFactoryLocator.BeanFactoryGroup.access$010(bfg);
/* 519 */             if (SingletonBeanFactoryLocator.BeanFactoryGroup.access$000(bfg) == 0) {
/* 520 */               SingletonBeanFactoryLocator.this.destroyDefinition(savedRef, SingletonBeanFactoryLocator.this.resourceLocation);
/* 521 */               SingletonBeanFactoryLocator.this.bfgInstancesByKey.remove(SingletonBeanFactoryLocator.this.resourceLocation);
/* 522 */               SingletonBeanFactoryLocator.this.bfgInstancesByObj.remove(savedRef);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 527 */             SingletonBeanFactoryLocator.logger.warn("Tried to release a SingletonBeanFactoryLocator group definition more times than it has actually been used. Resource name [" + SingletonBeanFactoryLocator.this.resourceLocation + 
/* 528 */               "]");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BeanFactoryGroup
/*     */   {
/*     */     private BeanFactory definition;
/* 486 */     private int refCount = 0;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.access.SingletonBeanFactoryLocator
 * JD-Core Version:    0.6.2
 */