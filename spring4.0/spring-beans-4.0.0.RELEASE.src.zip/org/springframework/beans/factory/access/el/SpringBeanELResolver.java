/*     */ package org.springframework.beans.factory.access.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.Iterator;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ELResolver;
/*     */ import javax.el.PropertyNotWritableException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ 
/*     */ public abstract class SpringBeanELResolver extends ELResolver
/*     */ {
/*  43 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   public Object getValue(ELContext elContext, Object base, Object property)
/*     */     throws ELException
/*     */   {
/*  48 */     if (base == null) {
/*  49 */       String beanName = property.toString();
/*  50 */       BeanFactory bf = getBeanFactory(elContext);
/*  51 */       if (bf.containsBean(beanName)) {
/*  52 */         if (this.logger.isTraceEnabled()) {
/*  53 */           this.logger.trace("Successfully resolved variable '" + beanName + "' in Spring BeanFactory");
/*     */         }
/*  55 */         elContext.setPropertyResolved(true);
/*  56 */         return bf.getBean(beanName);
/*     */       }
/*     */     }
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> getType(ELContext elContext, Object base, Object property) throws ELException
/*     */   {
/*  64 */     if (base == null) {
/*  65 */       String beanName = property.toString();
/*  66 */       BeanFactory bf = getBeanFactory(elContext);
/*  67 */       if (bf.containsBean(beanName)) {
/*  68 */         elContext.setPropertyResolved(true);
/*  69 */         return bf.getType(beanName);
/*     */       }
/*     */     }
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */   public void setValue(ELContext elContext, Object base, Object property, Object value) throws ELException
/*     */   {
/*  77 */     if (base == null) {
/*  78 */       String beanName = property.toString();
/*  79 */       BeanFactory bf = getBeanFactory(elContext);
/*  80 */       if (bf.containsBean(beanName))
/*  81 */         throw new PropertyNotWritableException("Variable '" + beanName + "' refers to a Spring bean which by definition is not writable");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly(ELContext elContext, Object base, Object property)
/*     */     throws ELException
/*     */   {
/*  89 */     if (base == null) {
/*  90 */       String beanName = property.toString();
/*  91 */       BeanFactory bf = getBeanFactory(elContext);
/*  92 */       if (bf.containsBean(beanName)) {
/*  93 */         return true;
/*     */       }
/*     */     }
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext elContext, Object base)
/*     */   {
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> getCommonPropertyType(ELContext elContext, Object base)
/*     */   {
/* 106 */     return Object.class;
/*     */   }
/*     */ 
/*     */   protected abstract BeanFactory getBeanFactory(ELContext paramELContext);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.access.el.SpringBeanELResolver
 * JD-Core Version:    0.6.2
 */