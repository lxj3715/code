package org.springframework.beans.factory.annotation;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.core.type.AnnotationMetadata;

public abstract interface AnnotatedBeanDefinition extends BeanDefinition
{
  public abstract AnnotationMetadata getMetadata();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.annotation.AnnotatedBeanDefinition
 * JD-Core Version:    0.6.2
 */