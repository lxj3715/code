/*    */ package org.springframework.beans.factory.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.StandardAnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AnnotatedGenericBeanDefinition extends GenericBeanDefinition
/*    */   implements AnnotatedBeanDefinition
/*    */ {
/*    */   private final AnnotationMetadata metadata;
/*    */ 
/*    */   public AnnotatedGenericBeanDefinition(Class<?> beanClass)
/*    */   {
/* 52 */     setBeanClass(beanClass);
/* 53 */     this.metadata = new StandardAnnotationMetadata(beanClass, true);
/*    */   }
/*    */ 
/*    */   public AnnotatedGenericBeanDefinition(AnnotationMetadata metadata)
/*    */   {
/* 67 */     Assert.notNull(metadata, "AnnotationMetadata must not be null");
/* 68 */     if ((metadata instanceof StandardAnnotationMetadata)) {
/* 69 */       setBeanClass(((StandardAnnotationMetadata)metadata).getIntrospectedClass());
/*    */     }
/*    */     else {
/* 72 */       setBeanClassName(metadata.getClassName());
/*    */     }
/* 74 */     this.metadata = metadata;
/*    */   }
/*    */ 
/*    */   public final AnnotationMetadata getMetadata()
/*    */   {
/* 80 */     return this.metadata;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition
 * JD-Core Version:    0.6.2
 */