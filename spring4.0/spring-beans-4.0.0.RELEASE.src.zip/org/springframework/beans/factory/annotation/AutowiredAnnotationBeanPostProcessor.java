/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AutowiredAnnotationBeanPostProcessor extends InstantiationAwareBeanPostProcessorAdapter
/*     */   implements MergedBeanDefinitionPostProcessor, PriorityOrdered, BeanFactoryAware
/*     */ {
/* 109 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/* 111 */   private final Set<Class<? extends Annotation>> autowiredAnnotationTypes = new LinkedHashSet();
/*     */ 
/* 114 */   private String requiredParameterName = "required";
/*     */ 
/* 116 */   private boolean requiredParameterValue = true;
/*     */ 
/* 118 */   private int order = 2147483645;
/*     */   private ConfigurableListableBeanFactory beanFactory;
/* 122 */   private final Map<Class<?>, Constructor<?>[]> candidateConstructorsCache = new ConcurrentHashMap(64);
/*     */ 
/* 125 */   private final Map<String, InjectionMetadata> injectionMetadataCache = new ConcurrentHashMap(64);
/*     */ 
/*     */   public AutowiredAnnotationBeanPostProcessor()
/*     */   {
/* 136 */     this.autowiredAnnotationTypes.add(Autowired.class);
/* 137 */     this.autowiredAnnotationTypes.add(Value.class);
/* 138 */     ClassLoader cl = AutowiredAnnotationBeanPostProcessor.class.getClassLoader();
/*     */     try {
/* 140 */       this.autowiredAnnotationTypes.add(cl.loadClass("javax.inject.Inject"));
/* 141 */       this.logger.info("JSR-330 'javax.inject.Inject' annotation found and supported for autowiring");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAutowiredAnnotationType(Class<? extends Annotation> autowiredAnnotationType)
/*     */   {
/* 159 */     Assert.notNull(autowiredAnnotationType, "'autowiredAnnotationType' must not be null");
/* 160 */     this.autowiredAnnotationTypes.clear();
/* 161 */     this.autowiredAnnotationTypes.add(autowiredAnnotationType);
/*     */   }
/*     */ 
/*     */   public void setAutowiredAnnotationTypes(Set<Class<? extends Annotation>> autowiredAnnotationTypes)
/*     */   {
/* 174 */     Assert.notEmpty(autowiredAnnotationTypes, "'autowiredAnnotationTypes' must not be empty");
/* 175 */     this.autowiredAnnotationTypes.clear();
/* 176 */     this.autowiredAnnotationTypes.addAll(autowiredAnnotationTypes);
/*     */   }
/*     */ 
/*     */   public void setRequiredParameterName(String requiredParameterName)
/*     */   {
/* 185 */     this.requiredParameterName = requiredParameterName;
/*     */   }
/*     */ 
/*     */   public void setRequiredParameterValue(boolean requiredParameterValue)
/*     */   {
/* 196 */     this.requiredParameterValue = requiredParameterValue;
/*     */   }
/*     */ 
/*     */   public void setOrder(int order) {
/* 200 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 205 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/* 210 */     if (!(beanFactory instanceof ConfigurableListableBeanFactory)) {
/* 211 */       throw new IllegalArgumentException("AutowiredAnnotationBeanPostProcessor requires a ConfigurableListableBeanFactory");
/*     */     }
/*     */ 
/* 214 */     this.beanFactory = ((ConfigurableListableBeanFactory)beanFactory);
/*     */   }
/*     */ 
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName)
/*     */   {
/* 220 */     if (beanType != null) {
/* 221 */       InjectionMetadata metadata = findAutowiringMetadata(beanName, beanType);
/* 222 */       metadata.checkConfigMembers(beanDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Constructor<?>[] determineCandidateConstructors(Class<?> beanClass, String beanName)
/*     */     throws BeansException
/*     */   {
/* 229 */     Constructor[] candidateConstructors = (Constructor[])this.candidateConstructorsCache.get(beanClass);
/* 230 */     if (candidateConstructors == null) {
/* 231 */       synchronized (this.candidateConstructorsCache) {
/* 232 */         candidateConstructors = (Constructor[])this.candidateConstructorsCache.get(beanClass);
/* 233 */         if (candidateConstructors == null) {
/* 234 */           Constructor[] rawCandidates = beanClass.getDeclaredConstructors();
/* 235 */           List candidates = new ArrayList(rawCandidates.length);
/* 236 */           Constructor requiredConstructor = null;
/* 237 */           Constructor defaultConstructor = null;
/* 238 */           for (Constructor candidate : rawCandidates) {
/* 239 */             AnnotationAttributes annotation = findAutowiredAnnotation(candidate);
/* 240 */             if (annotation != null) {
/* 241 */               if (requiredConstructor != null) {
/* 242 */                 throw new BeanCreationException("Invalid autowire-marked constructor: " + candidate + ". Found another constructor with 'required' Autowired annotation: " + requiredConstructor);
/*     */               }
/*     */ 
/* 246 */               if (candidate.getParameterTypes().length == 0) {
/* 247 */                 throw new IllegalStateException("Autowired annotation requires at least one argument: " + candidate);
/*     */               }
/*     */ 
/* 250 */               boolean required = determineRequiredStatus(annotation);
/* 251 */               if (required) {
/* 252 */                 if (!candidates.isEmpty()) {
/* 253 */                   throw new BeanCreationException("Invalid autowire-marked constructors: " + candidates + ". Found another constructor with 'required' Autowired annotation: " + requiredConstructor);
/*     */                 }
/*     */ 
/* 258 */                 requiredConstructor = candidate;
/*     */               }
/* 260 */               candidates.add(candidate);
/*     */             }
/* 262 */             else if (candidate.getParameterTypes().length == 0) {
/* 263 */               defaultConstructor = candidate;
/*     */             }
/*     */           }
/* 266 */           if (!candidates.isEmpty())
/*     */           {
/* 268 */             if ((requiredConstructor == null) && (defaultConstructor != null)) {
/* 269 */               candidates.add(defaultConstructor);
/*     */             }
/* 271 */             candidateConstructors = (Constructor[])candidates.toArray(new Constructor[candidates.size()]);
/*     */           }
/*     */           else {
/* 274 */             candidateConstructors = new Constructor[0];
/*     */           }
/* 276 */           this.candidateConstructorsCache.put(beanClass, candidateConstructors);
/*     */         }
/*     */       }
/*     */     }
/* 280 */     return candidateConstructors.length > 0 ? candidateConstructors : null;
/*     */   }
/*     */ 
/*     */   public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 287 */     InjectionMetadata metadata = findAutowiringMetadata(beanName, bean.getClass());
/*     */     try {
/* 289 */       metadata.inject(bean, beanName, pvs);
/*     */     }
/*     */     catch (Throwable ex) {
/* 292 */       throw new BeanCreationException(beanName, "Injection of autowired dependencies failed", ex);
/*     */     }
/* 294 */     return pvs;
/*     */   }
/*     */ 
/*     */   public void processInjection(Object bean)
/*     */     throws BeansException
/*     */   {
/* 304 */     Class clazz = bean.getClass();
/* 305 */     InjectionMetadata metadata = findAutowiringMetadata(clazz.getName(), clazz);
/*     */     try {
/* 307 */       metadata.inject(bean, null, null);
/*     */     }
/*     */     catch (Throwable ex) {
/* 310 */       throw new BeanCreationException("Injection of autowired dependencies failed for class [" + clazz + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private InjectionMetadata findAutowiringMetadata(String beanName, Class<?> clazz)
/*     */   {
/* 318 */     String cacheKey = StringUtils.hasLength(beanName) ? beanName : clazz.getName();
/* 319 */     InjectionMetadata metadata = (InjectionMetadata)this.injectionMetadataCache.get(cacheKey);
/* 320 */     if (metadata == null) {
/* 321 */       synchronized (this.injectionMetadataCache) {
/* 322 */         metadata = (InjectionMetadata)this.injectionMetadataCache.get(cacheKey);
/* 323 */         if (metadata == null) {
/* 324 */           metadata = buildAutowiringMetadata(clazz);
/* 325 */           this.injectionMetadataCache.put(cacheKey, metadata);
/*     */         }
/*     */       }
/*     */     }
/* 329 */     return metadata;
/*     */   }
/*     */ 
/*     */   private InjectionMetadata buildAutowiringMetadata(Class<?> clazz) {
/* 333 */     LinkedList elements = new LinkedList();
/* 334 */     Class targetClass = clazz;
/*     */     do
/*     */     {
/* 337 */       LinkedList currElements = new LinkedList();
/* 338 */       for (Field field : targetClass.getDeclaredFields()) {
/* 339 */         AnnotationAttributes annotation = findAutowiredAnnotation(field);
/* 340 */         if (annotation != null)
/* 341 */           if (Modifier.isStatic(field.getModifiers())) {
/* 342 */             if (this.logger.isWarnEnabled())
/* 343 */               this.logger.warn("Autowired annotation is not supported on static fields: " + field);
/*     */           }
/*     */           else
/*     */           {
/* 347 */             boolean required = determineRequiredStatus(annotation);
/* 348 */             currElements.add(new AutowiredFieldElement(field, required));
/*     */           }
/*     */       }
/* 351 */       for (Method method : targetClass.getDeclaredMethods()) {
/* 352 */         Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*     */ 
/* 354 */         AnnotationAttributes annotation = BridgeMethodResolver.isVisibilityBridgeMethodPair(method, bridgedMethod) ? 
/* 354 */           findAutowiredAnnotation(bridgedMethod) : 
/* 354 */           findAutowiredAnnotation(method);
/* 355 */         if ((annotation != null) && (method.equals(ClassUtils.getMostSpecificMethod(method, clazz))))
/* 356 */           if (Modifier.isStatic(method.getModifiers())) {
/* 357 */             if (this.logger.isWarnEnabled())
/* 358 */               this.logger.warn("Autowired annotation is not supported on static methods: " + method);
/*     */           }
/*     */           else
/*     */           {
/* 362 */             if ((method.getParameterTypes().length == 0) && 
/* 363 */               (this.logger.isWarnEnabled())) {
/* 364 */               this.logger.warn("Autowired annotation should be used on methods with actual parameters: " + method);
/*     */             }
/*     */ 
/* 367 */             boolean required = determineRequiredStatus(annotation);
/* 368 */             PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 369 */             currElements.add(new AutowiredMethodElement(method, required, pd));
/*     */           }
/*     */       }
/* 372 */       elements.addAll(0, currElements);
/* 373 */       targetClass = targetClass.getSuperclass();
/*     */     }
/* 375 */     while ((targetClass != null) && (targetClass != Object.class));
/*     */ 
/* 377 */     return new InjectionMetadata(clazz, elements);
/*     */   }
/*     */ 
/*     */   private AnnotationAttributes findAutowiredAnnotation(AccessibleObject ao) {
/* 381 */     for (Class type : this.autowiredAnnotationTypes) {
/* 382 */       AnnotationAttributes annotation = AnnotatedElementUtils.getAnnotationAttributes(ao, type.getName());
/* 383 */       if (annotation != null) {
/* 384 */         return annotation;
/*     */       }
/*     */     }
/* 387 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean determineRequiredStatus(AnnotationAttributes annotation)
/*     */   {
/* 400 */     return (!annotation.containsKey(this.requiredParameterName)) || 
/* 400 */       (this.requiredParameterValue == annotation
/* 400 */       .getBoolean(this.requiredParameterName));
/*     */   }
/*     */ 
/*     */   protected <T> Map<String, T> findAutowireCandidates(Class<T> type)
/*     */     throws BeansException
/*     */   {
/* 410 */     if (this.beanFactory == null) {
/* 411 */       throw new IllegalStateException("No BeanFactory configured - override the getBeanOfType method or specify the 'beanFactory' property");
/*     */     }
/*     */ 
/* 414 */     return BeanFactoryUtils.beansOfTypeIncludingAncestors(this.beanFactory, type);
/*     */   }
/*     */ 
/*     */   private void registerDependentBeans(String beanName, Set<String> autowiredBeanNames)
/*     */   {
/* 421 */     if (beanName != null)
/* 422 */       for (String autowiredBeanName : autowiredBeanNames) {
/* 423 */         if (this.beanFactory.containsBean(autowiredBeanName)) {
/* 424 */           this.beanFactory.registerDependentBean(autowiredBeanName, beanName);
/*     */         }
/* 426 */         if (this.logger.isDebugEnabled())
/* 427 */           this.logger.debug("Autowiring by type from bean name '" + beanName + "' to bean named '" + autowiredBeanName + "'");
/*     */       }
/*     */   }
/*     */ 
/*     */   private Object resolvedCachedArgument(String beanName, Object cachedArgument)
/*     */   {
/* 438 */     if ((cachedArgument instanceof DependencyDescriptor)) {
/* 439 */       DependencyDescriptor descriptor = (DependencyDescriptor)cachedArgument;
/* 440 */       return this.beanFactory.resolveDependency(descriptor, beanName, null, null);
/*     */     }
/* 442 */     if ((cachedArgument instanceof RuntimeBeanReference)) {
/* 443 */       return this.beanFactory.getBean(((RuntimeBeanReference)cachedArgument).getBeanName());
/*     */     }
/*     */ 
/* 446 */     return cachedArgument;
/*     */   }
/*     */ 
/*     */   private class AutowiredMethodElement extends InjectionMetadata.InjectedElement
/*     */   {
/*     */     private final boolean required;
/* 521 */     private volatile boolean cached = false;
/*     */     private volatile Object[] cachedMethodArguments;
/*     */ 
/*     */     public AutowiredMethodElement(Method method, boolean required, PropertyDescriptor pd)
/*     */     {
/* 526 */       super(pd);
/* 527 */       this.required = required;
/*     */     }
/*     */ 
/*     */     protected void inject(Object bean, String beanName, PropertyValues pvs) throws Throwable
/*     */     {
/* 532 */       if (checkPropertySkipping(pvs)) {
/* 533 */         return;
/*     */       }
/* 535 */       Method method = (Method)this.member;
/*     */       try
/*     */       {
/*     */         Object[] arguments;
/*     */         Object[] arguments;
/* 538 */         if (this.cached)
/*     */         {
/* 540 */           arguments = resolveCachedArguments(beanName);
/*     */         }
/*     */         else {
/* 543 */           Class[] paramTypes = method.getParameterTypes();
/* 544 */           arguments = new Object[paramTypes.length];
/* 545 */           DependencyDescriptor[] descriptors = new DependencyDescriptor[paramTypes.length];
/* 546 */           Set autowiredBeanNames = new LinkedHashSet(paramTypes.length);
/* 547 */           TypeConverter typeConverter = AutowiredAnnotationBeanPostProcessor.this.beanFactory.getTypeConverter();
/* 548 */           for (int i = 0; i < arguments.length; i++) {
/* 549 */             MethodParameter methodParam = new MethodParameter(method, i);
/* 550 */             DependencyDescriptor desc = new DependencyDescriptor(methodParam, this.required);
/* 551 */             desc.setContainingClass(bean.getClass());
/* 552 */             descriptors[i] = desc;
/* 553 */             Object arg = AutowiredAnnotationBeanPostProcessor.this.beanFactory.resolveDependency(desc, beanName, autowiredBeanNames, typeConverter);
/* 554 */             if ((arg == null) && (!this.required)) {
/* 555 */               arguments = null;
/* 556 */               break;
/*     */             }
/* 558 */             arguments[i] = arg;
/*     */           }
/* 560 */           synchronized (this) {
/* 561 */             if (!this.cached) {
/* 562 */               if (arguments != null) {
/* 563 */                 this.cachedMethodArguments = new Object[arguments.length];
/* 564 */                 for (int i = 0; i < arguments.length; i++) {
/* 565 */                   this.cachedMethodArguments[i] = descriptors[i];
/*     */                 }
/* 567 */                 AutowiredAnnotationBeanPostProcessor.this.registerDependentBeans(beanName, autowiredBeanNames);
/* 568 */                 if (autowiredBeanNames.size() == paramTypes.length) {
/* 569 */                   Iterator it = autowiredBeanNames.iterator();
/* 570 */                   for (int i = 0; i < paramTypes.length; i++) {
/* 571 */                     String autowiredBeanName = (String)it.next();
/* 572 */                     if ((AutowiredAnnotationBeanPostProcessor.this.beanFactory.containsBean(autowiredBeanName)) && 
/* 573 */                       (AutowiredAnnotationBeanPostProcessor.this.beanFactory.isTypeMatch(autowiredBeanName, paramTypes[i]))) {
/* 574 */                       this.cachedMethodArguments[i] = new RuntimeBeanReference(autowiredBeanName);
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */               else
/*     */               {
/* 581 */                 this.cachedMethodArguments = null;
/*     */               }
/* 583 */               this.cached = true;
/*     */             }
/*     */           }
/*     */         }
/* 587 */         if (arguments != null) {
/* 588 */           ReflectionUtils.makeAccessible(method);
/* 589 */           method.invoke(bean, arguments);
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 593 */         throw ex.getTargetException();
/*     */       }
/*     */       catch (Throwable ex) {
/* 596 */         throw new BeanCreationException("Could not autowire method: " + method, ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     private Object[] resolveCachedArguments(String beanName) {
/* 601 */       if (this.cachedMethodArguments == null) {
/* 602 */         return null;
/*     */       }
/* 604 */       Object[] arguments = new Object[this.cachedMethodArguments.length];
/* 605 */       for (int i = 0; i < arguments.length; i++) {
/* 606 */         arguments[i] = AutowiredAnnotationBeanPostProcessor.this.resolvedCachedArgument(beanName, this.cachedMethodArguments[i]);
/*     */       }
/* 608 */       return arguments;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AutowiredFieldElement extends InjectionMetadata.InjectedElement
/*     */   {
/*     */     private final boolean required;
/* 458 */     private volatile boolean cached = false;
/*     */     private volatile Object cachedFieldValue;
/*     */ 
/*     */     public AutowiredFieldElement(Field field, boolean required)
/*     */     {
/* 463 */       super(null);
/* 464 */       this.required = required;
/*     */     }
/*     */ 
/*     */     protected void inject(Object bean, String beanName, PropertyValues pvs) throws Throwable
/*     */     {
/* 469 */       Field field = (Field)this.member;
/*     */       try
/*     */       {
/*     */         Object value;
/*     */         Object value;
/* 472 */         if (this.cached) {
/* 473 */           value = AutowiredAnnotationBeanPostProcessor.this.resolvedCachedArgument(beanName, this.cachedFieldValue);
/*     */         }
/*     */         else {
/* 476 */           DependencyDescriptor desc = new DependencyDescriptor(field, this.required);
/* 477 */           desc.setContainingClass(bean.getClass());
/* 478 */           Set autowiredBeanNames = new LinkedHashSet(1);
/* 479 */           TypeConverter typeConverter = AutowiredAnnotationBeanPostProcessor.this.beanFactory.getTypeConverter();
/* 480 */           value = AutowiredAnnotationBeanPostProcessor.this.beanFactory.resolveDependency(desc, beanName, autowiredBeanNames, typeConverter);
/* 481 */           synchronized (this) {
/* 482 */             if (!this.cached) {
/* 483 */               if ((value != null) || (this.required)) {
/* 484 */                 this.cachedFieldValue = desc;
/* 485 */                 AutowiredAnnotationBeanPostProcessor.this.registerDependentBeans(beanName, autowiredBeanNames);
/* 486 */                 if (autowiredBeanNames.size() == 1) {
/* 487 */                   String autowiredBeanName = (String)autowiredBeanNames.iterator().next();
/* 488 */                   if ((AutowiredAnnotationBeanPostProcessor.this.beanFactory.containsBean(autowiredBeanName)) && 
/* 489 */                     (AutowiredAnnotationBeanPostProcessor.this.beanFactory.isTypeMatch(autowiredBeanName, field.getType()))) {
/* 490 */                     this.cachedFieldValue = new RuntimeBeanReference(autowiredBeanName);
/*     */                   }
/*     */                 }
/*     */               }
/*     */               else
/*     */               {
/* 496 */                 this.cachedFieldValue = null;
/*     */               }
/* 498 */               this.cached = true;
/*     */             }
/*     */           }
/*     */         }
/* 502 */         if (value != null) {
/* 503 */           ReflectionUtils.makeAccessible(field);
/* 504 */           field.set(bean, value);
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 508 */         throw new BeanCreationException("Could not autowire field: " + field, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.annotation.AutowiredAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.2
 */