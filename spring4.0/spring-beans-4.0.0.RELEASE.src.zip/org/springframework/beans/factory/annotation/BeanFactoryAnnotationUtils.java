/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class BeanFactoryAnnotationUtils
/*     */ {
/*     */   public static <T> T qualifiedBeanOfType(BeanFactory beanFactory, Class<T> beanType, String qualifier)
/*     */   {
/*  53 */     if ((beanFactory instanceof ConfigurableListableBeanFactory))
/*     */     {
/*  55 */       return qualifiedBeanOfType((ConfigurableListableBeanFactory)beanFactory, beanType, qualifier);
/*     */     }
/*  57 */     if (beanFactory.containsBean(qualifier))
/*     */     {
/*  59 */       return beanFactory.getBean(qualifier, beanType);
/*     */     }
/*     */ 
/*  62 */     throw new NoSuchBeanDefinitionException(qualifier, "No matching " + beanType.getSimpleName() + " bean found for bean name '" + qualifier + "'! (Note: Qualifier matching not supported because given " + "BeanFactory does not implement ConfigurableListableBeanFactory.)");
/*     */   }
/*     */ 
/*     */   private static <T> T qualifiedBeanOfType(ConfigurableListableBeanFactory bf, Class<T> beanType, String qualifier)
/*     */   {
/*  79 */     Map candidateBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(bf, beanType);
/*  80 */     Object matchingBean = null;
/*  81 */     for (String beanName : candidateBeans.keySet()) {
/*  82 */       if (isQualifierMatch(qualifier, beanName, bf)) {
/*  83 */         if (matchingBean != null) {
/*  84 */           throw new NoSuchBeanDefinitionException(qualifier, "No unique " + beanType.getSimpleName() + " bean found for qualifier '" + qualifier + "'");
/*     */         }
/*     */ 
/*  87 */         matchingBean = candidateBeans.get(beanName);
/*     */       }
/*     */     }
/*  90 */     if (matchingBean != null) {
/*  91 */       return matchingBean;
/*     */     }
/*     */ 
/*  94 */     throw new NoSuchBeanDefinitionException(qualifier, "No matching " + beanType.getSimpleName() + " bean found for qualifier '" + qualifier + "' - neither qualifier " + "match nor bean name match!");
/*     */   }
/*     */ 
/*     */   private static boolean isQualifierMatch(String qualifier, String beanName, ConfigurableListableBeanFactory bf)
/*     */   {
/* 109 */     if (bf.containsBean(beanName)) {
/*     */       try {
/* 111 */         BeanDefinition bd = bf.getMergedBeanDefinition(beanName);
/* 112 */         if ((bd instanceof AbstractBeanDefinition)) {
/* 113 */           AbstractBeanDefinition abd = (AbstractBeanDefinition)bd;
/* 114 */           AutowireCandidateQualifier candidate = abd.getQualifier(Qualifier.class.getName());
/* 115 */           if (((candidate != null) && (qualifier.equals(candidate.getAttribute(AutowireCandidateQualifier.VALUE_KEY)))) || 
/* 116 */             (qualifier
/* 116 */             .equals(beanName)) || 
/* 116 */             (ObjectUtils.containsElement(bf.getAliases(beanName), qualifier))) {
/* 117 */             return true;
/*     */           }
/*     */         }
/* 120 */         if ((bd instanceof RootBeanDefinition)) {
/* 121 */           Method factoryMethod = ((RootBeanDefinition)bd).getResolvedFactoryMethod();
/* 122 */           if (factoryMethod != null) {
/* 123 */             Qualifier targetAnnotation = (Qualifier)factoryMethod.getAnnotation(Qualifier.class);
/* 124 */             if ((targetAnnotation != null) && (qualifier.equals(targetAnnotation.value()))) {
/* 125 */               return true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (NoSuchBeanDefinitionException ex)
/*     */       {
/*     */       }
/*     */     }
/* 134 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils
 * JD-Core Version:    0.6.2
 */