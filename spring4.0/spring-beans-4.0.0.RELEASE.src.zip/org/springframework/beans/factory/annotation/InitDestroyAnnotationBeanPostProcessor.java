/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class InitDestroyAnnotationBeanPostProcessor
/*     */   implements DestructionAwareBeanPostProcessor, MergedBeanDefinitionPostProcessor, PriorityOrdered, Serializable
/*     */ {
/*     */   protected transient Log logger;
/*     */   private Class<? extends Annotation> initAnnotationType;
/*     */   private Class<? extends Annotation> destroyAnnotationType;
/*     */   private int order;
/*     */   private final transient Map<Class<?>, LifecycleMetadata> lifecycleMetadataCache;
/*     */ 
/*     */   public InitDestroyAnnotationBeanPostProcessor()
/*     */   {
/*  77 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  83 */     this.order = 2147483647;
/*     */ 
/*  85 */     this.lifecycleMetadataCache = new ConcurrentHashMap(64);
/*     */   }
/*     */ 
/*     */   public void setInitAnnotationType(Class<? extends Annotation> initAnnotationType)
/*     */   {
/*  97 */     this.initAnnotationType = initAnnotationType;
/*     */   }
/*     */ 
/*     */   public void setDestroyAnnotationType(Class<? extends Annotation> destroyAnnotationType)
/*     */   {
/* 108 */     this.destroyAnnotationType = destroyAnnotationType;
/*     */   }
/*     */ 
/*     */   public void setOrder(int order) {
/* 112 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 117 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName)
/*     */   {
/* 123 */     if (beanType != null) {
/* 124 */       LifecycleMetadata metadata = findLifecycleMetadata(beanType);
/* 125 */       metadata.checkConfigMembers(beanDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException
/*     */   {
/* 131 */     LifecycleMetadata metadata = findLifecycleMetadata(bean.getClass());
/*     */     try {
/* 133 */       metadata.invokeInitMethods(bean, beanName);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 136 */       throw new BeanCreationException(beanName, "Invocation of init method failed", ex.getTargetException());
/*     */     }
/*     */     catch (Throwable ex) {
/* 139 */       throw new BeanCreationException(beanName, "Couldn't invoke init method", ex);
/*     */     }
/* 141 */     return bean;
/*     */   }
/*     */ 
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException
/*     */   {
/* 146 */     return bean;
/*     */   }
/*     */ 
/*     */   public void postProcessBeforeDestruction(Object bean, String beanName) throws BeansException
/*     */   {
/* 151 */     LifecycleMetadata metadata = findLifecycleMetadata(bean.getClass());
/*     */     try {
/* 153 */       metadata.invokeDestroyMethods(bean, beanName);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 156 */       String msg = "Invocation of destroy method failed on bean with name '" + beanName + "'";
/* 157 */       if (this.logger.isDebugEnabled()) {
/* 158 */         this.logger.warn(msg, ex.getTargetException());
/*     */       }
/*     */       else
/* 161 */         this.logger.warn(msg + ": " + ex.getTargetException());
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 165 */       this.logger.error("Couldn't invoke destroy method on bean with name '" + beanName + "'", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private LifecycleMetadata findLifecycleMetadata(Class<?> clazz)
/*     */   {
/* 171 */     if (this.lifecycleMetadataCache == null)
/*     */     {
/* 173 */       return buildLifecycleMetadata(clazz);
/*     */     }
/*     */ 
/* 176 */     LifecycleMetadata metadata = (LifecycleMetadata)this.lifecycleMetadataCache.get(clazz);
/* 177 */     if (metadata == null) {
/* 178 */       synchronized (this.lifecycleMetadataCache) {
/* 179 */         metadata = (LifecycleMetadata)this.lifecycleMetadataCache.get(clazz);
/* 180 */         if (metadata == null) {
/* 181 */           metadata = buildLifecycleMetadata(clazz);
/* 182 */           this.lifecycleMetadataCache.put(clazz, metadata);
/*     */         }
/* 184 */         return metadata;
/*     */       }
/*     */     }
/* 187 */     return metadata;
/*     */   }
/*     */ 
/*     */   private LifecycleMetadata buildLifecycleMetadata(Class<?> clazz) {
/* 191 */     boolean debug = this.logger.isDebugEnabled();
/* 192 */     LinkedList initMethods = new LinkedList();
/* 193 */     LinkedList destroyMethods = new LinkedList();
/* 194 */     Class targetClass = clazz;
/*     */     do
/*     */     {
/* 197 */       LinkedList currInitMethods = new LinkedList();
/* 198 */       LinkedList currDestroyMethods = new LinkedList();
/* 199 */       for (Method method : targetClass.getDeclaredMethods()) {
/* 200 */         if ((this.initAnnotationType != null) && 
/* 201 */           (method.getAnnotation(this.initAnnotationType) != null)) {
/* 202 */           LifecycleElement element = new LifecycleElement(method);
/* 203 */           currInitMethods.add(element);
/* 204 */           if (debug) {
/* 205 */             this.logger.debug("Found init method on class [" + clazz.getName() + "]: " + method);
/*     */           }
/*     */         }
/*     */ 
/* 209 */         if ((this.destroyAnnotationType != null) && 
/* 210 */           (method.getAnnotation(this.destroyAnnotationType) != null)) {
/* 211 */           currDestroyMethods.add(new LifecycleElement(method));
/* 212 */           if (debug) {
/* 213 */             this.logger.debug("Found destroy method on class [" + clazz.getName() + "]: " + method);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 218 */       initMethods.addAll(0, currInitMethods);
/* 219 */       destroyMethods.addAll(currDestroyMethods);
/* 220 */       targetClass = targetClass.getSuperclass();
/*     */     }
/* 222 */     while ((targetClass != null) && (targetClass != Object.class));
/*     */ 
/* 224 */     return new LifecycleMetadata(clazz, initMethods, destroyMethods);
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 234 */     ois.defaultReadObject();
/*     */ 
/* 237 */     this.logger = LogFactory.getLog(getClass());
/*     */   }
/*     */ 
/*     */   private static class LifecycleElement
/*     */   {
/*     */     private final Method method;
/*     */     private final String identifier;
/*     */ 
/*     */     public LifecycleElement(Method method)
/*     */     {
/* 331 */       if (method.getParameterTypes().length != 0) {
/* 332 */         throw new IllegalStateException("Lifecycle method annotation requires a no-arg method: " + method);
/*     */       }
/* 334 */       this.method = method;
/* 335 */       this.identifier = (Modifier.isPrivate(method.getModifiers()) ? method
/* 336 */         .getDeclaringClass() + "." + method.getName() : method.getName());
/*     */     }
/*     */ 
/*     */     public Method getMethod() {
/* 340 */       return this.method;
/*     */     }
/*     */ 
/*     */     public String getIdentifier() {
/* 344 */       return this.identifier;
/*     */     }
/*     */ 
/*     */     public void invoke(Object target) throws Throwable {
/* 348 */       ReflectionUtils.makeAccessible(this.method);
/* 349 */       this.method.invoke(target, (Object[])null);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 354 */       if (this == other) {
/* 355 */         return true;
/*     */       }
/* 357 */       if (!(other instanceof LifecycleElement)) {
/* 358 */         return false;
/*     */       }
/* 360 */       LifecycleElement otherElement = (LifecycleElement)other;
/* 361 */       return this.identifier.equals(otherElement.identifier);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 366 */       return this.identifier.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class LifecycleMetadata
/*     */   {
/*     */     private final Class<?> targetClass;
/*     */     private final Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleElement> initMethods;
/*     */     private final Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleElement> destroyMethods;
/*     */     private volatile Set<InitDestroyAnnotationBeanPostProcessor.LifecycleElement> checkedInitMethods;
/*     */     private volatile Set<InitDestroyAnnotationBeanPostProcessor.LifecycleElement> checkedDestroyMethods;
/*     */ 
/*     */     public LifecycleMetadata(Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleElement> targetClass, Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleElement> initMethods)
/*     */     {
/* 259 */       this.targetClass = targetClass;
/* 260 */       this.initMethods = initMethods;
/* 261 */       this.destroyMethods = destroyMethods;
/*     */     }
/*     */ 
/*     */     public void checkConfigMembers(RootBeanDefinition beanDefinition) {
/* 265 */       Set checkedInitMethods = new LinkedHashSet(this.initMethods.size());
/* 266 */       for (Iterator localIterator = this.initMethods.iterator(); localIterator.hasNext(); ) { element = (InitDestroyAnnotationBeanPostProcessor.LifecycleElement)localIterator.next();
/* 267 */         String methodIdentifier = element.getIdentifier();
/* 268 */         if (!beanDefinition.isExternallyManagedInitMethod(methodIdentifier)) {
/* 269 */           beanDefinition.registerExternallyManagedInitMethod(methodIdentifier);
/* 270 */           checkedInitMethods.add(element);
/* 271 */           if (InitDestroyAnnotationBeanPostProcessor.this.logger.isDebugEnabled())
/* 272 */             InitDestroyAnnotationBeanPostProcessor.this.logger.debug("Registered init method on class [" + this.targetClass.getName() + "]: " + element);
/*     */         }
/*     */       }
/*     */       InitDestroyAnnotationBeanPostProcessor.LifecycleElement element;
/* 276 */       Object checkedDestroyMethods = new LinkedHashSet(this.destroyMethods.size());
/* 277 */       for (InitDestroyAnnotationBeanPostProcessor.LifecycleElement element : this.destroyMethods) {
/* 278 */         String methodIdentifier = element.getIdentifier();
/* 279 */         if (!beanDefinition.isExternallyManagedDestroyMethod(methodIdentifier)) {
/* 280 */           beanDefinition.registerExternallyManagedDestroyMethod(methodIdentifier);
/* 281 */           ((Set)checkedDestroyMethods).add(element);
/* 282 */           if (InitDestroyAnnotationBeanPostProcessor.this.logger.isDebugEnabled()) {
/* 283 */             InitDestroyAnnotationBeanPostProcessor.this.logger.debug("Registered destroy method on class [" + this.targetClass.getName() + "]: " + element);
/*     */           }
/*     */         }
/*     */       }
/* 287 */       this.checkedInitMethods = checkedInitMethods;
/* 288 */       this.checkedDestroyMethods = ((Set)checkedDestroyMethods);
/*     */     }
/*     */ 
/*     */     public void invokeInitMethods(Object target, String beanName) throws Throwable {
/* 292 */       Collection initMethodsToIterate = this.checkedInitMethods != null ? this.checkedInitMethods : this.initMethods;
/*     */       boolean debug;
/* 294 */       if (!initMethodsToIterate.isEmpty()) {
/* 295 */         debug = InitDestroyAnnotationBeanPostProcessor.this.logger.isDebugEnabled();
/* 296 */         for (InitDestroyAnnotationBeanPostProcessor.LifecycleElement element : initMethodsToIterate) {
/* 297 */           if (debug) {
/* 298 */             InitDestroyAnnotationBeanPostProcessor.this.logger.debug("Invoking init method on bean '" + beanName + "': " + element.getMethod());
/*     */           }
/* 300 */           element.invoke(target);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void invokeDestroyMethods(Object target, String beanName) throws Throwable {
/* 306 */       Collection destroyMethodsToIterate = this.checkedDestroyMethods != null ? this.checkedDestroyMethods : this.destroyMethods;
/*     */       boolean debug;
/* 308 */       if (!destroyMethodsToIterate.isEmpty()) {
/* 309 */         debug = InitDestroyAnnotationBeanPostProcessor.this.logger.isDebugEnabled();
/* 310 */         for (InitDestroyAnnotationBeanPostProcessor.LifecycleElement element : destroyMethodsToIterate) {
/* 311 */           if (debug) {
/* 312 */             InitDestroyAnnotationBeanPostProcessor.this.logger.debug("Invoking destroy method on bean '" + beanName + "': " + element.getMethod());
/*     */           }
/* 314 */           element.invoke(target);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.annotation.InitDestroyAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.2
 */