/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class InjectionMetadata
/*     */ {
/*  49 */   private final Log logger = LogFactory.getLog(InjectionMetadata.class);
/*     */   private final Class<?> targetClass;
/*     */   private final Collection<InjectedElement> injectedElements;
/*     */   private volatile Set<InjectedElement> checkedElements;
/*     */ 
/*     */   public InjectionMetadata(Class<?> targetClass, Collection<InjectedElement> elements)
/*     */   {
/*  59 */     this.targetClass = targetClass;
/*  60 */     this.injectedElements = elements;
/*     */   }
/*     */ 
/*     */   public void checkConfigMembers(RootBeanDefinition beanDefinition) {
/*  64 */     Set checkedElements = new LinkedHashSet(this.injectedElements.size());
/*  65 */     for (InjectedElement element : this.injectedElements) {
/*  66 */       Member member = element.getMember();
/*  67 */       if (!beanDefinition.isExternallyManagedConfigMember(member)) {
/*  68 */         beanDefinition.registerExternallyManagedConfigMember(member);
/*  69 */         checkedElements.add(element);
/*  70 */         if (this.logger.isDebugEnabled()) {
/*  71 */           this.logger.debug("Registered injected element on class [" + this.targetClass.getName() + "]: " + element);
/*     */         }
/*     */       }
/*     */     }
/*  75 */     this.checkedElements = checkedElements;
/*     */   }
/*     */ 
/*     */   public void inject(Object target, String beanName, PropertyValues pvs) throws Throwable {
/*  79 */     Collection elementsToIterate = this.checkedElements != null ? this.checkedElements : this.injectedElements;
/*     */     boolean debug;
/*  81 */     if (!elementsToIterate.isEmpty()) {
/*  82 */       debug = this.logger.isDebugEnabled();
/*  83 */       for (InjectedElement element : elementsToIterate) {
/*  84 */         if (debug) {
/*  85 */           this.logger.debug("Processing injected method of bean '" + beanName + "': " + element);
/*     */         }
/*  87 */         element.inject(target, beanName, pvs);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class InjectedElement
/*     */   {
/*     */     protected final Member member;
/*     */     protected final boolean isField;
/*     */     protected final PropertyDescriptor pd;
/*     */     protected volatile Boolean skip;
/*     */ 
/*     */     protected InjectedElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 104 */       this.member = member;
/* 105 */       this.isField = (member instanceof Field);
/* 106 */       this.pd = pd;
/*     */     }
/*     */ 
/*     */     public final Member getMember() {
/* 110 */       return this.member;
/*     */     }
/*     */ 
/*     */     protected final Class<?> getResourceType() {
/* 114 */       if (this.isField) {
/* 115 */         return ((Field)this.member).getType();
/*     */       }
/* 117 */       if (this.pd != null) {
/* 118 */         return this.pd.getPropertyType();
/*     */       }
/*     */ 
/* 121 */       return ((Method)this.member).getParameterTypes()[0];
/*     */     }
/*     */ 
/*     */     protected final void checkResourceType(Class<?> resourceType)
/*     */     {
/* 126 */       if (this.isField) {
/* 127 */         Class fieldType = ((Field)this.member).getType();
/* 128 */         if ((!resourceType.isAssignableFrom(fieldType)) && (!fieldType.isAssignableFrom(resourceType)))
/*     */         {
/* 130 */           throw new IllegalStateException("Specified field type [" + fieldType + "] is incompatible with resource type [" + resourceType
/* 130 */             .getName() + "]");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 135 */         Class paramType = this.pd != null ? this.pd
/* 135 */           .getPropertyType() : ((Method)this.member).getParameterTypes()[0];
/* 136 */         if ((!resourceType.isAssignableFrom(paramType)) && (!paramType.isAssignableFrom(resourceType)))
/*     */         {
/* 138 */           throw new IllegalStateException("Specified parameter type [" + paramType + "] is incompatible with resource type [" + resourceType
/* 138 */             .getName() + "]");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void inject(Object target, String requestingBeanName, PropertyValues pvs)
/*     */       throws Throwable
/*     */     {
/* 147 */       if (this.isField) {
/* 148 */         Field field = (Field)this.member;
/* 149 */         ReflectionUtils.makeAccessible(field);
/* 150 */         field.set(target, getResourceToInject(target, requestingBeanName));
/*     */       }
/*     */       else {
/* 153 */         if (checkPropertySkipping(pvs))
/* 154 */           return;
/*     */         try
/*     */         {
/* 157 */           Method method = (Method)this.member;
/* 158 */           ReflectionUtils.makeAccessible(method);
/* 159 */           method.invoke(target, new Object[] { getResourceToInject(target, requestingBeanName) });
/*     */         }
/*     */         catch (InvocationTargetException ex) {
/* 162 */           throw ex.getTargetException();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     protected boolean checkPropertySkipping(PropertyValues pvs)
/*     */     {
/* 173 */       if (this.skip != null) {
/* 174 */         return this.skip.booleanValue();
/*     */       }
/* 176 */       if (pvs == null) {
/* 177 */         this.skip = Boolean.valueOf(false);
/* 178 */         return false;
/*     */       }
/* 180 */       synchronized (pvs) {
/* 181 */         if (this.skip != null) {
/* 182 */           return this.skip.booleanValue();
/*     */         }
/* 184 */         if (this.pd != null) {
/* 185 */           if (pvs.contains(this.pd.getName()))
/*     */           {
/* 187 */             this.skip = Boolean.valueOf(true);
/* 188 */             return true;
/*     */           }
/* 190 */           if ((pvs instanceof MutablePropertyValues)) {
/* 191 */             ((MutablePropertyValues)pvs).registerProcessedProperty(this.pd.getName());
/*     */           }
/*     */         }
/* 194 */         this.skip = Boolean.valueOf(false);
/* 195 */         return false;
/*     */       }
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/* 203 */       return null;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 208 */       if (this == other) {
/* 209 */         return true;
/*     */       }
/* 211 */       if (!(other instanceof InjectedElement)) {
/* 212 */         return false;
/*     */       }
/* 214 */       InjectedElement otherElement = (InjectedElement)other;
/* 215 */       return this.member.equals(otherElement.member);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 220 */       return this.member.getClass().hashCode() * 29 + this.member.getName().hashCode();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 225 */       return getClass().getSimpleName() + " for " + this.member;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.annotation.InjectionMetadata
 * JD-Core Version:    0.6.2
 */