/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.GenericTypeAwareAutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class QualifierAnnotationAutowireCandidateResolver extends GenericTypeAwareAutowireCandidateResolver
/*     */ {
/*  56 */   private final Set<Class<? extends Annotation>> qualifierTypes = new LinkedHashSet();
/*     */ 
/*  58 */   private Class<? extends Annotation> valueAnnotationType = Value.class;
/*     */ 
/*     */   public QualifierAnnotationAutowireCandidateResolver()
/*     */   {
/*  68 */     this.qualifierTypes.add(Qualifier.class);
/*  69 */     ClassLoader cl = QualifierAnnotationAutowireCandidateResolver.class.getClassLoader();
/*     */     try {
/*  71 */       this.qualifierTypes.add(cl.loadClass("javax.inject.Qualifier"));
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public QualifierAnnotationAutowireCandidateResolver(Class<? extends Annotation> qualifierType)
/*     */   {
/*  84 */     Assert.notNull(qualifierType, "'qualifierType' must not be null");
/*  85 */     this.qualifierTypes.add(qualifierType);
/*     */   }
/*     */ 
/*     */   public QualifierAnnotationAutowireCandidateResolver(Set<Class<? extends Annotation>> qualifierTypes)
/*     */   {
/*  94 */     Assert.notNull(qualifierTypes, "'qualifierTypes' must not be null");
/*  95 */     this.qualifierTypes.addAll(qualifierTypes);
/*     */   }
/*     */ 
/*     */   public void addQualifierType(Class<? extends Annotation> qualifierType)
/*     */   {
/* 110 */     this.qualifierTypes.add(qualifierType);
/*     */   }
/*     */ 
/*     */   public void setValueAnnotationType(Class<? extends Annotation> valueAnnotationType)
/*     */   {
/* 123 */     this.valueAnnotationType = valueAnnotationType;
/*     */   }
/*     */ 
/*     */   public boolean isAutowireCandidate(BeanDefinitionHolder bdHolder, DependencyDescriptor descriptor)
/*     */   {
/* 141 */     boolean match = super.isAutowireCandidate(bdHolder, descriptor);
/* 142 */     if ((match) && (descriptor != null)) {
/* 143 */       match = checkQualifiers(bdHolder, descriptor.getAnnotations());
/* 144 */       if (match) {
/* 145 */         MethodParameter methodParam = descriptor.getMethodParameter();
/* 146 */         if (methodParam != null) {
/* 147 */           Method method = methodParam.getMethod();
/* 148 */           if ((method == null) || (Void.TYPE.equals(method.getReturnType()))) {
/* 149 */             match = checkQualifiers(bdHolder, methodParam.getMethodAnnotations());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 154 */     return match;
/*     */   }
/*     */ 
/*     */   protected boolean checkQualifiers(BeanDefinitionHolder bdHolder, Annotation[] annotationsToSearch)
/*     */   {
/* 161 */     if (ObjectUtils.isEmpty(annotationsToSearch)) {
/* 162 */       return true;
/*     */     }
/* 164 */     SimpleTypeConverter typeConverter = new SimpleTypeConverter();
/* 165 */     for (Annotation annotation : annotationsToSearch) {
/* 166 */       Class type = annotation.annotationType();
/* 167 */       boolean checkMeta = true;
/* 168 */       boolean fallbackToMeta = false;
/* 169 */       if (isQualifier(type)) {
/* 170 */         if (!checkQualifier(bdHolder, annotation, typeConverter)) {
/* 171 */           fallbackToMeta = true;
/*     */         }
/*     */         else {
/* 174 */           checkMeta = false;
/*     */         }
/*     */       }
/* 177 */       if (checkMeta) {
/* 178 */         boolean foundMeta = false;
/* 179 */         for (Annotation metaAnn : type.getAnnotations()) {
/* 180 */           Class metaType = metaAnn.annotationType();
/* 181 */           if (isQualifier(metaType)) {
/* 182 */             foundMeta = true;
/*     */ 
/* 185 */             if (((fallbackToMeta) && (StringUtils.isEmpty(AnnotationUtils.getValue(metaAnn)))) || 
/* 186 */               (!checkQualifier(bdHolder, metaAnn, typeConverter)))
/*     */             {
/* 187 */               return false;
/*     */             }
/*     */           }
/*     */         }
/* 191 */         if ((fallbackToMeta) && (!foundMeta)) {
/* 192 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 196 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean isQualifier(Class<? extends Annotation> annotationType)
/*     */   {
/* 203 */     for (Class qualifierType : this.qualifierTypes) {
/* 204 */       if ((annotationType.equals(qualifierType)) || (annotationType.isAnnotationPresent(qualifierType))) {
/* 205 */         return true;
/*     */       }
/*     */     }
/* 208 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean checkQualifier(BeanDefinitionHolder bdHolder, Annotation annotation, TypeConverter typeConverter)
/*     */   {
/* 217 */     Class type = annotation.annotationType();
/* 218 */     RootBeanDefinition bd = (RootBeanDefinition)bdHolder.getBeanDefinition();
/*     */ 
/* 220 */     AutowireCandidateQualifier qualifier = bd.getQualifier(type.getName());
/* 221 */     if (qualifier == null)
/* 222 */       qualifier = bd.getQualifier(ClassUtils.getShortName(type));
/*     */     Class beanType;
/* 224 */     if (qualifier == null)
/*     */     {
/* 226 */       Annotation targetAnnotation = getFactoryMethodAnnotation(bd, type);
/* 227 */       if (targetAnnotation == null) {
/* 228 */         RootBeanDefinition dbd = getResolvedDecoratedDefinition(bd);
/* 229 */         if (dbd != null) {
/* 230 */           targetAnnotation = getFactoryMethodAnnotation(dbd, type);
/*     */         }
/*     */       }
/* 233 */       if (targetAnnotation == null)
/*     */       {
/* 235 */         if (getBeanFactory() != null) {
/* 236 */           beanType = getBeanFactory().getType(bdHolder.getBeanName());
/* 237 */           if (beanType != null) {
/* 238 */             targetAnnotation = AnnotationUtils.getAnnotation(ClassUtils.getUserClass(beanType), type);
/*     */           }
/*     */         }
/* 241 */         if ((targetAnnotation == null) && (bd.hasBeanClass())) {
/* 242 */           targetAnnotation = AnnotationUtils.getAnnotation(ClassUtils.getUserClass(bd.getBeanClass()), type);
/*     */         }
/*     */       }
/* 245 */       if ((targetAnnotation != null) && (targetAnnotation.equals(annotation))) {
/* 246 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 250 */     Map attributes = AnnotationUtils.getAnnotationAttributes(annotation);
/* 251 */     if ((attributes.isEmpty()) && (qualifier == null))
/*     */     {
/* 253 */       return false;
/*     */     }
/* 255 */     for (Map.Entry entry : attributes.entrySet()) {
/* 256 */       String attributeName = (String)entry.getKey();
/* 257 */       Object expectedValue = entry.getValue();
/* 258 */       Object actualValue = null;
/*     */ 
/* 260 */       if (qualifier != null) {
/* 261 */         actualValue = qualifier.getAttribute(attributeName);
/*     */       }
/* 263 */       if (actualValue == null)
/*     */       {
/* 265 */         actualValue = bd.getAttribute(attributeName);
/*     */       }
/* 267 */       if ((actualValue != null) || (!attributeName.equals(AutowireCandidateQualifier.VALUE_KEY)) || (!(expectedValue instanceof String)) || 
/* 268 */         (!bdHolder
/* 268 */         .matchesName((String)expectedValue)))
/*     */       {
/* 272 */         if ((actualValue == null) && (qualifier != null))
/*     */         {
/* 274 */           actualValue = AnnotationUtils.getDefaultValue(annotation, attributeName);
/*     */         }
/* 276 */         if (actualValue != null) {
/* 277 */           actualValue = typeConverter.convertIfNecessary(actualValue, expectedValue.getClass());
/*     */         }
/* 279 */         if (!expectedValue.equals(actualValue))
/* 280 */           return false;
/*     */       }
/*     */     }
/* 283 */     return true;
/*     */   }
/*     */ 
/*     */   protected Annotation getFactoryMethodAnnotation(RootBeanDefinition bd, Class<? extends Annotation> type) {
/* 287 */     Method resolvedFactoryMethod = bd.getResolvedFactoryMethod();
/* 288 */     return resolvedFactoryMethod != null ? AnnotationUtils.getAnnotation(resolvedFactoryMethod, type) : null;
/*     */   }
/*     */ 
/*     */   public Object getSuggestedValue(DependencyDescriptor descriptor)
/*     */   {
/* 298 */     Object value = findValue(descriptor.getAnnotations());
/* 299 */     if (value == null) {
/* 300 */       MethodParameter methodParam = descriptor.getMethodParameter();
/* 301 */       if (methodParam != null) {
/* 302 */         value = findValue(methodParam.getMethodAnnotations());
/*     */       }
/*     */     }
/* 305 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object findValue(Annotation[] annotationsToSearch)
/*     */   {
/* 312 */     for (Annotation annotation : annotationsToSearch) {
/* 313 */       if (this.valueAnnotationType.isInstance(annotation)) {
/* 314 */         return extractValue(annotation);
/*     */       }
/*     */     }
/* 317 */     for (Annotation annotation : annotationsToSearch) {
/* 318 */       Annotation metaAnn = annotation.annotationType().getAnnotation(this.valueAnnotationType);
/* 319 */       if (metaAnn != null) {
/* 320 */         return extractValue(metaAnn);
/*     */       }
/*     */     }
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object extractValue(Annotation valueAnnotation)
/*     */   {
/* 330 */     Object value = AnnotationUtils.getValue(valueAnnotation);
/* 331 */     if (value == null) {
/* 332 */       throw new IllegalStateException("Value annotation must have a value attribute");
/*     */     }
/* 334 */     return value;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.annotation.QualifierAnnotationAutowireCandidateResolver
 * JD-Core Version:    0.6.2
 */