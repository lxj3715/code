package org.springframework.beans.factory.config;

import org.springframework.beans.BeansException;

public abstract interface BeanExpressionResolver
{
  public abstract Object evaluate(String paramString, BeanExpressionContext paramBeanExpressionContext)
    throws BeansException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.BeanExpressionResolver
 * JD-Core Version:    0.6.2
 */