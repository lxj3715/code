package org.springframework.beans.factory.config;

import org.springframework.beans.BeansException;

public abstract interface BeanPostProcessor
{
  public abstract Object postProcessBeforeInitialization(Object paramObject, String paramString)
    throws BeansException;

  public abstract Object postProcessAfterInitialization(Object paramObject, String paramString)
    throws BeansException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.BeanPostProcessor
 * JD-Core Version:    0.6.2
 */