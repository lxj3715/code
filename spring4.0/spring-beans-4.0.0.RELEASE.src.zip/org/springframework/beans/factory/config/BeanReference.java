package org.springframework.beans.factory.config;

import org.springframework.beans.BeanMetadataElement;

public abstract interface BeanReference extends BeanMetadataElement
{
  public abstract String getBeanName();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.BeanReference
 * JD-Core Version:    0.6.2
 */