/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.SmartFactoryBean;
/*     */ 
/*     */ @Deprecated
/*     */ public class BeanReferenceFactoryBean
/*     */   implements SmartFactoryBean<Object>, BeanFactoryAware
/*     */ {
/*     */   private String targetBeanName;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public void setTargetBeanName(String targetBeanName)
/*     */   {
/*  65 */     this.targetBeanName = targetBeanName;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  70 */     this.beanFactory = beanFactory;
/*  71 */     if (this.targetBeanName == null) {
/*  72 */       throw new IllegalArgumentException("'targetBeanName' is required");
/*     */     }
/*  74 */     if (!this.beanFactory.containsBean(this.targetBeanName))
/*  75 */       throw new NoSuchBeanDefinitionException(this.targetBeanName, this.beanFactory.toString());
/*     */   }
/*     */ 
/*     */   public Object getObject()
/*     */     throws BeansException
/*     */   {
/*  82 */     if (this.beanFactory == null) {
/*  83 */       throw new FactoryBeanNotInitializedException();
/*     */     }
/*  85 */     return this.beanFactory.getBean(this.targetBeanName);
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/*  90 */     if (this.beanFactory == null) {
/*  91 */       return null;
/*     */     }
/*  93 */     return this.beanFactory.getType(this.targetBeanName);
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/*  98 */     if (this.beanFactory == null) {
/*  99 */       throw new FactoryBeanNotInitializedException();
/*     */     }
/* 101 */     return this.beanFactory.isSingleton(this.targetBeanName);
/*     */   }
/*     */ 
/*     */   public boolean isPrototype()
/*     */   {
/* 106 */     if (this.beanFactory == null) {
/* 107 */       throw new FactoryBeanNotInitializedException();
/*     */     }
/* 109 */     return this.beanFactory.isPrototype(this.targetBeanName);
/*     */   }
/*     */ 
/*     */   public boolean isEagerInit()
/*     */   {
/* 114 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.BeanReferenceFactoryBean
 * JD-Core Version:    0.6.2
 */