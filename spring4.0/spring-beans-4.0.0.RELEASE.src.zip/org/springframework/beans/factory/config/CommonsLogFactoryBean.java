/*    */ package org.springframework.beans.factory.config;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ @Deprecated
/*    */ public class CommonsLogFactoryBean
/*    */   implements FactoryBean<Log>, InitializingBean
/*    */ {
/*    */   private Log log;
/*    */ 
/*    */   public void setLogName(String logName)
/*    */   {
/* 52 */     this.log = LogFactory.getLog(logName);
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 58 */     if (this.log == null)
/* 59 */       throw new IllegalArgumentException("'logName' is required");
/*    */   }
/*    */ 
/*    */   public Log getObject()
/*    */   {
/* 65 */     return this.log;
/*    */   }
/*    */ 
/*    */   public Class<? extends Log> getObjectType()
/*    */   {
/* 70 */     return this.log != null ? this.log.getClass() : Log.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton()
/*    */   {
/* 75 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.CommonsLogFactoryBean
 * JD-Core Version:    0.6.2
 */