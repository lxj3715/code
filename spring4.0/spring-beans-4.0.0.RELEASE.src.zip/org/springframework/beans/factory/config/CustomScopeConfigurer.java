/*    */ package org.springframework.beans.factory.config;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class CustomScopeConfigurer
/*    */   implements BeanFactoryPostProcessor, BeanClassLoaderAware, Ordered
/*    */ {
/*    */   private Map<String, Object> scopes;
/* 49 */   private int order = 2147483647;
/*    */ 
/* 51 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*    */ 
/*    */   public void setScopes(Map<String, Object> scopes)
/*    */   {
/* 61 */     this.scopes = scopes;
/*    */   }
/*    */ 
/*    */   public void setOrder(int order) {
/* 65 */     this.order = order;
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 70 */     return this.order;
/*    */   }
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*    */   {
/* 75 */     this.beanClassLoader = beanClassLoader;
/*    */   }
/*    */ 
/*    */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*    */     throws BeansException
/*    */   {
/* 81 */     if (this.scopes != null)
/* 82 */       for (Map.Entry entry : this.scopes.entrySet()) {
/* 83 */         String scopeKey = (String)entry.getKey();
/* 84 */         Object value = entry.getValue();
/* 85 */         if ((value instanceof Scope)) {
/* 86 */           beanFactory.registerScope(scopeKey, (Scope)value);
/*    */         }
/* 88 */         else if ((value instanceof Class)) {
/* 89 */           Class scopeClass = (Class)value;
/* 90 */           Assert.isAssignable(Scope.class, scopeClass);
/* 91 */           beanFactory.registerScope(scopeKey, (Scope)BeanUtils.instantiateClass(scopeClass));
/*    */         }
/* 93 */         else if ((value instanceof String)) {
/* 94 */           Class scopeClass = ClassUtils.resolveClassName((String)value, this.beanClassLoader);
/* 95 */           Assert.isAssignable(Scope.class, scopeClass);
/* 96 */           beanFactory.registerScope(scopeKey, (Scope)BeanUtils.instantiateClass(scopeClass));
/*    */         }
/*    */         else
/*    */         {
/* 100 */           throw new IllegalArgumentException("Mapped value [" + value + "] for scope key [" + scopeKey + "] is not an instance of required type [" + Scope.class
/* 100 */             .getName() + "] or a corresponding Class or String value indicating a Scope implementation");
/*    */         }
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.CustomScopeConfigurer
 * JD-Core Version:    0.6.2
 */