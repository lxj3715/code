/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import org.springframework.core.GenericCollectionTypeResolver;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class DependencyDescriptor
/*     */   implements Serializable
/*     */ {
/*     */   private transient MethodParameter methodParameter;
/*     */   private transient Field field;
/*     */   private Class<?> declaringClass;
/*     */   private Class<?> containingClass;
/*     */   private String methodName;
/*     */   private Class<?>[] parameterTypes;
/*     */   private int parameterIndex;
/*     */   private String fieldName;
/*     */   private final boolean required;
/*     */   private final boolean eager;
/*  65 */   private int nestingLevel = 1;
/*     */   private transient Annotation[] fieldAnnotations;
/*     */ 
/*     */   public DependencyDescriptor(MethodParameter methodParameter, boolean required)
/*     */   {
/*  77 */     this(methodParameter, required, true);
/*     */   }
/*     */ 
/*     */   public DependencyDescriptor(MethodParameter methodParameter, boolean required, boolean eager)
/*     */   {
/*  88 */     Assert.notNull(methodParameter, "MethodParameter must not be null");
/*  89 */     this.methodParameter = methodParameter;
/*  90 */     this.declaringClass = methodParameter.getDeclaringClass();
/*  91 */     this.containingClass = methodParameter.getContainingClass();
/*  92 */     if (this.methodParameter.getMethod() != null) {
/*  93 */       this.methodName = methodParameter.getMethod().getName();
/*  94 */       this.parameterTypes = methodParameter.getMethod().getParameterTypes();
/*     */     }
/*     */     else {
/*  97 */       this.parameterTypes = methodParameter.getConstructor().getParameterTypes();
/*     */     }
/*  99 */     this.parameterIndex = methodParameter.getParameterIndex();
/* 100 */     this.required = required;
/* 101 */     this.eager = eager;
/*     */   }
/*     */ 
/*     */   public DependencyDescriptor(Field field, boolean required)
/*     */   {
/* 111 */     this(field, required, true);
/*     */   }
/*     */ 
/*     */   public DependencyDescriptor(Field field, boolean required, boolean eager)
/*     */   {
/* 122 */     Assert.notNull(field, "Field must not be null");
/* 123 */     this.field = field;
/* 124 */     this.declaringClass = field.getDeclaringClass();
/* 125 */     this.fieldName = field.getName();
/* 126 */     this.required = required;
/* 127 */     this.eager = eager;
/*     */   }
/*     */ 
/*     */   public DependencyDescriptor(DependencyDescriptor original)
/*     */   {
/* 135 */     this.methodParameter = (original.methodParameter != null ? new MethodParameter(original.methodParameter) : null);
/* 136 */     this.field = original.field;
/* 137 */     this.declaringClass = original.declaringClass;
/* 138 */     this.containingClass = original.containingClass;
/* 139 */     this.methodName = original.methodName;
/* 140 */     this.parameterTypes = original.parameterTypes;
/* 141 */     this.parameterIndex = original.parameterIndex;
/* 142 */     this.fieldName = original.fieldName;
/* 143 */     this.required = original.required;
/* 144 */     this.eager = original.eager;
/* 145 */     this.nestingLevel = original.nestingLevel;
/* 146 */     this.fieldAnnotations = original.fieldAnnotations;
/*     */   }
/*     */ 
/*     */   public MethodParameter getMethodParameter()
/*     */   {
/* 156 */     return this.methodParameter;
/*     */   }
/*     */ 
/*     */   public Field getField()
/*     */   {
/* 165 */     return this.field;
/*     */   }
/*     */ 
/*     */   public boolean isRequired()
/*     */   {
/* 172 */     return this.required;
/*     */   }
/*     */ 
/*     */   public boolean isEager()
/*     */   {
/* 180 */     return this.eager;
/*     */   }
/*     */ 
/*     */   public void increaseNestingLevel()
/*     */   {
/* 189 */     this.nestingLevel += 1;
/* 190 */     if (this.methodParameter != null)
/* 191 */       this.methodParameter.increaseNestingLevel();
/*     */   }
/*     */ 
/*     */   public void setContainingClass(Class<?> containingClass)
/*     */   {
/* 201 */     this.containingClass = containingClass;
/* 202 */     if (this.methodParameter != null)
/* 203 */       GenericTypeResolver.resolveParameterType(this.methodParameter, containingClass);
/*     */   }
/*     */ 
/*     */   public ResolvableType getResolvableType()
/*     */   {
/* 212 */     return this.field != null ? ResolvableType.forField(this.field, this.nestingLevel, this.containingClass) : 
/* 212 */       ResolvableType.forMethodParameter(this.methodParameter);
/*     */   }
/*     */ 
/*     */   public boolean fallbackMatchAllowed()
/*     */   {
/* 222 */     return false;
/*     */   }
/*     */ 
/*     */   public DependencyDescriptor forFallbackMatch()
/*     */   {
/* 230 */     return new DependencyDescriptor(this)
/*     */     {
/*     */       public boolean fallbackMatchAllowed() {
/* 233 */         return true;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public void initParameterNameDiscovery(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 245 */     if (this.methodParameter != null)
/* 246 */       this.methodParameter.initParameterNameDiscovery(parameterNameDiscoverer);
/*     */   }
/*     */ 
/*     */   public String getDependencyName()
/*     */   {
/* 255 */     return this.field != null ? this.field.getName() : this.methodParameter.getParameterName();
/*     */   }
/*     */ 
/*     */   public Class<?> getDependencyType()
/*     */   {
/* 263 */     if (this.field != null) {
/* 264 */       if (this.nestingLevel > 1) {
/* 265 */         Type type = this.field.getGenericType();
/* 266 */         if ((type instanceof ParameterizedType)) {
/* 267 */           Type[] args = ((ParameterizedType)type).getActualTypeArguments();
/* 268 */           Type arg = args[(args.length - 1)];
/* 269 */           if ((arg instanceof Class)) {
/* 270 */             return (Class)arg;
/*     */           }
/* 272 */           if ((arg instanceof ParameterizedType)) {
/* 273 */             arg = ((ParameterizedType)arg).getRawType();
/* 274 */             if ((arg instanceof Class)) {
/* 275 */               return (Class)arg;
/*     */             }
/*     */           }
/*     */         }
/* 279 */         return Object.class;
/*     */       }
/*     */ 
/* 282 */       return this.field.getType();
/*     */     }
/*     */ 
/* 286 */     return this.methodParameter.getNestedParameterType();
/*     */   }
/*     */ 
/*     */   public Class<?> getCollectionType()
/*     */   {
/* 297 */     return this.field != null ? 
/* 296 */       GenericCollectionTypeResolver.getCollectionFieldType(this.field, this.nestingLevel) : 
/* 297 */       GenericCollectionTypeResolver.getCollectionParameterType(this.methodParameter);
/*     */   }
/*     */ 
/*     */   public Class<?> getMapKeyType()
/*     */   {
/* 307 */     return this.field != null ? 
/* 306 */       GenericCollectionTypeResolver.getMapKeyFieldType(this.field, this.nestingLevel) : 
/* 307 */       GenericCollectionTypeResolver.getMapKeyParameterType(this.methodParameter);
/*     */   }
/*     */ 
/*     */   public Class<?> getMapValueType()
/*     */   {
/* 317 */     return this.field != null ? 
/* 316 */       GenericCollectionTypeResolver.getMapValueFieldType(this.field, this.nestingLevel) : 
/* 317 */       GenericCollectionTypeResolver.getMapValueParameterType(this.methodParameter);
/*     */   }
/*     */ 
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 324 */     if (this.field != null) {
/* 325 */       if (this.fieldAnnotations == null) {
/* 326 */         this.fieldAnnotations = this.field.getAnnotations();
/*     */       }
/* 328 */       return this.fieldAnnotations;
/*     */     }
/*     */ 
/* 331 */     return this.methodParameter.getParameterAnnotations();
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 342 */     ois.defaultReadObject();
/*     */     try
/*     */     {
/* 346 */       if (this.fieldName != null) {
/* 347 */         this.field = this.declaringClass.getDeclaredField(this.fieldName);
/*     */       }
/*     */       else {
/* 350 */         if (this.methodName != null) {
/* 351 */           this.methodParameter = new MethodParameter(this.declaringClass
/* 352 */             .getDeclaredMethod(this.methodName, this.parameterTypes), 
/* 352 */             this.parameterIndex);
/*     */         }
/*     */         else {
/* 355 */           this.methodParameter = new MethodParameter(this.declaringClass
/* 356 */             .getDeclaredConstructor(this.parameterTypes), 
/* 356 */             this.parameterIndex);
/*     */         }
/* 358 */         for (int i = 1; i < this.nestingLevel; i++)
/* 359 */           this.methodParameter.increaseNestingLevel();
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 364 */       throw new IllegalStateException("Could not find original class structure", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.DependencyDescriptor
 * JD-Core Version:    0.6.2
 */