/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.support.ArgumentConvertingMethodInvoker;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class MethodInvokingFactoryBean extends ArgumentConvertingMethodInvoker
/*     */   implements FactoryBean<Object>, BeanClassLoaderAware, BeanFactoryAware, InitializingBean
/*     */ {
/*  93 */   private boolean singleton = true;
/*     */ 
/*  95 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   private ConfigurableBeanFactory beanFactory;
/*  99 */   private boolean initialized = false;
/*     */   private Object singletonObject;
/*     */ 
/*     */   public void setSingleton(boolean singleton)
/*     */   {
/* 110 */     this.singleton = singleton;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 115 */     return this.singleton;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 120 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   protected Class<?> resolveClassName(String className) throws ClassNotFoundException
/*     */   {
/* 125 */     return ClassUtils.forName(className, this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 130 */     if ((beanFactory instanceof ConfigurableBeanFactory))
/* 131 */       this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*     */   }
/*     */ 
/*     */   protected TypeConverter getDefaultTypeConverter()
/*     */   {
/* 142 */     if (this.beanFactory != null) {
/* 143 */       return this.beanFactory.getTypeConverter();
/*     */     }
/*     */ 
/* 146 */     return super.getDefaultTypeConverter();
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 153 */     prepare();
/* 154 */     if (this.singleton) {
/* 155 */       this.initialized = true;
/* 156 */       this.singletonObject = doInvoke();
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object doInvoke()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 166 */       return invoke();
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 169 */       if ((ex.getTargetException() instanceof Exception)) {
/* 170 */         throw ((Exception)ex.getTargetException());
/*     */       }
/* 172 */       if ((ex.getTargetException() instanceof Error)) {
/* 173 */         throw ((Error)ex.getTargetException());
/*     */       }
/* 175 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getObject()
/*     */     throws Exception
/*     */   {
/* 187 */     if (this.singleton) {
/* 188 */       if (!this.initialized) {
/* 189 */         throw new FactoryBeanNotInitializedException();
/*     */       }
/*     */ 
/* 192 */       return this.singletonObject;
/*     */     }
/*     */ 
/* 196 */     return doInvoke();
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 206 */     if (!isPrepared())
/*     */     {
/* 208 */       return null;
/*     */     }
/* 210 */     return getPreparedMethod().getReturnType();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.MethodInvokingFactoryBean
 * JD-Core Version:    0.6.2
 */