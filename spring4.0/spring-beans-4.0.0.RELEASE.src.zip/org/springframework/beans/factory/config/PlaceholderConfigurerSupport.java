/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public abstract class PlaceholderConfigurerSupport extends PropertyResourceConfigurer
/*     */   implements BeanNameAware, BeanFactoryAware
/*     */ {
/*     */   public static final String DEFAULT_PLACEHOLDER_PREFIX = "${";
/*     */   public static final String DEFAULT_PLACEHOLDER_SUFFIX = "}";
/*     */   public static final String DEFAULT_VALUE_SEPARATOR = ":";
/* 102 */   protected String placeholderPrefix = "${";
/*     */ 
/* 105 */   protected String placeholderSuffix = "}";
/*     */ 
/* 108 */   protected String valueSeparator = ":";
/*     */ 
/* 110 */   protected boolean ignoreUnresolvablePlaceholders = false;
/*     */   protected String nullValue;
/*     */   private BeanFactory beanFactory;
/*     */   private String beanName;
/*     */ 
/*     */   public void setPlaceholderPrefix(String placeholderPrefix)
/*     */   {
/* 124 */     this.placeholderPrefix = placeholderPrefix;
/*     */   }
/*     */ 
/*     */   public void setPlaceholderSuffix(String placeholderSuffix)
/*     */   {
/* 132 */     this.placeholderSuffix = placeholderSuffix;
/*     */   }
/*     */ 
/*     */   public void setValueSeparator(String valueSeparator)
/*     */   {
/* 142 */     this.valueSeparator = valueSeparator;
/*     */   }
/*     */ 
/*     */   public void setNullValue(String nullValue)
/*     */   {
/* 155 */     this.nullValue = nullValue;
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnresolvablePlaceholders(boolean ignoreUnresolvablePlaceholders)
/*     */   {
/* 166 */     this.ignoreUnresolvablePlaceholders = ignoreUnresolvablePlaceholders;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName)
/*     */   {
/* 179 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 192 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   protected void doProcessProperties(ConfigurableListableBeanFactory beanFactoryToProcess, StringValueResolver valueResolver)
/*     */   {
/* 199 */     BeanDefinitionVisitor visitor = new BeanDefinitionVisitor(valueResolver);
/*     */ 
/* 201 */     String[] beanNames = beanFactoryToProcess.getBeanDefinitionNames();
/* 202 */     for (String curName : beanNames)
/*     */     {
/* 205 */       if ((!curName.equals(this.beanName)) || (!beanFactoryToProcess.equals(this.beanFactory))) {
/* 206 */         BeanDefinition bd = beanFactoryToProcess.getBeanDefinition(curName);
/*     */         try {
/* 208 */           visitor.visitBeanDefinition(bd);
/*     */         }
/*     */         catch (Exception ex) {
/* 211 */           throw new BeanDefinitionStoreException(bd.getResourceDescription(), curName, ex.getMessage());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 217 */     beanFactoryToProcess.resolveAliases(valueResolver);
/*     */ 
/* 220 */     beanFactoryToProcess.addEmbeddedValueResolver(valueResolver);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.PlaceholderConfigurerSupport
 * JD-Core Version:    0.6.2
 */