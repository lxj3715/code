/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.util.PropertyPlaceholderHelper;
/*     */ import org.springframework.util.PropertyPlaceholderHelper.PlaceholderResolver;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class PropertyPlaceholderConfigurer extends PlaceholderConfigurerSupport
/*     */ {
/*     */   public static final int SYSTEM_PROPERTIES_MODE_NEVER = 0;
/*     */   public static final int SYSTEM_PROPERTIES_MODE_FALLBACK = 1;
/*     */   public static final int SYSTEM_PROPERTIES_MODE_OVERRIDE = 2;
/*  81 */   private static final Constants constants = new Constants(PropertyPlaceholderConfigurer.class);
/*     */   private int systemPropertiesMode;
/*     */   private boolean searchSystemEnvironment;
/*     */ 
/*     */   public PropertyPlaceholderConfigurer()
/*     */   {
/*  83 */     this.systemPropertiesMode = 1;
/*     */ 
/*  85 */     this.searchSystemEnvironment = true;
/*     */   }
/*     */ 
/*     */   public void setSystemPropertiesModeName(String constantName)
/*     */     throws IllegalArgumentException
/*     */   {
/*  96 */     this.systemPropertiesMode = constants.asNumber(constantName).intValue();
/*     */   }
/*     */ 
/*     */   public void setSystemPropertiesMode(int systemPropertiesMode)
/*     */   {
/* 112 */     this.systemPropertiesMode = systemPropertiesMode;
/*     */   }
/*     */ 
/*     */   public void setSearchSystemEnvironment(boolean searchSystemEnvironment)
/*     */   {
/* 134 */     this.searchSystemEnvironment = searchSystemEnvironment;
/*     */   }
/*     */ 
/*     */   protected String resolvePlaceholder(String placeholder, Properties props, int systemPropertiesMode)
/*     */   {
/* 154 */     String propVal = null;
/* 155 */     if (systemPropertiesMode == 2) {
/* 156 */       propVal = resolveSystemProperty(placeholder);
/*     */     }
/* 158 */     if (propVal == null) {
/* 159 */       propVal = resolvePlaceholder(placeholder, props);
/*     */     }
/* 161 */     if ((propVal == null) && (systemPropertiesMode == 1)) {
/* 162 */       propVal = resolveSystemProperty(placeholder);
/*     */     }
/* 164 */     return propVal;
/*     */   }
/*     */ 
/*     */   protected String resolvePlaceholder(String placeholder, Properties props)
/*     */   {
/* 181 */     return props.getProperty(placeholder);
/*     */   }
/*     */ 
/*     */   protected String resolveSystemProperty(String key)
/*     */   {
/*     */     try
/*     */     {
/* 195 */       String value = System.getProperty(key);
/* 196 */       if ((value == null) && (this.searchSystemEnvironment));
/* 197 */       return System.getenv(key);
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 202 */       if (this.logger.isDebugEnabled())
/* 203 */         this.logger.debug("Could not access system property '" + key + "': " + ex);
/*     */     }
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props)
/*     */     throws BeansException
/*     */   {
/* 218 */     StringValueResolver valueResolver = new PlaceholderResolvingStringValueResolver(props);
/*     */ 
/* 220 */     doProcessProperties(beanFactoryToProcess, valueResolver);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected String parseStringValue(String strVal, Properties props, Set<?> visitedPlaceholders)
/*     */   {
/* 235 */     PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper(this.placeholderPrefix, this.placeholderSuffix, this.valueSeparator, this.ignoreUnresolvablePlaceholders);
/*     */ 
/* 237 */     PropertyPlaceholderHelper.PlaceholderResolver resolver = new PropertyPlaceholderConfigurerResolver(props, null);
/* 238 */     return helper.replacePlaceholders(strVal, resolver);
/*     */   }
/*     */ 
/*     */   private class PropertyPlaceholderConfigurerResolver
/*     */     implements PropertyPlaceholderHelper.PlaceholderResolver
/*     */   {
/*     */     private final Properties props;
/*     */ 
/*     */     private PropertyPlaceholderConfigurerResolver(Properties props)
/*     */     {
/* 267 */       this.props = props;
/*     */     }
/*     */ 
/*     */     public String resolvePlaceholder(String placeholderName)
/*     */     {
/* 272 */       return PropertyPlaceholderConfigurer.this.resolvePlaceholder(placeholderName, this.props, PropertyPlaceholderConfigurer.this.systemPropertiesMode);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class PlaceholderResolvingStringValueResolver
/*     */     implements StringValueResolver
/*     */   {
/*     */     private final PropertyPlaceholderHelper helper;
/*     */     private final PropertyPlaceholderHelper.PlaceholderResolver resolver;
/*     */ 
/*     */     public PlaceholderResolvingStringValueResolver(Properties props)
/*     */     {
/* 249 */       this.helper = new PropertyPlaceholderHelper(PropertyPlaceholderConfigurer.this.placeholderPrefix, PropertyPlaceholderConfigurer.this.placeholderSuffix, PropertyPlaceholderConfigurer.this.valueSeparator, PropertyPlaceholderConfigurer.this.ignoreUnresolvablePlaceholders);
/*     */ 
/* 251 */       this.resolver = new PropertyPlaceholderConfigurer.PropertyPlaceholderConfigurerResolver(PropertyPlaceholderConfigurer.this, props, null);
/*     */     }
/*     */ 
/*     */     public String resolveStringValue(String strVal) throws BeansException
/*     */     {
/* 256 */       String value = this.helper.replacePlaceholders(strVal, this.resolver);
/* 257 */       return value.equals(PropertyPlaceholderConfigurer.this.nullValue) ? null : value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.config.PropertyPlaceholderConfigurer
 * JD-Core Version:    0.6.2
 */