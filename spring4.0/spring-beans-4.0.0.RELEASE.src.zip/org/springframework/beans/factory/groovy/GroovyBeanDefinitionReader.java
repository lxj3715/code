/*     */ package org.springframework.beans.factory.groovy;
/*     */ 
/*     */ import groovy.lang.Binding;
/*     */ import groovy.lang.Closure;
/*     */ import groovy.lang.GString;
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.lang.GroovyObjectSupport;
/*     */ import groovy.lang.GroovyShell;
/*     */ import groovy.lang.GroovySystem;
/*     */ import groovy.lang.MetaClass;
/*     */ import groovy.lang.MetaClassRegistry;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.codehaus.groovy.runtime.DefaultGroovyMethods;
/*     */ import org.codehaus.groovy.runtime.InvokerHelper;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanDefinitionParsingException;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.beans.factory.xml.NamespaceHandler;
/*     */ import org.springframework.beans.factory.xml.NamespaceHandlerResolver;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.io.DescriptiveResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ 
/*     */ public class GroovyBeanDefinitionReader extends AbstractBeanDefinitionReader
/*     */   implements GroovyObject
/*     */ {
/*     */   private final XmlBeanDefinitionReader xmlBeanDefinitionReader;
/* 127 */   private MetaClass metaClass = GroovySystem.getMetaClassRegistry().getMetaClass(getClass());
/*     */   private Binding binding;
/*     */   private GroovyBeanDefinitionWrapper currentBeanDefinition;
/* 133 */   private final Map<String, String> namespaces = new HashMap();
/*     */ 
/* 135 */   private final Map<String, DeferredProperty> deferredProperties = new HashMap();
/*     */ 
/*     */   public GroovyBeanDefinitionReader(BeanDefinitionRegistry registry)
/*     */   {
/* 144 */     super(registry);
/* 145 */     this.xmlBeanDefinitionReader = new XmlBeanDefinitionReader(registry);
/* 146 */     this.xmlBeanDefinitionReader.setValidating(false);
/*     */   }
/*     */ 
/*     */   public GroovyBeanDefinitionReader(XmlBeanDefinitionReader xmlBeanDefinitionReader)
/*     */   {
/* 156 */     super(xmlBeanDefinitionReader.getRegistry());
/* 157 */     this.xmlBeanDefinitionReader = xmlBeanDefinitionReader;
/*     */   }
/*     */ 
/*     */   public void setMetaClass(MetaClass metaClass)
/*     */   {
/* 162 */     this.metaClass = metaClass;
/*     */   }
/*     */ 
/*     */   public MetaClass getMetaClass() {
/* 166 */     return this.metaClass;
/*     */   }
/*     */ 
/*     */   public void setBinding(Binding binding)
/*     */   {
/* 174 */     this.binding = binding;
/*     */   }
/*     */ 
/*     */   public Binding getBinding()
/*     */   {
/* 181 */     return this.binding;
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(Resource resource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 194 */     return loadBeanDefinitions(new EncodedResource(resource));
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(EncodedResource encodedResource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 205 */     Closure beans = new Closure(this) {
/*     */       public Object call(Object[] args) {
/* 207 */         GroovyBeanDefinitionReader.this.invokeBeanDefiningClosure((Closure)args[0]);
/* 208 */         return null;
/*     */       }
/*     */     };
/* 211 */     Binding binding = new Binding()
/*     */     {
/*     */       public void setVariable(String name, Object value) {
/* 214 */         if (GroovyBeanDefinitionReader.this.currentBeanDefinition != null) {
/* 215 */           GroovyBeanDefinitionReader.this.applyPropertyToBeanDefinition(name, value);
/*     */         }
/*     */         else
/* 218 */           super.setVariable(name, value);
/*     */       }
/*     */     };
/* 222 */     binding.setVariable("beans", beans);
/*     */ 
/* 224 */     int countBefore = getRegistry().getBeanDefinitionCount();
/*     */     try {
/* 226 */       GroovyShell shell = new GroovyShell(getResourceLoader().getClassLoader(), binding);
/* 227 */       shell.evaluate(encodedResource.getReader(), encodedResource.getResource().getFilename());
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 231 */       throw new BeanDefinitionParsingException(new Problem("Error evaluating Groovy script: " + ex.getMessage(), new Location(encodedResource
/* 231 */         .getResource()), null, ex));
/*     */     }
/* 233 */     return getRegistry().getBeanDefinitionCount() - countBefore;
/*     */   }
/*     */ 
/*     */   public GroovyBeanDefinitionReader beans(Closure closure)
/*     */   {
/* 245 */     return invokeBeanDefiningClosure(closure);
/*     */   }
/*     */ 
/*     */   public GenericBeanDefinition bean(Class<?> type)
/*     */   {
/* 254 */     GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 255 */     beanDefinition.setBeanClass(type);
/* 256 */     return beanDefinition;
/*     */   }
/*     */ 
/*     */   public AbstractBeanDefinition bean(Class<?> type, Object[] args)
/*     */   {
/* 266 */     GroovyBeanDefinitionWrapper current = this.currentBeanDefinition;
/*     */     try {
/* 268 */       Closure callable = null;
/* 269 */       Collection constructorArgs = null;
/*     */       int index;
/* 270 */       if ((args != null) && (args.length > 0)) {
/* 271 */         index = args.length;
/* 272 */         Object lastArg = args[(index - 1)];
/*     */ 
/* 274 */         if ((lastArg instanceof Closure)) {
/* 275 */           callable = (Closure)lastArg;
/* 276 */           index--;
/*     */         }
/* 278 */         if (index > -1) {
/* 279 */           constructorArgs = resolveConstructorArguments(args, 0, index);
/*     */         }
/*     */       }
/* 282 */       this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(null, type, constructorArgs);
/* 283 */       if (callable != null) {
/* 284 */         callable.call(this.currentBeanDefinition);
/*     */       }
/* 286 */       return this.currentBeanDefinition.getBeanDefinition();
/*     */     }
/*     */     finally
/*     */     {
/* 290 */       this.currentBeanDefinition = current;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void xmlns(Map<String, String> definition)
/*     */   {
/* 299 */     if (!definition.isEmpty())
/* 300 */       for (Map.Entry entry : definition.entrySet()) {
/* 301 */         String namespace = (String)entry.getKey();
/* 302 */         String uri = (String)entry.getValue();
/* 303 */         if (uri == null) {
/* 304 */           throw new IllegalArgumentException("Namespace definition must supply a non-null URI");
/*     */         }
/* 306 */         NamespaceHandler namespaceHandler = this.xmlBeanDefinitionReader.getNamespaceHandlerResolver().resolve(uri);
/* 307 */         if (namespaceHandler == null) {
/* 308 */           throw new BeanDefinitionParsingException(new Problem("No namespace handler found for URI: " + uri, new Location(new DescriptiveResource("Groovy"))));
/*     */         }
/*     */ 
/* 311 */         this.namespaces.put(namespace, uri);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void importBeans(String resourcePattern)
/*     */     throws IOException
/*     */   {
/* 322 */     Resource[] resources = ResourcePatternUtils.getResourcePatternResolver(getResourceLoader()).getResources(resourcePattern);
/* 323 */     for (Resource resource : resources) {
/* 324 */       String filename = resource.getFilename();
/* 325 */       if (filename.endsWith(".groovy")) {
/* 326 */         loadBeanDefinitions(resource);
/*     */       }
/* 328 */       else if (filename.endsWith(".xml"))
/* 329 */         this.xmlBeanDefinitionReader.loadBeanDefinitions(resource);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object invokeMethod(String name, Object arg)
/*     */   {
/* 342 */     Object[] args = (Object[])arg;
/* 343 */     if (("beans".equals(name)) && (args.length == 1) && ((args[0] instanceof Closure))) {
/* 344 */       return beans((Closure)args[0]);
/*     */     }
/* 346 */     if ("ref".equals(name))
/*     */     {
/* 348 */       if (args[0] == null)
/* 349 */         throw new IllegalArgumentException("Argument to ref() is not a valid bean or was not found");
/*     */       String refName;
/*     */       String refName;
/* 351 */       if ((args[0] instanceof RuntimeBeanReference)) {
/* 352 */         refName = ((RuntimeBeanReference)args[0]).getBeanName();
/*     */       }
/*     */       else {
/* 355 */         refName = args[0].toString();
/*     */       }
/* 357 */       boolean parentRef = false;
/* 358 */       if ((args.length > 1) && 
/* 359 */         ((args[1] instanceof Boolean))) {
/* 360 */         parentRef = ((Boolean)args[1]).booleanValue();
/*     */       }
/*     */ 
/* 363 */       return new RuntimeBeanReference(refName, parentRef);
/*     */     }
/* 365 */     if ((this.namespaces.containsKey(name)) && (args.length > 0) && ((args[0] instanceof Closure))) {
/* 366 */       GroovyDynamicElementReader reader = createDynamicElementReader(name);
/* 367 */       reader.invokeMethod("doCall", args);
/*     */     } else {
/* 369 */       if ((args.length > 0) && ((args[0] instanceof Closure)))
/*     */       {
/* 371 */         return invokeBeanDefiningMethod(name, args);
/*     */       }
/* 373 */       if ((args.length > 0) && (((args[0] instanceof Class)) || ((args[0] instanceof RuntimeBeanReference)) || ((args[0] instanceof Map)))) {
/* 374 */         return invokeBeanDefiningMethod(name, args);
/*     */       }
/* 376 */       if ((args.length > 1) && ((args[(args.length - 1)] instanceof Closure)))
/* 377 */         return invokeBeanDefiningMethod(name, args);
/*     */     }
/* 379 */     MetaClass mc = DefaultGroovyMethods.getMetaClass(getRegistry());
/* 380 */     if (!mc.respondsTo(getRegistry(), name, args).isEmpty()) {
/* 381 */       return mc.invokeMethod(getRegistry(), name, args);
/*     */     }
/* 383 */     return this;
/*     */   }
/*     */ 
/*     */   private boolean addDeferredProperty(String property, Object newValue) {
/* 387 */     if ((newValue instanceof List)) {
/* 388 */       this.deferredProperties.put(this.currentBeanDefinition.getBeanName() + '.' + property, new DeferredProperty(this.currentBeanDefinition, property, newValue));
/*     */ 
/* 390 */       return true;
/*     */     }
/* 392 */     if ((newValue instanceof Map)) {
/* 393 */       this.deferredProperties.put(this.currentBeanDefinition.getBeanName() + '.' + property, new DeferredProperty(this.currentBeanDefinition, property, newValue));
/*     */ 
/* 395 */       return true;
/*     */     }
/* 397 */     return false;
/*     */   }
/*     */ 
/*     */   private void finalizeDeferredProperties() {
/* 401 */     for (DeferredProperty dp : this.deferredProperties.values()) {
/* 402 */       if ((dp.value instanceof List)) {
/* 403 */         dp.value = manageListIfNecessary((List)dp.value);
/*     */       }
/* 405 */       else if ((dp.value instanceof Map)) {
/* 406 */         dp.value = manageMapIfNecessary((Map)dp.value);
/*     */       }
/* 408 */       dp.apply();
/*     */     }
/* 410 */     this.deferredProperties.clear();
/*     */   }
/*     */ 
/*     */   protected GroovyBeanDefinitionReader invokeBeanDefiningClosure(Closure callable)
/*     */   {
/* 419 */     callable.setDelegate(this);
/* 420 */     callable.call();
/* 421 */     finalizeDeferredProperties();
/* 422 */     return this;
/*     */   }
/*     */ 
/*     */   private GroovyBeanDefinitionWrapper invokeBeanDefiningMethod(String beanName, Object[] args)
/*     */   {
/* 433 */     boolean hasClosureArgument = args[(args.length - 1)] instanceof Closure;
/* 434 */     if ((args[0] instanceof Class)) {
/* 435 */       Class beanClass = (args[0] instanceof Class) ? (Class)args[0] : args[0].getClass();
/* 436 */       if (args.length >= 1) {
/* 437 */         if (hasClosureArgument) {
/* 438 */           if (args.length - 1 != 1) {
/* 439 */             this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName, beanClass, 
/* 440 */               resolveConstructorArguments(args, 1, args.length - 1));
/*     */           }
/*     */           else
/*     */           {
/* 443 */             this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName, beanClass);
/*     */           }
/*     */         }
/*     */         else {
/* 447 */           this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName, beanClass, 
/* 448 */             resolveConstructorArguments(args, 1, args.length));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/* 453 */     else if ((args[0] instanceof RuntimeBeanReference)) {
/* 454 */       this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName);
/* 455 */       this.currentBeanDefinition.getBeanDefinition().setFactoryBeanName(((RuntimeBeanReference)args[0]).getBeanName());
/*     */     }
/* 457 */     else if ((args[0] instanceof Map))
/*     */     {
/*     */       Map namedArgs;
/*     */       Iterator localIterator;
/* 459 */       if ((args.length > 1) && ((args[1] instanceof Class))) {
/* 460 */         List constructorArgs = resolveConstructorArguments(args, 2, hasClosureArgument ? args.length - 1 : args.length);
/* 461 */         this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName, (Class)args[1], constructorArgs);
/* 462 */         namedArgs = (Map)args[0];
/* 463 */         for (localIterator = namedArgs.keySet().iterator(); localIterator.hasNext(); ) { Object o = localIterator.next();
/* 464 */           String propName = (String)o;
/* 465 */           setProperty(propName, namedArgs.get(propName));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 470 */         this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName);
/*     */ 
/* 472 */         Map.Entry factoryBeanEntry = (Map.Entry)((Map)args[0]).entrySet().iterator().next();
/*     */ 
/* 475 */         int constructorArgsTest = hasClosureArgument ? 2 : 1;
/*     */ 
/* 477 */         if (args.length > constructorArgsTest)
/*     */         {
/* 479 */           int endOfConstructArgs = hasClosureArgument ? args.length - 1 : args.length;
/* 480 */           this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName, null, 
/* 481 */             resolveConstructorArguments(args, 1, endOfConstructArgs));
/*     */         }
/*     */         else
/*     */         {
/* 484 */           this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName);
/*     */         }
/* 486 */         this.currentBeanDefinition.getBeanDefinition().setFactoryBeanName(factoryBeanEntry.getKey().toString());
/* 487 */         this.currentBeanDefinition.getBeanDefinition().setFactoryMethodName(factoryBeanEntry.getValue().toString());
/*     */       }
/*     */ 
/*     */     }
/* 491 */     else if ((args[0] instanceof Closure)) {
/* 492 */       this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName);
/* 493 */       this.currentBeanDefinition.getBeanDefinition().setAbstract(true);
/*     */     }
/*     */     else {
/* 496 */       List constructorArgs = resolveConstructorArguments(args, 0, hasClosureArgument ? args.length - 1 : args.length);
/* 497 */       this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(beanName, null, constructorArgs);
/*     */     }
/*     */ 
/* 500 */     if (hasClosureArgument) {
/* 501 */       Closure callable = (Closure)args[(args.length - 1)];
/* 502 */       callable.setDelegate(this);
/* 503 */       callable.setResolveStrategy(1);
/* 504 */       callable.call(new Object[] { this.currentBeanDefinition });
/*     */     }
/*     */ 
/* 507 */     GroovyBeanDefinitionWrapper beanDefinition = this.currentBeanDefinition;
/* 508 */     this.currentBeanDefinition = null;
/* 509 */     beanDefinition.getBeanDefinition().setAttribute(GroovyBeanDefinitionWrapper.class.getName(), beanDefinition);
/* 510 */     getRegistry().registerBeanDefinition(beanName, beanDefinition.getBeanDefinition());
/* 511 */     return beanDefinition;
/*     */   }
/*     */ 
/*     */   protected List<Object> resolveConstructorArguments(Object[] args, int start, int end) {
/* 515 */     Object[] constructorArgs = Arrays.copyOfRange(args, start, end);
/* 516 */     for (int i = 0; i < constructorArgs.length; i++) {
/* 517 */       if ((constructorArgs[i] instanceof GString)) {
/* 518 */         constructorArgs[i] = constructorArgs[i].toString();
/*     */       }
/* 520 */       else if ((constructorArgs[i] instanceof List)) {
/* 521 */         constructorArgs[i] = manageListIfNecessary((List)constructorArgs[i]);
/*     */       }
/* 523 */       else if ((constructorArgs[i] instanceof Map)) {
/* 524 */         constructorArgs[i] = manageMapIfNecessary((Map)constructorArgs[i]);
/*     */       }
/*     */     }
/* 527 */     return Arrays.asList(constructorArgs);
/*     */   }
/*     */ 
/*     */   private Object manageMapIfNecessary(Map<?, ?> map)
/*     */   {
/* 537 */     boolean containsRuntimeRefs = false;
/* 538 */     for (Iterator localIterator = map.values().iterator(); localIterator.hasNext(); ) { Object element = localIterator.next();
/* 539 */       if ((element instanceof RuntimeBeanReference)) {
/* 540 */         containsRuntimeRefs = true;
/* 541 */         break;
/*     */       }
/*     */     }
/* 544 */     if (containsRuntimeRefs) {
/* 545 */       Object managedMap = new ManagedMap();
/* 546 */       ((Map)managedMap).putAll(map);
/* 547 */       return managedMap;
/*     */     }
/* 549 */     return map;
/*     */   }
/*     */ 
/*     */   private Object manageListIfNecessary(List<?> list)
/*     */   {
/* 559 */     boolean containsRuntimeRefs = false;
/* 560 */     for (Iterator localIterator = list.iterator(); localIterator.hasNext(); ) { Object element = localIterator.next();
/* 561 */       if ((element instanceof RuntimeBeanReference)) {
/* 562 */         containsRuntimeRefs = true;
/* 563 */         break;
/*     */       }
/*     */     }
/* 566 */     if (containsRuntimeRefs) {
/* 567 */       Object managedList = new ManagedList();
/* 568 */       ((List)managedList).addAll(list);
/* 569 */       return managedList;
/*     */     }
/* 571 */     return list;
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, Object value)
/*     */   {
/* 579 */     if (this.currentBeanDefinition != null)
/* 580 */       applyPropertyToBeanDefinition(name, value);
/*     */   }
/*     */ 
/*     */   protected void applyPropertyToBeanDefinition(String name, Object value)
/*     */   {
/* 585 */     if ((value instanceof GString)) {
/* 586 */       value = value.toString();
/*     */     }
/* 588 */     if (addDeferredProperty(name, value)) {
/* 589 */       return;
/*     */     }
/* 591 */     if ((value instanceof Closure)) {
/* 592 */       GroovyBeanDefinitionWrapper current = this.currentBeanDefinition;
/*     */       try {
/* 594 */         Closure callable = (Closure)value;
/* 595 */         Class parameterType = callable.getParameterTypes()[0];
/* 596 */         if (parameterType.equals(Object.class)) {
/* 597 */           this.currentBeanDefinition = new GroovyBeanDefinitionWrapper("");
/* 598 */           callable.call(this.currentBeanDefinition);
/*     */         }
/*     */         else {
/* 601 */           this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(null, parameterType);
/* 602 */           callable.call((Object)null);
/*     */         }
/*     */ 
/* 605 */         value = this.currentBeanDefinition.getBeanDefinition();
/*     */       }
/*     */       finally {
/* 608 */         this.currentBeanDefinition = current;
/*     */       }
/*     */     }
/* 611 */     this.currentBeanDefinition.addProperty(name, value);
/*     */   }
/*     */ 
/*     */   public Object getProperty(String name)
/*     */   {
/* 621 */     Binding binding = getBinding();
/* 622 */     if ((binding != null) && (binding.hasVariable(name))) {
/* 623 */       return binding.getVariable(name);
/*     */     }
/*     */ 
/* 626 */     if (this.namespaces.containsKey(name)) {
/* 627 */       return createDynamicElementReader(name);
/*     */     }
/* 629 */     if (getRegistry().containsBeanDefinition(name))
/*     */     {
/* 631 */       GroovyBeanDefinitionWrapper beanDefinition = (GroovyBeanDefinitionWrapper)getRegistry().getBeanDefinition(name).getAttribute(GroovyBeanDefinitionWrapper.class.getName());
/* 632 */       if (beanDefinition != null) {
/* 633 */         return new GroovyRuntimeBeanReference(name, beanDefinition, false);
/*     */       }
/*     */ 
/* 636 */       return new RuntimeBeanReference(name, false);
/*     */     }
/*     */ 
/* 641 */     if (this.currentBeanDefinition != null) {
/* 642 */       MutablePropertyValues pvs = this.currentBeanDefinition.getBeanDefinition().getPropertyValues();
/* 643 */       if (pvs.contains(name)) {
/* 644 */         return pvs.get(name);
/*     */       }
/*     */ 
/* 647 */       DeferredProperty dp = (DeferredProperty)this.deferredProperties.get(this.currentBeanDefinition.getBeanName() + name);
/* 648 */       if (dp != null) {
/* 649 */         return dp.value;
/*     */       }
/*     */ 
/* 652 */       return getMetaClass().getProperty(this, name);
/*     */     }
/*     */ 
/* 657 */     return getMetaClass().getProperty(this, name);
/*     */   }
/*     */ 
/*     */   private GroovyDynamicElementReader createDynamicElementReader(String namespace)
/*     */   {
/* 663 */     XmlReaderContext readerContext = this.xmlBeanDefinitionReader.createReaderContext(new DescriptiveResource("Groovy"));
/* 664 */     BeanDefinitionParserDelegate delegate = new BeanDefinitionParserDelegate(readerContext, getEnvironment());
/* 665 */     boolean decorating = this.currentBeanDefinition != null;
/* 666 */     if (!decorating) {
/* 667 */       this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(namespace);
/*     */     }
/* 669 */     return new GroovyDynamicElementReader(namespace, this.namespaces, delegate, this.currentBeanDefinition, decorating)
/*     */     {
/*     */       protected void afterInvocation() {
/* 672 */         if (!this.decorating)
/* 673 */           GroovyBeanDefinitionReader.this.currentBeanDefinition = null;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private class GroovyRuntimeBeanReference extends RuntimeBeanReference
/*     */     implements GroovyObject
/*     */   {
/*     */     private final GroovyBeanDefinitionWrapper beanDefinition;
/*     */     private MetaClass metaClass;
/*     */ 
/*     */     public GroovyRuntimeBeanReference(String beanName, GroovyBeanDefinitionWrapper beanDefinition, boolean toParent)
/*     */     {
/* 715 */       super(toParent);
/* 716 */       this.beanDefinition = beanDefinition;
/* 717 */       this.metaClass = InvokerHelper.getMetaClass(this);
/*     */     }
/*     */ 
/*     */     public MetaClass getMetaClass() {
/* 721 */       return this.metaClass;
/*     */     }
/*     */ 
/*     */     public Object getProperty(String property) {
/* 725 */       if (property.equals("beanName")) {
/* 726 */         return getBeanName();
/*     */       }
/* 728 */       if (property.equals("source")) {
/* 729 */         return getSource();
/*     */       }
/* 731 */       if (this.beanDefinition != null)
/*     */       {
/* 733 */         return new GroovyPropertyValue(property, this.beanDefinition
/* 733 */           .getBeanDefinition().getPropertyValues().get(property));
/*     */       }
/*     */ 
/* 736 */       return this.metaClass.getProperty(this, property);
/*     */     }
/*     */ 
/*     */     public Object invokeMethod(String name, Object args)
/*     */     {
/* 741 */       return this.metaClass.invokeMethod(this, name, args);
/*     */     }
/*     */ 
/*     */     public void setMetaClass(MetaClass metaClass) {
/* 745 */       this.metaClass = metaClass;
/*     */     }
/*     */ 
/*     */     public void setProperty(String property, Object newValue) {
/* 749 */       if (!GroovyBeanDefinitionReader.this.addDeferredProperty(property, newValue))
/* 750 */         this.beanDefinition.getBeanDefinition().getPropertyValues().add(property, newValue);
/*     */     }
/*     */ 
/*     */     private class GroovyPropertyValue extends GroovyObjectSupport
/*     */     {
/*     */       private final String propertyName;
/*     */       private final Object propertyValue;
/*     */ 
/*     */       public GroovyPropertyValue(String propertyName, Object propertyValue)
/*     */       {
/* 766 */         this.propertyName = propertyName;
/* 767 */         this.propertyValue = propertyValue;
/*     */       }
/*     */ 
/*     */       public void leftShift(Object value) {
/* 771 */         InvokerHelper.invokeMethod(this.propertyValue, "leftShift", value);
/* 772 */         updateDeferredProperties(value);
/*     */       }
/*     */ 
/*     */       public boolean add(Object value) {
/* 776 */         boolean retVal = ((Boolean)InvokerHelper.invokeMethod(this.propertyValue, "add", value)).booleanValue();
/* 777 */         updateDeferredProperties(value);
/* 778 */         return retVal;
/*     */       }
/*     */ 
/*     */       public boolean addAll(Collection values) {
/* 782 */         boolean retVal = ((Boolean)InvokerHelper.invokeMethod(this.propertyValue, "addAll", values)).booleanValue();
/* 783 */         for (Iterator localIterator = values.iterator(); localIterator.hasNext(); ) { Object value = localIterator.next();
/* 784 */           updateDeferredProperties(value);
/*     */         }
/* 786 */         return retVal;
/*     */       }
/*     */ 
/*     */       public Object invokeMethod(String name, Object args) {
/* 790 */         return InvokerHelper.invokeMethod(this.propertyValue, name, args);
/*     */       }
/*     */ 
/*     */       public Object getProperty(String name) {
/* 794 */         return InvokerHelper.getProperty(this.propertyValue, name);
/*     */       }
/*     */ 
/*     */       public void setProperty(String name, Object value) {
/* 798 */         InvokerHelper.setProperty(this.propertyValue, name, value);
/*     */       }
/*     */ 
/*     */       private void updateDeferredProperties(Object value) {
/* 802 */         if ((value instanceof RuntimeBeanReference))
/* 803 */           GroovyBeanDefinitionReader.this.deferredProperties.put(GroovyBeanDefinitionReader.GroovyRuntimeBeanReference.this.beanDefinition.getBeanName(), new GroovyBeanDefinitionReader.DeferredProperty(GroovyBeanDefinitionReader.GroovyRuntimeBeanReference.this.beanDefinition, 
/* 804 */             this.propertyName, this.propertyValue));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DeferredProperty
/*     */   {
/*     */     private final GroovyBeanDefinitionWrapper beanDefinition;
/*     */     private final String name;
/*     */     public Object value;
/*     */ 
/*     */     public DeferredProperty(GroovyBeanDefinitionWrapper beanDefinition, String name, Object value)
/*     */     {
/* 694 */       this.beanDefinition = beanDefinition;
/* 695 */       this.name = name;
/* 696 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public void apply() {
/* 700 */       this.beanDefinition.addProperty(this.name, this.value);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.groovy.GroovyBeanDefinitionReader
 * JD-Core Version:    0.6.2
 */