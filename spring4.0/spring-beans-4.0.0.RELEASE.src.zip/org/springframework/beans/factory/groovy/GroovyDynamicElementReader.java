/*     */ package org.springframework.beans.factory.groovy;
/*     */ 
/*     */ import groovy.lang.Closure;
/*     */ import groovy.lang.GroovyObjectSupport;
/*     */ import groovy.lang.Reference;
/*     */ import groovy.xml.StreamingMarkupBuilder;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.codehaus.groovy.runtime.BytecodeInterface8;
/*     */ import org.codehaus.groovy.runtime.GStringImpl;
/*     */ import org.codehaus.groovy.runtime.GeneratedClosure;
/*     */ import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
/*     */ import org.codehaus.groovy.runtime.callsite.CallSite;
/*     */ import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class GroovyDynamicElementReader extends GroovyObjectSupport
/*     */ {
/*     */   private final String rootNamespace;
/*     */   private final Map<String, String> xmlNamespaces;
/*     */   private final BeanDefinitionParserDelegate delegate;
/*     */   private final GroovyBeanDefinitionWrapper beanDefinition;
/*     */   protected final boolean decorating;
/*     */   private boolean callAfterInvocation;
/*     */ 
/*     */   public GroovyDynamicElementReader(String namespace, Map<String, String> namespaceMap, BeanDefinitionParserDelegate delegate, GroovyBeanDefinitionWrapper beanDefinition, boolean decorating)
/*     */   {
/*  50 */     boolean bool1 = true; this.callAfterInvocation = bool1;
/*  51 */     String str = (String)namespace; this.rootNamespace = ((String)ScriptBytecodeAdapter.castToType(str, $get$$class$java$lang$String()));
/*  52 */     Map localMap = (Map)namespaceMap; this.xmlNamespaces = ((Map)ScriptBytecodeAdapter.castToType(localMap, $get$$class$java$util$Map()));
/*  53 */     BeanDefinitionParserDelegate localBeanDefinitionParserDelegate = (BeanDefinitionParserDelegate)delegate; this.delegate = ((BeanDefinitionParserDelegate)ScriptBytecodeAdapter.castToType(localBeanDefinitionParserDelegate, $get$$class$org$springframework$beans$factory$xml$BeanDefinitionParserDelegate()));
/*  54 */     GroovyBeanDefinitionWrapper localGroovyBeanDefinitionWrapper = (GroovyBeanDefinitionWrapper)beanDefinition; this.beanDefinition = ((GroovyBeanDefinitionWrapper)ScriptBytecodeAdapter.castToType(localGroovyBeanDefinitionWrapper, $get$$class$org$springframework$beans$factory$groovy$GroovyBeanDefinitionWrapper()));
/*  55 */     boolean bool2 = decorating; this.decorating = DefaultTypeTransformation.booleanUnbox((Boolean)DefaultTypeTransformation.box(bool2));
/*     */   }
/*     */ 
/*     */   public Object invokeMethod(String name, Object args)
/*     */   {
/*  61 */     Reference name = new Reference(name); Reference args = new Reference(args); CallSite[] arrayOfCallSite = $getCallSiteArray(); if (DefaultTypeTransformation.booleanUnbox(arrayOfCallSite[0].call((String)name.get(), "doCall"))) {
/*  62 */       Object callable = arrayOfCallSite[1].call((Object)args.get(), (Integer)DefaultTypeTransformation.box(0));
/*  63 */       Object localObject1 = arrayOfCallSite[2].callGetProperty($get$$class$groovy$lang$Closure()); ScriptBytecodeAdapter.setProperty(localObject1, null, callable, "resolveStrategy");
/*  64 */       GroovyDynamicElementReader localGroovyDynamicElementReader = this; ScriptBytecodeAdapter.setProperty(localGroovyDynamicElementReader, null, callable, "delegate");
/*  65 */       Object result = arrayOfCallSite[3].call(callable);
/*     */ 
/*  67 */       if (this.callAfterInvocation) {
/*  68 */         arrayOfCallSite[4].callCurrent(this);
/*  69 */         boolean bool1 = false; this.callAfterInvocation = DefaultTypeTransformation.booleanUnbox((Boolean)DefaultTypeTransformation.box(bool1));
/*     */       }
/*  71 */       return result;
/*     */     }
/*     */     else
/*     */     {
/*  75 */       Reference builder = new Reference((StreamingMarkupBuilder)ScriptBytecodeAdapter.castToType(arrayOfCallSite[5].callConstructor($get$$class$groovy$xml$StreamingMarkupBuilder()), $get$$class$groovy$xml$StreamingMarkupBuilder()));
/*  76 */       Reference myNamespace = new Reference(this.rootNamespace);
/*  77 */       Reference myNamespaces = new Reference(this.xmlNamespaces);
/*     */ 
/*  79 */       Object callable = new _invokeMethod_closure1(this, args, myNamespaces, myNamespace, builder, name);
/*     */ 
/*  90 */       Object localObject2 = arrayOfCallSite[6].callGetProperty($get$$class$groovy$lang$Closure()); ScriptBytecodeAdapter.setProperty(localObject2, null, callable, "resolveStrategy");
/*  91 */       StreamingMarkupBuilder localStreamingMarkupBuilder = (StreamingMarkupBuilder)builder.get(); ScriptBytecodeAdapter.setProperty(localStreamingMarkupBuilder, null, callable, "delegate");
/*  92 */       Object writable = arrayOfCallSite[7].call((StreamingMarkupBuilder)builder.get(), callable);
/*  93 */       Object sw = arrayOfCallSite[8].callConstructor($get$$class$java$io$StringWriter());
/*  94 */       arrayOfCallSite[9].call(writable, sw);
/*     */ 
/*  96 */       Element element = (Element)ScriptBytecodeAdapter.castToType(arrayOfCallSite[10].callGetProperty(arrayOfCallSite[11].call(arrayOfCallSite[12].callGetProperty(this.delegate), arrayOfCallSite[13].call(sw))), $get$$class$org$w3c$dom$Element());
/*  97 */       arrayOfCallSite[14].call(this.delegate, element);
/*  98 */       if (this.decorating) {
/*  99 */         BeanDefinitionHolder holder = (BeanDefinitionHolder)ScriptBytecodeAdapter.castToType(arrayOfCallSite[15].callGetProperty(this.beanDefinition), $get$$class$org$springframework$beans$factory$config$BeanDefinitionHolder());
/* 100 */         Object localObject3 = arrayOfCallSite[16].call(this.delegate, element, holder, null); holder = (BeanDefinitionHolder)ScriptBytecodeAdapter.castToType(localObject3, $get$$class$org$springframework$beans$factory$config$BeanDefinitionHolder());
/* 101 */         arrayOfCallSite[17].call(this.beanDefinition, holder);
/*     */       }
/*     */       else {
/* 104 */         Object beanDefinition = arrayOfCallSite[18].call(this.delegate, element);
/* 105 */         if (DefaultTypeTransformation.booleanUnbox(beanDefinition)) {
/* 106 */           arrayOfCallSite[19].call(this.beanDefinition, beanDefinition);
/*     */         }
/*     */       }
/* 109 */       if (this.callAfterInvocation) {
/* 110 */         arrayOfCallSite[20].callCurrent(this);
/* 111 */         boolean bool2 = false; this.callAfterInvocation = DefaultTypeTransformation.booleanUnbox((Boolean)DefaultTypeTransformation.box(bool2));
/*     */       }
/* 113 */       return element; } return null;
/*     */   }
/*     */ 
/*     */   protected void afterInvocation()
/*     */   {
/*     */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     __$swapInit();
/*     */     Long localLong1 = (Long)DefaultTypeTransformation.box(0L);
/*     */     __timeStamp__239_neverHappen1386831590855 = localLong1.longValue();
/*     */     Long localLong2 = (Long)DefaultTypeTransformation.box(1386831590855L);
/*     */   }
/*     */ 
/*     */   class _invokeMethod_closure1 extends Closure
/*     */     implements GeneratedClosure
/*     */   {
/*     */     public _invokeMethod_closure1(Object _thisObject, Reference args, Reference myNamespaces, Reference myNamespace, Reference builder, Reference name)
/*     */     {
/*     */       super(_thisObject);
/*     */       Reference localReference1 = args;
/*     */       this.args = localReference1;
/*     */       Reference localReference2 = myNamespaces;
/*     */       this.myNamespaces = localReference2;
/*     */       Reference localReference3 = myNamespace;
/*     */       this.myNamespace = localReference3;
/*     */       Reference localReference4 = builder;
/*     */       this.builder = localReference4;
/*     */       Reference localReference5 = name;
/*     */       this.name = localReference5;
/*     */     }
/*     */ 
/*     */     public Object doCall(Object it)
/*     */     {
/*  80 */       CallSite[] arrayOfCallSite = $getCallSiteArray(); Object namespace = null; for (Iterator localIterator = (Iterator)ScriptBytecodeAdapter.castToType(arrayOfCallSite[0].call(this.myNamespaces.get()), $get$$class$java$util$Iterator()); localIterator.hasNext(); ) { namespace = localIterator.next();
/*  81 */         arrayOfCallSite[1].call(arrayOfCallSite[2].callGroovyObjectGetProperty(this), ScriptBytecodeAdapter.createMap(new Object[] { arrayOfCallSite[3].callGetProperty(namespace), arrayOfCallSite[4].callGetProperty(namespace) })); } if ((!BytecodeInterface8.isOrigZ()) || (__$stMC) || (BytecodeInterface8.disabledStandardMetaClass()))
/*     */       {
/*  83 */         if (((DefaultTypeTransformation.booleanUnbox(this.args.get())) && ((arrayOfCallSite[5].call(this.args.get(), (Integer)DefaultTypeTransformation.box(-1)) instanceof Closure)) ? 1 : 0) != 0) {
/*  84 */           Object localObject1 = arrayOfCallSite[6].callGetProperty($get$$class$groovy$lang$Closure()); ScriptBytecodeAdapter.setProperty(localObject1, null, arrayOfCallSite[7].call(this.args.get(), (Integer)DefaultTypeTransformation.box(-1)), "resolveStrategy");
/*  85 */           Object localObject2 = this.builder.get(); ScriptBytecodeAdapter.setProperty(localObject2, null, arrayOfCallSite[8].call(this.args.get(), (Integer)DefaultTypeTransformation.box(-1)), "delegate");
/*     */         }
/*     */       }
/*  83 */       else if (((DefaultTypeTransformation.booleanUnbox(this.args.get())) && ((arrayOfCallSite[9].call(this.args.get(), (Integer)DefaultTypeTransformation.box(-1)) instanceof Closure)) ? 1 : 0) != 0) {
/*  84 */         Object localObject3 = arrayOfCallSite[10].callGetProperty($get$$class$groovy$lang$Closure()); ScriptBytecodeAdapter.setProperty(localObject3, null, arrayOfCallSite[11].call(this.args.get(), (Integer)DefaultTypeTransformation.box(-1)), "resolveStrategy");
/*  85 */         Object localObject4 = this.builder.get(); ScriptBytecodeAdapter.setProperty(localObject4, null, arrayOfCallSite[12].call(this.args.get(), (Integer)DefaultTypeTransformation.box(-1)), "delegate");
/*     */       }
/*  87 */       return ScriptBytecodeAdapter.invokeMethodN($get$$class$org$springframework$beans$factory$groovy$GroovyDynamicElementReader$_invokeMethod_closure1(), ScriptBytecodeAdapter.getProperty($get$$class$org$springframework$beans$factory$groovy$GroovyDynamicElementReader$_invokeMethod_closure1(), arrayOfCallSite[13].callGroovyObjectGetProperty(this), (String)ScriptBytecodeAdapter.castToType(new GStringImpl(new Object[] { this.myNamespace.get() }, new String[] { "", "" }), $get$$class$java$lang$String())), (String)ScriptBytecodeAdapter.castToType(new GStringImpl(new Object[] { this.name.get() }, new String[] { "", "" }), $get$$class$java$lang$String()), ScriptBytecodeAdapter.despreadList(new Object[0], new Object[] { this.args.get() }, new int[] { 0 })); return null;
/*     */     }
/*     */ 
/*     */     public Object getArgs()
/*     */     {
/*     */       CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return this.args.get();
/*     */       return null;
/*     */     }
/*     */ 
/*     */     public Object getMyNamespaces()
/*     */     {
/*     */       CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return this.myNamespaces.get();
/*     */       return null;
/*     */     }
/*     */ 
/*     */     public Object getMyNamespace()
/*     */     {
/*     */       CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return this.myNamespace.get();
/*     */       return null;
/*     */     }
/*     */ 
/*     */     public StreamingMarkupBuilder getBuilder()
/*     */     {
/*     */       CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return (StreamingMarkupBuilder)ScriptBytecodeAdapter.castToType(this.builder.get(), $get$$class$groovy$xml$StreamingMarkupBuilder());
/*     */       return null;
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/*     */       CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return (String)ScriptBytecodeAdapter.castToType(this.name.get(), $get$$class$java$lang$String());
/*     */       return null;
/*     */     }
/*     */ 
/*     */     public Object doCall()
/*     */     {
/*     */       CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return arrayOfCallSite[14].callCurrent(this, ScriptBytecodeAdapter.createPojoWrapper(null, $get$$class$java$lang$Object()));
/*     */       return null;
/*     */     }
/*     */ 
/*     */     static
/*     */     {
/*     */       __$swapInit();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.groovy.GroovyDynamicElementReader
 * JD-Core Version:    0.6.2
 */