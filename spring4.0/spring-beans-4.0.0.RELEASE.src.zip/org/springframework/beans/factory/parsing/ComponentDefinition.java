package org.springframework.beans.factory.parsing;

import org.springframework.beans.BeanMetadataElement;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanReference;

public abstract interface ComponentDefinition extends BeanMetadataElement
{
  public abstract String getName();

  public abstract String getDescription();

  public abstract BeanDefinition[] getBeanDefinitions();

  public abstract BeanDefinition[] getInnerBeanDefinitions();

  public abstract BeanReference[] getBeanReferences();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.parsing.ComponentDefinition
 * JD-Core Version:    0.6.2
 */