package org.springframework.beans.factory.parsing;

import org.springframework.beans.BeanMetadataElement;

public abstract interface DefaultsDefinition extends BeanMetadataElement
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.parsing.DefaultsDefinition
 * JD-Core Version:    0.6.2
 */