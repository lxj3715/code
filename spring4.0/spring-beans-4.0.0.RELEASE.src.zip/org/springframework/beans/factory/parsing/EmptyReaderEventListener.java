package org.springframework.beans.factory.parsing;

public class EmptyReaderEventListener
  implements ReaderEventListener
{
  public void defaultsRegistered(DefaultsDefinition defaultsDefinition)
  {
  }

  public void componentRegistered(ComponentDefinition componentDefinition)
  {
  }

  public void aliasRegistered(AliasDefinition aliasDefinition)
  {
  }

  public void importProcessed(ImportDefinition importDefinition)
  {
  }
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.parsing.EmptyReaderEventListener
 * JD-Core Version:    0.6.2
 */