package org.springframework.beans.factory.parsing;

import org.springframework.core.io.Resource;

public abstract interface SourceExtractor
{
  public abstract Object extractSource(Object paramObject, Resource paramResource);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.parsing.SourceExtractor
 * JD-Core Version:    0.6.2
 */