/*    */ package org.springframework.beans.factory.serviceloader;
/*    */ 
/*    */ import java.util.ServiceLoader;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ 
/*    */ public class ServiceLoaderFactoryBean extends AbstractServiceLoaderBasedFactoryBean
/*    */   implements BeanClassLoaderAware
/*    */ {
/*    */   protected Object getObjectToExpose(ServiceLoader<?> serviceLoader)
/*    */   {
/* 35 */     return serviceLoader;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType()
/*    */   {
/* 40 */     return ServiceLoader.class;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.serviceloader.ServiceLoaderFactoryBean
 * JD-Core Version:    0.6.2
 */