/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.BeanWrapper;
/*      */ import org.springframework.beans.BeanWrapperImpl;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.MutablePropertyValues;
/*      */ import org.springframework.beans.PropertyAccessorUtils;
/*      */ import org.springframework.beans.PropertyValue;
/*      */ import org.springframework.beans.PropertyValues;
/*      */ import org.springframework.beans.TypeConverter;
/*      */ import org.springframework.beans.factory.Aware;
/*      */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*      */ import org.springframework.beans.factory.BeanCreationException;
/*      */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*      */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.BeanNameAware;
/*      */ import org.springframework.beans.factory.FactoryBean;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.beans.factory.ObjectFactory;
/*      */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues.ValueHolder;
/*      */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*      */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.TypedStringValue;
/*      */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*      */ import org.springframework.core.GenericTypeResolver;
/*      */ import org.springframework.core.MethodParameter;
/*      */ import org.springframework.core.ParameterNameDiscoverer;
/*      */ import org.springframework.core.PriorityOrdered;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public abstract class AbstractAutowireCapableBeanFactory extends AbstractBeanFactory
/*      */   implements AutowireCapableBeanFactory
/*      */ {
/*  120 */   private InstantiationStrategy instantiationStrategy = new CglibSubclassingInstantiationStrategy();
/*      */ 
/*  123 */   private ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*      */ 
/*  126 */   private boolean allowCircularReferences = true;
/*      */ 
/*  132 */   private boolean allowRawInjectionDespiteWrapping = false;
/*      */ 
/*  138 */   private final Set<Class<?>> ignoredDependencyTypes = new HashSet();
/*      */ 
/*  144 */   private final Set<Class<?>> ignoredDependencyInterfaces = new HashSet();
/*      */ 
/*  147 */   private final Map<String, BeanWrapper> factoryBeanInstanceCache = new ConcurrentHashMap(16);
/*      */ 
/*  151 */   private final Map<Class<?>, PropertyDescriptor[]> filteredPropertyDescriptorsCache = new ConcurrentHashMap(64);
/*      */ 
/*      */   public AbstractAutowireCapableBeanFactory()
/*      */   {
/*  160 */     ignoreDependencyInterface(BeanNameAware.class);
/*  161 */     ignoreDependencyInterface(BeanFactoryAware.class);
/*  162 */     ignoreDependencyInterface(BeanClassLoaderAware.class);
/*      */   }
/*      */ 
/*      */   public AbstractAutowireCapableBeanFactory(BeanFactory parentBeanFactory)
/*      */   {
/*  170 */     this();
/*  171 */     setParentBeanFactory(parentBeanFactory);
/*      */   }
/*      */ 
/*      */   public void setInstantiationStrategy(InstantiationStrategy instantiationStrategy)
/*      */   {
/*  181 */     this.instantiationStrategy = instantiationStrategy;
/*      */   }
/*      */ 
/*      */   protected InstantiationStrategy getInstantiationStrategy()
/*      */   {
/*  188 */     return this.instantiationStrategy;
/*      */   }
/*      */ 
/*      */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*      */   {
/*  197 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*      */   }
/*      */ 
/*      */   protected ParameterNameDiscoverer getParameterNameDiscoverer()
/*      */   {
/*  205 */     return this.parameterNameDiscoverer;
/*      */   }
/*      */ 
/*      */   public void setAllowCircularReferences(boolean allowCircularReferences)
/*      */   {
/*  222 */     this.allowCircularReferences = allowCircularReferences;
/*      */   }
/*      */ 
/*      */   public void setAllowRawInjectionDespiteWrapping(boolean allowRawInjectionDespiteWrapping)
/*      */   {
/*  240 */     this.allowRawInjectionDespiteWrapping = allowRawInjectionDespiteWrapping;
/*      */   }
/*      */ 
/*      */   public void ignoreDependencyType(Class<?> type)
/*      */   {
/*  248 */     this.ignoredDependencyTypes.add(type);
/*      */   }
/*      */ 
/*      */   public void ignoreDependencyInterface(Class<?> ifc)
/*      */   {
/*  262 */     this.ignoredDependencyInterfaces.add(ifc);
/*      */   }
/*      */ 
/*      */   public void copyConfigurationFrom(ConfigurableBeanFactory otherFactory)
/*      */   {
/*  267 */     super.copyConfigurationFrom(otherFactory);
/*  268 */     if ((otherFactory instanceof AbstractAutowireCapableBeanFactory)) {
/*  269 */       AbstractAutowireCapableBeanFactory otherAutowireFactory = (AbstractAutowireCapableBeanFactory)otherFactory;
/*      */ 
/*  271 */       this.instantiationStrategy = otherAutowireFactory.instantiationStrategy;
/*  272 */       this.allowCircularReferences = otherAutowireFactory.allowCircularReferences;
/*  273 */       this.ignoredDependencyTypes.addAll(otherAutowireFactory.ignoredDependencyTypes);
/*  274 */       this.ignoredDependencyInterfaces.addAll(otherAutowireFactory.ignoredDependencyInterfaces);
/*      */     }
/*      */   }
/*      */ 
/*      */   public <T> T createBean(Class<T> beanClass)
/*      */     throws BeansException
/*      */   {
/*  287 */     RootBeanDefinition bd = new RootBeanDefinition(beanClass);
/*  288 */     bd.setScope("prototype");
/*  289 */     bd.allowCaching = false;
/*  290 */     return createBean(beanClass.getName(), bd, null);
/*      */   }
/*      */ 
/*      */   public void autowireBean(Object existingBean)
/*      */   {
/*  296 */     RootBeanDefinition bd = new RootBeanDefinition(ClassUtils.getUserClass(existingBean));
/*  297 */     bd.setScope("prototype");
/*  298 */     bd.allowCaching = false;
/*  299 */     BeanWrapper bw = new BeanWrapperImpl(existingBean);
/*  300 */     initBeanWrapper(bw);
/*  301 */     populateBean(bd.getBeanClass().getName(), bd, bw);
/*      */   }
/*      */ 
/*      */   public Object configureBean(Object existingBean, String beanName) throws BeansException
/*      */   {
/*  306 */     markBeanAsCreated(beanName);
/*  307 */     BeanDefinition mbd = getMergedBeanDefinition(beanName);
/*  308 */     RootBeanDefinition bd = null;
/*  309 */     if ((mbd instanceof RootBeanDefinition)) {
/*  310 */       RootBeanDefinition rbd = (RootBeanDefinition)mbd;
/*  311 */       bd = rbd.isPrototype() ? rbd : rbd.cloneBeanDefinition();
/*      */     }
/*  313 */     if (!mbd.isPrototype()) {
/*  314 */       if (bd == null) {
/*  315 */         bd = new RootBeanDefinition(mbd);
/*      */       }
/*  317 */       bd.setScope("prototype");
/*  318 */       bd.allowCaching = false;
/*      */     }
/*  320 */     BeanWrapper bw = new BeanWrapperImpl(existingBean);
/*  321 */     initBeanWrapper(bw);
/*  322 */     populateBean(beanName, bd, bw);
/*  323 */     return initializeBean(beanName, existingBean, bd);
/*      */   }
/*      */ 
/*      */   public Object resolveDependency(DependencyDescriptor descriptor, String beanName) throws BeansException
/*      */   {
/*  328 */     return resolveDependency(descriptor, beanName, null, null);
/*      */   }
/*      */ 
/*      */   public Object createBean(Class<?> beanClass, int autowireMode, boolean dependencyCheck)
/*      */     throws BeansException
/*      */   {
/*  339 */     RootBeanDefinition bd = new RootBeanDefinition(beanClass, autowireMode, dependencyCheck);
/*  340 */     bd.setScope("prototype");
/*  341 */     return createBean(beanClass.getName(), bd, null);
/*      */   }
/*      */ 
/*      */   public Object autowire(Class<?> beanClass, int autowireMode, boolean dependencyCheck)
/*      */     throws BeansException
/*      */   {
/*  347 */     final RootBeanDefinition bd = new RootBeanDefinition(beanClass, autowireMode, dependencyCheck);
/*  348 */     bd.setScope("prototype");
/*  349 */     if (bd.getResolvedAutowireMode() == 3) {
/*  350 */       return autowireConstructor(beanClass.getName(), bd, null, null).getWrappedInstance();
/*      */     }
/*      */ 
/*  354 */     final BeanFactory parent = this;
/*      */     Object bean;
/*      */     Object bean;
/*  355 */     if (System.getSecurityManager() != null) {
/*  356 */       bean = AccessController.doPrivileged(new PrivilegedAction()
/*      */       {
/*      */         public Object run() {
/*  359 */           return AbstractAutowireCapableBeanFactory.this.getInstantiationStrategy().instantiate(bd, null, parent);
/*      */         }
/*      */       }
/*      */       , getAccessControlContext());
/*      */     }
/*      */     else {
/*  364 */       bean = getInstantiationStrategy().instantiate(bd, null, parent);
/*      */     }
/*  366 */     populateBean(beanClass.getName(), bd, new BeanWrapperImpl(bean));
/*  367 */     return bean;
/*      */   }
/*      */ 
/*      */   public void autowireBeanProperties(Object existingBean, int autowireMode, boolean dependencyCheck)
/*      */     throws BeansException
/*      */   {
/*  375 */     if (autowireMode == 3) {
/*  376 */       throw new IllegalArgumentException("AUTOWIRE_CONSTRUCTOR not supported for existing bean instance");
/*      */     }
/*      */ 
/*  380 */     RootBeanDefinition bd = new RootBeanDefinition(
/*  380 */       ClassUtils.getUserClass(existingBean), 
/*  380 */       autowireMode, dependencyCheck);
/*  381 */     bd.setScope("prototype");
/*  382 */     BeanWrapper bw = new BeanWrapperImpl(existingBean);
/*  383 */     initBeanWrapper(bw);
/*  384 */     populateBean(bd.getBeanClass().getName(), bd, bw);
/*      */   }
/*      */ 
/*      */   public void applyBeanPropertyValues(Object existingBean, String beanName) throws BeansException
/*      */   {
/*  389 */     markBeanAsCreated(beanName);
/*  390 */     BeanDefinition bd = getMergedBeanDefinition(beanName);
/*  391 */     BeanWrapper bw = new BeanWrapperImpl(existingBean);
/*  392 */     initBeanWrapper(bw);
/*  393 */     applyPropertyValues(beanName, bd, bw, bd.getPropertyValues());
/*      */   }
/*      */ 
/*      */   public Object initializeBean(Object existingBean, String beanName)
/*      */   {
/*  398 */     return initializeBean(beanName, existingBean, null);
/*      */   }
/*      */ 
/*      */   public Object applyBeanPostProcessorsBeforeInitialization(Object existingBean, String beanName)
/*      */     throws BeansException
/*      */   {
/*  405 */     Object result = existingBean;
/*  406 */     for (BeanPostProcessor beanProcessor : getBeanPostProcessors()) {
/*  407 */       result = beanProcessor.postProcessBeforeInitialization(result, beanName);
/*  408 */       if (result == null) {
/*  409 */         return result;
/*      */       }
/*      */     }
/*  412 */     return result;
/*      */   }
/*      */ 
/*      */   public Object applyBeanPostProcessorsAfterInitialization(Object existingBean, String beanName)
/*      */     throws BeansException
/*      */   {
/*  419 */     Object result = existingBean;
/*  420 */     for (BeanPostProcessor beanProcessor : getBeanPostProcessors()) {
/*  421 */       result = beanProcessor.postProcessAfterInitialization(result, beanName);
/*  422 */       if (result == null) {
/*  423 */         return result;
/*      */       }
/*      */     }
/*  426 */     return result;
/*      */   }
/*      */ 
/*      */   public void destroyBean(Object existingBean)
/*      */   {
/*  431 */     new DisposableBeanAdapter(existingBean, getBeanPostProcessors(), getAccessControlContext()).destroy();
/*      */   }
/*      */ 
/*      */   protected Object createBean(String beanName, RootBeanDefinition mbd, Object[] args)
/*      */     throws BeanCreationException
/*      */   {
/*  448 */     if (this.logger.isDebugEnabled()) {
/*  449 */       this.logger.debug("Creating instance of bean '" + beanName + "'");
/*      */     }
/*      */ 
/*  452 */     resolveBeanClass(mbd, beanName, new Class[0]);
/*      */     try
/*      */     {
/*  456 */       mbd.prepareMethodOverrides();
/*      */     }
/*      */     catch (BeanDefinitionValidationException ex) {
/*  459 */       throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, "Validation of method overrides failed", ex);
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  465 */       Object bean = resolveBeforeInstantiation(beanName, mbd);
/*  466 */       if (bean != null)
/*  467 */         return bean;
/*      */     }
/*      */     catch (Throwable ex)
/*      */     {
/*  471 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "BeanPostProcessor before instantiation of bean failed", ex);
/*      */     }
/*      */ 
/*  475 */     Object beanInstance = doCreateBean(beanName, mbd, args);
/*  476 */     if (this.logger.isDebugEnabled()) {
/*  477 */       this.logger.debug("Finished creating instance of bean '" + beanName + "'");
/*      */     }
/*  479 */     return beanInstance;
/*      */   }
/*      */ 
/*      */   protected Object doCreateBean(final String beanName, final RootBeanDefinition mbd, Object[] args)
/*      */   {
/*  499 */     BeanWrapper instanceWrapper = null;
/*  500 */     if (mbd.isSingleton()) {
/*  501 */       instanceWrapper = (BeanWrapper)this.factoryBeanInstanceCache.remove(beanName);
/*      */     }
/*  503 */     if (instanceWrapper == null) {
/*  504 */       instanceWrapper = createBeanInstance(beanName, mbd, args);
/*      */     }
/*  506 */     final Object bean = instanceWrapper != null ? instanceWrapper.getWrappedInstance() : null;
/*  507 */     Class beanType = instanceWrapper != null ? instanceWrapper.getWrappedClass() : null;
/*      */ 
/*  510 */     synchronized (mbd.postProcessingLock) {
/*  511 */       if (!mbd.postProcessed) {
/*  512 */         applyMergedBeanDefinitionPostProcessors(mbd, beanType, beanName);
/*  513 */         mbd.postProcessed = true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  520 */     boolean earlySingletonExposure = (mbd.isSingleton()) && (this.allowCircularReferences) && 
/*  520 */       (isSingletonCurrentlyInCreation(beanName));
/*      */ 
/*  521 */     if (earlySingletonExposure) {
/*  522 */       if (this.logger.isDebugEnabled()) {
/*  523 */         this.logger.debug("Eagerly caching bean '" + beanName + "' to allow for resolving potential circular references");
/*      */       }
/*      */ 
/*  526 */       addSingletonFactory(beanName, new ObjectFactory()
/*      */       {
/*      */         public Object getObject() throws BeansException {
/*  529 */           return AbstractAutowireCapableBeanFactory.this.getEarlyBeanReference(beanName, mbd, bean);
/*      */         }
/*      */ 
/*      */       });
/*      */     }
/*      */ 
/*  535 */     Object exposedObject = bean;
/*      */     try {
/*  537 */       populateBean(beanName, mbd, instanceWrapper);
/*  538 */       if (exposedObject != null)
/*  539 */         exposedObject = initializeBean(beanName, exposedObject, mbd);
/*      */     }
/*      */     catch (Throwable ex)
/*      */     {
/*  543 */       if (((ex instanceof BeanCreationException)) && (beanName.equals(((BeanCreationException)ex).getBeanName()))) {
/*  544 */         throw ((BeanCreationException)ex);
/*      */       }
/*      */ 
/*  547 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Initialization of bean failed", ex);
/*      */     }
/*      */ 
/*  551 */     if (earlySingletonExposure) {
/*  552 */       Object earlySingletonReference = getSingleton(beanName, false);
/*  553 */       if (earlySingletonReference != null) {
/*  554 */         if (exposedObject == bean) {
/*  555 */           exposedObject = earlySingletonReference;
/*      */         }
/*  557 */         else if ((!this.allowRawInjectionDespiteWrapping) && (hasDependentBean(beanName))) {
/*  558 */           String[] dependentBeans = getDependentBeans(beanName);
/*  559 */           Set actualDependentBeans = new LinkedHashSet(dependentBeans.length);
/*  560 */           for (String dependentBean : dependentBeans) {
/*  561 */             if (!removeSingletonIfCreatedForTypeCheckOnly(dependentBean)) {
/*  562 */               actualDependentBeans.add(dependentBean);
/*      */             }
/*      */           }
/*  565 */           if (!actualDependentBeans.isEmpty())
/*      */           {
/*  568 */             throw new BeanCurrentlyInCreationException(beanName, "Bean with name '" + beanName + "' has been injected into other beans [" + 
/*  568 */               StringUtils.collectionToCommaDelimitedString(actualDependentBeans) + 
/*  568 */               "] in its raw version as part of a circular reference, but has eventually been " + "wrapped. This means that said other beans do not use the final version of the " + "bean. This is often the result of over-eager type matching - consider using " + "'getBeanNamesOfType' with the 'allowEagerInit' flag turned off, for example.");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  580 */       registerDisposableBeanIfNecessary(beanName, bean, mbd);
/*      */     }
/*      */     catch (BeanDefinitionValidationException ex) {
/*  583 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Invalid destruction signature", ex);
/*      */     }
/*      */ 
/*  586 */     return exposedObject;
/*      */   }
/*      */ 
/*      */   protected Class<?> predictBeanType(String beanName, RootBeanDefinition mbd, Class<?>[] typesToMatch)
/*      */   {
/*  591 */     Class targetType = mbd.getTargetType();
/*  592 */     if (targetType == null)
/*      */     {
/*  594 */       targetType = mbd.getFactoryMethodName() != null ? getTypeForFactoryMethod(beanName, mbd, typesToMatch) : 
/*  594 */         resolveBeanClass(mbd, beanName, typesToMatch);
/*      */ 
/*  595 */       if ((ObjectUtils.isEmpty(typesToMatch)) || (getTempClassLoader() == null)) {
/*  596 */         mbd.setTargetType(targetType);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  601 */     if ((targetType != null) && (!mbd.isSynthetic()) && (hasInstantiationAwareBeanPostProcessors())) {
/*  602 */       for (BeanPostProcessor bp : getBeanPostProcessors()) {
/*  603 */         if ((bp instanceof SmartInstantiationAwareBeanPostProcessor)) {
/*  604 */           SmartInstantiationAwareBeanPostProcessor ibp = (SmartInstantiationAwareBeanPostProcessor)bp;
/*  605 */           Class predicted = ibp.predictBeanType(targetType, beanName);
/*  606 */           if ((predicted != null) && ((typesToMatch.length != 1) || (!FactoryBean.class.equals(typesToMatch[0])) || 
/*  607 */             (FactoryBean.class
/*  607 */             .isAssignableFrom(predicted))))
/*      */           {
/*  608 */             return predicted;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  613 */     return targetType;
/*      */   }
/*      */ 
/*      */   protected Class<?> getTypeForFactoryMethod(String beanName, RootBeanDefinition mbd, Class<?>[] typesToMatch)
/*      */   {
/*  631 */     Class preResolved = mbd.resolvedFactoryMethodReturnType;
/*  632 */     if (preResolved != null) {
/*  633 */       return preResolved;
/*      */     }
/*      */ 
/*  637 */     boolean isStatic = true;
/*      */ 
/*  639 */     String factoryBeanName = mbd.getFactoryBeanName();
/*      */     Class factoryClass;
/*  640 */     if (factoryBeanName != null) {
/*  641 */       if (factoryBeanName.equals(beanName)) {
/*  642 */         throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, "factory-bean reference points back to the same bean definition");
/*      */       }
/*      */ 
/*  646 */       Class factoryClass = getType(factoryBeanName);
/*  647 */       isStatic = false;
/*      */     }
/*      */     else
/*      */     {
/*  651 */       factoryClass = resolveBeanClass(mbd, beanName, typesToMatch);
/*      */     }
/*      */ 
/*  654 */     if (factoryClass == null) {
/*  655 */       return null;
/*      */     }
/*      */ 
/*  660 */     Class commonType = null;
/*  661 */     boolean cache = false;
/*  662 */     int minNrOfArgs = mbd.getConstructorArgumentValues().getArgumentCount();
/*  663 */     Method[] candidates = ReflectionUtils.getUniqueDeclaredMethods(factoryClass);
/*  664 */     for (Method factoryMethod : candidates) {
/*  665 */       if ((Modifier.isStatic(factoryMethod.getModifiers()) == isStatic) && 
/*  666 */         (factoryMethod
/*  666 */         .getName().equals(mbd.getFactoryMethodName())) && 
/*  667 */         (factoryMethod
/*  667 */         .getParameterTypes().length >= minNrOfArgs))
/*      */       {
/*  669 */         if (factoryMethod.getTypeParameters().length > 0) {
/*      */           try
/*      */           {
/*  672 */             Class[] paramTypes = factoryMethod.getParameterTypes();
/*  673 */             String[] paramNames = null;
/*  674 */             ParameterNameDiscoverer pnd = getParameterNameDiscoverer();
/*  675 */             if (pnd != null) {
/*  676 */               paramNames = pnd.getParameterNames(factoryMethod);
/*      */             }
/*  678 */             ConstructorArgumentValues cav = mbd.getConstructorArgumentValues();
/*  679 */             Set usedValueHolders = new HashSet(paramTypes.length);
/*      */ 
/*  681 */             Object[] args = new Object[paramTypes.length];
/*  682 */             for (int i = 0; i < args.length; i++) {
/*  683 */               ConstructorArgumentValues.ValueHolder valueHolder = cav.getArgumentValue(i, paramTypes[i], paramNames != null ? paramNames[i] : null, usedValueHolders);
/*      */ 
/*  685 */               if (valueHolder == null) {
/*  686 */                 valueHolder = cav.getGenericArgumentValue(null, null, usedValueHolders);
/*      */               }
/*  688 */               if (valueHolder != null) {
/*  689 */                 args[i] = valueHolder.getValue();
/*  690 */                 usedValueHolders.add(valueHolder);
/*      */               }
/*      */             }
/*  693 */             Class returnType = AutowireUtils.resolveReturnTypeForFactoryMethod(factoryMethod, args, 
/*  694 */               getBeanClassLoader());
/*  695 */             if (returnType != null) {
/*  696 */               cache = true;
/*  697 */               commonType = ClassUtils.determineCommonAncestor(returnType, commonType);
/*      */             }
/*      */           }
/*      */           catch (Throwable ex) {
/*  701 */             if (this.logger.isDebugEnabled()) {
/*  702 */               this.logger.debug("Failed to resolve generic return type for factory method: " + ex);
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/*  707 */           commonType = ClassUtils.determineCommonAncestor(factoryMethod.getReturnType(), commonType);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  712 */     if (commonType != null)
/*      */     {
/*  714 */       if (cache) {
/*  715 */         mbd.resolvedFactoryMethodReturnType = commonType;
/*      */       }
/*  717 */       return commonType;
/*      */     }
/*      */ 
/*  721 */     return null;
/*      */   }
/*      */ 
/*      */   protected Class<?> getTypeForFactoryBean(String beanName, RootBeanDefinition mbd)
/*      */   {
/*  739 */     final Object objectType = new Object()
/*      */     {
/*  738 */       Class<?> value = null;
/*      */     };
/*  740 */     String factoryBeanName = mbd.getFactoryBeanName();
/*  741 */     final String factoryMethodName = mbd.getFactoryMethodName();
/*      */ 
/*  743 */     if (factoryBeanName != null) {
/*  744 */       if (factoryMethodName != null)
/*      */       {
/*  746 */         BeanDefinition fbDef = getBeanDefinition(factoryBeanName);
/*  747 */         if (((fbDef instanceof AbstractBeanDefinition)) && (((AbstractBeanDefinition)fbDef).hasBeanClass()))
/*      */         {
/*  749 */           Class fbClass = ClassUtils.getUserClass(((AbstractBeanDefinition)fbDef).getBeanClass());
/*      */ 
/*  752 */           ReflectionUtils.doWithMethods(fbClass, new ReflectionUtils.MethodCallback()
/*      */           {
/*      */             public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException
/*      */             {
/*  756 */               if ((method.getName().equals(factoryMethodName)) && 
/*  757 */                 (FactoryBean.class
/*  757 */                 .isAssignableFrom(method
/*  757 */                 .getReturnType())))
/*  758 */                 objectType.value = GenericTypeResolver.resolveReturnTypeArgument(method, FactoryBean.class);
/*      */             }
/*      */           });
/*  762 */           if (objectType.value != null) {
/*  763 */             return objectType.value;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  770 */       if (!isBeanEligibleForMetadataCaching(factoryBeanName)) {
/*  771 */         return null;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  777 */     FactoryBean fb = mbd.isSingleton() ? 
/*  776 */       getSingletonFactoryBeanForTypeCheck(beanName, mbd) : 
/*  777 */       getNonSingletonFactoryBeanForTypeCheck(beanName, mbd);
/*      */ 
/*  779 */     if (fb != null)
/*      */     {
/*  781 */       objectType.value = getTypeForFactoryBean(fb);
/*  782 */       if (objectType.value != null) {
/*  783 */         return objectType.value;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  788 */     return super.getTypeForFactoryBean(beanName, mbd);
/*      */   }
/*      */ 
/*      */   protected Object getEarlyBeanReference(String beanName, RootBeanDefinition mbd, Object bean)
/*      */   {
/*  800 */     Object exposedObject = bean;
/*  801 */     if ((bean != null) && (!mbd.isSynthetic()) && (hasInstantiationAwareBeanPostProcessors())) {
/*  802 */       for (BeanPostProcessor bp : getBeanPostProcessors()) {
/*  803 */         if ((bp instanceof SmartInstantiationAwareBeanPostProcessor)) {
/*  804 */           SmartInstantiationAwareBeanPostProcessor ibp = (SmartInstantiationAwareBeanPostProcessor)bp;
/*  805 */           exposedObject = ibp.getEarlyBeanReference(exposedObject, beanName);
/*  806 */           if (exposedObject == null) {
/*  807 */             return exposedObject;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  812 */     return exposedObject;
/*      */   }
/*      */ 
/*      */   private FactoryBean<?> getSingletonFactoryBeanForTypeCheck(String beanName, RootBeanDefinition mbd)
/*      */   {
/*  830 */     synchronized (getSingletonMutex()) {
/*  831 */       BeanWrapper bw = (BeanWrapper)this.factoryBeanInstanceCache.get(beanName);
/*  832 */       if (bw != null) {
/*  833 */         return (FactoryBean)bw.getWrappedInstance();
/*      */       }
/*  835 */       if (isSingletonCurrentlyInCreation(beanName)) {
/*  836 */         return null;
/*      */       }
/*  838 */       Object instance = null;
/*      */       try
/*      */       {
/*  841 */         beforeSingletonCreation(beanName);
/*      */ 
/*  843 */         instance = resolveBeforeInstantiation(beanName, mbd);
/*  844 */         if (instance == null) {
/*  845 */           bw = createBeanInstance(beanName, mbd, null);
/*  846 */           instance = bw.getWrappedInstance();
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/*  851 */         afterSingletonCreation(beanName);
/*      */       }
/*  853 */       FactoryBean fb = getFactoryBean(beanName, instance);
/*  854 */       if (bw != null) {
/*  855 */         this.factoryBeanInstanceCache.put(beanName, bw);
/*      */       }
/*  857 */       return fb;
/*      */     }
/*      */   }
/*      */ 
/*      */   private FactoryBean<?> getNonSingletonFactoryBeanForTypeCheck(String beanName, RootBeanDefinition mbd)
/*      */   {
/*  871 */     if (isPrototypeCurrentlyInCreation(beanName)) {
/*  872 */       return null;
/*      */     }
/*  874 */     Object instance = null;
/*      */     try
/*      */     {
/*  877 */       beforePrototypeCreation(beanName);
/*      */ 
/*  879 */       instance = resolveBeforeInstantiation(beanName, mbd);
/*  880 */       if (instance == null) {
/*  881 */         BeanWrapper bw = createBeanInstance(beanName, mbd, null);
/*  882 */         instance = bw.getWrappedInstance();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  887 */       afterPrototypeCreation(beanName);
/*      */     }
/*  889 */     return getFactoryBean(beanName, instance);
/*      */   }
/*      */ 
/*      */   protected void applyMergedBeanDefinitionPostProcessors(RootBeanDefinition mbd, Class<?> beanType, String beanName)
/*      */     throws BeansException
/*      */   {
/*      */     try
/*      */     {
/*  905 */       for (BeanPostProcessor bp : getBeanPostProcessors())
/*  906 */         if ((bp instanceof MergedBeanDefinitionPostProcessor)) {
/*  907 */           MergedBeanDefinitionPostProcessor bdp = (MergedBeanDefinitionPostProcessor)bp;
/*  908 */           bdp.postProcessMergedBeanDefinition(mbd, beanType, beanName);
/*      */         }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  913 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Post-processing failed of bean type [" + beanType + "] failed", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Object resolveBeforeInstantiation(String beanName, RootBeanDefinition mbd)
/*      */   {
/*  926 */     Object bean = null;
/*  927 */     if (!Boolean.FALSE.equals(mbd.beforeInstantiationResolved))
/*      */     {
/*  929 */       if ((mbd.hasBeanClass()) && (!mbd.isSynthetic()) && (hasInstantiationAwareBeanPostProcessors())) {
/*  930 */         bean = applyBeanPostProcessorsBeforeInstantiation(mbd.getBeanClass(), beanName);
/*  931 */         if (bean != null) {
/*  932 */           bean = applyBeanPostProcessorsAfterInitialization(bean, beanName);
/*      */         }
/*      */       }
/*  935 */       mbd.beforeInstantiationResolved = Boolean.valueOf(bean != null);
/*      */     }
/*  937 */     return bean;
/*      */   }
/*      */ 
/*      */   protected Object applyBeanPostProcessorsBeforeInstantiation(Class<?> beanClass, String beanName)
/*      */     throws BeansException
/*      */   {
/*  955 */     for (BeanPostProcessor bp : getBeanPostProcessors()) {
/*  956 */       if ((bp instanceof InstantiationAwareBeanPostProcessor)) {
/*  957 */         InstantiationAwareBeanPostProcessor ibp = (InstantiationAwareBeanPostProcessor)bp;
/*  958 */         Object result = ibp.postProcessBeforeInstantiation(beanClass, beanName);
/*  959 */         if (result != null) {
/*  960 */           return result;
/*      */         }
/*      */       }
/*      */     }
/*  964 */     return null;
/*      */   }
/*      */ 
/*      */   protected BeanWrapper createBeanInstance(String beanName, RootBeanDefinition mbd, Object[] args)
/*      */   {
/*  981 */     Class beanClass = resolveBeanClass(mbd, beanName, new Class[0]);
/*      */ 
/*  983 */     if ((beanClass != null) && (!Modifier.isPublic(beanClass.getModifiers())) && (!mbd.isNonPublicAccessAllowed()))
/*      */     {
/*  985 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Bean class isn't public, and non-public access not allowed: " + beanClass
/*  985 */         .getName());
/*      */     }
/*      */ 
/*  988 */     if (mbd.getFactoryMethodName() != null) {
/*  989 */       return instantiateUsingFactoryMethod(beanName, mbd, args);
/*      */     }
/*      */ 
/*  993 */     boolean resolved = false;
/*  994 */     boolean autowireNecessary = false;
/*  995 */     if (args == null) {
/*  996 */       synchronized (mbd.constructorArgumentLock) {
/*  997 */         if (mbd.resolvedConstructorOrFactoryMethod != null) {
/*  998 */           resolved = true;
/*  999 */           autowireNecessary = mbd.constructorArgumentsResolved;
/*      */         }
/*      */       }
/*      */     }
/* 1003 */     if (resolved) {
/* 1004 */       if (autowireNecessary) {
/* 1005 */         return autowireConstructor(beanName, mbd, null, null);
/*      */       }
/*      */ 
/* 1008 */       return instantiateBean(beanName, mbd);
/*      */     }
/*      */ 
/* 1013 */     Constructor[] ctors = determineConstructorsFromBeanPostProcessors(beanClass, beanName);
/* 1014 */     if ((ctors != null) || 
/* 1015 */       (mbd
/* 1015 */       .getResolvedAutowireMode() == 3) || 
/* 1016 */       (mbd
/* 1016 */       .hasConstructorArgumentValues()) || (!ObjectUtils.isEmpty(args))) {
/* 1017 */       return autowireConstructor(beanName, mbd, ctors, args);
/*      */     }
/*      */ 
/* 1021 */     return instantiateBean(beanName, mbd);
/*      */   }
/*      */ 
/*      */   protected Constructor<?>[] determineConstructorsFromBeanPostProcessors(Class<?> beanClass, String beanName)
/*      */     throws BeansException
/*      */   {
/* 1036 */     if ((beanClass != null) && (hasInstantiationAwareBeanPostProcessors())) {
/* 1037 */       for (BeanPostProcessor bp : getBeanPostProcessors()) {
/* 1038 */         if ((bp instanceof SmartInstantiationAwareBeanPostProcessor)) {
/* 1039 */           SmartInstantiationAwareBeanPostProcessor ibp = (SmartInstantiationAwareBeanPostProcessor)bp;
/* 1040 */           Constructor[] ctors = ibp.determineCandidateConstructors(beanClass, beanName);
/* 1041 */           if (ctors != null) {
/* 1042 */             return ctors;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1047 */     return null;
/*      */   }
/*      */ 
/*      */   protected BeanWrapper instantiateBean(final String beanName, final RootBeanDefinition mbd)
/*      */   {
/*      */     try
/*      */     {
/* 1059 */       final BeanFactory parent = this;
/*      */       Object beanInstance;
/*      */       Object beanInstance;
/* 1060 */       if (System.getSecurityManager() != null) {
/* 1061 */         beanInstance = AccessController.doPrivileged(new PrivilegedAction()
/*      */         {
/*      */           public Object run() {
/* 1064 */             return AbstractAutowireCapableBeanFactory.this.getInstantiationStrategy().instantiate(mbd, beanName, parent);
/*      */           }
/*      */         }
/*      */         , getAccessControlContext());
/*      */       }
/*      */       else {
/* 1069 */         beanInstance = getInstantiationStrategy().instantiate(mbd, beanName, parent);
/*      */       }
/* 1071 */       BeanWrapper bw = new BeanWrapperImpl(beanInstance);
/* 1072 */       initBeanWrapper(bw);
/* 1073 */       return bw;
/*      */     }
/*      */     catch (Throwable ex) {
/* 1076 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Instantiation of bean failed", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected BeanWrapper instantiateUsingFactoryMethod(String beanName, RootBeanDefinition mbd, Object[] explicitArgs)
/*      */   {
/* 1094 */     return new ConstructorResolver(this).instantiateUsingFactoryMethod(beanName, mbd, explicitArgs);
/*      */   }
/*      */ 
/*      */   protected BeanWrapper autowireConstructor(String beanName, RootBeanDefinition mbd, Constructor<?>[] ctors, Object[] explicitArgs)
/*      */   {
/* 1114 */     return new ConstructorResolver(this).autowireConstructor(beanName, mbd, ctors, explicitArgs);
/*      */   }
/*      */ 
/*      */   protected void populateBean(String beanName, RootBeanDefinition mbd, BeanWrapper bw)
/*      */   {
/* 1125 */     PropertyValues pvs = mbd.getPropertyValues();
/*      */ 
/* 1127 */     if (bw == null) {
/* 1128 */       if (!pvs.isEmpty())
/*      */       {
/* 1130 */         throw new BeanCreationException(mbd
/* 1130 */           .getResourceDescription(), beanName, "Cannot apply property values to null instance");
/*      */       }
/*      */ 
/* 1134 */       return;
/*      */     }
/*      */ 
/* 1141 */     boolean continueWithPropertyPopulation = true;
/*      */ 
/* 1143 */     if ((!mbd.isSynthetic()) && (hasInstantiationAwareBeanPostProcessors())) {
/* 1144 */       for (BeanPostProcessor bp : getBeanPostProcessors()) {
/* 1145 */         if ((bp instanceof InstantiationAwareBeanPostProcessor)) {
/* 1146 */           InstantiationAwareBeanPostProcessor ibp = (InstantiationAwareBeanPostProcessor)bp;
/* 1147 */           if (!ibp.postProcessAfterInstantiation(bw.getWrappedInstance(), beanName)) {
/* 1148 */             continueWithPropertyPopulation = false;
/* 1149 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1155 */     if (!continueWithPropertyPopulation) {
/* 1156 */       return;
/*      */     }
/*      */ 
/* 1159 */     if ((mbd.getResolvedAutowireMode() == 1) || 
/* 1160 */       (mbd
/* 1160 */       .getResolvedAutowireMode() == 2)) {
/* 1161 */       MutablePropertyValues newPvs = new MutablePropertyValues(pvs);
/*      */ 
/* 1164 */       if (mbd.getResolvedAutowireMode() == 1) {
/* 1165 */         autowireByName(beanName, mbd, bw, newPvs);
/*      */       }
/*      */ 
/* 1169 */       if (mbd.getResolvedAutowireMode() == 2) {
/* 1170 */         autowireByType(beanName, mbd, bw, newPvs);
/*      */       }
/*      */ 
/* 1173 */       pvs = newPvs;
/*      */     }
/*      */ 
/* 1176 */     boolean hasInstAwareBpps = hasInstantiationAwareBeanPostProcessors();
/* 1177 */     boolean needsDepCheck = mbd.getDependencyCheck() != 0;
/*      */ 
/* 1179 */     if ((hasInstAwareBpps) || (needsDepCheck)) {
/* 1180 */       PropertyDescriptor[] filteredPds = filterPropertyDescriptorsForDependencyCheck(bw, mbd.allowCaching);
/* 1181 */       if (hasInstAwareBpps) {
/* 1182 */         for (BeanPostProcessor bp : getBeanPostProcessors()) {
/* 1183 */           if ((bp instanceof InstantiationAwareBeanPostProcessor)) {
/* 1184 */             InstantiationAwareBeanPostProcessor ibp = (InstantiationAwareBeanPostProcessor)bp;
/* 1185 */             pvs = ibp.postProcessPropertyValues(pvs, filteredPds, bw.getWrappedInstance(), beanName);
/* 1186 */             if (pvs == null) {
/* 1187 */               return;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1192 */       if (needsDepCheck) {
/* 1193 */         checkDependencies(beanName, mbd, filteredPds, pvs);
/*      */       }
/*      */     }
/*      */ 
/* 1197 */     applyPropertyValues(beanName, mbd, bw, pvs);
/*      */   }
/*      */ 
/*      */   protected void autowireByName(String beanName, AbstractBeanDefinition mbd, BeanWrapper bw, MutablePropertyValues pvs)
/*      */   {
/* 1212 */     String[] propertyNames = unsatisfiedNonSimpleProperties(mbd, bw);
/* 1213 */     for (String propertyName : propertyNames)
/* 1214 */       if (containsBean(propertyName)) {
/* 1215 */         Object bean = getBean(propertyName);
/* 1216 */         pvs.add(propertyName, bean);
/* 1217 */         registerDependentBean(propertyName, beanName);
/* 1218 */         if (this.logger.isDebugEnabled()) {
/* 1219 */           this.logger.debug("Added autowiring by name from bean name '" + beanName + "' via property '" + propertyName + "' to bean named '" + propertyName + "'");
/*      */         }
/*      */ 
/*      */       }
/* 1224 */       else if (this.logger.isTraceEnabled()) {
/* 1225 */         this.logger.trace("Not autowiring property '" + propertyName + "' of bean '" + beanName + "' by name: no matching bean found");
/*      */       }
/*      */   }
/*      */ 
/*      */   protected void autowireByType(String beanName, AbstractBeanDefinition mbd, BeanWrapper bw, MutablePropertyValues pvs)
/*      */   {
/* 1246 */     TypeConverter converter = getCustomTypeConverter();
/* 1247 */     if (converter == null) {
/* 1248 */       converter = bw;
/*      */     }
/*      */ 
/* 1251 */     Set autowiredBeanNames = new LinkedHashSet(4);
/* 1252 */     String[] propertyNames = unsatisfiedNonSimpleProperties(mbd, bw);
/* 1253 */     for (String propertyName : propertyNames)
/*      */       try {
/* 1255 */         PropertyDescriptor pd = bw.getPropertyDescriptor(propertyName);
/*      */ 
/* 1258 */         if (!Object.class.equals(pd.getPropertyType())) {
/* 1259 */           MethodParameter methodParam = BeanUtils.getWriteMethodParameter(pd);
/*      */ 
/* 1261 */           boolean eager = !PriorityOrdered.class.isAssignableFrom(bw.getWrappedClass());
/* 1262 */           DependencyDescriptor desc = new AutowireByTypeDependencyDescriptor(methodParam, eager);
/* 1263 */           Object autowiredArgument = resolveDependency(desc, beanName, autowiredBeanNames, converter);
/* 1264 */           if (autowiredArgument != null) {
/* 1265 */             pvs.add(propertyName, autowiredArgument);
/*      */           }
/* 1267 */           for (String autowiredBeanName : autowiredBeanNames) {
/* 1268 */             registerDependentBean(autowiredBeanName, beanName);
/* 1269 */             if (this.logger.isDebugEnabled()) {
/* 1270 */               this.logger.debug("Autowiring by type from bean name '" + beanName + "' via property '" + propertyName + "' to bean named '" + autowiredBeanName + "'");
/*      */             }
/*      */           }
/*      */ 
/* 1274 */           autowiredBeanNames.clear();
/*      */         }
/*      */       }
/*      */       catch (BeansException ex) {
/* 1278 */         throw new UnsatisfiedDependencyException(mbd.getResourceDescription(), beanName, propertyName, ex);
/*      */       }
/*      */   }
/*      */ 
/*      */   protected String[] unsatisfiedNonSimpleProperties(AbstractBeanDefinition mbd, BeanWrapper bw)
/*      */   {
/* 1294 */     Set result = new TreeSet();
/* 1295 */     PropertyValues pvs = mbd.getPropertyValues();
/* 1296 */     PropertyDescriptor[] pds = bw.getPropertyDescriptors();
/* 1297 */     for (PropertyDescriptor pd : pds) {
/* 1298 */       if ((pd.getWriteMethod() != null) && (!isExcludedFromDependencyCheck(pd)) && (!pvs.contains(pd.getName())) && 
/* 1299 */         (!BeanUtils.isSimpleProperty(pd
/* 1299 */         .getPropertyType()))) {
/* 1300 */         result.add(pd.getName());
/*      */       }
/*      */     }
/* 1303 */     return StringUtils.toStringArray(result);
/*      */   }
/*      */ 
/*      */   protected PropertyDescriptor[] filterPropertyDescriptorsForDependencyCheck(BeanWrapper bw, boolean cache)
/*      */   {
/* 1316 */     PropertyDescriptor[] filtered = (PropertyDescriptor[])this.filteredPropertyDescriptorsCache.get(bw.getWrappedClass());
/* 1317 */     if (filtered == null) {
/* 1318 */       if (cache) {
/* 1319 */         synchronized (this.filteredPropertyDescriptorsCache) {
/* 1320 */           filtered = (PropertyDescriptor[])this.filteredPropertyDescriptorsCache.get(bw.getWrappedClass());
/* 1321 */           if (filtered == null) {
/* 1322 */             filtered = filterPropertyDescriptorsForDependencyCheck(bw);
/* 1323 */             this.filteredPropertyDescriptorsCache.put(bw.getWrappedClass(), filtered);
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1328 */         filtered = filterPropertyDescriptorsForDependencyCheck(bw);
/*      */       }
/*      */     }
/* 1331 */     return filtered;
/*      */   }
/*      */ 
/*      */   protected PropertyDescriptor[] filterPropertyDescriptorsForDependencyCheck(BeanWrapper bw)
/*      */   {
/* 1343 */     List pds = new LinkedList(
/* 1343 */       Arrays.asList(bw
/* 1343 */       .getPropertyDescriptors()));
/* 1344 */     for (Iterator it = pds.iterator(); it.hasNext(); ) {
/* 1345 */       PropertyDescriptor pd = (PropertyDescriptor)it.next();
/* 1346 */       if (isExcludedFromDependencyCheck(pd)) {
/* 1347 */         it.remove();
/*      */       }
/*      */     }
/* 1350 */     return (PropertyDescriptor[])pds.toArray(new PropertyDescriptor[pds.size()]);
/*      */   }
/*      */ 
/*      */   protected boolean isExcludedFromDependencyCheck(PropertyDescriptor pd)
/*      */   {
/* 1366 */     return (AutowireUtils.isExcludedFromDependencyCheck(pd)) || 
/* 1365 */       (this.ignoredDependencyTypes
/* 1365 */       .contains(pd
/* 1365 */       .getPropertyType())) || 
/* 1366 */       (AutowireUtils.isSetterDefinedInInterface(pd, this.ignoredDependencyInterfaces));
/*      */   }
/*      */ 
/*      */   protected void checkDependencies(String beanName, AbstractBeanDefinition mbd, PropertyDescriptor[] pds, PropertyValues pvs)
/*      */     throws UnsatisfiedDependencyException
/*      */   {
/* 1383 */     int dependencyCheck = mbd.getDependencyCheck();
/* 1384 */     for (PropertyDescriptor pd : pds)
/* 1385 */       if ((pd.getWriteMethod() != null) && (!pvs.contains(pd.getName()))) {
/* 1386 */         boolean isSimple = BeanUtils.isSimpleProperty(pd.getPropertyType());
/* 1387 */         boolean unsatisfied = (dependencyCheck == 3) || ((isSimple) && (dependencyCheck == 2)) || ((!isSimple) && (dependencyCheck == 1));
/*      */ 
/* 1390 */         if (unsatisfied)
/* 1391 */           throw new UnsatisfiedDependencyException(mbd.getResourceDescription(), beanName, pd.getName(), "Set this property value or disable dependency checking for this bean.");
/*      */       }
/*      */   }
/*      */ 
/*      */   protected void applyPropertyValues(String beanName, BeanDefinition mbd, BeanWrapper bw, PropertyValues pvs)
/*      */   {
/* 1408 */     if ((pvs == null) || (pvs.isEmpty())) {
/* 1409 */       return;
/*      */     }
/*      */ 
/* 1412 */     MutablePropertyValues mpvs = null;
/*      */ 
/* 1415 */     if ((System.getSecurityManager() != null) && 
/* 1416 */       ((bw instanceof BeanWrapperImpl)))
/* 1417 */       ((BeanWrapperImpl)bw).setSecurityContext(getAccessControlContext());
/*      */     List original;
/*      */     List original;
/* 1421 */     if ((pvs instanceof MutablePropertyValues)) {
/* 1422 */       mpvs = (MutablePropertyValues)pvs;
/* 1423 */       if (mpvs.isConverted()) {
/*      */         try
/*      */         {
/* 1426 */           bw.setPropertyValues(mpvs);
/* 1427 */           return;
/*      */         }
/*      */         catch (BeansException ex)
/*      */         {
/* 1431 */           throw new BeanCreationException(mbd
/* 1431 */             .getResourceDescription(), beanName, "Error setting property values", ex);
/*      */         }
/*      */       }
/* 1434 */       original = mpvs.getPropertyValueList();
/*      */     }
/*      */     else {
/* 1437 */       original = Arrays.asList(pvs.getPropertyValues());
/*      */     }
/*      */ 
/* 1440 */     TypeConverter converter = getCustomTypeConverter();
/* 1441 */     if (converter == null) {
/* 1442 */       converter = bw;
/*      */     }
/* 1444 */     BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver(this, beanName, mbd, converter);
/*      */ 
/* 1447 */     List deepCopy = new ArrayList(original.size());
/* 1448 */     boolean resolveNecessary = false;
/* 1449 */     for (PropertyValue pv : original) {
/* 1450 */       if (pv.isConverted()) {
/* 1451 */         deepCopy.add(pv);
/*      */       }
/*      */       else {
/* 1454 */         String propertyName = pv.getName();
/* 1455 */         Object originalValue = pv.getValue();
/* 1456 */         Object resolvedValue = valueResolver.resolveValueIfNecessary(pv, originalValue);
/* 1457 */         Object convertedValue = resolvedValue;
/*      */ 
/* 1459 */         boolean convertible = (bw.isWritableProperty(propertyName)) && 
/* 1459 */           (!PropertyAccessorUtils.isNestedOrIndexedProperty(propertyName));
/*      */ 
/* 1460 */         if (convertible) {
/* 1461 */           convertedValue = convertForProperty(resolvedValue, propertyName, bw, converter);
/*      */         }
/*      */ 
/* 1465 */         if (resolvedValue == originalValue) {
/* 1466 */           if (convertible) {
/* 1467 */             pv.setConvertedValue(convertedValue);
/*      */           }
/* 1469 */           deepCopy.add(pv);
/*      */         }
/* 1471 */         else if ((convertible) && ((originalValue instanceof TypedStringValue)) && 
/* 1472 */           (!((TypedStringValue)originalValue)
/* 1472 */           .isDynamic()) && (!(convertedValue instanceof Collection)) && 
/* 1473 */           (!ObjectUtils.isArray(convertedValue)))
/*      */         {
/* 1474 */           pv.setConvertedValue(convertedValue);
/* 1475 */           deepCopy.add(pv);
/*      */         }
/*      */         else {
/* 1478 */           resolveNecessary = true;
/* 1479 */           deepCopy.add(new PropertyValue(pv, convertedValue));
/*      */         }
/*      */       }
/*      */     }
/* 1483 */     if ((mpvs != null) && (!resolveNecessary)) {
/* 1484 */       mpvs.setConverted();
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1489 */       bw.setPropertyValues(new MutablePropertyValues(deepCopy));
/*      */     }
/*      */     catch (BeansException ex)
/*      */     {
/* 1493 */       throw new BeanCreationException(mbd
/* 1493 */         .getResourceDescription(), beanName, "Error setting property values", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Object convertForProperty(Object value, String propertyName, BeanWrapper bw, TypeConverter converter)
/*      */   {
/* 1501 */     if ((converter instanceof BeanWrapperImpl)) {
/* 1502 */       return ((BeanWrapperImpl)converter).convertForProperty(value, propertyName);
/*      */     }
/*      */ 
/* 1505 */     PropertyDescriptor pd = bw.getPropertyDescriptor(propertyName);
/* 1506 */     MethodParameter methodParam = BeanUtils.getWriteMethodParameter(pd);
/* 1507 */     return converter.convertIfNecessary(value, pd.getPropertyType(), methodParam);
/*      */   }
/*      */ 
/*      */   protected Object initializeBean(final String beanName, final Object bean, RootBeanDefinition mbd)
/*      */   {
/* 1530 */     if (System.getSecurityManager() != null) {
/* 1531 */       AccessController.doPrivileged(new PrivilegedAction()
/*      */       {
/*      */         public Object run() {
/* 1534 */           AbstractAutowireCapableBeanFactory.this.invokeAwareMethods(beanName, bean);
/* 1535 */           return null;
/*      */         }
/*      */       }
/*      */       , getAccessControlContext());
/*      */     }
/*      */     else {
/* 1540 */       invokeAwareMethods(beanName, bean);
/*      */     }
/*      */ 
/* 1543 */     Object wrappedBean = bean;
/* 1544 */     if ((mbd == null) || (!mbd.isSynthetic())) {
/* 1545 */       wrappedBean = applyBeanPostProcessorsBeforeInitialization(wrappedBean, beanName);
/*      */     }
/*      */     try
/*      */     {
/* 1549 */       invokeInitMethods(beanName, wrappedBean, mbd);
/*      */     }
/*      */     catch (Throwable ex)
/*      */     {
/* 1553 */       throw new BeanCreationException(mbd != null ? mbd
/* 1553 */         .getResourceDescription() : null, beanName, "Invocation of init method failed", ex);
/*      */     }
/*      */ 
/* 1557 */     if ((mbd == null) || (!mbd.isSynthetic())) {
/* 1558 */       wrappedBean = applyBeanPostProcessorsAfterInitialization(wrappedBean, beanName);
/*      */     }
/* 1560 */     return wrappedBean;
/*      */   }
/*      */ 
/*      */   private void invokeAwareMethods(String beanName, Object bean) {
/* 1564 */     if ((bean instanceof Aware)) {
/* 1565 */       if ((bean instanceof BeanNameAware)) {
/* 1566 */         ((BeanNameAware)bean).setBeanName(beanName);
/*      */       }
/* 1568 */       if ((bean instanceof BeanClassLoaderAware)) {
/* 1569 */         ((BeanClassLoaderAware)bean).setBeanClassLoader(getBeanClassLoader());
/*      */       }
/* 1571 */       if ((bean instanceof BeanFactoryAware))
/* 1572 */         ((BeanFactoryAware)bean).setBeanFactory(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void invokeInitMethods(String beanName, final Object bean, RootBeanDefinition mbd)
/*      */     throws Throwable
/*      */   {
/* 1592 */     boolean isInitializingBean = bean instanceof InitializingBean;
/* 1593 */     if ((isInitializingBean) && ((mbd == null) || (!mbd.isExternallyManagedInitMethod("afterPropertiesSet")))) {
/* 1594 */       if (this.logger.isDebugEnabled()) {
/* 1595 */         this.logger.debug("Invoking afterPropertiesSet() on bean with name '" + beanName + "'");
/*      */       }
/* 1597 */       if (System.getSecurityManager() != null) {
/*      */         try {
/* 1599 */           AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */           {
/*      */             public Object run() throws Exception {
/* 1602 */               ((InitializingBean)bean).afterPropertiesSet();
/* 1603 */               return null;
/*      */             }
/*      */           }
/*      */           , getAccessControlContext());
/*      */         }
/*      */         catch (PrivilegedActionException pae) {
/* 1608 */           throw pae.getException();
/*      */         }
/*      */       }
/*      */       else {
/* 1612 */         ((InitializingBean)bean).afterPropertiesSet();
/*      */       }
/*      */     }
/*      */ 
/* 1616 */     if (mbd != null) {
/* 1617 */       String initMethodName = mbd.getInitMethodName();
/* 1618 */       if ((initMethodName != null) && ((!isInitializingBean) || (!"afterPropertiesSet".equals(initMethodName))) && 
/* 1619 */         (!mbd
/* 1619 */         .isExternallyManagedInitMethod(initMethodName)))
/*      */       {
/* 1620 */         invokeCustomInitMethod(beanName, bean, mbd);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void invokeCustomInitMethod(String beanName, final Object bean, RootBeanDefinition mbd)
/*      */     throws Throwable
/*      */   {
/* 1633 */     String initMethodName = mbd.getInitMethodName();
/*      */ 
/* 1636 */     final Method initMethod = mbd.isNonPublicAccessAllowed() ? 
/* 1635 */       BeanUtils.findMethod(bean
/* 1635 */       .getClass(), initMethodName, new Class[0]) : 
/* 1636 */       ClassUtils.getMethodIfAvailable(bean
/* 1636 */       .getClass(), initMethodName, new Class[0]);
/* 1637 */     if (initMethod == null) {
/* 1638 */       if (mbd.isEnforceInitMethod()) {
/* 1639 */         throw new BeanDefinitionValidationException("Couldn't find an init method named '" + initMethodName + "' on bean with name '" + beanName + "'");
/*      */       }
/*      */ 
/* 1643 */       if (this.logger.isDebugEnabled()) {
/* 1644 */         this.logger.debug("No default init method named '" + initMethodName + "' found on bean with name '" + beanName + "'");
/*      */       }
/*      */ 
/* 1648 */       return;
/*      */     }
/*      */ 
/* 1652 */     if (this.logger.isDebugEnabled()) {
/* 1653 */       this.logger.debug("Invoking init method  '" + initMethodName + "' on bean with name '" + beanName + "'");
/*      */     }
/*      */ 
/* 1656 */     if (System.getSecurityManager() != null) {
/* 1657 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/* 1660 */           ReflectionUtils.makeAccessible(initMethod);
/* 1661 */           return null;
/*      */         }
/*      */       });
/*      */       try {
/* 1665 */         AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */         {
/*      */           public Object run() throws Exception {
/* 1668 */             initMethod.invoke(bean, new Object[0]);
/* 1669 */             return null;
/*      */           }
/*      */         }
/*      */         , getAccessControlContext());
/*      */       }
/*      */       catch (PrivilegedActionException pae) {
/* 1674 */         InvocationTargetException ex = (InvocationTargetException)pae.getException();
/* 1675 */         throw ex.getTargetException();
/*      */       }
/*      */     }
/*      */     else {
/*      */       try {
/* 1680 */         ReflectionUtils.makeAccessible(initMethod);
/* 1681 */         initMethod.invoke(bean, new Object[0]);
/*      */       }
/*      */       catch (InvocationTargetException ex) {
/* 1684 */         throw ex.getTargetException();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Object postProcessObjectFromFactoryBean(Object object, String beanName)
/*      */   {
/* 1698 */     return applyBeanPostProcessorsAfterInitialization(object, beanName);
/*      */   }
/*      */ 
/*      */   protected void removeSingleton(String beanName)
/*      */   {
/* 1706 */     super.removeSingleton(beanName);
/* 1707 */     this.factoryBeanInstanceCache.remove(beanName);
/*      */   }
/*      */ 
/*      */   private static class AutowireByTypeDependencyDescriptor extends DependencyDescriptor
/*      */   {
/*      */     public AutowireByTypeDependencyDescriptor(MethodParameter methodParameter, boolean eager)
/*      */     {
/* 1719 */       super(false, eager);
/*      */     }
/*      */ 
/*      */     public String getDependencyName()
/*      */     {
/* 1724 */       return null;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory
 * JD-Core Version:    0.6.2
 */