/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.util.Arrays;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.springframework.beans.BeanMetadataAttributeAccessor;
/*      */ import org.springframework.beans.MutablePropertyValues;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*      */ import org.springframework.core.io.DescriptiveResource;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public abstract class AbstractBeanDefinition extends BeanMetadataAttributeAccessor
/*      */   implements BeanDefinition, Cloneable
/*      */ {
/*      */   public static final String SCOPE_DEFAULT = "";
/*      */   public static final int AUTOWIRE_NO = 0;
/*      */   public static final int AUTOWIRE_BY_NAME = 1;
/*      */   public static final int AUTOWIRE_BY_TYPE = 2;
/*      */   public static final int AUTOWIRE_CONSTRUCTOR = 3;
/*      */ 
/*      */   @Deprecated
/*      */   public static final int AUTOWIRE_AUTODETECT = 4;
/*      */   public static final int DEPENDENCY_CHECK_NONE = 0;
/*      */   public static final int DEPENDENCY_CHECK_OBJECTS = 1;
/*      */   public static final int DEPENDENCY_CHECK_SIMPLE = 2;
/*      */   public static final int DEPENDENCY_CHECK_ALL = 3;
/*      */   public static final String INFER_METHOD = "(inferred)";
/*      */   private volatile Object beanClass;
/*  137 */   private String scope = "";
/*      */ 
/*  139 */   private boolean abstractFlag = false;
/*      */ 
/*  141 */   private boolean lazyInit = false;
/*      */ 
/*  143 */   private int autowireMode = 0;
/*      */ 
/*  145 */   private int dependencyCheck = 0;
/*      */   private String[] dependsOn;
/*  149 */   private boolean autowireCandidate = true;
/*      */ 
/*  151 */   private boolean primary = false;
/*      */ 
/*  153 */   private final Map<String, AutowireCandidateQualifier> qualifiers = new LinkedHashMap(0);
/*      */ 
/*  156 */   private boolean nonPublicAccessAllowed = true;
/*      */ 
/*  158 */   private boolean lenientConstructorResolution = true;
/*      */   private ConstructorArgumentValues constructorArgumentValues;
/*      */   private MutablePropertyValues propertyValues;
/*  164 */   private MethodOverrides methodOverrides = new MethodOverrides();
/*      */   private String factoryBeanName;
/*      */   private String factoryMethodName;
/*      */   private String initMethodName;
/*      */   private String destroyMethodName;
/*  174 */   private boolean enforceInitMethod = true;
/*      */ 
/*  176 */   private boolean enforceDestroyMethod = true;
/*      */ 
/*  178 */   private boolean synthetic = false;
/*      */ 
/*  180 */   private int role = 0;
/*      */   private String description;
/*      */   private Resource resource;
/*      */ 
/*      */   protected AbstractBeanDefinition()
/*      */   {
/*  191 */     this(null, null);
/*      */   }
/*      */ 
/*      */   protected AbstractBeanDefinition(ConstructorArgumentValues cargs, MutablePropertyValues pvs)
/*      */   {
/*  199 */     setConstructorArgumentValues(cargs);
/*  200 */     setPropertyValues(pvs);
/*      */   }
/*      */ 
/*      */   protected AbstractBeanDefinition(BeanDefinition original)
/*      */   {
/*  209 */     setParentName(original.getParentName());
/*  210 */     setBeanClassName(original.getBeanClassName());
/*  211 */     setFactoryBeanName(original.getFactoryBeanName());
/*  212 */     setFactoryMethodName(original.getFactoryMethodName());
/*  213 */     setScope(original.getScope());
/*  214 */     setAbstract(original.isAbstract());
/*  215 */     setLazyInit(original.isLazyInit());
/*  216 */     setRole(original.getRole());
/*  217 */     setConstructorArgumentValues(new ConstructorArgumentValues(original.getConstructorArgumentValues()));
/*  218 */     setPropertyValues(new MutablePropertyValues(original.getPropertyValues()));
/*  219 */     setSource(original.getSource());
/*  220 */     copyAttributesFrom(original);
/*      */ 
/*  222 */     if ((original instanceof AbstractBeanDefinition)) {
/*  223 */       AbstractBeanDefinition originalAbd = (AbstractBeanDefinition)original;
/*  224 */       if (originalAbd.hasBeanClass()) {
/*  225 */         setBeanClass(originalAbd.getBeanClass());
/*      */       }
/*  227 */       setAutowireMode(originalAbd.getAutowireMode());
/*  228 */       setDependencyCheck(originalAbd.getDependencyCheck());
/*  229 */       setDependsOn(originalAbd.getDependsOn());
/*  230 */       setAutowireCandidate(originalAbd.isAutowireCandidate());
/*  231 */       copyQualifiersFrom(originalAbd);
/*  232 */       setPrimary(originalAbd.isPrimary());
/*  233 */       setNonPublicAccessAllowed(originalAbd.isNonPublicAccessAllowed());
/*  234 */       setLenientConstructorResolution(originalAbd.isLenientConstructorResolution());
/*  235 */       setInitMethodName(originalAbd.getInitMethodName());
/*  236 */       setEnforceInitMethod(originalAbd.isEnforceInitMethod());
/*  237 */       setDestroyMethodName(originalAbd.getDestroyMethodName());
/*  238 */       setEnforceDestroyMethod(originalAbd.isEnforceDestroyMethod());
/*  239 */       setMethodOverrides(new MethodOverrides(originalAbd.getMethodOverrides()));
/*  240 */       setSynthetic(originalAbd.isSynthetic());
/*  241 */       setResource(originalAbd.getResource());
/*      */     }
/*      */     else {
/*  244 */       setResourceDescription(original.getResourceDescription());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void overrideFrom(BeanDefinition other)
/*      */   {
/*  266 */     if (StringUtils.hasLength(other.getBeanClassName())) {
/*  267 */       setBeanClassName(other.getBeanClassName());
/*      */     }
/*  269 */     if (StringUtils.hasLength(other.getFactoryBeanName())) {
/*  270 */       setFactoryBeanName(other.getFactoryBeanName());
/*      */     }
/*  272 */     if (StringUtils.hasLength(other.getFactoryMethodName())) {
/*  273 */       setFactoryMethodName(other.getFactoryMethodName());
/*      */     }
/*  275 */     if (StringUtils.hasLength(other.getScope())) {
/*  276 */       setScope(other.getScope());
/*      */     }
/*  278 */     setAbstract(other.isAbstract());
/*  279 */     setLazyInit(other.isLazyInit());
/*  280 */     setRole(other.getRole());
/*  281 */     getConstructorArgumentValues().addArgumentValues(other.getConstructorArgumentValues());
/*  282 */     getPropertyValues().addPropertyValues(other.getPropertyValues());
/*  283 */     setSource(other.getSource());
/*  284 */     copyAttributesFrom(other);
/*      */ 
/*  286 */     if ((other instanceof AbstractBeanDefinition)) {
/*  287 */       AbstractBeanDefinition otherAbd = (AbstractBeanDefinition)other;
/*  288 */       if (otherAbd.hasBeanClass()) {
/*  289 */         setBeanClass(otherAbd.getBeanClass());
/*      */       }
/*  291 */       setAutowireCandidate(otherAbd.isAutowireCandidate());
/*  292 */       setAutowireMode(otherAbd.getAutowireMode());
/*  293 */       copyQualifiersFrom(otherAbd);
/*  294 */       setPrimary(otherAbd.isPrimary());
/*  295 */       setDependencyCheck(otherAbd.getDependencyCheck());
/*  296 */       setDependsOn(otherAbd.getDependsOn());
/*  297 */       setNonPublicAccessAllowed(otherAbd.isNonPublicAccessAllowed());
/*  298 */       setLenientConstructorResolution(otherAbd.isLenientConstructorResolution());
/*  299 */       if (StringUtils.hasLength(otherAbd.getInitMethodName())) {
/*  300 */         setInitMethodName(otherAbd.getInitMethodName());
/*  301 */         setEnforceInitMethod(otherAbd.isEnforceInitMethod());
/*      */       }
/*  303 */       if (StringUtils.hasLength(otherAbd.getDestroyMethodName())) {
/*  304 */         setDestroyMethodName(otherAbd.getDestroyMethodName());
/*  305 */         setEnforceDestroyMethod(otherAbd.isEnforceDestroyMethod());
/*      */       }
/*  307 */       getMethodOverrides().addOverrides(otherAbd.getMethodOverrides());
/*  308 */       setSynthetic(otherAbd.isSynthetic());
/*  309 */       setResource(otherAbd.getResource());
/*      */     }
/*      */     else {
/*  312 */       setResourceDescription(other.getResourceDescription());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void applyDefaults(BeanDefinitionDefaults defaults)
/*      */   {
/*  321 */     setLazyInit(defaults.isLazyInit());
/*  322 */     setAutowireMode(defaults.getAutowireMode());
/*  323 */     setDependencyCheck(defaults.getDependencyCheck());
/*  324 */     setInitMethodName(defaults.getInitMethodName());
/*  325 */     setEnforceInitMethod(false);
/*  326 */     setDestroyMethodName(defaults.getDestroyMethodName());
/*  327 */     setEnforceDestroyMethod(false);
/*      */   }
/*      */ 
/*      */   public boolean hasBeanClass()
/*      */   {
/*  335 */     return this.beanClass instanceof Class;
/*      */   }
/*      */ 
/*      */   public void setBeanClass(Class<?> beanClass)
/*      */   {
/*  342 */     this.beanClass = beanClass;
/*      */   }
/*      */ 
/*      */   public Class<?> getBeanClass()
/*      */     throws IllegalStateException
/*      */   {
/*  352 */     Object beanClassObject = this.beanClass;
/*  353 */     if (beanClassObject == null) {
/*  354 */       throw new IllegalStateException("No bean class specified on bean definition");
/*      */     }
/*  356 */     if (!(beanClassObject instanceof Class)) {
/*  357 */       throw new IllegalStateException(new StringBuilder().append("Bean class name [").append(beanClassObject).append("] has not been resolved into an actual Class").toString());
/*      */     }
/*      */ 
/*  360 */     return (Class)beanClassObject;
/*      */   }
/*      */ 
/*      */   public void setBeanClassName(String beanClassName)
/*      */   {
/*  365 */     this.beanClass = beanClassName;
/*      */   }
/*      */ 
/*      */   public String getBeanClassName()
/*      */   {
/*  370 */     Object beanClassObject = this.beanClass;
/*  371 */     if ((beanClassObject instanceof Class)) {
/*  372 */       return ((Class)beanClassObject).getName();
/*      */     }
/*      */ 
/*  375 */     return (String)beanClassObject;
/*      */   }
/*      */ 
/*      */   public Class<?> resolveBeanClass(ClassLoader classLoader)
/*      */     throws ClassNotFoundException
/*      */   {
/*  388 */     String className = getBeanClassName();
/*  389 */     if (className == null) {
/*  390 */       return null;
/*      */     }
/*  392 */     Class resolvedClass = ClassUtils.forName(className, classLoader);
/*  393 */     this.beanClass = resolvedClass;
/*  394 */     return resolvedClass;
/*      */   }
/*      */ 
/*      */   public void setScope(String scope)
/*      */   {
/*  410 */     this.scope = scope;
/*      */   }
/*      */ 
/*      */   public String getScope()
/*      */   {
/*  418 */     return this.scope;
/*      */   }
/*      */ 
/*      */   public boolean isSingleton()
/*      */   {
/*  428 */     return ("singleton".equals(this.scope)) || ("".equals(this.scope));
/*      */   }
/*      */ 
/*      */   public boolean isPrototype()
/*      */   {
/*  438 */     return "prototype".equals(this.scope);
/*      */   }
/*      */ 
/*      */   public void setAbstract(boolean abstractFlag)
/*      */   {
/*  448 */     this.abstractFlag = abstractFlag;
/*      */   }
/*      */ 
/*      */   public boolean isAbstract()
/*      */   {
/*  457 */     return this.abstractFlag;
/*      */   }
/*      */ 
/*      */   public void setLazyInit(boolean lazyInit)
/*      */   {
/*  467 */     this.lazyInit = lazyInit;
/*      */   }
/*      */ 
/*      */   public boolean isLazyInit()
/*      */   {
/*  476 */     return this.lazyInit;
/*      */   }
/*      */ 
/*      */   public void setAutowireMode(int autowireMode)
/*      */   {
/*  493 */     this.autowireMode = autowireMode;
/*      */   }
/*      */ 
/*      */   public int getAutowireMode()
/*      */   {
/*  500 */     return this.autowireMode;
/*      */   }
/*      */ 
/*      */   public int getResolvedAutowireMode()
/*      */   {
/*  511 */     if (this.autowireMode == 4)
/*      */     {
/*  515 */       Constructor[] constructors = getBeanClass().getConstructors();
/*  516 */       for (Constructor constructor : constructors) {
/*  517 */         if (constructor.getParameterTypes().length == 0) {
/*  518 */           return 2;
/*      */         }
/*      */       }
/*  521 */       return 3;
/*      */     }
/*      */ 
/*  524 */     return this.autowireMode;
/*      */   }
/*      */ 
/*      */   public void setDependencyCheck(int dependencyCheck)
/*      */   {
/*  538 */     this.dependencyCheck = dependencyCheck;
/*      */   }
/*      */ 
/*      */   public int getDependencyCheck()
/*      */   {
/*  545 */     return this.dependencyCheck;
/*      */   }
/*      */ 
/*      */   public void setDependsOn(String[] dependsOn)
/*      */   {
/*  557 */     this.dependsOn = dependsOn;
/*      */   }
/*      */ 
/*      */   public String[] getDependsOn()
/*      */   {
/*  565 */     return this.dependsOn;
/*      */   }
/*      */ 
/*      */   public void setAutowireCandidate(boolean autowireCandidate)
/*      */   {
/*  573 */     this.autowireCandidate = autowireCandidate;
/*      */   }
/*      */ 
/*      */   public boolean isAutowireCandidate()
/*      */   {
/*  581 */     return this.autowireCandidate;
/*      */   }
/*      */ 
/*      */   public void setPrimary(boolean primary)
/*      */   {
/*  591 */     this.primary = primary;
/*      */   }
/*      */ 
/*      */   public boolean isPrimary()
/*      */   {
/*  601 */     return this.primary;
/*      */   }
/*      */ 
/*      */   public void addQualifier(AutowireCandidateQualifier qualifier)
/*      */   {
/*  610 */     this.qualifiers.put(qualifier.getTypeName(), qualifier);
/*      */   }
/*      */ 
/*      */   public boolean hasQualifier(String typeName)
/*      */   {
/*  617 */     return this.qualifiers.keySet().contains(typeName);
/*      */   }
/*      */ 
/*      */   public AutowireCandidateQualifier getQualifier(String typeName)
/*      */   {
/*  624 */     return (AutowireCandidateQualifier)this.qualifiers.get(typeName);
/*      */   }
/*      */ 
/*      */   public Set<AutowireCandidateQualifier> getQualifiers()
/*      */   {
/*  632 */     return new LinkedHashSet(this.qualifiers.values());
/*      */   }
/*      */ 
/*      */   public void copyQualifiersFrom(AbstractBeanDefinition source)
/*      */   {
/*  640 */     Assert.notNull(source, "Source must not be null");
/*  641 */     this.qualifiers.putAll(source.qualifiers);
/*      */   }
/*      */ 
/*      */   public void setNonPublicAccessAllowed(boolean nonPublicAccessAllowed)
/*      */   {
/*  656 */     this.nonPublicAccessAllowed = nonPublicAccessAllowed;
/*      */   }
/*      */ 
/*      */   public boolean isNonPublicAccessAllowed()
/*      */   {
/*  663 */     return this.nonPublicAccessAllowed;
/*      */   }
/*      */ 
/*      */   public void setLenientConstructorResolution(boolean lenientConstructorResolution)
/*      */   {
/*  673 */     this.lenientConstructorResolution = lenientConstructorResolution;
/*      */   }
/*      */ 
/*      */   public boolean isLenientConstructorResolution()
/*      */   {
/*  680 */     return this.lenientConstructorResolution;
/*      */   }
/*      */ 
/*      */   public void setConstructorArgumentValues(ConstructorArgumentValues constructorArgumentValues)
/*      */   {
/*  687 */     this.constructorArgumentValues = (constructorArgumentValues != null ? constructorArgumentValues : new ConstructorArgumentValues());
/*      */   }
/*      */ 
/*      */   public ConstructorArgumentValues getConstructorArgumentValues()
/*      */   {
/*  696 */     return this.constructorArgumentValues;
/*      */   }
/*      */ 
/*      */   public boolean hasConstructorArgumentValues()
/*      */   {
/*  703 */     return !this.constructorArgumentValues.isEmpty();
/*      */   }
/*      */ 
/*      */   public void setPropertyValues(MutablePropertyValues propertyValues)
/*      */   {
/*  710 */     this.propertyValues = (propertyValues != null ? propertyValues : new MutablePropertyValues());
/*      */   }
/*      */ 
/*      */   public MutablePropertyValues getPropertyValues()
/*      */   {
/*  718 */     return this.propertyValues;
/*      */   }
/*      */ 
/*      */   public void setMethodOverrides(MethodOverrides methodOverrides)
/*      */   {
/*  725 */     this.methodOverrides = (methodOverrides != null ? methodOverrides : new MethodOverrides());
/*      */   }
/*      */ 
/*      */   public MethodOverrides getMethodOverrides()
/*      */   {
/*  734 */     return this.methodOverrides;
/*      */   }
/*      */ 
/*      */   public void setFactoryBeanName(String factoryBeanName)
/*      */   {
/*  740 */     this.factoryBeanName = factoryBeanName;
/*      */   }
/*      */ 
/*      */   public String getFactoryBeanName()
/*      */   {
/*  745 */     return this.factoryBeanName;
/*      */   }
/*      */ 
/*      */   public void setFactoryMethodName(String factoryMethodName)
/*      */   {
/*  750 */     this.factoryMethodName = factoryMethodName;
/*      */   }
/*      */ 
/*      */   public String getFactoryMethodName()
/*      */   {
/*  755 */     return this.factoryMethodName;
/*      */   }
/*      */ 
/*      */   public void setInitMethodName(String initMethodName)
/*      */   {
/*  763 */     this.initMethodName = initMethodName;
/*      */   }
/*      */ 
/*      */   public String getInitMethodName()
/*      */   {
/*  770 */     return this.initMethodName;
/*      */   }
/*      */ 
/*      */   public void setEnforceInitMethod(boolean enforceInitMethod)
/*      */   {
/*  779 */     this.enforceInitMethod = enforceInitMethod;
/*      */   }
/*      */ 
/*      */   public boolean isEnforceInitMethod()
/*      */   {
/*  787 */     return this.enforceInitMethod;
/*      */   }
/*      */ 
/*      */   public void setDestroyMethodName(String destroyMethodName)
/*      */   {
/*  795 */     this.destroyMethodName = destroyMethodName;
/*      */   }
/*      */ 
/*      */   public String getDestroyMethodName()
/*      */   {
/*  802 */     return this.destroyMethodName;
/*      */   }
/*      */ 
/*      */   public void setEnforceDestroyMethod(boolean enforceDestroyMethod)
/*      */   {
/*  811 */     this.enforceDestroyMethod = enforceDestroyMethod;
/*      */   }
/*      */ 
/*      */   public boolean isEnforceDestroyMethod()
/*      */   {
/*  819 */     return this.enforceDestroyMethod;
/*      */   }
/*      */ 
/*      */   public void setSynthetic(boolean synthetic)
/*      */   {
/*  829 */     this.synthetic = synthetic;
/*      */   }
/*      */ 
/*      */   public boolean isSynthetic()
/*      */   {
/*  837 */     return this.synthetic;
/*      */   }
/*      */ 
/*      */   public void setRole(int role)
/*      */   {
/*  844 */     this.role = role;
/*      */   }
/*      */ 
/*      */   public int getRole()
/*      */   {
/*  852 */     return this.role;
/*      */   }
/*      */ 
/*      */   public void setDescription(String description)
/*      */   {
/*  860 */     this.description = description;
/*      */   }
/*      */ 
/*      */   public String getDescription()
/*      */   {
/*  865 */     return this.description;
/*      */   }
/*      */ 
/*      */   public void setResource(Resource resource)
/*      */   {
/*  873 */     this.resource = resource;
/*      */   }
/*      */ 
/*      */   public Resource getResource()
/*      */   {
/*  880 */     return this.resource;
/*      */   }
/*      */ 
/*      */   public void setResourceDescription(String resourceDescription)
/*      */   {
/*  888 */     this.resource = new DescriptiveResource(resourceDescription);
/*      */   }
/*      */ 
/*      */   public String getResourceDescription()
/*      */   {
/*  893 */     return this.resource != null ? this.resource.getDescription() : null;
/*      */   }
/*      */ 
/*      */   public void setOriginatingBeanDefinition(BeanDefinition originatingBd)
/*      */   {
/*  900 */     this.resource = new BeanDefinitionResource(originatingBd);
/*      */   }
/*      */ 
/*      */   public BeanDefinition getOriginatingBeanDefinition()
/*      */   {
/*  906 */     return (this.resource instanceof BeanDefinitionResource) ? ((BeanDefinitionResource)this.resource)
/*  906 */       .getBeanDefinition() : null;
/*      */   }
/*      */ 
/*      */   public void validate()
/*      */     throws BeanDefinitionValidationException
/*      */   {
/*  914 */     if ((!getMethodOverrides().isEmpty()) && (getFactoryMethodName() != null)) {
/*  915 */       throw new BeanDefinitionValidationException("Cannot combine static factory method with method overrides: the static factory method must create the instance");
/*      */     }
/*      */ 
/*  920 */     if (hasBeanClass())
/*  921 */       prepareMethodOverrides();
/*      */   }
/*      */ 
/*      */   public void prepareMethodOverrides()
/*      */     throws BeanDefinitionValidationException
/*      */   {
/*  932 */     MethodOverrides methodOverrides = getMethodOverrides();
/*  933 */     if (!methodOverrides.isEmpty())
/*  934 */       for (MethodOverride mo : methodOverrides.getOverrides())
/*  935 */         prepareMethodOverride(mo);
/*      */   }
/*      */ 
/*      */   protected void prepareMethodOverride(MethodOverride mo)
/*      */     throws BeanDefinitionValidationException
/*      */   {
/*  948 */     int count = ClassUtils.getMethodCountForName(getBeanClass(), mo.getMethodName());
/*  949 */     if (count == 0)
/*      */     {
/*  952 */       throw new BeanDefinitionValidationException(new StringBuilder().append("Invalid method override: no method with name '")
/*  951 */         .append(mo
/*  951 */         .getMethodName()).append("' on class [")
/*  952 */         .append(getBeanClassName()).append("]").toString());
/*      */     }
/*  954 */     if (count == 1)
/*      */     {
/*  956 */       mo.setOverloaded(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Object clone()
/*      */   {
/*  968 */     return cloneBeanDefinition();
/*      */   }
/*      */ 
/*      */   public abstract AbstractBeanDefinition cloneBeanDefinition();
/*      */ 
/*      */   public boolean equals(Object other)
/*      */   {
/*  981 */     if (this == other) {
/*  982 */       return true;
/*      */     }
/*  984 */     if (!(other instanceof AbstractBeanDefinition)) {
/*  985 */       return false;
/*      */     }
/*      */ 
/*  988 */     AbstractBeanDefinition that = (AbstractBeanDefinition)other;
/*      */ 
/*  990 */     if (!ObjectUtils.nullSafeEquals(getBeanClassName(), that.getBeanClassName())) return false;
/*  991 */     if (!ObjectUtils.nullSafeEquals(this.scope, that.scope)) return false;
/*  992 */     if (this.abstractFlag != that.abstractFlag) return false;
/*  993 */     if (this.lazyInit != that.lazyInit) return false;
/*      */ 
/*  995 */     if (this.autowireMode != that.autowireMode) return false;
/*  996 */     if (this.dependencyCheck != that.dependencyCheck) return false;
/*  997 */     if (!Arrays.equals(this.dependsOn, that.dependsOn)) return false;
/*  998 */     if (this.autowireCandidate != that.autowireCandidate) return false;
/*  999 */     if (!ObjectUtils.nullSafeEquals(this.qualifiers, that.qualifiers)) return false;
/* 1000 */     if (this.primary != that.primary) return false;
/*      */ 
/* 1002 */     if (this.nonPublicAccessAllowed != that.nonPublicAccessAllowed) return false;
/* 1003 */     if (this.lenientConstructorResolution != that.lenientConstructorResolution) return false;
/* 1004 */     if (!ObjectUtils.nullSafeEquals(this.constructorArgumentValues, that.constructorArgumentValues)) return false;
/* 1005 */     if (!ObjectUtils.nullSafeEquals(this.propertyValues, that.propertyValues)) return false;
/* 1006 */     if (!ObjectUtils.nullSafeEquals(this.methodOverrides, that.methodOverrides)) return false;
/*      */ 
/* 1008 */     if (!ObjectUtils.nullSafeEquals(this.factoryBeanName, that.factoryBeanName)) return false;
/* 1009 */     if (!ObjectUtils.nullSafeEquals(this.factoryMethodName, that.factoryMethodName)) return false;
/* 1010 */     if (!ObjectUtils.nullSafeEquals(this.initMethodName, that.initMethodName)) return false;
/* 1011 */     if (this.enforceInitMethod != that.enforceInitMethod) return false;
/* 1012 */     if (!ObjectUtils.nullSafeEquals(this.destroyMethodName, that.destroyMethodName)) return false;
/* 1013 */     if (this.enforceDestroyMethod != that.enforceDestroyMethod) return false;
/*      */ 
/* 1015 */     if (this.synthetic != that.synthetic) return false;
/* 1016 */     if (this.role != that.role) return false;
/*      */ 
/* 1018 */     return super.equals(other);
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1023 */     int hashCode = ObjectUtils.nullSafeHashCode(getBeanClassName());
/* 1024 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.scope);
/* 1025 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.constructorArgumentValues);
/* 1026 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.propertyValues);
/* 1027 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.factoryBeanName);
/* 1028 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.factoryMethodName);
/* 1029 */     hashCode = 29 * hashCode + super.hashCode();
/* 1030 */     return hashCode;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1035 */     StringBuilder sb = new StringBuilder("class [");
/* 1036 */     sb.append(getBeanClassName()).append("]");
/* 1037 */     sb.append("; scope=").append(this.scope);
/* 1038 */     sb.append("; abstract=").append(this.abstractFlag);
/* 1039 */     sb.append("; lazyInit=").append(this.lazyInit);
/* 1040 */     sb.append("; autowireMode=").append(this.autowireMode);
/* 1041 */     sb.append("; dependencyCheck=").append(this.dependencyCheck);
/* 1042 */     sb.append("; autowireCandidate=").append(this.autowireCandidate);
/* 1043 */     sb.append("; primary=").append(this.primary);
/* 1044 */     sb.append("; factoryBeanName=").append(this.factoryBeanName);
/* 1045 */     sb.append("; factoryMethodName=").append(this.factoryMethodName);
/* 1046 */     sb.append("; initMethodName=").append(this.initMethodName);
/* 1047 */     sb.append("; destroyMethodName=").append(this.destroyMethodName);
/* 1048 */     if (this.resource != null) {
/* 1049 */       sb.append("; defined in ").append(this.resource.getDescription());
/*      */     }
/* 1051 */     return sb.toString();
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.AbstractBeanDefinition
 * JD-Core Version:    0.6.2
 */