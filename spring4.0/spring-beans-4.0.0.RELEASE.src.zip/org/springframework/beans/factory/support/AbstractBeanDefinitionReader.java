/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractBeanDefinitionReader
/*     */   implements EnvironmentCapable, BeanDefinitionReader
/*     */ {
/*  49 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private ResourceLoader resourceLoader;
/*     */   private ClassLoader beanClassLoader;
/*     */   private Environment environment;
/*  59 */   private BeanNameGenerator beanNameGenerator = new DefaultBeanNameGenerator();
/*     */ 
/*     */   protected AbstractBeanDefinitionReader(BeanDefinitionRegistry registry)
/*     */   {
/*  80 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*  81 */     this.registry = registry;
/*     */ 
/*  84 */     if ((this.registry instanceof ResourceLoader)) {
/*  85 */       this.resourceLoader = ((ResourceLoader)this.registry);
/*     */     }
/*     */     else {
/*  88 */       this.resourceLoader = new PathMatchingResourcePatternResolver();
/*     */     }
/*     */ 
/*  92 */     if ((this.registry instanceof BeanDefinitionReader)) {
/*  93 */       this.environment = ((BeanDefinitionReader)this.registry).getEnvironment();
/*     */     }
/*     */     else
/*  96 */       this.environment = new StandardEnvironment();
/*     */   }
/*     */ 
/*     */   public final BeanDefinitionRegistry getBeanFactory()
/*     */   {
/* 102 */     return this.registry;
/*     */   }
/*     */ 
/*     */   public final BeanDefinitionRegistry getRegistry()
/*     */   {
/* 107 */     return this.registry;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 122 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public ResourceLoader getResourceLoader()
/*     */   {
/* 127 */     return this.resourceLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/* 138 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getBeanClassLoader()
/*     */   {
/* 143 */     return this.beanClassLoader;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 152 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public Environment getEnvironment()
/*     */   {
/* 157 */     return this.environment;
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 166 */     this.beanNameGenerator = (beanNameGenerator != null ? beanNameGenerator : new DefaultBeanNameGenerator());
/*     */   }
/*     */ 
/*     */   public BeanNameGenerator getBeanNameGenerator()
/*     */   {
/* 171 */     return this.beanNameGenerator;
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(Resource[] resources)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 177 */     Assert.notNull(resources, "Resource array must not be null");
/* 178 */     int counter = 0;
/* 179 */     for (Resource resource : resources) {
/* 180 */       counter += loadBeanDefinitions(resource);
/*     */     }
/* 182 */     return counter;
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(String location) throws BeanDefinitionStoreException
/*     */   {
/* 187 */     return loadBeanDefinitions(location, null);
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(String location, Set<Resource> actualResources)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 206 */     ResourceLoader resourceLoader = getResourceLoader();
/* 207 */     if (resourceLoader == null) {
/* 208 */       throw new BeanDefinitionStoreException("Cannot import bean definitions from location [" + location + "]: no ResourceLoader available");
/*     */     }
/*     */ 
/* 212 */     if ((resourceLoader instanceof ResourcePatternResolver)) {
/*     */       try
/*     */       {
/* 215 */         Resource[] resources = ((ResourcePatternResolver)resourceLoader).getResources(location);
/* 216 */         int loadCount = loadBeanDefinitions(resources);
/* 217 */         if (actualResources != null) {
/* 218 */           for (Resource resource : resources) {
/* 219 */             actualResources.add(resource);
/*     */           }
/*     */         }
/* 222 */         if (this.logger.isDebugEnabled()) {
/* 223 */           this.logger.debug("Loaded " + loadCount + " bean definitions from location pattern [" + location + "]");
/*     */         }
/* 225 */         return loadCount;
/*     */       }
/*     */       catch (IOException ex) {
/* 228 */         throw new BeanDefinitionStoreException("Could not resolve bean definition resource pattern [" + location + "]", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 234 */     Resource resource = resourceLoader.getResource(location);
/* 235 */     int loadCount = loadBeanDefinitions(resource);
/* 236 */     if (actualResources != null) {
/* 237 */       actualResources.add(resource);
/*     */     }
/* 239 */     if (this.logger.isDebugEnabled()) {
/* 240 */       this.logger.debug("Loaded " + loadCount + " bean definitions from location [" + location + "]");
/*     */     }
/* 242 */     return loadCount;
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(String[] locations)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 248 */     Assert.notNull(locations, "Location array must not be null");
/* 249 */     int counter = 0;
/* 250 */     for (String location : locations) {
/* 251 */       counter += loadBeanDefinitions(location);
/*     */     }
/* 253 */     return counter;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.AbstractBeanDefinitionReader
 * JD-Core Version:    0.6.2
 */