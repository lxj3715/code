/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import java.beans.PropertyEditor;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.BeanWrapper;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.PropertyEditorRegistrar;
/*      */ import org.springframework.beans.PropertyEditorRegistry;
/*      */ import org.springframework.beans.PropertyEditorRegistrySupport;
/*      */ import org.springframework.beans.SimpleTypeConverter;
/*      */ import org.springframework.beans.TypeConverter;
/*      */ import org.springframework.beans.TypeMismatchException;
/*      */ import org.springframework.beans.factory.BeanCreationException;
/*      */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*      */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.BeanIsAbstractException;
/*      */ import org.springframework.beans.factory.BeanIsNotAFactoryException;
/*      */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*      */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*      */ import org.springframework.beans.factory.FactoryBean;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.ObjectFactory;
/*      */ import org.springframework.beans.factory.SmartFactoryBean;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*      */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*      */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*      */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.Scope;
/*      */ import org.springframework.core.DecoratingClassLoader;
/*      */ import org.springframework.core.NamedThreadLocal;
/*      */ import org.springframework.core.convert.ConversionService;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.StringValueResolver;
/*      */ 
/*      */ public abstract class AbstractBeanFactory extends FactoryBeanRegistrySupport
/*      */   implements ConfigurableBeanFactory
/*      */ {
/*      */   private BeanFactory parentBeanFactory;
/*  116 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*      */   private ClassLoader tempClassLoader;
/*  122 */   private boolean cacheBeanMetadata = true;
/*      */   private BeanExpressionResolver beanExpressionResolver;
/*      */   private ConversionService conversionService;
/*  131 */   private final Set<PropertyEditorRegistrar> propertyEditorRegistrars = new LinkedHashSet(4);
/*      */   private TypeConverter typeConverter;
/*  138 */   private final Map<Class<?>, Class<? extends PropertyEditor>> customEditors = new HashMap(4);
/*      */ 
/*  142 */   private final List<StringValueResolver> embeddedValueResolvers = new LinkedList();
/*      */ 
/*  145 */   private final List<BeanPostProcessor> beanPostProcessors = new ArrayList();
/*      */   private boolean hasInstantiationAwareBeanPostProcessors;
/*      */   private boolean hasDestructionAwareBeanPostProcessors;
/*  154 */   private final Map<String, Scope> scopes = new HashMap(8);
/*      */   private SecurityContextProvider securityContextProvider;
/*  160 */   private final Map<String, RootBeanDefinition> mergedBeanDefinitions = new ConcurrentHashMap(64);
/*      */ 
/*  166 */   private final Set<String> alreadyCreated = Collections.newSetFromMap(new ConcurrentHashMap(64));
/*      */ 
/*  169 */   private final ThreadLocal<Object> prototypesCurrentlyInCreation = new NamedThreadLocal("Prototype beans currently in creation");
/*      */ 
/*      */   public AbstractBeanFactory()
/*      */   {
/*      */   }
/*      */ 
/*      */   public AbstractBeanFactory(BeanFactory parentBeanFactory)
/*      */   {
/*  185 */     this.parentBeanFactory = parentBeanFactory;
/*      */   }
/*      */ 
/*      */   public Object getBean(String name)
/*      */     throws BeansException
/*      */   {
/*  195 */     return doGetBean(name, null, null, false);
/*      */   }
/*      */ 
/*      */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException
/*      */   {
/*  200 */     return doGetBean(name, requiredType, null, false);
/*      */   }
/*      */ 
/*      */   public Object getBean(String name, Object[] args) throws BeansException
/*      */   {
/*  205 */     return doGetBean(name, null, args, false);
/*      */   }
/*      */ 
/*      */   public <T> T getBean(String name, Class<T> requiredType, Object[] args)
/*      */     throws BeansException
/*      */   {
/*  218 */     return doGetBean(name, requiredType, args, false);
/*      */   }
/*      */ 
/*      */   protected <T> T doGetBean(String name, Class<T> requiredType, final Object[] args, boolean typeCheckOnly)
/*      */     throws BeansException
/*      */   {
/*  237 */     final String beanName = transformedBeanName(name);
/*      */ 
/*  241 */     Object sharedInstance = getSingleton(beanName);
/*      */     Object bean;
/*  242 */     if ((sharedInstance != null) && (args == null)) {
/*  243 */       if (this.logger.isDebugEnabled()) {
/*  244 */         if (isSingletonCurrentlyInCreation(beanName)) {
/*  245 */           this.logger.debug(new StringBuilder().append("Returning eagerly cached instance of singleton bean '").append(beanName).append("' that is not fully initialized yet - a consequence of a circular reference").toString());
/*      */         }
/*      */         else
/*      */         {
/*  249 */           this.logger.debug(new StringBuilder().append("Returning cached instance of singleton bean '").append(beanName).append("'").toString());
/*      */         }
/*      */       }
/*  252 */       bean = getObjectForBeanInstance(sharedInstance, name, beanName, null);
/*      */     }
/*      */     else
/*      */     {
/*  258 */       if (isPrototypeCurrentlyInCreation(beanName)) {
/*  259 */         throw new BeanCurrentlyInCreationException(beanName);
/*      */       }
/*      */ 
/*  263 */       BeanFactory parentBeanFactory = getParentBeanFactory();
/*  264 */       if ((parentBeanFactory != null) && (!containsBeanDefinition(beanName)))
/*      */       {
/*  266 */         String nameToLookup = originalBeanName(name);
/*  267 */         if (args != null)
/*      */         {
/*  269 */           return parentBeanFactory.getBean(nameToLookup, args);
/*      */         }
/*      */ 
/*  273 */         return parentBeanFactory.getBean(nameToLookup, requiredType);
/*      */       }
/*      */ 
/*  277 */       if (!typeCheckOnly) {
/*  278 */         markBeanAsCreated(beanName);
/*      */       }
/*      */       try
/*      */       {
/*  282 */         final RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*  283 */         checkMergedBeanDefinition(mbd, beanName, args);
/*      */ 
/*  286 */         String[] dependsOn = mbd.getDependsOn();
/*  287 */         if (dependsOn != null)
/*  288 */           for (String dependsOnBean : dependsOn) {
/*  289 */             if (isDependent(beanName, dependsOnBean)) {
/*  290 */               throw new BeanCreationException(new StringBuilder().append("Circular depends-on relationship between '").append(beanName).append("' and '").append(dependsOnBean).append("'").toString());
/*      */             }
/*      */ 
/*  293 */             registerDependentBean(dependsOnBean, beanName);
/*  294 */             getBean(dependsOnBean);
/*      */           }
/*      */         Object bean;
/*  299 */         if (mbd.isSingleton()) {
/*  300 */           sharedInstance = getSingleton(beanName, new ObjectFactory()
/*      */           {
/*      */             public Object getObject() throws BeansException {
/*      */               try {
/*  304 */                 return AbstractBeanFactory.this.createBean(beanName, mbd, args);
/*      */               }
/*      */               catch (BeansException ex)
/*      */               {
/*  310 */                 AbstractBeanFactory.this.destroySingleton(beanName);
/*  311 */                 throw ex;
/*      */               }
/*      */             }
/*      */           });
/*  315 */           bean = getObjectForBeanInstance(sharedInstance, name, beanName, mbd);
/*      */         }
/*      */         else
/*      */         {
/*      */           Object bean;
/*  318 */           if (mbd.isPrototype())
/*      */           {
/*  320 */             Object prototypeInstance = null;
/*      */             try {
/*  322 */               beforePrototypeCreation(beanName);
/*  323 */               prototypeInstance = createBean(beanName, mbd, args);
/*      */             }
/*      */             finally {
/*  326 */               afterPrototypeCreation(beanName);
/*      */             }
/*  328 */             bean = getObjectForBeanInstance(prototypeInstance, name, beanName, mbd);
/*      */           }
/*      */           else
/*      */           {
/*  332 */             String scopeName = mbd.getScope();
/*  333 */             Scope scope = (Scope)this.scopes.get(scopeName);
/*  334 */             if (scope == null)
/*  335 */               throw new IllegalStateException(new StringBuilder().append("No Scope registered for scope '").append(scopeName).append("'").toString());
/*      */             try
/*      */             {
/*  338 */               Object scopedInstance = scope.get(beanName, new ObjectFactory()
/*      */               {
/*      */                 public Object getObject() throws BeansException {
/*  341 */                   AbstractBeanFactory.this.beforePrototypeCreation(beanName);
/*      */                   try {
/*  343 */                     return AbstractBeanFactory.this.createBean(beanName, mbd, args);
/*      */                   }
/*      */                   finally {
/*  346 */                     AbstractBeanFactory.this.afterPrototypeCreation(beanName);
/*      */                   }
/*      */                 }
/*      */               });
/*  350 */               bean = getObjectForBeanInstance(scopedInstance, name, beanName, mbd);
/*      */             }
/*      */             catch (IllegalStateException ex)
/*      */             {
/*      */               Object bean;
/*  353 */               throw new BeanCreationException(beanName, new StringBuilder().append("Scope '").append(scopeName).append("' is not active for the current thread; ").append("consider defining a scoped proxy for this bean if you intend to refer to it from a singleton").toString(), ex);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (BeansException ex)
/*      */       {
/*      */         Object bean;
/*  361 */         cleanupAfterBeanCreationFailure(beanName);
/*  362 */         throw ex;
/*      */       }
/*      */     }
/*      */     Object bean;
/*  367 */     if ((requiredType != null) && (bean != null) && (!requiredType.isAssignableFrom(bean.getClass()))) {
/*      */       try {
/*  369 */         return getTypeConverter().convertIfNecessary(bean, requiredType);
/*      */       }
/*      */       catch (TypeMismatchException ex) {
/*  372 */         if (this.logger.isDebugEnabled()) {
/*  373 */           this.logger.debug(new StringBuilder().append("Failed to convert bean '").append(name).append("' to required type [")
/*  374 */             .append(ClassUtils.getQualifiedName(requiredType))
/*  374 */             .append("]").toString(), ex);
/*      */         }
/*  376 */         throw new BeanNotOfRequiredTypeException(name, requiredType, bean.getClass());
/*      */       }
/*      */     }
/*  379 */     return bean;
/*      */   }
/*      */ 
/*      */   public boolean containsBean(String name)
/*      */   {
/*  384 */     String beanName = transformedBeanName(name);
/*  385 */     if ((containsSingleton(beanName)) || (containsBeanDefinition(beanName))) {
/*  386 */       return (!BeanFactoryUtils.isFactoryDereference(name)) || (isFactoryBean(name));
/*      */     }
/*      */ 
/*  389 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  390 */     return (parentBeanFactory != null) && (parentBeanFactory.containsBean(originalBeanName(name)));
/*      */   }
/*      */ 
/*      */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException
/*      */   {
/*  395 */     String beanName = transformedBeanName(name);
/*      */ 
/*  397 */     Object beanInstance = getSingleton(beanName, false);
/*  398 */     if (beanInstance != null) {
/*  399 */       if ((beanInstance instanceof FactoryBean)) {
/*  400 */         return (BeanFactoryUtils.isFactoryDereference(name)) || (((FactoryBean)beanInstance).isSingleton());
/*      */       }
/*      */ 
/*  403 */       return !BeanFactoryUtils.isFactoryDereference(name);
/*      */     }
/*      */ 
/*  406 */     if (containsSingleton(beanName)) {
/*  407 */       return true;
/*      */     }
/*      */ 
/*  412 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  413 */     if ((parentBeanFactory != null) && (!containsBeanDefinition(beanName)))
/*      */     {
/*  415 */       return parentBeanFactory.isSingleton(originalBeanName(name));
/*      */     }
/*      */ 
/*  418 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*      */ 
/*  421 */     if (mbd.isSingleton()) {
/*  422 */       if (isFactoryBean(beanName, mbd)) {
/*  423 */         if (BeanFactoryUtils.isFactoryDereference(name)) {
/*  424 */           return true;
/*      */         }
/*  426 */         FactoryBean factoryBean = (FactoryBean)getBean(new StringBuilder().append("&").append(beanName).toString());
/*  427 */         return factoryBean.isSingleton();
/*      */       }
/*      */ 
/*  430 */       return !BeanFactoryUtils.isFactoryDereference(name);
/*      */     }
/*      */ 
/*  434 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isPrototype(String name)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/*  441 */     String beanName = transformedBeanName(name);
/*      */ 
/*  443 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  444 */     if ((parentBeanFactory != null) && (!containsBeanDefinition(beanName)))
/*      */     {
/*  446 */       return parentBeanFactory.isPrototype(originalBeanName(name));
/*      */     }
/*      */ 
/*  449 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*  450 */     if (mbd.isPrototype())
/*      */     {
/*  452 */       return (!BeanFactoryUtils.isFactoryDereference(name)) || (isFactoryBean(beanName, mbd));
/*      */     }
/*      */ 
/*  457 */     if (BeanFactoryUtils.isFactoryDereference(name)) {
/*  458 */       return false;
/*      */     }
/*  460 */     if (isFactoryBean(beanName, mbd)) {
/*  461 */       final FactoryBean factoryBean = (FactoryBean)getBean(new StringBuilder().append("&").append(beanName).toString());
/*  462 */       if (System.getSecurityManager() != null) {
/*  463 */         return ((Boolean)AccessController.doPrivileged(new PrivilegedAction()
/*      */         {
/*      */           public Boolean run() {
/*  466 */             return Boolean.valueOf((((factoryBean instanceof SmartFactoryBean)) && (((SmartFactoryBean)factoryBean).isPrototype())) || 
/*  467 */               (!factoryBean
/*  467 */               .isSingleton()));
/*      */           }
/*      */         }
/*      */         , getAccessControlContext())).booleanValue();
/*      */       }
/*      */ 
/*  473 */       return (((factoryBean instanceof SmartFactoryBean)) && (((SmartFactoryBean)factoryBean).isPrototype())) || 
/*  473 */         (!factoryBean
/*  473 */         .isSingleton());
/*      */     }
/*      */ 
/*  477 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isTypeMatch(String name, Class<?> targetType)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/*  484 */     String beanName = transformedBeanName(name);
/*  485 */     Class typeToMatch = targetType != null ? targetType : Object.class;
/*      */ 
/*  488 */     Object beanInstance = getSingleton(beanName, false);
/*  489 */     if (beanInstance != null) {
/*  490 */       if ((beanInstance instanceof FactoryBean)) {
/*  491 */         if (!BeanFactoryUtils.isFactoryDereference(name)) {
/*  492 */           Class type = getTypeForFactoryBean((FactoryBean)beanInstance);
/*  493 */           return (type != null) && (ClassUtils.isAssignable(typeToMatch, type));
/*      */         }
/*      */ 
/*  496 */         return ClassUtils.isAssignableValue(typeToMatch, beanInstance);
/*      */       }
/*      */ 
/*  501 */       return (!BeanFactoryUtils.isFactoryDereference(name)) && 
/*  501 */         (ClassUtils.isAssignableValue(typeToMatch, beanInstance));
/*      */     }
/*      */ 
/*  504 */     if ((containsSingleton(beanName)) && (!containsBeanDefinition(beanName)))
/*      */     {
/*  506 */       return false;
/*      */     }
/*      */ 
/*  511 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  512 */     if ((parentBeanFactory != null) && (!containsBeanDefinition(beanName)))
/*      */     {
/*  514 */       return parentBeanFactory.isTypeMatch(originalBeanName(name), targetType);
/*      */     }
/*      */ 
/*  518 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*      */ 
/*  520 */     Class[] typesToMatch = { FactoryBean.class, FactoryBean.class.equals(typeToMatch) ? new Class[] { typeToMatch } : typeToMatch };
/*      */ 
/*  525 */     BeanDefinitionHolder dbd = mbd.getDecoratedDefinition();
/*  526 */     if ((dbd != null) && (!BeanFactoryUtils.isFactoryDereference(name))) {
/*  527 */       RootBeanDefinition tbd = getMergedBeanDefinition(dbd.getBeanName(), dbd.getBeanDefinition(), mbd);
/*  528 */       Class targetClass = predictBeanType(dbd.getBeanName(), tbd, typesToMatch);
/*  529 */       if ((targetClass != null) && (!FactoryBean.class.isAssignableFrom(targetClass))) {
/*  530 */         return typeToMatch.isAssignableFrom(targetClass);
/*      */       }
/*      */     }
/*      */ 
/*  534 */     Class beanType = predictBeanType(beanName, mbd, typesToMatch);
/*  535 */     if (beanType == null) {
/*  536 */       return false;
/*      */     }
/*      */ 
/*  540 */     if (FactoryBean.class.isAssignableFrom(beanType)) {
/*  541 */       if (!BeanFactoryUtils.isFactoryDereference(name))
/*      */       {
/*  543 */         beanType = getTypeForFactoryBean(beanName, mbd);
/*  544 */         if (beanType == null) {
/*  545 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*  549 */     else if (BeanFactoryUtils.isFactoryDereference(name))
/*      */     {
/*  553 */       beanType = predictBeanType(beanName, mbd, new Class[] { FactoryBean.class });
/*  554 */       if ((beanType == null) || (!FactoryBean.class.isAssignableFrom(beanType))) {
/*  555 */         return false;
/*      */       }
/*      */     }
/*      */ 
/*  559 */     return typeToMatch.isAssignableFrom(beanType);
/*      */   }
/*      */ 
/*      */   public Class<?> getType(String name)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/*  565 */     String beanName = transformedBeanName(name);
/*      */ 
/*  568 */     Object beanInstance = getSingleton(beanName, false);
/*  569 */     if (beanInstance != null) {
/*  570 */       if (((beanInstance instanceof FactoryBean)) && (!BeanFactoryUtils.isFactoryDereference(name))) {
/*  571 */         return getTypeForFactoryBean((FactoryBean)beanInstance);
/*      */       }
/*      */ 
/*  574 */       return beanInstance.getClass();
/*      */     }
/*      */ 
/*  577 */     if ((containsSingleton(beanName)) && (!containsBeanDefinition(beanName)))
/*      */     {
/*  579 */       return null;
/*      */     }
/*      */ 
/*  584 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  585 */     if ((parentBeanFactory != null) && (!containsBeanDefinition(beanName)))
/*      */     {
/*  587 */       return parentBeanFactory.getType(originalBeanName(name));
/*      */     }
/*      */ 
/*  590 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*      */ 
/*  594 */     BeanDefinitionHolder dbd = mbd.getDecoratedDefinition();
/*  595 */     if ((dbd != null) && (!BeanFactoryUtils.isFactoryDereference(name))) {
/*  596 */       RootBeanDefinition tbd = getMergedBeanDefinition(dbd.getBeanName(), dbd.getBeanDefinition(), mbd);
/*  597 */       Class targetClass = predictBeanType(dbd.getBeanName(), tbd, new Class[0]);
/*  598 */       if ((targetClass != null) && (!FactoryBean.class.isAssignableFrom(targetClass))) {
/*  599 */         return targetClass;
/*      */       }
/*      */     }
/*      */ 
/*  603 */     Class beanClass = predictBeanType(beanName, mbd, new Class[0]);
/*      */ 
/*  606 */     if ((beanClass != null) && (FactoryBean.class.isAssignableFrom(beanClass))) {
/*  607 */       if (!BeanFactoryUtils.isFactoryDereference(name))
/*      */       {
/*  609 */         return getTypeForFactoryBean(beanName, mbd);
/*      */       }
/*      */ 
/*  612 */       return beanClass;
/*      */     }
/*      */ 
/*  616 */     return !BeanFactoryUtils.isFactoryDereference(name) ? beanClass : null;
/*      */   }
/*      */ 
/*      */   public String[] getAliases(String name)
/*      */   {
/*  623 */     String beanName = transformedBeanName(name);
/*  624 */     List aliases = new ArrayList();
/*  625 */     boolean factoryPrefix = name.startsWith("&");
/*  626 */     String fullBeanName = beanName;
/*  627 */     if (factoryPrefix) {
/*  628 */       fullBeanName = new StringBuilder().append("&").append(beanName).toString();
/*      */     }
/*  630 */     if (!fullBeanName.equals(name)) {
/*  631 */       aliases.add(fullBeanName);
/*      */     }
/*  633 */     String[] retrievedAliases = super.getAliases(beanName);
/*  634 */     for (String retrievedAlias : retrievedAliases) {
/*  635 */       String alias = new StringBuilder().append(factoryPrefix ? "&" : "").append(retrievedAlias).toString();
/*  636 */       if (!alias.equals(name)) {
/*  637 */         aliases.add(alias);
/*      */       }
/*      */     }
/*  640 */     if ((!containsSingleton(beanName)) && (!containsBeanDefinition(beanName))) {
/*  641 */       BeanFactory parentBeanFactory = getParentBeanFactory();
/*  642 */       if (parentBeanFactory != null) {
/*  643 */         aliases.addAll(Arrays.asList(parentBeanFactory.getAliases(fullBeanName)));
/*      */       }
/*      */     }
/*  646 */     return StringUtils.toStringArray(aliases);
/*      */   }
/*      */ 
/*      */   public BeanFactory getParentBeanFactory()
/*      */   {
/*  656 */     return this.parentBeanFactory;
/*      */   }
/*      */ 
/*      */   public boolean containsLocalBean(String name)
/*      */   {
/*  661 */     String beanName = transformedBeanName(name);
/*      */ 
/*  663 */     return ((containsSingleton(beanName)) || (containsBeanDefinition(beanName))) && (
/*  663 */       (!BeanFactoryUtils.isFactoryDereference(name)) || 
/*  663 */       (isFactoryBean(beanName)));
/*      */   }
/*      */ 
/*      */   public void setParentBeanFactory(BeanFactory parentBeanFactory)
/*      */   {
/*  673 */     if ((this.parentBeanFactory != null) && (this.parentBeanFactory != parentBeanFactory)) {
/*  674 */       throw new IllegalStateException(new StringBuilder().append("Already associated with parent BeanFactory: ").append(this.parentBeanFactory).toString());
/*      */     }
/*  676 */     this.parentBeanFactory = parentBeanFactory;
/*      */   }
/*      */ 
/*      */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*      */   {
/*  681 */     this.beanClassLoader = (beanClassLoader != null ? beanClassLoader : ClassUtils.getDefaultClassLoader());
/*      */   }
/*      */ 
/*      */   public ClassLoader getBeanClassLoader()
/*      */   {
/*  686 */     return this.beanClassLoader;
/*      */   }
/*      */ 
/*      */   public void setTempClassLoader(ClassLoader tempClassLoader)
/*      */   {
/*  691 */     this.tempClassLoader = tempClassLoader;
/*      */   }
/*      */ 
/*      */   public ClassLoader getTempClassLoader()
/*      */   {
/*  696 */     return this.tempClassLoader;
/*      */   }
/*      */ 
/*      */   public void setCacheBeanMetadata(boolean cacheBeanMetadata)
/*      */   {
/*  701 */     this.cacheBeanMetadata = cacheBeanMetadata;
/*      */   }
/*      */ 
/*      */   public boolean isCacheBeanMetadata()
/*      */   {
/*  706 */     return this.cacheBeanMetadata;
/*      */   }
/*      */ 
/*      */   public void setBeanExpressionResolver(BeanExpressionResolver resolver)
/*      */   {
/*  711 */     this.beanExpressionResolver = resolver;
/*      */   }
/*      */ 
/*      */   public BeanExpressionResolver getBeanExpressionResolver()
/*      */   {
/*  716 */     return this.beanExpressionResolver;
/*      */   }
/*      */ 
/*      */   public void setConversionService(ConversionService conversionService)
/*      */   {
/*  721 */     this.conversionService = conversionService;
/*      */   }
/*      */ 
/*      */   public ConversionService getConversionService()
/*      */   {
/*  726 */     return this.conversionService;
/*      */   }
/*      */ 
/*      */   public void addPropertyEditorRegistrar(PropertyEditorRegistrar registrar)
/*      */   {
/*  731 */     Assert.notNull(registrar, "PropertyEditorRegistrar must not be null");
/*  732 */     this.propertyEditorRegistrars.add(registrar);
/*      */   }
/*      */ 
/*      */   public Set<PropertyEditorRegistrar> getPropertyEditorRegistrars()
/*      */   {
/*  739 */     return this.propertyEditorRegistrars;
/*      */   }
/*      */ 
/*      */   public void registerCustomEditor(Class<?> requiredType, Class<? extends PropertyEditor> propertyEditorClass)
/*      */   {
/*  744 */     Assert.notNull(requiredType, "Required type must not be null");
/*  745 */     Assert.isAssignable(PropertyEditor.class, propertyEditorClass);
/*  746 */     this.customEditors.put(requiredType, propertyEditorClass);
/*      */   }
/*      */ 
/*      */   public void copyRegisteredEditorsTo(PropertyEditorRegistry registry)
/*      */   {
/*  751 */     registerCustomEditors(registry);
/*      */   }
/*      */ 
/*      */   public Map<Class<?>, Class<? extends PropertyEditor>> getCustomEditors()
/*      */   {
/*  758 */     return this.customEditors;
/*      */   }
/*      */ 
/*      */   public void setTypeConverter(TypeConverter typeConverter)
/*      */   {
/*  763 */     this.typeConverter = typeConverter;
/*      */   }
/*      */ 
/*      */   protected TypeConverter getCustomTypeConverter()
/*      */   {
/*  771 */     return this.typeConverter;
/*      */   }
/*      */ 
/*      */   public TypeConverter getTypeConverter()
/*      */   {
/*  776 */     TypeConverter customConverter = getCustomTypeConverter();
/*  777 */     if (customConverter != null) {
/*  778 */       return customConverter;
/*      */     }
/*      */ 
/*  782 */     SimpleTypeConverter typeConverter = new SimpleTypeConverter();
/*  783 */     typeConverter.setConversionService(getConversionService());
/*  784 */     registerCustomEditors(typeConverter);
/*  785 */     return typeConverter;
/*      */   }
/*      */ 
/*      */   public void addEmbeddedValueResolver(StringValueResolver valueResolver)
/*      */   {
/*  791 */     Assert.notNull(valueResolver, "StringValueResolver must not be null");
/*  792 */     this.embeddedValueResolvers.add(valueResolver);
/*      */   }
/*      */ 
/*      */   public String resolveEmbeddedValue(String value)
/*      */   {
/*  797 */     String result = value;
/*  798 */     for (StringValueResolver resolver : this.embeddedValueResolvers) {
/*  799 */       if (result == null) {
/*  800 */         return null;
/*      */       }
/*  802 */       result = resolver.resolveStringValue(result);
/*      */     }
/*  804 */     return result;
/*      */   }
/*      */ 
/*      */   public void addBeanPostProcessor(BeanPostProcessor beanPostProcessor)
/*      */   {
/*  809 */     Assert.notNull(beanPostProcessor, "BeanPostProcessor must not be null");
/*  810 */     this.beanPostProcessors.remove(beanPostProcessor);
/*  811 */     this.beanPostProcessors.add(beanPostProcessor);
/*  812 */     if ((beanPostProcessor instanceof InstantiationAwareBeanPostProcessor)) {
/*  813 */       this.hasInstantiationAwareBeanPostProcessors = true;
/*      */     }
/*  815 */     if ((beanPostProcessor instanceof DestructionAwareBeanPostProcessor))
/*  816 */       this.hasDestructionAwareBeanPostProcessors = true;
/*      */   }
/*      */ 
/*      */   public int getBeanPostProcessorCount()
/*      */   {
/*  822 */     return this.beanPostProcessors.size();
/*      */   }
/*      */ 
/*      */   public List<BeanPostProcessor> getBeanPostProcessors()
/*      */   {
/*  830 */     return this.beanPostProcessors;
/*      */   }
/*      */ 
/*      */   protected boolean hasInstantiationAwareBeanPostProcessors()
/*      */   {
/*  840 */     return this.hasInstantiationAwareBeanPostProcessors;
/*      */   }
/*      */ 
/*      */   protected boolean hasDestructionAwareBeanPostProcessors()
/*      */   {
/*  850 */     return this.hasDestructionAwareBeanPostProcessors;
/*      */   }
/*      */ 
/*      */   public void registerScope(String scopeName, Scope scope)
/*      */   {
/*  855 */     Assert.notNull(scopeName, "Scope identifier must not be null");
/*  856 */     Assert.notNull(scope, "Scope must not be null");
/*  857 */     if (("singleton".equals(scopeName)) || ("prototype".equals(scopeName))) {
/*  858 */       throw new IllegalArgumentException("Cannot replace existing scopes 'singleton' and 'prototype'");
/*      */     }
/*  860 */     this.scopes.put(scopeName, scope);
/*      */   }
/*      */ 
/*      */   public String[] getRegisteredScopeNames()
/*      */   {
/*  865 */     return StringUtils.toStringArray(this.scopes.keySet());
/*      */   }
/*      */ 
/*      */   public Scope getRegisteredScope(String scopeName)
/*      */   {
/*  870 */     Assert.notNull(scopeName, "Scope identifier must not be null");
/*  871 */     return (Scope)this.scopes.get(scopeName);
/*      */   }
/*      */ 
/*      */   public void setSecurityContextProvider(SecurityContextProvider securityProvider)
/*      */   {
/*  880 */     this.securityContextProvider = securityProvider;
/*      */   }
/*      */ 
/*      */   public AccessControlContext getAccessControlContext()
/*      */   {
/*  891 */     return this.securityContextProvider != null ? this.securityContextProvider
/*  890 */       .getAccessControlContext() : 
/*  891 */       AccessController.getContext();
/*      */   }
/*      */ 
/*      */   public void copyConfigurationFrom(ConfigurableBeanFactory otherFactory)
/*      */   {
/*  896 */     Assert.notNull(otherFactory, "BeanFactory must not be null");
/*  897 */     setBeanClassLoader(otherFactory.getBeanClassLoader());
/*  898 */     setCacheBeanMetadata(otherFactory.isCacheBeanMetadata());
/*  899 */     setBeanExpressionResolver(otherFactory.getBeanExpressionResolver());
/*  900 */     if ((otherFactory instanceof AbstractBeanFactory)) {
/*  901 */       AbstractBeanFactory otherAbstractFactory = (AbstractBeanFactory)otherFactory;
/*  902 */       this.customEditors.putAll(otherAbstractFactory.customEditors);
/*  903 */       this.propertyEditorRegistrars.addAll(otherAbstractFactory.propertyEditorRegistrars);
/*  904 */       this.beanPostProcessors.addAll(otherAbstractFactory.beanPostProcessors);
/*  905 */       this.hasInstantiationAwareBeanPostProcessors = ((this.hasInstantiationAwareBeanPostProcessors) || (otherAbstractFactory.hasInstantiationAwareBeanPostProcessors));
/*      */ 
/*  907 */       this.hasDestructionAwareBeanPostProcessors = ((this.hasDestructionAwareBeanPostProcessors) || (otherAbstractFactory.hasDestructionAwareBeanPostProcessors));
/*      */ 
/*  909 */       this.scopes.putAll(otherAbstractFactory.scopes);
/*  910 */       this.securityContextProvider = otherAbstractFactory.securityContextProvider;
/*      */     }
/*      */     else {
/*  913 */       setTypeConverter(otherFactory.getTypeConverter());
/*      */     }
/*      */   }
/*      */ 
/*      */   public BeanDefinition getMergedBeanDefinition(String name)
/*      */     throws BeansException
/*      */   {
/*  930 */     String beanName = transformedBeanName(name);
/*      */ 
/*  933 */     if ((!containsBeanDefinition(beanName)) && ((getParentBeanFactory() instanceof ConfigurableBeanFactory))) {
/*  934 */       return ((ConfigurableBeanFactory)getParentBeanFactory()).getMergedBeanDefinition(beanName);
/*      */     }
/*      */ 
/*  937 */     return getMergedLocalBeanDefinition(beanName);
/*      */   }
/*      */ 
/*      */   public boolean isFactoryBean(String name) throws NoSuchBeanDefinitionException
/*      */   {
/*  942 */     String beanName = transformedBeanName(name);
/*      */ 
/*  944 */     Object beanInstance = getSingleton(beanName, false);
/*  945 */     if (beanInstance != null) {
/*  946 */       return beanInstance instanceof FactoryBean;
/*      */     }
/*  948 */     if (containsSingleton(beanName))
/*      */     {
/*  950 */       return false;
/*      */     }
/*      */ 
/*  954 */     if ((!containsBeanDefinition(beanName)) && ((getParentBeanFactory() instanceof ConfigurableBeanFactory)))
/*      */     {
/*  956 */       return ((ConfigurableBeanFactory)getParentBeanFactory()).isFactoryBean(name);
/*      */     }
/*      */ 
/*  959 */     return isFactoryBean(beanName, getMergedLocalBeanDefinition(beanName));
/*      */   }
/*      */ 
/*      */   public boolean isActuallyInCreation(String beanName)
/*      */   {
/*  964 */     return (isSingletonCurrentlyInCreation(beanName)) || (isPrototypeCurrentlyInCreation(beanName));
/*      */   }
/*      */ 
/*      */   protected boolean isPrototypeCurrentlyInCreation(String beanName)
/*      */   {
/*  973 */     Object curVal = this.prototypesCurrentlyInCreation.get();
/*      */ 
/*  975 */     return (curVal != null) && (
/*  975 */       (curVal
/*  975 */       .equals(beanName)) || 
/*  975 */       (((curVal instanceof Set)) && (((Set)curVal).contains(beanName))));
/*      */   }
/*      */ 
/*      */   protected void beforePrototypeCreation(String beanName)
/*      */   {
/*  986 */     Object curVal = this.prototypesCurrentlyInCreation.get();
/*  987 */     if (curVal == null) {
/*  988 */       this.prototypesCurrentlyInCreation.set(beanName);
/*      */     }
/*  990 */     else if ((curVal instanceof String)) {
/*  991 */       Set beanNameSet = new HashSet(2);
/*  992 */       beanNameSet.add((String)curVal);
/*  993 */       beanNameSet.add(beanName);
/*  994 */       this.prototypesCurrentlyInCreation.set(beanNameSet);
/*      */     }
/*      */     else {
/*  997 */       Set beanNameSet = (Set)curVal;
/*  998 */       beanNameSet.add(beanName);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void afterPrototypeCreation(String beanName)
/*      */   {
/* 1010 */     Object curVal = this.prototypesCurrentlyInCreation.get();
/* 1011 */     if ((curVal instanceof String)) {
/* 1012 */       this.prototypesCurrentlyInCreation.remove();
/*      */     }
/* 1014 */     else if ((curVal instanceof Set)) {
/* 1015 */       Set beanNameSet = (Set)curVal;
/* 1016 */       beanNameSet.remove(beanName);
/* 1017 */       if (beanNameSet.isEmpty())
/* 1018 */         this.prototypesCurrentlyInCreation.remove();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void destroyBean(String beanName, Object beanInstance)
/*      */   {
/* 1025 */     destroyBean(beanName, beanInstance, getMergedLocalBeanDefinition(beanName));
/*      */   }
/*      */ 
/*      */   protected void destroyBean(String beanName, Object beanInstance, RootBeanDefinition mbd)
/*      */   {
/* 1036 */     new DisposableBeanAdapter(beanInstance, beanName, mbd, getBeanPostProcessors(), getAccessControlContext()).destroy();
/*      */   }
/*      */ 
/*      */   public void destroyScopedBean(String beanName)
/*      */   {
/* 1041 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/* 1042 */     if ((mbd.isSingleton()) || (mbd.isPrototype())) {
/* 1043 */       throw new IllegalArgumentException(new StringBuilder().append("Bean name '").append(beanName).append("' does not correspond to an object in a mutable scope").toString());
/*      */     }
/*      */ 
/* 1046 */     String scopeName = mbd.getScope();
/* 1047 */     Scope scope = (Scope)this.scopes.get(scopeName);
/* 1048 */     if (scope == null) {
/* 1049 */       throw new IllegalStateException(new StringBuilder().append("No Scope SPI registered for scope '").append(scopeName).append("'").toString());
/*      */     }
/* 1051 */     Object bean = scope.remove(beanName);
/* 1052 */     if (bean != null)
/* 1053 */       destroyBean(beanName, bean, mbd);
/*      */   }
/*      */ 
/*      */   protected String transformedBeanName(String name)
/*      */   {
/* 1069 */     return canonicalName(BeanFactoryUtils.transformedBeanName(name));
/*      */   }
/*      */ 
/*      */   protected String originalBeanName(String name)
/*      */   {
/* 1078 */     String beanName = transformedBeanName(name);
/* 1079 */     if (name.startsWith("&")) {
/* 1080 */       beanName = new StringBuilder().append("&").append(beanName).toString();
/*      */     }
/* 1082 */     return beanName;
/*      */   }
/*      */ 
/*      */   protected void initBeanWrapper(BeanWrapper bw)
/*      */   {
/* 1094 */     bw.setConversionService(getConversionService());
/* 1095 */     registerCustomEditors(bw);
/*      */   }
/*      */ 
/*      */   protected void registerCustomEditors(PropertyEditorRegistry registry)
/*      */   {
/* 1107 */     PropertyEditorRegistrySupport registrySupport = (registry instanceof PropertyEditorRegistrySupport) ? (PropertyEditorRegistrySupport)registry : null;
/*      */ 
/* 1109 */     if (registrySupport != null) {
/* 1110 */       registrySupport.useConfigValueEditors();
/*      */     }
/* 1112 */     if (!this.propertyEditorRegistrars.isEmpty()) {
/* 1113 */       for (PropertyEditorRegistrar registrar : this.propertyEditorRegistrars)
/*      */         try {
/* 1115 */           registrar.registerCustomEditors(registry);
/*      */         }
/*      */         catch (BeanCreationException ex) {
/* 1118 */           Throwable rootCause = ex.getMostSpecificCause();
/* 1119 */           if ((rootCause instanceof BeanCurrentlyInCreationException)) {
/* 1120 */             BeanCreationException bce = (BeanCreationException)rootCause;
/* 1121 */             if (isCurrentlyInCreation(bce.getBeanName())) {
/* 1122 */               if (this.logger.isDebugEnabled()) {
/* 1123 */                 this.logger.debug(new StringBuilder().append("PropertyEditorRegistrar [").append(registrar.getClass().getName()).append("] failed because it tried to obtain currently created bean '")
/* 1125 */                   .append(ex
/* 1125 */                   .getBeanName()).append("': ").append(ex.getMessage()).toString());
/*      */               }
/* 1127 */               onSuppressedException(ex);
/*      */             }
/*      */           }
/*      */           else {
/* 1131 */             throw ex;
/*      */           }
/*      */         }
/*      */     }
/* 1135 */     if (!this.customEditors.isEmpty())
/* 1136 */       for (Map.Entry entry : this.customEditors.entrySet()) {
/* 1137 */         Class requiredType = (Class)entry.getKey();
/* 1138 */         Class editorClass = (Class)entry.getValue();
/* 1139 */         registry.registerCustomEditor(requiredType, (PropertyEditor)BeanUtils.instantiateClass(editorClass));
/*      */       }
/*      */   }
/*      */ 
/*      */   protected RootBeanDefinition getMergedLocalBeanDefinition(String beanName)
/*      */     throws BeansException
/*      */   {
/* 1155 */     RootBeanDefinition mbd = (RootBeanDefinition)this.mergedBeanDefinitions.get(beanName);
/* 1156 */     if (mbd != null) {
/* 1157 */       return mbd;
/*      */     }
/* 1159 */     return getMergedBeanDefinition(beanName, getBeanDefinition(beanName));
/*      */   }
/*      */ 
/*      */   protected RootBeanDefinition getMergedBeanDefinition(String beanName, BeanDefinition bd)
/*      */     throws BeanDefinitionStoreException
/*      */   {
/* 1173 */     return getMergedBeanDefinition(beanName, bd, null);
/*      */   }
/*      */ 
/*      */   protected RootBeanDefinition getMergedBeanDefinition(String beanName, BeanDefinition bd, BeanDefinition containingBd)
/*      */     throws BeanDefinitionStoreException
/*      */   {
/* 1190 */     synchronized (this.mergedBeanDefinitions) {
/* 1191 */       RootBeanDefinition mbd = null;
/*      */ 
/* 1194 */       if (containingBd == null) {
/* 1195 */         mbd = (RootBeanDefinition)this.mergedBeanDefinitions.get(beanName);
/*      */       }
/*      */ 
/* 1198 */       if (mbd == null) {
/* 1199 */         if (bd.getParentName() == null)
/*      */         {
/* 1201 */           if ((bd instanceof RootBeanDefinition)) {
/* 1202 */             mbd = ((RootBeanDefinition)bd).cloneBeanDefinition();
/*      */           }
/*      */           else {
/* 1205 */             mbd = new RootBeanDefinition(bd);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*      */           try
/*      */           {
/* 1212 */             String parentBeanName = transformedBeanName(bd.getParentName());
/*      */             BeanDefinition pbd;
/* 1213 */             if (!beanName.equals(parentBeanName)) {
/* 1214 */               pbd = getMergedBeanDefinition(parentBeanName);
/*      */             }
/*      */             else
/*      */             {
/*      */               BeanDefinition pbd;
/* 1217 */               if ((getParentBeanFactory() instanceof ConfigurableBeanFactory)) {
/* 1218 */                 pbd = ((ConfigurableBeanFactory)getParentBeanFactory()).getMergedBeanDefinition(parentBeanName);
/*      */               }
/*      */               else
/*      */               {
/* 1222 */                 throw new NoSuchBeanDefinitionException(bd.getParentName(), new StringBuilder().append("Parent name '")
/* 1222 */                   .append(bd
/* 1222 */                   .getParentName()).append("' is equal to bean name '").append(beanName).append("': cannot be resolved without an AbstractBeanFactory parent").toString());
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (NoSuchBeanDefinitionException ex)
/*      */           {
/*      */             BeanDefinition pbd;
/* 1229 */             throw new BeanDefinitionStoreException(bd.getResourceDescription(), beanName, new StringBuilder().append("Could not resolve parent bean definition '")
/* 1229 */               .append(bd
/* 1229 */               .getParentName()).append("'").toString(), ex);
/*      */           }
/*      */           BeanDefinition pbd;
/* 1232 */           mbd = new RootBeanDefinition(pbd);
/* 1233 */           mbd.overrideFrom(bd);
/*      */         }
/*      */ 
/* 1237 */         if (!StringUtils.hasLength(mbd.getScope())) {
/* 1238 */           mbd.setScope("singleton");
/*      */         }
/*      */ 
/* 1245 */         if ((containingBd != null) && (!containingBd.isSingleton()) && (mbd.isSingleton())) {
/* 1246 */           mbd.setScope(containingBd.getScope());
/*      */         }
/*      */ 
/* 1251 */         if ((containingBd == null) && (isCacheBeanMetadata()) && (isBeanEligibleForMetadataCaching(beanName))) {
/* 1252 */           this.mergedBeanDefinitions.put(beanName, mbd);
/*      */         }
/*      */       }
/*      */ 
/* 1256 */       return mbd;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void checkMergedBeanDefinition(RootBeanDefinition mbd, String beanName, Object[] args)
/*      */     throws BeanDefinitionStoreException
/*      */   {
/* 1272 */     if (mbd.isAbstract()) {
/* 1273 */       throw new BeanIsAbstractException(beanName);
/*      */     }
/*      */ 
/* 1278 */     if ((args != null) && (!mbd.isPrototype()))
/* 1279 */       throw new BeanDefinitionStoreException("Can only specify arguments for the getBean method when referring to a prototype bean definition");
/*      */   }
/*      */ 
/*      */   protected void clearMergedBeanDefinition(String beanName)
/*      */   {
/* 1290 */     this.mergedBeanDefinitions.remove(beanName);
/*      */   }
/*      */ 
/*      */   protected Class<?> resolveBeanClass(final RootBeanDefinition mbd, String beanName, final Class<?>[] typesToMatch)
/*      */     throws CannotLoadBeanClassException
/*      */   {
/*      */     try
/*      */     {
/* 1307 */       if (mbd.hasBeanClass()) {
/* 1308 */         return mbd.getBeanClass();
/*      */       }
/* 1310 */       if (System.getSecurityManager() != null) {
/* 1311 */         return (Class)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */         {
/*      */           public Class<?> run() throws Exception {
/* 1314 */             return AbstractBeanFactory.this.doResolveBeanClass(mbd, typesToMatch);
/*      */           }
/*      */         }
/*      */         , getAccessControlContext());
/*      */       }
/*      */ 
/* 1319 */       return doResolveBeanClass(mbd, typesToMatch);
/*      */     }
/*      */     catch (PrivilegedActionException pae)
/*      */     {
/* 1323 */       ClassNotFoundException ex = (ClassNotFoundException)pae.getException();
/* 1324 */       throw new CannotLoadBeanClassException(mbd.getResourceDescription(), beanName, mbd.getBeanClassName(), ex);
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/* 1327 */       throw new CannotLoadBeanClassException(mbd.getResourceDescription(), beanName, mbd.getBeanClassName(), ex);
/*      */     }
/*      */     catch (LinkageError err) {
/* 1330 */       throw new CannotLoadBeanClassException(mbd.getResourceDescription(), beanName, mbd.getBeanClassName(), err);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Class<?> doResolveBeanClass(RootBeanDefinition mbd, Class<?>[] typesToMatch) throws ClassNotFoundException {
/* 1335 */     if (!ObjectUtils.isEmpty(typesToMatch)) {
/* 1336 */       ClassLoader tempClassLoader = getTempClassLoader();
/* 1337 */       if (tempClassLoader != null) {
/* 1338 */         if ((tempClassLoader instanceof DecoratingClassLoader)) {
/* 1339 */           DecoratingClassLoader dcl = (DecoratingClassLoader)tempClassLoader;
/* 1340 */           for (Class typeToMatch : typesToMatch) {
/* 1341 */             dcl.excludeClass(typeToMatch.getName());
/*      */           }
/*      */         }
/* 1344 */         String className = mbd.getBeanClassName();
/* 1345 */         return className != null ? ClassUtils.forName(className, tempClassLoader) : null;
/*      */       }
/*      */     }
/* 1348 */     return mbd.resolveBeanClass(getBeanClassLoader());
/*      */   }
/*      */ 
/*      */   protected Object evaluateBeanDefinitionString(String value, BeanDefinition beanDefinition)
/*      */   {
/* 1360 */     if (this.beanExpressionResolver == null) {
/* 1361 */       return value;
/*      */     }
/* 1363 */     Scope scope = beanDefinition != null ? getRegisteredScope(beanDefinition.getScope()) : null;
/* 1364 */     return this.beanExpressionResolver.evaluate(value, new BeanExpressionContext(this, scope));
/*      */   }
/*      */ 
/*      */   protected Class<?> predictBeanType(String beanName, RootBeanDefinition mbd, Class<?>[] typesToMatch)
/*      */   {
/* 1384 */     if (mbd.getFactoryMethodName() != null) {
/* 1385 */       return null;
/*      */     }
/* 1387 */     return resolveBeanClass(mbd, beanName, typesToMatch);
/*      */   }
/*      */ 
/*      */   protected boolean isFactoryBean(String beanName, RootBeanDefinition mbd)
/*      */   {
/* 1396 */     Class beanType = predictBeanType(beanName, mbd, new Class[] { FactoryBean.class });
/* 1397 */     return (beanType != null) && (FactoryBean.class.isAssignableFrom(beanType));
/*      */   }
/*      */ 
/*      */   protected Class<?> getTypeForFactoryBean(String beanName, RootBeanDefinition mbd)
/*      */   {
/* 1416 */     if (!mbd.isSingleton())
/* 1417 */       return null;
/*      */     try
/*      */     {
/* 1420 */       FactoryBean factoryBean = (FactoryBean)doGetBean(new StringBuilder().append("&").append(beanName).toString(), FactoryBean.class, null, true);
/* 1421 */       return getTypeForFactoryBean(factoryBean);
/*      */     }
/*      */     catch (BeanCreationException ex)
/*      */     {
/* 1425 */       if (this.logger.isDebugEnabled()) {
/* 1426 */         this.logger.debug(new StringBuilder().append("Ignoring bean creation exception on FactoryBean type check: ").append(ex).toString());
/*      */       }
/* 1428 */       onSuppressedException(ex);
/* 1429 */     }return null;
/*      */   }
/*      */ 
/*      */   protected void markBeanAsCreated(String beanName)
/*      */   {
/* 1440 */     this.alreadyCreated.add(beanName);
/*      */   }
/*      */ 
/*      */   protected void cleanupAfterBeanCreationFailure(String beanName)
/*      */   {
/* 1448 */     this.alreadyCreated.remove(beanName);
/*      */   }
/*      */ 
/*      */   protected boolean isBeanEligibleForMetadataCaching(String beanName)
/*      */   {
/* 1459 */     return this.alreadyCreated.contains(beanName);
/*      */   }
/*      */ 
/*      */   protected boolean removeSingletonIfCreatedForTypeCheckOnly(String beanName)
/*      */   {
/* 1469 */     if (!this.alreadyCreated.contains(beanName)) {
/* 1470 */       removeSingleton(beanName);
/* 1471 */       return true;
/*      */     }
/*      */ 
/* 1474 */     return false;
/*      */   }
/*      */ 
/*      */   protected Object getObjectForBeanInstance(Object beanInstance, String name, String beanName, RootBeanDefinition mbd)
/*      */   {
/* 1491 */     if ((BeanFactoryUtils.isFactoryDereference(name)) && (!(beanInstance instanceof FactoryBean))) {
/* 1492 */       throw new BeanIsNotAFactoryException(transformedBeanName(name), beanInstance.getClass());
/*      */     }
/*      */ 
/* 1498 */     if ((!(beanInstance instanceof FactoryBean)) || (BeanFactoryUtils.isFactoryDereference(name))) {
/* 1499 */       return beanInstance;
/*      */     }
/*      */ 
/* 1502 */     Object object = null;
/* 1503 */     if (mbd == null) {
/* 1504 */       object = getCachedObjectForFactoryBean(beanName);
/*      */     }
/* 1506 */     if (object == null)
/*      */     {
/* 1508 */       FactoryBean factory = (FactoryBean)beanInstance;
/*      */ 
/* 1510 */       if ((mbd == null) && (containsBeanDefinition(beanName))) {
/* 1511 */         mbd = getMergedLocalBeanDefinition(beanName);
/*      */       }
/* 1513 */       boolean synthetic = (mbd != null) && (mbd.isSynthetic());
/* 1514 */       object = getObjectFromFactoryBean(factory, beanName, !synthetic);
/*      */     }
/* 1516 */     return object;
/*      */   }
/*      */ 
/*      */   public boolean isBeanNameInUse(String beanName)
/*      */   {
/* 1526 */     return (isAlias(beanName)) || (containsLocalBean(beanName)) || (hasDependentBean(beanName));
/*      */   }
/*      */ 
/*      */   protected boolean requiresDestruction(Object bean, RootBeanDefinition mbd)
/*      */   {
/* 1541 */     return (bean != null) && (
/* 1541 */       (DisposableBeanAdapter.hasDestroyMethod(bean, mbd)) || 
/* 1541 */       (hasDestructionAwareBeanPostProcessors()));
/*      */   }
/*      */ 
/*      */   protected void registerDisposableBeanIfNecessary(String beanName, Object bean, RootBeanDefinition mbd)
/*      */   {
/* 1557 */     AccessControlContext acc = System.getSecurityManager() != null ? getAccessControlContext() : null;
/* 1558 */     if ((!mbd.isPrototype()) && (requiresDestruction(bean, mbd)))
/* 1559 */       if (mbd.isSingleton())
/*      */       {
/* 1563 */         registerDisposableBean(beanName, new DisposableBeanAdapter(bean, beanName, mbd, 
/* 1564 */           getBeanPostProcessors(), acc));
/*      */       }
/*      */       else
/*      */       {
/* 1568 */         Scope scope = (Scope)this.scopes.get(mbd.getScope());
/* 1569 */         if (scope == null) {
/* 1570 */           throw new IllegalStateException(new StringBuilder().append("No Scope registered for scope '").append(mbd.getScope()).append("'").toString());
/*      */         }
/* 1572 */         scope.registerDestructionCallback(beanName, new DisposableBeanAdapter(bean, beanName, mbd, 
/* 1573 */           getBeanPostProcessors(), acc));
/*      */       }
/*      */   }
/*      */ 
/*      */   protected abstract boolean containsBeanDefinition(String paramString);
/*      */ 
/*      */   protected abstract BeanDefinition getBeanDefinition(String paramString)
/*      */     throws BeansException;
/*      */ 
/*      */   protected abstract Object createBean(String paramString, RootBeanDefinition paramRootBeanDefinition, Object[] paramArrayOfObject)
/*      */     throws BeanCreationException;
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.AbstractBeanFactory
 * JD-Core Version:    0.6.2
 */