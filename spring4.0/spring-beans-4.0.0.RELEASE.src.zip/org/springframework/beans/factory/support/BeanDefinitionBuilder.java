/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class BeanDefinitionBuilder
/*     */ {
/*     */   private AbstractBeanDefinition beanDefinition;
/*     */   private int constructorArgIndex;
/*     */ 
/*     */   public static BeanDefinitionBuilder genericBeanDefinition()
/*     */   {
/*  39 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder();
/*  40 */     builder.beanDefinition = new GenericBeanDefinition();
/*  41 */     return builder;
/*     */   }
/*     */ 
/*     */   public static BeanDefinitionBuilder genericBeanDefinition(Class<?> beanClass)
/*     */   {
/*  49 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder();
/*  50 */     builder.beanDefinition = new GenericBeanDefinition();
/*  51 */     builder.beanDefinition.setBeanClass(beanClass);
/*  52 */     return builder;
/*     */   }
/*     */ 
/*     */   public static BeanDefinitionBuilder genericBeanDefinition(String beanClassName)
/*     */   {
/*  60 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder();
/*  61 */     builder.beanDefinition = new GenericBeanDefinition();
/*  62 */     builder.beanDefinition.setBeanClassName(beanClassName);
/*  63 */     return builder;
/*     */   }
/*     */ 
/*     */   public static BeanDefinitionBuilder rootBeanDefinition(Class<?> beanClass)
/*     */   {
/*  71 */     return rootBeanDefinition(beanClass, null);
/*     */   }
/*     */ 
/*     */   public static BeanDefinitionBuilder rootBeanDefinition(Class<?> beanClass, String factoryMethodName)
/*     */   {
/*  80 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder();
/*  81 */     builder.beanDefinition = new RootBeanDefinition();
/*  82 */     builder.beanDefinition.setBeanClass(beanClass);
/*  83 */     builder.beanDefinition.setFactoryMethodName(factoryMethodName);
/*  84 */     return builder;
/*     */   }
/*     */ 
/*     */   public static BeanDefinitionBuilder rootBeanDefinition(String beanClassName)
/*     */   {
/*  92 */     return rootBeanDefinition(beanClassName, null);
/*     */   }
/*     */ 
/*     */   public static BeanDefinitionBuilder rootBeanDefinition(String beanClassName, String factoryMethodName)
/*     */   {
/* 101 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder();
/* 102 */     builder.beanDefinition = new RootBeanDefinition();
/* 103 */     builder.beanDefinition.setBeanClassName(beanClassName);
/* 104 */     builder.beanDefinition.setFactoryMethodName(factoryMethodName);
/* 105 */     return builder;
/*     */   }
/*     */ 
/*     */   public static BeanDefinitionBuilder childBeanDefinition(String parentName)
/*     */   {
/* 113 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder();
/* 114 */     builder.beanDefinition = new ChildBeanDefinition(parentName);
/* 115 */     return builder;
/*     */   }
/*     */ 
/*     */   public AbstractBeanDefinition getRawBeanDefinition()
/*     */   {
/* 141 */     return this.beanDefinition;
/*     */   }
/*     */ 
/*     */   public AbstractBeanDefinition getBeanDefinition()
/*     */   {
/* 148 */     this.beanDefinition.validate();
/* 149 */     return this.beanDefinition;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setParentName(String parentName)
/*     */   {
/* 157 */     this.beanDefinition.setParentName(parentName);
/* 158 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setFactoryMethod(String factoryMethod)
/*     */   {
/* 165 */     this.beanDefinition.setFactoryMethodName(factoryMethod);
/* 166 */     return this;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public BeanDefinitionBuilder addConstructorArg(Object value)
/*     */   {
/* 176 */     return addConstructorArgValue(value);
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder addConstructorArgValue(Object value)
/*     */   {
/* 184 */     this.beanDefinition.getConstructorArgumentValues().addIndexedArgumentValue(this.constructorArgIndex++, value);
/*     */ 
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder addConstructorArgReference(String beanName)
/*     */   {
/* 194 */     this.beanDefinition.getConstructorArgumentValues().addIndexedArgumentValue(this.constructorArgIndex++, new RuntimeBeanReference(beanName));
/*     */ 
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder addPropertyValue(String name, Object value)
/*     */   {
/* 203 */     this.beanDefinition.getPropertyValues().add(name, value);
/* 204 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder addPropertyReference(String name, String beanName)
/*     */   {
/* 213 */     this.beanDefinition.getPropertyValues().add(name, new RuntimeBeanReference(beanName));
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setInitMethodName(String methodName)
/*     */   {
/* 221 */     this.beanDefinition.setInitMethodName(methodName);
/* 222 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setDestroyMethodName(String methodName)
/*     */   {
/* 229 */     this.beanDefinition.setDestroyMethodName(methodName);
/* 230 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setScope(String scope)
/*     */   {
/* 240 */     this.beanDefinition.setScope(scope);
/* 241 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setAbstract(boolean flag)
/*     */   {
/* 248 */     this.beanDefinition.setAbstract(flag);
/* 249 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setLazyInit(boolean lazy)
/*     */   {
/* 256 */     this.beanDefinition.setLazyInit(lazy);
/* 257 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setAutowireMode(int autowireMode)
/*     */   {
/* 264 */     this.beanDefinition.setAutowireMode(autowireMode);
/* 265 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setDependencyCheck(int dependencyCheck)
/*     */   {
/* 272 */     this.beanDefinition.setDependencyCheck(dependencyCheck);
/* 273 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder addDependsOn(String beanName)
/*     */   {
/* 281 */     if (this.beanDefinition.getDependsOn() == null) {
/* 282 */       this.beanDefinition.setDependsOn(new String[] { beanName });
/*     */     }
/*     */     else {
/* 285 */       String[] added = (String[])ObjectUtils.addObjectToArray(this.beanDefinition.getDependsOn(), beanName);
/* 286 */       this.beanDefinition.setDependsOn(added);
/*     */     }
/* 288 */     return this;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionBuilder setRole(int role)
/*     */   {
/* 295 */     this.beanDefinition.setRole(role);
/* 296 */     return this;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.BeanDefinitionBuilder
 * JD-Core Version:    0.6.2
 */