package org.springframework.beans.factory.support;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;

public abstract interface BeanDefinitionRegistryPostProcessor extends BeanFactoryPostProcessor
{
  public abstract void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry paramBeanDefinitionRegistry)
    throws BeansException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor
 * JD-Core Version:    0.6.2
 */