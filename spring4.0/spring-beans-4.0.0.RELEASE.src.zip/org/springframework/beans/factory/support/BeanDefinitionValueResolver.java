/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanNameReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class BeanDefinitionValueResolver
/*     */ {
/*     */   private final AbstractBeanFactory beanFactory;
/*     */   private final String beanName;
/*     */   private final BeanDefinition beanDefinition;
/*     */   private final TypeConverter typeConverter;
/*     */ 
/*     */   public BeanDefinitionValueResolver(AbstractBeanFactory beanFactory, String beanName, BeanDefinition beanDefinition, TypeConverter typeConverter)
/*     */   {
/*  78 */     this.beanFactory = beanFactory;
/*  79 */     this.beanName = beanName;
/*  80 */     this.beanDefinition = beanDefinition;
/*  81 */     this.typeConverter = typeConverter;
/*     */   }
/*     */ 
/*     */   public Object resolveValueIfNecessary(Object argName, Object value)
/*     */   {
/* 105 */     if ((value instanceof RuntimeBeanReference)) {
/* 106 */       RuntimeBeanReference ref = (RuntimeBeanReference)value;
/* 107 */       return resolveReference(argName, ref);
/*     */     }
/* 109 */     if ((value instanceof RuntimeBeanNameReference)) {
/* 110 */       String refName = ((RuntimeBeanNameReference)value).getBeanName();
/* 111 */       refName = String.valueOf(evaluate(refName));
/* 112 */       if (!this.beanFactory.containsBean(refName)) {
/* 113 */         throw new BeanDefinitionStoreException(new StringBuilder().append("Invalid bean name '").append(refName).append("' in bean reference for ").append(argName).toString());
/*     */       }
/*     */ 
/* 116 */       return refName;
/*     */     }
/* 118 */     if ((value instanceof BeanDefinitionHolder))
/*     */     {
/* 120 */       BeanDefinitionHolder bdHolder = (BeanDefinitionHolder)value;
/* 121 */       return resolveInnerBean(argName, bdHolder.getBeanName(), bdHolder.getBeanDefinition());
/*     */     }
/* 123 */     if ((value instanceof BeanDefinition))
/*     */     {
/* 125 */       BeanDefinition bd = (BeanDefinition)value;
/* 126 */       return resolveInnerBean(argName, "(inner bean)", bd);
/*     */     }
/*     */     String elementTypeName;
/* 128 */     if ((value instanceof ManagedArray))
/*     */     {
/* 130 */       ManagedArray array = (ManagedArray)value;
/* 131 */       Class elementType = array.resolvedElementType;
/* 132 */       if (elementType == null) {
/* 133 */         elementTypeName = array.getElementTypeName();
/* 134 */         if (StringUtils.hasText(elementTypeName)) {
/*     */           try {
/* 136 */             elementType = ClassUtils.forName(elementTypeName, this.beanFactory.getBeanClassLoader());
/* 137 */             array.resolvedElementType = elementType;
/*     */           }
/*     */           catch (Throwable ex)
/*     */           {
/* 142 */             throw new BeanCreationException(this.beanDefinition
/* 142 */               .getResourceDescription(), this.beanName, new StringBuilder().append("Error resolving array type for ").append(argName).toString(), ex);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 147 */           elementType = Object.class;
/*     */         }
/*     */       }
/* 150 */       return resolveManagedArray(argName, (List)value, elementType);
/*     */     }
/* 152 */     if ((value instanceof ManagedList))
/*     */     {
/* 154 */       return resolveManagedList(argName, (List)value);
/*     */     }
/* 156 */     if ((value instanceof ManagedSet))
/*     */     {
/* 158 */       return resolveManagedSet(argName, (Set)value);
/*     */     }
/* 160 */     if ((value instanceof ManagedMap))
/*     */     {
/* 162 */       return resolveManagedMap(argName, (Map)value);
/*     */     }
/* 164 */     if ((value instanceof ManagedProperties)) {
/* 165 */       Properties original = (Properties)value;
/* 166 */       Properties copy = new Properties();
/* 167 */       for (Map.Entry propEntry : original.entrySet()) {
/* 168 */         Object propKey = propEntry.getKey();
/* 169 */         Object propValue = propEntry.getValue();
/* 170 */         if ((propKey instanceof TypedStringValue)) {
/* 171 */           propKey = evaluate((TypedStringValue)propKey);
/*     */         }
/* 173 */         if ((propValue instanceof TypedStringValue)) {
/* 174 */           propValue = evaluate((TypedStringValue)propValue);
/*     */         }
/* 176 */         copy.put(propKey, propValue);
/*     */       }
/* 178 */       return copy;
/*     */     }
/* 180 */     if ((value instanceof TypedStringValue))
/*     */     {
/* 182 */       TypedStringValue typedStringValue = (TypedStringValue)value;
/* 183 */       Object valueObject = evaluate(typedStringValue);
/*     */       try {
/* 185 */         Class resolvedTargetType = resolveTargetType(typedStringValue);
/* 186 */         if (resolvedTargetType != null) {
/* 187 */           return this.typeConverter.convertIfNecessary(valueObject, resolvedTargetType);
/*     */         }
/*     */ 
/* 190 */         return valueObject;
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 196 */         throw new BeanCreationException(this.beanDefinition
/* 196 */           .getResourceDescription(), this.beanName, new StringBuilder().append("Error converting typed String value for ").append(argName).toString(), ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 201 */     return evaluate(value);
/*     */   }
/*     */ 
/*     */   protected Object evaluate(TypedStringValue value)
/*     */   {
/* 211 */     Object result = this.beanFactory.evaluateBeanDefinitionString(value.getValue(), this.beanDefinition);
/* 212 */     if (!ObjectUtils.nullSafeEquals(result, value.getValue())) {
/* 213 */       value.setDynamic();
/*     */     }
/* 215 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object evaluate(Object value)
/*     */   {
/* 224 */     if ((value instanceof String)) {
/* 225 */       return this.beanFactory.evaluateBeanDefinitionString((String)value, this.beanDefinition);
/*     */     }
/*     */ 
/* 228 */     return value;
/*     */   }
/*     */ 
/*     */   protected Class<?> resolveTargetType(TypedStringValue value)
/*     */     throws ClassNotFoundException
/*     */   {
/* 240 */     if (value.hasTargetType()) {
/* 241 */       return value.getTargetType();
/*     */     }
/* 243 */     return value.resolveTargetType(this.beanFactory.getBeanClassLoader());
/*     */   }
/*     */ 
/*     */   private Object resolveInnerBean(Object argName, String innerBeanName, BeanDefinition innerBd)
/*     */   {
/* 254 */     RootBeanDefinition mbd = null;
/*     */     try {
/* 256 */       mbd = this.beanFactory.getMergedBeanDefinition(innerBeanName, innerBd, this.beanDefinition);
/*     */ 
/* 259 */       String actualInnerBeanName = adaptInnerBeanName(innerBeanName);
/* 260 */       this.beanFactory.registerContainedBean(actualInnerBeanName, this.beanName);
/*     */ 
/* 262 */       String[] dependsOn = mbd.getDependsOn();
/* 263 */       if (dependsOn != null) {
/* 264 */         for (String dependsOnBean : dependsOn) {
/* 265 */           this.beanFactory.getBean(dependsOnBean);
/* 266 */           this.beanFactory.registerDependentBean(dependsOnBean, actualInnerBeanName);
/*     */         }
/*     */       }
/* 269 */       Object innerBean = this.beanFactory.createBean(actualInnerBeanName, mbd, null);
/* 270 */       if ((innerBean instanceof FactoryBean)) {
/* 271 */         boolean synthetic = mbd.isSynthetic();
/* 272 */         return this.beanFactory.getObjectFromFactoryBean((FactoryBean)innerBean, actualInnerBeanName, !synthetic);
/*     */       }
/*     */ 
/* 275 */       return innerBean;
/*     */     }
/*     */     catch (BeansException ex)
/*     */     {
/* 280 */       if (mbd != null);
/* 282 */       throw new BeanCreationException(this.beanDefinition
/* 280 */         .getResourceDescription(), this.beanName, new StringBuilder().append("Cannot create inner bean '").append(innerBeanName).append("' ")
/* 282 */         .append(mbd
/* 282 */         .getBeanClassName() != null ? new StringBuilder().append("of type [").append(mbd.getBeanClassName()).append("] ").toString() : "").append("while setting ").append(argName).toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String adaptInnerBeanName(String innerBeanName)
/*     */   {
/* 294 */     String actualInnerBeanName = innerBeanName;
/* 295 */     int counter = 0;
/* 296 */     while (this.beanFactory.isBeanNameInUse(actualInnerBeanName)) {
/* 297 */       counter++;
/* 298 */       actualInnerBeanName = new StringBuilder().append(innerBeanName).append("#").append(counter).toString();
/*     */     }
/* 300 */     return actualInnerBeanName;
/*     */   }
/*     */ 
/*     */   private Object resolveReference(Object argName, RuntimeBeanReference ref)
/*     */   {
/*     */     try
/*     */     {
/* 308 */       String refName = ref.getBeanName();
/* 309 */       refName = String.valueOf(evaluate(refName));
/* 310 */       if (ref.isToParent()) {
/* 311 */         if (this.beanFactory.getParentBeanFactory() == null)
/*     */         {
/* 313 */           throw new BeanCreationException(this.beanDefinition
/* 313 */             .getResourceDescription(), this.beanName, new StringBuilder().append("Can't resolve reference to bean '").append(refName).append("' in parent factory: no parent factory available").toString());
/*     */         }
/*     */ 
/* 317 */         return this.beanFactory.getParentBeanFactory().getBean(refName);
/*     */       }
/*     */ 
/* 320 */       Object bean = this.beanFactory.getBean(refName);
/* 321 */       this.beanFactory.registerDependentBean(refName, this.beanName);
/* 322 */       return bean;
/*     */     }
/*     */     catch (BeansException ex)
/*     */     {
/* 328 */       throw new BeanCreationException(this.beanDefinition
/* 327 */         .getResourceDescription(), this.beanName, new StringBuilder().append("Cannot resolve reference to bean '")
/* 328 */         .append(ref
/* 328 */         .getBeanName()).append("' while setting ").append(argName).toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object resolveManagedArray(Object argName, List<?> ml, Class<?> elementType)
/*     */   {
/* 336 */     Object resolved = Array.newInstance(elementType, ml.size());
/* 337 */     for (int i = 0; i < ml.size(); i++) {
/* 338 */       Array.set(resolved, i, 
/* 339 */         resolveValueIfNecessary(new KeyedArgName(argName, 
/* 339 */         Integer.valueOf(i)), 
/* 339 */         ml.get(i)));
/*     */     }
/* 341 */     return resolved;
/*     */   }
/*     */ 
/*     */   private List<?> resolveManagedList(Object argName, List<?> ml)
/*     */   {
/* 348 */     List resolved = new ArrayList(ml.size());
/* 349 */     for (int i = 0; i < ml.size(); i++) {
/* 350 */       resolved.add(
/* 351 */         resolveValueIfNecessary(new KeyedArgName(argName, 
/* 351 */         Integer.valueOf(i)), 
/* 351 */         ml.get(i)));
/*     */     }
/* 353 */     return resolved;
/*     */   }
/*     */ 
/*     */   private Set<?> resolveManagedSet(Object argName, Set<?> ms)
/*     */   {
/* 360 */     Set resolved = new LinkedHashSet(ms.size());
/* 361 */     int i = 0;
/* 362 */     for (Iterator localIterator = ms.iterator(); localIterator.hasNext(); ) { Object m = localIterator.next();
/* 363 */       resolved.add(resolveValueIfNecessary(new KeyedArgName(argName, Integer.valueOf(i)), m));
/* 364 */       i++;
/*     */     }
/* 366 */     return resolved;
/*     */   }
/*     */ 
/*     */   private Map<?, ?> resolveManagedMap(Object argName, Map<?, ?> mm)
/*     */   {
/* 373 */     Map resolved = new LinkedHashMap(mm.size());
/* 374 */     for (Map.Entry entry : mm.entrySet()) {
/* 375 */       Object resolvedKey = resolveValueIfNecessary(argName, entry.getKey());
/* 376 */       Object resolvedValue = resolveValueIfNecessary(new KeyedArgName(argName, entry
/* 377 */         .getKey()), entry.getValue());
/* 378 */       resolved.put(resolvedKey, resolvedValue);
/*     */     }
/* 380 */     return resolved;
/*     */   }
/*     */ 
/*     */   private static class KeyedArgName
/*     */   {
/*     */     private final Object argName;
/*     */     private final Object key;
/*     */ 
/*     */     public KeyedArgName(Object argName, Object key)
/*     */     {
/* 394 */       this.argName = argName;
/* 395 */       this.key = key;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 400 */       return this.argName + " with key " + "[" + this.key + "]";
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.BeanDefinitionValueResolver
 * JD-Core Version:    0.6.2
 */