/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ 
/*     */ public class CglibSubclassingInstantiationStrategy extends SimpleInstantiationStrategy
/*     */ {
/*     */   private static final int PASSTHROUGH = 0;
/*     */   private static final int LOOKUP_OVERRIDE = 1;
/*     */   private static final int METHOD_REPLACER = 2;
/*     */ 
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition beanDefinition, String beanName, BeanFactory owner)
/*     */   {
/*  69 */     return new CglibSubclassCreator(beanDefinition, owner).instantiate(null, null);
/*     */   }
/*     */ 
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition beanDefinition, String beanName, BeanFactory owner, Constructor<?> ctor, Object[] args)
/*     */   {
/*  77 */     return new CglibSubclassCreator(beanDefinition, owner).instantiate(ctor, args);
/*     */   }
/*     */ 
/*     */   private static class CglibSubclassCreator
/*     */   {
/*  87 */     private static final Log logger = LogFactory.getLog(CglibSubclassCreator.class);
/*     */     private final RootBeanDefinition beanDefinition;
/*     */     private final BeanFactory owner;
/*     */ 
/*     */     public CglibSubclassCreator(RootBeanDefinition beanDefinition, BeanFactory owner)
/*     */     {
/*  94 */       this.beanDefinition = beanDefinition;
/*  95 */       this.owner = owner;
/*     */     }
/*     */ 
/*     */     public Object instantiate(Constructor<?> ctor, Object[] args)
/*     */     {
/* 108 */       Enhancer enhancer = new Enhancer();
/* 109 */       enhancer.setSuperclass(this.beanDefinition.getBeanClass());
/* 110 */       enhancer.setCallbackFilter(new CallbackFilterImpl(null));
/* 111 */       enhancer.setCallbacks(new Callback[] { NoOp.INSTANCE, new LookupOverrideMethodInterceptor(null), new ReplaceOverrideMethodInterceptor(null) });
/*     */ 
/* 119 */       return ctor == null ? enhancer
/* 118 */         .create() : enhancer
/* 119 */         .create(ctor
/* 119 */         .getParameterTypes(), args);
/*     */     }
/*     */ 
/*     */     private class CallbackFilterImpl extends CglibSubclassingInstantiationStrategy.CglibSubclassCreator.CglibIdentitySupport
/*     */       implements CallbackFilter
/*     */     {
/*     */       private CallbackFilterImpl()
/*     */       {
/* 184 */         super(null);
/*     */       }
/*     */ 
/*     */       public int accept(Method method) {
/* 188 */         MethodOverride methodOverride = CglibSubclassingInstantiationStrategy.CglibSubclassCreator.this.beanDefinition.getMethodOverrides().getOverride(method);
/* 189 */         if (CglibSubclassingInstantiationStrategy.CglibSubclassCreator.logger.isTraceEnabled()) {
/* 190 */           CglibSubclassingInstantiationStrategy.CglibSubclassCreator.logger.trace("Override for '" + method.getName() + "' is [" + methodOverride + "]");
/*     */         }
/* 192 */         if (methodOverride == null) {
/* 193 */           return 0;
/*     */         }
/* 195 */         if ((methodOverride instanceof LookupOverride)) {
/* 196 */           return 1;
/*     */         }
/* 198 */         if ((methodOverride instanceof ReplaceOverride)) {
/* 199 */           return 2;
/*     */         }
/*     */ 
/* 202 */         throw new UnsupportedOperationException("Unexpected MethodOverride subclass: " + methodOverride
/* 202 */           .getClass().getName());
/*     */       }
/*     */     }
/*     */ 
/*     */     private class ReplaceOverrideMethodInterceptor extends CglibSubclassingInstantiationStrategy.CglibSubclassCreator.CglibIdentitySupport
/*     */       implements MethodInterceptor
/*     */     {
/*     */       private ReplaceOverrideMethodInterceptor()
/*     */       {
/* 169 */         super(null);
/*     */       }
/*     */ 
/*     */       public Object intercept(Object obj, Method method, Object[] args, MethodProxy mp) throws Throwable {
/* 173 */         ReplaceOverride ro = (ReplaceOverride)CglibSubclassingInstantiationStrategy.CglibSubclassCreator.this.beanDefinition.getMethodOverrides().getOverride(method);
/*     */ 
/* 175 */         MethodReplacer mr = (MethodReplacer)CglibSubclassingInstantiationStrategy.CglibSubclassCreator.this.owner.getBean(ro.getMethodReplacerBeanName());
/* 176 */         return mr.reimplement(obj, method, args);
/*     */       }
/*     */     }
/*     */ 
/*     */     private class LookupOverrideMethodInterceptor extends CglibSubclassingInstantiationStrategy.CglibSubclassCreator.CglibIdentitySupport
/*     */       implements MethodInterceptor
/*     */     {
/*     */       private LookupOverrideMethodInterceptor()
/*     */       {
/* 154 */         super(null);
/*     */       }
/*     */ 
/*     */       public Object intercept(Object obj, Method method, Object[] args, MethodProxy mp) throws Throwable
/*     */       {
/* 159 */         LookupOverride lo = (LookupOverride)CglibSubclassingInstantiationStrategy.CglibSubclassCreator.this.beanDefinition.getMethodOverrides().getOverride(method);
/* 160 */         return CglibSubclassingInstantiationStrategy.CglibSubclassCreator.this.owner.getBean(lo.getBeanName());
/*     */       }
/*     */     }
/*     */ 
/*     */     private class CglibIdentitySupport
/*     */     {
/*     */       private CglibIdentitySupport()
/*     */       {
/*     */       }
/*     */ 
/*     */       protected RootBeanDefinition getBeanDefinition()
/*     */       {
/* 134 */         return CglibSubclassingInstantiationStrategy.CglibSubclassCreator.this.beanDefinition;
/*     */       }
/*     */ 
/*     */       public boolean equals(Object other)
/*     */       {
/* 140 */         return (other.getClass().equals(getClass())) && 
/* 140 */           (((CglibIdentitySupport)other)
/* 140 */           .getBeanDefinition().equals(CglibSubclassingInstantiationStrategy.CglibSubclassCreator.this.beanDefinition));
/*     */       }
/*     */ 
/*     */       public int hashCode()
/*     */       {
/* 145 */         return CglibSubclassingInstantiationStrategy.CglibSubclassCreator.this.beanDefinition.hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.CglibSubclassingInstantiationStrategy
 * JD-Core Version:    0.6.2
 */