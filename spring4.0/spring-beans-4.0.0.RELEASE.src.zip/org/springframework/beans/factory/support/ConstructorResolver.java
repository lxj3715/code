/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.beans.ConstructorProperties;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues.ValueHolder;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MethodInvoker;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ConstructorResolver
/*     */ {
/*     */   private static final String CONSTRUCTOR_PROPERTIES_CLASS_NAME = "java.beans.ConstructorProperties";
/*  77 */   private static final boolean constructorPropertiesAnnotationAvailable = ClassUtils.isPresent("java.beans.ConstructorProperties", ConstructorResolver.class
/*  77 */     .getClassLoader());
/*     */   private final AbstractAutowireCapableBeanFactory beanFactory;
/*     */ 
/*     */   public ConstructorResolver(AbstractAutowireCapableBeanFactory beanFactory)
/*     */   {
/*  87 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public BeanWrapper autowireConstructor(final String beanName, final RootBeanDefinition mbd, Constructor<?>[] chosenCtors, Object[] explicitArgs)
/*     */   {
/* 108 */     BeanWrapperImpl bw = new BeanWrapperImpl();
/* 109 */     this.beanFactory.initBeanWrapper(bw);
/*     */ 
/* 111 */     Constructor constructorToUse = null;
/* 112 */     ArgumentsHolder argsHolderToUse = null;
/* 113 */     Object[] argsToUse = null;
/*     */ 
/* 115 */     if (explicitArgs != null) {
/* 116 */       argsToUse = explicitArgs;
/*     */     }
/*     */     else {
/* 119 */       Object[] argsToResolve = null;
/* 120 */       synchronized (mbd.constructorArgumentLock) {
/* 121 */         constructorToUse = (Constructor)mbd.resolvedConstructorOrFactoryMethod;
/* 122 */         if ((constructorToUse != null) && (mbd.constructorArgumentsResolved))
/*     */         {
/* 124 */           argsToUse = mbd.resolvedConstructorArguments;
/* 125 */           if (argsToUse == null) {
/* 126 */             argsToResolve = mbd.preparedConstructorArguments;
/*     */           }
/*     */         }
/*     */       }
/* 130 */       if (argsToResolve != null) {
/* 131 */         argsToUse = resolvePreparedArguments(beanName, mbd, bw, constructorToUse, argsToResolve);
/*     */       }
/*     */     }
/*     */ 
/* 135 */     if (constructorToUse == null)
/*     */     {
/* 138 */       boolean autowiring = (chosenCtors != null) || 
/* 138 */         (mbd
/* 138 */         .getResolvedAutowireMode() == 3);
/* 139 */       ConstructorArgumentValues resolvedValues = null;
/*     */       int minNrOfArgs;
/*     */       int minNrOfArgs;
/* 142 */       if (explicitArgs != null) {
/* 143 */         minNrOfArgs = explicitArgs.length;
/*     */       }
/*     */       else {
/* 146 */         ConstructorArgumentValues cargs = mbd.getConstructorArgumentValues();
/* 147 */         resolvedValues = new ConstructorArgumentValues();
/* 148 */         minNrOfArgs = resolveConstructorArguments(beanName, mbd, bw, cargs, resolvedValues);
/*     */       }
/*     */ 
/* 152 */       Constructor[] candidates = chosenCtors;
/* 153 */       if (candidates == null) {
/* 154 */         Class beanClass = mbd.getBeanClass();
/*     */         try
/*     */         {
/* 157 */           candidates = mbd.isNonPublicAccessAllowed() ? beanClass
/* 157 */             .getDeclaredConstructors() : beanClass.getConstructors();
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/* 162 */           throw new BeanCreationException(mbd.getResourceDescription(), beanName, new StringBuilder().append("Resolution of declared constructors on bean Class [")
/* 161 */             .append(beanClass
/* 161 */             .getName()).append("] from ClassLoader [")
/* 162 */             .append(beanClass
/* 162 */             .getClassLoader()).append("] failed").toString(), ex);
/*     */         }
/*     */       }
/* 165 */       AutowireUtils.sortConstructors(candidates);
/* 166 */       int minTypeDiffWeight = 2147483647;
/* 167 */       Set ambiguousConstructors = null;
/* 168 */       List causes = null;
/*     */ 
/* 170 */       for (int i = 0; i < candidates.length; i++) {
/* 171 */         Constructor candidate = candidates[i];
/* 172 */         Class[] paramTypes = candidate.getParameterTypes();
/*     */ 
/* 174 */         if ((constructorToUse != null) && (argsToUse.length > paramTypes.length))
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/* 179 */         if (paramTypes.length >= minNrOfArgs)
/*     */         {
/*     */           ArgumentsHolder argsHolder;
/* 184 */           if (resolvedValues != null) {
/*     */             try {
/* 186 */               String[] paramNames = null;
/* 187 */               if (constructorPropertiesAnnotationAvailable) {
/* 188 */                 paramNames = ConstructorPropertiesChecker.evaluateAnnotation(candidate, paramTypes.length);
/*     */               }
/* 190 */               if (paramNames == null) {
/* 191 */                 pnd = this.beanFactory.getParameterNameDiscoverer();
/* 192 */                 if (pnd != null) {
/* 193 */                   paramNames = pnd.getParameterNames(candidate);
/*     */                 }
/*     */               }
/* 196 */               argsHolder = createArgumentArray(beanName, mbd, resolvedValues, bw, paramTypes, paramNames, candidate, autowiring);
/*     */             }
/*     */             catch (UnsatisfiedDependencyException ex)
/*     */             {
/*     */               ParameterNameDiscoverer pnd;
/*     */               ArgumentsHolder argsHolder;
/* 200 */               if (this.beanFactory.logger.isTraceEnabled()) {
/* 201 */                 this.beanFactory.logger.trace(new StringBuilder().append("Ignoring constructor [").append(candidate).append("] of bean '").append(beanName).append("': ").append(ex).toString());
/*     */               }
/*     */ 
/* 204 */               if ((i == candidates.length - 1) && (constructorToUse == null)) {
/* 205 */                 if (causes != null) {
/* 206 */                   for (Exception cause : causes) {
/* 207 */                     this.beanFactory.onSuppressedException(cause);
/*     */                   }
/*     */                 }
/* 210 */                 throw ex;
/*     */               }
/*     */ 
/* 214 */               if (causes == null) {
/* 215 */                 causes = new LinkedList();
/*     */               }
/* 217 */               causes.add(ex);
/* 218 */               continue;
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 224 */             if (paramTypes.length != explicitArgs.length) {
/*     */               continue;
/*     */             }
/* 227 */             argsHolder = new ArgumentsHolder(explicitArgs);
/*     */           }
/*     */ 
/* 231 */           int typeDiffWeight = mbd.isLenientConstructorResolution() ? argsHolder
/* 231 */             .getTypeDifferenceWeight(paramTypes) : 
/* 231 */             argsHolder.getAssignabilityWeight(paramTypes);
/*     */ 
/* 233 */           if (typeDiffWeight < minTypeDiffWeight) {
/* 234 */             constructorToUse = candidate;
/* 235 */             argsHolderToUse = argsHolder;
/* 236 */             argsToUse = argsHolder.arguments;
/* 237 */             minTypeDiffWeight = typeDiffWeight;
/* 238 */             ambiguousConstructors = null;
/*     */           }
/* 240 */           else if ((constructorToUse != null) && (typeDiffWeight == minTypeDiffWeight)) {
/* 241 */             if (ambiguousConstructors == null) {
/* 242 */               ambiguousConstructors = new LinkedHashSet();
/* 243 */               ambiguousConstructors.add(constructorToUse);
/*     */             }
/* 245 */             ambiguousConstructors.add(candidate);
/*     */           }
/*     */         }
/*     */       }
/* 249 */       if (constructorToUse == null) {
/* 250 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Could not resolve matching constructor (hint: specify index/type/name arguments for simple parameters to avoid type ambiguities)");
/*     */       }
/*     */ 
/* 254 */       if ((ambiguousConstructors != null) && (!mbd.isLenientConstructorResolution())) {
/* 255 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, new StringBuilder().append("Ambiguous constructor matches found in bean '").append(beanName).append("' ").append("(hint: specify index/type/name arguments for simple parameters to avoid type ambiguities): ").append(ambiguousConstructors).toString());
/*     */       }
/*     */ 
/* 261 */       if (explicitArgs == null)
/* 262 */         argsHolderToUse.storeCache(mbd, constructorToUse);
/*     */     }
/*     */     try
/*     */     {
/*     */       Object beanInstance;
/*     */       Object beanInstance;
/* 269 */       if (System.getSecurityManager() != null) {
/* 270 */         final Constructor ctorToUse = constructorToUse;
/* 271 */         final Object[] argumentsToUse = argsToUse;
/* 272 */         beanInstance = AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 275 */             return ConstructorResolver.this.beanFactory.getInstantiationStrategy().instantiate(mbd, beanName, ConstructorResolver.this.beanFactory, 
/* 276 */               ctorToUse, argumentsToUse);
/*     */           }
/*     */         }
/*     */         , this.beanFactory
/* 278 */           .getAccessControlContext());
/*     */       }
/*     */       else {
/* 281 */         beanInstance = this.beanFactory.getInstantiationStrategy().instantiate(mbd, beanName, this.beanFactory, constructorToUse, argsToUse);
/*     */       }
/*     */ 
/* 285 */       bw.setWrappedInstance(beanInstance);
/* 286 */       return bw;
/*     */     }
/*     */     catch (Throwable ex) {
/* 289 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Instantiation of bean failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resolveFactoryMethodIfPossible(RootBeanDefinition mbd)
/*     */   {
/*     */     Class factoryClass;
/* 300 */     if (mbd.getFactoryBeanName() != null) {
/* 301 */       factoryClass = this.beanFactory.getType(mbd.getFactoryBeanName());
/*     */     }
/*     */     else {
/* 304 */       factoryClass = mbd.getBeanClass();
/*     */     }
/* 306 */     Class factoryClass = ClassUtils.getUserClass(factoryClass);
/* 307 */     Method[] candidates = ReflectionUtils.getAllDeclaredMethods(factoryClass);
/* 308 */     Method uniqueCandidate = null;
/* 309 */     for (Method candidate : candidates) {
/* 310 */       if (mbd.isFactoryMethod(candidate)) {
/* 311 */         if (uniqueCandidate == null) {
/* 312 */           uniqueCandidate = candidate;
/*     */         }
/* 314 */         else if (!Arrays.equals(uniqueCandidate.getParameterTypes(), candidate.getParameterTypes())) {
/* 315 */           uniqueCandidate = null;
/* 316 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 320 */     synchronized (mbd.constructorArgumentLock) {
/* 321 */       mbd.resolvedConstructorOrFactoryMethod = uniqueCandidate;
/*     */     }
/*     */   }
/*     */ 
/*     */   public BeanWrapper instantiateUsingFactoryMethod(final String beanName, final RootBeanDefinition mbd, Object[] explicitArgs)
/*     */   {
/* 341 */     BeanWrapperImpl bw = new BeanWrapperImpl();
/* 342 */     this.beanFactory.initBeanWrapper(bw);
/*     */ 
/* 348 */     String factoryBeanName = mbd.getFactoryBeanName();
/*     */     boolean isStatic;
/*     */     Object factoryBean;
/*     */     Class factoryClass;
/*     */     boolean isStatic;
/* 349 */     if (factoryBeanName != null) {
/* 350 */       if (factoryBeanName.equals(beanName)) {
/* 351 */         throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, "factory-bean reference points back to the same bean definition");
/*     */       }
/*     */ 
/* 354 */       Object factoryBean = this.beanFactory.getBean(factoryBeanName);
/* 355 */       if (factoryBean == null) {
/* 356 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, new StringBuilder().append("factory-bean '").append(factoryBeanName).append("' returned null").toString());
/*     */       }
/*     */ 
/* 359 */       Class factoryClass = factoryBean.getClass();
/* 360 */       isStatic = false;
/*     */     }
/*     */     else
/*     */     {
/* 364 */       if (!mbd.hasBeanClass()) {
/* 365 */         throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, "bean definition declares neither a bean class nor a factory-bean reference");
/*     */       }
/*     */ 
/* 368 */       factoryBean = null;
/* 369 */       factoryClass = mbd.getBeanClass();
/* 370 */       isStatic = true;
/*     */     }
/*     */ 
/* 373 */     Method factoryMethodToUse = null;
/* 374 */     ArgumentsHolder argsHolderToUse = null;
/* 375 */     Object[] argsToUse = null;
/*     */ 
/* 377 */     if (explicitArgs != null) {
/* 378 */       argsToUse = explicitArgs;
/*     */     }
/*     */     else {
/* 381 */       Object[] argsToResolve = null;
/* 382 */       synchronized (mbd.constructorArgumentLock) {
/* 383 */         factoryMethodToUse = (Method)mbd.resolvedConstructorOrFactoryMethod;
/* 384 */         if ((factoryMethodToUse != null) && (mbd.constructorArgumentsResolved))
/*     */         {
/* 386 */           argsToUse = mbd.resolvedConstructorArguments;
/* 387 */           if (argsToUse == null) {
/* 388 */             argsToResolve = mbd.preparedConstructorArguments;
/*     */           }
/*     */         }
/*     */       }
/* 392 */       if (argsToResolve != null) {
/* 393 */         argsToUse = resolvePreparedArguments(beanName, mbd, bw, factoryMethodToUse, argsToResolve);
/*     */       }
/*     */     }
/*     */ 
/* 397 */     if ((factoryMethodToUse == null) || (argsToUse == null))
/*     */     {
/* 400 */       factoryClass = ClassUtils.getUserClass(factoryClass);
/*     */ 
/* 403 */       final Class factoryClazz = factoryClass;
/*     */       Method[] rawCandidates;
/*     */       Method[] rawCandidates;
/* 404 */       if (System.getSecurityManager() != null) {
/* 405 */         rawCandidates = (Method[])AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Method[] run()
/*     */           {
/* 409 */             return mbd.isNonPublicAccessAllowed() ? 
/* 409 */               ReflectionUtils.getAllDeclaredMethods(factoryClazz) : 
/* 409 */               factoryClazz.getMethods();
/*     */           }
/*     */         });
/*     */       }
/*     */       else
/*     */       {
/* 415 */         rawCandidates = mbd.isNonPublicAccessAllowed() ? 
/* 415 */           ReflectionUtils.getAllDeclaredMethods(factoryClazz) : 
/* 415 */           factoryClazz.getMethods();
/*     */       }
/*     */ 
/* 418 */       Object candidateSet = new ArrayList();
/* 419 */       for (Method candidate : rawCandidates) {
/* 420 */         if ((Modifier.isStatic(candidate.getModifiers()) == isStatic) && 
/* 421 */           (candidate
/* 421 */           .getName().equals(mbd.getFactoryMethodName())) && 
/* 422 */           (mbd
/* 422 */           .isFactoryMethod(candidate)))
/*     */         {
/* 423 */           ((List)candidateSet).add(candidate);
/*     */         }
/*     */       }
/* 426 */       Method[] candidates = (Method[])((List)candidateSet).toArray(new Method[((List)candidateSet).size()]);
/* 427 */       AutowireUtils.sortFactoryMethods(candidates);
/*     */ 
/* 429 */       ConstructorArgumentValues resolvedValues = null;
/* 430 */       boolean autowiring = mbd.getResolvedAutowireMode() == 3;
/* 431 */       int minTypeDiffWeight = 2147483647;
/* 432 */       Set ambiguousFactoryMethods = null;
/*     */       int minNrOfArgs;
/*     */       int minNrOfArgs;
/* 435 */       if (explicitArgs != null) {
/* 436 */         minNrOfArgs = explicitArgs.length;
/*     */       }
/*     */       else
/*     */       {
/* 441 */         ConstructorArgumentValues cargs = mbd.getConstructorArgumentValues();
/* 442 */         resolvedValues = new ConstructorArgumentValues();
/* 443 */         minNrOfArgs = resolveConstructorArguments(beanName, mbd, bw, cargs, resolvedValues);
/*     */       }
/*     */ 
/* 446 */       List causes = null;
/*     */       ArgumentsHolder argsHolder;
/* 448 */       for (int i = 0; i < candidates.length; i++) {
/* 449 */         Method candidate = candidates[i];
/* 450 */         Class[] paramTypes = candidate.getParameterTypes();
/*     */ 
/* 452 */         if (paramTypes.length >= minNrOfArgs)
/*     */         {
/* 455 */           if (resolvedValues != null)
/*     */           {
/*     */             try {
/* 458 */               String[] paramNames = null;
/* 459 */               pnd = this.beanFactory.getParameterNameDiscoverer();
/* 460 */               if (pnd != null) {
/* 461 */                 paramNames = pnd.getParameterNames(candidate);
/*     */               }
/* 463 */               argsHolder = createArgumentArray(beanName, mbd, resolvedValues, bw, paramTypes, paramNames, candidate, autowiring);
/*     */             }
/*     */             catch (UnsatisfiedDependencyException ex)
/*     */             {
/*     */               ParameterNameDiscoverer pnd;
/*     */               ArgumentsHolder argsHolder;
/* 467 */               if (this.beanFactory.logger.isTraceEnabled()) {
/* 468 */                 this.beanFactory.logger.trace(new StringBuilder().append("Ignoring factory method [").append(candidate).append("] of bean '").append(beanName).append("': ").append(ex).toString());
/*     */               }
/*     */ 
/* 471 */               if ((i == candidates.length - 1) && (argsHolderToUse == null)) {
/* 472 */                 if (causes != null) {
/* 473 */                   for (Exception cause : causes) {
/* 474 */                     this.beanFactory.onSuppressedException(cause);
/*     */                   }
/*     */                 }
/* 477 */                 throw ex;
/*     */               }
/*     */ 
/* 481 */               if (causes == null) {
/* 482 */                 causes = new LinkedList();
/*     */               }
/* 484 */               causes.add(ex);
/* 485 */               continue;
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 492 */             if (paramTypes.length != explicitArgs.length) {
/*     */               continue;
/*     */             }
/* 495 */             argsHolder = new ArgumentsHolder(explicitArgs);
/*     */           }
/*     */ 
/* 499 */           int typeDiffWeight = mbd.isLenientConstructorResolution() ? argsHolder
/* 499 */             .getTypeDifferenceWeight(paramTypes) : 
/* 499 */             argsHolder.getAssignabilityWeight(paramTypes);
/*     */ 
/* 501 */           if (typeDiffWeight < minTypeDiffWeight) {
/* 502 */             factoryMethodToUse = candidate;
/* 503 */             argsHolderToUse = argsHolder;
/* 504 */             argsToUse = argsHolder.arguments;
/* 505 */             minTypeDiffWeight = typeDiffWeight;
/* 506 */             ambiguousFactoryMethods = null;
/*     */           }
/* 513 */           else if ((factoryMethodToUse != null) && (typeDiffWeight == minTypeDiffWeight) && 
/* 514 */             (!mbd
/* 514 */             .isLenientConstructorResolution()) && 
/* 515 */             (paramTypes.length == factoryMethodToUse
/* 515 */             .getParameterTypes().length) && 
/* 516 */             (!Arrays.equals(paramTypes, factoryMethodToUse
/* 516 */             .getParameterTypes()))) {
/* 517 */             if (ambiguousFactoryMethods == null) {
/* 518 */               ambiguousFactoryMethods = new LinkedHashSet();
/* 519 */               ambiguousFactoryMethods.add(factoryMethodToUse);
/*     */             }
/* 521 */             ambiguousFactoryMethods.add(candidate);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 526 */       if (factoryMethodToUse == null) {
/* 527 */         boolean hasArgs = resolvedValues.getArgumentCount() > 0;
/* 528 */         String argDesc = "";
/* 529 */         if (hasArgs) {
/* 530 */           List argTypes = new ArrayList();
/* 531 */           for (ConstructorArgumentValues.ValueHolder value : resolvedValues.getIndexedArgumentValues().values())
/*     */           {
/* 533 */             String argType = value.getType() != null ? 
/* 533 */               ClassUtils.getShortName(value
/* 533 */               .getType()) : value.getValue().getClass().getSimpleName();
/* 534 */             argTypes.add(argType);
/*     */           }
/* 536 */           argDesc = StringUtils.collectionToCommaDelimitedString(argTypes);
/*     */         }
/*     */ 
/* 542 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, new StringBuilder().append("No matching factory method found: ")
/* 541 */           .append(mbd
/* 540 */           .getFactoryBeanName() != null ? new StringBuilder().append("factory bean '")
/* 541 */           .append(mbd
/* 541 */           .getFactoryBeanName()).append("'; ").toString() : "").append("factory method '")
/* 542 */           .append(mbd
/* 542 */           .getFactoryMethodName()).append("(").append(argDesc).append(")'. ").append("Check that a method with the specified name ").append(hasArgs ? "and arguments " : "").append("exists and that it is ").append(isStatic ? "static" : "non-static").append(".").toString());
/*     */       }
/*     */ 
/* 548 */       if (Void.TYPE.equals(factoryMethodToUse.getReturnType()))
/*     */       {
/* 550 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, new StringBuilder().append("Invalid factory method '")
/* 550 */           .append(mbd
/* 550 */           .getFactoryMethodName()).append("': needs to have a non-void return type!").toString());
/*     */       }
/*     */ 
/* 553 */       if (ambiguousFactoryMethods != null) {
/* 554 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, new StringBuilder().append("Ambiguous factory method matches found in bean '").append(beanName).append("' ").append("(hint: specify index/type/name arguments for simple parameters to avoid type ambiguities): ").append(ambiguousFactoryMethods).toString());
/*     */       }
/*     */ 
/* 560 */       if ((explicitArgs == null) && (argsHolderToUse != null))
/* 561 */         argsHolderToUse.storeCache(mbd, factoryMethodToUse);
/*     */     }
/*     */     try
/*     */     {
/*     */       Object beanInstance;
/*     */       Object beanInstance;
/* 568 */       if (System.getSecurityManager() != null) {
/* 569 */         final Object fb = factoryBean;
/* 570 */         final Method factoryMethod = factoryMethodToUse;
/* 571 */         final Object[] args = argsToUse;
/* 572 */         beanInstance = AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 575 */             return ConstructorResolver.this.beanFactory.getInstantiationStrategy().instantiate(mbd, beanName, ConstructorResolver.this.beanFactory, 
/* 576 */               fb, factoryMethod, args);
/*     */           }
/*     */         }
/*     */         , this.beanFactory
/* 578 */           .getAccessControlContext());
/*     */       }
/*     */       else {
/* 581 */         beanInstance = this.beanFactory.getInstantiationStrategy().instantiate(mbd, beanName, this.beanFactory, factoryBean, factoryMethodToUse, argsToUse);
/*     */       }
/*     */ 
/* 585 */       if (beanInstance == null) {
/* 586 */         return null;
/*     */       }
/* 588 */       bw.setWrappedInstance(beanInstance);
/* 589 */       return bw;
/*     */     }
/*     */     catch (Throwable ex) {
/* 592 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Instantiation of bean failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private int resolveConstructorArguments(String beanName, RootBeanDefinition mbd, BeanWrapper bw, ConstructorArgumentValues cargs, ConstructorArgumentValues resolvedValues)
/*     */   {
/* 606 */     TypeConverter converter = this.beanFactory.getCustomTypeConverter() != null ? this.beanFactory
/* 606 */       .getCustomTypeConverter() : bw;
/* 607 */     BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver(this.beanFactory, beanName, mbd, converter);
/*     */ 
/* 610 */     int minNrOfArgs = cargs.getArgumentCount();
/*     */ 
/* 612 */     for (Map.Entry entry : cargs.getIndexedArgumentValues().entrySet()) {
/* 613 */       int index = ((Integer)entry.getKey()).intValue();
/* 614 */       if (index < 0) {
/* 615 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, new StringBuilder().append("Invalid constructor argument index: ").append(index).toString());
/*     */       }
/*     */ 
/* 618 */       if (index > minNrOfArgs) {
/* 619 */         minNrOfArgs = index + 1;
/*     */       }
/* 621 */       ConstructorArgumentValues.ValueHolder valueHolder = (ConstructorArgumentValues.ValueHolder)entry.getValue();
/* 622 */       if (valueHolder.isConverted()) {
/* 623 */         resolvedValues.addIndexedArgumentValue(index, valueHolder);
/*     */       }
/*     */       else
/*     */       {
/* 627 */         Object resolvedValue = valueResolver
/* 627 */           .resolveValueIfNecessary("constructor argument", valueHolder
/* 627 */           .getValue());
/*     */ 
/* 629 */         ConstructorArgumentValues.ValueHolder resolvedValueHolder = new ConstructorArgumentValues.ValueHolder(resolvedValue, valueHolder
/* 629 */           .getType(), valueHolder.getName());
/* 630 */         resolvedValueHolder.setSource(valueHolder);
/* 631 */         resolvedValues.addIndexedArgumentValue(index, resolvedValueHolder);
/*     */       }
/*     */     }
/*     */ 
/* 635 */     for (ConstructorArgumentValues.ValueHolder valueHolder : cargs.getGenericArgumentValues()) {
/* 636 */       if (valueHolder.isConverted()) {
/* 637 */         resolvedValues.addGenericArgumentValue(valueHolder);
/*     */       }
/*     */       else
/*     */       {
/* 641 */         Object resolvedValue = valueResolver
/* 641 */           .resolveValueIfNecessary("constructor argument", valueHolder
/* 641 */           .getValue());
/*     */ 
/* 643 */         ConstructorArgumentValues.ValueHolder resolvedValueHolder = new ConstructorArgumentValues.ValueHolder(resolvedValue, valueHolder
/* 643 */           .getType(), valueHolder.getName());
/* 644 */         resolvedValueHolder.setSource(valueHolder);
/* 645 */         resolvedValues.addGenericArgumentValue(resolvedValueHolder);
/*     */       }
/*     */     }
/*     */ 
/* 649 */     return minNrOfArgs;
/*     */   }
/*     */ 
/*     */   private ArgumentsHolder createArgumentArray(String beanName, RootBeanDefinition mbd, ConstructorArgumentValues resolvedValues, BeanWrapper bw, Class<?>[] paramTypes, String[] paramNames, Object methodOrCtor, boolean autowiring)
/*     */     throws UnsatisfiedDependencyException
/*     */   {
/* 661 */     String methodType = (methodOrCtor instanceof Constructor) ? "constructor" : "factory method";
/*     */ 
/* 663 */     TypeConverter converter = this.beanFactory.getCustomTypeConverter() != null ? this.beanFactory
/* 663 */       .getCustomTypeConverter() : bw;
/*     */ 
/* 665 */     ArgumentsHolder args = new ArgumentsHolder(paramTypes.length);
/* 666 */     Set usedValueHolders = new HashSet(paramTypes.length);
/*     */ 
/* 668 */     Set autowiredBeanNames = new LinkedHashSet(4);
/*     */ 
/* 670 */     for (int paramIndex = 0; paramIndex < paramTypes.length; paramIndex++) {
/* 671 */       Class paramType = paramTypes[paramIndex];
/* 672 */       String paramName = paramNames != null ? paramNames[paramIndex] : null;
/*     */ 
/* 675 */       ConstructorArgumentValues.ValueHolder valueHolder = resolvedValues
/* 675 */         .getArgumentValue(paramIndex, paramType, paramName, usedValueHolders);
/*     */ 
/* 679 */       if ((valueHolder == null) && (!autowiring)) {
/* 680 */         valueHolder = resolvedValues.getGenericArgumentValue(null, null, usedValueHolders);
/*     */       }
/* 682 */       if (valueHolder != null)
/*     */       {
/* 685 */         usedValueHolders.add(valueHolder);
/* 686 */         Object originalValue = valueHolder.getValue();
/*     */ 
/* 688 */         if (valueHolder.isConverted()) {
/* 689 */           Object convertedValue = valueHolder.getConvertedValue();
/* 690 */           args.preparedArguments[paramIndex] = convertedValue;
/*     */         }
/*     */         else
/*     */         {
/* 694 */           ConstructorArgumentValues.ValueHolder sourceHolder = (ConstructorArgumentValues.ValueHolder)valueHolder
/* 694 */             .getSource();
/* 695 */           Object sourceValue = sourceHolder.getValue();
/*     */           try {
/* 697 */             Object convertedValue = converter.convertIfNecessary(originalValue, paramType, 
/* 698 */               MethodParameter.forMethodOrConstructor(methodOrCtor, paramIndex));
/*     */ 
/* 708 */             args.resolveNecessary = true;
/* 709 */             args.preparedArguments[paramIndex] = sourceValue;
/*     */           }
/*     */           catch (TypeMismatchException ex)
/*     */           {
/* 717 */             throw new UnsatisfiedDependencyException(mbd
/* 714 */               .getResourceDescription(), beanName, paramIndex, paramType, new StringBuilder().append("Could not convert ").append(methodType).append(" argument value of type [")
/* 716 */               .append(ObjectUtils.nullSafeClassName(valueHolder
/* 716 */               .getValue())).append("] to required type [")
/* 717 */               .append(paramType
/* 717 */               .getName()).append("]: ").append(ex.getMessage()).toString());
/*     */           }
/*     */         }
/*     */         Object convertedValue;
/* 720 */         args.arguments[paramIndex] = convertedValue;
/* 721 */         args.rawArguments[paramIndex] = originalValue;
/*     */       }
/*     */       else
/*     */       {
/* 726 */         if (!autowiring)
/*     */         {
/* 728 */           throw new UnsatisfiedDependencyException(mbd
/* 728 */             .getResourceDescription(), beanName, paramIndex, paramType, new StringBuilder().append("Ambiguous ").append(methodType).append(" argument types - ").append("did you specify the correct bean references as ").append(methodType).append(" arguments?").toString());
/*     */         }
/*     */ 
/*     */         try
/*     */         {
/* 733 */           MethodParameter param = MethodParameter.forMethodOrConstructor(methodOrCtor, paramIndex);
/* 734 */           Object autowiredArgument = resolveAutowiredArgument(param, beanName, autowiredBeanNames, converter);
/* 735 */           args.rawArguments[paramIndex] = autowiredArgument;
/* 736 */           args.arguments[paramIndex] = autowiredArgument;
/* 737 */           args.preparedArguments[paramIndex] = new AutowiredArgumentMarker(null);
/* 738 */           args.resolveNecessary = true;
/*     */         }
/*     */         catch (BeansException ex)
/*     */         {
/* 742 */           throw new UnsatisfiedDependencyException(mbd
/* 742 */             .getResourceDescription(), beanName, paramIndex, paramType, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 747 */     for (String autowiredBeanName : autowiredBeanNames) {
/* 748 */       this.beanFactory.registerDependentBean(autowiredBeanName, beanName);
/* 749 */       if (this.beanFactory.logger.isDebugEnabled()) {
/* 750 */         this.beanFactory.logger.debug(new StringBuilder().append("Autowiring by type from bean name '").append(beanName).append("' via ").append(methodType).append(" to bean named '").append(autowiredBeanName).append("'").toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 755 */     return args;
/*     */   }
/*     */ 
/*     */   private Object[] resolvePreparedArguments(String beanName, RootBeanDefinition mbd, BeanWrapper bw, Member methodOrCtor, Object[] argsToResolve)
/*     */   {
/* 765 */     Class[] paramTypes = (methodOrCtor instanceof Method) ? ((Method)methodOrCtor)
/* 765 */       .getParameterTypes() : ((Constructor)methodOrCtor).getParameterTypes();
/*     */ 
/* 767 */     TypeConverter converter = this.beanFactory.getCustomTypeConverter() != null ? this.beanFactory
/* 767 */       .getCustomTypeConverter() : bw;
/* 768 */     BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver(this.beanFactory, beanName, mbd, converter);
/*     */ 
/* 770 */     Object[] resolvedArgs = new Object[argsToResolve.length];
/* 771 */     for (int argIndex = 0; argIndex < argsToResolve.length; argIndex++) {
/* 772 */       Object argValue = argsToResolve[argIndex];
/* 773 */       MethodParameter methodParam = MethodParameter.forMethodOrConstructor(methodOrCtor, argIndex);
/* 774 */       GenericTypeResolver.resolveParameterType(methodParam, methodOrCtor.getDeclaringClass());
/* 775 */       if ((argValue instanceof AutowiredArgumentMarker)) {
/* 776 */         argValue = resolveAutowiredArgument(methodParam, beanName, null, converter);
/*     */       }
/* 778 */       else if ((argValue instanceof BeanMetadataElement)) {
/* 779 */         argValue = valueResolver.resolveValueIfNecessary("constructor argument", argValue);
/*     */       }
/* 781 */       else if ((argValue instanceof String)) {
/* 782 */         argValue = this.beanFactory.evaluateBeanDefinitionString((String)argValue, mbd);
/*     */       }
/* 784 */       Class paramType = paramTypes[argIndex];
/*     */       try {
/* 786 */         resolvedArgs[argIndex] = converter.convertIfNecessary(argValue, paramType, methodParam);
/*     */       }
/*     */       catch (TypeMismatchException ex) {
/* 789 */         String methodType = (methodOrCtor instanceof Constructor) ? "constructor" : "factory method";
/*     */ 
/* 794 */         throw new UnsatisfiedDependencyException(mbd
/* 791 */           .getResourceDescription(), beanName, argIndex, paramType, new StringBuilder().append("Could not convert ").append(methodType).append(" argument value of type [")
/* 793 */           .append(ObjectUtils.nullSafeClassName(argValue))
/* 793 */           .append("] to required type [")
/* 794 */           .append(paramType
/* 794 */           .getName()).append("]: ").append(ex.getMessage()).toString());
/*     */       }
/*     */     }
/* 797 */     return resolvedArgs;
/*     */   }
/*     */ 
/*     */   protected Object resolveAutowiredArgument(MethodParameter param, String beanName, Set<String> autowiredBeanNames, TypeConverter typeConverter)
/*     */   {
/* 806 */     return this.beanFactory.resolveDependency(new DependencyDescriptor(param, true), beanName, autowiredBeanNames, typeConverter);
/*     */   }
/*     */ 
/*     */   private static class ConstructorPropertiesChecker
/*     */   {
/*     */     public static String[] evaluateAnnotation(Constructor<?> candidate, int paramCount)
/*     */     {
/* 888 */       ConstructorProperties cp = (ConstructorProperties)candidate.getAnnotation(ConstructorProperties.class);
/* 889 */       if (cp != null) {
/* 890 */         String[] names = cp.value();
/* 891 */         if (names.length != paramCount) {
/* 892 */           throw new IllegalStateException("Constructor annotated with @ConstructorProperties but not corresponding to actual number of parameters (" + paramCount + "): " + candidate);
/*     */         }
/*     */ 
/* 895 */         return names;
/*     */       }
/*     */ 
/* 898 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class AutowiredArgumentMarker
/*     */   {
/*     */   }
/*     */ 
/*     */   private static class ArgumentsHolder
/*     */   {
/*     */     public final Object[] rawArguments;
/*     */     public final Object[] arguments;
/*     */     public final Object[] preparedArguments;
/* 822 */     public boolean resolveNecessary = false;
/*     */ 
/*     */     public ArgumentsHolder(int size) {
/* 825 */       this.rawArguments = new Object[size];
/* 826 */       this.arguments = new Object[size];
/* 827 */       this.preparedArguments = new Object[size];
/*     */     }
/*     */ 
/*     */     public ArgumentsHolder(Object[] args) {
/* 831 */       this.rawArguments = args;
/* 832 */       this.arguments = args;
/* 833 */       this.preparedArguments = args;
/*     */     }
/*     */ 
/*     */     public int getTypeDifferenceWeight(Class<?>[] paramTypes)
/*     */     {
/* 841 */       int typeDiffWeight = MethodInvoker.getTypeDifferenceWeight(paramTypes, this.arguments);
/* 842 */       int rawTypeDiffWeight = MethodInvoker.getTypeDifferenceWeight(paramTypes, this.rawArguments) - 1024;
/* 843 */       return rawTypeDiffWeight < typeDiffWeight ? rawTypeDiffWeight : typeDiffWeight;
/*     */     }
/*     */ 
/*     */     public int getAssignabilityWeight(Class<?>[] paramTypes) {
/* 847 */       for (int i = 0; i < paramTypes.length; i++) {
/* 848 */         if (!ClassUtils.isAssignableValue(paramTypes[i], this.arguments[i])) {
/* 849 */           return 2147483647;
/*     */         }
/*     */       }
/* 852 */       for (int i = 0; i < paramTypes.length; i++) {
/* 853 */         if (!ClassUtils.isAssignableValue(paramTypes[i], this.rawArguments[i])) {
/* 854 */           return 2147483135;
/*     */         }
/*     */       }
/* 857 */       return 2147482623;
/*     */     }
/*     */ 
/*     */     public void storeCache(RootBeanDefinition mbd, Object constructorOrFactoryMethod) {
/* 861 */       synchronized (mbd.constructorArgumentLock) {
/* 862 */         mbd.resolvedConstructorOrFactoryMethod = constructorOrFactoryMethod;
/* 863 */         mbd.constructorArgumentsResolved = true;
/* 864 */         if (this.resolveNecessary) {
/* 865 */           mbd.preparedConstructorArguments = this.preparedArguments;
/*     */         }
/*     */         else
/* 868 */           mbd.resolvedConstructorArguments = this.arguments;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.ConstructorResolver
 * JD-Core Version:    0.6.2
 */