/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.NotSerializableException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.io.Serializable;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import javax.inject.Provider;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.FatalBeanException;
/*      */ import org.springframework.beans.TypeConverter;
/*      */ import org.springframework.beans.factory.BeanCreationException;
/*      */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*      */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*      */ import org.springframework.beans.factory.FactoryBean;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*      */ import org.springframework.beans.factory.ObjectFactory;
/*      */ import org.springframework.beans.factory.SmartFactoryBean;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*      */ import org.springframework.core.annotation.AnnotationUtils;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public class DefaultListableBeanFactory extends AbstractAutowireCapableBeanFactory
/*      */   implements ConfigurableListableBeanFactory, BeanDefinitionRegistry, Serializable
/*      */ {
/*  104 */   private static Class<?> javaxInjectProviderClass = null;
/*      */ 
/*  118 */   private static final Map<String, Reference<DefaultListableBeanFactory>> serializableFactories = new ConcurrentHashMap(8);
/*      */   private String serializationId;
/*  125 */   private boolean allowBeanDefinitionOverriding = true;
/*      */ 
/*  128 */   private boolean allowEagerClassLoading = true;
/*      */   private Comparator<Object> dependencyComparator;
/*  134 */   private AutowireCandidateResolver autowireCandidateResolver = new SimpleAutowireCandidateResolver();
/*      */ 
/*  137 */   private final Map<Class<?>, Object> resolvableDependencies = new HashMap(16);
/*      */ 
/*  140 */   private final Map<String, BeanDefinition> beanDefinitionMap = new ConcurrentHashMap(64);
/*      */ 
/*  143 */   private final Map<Class<?>, String[]> allBeanNamesByType = new ConcurrentHashMap(64);
/*      */ 
/*  146 */   private final Map<Class<?>, String[]> singletonBeanNamesByType = new ConcurrentHashMap(64);
/*      */ 
/*  149 */   private final List<String> beanDefinitionNames = new ArrayList();
/*      */ 
/*  152 */   private boolean configurationFrozen = false;
/*      */   private String[] frozenBeanDefinitionNames;
/*      */ 
/*      */   public DefaultListableBeanFactory()
/*      */   {
/*      */   }
/*      */ 
/*      */   public DefaultListableBeanFactory(BeanFactory parentBeanFactory)
/*      */   {
/*  170 */     super(parentBeanFactory);
/*      */   }
/*      */ 
/*      */   public void setSerializationId(String serializationId)
/*      */   {
/*  179 */     if (serializationId != null) {
/*  180 */       serializableFactories.put(serializationId, new WeakReference(this));
/*      */     }
/*  182 */     else if (this.serializationId != null) {
/*  183 */       serializableFactories.remove(this.serializationId);
/*      */     }
/*  185 */     this.serializationId = serializationId;
/*      */   }
/*      */ 
/*      */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding)
/*      */   {
/*  196 */     this.allowBeanDefinitionOverriding = allowBeanDefinitionOverriding;
/*      */   }
/*      */ 
/*      */   public void setAllowEagerClassLoading(boolean allowEagerClassLoading)
/*      */   {
/*  210 */     this.allowEagerClassLoading = allowEagerClassLoading;
/*      */   }
/*      */ 
/*      */   public void setDependencyComparator(Comparator<Object> dependencyComparator)
/*      */   {
/*  219 */     this.dependencyComparator = dependencyComparator;
/*      */   }
/*      */ 
/*      */   public Comparator<Object> getDependencyComparator()
/*      */   {
/*  226 */     return this.dependencyComparator;
/*      */   }
/*      */ 
/*      */   public void setAutowireCandidateResolver(final AutowireCandidateResolver autowireCandidateResolver)
/*      */   {
/*  235 */     Assert.notNull(autowireCandidateResolver, "AutowireCandidateResolver must not be null");
/*  236 */     if ((autowireCandidateResolver instanceof BeanFactoryAware)) {
/*  237 */       if (System.getSecurityManager() != null) {
/*  238 */         final BeanFactory target = this;
/*  239 */         AccessController.doPrivileged(new PrivilegedAction()
/*      */         {
/*      */           public Object run() {
/*  242 */             ((BeanFactoryAware)autowireCandidateResolver).setBeanFactory(target);
/*  243 */             return null;
/*      */           }
/*      */         }
/*      */         , getAccessControlContext());
/*      */       }
/*      */       else {
/*  248 */         ((BeanFactoryAware)autowireCandidateResolver).setBeanFactory(this);
/*      */       }
/*      */     }
/*  251 */     this.autowireCandidateResolver = autowireCandidateResolver;
/*      */   }
/*      */ 
/*      */   public AutowireCandidateResolver getAutowireCandidateResolver()
/*      */   {
/*  258 */     return this.autowireCandidateResolver;
/*      */   }
/*      */ 
/*      */   public void copyConfigurationFrom(ConfigurableBeanFactory otherFactory)
/*      */   {
/*  264 */     super.copyConfigurationFrom(otherFactory);
/*  265 */     if ((otherFactory instanceof DefaultListableBeanFactory)) {
/*  266 */       DefaultListableBeanFactory otherListableFactory = (DefaultListableBeanFactory)otherFactory;
/*  267 */       this.allowBeanDefinitionOverriding = otherListableFactory.allowBeanDefinitionOverriding;
/*  268 */       this.allowEagerClassLoading = otherListableFactory.allowEagerClassLoading;
/*  269 */       this.autowireCandidateResolver = otherListableFactory.autowireCandidateResolver;
/*  270 */       this.resolvableDependencies.putAll(otherListableFactory.resolvableDependencies);
/*      */     }
/*      */   }
/*      */ 
/*      */   public <T> T getBean(Class<T> requiredType)
/*      */     throws BeansException
/*      */   {
/*  281 */     Assert.notNull(requiredType, "Required type must not be null");
/*  282 */     String[] beanNames = getBeanNamesForType(requiredType);
/*  283 */     if (beanNames.length > 1) {
/*  284 */       ArrayList autowireCandidates = new ArrayList();
/*  285 */       for (String beanName : beanNames) {
/*  286 */         if (getBeanDefinition(beanName).isAutowireCandidate()) {
/*  287 */           autowireCandidates.add(beanName);
/*      */         }
/*      */       }
/*  290 */       if (autowireCandidates.size() > 0) {
/*  291 */         beanNames = (String[])autowireCandidates.toArray(new String[autowireCandidates.size()]);
/*      */       }
/*      */     }
/*  294 */     if (beanNames.length == 1) {
/*  295 */       return getBean(beanNames[0], requiredType);
/*      */     }
/*  297 */     if (beanNames.length > 1) {
/*  298 */       Object primaryBean = null;
/*  299 */       for (String beanName : beanNames) {
/*  300 */         Object beanInstance = getBean(beanName, requiredType);
/*  301 */         if (isPrimary(beanName, beanInstance)) {
/*  302 */           if (primaryBean != null)
/*      */           {
/*  304 */             throw new NoUniqueBeanDefinitionException(requiredType, beanNames.length, new StringBuilder().append("more than one 'primary' bean found of required type: ")
/*  304 */               .append(Arrays.asList(beanNames))
/*  304 */               .toString());
/*      */           }
/*  306 */           primaryBean = beanInstance;
/*      */         }
/*      */       }
/*  309 */       if (primaryBean != null) {
/*  310 */         return primaryBean;
/*      */       }
/*  312 */       throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*      */     }
/*  314 */     if (getParentBeanFactory() != null) {
/*  315 */       return getParentBeanFactory().getBean(requiredType);
/*      */     }
/*      */ 
/*  318 */     throw new NoSuchBeanDefinitionException(requiredType);
/*      */   }
/*      */ 
/*      */   public boolean containsBeanDefinition(String beanName)
/*      */   {
/*  324 */     Assert.notNull(beanName, "Bean name must not be null");
/*  325 */     return this.beanDefinitionMap.containsKey(beanName);
/*      */   }
/*      */ 
/*      */   public int getBeanDefinitionCount()
/*      */   {
/*  330 */     return this.beanDefinitionMap.size();
/*      */   }
/*      */ 
/*      */   public String[] getBeanDefinitionNames()
/*      */   {
/*  335 */     synchronized (this.beanDefinitionMap) {
/*  336 */       if (this.frozenBeanDefinitionNames != null) {
/*  337 */         return this.frozenBeanDefinitionNames;
/*      */       }
/*      */ 
/*  340 */       return StringUtils.toStringArray(this.beanDefinitionNames);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String[] getBeanNamesForType(Class<?> type)
/*      */   {
/*  347 */     return getBeanNamesForType(type, true, true);
/*      */   }
/*      */ 
/*      */   public String[] getBeanNamesForType(Class<?> type, boolean includeNonSingletons, boolean allowEagerInit)
/*      */   {
/*  352 */     if ((!isConfigurationFrozen()) || (type == null) || (!allowEagerInit)) {
/*  353 */       return doGetBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*      */     }
/*  355 */     Map cache = includeNonSingletons ? this.allBeanNamesByType : this.singletonBeanNamesByType;
/*      */ 
/*  357 */     String[] resolvedBeanNames = (String[])cache.get(type);
/*  358 */     if (resolvedBeanNames != null) {
/*  359 */       return resolvedBeanNames;
/*      */     }
/*  361 */     resolvedBeanNames = doGetBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*  362 */     cache.put(type, resolvedBeanNames);
/*  363 */     return resolvedBeanNames;
/*      */   }
/*      */ 
/*      */   private String[] doGetBeanNamesForType(Class<?> type, boolean includeNonSingletons, boolean allowEagerInit) {
/*  367 */     List result = new ArrayList();
/*      */ 
/*  370 */     String[] beanDefinitionNames = getBeanDefinitionNames();
/*  371 */     String[] arrayOfString1 = beanDefinitionNames; int i = arrayOfString1.length; for (String str1 = 0; str1 < i; str1++) { beanName = arrayOfString1[str1];
/*      */ 
/*  374 */       if (!isAlias(beanName)) {
/*      */         try {
/*  376 */           RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*      */ 
/*  378 */           if ((!mbd.isAbstract()) && ((allowEagerInit) || (
/*  379 */             ((mbd
/*  379 */             .hasBeanClass()) || (!mbd.isLazyInit()) || (this.allowEagerClassLoading)) && 
/*  380 */             (!requiresEagerInitForType(mbd
/*  380 */             .getFactoryBeanName())))))
/*      */           {
/*  382 */             boolean isFactoryBean = isFactoryBean(beanName, mbd);
/*      */ 
/*  384 */             boolean matchFound = ((allowEagerInit) || (!isFactoryBean) || (containsSingleton(beanName))) && ((includeNonSingletons) || 
/*  384 */               (isSingleton(beanName))) && 
/*  384 */               (isTypeMatch(beanName, type));
/*  385 */             if ((!matchFound) && (isFactoryBean))
/*      */             {
/*  387 */               beanName = new StringBuilder().append("&").append(beanName).toString();
/*  388 */               matchFound = ((includeNonSingletons) || (mbd.isSingleton())) && (isTypeMatch(beanName, type));
/*      */             }
/*  390 */             if (matchFound)
/*  391 */               result.add(beanName);
/*      */           }
/*      */         }
/*      */         catch (CannotLoadBeanClassException ex)
/*      */         {
/*  396 */           if (allowEagerInit) {
/*  397 */             throw ex;
/*      */           }
/*      */ 
/*  400 */           if (this.logger.isDebugEnabled()) {
/*  401 */             this.logger.debug(new StringBuilder().append("Ignoring bean class loading failure for bean '").append(beanName).append("'").toString(), ex);
/*      */           }
/*  403 */           onSuppressedException(ex);
/*      */         }
/*      */         catch (BeanDefinitionStoreException ex) {
/*  406 */           if (allowEagerInit) {
/*  407 */             throw ex;
/*      */           }
/*      */ 
/*  410 */           if (this.logger.isDebugEnabled()) {
/*  411 */             this.logger.debug(new StringBuilder().append("Ignoring unresolvable metadata in bean definition '").append(beanName).append("'").toString(), ex);
/*      */           }
/*  413 */           onSuppressedException(ex);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  419 */     String[] singletonNames = getSingletonNames();
/*  420 */     String[] arrayOfString2 = singletonNames; str1 = arrayOfString2.length; for (String beanName = 0; beanName < str1; beanName++) { String beanName = arrayOfString2[beanName];
/*      */ 
/*  422 */       if (!containsBeanDefinition(beanName))
/*      */       {
/*  424 */         if (isFactoryBean(beanName)) {
/*  425 */           if (((includeNonSingletons) || (isSingleton(beanName))) && (isTypeMatch(beanName, type))) {
/*  426 */             result.add(beanName);
/*      */           }
/*      */           else
/*      */           {
/*  431 */             beanName = new StringBuilder().append("&").append(beanName).toString();
/*      */           }
/*      */         }
/*  434 */         else if (isTypeMatch(beanName, type)) {
/*  435 */           result.add(beanName);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  440 */     return StringUtils.toStringArray(result);
/*      */   }
/*      */ 
/*      */   private boolean requiresEagerInitForType(String factoryBeanName)
/*      */   {
/*  451 */     return (factoryBeanName != null) && (isFactoryBean(factoryBeanName)) && (!containsSingleton(factoryBeanName));
/*      */   }
/*      */ 
/*      */   public <T> Map<String, T> getBeansOfType(Class<T> type) throws BeansException
/*      */   {
/*  456 */     return getBeansOfType(type, true, true);
/*      */   }
/*      */ 
/*      */   public <T> Map<String, T> getBeansOfType(Class<T> type, boolean includeNonSingletons, boolean allowEagerInit)
/*      */     throws BeansException
/*      */   {
/*  463 */     String[] beanNames = getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*  464 */     Map result = new LinkedHashMap(beanNames.length);
/*  465 */     for (String beanName : beanNames) {
/*      */       try {
/*  467 */         result.put(beanName, getBean(beanName, type));
/*      */       }
/*      */       catch (BeanCreationException ex) {
/*  470 */         Throwable rootCause = ex.getMostSpecificCause();
/*  471 */         if ((rootCause instanceof BeanCurrentlyInCreationException)) {
/*  472 */           BeanCreationException bce = (BeanCreationException)rootCause;
/*  473 */           if (isCurrentlyInCreation(bce.getBeanName())) {
/*  474 */             if (this.logger.isDebugEnabled()) {
/*  475 */               this.logger.debug(new StringBuilder().append("Ignoring match to currently created bean '").append(beanName).append("': ")
/*  476 */                 .append(ex
/*  476 */                 .getMessage()).toString());
/*      */             }
/*  478 */             onSuppressedException(ex);
/*      */ 
/*  481 */             continue;
/*      */           }
/*      */         }
/*  484 */         throw ex;
/*      */       }
/*      */     }
/*  487 */     return result;
/*      */   }
/*      */ 
/*      */   public String[] getBeanNamesForAnnotation(Class<? extends Annotation> annotationType)
/*      */   {
/*  492 */     List results = new ArrayList();
/*  493 */     for (String beanName : getBeanDefinitionNames()) {
/*  494 */       BeanDefinition beanDefinition = getBeanDefinition(beanName);
/*  495 */       if ((!beanDefinition.isAbstract()) && (findAnnotationOnBean(beanName, annotationType) != null)) {
/*  496 */         results.add(beanName);
/*      */       }
/*      */     }
/*  499 */     for (String beanName : getSingletonNames()) {
/*  500 */       if ((!results.contains(beanName)) && (findAnnotationOnBean(beanName, annotationType) != null)) {
/*  501 */         results.add(beanName);
/*      */       }
/*      */     }
/*  504 */     return (String[])results.toArray(new String[results.size()]);
/*      */   }
/*      */ 
/*      */   public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> annotationType)
/*      */   {
/*  509 */     Map results = new LinkedHashMap();
/*  510 */     for (String beanName : getBeanDefinitionNames()) {
/*  511 */       BeanDefinition beanDefinition = getBeanDefinition(beanName);
/*  512 */       if ((!beanDefinition.isAbstract()) && (findAnnotationOnBean(beanName, annotationType) != null)) {
/*  513 */         results.put(beanName, getBean(beanName));
/*      */       }
/*      */     }
/*  516 */     for (String beanName : getSingletonNames()) {
/*  517 */       if ((!results.containsKey(beanName)) && (findAnnotationOnBean(beanName, annotationType) != null)) {
/*  518 */         results.put(beanName, getBean(beanName));
/*      */       }
/*      */     }
/*  521 */     return results;
/*      */   }
/*      */ 
/*      */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/*  534 */     Annotation ann = null;
/*  535 */     Class beanType = getType(beanName);
/*  536 */     if (beanType != null) {
/*  537 */       ann = AnnotationUtils.findAnnotation(beanType, annotationType);
/*      */     }
/*  539 */     if ((ann == null) && (containsBeanDefinition(beanName))) {
/*  540 */       BeanDefinition bd = getMergedBeanDefinition(beanName);
/*  541 */       if ((bd instanceof AbstractBeanDefinition)) {
/*  542 */         AbstractBeanDefinition abd = (AbstractBeanDefinition)bd;
/*  543 */         if (abd.hasBeanClass()) {
/*  544 */           ann = AnnotationUtils.findAnnotation(abd.getBeanClass(), annotationType);
/*      */         }
/*      */       }
/*      */     }
/*  548 */     return ann;
/*      */   }
/*      */ 
/*      */   public void registerResolvableDependency(Class<?> dependencyType, Object autowiredValue)
/*      */   {
/*  558 */     Assert.notNull(dependencyType, "Type must not be null");
/*  559 */     if (autowiredValue != null) {
/*  560 */       Assert.isTrue(((autowiredValue instanceof ObjectFactory)) || (dependencyType.isInstance(autowiredValue)), new StringBuilder().append("Value [").append(autowiredValue).append("] does not implement specified type [")
/*  561 */         .append(dependencyType
/*  561 */         .getName()).append("]").toString());
/*  562 */       this.resolvableDependencies.put(dependencyType, autowiredValue);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isAutowireCandidate(String beanName, DependencyDescriptor descriptor)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/*  570 */     return isAutowireCandidate(beanName, descriptor, getAutowireCandidateResolver());
/*      */   }
/*      */ 
/*      */   protected boolean isAutowireCandidate(String beanName, DependencyDescriptor descriptor, AutowireCandidateResolver resolver)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/*  584 */     String beanDefinitionName = BeanFactoryUtils.transformedBeanName(beanName);
/*  585 */     if (containsBeanDefinition(beanDefinitionName)) {
/*  586 */       return isAutowireCandidate(beanName, getMergedLocalBeanDefinition(beanDefinitionName), descriptor, resolver);
/*      */     }
/*  588 */     if (containsSingleton(beanName)) {
/*  589 */       return isAutowireCandidate(beanName, new RootBeanDefinition(getType(beanName)), descriptor, resolver);
/*      */     }
/*  591 */     if ((getParentBeanFactory() instanceof DefaultListableBeanFactory))
/*      */     {
/*  593 */       return ((DefaultListableBeanFactory)getParentBeanFactory()).isAutowireCandidate(beanName, descriptor, resolver);
/*      */     }
/*  595 */     if ((getParentBeanFactory() instanceof Serializable))
/*      */     {
/*  597 */       return ((Serializable)getParentBeanFactory()).isAutowireCandidate(beanName, descriptor);
/*      */     }
/*      */ 
/*  600 */     return true;
/*      */   }
/*      */ 
/*      */   protected boolean isAutowireCandidate(String beanName, RootBeanDefinition mbd, DependencyDescriptor descriptor, AutowireCandidateResolver resolver)
/*      */   {
/*  616 */     String beanDefinitionName = BeanFactoryUtils.transformedBeanName(beanName);
/*  617 */     resolveBeanClass(mbd, beanDefinitionName, new Class[0]);
/*  618 */     if (mbd.isFactoryMethodUnique)
/*      */     {
/*      */       boolean resolve;
/*  620 */       synchronized (mbd.constructorArgumentLock) {
/*  621 */         resolve = mbd.resolvedConstructorOrFactoryMethod == null;
/*      */       }
/*  623 */       if (resolve) {
/*  624 */         new ConstructorResolver(this).resolveFactoryMethodIfPossible(mbd);
/*      */       }
/*      */     }
/*  627 */     return resolver.isAutowireCandidate(new BeanDefinitionHolder(mbd, beanName, 
/*  628 */       getAliases(beanDefinitionName)), 
/*  628 */       descriptor);
/*      */   }
/*      */ 
/*      */   public BeanDefinition getBeanDefinition(String beanName) throws NoSuchBeanDefinitionException
/*      */   {
/*  633 */     BeanDefinition bd = (BeanDefinition)this.beanDefinitionMap.get(beanName);
/*  634 */     if (bd == null) {
/*  635 */       if (this.logger.isTraceEnabled()) {
/*  636 */         this.logger.trace(new StringBuilder().append("No bean named '").append(beanName).append("' found in ").append(this).toString());
/*      */       }
/*  638 */       throw new NoSuchBeanDefinitionException(beanName);
/*      */     }
/*  640 */     return bd;
/*      */   }
/*      */ 
/*      */   public void freezeConfiguration()
/*      */   {
/*  645 */     this.configurationFrozen = true;
/*  646 */     synchronized (this.beanDefinitionMap) {
/*  647 */       this.frozenBeanDefinitionNames = StringUtils.toStringArray(this.beanDefinitionNames);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isConfigurationFrozen()
/*      */   {
/*  653 */     return this.configurationFrozen;
/*      */   }
/*      */ 
/*      */   protected boolean isBeanEligibleForMetadataCaching(String beanName)
/*      */   {
/*  663 */     return (this.configurationFrozen) || (super.isBeanEligibleForMetadataCaching(beanName));
/*      */   }
/*      */ 
/*      */   public void preInstantiateSingletons() throws BeansException
/*      */   {
/*  668 */     if (this.logger.isDebugEnabled())
/*  669 */       this.logger.debug(new StringBuilder().append("Pre-instantiating singletons in ").append(this).toString());
/*      */     List beanNames;
/*  672 */     synchronized (this.beanDefinitionMap)
/*      */     {
/*  675 */       beanNames = new ArrayList(this.beanDefinitionNames);
/*      */     }
/*  677 */     for (??? = beanNames.iterator(); ???.hasNext(); ) { String beanName = (String)???.next();
/*  678 */       RootBeanDefinition bd = getMergedLocalBeanDefinition(beanName);
/*  679 */       if ((!bd.isAbstract()) && (bd.isSingleton()) && (!bd.isLazyInit()))
/*  680 */         if (isFactoryBean(beanName)) {
/*  681 */           final FactoryBean factory = (FactoryBean)getBean(new StringBuilder().append("&").append(beanName).toString());
/*      */           boolean isEagerInit;
/*      */           boolean isEagerInit;
/*  683 */           if ((System.getSecurityManager() != null) && ((factory instanceof SmartFactoryBean))) {
/*  684 */             isEagerInit = ((Boolean)AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               public Boolean run() {
/*  687 */                 return Boolean.valueOf(((SmartFactoryBean)factory).isEagerInit());
/*      */               }
/*      */             }
/*      */             , getAccessControlContext())).booleanValue();
/*      */           }
/*      */           else
/*      */           {
/*  693 */             isEagerInit = ((factory instanceof SmartFactoryBean)) && 
/*  693 */               (((SmartFactoryBean)factory)
/*  693 */               .isEagerInit());
/*      */           }
/*  695 */           if (isEagerInit)
/*  696 */             getBean(beanName);
/*      */         }
/*      */         else
/*      */         {
/*  700 */           getBean(beanName);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerBeanDefinition(String beanName, BeanDefinition beanDefinition)
/*      */     throws BeanDefinitionStoreException
/*      */   {
/*  715 */     Assert.hasText(beanName, "Bean name must not be empty");
/*  716 */     Assert.notNull(beanDefinition, "BeanDefinition must not be null");
/*      */ 
/*  718 */     if ((beanDefinition instanceof AbstractBeanDefinition)) {
/*      */       try {
/*  720 */         ((AbstractBeanDefinition)beanDefinition).validate();
/*      */       }
/*      */       catch (BeanDefinitionValidationException ex) {
/*  723 */         throw new BeanDefinitionStoreException(beanDefinition.getResourceDescription(), beanName, "Validation of bean definition failed", ex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  728 */     synchronized (this.beanDefinitionMap) {
/*  729 */       BeanDefinition oldBeanDefinition = (BeanDefinition)this.beanDefinitionMap.get(beanName);
/*  730 */       if (oldBeanDefinition != null) {
/*  731 */         if (!this.allowBeanDefinitionOverriding) {
/*  732 */           throw new BeanDefinitionStoreException(beanDefinition.getResourceDescription(), beanName, new StringBuilder().append("Cannot register bean definition [").append(beanDefinition).append("] for bean '").append(beanName).append("': There is already [").append(oldBeanDefinition).append("] bound.").toString());
/*      */         }
/*      */ 
/*  736 */         if (oldBeanDefinition.getRole() < beanDefinition.getRole())
/*      */         {
/*  738 */           if (this.logger.isWarnEnabled()) {
/*  739 */             this.logger.warn(new StringBuilder().append("Overriding user-defined bean definition for bean '").append(beanName).append(" with a framework-generated bean definition ': replacing [").append(oldBeanDefinition).append("] with [").append(beanDefinition).append("]").toString());
/*      */           }
/*      */ 
/*      */         }
/*  745 */         else if (this.logger.isInfoEnabled()) {
/*  746 */           this.logger.info(new StringBuilder().append("Overriding bean definition for bean '").append(beanName).append("': replacing [").append(oldBeanDefinition).append("] with [").append(beanDefinition).append("]").toString());
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  752 */         this.beanDefinitionNames.add(beanName);
/*  753 */         this.frozenBeanDefinitionNames = null;
/*      */       }
/*  755 */       this.beanDefinitionMap.put(beanName, beanDefinition);
/*      */     }
/*      */ 
/*  758 */     resetBeanDefinition(beanName);
/*      */   }
/*      */ 
/*      */   public void removeBeanDefinition(String beanName) throws NoSuchBeanDefinitionException
/*      */   {
/*  763 */     Assert.hasText(beanName, "'beanName' must not be empty");
/*      */ 
/*  765 */     synchronized (this.beanDefinitionMap) {
/*  766 */       BeanDefinition bd = (BeanDefinition)this.beanDefinitionMap.remove(beanName);
/*  767 */       if (bd == null) {
/*  768 */         if (this.logger.isTraceEnabled()) {
/*  769 */           this.logger.trace(new StringBuilder().append("No bean named '").append(beanName).append("' found in ").append(this).toString());
/*      */         }
/*  771 */         throw new NoSuchBeanDefinitionException(beanName);
/*      */       }
/*  773 */       this.beanDefinitionNames.remove(beanName);
/*  774 */       this.frozenBeanDefinitionNames = null;
/*      */     }
/*      */ 
/*  777 */     resetBeanDefinition(beanName);
/*      */   }
/*      */ 
/*      */   protected void resetBeanDefinition(String beanName)
/*      */   {
/*  787 */     clearMergedBeanDefinition(beanName);
/*      */ 
/*  792 */     destroySingleton(beanName);
/*      */ 
/*  795 */     clearByTypeCache();
/*      */ 
/*  798 */     for (String bdName : this.beanDefinitionNames)
/*  799 */       if (!beanName.equals(bdName)) {
/*  800 */         BeanDefinition bd = (BeanDefinition)this.beanDefinitionMap.get(bdName);
/*  801 */         if (beanName.equals(bd.getParentName()))
/*  802 */           resetBeanDefinition(bdName);
/*      */       }
/*      */   }
/*      */ 
/*      */   protected boolean allowAliasOverriding()
/*      */   {
/*  813 */     return this.allowBeanDefinitionOverriding;
/*      */   }
/*      */ 
/*      */   public void registerSingleton(String beanName, Object singletonObject) throws IllegalStateException
/*      */   {
/*  818 */     super.registerSingleton(beanName, singletonObject);
/*  819 */     clearByTypeCache();
/*      */   }
/*      */ 
/*      */   public void destroySingleton(String beanName)
/*      */   {
/*  824 */     super.destroySingleton(beanName);
/*  825 */     clearByTypeCache();
/*      */   }
/*      */ 
/*      */   private void clearByTypeCache()
/*      */   {
/*  832 */     this.allBeanNamesByType.clear();
/*  833 */     this.singletonBeanNamesByType.clear();
/*      */   }
/*      */ 
/*      */   public Object resolveDependency(DependencyDescriptor descriptor, String beanName, Set<String> autowiredBeanNames, TypeConverter typeConverter)
/*      */     throws BeansException
/*      */   {
/*  845 */     descriptor.initParameterNameDiscovery(getParameterNameDiscoverer());
/*  846 */     if (descriptor.getDependencyType().equals(ObjectFactory.class)) {
/*  847 */       return new DependencyObjectFactory(descriptor, beanName);
/*      */     }
/*  849 */     if (descriptor.getDependencyType().equals(javaxInjectProviderClass)) {
/*  850 */       return new DependencyProviderFactory(null).createDependencyProvider(descriptor, beanName);
/*      */     }
/*      */ 
/*  853 */     Object result = getAutowireCandidateResolver().getLazyResolutionProxyIfNecessary(descriptor, beanName);
/*  854 */     if (result == null) {
/*  855 */       result = doResolveDependency(descriptor, beanName, autowiredBeanNames, typeConverter);
/*      */     }
/*  857 */     return result;
/*      */   }
/*      */ 
/*      */   public Object doResolveDependency(DependencyDescriptor descriptor, String beanName, Set<String> autowiredBeanNames, TypeConverter typeConverter)
/*      */     throws BeansException
/*      */   {
/*  864 */     Class type = descriptor.getDependencyType();
/*  865 */     Object value = getAutowireCandidateResolver().getSuggestedValue(descriptor);
/*  866 */     if (value != null) {
/*  867 */       if ((value instanceof String)) {
/*  868 */         String strVal = resolveEmbeddedValue((String)value);
/*  869 */         BeanDefinition bd = (beanName != null) && (containsBean(beanName)) ? getMergedBeanDefinition(beanName) : null;
/*  870 */         value = evaluateBeanDefinitionString(strVal, bd);
/*      */       }
/*  872 */       TypeConverter converter = typeConverter != null ? typeConverter : getTypeConverter();
/*      */ 
/*  875 */       return descriptor.getField() != null ? converter
/*  874 */         .convertIfNecessary(value, type, descriptor
/*  874 */         .getField()) : converter
/*  875 */         .convertIfNecessary(value, type, descriptor
/*  875 */         .getMethodParameter());
/*      */     }
/*      */ 
/*  878 */     if (type.isArray()) {
/*  879 */       Class componentType = type.getComponentType();
/*  880 */       DependencyDescriptor targetDesc = new DependencyDescriptor(descriptor);
/*  881 */       targetDesc.increaseNestingLevel();
/*  882 */       Map matchingBeans = findAutowireCandidates(beanName, componentType, targetDesc);
/*  883 */       if (matchingBeans.isEmpty()) {
/*  884 */         if (descriptor.isRequired()) {
/*  885 */           raiseNoSuchBeanDefinitionException(componentType, new StringBuilder().append("array of ").append(componentType.getName()).toString(), descriptor);
/*      */         }
/*  887 */         return null;
/*      */       }
/*  889 */       if (autowiredBeanNames != null) {
/*  890 */         autowiredBeanNames.addAll(matchingBeans.keySet());
/*      */       }
/*  892 */       TypeConverter converter = typeConverter != null ? typeConverter : getTypeConverter();
/*  893 */       Object result = converter.convertIfNecessary(matchingBeans.values(), type);
/*  894 */       if ((this.dependencyComparator != null) && ((result instanceof Object[]))) {
/*  895 */         Arrays.sort((Object[])result, this.dependencyComparator);
/*      */       }
/*  897 */       return result;
/*      */     }
/*  899 */     if ((Collection.class.isAssignableFrom(type)) && (type.isInterface())) {
/*  900 */       Class elementType = descriptor.getCollectionType();
/*  901 */       if (elementType == null) {
/*  902 */         if (descriptor.isRequired()) {
/*  903 */           throw new FatalBeanException(new StringBuilder().append("No element type declared for collection [").append(type.getName()).append("]").toString());
/*      */         }
/*  905 */         return null;
/*      */       }
/*  907 */       DependencyDescriptor targetDesc = new DependencyDescriptor(descriptor);
/*  908 */       targetDesc.increaseNestingLevel();
/*  909 */       Map matchingBeans = findAutowireCandidates(beanName, elementType, targetDesc);
/*  910 */       if (matchingBeans.isEmpty()) {
/*  911 */         if (descriptor.isRequired()) {
/*  912 */           raiseNoSuchBeanDefinitionException(elementType, new StringBuilder().append("collection of ").append(elementType.getName()).toString(), descriptor);
/*      */         }
/*  914 */         return null;
/*      */       }
/*  916 */       if (autowiredBeanNames != null) {
/*  917 */         autowiredBeanNames.addAll(matchingBeans.keySet());
/*      */       }
/*  919 */       TypeConverter converter = typeConverter != null ? typeConverter : getTypeConverter();
/*  920 */       Object result = converter.convertIfNecessary(matchingBeans.values(), type);
/*  921 */       if ((this.dependencyComparator != null) && ((result instanceof List))) {
/*  922 */         Collections.sort((List)result, this.dependencyComparator);
/*      */       }
/*  924 */       return result;
/*      */     }
/*  926 */     if ((Map.class.isAssignableFrom(type)) && (type.isInterface())) {
/*  927 */       Class keyType = descriptor.getMapKeyType();
/*  928 */       if ((keyType == null) || (!String.class.isAssignableFrom(keyType))) {
/*  929 */         if (descriptor.isRequired()) {
/*  930 */           throw new FatalBeanException(new StringBuilder().append("Key type [").append(keyType).append("] of map [").append(type.getName()).append("] must be assignable to [java.lang.String]").toString());
/*      */         }
/*      */ 
/*  933 */         return null;
/*      */       }
/*  935 */       Class valueType = descriptor.getMapValueType();
/*  936 */       if (valueType == null) {
/*  937 */         if (descriptor.isRequired()) {
/*  938 */           throw new FatalBeanException(new StringBuilder().append("No value type declared for map [").append(type.getName()).append("]").toString());
/*      */         }
/*  940 */         return null;
/*      */       }
/*  942 */       DependencyDescriptor targetDesc = new DependencyDescriptor(descriptor);
/*  943 */       targetDesc.increaseNestingLevel();
/*  944 */       Map matchingBeans = findAutowireCandidates(beanName, valueType, targetDesc);
/*  945 */       if (matchingBeans.isEmpty()) {
/*  946 */         if (descriptor.isRequired()) {
/*  947 */           raiseNoSuchBeanDefinitionException(valueType, new StringBuilder().append("map with value type ").append(valueType.getName()).toString(), descriptor);
/*      */         }
/*  949 */         return null;
/*      */       }
/*  951 */       if (autowiredBeanNames != null) {
/*  952 */         autowiredBeanNames.addAll(matchingBeans.keySet());
/*      */       }
/*  954 */       return matchingBeans;
/*      */     }
/*      */ 
/*  957 */     Map matchingBeans = findAutowireCandidates(beanName, type, descriptor);
/*  958 */     if (matchingBeans.isEmpty()) {
/*  959 */       if (descriptor.isRequired()) {
/*  960 */         raiseNoSuchBeanDefinitionException(type, "", descriptor);
/*      */       }
/*  962 */       return null;
/*      */     }
/*  964 */     if (matchingBeans.size() > 1) {
/*  965 */       String primaryBeanName = determinePrimaryCandidate(matchingBeans, descriptor);
/*  966 */       if (primaryBeanName == null) {
/*  967 */         throw new NoUniqueBeanDefinitionException(type, matchingBeans.keySet());
/*      */       }
/*  969 */       if (autowiredBeanNames != null) {
/*  970 */         autowiredBeanNames.add(primaryBeanName);
/*      */       }
/*  972 */       return matchingBeans.get(primaryBeanName);
/*      */     }
/*      */ 
/*  975 */     Map.Entry entry = (Map.Entry)matchingBeans.entrySet().iterator().next();
/*  976 */     if (autowiredBeanNames != null) {
/*  977 */       autowiredBeanNames.add(entry.getKey());
/*      */     }
/*  979 */     return entry.getValue();
/*      */   }
/*      */ 
/*      */   protected Map<String, Object> findAutowireCandidates(String beanName, Class<?> requiredType, DependencyDescriptor descriptor)
/*      */   {
/*  999 */     String[] candidateNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this, requiredType, true, descriptor
/* 1000 */       .isEager());
/* 1001 */     Map result = new LinkedHashMap(candidateNames.length);
/* 1002 */     for (Object localObject1 = this.resolvableDependencies.keySet().iterator(); ((Iterator)localObject1).hasNext(); ) { autowiringType = (Class)((Iterator)localObject1).next();
/* 1003 */       if (autowiringType.isAssignableFrom(requiredType)) {
/* 1004 */         autowiringValue = this.resolvableDependencies.get(autowiringType);
/* 1005 */         autowiringValue = AutowireUtils.resolveAutowiringValue(autowiringValue, requiredType);
/* 1006 */         if (requiredType.isInstance(autowiringValue)) {
/* 1007 */           result.put(ObjectUtils.identityToString(autowiringValue), autowiringValue);
/* 1008 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1012 */     localObject1 = candidateNames; Class autowiringType = localObject1.length;
/*      */     String candidateName;
/* 1012 */     for (Object autowiringValue = 0; autowiringValue < autowiringType; autowiringValue++) { candidateName = localObject1[autowiringValue];
/* 1013 */       if ((!candidateName.equals(beanName)) && (isAutowireCandidate(candidateName, descriptor))) {
/* 1014 */         result.put(candidateName, getBean(candidateName));
/*      */       }
/*      */     }
/* 1017 */     if (result.isEmpty()) {
/* 1018 */       DependencyDescriptor fallbackDescriptor = descriptor.forFallbackMatch();
/* 1019 */       autowiringType = candidateNames; autowiringValue = autowiringType.length; for (candidateName = 0; candidateName < autowiringValue; candidateName++) { String candidateName = autowiringType[candidateName];
/* 1020 */         if ((!candidateName.equals(beanName)) && (isAutowireCandidate(candidateName, fallbackDescriptor))) {
/* 1021 */           result.put(candidateName, getBean(candidateName));
/*      */         }
/*      */       }
/*      */     }
/* 1025 */     return result;
/*      */   }
/*      */ 
/*      */   protected String determinePrimaryCandidate(Map<String, Object> candidateBeans, DependencyDescriptor descriptor)
/*      */   {
/* 1036 */     String primaryBeanName = null;
/* 1037 */     String fallbackBeanName = null;
/* 1038 */     for (Map.Entry entry : candidateBeans.entrySet()) {
/* 1039 */       String candidateBeanName = (String)entry.getKey();
/* 1040 */       Object beanInstance = entry.getValue();
/* 1041 */       if (isPrimary(candidateBeanName, beanInstance)) {
/* 1042 */         if (primaryBeanName != null) {
/* 1043 */           boolean candidateLocal = containsBeanDefinition(candidateBeanName);
/* 1044 */           boolean primaryLocal = containsBeanDefinition(primaryBeanName);
/* 1045 */           if (candidateLocal == primaryLocal)
/*      */           {
/* 1047 */             throw new NoUniqueBeanDefinitionException(descriptor.getDependencyType(), candidateBeans.size(), new StringBuilder().append("more than one 'primary' bean found among candidates: ")
/* 1047 */               .append(candidateBeans
/* 1047 */               .keySet()).toString());
/*      */           }
/* 1049 */           if ((candidateLocal) && (!primaryLocal))
/* 1050 */             primaryBeanName = candidateBeanName;
/*      */         }
/*      */         else
/*      */         {
/* 1054 */           primaryBeanName = candidateBeanName;
/*      */         }
/*      */       }
/* 1057 */       if ((primaryBeanName == null) && (
/* 1058 */         (this.resolvableDependencies
/* 1058 */         .values().contains(beanInstance)) || 
/* 1059 */         (matchesBeanName(candidateBeanName, descriptor
/* 1059 */         .getDependencyName())))) {
/* 1060 */         fallbackBeanName = candidateBeanName;
/*      */       }
/*      */     }
/* 1063 */     return primaryBeanName != null ? primaryBeanName : fallbackBeanName;
/*      */   }
/*      */ 
/*      */   protected boolean isPrimary(String beanName, Object beanInstance)
/*      */   {
/* 1074 */     if (containsBeanDefinition(beanName)) {
/* 1075 */       return getMergedLocalBeanDefinition(beanName).isPrimary();
/*      */     }
/* 1077 */     BeanFactory parentFactory = getParentBeanFactory();
/*      */ 
/* 1079 */     return ((parentFactory instanceof DefaultListableBeanFactory)) && 
/* 1079 */       (((DefaultListableBeanFactory)parentFactory)
/* 1079 */       .isPrimary(beanName, beanInstance));
/*      */   }
/*      */ 
/*      */   protected boolean matchesBeanName(String beanName, String candidateName)
/*      */   {
/* 1088 */     return (candidateName != null) && (
/* 1088 */       (candidateName
/* 1088 */       .equals(beanName)) || 
/* 1088 */       (ObjectUtils.containsElement(getAliases(beanName), candidateName)));
/*      */   }
/*      */ 
/*      */   private void raiseNoSuchBeanDefinitionException(Class<?> type, String dependencyDescription, DependencyDescriptor descriptor)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/* 1100 */     throw new NoSuchBeanDefinitionException(type, dependencyDescription, new StringBuilder().append("expected at least 1 bean which qualifies as autowire candidate for this dependency. Dependency annotations: ")
/* 1100 */       .append(ObjectUtils.nullSafeToString(descriptor
/* 1100 */       .getAnnotations())).toString());
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1106 */     StringBuilder sb = new StringBuilder(ObjectUtils.identityToString(this));
/* 1107 */     sb.append(": defining beans [");
/* 1108 */     sb.append(StringUtils.arrayToCommaDelimitedString(getBeanDefinitionNames()));
/* 1109 */     sb.append("]; ");
/* 1110 */     BeanFactory parent = getParentBeanFactory();
/* 1111 */     if (parent == null) {
/* 1112 */       sb.append("root of factory hierarchy");
/*      */     }
/*      */     else {
/* 1115 */       sb.append("parent: ").append(ObjectUtils.identityToString(parent));
/*      */     }
/* 1117 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private void readObject(ObjectInputStream ois)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1126 */     throw new NotSerializableException("DefaultListableBeanFactory itself is not deserializable - just a SerializedBeanFactoryReference is");
/*      */   }
/*      */ 
/*      */   protected Object writeReplace() throws ObjectStreamException
/*      */   {
/* 1131 */     if (this.serializationId != null) {
/* 1132 */       return new SerializedBeanFactoryReference(this.serializationId);
/*      */     }
/*      */ 
/* 1135 */     throw new NotSerializableException("DefaultListableBeanFactory has no serialization id");
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  107 */     ClassLoader cl = DefaultListableBeanFactory.class.getClassLoader();
/*      */     try {
/*  109 */       javaxInjectProviderClass = cl.loadClass("javax.inject.Provider");
/*      */     }
/*      */     catch (ClassNotFoundException ex)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   private class DependencyProviderFactory
/*      */   {
/*      */     private DependencyProviderFactory()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Object createDependencyProvider(DependencyDescriptor descriptor, String beanName)
/*      */     {
/* 1212 */       return new DefaultListableBeanFactory.DependencyProvider(DefaultListableBeanFactory.this, descriptor, beanName);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class DependencyProvider extends DefaultListableBeanFactory.DependencyObjectFactory
/*      */     implements Provider<Object>
/*      */   {
/*      */     public DependencyProvider(DependencyDescriptor descriptor, String beanName)
/*      */     {
/* 1196 */       super(descriptor, beanName);
/*      */     }
/*      */ 
/*      */     public Object get() throws BeansException
/*      */     {
/* 1201 */       return getObject();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class DependencyObjectFactory
/*      */     implements ObjectFactory<Object>, Serializable
/*      */   {
/*      */     private final DependencyDescriptor descriptor;
/*      */     private final String beanName;
/*      */ 
/*      */     public DependencyObjectFactory(DependencyDescriptor descriptor, String beanName)
/*      */     {
/* 1178 */       this.descriptor = new DependencyDescriptor(descriptor);
/* 1179 */       this.descriptor.increaseNestingLevel();
/* 1180 */       this.beanName = beanName;
/*      */     }
/*      */ 
/*      */     public Object getObject() throws BeansException
/*      */     {
/* 1185 */       return DefaultListableBeanFactory.this.doResolveDependency(this.descriptor, this.beanName, null, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SerializedBeanFactoryReference
/*      */     implements Serializable
/*      */   {
/*      */     private final String id;
/*      */ 
/*      */     public SerializedBeanFactoryReference(String id)
/*      */     {
/* 1149 */       this.id = id;
/*      */     }
/*      */ 
/*      */     private Object readResolve() {
/* 1153 */       Reference ref = (Reference)DefaultListableBeanFactory.serializableFactories.get(this.id);
/* 1154 */       if (ref == null) {
/* 1155 */         throw new IllegalStateException("Cannot deserialize BeanFactory with id " + this.id + ": no factory registered for this id");
/*      */       }
/*      */ 
/* 1158 */       Object result = ref.get();
/* 1159 */       if (result == null) {
/* 1160 */         throw new IllegalStateException("Cannot deserialize BeanFactory with id " + this.id + ": factory has been garbage-collected");
/*      */       }
/*      */ 
/* 1163 */       return result;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.DefaultListableBeanFactory
 * JD-Core Version:    0.6.2
 */