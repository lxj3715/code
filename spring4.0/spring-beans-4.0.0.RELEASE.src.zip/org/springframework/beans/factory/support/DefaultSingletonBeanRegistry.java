/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCreationNotAllowedException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.SingletonBeanRegistry;
/*     */ import org.springframework.core.SimpleAliasRegistry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class DefaultSingletonBeanRegistry extends SimpleAliasRegistry
/*     */   implements SingletonBeanRegistry
/*     */ {
/*  78 */   protected static final Object NULL_OBJECT = new Object();
/*     */ 
/*  82 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  85 */   private final Map<String, Object> singletonObjects = new ConcurrentHashMap(64);
/*     */ 
/*  88 */   private final Map<String, ObjectFactory<?>> singletonFactories = new HashMap(16);
/*     */ 
/*  91 */   private final Map<String, Object> earlySingletonObjects = new HashMap(16);
/*     */ 
/*  94 */   private final Set<String> registeredSingletons = new LinkedHashSet(64);
/*     */ 
/*  98 */   private final Set<String> singletonsCurrentlyInCreation = Collections.newSetFromMap(new ConcurrentHashMap(16))
/*  98 */     ;
/*     */ 
/* 102 */   private final Set<String> inCreationCheckExclusions = Collections.newSetFromMap(new ConcurrentHashMap(16))
/* 102 */     ;
/*     */   private Set<Exception> suppressedExceptions;
/* 108 */   private boolean singletonsCurrentlyInDestruction = false;
/*     */ 
/* 111 */   private final Map<String, Object> disposableBeans = new LinkedHashMap();
/*     */ 
/* 114 */   private final Map<String, Set<String>> containedBeanMap = new ConcurrentHashMap(16);
/*     */ 
/* 117 */   private final Map<String, Set<String>> dependentBeanMap = new ConcurrentHashMap(64);
/*     */ 
/* 120 */   private final Map<String, Set<String>> dependenciesForBeanMap = new ConcurrentHashMap(64);
/*     */ 
/*     */   public void registerSingleton(String beanName, Object singletonObject)
/*     */     throws IllegalStateException
/*     */   {
/* 125 */     Assert.notNull(beanName, "'beanName' must not be null");
/* 126 */     synchronized (this.singletonObjects) {
/* 127 */       Object oldObject = this.singletonObjects.get(beanName);
/* 128 */       if (oldObject != null) {
/* 129 */         throw new IllegalStateException("Could not register object [" + singletonObject + "] under bean name '" + beanName + "': there is already object [" + oldObject + "] bound");
/*     */       }
/*     */ 
/* 132 */       addSingleton(beanName, singletonObject);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addSingleton(String beanName, Object singletonObject)
/*     */   {
/* 143 */     synchronized (this.singletonObjects) {
/* 144 */       this.singletonObjects.put(beanName, singletonObject != null ? singletonObject : NULL_OBJECT);
/* 145 */       this.singletonFactories.remove(beanName);
/* 146 */       this.earlySingletonObjects.remove(beanName);
/* 147 */       this.registeredSingletons.add(beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addSingletonFactory(String beanName, ObjectFactory<?> singletonFactory)
/*     */   {
/* 160 */     Assert.notNull(singletonFactory, "Singleton factory must not be null");
/* 161 */     synchronized (this.singletonObjects) {
/* 162 */       if (!this.singletonObjects.containsKey(beanName)) {
/* 163 */         this.singletonFactories.put(beanName, singletonFactory);
/* 164 */         this.earlySingletonObjects.remove(beanName);
/* 165 */         this.registeredSingletons.add(beanName);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getSingleton(String beanName)
/*     */   {
/* 172 */     return getSingleton(beanName, true);
/*     */   }
/*     */ 
/*     */   protected Object getSingleton(String beanName, boolean allowEarlyReference)
/*     */   {
/* 184 */     Object singletonObject = this.singletonObjects.get(beanName);
/* 185 */     if ((singletonObject == null) && (isSingletonCurrentlyInCreation(beanName))) {
/* 186 */       synchronized (this.singletonObjects) {
/* 187 */         singletonObject = this.earlySingletonObjects.get(beanName);
/* 188 */         if ((singletonObject == null) && (allowEarlyReference)) {
/* 189 */           ObjectFactory singletonFactory = (ObjectFactory)this.singletonFactories.get(beanName);
/* 190 */           if (singletonFactory != null) {
/* 191 */             singletonObject = singletonFactory.getObject();
/* 192 */             this.earlySingletonObjects.put(beanName, singletonObject);
/* 193 */             this.singletonFactories.remove(beanName);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 198 */     return singletonObject != NULL_OBJECT ? singletonObject : null;
/*     */   }
/*     */ 
/*     */   public Object getSingleton(String beanName, ObjectFactory<?> singletonFactory)
/*     */   {
/* 210 */     Assert.notNull(beanName, "'beanName' must not be null");
/* 211 */     synchronized (this.singletonObjects) {
/* 212 */       Object singletonObject = this.singletonObjects.get(beanName);
/* 213 */       if (singletonObject == null) {
/* 214 */         if (this.singletonsCurrentlyInDestruction) {
/* 215 */           throw new BeanCreationNotAllowedException(beanName, "Singleton bean creation not allowed while the singletons of this factory are in destruction (Do not request a bean from a BeanFactory in a destroy method implementation!)");
/*     */         }
/*     */ 
/* 219 */         if (this.logger.isDebugEnabled()) {
/* 220 */           this.logger.debug("Creating shared instance of singleton bean '" + beanName + "'");
/*     */         }
/* 222 */         beforeSingletonCreation(beanName);
/* 223 */         boolean recordSuppressedExceptions = this.suppressedExceptions == null;
/* 224 */         if (recordSuppressedExceptions)
/* 225 */           this.suppressedExceptions = new LinkedHashSet();
/*     */         try
/*     */         {
/* 228 */           singletonObject = singletonFactory.getObject();
/*     */         }
/*     */         catch (BeanCreationException ex) {
/* 231 */           if (recordSuppressedExceptions) {
/* 232 */             for (Exception suppressedException : this.suppressedExceptions) {
/* 233 */               ex.addRelatedCause(suppressedException);
/*     */             }
/*     */           }
/* 236 */           throw ex;
/*     */         }
/*     */         finally {
/* 239 */           if (recordSuppressedExceptions) {
/* 240 */             this.suppressedExceptions = null;
/*     */           }
/* 242 */           afterSingletonCreation(beanName);
/*     */         }
/* 244 */         addSingleton(beanName, singletonObject);
/*     */       }
/* 246 */       return singletonObject != NULL_OBJECT ? singletonObject : null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void onSuppressedException(Exception ex)
/*     */   {
/* 256 */     synchronized (this.singletonObjects) {
/* 257 */       if (this.suppressedExceptions != null)
/* 258 */         this.suppressedExceptions.add(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void removeSingleton(String beanName)
/*     */   {
/* 270 */     synchronized (this.singletonObjects) {
/* 271 */       this.singletonObjects.remove(beanName);
/* 272 */       this.singletonFactories.remove(beanName);
/* 273 */       this.earlySingletonObjects.remove(beanName);
/* 274 */       this.registeredSingletons.remove(beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsSingleton(String beanName)
/*     */   {
/* 280 */     return this.singletonObjects.containsKey(beanName);
/*     */   }
/*     */ 
/*     */   public String[] getSingletonNames()
/*     */   {
/* 285 */     synchronized (this.singletonObjects) {
/* 286 */       return StringUtils.toStringArray(this.registeredSingletons);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getSingletonCount()
/*     */   {
/* 292 */     synchronized (this.singletonObjects) {
/* 293 */       return this.registeredSingletons.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCurrentlyInCreation(String beanName, boolean inCreation)
/*     */   {
/* 299 */     Assert.notNull(beanName, "Bean name must not be null");
/* 300 */     if (!inCreation) {
/* 301 */       this.inCreationCheckExclusions.add(beanName);
/*     */     }
/*     */     else
/* 304 */       this.inCreationCheckExclusions.remove(beanName);
/*     */   }
/*     */ 
/*     */   public boolean isCurrentlyInCreation(String beanName)
/*     */   {
/* 309 */     Assert.notNull(beanName, "Bean name must not be null");
/* 310 */     return (!this.inCreationCheckExclusions.contains(beanName)) && (isActuallyInCreation(beanName));
/*     */   }
/*     */ 
/*     */   protected boolean isActuallyInCreation(String beanName) {
/* 314 */     return isSingletonCurrentlyInCreation(beanName);
/*     */   }
/*     */ 
/*     */   public boolean isSingletonCurrentlyInCreation(String beanName)
/*     */   {
/* 323 */     return this.singletonsCurrentlyInCreation.contains(beanName);
/*     */   }
/*     */ 
/*     */   protected void beforeSingletonCreation(String beanName)
/*     */   {
/* 333 */     if ((!this.inCreationCheckExclusions.contains(beanName)) && 
/* 334 */       (!this.singletonsCurrentlyInCreation
/* 334 */       .add(beanName)))
/*     */     {
/* 335 */       throw new BeanCurrentlyInCreationException(beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void afterSingletonCreation(String beanName)
/*     */   {
/* 346 */     if ((!this.inCreationCheckExclusions.contains(beanName)) && 
/* 347 */       (!this.singletonsCurrentlyInCreation
/* 347 */       .remove(beanName)))
/*     */     {
/* 348 */       throw new IllegalStateException("Singleton '" + beanName + "' isn't currently in creation");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerDisposableBean(String beanName, DisposableBean bean)
/*     */   {
/* 363 */     synchronized (this.disposableBeans) {
/* 364 */       this.disposableBeans.put(beanName, bean);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerContainedBean(String containedBeanName, String containingBeanName)
/*     */   {
/* 378 */     synchronized (this.containedBeanMap) {
/* 379 */       Set containedBeans = (Set)this.containedBeanMap.get(containingBeanName);
/* 380 */       if (containedBeans == null) {
/* 381 */         containedBeans = new LinkedHashSet(8);
/* 382 */         this.containedBeanMap.put(containingBeanName, containedBeans);
/*     */       }
/* 384 */       containedBeans.add(containedBeanName);
/*     */     }
/* 386 */     registerDependentBean(containedBeanName, containingBeanName);
/*     */   }
/*     */ 
/*     */   public void registerDependentBean(String beanName, String dependentBeanName)
/*     */   {
/* 396 */     String canonicalName = canonicalName(beanName);
/* 397 */     synchronized (this.dependentBeanMap) {
/* 398 */       Set dependentBeans = (Set)this.dependentBeanMap.get(canonicalName);
/* 399 */       if (dependentBeans == null) {
/* 400 */         dependentBeans = new LinkedHashSet(8);
/* 401 */         this.dependentBeanMap.put(canonicalName, dependentBeans);
/*     */       }
/* 403 */       dependentBeans.add(dependentBeanName);
/*     */     }
/* 405 */     synchronized (this.dependenciesForBeanMap) {
/* 406 */       Set dependenciesForBean = (Set)this.dependenciesForBeanMap.get(dependentBeanName);
/* 407 */       if (dependenciesForBean == null) {
/* 408 */         dependenciesForBean = new LinkedHashSet(8);
/* 409 */         this.dependenciesForBeanMap.put(dependentBeanName, dependenciesForBean);
/*     */       }
/* 411 */       dependenciesForBean.add(canonicalName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isDependent(String beanName, String dependentBeanName)
/*     */   {
/* 422 */     Set dependentBeans = (Set)this.dependentBeanMap.get(beanName);
/* 423 */     if (dependentBeans == null) {
/* 424 */       return false;
/*     */     }
/* 426 */     if (dependentBeans.contains(dependentBeanName)) {
/* 427 */       return true;
/*     */     }
/* 429 */     for (String transitiveDependency : dependentBeans) {
/* 430 */       if (isDependent(transitiveDependency, dependentBeanName)) {
/* 431 */         return true;
/*     */       }
/*     */     }
/* 434 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean hasDependentBean(String beanName)
/*     */   {
/* 442 */     return this.dependentBeanMap.containsKey(beanName);
/*     */   }
/*     */ 
/*     */   public String[] getDependentBeans(String beanName)
/*     */   {
/* 451 */     Set dependentBeans = (Set)this.dependentBeanMap.get(beanName);
/* 452 */     if (dependentBeans == null) {
/* 453 */       return new String[0];
/*     */     }
/* 455 */     return StringUtils.toStringArray(dependentBeans);
/*     */   }
/*     */ 
/*     */   public String[] getDependenciesForBean(String beanName)
/*     */   {
/* 465 */     Set dependenciesForBean = (Set)this.dependenciesForBeanMap.get(beanName);
/* 466 */     if (dependenciesForBean == null) {
/* 467 */       return new String[0];
/*     */     }
/* 469 */     return (String[])dependenciesForBean.toArray(new String[dependenciesForBean.size()]);
/*     */   }
/*     */ 
/*     */   public void destroySingletons() {
/* 473 */     if (this.logger.isDebugEnabled()) {
/* 474 */       this.logger.debug("Destroying singletons in " + this);
/*     */     }
/* 476 */     synchronized (this.singletonObjects) {
/* 477 */       this.singletonsCurrentlyInDestruction = true;
/*     */     }
/*     */     String[] disposableBeanNames;
/* 481 */     synchronized (this.disposableBeans) {
/* 482 */       disposableBeanNames = StringUtils.toStringArray(this.disposableBeans.keySet());
/*     */     }
/* 484 */     for (int i = disposableBeanNames.length - 1; i >= 0; i--) {
/* 485 */       destroySingleton(disposableBeanNames[i]);
/*     */     }
/*     */ 
/* 488 */     this.containedBeanMap.clear();
/* 489 */     this.dependentBeanMap.clear();
/* 490 */     this.dependenciesForBeanMap.clear();
/*     */ 
/* 492 */     synchronized (this.singletonObjects) {
/* 493 */       this.singletonObjects.clear();
/* 494 */       this.singletonFactories.clear();
/* 495 */       this.earlySingletonObjects.clear();
/* 496 */       this.registeredSingletons.clear();
/* 497 */       this.singletonsCurrentlyInDestruction = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroySingleton(String beanName)
/*     */   {
/* 509 */     removeSingleton(beanName);
/*     */     DisposableBean disposableBean;
/* 513 */     synchronized (this.disposableBeans) {
/* 514 */       disposableBean = (DisposableBean)this.disposableBeans.remove(beanName);
/*     */     }
/* 516 */     destroyBean(beanName, disposableBean);
/*     */   }
/*     */ 
/*     */   protected void destroyBean(String beanName, DisposableBean bean)
/*     */   {
/* 527 */     Set dependencies = (Set)this.dependentBeanMap.remove(beanName);
/*     */     Iterator localIterator1;
/* 528 */     if (dependencies != null) {
/* 529 */       if (this.logger.isDebugEnabled()) {
/* 530 */         this.logger.debug("Retrieved dependent beans for bean '" + beanName + "': " + dependencies);
/*     */       }
/* 532 */       for (localIterator1 = dependencies.iterator(); localIterator1.hasNext(); ) { dependentBeanName = (String)localIterator1.next();
/* 533 */         destroySingleton(dependentBeanName);
/*     */       }
/*     */     }
/*     */     String dependentBeanName;
/* 538 */     if (bean != null) {
/*     */       try {
/* 540 */         bean.destroy();
/*     */       }
/*     */       catch (Throwable ex) {
/* 543 */         this.logger.error("Destroy method on bean with name '" + beanName + "' threw an exception", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 548 */     Set containedBeans = (Set)this.containedBeanMap.remove(beanName);
/* 549 */     if (containedBeans != null)
/* 550 */       for (String containedBeanName : containedBeans)
/* 551 */         destroySingleton(containedBeanName);
/*     */     Iterator it;
/* 556 */     synchronized (this.dependentBeanMap) {
/* 557 */       for (it = this.dependentBeanMap.entrySet().iterator(); it.hasNext(); ) {
/* 558 */         Map.Entry entry = (Map.Entry)it.next();
/* 559 */         Set dependenciesToClean = (Set)entry.getValue();
/* 560 */         dependenciesToClean.remove(beanName);
/* 561 */         if (dependenciesToClean.isEmpty()) {
/* 562 */           it.remove();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 568 */     this.dependenciesForBeanMap.remove(beanName);
/*     */   }
/*     */ 
/*     */   protected final Object getSingletonMutex()
/*     */   {
/* 579 */     return this.singletonObjects;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.DefaultSingletonBeanRegistry
 * JD-Core Version:    0.6.2
 */