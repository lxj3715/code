/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ class DisposableBeanAdapter
/*     */   implements DisposableBean, Runnable, Serializable
/*     */ {
/*     */   private static final String CLOSE_METHOD_NAME = "close";
/*     */   private static final String SHUTDOWN_METHOD_NAME = "shutdown";
/*  66 */   private static final Log logger = LogFactory.getLog(DisposableBeanAdapter.class);
/*     */   private static Class<?> closeableInterface;
/*     */   private final Object bean;
/*     */   private final String beanName;
/*     */   private final boolean invokeDisposableBean;
/*     */   private final boolean nonPublicAccessAllowed;
/*     */   private final AccessControlContext acc;
/*     */   private String destroyMethodName;
/*     */   private transient Method destroyMethod;
/*     */   private List<DestructionAwareBeanPostProcessor> beanPostProcessors;
/*     */ 
/*     */   public DisposableBeanAdapter(Object bean, String beanName, RootBeanDefinition beanDefinition, List<BeanPostProcessor> postProcessors, AccessControlContext acc)
/*     */   {
/* 108 */     Assert.notNull(bean, "Disposable bean must not be null");
/* 109 */     this.bean = bean;
/* 110 */     this.beanName = beanName;
/* 111 */     this.invokeDisposableBean = (((this.bean instanceof Serializable)) && 
/* 112 */       (!beanDefinition
/* 112 */       .isExternallyManagedDestroyMethod("destroy")));
/*     */ 
/* 113 */     this.nonPublicAccessAllowed = beanDefinition.isNonPublicAccessAllowed();
/* 114 */     this.acc = acc;
/* 115 */     String destroyMethodName = inferDestroyMethodIfNecessary(bean, beanDefinition);
/* 116 */     if ((destroyMethodName != null) && ((!this.invokeDisposableBean) || (!"destroy".equals(destroyMethodName))) && 
/* 117 */       (!beanDefinition
/* 117 */       .isExternallyManagedDestroyMethod(destroyMethodName)))
/*     */     {
/* 118 */       this.destroyMethodName = destroyMethodName;
/* 119 */       this.destroyMethod = determineDestroyMethod();
/* 120 */       if (this.destroyMethod == null) {
/* 121 */         if (beanDefinition.isEnforceDestroyMethod()) {
/* 122 */           throw new BeanDefinitionValidationException("Couldn't find a destroy method named '" + destroyMethodName + "' on bean with name '" + beanName + "'");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 127 */         Class[] paramTypes = this.destroyMethod.getParameterTypes();
/* 128 */         if (paramTypes.length > 1) {
/* 129 */           throw new BeanDefinitionValidationException("Method '" + destroyMethodName + "' of bean '" + beanName + "' has more than one parameter - not supported as destroy method");
/*     */         }
/*     */ 
/* 132 */         if ((paramTypes.length == 1) && (!paramTypes[0].equals(Boolean.TYPE))) {
/* 133 */           throw new BeanDefinitionValidationException("Method '" + destroyMethodName + "' of bean '" + beanName + "' has a non-boolean parameter - not supported as destroy method");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 138 */     this.beanPostProcessors = filterPostProcessors(postProcessors);
/*     */   }
/*     */ 
/*     */   public DisposableBeanAdapter(Object bean, List<BeanPostProcessor> postProcessors, AccessControlContext acc)
/*     */   {
/* 148 */     Assert.notNull(bean, "Disposable bean must not be null");
/* 149 */     this.bean = bean;
/* 150 */     this.beanName = null;
/* 151 */     this.invokeDisposableBean = (this.bean instanceof Serializable);
/* 152 */     this.nonPublicAccessAllowed = true;
/* 153 */     this.acc = acc;
/* 154 */     this.beanPostProcessors = filterPostProcessors(postProcessors);
/*     */   }
/*     */ 
/*     */   private DisposableBeanAdapter(Object bean, String beanName, boolean invokeDisposableBean, boolean nonPublicAccessAllowed, String destroyMethodName, List<DestructionAwareBeanPostProcessor> postProcessors)
/*     */   {
/* 164 */     this.bean = bean;
/* 165 */     this.beanName = beanName;
/* 166 */     this.invokeDisposableBean = invokeDisposableBean;
/* 167 */     this.nonPublicAccessAllowed = nonPublicAccessAllowed;
/* 168 */     this.acc = null;
/* 169 */     this.destroyMethodName = destroyMethodName;
/* 170 */     this.beanPostProcessors = postProcessors;
/*     */   }
/*     */ 
/*     */   private String inferDestroyMethodIfNecessary(Object bean, RootBeanDefinition beanDefinition)
/*     */   {
/* 188 */     if (("(inferred)".equals(beanDefinition.getDestroyMethodName())) || (
/* 189 */       (beanDefinition
/* 189 */       .getDestroyMethodName() == null) && (closeableInterface.isInstance(bean))))
/*     */     {
/* 192 */       if (!(bean instanceof Serializable)) {
/*     */         try {
/* 194 */           return bean.getClass().getMethod("close", new Class[0]).getName();
/*     */         }
/*     */         catch (NoSuchMethodException ex) {
/*     */           try {
/* 198 */             return bean.getClass().getMethod("shutdown", new Class[0]).getName();
/*     */           }
/*     */           catch (NoSuchMethodException ex2)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/* 205 */       return null;
/*     */     }
/* 207 */     return beanDefinition.getDestroyMethodName();
/*     */   }
/*     */ 
/*     */   private List<DestructionAwareBeanPostProcessor> filterPostProcessors(List<BeanPostProcessor> postProcessors)
/*     */   {
/* 216 */     List filteredPostProcessors = null;
/* 217 */     if ((postProcessors != null) && (!postProcessors.isEmpty())) {
/* 218 */       filteredPostProcessors = new ArrayList(postProcessors.size());
/* 219 */       for (BeanPostProcessor postProcessor : postProcessors) {
/* 220 */         if ((postProcessor instanceof DestructionAwareBeanPostProcessor)) {
/* 221 */           filteredPostProcessors.add((DestructionAwareBeanPostProcessor)postProcessor);
/*     */         }
/*     */       }
/*     */     }
/* 225 */     return filteredPostProcessors;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 231 */     destroy();
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 236 */     if ((this.beanPostProcessors != null) && (!this.beanPostProcessors.isEmpty())) {
/* 237 */       for (DestructionAwareBeanPostProcessor processor : this.beanPostProcessors) {
/* 238 */         processor.postProcessBeforeDestruction(this.bean, this.beanName);
/*     */       }
/*     */     }
/*     */ 
/* 242 */     if (this.invokeDisposableBean) {
/* 243 */       if (logger.isDebugEnabled())
/* 244 */         logger.debug("Invoking destroy() on bean with name '" + this.beanName + "'");
/*     */       try
/*     */       {
/* 247 */         if (System.getSecurityManager() != null) {
/* 248 */           AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */           {
/*     */             public Object run() throws Exception {
/* 251 */               ((DisposableBean)DisposableBeanAdapter.this.bean).destroy();
/* 252 */               return null;
/*     */             }
/*     */           }
/*     */           , this.acc);
/*     */         }
/*     */         else
/*     */         {
/* 257 */           ((Serializable)this.bean).destroy();
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 261 */         String msg = "Invocation of destroy method failed on bean with name '" + this.beanName + "'";
/* 262 */         if (logger.isDebugEnabled()) {
/* 263 */           logger.warn(msg, ex);
/*     */         }
/*     */         else {
/* 266 */           logger.warn(msg + ": " + ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 271 */     if (this.destroyMethod != null) {
/* 272 */       invokeCustomDestroyMethod(this.destroyMethod);
/*     */     }
/* 274 */     else if (this.destroyMethodName != null) {
/* 275 */       Method methodToCall = determineDestroyMethod();
/* 276 */       if (methodToCall != null)
/* 277 */         invokeCustomDestroyMethod(methodToCall);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Method determineDestroyMethod()
/*     */   {
/*     */     try
/*     */     {
/* 285 */       if (System.getSecurityManager() != null) {
/* 286 */         return (Method)AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Method run() {
/* 289 */             return DisposableBeanAdapter.this.findDestroyMethod();
/*     */           }
/*     */         });
/*     */       }
/*     */ 
/* 294 */       return findDestroyMethod();
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 299 */       throw new BeanDefinitionValidationException("Couldn't find a unique destroy method on bean with name '" + this.beanName + ": " + ex
/* 299 */         .getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private Method findDestroyMethod()
/*     */   {
/* 306 */     return this.nonPublicAccessAllowed ? 
/* 305 */       BeanUtils.findMethodWithMinimalParameters(this.bean
/* 305 */       .getClass(), this.destroyMethodName) : 
/* 306 */       BeanUtils.findMethodWithMinimalParameters(this.bean
/* 306 */       .getClass().getMethods(), this.destroyMethodName);
/*     */   }
/*     */ 
/*     */   private void invokeCustomDestroyMethod(final Method destroyMethod)
/*     */   {
/* 316 */     Class[] paramTypes = destroyMethod.getParameterTypes();
/* 317 */     final Object[] args = new Object[paramTypes.length];
/* 318 */     if (paramTypes.length == 1) {
/* 319 */       args[0] = Boolean.TRUE;
/*     */     }
/* 321 */     if (logger.isDebugEnabled()) {
/* 322 */       logger.debug("Invoking destroy method '" + this.destroyMethodName + "' on bean with name '" + this.beanName + "'");
/*     */     }
/*     */     try
/*     */     {
/* 326 */       if (System.getSecurityManager() != null) {
/* 327 */         AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 330 */             ReflectionUtils.makeAccessible(destroyMethod);
/* 331 */             return null;
/*     */           }
/*     */         });
/*     */         try {
/* 335 */           AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */           {
/*     */             public Object run() throws Exception {
/* 338 */               destroyMethod.invoke(DisposableBeanAdapter.this.bean, args);
/* 339 */               return null;
/*     */             }
/*     */           }
/*     */           , this.acc);
/*     */         }
/*     */         catch (PrivilegedActionException pax)
/*     */         {
/* 344 */           throw ((InvocationTargetException)pax.getException());
/*     */         }
/*     */       }
/*     */       else {
/* 348 */         ReflectionUtils.makeAccessible(destroyMethod);
/* 349 */         destroyMethod.invoke(this.bean, args);
/*     */       }
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 353 */       String msg = "Invocation of destroy method '" + this.destroyMethodName + "' failed on bean with name '" + this.beanName + "'";
/*     */ 
/* 355 */       if (logger.isDebugEnabled()) {
/* 356 */         logger.warn(msg, ex.getTargetException());
/*     */       }
/*     */       else
/* 359 */         logger.warn(msg + ": " + ex.getTargetException());
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 363 */       logger.error("Couldn't invoke destroy method '" + this.destroyMethodName + "' on bean with name '" + this.beanName + "'", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object writeReplace()
/*     */   {
/* 374 */     List serializablePostProcessors = null;
/* 375 */     if (this.beanPostProcessors != null) {
/* 376 */       serializablePostProcessors = new ArrayList();
/* 377 */       for (DestructionAwareBeanPostProcessor postProcessor : this.beanPostProcessors) {
/* 378 */         if ((postProcessor instanceof Serializable)) {
/* 379 */           serializablePostProcessors.add(postProcessor);
/*     */         }
/*     */       }
/*     */     }
/* 383 */     return new DisposableBeanAdapter(this.bean, this.beanName, this.invokeDisposableBean, this.nonPublicAccessAllowed, this.destroyMethodName, serializablePostProcessors);
/*     */   }
/*     */ 
/*     */   public static boolean hasDestroyMethod(Object bean, RootBeanDefinition beanDefinition)
/*     */   {
/* 394 */     if (((bean instanceof Serializable)) || (closeableInterface.isInstance(bean))) {
/* 395 */       return true;
/*     */     }
/* 397 */     String destroyMethodName = beanDefinition.getDestroyMethodName();
/* 398 */     if ("(inferred)".equals(destroyMethodName)) {
/* 399 */       return ClassUtils.hasMethod(bean.getClass(), "close", new Class[0]);
/*     */     }
/* 401 */     return destroyMethodName != null;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  72 */       closeableInterface = DisposableBeanAdapter.class.getClassLoader().loadClass("java.lang.AutoCloseable");
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  75 */       closeableInterface = Closeable.class;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.DisposableBeanAdapter
 * JD-Core Version:    0.6.2
 */