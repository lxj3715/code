/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ 
/*     */ public abstract class FactoryBeanRegistrySupport extends DefaultSingletonBeanRegistry
/*     */ {
/*  46 */   private final Map<String, Object> factoryBeanObjectCache = new ConcurrentHashMap(16);
/*     */ 
/*     */   protected Class<?> getTypeForFactoryBean(final FactoryBean<?> factoryBean)
/*     */   {
/*     */     try
/*     */     {
/*  57 */       if (System.getSecurityManager() != null) {
/*  58 */         return (Class)AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Class<?> run() {
/*  61 */             return factoryBean.getObjectType();
/*     */           }
/*     */         }
/*     */         , getAccessControlContext());
/*     */       }
/*     */ 
/*  66 */       return factoryBean.getObjectType();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  71 */       this.logger.warn("FactoryBean threw exception from getObjectType, despite the contract saying that it should return null if the type of its object cannot be determined yet", ex);
/*     */     }
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object getCachedObjectForFactoryBean(String beanName)
/*     */   {
/*  85 */     Object object = this.factoryBeanObjectCache.get(beanName);
/*  86 */     return object != NULL_OBJECT ? object : null;
/*     */   }
/*     */ 
/*     */   protected Object getObjectFromFactoryBean(FactoryBean<?> factory, String beanName, boolean shouldPostProcess)
/*     */   {
/*  99 */     if ((factory.isSingleton()) && (containsSingleton(beanName))) {
/* 100 */       synchronized (getSingletonMutex()) {
/* 101 */         Object object = this.factoryBeanObjectCache.get(beanName);
/* 102 */         if (object == null) {
/* 103 */           object = doGetObjectFromFactoryBean(factory, beanName, shouldPostProcess);
/* 104 */           this.factoryBeanObjectCache.put(beanName, object != null ? object : NULL_OBJECT);
/*     */         }
/* 106 */         return object != NULL_OBJECT ? object : null;
/*     */       }
/*     */     }
/*     */ 
/* 110 */     return doGetObjectFromFactoryBean(factory, beanName, shouldPostProcess);
/*     */   }
/*     */ 
/*     */   private Object doGetObjectFromFactoryBean(final FactoryBean<?> factory, String beanName, boolean shouldPostProcess)
/*     */     throws BeanCreationException
/*     */   {
/*     */     try
/*     */     {
/*     */       Object object;
/* 129 */       if (System.getSecurityManager() != null) {
/* 130 */         AccessControlContext acc = getAccessControlContext();
/*     */         try {
/* 132 */           object = AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */           {
/*     */             public Object run() throws Exception {
/* 135 */               return factory.getObject();
/*     */             }
/*     */           }
/*     */           , acc);
/*     */         }
/*     */         catch (PrivilegedActionException pae)
/*     */         {
/*     */           Object object;
/* 140 */           throw pae.getException();
/*     */         }
/*     */       }
/*     */       else {
/* 144 */         object = factory.getObject();
/*     */       }
/*     */     }
/*     */     catch (FactoryBeanNotInitializedException ex)
/*     */     {
/*     */       Object object;
/* 148 */       throw new BeanCurrentlyInCreationException(beanName, ex.toString());
/*     */     }
/*     */     catch (Throwable ex) {
/* 151 */       throw new BeanCreationException(beanName, "FactoryBean threw exception on object creation", ex);
/*     */     }
/*     */     Object object;
/* 157 */     if ((object == null) && (isSingletonCurrentlyInCreation(beanName))) {
/* 158 */       throw new BeanCurrentlyInCreationException(beanName, "FactoryBean which is currently in creation returned null from getObject");
/*     */     }
/*     */ 
/* 162 */     if ((object != null) && (shouldPostProcess)) {
/*     */       try {
/* 164 */         object = postProcessObjectFromFactoryBean(object, beanName);
/*     */       }
/*     */       catch (Throwable ex) {
/* 167 */         throw new BeanCreationException(beanName, "Post-processing of the FactoryBean's object failed", ex);
/*     */       }
/*     */     }
/*     */ 
/* 171 */     return object;
/*     */   }
/*     */ 
/*     */   protected Object postProcessObjectFromFactoryBean(Object object, String beanName)
/*     */     throws BeansException
/*     */   {
/* 185 */     return object;
/*     */   }
/*     */ 
/*     */   protected FactoryBean<?> getFactoryBean(String beanName, Object beanInstance)
/*     */     throws BeansException
/*     */   {
/* 196 */     if (!(beanInstance instanceof FactoryBean))
/*     */     {
/* 198 */       throw new BeanCreationException(beanName, "Bean instance of type [" + beanInstance
/* 198 */         .getClass() + "] is not a FactoryBean");
/*     */     }
/* 200 */     return (FactoryBean)beanInstance;
/*     */   }
/*     */ 
/*     */   protected void removeSingleton(String beanName)
/*     */   {
/* 208 */     super.removeSingleton(beanName);
/* 209 */     this.factoryBeanObjectCache.remove(beanName);
/*     */   }
/*     */ 
/*     */   protected AccessControlContext getAccessControlContext()
/*     */   {
/* 219 */     return AccessController.getContext();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.FactoryBeanRegistrySupport
 * JD-Core Version:    0.6.2
 */