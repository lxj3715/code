/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class GenericTypeAwareAutowireCandidateResolver
/*     */   implements AutowireCandidateResolver, BeanFactoryAware
/*     */ {
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  50 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   protected final BeanFactory getBeanFactory() {
/*  54 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   public boolean isAutowireCandidate(BeanDefinitionHolder bdHolder, DependencyDescriptor descriptor)
/*     */   {
/*  60 */     if (!bdHolder.getBeanDefinition().isAutowireCandidate())
/*     */     {
/*  62 */       return false;
/*     */     }
/*  64 */     return (descriptor == null) || (checkGenericTypeMatch(bdHolder, descriptor));
/*     */   }
/*     */ 
/*     */   protected boolean checkGenericTypeMatch(BeanDefinitionHolder bdHolder, DependencyDescriptor descriptor)
/*     */   {
/*  72 */     ResolvableType dependencyType = descriptor.getResolvableType();
/*  73 */     if ((dependencyType.getType() instanceof Class))
/*     */     {
/*  75 */       return true;
/*     */     }
/*  77 */     ResolvableType targetType = null;
/*  78 */     RootBeanDefinition rbd = null;
/*  79 */     if ((bdHolder.getBeanDefinition() instanceof RootBeanDefinition)) {
/*  80 */       rbd = (RootBeanDefinition)bdHolder.getBeanDefinition();
/*     */     }
/*  82 */     if (rbd != null)
/*     */     {
/*  84 */       targetType = getReturnTypeForFactoryMethod(rbd, descriptor);
/*  85 */       if (targetType == null) {
/*  86 */         RootBeanDefinition dbd = getResolvedDecoratedDefinition(rbd);
/*  87 */         if (dbd != null) {
/*  88 */           targetType = getReturnTypeForFactoryMethod(dbd, descriptor);
/*     */         }
/*     */       }
/*     */     }
/*  92 */     if (targetType == null)
/*     */     {
/*  94 */       if (this.beanFactory != null) {
/*  95 */         Class beanType = this.beanFactory.getType(bdHolder.getBeanName());
/*  96 */         if (beanType != null) {
/*  97 */           targetType = ResolvableType.forClass(ClassUtils.getUserClass(beanType));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 102 */       if ((targetType == null) && (rbd != null) && (rbd.hasBeanClass()) && (rbd.getFactoryMethodName() == null)) {
/* 103 */         Class beanClass = rbd.getBeanClass();
/* 104 */         if (!FactoryBean.class.isAssignableFrom(beanClass)) {
/* 105 */           targetType = ResolvableType.forClass(ClassUtils.getUserClass(beanClass));
/*     */         }
/*     */       }
/*     */     }
/* 109 */     if (targetType == null) {
/* 110 */       return true;
/*     */     }
/* 112 */     if ((descriptor.fallbackMatchAllowed()) && (targetType.hasUnresolvableGenerics())) {
/* 113 */       return descriptor.getDependencyType().isAssignableFrom(targetType.getRawClass());
/*     */     }
/* 115 */     return dependencyType.isAssignableFrom(targetType);
/*     */   }
/*     */ 
/*     */   protected RootBeanDefinition getResolvedDecoratedDefinition(RootBeanDefinition rbd) {
/* 119 */     BeanDefinitionHolder decDef = rbd.getDecoratedDefinition();
/* 120 */     if ((decDef != null) && ((this.beanFactory instanceof ConfigurableListableBeanFactory))) {
/* 121 */       ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)this.beanFactory;
/* 122 */       if (clbf.containsBeanDefinition(decDef.getBeanName())) {
/* 123 */         BeanDefinition dbd = clbf.getMergedBeanDefinition(decDef.getBeanName());
/* 124 */         if ((dbd instanceof RootBeanDefinition)) {
/* 125 */           return (RootBeanDefinition)dbd;
/*     */         }
/*     */       }
/*     */     }
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   protected ResolvableType getReturnTypeForFactoryMethod(RootBeanDefinition rbd, DependencyDescriptor descriptor)
/*     */   {
/* 135 */     Class preResolved = rbd.resolvedFactoryMethodReturnType;
/* 136 */     if (preResolved != null) {
/* 137 */       return ResolvableType.forClass(preResolved);
/*     */     }
/*     */ 
/* 140 */     Method resolvedFactoryMethod = rbd.getResolvedFactoryMethod();
/* 141 */     if ((resolvedFactoryMethod != null) && 
/* 142 */       (descriptor.getDependencyType().isAssignableFrom(resolvedFactoryMethod.getReturnType())))
/*     */     {
/* 146 */       return ResolvableType.forMethodReturnType(resolvedFactoryMethod);
/*     */     }
/*     */ 
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getSuggestedValue(DependencyDescriptor descriptor)
/*     */   {
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getLazyResolutionProxyIfNecessary(DependencyDescriptor descriptor, String beanName)
/*     */   {
/* 169 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.GenericTypeAwareAutowireCandidateResolver
 * JD-Core Version:    0.6.2
 */