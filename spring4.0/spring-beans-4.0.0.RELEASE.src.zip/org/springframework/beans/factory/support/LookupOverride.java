/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ public class LookupOverride extends MethodOverride
/*    */ {
/*    */   private final String beanName;
/*    */ 
/*    */   public LookupOverride(String methodName, String beanName)
/*    */   {
/* 46 */     super(methodName);
/* 47 */     Assert.notNull(beanName, "Bean name must not be null");
/* 48 */     this.beanName = beanName;
/*    */   }
/*    */ 
/*    */   public String getBeanName()
/*    */   {
/* 55 */     return this.beanName;
/*    */   }
/*    */ 
/*    */   public boolean matches(Method method)
/*    */   {
/* 64 */     return (method.getName().equals(getMethodName())) && (method.getParameterTypes().length == 0);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 70 */     return "LookupOverride for method '" + getMethodName() + "'; will return bean '" + this.beanName + "'";
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 76 */     return ((other instanceof LookupOverride)) && (super.equals(other)) && 
/* 76 */       (ObjectUtils.nullSafeEquals(this.beanName, ((LookupOverride)other).beanName));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 81 */     return 29 * super.hashCode() + ObjectUtils.nullSafeHashCode(this.beanName);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.LookupOverride
 * JD-Core Version:    0.6.2
 */