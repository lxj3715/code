/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MethodOverrides
/*     */ {
/*  37 */   private final Set<MethodOverride> overrides = new HashSet(0);
/*     */ 
/*     */   public MethodOverrides()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MethodOverrides(MethodOverrides other)
/*     */   {
/*  50 */     addOverrides(other);
/*     */   }
/*     */ 
/*     */   public void addOverrides(MethodOverrides other)
/*     */   {
/*  58 */     if (other != null)
/*  59 */       this.overrides.addAll(other.getOverrides());
/*     */   }
/*     */ 
/*     */   public void addOverride(MethodOverride override)
/*     */   {
/*  67 */     this.overrides.add(override);
/*     */   }
/*     */ 
/*     */   public Set<MethodOverride> getOverrides()
/*     */   {
/*  76 */     return this.overrides;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  83 */     return this.overrides.isEmpty();
/*     */   }
/*     */ 
/*     */   public MethodOverride getOverride(Method method)
/*     */   {
/*  92 */     for (MethodOverride override : this.overrides) {
/*  93 */       if (override.matches(method)) {
/*  94 */         return override;
/*     */       }
/*     */     }
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 102 */     if (this == other) {
/* 103 */       return true;
/*     */     }
/* 105 */     if (!(other instanceof MethodOverrides)) {
/* 106 */       return false;
/*     */     }
/* 108 */     MethodOverrides that = (MethodOverrides)other;
/* 109 */     return this.overrides.equals(that.overrides);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 115 */     return this.overrides.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.MethodOverrides
 * JD-Core Version:    0.6.2
 */