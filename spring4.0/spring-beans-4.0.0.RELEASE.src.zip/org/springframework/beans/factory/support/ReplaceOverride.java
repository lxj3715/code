/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class ReplaceOverride extends MethodOverride
/*     */ {
/*     */   private final String methodReplacerBeanName;
/*  41 */   private List<String> typeIdentifiers = new LinkedList();
/*     */ 
/*     */   public ReplaceOverride(String methodName, String methodReplacerBeanName)
/*     */   {
/*  50 */     super(methodName);
/*  51 */     Assert.notNull(methodName, "Method replacer bean name must not be null");
/*  52 */     this.methodReplacerBeanName = methodReplacerBeanName;
/*     */   }
/*     */ 
/*     */   public String getMethodReplacerBeanName()
/*     */   {
/*  59 */     return this.methodReplacerBeanName;
/*     */   }
/*     */ 
/*     */   public void addTypeIdentifier(String identifier)
/*     */   {
/*  68 */     this.typeIdentifiers.add(identifier);
/*     */   }
/*     */ 
/*     */   public boolean matches(Method method)
/*     */   {
/*  75 */     if (!method.getName().equals(getMethodName()))
/*     */     {
/*  77 */       return false;
/*     */     }
/*     */ 
/*  80 */     if (!isOverloaded())
/*     */     {
/*  82 */       return true;
/*     */     }
/*     */ 
/*  86 */     if (this.typeIdentifiers.size() != method.getParameterTypes().length) {
/*  87 */       return false;
/*     */     }
/*  89 */     for (int i = 0; i < this.typeIdentifiers.size(); i++) {
/*  90 */       String identifier = (String)this.typeIdentifiers.get(i);
/*  91 */       if (!method.getParameterTypes()[i].getName().contains(identifier))
/*     */       {
/*  93 */         return false;
/*     */       }
/*     */     }
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 102 */     return "Replace override for method '" + getMethodName() + "; will call bean '" + this.methodReplacerBeanName + "'";
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 108 */     if ((!(other instanceof ReplaceOverride)) || (!super.equals(other))) {
/* 109 */       return false;
/*     */     }
/* 111 */     ReplaceOverride that = (ReplaceOverride)other;
/*     */ 
/* 113 */     return (ObjectUtils.nullSafeEquals(this.methodReplacerBeanName, that.methodReplacerBeanName)) && 
/* 113 */       (ObjectUtils.nullSafeEquals(this.typeIdentifiers, that.typeIdentifiers));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 118 */     int hashCode = super.hashCode();
/* 119 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.methodReplacerBeanName);
/* 120 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.typeIdentifiers);
/* 121 */     return hashCode;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.ReplaceOverride
 * JD-Core Version:    0.6.2
 */