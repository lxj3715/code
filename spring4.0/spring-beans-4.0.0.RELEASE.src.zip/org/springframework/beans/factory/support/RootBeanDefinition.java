/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class RootBeanDefinition extends AbstractBeanDefinition
/*     */ {
/*  53 */   private final Set<Member> externallyManagedConfigMembers = Collections.newSetFromMap(new ConcurrentHashMap(0))
/*  53 */     ;
/*     */ 
/*  56 */   private final Set<String> externallyManagedInitMethods = Collections.newSetFromMap(new ConcurrentHashMap(0))
/*  56 */     ;
/*     */ 
/*  59 */   private final Set<String> externallyManagedDestroyMethods = Collections.newSetFromMap(new ConcurrentHashMap(0))
/*  59 */     ;
/*     */   private BeanDefinitionHolder decoratedDefinition;
/*  63 */   boolean allowCaching = true;
/*     */   private volatile Class<?> targetType;
/*  67 */   boolean isFactoryMethodUnique = false;
/*     */ 
/*  69 */   final Object constructorArgumentLock = new Object();
/*     */   Object resolvedConstructorOrFactoryMethod;
/*     */   volatile Class<?> resolvedFactoryMethodReturnType;
/*  78 */   boolean constructorArgumentsResolved = false;
/*     */   Object[] resolvedConstructorArguments;
/*     */   Object[] preparedConstructorArguments;
/*  86 */   final Object postProcessingLock = new Object();
/*     */ 
/*  89 */   boolean postProcessed = false;
/*     */   volatile Boolean beforeInstantiationResolved;
/*     */ 
/*     */   public RootBeanDefinition()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RootBeanDefinition(Class<?> beanClass)
/*     */   {
/* 116 */     setBeanClass(beanClass);
/*     */   }
/*     */ 
/*     */   public RootBeanDefinition(Class<?> beanClass, int autowireMode, boolean dependencyCheck)
/*     */   {
/* 129 */     setBeanClass(beanClass);
/* 130 */     setAutowireMode(autowireMode);
/* 131 */     if ((dependencyCheck) && (getResolvedAutowireMode() != 3))
/* 132 */       setDependencyCheck(1);
/*     */   }
/*     */ 
/*     */   public RootBeanDefinition(Class<?> beanClass, ConstructorArgumentValues cargs, MutablePropertyValues pvs)
/*     */   {
/* 144 */     super(cargs, pvs);
/* 145 */     setBeanClass(beanClass);
/*     */   }
/*     */ 
/*     */   public RootBeanDefinition(String beanClassName)
/*     */   {
/* 155 */     setBeanClassName(beanClassName);
/*     */   }
/*     */ 
/*     */   public RootBeanDefinition(String beanClassName, ConstructorArgumentValues cargs, MutablePropertyValues pvs)
/*     */   {
/* 167 */     super(cargs, pvs);
/* 168 */     setBeanClassName(beanClassName);
/*     */   }
/*     */ 
/*     */   public RootBeanDefinition(RootBeanDefinition original)
/*     */   {
/* 177 */     super(original);
/* 178 */     this.decoratedDefinition = original.decoratedDefinition;
/* 179 */     this.allowCaching = original.allowCaching;
/* 180 */     this.targetType = original.targetType;
/* 181 */     this.isFactoryMethodUnique = original.isFactoryMethodUnique;
/*     */   }
/*     */ 
/*     */   RootBeanDefinition(BeanDefinition original)
/*     */   {
/* 190 */     super(original);
/*     */   }
/*     */ 
/*     */   public String getParentName()
/*     */   {
/* 196 */     return null;
/*     */   }
/*     */ 
/*     */   public void setParentName(String parentName)
/*     */   {
/* 201 */     if (parentName != null)
/* 202 */       throw new IllegalArgumentException("Root bean cannot be changed into a child bean with parent reference");
/*     */   }
/*     */ 
/*     */   public void setTargetType(Class<?> targetType)
/*     */   {
/* 210 */     this.targetType = targetType;
/*     */   }
/*     */ 
/*     */   public Class<?> getTargetType()
/*     */   {
/* 218 */     return this.targetType;
/*     */   }
/*     */ 
/*     */   public void setUniqueFactoryMethodName(String name)
/*     */   {
/* 225 */     Assert.hasText(name, "Factory method name must not be empty");
/* 226 */     setFactoryMethodName(name);
/* 227 */     this.isFactoryMethodUnique = true;
/*     */   }
/*     */ 
/*     */   public boolean isFactoryMethod(Method candidate)
/*     */   {
/* 234 */     return (candidate != null) && (candidate.getName().equals(getFactoryMethodName()));
/*     */   }
/*     */ 
/*     */   public Method getResolvedFactoryMethod()
/*     */   {
/* 242 */     synchronized (this.constructorArgumentLock) {
/* 243 */       Object candidate = this.resolvedConstructorOrFactoryMethod;
/* 244 */       return (candidate instanceof Method) ? (Method)candidate : null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerExternallyManagedConfigMember(Member configMember)
/*     */   {
/* 250 */     this.externallyManagedConfigMembers.add(configMember);
/*     */   }
/*     */ 
/*     */   public boolean isExternallyManagedConfigMember(Member configMember) {
/* 254 */     return this.externallyManagedConfigMembers.contains(configMember);
/*     */   }
/*     */ 
/*     */   public void registerExternallyManagedInitMethod(String initMethod) {
/* 258 */     this.externallyManagedInitMethods.add(initMethod);
/*     */   }
/*     */ 
/*     */   public boolean isExternallyManagedInitMethod(String initMethod) {
/* 262 */     return this.externallyManagedInitMethods.contains(initMethod);
/*     */   }
/*     */ 
/*     */   public void registerExternallyManagedDestroyMethod(String destroyMethod) {
/* 266 */     this.externallyManagedDestroyMethods.add(destroyMethod);
/*     */   }
/*     */ 
/*     */   public boolean isExternallyManagedDestroyMethod(String destroyMethod) {
/* 270 */     return this.externallyManagedDestroyMethods.contains(destroyMethod);
/*     */   }
/*     */ 
/*     */   public void setDecoratedDefinition(BeanDefinitionHolder decoratedDefinition) {
/* 274 */     this.decoratedDefinition = decoratedDefinition;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionHolder getDecoratedDefinition() {
/* 278 */     return this.decoratedDefinition;
/*     */   }
/*     */ 
/*     */   public RootBeanDefinition cloneBeanDefinition()
/*     */   {
/* 284 */     return new RootBeanDefinition(this);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 289 */     return (this == other) || (((other instanceof RootBeanDefinition)) && (super.equals(other)));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 294 */     return "Root bean: " + super.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.RootBeanDefinition
 * JD-Core Version:    0.6.2
 */