package org.springframework.beans.factory.support;

import java.security.AccessControlContext;

public abstract interface SecurityContextProvider
{
  public abstract AccessControlContext getAccessControlContext();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.SecurityContextProvider
 * JD-Core Version:    0.6.2
 */