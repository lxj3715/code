/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class SimpleInstantiationStrategy
/*     */   implements InstantiationStrategy
/*     */ {
/*  45 */   private static final ThreadLocal<Method> currentlyInvokedFactoryMethod = new ThreadLocal();
/*     */ 
/*     */   public static Method getCurrentlyInvokedFactoryMethod()
/*     */   {
/*  54 */     return (Method)currentlyInvokedFactoryMethod.get();
/*     */   }
/*     */ 
/*     */   public Object instantiate(RootBeanDefinition beanDefinition, String beanName, BeanFactory owner)
/*     */   {
/*  61 */     if (beanDefinition.getMethodOverrides().isEmpty())
/*     */     {
/*     */       Constructor constructorToUse;
/*  63 */       synchronized (beanDefinition.constructorArgumentLock) {
/*  64 */         constructorToUse = (Constructor)beanDefinition.resolvedConstructorOrFactoryMethod;
/*  65 */         if (constructorToUse == null) {
/*  66 */           final Class clazz = beanDefinition.getBeanClass();
/*  67 */           if (clazz.isInterface())
/*  68 */             throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */           try
/*     */           {
/*  71 */             if (System.getSecurityManager() != null) {
/*  72 */               constructorToUse = (Constructor)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */               {
/*     */                 public Constructor<?> run() throws Exception {
/*  75 */                   return clazz.getDeclaredConstructor((Class[])null);
/*     */                 }
/*     */               });
/*     */             }
/*     */             else {
/*  80 */               constructorToUse = clazz.getDeclaredConstructor((Class[])null);
/*     */             }
/*  82 */             beanDefinition.resolvedConstructorOrFactoryMethod = constructorToUse;
/*     */           }
/*     */           catch (Exception ex) {
/*  85 */             throw new BeanInstantiationException(clazz, "No default constructor found", ex);
/*     */           }
/*     */         }
/*     */       }
/*  89 */       return BeanUtils.instantiateClass(constructorToUse, new Object[0]);
/*     */     }
/*     */ 
/*  93 */     return instantiateWithMethodInjection(beanDefinition, beanName, owner);
/*     */   }
/*     */ 
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition beanDefinition, String beanName, BeanFactory owner)
/*     */   {
/* 106 */     throw new UnsupportedOperationException("Method Injection not supported in SimpleInstantiationStrategy");
/*     */   }
/*     */ 
/*     */   public Object instantiate(RootBeanDefinition beanDefinition, String beanName, BeanFactory owner, final Constructor<?> ctor, Object[] args)
/*     */   {
/* 114 */     if (beanDefinition.getMethodOverrides().isEmpty()) {
/* 115 */       if (System.getSecurityManager() != null)
/*     */       {
/* 117 */         AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 120 */             ReflectionUtils.makeAccessible(ctor);
/* 121 */             return null;
/*     */           }
/*     */         });
/*     */       }
/* 125 */       return BeanUtils.instantiateClass(ctor, args);
/*     */     }
/*     */ 
/* 128 */     return instantiateWithMethodInjection(beanDefinition, beanName, owner, ctor, args);
/*     */   }
/*     */ 
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition beanDefinition, String beanName, BeanFactory owner, Constructor<?> ctor, Object[] args)
/*     */   {
/* 141 */     throw new UnsupportedOperationException("Method Injection not supported in SimpleInstantiationStrategy");
/*     */   }
/*     */ 
/*     */   public Object instantiate(RootBeanDefinition beanDefinition, String beanName, BeanFactory owner, Object factoryBean, final Method factoryMethod, Object[] args)
/*     */   {
/*     */     try
/*     */     {
/* 150 */       if (System.getSecurityManager() != null) {
/* 151 */         AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run() {
/* 154 */             ReflectionUtils.makeAccessible(factoryMethod);
/* 155 */             return null;
/*     */           }
/*     */         });
/*     */       }
/*     */       else {
/* 160 */         ReflectionUtils.makeAccessible(factoryMethod);
/*     */       }
/*     */ 
/* 163 */       Method priorInvokedFactoryMethod = (Method)currentlyInvokedFactoryMethod.get();
/*     */       try {
/* 165 */         currentlyInvokedFactoryMethod.set(factoryMethod);
/* 166 */         return factoryMethod.invoke(factoryBean, args);
/*     */       }
/*     */       finally {
/* 169 */         if (priorInvokedFactoryMethod != null) {
/* 170 */           currentlyInvokedFactoryMethod.set(priorInvokedFactoryMethod);
/*     */         }
/*     */         else {
/* 173 */           currentlyInvokedFactoryMethod.remove();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 180 */       throw new BeanDefinitionStoreException("Illegal arguments to factory method [" + factoryMethod + "]; " + "args: " + 
/* 180 */         StringUtils.arrayToCommaDelimitedString(args));
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 183 */       throw new BeanDefinitionStoreException("Cannot access factory method [" + factoryMethod + "]; is it public?");
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 188 */       throw new BeanDefinitionStoreException("Factory method [" + factoryMethod + "] threw exception", ex
/* 188 */         .getTargetException());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.SimpleInstantiationStrategy
 * JD-Core Version:    0.6.2
 */