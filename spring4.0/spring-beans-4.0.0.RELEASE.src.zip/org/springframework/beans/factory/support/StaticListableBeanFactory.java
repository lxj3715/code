/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanIsNotAFactoryException;
/*     */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.beans.factory.SmartFactoryBean;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class StaticListableBeanFactory
/*     */   implements ListableBeanFactory
/*     */ {
/*  61 */   private final Map<String, Object> beans = new HashMap();
/*     */ 
/*     */   public void addBean(String name, Object bean)
/*     */   {
/*  71 */     this.beans.put(name, bean);
/*     */   }
/*     */ 
/*     */   public Object getBean(String name)
/*     */     throws BeansException
/*     */   {
/*  81 */     String beanName = BeanFactoryUtils.transformedBeanName(name);
/*  82 */     Object bean = this.beans.get(beanName);
/*     */ 
/*  84 */     if (bean == null)
/*     */     {
/*  86 */       throw new NoSuchBeanDefinitionException(beanName, "Defined beans are [" + 
/*  86 */         StringUtils.collectionToCommaDelimitedString(this.beans
/*  86 */         .keySet()) + "]");
/*     */     }
/*     */ 
/*  91 */     if ((BeanFactoryUtils.isFactoryDereference(name)) && (!(bean instanceof FactoryBean))) {
/*  92 */       throw new BeanIsNotAFactoryException(beanName, bean.getClass());
/*     */     }
/*     */ 
/*  95 */     if (((bean instanceof FactoryBean)) && (!BeanFactoryUtils.isFactoryDereference(name))) {
/*     */       try {
/*  97 */         return ((FactoryBean)bean).getObject();
/*     */       }
/*     */       catch (Exception ex) {
/* 100 */         throw new BeanCreationException(beanName, "FactoryBean threw exception on object creation", ex);
/*     */       }
/*     */     }
/*     */ 
/* 104 */     return bean;
/*     */   }
/*     */ 
/*     */   public <T> T getBean(String name, Class<T> requiredType)
/*     */     throws BeansException
/*     */   {
/* 111 */     Object bean = getBean(name);
/* 112 */     if ((requiredType != null) && (!requiredType.isAssignableFrom(bean.getClass()))) {
/* 113 */       throw new BeanNotOfRequiredTypeException(name, requiredType, bean.getClass());
/*     */     }
/* 115 */     return bean;
/*     */   }
/*     */ 
/*     */   public <T> T getBean(Class<T> requiredType) throws BeansException
/*     */   {
/* 120 */     String[] beanNames = getBeanNamesForType(requiredType);
/* 121 */     if (beanNames.length == 1) {
/* 122 */       return getBean(beanNames[0], requiredType);
/*     */     }
/* 124 */     if (beanNames.length > 1) {
/* 125 */       throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*     */     }
/*     */ 
/* 128 */     throw new NoSuchBeanDefinitionException(requiredType);
/*     */   }
/*     */ 
/*     */   public Object getBean(String name, Object[] args)
/*     */     throws BeansException
/*     */   {
/* 134 */     if (args != null) {
/* 135 */       throw new UnsupportedOperationException("StaticListableBeanFactory does not support explicit bean creation arguments)");
/*     */     }
/*     */ 
/* 138 */     return getBean(name);
/*     */   }
/*     */ 
/*     */   public boolean containsBean(String name)
/*     */   {
/* 143 */     return this.beans.containsKey(name);
/*     */   }
/*     */ 
/*     */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException
/*     */   {
/* 148 */     Object bean = getBean(name);
/*     */ 
/* 150 */     return ((bean instanceof FactoryBean)) && (((FactoryBean)bean).isSingleton());
/*     */   }
/*     */ 
/*     */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException
/*     */   {
/* 155 */     Object bean = getBean(name);
/*     */ 
/* 158 */     return (((bean instanceof SmartFactoryBean)) && (((SmartFactoryBean)bean).isPrototype())) || (((bean instanceof FactoryBean)) && 
/* 158 */       (!((FactoryBean)bean)
/* 158 */       .isSingleton()));
/*     */   }
/*     */ 
/*     */   public boolean isTypeMatch(String name, Class<?> targetType) throws NoSuchBeanDefinitionException
/*     */   {
/* 163 */     Class type = getType(name);
/* 164 */     return (targetType == null) || ((type != null) && (targetType.isAssignableFrom(type)));
/*     */   }
/*     */ 
/*     */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException
/*     */   {
/* 169 */     String beanName = BeanFactoryUtils.transformedBeanName(name);
/*     */ 
/* 171 */     Object bean = this.beans.get(beanName);
/* 172 */     if (bean == null)
/*     */     {
/* 174 */       throw new NoSuchBeanDefinitionException(beanName, "Defined beans are [" + 
/* 174 */         StringUtils.collectionToCommaDelimitedString(this.beans
/* 174 */         .keySet()) + "]");
/*     */     }
/*     */ 
/* 177 */     if (((bean instanceof FactoryBean)) && (!BeanFactoryUtils.isFactoryDereference(name)))
/*     */     {
/* 179 */       return ((FactoryBean)bean).getObjectType();
/*     */     }
/* 181 */     return bean.getClass();
/*     */   }
/*     */ 
/*     */   public String[] getAliases(String name)
/*     */   {
/* 186 */     return new String[0];
/*     */   }
/*     */ 
/*     */   public boolean containsBeanDefinition(String name)
/*     */   {
/* 196 */     return this.beans.containsKey(name);
/*     */   }
/*     */ 
/*     */   public int getBeanDefinitionCount()
/*     */   {
/* 201 */     return this.beans.size();
/*     */   }
/*     */ 
/*     */   public String[] getBeanDefinitionNames()
/*     */   {
/* 206 */     return StringUtils.toStringArray(this.beans.keySet());
/*     */   }
/*     */ 
/*     */   public String[] getBeanNamesForType(Class<?> type)
/*     */   {
/* 211 */     return getBeanNamesForType(type, true, true);
/*     */   }
/*     */ 
/*     */   public String[] getBeanNamesForType(Class<?> type, boolean includeNonSingletons, boolean includeFactoryBeans)
/*     */   {
/* 216 */     boolean isFactoryType = (type != null) && (FactoryBean.class.isAssignableFrom(type));
/* 217 */     List matches = new ArrayList();
/* 218 */     for (String name : this.beans.keySet()) {
/* 219 */       Object beanInstance = this.beans.get(name);
/* 220 */       if (((beanInstance instanceof FactoryBean)) && (!isFactoryType)) {
/* 221 */         if (includeFactoryBeans) {
/* 222 */           Class objectType = ((FactoryBean)beanInstance).getObjectType();
/* 223 */           if ((objectType != null) && ((type == null) || (type.isAssignableFrom(objectType)))) {
/* 224 */             matches.add(name);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 229 */       else if ((type == null) || (type.isInstance(beanInstance))) {
/* 230 */         matches.add(name);
/*     */       }
/*     */     }
/*     */ 
/* 234 */     return StringUtils.toStringArray(matches);
/*     */   }
/*     */ 
/*     */   public <T> Map<String, T> getBeansOfType(Class<T> type) throws BeansException
/*     */   {
/* 239 */     return getBeansOfType(type, true, true);
/*     */   }
/*     */ 
/*     */   public <T> Map<String, T> getBeansOfType(Class<T> type, boolean includeNonSingletons, boolean includeFactoryBeans)
/*     */     throws BeansException
/*     */   {
/* 247 */     boolean isFactoryType = (type != null) && (FactoryBean.class.isAssignableFrom(type));
/* 248 */     Map matches = new HashMap();
/*     */ 
/* 250 */     for (Map.Entry entry : this.beans.entrySet()) {
/* 251 */       String beanName = (String)entry.getKey();
/* 252 */       Object beanInstance = entry.getValue();
/*     */ 
/* 254 */       if (((beanInstance instanceof FactoryBean)) && (!isFactoryType)) {
/* 255 */         if (includeFactoryBeans)
/*     */         {
/* 257 */           FactoryBean factory = (FactoryBean)beanInstance;
/* 258 */           Class objectType = factory.getObjectType();
/* 259 */           if (((includeNonSingletons) || (factory.isSingleton())) && (objectType != null) && ((type == null) || 
/* 260 */             (type
/* 260 */             .isAssignableFrom(objectType))))
/*     */           {
/* 261 */             matches.put(beanName, getBean(beanName, type));
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 266 */       else if ((type == null) || (type.isInstance(beanInstance)))
/*     */       {
/* 269 */         if (isFactoryType) {
/* 270 */           beanName = "&" + beanName;
/*     */         }
/* 272 */         matches.put(beanName, beanInstance);
/*     */       }
/*     */     }
/*     */ 
/* 276 */     return matches;
/*     */   }
/*     */ 
/*     */   public String[] getBeanNamesForAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 281 */     List results = new ArrayList();
/* 282 */     for (String beanName : this.beans.keySet()) {
/* 283 */       if (findAnnotationOnBean(beanName, annotationType) != null) {
/* 284 */         results.add(beanName);
/*     */       }
/*     */     }
/* 287 */     return (String[])results.toArray(new String[results.size()]);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> annotationType)
/*     */     throws BeansException
/*     */   {
/* 294 */     Map results = new LinkedHashMap();
/* 295 */     for (String beanName : this.beans.keySet()) {
/* 296 */       if (findAnnotationOnBean(beanName, annotationType) != null) {
/* 297 */         results.put(beanName, getBean(beanName));
/*     */       }
/*     */     }
/* 300 */     return results;
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType)
/*     */     throws NoSuchBeanDefinitionException
/*     */   {
/* 307 */     return AnnotationUtils.findAnnotation(getType(beanName), annotationType);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.support.StaticListableBeanFactory
 * JD-Core Version:    0.6.2
 */