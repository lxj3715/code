package org.springframework.beans.factory.wiring;

public abstract interface BeanWiringInfoResolver
{
  public abstract BeanWiringInfo resolveWiringInfo(Object paramObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.wiring.BeanWiringInfoResolver
 * JD-Core Version:    0.6.2
 */