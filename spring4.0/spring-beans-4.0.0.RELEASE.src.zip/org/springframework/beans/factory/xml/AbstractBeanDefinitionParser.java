/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public abstract class AbstractBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   public static final String ID_ATTRIBUTE = "id";
/*     */   public static final String NAME_ATTRIBUTE = "name";
/*     */ 
/*     */   public final BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  60 */     AbstractBeanDefinition definition = parseInternal(element, parserContext);
/*  61 */     if ((definition != null) && (!parserContext.isNested())) {
/*     */       try {
/*  63 */         String id = resolveId(element, definition, parserContext);
/*  64 */         if (!StringUtils.hasText(id)) {
/*  65 */           parserContext.getReaderContext().error("Id is required for element '" + parserContext
/*  66 */             .getDelegate().getLocalName(element) + "' when used as a top-level tag", element);
/*     */         }
/*     */ 
/*  69 */         String[] aliases = new String[0];
/*  70 */         String name = element.getAttribute("name");
/*  71 */         if (StringUtils.hasLength(name)) {
/*  72 */           aliases = StringUtils.trimArrayElements(StringUtils.commaDelimitedListToStringArray(name));
/*     */         }
/*  74 */         BeanDefinitionHolder holder = new BeanDefinitionHolder(definition, id, aliases);
/*  75 */         registerBeanDefinition(holder, parserContext.getRegistry());
/*  76 */         if (shouldFireEvents()) {
/*  77 */           BeanComponentDefinition componentDefinition = new BeanComponentDefinition(holder);
/*  78 */           postProcessComponentDefinition(componentDefinition);
/*  79 */           parserContext.registerComponent(componentDefinition);
/*     */         }
/*     */       }
/*     */       catch (BeanDefinitionStoreException ex) {
/*  83 */         parserContext.getReaderContext().error(ex.getMessage(), element);
/*  84 */         return null;
/*     */       }
/*     */     }
/*  87 */     return definition;
/*     */   }
/*     */ 
/*     */   protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 106 */     if (shouldGenerateId()) {
/* 107 */       return parserContext.getReaderContext().generateBeanName(definition);
/*     */     }
/*     */ 
/* 110 */     String id = element.getAttribute("id");
/* 111 */     if ((!StringUtils.hasText(id)) && (shouldGenerateIdAsFallback())) {
/* 112 */       id = parserContext.getReaderContext().generateBeanName(definition);
/*     */     }
/* 114 */     return id;
/*     */   }
/*     */ 
/*     */   protected void registerBeanDefinition(BeanDefinitionHolder definition, BeanDefinitionRegistry registry)
/*     */   {
/* 133 */     BeanDefinitionReaderUtils.registerBeanDefinition(definition, registry);
/*     */   }
/*     */ 
/*     */   protected abstract AbstractBeanDefinition parseInternal(Element paramElement, ParserContext paramParserContext);
/*     */ 
/*     */   protected boolean shouldGenerateId()
/*     */   {
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean shouldGenerateIdAsFallback()
/*     */   {
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean shouldFireEvents()
/*     */   {
/* 185 */     return true;
/*     */   }
/*     */ 
/*     */   protected void postProcessComponentDefinition(BeanComponentDefinition componentDefinition)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.AbstractBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */