/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ 
/*     */ public abstract class AbstractSimpleBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*     */ {
/*     */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */   {
/* 128 */     NamedNodeMap attributes = element.getAttributes();
/* 129 */     for (int x = 0; x < attributes.getLength(); x++) {
/* 130 */       Attr attribute = (Attr)attributes.item(x);
/* 131 */       if (isEligibleAttribute(attribute, parserContext)) {
/* 132 */         String propertyName = extractPropertyName(attribute.getLocalName());
/* 133 */         Assert.state(StringUtils.hasText(propertyName), "Illegal property name returned from 'extractPropertyName(String)': cannot be null or empty.");
/*     */ 
/* 135 */         builder.addPropertyValue(propertyName, attribute.getValue());
/*     */       }
/*     */     }
/* 138 */     postProcess(builder, element);
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleAttribute(Attr attribute, ParserContext parserContext)
/*     */   {
/* 151 */     boolean eligible = isEligibleAttribute(attribute);
/* 152 */     if (!eligible) {
/* 153 */       String fullName = attribute.getName();
/*     */ 
/* 155 */       eligible = (!fullName.equals("xmlns")) && (!fullName.startsWith("xmlns:")) && 
/* 155 */         (isEligibleAttribute(parserContext
/* 155 */         .getDelegate().getLocalName(attribute)));
/*     */     }
/* 157 */     return eligible;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected boolean isEligibleAttribute(Attr attribute)
/*     */   {
/* 171 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleAttribute(String attributeName)
/*     */   {
/* 183 */     return !"id".equals(attributeName);
/*     */   }
/*     */ 
/*     */   protected String extractPropertyName(String attributeName)
/*     */   {
/* 200 */     return Conventions.attributeNameToPropertyName(attributeName);
/*     */   }
/*     */ 
/*     */   protected void postProcess(BeanDefinitionBuilder beanDefinition, Element element)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */