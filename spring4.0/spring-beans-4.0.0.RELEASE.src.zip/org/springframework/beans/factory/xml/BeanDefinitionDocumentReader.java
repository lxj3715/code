package org.springframework.beans.factory.xml;

import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.core.env.Environment;
import org.w3c.dom.Document;

public abstract interface BeanDefinitionDocumentReader
{
  public abstract void setEnvironment(Environment paramEnvironment);

  public abstract void registerBeanDefinitions(Document paramDocument, XmlReaderContext paramXmlReaderContext)
    throws BeanDefinitionStoreException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.BeanDefinitionDocumentReader
 * JD-Core Version:    0.6.2
 */