/*      */ package org.springframework.beans.factory.xml;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeanMetadataAttribute;
/*      */ import org.springframework.beans.BeanMetadataAttributeAccessor;
/*      */ import org.springframework.beans.MutablePropertyValues;
/*      */ import org.springframework.beans.PropertyValue;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues.ValueHolder;
/*      */ import org.springframework.beans.factory.config.RuntimeBeanNameReference;
/*      */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*      */ import org.springframework.beans.factory.config.TypedStringValue;
/*      */ import org.springframework.beans.factory.parsing.BeanEntry;
/*      */ import org.springframework.beans.factory.parsing.ConstructorArgumentEntry;
/*      */ import org.springframework.beans.factory.parsing.ParseState;
/*      */ import org.springframework.beans.factory.parsing.PropertyEntry;
/*      */ import org.springframework.beans.factory.parsing.QualifierEntry;
/*      */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*      */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionDefaults;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*      */ import org.springframework.beans.factory.support.LookupOverride;
/*      */ import org.springframework.beans.factory.support.ManagedArray;
/*      */ import org.springframework.beans.factory.support.ManagedList;
/*      */ import org.springframework.beans.factory.support.ManagedMap;
/*      */ import org.springframework.beans.factory.support.ManagedProperties;
/*      */ import org.springframework.beans.factory.support.ManagedSet;
/*      */ import org.springframework.beans.factory.support.MethodOverrides;
/*      */ import org.springframework.beans.factory.support.ReplaceOverride;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.core.env.StandardEnvironment;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.PatternMatchUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.xml.DomUtils;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ public class BeanDefinitionParserDelegate
/*      */ {
/*      */   public static final String BEANS_NAMESPACE_URI = "http://www.springframework.org/schema/beans";
/*      */   public static final String MULTI_VALUE_ATTRIBUTE_DELIMITERS = ",; ";
/*      */ 
/*      */   @Deprecated
/*      */   public static final String BEAN_NAME_DELIMITERS = ",; ";
/*      */   public static final String TRUE_VALUE = "true";
/*      */   public static final String FALSE_VALUE = "false";
/*      */   public static final String DEFAULT_VALUE = "default";
/*      */   public static final String DESCRIPTION_ELEMENT = "description";
/*      */   public static final String AUTOWIRE_NO_VALUE = "no";
/*      */   public static final String AUTOWIRE_BY_NAME_VALUE = "byName";
/*      */   public static final String AUTOWIRE_BY_TYPE_VALUE = "byType";
/*      */   public static final String AUTOWIRE_CONSTRUCTOR_VALUE = "constructor";
/*      */   public static final String AUTOWIRE_AUTODETECT_VALUE = "autodetect";
/*      */   public static final String DEPENDENCY_CHECK_ALL_ATTRIBUTE_VALUE = "all";
/*      */   public static final String DEPENDENCY_CHECK_SIMPLE_ATTRIBUTE_VALUE = "simple";
/*      */   public static final String DEPENDENCY_CHECK_OBJECTS_ATTRIBUTE_VALUE = "objects";
/*      */   public static final String NAME_ATTRIBUTE = "name";
/*      */   public static final String BEAN_ELEMENT = "bean";
/*      */   public static final String META_ELEMENT = "meta";
/*      */   public static final String ID_ATTRIBUTE = "id";
/*      */   public static final String PARENT_ATTRIBUTE = "parent";
/*      */   public static final String CLASS_ATTRIBUTE = "class";
/*      */   public static final String ABSTRACT_ATTRIBUTE = "abstract";
/*      */   public static final String SCOPE_ATTRIBUTE = "scope";
/*      */   public static final String LAZY_INIT_ATTRIBUTE = "lazy-init";
/*      */   public static final String AUTOWIRE_ATTRIBUTE = "autowire";
/*      */   public static final String AUTOWIRE_CANDIDATE_ATTRIBUTE = "autowire-candidate";
/*      */   public static final String PRIMARY_ATTRIBUTE = "primary";
/*      */   public static final String DEPENDENCY_CHECK_ATTRIBUTE = "dependency-check";
/*      */   public static final String DEPENDS_ON_ATTRIBUTE = "depends-on";
/*      */   public static final String INIT_METHOD_ATTRIBUTE = "init-method";
/*      */   public static final String DESTROY_METHOD_ATTRIBUTE = "destroy-method";
/*      */   public static final String FACTORY_METHOD_ATTRIBUTE = "factory-method";
/*      */   public static final String FACTORY_BEAN_ATTRIBUTE = "factory-bean";
/*      */   public static final String CONSTRUCTOR_ARG_ELEMENT = "constructor-arg";
/*      */   public static final String INDEX_ATTRIBUTE = "index";
/*      */   public static final String TYPE_ATTRIBUTE = "type";
/*      */   public static final String VALUE_TYPE_ATTRIBUTE = "value-type";
/*      */   public static final String KEY_TYPE_ATTRIBUTE = "key-type";
/*      */   public static final String PROPERTY_ELEMENT = "property";
/*      */   public static final String REF_ATTRIBUTE = "ref";
/*      */   public static final String VALUE_ATTRIBUTE = "value";
/*      */   public static final String LOOKUP_METHOD_ELEMENT = "lookup-method";
/*      */   public static final String REPLACED_METHOD_ELEMENT = "replaced-method";
/*      */   public static final String REPLACER_ATTRIBUTE = "replacer";
/*      */   public static final String ARG_TYPE_ELEMENT = "arg-type";
/*      */   public static final String ARG_TYPE_MATCH_ATTRIBUTE = "match";
/*      */   public static final String REF_ELEMENT = "ref";
/*      */   public static final String IDREF_ELEMENT = "idref";
/*      */   public static final String BEAN_REF_ATTRIBUTE = "bean";
/*      */   public static final String LOCAL_REF_ATTRIBUTE = "local";
/*      */   public static final String PARENT_REF_ATTRIBUTE = "parent";
/*      */   public static final String VALUE_ELEMENT = "value";
/*      */   public static final String NULL_ELEMENT = "null";
/*      */   public static final String ARRAY_ELEMENT = "array";
/*      */   public static final String LIST_ELEMENT = "list";
/*      */   public static final String SET_ELEMENT = "set";
/*      */   public static final String MAP_ELEMENT = "map";
/*      */   public static final String ENTRY_ELEMENT = "entry";
/*      */   public static final String KEY_ELEMENT = "key";
/*      */   public static final String KEY_ATTRIBUTE = "key";
/*      */   public static final String KEY_REF_ATTRIBUTE = "key-ref";
/*      */   public static final String VALUE_REF_ATTRIBUTE = "value-ref";
/*      */   public static final String PROPS_ELEMENT = "props";
/*      */   public static final String PROP_ELEMENT = "prop";
/*      */   public static final String MERGE_ATTRIBUTE = "merge";
/*      */   public static final String QUALIFIER_ELEMENT = "qualifier";
/*      */   public static final String QUALIFIER_ATTRIBUTE_ELEMENT = "attribute";
/*      */   public static final String DEFAULT_LAZY_INIT_ATTRIBUTE = "default-lazy-init";
/*      */   public static final String DEFAULT_MERGE_ATTRIBUTE = "default-merge";
/*      */   public static final String DEFAULT_AUTOWIRE_ATTRIBUTE = "default-autowire";
/*      */   public static final String DEFAULT_DEPENDENCY_CHECK_ATTRIBUTE = "default-dependency-check";
/*      */   public static final String DEFAULT_AUTOWIRE_CANDIDATES_ATTRIBUTE = "default-autowire-candidates";
/*      */   public static final String DEFAULT_INIT_METHOD_ATTRIBUTE = "default-init-method";
/*      */   public static final String DEFAULT_DESTROY_METHOD_ATTRIBUTE = "default-destroy-method";
/*  243 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */   private final XmlReaderContext readerContext;
/*  247 */   private final DocumentDefaultsDefinition defaults = new DocumentDefaultsDefinition();
/*      */ 
/*  249 */   private final ParseState parseState = new ParseState();
/*      */   private Environment environment;
/*  258 */   private final Set<String> usedNames = new HashSet();
/*      */ 
/*      */   public BeanDefinitionParserDelegate(XmlReaderContext readerContext, Environment environment)
/*      */   {
/*  266 */     Assert.notNull(readerContext, "XmlReaderContext must not be null");
/*  267 */     Assert.notNull(readerContext, "Environment must not be null");
/*  268 */     this.readerContext = readerContext;
/*  269 */     this.environment = environment;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public BeanDefinitionParserDelegate(XmlReaderContext readerContext)
/*      */   {
/*  280 */     this(readerContext, new StandardEnvironment());
/*      */   }
/*      */ 
/*      */   public final XmlReaderContext getReaderContext()
/*      */   {
/*  287 */     return this.readerContext;
/*      */   }
/*      */ 
/*      */   public final Environment getEnvironment()
/*      */   {
/*  294 */     return this.environment;
/*      */   }
/*      */ 
/*      */   protected Object extractSource(Element ele)
/*      */   {
/*  302 */     return this.readerContext.extractSource(ele);
/*      */   }
/*      */ 
/*      */   protected void error(String message, Node source)
/*      */   {
/*  309 */     this.readerContext.error(message, source, this.parseState.snapshot());
/*      */   }
/*      */ 
/*      */   protected void error(String message, Element source)
/*      */   {
/*  316 */     this.readerContext.error(message, source, this.parseState.snapshot());
/*      */   }
/*      */ 
/*      */   protected void error(String message, Element source, Throwable cause)
/*      */   {
/*  323 */     this.readerContext.error(message, source, this.parseState.snapshot(), cause);
/*      */   }
/*      */ 
/*      */   public void initDefaults(Element root)
/*      */   {
/*  331 */     initDefaults(root, null);
/*      */   }
/*      */ 
/*      */   public void initDefaults(Element root, BeanDefinitionParserDelegate parent)
/*      */   {
/*  343 */     populateDefaults(this.defaults, parent != null ? parent.defaults : null, root);
/*  344 */     this.readerContext.fireDefaultsRegistered(this.defaults);
/*      */   }
/*      */ 
/*      */   protected void populateDefaults(DocumentDefaultsDefinition defaults, DocumentDefaultsDefinition parentDefaults, Element root)
/*      */   {
/*  358 */     String lazyInit = root.getAttribute("default-lazy-init");
/*  359 */     if ("default".equals(lazyInit)) {
/*  360 */       lazyInit = parentDefaults != null ? parentDefaults.getLazyInit() : "false";
/*      */     }
/*  362 */     defaults.setLazyInit(lazyInit);
/*      */ 
/*  364 */     String merge = root.getAttribute("default-merge");
/*  365 */     if ("default".equals(merge)) {
/*  366 */       merge = parentDefaults != null ? parentDefaults.getMerge() : "false";
/*      */     }
/*  368 */     defaults.setMerge(merge);
/*      */ 
/*  370 */     String autowire = root.getAttribute("default-autowire");
/*  371 */     if ("default".equals(autowire)) {
/*  372 */       autowire = parentDefaults != null ? parentDefaults.getAutowire() : "no";
/*      */     }
/*  374 */     defaults.setAutowire(autowire);
/*      */ 
/*  379 */     defaults.setDependencyCheck(root.getAttribute("default-dependency-check"));
/*      */ 
/*  381 */     if (root.hasAttribute("default-autowire-candidates")) {
/*  382 */       defaults.setAutowireCandidates(root.getAttribute("default-autowire-candidates"));
/*      */     }
/*  384 */     else if (parentDefaults != null) {
/*  385 */       defaults.setAutowireCandidates(parentDefaults.getAutowireCandidates());
/*      */     }
/*      */ 
/*  388 */     if (root.hasAttribute("default-init-method")) {
/*  389 */       defaults.setInitMethod(root.getAttribute("default-init-method"));
/*      */     }
/*  391 */     else if (parentDefaults != null) {
/*  392 */       defaults.setInitMethod(parentDefaults.getInitMethod());
/*      */     }
/*      */ 
/*  395 */     if (root.hasAttribute("default-destroy-method")) {
/*  396 */       defaults.setDestroyMethod(root.getAttribute("default-destroy-method"));
/*      */     }
/*  398 */     else if (parentDefaults != null) {
/*  399 */       defaults.setDestroyMethod(parentDefaults.getDestroyMethod());
/*      */     }
/*      */ 
/*  402 */     defaults.setSource(this.readerContext.extractSource(root));
/*      */   }
/*      */ 
/*      */   public DocumentDefaultsDefinition getDefaults()
/*      */   {
/*  410 */     return this.defaults;
/*      */   }
/*      */ 
/*      */   public BeanDefinitionDefaults getBeanDefinitionDefaults()
/*      */   {
/*  418 */     BeanDefinitionDefaults bdd = new BeanDefinitionDefaults();
/*  419 */     bdd.setLazyInit("TRUE".equalsIgnoreCase(this.defaults.getLazyInit()));
/*  420 */     bdd.setDependencyCheck(getDependencyCheck("default"));
/*  421 */     bdd.setAutowireMode(getAutowireMode("default"));
/*  422 */     bdd.setInitMethodName(this.defaults.getInitMethod());
/*  423 */     bdd.setDestroyMethodName(this.defaults.getDestroyMethod());
/*  424 */     return bdd;
/*      */   }
/*      */ 
/*      */   public String[] getAutowireCandidatePatterns()
/*      */   {
/*  432 */     String candidatePattern = this.defaults.getAutowireCandidates();
/*  433 */     return candidatePattern != null ? StringUtils.commaDelimitedListToStringArray(candidatePattern) : null;
/*      */   }
/*      */ 
/*      */   public BeanDefinitionHolder parseBeanDefinitionElement(Element ele)
/*      */   {
/*  443 */     return parseBeanDefinitionElement(ele, null);
/*      */   }
/*      */ 
/*      */   public BeanDefinitionHolder parseBeanDefinitionElement(Element ele, BeanDefinition containingBean)
/*      */   {
/*  452 */     String id = ele.getAttribute("id");
/*  453 */     String nameAttr = ele.getAttribute("name");
/*      */ 
/*  455 */     List aliases = new ArrayList();
/*  456 */     if (StringUtils.hasLength(nameAttr)) {
/*  457 */       String[] nameArr = StringUtils.tokenizeToStringArray(nameAttr, ",; ");
/*  458 */       aliases.addAll(Arrays.asList(nameArr));
/*      */     }
/*      */ 
/*  461 */     String beanName = id;
/*  462 */     if ((!StringUtils.hasText(beanName)) && (!aliases.isEmpty())) {
/*  463 */       beanName = (String)aliases.remove(0);
/*  464 */       if (this.logger.isDebugEnabled()) {
/*  465 */         this.logger.debug("No XML 'id' specified - using '" + beanName + "' as bean name and " + aliases + " as aliases");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  470 */     if (containingBean == null) {
/*  471 */       checkNameUniqueness(beanName, aliases, ele);
/*      */     }
/*      */ 
/*  474 */     AbstractBeanDefinition beanDefinition = parseBeanDefinitionElement(ele, beanName, containingBean);
/*  475 */     if (beanDefinition != null) {
/*  476 */       if (!StringUtils.hasText(beanName)) {
/*      */         try {
/*  478 */           if (containingBean != null) {
/*  479 */             beanName = BeanDefinitionReaderUtils.generateBeanName(beanDefinition, this.readerContext
/*  480 */               .getRegistry(), true);
/*      */           }
/*      */           else {
/*  483 */             beanName = this.readerContext.generateBeanName(beanDefinition);
/*      */ 
/*  487 */             String beanClassName = beanDefinition.getBeanClassName();
/*  488 */             if ((beanClassName != null) && 
/*  489 */               (beanName
/*  489 */               .startsWith(beanClassName)) && 
/*  489 */               (beanName.length() > beanClassName.length()) && 
/*  490 */               (!this.readerContext
/*  490 */               .getRegistry().isBeanNameInUse(beanClassName))) {
/*  491 */               aliases.add(beanClassName);
/*      */             }
/*      */           }
/*  494 */           if (this.logger.isDebugEnabled()) {
/*  495 */             this.logger.debug("Neither XML 'id' nor 'name' specified - using generated bean name [" + beanName + "]");
/*      */           }
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*  500 */           error(ex.getMessage(), ele);
/*  501 */           return null;
/*      */         }
/*      */       }
/*  504 */       String[] aliasesArray = StringUtils.toStringArray(aliases);
/*  505 */       return new BeanDefinitionHolder(beanDefinition, beanName, aliasesArray);
/*      */     }
/*      */ 
/*  508 */     return null;
/*      */   }
/*      */ 
/*      */   protected void checkNameUniqueness(String beanName, List<String> aliases, Element beanElement)
/*      */   {
/*  516 */     String foundName = null;
/*      */ 
/*  518 */     if ((StringUtils.hasText(beanName)) && (this.usedNames.contains(beanName))) {
/*  519 */       foundName = beanName;
/*      */     }
/*  521 */     if (foundName == null) {
/*  522 */       foundName = (String)CollectionUtils.findFirstMatch(this.usedNames, aliases);
/*      */     }
/*  524 */     if (foundName != null) {
/*  525 */       error("Bean name '" + foundName + "' is already used in this <beans> element", beanElement);
/*      */     }
/*      */ 
/*  528 */     this.usedNames.add(beanName);
/*  529 */     this.usedNames.addAll(aliases);
/*      */   }
/*      */ 
/*      */   public AbstractBeanDefinition parseBeanDefinitionElement(Element ele, String beanName, BeanDefinition containingBean)
/*      */   {
/*  539 */     this.parseState.push(new BeanEntry(beanName));
/*      */ 
/*  541 */     String className = null;
/*  542 */     if (ele.hasAttribute("class")) {
/*  543 */       className = ele.getAttribute("class").trim();
/*      */     }
/*      */     try
/*      */     {
/*  547 */       String parent = null;
/*  548 */       if (ele.hasAttribute("parent")) {
/*  549 */         parent = ele.getAttribute("parent");
/*      */       }
/*  551 */       AbstractBeanDefinition bd = createBeanDefinition(className, parent);
/*      */ 
/*  553 */       parseBeanDefinitionAttributes(ele, beanName, containingBean, bd);
/*  554 */       bd.setDescription(DomUtils.getChildElementValueByTagName(ele, "description"));
/*      */ 
/*  556 */       parseMetaElements(ele, bd);
/*  557 */       parseLookupOverrideSubElements(ele, bd.getMethodOverrides());
/*  558 */       parseReplacedMethodSubElements(ele, bd.getMethodOverrides());
/*      */ 
/*  560 */       parseConstructorArgElements(ele, bd);
/*  561 */       parsePropertyElements(ele, bd);
/*  562 */       parseQualifierElements(ele, bd);
/*      */ 
/*  564 */       bd.setResource(this.readerContext.getResource());
/*  565 */       bd.setSource(extractSource(ele));
/*      */ 
/*  567 */       return bd;
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/*  570 */       error("Bean class [" + className + "] not found", ele, ex);
/*      */     }
/*      */     catch (NoClassDefFoundError err) {
/*  573 */       error("Class that bean class [" + className + "] depends on not found", ele, err);
/*      */     }
/*      */     catch (Throwable ex) {
/*  576 */       error("Unexpected failure during bean definition parsing", ele, ex);
/*      */     }
/*      */     finally {
/*  579 */       this.parseState.pop();
/*      */     }
/*      */ 
/*  582 */     return null;
/*      */   }
/*      */ 
/*      */   public AbstractBeanDefinition parseBeanDefinitionAttributes(Element ele, String beanName, BeanDefinition containingBean, AbstractBeanDefinition bd)
/*      */   {
/*  595 */     if (ele.hasAttribute("scope")) {
/*  596 */       bd.setScope(ele.getAttribute("scope"));
/*      */     }
/*  598 */     else if (containingBean != null)
/*      */     {
/*  600 */       bd.setScope(containingBean.getScope());
/*      */     }
/*      */ 
/*  603 */     if (ele.hasAttribute("abstract")) {
/*  604 */       bd.setAbstract("true".equals(ele.getAttribute("abstract")));
/*      */     }
/*      */ 
/*  607 */     String lazyInit = ele.getAttribute("lazy-init");
/*  608 */     if ("default".equals(lazyInit)) {
/*  609 */       lazyInit = this.defaults.getLazyInit();
/*      */     }
/*  611 */     bd.setLazyInit("true".equals(lazyInit));
/*      */ 
/*  613 */     String autowire = ele.getAttribute("autowire");
/*  614 */     bd.setAutowireMode(getAutowireMode(autowire));
/*      */ 
/*  616 */     String dependencyCheck = ele.getAttribute("dependency-check");
/*  617 */     bd.setDependencyCheck(getDependencyCheck(dependencyCheck));
/*      */ 
/*  619 */     if (ele.hasAttribute("depends-on")) {
/*  620 */       String dependsOn = ele.getAttribute("depends-on");
/*  621 */       bd.setDependsOn(StringUtils.tokenizeToStringArray(dependsOn, ",; "));
/*      */     }
/*      */ 
/*  624 */     String autowireCandidate = ele.getAttribute("autowire-candidate");
/*  625 */     if (("".equals(autowireCandidate)) || ("default".equals(autowireCandidate))) {
/*  626 */       String candidatePattern = this.defaults.getAutowireCandidates();
/*  627 */       if (candidatePattern != null) {
/*  628 */         String[] patterns = StringUtils.commaDelimitedListToStringArray(candidatePattern);
/*  629 */         bd.setAutowireCandidate(PatternMatchUtils.simpleMatch(patterns, beanName));
/*      */       }
/*      */     }
/*      */     else {
/*  633 */       bd.setAutowireCandidate("true".equals(autowireCandidate));
/*      */     }
/*      */ 
/*  636 */     if (ele.hasAttribute("primary")) {
/*  637 */       bd.setPrimary("true".equals(ele.getAttribute("primary")));
/*      */     }
/*      */ 
/*  640 */     if (ele.hasAttribute("init-method")) {
/*  641 */       String initMethodName = ele.getAttribute("init-method");
/*  642 */       if (!"".equals(initMethodName)) {
/*  643 */         bd.setInitMethodName(initMethodName);
/*      */       }
/*      */ 
/*      */     }
/*  647 */     else if (this.defaults.getInitMethod() != null) {
/*  648 */       bd.setInitMethodName(this.defaults.getInitMethod());
/*  649 */       bd.setEnforceInitMethod(false);
/*      */     }
/*      */ 
/*  653 */     if (ele.hasAttribute("destroy-method")) {
/*  654 */       String destroyMethodName = ele.getAttribute("destroy-method");
/*  655 */       if (!"".equals(destroyMethodName)) {
/*  656 */         bd.setDestroyMethodName(destroyMethodName);
/*      */       }
/*      */ 
/*      */     }
/*  660 */     else if (this.defaults.getDestroyMethod() != null) {
/*  661 */       bd.setDestroyMethodName(this.defaults.getDestroyMethod());
/*  662 */       bd.setEnforceDestroyMethod(false);
/*      */     }
/*      */ 
/*  666 */     if (ele.hasAttribute("factory-method")) {
/*  667 */       bd.setFactoryMethodName(ele.getAttribute("factory-method"));
/*      */     }
/*  669 */     if (ele.hasAttribute("factory-bean")) {
/*  670 */       bd.setFactoryBeanName(ele.getAttribute("factory-bean"));
/*      */     }
/*      */ 
/*  673 */     return bd;
/*      */   }
/*      */ 
/*      */   protected AbstractBeanDefinition createBeanDefinition(String className, String parentName)
/*      */     throws ClassNotFoundException
/*      */   {
/*  686 */     return BeanDefinitionReaderUtils.createBeanDefinition(parentName, className, this.readerContext
/*  687 */       .getBeanClassLoader());
/*      */   }
/*      */ 
/*      */   public void parseMetaElements(Element ele, BeanMetadataAttributeAccessor attributeAccessor) {
/*  691 */     NodeList nl = ele.getChildNodes();
/*  692 */     for (int i = 0; i < nl.getLength(); i++) {
/*  693 */       Node node = nl.item(i);
/*  694 */       if ((isCandidateElement(node)) && (nodeNameEquals(node, "meta"))) {
/*  695 */         Element metaElement = (Element)node;
/*  696 */         String key = metaElement.getAttribute("key");
/*  697 */         String value = metaElement.getAttribute("value");
/*  698 */         BeanMetadataAttribute attribute = new BeanMetadataAttribute(key, value);
/*  699 */         attribute.setSource(extractSource(metaElement));
/*  700 */         attributeAccessor.addMetadataAttribute(attribute);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getAutowireMode(String attValue)
/*      */   {
/*  707 */     String att = attValue;
/*  708 */     if ("default".equals(att)) {
/*  709 */       att = this.defaults.getAutowire();
/*      */     }
/*  711 */     int autowire = 0;
/*  712 */     if ("byName".equals(att)) {
/*  713 */       autowire = 1;
/*      */     }
/*  715 */     else if ("byType".equals(att)) {
/*  716 */       autowire = 2;
/*      */     }
/*  718 */     else if ("constructor".equals(att)) {
/*  719 */       autowire = 3;
/*      */     }
/*  721 */     else if ("autodetect".equals(att)) {
/*  722 */       autowire = 4;
/*      */     }
/*      */ 
/*  725 */     return autowire;
/*      */   }
/*      */ 
/*      */   public int getDependencyCheck(String attValue) {
/*  729 */     String att = attValue;
/*  730 */     if ("default".equals(att)) {
/*  731 */       att = this.defaults.getDependencyCheck();
/*      */     }
/*  733 */     if ("all".equals(att)) {
/*  734 */       return 3;
/*      */     }
/*  736 */     if ("objects".equals(att)) {
/*  737 */       return 1;
/*      */     }
/*  739 */     if ("simple".equals(att)) {
/*  740 */       return 2;
/*      */     }
/*      */ 
/*  743 */     return 0;
/*      */   }
/*      */ 
/*      */   public void parseConstructorArgElements(Element beanEle, BeanDefinition bd)
/*      */   {
/*  751 */     NodeList nl = beanEle.getChildNodes();
/*  752 */     for (int i = 0; i < nl.getLength(); i++) {
/*  753 */       Node node = nl.item(i);
/*  754 */       if ((isCandidateElement(node)) && (nodeNameEquals(node, "constructor-arg")))
/*  755 */         parseConstructorArgElement((Element)node, bd);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void parsePropertyElements(Element beanEle, BeanDefinition bd)
/*      */   {
/*  764 */     NodeList nl = beanEle.getChildNodes();
/*  765 */     for (int i = 0; i < nl.getLength(); i++) {
/*  766 */       Node node = nl.item(i);
/*  767 */       if ((isCandidateElement(node)) && (nodeNameEquals(node, "property")))
/*  768 */         parsePropertyElement((Element)node, bd);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void parseQualifierElements(Element beanEle, AbstractBeanDefinition bd)
/*      */   {
/*  777 */     NodeList nl = beanEle.getChildNodes();
/*  778 */     for (int i = 0; i < nl.getLength(); i++) {
/*  779 */       Node node = nl.item(i);
/*  780 */       if ((isCandidateElement(node)) && (nodeNameEquals(node, "qualifier")))
/*  781 */         parseQualifierElement((Element)node, bd);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void parseLookupOverrideSubElements(Element beanEle, MethodOverrides overrides)
/*      */   {
/*  790 */     NodeList nl = beanEle.getChildNodes();
/*  791 */     for (int i = 0; i < nl.getLength(); i++) {
/*  792 */       Node node = nl.item(i);
/*  793 */       if ((isCandidateElement(node)) && (nodeNameEquals(node, "lookup-method"))) {
/*  794 */         Element ele = (Element)node;
/*  795 */         String methodName = ele.getAttribute("name");
/*  796 */         String beanRef = ele.getAttribute("bean");
/*  797 */         LookupOverride override = new LookupOverride(methodName, beanRef);
/*  798 */         override.setSource(extractSource(ele));
/*  799 */         overrides.addOverride(override);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void parseReplacedMethodSubElements(Element beanEle, MethodOverrides overrides)
/*      */   {
/*  808 */     NodeList nl = beanEle.getChildNodes();
/*  809 */     for (int i = 0; i < nl.getLength(); i++) {
/*  810 */       Node node = nl.item(i);
/*  811 */       if ((isCandidateElement(node)) && (nodeNameEquals(node, "replaced-method"))) {
/*  812 */         Element replacedMethodEle = (Element)node;
/*  813 */         String name = replacedMethodEle.getAttribute("name");
/*  814 */         String callback = replacedMethodEle.getAttribute("replacer");
/*  815 */         ReplaceOverride replaceOverride = new ReplaceOverride(name, callback);
/*      */ 
/*  817 */         List argTypeEles = DomUtils.getChildElementsByTagName(replacedMethodEle, "arg-type");
/*  818 */         for (Element argTypeEle : argTypeEles) {
/*  819 */           String match = argTypeEle.getAttribute("match");
/*  820 */           match = StringUtils.hasText(match) ? match : DomUtils.getTextValue(argTypeEle);
/*  821 */           if (StringUtils.hasText(match)) {
/*  822 */             replaceOverride.addTypeIdentifier(match);
/*      */           }
/*      */         }
/*  825 */         replaceOverride.setSource(extractSource(replacedMethodEle));
/*  826 */         overrides.addOverride(replaceOverride);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void parseConstructorArgElement(Element ele, BeanDefinition bd)
/*      */   {
/*  835 */     String indexAttr = ele.getAttribute("index");
/*  836 */     String typeAttr = ele.getAttribute("type");
/*  837 */     String nameAttr = ele.getAttribute("name");
/*  838 */     if (StringUtils.hasLength(indexAttr))
/*      */       try {
/*  840 */         int index = Integer.parseInt(indexAttr);
/*  841 */         if (index < 0)
/*  842 */           error("'index' cannot be lower than 0", ele);
/*      */         else
/*      */           try
/*      */           {
/*  846 */             this.parseState.push(new ConstructorArgumentEntry(index));
/*  847 */             Object value = parsePropertyValue(ele, bd, null);
/*  848 */             ConstructorArgumentValues.ValueHolder valueHolder = new ConstructorArgumentValues.ValueHolder(value);
/*  849 */             if (StringUtils.hasLength(typeAttr)) {
/*  850 */               valueHolder.setType(typeAttr);
/*      */             }
/*  852 */             if (StringUtils.hasLength(nameAttr)) {
/*  853 */               valueHolder.setName(nameAttr);
/*      */             }
/*  855 */             valueHolder.setSource(extractSource(ele));
/*  856 */             if (bd.getConstructorArgumentValues().hasIndexedArgumentValue(index)) {
/*  857 */               error("Ambiguous constructor-arg entries for index " + index, ele);
/*      */             }
/*      */             else
/*  860 */               bd.getConstructorArgumentValues().addIndexedArgumentValue(index, valueHolder);
/*      */           }
/*      */           finally
/*      */           {
/*  864 */             this.parseState.pop();
/*      */           }
/*      */       }
/*      */       catch (NumberFormatException ex)
/*      */       {
/*  869 */         error("Attribute 'index' of tag 'constructor-arg' must be an integer", ele);
/*      */       }
/*      */     else
/*      */       try
/*      */       {
/*  874 */         this.parseState.push(new ConstructorArgumentEntry());
/*  875 */         Object value = parsePropertyValue(ele, bd, null);
/*  876 */         ConstructorArgumentValues.ValueHolder valueHolder = new ConstructorArgumentValues.ValueHolder(value);
/*  877 */         if (StringUtils.hasLength(typeAttr)) {
/*  878 */           valueHolder.setType(typeAttr);
/*      */         }
/*  880 */         if (StringUtils.hasLength(nameAttr)) {
/*  881 */           valueHolder.setName(nameAttr);
/*      */         }
/*  883 */         valueHolder.setSource(extractSource(ele));
/*  884 */         bd.getConstructorArgumentValues().addGenericArgumentValue(valueHolder);
/*      */       }
/*      */       finally {
/*  887 */         this.parseState.pop();
/*      */       }
/*      */   }
/*      */ 
/*      */   public void parsePropertyElement(Element ele, BeanDefinition bd)
/*      */   {
/*  896 */     String propertyName = ele.getAttribute("name");
/*  897 */     if (!StringUtils.hasLength(propertyName)) {
/*  898 */       error("Tag 'property' must have a 'name' attribute", ele);
/*  899 */       return;
/*      */     }
/*  901 */     this.parseState.push(new PropertyEntry(propertyName));
/*      */     try {
/*  903 */       if (bd.getPropertyValues().contains(propertyName)) {
/*  904 */         error("Multiple 'property' definitions for property '" + propertyName + "'", ele);
/*  905 */         return;
/*      */       }
/*  907 */       Object val = parsePropertyValue(ele, bd, propertyName);
/*  908 */       PropertyValue pv = new PropertyValue(propertyName, val);
/*  909 */       parseMetaElements(ele, pv);
/*  910 */       pv.setSource(extractSource(ele));
/*  911 */       bd.getPropertyValues().addPropertyValue(pv);
/*      */     }
/*      */     finally {
/*  914 */       this.parseState.pop();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void parseQualifierElement(Element ele, AbstractBeanDefinition bd)
/*      */   {
/*  922 */     String typeName = ele.getAttribute("type");
/*  923 */     if (!StringUtils.hasLength(typeName)) {
/*  924 */       error("Tag 'qualifier' must have a 'type' attribute", ele);
/*  925 */       return;
/*      */     }
/*  927 */     this.parseState.push(new QualifierEntry(typeName));
/*      */     try {
/*  929 */       AutowireCandidateQualifier qualifier = new AutowireCandidateQualifier(typeName);
/*  930 */       qualifier.setSource(extractSource(ele));
/*  931 */       String value = ele.getAttribute("value");
/*  932 */       if (StringUtils.hasLength(value)) {
/*  933 */         qualifier.setAttribute(AutowireCandidateQualifier.VALUE_KEY, value);
/*      */       }
/*  935 */       NodeList nl = ele.getChildNodes();
/*  936 */       for (int i = 0; i < nl.getLength(); i++) {
/*  937 */         Node node = nl.item(i);
/*  938 */         if ((isCandidateElement(node)) && (nodeNameEquals(node, "attribute"))) {
/*  939 */           Element attributeEle = (Element)node;
/*  940 */           String attributeName = attributeEle.getAttribute("key");
/*  941 */           String attributeValue = attributeEle.getAttribute("value");
/*  942 */           if ((StringUtils.hasLength(attributeName)) && (StringUtils.hasLength(attributeValue))) {
/*  943 */             BeanMetadataAttribute attribute = new BeanMetadataAttribute(attributeName, attributeValue);
/*  944 */             attribute.setSource(extractSource(attributeEle));
/*  945 */             qualifier.addMetadataAttribute(attribute);
/*      */           }
/*      */           else {
/*  948 */             error("Qualifier 'attribute' tag must have a 'name' and 'value'", attributeEle);
/*  949 */             return;
/*      */           }
/*      */         }
/*      */       }
/*  953 */       bd.addQualifier(qualifier);
/*      */     }
/*      */     finally {
/*  956 */       this.parseState.pop();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Object parsePropertyValue(Element ele, BeanDefinition bd, String propertyName)
/*      */   {
/*  965 */     String elementName = propertyName != null ? "<property> element for property '" + propertyName + "'" : "<constructor-arg> element";
/*      */ 
/*  970 */     NodeList nl = ele.getChildNodes();
/*  971 */     Element subElement = null;
/*  972 */     for (int i = 0; i < nl.getLength(); i++) {
/*  973 */       Node node = nl.item(i);
/*  974 */       if (((node instanceof Element)) && (!nodeNameEquals(node, "description")) && 
/*  975 */         (!nodeNameEquals(node, "meta")))
/*      */       {
/*  977 */         if (subElement != null) {
/*  978 */           error(elementName + " must not contain more than one sub-element", ele);
/*      */         }
/*      */         else {
/*  981 */           subElement = (Element)node;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  986 */     boolean hasRefAttribute = ele.hasAttribute("ref");
/*  987 */     boolean hasValueAttribute = ele.hasAttribute("value");
/*  988 */     if (((hasRefAttribute) && (hasValueAttribute)) || (((hasRefAttribute) || (hasValueAttribute)) && (subElement != null)))
/*      */     {
/*  990 */       error(elementName + " is only allowed to contain either 'ref' attribute OR 'value' attribute OR sub-element", ele);
/*      */     }
/*      */ 
/*  994 */     if (hasRefAttribute) {
/*  995 */       String refName = ele.getAttribute("ref");
/*  996 */       if (!StringUtils.hasText(refName)) {
/*  997 */         error(elementName + " contains empty 'ref' attribute", ele);
/*      */       }
/*  999 */       RuntimeBeanReference ref = new RuntimeBeanReference(refName);
/* 1000 */       ref.setSource(extractSource(ele));
/* 1001 */       return ref;
/*      */     }
/* 1003 */     if (hasValueAttribute) {
/* 1004 */       TypedStringValue valueHolder = new TypedStringValue(ele.getAttribute("value"));
/* 1005 */       valueHolder.setSource(extractSource(ele));
/* 1006 */       return valueHolder;
/*      */     }
/* 1008 */     if (subElement != null) {
/* 1009 */       return parsePropertySubElement(subElement, bd);
/*      */     }
/*      */ 
/* 1013 */     error(elementName + " must specify a ref or value", ele);
/* 1014 */     return null;
/*      */   }
/*      */ 
/*      */   public Object parsePropertySubElement(Element ele, BeanDefinition bd)
/*      */   {
/* 1019 */     return parsePropertySubElement(ele, bd, null);
/*      */   }
/*      */ 
/*      */   public Object parsePropertySubElement(Element ele, BeanDefinition bd, String defaultValueType)
/*      */   {
/* 1030 */     if (!isDefaultNamespace(ele)) {
/* 1031 */       return parseNestedCustomElement(ele, bd);
/*      */     }
/* 1033 */     if (nodeNameEquals(ele, "bean")) {
/* 1034 */       BeanDefinitionHolder nestedBd = parseBeanDefinitionElement(ele, bd);
/* 1035 */       if (nestedBd != null) {
/* 1036 */         nestedBd = decorateBeanDefinitionIfRequired(ele, nestedBd, bd);
/*      */       }
/* 1038 */       return nestedBd;
/*      */     }
/* 1040 */     if (nodeNameEquals(ele, "ref"))
/*      */     {
/* 1042 */       String refName = ele.getAttribute("bean");
/* 1043 */       boolean toParent = false;
/* 1044 */       if (!StringUtils.hasLength(refName))
/*      */       {
/* 1046 */         refName = ele.getAttribute("local");
/* 1047 */         if (!StringUtils.hasLength(refName))
/*      */         {
/* 1049 */           refName = ele.getAttribute("parent");
/* 1050 */           toParent = true;
/* 1051 */           if (!StringUtils.hasLength(refName)) {
/* 1052 */             error("'bean', 'local' or 'parent' is required for <ref> element", ele);
/* 1053 */             return null;
/*      */           }
/*      */         }
/*      */       }
/* 1057 */       if (!StringUtils.hasText(refName)) {
/* 1058 */         error("<ref> element contains empty target attribute", ele);
/* 1059 */         return null;
/*      */       }
/* 1061 */       RuntimeBeanReference ref = new RuntimeBeanReference(refName, toParent);
/* 1062 */       ref.setSource(extractSource(ele));
/* 1063 */       return ref;
/*      */     }
/* 1065 */     if (nodeNameEquals(ele, "idref")) {
/* 1066 */       return parseIdRefElement(ele);
/*      */     }
/* 1068 */     if (nodeNameEquals(ele, "value")) {
/* 1069 */       return parseValueElement(ele, defaultValueType);
/*      */     }
/* 1071 */     if (nodeNameEquals(ele, "null"))
/*      */     {
/* 1074 */       TypedStringValue nullHolder = new TypedStringValue(null);
/* 1075 */       nullHolder.setSource(extractSource(ele));
/* 1076 */       return nullHolder;
/*      */     }
/* 1078 */     if (nodeNameEquals(ele, "array")) {
/* 1079 */       return parseArrayElement(ele, bd);
/*      */     }
/* 1081 */     if (nodeNameEquals(ele, "list")) {
/* 1082 */       return parseListElement(ele, bd);
/*      */     }
/* 1084 */     if (nodeNameEquals(ele, "set")) {
/* 1085 */       return parseSetElement(ele, bd);
/*      */     }
/* 1087 */     if (nodeNameEquals(ele, "map")) {
/* 1088 */       return parseMapElement(ele, bd);
/*      */     }
/* 1090 */     if (nodeNameEquals(ele, "props")) {
/* 1091 */       return parsePropsElement(ele);
/*      */     }
/*      */ 
/* 1094 */     error("Unknown property sub-element: [" + ele.getNodeName() + "]", ele);
/* 1095 */     return null;
/*      */   }
/*      */ 
/*      */   public Object parseIdRefElement(Element ele)
/*      */   {
/* 1104 */     String refName = ele.getAttribute("bean");
/* 1105 */     if (!StringUtils.hasLength(refName))
/*      */     {
/* 1107 */       refName = ele.getAttribute("local");
/* 1108 */       if (!StringUtils.hasLength(refName)) {
/* 1109 */         error("Either 'bean' or 'local' is required for <idref> element", ele);
/* 1110 */         return null;
/*      */       }
/*      */     }
/* 1113 */     if (!StringUtils.hasText(refName)) {
/* 1114 */       error("<idref> element contains empty target attribute", ele);
/* 1115 */       return null;
/*      */     }
/* 1117 */     RuntimeBeanNameReference ref = new RuntimeBeanNameReference(refName);
/* 1118 */     ref.setSource(extractSource(ele));
/* 1119 */     return ref;
/*      */   }
/*      */ 
/*      */   public Object parseValueElement(Element ele, String defaultTypeName)
/*      */   {
/* 1127 */     String value = DomUtils.getTextValue(ele);
/* 1128 */     String specifiedTypeName = ele.getAttribute("type");
/* 1129 */     String typeName = specifiedTypeName;
/* 1130 */     if (!StringUtils.hasText(typeName))
/* 1131 */       typeName = defaultTypeName;
/*      */     try
/*      */     {
/* 1134 */       TypedStringValue typedValue = buildTypedStringValue(value, typeName);
/* 1135 */       typedValue.setSource(extractSource(ele));
/* 1136 */       typedValue.setSpecifiedTypeName(specifiedTypeName);
/* 1137 */       return typedValue;
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/* 1140 */       error("Type class [" + typeName + "] not found for <value> element", ele, ex);
/* 1141 */     }return value;
/*      */   }
/*      */ 
/*      */   protected TypedStringValue buildTypedStringValue(String value, String targetTypeName)
/*      */     throws ClassNotFoundException
/*      */   {
/* 1152 */     ClassLoader classLoader = this.readerContext.getBeanClassLoader();
/*      */     TypedStringValue typedValue;
/*      */     TypedStringValue typedValue;
/* 1154 */     if (!StringUtils.hasText(targetTypeName)) {
/* 1155 */       typedValue = new TypedStringValue(value);
/*      */     }
/*      */     else
/*      */     {
/*      */       TypedStringValue typedValue;
/* 1157 */       if (classLoader != null) {
/* 1158 */         Class targetType = ClassUtils.forName(targetTypeName, classLoader);
/* 1159 */         typedValue = new TypedStringValue(value, targetType);
/*      */       }
/*      */       else {
/* 1162 */         typedValue = new TypedStringValue(value, targetTypeName);
/*      */       }
/*      */     }
/* 1164 */     return typedValue;
/*      */   }
/*      */ 
/*      */   public Object parseArrayElement(Element arrayEle, BeanDefinition bd)
/*      */   {
/* 1171 */     String elementType = arrayEle.getAttribute("value-type");
/* 1172 */     NodeList nl = arrayEle.getChildNodes();
/* 1173 */     ManagedArray target = new ManagedArray(elementType, nl.getLength());
/* 1174 */     target.setSource(extractSource(arrayEle));
/* 1175 */     target.setElementTypeName(elementType);
/* 1176 */     target.setMergeEnabled(parseMergeAttribute(arrayEle));
/* 1177 */     parseCollectionElements(nl, target, bd, elementType);
/* 1178 */     return target;
/*      */   }
/*      */ 
/*      */   public List<Object> parseListElement(Element collectionEle, BeanDefinition bd)
/*      */   {
/* 1185 */     String defaultElementType = collectionEle.getAttribute("value-type");
/* 1186 */     NodeList nl = collectionEle.getChildNodes();
/* 1187 */     ManagedList target = new ManagedList(nl.getLength());
/* 1188 */     target.setSource(extractSource(collectionEle));
/* 1189 */     target.setElementTypeName(defaultElementType);
/* 1190 */     target.setMergeEnabled(parseMergeAttribute(collectionEle));
/* 1191 */     parseCollectionElements(nl, target, bd, defaultElementType);
/* 1192 */     return target;
/*      */   }
/*      */ 
/*      */   public Set<Object> parseSetElement(Element collectionEle, BeanDefinition bd)
/*      */   {
/* 1199 */     String defaultElementType = collectionEle.getAttribute("value-type");
/* 1200 */     NodeList nl = collectionEle.getChildNodes();
/* 1201 */     ManagedSet target = new ManagedSet(nl.getLength());
/* 1202 */     target.setSource(extractSource(collectionEle));
/* 1203 */     target.setElementTypeName(defaultElementType);
/* 1204 */     target.setMergeEnabled(parseMergeAttribute(collectionEle));
/* 1205 */     parseCollectionElements(nl, target, bd, defaultElementType);
/* 1206 */     return target;
/*      */   }
/*      */ 
/*      */   protected void parseCollectionElements(NodeList elementNodes, Collection<Object> target, BeanDefinition bd, String defaultElementType)
/*      */   {
/* 1212 */     for (int i = 0; i < elementNodes.getLength(); i++) {
/* 1213 */       Node node = elementNodes.item(i);
/* 1214 */       if (((node instanceof Element)) && (!nodeNameEquals(node, "description")))
/* 1215 */         target.add(parsePropertySubElement((Element)node, bd, defaultElementType));
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<Object, Object> parseMapElement(Element mapEle, BeanDefinition bd)
/*      */   {
/* 1224 */     String defaultKeyType = mapEle.getAttribute("key-type");
/* 1225 */     String defaultValueType = mapEle.getAttribute("value-type");
/*      */ 
/* 1227 */     List entryEles = DomUtils.getChildElementsByTagName(mapEle, "entry");
/* 1228 */     ManagedMap map = new ManagedMap(entryEles.size());
/* 1229 */     map.setSource(extractSource(mapEle));
/* 1230 */     map.setKeyTypeName(defaultKeyType);
/* 1231 */     map.setValueTypeName(defaultValueType);
/* 1232 */     map.setMergeEnabled(parseMergeAttribute(mapEle));
/*      */ 
/* 1234 */     for (Element entryEle : entryEles)
/*      */     {
/* 1237 */       NodeList entrySubNodes = entryEle.getChildNodes();
/* 1238 */       Element keyEle = null;
/* 1239 */       Element valueEle = null;
/* 1240 */       for (int j = 0; j < entrySubNodes.getLength(); j++) {
/* 1241 */         Node node = entrySubNodes.item(j);
/* 1242 */         if ((node instanceof Element)) {
/* 1243 */           Element candidateEle = (Element)node;
/* 1244 */           if (nodeNameEquals(candidateEle, "key")) {
/* 1245 */             if (keyEle != null) {
/* 1246 */               error("<entry> element is only allowed to contain one <key> sub-element", entryEle);
/*      */             }
/*      */             else {
/* 1249 */               keyEle = candidateEle;
/*      */             }
/*      */ 
/*      */           }
/* 1254 */           else if (!nodeNameEquals(candidateEle, "description"))
/*      */           {
/* 1257 */             if (valueEle != null) {
/* 1258 */               error("<entry> element must not contain more than one value sub-element", entryEle);
/*      */             }
/*      */             else {
/* 1261 */               valueEle = candidateEle;
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1268 */       Object key = null;
/* 1269 */       boolean hasKeyAttribute = entryEle.hasAttribute("key");
/* 1270 */       boolean hasKeyRefAttribute = entryEle.hasAttribute("key-ref");
/* 1271 */       if (((hasKeyAttribute) && (hasKeyRefAttribute)) || (((hasKeyAttribute) || (hasKeyRefAttribute)) && (keyEle != null)))
/*      */       {
/* 1273 */         error("<entry> element is only allowed to contain either a 'key' attribute OR a 'key-ref' attribute OR a <key> sub-element", entryEle);
/*      */       }
/*      */ 
/* 1276 */       if (hasKeyAttribute) {
/* 1277 */         key = buildTypedStringValueForMap(entryEle.getAttribute("key"), defaultKeyType, entryEle);
/*      */       }
/* 1279 */       else if (hasKeyRefAttribute) {
/* 1280 */         String refName = entryEle.getAttribute("key-ref");
/* 1281 */         if (!StringUtils.hasText(refName)) {
/* 1282 */           error("<entry> element contains empty 'key-ref' attribute", entryEle);
/*      */         }
/* 1284 */         RuntimeBeanReference ref = new RuntimeBeanReference(refName);
/* 1285 */         ref.setSource(extractSource(entryEle));
/* 1286 */         key = ref;
/*      */       }
/* 1288 */       else if (keyEle != null) {
/* 1289 */         key = parseKeyElement(keyEle, bd, defaultKeyType);
/*      */       }
/*      */       else {
/* 1292 */         error("<entry> element must specify a key", entryEle);
/*      */       }
/*      */ 
/* 1296 */       Object value = null;
/* 1297 */       boolean hasValueAttribute = entryEle.hasAttribute("value");
/* 1298 */       boolean hasValueRefAttribute = entryEle.hasAttribute("value-ref");
/* 1299 */       boolean hasValueTypeAttribute = entryEle.hasAttribute("value-type");
/* 1300 */       if (((hasValueAttribute) && (hasValueRefAttribute)) || (((hasValueAttribute) || (hasValueRefAttribute)) && (valueEle != null)))
/*      */       {
/* 1302 */         error("<entry> element is only allowed to contain either 'value' attribute OR 'value-ref' attribute OR <value> sub-element", entryEle);
/*      */       }
/*      */ 
/* 1305 */       if (((hasValueTypeAttribute) && (hasValueRefAttribute)) || ((hasValueTypeAttribute) && (!hasValueAttribute)) || ((hasValueTypeAttribute) && (valueEle != null)))
/*      */       {
/* 1308 */         error("<entry> element is only allowed to contain a 'value-type' attribute when it has a 'value' attribute", entryEle);
/*      */       }
/*      */ 
/* 1311 */       if (hasValueAttribute) {
/* 1312 */         String valueType = entryEle.getAttribute("value-type");
/* 1313 */         if (!StringUtils.hasText(valueType)) {
/* 1314 */           valueType = defaultValueType;
/*      */         }
/* 1316 */         value = buildTypedStringValueForMap(entryEle.getAttribute("value"), valueType, entryEle);
/*      */       }
/* 1318 */       else if (hasValueRefAttribute) {
/* 1319 */         String refName = entryEle.getAttribute("value-ref");
/* 1320 */         if (!StringUtils.hasText(refName)) {
/* 1321 */           error("<entry> element contains empty 'value-ref' attribute", entryEle);
/*      */         }
/* 1323 */         RuntimeBeanReference ref = new RuntimeBeanReference(refName);
/* 1324 */         ref.setSource(extractSource(entryEle));
/* 1325 */         value = ref;
/*      */       }
/* 1327 */       else if (valueEle != null) {
/* 1328 */         value = parsePropertySubElement(valueEle, bd, defaultValueType);
/*      */       }
/*      */       else {
/* 1331 */         error("<entry> element must specify a value", entryEle);
/*      */       }
/*      */ 
/* 1335 */       map.put(key, value);
/*      */     }
/*      */ 
/* 1338 */     return map;
/*      */   }
/*      */ 
/*      */   protected final Object buildTypedStringValueForMap(String value, String defaultTypeName, Element entryEle)
/*      */   {
/*      */     try
/*      */     {
/* 1347 */       TypedStringValue typedValue = buildTypedStringValue(value, defaultTypeName);
/* 1348 */       typedValue.setSource(extractSource(entryEle));
/* 1349 */       return typedValue;
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/* 1352 */       error("Type class [" + defaultTypeName + "] not found for Map key/value type", entryEle, ex);
/* 1353 */     }return value;
/*      */   }
/*      */ 
/*      */   protected Object parseKeyElement(Element keyEle, BeanDefinition bd, String defaultKeyTypeName)
/*      */   {
/* 1361 */     NodeList nl = keyEle.getChildNodes();
/* 1362 */     Element subElement = null;
/* 1363 */     for (int i = 0; i < nl.getLength(); i++) {
/* 1364 */       Node node = nl.item(i);
/* 1365 */       if ((node instanceof Element))
/*      */       {
/* 1367 */         if (subElement != null) {
/* 1368 */           error("<key> element must not contain more than one value sub-element", keyEle);
/*      */         }
/*      */         else {
/* 1371 */           subElement = (Element)node;
/*      */         }
/*      */       }
/*      */     }
/* 1375 */     return parsePropertySubElement(subElement, bd, defaultKeyTypeName);
/*      */   }
/*      */ 
/*      */   public Properties parsePropsElement(Element propsEle)
/*      */   {
/* 1382 */     ManagedProperties props = new ManagedProperties();
/* 1383 */     props.setSource(extractSource(propsEle));
/* 1384 */     props.setMergeEnabled(parseMergeAttribute(propsEle));
/*      */ 
/* 1386 */     List propEles = DomUtils.getChildElementsByTagName(propsEle, "prop");
/* 1387 */     for (Element propEle : propEles) {
/* 1388 */       String key = propEle.getAttribute("key");
/*      */ 
/* 1391 */       String value = DomUtils.getTextValue(propEle).trim();
/* 1392 */       TypedStringValue keyHolder = new TypedStringValue(key);
/* 1393 */       keyHolder.setSource(extractSource(propEle));
/* 1394 */       TypedStringValue valueHolder = new TypedStringValue(value);
/* 1395 */       valueHolder.setSource(extractSource(propEle));
/* 1396 */       props.put(keyHolder, valueHolder);
/*      */     }
/*      */ 
/* 1399 */     return props;
/*      */   }
/*      */ 
/*      */   public boolean parseMergeAttribute(Element collectionElement)
/*      */   {
/* 1406 */     String value = collectionElement.getAttribute("merge");
/* 1407 */     if ("default".equals(value)) {
/* 1408 */       value = this.defaults.getMerge();
/*      */     }
/* 1410 */     return "true".equals(value);
/*      */   }
/*      */ 
/*      */   public BeanDefinition parseCustomElement(Element ele) {
/* 1414 */     return parseCustomElement(ele, null);
/*      */   }
/*      */ 
/*      */   public BeanDefinition parseCustomElement(Element ele, BeanDefinition containingBd) {
/* 1418 */     String namespaceUri = getNamespaceURI(ele);
/* 1419 */     NamespaceHandler handler = this.readerContext.getNamespaceHandlerResolver().resolve(namespaceUri);
/* 1420 */     if (handler == null) {
/* 1421 */       error("Unable to locate Spring NamespaceHandler for XML schema namespace [" + namespaceUri + "]", ele);
/* 1422 */       return null;
/*      */     }
/* 1424 */     return handler.parse(ele, new ParserContext(this.readerContext, this, containingBd));
/*      */   }
/*      */ 
/*      */   public BeanDefinitionHolder decorateBeanDefinitionIfRequired(Element ele, BeanDefinitionHolder definitionHolder) {
/* 1428 */     return decorateBeanDefinitionIfRequired(ele, definitionHolder, null);
/*      */   }
/*      */ 
/*      */   public BeanDefinitionHolder decorateBeanDefinitionIfRequired(Element ele, BeanDefinitionHolder definitionHolder, BeanDefinition containingBd)
/*      */   {
/* 1434 */     BeanDefinitionHolder finalDefinition = definitionHolder;
/*      */ 
/* 1437 */     NamedNodeMap attributes = ele.getAttributes();
/* 1438 */     for (int i = 0; i < attributes.getLength(); i++) {
/* 1439 */       Node node = attributes.item(i);
/* 1440 */       finalDefinition = decorateIfRequired(node, finalDefinition, containingBd);
/*      */     }
/*      */ 
/* 1444 */     NodeList children = ele.getChildNodes();
/* 1445 */     for (int i = 0; i < children.getLength(); i++) {
/* 1446 */       Node node = children.item(i);
/* 1447 */       if (node.getNodeType() == 1) {
/* 1448 */         finalDefinition = decorateIfRequired(node, finalDefinition, containingBd);
/*      */       }
/*      */     }
/* 1451 */     return finalDefinition;
/*      */   }
/*      */ 
/*      */   public BeanDefinitionHolder decorateIfRequired(Node node, BeanDefinitionHolder originalDef, BeanDefinition containingBd)
/*      */   {
/* 1457 */     String namespaceUri = getNamespaceURI(node);
/* 1458 */     if (!isDefaultNamespace(namespaceUri)) {
/* 1459 */       NamespaceHandler handler = this.readerContext.getNamespaceHandlerResolver().resolve(namespaceUri);
/* 1460 */       if (handler != null) {
/* 1461 */         return handler.decorate(node, originalDef, new ParserContext(this.readerContext, this, containingBd));
/*      */       }
/* 1463 */       if ((namespaceUri != null) && (namespaceUri.startsWith("http://www.springframework.org/"))) {
/* 1464 */         error("Unable to locate Spring NamespaceHandler for XML schema namespace [" + namespaceUri + "]", node);
/*      */       }
/* 1468 */       else if (this.logger.isDebugEnabled()) {
/* 1469 */         this.logger.debug("No Spring NamespaceHandler found for XML schema namespace [" + namespaceUri + "]");
/*      */       }
/*      */     }
/*      */ 
/* 1473 */     return originalDef;
/*      */   }
/*      */ 
/*      */   private BeanDefinitionHolder parseNestedCustomElement(Element ele, BeanDefinition containingBd) {
/* 1477 */     BeanDefinition innerDefinition = parseCustomElement(ele, containingBd);
/* 1478 */     if (innerDefinition == null) {
/* 1479 */       error("Incorrect usage of element '" + ele.getNodeName() + "' in a nested manner. " + "This tag cannot be used nested inside <property>.", ele);
/*      */ 
/* 1481 */       return null;
/*      */     }
/*      */ 
/* 1484 */     String id = ele.getNodeName() + "#" + 
/* 1484 */       ObjectUtils.getIdentityHexString(innerDefinition);
/*      */ 
/* 1485 */     if (this.logger.isDebugEnabled()) {
/* 1486 */       this.logger.debug("Using generated bean name [" + id + "] for nested custom element '" + ele
/* 1487 */         .getNodeName() + "'");
/*      */     }
/* 1489 */     return new BeanDefinitionHolder(innerDefinition, id);
/*      */   }
/*      */ 
/*      */   public String getNamespaceURI(Node node)
/*      */   {
/* 1499 */     return node.getNamespaceURI();
/*      */   }
/*      */ 
/*      */   public String getLocalName(Node node)
/*      */   {
/* 1508 */     return node.getLocalName();
/*      */   }
/*      */ 
/*      */   public boolean nodeNameEquals(Node node, String desiredName)
/*      */   {
/* 1521 */     return (desiredName.equals(node.getNodeName())) || (desiredName.equals(getLocalName(node)));
/*      */   }
/*      */ 
/*      */   public boolean isDefaultNamespace(String namespaceUri) {
/* 1525 */     return (!StringUtils.hasLength(namespaceUri)) || ("http://www.springframework.org/schema/beans".equals(namespaceUri));
/*      */   }
/*      */ 
/*      */   public boolean isDefaultNamespace(Node node) {
/* 1529 */     return isDefaultNamespace(getNamespaceURI(node));
/*      */   }
/*      */ 
/*      */   private boolean isCandidateElement(Node node) {
/* 1533 */     return ((node instanceof Element)) && ((isDefaultNamespace(node)) || (!isDefaultNamespace(node.getParentNode())));
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.BeanDefinitionParserDelegate
 * JD-Core Version:    0.6.2
 */