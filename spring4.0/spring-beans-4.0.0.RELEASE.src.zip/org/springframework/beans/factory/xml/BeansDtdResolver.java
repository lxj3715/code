/*    */ package org.springframework.beans.factory.xml;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.io.ClassPathResource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.xml.sax.EntityResolver;
/*    */ import org.xml.sax.InputSource;
/*    */ 
/*    */ public class BeansDtdResolver
/*    */   implements EntityResolver
/*    */ {
/*    */   private static final String DTD_EXTENSION = ".dtd";
/* 48 */   private static final String[] DTD_NAMES = { "spring-beans-2.0", "spring-beans" };
/*    */ 
/* 50 */   private static final Log logger = LogFactory.getLog(BeansDtdResolver.class);
/*    */ 
/*    */   public InputSource resolveEntity(String publicId, String systemId)
/*    */     throws IOException
/*    */   {
/* 55 */     if (logger.isTraceEnabled()) {
/* 56 */       logger.trace("Trying to resolve XML entity with public ID [" + publicId + "] and system ID [" + systemId + "]");
/*    */     }
/*    */ 
/* 59 */     if ((systemId != null) && (systemId.endsWith(".dtd"))) {
/* 60 */       int lastPathSeparator = systemId.lastIndexOf("/");
/* 61 */       for (String DTD_NAME : DTD_NAMES) {
/* 62 */         int dtdNameStart = systemId.indexOf(DTD_NAME);
/* 63 */         if (dtdNameStart > lastPathSeparator) {
/* 64 */           String dtdFile = systemId.substring(dtdNameStart);
/* 65 */           if (logger.isTraceEnabled())
/* 66 */             logger.trace("Trying to locate [" + dtdFile + "] in Spring jar");
/*    */           try
/*    */           {
/* 69 */             Resource resource = new ClassPathResource(dtdFile, getClass());
/* 70 */             InputSource source = new InputSource(resource.getInputStream());
/* 71 */             source.setPublicId(publicId);
/* 72 */             source.setSystemId(systemId);
/* 73 */             if (logger.isDebugEnabled()) {
/* 74 */               logger.debug("Found beans DTD [" + systemId + "] in classpath: " + dtdFile);
/*    */             }
/* 76 */             return source;
/*    */           }
/*    */           catch (IOException ex) {
/* 79 */             if (logger.isDebugEnabled()) {
/* 80 */               logger.debug("Could not resolve beans DTD [" + systemId + "]: not found in class path", ex);
/*    */             }
/*    */           }
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 89 */     return null;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 95 */     return "EntityResolver for DTDs " + Arrays.toString(DTD_NAMES);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.BeansDtdResolver
 * JD-Core Version:    0.6.2
 */