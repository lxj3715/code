/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class DefaultBeanDefinitionDocumentReader
/*     */   implements BeanDefinitionDocumentReader
/*     */ {
/*     */   public static final String BEAN_ELEMENT = "bean";
/*     */   public static final String NESTED_BEANS_ELEMENT = "beans";
/*     */   public static final String ALIAS_ELEMENT = "alias";
/*     */   public static final String NAME_ATTRIBUTE = "name";
/*     */   public static final String ALIAS_ATTRIBUTE = "alias";
/*     */   public static final String IMPORT_ELEMENT = "import";
/*     */   public static final String RESOURCE_ATTRIBUTE = "resource";
/*     */   public static final String PROFILE_ATTRIBUTE = "profile";
/*  78 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Environment environment;
/*     */   private XmlReaderContext readerContext;
/*     */   private BeanDefinitionParserDelegate delegate;
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/*  95 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void registerBeanDefinitions(Document doc, XmlReaderContext readerContext)
/*     */   {
/* 107 */     this.readerContext = readerContext;
/* 108 */     this.logger.debug("Loading bean definitions");
/* 109 */     Element root = doc.getDocumentElement();
/* 110 */     doRegisterBeanDefinitions(root);
/*     */   }
/*     */ 
/*     */   protected void doRegisterBeanDefinitions(Element root)
/*     */   {
/* 121 */     String profileSpec = root.getAttribute("profile");
/* 122 */     if (StringUtils.hasText(profileSpec)) {
/* 123 */       Assert.state(this.environment != null, "Environment must be set for evaluating profiles");
/* 124 */       String[] specifiedProfiles = StringUtils.tokenizeToStringArray(profileSpec, ",; ");
/*     */ 
/* 126 */       if (!this.environment.acceptsProfiles(specifiedProfiles)) {
/* 127 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 137 */     BeanDefinitionParserDelegate parent = this.delegate;
/* 138 */     this.delegate = createDelegate(this.readerContext, root, parent);
/*     */ 
/* 140 */     preProcessXml(root);
/* 141 */     parseBeanDefinitions(root, this.delegate);
/* 142 */     postProcessXml(root);
/*     */ 
/* 144 */     this.delegate = parent;
/*     */   }
/*     */ 
/*     */   protected BeanDefinitionParserDelegate createDelegate(XmlReaderContext readerContext, Element root, BeanDefinitionParserDelegate parentDelegate)
/*     */   {
/* 150 */     BeanDefinitionParserDelegate delegate = new BeanDefinitionParserDelegate(readerContext, this.environment);
/* 151 */     delegate.initDefaults(root, parentDelegate);
/* 152 */     return delegate;
/*     */   }
/*     */ 
/*     */   protected final XmlReaderContext getReaderContext()
/*     */   {
/* 159 */     return this.readerContext;
/*     */   }
/*     */ 
/*     */   protected Object extractSource(Element ele)
/*     */   {
/* 167 */     return this.readerContext.extractSource(ele);
/*     */   }
/*     */ 
/*     */   protected void parseBeanDefinitions(Element root, BeanDefinitionParserDelegate delegate)
/*     */   {
/* 177 */     if (delegate.isDefaultNamespace(root)) {
/* 178 */       NodeList nl = root.getChildNodes();
/* 179 */       for (int i = 0; i < nl.getLength(); i++) {
/* 180 */         Node node = nl.item(i);
/* 181 */         if ((node instanceof Element)) {
/* 182 */           Element ele = (Element)node;
/* 183 */           if (delegate.isDefaultNamespace(ele)) {
/* 184 */             parseDefaultElement(ele, delegate);
/*     */           }
/*     */           else
/* 187 */             delegate.parseCustomElement(ele);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 193 */       delegate.parseCustomElement(root);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void parseDefaultElement(Element ele, BeanDefinitionParserDelegate delegate) {
/* 198 */     if (delegate.nodeNameEquals(ele, "import")) {
/* 199 */       importBeanDefinitionResource(ele);
/*     */     }
/* 201 */     else if (delegate.nodeNameEquals(ele, "alias")) {
/* 202 */       processAliasRegistration(ele);
/*     */     }
/* 204 */     else if (delegate.nodeNameEquals(ele, "bean")) {
/* 205 */       processBeanDefinition(ele, delegate);
/*     */     }
/* 207 */     else if (delegate.nodeNameEquals(ele, "beans"))
/*     */     {
/* 209 */       doRegisterBeanDefinitions(ele);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void importBeanDefinitionResource(Element ele)
/*     */   {
/* 218 */     String location = ele.getAttribute("resource");
/* 219 */     if (!StringUtils.hasText(location)) {
/* 220 */       getReaderContext().error("Resource location must not be empty", ele);
/* 221 */       return;
/*     */     }
/*     */ 
/* 225 */     location = this.environment.resolveRequiredPlaceholders(location);
/*     */ 
/* 227 */     Set actualResources = new LinkedHashSet(4);
/*     */ 
/* 230 */     boolean absoluteLocation = false;
/*     */     try {
/* 232 */       absoluteLocation = (ResourcePatternUtils.isUrl(location)) || (ResourceUtils.toURI(location).isAbsolute());
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/*     */     }
/*     */ 
/* 240 */     if (absoluteLocation) {
/*     */       try {
/* 242 */         int importCount = getReaderContext().getReader().loadBeanDefinitions(location, actualResources);
/* 243 */         if (this.logger.isDebugEnabled())
/* 244 */           this.logger.debug("Imported " + importCount + " bean definitions from URL location [" + location + "]");
/*     */       }
/*     */       catch (BeanDefinitionStoreException ex)
/*     */       {
/* 248 */         getReaderContext().error("Failed to import bean definitions from URL location [" + location + "]", ele, ex);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 256 */         Resource relativeResource = getReaderContext().getResource().createRelative(location);
/*     */         int importCount;
/* 257 */         if (relativeResource.exists()) {
/* 258 */           int importCount = getReaderContext().getReader().loadBeanDefinitions(relativeResource);
/* 259 */           actualResources.add(relativeResource);
/*     */         }
/*     */         else {
/* 262 */           String baseLocation = getReaderContext().getResource().getURL().toString();
/* 263 */           importCount = getReaderContext().getReader().loadBeanDefinitions(
/* 264 */             StringUtils.applyRelativePath(baseLocation, location), 
/* 264 */             actualResources);
/*     */         }
/* 266 */         if (this.logger.isDebugEnabled())
/* 267 */           this.logger.debug("Imported " + importCount + " bean definitions from relative location [" + location + "]");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 271 */         getReaderContext().error("Failed to resolve current resource location", ele, ex);
/*     */       }
/*     */       catch (BeanDefinitionStoreException ex) {
/* 274 */         getReaderContext().error("Failed to import bean definitions from relative location [" + location + "]", ele, ex);
/*     */       }
/*     */     }
/*     */ 
/* 278 */     Resource[] actResArray = (Resource[])actualResources.toArray(new Resource[actualResources.size()]);
/* 279 */     getReaderContext().fireImportProcessed(location, actResArray, extractSource(ele));
/*     */   }
/*     */ 
/*     */   protected void processAliasRegistration(Element ele)
/*     */   {
/* 286 */     String name = ele.getAttribute("name");
/* 287 */     String alias = ele.getAttribute("alias");
/* 288 */     boolean valid = true;
/* 289 */     if (!StringUtils.hasText(name)) {
/* 290 */       getReaderContext().error("Name must not be empty", ele);
/* 291 */       valid = false;
/*     */     }
/* 293 */     if (!StringUtils.hasText(alias)) {
/* 294 */       getReaderContext().error("Alias must not be empty", ele);
/* 295 */       valid = false;
/*     */     }
/* 297 */     if (valid) {
/*     */       try {
/* 299 */         getReaderContext().getRegistry().registerAlias(name, alias);
/*     */       }
/*     */       catch (Exception ex) {
/* 302 */         getReaderContext().error("Failed to register alias '" + alias + "' for bean with name '" + name + "'", ele, ex);
/*     */       }
/*     */ 
/* 305 */       getReaderContext().fireAliasRegistered(name, alias, extractSource(ele));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void processBeanDefinition(Element ele, BeanDefinitionParserDelegate delegate)
/*     */   {
/* 314 */     BeanDefinitionHolder bdHolder = delegate.parseBeanDefinitionElement(ele);
/* 315 */     if (bdHolder != null) {
/* 316 */       bdHolder = delegate.decorateBeanDefinitionIfRequired(ele, bdHolder);
/*     */       try
/*     */       {
/* 319 */         BeanDefinitionReaderUtils.registerBeanDefinition(bdHolder, getReaderContext().getRegistry());
/*     */       }
/*     */       catch (BeanDefinitionStoreException ex) {
/* 322 */         getReaderContext().error("Failed to register bean definition with name '" + bdHolder
/* 323 */           .getBeanName() + "'", ele, ex);
/*     */       }
/*     */ 
/* 326 */       getReaderContext().fireComponentRegistered(new BeanComponentDefinition(bdHolder));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void preProcessXml(Element root)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void postProcessXml(Element root)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.DefaultBeanDefinitionDocumentReader
 * JD-Core Version:    0.6.2
 */