package org.springframework.beans.factory.xml;

public abstract interface NamespaceHandlerResolver
{
  public abstract NamespaceHandler resolve(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.NamespaceHandlerResolver
 * JD-Core Version:    0.6.2
 */