/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues.ValueHolder;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public class SimpleConstructorNamespaceHandler
/*     */   implements NamespaceHandler
/*     */ {
/*     */   private static final String REF_SUFFIX = "-ref";
/*     */   private static final String DELIMITER_PREFIX = "_";
/*     */ 
/*     */   public void init()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  68 */     parserContext.getReaderContext().error("Class [" + 
/*  69 */       getClass().getName() + "] does not support custom elements.", element);
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */   public BeanDefinitionHolder decorate(Node node, BeanDefinitionHolder definition, ParserContext parserContext)
/*     */   {
/*  75 */     if ((node instanceof Attr)) {
/*  76 */       Attr attr = (Attr)node;
/*  77 */       String argName = StringUtils.trimWhitespace(parserContext.getDelegate().getLocalName(attr));
/*  78 */       String argValue = StringUtils.trimWhitespace(attr.getValue());
/*     */ 
/*  80 */       ConstructorArgumentValues cvs = definition.getBeanDefinition().getConstructorArgumentValues();
/*  81 */       boolean ref = false;
/*     */ 
/*  84 */       if (argName.endsWith("-ref")) {
/*  85 */         ref = true;
/*  86 */         argName = argName.substring(0, argName.length() - "-ref".length());
/*     */       }
/*     */ 
/*  89 */       ConstructorArgumentValues.ValueHolder valueHolder = new ConstructorArgumentValues.ValueHolder(ref ? new RuntimeBeanReference(argValue) : argValue);
/*  90 */       valueHolder.setSource(parserContext.getReaderContext().extractSource(attr));
/*     */ 
/*  93 */       if (argName.startsWith("_")) {
/*  94 */         String arg = argName.substring(1).trim();
/*     */ 
/*  97 */         if (!StringUtils.hasText(arg)) {
/*  98 */           cvs.addGenericArgumentValue(valueHolder);
/*     */         }
/*     */         else
/*     */         {
/* 102 */           int index = -1;
/*     */           try {
/* 104 */             index = Integer.parseInt(arg);
/*     */           } catch (NumberFormatException ex) {
/* 106 */             parserContext.getReaderContext().error("Constructor argument '" + argName + "' specifies an invalid integer", attr);
/*     */           }
/*     */ 
/* 109 */           if (index < 0) {
/* 110 */             parserContext.getReaderContext().error("Constructor argument '" + argName + "' specifies a negative index", attr);
/*     */           }
/*     */ 
/* 114 */           if (cvs.hasIndexedArgumentValue(index)) {
/* 115 */             parserContext.getReaderContext().error("Constructor argument '" + argName + "' with index " + index + " already defined using <constructor-arg>." + " Only one approach may be used per argument.", attr);
/*     */           }
/*     */ 
/* 120 */           cvs.addIndexedArgumentValue(index, valueHolder);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 125 */         String name = Conventions.attributeNameToPropertyName(argName);
/* 126 */         if (containsArgWithName(name, cvs)) {
/* 127 */           parserContext.getReaderContext().error("Constructor argument '" + argName + "' already defined using <constructor-arg>." + " Only one approach may be used per argument.", attr);
/*     */         }
/*     */ 
/* 131 */         valueHolder.setName(Conventions.attributeNameToPropertyName(argName));
/* 132 */         cvs.addGenericArgumentValue(valueHolder);
/*     */       }
/*     */     }
/* 135 */     return definition;
/*     */   }
/*     */ 
/*     */   private boolean containsArgWithName(String name, ConstructorArgumentValues cvs) {
/* 139 */     if (!checkName(name, cvs.getGenericArgumentValues())) {
/* 140 */       return checkName(name, cvs.getIndexedArgumentValues().values());
/*     */     }
/*     */ 
/* 143 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean checkName(String name, Collection<ConstructorArgumentValues.ValueHolder> values) {
/* 147 */     for (ConstructorArgumentValues.ValueHolder holder : values) {
/* 148 */       if (name.equals(holder.getName())) {
/* 149 */         return true;
/*     */       }
/*     */     }
/* 152 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.SimpleConstructorNamespaceHandler
 * JD-Core Version:    0.6.2
 */