/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.config.FieldRetrievingFactoryBean;
/*     */ import org.springframework.beans.factory.config.ListFactoryBean;
/*     */ import org.springframework.beans.factory.config.MapFactoryBean;
/*     */ import org.springframework.beans.factory.config.PropertiesFactoryBean;
/*     */ import org.springframework.beans.factory.config.PropertyPathFactoryBean;
/*     */ import org.springframework.beans.factory.config.SetFactoryBean;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public class UtilNamespaceHandler extends NamespaceHandlerSupport
/*     */ {
/*     */   private static final String SCOPE_ATTRIBUTE = "scope";
/*     */ 
/*     */   public void init()
/*     */   {
/*  50 */     registerBeanDefinitionParser("constant", new ConstantBeanDefinitionParser(null));
/*  51 */     registerBeanDefinitionParser("property-path", new PropertyPathBeanDefinitionParser(null));
/*  52 */     registerBeanDefinitionParser("list", new ListBeanDefinitionParser(null));
/*  53 */     registerBeanDefinitionParser("set", new SetBeanDefinitionParser(null));
/*  54 */     registerBeanDefinitionParser("map", new MapBeanDefinitionParser(null));
/*  55 */     registerBeanDefinitionParser("properties", new PropertiesBeanDefinitionParser(null));
/*     */   }
/*     */ 
/*     */   private static class PropertiesBeanDefinitionParser extends AbstractSimpleBeanDefinitionParser
/*     */   {
/*     */     protected Class<?> getBeanClass(Element element)
/*     */     {
/* 187 */       return PropertiesFactoryBean.class;
/*     */     }
/*     */ 
/*     */     protected boolean isEligibleAttribute(String attributeName)
/*     */     {
/* 192 */       return (super.isEligibleAttribute(attributeName)) && (!"scope".equals(attributeName));
/*     */     }
/*     */ 
/*     */     protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */     {
/* 197 */       super.doParse(element, parserContext, builder);
/* 198 */       Properties parsedProps = parserContext.getDelegate().parsePropsElement(element);
/* 199 */       builder.addPropertyValue("properties", parsedProps);
/* 200 */       String scope = element.getAttribute("scope");
/* 201 */       if (StringUtils.hasLength(scope))
/* 202 */         builder.setScope(scope);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MapBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*     */   {
/*     */     protected Class<?> getBeanClass(Element element)
/*     */     {
/* 164 */       return MapFactoryBean.class;
/*     */     }
/*     */ 
/*     */     protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */     {
/* 169 */       String mapClass = element.getAttribute("map-class");
/* 170 */       Map parsedMap = parserContext.getDelegate().parseMapElement(element, builder.getRawBeanDefinition());
/* 171 */       builder.addPropertyValue("sourceMap", parsedMap);
/* 172 */       if (StringUtils.hasText(mapClass)) {
/* 173 */         builder.addPropertyValue("targetMapClass", mapClass);
/*     */       }
/* 175 */       String scope = element.getAttribute("scope");
/* 176 */       if (StringUtils.hasLength(scope))
/* 177 */         builder.setScope(scope);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SetBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*     */   {
/*     */     protected Class<?> getBeanClass(Element element)
/*     */     {
/* 141 */       return SetFactoryBean.class;
/*     */     }
/*     */ 
/*     */     protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */     {
/* 146 */       String setClass = element.getAttribute("set-class");
/* 147 */       Set parsedSet = parserContext.getDelegate().parseSetElement(element, builder.getRawBeanDefinition());
/* 148 */       builder.addPropertyValue("sourceSet", parsedSet);
/* 149 */       if (StringUtils.hasText(setClass)) {
/* 150 */         builder.addPropertyValue("targetSetClass", setClass);
/*     */       }
/* 152 */       String scope = element.getAttribute("scope");
/* 153 */       if (StringUtils.hasLength(scope))
/* 154 */         builder.setScope(scope);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ListBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*     */   {
/*     */     protected Class<?> getBeanClass(Element element)
/*     */     {
/* 118 */       return ListFactoryBean.class;
/*     */     }
/*     */ 
/*     */     protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */     {
/* 123 */       String listClass = element.getAttribute("list-class");
/* 124 */       List parsedList = parserContext.getDelegate().parseListElement(element, builder.getRawBeanDefinition());
/* 125 */       builder.addPropertyValue("sourceList", parsedList);
/* 126 */       if (StringUtils.hasText(listClass)) {
/* 127 */         builder.addPropertyValue("targetListClass", listClass);
/*     */       }
/* 129 */       String scope = element.getAttribute("scope");
/* 130 */       if (StringUtils.hasLength(scope))
/* 131 */         builder.setScope(scope);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PropertyPathBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*     */   {
/*     */     protected Class<?> getBeanClass(Element element)
/*     */     {
/*  81 */       return PropertyPathFactoryBean.class;
/*     */     }
/*     */ 
/*     */     protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */     {
/*  86 */       String path = element.getAttribute("path");
/*  87 */       if (!StringUtils.hasText(path)) {
/*  88 */         parserContext.getReaderContext().error("Attribute 'path' must not be empty", element);
/*  89 */         return;
/*     */       }
/*  91 */       int dotIndex = path.indexOf(".");
/*  92 */       if (dotIndex == -1) {
/*  93 */         parserContext.getReaderContext().error("Attribute 'path' must follow pattern 'beanName.propertyName'", element);
/*     */ 
/*  95 */         return;
/*     */       }
/*  97 */       String beanName = path.substring(0, dotIndex);
/*  98 */       String propertyPath = path.substring(dotIndex + 1);
/*  99 */       builder.addPropertyValue("targetBeanName", beanName);
/* 100 */       builder.addPropertyValue("propertyPath", propertyPath);
/*     */     }
/*     */ 
/*     */     protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext)
/*     */     {
/* 105 */       String id = super.resolveId(element, definition, parserContext);
/* 106 */       if (!StringUtils.hasText(id)) {
/* 107 */         id = element.getAttribute("path");
/*     */       }
/* 109 */       return id;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConstantBeanDefinitionParser extends AbstractSimpleBeanDefinitionParser
/*     */   {
/*     */     protected Class<?> getBeanClass(Element element)
/*     */     {
/*  63 */       return FieldRetrievingFactoryBean.class;
/*     */     }
/*     */ 
/*     */     protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext)
/*     */     {
/*  68 */       String id = super.resolveId(element, definition, parserContext);
/*  69 */       if (!StringUtils.hasText(id)) {
/*  70 */         id = element.getAttribute("static-field");
/*     */       }
/*  72 */       return id;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.UtilNamespaceHandler
 * JD-Core Version:    0.6.2
 */