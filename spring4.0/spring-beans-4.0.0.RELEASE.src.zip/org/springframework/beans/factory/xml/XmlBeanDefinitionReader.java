/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.parsing.EmptyReaderEventListener;
/*     */ import org.springframework.beans.factory.parsing.FailFastProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.NullSourceExtractor;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.ReaderEventListener;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.core.io.DescriptiveResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.xml.SimpleSaxErrorHandler;
/*     */ import org.springframework.util.xml.XmlValidationModeDetector;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ public class XmlBeanDefinitionReader extends AbstractBeanDefinitionReader
/*     */ {
/*     */   public static final int VALIDATION_NONE = 0;
/*     */   public static final int VALIDATION_AUTO = 1;
/*     */   public static final int VALIDATION_DTD = 2;
/*     */   public static final int VALIDATION_XSD = 3;
/* 101 */   private static final Constants constants = new Constants(XmlBeanDefinitionReader.class);
/*     */ 
/* 103 */   private int validationMode = 1;
/*     */ 
/* 105 */   private boolean namespaceAware = false;
/*     */ 
/* 107 */   private Class<?> documentReaderClass = DefaultBeanDefinitionDocumentReader.class;
/*     */ 
/* 109 */   private ProblemReporter problemReporter = new FailFastProblemReporter();
/*     */ 
/* 111 */   private ReaderEventListener eventListener = new EmptyReaderEventListener();
/*     */ 
/* 113 */   private SourceExtractor sourceExtractor = new NullSourceExtractor();
/*     */   private NamespaceHandlerResolver namespaceHandlerResolver;
/* 117 */   private DocumentLoader documentLoader = new DefaultDocumentLoader();
/*     */   private EntityResolver entityResolver;
/* 121 */   private ErrorHandler errorHandler = new SimpleSaxErrorHandler(this.logger);
/*     */ 
/* 123 */   private final XmlValidationModeDetector validationModeDetector = new XmlValidationModeDetector();
/*     */ 
/* 125 */   private final ThreadLocal<Set<EncodedResource>> resourcesCurrentlyBeingLoaded = new NamedThreadLocal("XML bean definition resources currently being loaded");
/*     */ 
/*     */   public XmlBeanDefinitionReader(BeanDefinitionRegistry registry)
/*     */   {
/* 135 */     super(registry);
/*     */   }
/*     */ 
/*     */   public void setValidating(boolean validating)
/*     */   {
/* 146 */     this.validationMode = (validating ? 1 : 0);
/* 147 */     this.namespaceAware = (!validating);
/*     */   }
/*     */ 
/*     */   public void setValidationModeName(String validationModeName)
/*     */   {
/* 155 */     setValidationMode(constants.asNumber(validationModeName).intValue());
/*     */   }
/*     */ 
/*     */   public void setValidationMode(int validationMode)
/*     */   {
/* 165 */     this.validationMode = validationMode;
/*     */   }
/*     */ 
/*     */   public int getValidationMode()
/*     */   {
/* 172 */     return this.validationMode;
/*     */   }
/*     */ 
/*     */   public void setNamespaceAware(boolean namespaceAware)
/*     */   {
/* 183 */     this.namespaceAware = namespaceAware;
/*     */   }
/*     */ 
/*     */   public boolean isNamespaceAware()
/*     */   {
/* 190 */     return this.namespaceAware;
/*     */   }
/*     */ 
/*     */   public void setProblemReporter(ProblemReporter problemReporter)
/*     */   {
/* 200 */     this.problemReporter = (problemReporter != null ? problemReporter : new FailFastProblemReporter());
/*     */   }
/*     */ 
/*     */   public void setEventListener(ReaderEventListener eventListener)
/*     */   {
/* 210 */     this.eventListener = (eventListener != null ? eventListener : new EmptyReaderEventListener());
/*     */   }
/*     */ 
/*     */   public void setSourceExtractor(SourceExtractor sourceExtractor)
/*     */   {
/* 220 */     this.sourceExtractor = (sourceExtractor != null ? sourceExtractor : new NullSourceExtractor());
/*     */   }
/*     */ 
/*     */   public void setNamespaceHandlerResolver(NamespaceHandlerResolver namespaceHandlerResolver)
/*     */   {
/* 229 */     this.namespaceHandlerResolver = namespaceHandlerResolver;
/*     */   }
/*     */ 
/*     */   public void setDocumentLoader(DocumentLoader documentLoader)
/*     */   {
/* 238 */     this.documentLoader = (documentLoader != null ? documentLoader : new DefaultDocumentLoader());
/*     */   }
/*     */ 
/*     */   public void setEntityResolver(EntityResolver entityResolver)
/*     */   {
/* 247 */     this.entityResolver = entityResolver;
/*     */   }
/*     */ 
/*     */   protected EntityResolver getEntityResolver()
/*     */   {
/* 255 */     if (this.entityResolver == null)
/*     */     {
/* 257 */       ResourceLoader resourceLoader = getResourceLoader();
/* 258 */       if (resourceLoader != null) {
/* 259 */         this.entityResolver = new ResourceEntityResolver(resourceLoader);
/*     */       }
/*     */       else {
/* 262 */         this.entityResolver = new DelegatingEntityResolver(getBeanClassLoader());
/*     */       }
/*     */     }
/* 265 */     return this.entityResolver;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/* 277 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   public void setDocumentReaderClass(Class<?> documentReaderClass)
/*     */   {
/* 287 */     if ((documentReaderClass == null) || (!BeanDefinitionDocumentReader.class.isAssignableFrom(documentReaderClass))) {
/* 288 */       throw new IllegalArgumentException("documentReaderClass must be an implementation of the BeanDefinitionDocumentReader interface");
/*     */     }
/*     */ 
/* 291 */     this.documentReaderClass = documentReaderClass;
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(Resource resource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 303 */     return loadBeanDefinitions(new EncodedResource(resource));
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(EncodedResource encodedResource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 314 */     Assert.notNull(encodedResource, "EncodedResource must not be null");
/* 315 */     if (this.logger.isInfoEnabled()) {
/* 316 */       this.logger.info("Loading XML bean definitions from " + encodedResource.getResource());
/*     */     }
/*     */ 
/* 319 */     Set currentResources = (Set)this.resourcesCurrentlyBeingLoaded.get();
/* 320 */     if (currentResources == null) {
/* 321 */       currentResources = new HashSet(4);
/* 322 */       this.resourcesCurrentlyBeingLoaded.set(currentResources);
/*     */     }
/* 324 */     if (!currentResources.add(encodedResource)) {
/* 325 */       throw new BeanDefinitionStoreException("Detected cyclic loading of " + encodedResource + " - check your import definitions!");
/*     */     }
/*     */     try
/*     */     {
/* 329 */       InputStream inputStream = encodedResource.getResource().getInputStream();
/*     */       try {
/* 331 */         InputSource inputSource = new InputSource(inputStream);
/* 332 */         if (encodedResource.getEncoding() != null) {
/* 333 */           inputSource.setEncoding(encodedResource.getEncoding());
/*     */         }
/* 335 */         int i = doLoadBeanDefinitions(inputSource, encodedResource.getResource());
/*     */ 
/* 338 */         inputStream.close();
/*     */ 
/* 348 */         return i;
/*     */       }
/*     */       finally
/*     */       {
/* 338 */         inputStream.close();
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 343 */       throw new BeanDefinitionStoreException("IOException parsing XML document from " + encodedResource
/* 343 */         .getResource(), ex);
/*     */     }
/*     */     finally {
/* 346 */       currentResources.remove(encodedResource);
/* 347 */       if (currentResources.isEmpty())
/* 348 */         this.resourcesCurrentlyBeingLoaded.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(InputSource inputSource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 360 */     return loadBeanDefinitions(inputSource, "resource loaded through SAX InputSource");
/*     */   }
/*     */ 
/*     */   public int loadBeanDefinitions(InputSource inputSource, String resourceDescription)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 374 */     return doLoadBeanDefinitions(inputSource, new DescriptiveResource(resourceDescription));
/*     */   }
/*     */ 
/*     */   protected int doLoadBeanDefinitions(InputSource inputSource, Resource resource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/*     */     try
/*     */     {
/* 390 */       Document doc = doLoadDocument(inputSource, resource);
/* 391 */       return registerBeanDefinitions(doc, resource);
/*     */     }
/*     */     catch (BeanDefinitionStoreException ex) {
/* 394 */       throw ex;
/*     */     }
/*     */     catch (SAXParseException ex)
/*     */     {
/* 398 */       throw new XmlBeanDefinitionStoreException(resource.getDescription(), "Line " + ex
/* 398 */         .getLineNumber() + " in XML document from " + resource + " is invalid", ex);
/*     */     }
/*     */     catch (SAXException ex) {
/* 401 */       throw new XmlBeanDefinitionStoreException(resource.getDescription(), "XML document from " + resource + " is invalid", ex);
/*     */     }
/*     */     catch (ParserConfigurationException ex)
/*     */     {
/* 405 */       throw new BeanDefinitionStoreException(resource.getDescription(), "Parser configuration exception parsing XML from " + resource, ex);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 409 */       throw new BeanDefinitionStoreException(resource.getDescription(), "IOException parsing XML document from " + resource, ex);
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 413 */       throw new BeanDefinitionStoreException(resource.getDescription(), "Unexpected exception parsing XML document from " + resource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Document doLoadDocument(InputSource inputSource, Resource resource)
/*     */     throws Exception
/*     */   {
/* 428 */     return this.documentLoader.loadDocument(inputSource, getEntityResolver(), this.errorHandler, 
/* 429 */       getValidationModeForResource(resource), 
/* 429 */       isNamespaceAware());
/*     */   }
/*     */ 
/*     */   protected int getValidationModeForResource(Resource resource)
/*     */   {
/* 441 */     int validationModeToUse = getValidationMode();
/* 442 */     if (validationModeToUse != 1) {
/* 443 */       return validationModeToUse;
/*     */     }
/* 445 */     int detectedMode = detectValidationMode(resource);
/* 446 */     if (detectedMode != 1) {
/* 447 */       return detectedMode;
/*     */     }
/*     */ 
/* 452 */     return 3;
/*     */   }
/*     */ 
/*     */   protected int detectValidationMode(Resource resource)
/*     */   {
/* 463 */     if (resource.isOpen()) {
/* 464 */       throw new BeanDefinitionStoreException("Passed-in Resource [" + resource + "] contains an open stream: " + "cannot determine validation mode automatically. Either pass in a Resource " + "that is able to create fresh streams, or explicitly specify the validationMode " + "on your XmlBeanDefinitionReader instance.");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 473 */       inputStream = resource.getInputStream();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */       InputStream inputStream;
/* 476 */       throw new BeanDefinitionStoreException("Unable to determine validation mode for [" + resource + "]: cannot open InputStream. " + "Did you attempt to load directly from a SAX InputSource without specifying the " + "validationMode on your XmlBeanDefinitionReader instance?", ex);
/*     */     }
/*     */     try
/*     */     {
/*     */       InputStream inputStream;
/* 483 */       return this.validationModeDetector.detectValidationMode(inputStream);
/*     */     }
/*     */     catch (IOException ex) {
/* 486 */       throw new BeanDefinitionStoreException("Unable to determine validation mode for [" + resource + "]: an error occurred whilst reading from the InputStream.", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int registerBeanDefinitions(Document doc, Resource resource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 505 */     BeanDefinitionDocumentReader documentReader = createBeanDefinitionDocumentReader();
/* 506 */     documentReader.setEnvironment(getEnvironment());
/* 507 */     int countBefore = getRegistry().getBeanDefinitionCount();
/* 508 */     documentReader.registerBeanDefinitions(doc, createReaderContext(resource));
/* 509 */     return getRegistry().getBeanDefinitionCount() - countBefore;
/*     */   }
/*     */ 
/*     */   protected BeanDefinitionDocumentReader createBeanDefinitionDocumentReader()
/*     */   {
/* 519 */     return (BeanDefinitionDocumentReader)BeanDefinitionDocumentReader.class.cast(BeanUtils.instantiateClass(this.documentReaderClass));
/*     */   }
/*     */ 
/*     */   public XmlReaderContext createReaderContext(Resource resource)
/*     */   {
/* 527 */     return new XmlReaderContext(resource, this.problemReporter, this.eventListener, this.sourceExtractor, this, 
/* 527 */       getNamespaceHandlerResolver());
/*     */   }
/*     */ 
/*     */   public NamespaceHandlerResolver getNamespaceHandlerResolver()
/*     */   {
/* 535 */     if (this.namespaceHandlerResolver == null) {
/* 536 */       this.namespaceHandlerResolver = createDefaultNamespaceHandlerResolver();
/*     */     }
/* 538 */     return this.namespaceHandlerResolver;
/*     */   }
/*     */ 
/*     */   protected NamespaceHandlerResolver createDefaultNamespaceHandlerResolver()
/*     */   {
/* 546 */     return new DefaultNamespaceHandlerResolver(getResourceLoader().getClassLoader());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.XmlBeanDefinitionReader
 * JD-Core Version:    0.6.2
 */