/*    */ package org.springframework.beans.factory.xml;
/*    */ 
/*    */ import java.io.StringReader;
/*    */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*    */ import org.springframework.beans.factory.parsing.ReaderContext;
/*    */ import org.springframework.beans.factory.parsing.ReaderEventListener;
/*    */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.w3c.dom.Document;
/*    */ import org.xml.sax.InputSource;
/*    */ 
/*    */ public class XmlReaderContext extends ReaderContext
/*    */ {
/*    */   private final XmlBeanDefinitionReader reader;
/*    */   private final NamespaceHandlerResolver namespaceHandlerResolver;
/*    */ 
/*    */   public XmlReaderContext(Resource resource, ProblemReporter problemReporter, ReaderEventListener eventListener, SourceExtractor sourceExtractor, XmlBeanDefinitionReader reader, NamespaceHandlerResolver namespaceHandlerResolver)
/*    */   {
/* 55 */     super(resource, problemReporter, eventListener, sourceExtractor);
/* 56 */     this.reader = reader;
/* 57 */     this.namespaceHandlerResolver = namespaceHandlerResolver;
/*    */   }
/*    */ 
/*    */   public final XmlBeanDefinitionReader getReader()
/*    */   {
/* 62 */     return this.reader;
/*    */   }
/*    */ 
/*    */   public final BeanDefinitionRegistry getRegistry() {
/* 66 */     return this.reader.getRegistry();
/*    */   }
/*    */ 
/*    */   public final ResourceLoader getResourceLoader() {
/* 70 */     return this.reader.getResourceLoader();
/*    */   }
/*    */ 
/*    */   public final ClassLoader getBeanClassLoader() {
/* 74 */     return this.reader.getBeanClassLoader();
/*    */   }
/*    */ 
/*    */   public final NamespaceHandlerResolver getNamespaceHandlerResolver() {
/* 78 */     return this.namespaceHandlerResolver;
/*    */   }
/*    */ 
/*    */   public String generateBeanName(BeanDefinition beanDefinition)
/*    */   {
/* 83 */     return this.reader.getBeanNameGenerator().generateBeanName(beanDefinition, getRegistry());
/*    */   }
/*    */ 
/*    */   public String registerWithGeneratedName(BeanDefinition beanDefinition) {
/* 87 */     String generatedName = generateBeanName(beanDefinition);
/* 88 */     getRegistry().registerBeanDefinition(generatedName, beanDefinition);
/* 89 */     return generatedName;
/*    */   }
/*    */ 
/*    */   public Document readDocumentFromString(String documentContent) {
/* 93 */     InputSource is = new InputSource(new StringReader(documentContent));
/*    */     try {
/* 95 */       return this.reader.doLoadDocument(is, getResource());
/*    */     }
/*    */     catch (Exception ex) {
/* 98 */       throw new BeanDefinitionStoreException("Failed to read XML document", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.factory.xml.XmlReaderContext
 * JD-Core Version:    0.6.2
 */