/*     */ package org.springframework.beans.propertyeditors;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CharacterEditor extends PropertyEditorSupport
/*     */ {
/*     */   private static final String UNICODE_PREFIX = "\\u";
/*     */   private static final int UNICODE_LENGTH = 6;
/*     */   private final boolean allowEmpty;
/*     */ 
/*     */   public CharacterEditor(boolean allowEmpty)
/*     */   {
/*  68 */     this.allowEmpty = allowEmpty;
/*     */   }
/*     */ 
/*     */   public void setAsText(String text)
/*     */     throws IllegalArgumentException
/*     */   {
/*  74 */     if ((this.allowEmpty) && (!StringUtils.hasLength(text)))
/*     */     {
/*  76 */       setValue(null);
/*     */     } else {
/*  78 */       if (text == null) {
/*  79 */         throw new IllegalArgumentException("null String cannot be converted to char type");
/*     */       }
/*  81 */       if (isUnicodeCharacterSequence(text)) {
/*  82 */         setAsUnicode(text);
/*     */       } else {
/*  84 */         if (text.length() != 1)
/*     */         {
/*  86 */           throw new IllegalArgumentException("String [" + text + "] with length " + text
/*  86 */             .length() + " cannot be converted to char type");
/*     */         }
/*     */ 
/*  89 */         setValue(new Character(text.charAt(0)));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getAsText() {
/*  95 */     Object value = getValue();
/*  96 */     return value != null ? value.toString() : "";
/*     */   }
/*     */ 
/*     */   private boolean isUnicodeCharacterSequence(String sequence)
/*     */   {
/* 101 */     return (sequence.startsWith("\\u")) && (sequence.length() == 6);
/*     */   }
/*     */ 
/*     */   private void setAsUnicode(String text) {
/* 105 */     int code = Integer.parseInt(text.substring("\\u".length()), 16);
/* 106 */     setValue(new Character((char)code));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.propertyeditors.CharacterEditor
 * JD-Core Version:    0.6.2
 */