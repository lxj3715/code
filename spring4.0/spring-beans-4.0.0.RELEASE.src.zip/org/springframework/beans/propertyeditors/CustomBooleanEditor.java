/*     */ package org.springframework.beans.propertyeditors;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CustomBooleanEditor extends PropertyEditorSupport
/*     */ {
/*     */   public static final String VALUE_TRUE = "true";
/*     */   public static final String VALUE_FALSE = "false";
/*     */   public static final String VALUE_ON = "on";
/*     */   public static final String VALUE_OFF = "off";
/*     */   public static final String VALUE_YES = "yes";
/*     */   public static final String VALUE_NO = "no";
/*     */   public static final String VALUE_1 = "1";
/*     */   public static final String VALUE_0 = "0";
/*     */   private final String trueString;
/*     */   private final String falseString;
/*     */   private final boolean allowEmpty;
/*     */ 
/*     */   public CustomBooleanEditor(boolean allowEmpty)
/*     */   {
/*  69 */     this(null, null, allowEmpty);
/*     */   }
/*     */ 
/*     */   public CustomBooleanEditor(String trueString, String falseString, boolean allowEmpty)
/*     */   {
/*  93 */     this.trueString = trueString;
/*  94 */     this.falseString = falseString;
/*  95 */     this.allowEmpty = allowEmpty;
/*     */   }
/*     */ 
/*     */   public void setAsText(String text) throws IllegalArgumentException
/*     */   {
/* 100 */     String input = text != null ? text.trim() : null;
/* 101 */     if ((this.allowEmpty) && (!StringUtils.hasLength(input)))
/*     */     {
/* 103 */       setValue(null);
/*     */     }
/* 105 */     else if ((this.trueString != null) && (input.equalsIgnoreCase(this.trueString))) {
/* 106 */       setValue(Boolean.TRUE);
/*     */     }
/* 108 */     else if ((this.falseString != null) && (input.equalsIgnoreCase(this.falseString))) {
/* 109 */       setValue(Boolean.FALSE);
/*     */     }
/* 111 */     else if ((this.trueString == null) && (
/* 112 */       (input
/* 112 */       .equalsIgnoreCase("true")) || 
/* 112 */       (input.equalsIgnoreCase("on")) || 
/* 113 */       (input
/* 113 */       .equalsIgnoreCase("yes")) || 
/* 113 */       (input.equals("1")))) {
/* 114 */       setValue(Boolean.TRUE);
/*     */     }
/* 116 */     else if ((this.falseString == null) && (
/* 117 */       (input
/* 117 */       .equalsIgnoreCase("false")) || 
/* 117 */       (input.equalsIgnoreCase("off")) || 
/* 118 */       (input
/* 118 */       .equalsIgnoreCase("no")) || 
/* 118 */       (input.equals("0")))) {
/* 119 */       setValue(Boolean.FALSE);
/*     */     }
/*     */     else
/* 122 */       throw new IllegalArgumentException("Invalid boolean value [" + text + "]");
/*     */   }
/*     */ 
/*     */   public String getAsText()
/*     */   {
/* 128 */     if (Boolean.TRUE.equals(getValue())) {
/* 129 */       return this.trueString != null ? this.trueString : "true";
/*     */     }
/* 131 */     if (Boolean.FALSE.equals(getValue())) {
/* 132 */       return this.falseString != null ? this.falseString : "false";
/*     */     }
/*     */ 
/* 135 */     return "";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.propertyeditors.CustomBooleanEditor
 * JD-Core Version:    0.6.2
 */