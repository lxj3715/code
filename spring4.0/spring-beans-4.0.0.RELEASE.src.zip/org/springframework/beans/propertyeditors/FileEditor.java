/*     */ package org.springframework.beans.propertyeditors;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceEditor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class FileEditor extends PropertyEditorSupport
/*     */ {
/*     */   private final ResourceEditor resourceEditor;
/*     */ 
/*     */   public FileEditor()
/*     */   {
/*  66 */     this.resourceEditor = new ResourceEditor();
/*     */   }
/*     */ 
/*     */   public FileEditor(ResourceEditor resourceEditor)
/*     */   {
/*  75 */     Assert.notNull(resourceEditor, "ResourceEditor must not be null");
/*  76 */     this.resourceEditor = resourceEditor;
/*     */   }
/*     */ 
/*     */   public void setAsText(String text)
/*     */     throws IllegalArgumentException
/*     */   {
/*  82 */     if (!StringUtils.hasText(text)) {
/*  83 */       setValue(null);
/*  84 */       return;
/*     */     }
/*     */ 
/*  89 */     if (!ResourceUtils.isUrl(text)) {
/*  90 */       File file = new File(text);
/*  91 */       if (file.isAbsolute()) {
/*  92 */         setValue(file);
/*  93 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  98 */     this.resourceEditor.setAsText(text);
/*  99 */     Resource resource = (Resource)this.resourceEditor.getValue();
/*     */ 
/* 102 */     if ((ResourceUtils.isUrl(text)) || (resource.exists())) {
/*     */       try {
/* 104 */         setValue(resource.getFile());
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 108 */         throw new IllegalArgumentException("Could not retrieve File for " + resource + ": " + ex
/* 108 */           .getMessage());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 113 */       setValue(new File(text));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getAsText()
/*     */   {
/* 119 */     File value = (File)getValue();
/* 120 */     return value != null ? value.getPath() : "";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.propertyeditors.FileEditor
 * JD-Core Version:    0.6.2
 */