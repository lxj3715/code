/*    */ package org.springframework.beans.propertyeditors;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.io.IOException;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceEditor;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class InputStreamEditor extends PropertyEditorSupport
/*    */ {
/*    */   private final ResourceEditor resourceEditor;
/*    */ 
/*    */   public InputStreamEditor()
/*    */   {
/* 54 */     this.resourceEditor = new ResourceEditor();
/*    */   }
/*    */ 
/*    */   public InputStreamEditor(ResourceEditor resourceEditor)
/*    */   {
/* 63 */     Assert.notNull(resourceEditor, "ResourceEditor must not be null");
/* 64 */     this.resourceEditor = resourceEditor;
/*    */   }
/*    */ 
/*    */   public void setAsText(String text)
/*    */     throws IllegalArgumentException
/*    */   {
/* 70 */     this.resourceEditor.setAsText(text);
/* 71 */     Resource resource = (Resource)this.resourceEditor.getValue();
/*    */     try {
/* 73 */       setValue(resource != null ? resource.getInputStream() : null);
/*    */     }
/*    */     catch (IOException ex)
/*    */     {
/* 77 */       throw new IllegalArgumentException("Could not retrieve InputStream for " + resource + ": " + ex
/* 77 */         .getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getAsText()
/*    */   {
/* 87 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.propertyeditors.InputStreamEditor
 * JD-Core Version:    0.6.2
 */