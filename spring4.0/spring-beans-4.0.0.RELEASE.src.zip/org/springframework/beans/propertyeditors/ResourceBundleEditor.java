/*     */ package org.springframework.beans.propertyeditors;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceBundleEditor extends PropertyEditorSupport
/*     */ {
/*     */   public static final String BASE_NAME_SEPARATOR = "_";
/*     */ 
/*     */   public void setAsText(String text)
/*     */     throws IllegalArgumentException
/*     */   {
/*  84 */     Assert.hasText(text, "'text' must not be empty");
/*     */ 
/*  86 */     String rawBaseName = text.trim();
/*  87 */     int indexOfBaseNameSeparator = rawBaseName.indexOf("_");
/*     */     ResourceBundle bundle;
/*     */     ResourceBundle bundle;
/*  88 */     if (indexOfBaseNameSeparator == -1) {
/*  89 */       bundle = ResourceBundle.getBundle(rawBaseName);
/*     */     }
/*     */     else {
/*  92 */       String baseName = rawBaseName.substring(0, indexOfBaseNameSeparator);
/*  93 */       if (!StringUtils.hasText(baseName)) {
/*  94 */         throw new IllegalArgumentException("Bad ResourceBundle name : received '" + text + "' as argument to 'setAsText(String value)'.");
/*     */       }
/*  96 */       String localeString = rawBaseName.substring(indexOfBaseNameSeparator + 1);
/*  97 */       Locale locale = StringUtils.parseLocaleString(localeString);
/*     */ 
/* 100 */       bundle = StringUtils.hasText(localeString) ? 
/*  99 */         ResourceBundle.getBundle(baseName, locale) : 
/* 100 */         ResourceBundle.getBundle(baseName);
/*     */     }
/*     */ 
/* 102 */     setValue(bundle);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.propertyeditors.ResourceBundleEditor
 * JD-Core Version:    0.6.2
 */