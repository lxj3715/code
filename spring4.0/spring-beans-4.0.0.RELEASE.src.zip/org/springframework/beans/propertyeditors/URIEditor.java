/*     */ package org.springframework.beans.propertyeditors;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class URIEditor extends PropertyEditorSupport
/*     */ {
/*     */   private final ClassLoader classLoader;
/*     */   private final boolean encode;
/*     */ 
/*     */   public URIEditor()
/*     */   {
/*  63 */     this.classLoader = null;
/*  64 */     this.encode = true;
/*     */   }
/*     */ 
/*     */   public URIEditor(boolean encode)
/*     */   {
/*  73 */     this.classLoader = null;
/*  74 */     this.encode = encode;
/*     */   }
/*     */ 
/*     */   public URIEditor(ClassLoader classLoader)
/*     */   {
/*  85 */     this.classLoader = (classLoader != null ? classLoader : ClassUtils.getDefaultClassLoader());
/*  86 */     this.encode = true;
/*     */   }
/*     */ 
/*     */   public URIEditor(ClassLoader classLoader, boolean encode)
/*     */   {
/*  97 */     this.classLoader = (classLoader != null ? classLoader : ClassUtils.getDefaultClassLoader());
/*  98 */     this.encode = encode;
/*     */   }
/*     */ 
/*     */   public void setAsText(String text)
/*     */     throws IllegalArgumentException
/*     */   {
/* 104 */     if (StringUtils.hasText(text)) {
/* 105 */       String uri = text.trim();
/* 106 */       if ((this.classLoader != null) && (uri.startsWith("classpath:")))
/*     */       {
/* 108 */         ClassPathResource resource = new ClassPathResource(uri
/* 108 */           .substring("classpath:"
/* 108 */           .length()), this.classLoader);
/*     */         try {
/* 110 */           String url = resource.getURL().toString();
/* 111 */           setValue(createURI(url));
/*     */         }
/*     */         catch (IOException ex) {
/* 114 */           throw new IllegalArgumentException("Could not retrieve URI for " + resource + ": " + ex.getMessage());
/*     */         }
/*     */         catch (URISyntaxException ex) {
/* 117 */           throw new IllegalArgumentException("Invalid URI syntax: " + ex);
/*     */         }
/*     */       }
/*     */       else {
/*     */         try {
/* 122 */           setValue(createURI(uri));
/*     */         }
/*     */         catch (URISyntaxException ex) {
/* 125 */           throw new IllegalArgumentException("Invalid URI syntax: " + ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 130 */       setValue(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected URI createURI(String value)
/*     */     throws URISyntaxException
/*     */   {
/* 143 */     int colonIndex = value.indexOf(':');
/* 144 */     if ((this.encode) && (colonIndex != -1)) {
/* 145 */       int fragmentIndex = value.indexOf('#', colonIndex + 1);
/* 146 */       String scheme = value.substring(0, colonIndex);
/* 147 */       String ssp = value.substring(colonIndex + 1, fragmentIndex > 0 ? fragmentIndex : value.length());
/* 148 */       String fragment = fragmentIndex > 0 ? value.substring(fragmentIndex + 1) : null;
/* 149 */       return new URI(scheme, ssp, fragment);
/*     */     }
/*     */ 
/* 153 */     return new URI(value);
/*     */   }
/*     */ 
/*     */   public String getAsText()
/*     */   {
/* 160 */     URI value = (URI)getValue();
/* 161 */     return value != null ? value.toString() : "";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.propertyeditors.URIEditor
 * JD-Core Version:    0.6.2
 */