/*    */ package org.springframework.beans.propertyeditors;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.time.ZoneId;
/*    */ 
/*    */ public class ZoneIdEditor extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text)
/*    */     throws IllegalArgumentException
/*    */   {
/* 35 */     setValue(ZoneId.of(text));
/*    */   }
/*    */ 
/*    */   public String getAsText()
/*    */   {
/* 40 */     ZoneId value = (ZoneId)getValue();
/* 41 */     return value != null ? value.getId() : "";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.propertyeditors.ZoneIdEditor
 * JD-Core Version:    0.6.2
 */