/*     */ package org.springframework.beans.support;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import org.springframework.beans.PropertyEditorRegistrar;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.PropertyEditorRegistrySupport;
/*     */ import org.springframework.beans.propertyeditors.ClassArrayEditor;
/*     */ import org.springframework.beans.propertyeditors.ClassEditor;
/*     */ import org.springframework.beans.propertyeditors.FileEditor;
/*     */ import org.springframework.beans.propertyeditors.InputSourceEditor;
/*     */ import org.springframework.beans.propertyeditors.InputStreamEditor;
/*     */ import org.springframework.beans.propertyeditors.URIEditor;
/*     */ import org.springframework.beans.propertyeditors.URLEditor;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.ContextResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceEditor;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourceArrayPropertyEditor;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public class ResourceEditorRegistrar
/*     */   implements PropertyEditorRegistrar
/*     */ {
/*     */   private final PropertyResolver propertyResolver;
/*     */   private final ResourceLoader resourceLoader;
/*     */ 
/*     */   @Deprecated
/*     */   public ResourceEditorRegistrar(ResourceLoader resourceLoader)
/*     */   {
/*  77 */     this(resourceLoader, new StandardEnvironment());
/*     */   }
/*     */ 
/*     */   public ResourceEditorRegistrar(ResourceLoader resourceLoader, PropertyResolver propertyResolver)
/*     */   {
/*  91 */     this.resourceLoader = resourceLoader;
/*  92 */     this.propertyResolver = propertyResolver;
/*     */   }
/*     */ 
/*     */   public void registerCustomEditors(PropertyEditorRegistry registry)
/*     */   {
/* 114 */     ResourceEditor baseEditor = new ResourceEditor(this.resourceLoader, this.propertyResolver);
/* 115 */     doRegisterEditor(registry, Resource.class, baseEditor);
/* 116 */     doRegisterEditor(registry, ContextResource.class, baseEditor);
/* 117 */     doRegisterEditor(registry, InputStream.class, new InputStreamEditor(baseEditor));
/* 118 */     doRegisterEditor(registry, InputSource.class, new InputSourceEditor(baseEditor));
/* 119 */     doRegisterEditor(registry, File.class, new FileEditor(baseEditor));
/* 120 */     doRegisterEditor(registry, URL.class, new URLEditor(baseEditor));
/*     */ 
/* 122 */     ClassLoader classLoader = this.resourceLoader.getClassLoader();
/* 123 */     doRegisterEditor(registry, URI.class, new URIEditor(classLoader));
/* 124 */     doRegisterEditor(registry, Class.class, new ClassEditor(classLoader));
/* 125 */     doRegisterEditor(registry, [Ljava.lang.Class.class, new ClassArrayEditor(classLoader));
/*     */ 
/* 127 */     if ((this.resourceLoader instanceof ResourcePatternResolver))
/* 128 */       doRegisterEditor(registry, [Lorg.springframework.core.io.Resource.class, new ResourceArrayPropertyEditor((ResourcePatternResolver)this.resourceLoader, this.propertyResolver));
/*     */   }
/*     */ 
/*     */   private void doRegisterEditor(PropertyEditorRegistry registry, Class<?> requiredType, PropertyEditor editor)
/*     */   {
/* 138 */     if ((registry instanceof PropertyEditorRegistrySupport)) {
/* 139 */       ((PropertyEditorRegistrySupport)registry).overrideDefaultEditor(requiredType, editor);
/*     */     }
/*     */     else
/* 142 */       registry.registerCustomEditor(requiredType, editor);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.support.ResourceEditorRegistrar
 * JD-Core Version:    0.6.2
 */