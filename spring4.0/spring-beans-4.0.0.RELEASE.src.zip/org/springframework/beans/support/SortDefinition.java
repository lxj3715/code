package org.springframework.beans.support;

public abstract interface SortDefinition
{
  public abstract String getProperty();

  public abstract boolean isIgnoreCase();

  public abstract boolean isAscending();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-beans-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.beans.support.SortDefinition
 * JD-Core Version:    0.6.2
 */