package org.springframework.cache;

public abstract interface Cache
{
  public abstract String getName();

  public abstract Object getNativeCache();

  public abstract ValueWrapper get(Object paramObject);

  public abstract <T> T get(Object paramObject, Class<T> paramClass);

  public abstract void put(Object paramObject1, Object paramObject2);

  public abstract void evict(Object paramObject);

  public abstract void clear();

  public static abstract interface ValueWrapper
  {
    public abstract Object get();
  }
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.Cache
 * JD-Core Version:    0.6.2
 */