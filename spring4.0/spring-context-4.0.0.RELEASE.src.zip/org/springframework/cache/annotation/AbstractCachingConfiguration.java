/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.cache.interceptor.KeyGenerator;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ImportAware;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ @Configuration
/*    */ public abstract class AbstractCachingConfiguration
/*    */   implements ImportAware
/*    */ {
/*    */   protected AnnotationAttributes enableCaching;
/*    */   protected CacheManager cacheManager;
/*    */   protected KeyGenerator keyGenerator;
/*    */ 
/*    */   @Autowired(required=false)
/*    */   private Collection<CacheManager> cacheManagerBeans;
/*    */ 
/*    */   @Autowired(required=false)
/*    */   private Collection<CachingConfigurer> cachingConfigurers;
/*    */ 
/*    */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*    */   {
/* 59 */     this.enableCaching = AnnotationAttributes.fromMap(importMetadata
/* 60 */       .getAnnotationAttributes(EnableCaching.class
/* 60 */       .getName(), false));
/* 61 */     Assert.notNull(this.enableCaching, "@EnableCaching is not present on importing class " + importMetadata
/* 63 */       .getClassName());
/*    */   }
/*    */ 
/*    */   @PostConstruct
/*    */   protected void reconcileCacheManager()
/*    */   {
/* 77 */     if (!CollectionUtils.isEmpty(this.cachingConfigurers)) {
/* 78 */       int nConfigurers = this.cachingConfigurers.size();
/* 79 */       if (nConfigurers > 1) {
/* 80 */         throw new IllegalStateException(nConfigurers + " implementations of " + "CachingConfigurer were found when only 1 was expected. " + "Refactor the configuration such that CachingConfigurer is " + "implemented only once or not at all.");
/*    */       }
/*    */ 
/* 85 */       CachingConfigurer cachingConfigurer = (CachingConfigurer)this.cachingConfigurers.iterator().next();
/* 86 */       this.cacheManager = cachingConfigurer.cacheManager();
/* 87 */       this.keyGenerator = cachingConfigurer.keyGenerator();
/*    */     }
/* 89 */     else if (!CollectionUtils.isEmpty(this.cacheManagerBeans)) {
/* 90 */       int nManagers = this.cacheManagerBeans.size();
/* 91 */       if (nManagers > 1) {
/* 92 */         throw new IllegalStateException(nManagers + " beans of type CacheManager " + "were found when only 1 was expected. Remove all but one of the " + "CacheManager bean definitions, or implement CachingConfigurer " + "to make explicit which CacheManager should be used for " + "annotation-driven cache management.");
/*    */       }
/*    */ 
/* 98 */       CacheManager cacheManager = (CacheManager)this.cacheManagerBeans.iterator().next();
/* 99 */       this.cacheManager = cacheManager;
/*    */     }
/*    */     else
/*    */     {
/* 103 */       throw new IllegalStateException("No bean of type CacheManager could be found. Register a CacheManager bean or remove the @EnableCaching annotation from your configuration.");
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.AbstractCachingConfiguration
 * JD-Core Version:    0.6.2
 */