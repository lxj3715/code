/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ 
/*    */ public class CachingConfigurationSelector extends AdviceModeImportSelector<EnableCaching>
/*    */ {
/*    */   public String[] selectImports(AdviceMode adviceMode)
/*    */   {
/* 44 */     switch (1.$SwitchMap$org$springframework$context$annotation$AdviceMode[adviceMode.ordinal()]) {
/*    */     case 1:
/* 46 */       return new String[] { AutoProxyRegistrar.class.getName(), ProxyCachingConfiguration.class.getName() };
/*    */     case 2:
/* 48 */       return new String[] { "org.springframework.cache.aspectj.AspectJCachingConfiguration" };
/*    */     }
/* 50 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.CachingConfigurationSelector
 * JD-Core Version:    0.6.2
 */