/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import org.springframework.cache.interceptor.BeanFactoryCacheOperationSourceAdvisor;
/*    */ import org.springframework.cache.interceptor.CacheInterceptor;
/*    */ import org.springframework.cache.interceptor.CacheOperationSource;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ 
/*    */ @Configuration
/*    */ public class ProxyCachingConfiguration extends AbstractCachingConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.cache.config.internalCacheAdvisor"})
/*    */   @Role(2)
/*    */   public BeanFactoryCacheOperationSourceAdvisor cacheAdvisor()
/*    */   {
/* 43 */     BeanFactoryCacheOperationSourceAdvisor advisor = new BeanFactoryCacheOperationSourceAdvisor();
/*    */ 
/* 45 */     advisor.setCacheOperationSource(cacheOperationSource());
/* 46 */     advisor.setAdvice(cacheInterceptor());
/* 47 */     advisor.setOrder(((Integer)this.enableCaching.getNumber("order")).intValue());
/* 48 */     return advisor;
/*    */   }
/*    */   @Bean
/*    */   @Role(2)
/*    */   public CacheOperationSource cacheOperationSource() {
/* 54 */     return new AnnotationCacheOperationSource();
/*    */   }
/*    */   @Bean
/*    */   @Role(2)
/*    */   public CacheInterceptor cacheInterceptor() {
/* 60 */     CacheInterceptor interceptor = new CacheInterceptor();
/* 61 */     interceptor.setCacheOperationSources(new CacheOperationSource[] { cacheOperationSource() });
/* 62 */     if (this.cacheManager != null) {
/* 63 */       interceptor.setCacheManager(this.cacheManager);
/*    */     }
/* 65 */     if (this.keyGenerator != null) {
/* 66 */       interceptor.setKeyGenerator(this.keyGenerator);
/*    */     }
/* 68 */     return interceptor;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.ProxyCachingConfiguration
 * JD-Core Version:    0.6.2
 */