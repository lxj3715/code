/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.springframework.cache.interceptor.CacheEvictOperation;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.cache.interceptor.CachePutOperation;
/*     */ import org.springframework.cache.interceptor.CacheableOperation;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class SpringCacheAnnotationParser
/*     */   implements CacheAnnotationParser, Serializable
/*     */ {
/*     */   public Collection<CacheOperation> parseCacheAnnotations(AnnotatedElement ae)
/*     */   {
/*  46 */     Collection ops = null;
/*     */ 
/*  48 */     Collection cacheables = getAnnotations(ae, Cacheable.class);
/*     */     Iterator localIterator;
/*  49 */     if (cacheables != null) {
/*  50 */       ops = lazyInit(ops);
/*  51 */       for (localIterator = cacheables.iterator(); localIterator.hasNext(); ) { cacheable = (Cacheable)localIterator.next();
/*  52 */         ops.add(parseCacheableAnnotation(ae, cacheable));
/*     */       }
/*     */     }
/*     */     Cacheable cacheable;
/*  55 */     Collection evicts = getAnnotations(ae, CacheEvict.class);
/*  56 */     if (evicts != null) {
/*  57 */       ops = lazyInit(ops);
/*  58 */       for (cacheable = evicts.iterator(); cacheable.hasNext(); ) { e = (CacheEvict)cacheable.next();
/*  59 */         ops.add(parseEvictAnnotation(ae, e));
/*     */       }
/*     */     }
/*     */     CacheEvict e;
/*  62 */     Collection updates = getAnnotations(ae, CachePut.class);
/*  63 */     if (updates != null) {
/*  64 */       ops = lazyInit(ops);
/*  65 */       for (e = updates.iterator(); e.hasNext(); ) { p = (CachePut)e.next();
/*  66 */         ops.add(parseUpdateAnnotation(ae, p));
/*     */       }
/*     */     }
/*     */     CachePut p;
/*  69 */     Collection caching = getAnnotations(ae, Caching.class);
/*  70 */     if (caching != null) {
/*  71 */       ops = lazyInit(ops);
/*  72 */       for (Caching c : caching) {
/*  73 */         ops.addAll(parseCachingAnnotation(ae, c));
/*     */       }
/*     */     }
/*  76 */     return ops;
/*     */   }
/*     */ 
/*     */   private <T extends Annotation> Collection<CacheOperation> lazyInit(Collection<CacheOperation> ops) {
/*  80 */     return ops != null ? ops : new ArrayList(1);
/*     */   }
/*     */ 
/*     */   CacheableOperation parseCacheableAnnotation(AnnotatedElement ae, Cacheable caching) {
/*  84 */     CacheableOperation cuo = new CacheableOperation();
/*  85 */     cuo.setCacheNames(caching.value());
/*  86 */     cuo.setCondition(caching.condition());
/*  87 */     cuo.setUnless(caching.unless());
/*  88 */     cuo.setKey(caching.key());
/*  89 */     cuo.setName(ae.toString());
/*  90 */     return cuo;
/*     */   }
/*     */ 
/*     */   CacheEvictOperation parseEvictAnnotation(AnnotatedElement ae, CacheEvict caching) {
/*  94 */     CacheEvictOperation ceo = new CacheEvictOperation();
/*  95 */     ceo.setCacheNames(caching.value());
/*  96 */     ceo.setCondition(caching.condition());
/*  97 */     ceo.setKey(caching.key());
/*  98 */     ceo.setCacheWide(caching.allEntries());
/*  99 */     ceo.setBeforeInvocation(caching.beforeInvocation());
/* 100 */     ceo.setName(ae.toString());
/* 101 */     return ceo;
/*     */   }
/*     */ 
/*     */   CacheOperation parseUpdateAnnotation(AnnotatedElement ae, CachePut caching) {
/* 105 */     CachePutOperation cuo = new CachePutOperation();
/* 106 */     cuo.setCacheNames(caching.value());
/* 107 */     cuo.setCondition(caching.condition());
/* 108 */     cuo.setUnless(caching.unless());
/* 109 */     cuo.setKey(caching.key());
/* 110 */     cuo.setName(ae.toString());
/* 111 */     return cuo;
/*     */   }
/*     */ 
/*     */   Collection<CacheOperation> parseCachingAnnotation(AnnotatedElement ae, Caching caching) {
/* 115 */     Collection ops = null;
/*     */ 
/* 117 */     Cacheable[] cacheables = caching.cacheable();
/*     */     Object localObject;
/*     */     Cacheable cacheable;
/* 118 */     if (!ObjectUtils.isEmpty(cacheables)) {
/* 119 */       ops = lazyInit(ops);
/* 120 */       Cacheable[] arrayOfCacheable1 = cacheables; int i = arrayOfCacheable1.length; for (localObject = 0; localObject < i; localObject++) { cacheable = arrayOfCacheable1[localObject];
/* 121 */         ops.add(parseCacheableAnnotation(ae, cacheable));
/*     */       }
/*     */     }
/* 124 */     CacheEvict[] evicts = caching.evict();
/*     */     CacheEvict evict;
/* 125 */     if (!ObjectUtils.isEmpty(evicts)) {
/* 126 */       ops = lazyInit(ops);
/* 127 */       CacheEvict[] arrayOfCacheEvict1 = evicts; localObject = arrayOfCacheEvict1.length; for (cacheable = 0; cacheable < localObject; cacheable++) { evict = arrayOfCacheEvict1[cacheable];
/* 128 */         ops.add(parseEvictAnnotation(ae, evict));
/*     */       }
/*     */     }
/* 131 */     CachePut[] updates = caching.put();
/* 132 */     if (!ObjectUtils.isEmpty(updates)) {
/* 133 */       ops = lazyInit(ops);
/* 134 */       localObject = updates; cacheable = localObject.length; for (evict = 0; evict < cacheable; evict++) { CachePut update = localObject[evict];
/* 135 */         ops.add(parseUpdateAnnotation(ae, update));
/*     */       }
/*     */     }
/*     */ 
/* 139 */     return ops;
/*     */   }
/*     */ 
/*     */   private <T extends Annotation> Collection<T> getAnnotations(AnnotatedElement ae, Class<T> annotationType) {
/* 143 */     Collection anns = new ArrayList(2);
/*     */ 
/* 146 */     Annotation ann = ae.getAnnotation(annotationType);
/* 147 */     if (ann != null) {
/* 148 */       anns.add(ann);
/*     */     }
/*     */ 
/* 152 */     for (Annotation metaAnn : ae.getAnnotations()) {
/* 153 */       ann = metaAnn.annotationType().getAnnotation(annotationType);
/* 154 */       if (ann != null) {
/* 155 */         anns.add(ann);
/*     */       }
/*     */     }
/*     */ 
/* 159 */     return anns.isEmpty() ? null : anns;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 164 */     return (this == other) || ((other instanceof SpringCacheAnnotationParser));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 169 */     return SpringCacheAnnotationParser.class.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.SpringCacheAnnotationParser
 * JD-Core Version:    0.6.2
 */