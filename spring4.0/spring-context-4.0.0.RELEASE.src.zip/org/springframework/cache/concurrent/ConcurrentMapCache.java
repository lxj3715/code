/*     */ package org.springframework.cache.concurrent;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.cache.support.SimpleValueWrapper;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ConcurrentMapCache
/*     */   implements Cache
/*     */ {
/*  46 */   private static final Object NULL_HOLDER = new NullHolder(null);
/*     */   private final String name;
/*     */   private final ConcurrentMap<Object, Object> store;
/*     */   private final boolean allowNullValues;
/*     */ 
/*     */   public ConcurrentMapCache(String name)
/*     */   {
/*  60 */     this(name, new ConcurrentHashMap(256), true);
/*     */   }
/*     */ 
/*     */   public ConcurrentMapCache(String name, boolean allowNullValues)
/*     */   {
/*  69 */     this(name, new ConcurrentHashMap(256), allowNullValues);
/*     */   }
/*     */ 
/*     */   public ConcurrentMapCache(String name, ConcurrentMap<Object, Object> store, boolean allowNullValues)
/*     */   {
/*  81 */     Assert.notNull(name, "Name must not be null");
/*  82 */     Assert.notNull(store, "Store must not be null");
/*  83 */     this.name = name;
/*  84 */     this.store = store;
/*  85 */     this.allowNullValues = allowNullValues;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  91 */     return this.name;
/*     */   }
/*     */ 
/*     */   public ConcurrentMap<Object, Object> getNativeCache()
/*     */   {
/*  96 */     return this.store;
/*     */   }
/*     */ 
/*     */   public boolean isAllowNullValues() {
/* 100 */     return this.allowNullValues;
/*     */   }
/*     */ 
/*     */   public Cache.ValueWrapper get(Object key)
/*     */   {
/* 105 */     Object value = this.store.get(key);
/* 106 */     return value != null ? new SimpleValueWrapper(fromStoreValue(value)) : null;
/*     */   }
/*     */ 
/*     */   public <T> T get(Object key, Class<T> type)
/*     */   {
/* 112 */     Object value = fromStoreValue(this.store.get(key));
/* 113 */     if ((type != null) && (!type.isInstance(value))) {
/* 114 */       throw new IllegalStateException("Cached value is not of required type [" + type.getName() + "]: " + value);
/*     */     }
/* 116 */     return value;
/*     */   }
/*     */ 
/*     */   public void put(Object key, Object value)
/*     */   {
/* 121 */     this.store.put(key, toStoreValue(value));
/*     */   }
/*     */ 
/*     */   public void evict(Object key)
/*     */   {
/* 126 */     this.store.remove(key);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 131 */     this.store.clear();
/*     */   }
/*     */ 
/*     */   protected Object fromStoreValue(Object storeValue)
/*     */   {
/* 142 */     if ((this.allowNullValues) && (storeValue == NULL_HOLDER)) {
/* 143 */       return null;
/*     */     }
/* 145 */     return storeValue;
/*     */   }
/*     */ 
/*     */   protected Object toStoreValue(Object userValue)
/*     */   {
/* 155 */     if ((this.allowNullValues) && (userValue == null)) {
/* 156 */       return NULL_HOLDER;
/*     */     }
/* 158 */     return userValue;
/*     */   }
/*     */ 
/*     */   private static class NullHolder
/*     */     implements Serializable
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.concurrent.ConcurrentMapCache
 * JD-Core Version:    0.6.2
 */