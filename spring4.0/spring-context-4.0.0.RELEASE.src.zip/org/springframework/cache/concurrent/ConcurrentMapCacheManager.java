/*     */ package org.springframework.cache.concurrent;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.CacheManager;
/*     */ 
/*     */ public class ConcurrentMapCacheManager
/*     */   implements CacheManager
/*     */ {
/*  46 */   private final ConcurrentMap<String, Cache> cacheMap = new ConcurrentHashMap(16);
/*     */ 
/*  48 */   private boolean dynamic = true;
/*     */ 
/*     */   public ConcurrentMapCacheManager()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ConcurrentMapCacheManager(String[] cacheNames)
/*     */   {
/*  63 */     setCacheNames(Arrays.asList(cacheNames));
/*     */   }
/*     */ 
/*     */   public void setCacheNames(Collection<String> cacheNames)
/*     */   {
/*  73 */     if (cacheNames != null) {
/*  74 */       for (String name : cacheNames) {
/*  75 */         this.cacheMap.put(name, createConcurrentMapCache(name));
/*     */       }
/*  77 */       this.dynamic = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Collection<String> getCacheNames()
/*     */   {
/*  83 */     return Collections.unmodifiableSet(this.cacheMap.keySet());
/*     */   }
/*     */ 
/*     */   public Cache getCache(String name)
/*     */   {
/*  88 */     Cache cache = (Cache)this.cacheMap.get(name);
/*  89 */     if ((cache == null) && (this.dynamic)) {
/*  90 */       synchronized (this.cacheMap) {
/*  91 */         cache = (Cache)this.cacheMap.get(name);
/*  92 */         if (cache == null) {
/*  93 */           cache = createConcurrentMapCache(name);
/*  94 */           this.cacheMap.put(name, cache);
/*     */         }
/*     */       }
/*     */     }
/*  98 */     return cache;
/*     */   }
/*     */ 
/*     */   protected Cache createConcurrentMapCache(String name)
/*     */   {
/* 107 */     return new ConcurrentMapCache(name);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.concurrent.ConcurrentMapCacheManager
 * JD-Core Version:    0.6.2
 */