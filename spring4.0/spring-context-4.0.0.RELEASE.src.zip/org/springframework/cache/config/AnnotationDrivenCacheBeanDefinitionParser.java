/*     */ package org.springframework.cache.config;
/*     */ 
/*     */ import org.springframework.aop.config.AopNamespaceUtils;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.cache.annotation.AnnotationCacheOperationSource;
/*     */ import org.springframework.cache.interceptor.BeanFactoryCacheOperationSourceAdvisor;
/*     */ import org.springframework.cache.interceptor.CacheInterceptor;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class AnnotationDrivenCacheBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  58 */     String mode = element.getAttribute("mode");
/*  59 */     if ("aspectj".equals(mode))
/*     */     {
/*  61 */       registerCacheAspect(element, parserContext);
/*     */     }
/*     */     else
/*     */     {
/*  65 */       AopAutoProxyConfigurer.configureAutoProxyCreator(element, parserContext);
/*     */     }
/*     */ 
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   private static void parseCacheManagerProperty(Element element, BeanDefinition def) {
/*  72 */     def.getPropertyValues().add("cacheManager", new RuntimeBeanReference(
/*  73 */       CacheNamespaceHandler.extractCacheManager(element)));
/*     */   }
/*     */ 
/*     */   private void registerCacheAspect(Element element, ParserContext parserContext)
/*     */   {
/*  86 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.cache.config.internalCacheAspect")) {
/*  87 */       RootBeanDefinition def = new RootBeanDefinition();
/*  88 */       def.setBeanClassName("org.springframework.cache.aspectj.AnnotationCacheAspect");
/*  89 */       def.setFactoryMethodName("aspectOf");
/*  90 */       parseCacheManagerProperty(element, def);
/*  91 */       CacheNamespaceHandler.parseKeyGenerator(element, def);
/*  92 */       parserContext.registerBeanComponent(new BeanComponentDefinition(def, "org.springframework.cache.config.internalCacheAspect"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class AopAutoProxyConfigurer
/*     */   {
/*     */     public static void configureAutoProxyCreator(Element element, ParserContext parserContext)
/*     */     {
/* 103 */       AopNamespaceUtils.registerAutoProxyCreatorIfNecessary(parserContext, element);
/*     */ 
/* 105 */       if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.cache.config.internalCacheAdvisor")) {
/* 106 */         Object eleSource = parserContext.extractSource(element);
/*     */ 
/* 109 */         RootBeanDefinition sourceDef = new RootBeanDefinition(AnnotationCacheOperationSource.class);
/* 110 */         sourceDef.setSource(eleSource);
/* 111 */         sourceDef.setRole(2);
/* 112 */         String sourceName = parserContext.getReaderContext().registerWithGeneratedName(sourceDef);
/*     */ 
/* 115 */         RootBeanDefinition interceptorDef = new RootBeanDefinition(CacheInterceptor.class);
/* 116 */         interceptorDef.setSource(eleSource);
/* 117 */         interceptorDef.setRole(2);
/* 118 */         AnnotationDrivenCacheBeanDefinitionParser.parseCacheManagerProperty(element, interceptorDef);
/* 119 */         CacheNamespaceHandler.parseKeyGenerator(element, interceptorDef);
/* 120 */         interceptorDef.getPropertyValues().add("cacheOperationSources", new RuntimeBeanReference(sourceName));
/* 121 */         String interceptorName = parserContext.getReaderContext().registerWithGeneratedName(interceptorDef);
/*     */ 
/* 124 */         RootBeanDefinition advisorDef = new RootBeanDefinition(BeanFactoryCacheOperationSourceAdvisor.class);
/* 125 */         advisorDef.setSource(eleSource);
/* 126 */         advisorDef.setRole(2);
/* 127 */         advisorDef.getPropertyValues().add("cacheOperationSource", new RuntimeBeanReference(sourceName));
/* 128 */         advisorDef.getPropertyValues().add("adviceBeanName", interceptorName);
/* 129 */         if (element.hasAttribute("order")) {
/* 130 */           advisorDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */         }
/* 132 */         parserContext.getRegistry().registerBeanDefinition("org.springframework.cache.config.internalCacheAdvisor", advisorDef);
/*     */ 
/* 134 */         CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), eleSource);
/*     */ 
/* 136 */         compositeDef.addNestedComponent(new BeanComponentDefinition(sourceDef, sourceName));
/* 137 */         compositeDef.addNestedComponent(new BeanComponentDefinition(interceptorDef, interceptorName));
/* 138 */         compositeDef.addNestedComponent(new BeanComponentDefinition(advisorDef, "org.springframework.cache.config.internalCacheAdvisor"));
/* 139 */         parserContext.registerComponent(compositeDef);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.config.AnnotationDrivenCacheBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */