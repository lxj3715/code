/*     */ package org.springframework.cache.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.parsing.ReaderContext;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.cache.annotation.AnnotationCacheOperationSource;
/*     */ import org.springframework.cache.interceptor.CacheEvictOperation;
/*     */ import org.springframework.cache.interceptor.CacheInterceptor;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.cache.interceptor.CachePutOperation;
/*     */ import org.springframework.cache.interceptor.CacheableOperation;
/*     */ import org.springframework.cache.interceptor.NameMatchCacheOperationSource;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class CacheAdviceParser extends AbstractSingleBeanDefinitionParser
/*     */ {
/*     */   private static final String CACHEABLE_ELEMENT = "cacheable";
/*     */   private static final String CACHE_EVICT_ELEMENT = "cache-evict";
/*     */   private static final String CACHE_PUT_ELEMENT = "cache-put";
/*     */   private static final String METHOD_ATTRIBUTE = "method";
/*     */   private static final String DEFS_ELEMENT = "caching";
/*     */ 
/*     */   protected Class<?> getBeanClass(Element element)
/*     */   {
/*  64 */     return CacheInterceptor.class;
/*     */   }
/*     */ 
/*     */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */   {
/*  69 */     builder.addPropertyReference("cacheManager", CacheNamespaceHandler.extractCacheManager(element));
/*  70 */     CacheNamespaceHandler.parseKeyGenerator(element, builder.getBeanDefinition());
/*     */ 
/*  72 */     List cacheDefs = DomUtils.getChildElementsByTagName(element, "caching");
/*  73 */     if (cacheDefs.size() >= 1)
/*     */     {
/*  75 */       List attributeSourceDefinitions = parseDefinitionsSources(cacheDefs, parserContext);
/*  76 */       builder.addPropertyValue("cacheOperationSources", attributeSourceDefinitions);
/*     */     }
/*     */     else {
/*  79 */       builder.addPropertyValue("cacheOperationSources", new RootBeanDefinition(AnnotationCacheOperationSource.class));
/*     */     }
/*     */   }
/*     */ 
/*     */   private List<RootBeanDefinition> parseDefinitionsSources(List<Element> definitions, ParserContext parserContext)
/*     */   {
/*  85 */     ManagedList defs = new ManagedList(definitions.size());
/*     */ 
/*  88 */     for (Element element : definitions) {
/*  89 */       defs.add(parseDefinitionSource(element, parserContext));
/*     */     }
/*     */ 
/*  92 */     return defs;
/*     */   }
/*     */ 
/*     */   private RootBeanDefinition parseDefinitionSource(Element definition, ParserContext parserContext) {
/*  96 */     Props prop = new Props(definition);
/*     */ 
/*  99 */     ManagedMap cacheOpMap = new ManagedMap();
/* 100 */     cacheOpMap.setSource(parserContext.extractSource(definition));
/*     */ 
/* 102 */     List cacheableCacheMethods = DomUtils.getChildElementsByTagName(definition, "cacheable");
/*     */ 
/* 104 */     for (Iterator localIterator = cacheableCacheMethods.iterator(); localIterator.hasNext(); ) { opElement = (Element)localIterator.next();
/* 105 */       String name = prop.merge(opElement, parserContext.getReaderContext());
/* 106 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 107 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 108 */       CacheableOperation op = (CacheableOperation)prop.merge(opElement, parserContext.getReaderContext(), new CacheableOperation());
/* 109 */       op.setUnless(getAttributeValue(opElement, "unless", ""));
/*     */ 
/* 111 */       Collection col = (Collection)cacheOpMap.get(nameHolder);
/* 112 */       if (col == null) {
/* 113 */         col = new ArrayList(2);
/* 114 */         cacheOpMap.put(nameHolder, col);
/*     */       }
/* 116 */       col.add(op);
/*     */     }
/*     */ 
/* 119 */     List evictCacheMethods = DomUtils.getChildElementsByTagName(definition, "cache-evict");
/*     */ 
/* 121 */     for (Element opElement = evictCacheMethods.iterator(); opElement.hasNext(); ) { opElement = (Element)opElement.next();
/* 122 */       String name = prop.merge(opElement, parserContext.getReaderContext());
/* 123 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 124 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 125 */       CacheEvictOperation op = (CacheEvictOperation)prop.merge(opElement, parserContext.getReaderContext(), new CacheEvictOperation());
/*     */ 
/* 127 */       String wide = opElement.getAttribute("all-entries");
/* 128 */       if (StringUtils.hasText(wide)) {
/* 129 */         op.setCacheWide(Boolean.valueOf(wide.trim()).booleanValue());
/*     */       }
/*     */ 
/* 132 */       String after = opElement.getAttribute("before-invocation");
/* 133 */       if (StringUtils.hasText(after)) {
/* 134 */         op.setBeforeInvocation(Boolean.valueOf(after.trim()).booleanValue());
/*     */       }
/*     */ 
/* 137 */       Collection col = (Collection)cacheOpMap.get(nameHolder);
/* 138 */       if (col == null) {
/* 139 */         col = new ArrayList(2);
/* 140 */         cacheOpMap.put(nameHolder, col);
/*     */       }
/* 142 */       col.add(op);
/*     */     }
/*     */     Element opElement;
/* 145 */     List putCacheMethods = DomUtils.getChildElementsByTagName(definition, "cache-put");
/*     */ 
/* 147 */     for (Element opElement : putCacheMethods) {
/* 148 */       String name = prop.merge(opElement, parserContext.getReaderContext());
/* 149 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 150 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 151 */       CachePutOperation op = (CachePutOperation)prop.merge(opElement, parserContext.getReaderContext(), new CachePutOperation());
/* 152 */       op.setUnless(getAttributeValue(opElement, "unless", ""));
/*     */ 
/* 154 */       Collection col = (Collection)cacheOpMap.get(nameHolder);
/* 155 */       if (col == null) {
/* 156 */         col = new ArrayList(2);
/* 157 */         cacheOpMap.put(nameHolder, col);
/*     */       }
/* 159 */       col.add(op);
/*     */     }
/*     */ 
/* 162 */     RootBeanDefinition attributeSourceDefinition = new RootBeanDefinition(NameMatchCacheOperationSource.class);
/* 163 */     attributeSourceDefinition.setSource(parserContext.extractSource(definition));
/* 164 */     attributeSourceDefinition.getPropertyValues().add("nameMap", cacheOpMap);
/* 165 */     return attributeSourceDefinition;
/*     */   }
/*     */ 
/*     */   private static String getAttributeValue(Element element, String attributeName, String defaultValue)
/*     */   {
/* 170 */     String attribute = element.getAttribute(attributeName);
/* 171 */     if (StringUtils.hasText(attribute)) {
/* 172 */       return attribute.trim();
/*     */     }
/* 174 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   private static class Props
/*     */   {
/*     */     private String key;
/*     */     private String condition;
/*     */     private String method;
/* 191 */     private String[] caches = null;
/*     */ 
/*     */     Props(Element root)
/*     */     {
/* 195 */       String defaultCache = root.getAttribute("cache");
/* 196 */       this.key = root.getAttribute("key");
/* 197 */       this.condition = root.getAttribute("condition");
/* 198 */       this.method = root.getAttribute("method");
/*     */ 
/* 200 */       if (StringUtils.hasText(defaultCache))
/* 201 */         this.caches = StringUtils.commaDelimitedListToStringArray(defaultCache.trim());
/*     */     }
/*     */ 
/*     */     <T extends CacheOperation> T merge(Element element, ReaderContext readerCtx, T op)
/*     */     {
/* 207 */       String cache = element.getAttribute("cache");
/*     */ 
/* 210 */       String[] localCaches = this.caches;
/* 211 */       if (StringUtils.hasText(cache)) {
/* 212 */         localCaches = StringUtils.commaDelimitedListToStringArray(cache.trim());
/*     */       }
/* 214 */       else if (this.caches == null) {
/* 215 */         readerCtx.error("No cache specified specified for " + element.getNodeName(), element);
/*     */       }
/*     */ 
/* 218 */       op.setCacheNames(localCaches);
/*     */ 
/* 220 */       op.setKey(CacheAdviceParser.getAttributeValue(element, "key", this.key));
/* 221 */       op.setCondition(CacheAdviceParser.getAttributeValue(element, "condition", this.condition));
/*     */ 
/* 223 */       return op;
/*     */     }
/*     */ 
/*     */     String merge(Element element, ReaderContext readerCtx) {
/* 227 */       String m = element.getAttribute("method");
/*     */ 
/* 229 */       if (StringUtils.hasText(m)) {
/* 230 */         return m.trim();
/*     */       }
/* 232 */       if (StringUtils.hasText(this.method)) {
/* 233 */         return this.method;
/*     */       }
/* 235 */       readerCtx.error("No method specified for " + element.getNodeName(), element);
/* 236 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.config.CacheAdviceParser
 * JD-Core Version:    0.6.2
 */