/*    */ package org.springframework.cache.config;
/*    */ 
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class CacheNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   static final String CACHE_MANAGER_ATTRIBUTE = "cache-manager";
/*    */   static final String DEFAULT_CACHE_MANAGER_BEAN_NAME = "cacheManager";
/*    */ 
/*    */   static String extractCacheManager(Element element)
/*    */   {
/* 43 */     return element.hasAttribute("cache-manager") ? element
/* 43 */       .getAttribute("cache-manager") : 
/* 43 */       "cacheManager";
/*    */   }
/*    */ 
/*    */   static BeanDefinition parseKeyGenerator(Element element, BeanDefinition def)
/*    */   {
/* 48 */     String name = element.getAttribute("key-generator");
/* 49 */     if (StringUtils.hasText(name)) {
/* 50 */       def.getPropertyValues().add("keyGenerator", new RuntimeBeanReference(name.trim()));
/*    */     }
/* 52 */     return def;
/*    */   }
/*    */ 
/*    */   public void init()
/*    */   {
/* 57 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenCacheBeanDefinitionParser());
/* 58 */     registerBeanDefinitionParser("advice", new CacheAdviceParser());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.config.CacheNamespaceHandler
 * JD-Core Version:    0.6.2
 */