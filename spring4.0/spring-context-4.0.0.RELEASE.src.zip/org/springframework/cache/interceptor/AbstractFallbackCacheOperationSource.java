/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class AbstractFallbackCacheOperationSource
/*     */   implements CacheOperationSource
/*     */ {
/*  61 */   private static final Collection<CacheOperation> NULL_CACHING_ATTRIBUTE = Collections.emptyList();
/*     */   protected final Log logger;
/*     */   final Map<Object, Collection<CacheOperation>> attributeCache;
/*     */ 
/*     */   public AbstractFallbackCacheOperationSource()
/*     */   {
/*  68 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  75 */     this.attributeCache = new ConcurrentHashMap(1024);
/*     */   }
/*     */ 
/*     */   public Collection<CacheOperation> getCacheOperations(Method method, Class<?> targetClass)
/*     */   {
/*  90 */     Object cacheKey = getCacheKey(method, targetClass);
/*  91 */     Collection cached = (Collection)this.attributeCache.get(cacheKey);
/*  92 */     if (cached != null) {
/*  93 */       if (cached == NULL_CACHING_ATTRIBUTE) {
/*  94 */         return null;
/*     */       }
/*     */ 
/*  98 */       return cached;
/*     */     }
/*     */ 
/* 102 */     Collection cacheOps = computeCacheOperations(method, targetClass);
/*     */ 
/* 104 */     if (cacheOps == null) {
/* 105 */       this.attributeCache.put(cacheKey, NULL_CACHING_ATTRIBUTE);
/*     */     }
/*     */     else {
/* 108 */       if (this.logger.isDebugEnabled()) {
/* 109 */         this.logger.debug("Adding cacheable method '" + method.getName() + "' with attribute: " + cacheOps);
/*     */       }
/* 111 */       this.attributeCache.put(cacheKey, cacheOps);
/*     */     }
/* 113 */     return cacheOps;
/*     */   }
/*     */ 
/*     */   protected Object getCacheKey(Method method, Class<?> targetClass)
/*     */   {
/* 126 */     return new DefaultCacheKey(method, targetClass);
/*     */   }
/*     */ 
/*     */   private Collection<CacheOperation> computeCacheOperations(Method method, Class<?> targetClass)
/*     */   {
/* 131 */     if ((allowPublicMethodsOnly()) && (!Modifier.isPublic(method.getModifiers()))) {
/* 132 */       return null;
/*     */     }
/*     */ 
/* 137 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/*     */ 
/* 139 */     specificMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/*     */ 
/* 142 */     Collection opDef = findCacheOperations(specificMethod);
/* 143 */     if (opDef != null) {
/* 144 */       return opDef;
/*     */     }
/*     */ 
/* 148 */     opDef = findCacheOperations(specificMethod.getDeclaringClass());
/* 149 */     if (opDef != null) {
/* 150 */       return opDef;
/*     */     }
/*     */ 
/* 153 */     if (specificMethod != method)
/*     */     {
/* 155 */       opDef = findCacheOperations(method);
/* 156 */       if (opDef != null) {
/* 157 */         return opDef;
/*     */       }
/*     */ 
/* 160 */       return findCacheOperations(method.getDeclaringClass());
/*     */     }
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   protected abstract Collection<CacheOperation> findCacheOperations(Method paramMethod);
/*     */ 
/*     */   protected abstract Collection<CacheOperation> findCacheOperations(Class<?> paramClass);
/*     */ 
/*     */   protected boolean allowPublicMethodsOnly()
/*     */   {
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */   private static class DefaultCacheKey
/*     */   {
/*     */     private final Method method;
/*     */     private final Class<?> targetClass;
/*     */ 
/*     */     public DefaultCacheKey(Method method, Class<?> targetClass)
/*     */     {
/* 203 */       this.method = method;
/* 204 */       this.targetClass = targetClass;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 209 */       if (this == other) {
/* 210 */         return true;
/*     */       }
/* 212 */       if (!(other instanceof DefaultCacheKey)) {
/* 213 */         return false;
/*     */       }
/* 215 */       DefaultCacheKey otherKey = (DefaultCacheKey)other;
/* 216 */       return (this.method.equals(otherKey.method)) && (ObjectUtils.nullSafeEquals(this.targetClass, otherKey.targetClass));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 222 */       return this.method.hashCode() * 29 + (this.targetClass != null ? this.targetClass.hashCode() : 0);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.AbstractFallbackCacheOperationSource
 * JD-Core Version:    0.6.2
 */