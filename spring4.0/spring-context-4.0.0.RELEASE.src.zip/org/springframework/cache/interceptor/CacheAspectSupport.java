/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.AopProxyUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.cache.support.SimpleValueWrapper;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class CacheAspectSupport
/*     */   implements InitializingBean
/*     */ {
/*     */   protected final Log logger;
/*     */   private final ExpressionEvaluator evaluator;
/*     */   private CacheManager cacheManager;
/*     */   private CacheOperationSource cacheOperationSource;
/*     */   private KeyGenerator keyGenerator;
/*     */   private boolean initialized;
/*     */ 
/*     */   public CacheAspectSupport()
/*     */   {
/*  69 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  71 */     this.evaluator = new ExpressionEvaluator();
/*     */ 
/*  77 */     this.keyGenerator = new SimpleKeyGenerator();
/*     */ 
/*  79 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */   public void setCacheManager(CacheManager cacheManager)
/*     */   {
/*  86 */     this.cacheManager = cacheManager;
/*     */   }
/*     */ 
/*     */   public CacheManager getCacheManager()
/*     */   {
/*  93 */     return this.cacheManager;
/*     */   }
/*     */ 
/*     */   public void setCacheOperationSources(CacheOperationSource[] cacheOperationSources)
/*     */   {
/* 103 */     Assert.notEmpty(cacheOperationSources);
/* 104 */     this.cacheOperationSource = (cacheOperationSources.length > 1 ? new CompositeCacheOperationSource(cacheOperationSources) : cacheOperationSources[0]);
/*     */   }
/*     */ 
/*     */   public CacheOperationSource getCacheOperationSource()
/*     */   {
/* 112 */     return this.cacheOperationSource;
/*     */   }
/*     */ 
/*     */   public void setKeyGenerator(KeyGenerator keyGenerator)
/*     */   {
/* 120 */     this.keyGenerator = keyGenerator;
/*     */   }
/*     */ 
/*     */   public KeyGenerator getKeyGenerator()
/*     */   {
/* 127 */     return this.keyGenerator;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/* 131 */     Assert.state(this.cacheManager != null, "'cacheManager' is required");
/* 132 */     Assert.state(this.cacheOperationSource != null, "The 'cacheOperationSources' property is required: If there are no cacheable methods, then don't use a cache aspect.");
/*     */ 
/* 134 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */   protected String methodIdentification(Method method, Class<?> targetClass)
/*     */   {
/* 148 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/* 149 */     return ClassUtils.getQualifiedMethodName(specificMethod);
/*     */   }
/*     */ 
/*     */   protected Collection<? extends Cache> getCaches(CacheOperation operation) {
/* 153 */     Set cacheNames = operation.getCacheNames();
/* 154 */     Collection caches = new ArrayList(cacheNames.size());
/* 155 */     for (String cacheName : cacheNames) {
/* 156 */       Cache cache = this.cacheManager.getCache(cacheName);
/* 157 */       Assert.notNull(cache, new StringBuilder().append("Cannot find cache named '").append(cacheName).append("' for ").append(operation).toString());
/* 158 */       caches.add(cache);
/*     */     }
/* 160 */     return caches;
/*     */   }
/*     */ 
/*     */   protected CacheOperationContext getOperationContext(CacheOperation operation, Method method, Object[] args, Object target, Class<?> targetClass)
/*     */   {
/* 166 */     return new CacheOperationContext(operation, method, args, target, targetClass);
/*     */   }
/*     */ 
/*     */   protected Object execute(Invoker invoker, Object target, Method method, Object[] args)
/*     */   {
/* 172 */     if (this.initialized) {
/* 173 */       Class targetClass = getTargetClass(target);
/* 174 */       Collection operations = getCacheOperationSource().getCacheOperations(method, targetClass);
/* 175 */       if (!CollectionUtils.isEmpty(operations)) {
/* 176 */         return execute(invoker, new CacheOperationContexts(operations, method, args, target, targetClass));
/*     */       }
/*     */     }
/*     */ 
/* 180 */     return invoker.invoke();
/*     */   }
/*     */ 
/*     */   private Class<?> getTargetClass(Object target) {
/* 184 */     Class targetClass = AopProxyUtils.ultimateTargetClass(target);
/* 185 */     if ((targetClass == null) && (target != null)) {
/* 186 */       targetClass = target.getClass();
/*     */     }
/* 188 */     return targetClass;
/*     */   }
/*     */ 
/*     */   private Object execute(Invoker invoker, CacheOperationContexts contexts)
/*     */   {
/* 193 */     processCacheEvicts(contexts.get(CacheEvictOperation.class), true, ExpressionEvaluator.NO_RESULT);
/*     */ 
/* 196 */     List cachePutRequests = new ArrayList();
/* 197 */     collectPutRequests(contexts.get(CacheableOperation.class), ExpressionEvaluator.NO_RESULT, cachePutRequests, true);
/*     */ 
/* 199 */     Cache.ValueWrapper result = null;
/*     */ 
/* 202 */     if ((cachePutRequests.isEmpty()) && (contexts.get(CachePutOperation.class).isEmpty())) {
/* 203 */       result = findCachedResult(contexts.get(CacheableOperation.class));
/*     */     }
/*     */ 
/* 207 */     if (result == null) {
/* 208 */       result = new SimpleValueWrapper(invoker.invoke());
/*     */     }
/*     */ 
/* 212 */     collectPutRequests(contexts.get(CachePutOperation.class), result.get(), cachePutRequests, false);
/*     */ 
/* 215 */     for (CachePutRequest cachePutRequest : cachePutRequests) {
/* 216 */       cachePutRequest.apply(result.get());
/*     */     }
/*     */ 
/* 220 */     processCacheEvicts(contexts.get(CacheEvictOperation.class), false, result.get());
/*     */ 
/* 222 */     return result.get();
/*     */   }
/*     */ 
/*     */   private void processCacheEvicts(Collection<CacheOperationContext> contexts, boolean beforeInvocation, Object result) {
/* 226 */     for (CacheOperationContext context : contexts) {
/* 227 */       CacheEvictOperation operation = (CacheEvictOperation)context.operation;
/* 228 */       if ((beforeInvocation == operation.isBeforeInvocation()) && (isConditionPassing(context, result)))
/* 229 */         performCacheEvict(context, operation, result);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void performCacheEvict(CacheOperationContext context, CacheEvictOperation operation, Object result)
/*     */   {
/* 235 */     Object key = null;
/* 236 */     for (Cache cache : context.getCaches())
/* 237 */       if (operation.isCacheWide()) {
/* 238 */         logInvalidating(context, operation, null);
/* 239 */         cache.clear();
/*     */       }
/*     */       else {
/* 242 */         if (key == null) {
/* 243 */           key = context.generateKey(result);
/*     */         }
/* 245 */         logInvalidating(context, operation, key);
/* 246 */         cache.evict(key);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void logInvalidating(CacheOperationContext context, CacheEvictOperation operation, Object key)
/*     */   {
/* 252 */     if (this.logger.isTraceEnabled())
/* 253 */       this.logger.trace(new StringBuilder().append("Invalidating ").append(key == null ? "entire cache" : new StringBuilder().append("cache key ").append(key).toString()).append(" for operation ").append(operation).append(" on method ")
/* 254 */         .append(context.method)
/* 254 */         .toString());
/*     */   }
/*     */ 
/*     */   private void collectPutRequests(Collection<CacheOperationContext> contexts, Object result, Collection<CachePutRequest> putRequests, boolean whenNotInCache)
/*     */   {
/* 261 */     for (CacheOperationContext context : contexts)
/* 262 */       if (isConditionPassing(context, result)) {
/* 263 */         Object key = generateKey(context, result);
/* 264 */         if ((!whenNotInCache) || (findInAnyCaches(contexts, key) == null))
/* 265 */           putRequests.add(new CachePutRequest(context, key));
/*     */       }
/*     */   }
/*     */ 
/*     */   private Cache.ValueWrapper findCachedResult(Collection<CacheOperationContext> contexts)
/*     */   {
/* 272 */     Cache.ValueWrapper result = null;
/* 273 */     for (CacheOperationContext context : contexts) {
/* 274 */       if ((isConditionPassing(context, ExpressionEvaluator.NO_RESULT)) && 
/* 275 */         (result == null)) {
/* 276 */         result = findInCaches(context, generateKey(context, ExpressionEvaluator.NO_RESULT));
/*     */       }
/*     */     }
/*     */ 
/* 280 */     return result;
/*     */   }
/*     */ 
/*     */   private Cache.ValueWrapper findInAnyCaches(Collection<CacheOperationContext> contexts, Object key) {
/* 284 */     for (CacheOperationContext context : contexts) {
/* 285 */       Cache.ValueWrapper wrapper = findInCaches(context, key);
/* 286 */       if (wrapper != null) {
/* 287 */         return wrapper;
/*     */       }
/*     */     }
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */   private Cache.ValueWrapper findInCaches(CacheOperationContext context, Object key) {
/* 294 */     for (Cache cache : context.getCaches()) {
/* 295 */       Cache.ValueWrapper wrapper = cache.get(key);
/* 296 */       if (wrapper != null) {
/* 297 */         return wrapper;
/*     */       }
/*     */     }
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */   private boolean isConditionPassing(CacheOperationContext context, Object result) {
/* 304 */     boolean passing = context.isConditionPassing(result);
/* 305 */     if ((!passing) && (this.logger.isTraceEnabled())) {
/* 306 */       this.logger.trace(new StringBuilder().append("Cache condition failed on method ").append(context.method).append(" for operation ").append(context.operation).toString());
/*     */     }
/* 308 */     return passing;
/*     */   }
/*     */ 
/*     */   private Object generateKey(CacheOperationContext context, Object result) {
/* 312 */     Object key = context.generateKey(result);
/* 313 */     Assert.notNull(key, new StringBuilder().append("Null key returned for cache operation (maybe you are using named params on classes without debug info?) ")
/* 314 */       .append(context.operation)
/* 314 */       .toString());
/* 315 */     if (this.logger.isTraceEnabled()) {
/* 316 */       this.logger.trace(new StringBuilder().append("Computed cache key ").append(key).append(" for operation ").append(context.operation).toString());
/*     */     }
/* 318 */     return key;
/*     */   }
/*     */ 
/*     */   private static class CachePutRequest
/*     */   {
/*     */     private final CacheAspectSupport.CacheOperationContext context;
/*     */     private final Object key;
/*     */ 
/*     */     public CachePutRequest(CacheAspectSupport.CacheOperationContext context, Object key)
/*     */     {
/* 435 */       this.context = context;
/* 436 */       this.key = key;
/*     */     }
/*     */ 
/*     */     public void apply(Object result) {
/* 440 */       if (this.context.canPutToCache(result))
/* 441 */         for (Cache cache : this.context.getCaches())
/* 442 */           cache.put(this.key, result);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class CacheOperationContext
/*     */   {
/*     */     private final CacheOperation operation;
/*     */     private final Method method;
/*     */     private final Object[] args;
/*     */     private final Object target;
/*     */     private final Class<?> targetClass;
/*     */     private final Collection<? extends Cache> caches;
/*     */ 
/*     */     public CacheOperationContext(Method operation, Object[] method, Object args, Class<?> target)
/*     */     {
/* 364 */       this.operation = operation;
/* 365 */       this.method = method;
/* 366 */       this.args = extractArgs(method, args);
/* 367 */       this.target = target;
/* 368 */       this.targetClass = targetClass;
/* 369 */       this.caches = CacheAspectSupport.this.getCaches(operation);
/*     */     }
/*     */ 
/*     */     private Object[] extractArgs(Method method, Object[] args) {
/* 373 */       if (!method.isVarArgs()) {
/* 374 */         return args;
/*     */       }
/* 376 */       Object[] varArgs = (Object[])args[(args.length - 1)];
/* 377 */       Object[] combinedArgs = new Object[args.length - 1 + varArgs.length];
/* 378 */       System.arraycopy(args, 0, combinedArgs, 0, args.length - 1);
/* 379 */       System.arraycopy(varArgs, 0, combinedArgs, args.length - 1, varArgs.length);
/* 380 */       return combinedArgs;
/*     */     }
/*     */ 
/*     */     protected boolean isConditionPassing(Object result) {
/* 384 */       if (StringUtils.hasText(this.operation.getCondition())) {
/* 385 */         EvaluationContext evaluationContext = createEvaluationContext(result);
/* 386 */         return CacheAspectSupport.this.evaluator.condition(this.operation.getCondition(), this.method, evaluationContext);
/*     */       }
/* 388 */       return true;
/*     */     }
/*     */ 
/*     */     protected boolean canPutToCache(Object value) {
/* 392 */       String unless = "";
/* 393 */       if ((this.operation instanceof CacheableOperation)) {
/* 394 */         unless = ((CacheableOperation)this.operation).getUnless();
/*     */       }
/* 396 */       else if ((this.operation instanceof CachePutOperation)) {
/* 397 */         unless = ((CachePutOperation)this.operation).getUnless();
/*     */       }
/* 399 */       if (StringUtils.hasText(unless)) {
/* 400 */         EvaluationContext evaluationContext = createEvaluationContext(value);
/* 401 */         return !CacheAspectSupport.this.evaluator.unless(unless, this.method, evaluationContext);
/*     */       }
/* 403 */       return true;
/*     */     }
/*     */ 
/*     */     protected Object generateKey(Object result)
/*     */     {
/* 411 */       if (StringUtils.hasText(this.operation.getKey())) {
/* 412 */         EvaluationContext evaluationContext = createEvaluationContext(result);
/* 413 */         return CacheAspectSupport.this.evaluator.key(this.operation.getKey(), this.method, evaluationContext);
/*     */       }
/* 415 */       return CacheAspectSupport.this.keyGenerator.generate(this.target, this.method, this.args);
/*     */     }
/*     */ 
/*     */     private EvaluationContext createEvaluationContext(Object result) {
/* 419 */       return CacheAspectSupport.this.evaluator.createEvaluationContext(this.caches, this.method, this.args, this.target, this.targetClass, result);
/*     */     }
/*     */ 
/*     */     protected Collection<? extends Cache> getCaches() {
/* 423 */       return this.caches;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class CacheOperationContexts
/*     */   {
/* 330 */     private final MultiValueMap<Class<? extends CacheOperation>, CacheAspectSupport.CacheOperationContext> contexts = new LinkedMultiValueMap();
/*     */ 
/*     */     public CacheOperationContexts(Method operations, Object[] method, Object args, Class<?> target)
/*     */     {
/* 336 */       for (CacheOperation operation : operations)
/* 337 */         this.contexts.add(operation.getClass(), new CacheAspectSupport.CacheOperationContext(CacheAspectSupport.this, operation, method, args, target, targetClass));
/*     */     }
/*     */ 
/*     */     public Collection<CacheAspectSupport.CacheOperationContext> get(Class<? extends CacheOperation> operationClass)
/*     */     {
/* 342 */       Collection result = (Collection)this.contexts.get(operationClass);
/* 343 */       return result != null ? result : Collections.emptyList();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface Invoker
/*     */   {
/*     */     public abstract Object invoke();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheAspectSupport
 * JD-Core Version:    0.6.2
 */