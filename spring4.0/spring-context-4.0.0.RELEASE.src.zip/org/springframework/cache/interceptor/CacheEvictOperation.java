/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ public class CacheEvictOperation extends CacheOperation
/*    */ {
/* 27 */   private boolean cacheWide = false;
/*    */ 
/* 29 */   private boolean beforeInvocation = false;
/*    */ 
/*    */   public void setCacheWide(boolean cacheWide)
/*    */   {
/* 33 */     this.cacheWide = cacheWide;
/*    */   }
/*    */ 
/*    */   public boolean isCacheWide() {
/* 37 */     return this.cacheWide;
/*    */   }
/*    */ 
/*    */   public void setBeforeInvocation(boolean beforeInvocation) {
/* 41 */     this.beforeInvocation = beforeInvocation;
/*    */   }
/*    */ 
/*    */   public boolean isBeforeInvocation() {
/* 45 */     return this.beforeInvocation;
/*    */   }
/*    */ 
/*    */   protected StringBuilder getOperationDescription()
/*    */   {
/* 50 */     StringBuilder sb = super.getOperationDescription();
/* 51 */     sb.append(",");
/* 52 */     sb.append(this.cacheWide);
/* 53 */     sb.append(",");
/* 54 */     sb.append(this.beforeInvocation);
/* 55 */     return sb;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheEvictOperation
 * JD-Core Version:    0.6.2
 */