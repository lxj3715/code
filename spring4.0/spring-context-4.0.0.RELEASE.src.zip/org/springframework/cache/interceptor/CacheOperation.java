/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class CacheOperation
/*     */ {
/*  32 */   private Set<String> cacheNames = Collections.emptySet();
/*     */ 
/*  34 */   private String condition = "";
/*     */ 
/*  36 */   private String key = "";
/*     */ 
/*  38 */   private String name = "";
/*     */ 
/*     */   public Set<String> getCacheNames()
/*     */   {
/*  42 */     return this.cacheNames;
/*     */   }
/*     */ 
/*     */   public String getCondition() {
/*  46 */     return this.condition;
/*     */   }
/*     */ 
/*     */   public String getKey() {
/*  50 */     return this.key;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  54 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setCacheName(String cacheName) {
/*  58 */     Assert.hasText(cacheName);
/*  59 */     this.cacheNames = Collections.singleton(cacheName);
/*     */   }
/*     */ 
/*     */   public void setCacheNames(String[] cacheNames) {
/*  63 */     Assert.notEmpty(cacheNames);
/*  64 */     this.cacheNames = new LinkedHashSet(cacheNames.length);
/*  65 */     for (String string : cacheNames)
/*  66 */       this.cacheNames.add(string);
/*     */   }
/*     */ 
/*     */   public void setCondition(String condition)
/*     */   {
/*  71 */     Assert.notNull(condition);
/*  72 */     this.condition = condition;
/*     */   }
/*     */ 
/*     */   public void setKey(String key) {
/*  76 */     Assert.notNull(key);
/*  77 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  81 */     Assert.hasText(name);
/*  82 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  91 */     return ((other instanceof CacheOperation)) && (toString().equals(other.toString()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 100 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 111 */     return getOperationDescription().toString();
/*     */   }
/*     */ 
/*     */   protected StringBuilder getOperationDescription()
/*     */   {
/* 119 */     StringBuilder result = new StringBuilder();
/* 120 */     result.append(getClass().getSimpleName());
/* 121 */     result.append("[");
/* 122 */     result.append(this.name);
/* 123 */     result.append("] caches=");
/* 124 */     result.append(this.cacheNames);
/* 125 */     result.append(" | key='");
/* 126 */     result.append(this.key);
/* 127 */     result.append("' | condition='");
/* 128 */     result.append(this.condition);
/* 129 */     result.append("'");
/* 130 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheOperation
 * JD-Core Version:    0.6.2
 */