package org.springframework.cache.interceptor;

import java.lang.reflect.Method;
import java.util.Collection;

public abstract interface CacheOperationSource
{
  public abstract Collection<CacheOperation> getCacheOperations(Method paramMethod, Class<?> paramClass);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheOperationSource
 * JD-Core Version:    0.6.2
 */