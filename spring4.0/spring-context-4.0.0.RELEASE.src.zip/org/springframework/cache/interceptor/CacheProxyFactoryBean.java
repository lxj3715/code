/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.framework.AbstractSingletonProxyFactoryBean;
/*    */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*    */ 
/*    */ public class CacheProxyFactoryBean extends AbstractSingletonProxyFactoryBean
/*    */ {
/* 44 */   private final CacheInterceptor cachingInterceptor = new CacheInterceptor();
/*    */   private Pointcut pointcut;
/*    */ 
/*    */   public void setPointcut(Pointcut pointcut)
/*    */   {
/* 57 */     this.pointcut = pointcut;
/*    */   }
/*    */ 
/*    */   protected Object createMainInterceptor()
/*    */   {
/* 62 */     this.cachingInterceptor.afterPropertiesSet();
/* 63 */     if (this.pointcut == null)
/*    */     {
/* 65 */       throw new UnsupportedOperationException();
/*    */     }
/* 67 */     return new DefaultPointcutAdvisor(this.pointcut, this.cachingInterceptor);
/*    */   }
/*    */ 
/*    */   public void setCacheOperationSources(CacheOperationSource[] cacheOperationSources)
/*    */   {
/* 74 */     this.cachingInterceptor.setCacheOperationSources(cacheOperationSources);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheProxyFactoryBean
 * JD-Core Version:    0.6.2
 */