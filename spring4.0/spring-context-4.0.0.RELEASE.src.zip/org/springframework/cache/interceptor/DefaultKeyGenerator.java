/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ @Deprecated
/*    */ public class DefaultKeyGenerator
/*    */   implements KeyGenerator
/*    */ {
/*    */   public static final int NO_PARAM_KEY = 0;
/*    */   public static final int NULL_PARAM_KEY = 53;
/*    */ 
/*    */   public Object generate(Object target, Method method, Object[] params)
/*    */   {
/* 50 */     if (params.length == 1) {
/* 51 */       return params[0] == null ? Integer.valueOf(53) : params[0];
/*    */     }
/* 53 */     if (params.length == 0) {
/* 54 */       return Integer.valueOf(0);
/*    */     }
/* 56 */     int hashCode = 17;
/* 57 */     for (Object object : params) {
/* 58 */       hashCode = 31 * hashCode + (object == null ? 53 : object.hashCode());
/*    */     }
/* 60 */     return Integer.valueOf(hashCode);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.DefaultKeyGenerator
 * JD-Core Version:    0.6.2
 */