/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ 
/*     */ class ExpressionEvaluator
/*     */ {
/*  44 */   public static final Object NO_RESULT = new Object();
/*     */ 
/*  47 */   private final SpelExpressionParser parser = new SpelExpressionParser();
/*     */ 
/*  50 */   private final ParameterNameDiscoverer paramNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */ 
/*  52 */   private final Map<String, Expression> keyCache = new ConcurrentHashMap(64);
/*     */ 
/*  54 */   private final Map<String, Expression> conditionCache = new ConcurrentHashMap(64);
/*     */ 
/*  56 */   private final Map<String, Expression> unlessCache = new ConcurrentHashMap(64);
/*     */ 
/*  58 */   private final Map<String, Method> targetMethodCache = new ConcurrentHashMap(64);
/*     */ 
/*     */   public EvaluationContext createEvaluationContext(Collection<? extends Cache> caches, Method method, Object[] args, Object target, Class<?> targetClass)
/*     */   {
/*  67 */     return createEvaluationContext(caches, method, args, target, targetClass, NO_RESULT);
/*     */   }
/*     */ 
/*     */   public EvaluationContext createEvaluationContext(Collection<? extends Cache> caches, Method method, Object[] args, Object target, Class<?> targetClass, Object result)
/*     */   {
/*  86 */     CacheExpressionRootObject rootObject = new CacheExpressionRootObject(caches, method, args, target, targetClass);
/*     */ 
/*  88 */     LazyParamAwareEvaluationContext evaluationContext = new LazyParamAwareEvaluationContext(rootObject, this.paramNameDiscoverer, method, args, targetClass, this.targetMethodCache);
/*     */ 
/*  90 */     if (result != NO_RESULT) {
/*  91 */       evaluationContext.setVariable("result", result);
/*     */     }
/*  93 */     return evaluationContext;
/*     */   }
/*     */ 
/*     */   public Object key(String keyExpression, Method method, EvaluationContext evalContext) {
/*  97 */     return getExpression(this.keyCache, keyExpression, method).getValue(evalContext);
/*     */   }
/*     */ 
/*     */   public boolean condition(String conditionExpression, Method method, EvaluationContext evalContext) {
/* 101 */     return ((Boolean)getExpression(this.conditionCache, conditionExpression, method).getValue(evalContext, Boolean.TYPE)).booleanValue();
/*     */   }
/*     */ 
/*     */   public boolean unless(String unlessExpression, Method method, EvaluationContext evalContext)
/*     */   {
/* 106 */     return ((Boolean)getExpression(this.unlessCache, unlessExpression, method).getValue(evalContext, Boolean.TYPE)).booleanValue();
/*     */   }
/*     */ 
/*     */   private Expression getExpression(Map<String, Expression> cache, String expression, Method method)
/*     */   {
/* 111 */     String key = toString(method, expression);
/* 112 */     Expression rtn = (Expression)cache.get(key);
/* 113 */     if (rtn == null) {
/* 114 */       rtn = this.parser.parseExpression(expression);
/* 115 */       cache.put(key, rtn);
/*     */     }
/* 117 */     return rtn;
/*     */   }
/*     */ 
/*     */   private String toString(Method method, String expression) {
/* 121 */     StringBuilder sb = new StringBuilder();
/* 122 */     sb.append(method.getDeclaringClass().getName());
/* 123 */     sb.append("#");
/* 124 */     sb.append(method.toString());
/* 125 */     sb.append("#");
/* 126 */     sb.append(expression);
/* 127 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.ExpressionEvaluator
 * JD-Core Version:    0.6.2
 */