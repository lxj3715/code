package org.springframework.cache.interceptor;

import java.lang.reflect.Method;

public abstract interface KeyGenerator
{
  public abstract Object generate(Object paramObject, Method paramMethod, Object[] paramArrayOfObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.KeyGenerator
 * JD-Core Version:    0.6.2
 */