/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ public class NameMatchCacheOperationSource
/*     */   implements CacheOperationSource, Serializable
/*     */ {
/*  43 */   protected static final Log logger = LogFactory.getLog(NameMatchCacheOperationSource.class);
/*     */ 
/*  47 */   private Map<String, Collection<CacheOperation>> nameMap = new LinkedHashMap();
/*     */ 
/*     */   public void setNameMap(Map<String, Collection<CacheOperation>> nameMap)
/*     */   {
/*  57 */     for (Map.Entry entry : nameMap.entrySet())
/*  58 */       addCacheMethod((String)entry.getKey(), (Collection)entry.getValue());
/*     */   }
/*     */ 
/*     */   public void addCacheMethod(String methodName, Collection<CacheOperation> ops)
/*     */   {
/*  70 */     if (logger.isDebugEnabled()) {
/*  71 */       logger.debug("Adding method [" + methodName + "] with cache operations [" + ops + "]");
/*     */     }
/*  73 */     this.nameMap.put(methodName, ops);
/*     */   }
/*     */ 
/*     */   public Collection<CacheOperation> getCacheOperations(Method method, Class<?> targetClass)
/*     */   {
/*  79 */     String methodName = method.getName();
/*  80 */     Collection ops = (Collection)this.nameMap.get(methodName);
/*     */     String bestNameMatch;
/*  82 */     if (ops == null)
/*     */     {
/*  84 */       bestNameMatch = null;
/*  85 */       for (String mappedName : this.nameMap.keySet()) {
/*  86 */         if ((isMatch(methodName, mappedName)) && ((bestNameMatch == null) || 
/*  87 */           (bestNameMatch
/*  87 */           .length() <= mappedName.length()))) {
/*  88 */           ops = (Collection)this.nameMap.get(mappedName);
/*  89 */           bestNameMatch = mappedName;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  94 */     return ops;
/*     */   }
/*     */ 
/*     */   protected boolean isMatch(String methodName, String mappedName)
/*     */   {
/* 107 */     return PatternMatchUtils.simpleMatch(mappedName, methodName);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 112 */     if (this == other) {
/* 113 */       return true;
/*     */     }
/* 115 */     if (!(other instanceof NameMatchCacheOperationSource)) {
/* 116 */       return false;
/*     */     }
/* 118 */     NameMatchCacheOperationSource otherTas = (NameMatchCacheOperationSource)other;
/* 119 */     return ObjectUtils.nullSafeEquals(this.nameMap, otherTas.nameMap);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 124 */     return NameMatchCacheOperationSource.class.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 129 */     return getClass().getName() + ": " + this.nameMap;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.NameMatchCacheOperationSource
 * JD-Core Version:    0.6.2
 */