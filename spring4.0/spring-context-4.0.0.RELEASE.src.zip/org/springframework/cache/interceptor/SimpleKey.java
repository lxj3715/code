/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public final class SimpleKey
/*    */   implements Serializable
/*    */ {
/* 35 */   public static final SimpleKey EMPTY = new SimpleKey(new Object[0]);
/*    */   private final Object[] params;
/*    */ 
/*    */   public SimpleKey(Object[] elements)
/*    */   {
/* 45 */     Assert.notNull(elements, "Elements must not be null");
/* 46 */     this.params = new Object[elements.length];
/* 47 */     System.arraycopy(elements, 0, this.params, 0, elements.length);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 53 */     return (this == obj) || (((obj instanceof SimpleKey)) && (Arrays.equals(this.params, ((SimpleKey)obj).params)));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 58 */     return Arrays.hashCode(this.params);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 63 */     return "SimpleKey [" + StringUtils.arrayToCommaDelimitedString(this.params) + "]";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.SimpleKey
 * JD-Core Version:    0.6.2
 */