/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class SimpleKeyGenerator
/*    */   implements KeyGenerator
/*    */ {
/*    */   public Object generate(Object target, Method method, Object[] params)
/*    */   {
/* 41 */     if (params.length == 0) {
/* 42 */       return SimpleKey.EMPTY;
/*    */     }
/* 44 */     if ((params.length == 1) && (params[0] != null)) {
/* 45 */       return params[0];
/*    */     }
/* 47 */     return new SimpleKey(params);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.SimpleKeyGenerator
 * JD-Core Version:    0.6.2
 */