/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.CacheManager;
/*    */ 
/*    */ public abstract class AbstractCacheManager
/*    */   implements CacheManager, InitializingBean
/*    */ {
/* 40 */   private final ConcurrentMap<String, Cache> cacheMap = new ConcurrentHashMap(16);
/*    */ 
/* 42 */   private Set<String> cacheNames = new LinkedHashSet(16);
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 47 */     Collection caches = loadCaches();
/*    */ 
/* 50 */     this.cacheMap.clear();
/* 51 */     this.cacheNames.clear();
/* 52 */     for (Cache cache : caches) {
/* 53 */       this.cacheMap.put(cache.getName(), decorateCache(cache));
/* 54 */       this.cacheNames.add(cache.getName());
/*    */     }
/*    */   }
/*    */ 
/*    */   protected final void addCache(Cache cache) {
/* 59 */     this.cacheMap.put(cache.getName(), decorateCache(cache));
/* 60 */     this.cacheNames.add(cache.getName());
/*    */   }
/*    */ 
/*    */   protected Cache decorateCache(Cache cache)
/*    */   {
/* 70 */     return cache;
/*    */   }
/*    */ 
/*    */   public Cache getCache(String name)
/*    */   {
/* 76 */     return (Cache)this.cacheMap.get(name);
/*    */   }
/*    */ 
/*    */   public Collection<String> getCacheNames()
/*    */   {
/* 81 */     return Collections.unmodifiableSet(this.cacheNames);
/*    */   }
/*    */ 
/*    */   protected abstract Collection<? extends Cache> loadCaches();
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.AbstractCacheManager
 * JD-Core Version:    0.6.2
 */