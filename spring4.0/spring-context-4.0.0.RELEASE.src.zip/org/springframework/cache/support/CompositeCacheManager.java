/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class CompositeCacheManager
/*    */   implements InitializingBean, CacheManager
/*    */ {
/*    */   private List<CacheManager> cacheManagers;
/* 44 */   private boolean fallbackToNoOpCache = false;
/*    */ 
/*    */   public void setCacheManagers(Collection<CacheManager> cacheManagers)
/*    */   {
/* 48 */     Assert.notEmpty(cacheManagers, "cacheManagers Collection must not be empty");
/* 49 */     this.cacheManagers = new ArrayList();
/* 50 */     this.cacheManagers.addAll(cacheManagers);
/*    */   }
/*    */ 
/*    */   public void setFallbackToNoOpCache(boolean fallbackToNoOpCache)
/*    */   {
/* 59 */     this.fallbackToNoOpCache = fallbackToNoOpCache;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 64 */     if (this.fallbackToNoOpCache)
/* 65 */       this.cacheManagers.add(new NoOpCacheManager());
/*    */   }
/*    */ 
/*    */   public Cache getCache(String name)
/*    */   {
/* 72 */     for (CacheManager cacheManager : this.cacheManagers) {
/* 73 */       Cache cache = cacheManager.getCache(name);
/* 74 */       if (cache != null) {
/* 75 */         return cache;
/*    */       }
/*    */     }
/* 78 */     return null;
/*    */   }
/*    */ 
/*    */   public Collection<String> getCacheNames()
/*    */   {
/* 83 */     List names = new ArrayList();
/* 84 */     for (CacheManager manager : this.cacheManagers) {
/* 85 */       names.addAll(manager.getCacheNames());
/*    */     }
/* 87 */     return Collections.unmodifiableList(names);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.CompositeCacheManager
 * JD-Core Version:    0.6.2
 */