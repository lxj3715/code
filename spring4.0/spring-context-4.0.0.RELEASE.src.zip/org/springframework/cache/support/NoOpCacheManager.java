/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.cache.CacheManager;
/*     */ 
/*     */ public class NoOpCacheManager
/*     */   implements CacheManager
/*     */ {
/*     */   private final ConcurrentMap<String, Cache> caches;
/*     */   private final Set<String> cacheNames;
/*     */ 
/*     */   public NoOpCacheManager()
/*     */   {
/*  42 */     this.caches = new ConcurrentHashMap(16);
/*     */ 
/*  44 */     this.cacheNames = new LinkedHashSet(16);
/*     */   }
/*     */ 
/*     */   public Cache getCache(String name)
/*     */   {
/*  53 */     Cache cache = (Cache)this.caches.get(name);
/*  54 */     if (cache == null) {
/*  55 */       this.caches.putIfAbsent(name, new NoOpCache(name));
/*  56 */       synchronized (this.cacheNames) {
/*  57 */         this.cacheNames.add(name);
/*     */       }
/*     */     }
/*     */ 
/*  61 */     return (Cache)this.caches.get(name);
/*     */   }
/*     */ 
/*     */   public Collection<String> getCacheNames()
/*     */   {
/*  69 */     synchronized (this.cacheNames) {
/*  70 */       return Collections.unmodifiableSet(this.cacheNames);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class NoOpCache implements Cache
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     public NoOpCache(String name)
/*     */     {
/*  80 */       this.name = name;
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void evict(Object key)
/*     */     {
/*     */     }
/*     */ 
/*     */     public Cache.ValueWrapper get(Object key)
/*     */     {
/*  93 */       return null;
/*     */     }
/*     */ 
/*     */     public <T> T get(Object key, Class<T> type)
/*     */     {
/*  98 */       return null;
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/* 103 */       return this.name;
/*     */     }
/*     */ 
/*     */     public Object getNativeCache()
/*     */     {
/* 108 */       return null;
/*     */     }
/*     */ 
/*     */     public void put(Object key, Object value)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.NoOpCacheManager
 * JD-Core Version:    0.6.2
 */