/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.cache.Cache;
/*    */ 
/*    */ public class SimpleCacheManager extends AbstractCacheManager
/*    */ {
/*    */   private Collection<? extends Cache> caches;
/*    */ 
/*    */   public void setCaches(Collection<? extends Cache> caches)
/*    */   {
/* 39 */     this.caches = caches;
/*    */   }
/*    */ 
/*    */   protected Collection<? extends Cache> loadCaches()
/*    */   {
/* 44 */     return this.caches;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.SimpleCacheManager
 * JD-Core Version:    0.6.2
 */