/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import org.springframework.cache.Cache.ValueWrapper;
/*    */ 
/*    */ public class SimpleValueWrapper
/*    */   implements Cache.ValueWrapper
/*    */ {
/*    */   private final Object value;
/*    */ 
/*    */   public SimpleValueWrapper(Object value)
/*    */   {
/* 38 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Object get()
/*    */   {
/* 47 */     return this.value;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.SimpleValueWrapper
 * JD-Core Version:    0.6.2
 */