package org.springframework.context;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.Aware;

public abstract interface ApplicationContextAware extends Aware
{
  public abstract void setApplicationContext(ApplicationContext paramApplicationContext)
    throws BeansException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationContextAware
 * JD-Core Version:    0.6.2
 */