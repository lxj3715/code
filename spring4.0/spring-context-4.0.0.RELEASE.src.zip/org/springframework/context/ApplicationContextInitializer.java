package org.springframework.context;

public abstract interface ApplicationContextInitializer<C extends ConfigurableApplicationContext>
{
  public abstract void initialize(C paramC);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationContextInitializer
 * JD-Core Version:    0.6.2
 */