package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.util.StringValueResolver;

public abstract interface EmbeddedValueResolverAware extends Aware
{
  public abstract void setEmbeddedValueResolver(StringValueResolver paramStringValueResolver);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.EmbeddedValueResolverAware
 * JD-Core Version:    0.6.2
 */