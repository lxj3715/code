package org.springframework.context;

public abstract interface HierarchicalMessageSource extends MessageSource
{
  public abstract void setParentMessageSource(MessageSource paramMessageSource);

  public abstract MessageSource getParentMessageSource();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.HierarchicalMessageSource
 * JD-Core Version:    0.6.2
 */