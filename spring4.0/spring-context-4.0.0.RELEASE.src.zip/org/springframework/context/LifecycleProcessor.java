package org.springframework.context;

public abstract interface LifecycleProcessor extends Lifecycle
{
  public abstract void onRefresh();

  public abstract void onClose();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.LifecycleProcessor
 * JD-Core Version:    0.6.2
 */