package org.springframework.context;

public abstract interface MessageSourceResolvable
{
  public abstract String[] getCodes();

  public abstract Object[] getArguments();

  public abstract String getDefaultMessage();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.MessageSourceResolvable
 * JD-Core Version:    0.6.2
 */