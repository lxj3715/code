package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.core.io.ResourceLoader;

public abstract interface ResourceLoaderAware extends Aware
{
  public abstract void setResourceLoader(ResourceLoader paramResourceLoader);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.ResourceLoaderAware
 * JD-Core Version:    0.6.2
 */