/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.core.GenericTypeResolver;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class AdviceModeImportSelector<A extends Annotation>
/*    */   implements ImportSelector
/*    */ {
/*    */   public static final String DEFAULT_ADVICE_MODE_ATTRIBUTE_NAME = "mode";
/*    */ 
/*    */   protected String getAdviceModeAttributeName()
/*    */   {
/* 46 */     return "mode";
/*    */   }
/*    */ 
/*    */   public final String[] selectImports(AnnotationMetadata importingClassMetadata)
/*    */   {
/* 63 */     Class annoType = GenericTypeResolver.resolveTypeArgument(getClass(), AdviceModeImportSelector.class);
/* 64 */     AnnotationAttributes attributes = AnnotationConfigUtils.attributesFor(importingClassMetadata, annoType);
/* 65 */     Assert.notNull(attributes, String.format("@%s is not present on importing class '%s' as expected", new Object[] { annoType
/* 67 */       .getSimpleName(), importingClassMetadata.getClassName() }));
/*    */ 
/* 69 */     AdviceMode adviceMode = (AdviceMode)attributes.getEnum(getAdviceModeAttributeName());
/* 70 */     String[] imports = selectImports(adviceMode);
/* 71 */     Assert.notNull(imports, String.format("Unknown AdviceMode: '%s'", new Object[] { adviceMode }));
/* 72 */     return imports;
/*    */   }
/*    */ 
/*    */   protected abstract String[] selectImports(AdviceMode paramAdviceMode);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AdviceModeImportSelector
 * JD-Core Version:    0.6.2
 */