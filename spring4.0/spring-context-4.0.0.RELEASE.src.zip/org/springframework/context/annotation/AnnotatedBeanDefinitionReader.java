/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class AnnotatedBeanDefinitionReader
/*     */ {
/*     */   private final BeanDefinitionRegistry registry;
/*  48 */   private BeanNameGenerator beanNameGenerator = new AnnotationBeanNameGenerator();
/*     */ 
/*  50 */   private ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */   private ConditionEvaluator conditionEvaluator;
/*     */ 
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry)
/*     */   {
/*  66 */     this(registry, getOrCreateEnvironment(registry));
/*     */   }
/*     */ 
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry, Environment environment)
/*     */   {
/*  79 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*  80 */     Assert.notNull(environment, "Environment must not be null");
/*  81 */     this.registry = registry;
/*  82 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, null);
/*  83 */     AnnotationConfigUtils.registerAnnotationConfigProcessors(this.registry);
/*     */   }
/*     */ 
/*     */   public final BeanDefinitionRegistry getRegistry()
/*     */   {
/*  90 */     return this.registry;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 100 */     this.conditionEvaluator = new ConditionEvaluator(this.registry, environment, null);
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 108 */     this.beanNameGenerator = (beanNameGenerator != null ? beanNameGenerator : new AnnotationBeanNameGenerator());
/*     */   }
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 116 */     this.scopeMetadataResolver = (scopeMetadataResolver != null ? scopeMetadataResolver : new AnnotationScopeMetadataResolver());
/*     */   }
/*     */ 
/*     */   public void register(Class<?>[] annotatedClasses)
/*     */   {
/* 121 */     for (Class annotatedClass : annotatedClasses)
/* 122 */       registerBean(annotatedClass);
/*     */   }
/*     */ 
/*     */   public void registerBean(Class<?> annotatedClass)
/*     */   {
/* 127 */     registerBean(annotatedClass, null, (Class[])null);
/*     */   }
/*     */ 
/*     */   public void registerBean(Class<?> annotatedClass, Class<? extends Annotation>[] qualifiers)
/*     */   {
/* 133 */     registerBean(annotatedClass, null, qualifiers);
/*     */   }
/*     */ 
/*     */   public void registerBean(Class<?> annotatedClass, String name, Class<? extends Annotation>[] qualifiers)
/*     */   {
/* 139 */     AnnotatedGenericBeanDefinition abd = new AnnotatedGenericBeanDefinition(annotatedClass);
/* 140 */     if (this.conditionEvaluator.shouldSkip(abd.getMetadata())) {
/* 141 */       return;
/*     */     }
/*     */ 
/* 144 */     ScopeMetadata scopeMetadata = this.scopeMetadataResolver.resolveScopeMetadata(abd);
/* 145 */     abd.setScope(scopeMetadata.getScopeName());
/* 146 */     String beanName = name != null ? name : this.beanNameGenerator.generateBeanName(abd, this.registry);
/* 147 */     AnnotationConfigUtils.processCommonDefinitionAnnotations(abd);
/* 148 */     if (qualifiers != null) {
/* 149 */       for (Class qualifier : qualifiers) {
/* 150 */         if (Primary.class.equals(qualifier)) {
/* 151 */           abd.setPrimary(true);
/*     */         }
/* 153 */         else if (Lazy.class.equals(qualifier)) {
/* 154 */           abd.setLazyInit(true);
/*     */         }
/*     */         else {
/* 157 */           abd.addQualifier(new AutowireCandidateQualifier(qualifier));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 162 */     BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder(abd, beanName);
/* 163 */     definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 164 */     BeanDefinitionReaderUtils.registerBeanDefinition(definitionHolder, this.registry);
/*     */   }
/*     */ 
/*     */   private static Environment getOrCreateEnvironment(BeanDefinitionRegistry registry)
/*     */   {
/* 173 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 174 */     if ((registry instanceof EnvironmentCapable)) {
/* 175 */       return ((EnvironmentCapable)registry).getEnvironment();
/*     */     }
/* 177 */     return new StandardEnvironment();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotatedBeanDefinitionReader
 * JD-Core Version:    0.6.2
 */