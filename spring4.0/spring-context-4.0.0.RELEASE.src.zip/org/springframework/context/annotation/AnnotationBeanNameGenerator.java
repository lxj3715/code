/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AnnotationBeanNameGenerator
/*     */   implements BeanNameGenerator
/*     */ {
/*     */   private static final String COMPONENT_ANNOTATION_CLASSNAME = "org.springframework.stereotype.Component";
/*     */ 
/*     */   public String generateBeanName(BeanDefinition definition, BeanDefinitionRegistry registry)
/*     */   {
/*  69 */     if ((definition instanceof AnnotatedBeanDefinition)) {
/*  70 */       String beanName = determineBeanNameFromAnnotation((AnnotatedBeanDefinition)definition);
/*  71 */       if (StringUtils.hasText(beanName))
/*     */       {
/*  73 */         return beanName;
/*     */       }
/*     */     }
/*     */ 
/*  77 */     return buildDefaultBeanName(definition, registry);
/*     */   }
/*     */ 
/*     */   protected String determineBeanNameFromAnnotation(AnnotatedBeanDefinition annotatedDef)
/*     */   {
/*  86 */     AnnotationMetadata amd = annotatedDef.getMetadata();
/*  87 */     Set types = amd.getAnnotationTypes();
/*  88 */     String beanName = null;
/*  89 */     for (String type : types) {
/*  90 */       AnnotationAttributes attributes = AnnotationConfigUtils.attributesFor(amd, type);
/*  91 */       if (isStereotypeWithNameValue(type, amd.getMetaAnnotationTypes(type), attributes)) {
/*  92 */         String value = (String)attributes.get("value");
/*  93 */         if (StringUtils.hasLength(value)) {
/*  94 */           if ((beanName != null) && (!value.equals(beanName))) {
/*  95 */             throw new IllegalStateException("Stereotype annotations suggest inconsistent component names: '" + beanName + "' versus '" + value + "'");
/*     */           }
/*     */ 
/*  98 */           beanName = value;
/*     */         }
/*     */       }
/*     */     }
/* 102 */     return beanName;
/*     */   }
/*     */ 
/*     */   protected boolean isStereotypeWithNameValue(String annotationType, Set<String> metaAnnotationTypes, Map<String, Object> attributes)
/*     */   {
/* 119 */     boolean isStereotype = (annotationType.equals("org.springframework.stereotype.Component")) || ((metaAnnotationTypes != null) && 
/* 117 */       (metaAnnotationTypes
/* 117 */       .contains("org.springframework.stereotype.Component"))) || 
/* 118 */       (annotationType
/* 118 */       .equals("javax.annotation.ManagedBean")) || 
/* 119 */       (annotationType
/* 119 */       .equals("javax.inject.Named"));
/*     */ 
/* 123 */     return (isStereotype) && (attributes != null) && 
/* 122 */       (attributes
/* 122 */       .containsKey("value")) && 
/* 123 */       ((attributes
/* 123 */       .get("value") instanceof String));
/*     */   }
/*     */ 
/*     */   protected String buildDefaultBeanName(BeanDefinition definition, BeanDefinitionRegistry registry)
/*     */   {
/* 134 */     return buildDefaultBeanName(definition);
/*     */   }
/*     */ 
/*     */   protected String buildDefaultBeanName(BeanDefinition definition)
/*     */   {
/* 148 */     String shortClassName = ClassUtils.getShortName(definition.getBeanClassName());
/* 149 */     return Introspector.decapitalize(shortClassName);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotationBeanNameGenerator
 * JD-Core Version:    0.6.2
 */