/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AutowiredAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.annotation.RequiredAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class AnnotationConfigUtils
/*     */ {
/*     */   public static final String CONFIGURATION_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalConfigurationAnnotationProcessor";
/*     */   public static final String CONFIGURATION_BEAN_NAME_GENERATOR = "org.springframework.context.annotation.internalConfigurationBeanNameGenerator";
/*     */   public static final String AUTOWIRED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalAutowiredAnnotationProcessor";
/*     */   public static final String REQUIRED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalRequiredAnnotationProcessor";
/*     */   public static final String COMMON_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalCommonAnnotationProcessor";
/*     */   public static final String SCHEDULED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalScheduledAnnotationProcessor";
/*     */   public static final String ASYNC_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalAsyncAnnotationProcessor";
/*     */   public static final String ASYNC_EXECUTION_ASPECT_BEAN_NAME = "org.springframework.scheduling.config.internalAsyncExecutionAspect";
/*     */   public static final String ASYNC_EXECUTION_ASPECT_CLASS_NAME = "org.springframework.scheduling.aspectj.AnnotationAsyncExecutionAspect";
/*     */   public static final String ASYNC_EXECUTION_ASPECT_CONFIGURATION_CLASS_NAME = "org.springframework.scheduling.aspectj.AspectJAsyncConfiguration";
/*     */   public static final String CACHE_ADVISOR_BEAN_NAME = "org.springframework.cache.config.internalCacheAdvisor";
/*     */   public static final String CACHE_ASPECT_BEAN_NAME = "org.springframework.cache.config.internalCacheAspect";
/*     */   public static final String CACHE_ASPECT_CLASS_NAME = "org.springframework.cache.aspectj.AnnotationCacheAspect";
/*     */   public static final String CACHE_ASPECT_CONFIGURATION_CLASS_NAME = "org.springframework.cache.aspectj.AspectJCachingConfiguration";
/*     */   public static final String PERSISTENCE_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalPersistenceAnnotationProcessor";
/*     */   private static final String PERSISTENCE_ANNOTATION_PROCESSOR_CLASS_NAME = "org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor";
/* 162 */   private static final boolean jsr250Present = ClassUtils.isPresent("javax.annotation.Resource", AnnotationConfigUtils.class
/* 162 */     .getClassLoader());
/*     */ 
/* 165 */   private static final boolean jpaPresent = (ClassUtils.isPresent("javax.persistence.EntityManagerFactory", AnnotationConfigUtils.class
/* 165 */     .getClassLoader())) && 
/* 166 */     (ClassUtils.isPresent("org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor", AnnotationConfigUtils.class
/* 166 */     .getClassLoader()));
/*     */ 
/*     */   public static void registerAnnotationConfigProcessors(BeanDefinitionRegistry registry)
/*     */   {
/* 174 */     registerAnnotationConfigProcessors(registry, null);
/*     */   }
/*     */ 
/*     */   public static Set<BeanDefinitionHolder> registerAnnotationConfigProcessors(BeanDefinitionRegistry registry, Object source)
/*     */   {
/* 188 */     DefaultListableBeanFactory beanFactory = unwrapDefaultListableBeanFactory(registry);
/* 189 */     if (beanFactory != null) {
/* 190 */       if (!(beanFactory.getDependencyComparator() instanceof AnnotationAwareOrderComparator)) {
/* 191 */         beanFactory.setDependencyComparator(AnnotationAwareOrderComparator.INSTANCE);
/*     */       }
/* 193 */       if (!(beanFactory.getAutowireCandidateResolver() instanceof ContextAnnotationAutowireCandidateResolver)) {
/* 194 */         beanFactory.setAutowireCandidateResolver(new ContextAnnotationAutowireCandidateResolver());
/*     */       }
/*     */     }
/*     */ 
/* 198 */     Set beanDefs = new LinkedHashSet(4);
/*     */ 
/* 200 */     if (!registry.containsBeanDefinition("org.springframework.context.annotation.internalConfigurationAnnotationProcessor")) {
/* 201 */       RootBeanDefinition def = new RootBeanDefinition(ConfigurationClassPostProcessor.class);
/* 202 */       def.setSource(source);
/* 203 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalConfigurationAnnotationProcessor"));
/*     */     }
/*     */ 
/* 206 */     if (!registry.containsBeanDefinition("org.springframework.context.annotation.internalAutowiredAnnotationProcessor")) {
/* 207 */       RootBeanDefinition def = new RootBeanDefinition(AutowiredAnnotationBeanPostProcessor.class);
/* 208 */       def.setSource(source);
/* 209 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalAutowiredAnnotationProcessor"));
/*     */     }
/*     */ 
/* 212 */     if (!registry.containsBeanDefinition("org.springframework.context.annotation.internalRequiredAnnotationProcessor")) {
/* 213 */       RootBeanDefinition def = new RootBeanDefinition(RequiredAnnotationBeanPostProcessor.class);
/* 214 */       def.setSource(source);
/* 215 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalRequiredAnnotationProcessor"));
/*     */     }
/*     */ 
/* 219 */     if ((jsr250Present) && (!registry.containsBeanDefinition("org.springframework.context.annotation.internalCommonAnnotationProcessor"))) {
/* 220 */       RootBeanDefinition def = new RootBeanDefinition(CommonAnnotationBeanPostProcessor.class);
/* 221 */       def.setSource(source);
/* 222 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalCommonAnnotationProcessor"));
/*     */     }
/*     */ 
/* 226 */     if ((jpaPresent) && (!registry.containsBeanDefinition("org.springframework.context.annotation.internalPersistenceAnnotationProcessor"))) {
/* 227 */       RootBeanDefinition def = new RootBeanDefinition();
/*     */       try {
/* 229 */         ClassLoader cl = AnnotationConfigUtils.class.getClassLoader();
/* 230 */         def.setBeanClass(cl.loadClass("org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor"));
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 233 */         throw new IllegalStateException("Cannot load optional framework class: org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor", ex);
/*     */       }
/*     */ 
/* 236 */       def.setSource(source);
/* 237 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalPersistenceAnnotationProcessor"));
/*     */     }
/*     */ 
/* 240 */     return beanDefs;
/*     */   }
/*     */ 
/*     */   private static BeanDefinitionHolder registerPostProcessor(BeanDefinitionRegistry registry, RootBeanDefinition definition, String beanName)
/*     */   {
/* 246 */     definition.setRole(2);
/* 247 */     registry.registerBeanDefinition(beanName, definition);
/* 248 */     return new BeanDefinitionHolder(definition, beanName);
/*     */   }
/*     */ 
/*     */   private static DefaultListableBeanFactory unwrapDefaultListableBeanFactory(BeanDefinitionRegistry registry) {
/* 252 */     if ((registry instanceof DefaultListableBeanFactory)) {
/* 253 */       return (DefaultListableBeanFactory)registry;
/*     */     }
/* 255 */     if ((registry instanceof GenericApplicationContext)) {
/* 256 */       return ((GenericApplicationContext)registry).getDefaultListableBeanFactory();
/*     */     }
/*     */ 
/* 259 */     return null;
/*     */   }
/*     */ 
/*     */   public static void processCommonDefinitionAnnotations(AnnotatedBeanDefinition abd)
/*     */   {
/* 264 */     processCommonDefinitionAnnotations(abd, abd.getMetadata());
/*     */   }
/*     */ 
/*     */   static void processCommonDefinitionAnnotations(AnnotatedBeanDefinition abd, AnnotatedTypeMetadata metadata) {
/* 268 */     if (metadata.isAnnotated(Lazy.class.getName())) {
/* 269 */       abd.setLazyInit(attributesFor(metadata, Lazy.class).getBoolean("value"));
/*     */     }
/* 271 */     else if (abd.getMetadata().isAnnotated(Lazy.class.getName())) {
/* 272 */       abd.setLazyInit(attributesFor(abd.getMetadata(), Lazy.class).getBoolean("value"));
/*     */     }
/*     */ 
/* 275 */     if (metadata.isAnnotated(Primary.class.getName())) {
/* 276 */       abd.setPrimary(true);
/*     */     }
/* 278 */     if (metadata.isAnnotated(DependsOn.class.getName())) {
/* 279 */       abd.setDependsOn(attributesFor(metadata, DependsOn.class).getStringArray("value"));
/*     */     }
/*     */ 
/* 282 */     if ((abd instanceof AbstractBeanDefinition)) {
/* 283 */       AbstractBeanDefinition absBd = (AbstractBeanDefinition)abd;
/* 284 */       if (metadata.isAnnotated(Role.class.getName())) {
/* 285 */         absBd.setRole(attributesFor(metadata, Role.class).getNumber("value").intValue());
/*     */       }
/* 287 */       if (metadata.isAnnotated(Description.class.getName()))
/* 288 */         absBd.setDescription(attributesFor(metadata, Description.class).getString("value"));
/*     */     }
/*     */   }
/*     */ 
/*     */   static BeanDefinitionHolder applyScopedProxyMode(ScopeMetadata metadata, BeanDefinitionHolder definition, BeanDefinitionRegistry registry)
/*     */   {
/* 296 */     ScopedProxyMode scopedProxyMode = metadata.getScopedProxyMode();
/* 297 */     if (scopedProxyMode.equals(ScopedProxyMode.NO)) {
/* 298 */       return definition;
/*     */     }
/* 300 */     boolean proxyTargetClass = scopedProxyMode.equals(ScopedProxyMode.TARGET_CLASS);
/* 301 */     return ScopedProxyCreator.createScopedProxy(definition, registry, proxyTargetClass);
/*     */   }
/*     */ 
/*     */   static AnnotationAttributes attributesFor(AnnotatedTypeMetadata metadata, Class<?> annotationClass) {
/* 305 */     return attributesFor(metadata, annotationClass.getName());
/*     */   }
/*     */ 
/*     */   static AnnotationAttributes attributesFor(AnnotatedTypeMetadata metadata, String annotationClassName) {
/* 309 */     return AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(annotationClassName, false));
/*     */   }
/*     */ 
/*     */   static Set<AnnotationAttributes> attributesForRepeatable(AnnotationMetadata metadata, Class<?> containerClass, Class<?> annotationClass)
/*     */   {
/* 314 */     return attributesForRepeatable(metadata, containerClass.getName(), annotationClass.getName());
/*     */   }
/*     */ 
/*     */   static Set<AnnotationAttributes> attributesForRepeatable(AnnotationMetadata metadata, String containerClassName, String annotationClassName)
/*     */   {
/* 320 */     Set result = new LinkedHashSet();
/*     */ 
/* 322 */     addAttributesIfNotNull(result, metadata.getAnnotationAttributes(annotationClassName, false));
/*     */ 
/* 324 */     Map container = metadata.getAnnotationAttributes(containerClassName, false);
/* 325 */     if ((container != null) && (container.containsKey("value"))) {
/* 326 */       for (Map containedAttributes : (Map[])container.get("value")) {
/* 327 */         addAttributesIfNotNull(result, containedAttributes);
/*     */       }
/*     */     }
/* 330 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */ 
/*     */   private static void addAttributesIfNotNull(Set<AnnotationAttributes> result, Map<String, Object> attributes)
/*     */   {
/* 335 */     if (attributes != null)
/* 336 */       result.add(AnnotationAttributes.fromMap(attributes));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotationConfigUtils
 * JD-Core Version:    0.6.2
 */