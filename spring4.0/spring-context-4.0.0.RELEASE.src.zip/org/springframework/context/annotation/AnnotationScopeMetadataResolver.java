/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AnnotationScopeMetadataResolver
/*    */   implements ScopeMetadataResolver
/*    */ {
/*    */   private final ScopedProxyMode defaultProxyMode;
/* 42 */   protected Class<? extends Annotation> scopeAnnotationType = Scope.class;
/*    */ 
/*    */   public AnnotationScopeMetadataResolver()
/*    */   {
/* 51 */     this.defaultProxyMode = ScopedProxyMode.NO;
/*    */   }
/*    */ 
/*    */   public AnnotationScopeMetadataResolver(ScopedProxyMode defaultProxyMode)
/*    */   {
/* 59 */     Assert.notNull(defaultProxyMode, "'defaultProxyMode' must not be null");
/* 60 */     this.defaultProxyMode = defaultProxyMode;
/*    */   }
/*    */ 
/*    */   public void setScopeAnnotationType(Class<? extends Annotation> scopeAnnotationType)
/*    */   {
/* 70 */     Assert.notNull(scopeAnnotationType, "'scopeAnnotationType' must not be null");
/* 71 */     this.scopeAnnotationType = scopeAnnotationType;
/*    */   }
/*    */ 
/*    */   public ScopeMetadata resolveScopeMetadata(BeanDefinition definition)
/*    */   {
/* 77 */     ScopeMetadata metadata = new ScopeMetadata();
/* 78 */     if ((definition instanceof AnnotatedBeanDefinition)) {
/* 79 */       AnnotatedBeanDefinition annDef = (AnnotatedBeanDefinition)definition;
/* 80 */       AnnotationAttributes attributes = AnnotationConfigUtils.attributesFor(annDef.getMetadata(), this.scopeAnnotationType);
/* 81 */       if (attributes != null) {
/* 82 */         metadata.setScopeName(attributes.getString("value"));
/* 83 */         ScopedProxyMode proxyMode = (ScopedProxyMode)attributes.getEnum("proxyMode");
/* 84 */         if ((proxyMode == null) || (proxyMode == ScopedProxyMode.DEFAULT)) {
/* 85 */           proxyMode = this.defaultProxyMode;
/*    */         }
/* 87 */         metadata.setScopedProxyMode(proxyMode);
/*    */       }
/*    */     }
/* 90 */     return metadata;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotationScopeMetadataResolver
 * JD-Core Version:    0.6.2
 */