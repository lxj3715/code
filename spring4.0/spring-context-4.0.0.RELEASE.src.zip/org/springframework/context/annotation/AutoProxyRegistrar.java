/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.aop.config.AopConfigUtils;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ public class AutoProxyRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/* 40 */   private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry)
/*    */   {
/* 59 */     boolean candidateFound = false;
/* 60 */     Set annoTypes = importingClassMetadata.getAnnotationTypes();
/* 61 */     for (String annoType : annoTypes) {
/* 62 */       AnnotationAttributes candidate = AnnotationConfigUtils.attributesFor(importingClassMetadata, annoType);
/* 63 */       Object mode = candidate.get("mode");
/* 64 */       Object proxyTargetClass = candidate.get("proxyTargetClass");
/* 65 */       if ((mode != null) && (proxyTargetClass != null) && (mode.getClass().equals(AdviceMode.class)) && 
/* 66 */         (proxyTargetClass
/* 66 */         .getClass().equals(Boolean.class))) {
/* 67 */         candidateFound = true;
/* 68 */         if (mode == AdviceMode.PROXY) {
/* 69 */           AopConfigUtils.registerAutoProxyCreatorIfNecessary(registry);
/* 70 */           if (((Boolean)proxyTargetClass).booleanValue()) {
/* 71 */             AopConfigUtils.forceAutoProxyCreatorToUseClassProxying(registry);
/* 72 */             return;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 77 */     if (!candidateFound) {
/* 78 */       String name = getClass().getSimpleName();
/* 79 */       this.logger.warn(String.format("%s was imported but no annotations were found having both 'mode' and 'proxyTargetClass' attributes of type AdviceMode and boolean respectively. This means that auto proxy creator registration and configuration may not have occured as intended, and components may not be proxied as expected. Check to ensure that %s has been @Import'ed on the same class where these annotations are declared; otherwise remove the import of %s altogether.", new Object[] { name, name, name }));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AutoProxyRegistrar
 * JD-Core Version:    0.6.2
 */