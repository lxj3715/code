/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class ClassPathScanningCandidateComponentProvider
/*     */   implements EnvironmentCapable, ResourceLoaderAware
/*     */ {
/*     */   static final String DEFAULT_RESOURCE_PATTERN = "**/*.class";
/*  75 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Environment environment;
/*  79 */   private ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
/*     */ 
/*  81 */   private MetadataReaderFactory metadataReaderFactory = new CachingMetadataReaderFactory(this.resourcePatternResolver);
/*     */ 
/*  84 */   private String resourcePattern = "**/*.class";
/*     */ 
/*  86 */   private final List<TypeFilter> includeFilters = new LinkedList();
/*     */ 
/*  88 */   private final List<TypeFilter> excludeFilters = new LinkedList();
/*     */   private ConditionEvaluator conditionEvaluator;
/*     */ 
/*     */   public ClassPathScanningCandidateComponentProvider(boolean useDefaultFilters)
/*     */   {
/* 102 */     this(useDefaultFilters, new StandardEnvironment());
/*     */   }
/*     */ 
/*     */   public ClassPathScanningCandidateComponentProvider(boolean useDefaultFilters, Environment environment)
/*     */   {
/* 115 */     if (useDefaultFilters) {
/* 116 */       registerDefaultFilters();
/*     */     }
/* 118 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 132 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/* 133 */     this.metadataReaderFactory = new CachingMetadataReaderFactory(resourceLoader);
/*     */   }
/*     */ 
/*     */   public final ResourceLoader getResourceLoader()
/*     */   {
/* 140 */     return this.resourcePatternResolver;
/*     */   }
/*     */ 
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory)
/*     */   {
/* 151 */     this.metadataReaderFactory = metadataReaderFactory;
/*     */   }
/*     */ 
/*     */   public final MetadataReaderFactory getMetadataReaderFactory()
/*     */   {
/* 158 */     return this.metadataReaderFactory;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 168 */     this.environment = environment;
/* 169 */     this.conditionEvaluator = null;
/*     */   }
/*     */ 
/*     */   public final Environment getEnvironment()
/*     */   {
/* 174 */     return this.environment;
/*     */   }
/*     */ 
/*     */   protected BeanDefinitionRegistry getRegistry()
/*     */   {
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   public void setResourcePattern(String resourcePattern)
/*     */   {
/* 191 */     Assert.notNull(resourcePattern, "'resourcePattern' must not be null");
/* 192 */     this.resourcePattern = resourcePattern;
/*     */   }
/*     */ 
/*     */   public void addIncludeFilter(TypeFilter includeFilter)
/*     */   {
/* 199 */     this.includeFilters.add(includeFilter);
/*     */   }
/*     */ 
/*     */   public void addExcludeFilter(TypeFilter excludeFilter)
/*     */   {
/* 206 */     this.excludeFilters.add(0, excludeFilter);
/*     */   }
/*     */ 
/*     */   public void resetFilters(boolean useDefaultFilters)
/*     */   {
/* 218 */     this.includeFilters.clear();
/* 219 */     this.excludeFilters.clear();
/* 220 */     if (useDefaultFilters)
/* 221 */       registerDefaultFilters();
/*     */   }
/*     */ 
/*     */   protected void registerDefaultFilters()
/*     */   {
/* 237 */     this.includeFilters.add(new AnnotationTypeFilter(Component.class));
/* 238 */     ClassLoader cl = ClassPathScanningCandidateComponentProvider.class.getClassLoader();
/*     */     try {
/* 240 */       this.includeFilters.add(new AnnotationTypeFilter(cl
/* 241 */         .loadClass("javax.annotation.ManagedBean"), 
/* 241 */         false));
/* 242 */       this.logger.debug("JSR-250 'javax.annotation.ManagedBean' found and supported for component scanning");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */     }
/*     */     try {
/* 248 */       this.includeFilters.add(new AnnotationTypeFilter(cl
/* 249 */         .loadClass("javax.inject.Named"), 
/* 249 */         false));
/* 250 */       this.logger.debug("JSR-330 'javax.inject.Named' annotation found and supported for component scanning");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set<BeanDefinition> findCandidateComponents(String basePackage)
/*     */   {
/* 264 */     Set candidates = new LinkedHashSet();
/*     */     try
/*     */     {
/* 267 */       String packageSearchPath = "classpath*:" + 
/* 267 */         resolveBasePackage(basePackage) + 
/* 267 */         "/" + this.resourcePattern;
/* 268 */       Resource[] resources = this.resourcePatternResolver.getResources(packageSearchPath);
/* 269 */       boolean traceEnabled = this.logger.isTraceEnabled();
/* 270 */       boolean debugEnabled = this.logger.isDebugEnabled();
/* 271 */       for (Resource resource : resources) {
/* 272 */         if (traceEnabled) {
/* 273 */           this.logger.trace("Scanning " + resource);
/*     */         }
/* 275 */         if (resource.isReadable()) {
/*     */           try {
/* 277 */             MetadataReader metadataReader = this.metadataReaderFactory.getMetadataReader(resource);
/* 278 */             if (isCandidateComponent(metadataReader)) {
/* 279 */               ScannedGenericBeanDefinition sbd = new ScannedGenericBeanDefinition(metadataReader);
/* 280 */               sbd.setResource(resource);
/* 281 */               sbd.setSource(resource);
/* 282 */               if (isCandidateComponent(sbd)) {
/* 283 */                 if (debugEnabled) {
/* 284 */                   this.logger.debug("Identified candidate component class: " + resource);
/*     */                 }
/* 286 */                 candidates.add(sbd);
/*     */               }
/* 289 */               else if (debugEnabled) {
/* 290 */                 this.logger.debug("Ignored because not a concrete top-level class: " + resource);
/*     */               }
/*     */ 
/*     */             }
/* 295 */             else if (traceEnabled) {
/* 296 */               this.logger.trace("Ignored because not matching any filter: " + resource);
/*     */             }
/*     */           }
/*     */           catch (Throwable ex)
/*     */           {
/* 301 */             throw new BeanDefinitionStoreException("Failed to read candidate component class: " + resource, ex);
/*     */           }
/*     */ 
/*     */         }
/* 306 */         else if (traceEnabled) {
/* 307 */           this.logger.trace("Ignored because not readable: " + resource);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 313 */       throw new BeanDefinitionStoreException("I/O failure during classpath scanning", ex);
/*     */     }
/* 315 */     return candidates;
/*     */   }
/*     */ 
/*     */   protected String resolveBasePackage(String basePackage)
/*     */   {
/* 328 */     return ClassUtils.convertClassNameToResourcePath(this.environment.resolveRequiredPlaceholders(basePackage));
/*     */   }
/*     */ 
/*     */   protected boolean isCandidateComponent(MetadataReader metadataReader)
/*     */     throws IOException
/*     */   {
/* 338 */     for (TypeFilter tf : this.excludeFilters) {
/* 339 */       if (tf.match(metadataReader, this.metadataReaderFactory)) {
/* 340 */         return false;
/*     */       }
/*     */     }
/* 343 */     for (TypeFilter tf : this.includeFilters) {
/* 344 */       if (tf.match(metadataReader, this.metadataReaderFactory)) {
/* 345 */         return isConditionMatch(metadataReader);
/*     */       }
/*     */     }
/* 348 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean isConditionMatch(MetadataReader metadataReader)
/*     */   {
/* 358 */     if (this.conditionEvaluator == null) {
/* 359 */       this.conditionEvaluator = new ConditionEvaluator(getRegistry(), getEnvironment(), getResourceLoader());
/*     */     }
/* 361 */     return !this.conditionEvaluator.shouldSkip(metadataReader.getAnnotationMetadata());
/*     */   }
/*     */ 
/*     */   protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition)
/*     */   {
/* 372 */     return (beanDefinition.getMetadata().isConcrete()) && (beanDefinition.getMetadata().isIndependent());
/*     */   }
/*     */ 
/*     */   public void clearCache()
/*     */   {
/* 380 */     if ((this.metadataReaderFactory instanceof CachingMetadataReaderFactory))
/* 381 */       ((CachingMetadataReaderFactory)this.metadataReaderFactory).clearCache();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider
 * JD-Core Version:    0.6.2
 */