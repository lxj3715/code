/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.annotation.PreDestroy;
/*     */ import javax.annotation.Resource;
/*     */ import javax.ejb.EJB;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebServiceClient;
/*     */ import javax.xml.ws.WebServiceRef;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.InitDestroyAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata.InjectedElement;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.jndi.support.SimpleJndiBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CommonAnnotationBeanPostProcessor extends InitDestroyAnnotationBeanPostProcessor
/*     */   implements InstantiationAwareBeanPostProcessor, BeanFactoryAware, Serializable
/*     */ {
/* 140 */   private static Class<? extends Annotation> webServiceRefClass = null;
/*     */ 
/* 142 */   private static Class<? extends Annotation> ejbRefClass = null;
/*     */ 
/* 165 */   private final Set<String> ignoredResourceTypes = new HashSet(1);
/*     */ 
/* 167 */   private boolean fallbackToDefaultTypeMatch = true;
/*     */ 
/* 169 */   private boolean alwaysUseJndiLookup = false;
/*     */ 
/* 171 */   private transient BeanFactory jndiFactory = new SimpleJndiBeanFactory();
/*     */   private transient BeanFactory resourceFactory;
/*     */   private transient BeanFactory beanFactory;
/* 177 */   private final transient Map<String, InjectionMetadata> injectionMetadataCache = new ConcurrentHashMap(64);
/*     */ 
/*     */   public CommonAnnotationBeanPostProcessor()
/*     */   {
/* 188 */     setOrder(2147483644);
/* 189 */     setInitAnnotationType(PostConstruct.class);
/* 190 */     setDestroyAnnotationType(PreDestroy.class);
/* 191 */     ignoreResourceType("javax.xml.ws.WebServiceContext");
/*     */   }
/*     */ 
/*     */   public void ignoreResourceType(String resourceType)
/*     */   {
/* 203 */     Assert.notNull(resourceType, "Ignored resource type must not be null");
/* 204 */     this.ignoredResourceTypes.add(resourceType);
/*     */   }
/*     */ 
/*     */   public void setFallbackToDefaultTypeMatch(boolean fallbackToDefaultTypeMatch)
/*     */   {
/* 218 */     this.fallbackToDefaultTypeMatch = fallbackToDefaultTypeMatch;
/*     */   }
/*     */ 
/*     */   public void setAlwaysUseJndiLookup(boolean alwaysUseJndiLookup)
/*     */   {
/* 232 */     this.alwaysUseJndiLookup = alwaysUseJndiLookup;
/*     */   }
/*     */ 
/*     */   public void setJndiFactory(BeanFactory jndiFactory)
/*     */   {
/* 247 */     Assert.notNull(jndiFactory, "BeanFactory must not be null");
/* 248 */     this.jndiFactory = jndiFactory;
/*     */   }
/*     */ 
/*     */   public void setResourceFactory(BeanFactory resourceFactory)
/*     */   {
/* 265 */     Assert.notNull(resourceFactory, "BeanFactory must not be null");
/* 266 */     this.resourceFactory = resourceFactory;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/* 271 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 272 */     this.beanFactory = beanFactory;
/* 273 */     if (this.resourceFactory == null)
/* 274 */       this.resourceFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName)
/*     */   {
/* 281 */     super.postProcessMergedBeanDefinition(beanDefinition, beanType, beanName);
/* 282 */     if (beanType != null) {
/* 283 */       InjectionMetadata metadata = findResourceMetadata(beanName, beanType);
/* 284 */       metadata.checkConfigMembers(beanDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException
/*     */   {
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException
/*     */   {
/* 295 */     return true;
/*     */   }
/*     */ 
/*     */   public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 302 */     InjectionMetadata metadata = findResourceMetadata(beanName, bean.getClass());
/*     */     try {
/* 304 */       metadata.inject(bean, beanName, pvs);
/*     */     }
/*     */     catch (Throwable ex) {
/* 307 */       throw new BeanCreationException(beanName, "Injection of resource dependencies failed", ex);
/*     */     }
/* 309 */     return pvs;
/*     */   }
/*     */ 
/*     */   private InjectionMetadata findResourceMetadata(String beanName, Class<?> clazz)
/*     */   {
/* 316 */     String cacheKey = StringUtils.hasLength(beanName) ? beanName : clazz.getName();
/* 317 */     InjectionMetadata metadata = (InjectionMetadata)this.injectionMetadataCache.get(cacheKey);
/* 318 */     if (metadata == null) {
/* 319 */       synchronized (this.injectionMetadataCache) {
/* 320 */         metadata = (InjectionMetadata)this.injectionMetadataCache.get(cacheKey);
/* 321 */         if (metadata == null) {
/* 322 */           LinkedList elements = new LinkedList();
/* 323 */           Class targetClass = clazz;
/*     */           do
/*     */           {
/* 326 */             LinkedList currElements = new LinkedList();
/* 327 */             for (Field field : targetClass.getDeclaredFields()) {
/* 328 */               if ((webServiceRefClass != null) && (field.isAnnotationPresent(webServiceRefClass))) {
/* 329 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 330 */                   throw new IllegalStateException("@WebServiceRef annotation is not supported on static fields");
/*     */                 }
/* 332 */                 currElements.add(new WebServiceRefElement(field, null));
/*     */               }
/* 334 */               else if ((ejbRefClass != null) && (field.isAnnotationPresent(ejbRefClass))) {
/* 335 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 336 */                   throw new IllegalStateException("@EJB annotation is not supported on static fields");
/*     */                 }
/* 338 */                 currElements.add(new EjbRefElement(field, null));
/*     */               }
/* 340 */               else if (field.isAnnotationPresent(Resource.class)) {
/* 341 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 342 */                   throw new IllegalStateException("@Resource annotation is not supported on static fields");
/*     */                 }
/* 344 */                 if (!this.ignoredResourceTypes.contains(field.getType().getName())) {
/* 345 */                   currElements.add(new ResourceElement(field, null));
/*     */                 }
/*     */               }
/*     */             }
/* 349 */             for (Method method : targetClass.getDeclaredMethods()) {
/* 350 */               method = BridgeMethodResolver.findBridgedMethod(method);
/* 351 */               Method mostSpecificMethod = BridgeMethodResolver.findBridgedMethod(ClassUtils.getMostSpecificMethod(method, clazz));
/* 352 */               if (method.equals(mostSpecificMethod)) {
/* 353 */                 if ((webServiceRefClass != null) && (method.isAnnotationPresent(webServiceRefClass))) {
/* 354 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 355 */                     throw new IllegalStateException("@WebServiceRef annotation is not supported on static methods");
/*     */                   }
/* 357 */                   if (method.getParameterTypes().length != 1) {
/* 358 */                     throw new IllegalStateException("@WebServiceRef annotation requires a single-arg method: " + method);
/*     */                   }
/* 360 */                   PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 361 */                   currElements.add(new WebServiceRefElement(method, pd));
/*     */                 }
/* 363 */                 else if ((ejbRefClass != null) && (method.isAnnotationPresent(ejbRefClass))) {
/* 364 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 365 */                     throw new IllegalStateException("@EJB annotation is not supported on static methods");
/*     */                   }
/* 367 */                   if (method.getParameterTypes().length != 1) {
/* 368 */                     throw new IllegalStateException("@EJB annotation requires a single-arg method: " + method);
/*     */                   }
/* 370 */                   PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 371 */                   currElements.add(new EjbRefElement(method, pd));
/*     */                 }
/* 373 */                 else if (method.isAnnotationPresent(Resource.class)) {
/* 374 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 375 */                     throw new IllegalStateException("@Resource annotation is not supported on static methods");
/*     */                   }
/* 377 */                   Class[] paramTypes = method.getParameterTypes();
/* 378 */                   if (paramTypes.length != 1) {
/* 379 */                     throw new IllegalStateException("@Resource annotation requires a single-arg method: " + method);
/*     */                   }
/* 381 */                   if (!this.ignoredResourceTypes.contains(paramTypes[0].getName())) {
/* 382 */                     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 383 */                     currElements.add(new ResourceElement(method, pd));
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/* 388 */             elements.addAll(0, currElements);
/* 389 */             targetClass = targetClass.getSuperclass();
/*     */           }
/* 391 */           while ((targetClass != null) && (targetClass != Object.class));
/*     */ 
/* 393 */           metadata = new InjectionMetadata(clazz, elements);
/* 394 */           this.injectionMetadataCache.put(cacheKey, metadata);
/*     */         }
/*     */       }
/*     */     }
/* 398 */     return metadata;
/*     */   }
/*     */ 
/*     */   protected Object getResource(LookupElement element, String requestingBeanName)
/*     */     throws BeansException
/*     */   {
/* 409 */     if (StringUtils.hasLength(element.mappedName)) {
/* 410 */       return this.jndiFactory.getBean(element.mappedName, element.lookupType);
/*     */     }
/* 412 */     if (this.alwaysUseJndiLookup) {
/* 413 */       return this.jndiFactory.getBean(element.name, element.lookupType);
/*     */     }
/* 415 */     if (this.resourceFactory == null) {
/* 416 */       throw new NoSuchBeanDefinitionException(element.lookupType, "No resource factory configured - specify the 'resourceFactory' property");
/*     */     }
/*     */ 
/* 419 */     return autowireResource(this.resourceFactory, element, requestingBeanName);
/*     */   }
/*     */ 
/*     */   protected Object autowireResource(BeanFactory factory, LookupElement element, String requestingBeanName)
/*     */     throws BeansException
/*     */   {
/* 436 */     String name = element.name;
/*     */     Object resource;
/*     */     Object resource;
/*     */     Set autowiredBeanNames;
/* 438 */     if ((this.fallbackToDefaultTypeMatch) && (element.isDefaultName) && ((factory instanceof AutowireCapableBeanFactory)) && 
/* 439 */       (!factory
/* 439 */       .containsBean(name)))
/*     */     {
/* 440 */       Set autowiredBeanNames = new LinkedHashSet();
/* 441 */       resource = ((AutowireCapableBeanFactory)factory).resolveDependency(element
/* 442 */         .getDependencyDescriptor(), requestingBeanName, autowiredBeanNames, null);
/*     */     }
/*     */     else {
/* 445 */       resource = factory.getBean(name, element.lookupType);
/* 446 */       autowiredBeanNames = Collections.singleton(name);
/*     */     }
/*     */     ConfigurableBeanFactory beanFactory;
/* 449 */     if ((factory instanceof ConfigurableBeanFactory)) {
/* 450 */       beanFactory = (ConfigurableBeanFactory)factory;
/* 451 */       for (String autowiredBeanName : autowiredBeanNames) {
/* 452 */         if (beanFactory.containsBean(autowiredBeanName)) {
/* 453 */           beanFactory.registerDependentBean(autowiredBeanName, requestingBeanName);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 458 */     return resource;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 145 */     ClassLoader cl = CommonAnnotationBeanPostProcessor.class.getClassLoader();
/*     */     try
/*     */     {
/* 148 */       Class clazz = cl.loadClass("javax.xml.ws.WebServiceRef");
/* 149 */       webServiceRefClass = clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 152 */       webServiceRefClass = null;
/*     */     }
/*     */     try
/*     */     {
/* 156 */       Class clazz = cl.loadClass("javax.ejb.EJB");
/* 157 */       ejbRefClass = clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 160 */       ejbRefClass = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LookupDependencyDescriptor extends DependencyDescriptor
/*     */   {
/*     */     private final Class<?> lookupType;
/*     */ 
/*     */     public LookupDependencyDescriptor(Field field, Class<?> lookupType)
/*     */     {
/* 701 */       super(true);
/* 702 */       this.lookupType = lookupType;
/*     */     }
/*     */ 
/*     */     public LookupDependencyDescriptor(Method method, Class<?> lookupType) {
/* 706 */       super(true);
/* 707 */       this.lookupType = lookupType;
/*     */     }
/*     */ 
/*     */     public Class<?> getDependencyType()
/*     */     {
/* 712 */       return this.lookupType;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EjbRefElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/*     */     private final String beanName;
/*     */ 
/*     */     public EjbRefElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 644 */       super(member, pd);
/* 645 */       AnnotatedElement ae = (AnnotatedElement)member;
/* 646 */       EJB resource = (EJB)ae.getAnnotation(EJB.class);
/* 647 */       String resourceBeanName = resource.beanName();
/* 648 */       String resourceName = resource.name();
/* 649 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 650 */       if (this.isDefaultName) {
/* 651 */         resourceName = this.member.getName();
/* 652 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 653 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 656 */       Class resourceType = resource.beanInterface();
/* 657 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 658 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 662 */         resourceType = getResourceType();
/*     */       }
/* 664 */       this.beanName = resourceBeanName;
/* 665 */       this.name = resourceName;
/* 666 */       this.lookupType = resourceType;
/* 667 */       this.mappedName = resource.mappedName();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/* 672 */       if (StringUtils.hasLength(this.beanName)) {
/* 673 */         if ((CommonAnnotationBeanPostProcessor.this.beanFactory != null) && (CommonAnnotationBeanPostProcessor.this.beanFactory.containsBean(this.beanName)))
/*     */         {
/* 675 */           Object bean = CommonAnnotationBeanPostProcessor.this.beanFactory.getBean(this.beanName, this.lookupType);
/* 676 */           if ((CommonAnnotationBeanPostProcessor.this.beanFactory instanceof ConfigurableBeanFactory)) {
/* 677 */             ((ConfigurableBeanFactory)CommonAnnotationBeanPostProcessor.this.beanFactory).registerDependentBean(this.beanName, requestingBeanName);
/*     */           }
/* 679 */           return bean;
/*     */         }
/* 681 */         if ((this.isDefaultName) && (!StringUtils.hasLength(this.mappedName))) {
/* 682 */           throw new NoSuchBeanDefinitionException(this.beanName, "Cannot resolve 'beanName' in local BeanFactory. Consider specifying a general 'name' value instead.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 687 */       return CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class WebServiceRefElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/*     */     private final Class<?> elementType;
/*     */     private final String wsdlLocation;
/*     */ 
/*     */     public WebServiceRefElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 560 */       super(member, pd);
/* 561 */       AnnotatedElement ae = (AnnotatedElement)member;
/* 562 */       WebServiceRef resource = (WebServiceRef)ae.getAnnotation(WebServiceRef.class);
/* 563 */       String resourceName = resource.name();
/* 564 */       Class resourceType = resource.type();
/* 565 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 566 */       if (this.isDefaultName) {
/* 567 */         resourceName = this.member.getName();
/* 568 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 569 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 572 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 573 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 577 */         resourceType = getResourceType();
/*     */       }
/* 579 */       this.name = resourceName;
/* 580 */       this.elementType = resourceType;
/* 581 */       if (Service.class.isAssignableFrom(resourceType)) {
/* 582 */         this.lookupType = resourceType;
/*     */       }
/*     */       else {
/* 585 */         this.lookupType = (!Object.class.equals(resource.value()) ? resource.value() : Service.class);
/*     */       }
/* 587 */       this.mappedName = resource.mappedName();
/* 588 */       this.wsdlLocation = resource.wsdlLocation();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/*     */       Service service;
/*     */       try {
/* 595 */         service = (Service)CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */       }
/*     */       catch (NoSuchBeanDefinitionException notFound)
/*     */       {
/*     */         Service service;
/* 599 */         if (Service.class.equals(this.lookupType)) {
/* 600 */           throw new IllegalStateException("No resource with name '" + this.name + "' found in context, " + "and no specific JAX-WS Service subclass specified. The typical solution is to either specify " + "a LocalJaxWsServiceFactoryBean with the given name or to specify the (generated) Service " + "subclass as @WebServiceRef(...) value.");
/*     */         }
/*     */ 
/* 605 */         if (StringUtils.hasLength(this.wsdlLocation)) {
/*     */           try {
/* 607 */             Constructor ctor = this.lookupType.getConstructor(new Class[] { URL.class, QName.class });
/* 608 */             WebServiceClient clientAnn = (WebServiceClient)this.lookupType.getAnnotation(WebServiceClient.class);
/* 609 */             if (clientAnn == null) {
/* 610 */               throw new IllegalStateException("JAX-WS Service class [" + this.lookupType.getName() + "] does not carry a WebServiceClient annotation");
/*     */             }
/*     */ 
/* 613 */             service = (Service)BeanUtils.instantiateClass(ctor, new Object[] { new URL(this.wsdlLocation), new QName(clientAnn
/* 614 */               .targetNamespace(), clientAnn.name()) });
/*     */           }
/*     */           catch (NoSuchMethodException ex)
/*     */           {
/*     */             Service service;
/* 617 */             throw new IllegalStateException("JAX-WS Service class [" + this.lookupType.getName() + "] does not have a (URL, QName) constructor. Cannot apply specified WSDL location [" + this.wsdlLocation + "].");
/*     */           }
/*     */           catch (MalformedURLException ex)
/*     */           {
/* 622 */             throw new IllegalArgumentException("Specified WSDL location [" + this.wsdlLocation + "] isn't a valid URL");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 627 */           service = (Service)BeanUtils.instantiateClass(this.lookupType);
/*     */         }
/*     */       }
/* 630 */       return service.getPort(this.elementType);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResourceElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/*     */     public ResourceElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 515 */       super(member, pd);
/* 516 */       AnnotatedElement ae = (AnnotatedElement)member;
/* 517 */       Resource resource = (Resource)ae.getAnnotation(Resource.class);
/* 518 */       String resourceName = resource.name();
/* 519 */       Class resourceType = resource.type();
/* 520 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 521 */       if (this.isDefaultName) {
/* 522 */         resourceName = this.member.getName();
/* 523 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 524 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 527 */       else if ((CommonAnnotationBeanPostProcessor.this.beanFactory instanceof ConfigurableBeanFactory)) {
/* 528 */         resourceName = ((ConfigurableBeanFactory)CommonAnnotationBeanPostProcessor.this.beanFactory).resolveEmbeddedValue(resourceName);
/*     */       }
/* 530 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 531 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 535 */         resourceType = getResourceType();
/*     */       }
/* 537 */       this.name = resourceName;
/* 538 */       this.lookupType = resourceType;
/* 539 */       this.mappedName = resource.mappedName();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/* 544 */       return CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract class LookupElement extends InjectionMetadata.InjectedElement
/*     */   {
/*     */     protected String name;
/* 470 */     protected boolean isDefaultName = false;
/*     */     protected Class<?> lookupType;
/*     */     protected String mappedName;
/*     */ 
/*     */     public LookupElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 477 */       super(pd);
/*     */     }
/*     */ 
/*     */     public final String getName()
/*     */     {
/* 484 */       return this.name;
/*     */     }
/*     */ 
/*     */     public final Class<?> getLookupType()
/*     */     {
/* 491 */       return this.lookupType;
/*     */     }
/*     */ 
/*     */     public final DependencyDescriptor getDependencyDescriptor()
/*     */     {
/* 498 */       if (this.isField) {
/* 499 */         return new CommonAnnotationBeanPostProcessor.LookupDependencyDescriptor((Field)this.member, this.lookupType);
/*     */       }
/*     */ 
/* 502 */       return new CommonAnnotationBeanPostProcessor.LookupDependencyDescriptor((Method)this.member, this.lookupType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.CommonAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.2
 */