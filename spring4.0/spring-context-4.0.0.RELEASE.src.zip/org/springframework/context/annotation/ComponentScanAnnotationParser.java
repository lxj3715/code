/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AbstractTypeHierarchyTraversingFilter;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AspectJTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.RegexPatternTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ComponentScanAnnotationParser
/*     */ {
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final Environment environment;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final BeanNameGenerator beanNameGenerator;
/*     */ 
/*     */   public ComponentScanAnnotationParser(ResourceLoader resourceLoader, Environment environment, BeanNameGenerator beanNameGenerator, BeanDefinitionRegistry registry)
/*     */   {
/*  65 */     this.resourceLoader = resourceLoader;
/*  66 */     this.environment = environment;
/*  67 */     this.beanNameGenerator = beanNameGenerator;
/*  68 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */   public Set<BeanDefinitionHolder> parse(AnnotationAttributes componentScan, final String declaringClass)
/*     */   {
/*  74 */     ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(this.registry, componentScan
/*  74 */       .getBoolean("useDefaultFilters"));
/*     */ 
/*  76 */     Assert.notNull(this.environment, "Environment must not be null");
/*  77 */     scanner.setEnvironment(this.environment);
/*     */ 
/*  79 */     Assert.notNull(this.resourceLoader, "ResourceLoader must not be null");
/*  80 */     scanner.setResourceLoader(this.resourceLoader);
/*     */ 
/*  82 */     Class generatorClass = componentScan.getClass("nameGenerator");
/*  83 */     boolean useInheritedGenerator = BeanNameGenerator.class.equals(generatorClass);
/*  84 */     scanner.setBeanNameGenerator(useInheritedGenerator ? this.beanNameGenerator : 
/*  85 */       (BeanNameGenerator)BeanUtils.instantiateClass(generatorClass));
/*     */ 
/*  87 */     ScopedProxyMode scopedProxyMode = (ScopedProxyMode)componentScan.getEnum("scopedProxy");
/*  88 */     if (scopedProxyMode != ScopedProxyMode.DEFAULT) {
/*  89 */       scanner.setScopedProxyMode(scopedProxyMode);
/*     */     }
/*     */     else {
/*  92 */       resolverClass = componentScan.getClass("scopeResolver");
/*  93 */       scanner.setScopeMetadataResolver((ScopeMetadataResolver)BeanUtils.instantiateClass(resolverClass));
/*     */     }
/*     */ 
/*  96 */     scanner.setResourcePattern(componentScan.getString("resourcePattern"));
/*     */ 
/*  98 */     Class resolverClass = componentScan.getAnnotationArray("includeFilters"); int i = resolverClass.length; for (AnnotationAttributes localAnnotationAttributes1 = 0; localAnnotationAttributes1 < i; localAnnotationAttributes1++) { AnnotationAttributes filter = resolverClass[localAnnotationAttributes1];
/*  99 */       for (TypeFilter typeFilter : typeFiltersFor(filter)) {
/* 100 */         scanner.addIncludeFilter(typeFilter);
/*     */       }
/*     */     }
/* 103 */     resolverClass = componentScan.getAnnotationArray("excludeFilters"); i = resolverClass.length; for (localAnnotationAttributes1 = 0; localAnnotationAttributes1 < i; localAnnotationAttributes1++) { filter = resolverClass[localAnnotationAttributes1];
/* 104 */       for (TypeFilter typeFilter : typeFiltersFor(filter)) {
/* 105 */         scanner.addExcludeFilter(typeFilter);
/*     */       }
/*     */     }
/*     */ 
/* 109 */     List basePackages = new ArrayList();
/* 110 */     Object localObject = componentScan.getStringArray("value"); localAnnotationAttributes1 = localObject.length; for (AnnotationAttributes filter = 0; filter < localAnnotationAttributes1; filter++) { String pkg = localObject[filter];
/* 111 */       if (StringUtils.hasText(pkg)) {
/* 112 */         basePackages.add(pkg);
/*     */       }
/*     */     }
/* 115 */     localObject = componentScan.getStringArray("basePackages"); AnnotationAttributes localAnnotationAttributes2 = localObject.length; for (filter = 0; filter < localAnnotationAttributes2; filter++) { String pkg = localObject[filter];
/* 116 */       if (StringUtils.hasText(pkg)) {
/* 117 */         basePackages.add(pkg);
/*     */       }
/*     */     }
/* 120 */     localObject = componentScan.getClassArray("basePackageClasses"); AnnotationAttributes localAnnotationAttributes3 = localObject.length; for (filter = 0; filter < localAnnotationAttributes3; filter++) { Class clazz = localObject[filter];
/* 121 */       basePackages.add(ClassUtils.getPackageName(clazz));
/*     */     }
/*     */ 
/* 124 */     if (basePackages.isEmpty()) {
/* 125 */       basePackages.add(ClassUtils.getPackageName(declaringClass));
/*     */     }
/*     */ 
/* 128 */     scanner.addExcludeFilter(new AbstractTypeHierarchyTraversingFilter(false, false)
/*     */     {
/*     */       protected boolean matchClassName(String className) {
/* 131 */         return declaringClass.equals(className);
/*     */       }
/*     */     });
/* 134 */     return scanner.doScan(StringUtils.toStringArray(basePackages));
/*     */   }
/*     */ 
/*     */   private List<TypeFilter> typeFiltersFor(AnnotationAttributes filterAttributes) {
/* 138 */     List typeFilters = new ArrayList();
/* 139 */     FilterType filterType = (FilterType)filterAttributes.getEnum("type");
/*     */ 
/* 141 */     for (Class filterClass : filterAttributes.getClassArray("value")) {
/* 142 */       switch (2.$SwitchMap$org$springframework$context$annotation$FilterType[filterType.ordinal()]) {
/*     */       case 1:
/* 144 */         Assert.isAssignable(Annotation.class, filterClass, "An error occured while processing a @ComponentScan ANNOTATION type filter: ");
/*     */ 
/* 147 */         Class annotationType = filterClass;
/* 148 */         typeFilters.add(new AnnotationTypeFilter(annotationType));
/* 149 */         break;
/*     */       case 2:
/* 151 */         typeFilters.add(new AssignableTypeFilter(filterClass));
/* 152 */         break;
/*     */       case 3:
/* 154 */         Assert.isAssignable(TypeFilter.class, filterClass, "An error occured while processing a @ComponentScan CUSTOM type filter: ");
/*     */ 
/* 156 */         typeFilters.add(BeanUtils.instantiateClass(filterClass, TypeFilter.class));
/* 157 */         break;
/*     */       default:
/* 159 */         throw new IllegalArgumentException("Filter type not supported with Class value: " + filterType);
/*     */       }
/*     */     }
/*     */ 
/* 163 */     for (String expression : filterAttributes.getStringArray("pattern")) {
/* 164 */       switch (2.$SwitchMap$org$springframework$context$annotation$FilterType[filterType.ordinal()]) {
/*     */       case 4:
/* 166 */         typeFilters.add(new AspectJTypeFilter(expression, this.resourceLoader.getClassLoader()));
/* 167 */         break;
/*     */       case 5:
/* 169 */         typeFilters.add(new RegexPatternTypeFilter(Pattern.compile(expression)));
/* 170 */         break;
/*     */       default:
/* 172 */         throw new IllegalArgumentException("Filter type not supported with String pattern: " + filterType);
/*     */       }
/*     */     }
/*     */ 
/* 176 */     return typeFilters;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ComponentScanAnnotationParser
 * JD-Core Version:    0.6.2
 */