package org.springframework.context.annotation;

import org.springframework.core.type.AnnotatedTypeMetadata;

public abstract interface Condition
{
  public abstract boolean matches(ConditionContext paramConditionContext, AnnotatedTypeMetadata paramAnnotatedTypeMetadata);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.Condition
 * JD-Core Version:    0.6.2
 */