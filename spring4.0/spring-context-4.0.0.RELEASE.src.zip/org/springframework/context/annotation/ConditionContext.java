package org.springframework.context.annotation;

import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;

public abstract interface ConditionContext
{
  public abstract BeanDefinitionRegistry getRegistry();

  public abstract ConfigurableListableBeanFactory getBeanFactory();

  public abstract Environment getEnvironment();

  public abstract ResourceLoader getResourceLoader();

  public abstract ClassLoader getClassLoader();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConditionContext
 * JD-Core Version:    0.6.2
 */