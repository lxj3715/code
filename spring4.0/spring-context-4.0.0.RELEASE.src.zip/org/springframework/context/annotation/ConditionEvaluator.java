/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ class ConditionEvaluator
/*     */ {
/*     */   private final ConditionContextImpl context;
/*     */ 
/*     */   public ConditionEvaluator(BeanDefinitionRegistry registry, Environment environment, ResourceLoader resourceLoader)
/*     */   {
/*  50 */     this.context = new ConditionContextImpl(registry, environment, resourceLoader);
/*     */   }
/*     */ 
/*     */   public boolean shouldSkip(AnnotatedTypeMetadata metadata)
/*     */   {
/*  62 */     return shouldSkip(metadata, null);
/*     */   }
/*     */ 
/*     */   public boolean shouldSkip(AnnotatedTypeMetadata metadata, ConfigurationCondition.ConfigurationPhase phase)
/*     */   {
/*  72 */     if ((metadata == null) || (!metadata.isAnnotated(Conditional.class.getName()))) {
/*  73 */       return false;
/*     */     }
/*     */ 
/*  76 */     if (phase == null) {
/*  77 */       if (((metadata instanceof AnnotationMetadata)) && 
/*  78 */         (ConfigurationClassUtils.isConfigurationCandidate((AnnotationMetadata)metadata)))
/*     */       {
/*  79 */         return shouldSkip(metadata, ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION);
/*     */       }
/*  81 */       return shouldSkip(metadata, ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     }
/*     */ 
/*  84 */     for (String[] conditionClasses : getConditionClasses(metadata)) {
/*  85 */       for (String conditionClass : conditionClasses) {
/*  86 */         Condition condition = getCondition(conditionClass, this.context.getClassLoader());
/*  87 */         ConfigurationCondition.ConfigurationPhase requiredPhase = null;
/*  88 */         if ((condition instanceof ConfigurationCondition)) {
/*  89 */           requiredPhase = ((ConfigurationCondition)condition).getConfigurationPhase();
/*     */         }
/*  91 */         if (((requiredPhase == null) || (requiredPhase == phase)) && 
/*  92 */           (!condition.matches(this.context, metadata))) {
/*  93 */           return true;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */   private List<String[]> getConditionClasses(AnnotatedTypeMetadata metadata)
/*     */   {
/* 104 */     MultiValueMap attributes = metadata.getAllAnnotationAttributes(Conditional.class.getName(), true);
/* 105 */     Object values = attributes != null ? (List)attributes.get("value") : null;
/* 106 */     return (List)(values != null ? values : Collections.emptyList());
/*     */   }
/*     */ 
/*     */   private Condition getCondition(String conditionClassName, ClassLoader classloader) {
/* 110 */     Class conditionClass = ClassUtils.resolveClassName(conditionClassName, classloader);
/* 111 */     return (Condition)BeanUtils.instantiateClass(conditionClass);
/*     */   }
/*     */ 
/*     */   private static class ConditionContextImpl
/*     */     implements ConditionContext
/*     */   {
/*     */     private final BeanDefinitionRegistry registry;
/*     */     private final ConfigurableListableBeanFactory beanFactory;
/*     */     private final Environment environment;
/*     */     private final ResourceLoader resourceLoader;
/*     */ 
/*     */     public ConditionContextImpl(BeanDefinitionRegistry registry, Environment environment, ResourceLoader resourceLoader)
/*     */     {
/* 129 */       this.registry = registry;
/* 130 */       this.beanFactory = deduceBeanFactory(registry);
/* 131 */       this.environment = (environment != null ? environment : deduceEnvironment(registry));
/* 132 */       this.resourceLoader = (resourceLoader != null ? resourceLoader : deduceResourceLoader(registry));
/*     */     }
/*     */ 
/*     */     private ConfigurableListableBeanFactory deduceBeanFactory(BeanDefinitionRegistry source) {
/* 136 */       if ((source instanceof ConfigurableListableBeanFactory)) {
/* 137 */         return (ConfigurableListableBeanFactory)source;
/*     */       }
/* 139 */       if ((source instanceof ConfigurableApplicationContext)) {
/* 140 */         return ((ConfigurableApplicationContext)source).getBeanFactory();
/*     */       }
/* 142 */       return null;
/*     */     }
/*     */ 
/*     */     private Environment deduceEnvironment(BeanDefinitionRegistry source) {
/* 146 */       if ((source instanceof EnvironmentCapable)) {
/* 147 */         return ((EnvironmentCapable)source).getEnvironment();
/*     */       }
/* 149 */       return null;
/*     */     }
/*     */ 
/*     */     private ResourceLoader deduceResourceLoader(BeanDefinitionRegistry source) {
/* 153 */       if ((source instanceof ResourceLoader)) {
/* 154 */         return (ResourceLoader)source;
/*     */       }
/* 156 */       return null;
/*     */     }
/*     */ 
/*     */     public BeanDefinitionRegistry getRegistry()
/*     */     {
/* 161 */       return this.registry;
/*     */     }
/*     */ 
/*     */     public ConfigurableListableBeanFactory getBeanFactory()
/*     */     {
/* 166 */       return this.beanFactory;
/*     */     }
/*     */ 
/*     */     public Environment getEnvironment()
/*     */     {
/* 171 */       return this.environment;
/*     */     }
/*     */ 
/*     */     public ResourceLoader getResourceLoader()
/*     */     {
/* 176 */       return this.resourceLoader;
/*     */     }
/*     */ 
/*     */     public ClassLoader getClassLoader()
/*     */     {
/* 181 */       if (this.resourceLoader != null) {
/* 182 */         return this.resourceLoader.getClassLoader();
/*     */       }
/* 184 */       if (this.beanFactory != null) {
/* 185 */         return this.beanFactory.getBeanClassLoader();
/*     */       }
/* 187 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConditionEvaluator
 * JD-Core Version:    0.6.2
 */