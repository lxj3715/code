/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.core.io.DescriptiveResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ final class ConfigurationClass
/*     */ {
/*     */   private final AnnotationMetadata metadata;
/*     */   private final Resource resource;
/*     */   private String beanName;
/*     */   private final ConfigurationClass importedBy;
/*  59 */   private final Set<BeanMethod> beanMethods = new LinkedHashSet();
/*     */ 
/*  61 */   private final Map<String, Class<? extends BeanDefinitionReader>> importedResources = new LinkedHashMap();
/*     */ 
/*  64 */   private final Map<ImportBeanDefinitionRegistrar, AnnotationMetadata> importBeanDefinitionRegistrars = new LinkedHashMap();
/*     */ 
/*     */   public ConfigurationClass(MetadataReader metadataReader, String beanName)
/*     */   {
/*  76 */     Assert.hasText(beanName, "bean name must not be null");
/*  77 */     this.metadata = metadataReader.getAnnotationMetadata();
/*  78 */     this.resource = metadataReader.getResource();
/*  79 */     this.beanName = beanName;
/*  80 */     this.importedBy = null;
/*     */   }
/*     */ 
/*     */   public ConfigurationClass(MetadataReader metadataReader, ConfigurationClass importedBy)
/*     */   {
/*  92 */     this.metadata = metadataReader.getAnnotationMetadata();
/*  93 */     this.resource = metadataReader.getResource();
/*  94 */     this.importedBy = importedBy;
/*     */   }
/*     */ 
/*     */   public ConfigurationClass(Class<?> clazz, String beanName)
/*     */   {
/* 105 */     Assert.hasText(beanName, "Bean name must not be null");
/* 106 */     this.metadata = new StandardAnnotationMetadata(clazz, true);
/* 107 */     this.resource = new DescriptiveResource(clazz.toString());
/* 108 */     this.beanName = beanName;
/* 109 */     this.importedBy = null;
/*     */   }
/*     */ 
/*     */   public ConfigurationClass(Class<?> clazz, ConfigurationClass importedBy)
/*     */   {
/* 121 */     this.metadata = new StandardAnnotationMetadata(clazz, true);
/* 122 */     this.resource = new DescriptiveResource(clazz.toString());
/* 123 */     this.importedBy = importedBy;
/*     */   }
/*     */ 
/*     */   public AnnotationMetadata getMetadata()
/*     */   {
/* 128 */     return this.metadata;
/*     */   }
/*     */ 
/*     */   public Resource getResource() {
/* 132 */     return this.resource;
/*     */   }
/*     */ 
/*     */   public String getSimpleName() {
/* 136 */     return ClassUtils.getShortName(getMetadata().getClassName());
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 140 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public String getBeanName() {
/* 144 */     return this.beanName;
/*     */   }
/*     */ 
/*     */   public boolean isImported()
/*     */   {
/* 154 */     return this.importedBy != null;
/*     */   }
/*     */ 
/*     */   public ConfigurationClass getImportedBy()
/*     */   {
/* 164 */     return this.importedBy;
/*     */   }
/*     */ 
/*     */   public void addBeanMethod(BeanMethod method) {
/* 168 */     this.beanMethods.add(method);
/*     */   }
/*     */ 
/*     */   public Set<BeanMethod> getBeanMethods() {
/* 172 */     return this.beanMethods;
/*     */   }
/*     */ 
/*     */   public void addImportedResource(String importedResource, Class<? extends BeanDefinitionReader> readerClass) {
/* 176 */     this.importedResources.put(importedResource, readerClass);
/*     */   }
/*     */ 
/*     */   public void addImportBeanDefinitionRegistrar(ImportBeanDefinitionRegistrar registrar, AnnotationMetadata importingClassMetadata) {
/* 180 */     this.importBeanDefinitionRegistrars.put(registrar, importingClassMetadata);
/*     */   }
/*     */ 
/*     */   public Map<ImportBeanDefinitionRegistrar, AnnotationMetadata> getImportBeanDefinitionRegistrars() {
/* 184 */     return this.importBeanDefinitionRegistrars;
/*     */   }
/*     */ 
/*     */   public Map<String, Class<? extends BeanDefinitionReader>> getImportedResources() {
/* 188 */     return this.importedResources;
/*     */   }
/*     */ 
/*     */   public void validate(ProblemReporter problemReporter)
/*     */   {
/* 193 */     if ((getMetadata().isAnnotated(Configuration.class.getName())) && 
/* 194 */       (getMetadata().isFinal())) {
/* 195 */       problemReporter.error(new FinalConfigurationProblem());
/*     */     }
/*     */ 
/* 199 */     for (BeanMethod beanMethod : this.beanMethods)
/* 200 */       beanMethod.validate(problemReporter);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 207 */     return (this == other) || (((other instanceof ConfigurationClass)) && 
/* 207 */       (getMetadata().getClassName().equals(((ConfigurationClass)other).getMetadata().getClassName())));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 212 */     return getMetadata().getClassName().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 217 */     return "ConfigurationClass:beanName=" + this.beanName + ",resource=" + this.resource;
/*     */   }
/*     */ 
/*     */   private class FinalConfigurationProblem extends Problem
/*     */   {
/*     */     public FinalConfigurationProblem()
/*     */     {
/* 227 */       super(new Location(ConfigurationClass.this
/* 228 */         .getResource(), ConfigurationClass.this.getMetadata()));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClass
 * JD-Core Version:    0.6.2
 */