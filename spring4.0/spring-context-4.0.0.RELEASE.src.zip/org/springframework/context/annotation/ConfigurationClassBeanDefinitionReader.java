/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.Autowire;
/*     */ import org.springframework.beans.factory.annotation.RequiredAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ConfigurationClassBeanDefinitionReader
/*     */ {
/*  71 */   private static final Log logger = LogFactory.getLog(ConfigurationClassBeanDefinitionReader.class);
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final SourceExtractor sourceExtractor;
/*     */   private final ProblemReporter problemReporter;
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final Environment environment;
/*     */   private final BeanNameGenerator importBeanNameGenerator;
/*     */   private final ConditionEvaluator conditionEvaluator;
/*     */ 
/*     */   public ConfigurationClassBeanDefinitionReader(BeanDefinitionRegistry registry, SourceExtractor sourceExtractor, ProblemReporter problemReporter, MetadataReaderFactory metadataReaderFactory, ResourceLoader resourceLoader, Environment environment, BeanNameGenerator importBeanNameGenerator)
/*     */   {
/*  98 */     this.registry = registry;
/*  99 */     this.sourceExtractor = sourceExtractor;
/* 100 */     this.problemReporter = problemReporter;
/* 101 */     this.metadataReaderFactory = metadataReaderFactory;
/* 102 */     this.resourceLoader = resourceLoader;
/* 103 */     this.environment = environment;
/* 104 */     this.importBeanNameGenerator = importBeanNameGenerator;
/* 105 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, resourceLoader);
/*     */   }
/*     */ 
/*     */   public void loadBeanDefinitions(Set<ConfigurationClass> configurationModel)
/*     */   {
/* 114 */     TrackedConditionEvaluator trackedConditionEvaluator = new TrackedConditionEvaluator(null);
/* 115 */     for (ConfigurationClass configClass : configurationModel)
/* 116 */       loadBeanDefinitionsForConfigurationClass(configClass, trackedConditionEvaluator);
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsForConfigurationClass(ConfigurationClass configClass, TrackedConditionEvaluator trackedConditionEvaluator)
/*     */   {
/* 127 */     if (trackedConditionEvaluator.shouldSkip(configClass)) {
/* 128 */       removeBeanDefinition(configClass);
/* 129 */       return;
/*     */     }
/*     */ 
/* 132 */     if (configClass.isImported()) {
/* 133 */       registerBeanDefinitionForImportedConfigurationClass(configClass);
/*     */     }
/* 135 */     for (BeanMethod beanMethod : configClass.getBeanMethods()) {
/* 136 */       loadBeanDefinitionsForBeanMethod(beanMethod);
/*     */     }
/* 138 */     loadBeanDefinitionsFromImportedResources(configClass.getImportedResources());
/* 139 */     loadBeanDefinitionsFromRegistrars(configClass.getImportBeanDefinitionRegistrars());
/*     */   }
/*     */ 
/*     */   private void removeBeanDefinition(ConfigurationClass configClass) {
/* 143 */     String beanName = configClass.getBeanName();
/* 144 */     if ((StringUtils.hasLength(beanName)) && (this.registry.containsBeanDefinition(beanName)))
/* 145 */       this.registry.removeBeanDefinition(beanName);
/*     */   }
/*     */ 
/*     */   private void registerBeanDefinitionForImportedConfigurationClass(ConfigurationClass configClass)
/*     */   {
/* 153 */     AnnotationMetadata metadata = configClass.getMetadata();
/* 154 */     BeanDefinition configBeanDef = new AnnotatedGenericBeanDefinition(metadata);
/* 155 */     if (ConfigurationClassUtils.checkConfigurationClassCandidate(configBeanDef, this.metadataReaderFactory)) {
/* 156 */       String configBeanName = this.importBeanNameGenerator.generateBeanName(configBeanDef, this.registry);
/* 157 */       this.registry.registerBeanDefinition(configBeanName, configBeanDef);
/* 158 */       configClass.setBeanName(configBeanName);
/* 159 */       if (logger.isDebugEnabled())
/* 160 */         logger.debug(String.format("Registered bean definition for imported @Configuration class %s", new Object[] { configBeanName }));
/*     */     }
/*     */     else
/*     */     {
/* 164 */       this.problemReporter.error(new InvalidConfigurationImportProblem(metadata
/* 165 */         .getClassName(), configClass.getResource(), metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsForBeanMethod(BeanMethod beanMethod)
/*     */   {
/* 174 */     if (this.conditionEvaluator.shouldSkip(beanMethod.getMetadata(), ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN)) {
/* 175 */       return;
/*     */     }
/*     */ 
/* 178 */     ConfigurationClass configClass = beanMethod.getConfigurationClass();
/* 179 */     MethodMetadata metadata = beanMethod.getMetadata();
/*     */ 
/* 181 */     ConfigurationClassBeanDefinition beanDef = new ConfigurationClassBeanDefinition(configClass);
/* 182 */     beanDef.setResource(configClass.getResource());
/* 183 */     beanDef.setSource(this.sourceExtractor.extractSource(metadata, configClass.getResource()));
/* 184 */     if (metadata.isStatic())
/*     */     {
/* 186 */       beanDef.setBeanClassName(configClass.getMetadata().getClassName());
/* 187 */       beanDef.setFactoryMethodName(metadata.getMethodName());
/*     */     }
/*     */     else
/*     */     {
/* 191 */       beanDef.setFactoryBeanName(configClass.getBeanName());
/* 192 */       beanDef.setUniqueFactoryMethodName(metadata.getMethodName());
/*     */     }
/* 194 */     beanDef.setAutowireMode(3);
/* 195 */     beanDef.setAttribute(RequiredAnnotationBeanPostProcessor.SKIP_REQUIRED_CHECK_ATTRIBUTE, Boolean.TRUE);
/*     */ 
/* 198 */     AnnotationAttributes bean = AnnotationConfigUtils.attributesFor(metadata, Bean.class);
/* 199 */     List names = new ArrayList(Arrays.asList(bean.getStringArray("name")));
/* 200 */     String beanName = names.size() > 0 ? (String)names.remove(0) : beanMethod.getMetadata().getMethodName();
/* 201 */     for (String alias : names) {
/* 202 */       this.registry.registerAlias(beanName, alias);
/*     */     }
/*     */ 
/* 206 */     if (isOverriddenByExistingDefinition(beanMethod, beanName)) {
/* 207 */       return;
/*     */     }
/*     */ 
/* 210 */     AnnotationConfigUtils.processCommonDefinitionAnnotations(beanDef, metadata);
/*     */ 
/* 212 */     Autowire autowire = (Autowire)bean.getEnum("autowire");
/* 213 */     if (autowire.isAutowire()) {
/* 214 */       beanDef.setAutowireMode(autowire.value());
/*     */     }
/*     */ 
/* 217 */     String initMethodName = bean.getString("initMethod");
/* 218 */     if (StringUtils.hasText(initMethodName)) {
/* 219 */       beanDef.setInitMethodName(initMethodName);
/*     */     }
/*     */ 
/* 222 */     String destroyMethodName = bean.getString("destroyMethod");
/* 223 */     if (StringUtils.hasText(destroyMethodName)) {
/* 224 */       beanDef.setDestroyMethodName(destroyMethodName);
/*     */     }
/*     */ 
/* 228 */     ScopedProxyMode proxyMode = ScopedProxyMode.NO;
/* 229 */     AnnotationAttributes scope = AnnotationConfigUtils.attributesFor(metadata, Scope.class);
/* 230 */     if (scope != null) {
/* 231 */       beanDef.setScope(scope.getString("value"));
/* 232 */       proxyMode = (ScopedProxyMode)scope.getEnum("proxyMode");
/* 233 */       if (proxyMode == ScopedProxyMode.DEFAULT) {
/* 234 */         proxyMode = ScopedProxyMode.NO;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 239 */     BeanDefinition beanDefToRegister = beanDef;
/* 240 */     if (proxyMode != ScopedProxyMode.NO) {
/* 241 */       BeanDefinitionHolder proxyDef = ScopedProxyCreator.createScopedProxy(new BeanDefinitionHolder(beanDef, beanName), this.registry, proxyMode == ScopedProxyMode.TARGET_CLASS);
/*     */ 
/* 244 */       beanDefToRegister = new ConfigurationClassBeanDefinition(
/* 244 */         (RootBeanDefinition)proxyDef
/* 244 */         .getBeanDefinition(), configClass);
/*     */     }
/*     */ 
/* 247 */     if (logger.isDebugEnabled()) {
/* 248 */       logger.debug(String.format("Registering bean definition for @Bean method %s.%s()", new Object[] { configClass
/* 249 */         .getMetadata().getClassName(), beanName }));
/*     */     }
/*     */ 
/* 252 */     this.registry.registerBeanDefinition(beanName, beanDefToRegister);
/*     */   }
/*     */ 
/*     */   protected boolean isOverriddenByExistingDefinition(BeanMethod beanMethod, String beanName) {
/* 256 */     if (!this.registry.containsBeanDefinition(beanName)) {
/* 257 */       return false;
/*     */     }
/* 259 */     BeanDefinition existingBeanDef = this.registry.getBeanDefinition(beanName);
/*     */ 
/* 265 */     if ((existingBeanDef instanceof ConfigurationClassBeanDefinition)) {
/* 266 */       ConfigurationClassBeanDefinition ccbd = (ConfigurationClassBeanDefinition)existingBeanDef;
/* 267 */       return ccbd.getMetadata().getClassName().equals(beanMethod.getConfigurationClass().getMetadata().getClassName());
/*     */     }
/*     */ 
/* 272 */     if (existingBeanDef.getRole() > 0) {
/* 273 */       return false;
/*     */     }
/*     */ 
/* 278 */     if (logger.isInfoEnabled()) {
/* 279 */       logger.info(String.format("Skipping bean definition for %s: a definition for bean '%s' already exists. This top-level bean definition is considered as an override.", new Object[] { beanMethod, beanName }));
/*     */     }
/*     */ 
/* 283 */     return true;
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsFromImportedResources(Map<String, Class<? extends BeanDefinitionReader>> importedResources)
/*     */   {
/* 289 */     Map readerInstanceCache = new HashMap();
/* 290 */     for (Map.Entry entry : importedResources.entrySet()) {
/* 291 */       String resource = (String)entry.getKey();
/* 292 */       Class readerClass = (Class)entry.getValue();
/* 293 */       if (!readerInstanceCache.containsKey(readerClass))
/*     */       {
/*     */         try
/*     */         {
/* 297 */           BeanDefinitionReader readerInstance = (BeanDefinitionReader)readerClass
/* 297 */             .getConstructor(new Class[] { BeanDefinitionRegistry.class })
/* 297 */             .newInstance(new Object[] { this.registry });
/*     */ 
/* 299 */           if ((readerInstance instanceof AbstractBeanDefinitionReader)) {
/* 300 */             AbstractBeanDefinitionReader abdr = (AbstractBeanDefinitionReader)readerInstance;
/* 301 */             abdr.setResourceLoader(this.resourceLoader);
/* 302 */             abdr.setEnvironment(this.environment);
/*     */           }
/* 304 */           readerInstanceCache.put(readerClass, readerInstance);
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 308 */           throw new IllegalStateException("Could not instantiate BeanDefinitionReader class [" + readerClass
/* 308 */             .getName() + "]");
/*     */         }
/*     */       }
/* 311 */       BeanDefinitionReader reader = (BeanDefinitionReader)readerInstanceCache.get(readerClass);
/*     */ 
/* 313 */       reader.loadBeanDefinitions(resource);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsFromRegistrars(Map<ImportBeanDefinitionRegistrar, AnnotationMetadata> registrars) {
/* 318 */     for (Map.Entry entry : registrars.entrySet())
/* 319 */       ((ImportBeanDefinitionRegistrar)entry.getKey()).registerBeanDefinitions((AnnotationMetadata)entry.getValue(), this.registry);
/*     */   }
/*     */ 
/*     */   private class TrackedConditionEvaluator
/*     */   {
/* 388 */     private final Map<ConfigurationClass, Boolean> skipped = new HashMap();
/*     */ 
/*     */     private TrackedConditionEvaluator() {  } 
/* 391 */     public boolean shouldSkip(ConfigurationClass configClass) { Boolean skip = (Boolean)this.skipped.get(configClass);
/* 392 */       if (skip == null) {
/* 393 */         if ((configClass.isImported()) && 
/* 394 */           (shouldSkip(configClass.getImportedBy())))
/*     */         {
/* 396 */           skip = Boolean.valueOf(true);
/*     */         }
/*     */ 
/* 399 */         if (skip == null) {
/* 400 */           skip = Boolean.valueOf(ConfigurationClassBeanDefinitionReader.this.conditionEvaluator.shouldSkip(configClass.getMetadata(), ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN));
/*     */         }
/*     */ 
/* 403 */         this.skipped.put(configClass, skip);
/*     */       }
/* 405 */       return skip.booleanValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InvalidConfigurationImportProblem extends Problem
/*     */   {
/*     */     public InvalidConfigurationImportProblem(String className, Resource resource, AnnotationMetadata metadata)
/*     */     {
/* 374 */       super(new Location(resource, metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConfigurationClassBeanDefinition extends RootBeanDefinition
/*     */     implements AnnotatedBeanDefinition
/*     */   {
/*     */     private final AnnotationMetadata annotationMetadata;
/*     */ 
/*     */     public ConfigurationClassBeanDefinition(ConfigurationClass configClass)
/*     */     {
/* 336 */       this.annotationMetadata = configClass.getMetadata();
/* 337 */       setLenientConstructorResolution(false);
/*     */     }
/*     */ 
/*     */     public ConfigurationClassBeanDefinition(RootBeanDefinition original, ConfigurationClass configClass) {
/* 341 */       super();
/* 342 */       this.annotationMetadata = configClass.getMetadata();
/*     */     }
/*     */ 
/*     */     private ConfigurationClassBeanDefinition(ConfigurationClassBeanDefinition original) {
/* 346 */       super();
/* 347 */       this.annotationMetadata = original.annotationMetadata;
/*     */     }
/*     */ 
/*     */     public AnnotationMetadata getMetadata()
/*     */     {
/* 352 */       return this.annotationMetadata;
/*     */     }
/*     */ 
/*     */     public boolean isFactoryMethod(Method candidate)
/*     */     {
/* 357 */       return (super.isFactoryMethod(candidate)) && (BeanAnnotationHelper.isBeanAnnotated(candidate));
/*     */     }
/*     */ 
/*     */     public ConfigurationClassBeanDefinition cloneBeanDefinition()
/*     */     {
/* 362 */       return new ConfigurationClassBeanDefinition(this);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassBeanDefinitionReader
 * JD-Core Version:    0.6.2
 */