/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.scope.ScopedProxyFactoryBean;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.SimpleInstantiationStrategy;
/*     */ import org.springframework.cglib.core.ClassGenerator;
/*     */ import org.springframework.cglib.core.DefaultGeneratorStrategy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.cglib.transform.ClassEmitterTransformer;
/*     */ import org.springframework.cglib.transform.TransformingClassGenerator;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ class ConfigurationClassEnhancer
/*     */ {
/*  61 */   private static final Callback[] CALLBACKS = { new BeanMethodInterceptor(null), new DisposableBeanMethodInterceptor(null), new BeanFactoryAwareMethodInterceptor(null), NoOp.INSTANCE };
/*     */ 
/*  68 */   private static final ConditionalCallbackFilter CALLBACK_FILTER = new ConditionalCallbackFilter(CALLBACKS);
/*     */   private static final String BEAN_FACTORY_FIELD = "$$beanFactory";
/*  72 */   private static final Log logger = LogFactory.getLog(ConfigurationClassEnhancer.class);
/*     */ 
/*     */   public Class<?> enhance(Class<?> configClass)
/*     */   {
/*  81 */     if (EnhancedConfiguration.class.isAssignableFrom(configClass)) {
/*  82 */       if (logger.isDebugEnabled()) {
/*  83 */         logger.debug(String.format("Ignoring request to enhance %s as it has already been enhanced. This usually indicates that more than one ConfigurationClassPostProcessor has been registered (e.g. via <context:annotation-config>). This is harmless, but you may want check your configuration and remove one CCPP if possible", new Object[] { configClass
/*  88 */           .getName() }));
/*     */       }
/*  90 */       return configClass;
/*     */     }
/*  92 */     Class enhancedClass = createClass(newEnhancer(configClass));
/*  93 */     if (logger.isDebugEnabled()) {
/*  94 */       logger.debug(String.format("Successfully enhanced %s; enhanced class name is: %s", new Object[] { configClass
/*  95 */         .getName(), enhancedClass.getName() }));
/*     */     }
/*  97 */     return enhancedClass;
/*     */   }
/*     */ 
/*     */   private Enhancer newEnhancer(Class<?> superclass)
/*     */   {
/* 104 */     Enhancer enhancer = new Enhancer();
/* 105 */     enhancer.setSuperclass(superclass);
/* 106 */     enhancer.setInterfaces(new Class[] { EnhancedConfiguration.class });
/* 107 */     enhancer.setUseFactory(false);
/* 108 */     enhancer.setCallbackFilter(CALLBACK_FILTER);
/* 109 */     enhancer.setCallbackTypes(CALLBACK_FILTER.getCallbackTypes());
/* 110 */     enhancer.setStrategy(new DefaultGeneratorStrategy()
/*     */     {
/*     */       protected ClassGenerator transform(ClassGenerator cg) throws Exception {
/* 113 */         ClassEmitterTransformer transformer = new ClassEmitterTransformer()
/*     */         {
/*     */           public void end_class() {
/* 116 */             declare_field(1, "$$beanFactory", 
/* 117 */               Type.getType(BeanFactory.class), 
/* 117 */               null);
/* 118 */             super.end_class();
/*     */           }
/*     */         };
/* 121 */         return new TransformingClassGenerator(cg, transformer);
/*     */       }
/*     */     });
/* 124 */     return enhancer;
/*     */   }
/*     */ 
/*     */   private Class<?> createClass(Enhancer enhancer)
/*     */   {
/* 132 */     Class subclass = enhancer.createClass();
/*     */ 
/* 135 */     Enhancer.registerStaticCallbacks(subclass, CALLBACKS);
/* 136 */     return subclass;
/*     */   }
/*     */ 
/*     */   private static class BeanMethodInterceptor
/*     */     implements MethodInterceptor, ConfigurationClassEnhancer.ConditionalCallback
/*     */   {
/*     */     public Object intercept(Object enhancedConfigInstance, Method beanMethod, Object[] beanMethodArgs, MethodProxy cglibMethodProxy)
/*     */       throws Throwable
/*     */     {
/* 281 */       ConfigurableBeanFactory beanFactory = getBeanFactory(enhancedConfigInstance);
/* 282 */       String beanName = BeanAnnotationHelper.determineBeanNameFor(beanMethod);
/*     */ 
/* 285 */       Scope scope = (Scope)AnnotationUtils.findAnnotation(beanMethod, Scope.class);
/* 286 */       if ((scope != null) && (scope.proxyMode() != ScopedProxyMode.NO)) {
/* 287 */         String scopedBeanName = ScopedProxyCreator.getTargetBeanName(beanName);
/* 288 */         if (beanFactory.isCurrentlyInCreation(scopedBeanName)) {
/* 289 */           beanName = scopedBeanName;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 300 */       if ((factoryContainsBean(beanFactory, "&" + beanName)) && 
/* 301 */         (factoryContainsBean(beanFactory, beanName)))
/*     */       {
/* 302 */         Object factoryBean = beanFactory.getBean("&" + beanName);
/* 303 */         if (!(factoryBean instanceof ScopedProxyFactoryBean))
/*     */         {
/* 309 */           return enhanceFactoryBean(factoryBean.getClass(), beanFactory, beanName);
/*     */         }
/*     */       }
/*     */ 
/* 313 */       if ((isCurrentlyInvokedFactoryMethod(beanMethod)) && (!beanFactory.containsSingleton(beanName)))
/*     */       {
/* 317 */         if (BeanFactoryPostProcessor.class.isAssignableFrom(beanMethod.getReturnType())) {
/* 318 */           ConfigurationClassEnhancer.logger.warn(String.format("@Bean method %s.%s is non-static and returns an object assignable to Spring's BeanFactoryPostProcessor interface. This will result in a failure to process annotations such as @Autowired, @Resource and @PostConstruct within the method's declaring @Configuration class. Add the 'static' modifier to this method to avoid these container lifecycle issues; see @Bean Javadoc for complete details", new Object[] { beanMethod
/* 324 */             .getDeclaringClass().getSimpleName(), beanMethod.getName() }));
/*     */         }
/* 326 */         return cglibMethodProxy.invokeSuper(enhancedConfigInstance, beanMethodArgs);
/*     */       }
/*     */ 
/* 333 */       boolean alreadyInCreation = beanFactory.isCurrentlyInCreation(beanName);
/*     */       try {
/* 335 */         if (alreadyInCreation) {
/* 336 */           beanFactory.setCurrentlyInCreation(beanName, false);
/*     */         }
/* 338 */         return beanFactory.getBean(beanName);
/*     */       }
/*     */       finally {
/* 341 */         if (alreadyInCreation)
/* 342 */           beanFactory.setCurrentlyInCreation(beanName, true);
/*     */       }
/*     */     }
/*     */ 
/*     */     private boolean factoryContainsBean(ConfigurableBeanFactory beanFactory, String beanName)
/*     */     {
/* 362 */       return (beanFactory.containsBean(beanName)) && (!beanFactory.isCurrentlyInCreation(beanName));
/*     */     }
/*     */ 
/*     */     private boolean isCurrentlyInvokedFactoryMethod(Method method)
/*     */     {
/* 372 */       Method currentlyInvoked = SimpleInstantiationStrategy.getCurrentlyInvokedFactoryMethod();
/*     */ 
/* 374 */       return (currentlyInvoked != null) && (method.getName().equals(currentlyInvoked.getName())) && 
/* 374 */         (Arrays.equals(method
/* 374 */         .getParameterTypes(), currentlyInvoked.getParameterTypes()));
/*     */     }
/*     */ 
/*     */     private Object enhanceFactoryBean(Class<?> fbClass, final ConfigurableBeanFactory beanFactory, final String beanName)
/*     */       throws InstantiationException, IllegalAccessException
/*     */     {
/* 387 */       Enhancer enhancer = new Enhancer();
/* 388 */       enhancer.setSuperclass(fbClass);
/* 389 */       enhancer.setUseFactory(false);
/* 390 */       enhancer.setCallback(new MethodInterceptor()
/*     */       {
/*     */         public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
/* 393 */           if ((method.getName().equals("getObject")) && (args.length == 0)) {
/* 394 */             return beanFactory.getBean(beanName);
/*     */           }
/* 396 */           return proxy.invokeSuper(obj, args);
/*     */         }
/*     */       });
/* 399 */       return enhancer.create();
/*     */     }
/*     */ 
/*     */     private ConfigurableBeanFactory getBeanFactory(Object enhancedConfigInstance) {
/* 403 */       Field field = ReflectionUtils.findField(enhancedConfigInstance.getClass(), "$$beanFactory");
/* 404 */       Assert.state(field != null, "Unable to find generated bean factory field");
/* 405 */       Object beanFactory = ReflectionUtils.getField(field, enhancedConfigInstance);
/* 406 */       Assert.state(beanFactory != null, "BeanFactory has not been injected into @Configuration class");
/* 407 */       Assert.state(beanFactory instanceof ConfigurableBeanFactory, "Injected BeanFactory is not a ConfigurableBeanFactory");
/* 408 */       return (ConfigurableBeanFactory)beanFactory;
/*     */     }
/*     */ 
/*     */     public boolean isMatch(Method candidateMethod)
/*     */     {
/* 413 */       return BeanAnnotationHelper.isBeanAnnotated(candidateMethod);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BeanFactoryAwareMethodInterceptor
/*     */     implements MethodInterceptor, ConfigurationClassEnhancer.ConditionalCallback
/*     */   {
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy)
/*     */       throws Throwable
/*     */     {
/* 240 */       Field field = obj.getClass().getDeclaredField("$$beanFactory");
/* 241 */       Assert.state(field != null, "Unable to find generated BeanFactory field");
/* 242 */       field.set(obj, args[0]);
/*     */ 
/* 246 */       if (BeanFactoryAware.class.isAssignableFrom(obj.getClass().getSuperclass())) {
/* 247 */         return proxy.invokeSuper(obj, args);
/*     */       }
/* 249 */       return null;
/*     */     }
/*     */ 
/*     */     public boolean isMatch(Method candidateMethod)
/*     */     {
/* 257 */       return (candidateMethod.getName().equals("setBeanFactory")) && 
/* 255 */         (candidateMethod
/* 255 */         .getParameterTypes().length == 1) && 
/* 256 */         (candidateMethod
/* 256 */         .getParameterTypes()[0].equals(BeanFactory.class)) && 
/* 257 */         (BeanFactoryAware.class
/* 257 */         .isAssignableFrom(candidateMethod
/* 257 */         .getDeclaringClass()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DisposableBeanMethodInterceptor
/*     */     implements MethodInterceptor, ConfigurationClassEnhancer.ConditionalCallback
/*     */   {
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy)
/*     */       throws Throwable
/*     */     {
/* 212 */       Enhancer.registerStaticCallbacks(obj.getClass(), null);
/*     */ 
/* 215 */       if (DisposableBean.class.isAssignableFrom(obj.getClass().getSuperclass())) {
/* 216 */         return proxy.invokeSuper(obj, args);
/*     */       }
/* 218 */       return null;
/*     */     }
/*     */ 
/*     */     public boolean isMatch(Method candidateMethod)
/*     */     {
/* 225 */       return (candidateMethod.getName().equals("destroy")) && 
/* 224 */         (candidateMethod
/* 224 */         .getParameterTypes().length == 0) && 
/* 225 */         (DisposableBean.class
/* 225 */         .isAssignableFrom(candidateMethod
/* 225 */         .getDeclaringClass()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConditionalCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     private final Callback[] callbacks;
/*     */     private final Class<?>[] callbackTypes;
/*     */ 
/*     */     public ConditionalCallbackFilter(Callback[] callbacks)
/*     */     {
/* 178 */       this.callbacks = callbacks;
/* 179 */       this.callbackTypes = new Class[callbacks.length];
/* 180 */       for (int i = 0; i < callbacks.length; i++)
/* 181 */         this.callbackTypes[i] = callbacks[i].getClass();
/*     */     }
/*     */ 
/*     */     public int accept(Method method)
/*     */     {
/* 187 */       for (int i = 0; i < this.callbacks.length; i++) {
/* 188 */         if ((!(this.callbacks[i] instanceof ConfigurationClassEnhancer.ConditionalCallback)) || 
/* 189 */           (((ConfigurationClassEnhancer.ConditionalCallback)this.callbacks[i])
/* 189 */           .isMatch(method)))
/*     */         {
/* 190 */           return i;
/*     */         }
/*     */       }
/* 193 */       throw new IllegalStateException("No callback available for method " + method.getName());
/*     */     }
/*     */ 
/*     */     public Class<?>[] getCallbackTypes() {
/* 197 */       return this.callbackTypes;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract interface ConditionalCallback extends Callback
/*     */   {
/*     */     public abstract boolean isMatch(Method paramMethod);
/*     */   }
/*     */ 
/*     */   public static abstract interface EnhancedConfiguration extends DisposableBean, BeanFactoryAware
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassEnhancer
 * JD-Core Version:    0.6.2
 */