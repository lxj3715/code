/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.Aware;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.NestedIOException;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.CompositePropertySource;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourcePropertySource;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.ClassMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ConfigurationClassParser
/*     */ {
/*  94 */   private static final Comparator<DeferredImportSelectorHolder> DEFERRED_IMPORT_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(ConfigurationClassParser.DeferredImportSelectorHolder o1, ConfigurationClassParser.DeferredImportSelectorHolder o2)
/*     */     {
/*  98 */       return AnnotationAwareOrderComparator.INSTANCE.compare(o1.getImportSelector(), o2.getImportSelector());
/*     */     }
/*  94 */   };
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   private final ProblemReporter problemReporter;
/*     */   private final Environment environment;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final ComponentScanAnnotationParser componentScanParser;
/* 115 */   private final Set<ConfigurationClass> configurationClasses = new LinkedHashSet();
/*     */ 
/* 117 */   private final Map<String, ConfigurationClass> knownSuperclasses = new HashMap();
/*     */ 
/* 119 */   private final MultiValueMap<String, org.springframework.core.env.PropertySource<?>> propertySources = new LinkedMultiValueMap();
/*     */ 
/* 121 */   private final ImportStack importStack = new ImportStack(null);
/*     */ 
/* 123 */   private final List<DeferredImportSelectorHolder> deferredImportSelectors = new LinkedList();
/*     */   private final ConditionEvaluator conditionEvaluator;
/*     */ 
/*     */   public ConfigurationClassParser(MetadataReaderFactory metadataReaderFactory, ProblemReporter problemReporter, Environment environment, ResourceLoader resourceLoader, BeanNameGenerator componentScanBeanNameGenerator, BeanDefinitionRegistry registry)
/*     */   {
/* 136 */     this.metadataReaderFactory = metadataReaderFactory;
/* 137 */     this.problemReporter = problemReporter;
/* 138 */     this.environment = environment;
/* 139 */     this.resourceLoader = resourceLoader;
/* 140 */     this.registry = registry;
/* 141 */     this.componentScanParser = new ComponentScanAnnotationParser(resourceLoader, environment, componentScanBeanNameGenerator, registry);
/*     */ 
/* 143 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, resourceLoader);
/*     */   }
/*     */ 
/*     */   public void parse(Set<BeanDefinitionHolder> configCandidates)
/*     */   {
/* 148 */     for (BeanDefinitionHolder holder : configCandidates) {
/* 149 */       BeanDefinition bd = holder.getBeanDefinition();
/*     */       try {
/* 151 */         if (((bd instanceof AbstractBeanDefinition)) && (((AbstractBeanDefinition)bd).hasBeanClass())) {
/* 152 */           parse(((AbstractBeanDefinition)bd).getBeanClass(), holder.getBeanName());
/*     */         }
/*     */         else
/* 155 */           parse(bd.getBeanClassName(), holder.getBeanName());
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 159 */         throw new BeanDefinitionStoreException("Failed to load bean class: " + bd.getBeanClassName(), ex);
/*     */       }
/*     */     }
/* 162 */     processDeferredImportSelectors();
/*     */   }
/*     */ 
/*     */   protected final void parse(String className, String beanName)
/*     */     throws IOException
/*     */   {
/* 172 */     MetadataReader reader = this.metadataReaderFactory.getMetadataReader(className);
/* 173 */     processConfigurationClass(new ConfigurationClass(reader, beanName));
/*     */   }
/*     */ 
/*     */   protected final void parse(Class<?> clazz, String beanName)
/*     */     throws IOException
/*     */   {
/* 182 */     processConfigurationClass(new ConfigurationClass(clazz, beanName));
/*     */   }
/*     */ 
/*     */   protected void processConfigurationClass(ConfigurationClass configClass) throws IOException
/*     */   {
/* 187 */     if (this.conditionEvaluator.shouldSkip(configClass.getMetadata(), ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION))
/*     */       return;
/*     */     Iterator it;
/* 191 */     if ((this.configurationClasses.contains(configClass)) && (configClass.getBeanName() != null))
/*     */     {
/* 194 */       this.configurationClasses.remove(configClass);
/* 195 */       for (it = this.knownSuperclasses.values().iterator(); it.hasNext(); ) {
/* 196 */         if (configClass.equals(it.next())) {
/* 197 */           it.remove();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 203 */     SourceClass sourceClass = asSourceClass(configClass);
/*     */     do {
/* 205 */       sourceClass = doProcessConfigurationClass(configClass, sourceClass);
/*     */     }
/* 207 */     while (sourceClass != null);
/*     */ 
/* 209 */     this.configurationClasses.add(configClass);
/*     */   }
/*     */ 
/*     */   protected final SourceClass doProcessConfigurationClass(ConfigurationClass configClass, SourceClass sourceClass)
/*     */     throws IOException
/*     */   {
/* 222 */     processMemberClasses(configClass, sourceClass);
/*     */ 
/* 225 */     for (AnnotationAttributes propertySource : AnnotationConfigUtils.attributesForRepeatable(sourceClass
/* 226 */       .getMetadata(), PropertySources.class, PropertySource.class))
/*     */     {
/* 227 */       processPropertySource(propertySource);
/*     */     }
/*     */ 
/* 231 */     AnnotationAttributes componentScan = AnnotationConfigUtils.attributesFor(sourceClass.getMetadata(), ComponentScan.class);
/* 232 */     if (componentScan != null)
/*     */     {
/* 234 */       if (!this.conditionEvaluator.shouldSkip(sourceClass.getMetadata(), ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN))
/*     */       {
/* 236 */         Set scannedBeanDefinitions = this.componentScanParser
/* 236 */           .parse(componentScan, sourceClass
/* 236 */           .getMetadata().getClassName());
/*     */ 
/* 239 */         for (BeanDefinitionHolder holder : scannedBeanDefinitions) {
/* 240 */           if (ConfigurationClassUtils.checkConfigurationClassCandidate(holder.getBeanDefinition(), this.metadataReaderFactory)) {
/* 241 */             parse(holder.getBeanDefinition().getBeanClassName(), holder.getBeanName());
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 248 */     processImports(configClass, sourceClass, getImports(sourceClass), true);
/*     */ 
/* 251 */     if (sourceClass.getMetadata().isAnnotated(ImportResource.class.getName())) {
/* 252 */       AnnotationAttributes importResource = AnnotationConfigUtils.attributesFor(sourceClass.getMetadata(), ImportResource.class);
/* 253 */       resources = importResource.getStringArray("value");
/* 254 */       Class readerClass = importResource.getClass("reader");
/* 255 */       for (String resource : resources) {
/* 256 */         String resolvedResource = this.environment.resolveRequiredPlaceholders(resource);
/* 257 */         configClass.addImportedResource(resolvedResource, readerClass);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 262 */     Set beanMethods = sourceClass.getMetadata().getAnnotatedMethods(Bean.class.getName());
/* 263 */     for (Object resources = beanMethods.iterator(); ((Iterator)resources).hasNext(); ) { MethodMetadata methodMetadata = (MethodMetadata)((Iterator)resources).next();
/* 264 */       configClass.addBeanMethod(new BeanMethod(methodMetadata, configClass));
/*     */     }
/*     */ 
/* 268 */     if (sourceClass.getMetadata().hasSuperClass()) {
/* 269 */       String superclass = sourceClass.getMetadata().getSuperClassName();
/* 270 */       if (!this.knownSuperclasses.containsKey(superclass)) {
/* 271 */         this.knownSuperclasses.put(superclass, configClass);
/*     */         try
/*     */         {
/* 274 */           return sourceClass.getSuperClass();
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 277 */           throw new IllegalStateException(ex);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 283 */     return null;
/*     */   }
/*     */ 
/*     */   private void processMemberClasses(ConfigurationClass configClass, SourceClass sourceClass)
/*     */     throws IOException
/*     */   {
/* 292 */     for (SourceClass memberClass : sourceClass.getMemberClasses())
/* 293 */       if (ConfigurationClassUtils.isConfigurationCandidate(memberClass.getMetadata()))
/* 294 */         processConfigurationClass(memberClass.asConfigClass(configClass));
/*     */   }
/*     */ 
/*     */   private void processPropertySource(AnnotationAttributes propertySource)
/*     */     throws IOException
/*     */   {
/* 305 */     String name = propertySource.getString("name");
/* 306 */     String[] locations = propertySource.getStringArray("value");
/* 307 */     boolean ignoreResourceNotFound = propertySource.getBoolean("ignoreResourceNotFound");
/* 308 */     int locationCount = locations.length;
/* 309 */     if (locationCount == 0) {
/* 310 */       throw new IllegalArgumentException("At least one @PropertySource(value) location is required");
/*     */     }
/* 312 */     for (String location : locations) {
/* 313 */       Resource resource = this.resourceLoader.getResource(this.environment
/* 314 */         .resolveRequiredPlaceholders(location));
/*     */       try
/*     */       {
/* 316 */         if ((!StringUtils.hasText(name)) || (this.propertySources.containsKey(name)))
/*     */         {
/* 319 */           ResourcePropertySource ps = new ResourcePropertySource(resource);
/* 320 */           this.propertySources.add(StringUtils.hasText(name) ? name : ps.getName(), ps);
/*     */         }
/*     */         else {
/* 323 */           this.propertySources.add(name, new ResourcePropertySource(name, resource));
/*     */         }
/*     */       }
/*     */       catch (FileNotFoundException ex) {
/* 327 */         if (!ignoreResourceNotFound)
/* 328 */           throw ex;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Set<SourceClass> getImports(SourceClass sourceClass)
/*     */     throws IOException
/*     */   {
/* 338 */     Set imports = new LinkedHashSet();
/* 339 */     Set visited = new LinkedHashSet();
/* 340 */     collectImports(sourceClass, imports, visited);
/* 341 */     return imports;
/*     */   }
/*     */ 
/*     */   private void collectImports(SourceClass sourceClass, Set<SourceClass> imports, Set<SourceClass> visited)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 359 */       if (visited.add(sourceClass)) {
/* 360 */         for (SourceClass annotation : sourceClass.getAnnotations()) {
/* 361 */           String annName = annotation.getMetadata().getClassName();
/* 362 */           if ((!annName.startsWith("java")) && (!annName.equals(Import.class.getName()))) {
/* 363 */             collectImports(annotation, imports, visited);
/*     */           }
/*     */         }
/* 366 */         imports.addAll(sourceClass.getAnnotationAttributes(Import.class.getName(), "value"));
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 370 */       throw new NestedIOException("Unable to collect imports", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processDeferredImportSelectors() {
/* 375 */     Collections.sort(this.deferredImportSelectors, DEFERRED_IMPORT_COMPARATOR);
/* 376 */     for (DeferredImportSelectorHolder deferredImport : this.deferredImportSelectors) {
/*     */       try {
/* 378 */         ConfigurationClass configClass = deferredImport.getConfigurationClass();
/* 379 */         String[] imports = deferredImport.getImportSelector().selectImports(configClass.getMetadata());
/* 380 */         processImports(configClass, asSourceClass(configClass), asSourceClasses(imports), false);
/*     */       }
/*     */       catch (Exception ex) {
/* 383 */         throw new BeanDefinitionStoreException("Failed to load bean class: ", ex);
/*     */       }
/*     */     }
/* 386 */     this.deferredImportSelectors.clear();
/*     */   }
/*     */ 
/*     */   private void processImports(ConfigurationClass configClass, SourceClass currentSourceClass, Collection<SourceClass> importCandidates, boolean checkForCircularImports)
/*     */     throws IOException
/*     */   {
/* 392 */     if (importCandidates.isEmpty()) {
/* 393 */       return;
/*     */     }
/* 395 */     if ((checkForCircularImports) && (this.importStack.contains(configClass))) {
/* 396 */       this.problemReporter.error(new CircularImportProblem(configClass, this.importStack, configClass.getMetadata()));
/*     */     }
/*     */     else {
/* 399 */       this.importStack.push(configClass);
/*     */       try {
/* 401 */         for (SourceClass candidate : importCandidates)
/* 402 */           if (candidate.isAssignable(ImportSelector.class))
/*     */           {
/* 404 */             Class candidateClass = candidate.loadClass();
/* 405 */             ImportSelector selector = (ImportSelector)BeanUtils.instantiateClass(candidateClass, ImportSelector.class);
/* 406 */             invokeAwareMethods(selector);
/* 407 */             if ((selector instanceof DeferredImportSelector)) {
/* 408 */               this.deferredImportSelectors.add(new DeferredImportSelectorHolder(configClass, (DeferredImportSelector)selector));
/*     */             }
/*     */             else {
/* 411 */               String[] importClassNames = selector.selectImports(currentSourceClass.getMetadata());
/* 412 */               Collection importSourceClasses = asSourceClasses(importClassNames);
/* 413 */               processImports(configClass, currentSourceClass, importSourceClasses, false);
/*     */             }
/*     */           }
/* 416 */           else if (candidate.isAssignable(ImportBeanDefinitionRegistrar.class))
/*     */           {
/* 418 */             Class candidateClass = candidate.loadClass();
/* 419 */             ImportBeanDefinitionRegistrar registrar = (ImportBeanDefinitionRegistrar)BeanUtils.instantiateClass(candidateClass, ImportBeanDefinitionRegistrar.class);
/* 420 */             invokeAwareMethods(registrar);
/* 421 */             configClass.addImportBeanDefinitionRegistrar(registrar, currentSourceClass.getMetadata());
/*     */           }
/*     */           else
/*     */           {
/* 425 */             this.importStack.registerImport(currentSourceClass.getMetadata(), candidate.getMetadata().getClassName());
/* 426 */             processConfigurationClass(candidate.asConfigClass(configClass));
/*     */           }
/*     */       }
/*     */       catch (ClassNotFoundException ex)
/*     */       {
/* 431 */         throw new NestedIOException("Failed to load import candidate class", ex);
/*     */       }
/*     */       finally {
/* 434 */         this.importStack.pop();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void invokeAwareMethods(Object importStrategyBean)
/*     */   {
/* 444 */     if ((importStrategyBean instanceof Aware)) {
/* 445 */       if ((importStrategyBean instanceof EnvironmentAware)) {
/* 446 */         ((EnvironmentAware)importStrategyBean).setEnvironment(this.environment);
/*     */       }
/* 448 */       if ((importStrategyBean instanceof ResourceLoaderAware)) {
/* 449 */         ((ResourceLoaderAware)importStrategyBean).setResourceLoader(this.resourceLoader);
/*     */       }
/* 451 */       if ((importStrategyBean instanceof BeanClassLoaderAware))
/*     */       {
/* 454 */         ClassLoader classLoader = (this.registry instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)this.registry)
/* 453 */           .getBeanClassLoader() : this.resourceLoader
/* 454 */           .getClassLoader();
/* 455 */         ((BeanClassLoaderAware)importStrategyBean).setBeanClassLoader(classLoader);
/*     */       }
/* 457 */       if (((importStrategyBean instanceof BeanFactoryAware)) && ((this.registry instanceof BeanFactory)))
/* 458 */         ((BeanFactoryAware)importStrategyBean).setBeanFactory((BeanFactory)this.registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 469 */     for (ConfigurationClass configClass : this.configurationClasses)
/* 470 */       configClass.validate(this.problemReporter);
/*     */   }
/*     */ 
/*     */   public Set<ConfigurationClass> getConfigurationClasses()
/*     */   {
/* 475 */     return this.configurationClasses;
/*     */   }
/*     */ 
/*     */   public List<org.springframework.core.env.PropertySource<?>> getPropertySources() {
/* 479 */     List propertySources = new LinkedList();
/* 480 */     for (Map.Entry entry : this.propertySources.entrySet()) {
/* 481 */       propertySources.add(0, collatePropertySources((String)entry.getKey(), (List)entry.getValue()));
/*     */     }
/* 483 */     return propertySources;
/*     */   }
/*     */ 
/*     */   private org.springframework.core.env.PropertySource<?> collatePropertySources(String name, List<org.springframework.core.env.PropertySource<?>> propertySources) {
/* 487 */     if (propertySources.size() == 1) {
/* 488 */       return (org.springframework.core.env.PropertySource)propertySources.get(0);
/*     */     }
/* 490 */     CompositePropertySource result = new CompositePropertySource(name);
/* 491 */     for (int i = propertySources.size() - 1; i >= 0; i--) {
/* 492 */       result.addPropertySource((org.springframework.core.env.PropertySource)propertySources.get(i));
/*     */     }
/* 494 */     return result;
/*     */   }
/*     */ 
/*     */   ImportRegistry getImportRegistry()
/*     */   {
/* 499 */     return this.importStack;
/*     */   }
/*     */ 
/*     */   public SourceClass asSourceClass(ConfigurationClass configurationClass)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 507 */       AnnotationMetadata metadata = configurationClass.getMetadata();
/* 508 */       if ((metadata instanceof StandardAnnotationMetadata)) {
/* 509 */         return asSourceClass(((StandardAnnotationMetadata)metadata).getIntrospectedClass());
/*     */       }
/* 511 */       return asSourceClass(configurationClass.getMetadata().getClassName());
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 514 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public SourceClass asSourceClass(Class<?> classType)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 524 */       classType.getAnnotations();
/* 525 */       return new SourceClass(classType);
/*     */     } catch (Throwable ex) {
/*     */     }
/* 528 */     return asSourceClass(classType.getName());
/*     */   }
/*     */ 
/*     */   public Collection<SourceClass> asSourceClasses(String[] classNames)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 536 */     List annotatedClasses = new ArrayList();
/* 537 */     for (String className : classNames) {
/* 538 */       annotatedClasses.add(asSourceClass(className));
/*     */     }
/* 540 */     return annotatedClasses;
/*     */   }
/*     */ 
/*     */   public SourceClass asSourceClass(String className)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 547 */     if (className.startsWith("java"))
/*     */     {
/* 549 */       return new SourceClass(this.resourceLoader.getClassLoader().loadClass(className));
/*     */     }
/* 551 */     return new SourceClass(this.metadataReaderFactory.getMetadataReader(className));
/*     */   }
/*     */ 
/*     */   private static class CircularImportProblem extends Problem
/*     */   {
/*     */     public CircularImportProblem(ConfigurationClass attemptedImport, Stack<ConfigurationClass> importStack, AnnotationMetadata metadata)
/*     */     {
/* 787 */       super(new Location(
/* 791 */         ((ConfigurationClass)importStack
/* 791 */         .peek()).getResource(), metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SourceClass
/*     */   {
/*     */     private final Object source;
/*     */     private final AnnotationMetadata metadata;
/*     */ 
/*     */     public SourceClass(Object source)
/*     */     {
/* 648 */       this.source = source;
/* 649 */       if ((source instanceof Class)) {
/* 650 */         this.metadata = new StandardAnnotationMetadata((Class)source, true);
/*     */       }
/*     */       else
/* 653 */         this.metadata = ((MetadataReader)source).getAnnotationMetadata();
/*     */     }
/*     */ 
/*     */     public final AnnotationMetadata getMetadata()
/*     */     {
/* 658 */       return this.metadata;
/*     */     }
/*     */ 
/*     */     public Class<?> loadClass() throws ClassNotFoundException {
/* 662 */       if ((this.source instanceof Class)) {
/* 663 */         return (Class)this.source;
/*     */       }
/* 665 */       String className = ((MetadataReader)this.source).getClassMetadata().getClassName();
/* 666 */       return ConfigurationClassParser.this.resourceLoader.getClassLoader().loadClass(className);
/*     */     }
/*     */ 
/*     */     public boolean isAssignable(Class<?> clazz) throws IOException {
/* 670 */       if ((this.source instanceof Class)) {
/* 671 */         return clazz.isAssignableFrom((Class)this.source);
/*     */       }
/* 673 */       return new AssignableTypeFilter(clazz).match((MetadataReader)this.source, ConfigurationClassParser.this.metadataReaderFactory);
/*     */     }
/*     */ 
/*     */     public ConfigurationClass asConfigClass(ConfigurationClass importedBy) throws IOException {
/* 677 */       if ((this.source instanceof Class)) {
/* 678 */         return new ConfigurationClass((Class)this.source, importedBy);
/*     */       }
/* 680 */       return new ConfigurationClass((MetadataReader)this.source, importedBy);
/*     */     }
/*     */ 
/*     */     public Collection<SourceClass> getMemberClasses() throws IOException {
/* 684 */       List members = new ArrayList();
/* 685 */       if ((this.source instanceof Class)) {
/* 686 */         Class sourceClass = (Class)this.source;
/* 687 */         for (Class declaredClass : sourceClass.getDeclaredClasses())
/*     */           try {
/* 689 */             members.add(ConfigurationClassParser.this.asSourceClass(declaredClass));
/*     */           }
/*     */           catch (ClassNotFoundException ex)
/*     */           {
/*     */           }
/*     */       }
/*     */       else
/*     */       {
/* 697 */         MetadataReader sourceReader = (MetadataReader)this.source;
/* 698 */         for (String memberClassName : sourceReader.getClassMetadata().getMemberClassNames()) {
/*     */           try {
/* 700 */             members.add(ConfigurationClassParser.this.asSourceClass(memberClassName));
/*     */           }
/*     */           catch (ClassNotFoundException ex)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/* 707 */       return members;
/*     */     }
/*     */ 
/*     */     public SourceClass getSuperClass() throws IOException, ClassNotFoundException {
/* 711 */       if ((this.source instanceof Class)) {
/* 712 */         return ConfigurationClassParser.this.asSourceClass(((Class)this.source).getSuperclass());
/*     */       }
/* 714 */       return ConfigurationClassParser.this.asSourceClass(((MetadataReader)this.source).getClassMetadata().getSuperClassName());
/*     */     }
/*     */ 
/*     */     public Set<SourceClass> getAnnotations() throws IOException {
/* 718 */       Set result = new LinkedHashSet();
/* 719 */       for (String className : this.metadata.getAnnotationTypes()) {
/*     */         try {
/* 721 */           result.add(getRelated(className));
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/*     */         }
/*     */       }
/*     */ 
/* 728 */       return result;
/*     */     }
/*     */ 
/*     */     public Collection<SourceClass> getAnnotationAttributes(String annotationType, String attribute)
/*     */       throws IOException, ClassNotFoundException
/*     */     {
/* 734 */       Map annotationAttributes = this.metadata.getAnnotationAttributes(annotationType, true);
/* 735 */       if ((annotationAttributes == null) || (!annotationAttributes.containsKey(attribute))) {
/* 736 */         return Collections.emptySet();
/*     */       }
/* 738 */       String[] classNames = (String[])annotationAttributes.get(attribute);
/* 739 */       Set result = new LinkedHashSet();
/* 740 */       for (String className : classNames) {
/* 741 */         result.add(getRelated(className));
/*     */       }
/* 743 */       return result;
/*     */     }
/*     */ 
/*     */     private SourceClass getRelated(String className) throws IOException, ClassNotFoundException {
/* 747 */       if ((this.source instanceof Class)) {
/*     */         try {
/* 749 */           Class clazz = ConfigurationClassParser.this.resourceLoader.getClassLoader().loadClass(className);
/* 750 */           return ConfigurationClassParser.this.asSourceClass(clazz);
/*     */         }
/*     */         catch (ClassNotFoundException ex)
/*     */         {
/* 754 */           if (className.startsWith("java")) {
/* 755 */             throw ex;
/*     */           }
/* 757 */           return new SourceClass(ConfigurationClassParser.this, ConfigurationClassParser.this.metadataReaderFactory.getMetadataReader(className));
/*     */         }
/*     */       }
/* 760 */       return ConfigurationClassParser.this.asSourceClass(className);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 766 */       return (this == other) || (((other instanceof SourceClass)) && 
/* 766 */         (this.metadata
/* 766 */         .getClassName().equals(((SourceClass)other).metadata.getClassName())));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 771 */       return this.metadata.getClassName().hashCode();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 776 */       return this.metadata.getClassName();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DeferredImportSelectorHolder
/*     */   {
/*     */     private final ConfigurationClass configurationClass;
/*     */     private final DeferredImportSelector importSelector;
/*     */ 
/*     */     public DeferredImportSelectorHolder(ConfigurationClass configurationClass, DeferredImportSelector importSelector)
/*     */     {
/* 623 */       this.configurationClass = configurationClass;
/* 624 */       this.importSelector = importSelector;
/*     */     }
/*     */ 
/*     */     public ConfigurationClass getConfigurationClass() {
/* 628 */       return this.configurationClass;
/*     */     }
/*     */ 
/*     */     public DeferredImportSelector getImportSelector() {
/* 632 */       return this.importSelector;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ImportStack extends Stack<ConfigurationClass>
/*     */     implements ConfigurationClassParser.ImportRegistry
/*     */   {
/* 564 */     private final Map<String, AnnotationMetadata> imports = new HashMap();
/*     */ 
/*     */     public void registerImport(AnnotationMetadata importingClass, String importedClass) {
/* 567 */       this.imports.put(importedClass, importingClass);
/*     */     }
/*     */ 
/*     */     public AnnotationMetadata getImportingClassFor(String importedClass)
/*     */     {
/* 572 */       return (AnnotationMetadata)this.imports.get(importedClass);
/*     */     }
/*     */ 
/*     */     public boolean contains(Object elem)
/*     */     {
/* 582 */       ConfigurationClass configClass = (ConfigurationClass)elem;
/* 583 */       Comparator comparator = new Comparator()
/*     */       {
/*     */         public int compare(ConfigurationClass first, ConfigurationClass second) {
/* 586 */           return first.getMetadata().getClassName().equals(second.getMetadata().getClassName()) ? 0 : 1;
/*     */         }
/*     */       };
/* 589 */       return Collections.binarySearch(this, configClass, comparator) != -1;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 603 */       StringBuilder builder = new StringBuilder("ImportStack: [");
/* 604 */       Iterator iterator = iterator();
/* 605 */       while (iterator.hasNext()) {
/* 606 */         builder.append(((ConfigurationClass)iterator.next()).getSimpleName());
/* 607 */         if (iterator.hasNext()) {
/* 608 */           builder.append("->");
/*     */         }
/*     */       }
/* 611 */       return builder.append(']').toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface ImportRegistry
/*     */   {
/*     */     public abstract AnnotationMetadata getImportingClassFor(String paramString);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassParser
 * JD-Core Version:    0.6.2
 */