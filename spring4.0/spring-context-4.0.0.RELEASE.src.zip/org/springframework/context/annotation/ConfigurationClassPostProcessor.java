/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.autoproxy.AutoProxyUtils;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
/*     */ import org.springframework.beans.factory.config.SingletonBeanRegistry;
/*     */ import org.springframework.beans.factory.parsing.FailFastProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.PassThroughSourceExtractor;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class ConfigurationClassPostProcessor
/*     */   implements BeanDefinitionRegistryPostProcessor, PriorityOrdered, ResourceLoaderAware, BeanClassLoaderAware, EnvironmentAware
/*     */ {
/*  95 */   private static final String IMPORT_AWARE_PROCESSOR_BEAN_NAME = ConfigurationClassPostProcessor.class
/*  95 */     .getName() + ".importAwareProcessor";
/*     */ 
/*  98 */   private static final String IMPORT_REGISTRY_BEAN_NAME = ConfigurationClassPostProcessor.class
/*  98 */     .getName() + ".importRegistry";
/*     */ 
/* 101 */   private static final String ENHANCED_CONFIGURATION_PROCESSOR_BEAN_NAME = ConfigurationClassPostProcessor.class
/* 101 */     .getName() + ".enhancedConfigurationProcessor";
/*     */   private final Log logger;
/*     */   private SourceExtractor sourceExtractor;
/*     */   private ProblemReporter problemReporter;
/*     */   private Environment environment;
/*     */   private ResourceLoader resourceLoader;
/*     */   private ClassLoader beanClassLoader;
/*     */   private MetadataReaderFactory metadataReaderFactory;
/*     */   private boolean setMetadataReaderFactoryCalled;
/*     */   private final Set<Integer> registriesPostProcessed;
/*     */   private final Set<Integer> factoriesPostProcessed;
/*     */   private ConfigurationClassBeanDefinitionReader reader;
/*     */   private boolean localBeanNameGeneratorSet;
/*     */   private BeanNameGenerator componentScanBeanNameGenerator;
/*     */   private BeanNameGenerator importBeanNameGenerator;
/*     */ 
/*     */   public ConfigurationClassPostProcessor()
/*     */   {
/* 104 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/* 106 */     this.sourceExtractor = new PassThroughSourceExtractor();
/*     */ 
/* 108 */     this.problemReporter = new FailFastProblemReporter();
/*     */ 
/* 112 */     this.resourceLoader = new DefaultResourceLoader();
/*     */ 
/* 114 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/* 116 */     this.metadataReaderFactory = new CachingMetadataReaderFactory();
/*     */ 
/* 118 */     this.setMetadataReaderFactoryCalled = false;
/*     */ 
/* 120 */     this.registriesPostProcessed = new HashSet();
/*     */ 
/* 122 */     this.factoriesPostProcessed = new HashSet();
/*     */ 
/* 126 */     this.localBeanNameGeneratorSet = false;
/*     */ 
/* 129 */     this.componentScanBeanNameGenerator = new AnnotationBeanNameGenerator();
/*     */ 
/* 132 */     this.importBeanNameGenerator = new AnnotationBeanNameGenerator()
/*     */     {
/*     */       protected String buildDefaultBeanName(BeanDefinition definition) {
/* 135 */         return definition.getBeanClassName();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 142 */     return 2147483647;
/*     */   }
/*     */ 
/*     */   public void setSourceExtractor(SourceExtractor sourceExtractor)
/*     */   {
/* 150 */     this.sourceExtractor = (sourceExtractor != null ? sourceExtractor : new PassThroughSourceExtractor());
/*     */   }
/*     */ 
/*     */   public void setProblemReporter(ProblemReporter problemReporter)
/*     */   {
/* 160 */     this.problemReporter = (problemReporter != null ? problemReporter : new FailFastProblemReporter());
/*     */   }
/*     */ 
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory)
/*     */   {
/* 169 */     Assert.notNull(metadataReaderFactory, "MetadataReaderFactory must not be null");
/* 170 */     this.metadataReaderFactory = metadataReaderFactory;
/* 171 */     this.setMetadataReaderFactoryCalled = true;
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 192 */     Assert.notNull(beanNameGenerator, "BeanNameGenerator must not be null");
/* 193 */     this.localBeanNameGeneratorSet = true;
/* 194 */     this.componentScanBeanNameGenerator = beanNameGenerator;
/* 195 */     this.importBeanNameGenerator = beanNameGenerator;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 200 */     Assert.notNull(environment, "Environment must not be null");
/* 201 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 206 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 207 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/* 212 */     this.beanClassLoader = beanClassLoader;
/* 213 */     if (!this.setMetadataReaderFactoryCalled)
/* 214 */       this.metadataReaderFactory = new CachingMetadataReaderFactory(beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry)
/*     */   {
/* 224 */     RootBeanDefinition iabpp = new RootBeanDefinition(ImportAwareBeanPostProcessor.class);
/* 225 */     iabpp.setRole(2);
/* 226 */     registry.registerBeanDefinition(IMPORT_AWARE_PROCESSOR_BEAN_NAME, iabpp);
/*     */ 
/* 228 */     RootBeanDefinition ecbpp = new RootBeanDefinition(EnhancedConfigurationBeanPostProcessor.class);
/* 229 */     ecbpp.setRole(2);
/* 230 */     registry.registerBeanDefinition(ENHANCED_CONFIGURATION_PROCESSOR_BEAN_NAME, ecbpp);
/*     */ 
/* 232 */     int registryId = System.identityHashCode(registry);
/* 233 */     if (this.registriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 234 */       throw new IllegalStateException("postProcessBeanDefinitionRegistry already called for this post-processor against " + registry);
/*     */     }
/*     */ 
/* 237 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 238 */       throw new IllegalStateException("postProcessBeanFactory already called for this post-processor against " + registry);
/*     */     }
/*     */ 
/* 241 */     this.registriesPostProcessed.add(Integer.valueOf(registryId));
/*     */ 
/* 243 */     processConfigBeanDefinitions(registry);
/*     */   }
/*     */ 
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 252 */     int factoryId = System.identityHashCode(beanFactory);
/* 253 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(factoryId))) {
/* 254 */       throw new IllegalStateException("postProcessBeanFactory already called for this post-processor against " + beanFactory);
/*     */     }
/*     */ 
/* 257 */     this.factoriesPostProcessed.add(Integer.valueOf(factoryId));
/* 258 */     if (!this.registriesPostProcessed.contains(Integer.valueOf(factoryId)))
/*     */     {
/* 261 */       processConfigBeanDefinitions((BeanDefinitionRegistry)beanFactory);
/*     */     }
/* 263 */     enhanceConfigurationClasses(beanFactory);
/*     */   }
/*     */ 
/*     */   public void processConfigBeanDefinitions(BeanDefinitionRegistry registry)
/*     */   {
/* 271 */     Set configCandidates = new LinkedHashSet();
/*     */     BeanDefinition beanDef;
/* 272 */     for (String beanName : registry.getBeanDefinitionNames()) {
/* 273 */       beanDef = registry.getBeanDefinition(beanName);
/* 274 */       if (ConfigurationClassUtils.checkConfigurationClassCandidate(beanDef, this.metadataReaderFactory)) {
/* 275 */         configCandidates.add(new BeanDefinitionHolder(beanDef, beanName));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 280 */     if (configCandidates.isEmpty()) {
/* 281 */       return;
/*     */     }
/*     */ 
/* 285 */     SingletonBeanRegistry singletonRegistry = null;
/* 286 */     if ((registry instanceof SingletonBeanRegistry)) {
/* 287 */       singletonRegistry = (SingletonBeanRegistry)registry;
/* 288 */       if ((!this.localBeanNameGeneratorSet) && (singletonRegistry.containsSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator"))) {
/* 289 */         BeanNameGenerator generator = (BeanNameGenerator)singletonRegistry.getSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator");
/* 290 */         this.componentScanBeanNameGenerator = generator;
/* 291 */         this.importBeanNameGenerator = generator;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 296 */     ConfigurationClassParser parser = new ConfigurationClassParser(this.metadataReaderFactory, this.problemReporter, this.environment, this.resourceLoader, this.componentScanBeanNameGenerator, registry);
/*     */ 
/* 299 */     parser.parse(configCandidates);
/* 300 */     parser.validate();
/*     */ 
/* 303 */     List parsedPropertySources = parser.getPropertySources();
/*     */     MutablePropertySources envPropertySources;
/* 304 */     if (!parsedPropertySources.isEmpty()) {
/* 305 */       if (!(this.environment instanceof ConfigurableEnvironment)) {
/* 306 */         this.logger.warn("Ignoring @PropertySource annotations. Reason: Environment must implement ConfigurableEnvironment");
/*     */       }
/*     */       else
/*     */       {
/* 310 */         envPropertySources = ((ConfigurableEnvironment)this.environment).getPropertySources();
/* 311 */         for (PropertySource propertySource : parsedPropertySources) {
/* 312 */           envPropertySources.addLast(propertySource);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 318 */     if (this.reader == null) {
/* 319 */       this.reader = new ConfigurationClassBeanDefinitionReader(registry, this.sourceExtractor, this.problemReporter, this.metadataReaderFactory, this.resourceLoader, this.environment, this.importBeanNameGenerator);
/*     */     }
/*     */ 
/* 324 */     this.reader.loadBeanDefinitions(parser.getConfigurationClasses());
/*     */ 
/* 327 */     if ((singletonRegistry != null) && 
/* 328 */       (!singletonRegistry.containsSingleton(IMPORT_REGISTRY_BEAN_NAME))) {
/* 329 */       singletonRegistry.registerSingleton(IMPORT_REGISTRY_BEAN_NAME, parser.getImportRegistry());
/*     */     }
/*     */ 
/* 333 */     if ((this.metadataReaderFactory instanceof CachingMetadataReaderFactory))
/* 334 */       ((CachingMetadataReaderFactory)this.metadataReaderFactory).clearCache();
/*     */   }
/*     */ 
/*     */   public void enhanceConfigurationClasses(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 345 */     Map configBeanDefs = new LinkedHashMap();
/* 346 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 347 */       BeanDefinition beanDef = beanFactory.getBeanDefinition(beanName);
/* 348 */       if (ConfigurationClassUtils.isFullConfigurationClass(beanDef)) {
/* 349 */         if (!(beanDef instanceof AbstractBeanDefinition)) {
/* 350 */           throw new BeanDefinitionStoreException("Cannot enhance @Configuration bean definition '" + beanName + "' since it is not stored in an AbstractBeanDefinition subclass");
/*     */         }
/*     */ 
/* 353 */         configBeanDefs.put(beanName, (AbstractBeanDefinition)beanDef);
/*     */       }
/*     */     }
/* 356 */     if (configBeanDefs.isEmpty())
/*     */     {
/* 358 */       return;
/*     */     }
/* 360 */     ConfigurationClassEnhancer enhancer = new ConfigurationClassEnhancer();
/* 361 */     for (Map.Entry entry : configBeanDefs.entrySet()) {
/* 362 */       AbstractBeanDefinition beanDef = (AbstractBeanDefinition)entry.getValue();
/*     */ 
/* 364 */       beanDef.setAttribute(AutoProxyUtils.PRESERVE_TARGET_CLASS_ATTRIBUTE, Boolean.TRUE);
/*     */       try
/*     */       {
/* 367 */         Class configClass = beanDef.resolveBeanClass(this.beanClassLoader);
/* 368 */         Class enhancedClass = enhancer.enhance(configClass);
/* 369 */         if (configClass != enhancedClass) {
/* 370 */           if (this.logger.isDebugEnabled()) {
/* 371 */             this.logger.debug(String.format("Replacing bean definition '%s' existing class name '%s' with enhanced class name '%s'", new Object[] { entry
/* 372 */               .getKey(), configClass.getName(), enhancedClass.getName() }));
/*     */           }
/* 374 */           beanDef.setBeanClass(enhancedClass);
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 378 */         throw new IllegalStateException("Cannot load configuration class: " + beanDef.getBeanClassName(), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EnhancedConfigurationBeanPostProcessor extends InstantiationAwareBeanPostProcessorAdapter
/*     */     implements PriorityOrdered, BeanFactoryAware
/*     */   {
/*     */     private BeanFactory beanFactory;
/*     */ 
/*     */     public int getOrder()
/*     */     {
/* 429 */       return -2147483648;
/*     */     }
/*     */ 
/*     */     public void setBeanFactory(BeanFactory beanFactory)
/*     */     {
/* 434 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */     public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean, String beanName)
/*     */     {
/* 441 */       if ((bean instanceof ConfigurationClassEnhancer.EnhancedConfiguration)) {
/* 442 */         ((ConfigurationClassEnhancer.EnhancedConfiguration)bean).setBeanFactory(this.beanFactory);
/*     */       }
/* 444 */       return pvs;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ImportAwareBeanPostProcessor
/*     */     implements BeanPostProcessor, BeanFactoryAware, PriorityOrdered
/*     */   {
/*     */     private BeanFactory beanFactory;
/*     */ 
/*     */     public void setBeanFactory(BeanFactory beanFactory)
/*     */     {
/* 390 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */     public int getOrder()
/*     */     {
/* 395 */       return -2147483648;
/*     */     }
/*     */ 
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     {
/* 400 */       if ((bean instanceof ImportAware)) {
/* 401 */         ConfigurationClassParser.ImportRegistry importRegistry = (ConfigurationClassParser.ImportRegistry)this.beanFactory.getBean(ConfigurationClassPostProcessor.IMPORT_REGISTRY_BEAN_NAME, ConfigurationClassParser.ImportRegistry.class);
/* 402 */         AnnotationMetadata importingClass = importRegistry.getImportingClassFor(bean.getClass().getSuperclass().getName());
/* 403 */         if (importingClass != null) {
/* 404 */           ((ImportAware)bean).setImportMetadata(importingClass);
/*     */         }
/*     */       }
/* 407 */       return bean;
/*     */     }
/*     */ 
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     {
/* 412 */       return bean;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassPostProcessor
 * JD-Core Version:    0.6.2
 */