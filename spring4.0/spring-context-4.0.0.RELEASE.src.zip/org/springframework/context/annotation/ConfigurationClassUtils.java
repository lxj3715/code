/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.stereotype.Component;
/*     */ 
/*     */ abstract class ConfigurationClassUtils
/*     */ {
/*     */   private static final String CONFIGURATION_CLASS_FULL = "full";
/*     */   private static final String CONFIGURATION_CLASS_LITE = "lite";
/*  47 */   private static final String CONFIGURATION_CLASS_ATTRIBUTE = Conventions.getQualifiedAttributeName(ConfigurationClassPostProcessor.class, "configurationClass")
/*  47 */     ;
/*     */ 
/*  49 */   private static final Log logger = LogFactory.getLog(ConfigurationClassUtils.class);
/*     */ 
/*     */   public static boolean checkConfigurationClassCandidate(BeanDefinition beanDef, MetadataReaderFactory metadataReaderFactory)
/*     */   {
/*  61 */     AnnotationMetadata metadata = null;
/*     */ 
/*  65 */     if (((beanDef instanceof AbstractBeanDefinition)) && (((AbstractBeanDefinition)beanDef).hasBeanClass())) {
/*  66 */       Class beanClass = ((AbstractBeanDefinition)beanDef).getBeanClass();
/*  67 */       metadata = new StandardAnnotationMetadata(beanClass, true);
/*     */     }
/*     */     else {
/*  70 */       String className = beanDef.getBeanClassName();
/*  71 */       if (className != null) {
/*     */         try {
/*  73 */           MetadataReader metadataReader = metadataReaderFactory.getMetadataReader(className);
/*  74 */           metadata = metadataReader.getAnnotationMetadata();
/*     */         }
/*     */         catch (IOException ex) {
/*  77 */           if (logger.isDebugEnabled()) {
/*  78 */             logger.debug("Could not find class file for introspecting factory methods: " + className, ex);
/*     */           }
/*  80 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  85 */     if (metadata != null) {
/*  86 */       if (isFullConfigurationCandidate(metadata)) {
/*  87 */         beanDef.setAttribute(CONFIGURATION_CLASS_ATTRIBUTE, "full");
/*  88 */         return true;
/*     */       }
/*  90 */       if (isLiteConfigurationCandidate(metadata)) {
/*  91 */         beanDef.setAttribute(CONFIGURATION_CLASS_ATTRIBUTE, "lite");
/*  92 */         return true;
/*     */       }
/*     */     }
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isConfigurationCandidate(AnnotationMetadata metadata)
/*     */   {
/* 106 */     return (isFullConfigurationCandidate(metadata)) || (isLiteConfigurationCandidate(metadata));
/*     */   }
/*     */ 
/*     */   public static boolean isFullConfigurationCandidate(AnnotationMetadata metadata)
/*     */   {
/* 117 */     return metadata.isAnnotated(Configuration.class.getName());
/*     */   }
/*     */ 
/*     */   public static boolean isLiteConfigurationCandidate(AnnotationMetadata metadata)
/*     */   {
/* 131 */     return (!metadata.isInterface()) && ((metadata.isAnnotated(Component.class.getName())) || 
/* 131 */       (metadata
/* 131 */       .isAnnotated(Import.class
/* 131 */       .getName())) || (metadata.hasAnnotatedMethods(Bean.class.getName())));
/*     */   }
/*     */ 
/*     */   public static boolean isFullConfigurationClass(BeanDefinition beanDef)
/*     */   {
/* 139 */     return "full".equals(beanDef.getAttribute(CONFIGURATION_CLASS_ATTRIBUTE));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassUtils
 * JD-Core Version:    0.6.2
 */