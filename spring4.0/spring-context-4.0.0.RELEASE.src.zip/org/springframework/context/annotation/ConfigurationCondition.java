/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ public abstract interface ConfigurationCondition extends Condition
/*    */ {
/*    */   public abstract ConfigurationPhase getConfigurationPhase();
/*    */ 
/*    */   public static enum ConfigurationPhase
/*    */   {
/* 48 */     PARSE_CONFIGURATION, 
/*    */ 
/* 58 */     REGISTER_BEAN;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationCondition
 * JD-Core Version:    0.6.2
 */