/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.Location;
/*    */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*    */ import org.springframework.core.type.MethodMetadata;
/*    */ 
/*    */ abstract class ConfigurationMethod
/*    */ {
/*    */   protected final MethodMetadata metadata;
/*    */   protected final ConfigurationClass configurationClass;
/*    */ 
/*    */   public ConfigurationMethod(MethodMetadata metadata, ConfigurationClass configurationClass)
/*    */   {
/* 35 */     this.metadata = metadata;
/* 36 */     this.configurationClass = configurationClass;
/*    */   }
/*    */ 
/*    */   public MethodMetadata getMetadata()
/*    */   {
/* 41 */     return this.metadata;
/*    */   }
/*    */ 
/*    */   public ConfigurationClass getConfigurationClass() {
/* 45 */     return this.configurationClass;
/*    */   }
/*    */ 
/*    */   public Location getResourceLocation() {
/* 49 */     return new Location(this.configurationClass.getResource(), this.metadata);
/*    */   }
/*    */ 
/*    */   String getFullyQualifiedMethodName() {
/* 53 */     return this.metadata.getDeclaringClassName() + "#" + this.metadata.getMethodName();
/*    */   }
/*    */ 
/*    */   static String getShortMethodName(String fullyQualifiedMethodName) {
/* 57 */     return fullyQualifiedMethodName.substring(fullyQualifiedMethodName.indexOf('#') + 1);
/*    */   }
/*    */ 
/*    */   public void validate(ProblemReporter problemReporter)
/*    */   {
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 66 */     return String.format("[%s:name=%s,declaringClass=%s]", new Object[] { 
/* 67 */       getClass().getSimpleName(), getMetadata().getMethodName(), getMetadata().getDeclaringClassName() });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationMethod
 * JD-Core Version:    0.6.2
 */