/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.TargetSource;
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.annotation.QualifierAnnotationAutowireCandidateResolver;
/*    */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*    */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ContextAnnotationAutowireCandidateResolver extends QualifierAnnotationAutowireCandidateResolver
/*    */ {
/*    */   public Object getLazyResolutionProxyIfNecessary(DependencyDescriptor descriptor, String beanName)
/*    */   {
/* 44 */     return isLazy(descriptor) ? buildLazyResolutionProxy(descriptor, beanName) : null;
/*    */   }
/*    */ 
/*    */   protected boolean isLazy(DependencyDescriptor descriptor) {
/* 48 */     for (Annotation ann : descriptor.getAnnotations()) {
/* 49 */       Lazy lazy = (Lazy)AnnotationUtils.getAnnotation(ann, Lazy.class);
/* 50 */       if ((lazy != null) && (lazy.value())) {
/* 51 */         return true;
/*    */       }
/*    */     }
/* 54 */     MethodParameter methodParam = descriptor.getMethodParameter();
/* 55 */     if (methodParam != null) {
/* 56 */       Method method = methodParam.getMethod();
/* 57 */       if ((method == null) || (Void.TYPE.equals(method.getReturnType()))) {
/* 58 */         Lazy lazy = (Lazy)AnnotationUtils.getAnnotation(methodParam.getAnnotatedElement(), Lazy.class);
/* 59 */         if ((lazy != null) && (lazy.value())) {
/* 60 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 64 */     return false;
/*    */   }
/*    */ 
/*    */   protected Object buildLazyResolutionProxy(final DependencyDescriptor descriptor, final String beanName) {
/* 68 */     Assert.state(getBeanFactory() instanceof DefaultListableBeanFactory, "BeanFactory needs to be a DefaultListableBeanFactory");
/*    */ 
/* 70 */     final DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory)getBeanFactory();
/* 71 */     TargetSource ts = new TargetSource()
/*    */     {
/*    */       public Class<?> getTargetClass() {
/* 74 */         return descriptor.getDependencyType();
/*    */       }
/*    */ 
/*    */       public boolean isStatic() {
/* 78 */         return false;
/*    */       }
/*    */ 
/*    */       public Object getTarget() {
/* 82 */         return beanFactory.doResolveDependency(descriptor, beanName, null, null);
/*    */       }
/*    */ 
/*    */       public void releaseTarget(Object target)
/*    */       {
/*    */       }
/*    */     };
/* 88 */     ProxyFactory pf = new ProxyFactory();
/* 89 */     pf.setTargetSource(ts);
/* 90 */     Class dependencyType = descriptor.getDependencyType();
/* 91 */     if (dependencyType.isInterface()) {
/* 92 */       pf.addInterface(dependencyType);
/*    */     }
/* 94 */     return pf.getProxy(beanFactory.getBeanClassLoader());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ContextAnnotationAutowireCandidateResolver
 * JD-Core Version:    0.6.2
 */