/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ public enum FilterType
/*    */ {
/* 38 */   ANNOTATION, 
/*    */ 
/* 44 */   ASSIGNABLE_TYPE, 
/*    */ 
/* 50 */   ASPECTJ, 
/*    */ 
/* 56 */   REGEX, 
/*    */ 
/* 61 */   CUSTOM;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.FilterType
 * JD-Core Version:    0.6.2
 */