package org.springframework.context.annotation;

import org.springframework.beans.factory.Aware;
import org.springframework.core.type.AnnotationMetadata;

public abstract interface ImportAware extends Aware
{
  public abstract void setImportMetadata(AnnotationMetadata paramAnnotationMetadata);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ImportAware
 * JD-Core Version:    0.6.2
 */