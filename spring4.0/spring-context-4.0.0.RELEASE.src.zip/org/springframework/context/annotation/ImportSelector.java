package org.springframework.context.annotation;

import org.springframework.core.type.AnnotationMetadata;

public abstract interface ImportSelector
{
  public abstract String[] selectImports(AnnotationMetadata paramAnnotationMetadata);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ImportSelector
 * JD-Core Version:    0.6.2
 */