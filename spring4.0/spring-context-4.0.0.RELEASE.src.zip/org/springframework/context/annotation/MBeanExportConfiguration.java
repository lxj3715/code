/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.jmx.export.annotation.AnnotationMBeanExporter;
/*     */ import org.springframework.jmx.support.RegistrationPolicy;
/*     */ import org.springframework.jmx.support.WebSphereMBeanServerFactoryBean;
/*     */ import org.springframework.jndi.JndiObjectFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ @Configuration
/*     */ public class MBeanExportConfiguration
/*     */   implements ImportAware, EnvironmentAware, BeanFactoryAware
/*     */ {
/*     */   private static final String MBEAN_EXPORTER_BEAN_NAME = "mbeanExporter";
/*     */   private AnnotationAttributes attributes;
/*     */   private Environment environment;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*     */   {
/*  63 */     Map map = importMetadata.getAnnotationAttributes(EnableMBeanExport.class.getName());
/*  64 */     this.attributes = AnnotationAttributes.fromMap(map);
/*  65 */     Assert.notNull(this.attributes, "@EnableMBeanExport is not present on importing class " + importMetadata
/*  66 */       .getClassName());
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/*  71 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  76 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   @Bean(name={"mbeanExporter"})
/*     */   @Role(2)
/*     */   public AnnotationMBeanExporter mbeanExporter() {
/*  83 */     AnnotationMBeanExporter exporter = new AnnotationMBeanExporter();
/*  84 */     setupDomain(exporter);
/*  85 */     setupServer(exporter);
/*  86 */     setupRegistrationPolicy(exporter);
/*  87 */     return exporter;
/*     */   }
/*     */ 
/*     */   private void setupDomain(AnnotationMBeanExporter exporter) {
/*  91 */     String defaultDomain = this.attributes.getString("defaultDomain");
/*  92 */     if ((defaultDomain != null) && (this.environment != null)) {
/*  93 */       defaultDomain = this.environment.resolvePlaceholders(defaultDomain);
/*     */     }
/*  95 */     if (StringUtils.hasText(defaultDomain))
/*  96 */       exporter.setDefaultDomain(defaultDomain);
/*     */   }
/*     */ 
/*     */   private void setupServer(AnnotationMBeanExporter exporter)
/*     */   {
/* 101 */     String server = this.attributes.getString("server");
/* 102 */     if ((server != null) && (this.environment != null)) {
/* 103 */       server = this.environment.resolvePlaceholders(server);
/*     */     }
/* 105 */     if (StringUtils.hasText(server)) {
/* 106 */       exporter.setServer((MBeanServer)this.beanFactory.getBean(server, MBeanServer.class));
/*     */     }
/*     */     else {
/* 109 */       SpecificPlatform specificPlatform = SpecificPlatform.get();
/* 110 */       if (specificPlatform != null)
/* 111 */         exporter.setServer(specificPlatform.getMBeanServer());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setupRegistrationPolicy(AnnotationMBeanExporter exporter)
/*     */   {
/* 117 */     RegistrationPolicy registrationPolicy = (RegistrationPolicy)this.attributes.getEnum("registration");
/* 118 */     exporter.setRegistrationPolicy(registrationPolicy);
/*     */   }
/*     */ 
/*     */   private static abstract enum SpecificPlatform
/*     */   {
/* 124 */     WEBLOGIC("weblogic.management.Helper"), 
/*     */ 
/* 133 */     WEBSPHERE("com.ibm.websphere.management.AdminServiceFactory");
/*     */ 
/*     */     private final String identifyingClass;
/*     */ 
/*     */     private SpecificPlatform(String identifyingClass)
/*     */     {
/* 143 */       this.identifyingClass = identifyingClass;
/*     */     }
/*     */ 
/*     */     public MBeanServer getMBeanServer()
/*     */     {
/*     */       try {
/* 149 */         Object server = getMBeanServerFactory().getObject();
/* 150 */         Assert.isInstanceOf(MBeanServer.class, server);
/* 151 */         return (MBeanServer)server;
/*     */       }
/*     */       catch (Exception ex) {
/* 154 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected abstract FactoryBean<?> getMBeanServerFactory();
/*     */ 
/*     */     public static SpecificPlatform get() {
/* 161 */       ClassLoader classLoader = MBeanExportConfiguration.class.getClassLoader();
/* 162 */       for (SpecificPlatform environment : values()) {
/* 163 */         if (ClassUtils.isPresent(environment.identifyingClass, classLoader)) {
/* 164 */           return environment;
/*     */         }
/*     */       }
/* 167 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.MBeanExportConfiguration
 * JD-Core Version:    0.6.2
 */