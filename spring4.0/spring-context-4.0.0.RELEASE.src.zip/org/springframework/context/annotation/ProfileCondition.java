/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ class ProfileCondition
/*    */   implements Condition
/*    */ {
/*    */   public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 35 */     if (context.getEnvironment() != null) {
/* 36 */       MultiValueMap attrs = metadata.getAllAnnotationAttributes(Profile.class.getName());
/* 37 */       if (attrs != null) {
/* 38 */         for (Iterator localIterator = ((List)attrs.get("value")).iterator(); localIterator.hasNext(); ) { Object value = localIterator.next();
/* 39 */           if (context.getEnvironment().acceptsProfiles((String[])value)) {
/* 40 */             return true;
/*    */           }
/*    */         }
/* 43 */         return false;
/*    */       }
/*    */     }
/* 46 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ProfileCondition
 * JD-Core Version:    0.6.2
 */