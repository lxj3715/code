/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*    */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.classreading.MetadataReader;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ScannedGenericBeanDefinition extends GenericBeanDefinition
/*    */   implements AnnotatedBeanDefinition
/*    */ {
/*    */   private final AnnotationMetadata metadata;
/*    */ 
/*    */   public ScannedGenericBeanDefinition(MetadataReader metadataReader)
/*    */   {
/* 58 */     Assert.notNull(metadataReader, "MetadataReader must not be null");
/* 59 */     this.metadata = metadataReader.getAnnotationMetadata();
/* 60 */     setBeanClassName(this.metadata.getClassName());
/*    */   }
/*    */ 
/*    */   public final AnnotationMetadata getMetadata()
/*    */   {
/* 66 */     return this.metadata;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ScannedGenericBeanDefinition
 * JD-Core Version:    0.6.2
 */