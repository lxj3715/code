/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ public enum ScopedProxyMode
/*    */ {
/* 36 */   DEFAULT, 
/*    */ 
/* 45 */   NO, 
/*    */ 
/* 51 */   INTERFACES, 
/*    */ 
/* 56 */   TARGET_CLASS;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ScopedProxyMode
 * JD-Core Version:    0.6.2
 */