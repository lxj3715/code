/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ abstract class AbstractPropertyLoadingBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*    */ {
/*    */   protected boolean shouldGenerateId()
/*    */   {
/* 38 */     return true;
/*    */   }
/*    */ 
/*    */   protected void doParse(Element element, BeanDefinitionBuilder builder)
/*    */   {
/* 43 */     String location = element.getAttribute("location");
/* 44 */     if (StringUtils.hasLength(location)) {
/* 45 */       String[] locations = StringUtils.commaDelimitedListToStringArray(location);
/* 46 */       builder.addPropertyValue("locations", locations);
/*    */     }
/*    */ 
/* 49 */     String propertiesRef = element.getAttribute("properties-ref");
/* 50 */     if (StringUtils.hasLength(propertiesRef)) {
/* 51 */       builder.addPropertyReference("properties", propertiesRef);
/*    */     }
/*    */ 
/* 54 */     String fileEncoding = element.getAttribute("file-encoding");
/* 55 */     if (StringUtils.hasLength(fileEncoding)) {
/* 56 */       builder.addPropertyValue("fileEncoding", fileEncoding);
/*    */     }
/*    */ 
/* 59 */     String order = element.getAttribute("order");
/* 60 */     if (StringUtils.hasLength(order)) {
/* 61 */       builder.addPropertyValue("order", Integer.valueOf(order));
/*    */     }
/*    */ 
/* 64 */     builder.addPropertyValue("ignoreResourceNotFound", 
/* 65 */       Boolean.valueOf(element
/* 65 */       .getAttribute("ignore-resource-not-found")));
/*    */ 
/* 67 */     builder.addPropertyValue("localOverride", 
/* 68 */       Boolean.valueOf(element
/* 68 */       .getAttribute("local-override")));
/*    */ 
/* 70 */     builder.setRole(2);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.config.AbstractPropertyLoadingBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */