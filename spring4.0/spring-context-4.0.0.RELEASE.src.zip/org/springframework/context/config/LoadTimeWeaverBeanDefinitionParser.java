/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class LoadTimeWeaverBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*    */ {
/*    */   private static final String WEAVER_CLASS_ATTRIBUTE = "weaver-class";
/*    */   private static final String ASPECTJ_WEAVING_ATTRIBUTE = "aspectj-weaving";
/*    */   private static final String DEFAULT_LOAD_TIME_WEAVER_CLASS_NAME = "org.springframework.context.weaving.DefaultContextLoadTimeWeaver";
/*    */   private static final String ASPECTJ_WEAVING_ENABLER_CLASS_NAME = "org.springframework.context.weaving.AspectJWeavingEnabler";
/*    */ 
/*    */   protected String getBeanClassName(Element element)
/*    */   {
/* 52 */     if (element.hasAttribute("weaver-class")) {
/* 53 */       return element.getAttribute("weaver-class");
/*    */     }
/* 55 */     return "org.springframework.context.weaving.DefaultContextLoadTimeWeaver";
/*    */   }
/*    */ 
/*    */   protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext)
/*    */   {
/* 60 */     return "loadTimeWeaver";
/*    */   }
/*    */ 
/*    */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*    */   {
/* 65 */     builder.setRole(2);
/*    */ 
/* 67 */     if (isAspectJWeavingEnabled(element.getAttribute("aspectj-weaving"), parserContext)) {
/* 68 */       RootBeanDefinition weavingEnablerDef = new RootBeanDefinition();
/* 69 */       weavingEnablerDef.setBeanClassName("org.springframework.context.weaving.AspectJWeavingEnabler");
/* 70 */       parserContext.getReaderContext().registerWithGeneratedName(weavingEnablerDef);
/*    */ 
/* 72 */       if (isBeanConfigurerAspectEnabled(parserContext.getReaderContext().getBeanClassLoader()))
/* 73 */         new SpringConfiguredBeanDefinitionParser().parse(element, parserContext);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected boolean isAspectJWeavingEnabled(String value, ParserContext parserContext)
/*    */   {
/* 79 */     if ("on".equals(value)) {
/* 80 */       return true;
/*    */     }
/* 82 */     if ("off".equals(value)) {
/* 83 */       return false;
/*    */     }
/*    */ 
/* 87 */     ClassLoader cl = parserContext.getReaderContext().getResourceLoader().getClassLoader();
/* 88 */     return cl.getResource("META-INF/aop.xml") != null;
/*    */   }
/*    */ 
/*    */   protected boolean isBeanConfigurerAspectEnabled(ClassLoader beanClassLoader)
/*    */   {
/* 93 */     return ClassUtils.isPresent("org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect", beanClassLoader);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.config.LoadTimeWeaverBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */