/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class AbstractApplicationEventMulticaster
/*     */   implements ApplicationEventMulticaster, BeanFactoryAware
/*     */ {
/*     */   private final ListenerRetriever defaultRetriever;
/*     */   private final Map<ListenerCacheKey, ListenerRetriever> retrieverCache;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public AbstractApplicationEventMulticaster()
/*     */   {
/*  55 */     this.defaultRetriever = new ListenerRetriever(false);
/*     */ 
/*  57 */     this.retrieverCache = new ConcurrentHashMap(64);
/*     */   }
/*     */ 
/*     */   public void addApplicationListener(ApplicationListener<?> listener)
/*     */   {
/*  65 */     synchronized (this.defaultRetriever) {
/*  66 */       this.defaultRetriever.applicationListeners.add(listener);
/*  67 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addApplicationListenerBean(String listenerBeanName)
/*     */   {
/*  73 */     synchronized (this.defaultRetriever) {
/*  74 */       this.defaultRetriever.applicationListenerBeans.add(listenerBeanName);
/*  75 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeApplicationListener(ApplicationListener<?> listener)
/*     */   {
/*  81 */     synchronized (this.defaultRetriever) {
/*  82 */       this.defaultRetriever.applicationListeners.remove(listener);
/*  83 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeApplicationListenerBean(String listenerBeanName)
/*     */   {
/*  89 */     synchronized (this.defaultRetriever) {
/*  90 */       this.defaultRetriever.applicationListenerBeans.remove(listenerBeanName);
/*  91 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAllListeners()
/*     */   {
/*  97 */     synchronized (this.defaultRetriever) {
/*  98 */       this.defaultRetriever.applicationListeners.clear();
/*  99 */       this.defaultRetriever.applicationListenerBeans.clear();
/* 100 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 106 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   private BeanFactory getBeanFactory() {
/* 110 */     if (this.beanFactory == null) {
/* 111 */       throw new IllegalStateException("ApplicationEventMulticaster cannot retrieve listener beans because it is not associated with a BeanFactory");
/*     */     }
/*     */ 
/* 114 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   protected Collection<ApplicationListener<?>> getApplicationListeners()
/*     */   {
/* 124 */     synchronized (this.defaultRetriever) {
/* 125 */       return this.defaultRetriever.getApplicationListeners();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Collection<ApplicationListener<?>> getApplicationListeners(ApplicationEvent event)
/*     */   {
/* 138 */     Class eventType = event.getClass();
/* 139 */     Object source = event.getSource();
/* 140 */     Class sourceType = source != null ? source.getClass() : null;
/* 141 */     ListenerCacheKey cacheKey = new ListenerCacheKey(eventType, sourceType);
/* 142 */     ListenerRetriever retriever = (ListenerRetriever)this.retrieverCache.get(cacheKey);
/* 143 */     if (retriever != null) {
/* 144 */       return retriever.getApplicationListeners();
/*     */     }
/*     */ 
/* 147 */     retriever = new ListenerRetriever(true);
/* 148 */     LinkedList allListeners = new LinkedList();
/*     */     Set listeners;
/*     */     Set listenerBeans;
/* 151 */     synchronized (this.defaultRetriever) {
/* 152 */       listeners = new LinkedHashSet(this.defaultRetriever.applicationListeners);
/* 153 */       listenerBeans = new LinkedHashSet(this.defaultRetriever.applicationListenerBeans);
/*     */     }
/* 155 */     for (??? = listeners.iterator(); ???.hasNext(); ) { listener = (ApplicationListener)???.next();
/* 156 */       if (supportsEvent((ApplicationListener)listener, eventType, sourceType)) {
/* 157 */         retriever.applicationListeners.add(listener);
/* 158 */         allListeners.add(listener);
/*     */       }
/*     */     }
/*     */     Object listener;
/*     */     BeanFactory beanFactory;
/* 161 */     if (!listenerBeans.isEmpty()) {
/* 162 */       beanFactory = getBeanFactory();
/* 163 */       for (listener = listenerBeans.iterator(); ((Iterator)listener).hasNext(); ) { String listenerBeanName = (String)((Iterator)listener).next();
/*     */         try {
/* 165 */           ApplicationListener listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 166 */           if ((!allListeners.contains(listener)) && (supportsEvent(listener, eventType, sourceType))) {
/* 167 */             retriever.applicationListenerBeans.add(listenerBeanName);
/* 168 */             allListeners.add(listener);
/*     */           }
/*     */         }
/*     */         catch (NoSuchBeanDefinitionException ex)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 177 */     OrderComparator.sort(allListeners);
/* 178 */     this.retrieverCache.put(cacheKey, retriever);
/* 179 */     return allListeners;
/*     */   }
/*     */ 
/*     */   protected boolean supportsEvent(ApplicationListener<?> listener, Class<? extends ApplicationEvent> eventType, Class<?> sourceType)
/*     */   {
/* 198 */     SmartApplicationListener smartListener = (listener instanceof SmartApplicationListener) ? (SmartApplicationListener)listener : new GenericApplicationListenerAdapter(listener);
/*     */ 
/* 200 */     return (smartListener.supportsEventType(eventType)) && (smartListener.supportsSourceType(sourceType));
/*     */   }
/*     */ 
/*     */   private class ListenerRetriever
/*     */   {
/*     */     public final Set<ApplicationListener<?>> applicationListeners;
/*     */     public final Set<String> applicationListenerBeans;
/*     */     private final boolean preFiltered;
/*     */ 
/*     */     public ListenerRetriever(boolean preFiltered)
/*     */     {
/* 249 */       this.applicationListeners = new LinkedHashSet();
/* 250 */       this.applicationListenerBeans = new LinkedHashSet();
/* 251 */       this.preFiltered = preFiltered;
/*     */     }
/*     */ 
/*     */     public Collection<ApplicationListener<?>> getApplicationListeners() {
/* 255 */       LinkedList allListeners = new LinkedList();
/* 256 */       for (Iterator localIterator = this.applicationListeners.iterator(); localIterator.hasNext(); ) { listener = (ApplicationListener)localIterator.next();
/* 257 */         allListeners.add(listener);
/*     */       }
/*     */       ApplicationListener listener;
/*     */       BeanFactory beanFactory;
/* 259 */       if (!this.applicationListenerBeans.isEmpty()) {
/* 260 */         beanFactory = AbstractApplicationEventMulticaster.this.getBeanFactory();
/* 261 */         for (String listenerBeanName : this.applicationListenerBeans) {
/*     */           try {
/* 263 */             ApplicationListener listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 264 */             if ((this.preFiltered) || (!allListeners.contains(listener))) {
/* 265 */               allListeners.add(listener);
/*     */             }
/*     */           }
/*     */           catch (NoSuchBeanDefinitionException ex)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 274 */       OrderComparator.sort(allListeners);
/* 275 */       return allListeners;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ListenerCacheKey
/*     */   {
/*     */     private final Class<?> eventType;
/*     */     private final Class<?> sourceType;
/*     */ 
/*     */     public ListenerCacheKey(Class<?> eventType, Class<?> sourceType)
/*     */     {
/* 214 */       this.eventType = eventType;
/* 215 */       this.sourceType = sourceType;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 220 */       if (this == other) {
/* 221 */         return true;
/*     */       }
/* 223 */       ListenerCacheKey otherKey = (ListenerCacheKey)other;
/*     */ 
/* 225 */       return (ObjectUtils.nullSafeEquals(this.eventType, otherKey.eventType)) && 
/* 225 */         (ObjectUtils.nullSafeEquals(this.sourceType, otherKey.sourceType));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 230 */       return ObjectUtils.nullSafeHashCode(this.eventType) * 29 + ObjectUtils.nullSafeHashCode(this.sourceType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.AbstractApplicationEventMulticaster
 * JD-Core Version:    0.6.2
 */