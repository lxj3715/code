/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ public class ContextRefreshedEvent extends ApplicationContextEvent
/*    */ {
/*    */   public ContextRefreshedEvent(ApplicationContext source)
/*    */   {
/* 37 */     super(source);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.ContextRefreshedEvent
 * JD-Core Version:    0.6.2
 */