/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ public class ContextStartedEvent extends ApplicationContextEvent
/*    */ {
/*    */   public ContextStartedEvent(ApplicationContext source)
/*    */   {
/* 38 */     super(source);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.ContextStartedEvent
 * JD-Core Version:    0.6.2
 */