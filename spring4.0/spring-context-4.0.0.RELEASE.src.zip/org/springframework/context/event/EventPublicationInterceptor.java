/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ 
/*     */ public class EventPublicationInterceptor
/*     */   implements MethodInterceptor, ApplicationEventPublisherAware, InitializingBean
/*     */ {
/*     */   private Constructor<?> applicationEventClassConstructor;
/*     */   private ApplicationEventPublisher applicationEventPublisher;
/*     */ 
/*     */   public void setApplicationEventClass(Class<?> applicationEventClass)
/*     */   {
/*  66 */     if ((ApplicationEvent.class.equals(applicationEventClass)) || 
/*  67 */       (!ApplicationEvent.class
/*  67 */       .isAssignableFrom(applicationEventClass)))
/*     */     {
/*  68 */       throw new IllegalArgumentException("applicationEventClass needs to extend ApplicationEvent");
/*     */     }
/*     */     try {
/*  71 */       this.applicationEventClassConstructor = applicationEventClass
/*  72 */         .getConstructor(new Class[] { Object.class });
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/*  76 */       throw new IllegalArgumentException("applicationEventClass [" + applicationEventClass
/*  76 */         .getName() + "] does not have the required Object constructor: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher)
/*     */   {
/*  82 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/*  87 */     if (this.applicationEventClassConstructor == null)
/*  88 */       throw new IllegalArgumentException("applicationEventClass is required");
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  95 */     Object retVal = invocation.proceed();
/*     */ 
/*  98 */     ApplicationEvent event = (ApplicationEvent)this.applicationEventClassConstructor
/*  98 */       .newInstance(new Object[] { invocation
/*  98 */       .getThis() });
/*  99 */     this.applicationEventPublisher.publishEvent(event);
/*     */ 
/* 101 */     return retVal;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.EventPublicationInterceptor
 * JD-Core Version:    0.6.2
 */