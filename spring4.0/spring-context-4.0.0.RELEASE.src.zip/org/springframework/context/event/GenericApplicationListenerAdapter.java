/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.GenericTypeResolver;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class GenericApplicationListenerAdapter
/*    */   implements SmartApplicationListener
/*    */ {
/*    */   private final ApplicationListener<ApplicationEvent> delegate;
/*    */ 
/*    */   public GenericApplicationListenerAdapter(ApplicationListener<?> delegate)
/*    */   {
/* 45 */     Assert.notNull(delegate, "Delegate listener must not be null");
/* 46 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   public void onApplicationEvent(ApplicationEvent event)
/*    */   {
/* 52 */     this.delegate.onApplicationEvent(event);
/*    */   }
/*    */ 
/*    */   public boolean supportsEventType(Class<? extends ApplicationEvent> eventType)
/*    */   {
/* 57 */     Class typeArg = GenericTypeResolver.resolveTypeArgument(this.delegate.getClass(), ApplicationListener.class);
/* 58 */     if ((typeArg == null) || (typeArg.equals(ApplicationEvent.class))) {
/* 59 */       Class targetClass = AopUtils.getTargetClass(this.delegate);
/* 60 */       if (targetClass != this.delegate.getClass()) {
/* 61 */         typeArg = GenericTypeResolver.resolveTypeArgument(targetClass, ApplicationListener.class);
/*    */       }
/*    */     }
/* 64 */     return (typeArg == null) || (typeArg.isAssignableFrom(eventType));
/*    */   }
/*    */ 
/*    */   public boolean supportsSourceType(Class<?> sourceType)
/*    */   {
/* 69 */     return true;
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 74 */     return (this.delegate instanceof Ordered) ? ((Ordered)this.delegate).getOrder() : 2147483647;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.GenericApplicationListenerAdapter
 * JD-Core Version:    0.6.2
 */