/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ 
/*     */ public class SourceFilteringListener
/*     */   implements SmartApplicationListener
/*     */ {
/*     */   private final Object source;
/*     */   private SmartApplicationListener delegate;
/*     */ 
/*     */   public SourceFilteringListener(Object source, ApplicationListener<?> delegate)
/*     */   {
/*  49 */     this.source = source;
/*  50 */     this.delegate = ((delegate instanceof SmartApplicationListener) ? (SmartApplicationListener)delegate : new GenericApplicationListenerAdapter(delegate));
/*     */   }
/*     */ 
/*     */   protected SourceFilteringListener(Object source)
/*     */   {
/*  62 */     this.source = source;
/*     */   }
/*     */ 
/*     */   public void onApplicationEvent(ApplicationEvent event)
/*     */   {
/*  68 */     if (event.getSource() == this.source)
/*  69 */       onApplicationEventInternal(event);
/*     */   }
/*     */ 
/*     */   public boolean supportsEventType(Class<? extends ApplicationEvent> eventType)
/*     */   {
/*  75 */     return (this.delegate == null) || (this.delegate.supportsEventType(eventType));
/*     */   }
/*     */ 
/*     */   public boolean supportsSourceType(Class<?> sourceType)
/*     */   {
/*  80 */     return (sourceType != null) && (sourceType.isInstance(this.source));
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/*  85 */     return this.delegate != null ? this.delegate.getOrder() : 2147483647;
/*     */   }
/*     */ 
/*     */   protected void onApplicationEventInternal(ApplicationEvent event)
/*     */   {
/*  96 */     if (this.delegate == null) {
/*  97 */       throw new IllegalStateException("Must specify a delegate object or override the onApplicationEventInternal method");
/*     */     }
/*     */ 
/* 100 */     this.delegate.onApplicationEvent(event);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.SourceFilteringListener
 * JD-Core Version:    0.6.2
 */