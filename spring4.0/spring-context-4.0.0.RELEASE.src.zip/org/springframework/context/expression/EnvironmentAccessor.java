/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.expression.AccessException;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.PropertyAccessor;
/*    */ import org.springframework.expression.TypedValue;
/*    */ 
/*    */ public class EnvironmentAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Class<?>[] getSpecificTargetClasses()
/*    */   {
/* 36 */     return new Class[] { Environment.class };
/*    */   }
/*    */ 
/*    */   public boolean canRead(EvaluationContext context, Object target, String name)
/*    */     throws AccessException
/*    */   {
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */   public TypedValue read(EvaluationContext context, Object target, String name)
/*    */     throws AccessException
/*    */   {
/* 54 */     return new TypedValue(((Environment)target).getProperty(name));
/*    */   }
/*    */ 
/*    */   public boolean canWrite(EvaluationContext context, Object target, String name)
/*    */     throws AccessException
/*    */   {
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */   public void write(EvaluationContext context, Object target, String name, Object newValue)
/*    */     throws AccessException
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.expression.EnvironmentAccessor
 * JD-Core Version:    0.6.2
 */