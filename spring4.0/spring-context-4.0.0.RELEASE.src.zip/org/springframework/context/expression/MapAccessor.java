/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.expression.AccessException;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.PropertyAccessor;
/*    */ import org.springframework.expression.TypedValue;
/*    */ 
/*    */ public class MapAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public boolean canRead(EvaluationContext context, Object target, String name)
/*    */     throws AccessException
/*    */   {
/* 38 */     Map map = (Map)target;
/* 39 */     return map.containsKey(name);
/*    */   }
/*    */ 
/*    */   public TypedValue read(EvaluationContext context, Object target, String name) throws AccessException
/*    */   {
/* 44 */     Map map = (Map)target;
/* 45 */     Object value = map.get(name);
/* 46 */     if ((value == null) && (!map.containsKey(name))) {
/* 47 */       throw new MapAccessException(name);
/*    */     }
/* 49 */     return new TypedValue(value);
/*    */   }
/*    */ 
/*    */   public boolean canWrite(EvaluationContext context, Object target, String name) throws AccessException
/*    */   {
/* 54 */     return true;
/*    */   }
/*    */ 
/*    */   public void write(EvaluationContext context, Object target, String name, Object newValue)
/*    */     throws AccessException
/*    */   {
/* 60 */     Map map = (Map)target;
/* 61 */     map.put(name, newValue);
/*    */   }
/*    */ 
/*    */   public Class<?>[] getSpecificTargetClasses()
/*    */   {
/* 66 */     return new Class[] { Map.class };
/*    */   }
/*    */ 
/*    */   private static class MapAccessException extends AccessException
/*    */   {
/*    */     private final String key;
/*    */ 
/*    */     public MapAccessException(String key)
/*    */     {
/* 80 */       super();
/* 81 */       this.key = key;
/*    */     }
/*    */ 
/*    */     public String getMessage()
/*    */     {
/* 86 */       return "Map does not contain a value for key '" + this.key + "'";
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.expression.MapAccessor
 * JD-Core Version:    0.6.2
 */