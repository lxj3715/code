/*     */ package org.springframework.context.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanExpressionException;
/*     */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*     */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.ParserContext;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.expression.spel.support.StandardTypeConverter;
/*     */ import org.springframework.expression.spel.support.StandardTypeLocator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class StandardBeanExpressionResolver
/*     */   implements BeanExpressionResolver
/*     */ {
/*     */   public static final String DEFAULT_EXPRESSION_PREFIX = "#{";
/*     */   public static final String DEFAULT_EXPRESSION_SUFFIX = "}";
/*  57 */   private String expressionPrefix = "#{";
/*     */ 
/*  59 */   private String expressionSuffix = "}";
/*     */ 
/*  61 */   private ExpressionParser expressionParser = new SpelExpressionParser();
/*     */ 
/*  63 */   private final Map<String, Expression> expressionCache = new ConcurrentHashMap(256);
/*     */ 
/*  65 */   private final Map<BeanExpressionContext, StandardEvaluationContext> evaluationCache = new ConcurrentHashMap(8);
/*     */ 
/*  68 */   private final ParserContext beanExpressionParserContext = new ParserContext()
/*     */   {
/*     */     public boolean isTemplate() {
/*  71 */       return true;
/*     */     }
/*     */ 
/*     */     public String getExpressionPrefix() {
/*  75 */       return StandardBeanExpressionResolver.this.expressionPrefix;
/*     */     }
/*     */ 
/*     */     public String getExpressionSuffix() {
/*  79 */       return StandardBeanExpressionResolver.this.expressionSuffix;
/*     */     }
/*  68 */   };
/*     */ 
/*     */   public void setExpressionPrefix(String expressionPrefix)
/*     */   {
/*  90 */     Assert.hasText(expressionPrefix, "Expression prefix must not be empty");
/*  91 */     this.expressionPrefix = expressionPrefix;
/*     */   }
/*     */ 
/*     */   public void setExpressionSuffix(String expressionSuffix)
/*     */   {
/* 100 */     Assert.hasText(expressionSuffix, "Expression suffix must not be empty");
/* 101 */     this.expressionSuffix = expressionSuffix;
/*     */   }
/*     */ 
/*     */   public void setExpressionParser(ExpressionParser expressionParser)
/*     */   {
/* 110 */     Assert.notNull(expressionParser, "ExpressionParser must not be null");
/* 111 */     this.expressionParser = expressionParser;
/*     */   }
/*     */ 
/*     */   public Object evaluate(String value, BeanExpressionContext evalContext)
/*     */     throws BeansException
/*     */   {
/* 117 */     if (!StringUtils.hasLength(value))
/* 118 */       return value;
/*     */     try
/*     */     {
/* 121 */       Expression expr = (Expression)this.expressionCache.get(value);
/* 122 */       if (expr == null) {
/* 123 */         expr = this.expressionParser.parseExpression(value, this.beanExpressionParserContext);
/* 124 */         this.expressionCache.put(value, expr);
/*     */       }
/* 126 */       StandardEvaluationContext sec = (StandardEvaluationContext)this.evaluationCache.get(evalContext);
/* 127 */       if (sec == null) {
/* 128 */         sec = new StandardEvaluationContext();
/* 129 */         sec.setRootObject(evalContext);
/* 130 */         sec.addPropertyAccessor(new BeanExpressionContextAccessor());
/* 131 */         sec.addPropertyAccessor(new BeanFactoryAccessor());
/* 132 */         sec.addPropertyAccessor(new MapAccessor());
/* 133 */         sec.addPropertyAccessor(new EnvironmentAccessor());
/* 134 */         sec.setBeanResolver(new BeanFactoryResolver(evalContext.getBeanFactory()));
/* 135 */         sec.setTypeLocator(new StandardTypeLocator(evalContext.getBeanFactory().getBeanClassLoader()));
/* 136 */         ConversionService conversionService = evalContext.getBeanFactory().getConversionService();
/* 137 */         if (conversionService != null) {
/* 138 */           sec.setTypeConverter(new StandardTypeConverter(conversionService));
/*     */         }
/* 140 */         customizeEvaluationContext(sec);
/* 141 */         this.evaluationCache.put(evalContext, sec);
/*     */       }
/* 143 */       return expr.getValue(sec);
/*     */     }
/*     */     catch (Exception ex) {
/* 146 */       throw new BeanExpressionException("Expression parsing failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void customizeEvaluationContext(StandardEvaluationContext evalContext)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.expression.StandardBeanExpressionResolver
 * JD-Core Version:    0.6.2
 */