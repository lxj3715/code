/*     */ package org.springframework.context.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.core.NamedInheritableThreadLocal;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ 
/*     */ public abstract class LocaleContextHolder
/*     */ {
/*  46 */   private static final ThreadLocal<LocaleContext> localeContextHolder = new NamedThreadLocal("Locale context");
/*     */ 
/*  49 */   private static final ThreadLocal<LocaleContext> inheritableLocaleContextHolder = new NamedInheritableThreadLocal("Locale context");
/*     */ 
/*     */   public static void resetLocaleContext()
/*     */   {
/*  57 */     localeContextHolder.remove();
/*  58 */     inheritableLocaleContextHolder.remove();
/*     */   }
/*     */ 
/*     */   public static void setLocaleContext(LocaleContext localeContext)
/*     */   {
/*  72 */     setLocaleContext(localeContext, false);
/*     */   }
/*     */ 
/*     */   public static void setLocaleContext(LocaleContext localeContext, boolean inheritable)
/*     */   {
/*  87 */     if (localeContext == null) {
/*  88 */       resetLocaleContext();
/*     */     }
/*  91 */     else if (inheritable) {
/*  92 */       inheritableLocaleContextHolder.set(localeContext);
/*  93 */       localeContextHolder.remove();
/*     */     }
/*     */     else {
/*  96 */       localeContextHolder.set(localeContext);
/*  97 */       inheritableLocaleContextHolder.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static LocaleContext getLocaleContext()
/*     */   {
/* 107 */     LocaleContext localeContext = (LocaleContext)localeContextHolder.get();
/* 108 */     if (localeContext == null) {
/* 109 */       localeContext = (LocaleContext)inheritableLocaleContextHolder.get();
/*     */     }
/* 111 */     return localeContext;
/*     */   }
/*     */ 
/*     */   public static void setLocale(Locale locale)
/*     */   {
/* 125 */     setLocale(locale, false);
/*     */   }
/*     */ 
/*     */   public static void setLocale(Locale locale, boolean inheritable)
/*     */   {
/* 140 */     LocaleContext localeContext = getLocaleContext();
/*     */ 
/* 142 */     TimeZone timeZone = (localeContext instanceof TimeZoneAwareLocaleContext) ? ((TimeZoneAwareLocaleContext)localeContext)
/* 142 */       .getTimeZone() : null;
/* 143 */     if (timeZone != null) {
/* 144 */       localeContext = new SimpleTimeZoneAwareLocaleContext(locale, timeZone);
/*     */     }
/* 146 */     else if (locale != null) {
/* 147 */       localeContext = new SimpleLocaleContext(locale);
/*     */     }
/*     */     else {
/* 150 */       localeContext = null;
/*     */     }
/* 152 */     setLocaleContext(localeContext, inheritable);
/*     */   }
/*     */ 
/*     */   public static Locale getLocale()
/*     */   {
/* 170 */     LocaleContext localeContext = getLocaleContext();
/* 171 */     if (localeContext != null) {
/* 172 */       Locale locale = localeContext.getLocale();
/* 173 */       if (locale != null) {
/* 174 */         return locale;
/*     */       }
/*     */     }
/* 177 */     return Locale.getDefault();
/*     */   }
/*     */ 
/*     */   public static void setTimeZone(TimeZone timeZone)
/*     */   {
/* 191 */     setTimeZone(timeZone, false);
/*     */   }
/*     */ 
/*     */   public static void setTimeZone(TimeZone timeZone, boolean inheritable)
/*     */   {
/* 206 */     LocaleContext localeContext = getLocaleContext();
/* 207 */     Locale locale = localeContext != null ? localeContext.getLocale() : null;
/* 208 */     if (timeZone != null) {
/* 209 */       localeContext = new SimpleTimeZoneAwareLocaleContext(locale, timeZone);
/*     */     }
/* 211 */     else if (locale != null) {
/* 212 */       localeContext = new SimpleLocaleContext(locale);
/*     */     }
/*     */     else {
/* 215 */       localeContext = null;
/*     */     }
/* 217 */     setLocaleContext(localeContext, inheritable);
/*     */   }
/*     */ 
/*     */   public static TimeZone getTimeZone()
/*     */   {
/* 236 */     LocaleContext localeContext = getLocaleContext();
/* 237 */     if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 238 */       TimeZone timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/* 239 */       if (timeZone != null) {
/* 240 */         return timeZone;
/*     */       }
/*     */     }
/* 243 */     return TimeZone.getDefault();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.i18n.LocaleContextHolder
 * JD-Core Version:    0.6.2
 */