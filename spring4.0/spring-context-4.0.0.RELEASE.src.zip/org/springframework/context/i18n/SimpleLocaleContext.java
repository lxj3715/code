/*    */ package org.springframework.context.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class SimpleLocaleContext
/*    */   implements LocaleContext
/*    */ {
/*    */   private final Locale locale;
/*    */ 
/*    */   public SimpleLocaleContext(Locale locale)
/*    */   {
/* 42 */     this.locale = locale;
/*    */   }
/*    */ 
/*    */   public Locale getLocale()
/*    */   {
/* 47 */     return this.locale;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 52 */     return this.locale != null ? this.locale.toString() : "-";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.i18n.SimpleLocaleContext
 * JD-Core Version:    0.6.2
 */