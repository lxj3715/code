/*    */ package org.springframework.context.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ public class SimpleTimeZoneAwareLocaleContext extends SimpleLocaleContext
/*    */   implements TimeZoneAwareLocaleContext
/*    */ {
/*    */   private final TimeZone timeZone;
/*    */ 
/*    */   public SimpleTimeZoneAwareLocaleContext(Locale locale, TimeZone timeZone)
/*    */   {
/* 48 */     super(locale);
/* 49 */     this.timeZone = timeZone;
/*    */   }
/*    */ 
/*    */   public TimeZone getTimeZone()
/*    */   {
/* 54 */     return this.timeZone;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 59 */     return new StringBuilder().append(super.toString()).append(" ").append(this.timeZone != null ? this.timeZone.toString() : "-").toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.i18n.SimpleTimeZoneAwareLocaleContext
 * JD-Core Version:    0.6.2
 */