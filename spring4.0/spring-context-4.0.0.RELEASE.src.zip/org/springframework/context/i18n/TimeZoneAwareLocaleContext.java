package org.springframework.context.i18n;

import java.util.TimeZone;

public abstract interface TimeZoneAwareLocaleContext extends LocaleContext
{
  public abstract TimeZone getTimeZone();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.i18n.TimeZoneAwareLocaleContext
 * JD-Core Version:    0.6.2
 */