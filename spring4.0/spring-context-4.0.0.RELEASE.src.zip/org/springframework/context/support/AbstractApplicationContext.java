/*      */ package org.springframework.context.support;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.DisposableBean;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.support.ResourceEditorRegistrar;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.context.ApplicationEvent;
/*      */ import org.springframework.context.ApplicationEventPublisher;
/*      */ import org.springframework.context.ApplicationEventPublisherAware;
/*      */ import org.springframework.context.ApplicationListener;
/*      */ import org.springframework.context.ConfigurableApplicationContext;
/*      */ import org.springframework.context.EnvironmentAware;
/*      */ import org.springframework.context.HierarchicalMessageSource;
/*      */ import org.springframework.context.LifecycleProcessor;
/*      */ import org.springframework.context.MessageSource;
/*      */ import org.springframework.context.MessageSourceAware;
/*      */ import org.springframework.context.MessageSourceResolvable;
/*      */ import org.springframework.context.NoSuchMessageException;
/*      */ import org.springframework.context.ResourceLoaderAware;
/*      */ import org.springframework.context.event.ApplicationEventMulticaster;
/*      */ import org.springframework.context.event.ContextClosedEvent;
/*      */ import org.springframework.context.event.ContextRefreshedEvent;
/*      */ import org.springframework.context.event.ContextStartedEvent;
/*      */ import org.springframework.context.event.ContextStoppedEvent;
/*      */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*      */ import org.springframework.context.expression.StandardBeanExpressionResolver;
/*      */ import org.springframework.context.weaving.LoadTimeWeaverAware;
/*      */ import org.springframework.context.weaving.LoadTimeWeaverAwareProcessor;
/*      */ import org.springframework.core.convert.ConversionService;
/*      */ import org.springframework.core.env.ConfigurableEnvironment;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.core.env.StandardEnvironment;
/*      */ import org.springframework.core.io.DefaultResourceLoader;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.core.io.ResourceLoader;
/*      */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*      */ import org.springframework.core.io.support.ResourcePatternResolver;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ 
/*      */ public abstract class AbstractApplicationContext extends DefaultResourceLoader
/*      */   implements ConfigurableApplicationContext, DisposableBean
/*      */ {
/*      */   public static final String MESSAGE_SOURCE_BEAN_NAME = "messageSource";
/*      */   public static final String LIFECYCLE_PROCESSOR_BEAN_NAME = "lifecycleProcessor";
/*      */   public static final String APPLICATION_EVENT_MULTICASTER_BEAN_NAME = "applicationEventMulticaster";
/*  153 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */ 
/*  156 */   private String id = ObjectUtils.identityToString(this);
/*      */ 
/*  159 */   private String displayName = ObjectUtils.identityToString(this);
/*      */   private ApplicationContext parent;
/*  165 */   private final List<BeanFactoryPostProcessor> beanFactoryPostProcessors = new ArrayList();
/*      */   private long startupDate;
/*  172 */   private boolean active = false;
/*      */ 
/*  175 */   private boolean closed = false;
/*      */ 
/*  178 */   private final Object activeMonitor = new Object();
/*      */ 
/*  181 */   private final Object startupShutdownMonitor = new Object();
/*      */   private Thread shutdownHook;
/*      */   private ResourcePatternResolver resourcePatternResolver;
/*      */   private LifecycleProcessor lifecycleProcessor;
/*      */   private MessageSource messageSource;
/*      */   private ApplicationEventMulticaster applicationEventMulticaster;
/*  199 */   private Set<ApplicationListener<?>> applicationListeners = new LinkedHashSet();
/*      */   private ConfigurableEnvironment environment;
/*      */ 
/*      */   public AbstractApplicationContext()
/*      */   {
/*  209 */     this.resourcePatternResolver = getResourcePatternResolver();
/*      */   }
/*      */ 
/*      */   public AbstractApplicationContext(ApplicationContext parent)
/*      */   {
/*  217 */     this();
/*  218 */     setParent(parent);
/*      */   }
/*      */ 
/*      */   public void setId(String id)
/*      */   {
/*  234 */     this.id = id;
/*      */   }
/*      */ 
/*      */   public String getId()
/*      */   {
/*  239 */     return this.id;
/*      */   }
/*      */ 
/*      */   public String getApplicationName()
/*      */   {
/*  244 */     return "";
/*      */   }
/*      */ 
/*      */   public void setDisplayName(String displayName)
/*      */   {
/*  253 */     Assert.hasLength(displayName, "Display name must not be empty");
/*  254 */     this.displayName = displayName;
/*      */   }
/*      */ 
/*      */   public String getDisplayName()
/*      */   {
/*  263 */     return this.displayName;
/*      */   }
/*      */ 
/*      */   public ApplicationContext getParent()
/*      */   {
/*  272 */     return this.parent;
/*      */   }
/*      */ 
/*      */   public ConfigurableEnvironment getEnvironment()
/*      */   {
/*  282 */     if (this.environment == null) {
/*  283 */       this.environment = createEnvironment();
/*      */     }
/*  285 */     return this.environment;
/*      */   }
/*      */ 
/*      */   public void setEnvironment(ConfigurableEnvironment environment)
/*      */   {
/*  298 */     this.environment = environment;
/*      */   }
/*      */ 
/*      */   public AutowireCapableBeanFactory getAutowireCapableBeanFactory()
/*      */     throws IllegalStateException
/*      */   {
/*  308 */     return getBeanFactory();
/*      */   }
/*      */ 
/*      */   public long getStartupDate()
/*      */   {
/*  316 */     return this.startupDate;
/*      */   }
/*      */ 
/*      */   public void publishEvent(ApplicationEvent event)
/*      */   {
/*  329 */     Assert.notNull(event, "Event must not be null");
/*  330 */     if (this.logger.isTraceEnabled()) {
/*  331 */       this.logger.trace(new StringBuilder().append("Publishing event in ").append(getDisplayName()).append(": ").append(event).toString());
/*      */     }
/*  333 */     getApplicationEventMulticaster().multicastEvent(event);
/*  334 */     if (this.parent != null)
/*  335 */       this.parent.publishEvent(event);
/*      */   }
/*      */ 
/*      */   ApplicationEventMulticaster getApplicationEventMulticaster()
/*      */     throws IllegalStateException
/*      */   {
/*  345 */     if (this.applicationEventMulticaster == null) {
/*  346 */       throw new IllegalStateException(new StringBuilder().append("ApplicationEventMulticaster not initialized - call 'refresh' before multicasting events via the context: ").append(this).toString());
/*      */     }
/*      */ 
/*  349 */     return this.applicationEventMulticaster;
/*      */   }
/*      */ 
/*      */   LifecycleProcessor getLifecycleProcessor()
/*      */   {
/*  358 */     if (this.lifecycleProcessor == null) {
/*  359 */       throw new IllegalStateException(new StringBuilder().append("LifecycleProcessor not initialized - call 'refresh' before invoking lifecycle methods via the context: ").append(this).toString());
/*      */     }
/*      */ 
/*  362 */     return this.lifecycleProcessor;
/*      */   }
/*      */ 
/*      */   protected ResourcePatternResolver getResourcePatternResolver()
/*      */   {
/*  380 */     return new PathMatchingResourcePatternResolver(this);
/*      */   }
/*      */ 
/*      */   public void setParent(ApplicationContext parent)
/*      */   {
/*  398 */     this.parent = parent;
/*  399 */     if (parent != null) {
/*  400 */       Environment parentEnvironment = parent.getEnvironment();
/*  401 */       if ((parentEnvironment instanceof ConfigurableEnvironment))
/*  402 */         getEnvironment().merge((ConfigurableEnvironment)parentEnvironment);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addBeanFactoryPostProcessor(BeanFactoryPostProcessor beanFactoryPostProcessor)
/*      */   {
/*  409 */     this.beanFactoryPostProcessors.add(beanFactoryPostProcessor);
/*      */   }
/*      */ 
/*      */   public List<BeanFactoryPostProcessor> getBeanFactoryPostProcessors()
/*      */   {
/*  418 */     return this.beanFactoryPostProcessors;
/*      */   }
/*      */ 
/*      */   public void addApplicationListener(ApplicationListener<?> listener)
/*      */   {
/*  423 */     if (this.applicationEventMulticaster != null) {
/*  424 */       this.applicationEventMulticaster.addApplicationListener(listener);
/*      */     }
/*      */     else
/*  427 */       this.applicationListeners.add(listener);
/*      */   }
/*      */ 
/*      */   public Collection<ApplicationListener<?>> getApplicationListeners()
/*      */   {
/*  435 */     return this.applicationListeners;
/*      */   }
/*      */ 
/*      */   protected ConfigurableEnvironment createEnvironment()
/*      */   {
/*  444 */     return new StandardEnvironment();
/*      */   }
/*      */ 
/*      */   public void refresh() throws BeansException, IllegalStateException
/*      */   {
/*  449 */     synchronized (this.startupShutdownMonitor)
/*      */     {
/*  451 */       prepareRefresh();
/*      */ 
/*  454 */       ConfigurableListableBeanFactory beanFactory = obtainFreshBeanFactory();
/*      */ 
/*  457 */       prepareBeanFactory(beanFactory);
/*      */       try
/*      */       {
/*  461 */         postProcessBeanFactory(beanFactory);
/*      */ 
/*  464 */         invokeBeanFactoryPostProcessors(beanFactory);
/*      */ 
/*  467 */         registerBeanPostProcessors(beanFactory);
/*      */ 
/*  470 */         initMessageSource();
/*      */ 
/*  473 */         initApplicationEventMulticaster();
/*      */ 
/*  476 */         onRefresh();
/*      */ 
/*  479 */         registerListeners();
/*      */ 
/*  482 */         finishBeanFactoryInitialization(beanFactory);
/*      */ 
/*  485 */         finishRefresh();
/*      */       }
/*      */       catch (BeansException ex)
/*      */       {
/*  490 */         destroyBeans();
/*      */ 
/*  493 */         cancelRefresh(ex);
/*      */ 
/*  496 */         throw ex;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void prepareRefresh()
/*      */   {
/*  506 */     this.startupDate = System.currentTimeMillis();
/*      */ 
/*  508 */     synchronized (this.activeMonitor) {
/*  509 */       this.active = true;
/*      */     }
/*      */ 
/*  512 */     if (this.logger.isInfoEnabled()) {
/*  513 */       this.logger.info(new StringBuilder().append("Refreshing ").append(this).toString());
/*      */     }
/*      */ 
/*  517 */     initPropertySources();
/*      */ 
/*  521 */     getEnvironment().validateRequiredProperties();
/*      */   }
/*      */ 
/*      */   protected void initPropertySources()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected ConfigurableListableBeanFactory obtainFreshBeanFactory()
/*      */   {
/*  540 */     refreshBeanFactory();
/*  541 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  542 */     if (this.logger.isDebugEnabled()) {
/*  543 */       this.logger.debug(new StringBuilder().append("Bean factory for ").append(getDisplayName()).append(": ").append(beanFactory).toString());
/*      */     }
/*  545 */     return beanFactory;
/*      */   }
/*      */ 
/*      */   protected void prepareBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  555 */     beanFactory.setBeanClassLoader(getClassLoader());
/*  556 */     beanFactory.setBeanExpressionResolver(new StandardBeanExpressionResolver());
/*  557 */     beanFactory.addPropertyEditorRegistrar(new ResourceEditorRegistrar(this, getEnvironment()));
/*      */ 
/*  560 */     beanFactory.addBeanPostProcessor(new ApplicationContextAwareProcessor(this));
/*  561 */     beanFactory.ignoreDependencyInterface(ResourceLoaderAware.class);
/*  562 */     beanFactory.ignoreDependencyInterface(ApplicationEventPublisherAware.class);
/*  563 */     beanFactory.ignoreDependencyInterface(MessageSourceAware.class);
/*  564 */     beanFactory.ignoreDependencyInterface(ApplicationContextAware.class);
/*  565 */     beanFactory.ignoreDependencyInterface(EnvironmentAware.class);
/*      */ 
/*  569 */     beanFactory.registerResolvableDependency(BeanFactory.class, beanFactory);
/*  570 */     beanFactory.registerResolvableDependency(ResourceLoader.class, this);
/*  571 */     beanFactory.registerResolvableDependency(ApplicationEventPublisher.class, this);
/*  572 */     beanFactory.registerResolvableDependency(ApplicationContext.class, this);
/*      */ 
/*  575 */     if (beanFactory.containsBean("loadTimeWeaver")) {
/*  576 */       beanFactory.addBeanPostProcessor(new LoadTimeWeaverAwareProcessor(beanFactory));
/*      */ 
/*  578 */       beanFactory.setTempClassLoader(new ContextTypeMatchClassLoader(beanFactory.getBeanClassLoader()));
/*      */     }
/*      */ 
/*  582 */     if (!beanFactory.containsLocalBean("environment")) {
/*  583 */       beanFactory.registerSingleton("environment", getEnvironment());
/*      */     }
/*  585 */     if (!beanFactory.containsLocalBean("systemProperties")) {
/*  586 */       beanFactory.registerSingleton("systemProperties", getEnvironment().getSystemProperties());
/*      */     }
/*  588 */     if (!beanFactory.containsLocalBean("systemEnvironment"))
/*  589 */       beanFactory.registerSingleton("systemEnvironment", getEnvironment().getSystemEnvironment());
/*      */   }
/*      */ 
/*      */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void invokeBeanFactoryPostProcessors(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  609 */     PostProcessorRegistrationDelegate.invokeBeanFactoryPostProcessors(beanFactory, getBeanFactoryPostProcessors());
/*      */   }
/*      */ 
/*      */   protected void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  618 */     PostProcessorRegistrationDelegate.registerBeanPostProcessors(beanFactory, this);
/*      */   }
/*      */ 
/*      */   protected void initMessageSource()
/*      */   {
/*  626 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  627 */     if (beanFactory.containsLocalBean("messageSource")) {
/*  628 */       this.messageSource = ((MessageSource)beanFactory.getBean("messageSource", MessageSource.class));
/*      */ 
/*  630 */       if ((this.parent != null) && ((this.messageSource instanceof HierarchicalMessageSource))) {
/*  631 */         HierarchicalMessageSource hms = (HierarchicalMessageSource)this.messageSource;
/*  632 */         if (hms.getParentMessageSource() == null)
/*      */         {
/*  635 */           hms.setParentMessageSource(getInternalParentMessageSource());
/*      */         }
/*      */       }
/*  638 */       if (this.logger.isDebugEnabled()) {
/*  639 */         this.logger.debug(new StringBuilder().append("Using MessageSource [").append(this.messageSource).append("]").toString());
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  644 */       DelegatingMessageSource dms = new DelegatingMessageSource();
/*  645 */       dms.setParentMessageSource(getInternalParentMessageSource());
/*  646 */       this.messageSource = dms;
/*  647 */       beanFactory.registerSingleton("messageSource", this.messageSource);
/*  648 */       if (this.logger.isDebugEnabled())
/*  649 */         this.logger.debug(new StringBuilder().append("Unable to locate MessageSource with name 'messageSource': using default [").append(this.messageSource).append("]").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initApplicationEventMulticaster()
/*      */   {
/*  661 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  662 */     if (beanFactory.containsLocalBean("applicationEventMulticaster")) {
/*  663 */       this.applicationEventMulticaster = 
/*  664 */         ((ApplicationEventMulticaster)beanFactory
/*  664 */         .getBean("applicationEventMulticaster", ApplicationEventMulticaster.class));
/*      */ 
/*  665 */       if (this.logger.isDebugEnabled())
/*  666 */         this.logger.debug(new StringBuilder().append("Using ApplicationEventMulticaster [").append(this.applicationEventMulticaster).append("]").toString());
/*      */     }
/*      */     else
/*      */     {
/*  670 */       this.applicationEventMulticaster = new SimpleApplicationEventMulticaster(beanFactory);
/*  671 */       beanFactory.registerSingleton("applicationEventMulticaster", this.applicationEventMulticaster);
/*  672 */       if (this.logger.isDebugEnabled())
/*  673 */         this.logger.debug(new StringBuilder().append("Unable to locate ApplicationEventMulticaster with name 'applicationEventMulticaster': using default [").append(this.applicationEventMulticaster).append("]").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initLifecycleProcessor()
/*      */   {
/*  686 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  687 */     if (beanFactory.containsLocalBean("lifecycleProcessor")) {
/*  688 */       this.lifecycleProcessor = 
/*  689 */         ((LifecycleProcessor)beanFactory
/*  689 */         .getBean("lifecycleProcessor", LifecycleProcessor.class));
/*      */ 
/*  690 */       if (this.logger.isDebugEnabled())
/*  691 */         this.logger.debug(new StringBuilder().append("Using LifecycleProcessor [").append(this.lifecycleProcessor).append("]").toString());
/*      */     }
/*      */     else
/*      */     {
/*  695 */       DefaultLifecycleProcessor defaultProcessor = new DefaultLifecycleProcessor();
/*  696 */       defaultProcessor.setBeanFactory(beanFactory);
/*  697 */       this.lifecycleProcessor = defaultProcessor;
/*  698 */       beanFactory.registerSingleton("lifecycleProcessor", this.lifecycleProcessor);
/*  699 */       if (this.logger.isDebugEnabled())
/*  700 */         this.logger.debug(new StringBuilder().append("Unable to locate LifecycleProcessor with name 'lifecycleProcessor': using default [").append(this.lifecycleProcessor).append("]").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void onRefresh()
/*      */     throws BeansException
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void registerListeners()
/*      */   {
/*  724 */     for (Iterator localIterator = getApplicationListeners().iterator(); localIterator.hasNext(); ) { listener = (ApplicationListener)localIterator.next();
/*  725 */       getApplicationEventMulticaster().addApplicationListener(listener);
/*      */     }
/*      */     ApplicationListener listener;
/*  729 */     String[] listenerBeanNames = getBeanNamesForType(ApplicationListener.class, true, false);
/*  730 */     for (String lisName : listenerBeanNames)
/*  731 */       getApplicationEventMulticaster().addApplicationListenerBean(lisName);
/*      */   }
/*      */ 
/*      */   protected void finishBeanFactoryInitialization(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  741 */     if ((beanFactory.containsBean("conversionService")) && 
/*  742 */       (beanFactory
/*  742 */       .isTypeMatch("conversionService", ConversionService.class)))
/*      */     {
/*  743 */       beanFactory.setConversionService(
/*  744 */         (ConversionService)beanFactory
/*  744 */         .getBean("conversionService", ConversionService.class));
/*      */     }
/*      */ 
/*  748 */     String[] weaverAwareNames = beanFactory.getBeanNamesForType(LoadTimeWeaverAware.class, false, false);
/*  749 */     for (String weaverAwareName : weaverAwareNames) {
/*  750 */       getBean(weaverAwareName);
/*      */     }
/*      */ 
/*  754 */     beanFactory.setTempClassLoader(null);
/*      */ 
/*  757 */     beanFactory.freezeConfiguration();
/*      */ 
/*  760 */     beanFactory.preInstantiateSingletons();
/*      */   }
/*      */ 
/*      */   protected void finishRefresh()
/*      */   {
/*  770 */     initLifecycleProcessor();
/*      */ 
/*  773 */     getLifecycleProcessor().onRefresh();
/*      */ 
/*  776 */     publishEvent(new ContextRefreshedEvent(this));
/*      */ 
/*  779 */     LiveBeansView.registerApplicationContext(this);
/*      */   }
/*      */ 
/*      */   protected void cancelRefresh(BeansException ex)
/*      */   {
/*  788 */     synchronized (this.activeMonitor) {
/*  789 */       this.active = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerShutdownHook()
/*      */   {
/*  804 */     if (this.shutdownHook == null)
/*      */     {
/*  806 */       this.shutdownHook = new Thread()
/*      */       {
/*      */         public void run() {
/*  809 */           AbstractApplicationContext.this.doClose();
/*      */         }
/*      */       };
/*  812 */       Runtime.getRuntime().addShutdownHook(this.shutdownHook);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void destroy()
/*      */   {
/*  828 */     close();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*  840 */     synchronized (this.startupShutdownMonitor) {
/*  841 */       doClose();
/*      */ 
/*  844 */       if (this.shutdownHook != null)
/*      */         try {
/*  846 */           Runtime.getRuntime().removeShutdownHook(this.shutdownHook);
/*      */         }
/*      */         catch (IllegalStateException ex)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void doClose()
/*      */   {
/*      */     boolean actuallyClose;
/*  866 */     synchronized (this.activeMonitor) {
/*  867 */       actuallyClose = (this.active) && (!this.closed);
/*  868 */       this.closed = true;
/*      */     }
/*      */ 
/*  871 */     if (actuallyClose) {
/*  872 */       if (this.logger.isInfoEnabled()) {
/*  873 */         this.logger.info(new StringBuilder().append("Closing ").append(this).toString());
/*      */       }
/*      */ 
/*  876 */       LiveBeansView.unregisterApplicationContext(this);
/*      */       try
/*      */       {
/*  880 */         publishEvent(new ContextClosedEvent(this));
/*      */       }
/*      */       catch (Throwable ex) {
/*  883 */         this.logger.warn("Exception thrown from ApplicationListener handling ContextClosedEvent", ex);
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  888 */         getLifecycleProcessor().onClose();
/*      */       }
/*      */       catch (Throwable ex) {
/*  891 */         this.logger.warn("Exception thrown from LifecycleProcessor on context close", ex);
/*      */       }
/*      */ 
/*  895 */       destroyBeans();
/*      */ 
/*  898 */       closeBeanFactory();
/*      */ 
/*  901 */       onClose();
/*      */ 
/*  903 */       synchronized (this.activeMonitor) {
/*  904 */         this.active = false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void destroyBeans()
/*      */   {
/*  921 */     getBeanFactory().destroySingletons();
/*      */   }
/*      */ 
/*      */   protected void onClose()
/*      */   {
/*      */   }
/*      */ 
/*      */   public boolean isActive()
/*      */   {
/*  938 */     synchronized (this.activeMonitor) {
/*  939 */       return this.active;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void assertBeanFactoryActive()
/*      */   {
/*  953 */     synchronized (this.activeMonitor) {
/*  954 */       if (!this.active) {
/*  955 */         if (this.closed) {
/*  956 */           throw new IllegalStateException(new StringBuilder().append(getDisplayName()).append(" has been closed already").toString());
/*      */         }
/*      */ 
/*  959 */         throw new IllegalStateException(new StringBuilder().append(getDisplayName()).append(" has not been refreshed yet").toString());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public Object getBean(String name)
/*      */     throws BeansException
/*      */   {
/*  972 */     assertBeanFactoryActive();
/*  973 */     return getBeanFactory().getBean(name);
/*      */   }
/*      */ 
/*      */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException
/*      */   {
/*  978 */     assertBeanFactoryActive();
/*  979 */     return getBeanFactory().getBean(name, requiredType);
/*      */   }
/*      */ 
/*      */   public <T> T getBean(Class<T> requiredType) throws BeansException
/*      */   {
/*  984 */     assertBeanFactoryActive();
/*  985 */     return getBeanFactory().getBean(requiredType);
/*      */   }
/*      */ 
/*      */   public Object getBean(String name, Object[] args) throws BeansException
/*      */   {
/*  990 */     assertBeanFactoryActive();
/*  991 */     return getBeanFactory().getBean(name, args);
/*      */   }
/*      */ 
/*      */   public boolean containsBean(String name)
/*      */   {
/*  996 */     return getBeanFactory().containsBean(name);
/*      */   }
/*      */ 
/*      */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException
/*      */   {
/* 1001 */     assertBeanFactoryActive();
/* 1002 */     return getBeanFactory().isSingleton(name);
/*      */   }
/*      */ 
/*      */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException
/*      */   {
/* 1007 */     assertBeanFactoryActive();
/* 1008 */     return getBeanFactory().isPrototype(name);
/*      */   }
/*      */ 
/*      */   public boolean isTypeMatch(String name, Class<?> targetType) throws NoSuchBeanDefinitionException
/*      */   {
/* 1013 */     assertBeanFactoryActive();
/* 1014 */     return getBeanFactory().isTypeMatch(name, targetType);
/*      */   }
/*      */ 
/*      */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException
/*      */   {
/* 1019 */     assertBeanFactoryActive();
/* 1020 */     return getBeanFactory().getType(name);
/*      */   }
/*      */ 
/*      */   public String[] getAliases(String name)
/*      */   {
/* 1025 */     return getBeanFactory().getAliases(name);
/*      */   }
/*      */ 
/*      */   public boolean containsBeanDefinition(String beanName)
/*      */   {
/* 1035 */     return getBeanFactory().containsBeanDefinition(beanName);
/*      */   }
/*      */ 
/*      */   public int getBeanDefinitionCount()
/*      */   {
/* 1040 */     return getBeanFactory().getBeanDefinitionCount();
/*      */   }
/*      */ 
/*      */   public String[] getBeanDefinitionNames()
/*      */   {
/* 1045 */     return getBeanFactory().getBeanDefinitionNames();
/*      */   }
/*      */ 
/*      */   public String[] getBeanNamesForType(Class<?> type)
/*      */   {
/* 1050 */     assertBeanFactoryActive();
/* 1051 */     return getBeanFactory().getBeanNamesForType(type);
/*      */   }
/*      */ 
/*      */   public String[] getBeanNamesForType(Class<?> type, boolean includeNonSingletons, boolean allowEagerInit)
/*      */   {
/* 1056 */     assertBeanFactoryActive();
/* 1057 */     return getBeanFactory().getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */   public <T> Map<String, T> getBeansOfType(Class<T> type) throws BeansException
/*      */   {
/* 1062 */     assertBeanFactoryActive();
/* 1063 */     return getBeanFactory().getBeansOfType(type);
/*      */   }
/*      */ 
/*      */   public <T> Map<String, T> getBeansOfType(Class<T> type, boolean includeNonSingletons, boolean allowEagerInit)
/*      */     throws BeansException
/*      */   {
/* 1070 */     assertBeanFactoryActive();
/* 1071 */     return getBeanFactory().getBeansOfType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */   public String[] getBeanNamesForAnnotation(Class<? extends Annotation> annotationType)
/*      */   {
/* 1076 */     assertBeanFactoryActive();
/* 1077 */     return getBeanFactory().getBeanNamesForAnnotation(annotationType);
/*      */   }
/*      */ 
/*      */   public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> annotationType)
/*      */     throws BeansException
/*      */   {
/* 1084 */     assertBeanFactoryActive();
/* 1085 */     return getBeanFactory().getBeansWithAnnotation(annotationType);
/*      */   }
/*      */ 
/*      */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType)
/*      */     throws NoSuchBeanDefinitionException
/*      */   {
/* 1092 */     assertBeanFactoryActive();
/* 1093 */     return getBeanFactory().findAnnotationOnBean(beanName, annotationType);
/*      */   }
/*      */ 
/*      */   public BeanFactory getParentBeanFactory()
/*      */   {
/* 1103 */     return getParent();
/*      */   }
/*      */ 
/*      */   public boolean containsLocalBean(String name)
/*      */   {
/* 1108 */     return getBeanFactory().containsLocalBean(name);
/*      */   }
/*      */ 
/*      */   protected BeanFactory getInternalParentBeanFactory()
/*      */   {
/* 1118 */     return (getParent() instanceof DisposableBean) ? 
/* 1118 */       ((DisposableBean)getParent()).getBeanFactory() : getParent();
/*      */   }
/*      */ 
/*      */   public String getMessage(String code, Object[] args, String defaultMessage, Locale locale)
/*      */   {
/* 1128 */     return getMessageSource().getMessage(code, args, defaultMessage, locale);
/*      */   }
/*      */ 
/*      */   public String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException
/*      */   {
/* 1133 */     return getMessageSource().getMessage(code, args, locale);
/*      */   }
/*      */ 
/*      */   public String getMessage(MessageSourceResolvable resolvable, Locale locale) throws NoSuchMessageException
/*      */   {
/* 1138 */     return getMessageSource().getMessage(resolvable, locale);
/*      */   }
/*      */ 
/*      */   private MessageSource getMessageSource()
/*      */     throws IllegalStateException
/*      */   {
/* 1147 */     if (this.messageSource == null) {
/* 1148 */       throw new IllegalStateException(new StringBuilder().append("MessageSource not initialized - call 'refresh' before accessing messages via the context: ").append(this).toString());
/*      */     }
/*      */ 
/* 1151 */     return this.messageSource;
/*      */   }
/*      */ 
/*      */   protected MessageSource getInternalParentMessageSource()
/*      */   {
/* 1160 */     return (getParent() instanceof AbstractApplicationContext) ? 
/* 1160 */       ((AbstractApplicationContext)getParent()).messageSource : getParent();
/*      */   }
/*      */ 
/*      */   public Resource[] getResources(String locationPattern)
/*      */     throws IOException
/*      */   {
/* 1170 */     return this.resourcePatternResolver.getResources(locationPattern);
/*      */   }
/*      */ 
/*      */   public void start()
/*      */   {
/* 1180 */     getLifecycleProcessor().start();
/* 1181 */     publishEvent(new ContextStartedEvent(this));
/*      */   }
/*      */ 
/*      */   public void stop()
/*      */   {
/* 1186 */     getLifecycleProcessor().stop();
/* 1187 */     publishEvent(new ContextStoppedEvent(this));
/*      */   }
/*      */ 
/*      */   public boolean isRunning()
/*      */   {
/* 1192 */     return getLifecycleProcessor().isRunning();
/*      */   }
/*      */ 
/*      */   protected abstract void refreshBeanFactory()
/*      */     throws BeansException, IllegalStateException;
/*      */ 
/*      */   protected abstract void closeBeanFactory();
/*      */ 
/*      */   public abstract ConfigurableListableBeanFactory getBeanFactory()
/*      */     throws IllegalStateException;
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1241 */     StringBuilder sb = new StringBuilder(getDisplayName());
/* 1242 */     sb.append(": startup date [").append(new Date(getStartupDate()));
/* 1243 */     sb.append("]; ");
/* 1244 */     ApplicationContext parent = getParent();
/* 1245 */     if (parent == null) {
/* 1246 */       sb.append("root of context hierarchy");
/*      */     }
/*      */     else {
/* 1249 */       sb.append("parent: ").append(parent.getDisplayName());
/*      */     }
/* 1251 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  148 */     ContextClosedEvent.class.getName();
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.AbstractApplicationContext
 * JD-Core Version:    0.6.2
 */