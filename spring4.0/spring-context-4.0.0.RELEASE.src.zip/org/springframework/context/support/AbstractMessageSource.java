/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import org.springframework.context.HierarchicalMessageSource;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class AbstractMessageSource extends MessageSourceSupport
/*     */   implements HierarchicalMessageSource
/*     */ {
/*     */   private MessageSource parentMessageSource;
/*     */   private Properties commonMessages;
/*  70 */   private boolean useCodeAsDefaultMessage = false;
/*     */ 
/*     */   public void setParentMessageSource(MessageSource parent)
/*     */   {
/*  75 */     this.parentMessageSource = parent;
/*     */   }
/*     */ 
/*     */   public MessageSource getParentMessageSource()
/*     */   {
/*  80 */     return this.parentMessageSource;
/*     */   }
/*     */ 
/*     */   public void setCommonMessages(Properties commonMessages)
/*     */   {
/*  90 */     this.commonMessages = commonMessages;
/*     */   }
/*     */ 
/*     */   protected Properties getCommonMessages()
/*     */   {
/*  97 */     return this.commonMessages;
/*     */   }
/*     */ 
/*     */   public void setUseCodeAsDefaultMessage(boolean useCodeAsDefaultMessage)
/*     */   {
/* 118 */     this.useCodeAsDefaultMessage = useCodeAsDefaultMessage;
/*     */   }
/*     */ 
/*     */   protected boolean isUseCodeAsDefaultMessage()
/*     */   {
/* 130 */     return this.useCodeAsDefaultMessage;
/*     */   }
/*     */ 
/*     */   public final String getMessage(String code, Object[] args, String defaultMessage, Locale locale)
/*     */   {
/* 136 */     String msg = getMessageInternal(code, args, locale);
/* 137 */     if (msg != null) {
/* 138 */       return msg;
/*     */     }
/* 140 */     if (defaultMessage == null) {
/* 141 */       String fallback = getDefaultMessage(code);
/* 142 */       if (fallback != null) {
/* 143 */         return fallback;
/*     */       }
/*     */     }
/* 146 */     return renderDefaultMessage(defaultMessage, args, locale);
/*     */   }
/*     */ 
/*     */   public final String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException
/*     */   {
/* 151 */     String msg = getMessageInternal(code, args, locale);
/* 152 */     if (msg != null) {
/* 153 */       return msg;
/*     */     }
/* 155 */     String fallback = getDefaultMessage(code);
/* 156 */     if (fallback != null) {
/* 157 */       return fallback;
/*     */     }
/* 159 */     throw new NoSuchMessageException(code, locale);
/*     */   }
/*     */ 
/*     */   public final String getMessage(MessageSourceResolvable resolvable, Locale locale)
/*     */     throws NoSuchMessageException
/*     */   {
/* 166 */     String[] codes = resolvable.getCodes();
/* 167 */     if (codes == null) {
/* 168 */       codes = new String[0];
/*     */     }
/* 170 */     for (String code : codes) {
/* 171 */       String msg = getMessageInternal(code, resolvable.getArguments(), locale);
/* 172 */       if (msg != null) {
/* 173 */         return msg;
/*     */       }
/*     */     }
/* 176 */     String defaultMessage = resolvable.getDefaultMessage();
/* 177 */     if (defaultMessage != null) {
/* 178 */       return renderDefaultMessage(defaultMessage, resolvable.getArguments(), locale);
/*     */     }
/* 180 */     if (codes.length > 0) {
/* 181 */       String fallback = getDefaultMessage(codes[0]);
/* 182 */       if (fallback != null) {
/* 183 */         return fallback;
/*     */       }
/*     */     }
/* 186 */     throw new NoSuchMessageException(codes.length > 0 ? codes[(codes.length - 1)] : null, locale);
/*     */   }
/*     */ 
/*     */   protected String getMessageInternal(String code, Object[] args, Locale locale)
/*     */   {
/* 205 */     if (code == null) {
/* 206 */       return null;
/*     */     }
/* 208 */     if (locale == null) {
/* 209 */       locale = Locale.getDefault();
/*     */     }
/* 211 */     Object[] argsToUse = args;
/*     */ 
/* 213 */     if ((!isAlwaysUseMessageFormat()) && (ObjectUtils.isEmpty(args)))
/*     */     {
/* 218 */       String message = resolveCodeWithoutArguments(code, locale);
/* 219 */       if (message != null) {
/* 220 */         return message;
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 228 */       argsToUse = resolveArguments(args, locale);
/*     */ 
/* 230 */       MessageFormat messageFormat = resolveCode(code, locale);
/* 231 */       if (messageFormat != null) {
/* 232 */         synchronized (messageFormat) {
/* 233 */           return messageFormat.format(argsToUse);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 239 */     Properties commonMessages = getCommonMessages();
/* 240 */     if (commonMessages != null) {
/* 241 */       String commonMessage = commonMessages.getProperty(code);
/* 242 */       if (commonMessage != null) {
/* 243 */         return formatMessage(commonMessage, args, locale);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 248 */     return getMessageFromParent(code, argsToUse, locale);
/*     */   }
/*     */ 
/*     */   protected String getMessageFromParent(String code, Object[] args, Locale locale)
/*     */   {
/* 261 */     MessageSource parent = getParentMessageSource();
/* 262 */     if (parent != null) {
/* 263 */       if ((parent instanceof AbstractMessageSource))
/*     */       {
/* 266 */         return ((AbstractMessageSource)parent).getMessageInternal(code, args, locale);
/*     */       }
/*     */ 
/* 270 */       return parent.getMessage(code, args, null, locale);
/*     */     }
/*     */ 
/* 274 */     return null;
/*     */   }
/*     */ 
/*     */   protected String getDefaultMessage(String code)
/*     */   {
/* 288 */     if (isUseCodeAsDefaultMessage()) {
/* 289 */       return code;
/*     */     }
/* 291 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object[] resolveArguments(Object[] args, Locale locale)
/*     */   {
/* 305 */     if (args == null) {
/* 306 */       return new Object[0];
/*     */     }
/* 308 */     List resolvedArgs = new ArrayList(args.length);
/* 309 */     for (Object arg : args) {
/* 310 */       if ((arg instanceof MessageSourceResolvable)) {
/* 311 */         resolvedArgs.add(getMessage((MessageSourceResolvable)arg, locale));
/*     */       }
/*     */       else {
/* 314 */         resolvedArgs.add(arg);
/*     */       }
/*     */     }
/* 317 */     return resolvedArgs.toArray(new Object[resolvedArgs.size()]);
/*     */   }
/*     */ 
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale)
/*     */   {
/* 338 */     MessageFormat messageFormat = resolveCode(code, locale);
/* 339 */     if (messageFormat != null) {
/* 340 */       synchronized (messageFormat) {
/* 341 */         return messageFormat.format(new Object[0]);
/*     */       }
/*     */     }
/* 344 */     return null;
/*     */   }
/*     */ 
/*     */   protected abstract MessageFormat resolveCode(String paramString, Locale paramLocale);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.AbstractMessageSource
 * JD-Core Version:    0.6.2
 */