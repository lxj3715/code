/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.DecoratingClassLoader;
/*     */ import org.springframework.core.OverridingClassLoader;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ class ContextTypeMatchClassLoader extends DecoratingClassLoader
/*     */   implements SmartClassLoader
/*     */ {
/*     */   private static Method findLoadedClassMethod;
/*  54 */   private final Map<String, byte[]> bytesCache = new HashMap();
/*     */ 
/*     */   public ContextTypeMatchClassLoader(ClassLoader parent)
/*     */   {
/*  58 */     super(parent);
/*     */   }
/*     */ 
/*     */   public Class<?> loadClass(String name) throws ClassNotFoundException
/*     */   {
/*  63 */     return new ContextOverridingClassLoader(getParent()).loadClass(name);
/*     */   }
/*     */ 
/*     */   public boolean isClassReloadable(Class<?> clazz)
/*     */   {
/*  68 */     return clazz.getClassLoader() instanceof ContextOverridingClassLoader;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  45 */       findLoadedClassMethod = ClassLoader.class.getDeclaredMethod("findLoadedClass", new Class[] { String.class });
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/*  48 */       throw new IllegalStateException("Invalid [java.lang.ClassLoader] class: no 'findLoadedClass' method defined!");
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ContextOverridingClassLoader extends OverridingClassLoader
/*     */   {
/*     */     public ContextOverridingClassLoader(ClassLoader parent)
/*     */     {
/*  79 */       super();
/*     */     }
/*     */ 
/*     */     protected boolean isEligibleForOverriding(String className)
/*     */     {
/*  84 */       if ((isExcluded(className)) || (ContextTypeMatchClassLoader.this.isExcluded(className))) {
/*  85 */         return false;
/*     */       }
/*  87 */       ReflectionUtils.makeAccessible(ContextTypeMatchClassLoader.findLoadedClassMethod);
/*  88 */       ClassLoader parent = getParent();
/*  89 */       while (parent != null) {
/*  90 */         if (ReflectionUtils.invokeMethod(ContextTypeMatchClassLoader.findLoadedClassMethod, parent, new Object[] { className }) != null) {
/*  91 */           return false;
/*     */         }
/*  93 */         parent = parent.getParent();
/*     */       }
/*  95 */       return true;
/*     */     }
/*     */ 
/*     */     protected Class<?> loadClassForOverriding(String name) throws ClassNotFoundException
/*     */     {
/* 100 */       byte[] bytes = (byte[])ContextTypeMatchClassLoader.this.bytesCache.get(name);
/* 101 */       if (bytes == null) {
/* 102 */         bytes = loadBytesForClass(name);
/* 103 */         if (bytes != null) {
/* 104 */           ContextTypeMatchClassLoader.this.bytesCache.put(name, bytes);
/*     */         }
/*     */         else {
/* 107 */           return null;
/*     */         }
/*     */       }
/* 110 */       return defineClass(name, bytes, 0, bytes.length);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.ContextTypeMatchClassLoader
 * JD-Core Version:    0.6.2
 */