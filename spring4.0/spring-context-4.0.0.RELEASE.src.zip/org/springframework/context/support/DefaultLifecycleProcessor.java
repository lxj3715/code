/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.Lifecycle;
/*     */ import org.springframework.context.LifecycleProcessor;
/*     */ import org.springframework.context.Phased;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class DefaultLifecycleProcessor
/*     */   implements LifecycleProcessor, BeanFactoryAware
/*     */ {
/*     */   private final Log logger;
/*     */   private volatile long timeoutPerShutdownPhase;
/*     */   private volatile boolean running;
/*     */   private volatile ConfigurableListableBeanFactory beanFactory;
/*     */ 
/*     */   public DefaultLifecycleProcessor()
/*     */   {
/*  53 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  55 */     this.timeoutPerShutdownPhase = 30000L;
/*     */   }
/*     */ 
/*     */   public void setTimeoutPerShutdownPhase(long timeoutPerShutdownPhase)
/*     */   {
/*  68 */     this.timeoutPerShutdownPhase = timeoutPerShutdownPhase;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  73 */     Assert.isInstanceOf(ConfigurableListableBeanFactory.class, beanFactory);
/*  74 */     this.beanFactory = ((ConfigurableListableBeanFactory)beanFactory);
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*  91 */     startBeans(false);
/*  92 */     this.running = true;
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 106 */     stopBeans();
/* 107 */     this.running = false;
/*     */   }
/*     */ 
/*     */   public void onRefresh()
/*     */   {
/* 112 */     startBeans(true);
/* 113 */     this.running = true;
/*     */   }
/*     */ 
/*     */   public void onClose()
/*     */   {
/* 118 */     stopBeans();
/* 119 */     this.running = false;
/*     */   }
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/* 124 */     return this.running;
/*     */   }
/*     */ 
/*     */   private void startBeans(boolean autoStartupOnly)
/*     */   {
/* 131 */     Map lifecycleBeans = getLifecycleBeans();
/* 132 */     Map phases = new HashMap();
/* 133 */     for (Iterator localIterator = lifecycleBeans.entrySet().iterator(); localIterator.hasNext(); ) { entry = (Map.Entry)localIterator.next();
/* 134 */       Lifecycle bean = (Lifecycle)entry.getValue();
/* 135 */       if ((!autoStartupOnly) || (((bean instanceof SmartLifecycle)) && (((SmartLifecycle)bean).isAutoStartup()))) {
/* 136 */         int phase = getPhase(bean);
/* 137 */         LifecycleGroup group = (LifecycleGroup)phases.get(Integer.valueOf(phase));
/* 138 */         if (group == null) {
/* 139 */           group = new LifecycleGroup(phase, this.timeoutPerShutdownPhase, lifecycleBeans, autoStartupOnly);
/* 140 */           phases.put(Integer.valueOf(phase), group);
/*     */         }
/* 142 */         group.add((String)entry.getKey(), bean);
/*     */       }
/*     */     }
/*     */     Map.Entry entry;
/* 145 */     if (phases.size() > 0) {
/* 146 */       Object keys = new ArrayList(phases.keySet());
/* 147 */       Collections.sort((List)keys);
/* 148 */       for (Integer key : (List)keys)
/* 149 */         ((LifecycleGroup)phases.get(key)).start();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void doStart(Map<String, ? extends Lifecycle> lifecycleBeans, String beanName, boolean autoStartupOnly)
/*     */   {
/* 161 */     Lifecycle bean = (Lifecycle)lifecycleBeans.remove(beanName);
/* 162 */     if ((bean != null) && (!equals(bean))) {
/* 163 */       String[] dependenciesForBean = this.beanFactory.getDependenciesForBean(beanName);
/* 164 */       for (String dependency : dependenciesForBean) {
/* 165 */         doStart(lifecycleBeans, dependency, autoStartupOnly);
/*     */       }
/* 167 */       if ((!bean.isRunning()) && ((!autoStartupOnly) || (!(bean instanceof SmartLifecycle)) || 
/* 168 */         (((SmartLifecycle)bean)
/* 168 */         .isAutoStartup()))) {
/* 169 */         if (this.logger.isDebugEnabled())
/* 170 */           this.logger.debug("Starting bean '" + beanName + "' of type [" + bean.getClass() + "]");
/*     */         try
/*     */         {
/* 173 */           bean.start();
/*     */         }
/*     */         catch (Throwable ex) {
/* 176 */           throw new ApplicationContextException("Failed to start bean '" + beanName + "'", ex);
/*     */         }
/* 178 */         if (this.logger.isDebugEnabled())
/* 179 */           this.logger.debug("Successfully started bean '" + beanName + "'");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void stopBeans()
/*     */   {
/* 186 */     Map lifecycleBeans = getLifecycleBeans();
/* 187 */     Map phases = new HashMap();
/* 188 */     for (Iterator localIterator = lifecycleBeans.entrySet().iterator(); localIterator.hasNext(); ) { entry = (Map.Entry)localIterator.next();
/* 189 */       Lifecycle bean = (Lifecycle)entry.getValue();
/* 190 */       int shutdownOrder = getPhase(bean);
/* 191 */       LifecycleGroup group = (LifecycleGroup)phases.get(Integer.valueOf(shutdownOrder));
/* 192 */       if (group == null) {
/* 193 */         group = new LifecycleGroup(shutdownOrder, this.timeoutPerShutdownPhase, lifecycleBeans, false);
/* 194 */         phases.put(Integer.valueOf(shutdownOrder), group);
/*     */       }
/* 196 */       group.add((String)entry.getKey(), bean);
/*     */     }
/*     */     Map.Entry entry;
/* 198 */     if (phases.size() > 0) {
/* 199 */       Object keys = new ArrayList(phases.keySet());
/* 200 */       Collections.sort((List)keys, Collections.reverseOrder());
/* 201 */       for (Integer key : (List)keys)
/* 202 */         ((LifecycleGroup)phases.get(key)).stop();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void doStop(Map<String, ? extends Lifecycle> lifecycleBeans, final String beanName, final CountDownLatch latch, final Set<String> countDownBeanNames)
/*     */   {
/* 216 */     Lifecycle bean = (Lifecycle)lifecycleBeans.remove(beanName);
/* 217 */     if (bean != null) {
/* 218 */       String[] dependentBeans = this.beanFactory.getDependentBeans(beanName);
/* 219 */       for (String dependentBean : dependentBeans)
/* 220 */         doStop(lifecycleBeans, dependentBean, latch, countDownBeanNames);
/*     */       try
/*     */       {
/* 223 */         if (bean.isRunning()) {
/* 224 */           if ((bean instanceof SmartLifecycle)) {
/* 225 */             if (this.logger.isDebugEnabled()) {
/* 226 */               this.logger.debug("Asking bean '" + beanName + "' of type [" + bean.getClass() + "] to stop");
/*     */             }
/* 228 */             countDownBeanNames.add(beanName);
/* 229 */             ((SmartLifecycle)bean).stop(new Runnable()
/*     */             {
/*     */               public void run() {
/* 232 */                 latch.countDown();
/* 233 */                 countDownBeanNames.remove(beanName);
/* 234 */                 if (DefaultLifecycleProcessor.this.logger.isDebugEnabled())
/* 235 */                   DefaultLifecycleProcessor.this.logger.debug("Bean '" + beanName + "' completed its stop procedure");
/*     */               }
/*     */             });
/*     */           }
/*     */           else
/*     */           {
/* 241 */             if (this.logger.isDebugEnabled()) {
/* 242 */               this.logger.debug("Stopping bean '" + beanName + "' of type [" + bean.getClass() + "]");
/*     */             }
/* 244 */             bean.stop();
/* 245 */             if (this.logger.isDebugEnabled()) {
/* 246 */               this.logger.debug("Successfully stopped bean '" + beanName + "'");
/*     */             }
/*     */           }
/*     */         }
/* 250 */         else if ((bean instanceof SmartLifecycle))
/*     */         {
/* 252 */           latch.countDown();
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 256 */         if (this.logger.isWarnEnabled())
/* 257 */           this.logger.warn("Failed to stop bean '" + beanName + "'", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Map<String, Lifecycle> getLifecycleBeans()
/*     */   {
/* 272 */     Map beans = new LinkedHashMap();
/* 273 */     String[] beanNames = this.beanFactory.getBeanNamesForType(Lifecycle.class, false, false);
/* 274 */     for (String beanName : beanNames) {
/* 275 */       String beanNameToRegister = BeanFactoryUtils.transformedBeanName(beanName);
/* 276 */       boolean isFactoryBean = this.beanFactory.isFactoryBean(beanNameToRegister);
/* 277 */       String beanNameToCheck = isFactoryBean ? "&" + beanName : beanName;
/* 278 */       if (((this.beanFactory.containsSingleton(beanNameToRegister)) && ((!isFactoryBean) || 
/* 279 */         (Lifecycle.class
/* 279 */         .isAssignableFrom(this.beanFactory
/* 279 */         .getType(beanNameToCheck))))) || 
/* 280 */         (SmartLifecycle.class
/* 280 */         .isAssignableFrom(this.beanFactory
/* 280 */         .getType(beanNameToCheck))))
/*     */       {
/* 281 */         Lifecycle bean = (Lifecycle)this.beanFactory.getBean(beanNameToCheck, Lifecycle.class);
/* 282 */         if (bean != this) {
/* 283 */           beans.put(beanNameToRegister, bean);
/*     */         }
/*     */       }
/*     */     }
/* 287 */     return beans;
/*     */   }
/*     */ 
/*     */   protected int getPhase(Lifecycle bean)
/*     */   {
/* 300 */     return (bean instanceof Phased) ? ((Phased)bean).getPhase() : 0;
/*     */   }
/*     */ 
/*     */   private class LifecycleGroupMember
/*     */     implements Comparable<LifecycleGroupMember>
/*     */   {
/*     */     private final String name;
/*     */     private final Lifecycle bean;
/*     */ 
/*     */     LifecycleGroupMember(String name, Lifecycle bean)
/*     */     {
/* 395 */       this.name = name;
/* 396 */       this.bean = bean;
/*     */     }
/*     */ 
/*     */     public int compareTo(LifecycleGroupMember other)
/*     */     {
/* 401 */       int thisOrder = DefaultLifecycleProcessor.this.getPhase(this.bean);
/* 402 */       int otherOrder = DefaultLifecycleProcessor.this.getPhase(other.bean);
/* 403 */       return thisOrder < otherOrder ? -1 : thisOrder == otherOrder ? 0 : 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class LifecycleGroup
/*     */   {
/* 310 */     private final List<DefaultLifecycleProcessor.LifecycleGroupMember> members = new ArrayList();
/*     */     private final int phase;
/*     */     private final long timeout;
/*     */     private final Map<String, ? extends Lifecycle> lifecycleBeans;
/*     */     private final boolean autoStartupOnly;
/*     */     private volatile int smartMemberCount;
/*     */ 
/*     */     public LifecycleGroup(long phase, Map<String, ? extends Lifecycle> arg4, boolean lifecycleBeans)
/*     */     {
/* 323 */       this.phase = phase;
/* 324 */       this.timeout = timeout;
/* 325 */       this.lifecycleBeans = lifecycleBeans;
/* 326 */       this.autoStartupOnly = autoStartupOnly;
/*     */     }
/*     */ 
/*     */     public void add(String name, Lifecycle bean) {
/* 330 */       if ((bean instanceof SmartLifecycle)) {
/* 331 */         this.smartMemberCount += 1;
/*     */       }
/* 333 */       this.members.add(new DefaultLifecycleProcessor.LifecycleGroupMember(DefaultLifecycleProcessor.this, name, bean));
/*     */     }
/*     */ 
/*     */     public void start() {
/* 337 */       if (this.members.isEmpty()) {
/* 338 */         return;
/*     */       }
/* 340 */       if (DefaultLifecycleProcessor.this.logger.isInfoEnabled()) {
/* 341 */         DefaultLifecycleProcessor.this.logger.info(new StringBuilder().append("Starting beans in phase ").append(this.phase).toString());
/*     */       }
/* 343 */       Collections.sort(this.members);
/* 344 */       for (DefaultLifecycleProcessor.LifecycleGroupMember member : this.members)
/* 345 */         if (this.lifecycleBeans.containsKey(member.name))
/* 346 */           DefaultLifecycleProcessor.this.doStart(this.lifecycleBeans, member.name, this.autoStartupOnly);
/*     */     }
/*     */ 
/*     */     public void stop()
/*     */     {
/* 352 */       if (this.members.isEmpty()) {
/* 353 */         return;
/*     */       }
/* 355 */       if (DefaultLifecycleProcessor.this.logger.isInfoEnabled()) {
/* 356 */         DefaultLifecycleProcessor.this.logger.info(new StringBuilder().append("Stopping beans in phase ").append(this.phase).toString());
/*     */       }
/* 358 */       Collections.sort(this.members, Collections.reverseOrder());
/* 359 */       CountDownLatch latch = new CountDownLatch(this.smartMemberCount);
/* 360 */       Set countDownBeanNames = Collections.synchronizedSet(new LinkedHashSet());
/* 361 */       for (DefaultLifecycleProcessor.LifecycleGroupMember member : this.members)
/* 362 */         if (this.lifecycleBeans.containsKey(member.name)) {
/* 363 */           DefaultLifecycleProcessor.this.doStop(this.lifecycleBeans, member.name, latch, countDownBeanNames);
/*     */         }
/* 365 */         else if ((member.bean instanceof SmartLifecycle))
/*     */         {
/* 367 */           latch.countDown();
/*     */         }
/*     */       try
/*     */       {
/* 371 */         latch.await(this.timeout, TimeUnit.MILLISECONDS);
/* 372 */         if ((latch.getCount() > 0L) && (!countDownBeanNames.isEmpty()) && (DefaultLifecycleProcessor.this.logger.isWarnEnabled())) {
/* 373 */           DefaultLifecycleProcessor.this.logger.warn(new StringBuilder().append("Failed to shut down ").append(countDownBeanNames.size()).append(" bean")
/* 374 */             .append(countDownBeanNames
/* 374 */             .size() > 1 ? "s" : "").append(" with phase value ").append(this.phase).append(" within timeout of ").append(this.timeout).append(": ").append(countDownBeanNames).toString());
/*     */         }
/*     */       }
/*     */       catch (InterruptedException ex)
/*     */       {
/* 379 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.DefaultLifecycleProcessor
 * JD-Core Version:    0.6.2
 */