/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class GenericApplicationContext extends AbstractApplicationContext
/*     */   implements BeanDefinitionRegistry
/*     */ {
/*     */   private final DefaultListableBeanFactory beanFactory;
/*     */   private ResourceLoader resourceLoader;
/*  92 */   private boolean refreshed = false;
/*     */ 
/*     */   public GenericApplicationContext()
/*     */   {
/* 101 */     this.beanFactory = new DefaultListableBeanFactory();
/*     */   }
/*     */ 
/*     */   public GenericApplicationContext(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 111 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 112 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public GenericApplicationContext(ApplicationContext parent)
/*     */   {
/* 122 */     this();
/* 123 */     setParent(parent);
/*     */   }
/*     */ 
/*     */   public GenericApplicationContext(DefaultListableBeanFactory beanFactory, ApplicationContext parent)
/*     */   {
/* 134 */     this(beanFactory);
/* 135 */     setParent(parent);
/*     */   }
/*     */ 
/*     */   public void setParent(ApplicationContext parent)
/*     */   {
/* 146 */     super.setParent(parent);
/* 147 */     this.beanFactory.setParentBeanFactory(getInternalParentBeanFactory());
/*     */   }
/*     */ 
/*     */   public void setId(String id)
/*     */   {
/* 152 */     super.setId(id);
/*     */   }
/*     */ 
/*     */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding)
/*     */   {
/* 162 */     this.beanFactory.setAllowBeanDefinitionOverriding(allowBeanDefinitionOverriding);
/*     */   }
/*     */ 
/*     */   public void setAllowCircularReferences(boolean allowCircularReferences)
/*     */   {
/* 173 */     this.beanFactory.setAllowCircularReferences(allowCircularReferences);
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 195 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public Resource getResource(String location)
/*     */   {
/* 206 */     if (this.resourceLoader != null) {
/* 207 */       return this.resourceLoader.getResource(location);
/*     */     }
/* 209 */     return super.getResource(location);
/*     */   }
/*     */ 
/*     */   public Resource[] getResources(String locationPattern)
/*     */     throws IOException
/*     */   {
/* 220 */     if ((this.resourceLoader instanceof ResourcePatternResolver)) {
/* 221 */       return ((ResourcePatternResolver)this.resourceLoader).getResources(locationPattern);
/*     */     }
/* 223 */     return super.getResources(locationPattern);
/*     */   }
/*     */ 
/*     */   protected final void refreshBeanFactory()
/*     */     throws IllegalStateException
/*     */   {
/* 238 */     if (this.refreshed) {
/* 239 */       throw new IllegalStateException("GenericApplicationContext does not support multiple refresh attempts: just call 'refresh' once");
/*     */     }
/*     */ 
/* 242 */     this.beanFactory.setSerializationId(getId());
/* 243 */     this.refreshed = true;
/*     */   }
/*     */ 
/*     */   protected void cancelRefresh(BeansException ex)
/*     */   {
/* 248 */     this.beanFactory.setSerializationId(null);
/* 249 */     super.cancelRefresh(ex);
/*     */   }
/*     */ 
/*     */   protected final void closeBeanFactory()
/*     */   {
/* 258 */     this.beanFactory.setSerializationId(null);
/*     */   }
/*     */ 
/*     */   public final ConfigurableListableBeanFactory getBeanFactory()
/*     */   {
/* 267 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   public final DefaultListableBeanFactory getDefaultListableBeanFactory()
/*     */   {
/* 279 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   public void registerBeanDefinition(String beanName, BeanDefinition beanDefinition)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 291 */     this.beanFactory.registerBeanDefinition(beanName, beanDefinition);
/*     */   }
/*     */ 
/*     */   public void removeBeanDefinition(String beanName) throws NoSuchBeanDefinitionException
/*     */   {
/* 296 */     this.beanFactory.removeBeanDefinition(beanName);
/*     */   }
/*     */ 
/*     */   public BeanDefinition getBeanDefinition(String beanName) throws NoSuchBeanDefinitionException
/*     */   {
/* 301 */     return this.beanFactory.getBeanDefinition(beanName);
/*     */   }
/*     */ 
/*     */   public boolean isBeanNameInUse(String beanName)
/*     */   {
/* 306 */     return this.beanFactory.isBeanNameInUse(beanName);
/*     */   }
/*     */ 
/*     */   public void registerAlias(String beanName, String alias)
/*     */   {
/* 311 */     this.beanFactory.registerAlias(beanName, alias);
/*     */   }
/*     */ 
/*     */   public void removeAlias(String alias)
/*     */   {
/* 316 */     this.beanFactory.removeAlias(alias);
/*     */   }
/*     */ 
/*     */   public boolean isAlias(String beanName)
/*     */   {
/* 321 */     return this.beanFactory.isAlias(beanName);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.GenericApplicationContext
 * JD-Core Version:    0.6.2
 */