/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.lang.GroovySystem;
/*     */ import groovy.lang.MetaClass;
/*     */ import groovy.lang.MetaClassRegistry;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.groovy.GroovyBeanDefinitionReader;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ public class GenericGroovyApplicationContext extends GenericApplicationContext
/*     */   implements GroovyObject
/*     */ {
/* 106 */   private final GroovyBeanDefinitionReader reader = new GroovyBeanDefinitionReader(this);
/*     */ 
/* 108 */   private final BeanWrapper contextWrapper = new BeanWrapperImpl(this);
/*     */ 
/* 110 */   private MetaClass metaClass = GroovySystem.getMetaClassRegistry().getMetaClass(getClass());
/*     */ 
/*     */   public GenericGroovyApplicationContext()
/*     */   {
/*     */   }
/*     */ 
/*     */   public GenericGroovyApplicationContext(Resource[] resources)
/*     */   {
/* 126 */     load(resources);
/* 127 */     refresh();
/*     */   }
/*     */ 
/*     */   public GenericGroovyApplicationContext(String[] resourceLocations)
/*     */   {
/* 136 */     load(resourceLocations);
/* 137 */     refresh();
/*     */   }
/*     */ 
/*     */   public GenericGroovyApplicationContext(Class<?> relativeClass, String[] resourceNames)
/*     */   {
/* 148 */     load(relativeClass, resourceNames);
/* 149 */     refresh();
/*     */   }
/*     */ 
/*     */   public final GroovyBeanDefinitionReader getReader()
/*     */   {
/* 161 */     return this.reader;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(ConfigurableEnvironment environment)
/*     */   {
/* 170 */     super.setEnvironment(environment);
/* 171 */     this.reader.setEnvironment(getEnvironment());
/*     */   }
/*     */ 
/*     */   public void load(Resource[] resources)
/*     */   {
/* 179 */     this.reader.loadBeanDefinitions(resources);
/*     */   }
/*     */ 
/*     */   public void load(String[] resourceLocations)
/*     */   {
/* 187 */     this.reader.loadBeanDefinitions(resourceLocations);
/*     */   }
/*     */ 
/*     */   public void load(Class<?> relativeClass, String[] resourceNames)
/*     */   {
/* 197 */     Resource[] resources = new Resource[resourceNames.length];
/* 198 */     for (int i = 0; i < resourceNames.length; i++) {
/* 199 */       resources[i] = new ClassPathResource(resourceNames[i], relativeClass);
/*     */     }
/* 201 */     load(resources);
/*     */   }
/*     */ 
/*     */   public void setMetaClass(MetaClass metaClass)
/*     */   {
/* 208 */     this.metaClass = metaClass;
/*     */   }
/*     */ 
/*     */   public MetaClass getMetaClass() {
/* 212 */     return this.metaClass;
/*     */   }
/*     */ 
/*     */   public Object invokeMethod(String name, Object args) {
/* 216 */     return this.metaClass.invokeMethod(this, name, args);
/*     */   }
/*     */ 
/*     */   public void setProperty(String property, Object newValue) {
/* 220 */     if ((newValue instanceof BeanDefinition)) {
/* 221 */       registerBeanDefinition(property, (BeanDefinition)newValue);
/*     */     }
/*     */     else
/* 224 */       this.metaClass.setProperty(this, property, newValue);
/*     */   }
/*     */ 
/*     */   public Object getProperty(String property)
/*     */   {
/* 229 */     if (containsBean(property)) {
/* 230 */       return getBean(property);
/*     */     }
/* 232 */     if (this.contextWrapper.isReadableProperty(property)) {
/* 233 */       return this.contextWrapper.getPropertyValue(property);
/*     */     }
/* 235 */     throw new NoSuchBeanDefinitionException(property);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.GenericGroovyApplicationContext
 * JD-Core Version:    0.6.2
 */