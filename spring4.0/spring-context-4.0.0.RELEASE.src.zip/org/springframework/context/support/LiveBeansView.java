/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class LiveBeansView
/*     */   implements LiveBeansViewMBean, ApplicationContextAware
/*     */ {
/*     */   public static final String MBEAN_DOMAIN_PROPERTY_NAME = "spring.liveBeansView.mbeanDomain";
/*     */   public static final String MBEAN_APPLICATION_KEY = "application";
/*  56 */   private static final Set<ConfigurableApplicationContext> applicationContexts = new LinkedHashSet();
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */ 
/*     */   static void registerApplicationContext(ConfigurableApplicationContext applicationContext)
/*     */   {
/*  60 */     String mbeanDomain = applicationContext.getEnvironment().getProperty("spring.liveBeansView.mbeanDomain");
/*  61 */     if (mbeanDomain != null)
/*  62 */       synchronized (applicationContexts) {
/*  63 */         if (applicationContexts.isEmpty()) {
/*     */           try {
/*  65 */             MBeanServer server = ManagementFactory.getPlatformMBeanServer();
/*  66 */             server.registerMBean(new LiveBeansView(), new ObjectName(mbeanDomain, "application", applicationContext
/*  67 */               .getApplicationName()));
/*     */           }
/*     */           catch (Exception ex) {
/*  70 */             throw new ApplicationContextException("Failed to register LiveBeansView MBean", ex);
/*     */           }
/*     */         }
/*  73 */         applicationContexts.add(applicationContext);
/*     */       }
/*     */   }
/*     */ 
/*     */   static void unregisterApplicationContext(ConfigurableApplicationContext applicationContext)
/*     */   {
/*  79 */     synchronized (applicationContexts) {
/*  80 */       if ((applicationContexts.remove(applicationContext)) && (applicationContexts.isEmpty()))
/*     */         try {
/*  82 */           MBeanServer server = ManagementFactory.getPlatformMBeanServer();
/*  83 */           String mbeanDomain = applicationContext.getEnvironment().getProperty("spring.liveBeansView.mbeanDomain");
/*  84 */           server.unregisterMBean(new ObjectName(mbeanDomain, "application", applicationContext.getApplicationName()));
/*     */         }
/*     */         catch (Exception ex) {
/*  87 */           throw new ApplicationContextException("Failed to unregister LiveBeansView MBean", ex);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/*  98 */     Assert.isTrue(applicationContext instanceof ConfigurableApplicationContext, "ApplicationContext does not implement ConfigurableApplicationContext");
/*     */ 
/* 100 */     this.applicationContext = ((ConfigurableApplicationContext)applicationContext);
/*     */   }
/*     */ 
/*     */   public String getSnapshotAsJson()
/*     */   {
/*     */     Set contexts;
/*     */     Set contexts;
/* 112 */     if (this.applicationContext != null) {
/* 113 */       contexts = Collections.singleton(this.applicationContext);
/*     */     }
/*     */     else {
/* 116 */       contexts = findApplicationContexts();
/*     */     }
/* 118 */     return generateJson(contexts);
/*     */   }
/*     */ 
/*     */   protected String generateJson(Set<ConfigurableApplicationContext> contexts)
/*     */   {
/* 133 */     StringBuilder result = new StringBuilder("[\n");
/* 134 */     for (Iterator it = contexts.iterator(); it.hasNext(); ) {
/* 135 */       ConfigurableApplicationContext context = (ConfigurableApplicationContext)it.next();
/* 136 */       result.append("{\n\"context\": \"").append(context.getId()).append("\",\n");
/* 137 */       if (context.getParent() != null) {
/* 138 */         result.append("\"parent\": \"").append(context.getParent().getId()).append("\",\n");
/*     */       }
/*     */       else {
/* 141 */         result.append("\"parent\": null,\n");
/*     */       }
/* 143 */       result.append("\"beans\": [\n");
/* 144 */       ConfigurableListableBeanFactory bf = context.getBeanFactory();
/* 145 */       String[] beanNames = bf.getBeanDefinitionNames();
/* 146 */       for (int i = 0; i < beanNames.length; i++) {
/* 147 */         String beanName = beanNames[i];
/* 148 */         BeanDefinition bd = bf.getBeanDefinition(beanName);
/* 149 */         if ((bd.getRole() != 2) && (
/* 150 */           (!bd
/* 150 */           .isLazyInit()) || (bf.containsSingleton(beanName)))) {
/* 151 */           result.append("{\n\"bean\": \"").append(beanName).append("\",\n");
/* 152 */           String scope = bd.getScope();
/* 153 */           if (!StringUtils.hasText(scope)) {
/* 154 */             scope = "singleton";
/*     */           }
/* 156 */           result.append("\"scope\": \"").append(scope).append("\",\n");
/* 157 */           Class beanType = bf.getType(beanName);
/* 158 */           if (beanType != null) {
/* 159 */             result.append("\"type\": \"").append(beanType.getName()).append("\",\n");
/*     */           }
/*     */           else {
/* 162 */             result.append("\"type\": null,\n");
/*     */           }
/* 164 */           String resource = StringUtils.replace(bd.getResourceDescription(), "\\", "/");
/* 165 */           result.append("\"resource\": \"").append(resource).append("\",\n");
/* 166 */           result.append("\"dependencies\": [");
/* 167 */           String[] dependencies = bf.getDependenciesForBean(beanName);
/* 168 */           if (dependencies.length > 0) {
/* 169 */             result.append("\"");
/*     */           }
/* 171 */           result.append(StringUtils.arrayToDelimitedString(dependencies, "\", \""));
/* 172 */           if (dependencies.length > 0) {
/* 173 */             result.append("\"");
/*     */           }
/* 175 */           result.append("]\n}");
/* 176 */           if (i < beanNames.length - 1) {
/* 177 */             result.append(",\n");
/*     */           }
/*     */         }
/*     */       }
/* 181 */       result.append("]\n");
/* 182 */       result.append("}");
/* 183 */       if (it.hasNext()) {
/* 184 */         result.append(",\n");
/*     */       }
/*     */     }
/* 187 */     result.append("]");
/* 188 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected Set<ConfigurableApplicationContext> findApplicationContexts()
/*     */   {
/* 197 */     synchronized (applicationContexts) {
/* 198 */       return new LinkedHashSet(applicationContexts);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.LiveBeansView
 * JD-Core Version:    0.6.2
 */