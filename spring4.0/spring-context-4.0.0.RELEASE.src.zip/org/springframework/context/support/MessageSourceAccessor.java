/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ 
/*     */ public class MessageSourceAccessor
/*     */ {
/*     */   private final MessageSource messageSource;
/*     */   private final Locale defaultLocale;
/*     */ 
/*     */   public MessageSourceAccessor(MessageSource messageSource)
/*     */   {
/*  50 */     this.messageSource = messageSource;
/*  51 */     this.defaultLocale = null;
/*     */   }
/*     */ 
/*     */   public MessageSourceAccessor(MessageSource messageSource, Locale defaultLocale)
/*     */   {
/*  60 */     this.messageSource = messageSource;
/*  61 */     this.defaultLocale = defaultLocale;
/*     */   }
/*     */ 
/*     */   protected Locale getDefaultLocale()
/*     */   {
/*  73 */     return this.defaultLocale != null ? this.defaultLocale : LocaleContextHolder.getLocale();
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, String defaultMessage)
/*     */   {
/*  83 */     return this.messageSource.getMessage(code, null, defaultMessage, getDefaultLocale());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, String defaultMessage, Locale locale)
/*     */   {
/*  94 */     return this.messageSource.getMessage(code, null, defaultMessage, locale);
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Object[] args, String defaultMessage)
/*     */   {
/* 105 */     return this.messageSource.getMessage(code, args, defaultMessage, getDefaultLocale());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Object[] args, String defaultMessage, Locale locale)
/*     */   {
/* 117 */     return this.messageSource.getMessage(code, args, defaultMessage, locale);
/*     */   }
/*     */ 
/*     */   public String getMessage(String code)
/*     */     throws NoSuchMessageException
/*     */   {
/* 127 */     return this.messageSource.getMessage(code, null, getDefaultLocale());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Locale locale)
/*     */     throws NoSuchMessageException
/*     */   {
/* 138 */     return this.messageSource.getMessage(code, null, locale);
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Object[] args)
/*     */     throws NoSuchMessageException
/*     */   {
/* 149 */     return this.messageSource.getMessage(code, args, getDefaultLocale());
/*     */   }
/*     */ 
/*     */   public String getMessage(String code, Object[] args, Locale locale)
/*     */     throws NoSuchMessageException
/*     */   {
/* 161 */     return this.messageSource.getMessage(code, args, locale);
/*     */   }
/*     */ 
/*     */   public String getMessage(MessageSourceResolvable resolvable)
/*     */     throws NoSuchMessageException
/*     */   {
/* 172 */     return this.messageSource.getMessage(resolvable, getDefaultLocale());
/*     */   }
/*     */ 
/*     */   public String getMessage(MessageSourceResolvable resolvable, Locale locale)
/*     */     throws NoSuchMessageException
/*     */   {
/* 184 */     return this.messageSource.getMessage(resolvable, locale);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.MessageSourceAccessor
 * JD-Core Version:    0.6.2
 */