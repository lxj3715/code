/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.ApplicationEventMulticaster;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ 
/*     */ class PostProcessorRegistrationDelegate
/*     */ {
/*     */   public static void invokeBeanFactoryPostProcessors(ConfigurableListableBeanFactory beanFactory, List<BeanFactoryPostProcessor> beanFactoryPostProcessors)
/*     */   {
/*  57 */     Set processedBeans = new HashSet();
/*     */ 
/*  59 */     if ((beanFactory instanceof BeanDefinitionRegistry)) {
/*  60 */       BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/*  61 */       List regularPostProcessors = new LinkedList();
/*  62 */       List registryPostProcessors = new LinkedList();
/*     */ 
/*  65 */       for (BeanFactoryPostProcessor postProcessor : beanFactoryPostProcessors) {
/*  66 */         if ((postProcessor instanceof BeanDefinitionRegistryPostProcessor)) {
/*  67 */           registryPostProcessor = (BeanDefinitionRegistryPostProcessor)postProcessor;
/*     */ 
/*  69 */           registryPostProcessor.postProcessBeanDefinitionRegistry(registry);
/*  70 */           registryPostProcessors.add(registryPostProcessor);
/*     */         }
/*     */         else {
/*  73 */           regularPostProcessors.add(postProcessor);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  82 */       String[] postProcessorNames = beanFactory
/*  82 */         .getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/*     */ 
/*  85 */       priorityOrderedPostProcessors = new ArrayList();
/*  86 */       BeanDefinitionRegistryPostProcessor registryPostProcessor = postProcessorNames; int i = registryPostProcessor.length; for (Object localObject1 = 0; localObject1 < i; localObject1++) { ppName = registryPostProcessor[localObject1];
/*  87 */         if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/*  88 */           priorityOrderedPostProcessors.add(beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class));
/*  89 */           processedBeans.add(ppName);
/*     */         }
/*     */       }
/*  92 */       OrderComparator.sort(priorityOrderedPostProcessors);
/*  93 */       registryPostProcessors.addAll(priorityOrderedPostProcessors);
/*  94 */       invokeBeanDefinitionRegistryPostProcessors(priorityOrderedPostProcessors, registry);
/*     */ 
/*  97 */       postProcessorNames = beanFactory.getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/*  98 */       orderedPostProcessors = new ArrayList();
/*  99 */       String[] arrayOfString1 = postProcessorNames; localObject1 = arrayOfString1.length;
/*     */       String ppName;
/*  99 */       for (String ppName = 0; ppName < localObject1; ppName++) { ppName = arrayOfString1[ppName];
/* 100 */         if ((!processedBeans.contains(ppName)) && (beanFactory.isTypeMatch(ppName, Ordered.class))) {
/* 101 */           orderedPostProcessors.add(beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class));
/* 102 */           processedBeans.add(ppName);
/*     */         }
/*     */       }
/* 105 */       OrderComparator.sort(orderedPostProcessors);
/* 106 */       registryPostProcessors.addAll(orderedPostProcessors);
/* 107 */       invokeBeanDefinitionRegistryPostProcessors(orderedPostProcessors, registry);
/*     */ 
/* 110 */       reiterate = true;
/* 111 */       while (reiterate) {
/* 112 */         reiterate = false;
/* 113 */         postProcessorNames = beanFactory.getBeanNamesForType(BeanDefinitionRegistryPostProcessor.class, true, false);
/* 114 */         localObject1 = postProcessorNames; ppName = localObject1.length; for (ppName = 0; ppName < ppName; ppName++) { String ppName = localObject1[ppName];
/* 115 */           if (!processedBeans.contains(ppName)) {
/* 116 */             BeanDefinitionRegistryPostProcessor pp = (BeanDefinitionRegistryPostProcessor)beanFactory.getBean(ppName, BeanDefinitionRegistryPostProcessor.class);
/* 117 */             registryPostProcessors.add(pp);
/* 118 */             processedBeans.add(ppName);
/* 119 */             pp.postProcessBeanDefinitionRegistry(registry);
/* 120 */             reiterate = true;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 126 */       invokeBeanFactoryPostProcessors(registryPostProcessors, beanFactory);
/* 127 */       invokeBeanFactoryPostProcessors(regularPostProcessors, beanFactory);
/*     */     }
/*     */     else
/*     */     {
/* 132 */       invokeBeanFactoryPostProcessors(beanFactoryPostProcessors, beanFactory);
/*     */     }
/*     */ 
/* 138 */     String[] postProcessorNames = beanFactory
/* 138 */       .getBeanNamesForType(BeanFactoryPostProcessor.class, true, false);
/*     */ 
/* 142 */     List priorityOrderedPostProcessors = new ArrayList();
/* 143 */     List orderedPostProcessorNames = new ArrayList();
/* 144 */     Object nonOrderedPostProcessorNames = new ArrayList();
/* 145 */     List priorityOrderedPostProcessors = postProcessorNames; List orderedPostProcessors = priorityOrderedPostProcessors.length; for (boolean reiterate = false; reiterate < orderedPostProcessors; reiterate++) { String ppName = priorityOrderedPostProcessors[reiterate];
/* 146 */       if (!processedBeans.contains(ppName))
/*     */       {
/* 149 */         if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/* 150 */           priorityOrderedPostProcessors.add(beanFactory.getBean(ppName, BeanFactoryPostProcessor.class));
/*     */         }
/* 152 */         else if (beanFactory.isTypeMatch(ppName, Ordered.class)) {
/* 153 */           orderedPostProcessorNames.add(ppName);
/*     */         }
/*     */         else {
/* 156 */           ((List)nonOrderedPostProcessorNames).add(ppName);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 161 */     OrderComparator.sort(priorityOrderedPostProcessors);
/* 162 */     invokeBeanFactoryPostProcessors(priorityOrderedPostProcessors, beanFactory);
/*     */ 
/* 165 */     List orderedPostProcessors = new ArrayList();
/* 166 */     for (orderedPostProcessors = orderedPostProcessorNames.iterator(); orderedPostProcessors.hasNext(); ) { postProcessorName = (String)orderedPostProcessors.next();
/* 167 */       orderedPostProcessors.add(beanFactory.getBean((String)postProcessorName, BeanFactoryPostProcessor.class));
/*     */     }
/* 169 */     OrderComparator.sort(orderedPostProcessors);
/* 170 */     invokeBeanFactoryPostProcessors(orderedPostProcessors, beanFactory);
/*     */ 
/* 173 */     List nonOrderedPostProcessors = new ArrayList();
/* 174 */     for (Object postProcessorName = ((List)nonOrderedPostProcessorNames).iterator(); ((Iterator)postProcessorName).hasNext(); ) { String postProcessorName = (String)((Iterator)postProcessorName).next();
/* 175 */       nonOrderedPostProcessors.add(beanFactory.getBean(postProcessorName, BeanFactoryPostProcessor.class));
/*     */     }
/* 177 */     invokeBeanFactoryPostProcessors(nonOrderedPostProcessors, beanFactory);
/*     */   }
/*     */ 
/*     */   public static void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory, AbstractApplicationContext applicationContext)
/*     */   {
/* 183 */     String[] postProcessorNames = beanFactory.getBeanNamesForType(BeanPostProcessor.class, true, false);
/*     */ 
/* 188 */     int beanProcessorTargetCount = beanFactory.getBeanPostProcessorCount() + 1 + postProcessorNames.length;
/* 189 */     beanFactory.addBeanPostProcessor(new BeanPostProcessorChecker(beanFactory, beanProcessorTargetCount));
/*     */ 
/* 193 */     List priorityOrderedPostProcessors = new ArrayList();
/* 194 */     List internalPostProcessors = new ArrayList();
/* 195 */     List orderedPostProcessorNames = new ArrayList();
/* 196 */     List nonOrderedPostProcessorNames = new ArrayList();
/* 197 */     for (String ppName : postProcessorNames) {
/* 198 */       if (beanFactory.isTypeMatch(ppName, PriorityOrdered.class)) {
/* 199 */         BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/* 200 */         priorityOrderedPostProcessors.add(pp);
/* 201 */         if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/* 202 */           internalPostProcessors.add(pp);
/*     */         }
/*     */       }
/* 205 */       else if (beanFactory.isTypeMatch(ppName, Ordered.class)) {
/* 206 */         orderedPostProcessorNames.add(ppName);
/*     */       }
/*     */       else {
/* 209 */         nonOrderedPostProcessorNames.add(ppName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 214 */     OrderComparator.sort(priorityOrderedPostProcessors);
/* 215 */     registerBeanPostProcessors(beanFactory, priorityOrderedPostProcessors);
/*     */ 
/* 218 */     Object orderedPostProcessors = new ArrayList();
/* 219 */     for (Iterator localIterator = orderedPostProcessorNames.iterator(); localIterator.hasNext(); ) { ppName = (String)localIterator.next();
/* 220 */       BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean((String)ppName, BeanPostProcessor.class);
/* 221 */       ((List)orderedPostProcessors).add(pp);
/* 222 */       if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/* 223 */         internalPostProcessors.add(pp);
/*     */       }
/*     */     }
/* 226 */     OrderComparator.sort((List)orderedPostProcessors);
/* 227 */     registerBeanPostProcessors(beanFactory, (List)orderedPostProcessors);
/*     */ 
/* 230 */     Object nonOrderedPostProcessors = new ArrayList();
/* 231 */     for (Object ppName = nonOrderedPostProcessorNames.iterator(); ((Iterator)ppName).hasNext(); ) { String ppName = (String)((Iterator)ppName).next();
/* 232 */       BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/* 233 */       ((List)nonOrderedPostProcessors).add(pp);
/* 234 */       if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/* 235 */         internalPostProcessors.add(pp);
/*     */       }
/*     */     }
/* 238 */     registerBeanPostProcessors(beanFactory, (List)nonOrderedPostProcessors);
/*     */ 
/* 241 */     OrderComparator.sort(internalPostProcessors);
/* 242 */     registerBeanPostProcessors(beanFactory, internalPostProcessors);
/*     */ 
/* 244 */     beanFactory.addBeanPostProcessor(new ApplicationListenerDetector(applicationContext));
/*     */   }
/*     */ 
/*     */   private static void invokeBeanDefinitionRegistryPostProcessors(Collection<? extends BeanDefinitionRegistryPostProcessor> postProcessors, BeanDefinitionRegistry registry)
/*     */   {
/* 253 */     for (BeanDefinitionRegistryPostProcessor postProcessor : postProcessors)
/* 254 */       postProcessor.postProcessBeanDefinitionRegistry(registry);
/*     */   }
/*     */ 
/*     */   private static void invokeBeanFactoryPostProcessors(Collection<? extends BeanFactoryPostProcessor> postProcessors, ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 264 */     for (BeanFactoryPostProcessor postProcessor : postProcessors)
/* 265 */       postProcessor.postProcessBeanFactory(beanFactory);
/*     */   }
/*     */ 
/*     */   private static void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory, List<BeanPostProcessor> postProcessors)
/*     */   {
/* 275 */     for (BeanPostProcessor postProcessor : postProcessors)
/* 276 */       beanFactory.addBeanPostProcessor(postProcessor);
/*     */   }
/*     */ 
/*     */   private static class ApplicationListenerDetector
/*     */     implements MergedBeanDefinitionPostProcessor, DestructionAwareBeanPostProcessor
/*     */   {
/* 325 */     private static final Log logger = LogFactory.getLog(ApplicationListenerDetector.class);
/*     */     private final AbstractApplicationContext applicationContext;
/* 329 */     private final Map<String, Boolean> singletonNames = new ConcurrentHashMap(64);
/*     */ 
/*     */     public ApplicationListenerDetector(AbstractApplicationContext applicationContext) {
/* 332 */       this.applicationContext = applicationContext;
/*     */     }
/*     */ 
/*     */     public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName)
/*     */     {
/* 337 */       if (beanDefinition.isSingleton())
/* 338 */         this.singletonNames.put(beanName, Boolean.TRUE);
/*     */     }
/*     */ 
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     {
/* 344 */       return bean;
/*     */     }
/*     */ 
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     {
/* 349 */       if ((bean instanceof ApplicationListener))
/*     */       {
/* 351 */         Boolean flag = (Boolean)this.singletonNames.get(beanName);
/* 352 */         if (Boolean.TRUE.equals(flag))
/*     */         {
/* 354 */           this.applicationContext.addApplicationListener((ApplicationListener)bean);
/*     */         }
/* 356 */         else if (flag == null) {
/* 357 */           if ((logger.isWarnEnabled()) && (!this.applicationContext.containsBean(beanName)))
/*     */           {
/* 359 */             logger.warn("Inner bean '" + beanName + "' implements ApplicationListener interface " + "but is not reachable for event multicasting by its containing ApplicationContext " + "because it does not have singleton scope. Only top-level listener beans are allowed " + "to be of non-singleton scope.");
/*     */           }
/*     */ 
/* 364 */           this.singletonNames.put(beanName, Boolean.FALSE);
/*     */         }
/*     */       }
/* 367 */       return bean;
/*     */     }
/*     */ 
/*     */     public void postProcessBeforeDestruction(Object bean, String beanName)
/*     */     {
/* 372 */       if ((bean instanceof ApplicationListener)) {
/* 373 */         ApplicationEventMulticaster multicaster = this.applicationContext.getApplicationEventMulticaster();
/* 374 */         multicaster.removeApplicationListener((ApplicationListener)bean);
/* 375 */         multicaster.removeApplicationListenerBean(beanName);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BeanPostProcessorChecker
/*     */     implements BeanPostProcessor
/*     */   {
/* 288 */     private static final Log logger = LogFactory.getLog(BeanPostProcessorChecker.class);
/*     */     private final ConfigurableListableBeanFactory beanFactory;
/*     */     private final int beanPostProcessorTargetCount;
/*     */ 
/*     */     public BeanPostProcessorChecker(ConfigurableListableBeanFactory beanFactory, int beanPostProcessorTargetCount)
/*     */     {
/* 295 */       this.beanFactory = beanFactory;
/* 296 */       this.beanPostProcessorTargetCount = beanPostProcessorTargetCount;
/*     */     }
/*     */ 
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     {
/* 301 */       return bean;
/*     */     }
/*     */ 
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */     {
/* 306 */       if ((bean != null) && (!(bean instanceof BeanPostProcessor)) && 
/* 307 */         (this.beanFactory
/* 307 */         .getBeanPostProcessorCount() < this.beanPostProcessorTargetCount) && 
/* 308 */         (logger.isInfoEnabled())) {
/* 309 */         logger.info("Bean '" + beanName + "' of type [" + bean.getClass() + "] is not eligible for getting processed by all BeanPostProcessors " + "(for example: not eligible for auto-proxying)");
/*     */       }
/*     */ 
/* 314 */       return bean;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.PostProcessorRegistrationDelegate
 * JD-Core Version:    0.6.2
 */