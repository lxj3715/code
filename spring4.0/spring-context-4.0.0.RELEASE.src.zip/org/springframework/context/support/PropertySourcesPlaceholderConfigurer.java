/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.PlaceholderConfigurerSupport;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.ConfigurablePropertyResolver;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertiesPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class PropertySourcesPlaceholderConfigurer extends PlaceholderConfigurerSupport
/*     */   implements EnvironmentAware
/*     */ {
/*     */   public static final String LOCAL_PROPERTIES_PROPERTY_SOURCE_NAME = "localProperties";
/*     */   public static final String ENVIRONMENT_PROPERTIES_PROPERTY_SOURCE_NAME = "environmentProperties";
/*     */   private MutablePropertySources propertySources;
/*     */   private PropertySources appliedPropertySources;
/*     */   private Environment environment;
/*     */ 
/*     */   public void setPropertySources(PropertySources propertySources)
/*     */   {
/*  95 */     this.propertySources = new MutablePropertySources(propertySources);
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 106 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */     throws BeansException
/*     */   {
/* 128 */     if (this.propertySources == null) {
/* 129 */       this.propertySources = new MutablePropertySources();
/* 130 */       if (this.environment != null) {
/* 131 */         this.propertySources.addLast(new PropertySource("environmentProperties", this.environment)
/*     */         {
/*     */           public String getProperty(String key)
/*     */           {
/* 135 */             return ((Environment)this.source).getProperty(key);
/*     */           }
/*     */         });
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 142 */         PropertySource localPropertySource = new PropertiesPropertySource("localProperties", 
/* 142 */           mergeProperties());
/* 143 */         if (this.localOverride) {
/* 144 */           this.propertySources.addFirst(localPropertySource);
/*     */         }
/*     */         else
/* 147 */           this.propertySources.addLast(localPropertySource);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 151 */         throw new BeanInitializationException("Could not load properties", ex);
/*     */       }
/*     */     }
/*     */ 
/* 155 */     processProperties(beanFactory, new PropertySourcesPropertyResolver(this.propertySources));
/* 156 */     this.appliedPropertySources = this.propertySources;
/*     */   }
/*     */ 
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, final ConfigurablePropertyResolver propertyResolver)
/*     */     throws BeansException
/*     */   {
/* 166 */     propertyResolver.setPlaceholderPrefix(this.placeholderPrefix);
/* 167 */     propertyResolver.setPlaceholderSuffix(this.placeholderSuffix);
/* 168 */     propertyResolver.setValueSeparator(this.valueSeparator);
/*     */ 
/* 170 */     StringValueResolver valueResolver = new StringValueResolver()
/*     */     {
/*     */       public String resolveStringValue(String strVal)
/*     */       {
/* 175 */         String resolved = PropertySourcesPlaceholderConfigurer.this.ignoreUnresolvablePlaceholders ? propertyResolver
/* 174 */           .resolvePlaceholders(strVal) : 
/* 174 */           propertyResolver
/* 175 */           .resolveRequiredPlaceholders(strVal);
/*     */ 
/* 176 */         return resolved.equals(PropertySourcesPlaceholderConfigurer.this.nullValue) ? null : resolved;
/*     */       }
/*     */     };
/* 180 */     doProcessProperties(beanFactoryToProcess, valueResolver);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties props)
/*     */   {
/* 191 */     throw new UnsupportedOperationException("Call processProperties(ConfigurableListableBeanFactory, ConfigurablePropertyResolver) instead");
/*     */   }
/*     */ 
/*     */   public PropertySources getAppliedPropertySources()
/*     */     throws IllegalStateException
/*     */   {
/* 203 */     Assert.state(this.appliedPropertySources != null, "PropertySources have not get been applied");
/* 204 */     return this.appliedPropertySources;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.PropertySourcesPlaceholderConfigurer
 * JD-Core Version:    0.6.2
 */