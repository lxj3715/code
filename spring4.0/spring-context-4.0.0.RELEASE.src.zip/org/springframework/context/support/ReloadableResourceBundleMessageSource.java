/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.DefaultPropertiesPersister;
/*     */ import org.springframework.util.PropertiesPersister;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ReloadableResourceBundleMessageSource extends AbstractMessageSource
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private static final String PROPERTIES_SUFFIX = ".properties";
/*     */   private static final String XML_SUFFIX = ".xml";
/*     */   private String[] basenames;
/*     */   private String defaultEncoding;
/*     */   private Properties fileEncodings;
/*     */   private boolean fallbackToSystemLocale;
/*     */   private long cacheMillis;
/*     */   private PropertiesPersister propertiesPersister;
/*     */   private ResourceLoader resourceLoader;
/*     */   private final Map<String, Map<Locale, List<String>>> cachedFilenames;
/*     */   private final Map<String, PropertiesHolder> cachedProperties;
/*     */   private final Map<Locale, PropertiesHolder> cachedMergedProperties;
/*     */ 
/*     */   public ReloadableResourceBundleMessageSource()
/*     */   {
/* 103 */     this.basenames = new String[0];
/*     */ 
/* 109 */     this.fallbackToSystemLocale = true;
/*     */ 
/* 111 */     this.cacheMillis = -1L;
/*     */ 
/* 113 */     this.propertiesPersister = new DefaultPropertiesPersister();
/*     */ 
/* 115 */     this.resourceLoader = new DefaultResourceLoader();
/*     */ 
/* 118 */     this.cachedFilenames = new HashMap();
/*     */ 
/* 122 */     this.cachedProperties = new HashMap();
/*     */ 
/* 125 */     this.cachedMergedProperties = new HashMap();
/*     */   }
/*     */ 
/*     */   public void setBasename(String basename)
/*     */   {
/* 142 */     setBasenames(new String[] { basename });
/*     */   }
/*     */ 
/*     */   public void setBasenames(String[] basenames)
/*     */   {
/* 161 */     if (basenames != null) {
/* 162 */       this.basenames = new String[basenames.length];
/* 163 */       for (int i = 0; i < basenames.length; i++) {
/* 164 */         String basename = basenames[i];
/* 165 */         Assert.hasText(basename, "Basename must not be empty");
/* 166 */         this.basenames[i] = basename.trim();
/*     */       }
/*     */     }
/*     */     else {
/* 170 */       this.basenames = new String[0];
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 185 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */ 
/*     */   public void setFileEncodings(Properties fileEncodings)
/*     */   {
/* 199 */     this.fileEncodings = fileEncodings;
/*     */   }
/*     */ 
/*     */   public void setFallbackToSystemLocale(boolean fallbackToSystemLocale)
/*     */   {
/* 213 */     this.fallbackToSystemLocale = fallbackToSystemLocale;
/*     */   }
/*     */ 
/*     */   public void setCacheSeconds(int cacheSeconds)
/*     */   {
/* 231 */     this.cacheMillis = (cacheSeconds * 1000);
/*     */   }
/*     */ 
/*     */   public void setPropertiesPersister(PropertiesPersister propertiesPersister)
/*     */   {
/* 240 */     this.propertiesPersister = (propertiesPersister != null ? propertiesPersister : new DefaultPropertiesPersister());
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 255 */     this.resourceLoader = (resourceLoader != null ? resourceLoader : new DefaultResourceLoader());
/*     */   }
/*     */ 
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale)
/*     */   {
/*     */     PropertiesHolder propHolder;
/*     */     String result;
/* 265 */     if (this.cacheMillis < 0L) {
/* 266 */       propHolder = getMergedProperties(locale);
/* 267 */       result = propHolder.getProperty(code);
/* 268 */       if (result != null)
/* 269 */         return result;
/*     */     }
/*     */     else
/*     */     {
/* 273 */       propHolder = this.basenames; result = propHolder.length; for (String str1 = 0; str1 < result; str1++) { String basename = propHolder[str1];
/* 274 */         List filenames = calculateAllFilenames(basename, locale);
/* 275 */         for (String filename : filenames) {
/* 276 */           PropertiesHolder propHolder = getProperties(filename);
/* 277 */           String result = propHolder.getProperty(code);
/* 278 */           if (result != null) {
/* 279 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 284 */     return null;
/*     */   }
/*     */ 
/*     */   protected MessageFormat resolveCode(String code, Locale locale)
/*     */   {
/*     */     PropertiesHolder propHolder;
/*     */     MessageFormat result;
/* 293 */     if (this.cacheMillis < 0L) {
/* 294 */       propHolder = getMergedProperties(locale);
/* 295 */       result = propHolder.getMessageFormat(code, locale);
/* 296 */       if (result != null)
/* 297 */         return result;
/*     */     }
/*     */     else
/*     */     {
/* 301 */       propHolder = this.basenames; result = propHolder.length; for (MessageFormat localMessageFormat1 = 0; localMessageFormat1 < result; localMessageFormat1++) { String basename = propHolder[localMessageFormat1];
/* 302 */         List filenames = calculateAllFilenames(basename, locale);
/* 303 */         for (String filename : filenames) {
/* 304 */           PropertiesHolder propHolder = getProperties(filename);
/* 305 */           MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 306 */           if (result != null) {
/* 307 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 312 */     return null;
/*     */   }
/*     */ 
/*     */   protected PropertiesHolder getMergedProperties(Locale locale)
/*     */   {
/* 325 */     synchronized (this.cachedMergedProperties) {
/* 326 */       PropertiesHolder mergedHolder = (PropertiesHolder)this.cachedMergedProperties.get(locale);
/* 327 */       if (mergedHolder != null) {
/* 328 */         return mergedHolder;
/*     */       }
/* 330 */       Properties mergedProps = new Properties();
/* 331 */       mergedHolder = new PropertiesHolder(mergedProps, -1L);
/* 332 */       for (int i = this.basenames.length - 1; i >= 0; i--) {
/* 333 */         List filenames = calculateAllFilenames(this.basenames[i], locale);
/* 334 */         for (int j = filenames.size() - 1; j >= 0; j--) {
/* 335 */           String filename = (String)filenames.get(j);
/* 336 */           PropertiesHolder propHolder = getProperties(filename);
/* 337 */           if (propHolder.getProperties() != null) {
/* 338 */             mergedProps.putAll(propHolder.getProperties());
/*     */           }
/*     */         }
/*     */       }
/* 342 */       this.cachedMergedProperties.put(locale, mergedHolder);
/* 343 */       return mergedHolder;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<String> calculateAllFilenames(String basename, Locale locale)
/*     */   {
/* 358 */     synchronized (this.cachedFilenames) {
/* 359 */       Map localeMap = (Map)this.cachedFilenames.get(basename);
/* 360 */       if (localeMap != null) {
/* 361 */         List filenames = (List)localeMap.get(locale);
/* 362 */         if (filenames != null) {
/* 363 */           return filenames;
/*     */         }
/*     */       }
/* 366 */       List filenames = new ArrayList(7);
/* 367 */       filenames.addAll(calculateFilenamesForLocale(basename, locale));
/* 368 */       if ((this.fallbackToSystemLocale) && (!locale.equals(Locale.getDefault()))) {
/* 369 */         List fallbackFilenames = calculateFilenamesForLocale(basename, Locale.getDefault());
/* 370 */         for (String fallbackFilename : fallbackFilenames) {
/* 371 */           if (!filenames.contains(fallbackFilename))
/*     */           {
/* 373 */             filenames.add(fallbackFilename);
/*     */           }
/*     */         }
/*     */       }
/* 377 */       filenames.add(basename);
/* 378 */       if (localeMap != null) {
/* 379 */         localeMap.put(locale, filenames);
/*     */       }
/*     */       else {
/* 382 */         localeMap = new HashMap();
/* 383 */         localeMap.put(locale, filenames);
/* 384 */         this.cachedFilenames.put(basename, localeMap);
/*     */       }
/* 386 */       return filenames;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<String> calculateFilenamesForLocale(String basename, Locale locale)
/*     */   {
/* 401 */     List result = new ArrayList(3);
/* 402 */     String language = locale.getLanguage();
/* 403 */     String country = locale.getCountry();
/* 404 */     String variant = locale.getVariant();
/* 405 */     StringBuilder temp = new StringBuilder(basename);
/*     */ 
/* 407 */     temp.append('_');
/* 408 */     if (language.length() > 0) {
/* 409 */       temp.append(language);
/* 410 */       result.add(0, temp.toString());
/*     */     }
/*     */ 
/* 413 */     temp.append('_');
/* 414 */     if (country.length() > 0) {
/* 415 */       temp.append(country);
/* 416 */       result.add(0, temp.toString());
/*     */     }
/*     */ 
/* 419 */     if ((variant.length() > 0) && ((language.length() > 0) || (country.length() > 0))) {
/* 420 */       temp.append('_').append(variant);
/* 421 */       result.add(0, temp.toString());
/*     */     }
/*     */ 
/* 424 */     return result;
/*     */   }
/*     */ 
/*     */   protected PropertiesHolder getProperties(String filename)
/*     */   {
/* 435 */     synchronized (this.cachedProperties) {
/* 436 */       PropertiesHolder propHolder = (PropertiesHolder)this.cachedProperties.get(filename);
/* 437 */       if ((propHolder != null) && (
/* 438 */         (propHolder
/* 438 */         .getRefreshTimestamp() < 0L) || 
/* 439 */         (propHolder
/* 439 */         .getRefreshTimestamp() > System.currentTimeMillis() - this.cacheMillis)))
/*     */       {
/* 441 */         return propHolder;
/*     */       }
/* 443 */       return refreshProperties(filename, propHolder);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected PropertiesHolder refreshProperties(String filename, PropertiesHolder propHolder)
/*     */   {
/* 455 */     long refreshTimestamp = this.cacheMillis < 0L ? -1L : System.currentTimeMillis();
/*     */ 
/* 457 */     Resource resource = this.resourceLoader.getResource(new StringBuilder().append(filename).append(".properties").toString());
/* 458 */     if (!resource.exists()) {
/* 459 */       resource = this.resourceLoader.getResource(new StringBuilder().append(filename).append(".xml").toString());
/*     */     }
/*     */ 
/* 462 */     if (resource.exists()) {
/* 463 */       long fileTimestamp = -1L;
/* 464 */       if (this.cacheMillis >= 0L)
/*     */         try
/*     */         {
/* 467 */           fileTimestamp = resource.lastModified();
/* 468 */           if ((propHolder != null) && (propHolder.getFileTimestamp() == fileTimestamp)) {
/* 469 */             if (this.logger.isDebugEnabled()) {
/* 470 */               this.logger.debug(new StringBuilder().append("Re-caching properties for filename [").append(filename).append("] - file hasn't been modified").toString());
/*     */             }
/* 472 */             propHolder.setRefreshTimestamp(refreshTimestamp);
/* 473 */             return propHolder;
/*     */           }
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/* 478 */           if (this.logger.isDebugEnabled()) {
/* 479 */             this.logger.debug(new StringBuilder().append(resource).append(" could not be resolved in the file system - assuming that is hasn't changed").toString(), ex);
/*     */           }
/*     */ 
/* 482 */           fileTimestamp = -1L;
/*     */         }
/*     */       try
/*     */       {
/* 486 */         Properties props = loadProperties(resource, filename);
/* 487 */         propHolder = new PropertiesHolder(props, fileTimestamp);
/*     */       }
/*     */       catch (IOException ex) {
/* 490 */         if (this.logger.isWarnEnabled()) {
/* 491 */           this.logger.warn(new StringBuilder().append("Could not parse properties file [").append(resource.getFilename()).append("]").toString(), ex);
/*     */         }
/*     */ 
/* 494 */         propHolder = new PropertiesHolder();
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 500 */       if (this.logger.isDebugEnabled()) {
/* 501 */         this.logger.debug(new StringBuilder().append("No properties file found for [").append(filename).append("] - neither plain properties nor XML").toString());
/*     */       }
/*     */ 
/* 504 */       propHolder = new PropertiesHolder();
/*     */     }
/*     */ 
/* 507 */     propHolder.setRefreshTimestamp(refreshTimestamp);
/* 508 */     this.cachedProperties.put(filename, propHolder);
/* 509 */     return propHolder;
/*     */   }
/*     */ 
/*     */   protected Properties loadProperties(Resource resource, String filename)
/*     */     throws IOException
/*     */   {
/* 520 */     InputStream is = resource.getInputStream();
/* 521 */     Properties props = new Properties();
/*     */     try
/*     */     {
/*     */       String encoding;
/* 523 */       if (resource.getFilename().endsWith(".xml")) {
/* 524 */         if (this.logger.isDebugEnabled()) {
/* 525 */           this.logger.debug(new StringBuilder().append("Loading properties [").append(resource.getFilename()).append("]").toString());
/*     */         }
/* 527 */         this.propertiesPersister.loadFromXml(props, is);
/*     */       }
/*     */       else {
/* 530 */         encoding = null;
/* 531 */         if (this.fileEncodings != null) {
/* 532 */           encoding = this.fileEncodings.getProperty(filename);
/*     */         }
/* 534 */         if (encoding == null) {
/* 535 */           encoding = this.defaultEncoding;
/*     */         }
/* 537 */         if (encoding != null) {
/* 538 */           if (this.logger.isDebugEnabled()) {
/* 539 */             this.logger.debug(new StringBuilder().append("Loading properties [").append(resource.getFilename()).append("] with encoding '").append(encoding).append("'").toString());
/*     */           }
/* 541 */           this.propertiesPersister.load(props, new InputStreamReader(is, encoding));
/*     */         }
/*     */         else {
/* 544 */           if (this.logger.isDebugEnabled()) {
/* 545 */             this.logger.debug(new StringBuilder().append("Loading properties [").append(resource.getFilename()).append("]").toString());
/*     */           }
/* 547 */           this.propertiesPersister.load(props, is);
/*     */         }
/*     */       }
/* 550 */       return props;
/*     */     }
/*     */     finally {
/* 553 */       is.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearCache()
/*     */   {
/* 563 */     this.logger.debug("Clearing entire resource bundle cache");
/* 564 */     synchronized (this.cachedProperties) {
/* 565 */       this.cachedProperties.clear();
/*     */     }
/* 567 */     synchronized (this.cachedMergedProperties) {
/* 568 */       this.cachedMergedProperties.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearCacheIncludingAncestors()
/*     */   {
/* 577 */     clearCache();
/* 578 */     if ((getParentMessageSource() instanceof ReloadableResourceBundleMessageSource))
/* 579 */       ((ReloadableResourceBundleMessageSource)getParentMessageSource()).clearCacheIncludingAncestors();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 586 */     return new StringBuilder().append(getClass().getName()).append(": basenames=[").append(StringUtils.arrayToCommaDelimitedString(this.basenames)).append("]").toString();
/*     */   }
/*     */ 
/*     */   protected class PropertiesHolder
/*     */   {
/*     */     private Properties properties;
/* 600 */     private long fileTimestamp = -1L;
/*     */ 
/* 602 */     private long refreshTimestamp = -1L;
/*     */ 
/* 605 */     private final Map<String, Map<Locale, MessageFormat>> cachedMessageFormats = new HashMap();
/*     */ 
/*     */     public PropertiesHolder(Properties properties, long fileTimestamp)
/*     */     {
/* 609 */       this.properties = properties;
/* 610 */       this.fileTimestamp = fileTimestamp;
/*     */     }
/*     */ 
/*     */     public PropertiesHolder() {
/*     */     }
/*     */ 
/*     */     public Properties getProperties() {
/* 617 */       return this.properties;
/*     */     }
/*     */ 
/*     */     public long getFileTimestamp() {
/* 621 */       return this.fileTimestamp;
/*     */     }
/*     */ 
/*     */     public void setRefreshTimestamp(long refreshTimestamp) {
/* 625 */       this.refreshTimestamp = refreshTimestamp;
/*     */     }
/*     */ 
/*     */     public long getRefreshTimestamp() {
/* 629 */       return this.refreshTimestamp;
/*     */     }
/*     */ 
/*     */     public String getProperty(String code) {
/* 633 */       if (this.properties == null) {
/* 634 */         return null;
/*     */       }
/* 636 */       return this.properties.getProperty(code);
/*     */     }
/*     */ 
/*     */     public MessageFormat getMessageFormat(String code, Locale locale) {
/* 640 */       if (this.properties == null) {
/* 641 */         return null;
/*     */       }
/* 643 */       synchronized (this.cachedMessageFormats) {
/* 644 */         Map localeMap = (Map)this.cachedMessageFormats.get(code);
/* 645 */         if (localeMap != null) {
/* 646 */           MessageFormat result = (MessageFormat)localeMap.get(locale);
/* 647 */           if (result != null) {
/* 648 */             return result;
/*     */           }
/*     */         }
/* 651 */         String msg = this.properties.getProperty(code);
/* 652 */         if (msg != null) {
/* 653 */           if (localeMap == null) {
/* 654 */             localeMap = new HashMap();
/* 655 */             this.cachedMessageFormats.put(code, localeMap);
/*     */           }
/* 657 */           MessageFormat result = ReloadableResourceBundleMessageSource.this.createMessageFormat(msg, locale);
/* 658 */           localeMap.put(locale, result);
/* 659 */           return result;
/*     */         }
/* 661 */         return null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.ReloadableResourceBundleMessageSource
 * JD-Core Version:    0.6.2
 */