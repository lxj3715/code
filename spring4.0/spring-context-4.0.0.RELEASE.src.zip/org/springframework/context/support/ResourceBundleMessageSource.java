/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.PropertyResourceBundle;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.ResourceBundle.Control;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceBundleMessageSource extends AbstractMessageSource
/*     */   implements BeanClassLoaderAware
/*     */ {
/*     */   private String[] basenames;
/*     */   private String defaultEncoding;
/*     */   private boolean fallbackToSystemLocale;
/*     */   private long cacheMillis;
/*     */   private ClassLoader bundleClassLoader;
/*     */   private ClassLoader beanClassLoader;
/*     */   private final Map<String, Map<Locale, ResourceBundle>> cachedResourceBundles;
/*     */   private final Map<ResourceBundle, Map<String, Map<Locale, MessageFormat>>> cachedBundleMessageFormats;
/*     */ 
/*     */   public ResourceBundleMessageSource()
/*     */   {
/*  68 */     this.basenames = new String[0];
/*     */ 
/*  72 */     this.fallbackToSystemLocale = true;
/*     */ 
/*  74 */     this.cacheMillis = -1L;
/*     */ 
/*  78 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*  87 */     this.cachedResourceBundles = new HashMap();
/*     */ 
/*  98 */     this.cachedBundleMessageFormats = new HashMap();
/*     */   }
/*     */ 
/*     */   public void setBasename(String basename)
/*     */   {
/* 118 */     setBasenames(new String[] { basename });
/*     */   }
/*     */ 
/*     */   public void setBasenames(String[] basenames)
/*     */   {
/* 138 */     if (basenames != null) {
/* 139 */       this.basenames = new String[basenames.length];
/* 140 */       for (int i = 0; i < basenames.length; i++) {
/* 141 */         String basename = basenames[i];
/* 142 */         Assert.hasText(basename, "Basename must not be empty");
/* 143 */         this.basenames[i] = basename.trim();
/*     */       }
/*     */     }
/*     */     else {
/* 147 */       this.basenames = new String[0];
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 158 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */ 
/*     */   public void setFallbackToSystemLocale(boolean fallbackToSystemLocale)
/*     */   {
/* 172 */     this.fallbackToSystemLocale = fallbackToSystemLocale;
/*     */   }
/*     */ 
/*     */   public void setCacheSeconds(int cacheSeconds)
/*     */   {
/* 193 */     this.cacheMillis = (cacheSeconds * 1000);
/*     */   }
/*     */ 
/*     */   public void setBundleClassLoader(ClassLoader classLoader)
/*     */   {
/* 205 */     this.bundleClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   protected ClassLoader getBundleClassLoader()
/*     */   {
/* 214 */     return this.bundleClassLoader != null ? this.bundleClassLoader : this.beanClassLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 219 */     this.beanClassLoader = (classLoader != null ? classLoader : ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale)
/*     */   {
/* 229 */     String result = null;
/* 230 */     for (int i = 0; (result == null) && (i < this.basenames.length); i++) {
/* 231 */       ResourceBundle bundle = getResourceBundle(this.basenames[i], locale);
/* 232 */       if (bundle != null) {
/* 233 */         result = getStringOrNull(bundle, code);
/*     */       }
/*     */     }
/* 236 */     return result;
/*     */   }
/*     */ 
/*     */   protected MessageFormat resolveCode(String code, Locale locale)
/*     */   {
/* 245 */     MessageFormat messageFormat = null;
/* 246 */     for (int i = 0; (messageFormat == null) && (i < this.basenames.length); i++) {
/* 247 */       ResourceBundle bundle = getResourceBundle(this.basenames[i], locale);
/* 248 */       if (bundle != null) {
/* 249 */         messageFormat = getMessageFormat(bundle, code, locale);
/*     */       }
/*     */     }
/* 252 */     return messageFormat;
/*     */   }
/*     */ 
/*     */   protected ResourceBundle getResourceBundle(String basename, Locale locale)
/*     */   {
/* 265 */     if (this.cacheMillis >= 0L)
/*     */     {
/* 268 */       return doGetBundle(basename, locale);
/*     */     }
/*     */ 
/* 272 */     synchronized (this.cachedResourceBundles) {
/* 273 */       Map localeMap = (Map)this.cachedResourceBundles.get(basename);
/* 274 */       if (localeMap != null) {
/* 275 */         ResourceBundle bundle = (ResourceBundle)localeMap.get(locale);
/* 276 */         if (bundle != null)
/* 277 */           return bundle;
/*     */       }
/*     */       try
/*     */       {
/* 281 */         ResourceBundle bundle = doGetBundle(basename, locale);
/* 282 */         if (localeMap == null) {
/* 283 */           localeMap = new HashMap();
/* 284 */           this.cachedResourceBundles.put(basename, localeMap);
/*     */         }
/* 286 */         localeMap.put(locale, bundle);
/* 287 */         return bundle;
/*     */       }
/*     */       catch (MissingResourceException ex) {
/* 290 */         if (this.logger.isWarnEnabled()) {
/* 291 */           this.logger.warn("ResourceBundle [" + basename + "] not found for MessageSource: " + ex.getMessage());
/*     */         }
/*     */ 
/* 295 */         return null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ResourceBundle doGetBundle(String basename, Locale locale)
/*     */     throws MissingResourceException
/*     */   {
/* 311 */     if (((this.defaultEncoding != null) && (!"ISO-8859-1".equals(this.defaultEncoding))) || (!this.fallbackToSystemLocale) || (this.cacheMillis >= 0L))
/*     */     {
/* 313 */       return ResourceBundle.getBundle(basename, locale, getBundleClassLoader(), new MessageSourceControl(null));
/*     */     }
/*     */ 
/* 317 */     return ResourceBundle.getBundle(basename, locale, getBundleClassLoader());
/*     */   }
/*     */ 
/*     */   protected MessageFormat getMessageFormat(ResourceBundle bundle, String code, Locale locale)
/*     */     throws MissingResourceException
/*     */   {
/* 334 */     synchronized (this.cachedBundleMessageFormats) {
/* 335 */       Map codeMap = (Map)this.cachedBundleMessageFormats.get(bundle);
/* 336 */       Map localeMap = null;
/* 337 */       if (codeMap != null) {
/* 338 */         localeMap = (Map)codeMap.get(code);
/* 339 */         if (localeMap != null) {
/* 340 */           MessageFormat result = (MessageFormat)localeMap.get(locale);
/* 341 */           if (result != null) {
/* 342 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 347 */       String msg = getStringOrNull(bundle, code);
/* 348 */       if (msg != null) {
/* 349 */         if (codeMap == null) {
/* 350 */           codeMap = new HashMap();
/* 351 */           this.cachedBundleMessageFormats.put(bundle, codeMap);
/*     */         }
/* 353 */         if (localeMap == null) {
/* 354 */           localeMap = new HashMap();
/* 355 */           codeMap.put(code, localeMap);
/*     */         }
/* 357 */         MessageFormat result = createMessageFormat(msg, locale);
/* 358 */         localeMap.put(locale, result);
/* 359 */         return result;
/*     */       }
/*     */ 
/* 362 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getStringOrNull(ResourceBundle bundle, String key) {
/*     */     try {
/* 368 */       return bundle.getString(key);
/*     */     }
/*     */     catch (MissingResourceException ex)
/*     */     {
/*     */     }
/* 373 */     return null;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 383 */     return getClass().getName() + ": basenames=[" + 
/* 383 */       StringUtils.arrayToCommaDelimitedString(this.basenames) + 
/* 383 */       "]";
/*     */   }
/*     */ 
/*     */   private class MessageSourceControl extends ResourceBundle.Control
/*     */   {
/*     */     private MessageSourceControl()
/*     */     {
/*     */     }
/*     */ 
/*     */     public ResourceBundle newBundle(String baseName, Locale locale, String format, ClassLoader loader, boolean reload)
/*     */       throws IllegalAccessException, InstantiationException, IOException
/*     */     {
/* 397 */       if (format.equals("java.properties")) {
/* 398 */         String bundleName = toBundleName(baseName, locale);
/* 399 */         final String resourceName = toResourceName(bundleName, "properties");
/* 400 */         final ClassLoader classLoader = loader;
/* 401 */         final boolean reloadFlag = reload;
/*     */         try
/*     */         {
/* 404 */           stream = (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */           {
/*     */             public InputStream run() throws IOException
/*     */             {
/* 408 */               InputStream is = null;
/* 409 */               if (reloadFlag) {
/* 410 */                 URL url = classLoader.getResource(resourceName);
/* 411 */                 if (url != null) {
/* 412 */                   URLConnection connection = url.openConnection();
/* 413 */                   if (connection != null) {
/* 414 */                     connection.setUseCaches(false);
/* 415 */                     is = connection.getInputStream();
/*     */                   }
/*     */                 }
/*     */               }
/*     */               else {
/* 420 */                 is = classLoader.getResourceAsStream(resourceName);
/*     */               }
/* 422 */               return is;
/*     */             }
/*     */           });
/*     */         }
/*     */         catch (PrivilegedActionException ex)
/*     */         {
/*     */           InputStream stream;
/* 427 */           throw ((IOException)ex.getException());
/*     */         }
/*     */         InputStream stream;
/* 429 */         if (stream != null) {
/*     */           try
/*     */           {
/* 432 */             return ResourceBundleMessageSource.this.defaultEncoding != null ? new PropertyResourceBundle(new InputStreamReader(stream, ResourceBundleMessageSource.this.defaultEncoding)) : 
/* 432 */               new PropertyResourceBundle(stream);
/*     */           }
/*     */           finally
/*     */           {
/* 436 */             stream.close();
/*     */           }
/*     */         }
/*     */ 
/* 440 */         return null;
/*     */       }
/*     */ 
/* 444 */       return super.newBundle(baseName, locale, format, loader, reload);
/*     */     }
/*     */ 
/*     */     public Locale getFallbackLocale(String baseName, Locale locale)
/*     */     {
/* 450 */       return ResourceBundleMessageSource.this.fallbackToSystemLocale ? super.getFallbackLocale(baseName, locale) : null;
/*     */     }
/*     */ 
/*     */     public long getTimeToLive(String baseName, Locale locale)
/*     */     {
/* 455 */       return ResourceBundleMessageSource.this.cacheMillis >= 0L ? ResourceBundleMessageSource.this.cacheMillis : super.getTimeToLive(baseName, locale);
/*     */     }
/*     */ 
/*     */     public boolean needsReload(String baseName, Locale locale, String format, ClassLoader loader, ResourceBundle bundle, long loadTime)
/*     */     {
/* 460 */       if (super.needsReload(baseName, locale, format, loader, bundle, loadTime)) {
/* 461 */         ResourceBundleMessageSource.this.cachedBundleMessageFormats.remove(bundle);
/* 462 */         return true;
/*     */       }
/*     */ 
/* 465 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.ResourceBundleMessageSource
 * JD-Core Version:    0.6.2
 */