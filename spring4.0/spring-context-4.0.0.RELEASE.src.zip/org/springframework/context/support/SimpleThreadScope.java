/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.ObjectFactory;
/*    */ import org.springframework.beans.factory.config.Scope;
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ 
/*    */ public class SimpleThreadScope
/*    */   implements Scope
/*    */ {
/* 48 */   private static final Log logger = LogFactory.getLog(SimpleThreadScope.class);
/*    */ 
/* 50 */   private final ThreadLocal<Map<String, Object>> threadScope = new NamedThreadLocal("SimpleThreadScope")
/*    */   {
/*    */     protected Map<String, Object> initialValue()
/*    */     {
/* 54 */       return new HashMap();
/*    */     }
/* 50 */   };
/*    */ 
/*    */   public Object get(String name, ObjectFactory<?> objectFactory)
/*    */   {
/* 60 */     Map scope = (Map)this.threadScope.get();
/* 61 */     Object object = scope.get(name);
/* 62 */     if (object == null) {
/* 63 */       object = objectFactory.getObject();
/* 64 */       scope.put(name, object);
/*    */     }
/* 66 */     return object;
/*    */   }
/*    */ 
/*    */   public Object remove(String name)
/*    */   {
/* 71 */     Map scope = (Map)this.threadScope.get();
/* 72 */     return scope.remove(name);
/*    */   }
/*    */ 
/*    */   public void registerDestructionCallback(String name, Runnable callback)
/*    */   {
/* 77 */     logger.warn("SimpleThreadScope does not support descruction callbacks. Consider using a RequestScope in a Web environment.");
/*    */   }
/*    */ 
/*    */   public Object resolveContextualObject(String key)
/*    */   {
/* 83 */     return null;
/*    */   }
/*    */ 
/*    */   public String getConversationId()
/*    */   {
/* 88 */     return Thread.currentThread().getName();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.SimpleThreadScope
 * JD-Core Version:    0.6.2
 */