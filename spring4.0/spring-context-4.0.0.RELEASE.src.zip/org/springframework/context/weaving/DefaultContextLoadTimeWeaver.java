/*     */ package org.springframework.context.weaving;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.ReflectiveLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.glassfish.GlassFishLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.jboss.JBossLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.tomcat.TomcatLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.weblogic.WebLogicLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.websphere.WebSphereLoadTimeWeaver;
/*     */ 
/*     */ public class DefaultContextLoadTimeWeaver
/*     */   implements LoadTimeWeaver, BeanClassLoaderAware, DisposableBean
/*     */ {
/*  58 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private LoadTimeWeaver loadTimeWeaver;
/*     */ 
/*     */   public DefaultContextLoadTimeWeaver()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DefaultContextLoadTimeWeaver(ClassLoader beanClassLoader)
/*     */   {
/*  67 */     setBeanClassLoader(beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  72 */     LoadTimeWeaver serverSpecificLoadTimeWeaver = createServerSpecificLoadTimeWeaver(classLoader);
/*  73 */     if (serverSpecificLoadTimeWeaver != null) {
/*  74 */       if (this.logger.isInfoEnabled()) {
/*  75 */         this.logger.info("Determined server-specific load-time weaver: " + serverSpecificLoadTimeWeaver
/*  76 */           .getClass().getName());
/*     */       }
/*  78 */       this.loadTimeWeaver = serverSpecificLoadTimeWeaver;
/*     */     }
/*  80 */     else if (InstrumentationLoadTimeWeaver.isInstrumentationAvailable()) {
/*  81 */       this.logger.info("Found Spring's JVM agent for instrumentation");
/*  82 */       this.loadTimeWeaver = new InstrumentationLoadTimeWeaver(classLoader);
/*     */     }
/*     */     else {
/*     */       try {
/*  86 */         this.loadTimeWeaver = new ReflectiveLoadTimeWeaver(classLoader);
/*  87 */         this.logger.info("Using a reflective load-time weaver for class loader: " + this.loadTimeWeaver
/*  88 */           .getInstrumentableClassLoader().getClass().getName());
/*     */       }
/*     */       catch (IllegalStateException ex) {
/*  91 */         throw new IllegalStateException(ex.getMessage() + " Specify a custom LoadTimeWeaver or start your " + "Java virtual machine with Spring's agent: -javaagent:org.springframework.instrument.jar");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected LoadTimeWeaver createServerSpecificLoadTimeWeaver(ClassLoader classLoader)
/*     */   {
/* 107 */     String name = classLoader.getClass().getName();
/*     */     try {
/* 109 */       if (name.startsWith("weblogic")) {
/* 110 */         return new WebLogicLoadTimeWeaver(classLoader);
/*     */       }
/* 112 */       if (name.startsWith("org.glassfish")) {
/* 113 */         return new GlassFishLoadTimeWeaver(classLoader);
/*     */       }
/* 115 */       if (name.startsWith("org.apache.catalina")) {
/* 116 */         return new TomcatLoadTimeWeaver(classLoader);
/*     */       }
/* 118 */       if (name.startsWith("org.jboss")) {
/* 119 */         return new JBossLoadTimeWeaver(classLoader);
/*     */       }
/* 121 */       if (name.startsWith("com.ibm"))
/* 122 */         return new WebSphereLoadTimeWeaver(classLoader);
/*     */     }
/*     */     catch (IllegalStateException ex)
/*     */     {
/* 126 */       this.logger.info("Could not obtain server-specific LoadTimeWeaver: " + ex.getMessage());
/*     */     }
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 133 */     if ((this.loadTimeWeaver instanceof InstrumentationLoadTimeWeaver)) {
/* 134 */       this.logger.info("Removing all registered transformers for class loader: " + this.loadTimeWeaver
/* 135 */         .getInstrumentableClassLoader().getClass().getName());
/* 136 */       ((InstrumentationLoadTimeWeaver)this.loadTimeWeaver).removeTransformers();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/* 143 */     this.loadTimeWeaver.addTransformer(transformer);
/*     */   }
/*     */ 
/*     */   public ClassLoader getInstrumentableClassLoader()
/*     */   {
/* 148 */     return this.loadTimeWeaver.getInstrumentableClassLoader();
/*     */   }
/*     */ 
/*     */   public ClassLoader getThrowawayClassLoader()
/*     */   {
/* 153 */     return this.loadTimeWeaver.getThrowawayClassLoader();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.weaving.DefaultContextLoadTimeWeaver
 * JD-Core Version:    0.6.2
 */