package org.springframework.context.weaving;

import org.springframework.beans.factory.Aware;
import org.springframework.instrument.classloading.LoadTimeWeaver;

public abstract interface LoadTimeWeaverAware extends Aware
{
  public abstract void setLoadTimeWeaver(LoadTimeWeaver paramLoadTimeWeaver);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.context.weaving.LoadTimeWeaverAware
 * JD-Core Version:    0.6.2
 */