/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.jndi.JndiObjectLocator;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ 
/*     */ public abstract class AbstractSlsbInvokerInterceptor extends JndiObjectLocator
/*     */   implements MethodInterceptor
/*     */ {
/*  44 */   private boolean lookupHomeOnStartup = true;
/*     */ 
/*  46 */   private boolean cacheHome = true;
/*     */ 
/*  48 */   private boolean exposeAccessContext = false;
/*     */   private Object cachedHome;
/*     */   private Method createMethod;
/*  61 */   private final Object homeMonitor = new Object();
/*     */ 
/*     */   public void setLookupHomeOnStartup(boolean lookupHomeOnStartup)
/*     */   {
/*  72 */     this.lookupHomeOnStartup = lookupHomeOnStartup;
/*     */   }
/*     */ 
/*     */   public void setCacheHome(boolean cacheHome)
/*     */   {
/*  83 */     this.cacheHome = cacheHome;
/*     */   }
/*     */ 
/*     */   public void setExposeAccessContext(boolean exposeAccessContext)
/*     */   {
/*  95 */     this.exposeAccessContext = exposeAccessContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException
/*     */   {
/* 106 */     super.afterPropertiesSet();
/* 107 */     if (this.lookupHomeOnStartup)
/*     */     {
/* 109 */       refreshHome();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void refreshHome()
/*     */     throws NamingException
/*     */   {
/* 121 */     synchronized (this.homeMonitor) {
/* 122 */       Object home = lookup();
/* 123 */       if (this.cacheHome) {
/* 124 */         this.cachedHome = home;
/* 125 */         this.createMethod = getCreateMethod(home);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Method getCreateMethod(Object home)
/*     */     throws EjbAccessException
/*     */   {
/*     */     try
/*     */     {
/* 139 */       return home.getClass().getMethod("create", (Class[])null);
/*     */     } catch (NoSuchMethodException ex) {
/*     */     }
/* 142 */     throw new EjbAccessException("EJB home [" + home + "] has no no-arg create() method");
/*     */   }
/*     */ 
/*     */   protected Object getHome()
/*     */     throws NamingException
/*     */   {
/* 159 */     if ((!this.cacheHome) || ((this.lookupHomeOnStartup) && (!isHomeRefreshable()))) {
/* 160 */       return this.cachedHome != null ? this.cachedHome : lookup();
/*     */     }
/*     */ 
/* 163 */     synchronized (this.homeMonitor) {
/* 164 */       if (this.cachedHome == null) {
/* 165 */         this.cachedHome = lookup();
/* 166 */         this.createMethod = getCreateMethod(this.cachedHome);
/*     */       }
/* 168 */       return this.cachedHome;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isHomeRefreshable()
/*     */   {
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 188 */     Context ctx = this.exposeAccessContext ? getJndiTemplate().getContext() : null;
/*     */     try {
/* 190 */       return invokeInContext(invocation);
/*     */     }
/*     */     finally {
/* 193 */       getJndiTemplate().releaseContext(ctx);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract Object invokeInContext(MethodInvocation paramMethodInvocation)
/*     */     throws Throwable;
/*     */ 
/*     */   protected Object create()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/*     */     try
/*     */     {
/* 216 */       Object home = getHome();
/* 217 */       Method createMethodToUse = this.createMethod;
/* 218 */       if (createMethodToUse == null) {
/* 219 */         createMethodToUse = getCreateMethod(home);
/*     */       }
/* 221 */       if (createMethodToUse == null) {
/* 222 */         return home;
/*     */       }
/*     */ 
/* 225 */       return createMethodToUse.invoke(home, (Object[])null);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 228 */       throw new EjbAccessException("Could not access EJB home create() method", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.access.AbstractSlsbInvokerInterceptor
 * JD-Core Version:    0.6.2
 */