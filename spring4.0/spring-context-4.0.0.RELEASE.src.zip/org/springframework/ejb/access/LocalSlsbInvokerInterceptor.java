/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.ejb.CreateException;
/*     */ import javax.ejb.EJBLocalHome;
/*     */ import javax.ejb.EJBLocalObject;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class LocalSlsbInvokerInterceptor extends AbstractSlsbInvokerInterceptor
/*     */ {
/*  53 */   private volatile boolean homeAsComponent = false;
/*     */ 
/*     */   public Object invokeInContext(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  65 */     Object ejb = null;
/*     */     try {
/*  67 */       ejb = getSessionBeanInstance();
/*  68 */       Method method = invocation.getMethod();
/*  69 */       if (method.getDeclaringClass().isInstance(ejb))
/*     */       {
/*  71 */         return method.invoke(ejb, invocation.getArguments());
/*     */       }
/*     */ 
/*  75 */       Method ejbMethod = ejb.getClass().getMethod(method.getName(), method.getParameterTypes());
/*  76 */       return ejbMethod.invoke(ejb, invocation.getArguments());
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/*  80 */       Throwable targetEx = ex.getTargetException();
/*  81 */       if (this.logger.isDebugEnabled()) {
/*  82 */         this.logger.debug("Method of local EJB [" + getJndiName() + "] threw exception", targetEx);
/*     */       }
/*  84 */       if ((targetEx instanceof CreateException)) {
/*  85 */         throw new EjbAccessException("Could not create local EJB [" + getJndiName() + "]", targetEx);
/*     */       }
/*     */ 
/*  88 */       throw targetEx;
/*     */     }
/*     */     catch (NamingException ex)
/*     */     {
/*  92 */       throw new EjbAccessException("Failed to locate local EJB [" + getJndiName() + "]", ex);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/*  96 */       throw new EjbAccessException("Could not access method [" + invocation.getMethod().getName() + "] of local EJB [" + 
/*  96 */         getJndiName() + "]", ex);
/*     */     }
/*     */     finally {
/*  99 */       if ((ejb instanceof EJBLocalObject))
/* 100 */         releaseSessionBeanInstance((EJBLocalObject)ejb);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Method getCreateMethod(Object home)
/*     */     throws EjbAccessException
/*     */   {
/* 110 */     if (this.homeAsComponent) {
/* 111 */       return null;
/*     */     }
/* 113 */     if (!(home instanceof EJBLocalHome))
/*     */     {
/* 115 */       this.homeAsComponent = true;
/* 116 */       return null;
/*     */     }
/* 118 */     return super.getCreateMethod(home);
/*     */   }
/*     */ 
/*     */   protected Object getSessionBeanInstance()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/* 129 */     return newSessionBeanInstance();
/*     */   }
/*     */ 
/*     */   protected void releaseSessionBeanInstance(EJBLocalObject ejb)
/*     */   {
/* 139 */     removeSessionBeanInstance(ejb);
/*     */   }
/*     */ 
/*     */   protected Object newSessionBeanInstance()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/* 150 */     if (this.logger.isDebugEnabled()) {
/* 151 */       this.logger.debug("Trying to create reference to local EJB");
/*     */     }
/* 153 */     Object ejbInstance = create();
/* 154 */     if (this.logger.isDebugEnabled()) {
/* 155 */       this.logger.debug("Obtained reference to local EJB: " + ejbInstance);
/*     */     }
/* 157 */     return ejbInstance;
/*     */   }
/*     */ 
/*     */   protected void removeSessionBeanInstance(EJBLocalObject ejb)
/*     */   {
/* 166 */     if ((ejb != null) && (!this.homeAsComponent))
/*     */       try {
/* 168 */         ejb.remove();
/*     */       }
/*     */       catch (Throwable ex) {
/* 171 */         this.logger.warn("Could not invoke 'remove' on local EJB proxy", ex);
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.access.LocalSlsbInvokerInterceptor
 * JD-Core Version:    0.6.2
 */