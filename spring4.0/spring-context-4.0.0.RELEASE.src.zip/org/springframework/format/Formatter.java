package org.springframework.format;

public abstract interface Formatter<T> extends Printer<T>, Parser<T>
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.Formatter
 * JD-Core Version:    0.6.2
 */