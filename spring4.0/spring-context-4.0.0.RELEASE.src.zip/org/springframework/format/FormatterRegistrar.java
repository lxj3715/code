package org.springframework.format;

public abstract interface FormatterRegistrar
{
  public abstract void registerFormatters(FormatterRegistry paramFormatterRegistry);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.FormatterRegistrar
 * JD-Core Version:    0.6.2
 */