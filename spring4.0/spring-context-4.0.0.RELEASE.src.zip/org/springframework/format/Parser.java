package org.springframework.format;

import java.text.ParseException;
import java.util.Locale;

public abstract interface Parser<T>
{
  public abstract T parse(String paramString, Locale paramLocale)
    throws ParseException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.Parser
 * JD-Core Version:    0.6.2
 */