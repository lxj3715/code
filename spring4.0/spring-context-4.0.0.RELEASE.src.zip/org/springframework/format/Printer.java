package org.springframework.format;

import java.util.Locale;

public abstract interface Printer<T>
{
  public abstract String print(T paramT, Locale paramLocale);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.Printer
 * JD-Core Version:    0.6.2
 */