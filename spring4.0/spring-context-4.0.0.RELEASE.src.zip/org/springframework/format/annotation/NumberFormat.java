/*    */ package org.springframework.format.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ 
/*    */ @Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.PARAMETER})
/*    */ @Retention(RetentionPolicy.RUNTIME)
/*    */ public @interface NumberFormat
/*    */ {
/*    */   public abstract Style style();
/*    */ 
/*    */   public abstract String pattern();
/*    */ 
/*    */   public static enum Style
/*    */   {
/* 69 */     NUMBER, 
/*    */ 
/* 74 */     CURRENCY, 
/*    */ 
/* 79 */     PERCENT;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.annotation.NumberFormat
 * JD-Core Version:    0.6.2
 */