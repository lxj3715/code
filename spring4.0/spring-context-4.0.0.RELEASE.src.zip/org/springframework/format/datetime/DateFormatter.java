/*     */ package org.springframework.format.datetime;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class DateFormatter
/*     */   implements Formatter<Date>
/*     */ {
/*  53 */   private static final Map<DateTimeFormat.ISO, String> ISO_PATTERNS = Collections.unmodifiableMap(formats);
/*     */   private String pattern;
/*  59 */   private int style = 2;
/*     */   private String stylePattern;
/*     */   private DateTimeFormat.ISO iso;
/*     */   private TimeZone timeZone;
/*  67 */   private boolean lenient = false;
/*     */ 
/*     */   public DateFormatter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DateFormatter(String pattern)
/*     */   {
/*  80 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/*  89 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */   public void setIso(DateTimeFormat.ISO iso)
/*     */   {
/*  98 */     this.iso = iso;
/*     */   }
/*     */ 
/*     */   public void setStyle(int style)
/*     */   {
/* 111 */     this.style = style;
/*     */   }
/*     */ 
/*     */   public void setStylePattern(String stylePattern)
/*     */   {
/* 129 */     this.stylePattern = stylePattern;
/*     */   }
/*     */ 
/*     */   public void setTimeZone(TimeZone timeZone)
/*     */   {
/* 136 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */   public void setLenient(boolean lenient)
/*     */   {
/* 145 */     this.lenient = lenient;
/*     */   }
/*     */ 
/*     */   public String print(Date date, Locale locale)
/*     */   {
/* 151 */     return getDateFormat(locale).format(date);
/*     */   }
/*     */ 
/*     */   public Date parse(String text, Locale locale) throws ParseException
/*     */   {
/* 156 */     return getDateFormat(locale).parse(text);
/*     */   }
/*     */ 
/*     */   protected DateFormat getDateFormat(Locale locale)
/*     */   {
/* 161 */     DateFormat dateFormat = createDateFormat(locale);
/* 162 */     if (this.timeZone != null) {
/* 163 */       dateFormat.setTimeZone(this.timeZone);
/*     */     }
/* 165 */     dateFormat.setLenient(this.lenient);
/* 166 */     return dateFormat;
/*     */   }
/*     */ 
/*     */   private DateFormat createDateFormat(Locale locale) {
/* 170 */     if (StringUtils.hasLength(this.pattern)) {
/* 171 */       return new SimpleDateFormat(this.pattern, locale);
/*     */     }
/* 173 */     if ((this.iso != null) && (this.iso != DateTimeFormat.ISO.NONE)) {
/* 174 */       String pattern = (String)ISO_PATTERNS.get(this.iso);
/* 175 */       if (pattern == null) {
/* 176 */         throw new IllegalStateException("Unsupported ISO format " + this.iso);
/*     */       }
/* 178 */       SimpleDateFormat format = new SimpleDateFormat(pattern);
/* 179 */       format.setTimeZone(TimeZone.getTimeZone("UTC"));
/* 180 */       return format;
/*     */     }
/* 182 */     if (StringUtils.hasLength(this.stylePattern)) {
/* 183 */       int dateStyle = getStylePatternForChar(0);
/* 184 */       int timeStyle = getStylePatternForChar(1);
/* 185 */       if ((dateStyle != -1) && (timeStyle != -1)) {
/* 186 */         return DateFormat.getDateTimeInstance(dateStyle, timeStyle, locale);
/*     */       }
/* 188 */       if (dateStyle != -1) {
/* 189 */         return DateFormat.getDateInstance(dateStyle, locale);
/*     */       }
/* 191 */       if (timeStyle != -1) {
/* 192 */         return DateFormat.getTimeInstance(timeStyle, locale);
/*     */       }
/* 194 */       throw new IllegalStateException("Unsupported style pattern '" + this.stylePattern + "'");
/*     */     }
/*     */ 
/* 197 */     return DateFormat.getDateInstance(this.style, locale);
/*     */   }
/*     */ 
/*     */   private int getStylePatternForChar(int index) {
/* 201 */     if ((this.stylePattern != null) && (this.stylePattern.length() > index)) {
/* 202 */       switch (this.stylePattern.charAt(index)) { case 'S':
/* 203 */         return 3;
/*     */       case 'M':
/* 204 */         return 2;
/*     */       case 'L':
/* 205 */         return 1;
/*     */       case 'F':
/* 206 */         return 0;
/*     */       case '-':
/* 207 */         return -1;
/*     */       }
/*     */     }
/* 210 */     throw new IllegalStateException("Unsupported style pattern '" + this.stylePattern + "'");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  49 */     Map formats = new HashMap(4);
/*  50 */     formats.put(DateTimeFormat.ISO.DATE, "yyyy-MM-dd");
/*  51 */     formats.put(DateTimeFormat.ISO.TIME, "HH:mm:ss.SSSZ");
/*  52 */     formats.put(DateTimeFormat.ISO.DATE_TIME, "yyyy-MM-dd'T'HH:mm:ss.SSSZ");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.DateFormatter
 * JD-Core Version:    0.6.2
 */