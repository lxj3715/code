/*    */ package org.springframework.format.datetime;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Collections;
/*    */ import java.util.Date;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.context.EmbeddedValueResolverAware;
/*    */ import org.springframework.format.AnnotationFormatterFactory;
/*    */ import org.springframework.format.Formatter;
/*    */ import org.springframework.format.Parser;
/*    */ import org.springframework.format.Printer;
/*    */ import org.springframework.format.annotation.DateTimeFormat;
/*    */ import org.springframework.util.StringValueResolver;
/*    */ 
/*    */ public class DateTimeFormatAnnotationFormatterFactory
/*    */   implements AnnotationFormatterFactory<DateTimeFormat>, EmbeddedValueResolverAware
/*    */ {
/* 51 */   private static final Set<Class<?>> FIELD_TYPES = Collections.unmodifiableSet(fieldTypes);
/*    */   private StringValueResolver embeddedValueResolver;
/*    */ 
/*    */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*    */   {
/* 60 */     this.embeddedValueResolver = resolver;
/*    */   }
/*    */ 
/*    */   public Set<Class<?>> getFieldTypes()
/*    */   {
/* 65 */     return FIELD_TYPES;
/*    */   }
/*    */ 
/*    */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType)
/*    */   {
/* 70 */     return getFormatter(annotation, fieldType);
/*    */   }
/*    */ 
/*    */   public Parser<?> getParser(DateTimeFormat annotation, Class<?> fieldType)
/*    */   {
/* 75 */     return getFormatter(annotation, fieldType);
/*    */   }
/*    */ 
/*    */   protected Formatter<Date> getFormatter(DateTimeFormat annotation, Class<?> fieldType) {
/* 79 */     DateFormatter formatter = new DateFormatter();
/* 80 */     formatter.setStylePattern(resolveEmbeddedValue(annotation.style()));
/* 81 */     formatter.setIso(annotation.iso());
/* 82 */     formatter.setPattern(resolveEmbeddedValue(annotation.pattern()));
/* 83 */     return formatter;
/*    */   }
/*    */ 
/*    */   protected String resolveEmbeddedValue(String value) {
/* 87 */     return this.embeddedValueResolver != null ? this.embeddedValueResolver.resolveStringValue(value) : value;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 47 */     Set fieldTypes = new HashSet(4);
/* 48 */     fieldTypes.add(Date.class);
/* 49 */     fieldTypes.add(Calendar.class);
/* 50 */     fieldTypes.add(Long.class);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.DateTimeFormatAnnotationFormatterFactory
 * JD-Core Version:    0.6.2
 */