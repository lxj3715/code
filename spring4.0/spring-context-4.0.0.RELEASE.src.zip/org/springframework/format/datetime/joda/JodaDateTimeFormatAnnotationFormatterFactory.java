/*     */ package org.springframework.format.datetime.joda;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.joda.time.LocalDate;
/*     */ import org.joda.time.LocalDateTime;
/*     */ import org.joda.time.LocalTime;
/*     */ import org.joda.time.ReadableInstant;
/*     */ import org.joda.time.ReadablePartial;
/*     */ import org.joda.time.format.DateTimeFormatter;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class JodaDateTimeFormatAnnotationFormatterFactory
/*     */   implements AnnotationFormatterFactory<DateTimeFormat>, EmbeddedValueResolverAware
/*     */ {
/*  68 */   private static final Set<Class<?>> FIELD_TYPES = Collections.unmodifiableSet(fieldTypes);
/*     */   private StringValueResolver embeddedValueResolver;
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/*  77 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   protected String resolveEmbeddedValue(String value) {
/*  81 */     return this.embeddedValueResolver != null ? this.embeddedValueResolver.resolveStringValue(value) : value;
/*     */   }
/*     */ 
/*     */   public final Set<Class<?>> getFieldTypes()
/*     */   {
/*  87 */     return FIELD_TYPES;
/*     */   }
/*     */ 
/*     */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/*  92 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/*  93 */     if (ReadablePartial.class.isAssignableFrom(fieldType)) {
/*  94 */       return new ReadablePartialPrinter(formatter);
/*     */     }
/*  96 */     if ((ReadableInstant.class.isAssignableFrom(fieldType)) || (Calendar.class.isAssignableFrom(fieldType)))
/*     */     {
/*  98 */       return new ReadableInstantPrinter(formatter);
/*     */     }
/*     */ 
/* 102 */     return new MillisecondInstantPrinter(formatter);
/*     */   }
/*     */ 
/*     */   public Parser<?> getParser(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/* 108 */     if (LocalDate.class.equals(fieldType)) {
/* 109 */       return new LocalDateParser(getFormatter(annotation, fieldType));
/*     */     }
/* 111 */     if (LocalTime.class.equals(fieldType)) {
/* 112 */       return new LocalTimeParser(getFormatter(annotation, fieldType));
/*     */     }
/* 114 */     if (LocalDateTime.class.equals(fieldType)) {
/* 115 */       return new LocalDateTimeParser(getFormatter(annotation, fieldType));
/*     */     }
/*     */ 
/* 118 */     return new DateTimeParser(getFormatter(annotation, fieldType));
/*     */   }
/*     */ 
/*     */   protected DateTimeFormatter getFormatter(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/* 130 */     DateTimeFormatterFactory factory = new DateTimeFormatterFactory();
/* 131 */     factory.setStyle(resolveEmbeddedValue(annotation.style()));
/* 132 */     factory.setIso(annotation.iso());
/* 133 */     factory.setPattern(resolveEmbeddedValue(annotation.pattern()));
/* 134 */     return factory.createDateTimeFormatter();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  60 */     Set fieldTypes = new HashSet(8);
/*  61 */     fieldTypes.add(ReadableInstant.class);
/*  62 */     fieldTypes.add(LocalDate.class);
/*  63 */     fieldTypes.add(LocalTime.class);
/*  64 */     fieldTypes.add(LocalDateTime.class);
/*  65 */     fieldTypes.add(Date.class);
/*  66 */     fieldTypes.add(Calendar.class);
/*  67 */     fieldTypes.add(Long.class);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.JodaDateTimeFormatAnnotationFormatterFactory
 * JD-Core Version:    0.6.2
 */