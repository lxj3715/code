/*     */ package org.springframework.format.datetime.joda;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.joda.time.LocalDate;
/*     */ import org.joda.time.LocalDateTime;
/*     */ import org.joda.time.LocalTime;
/*     */ import org.joda.time.ReadableInstant;
/*     */ import org.joda.time.format.DateTimeFormat;
/*     */ import org.joda.time.format.DateTimeFormatter;
/*     */ import org.springframework.format.FormatterRegistrar;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ 
/*     */ public class JodaTimeFormatterRegistrar
/*     */   implements FormatterRegistrar
/*     */ {
/*  63 */   private final Map<Type, DateTimeFormatter> formatters = new HashMap();
/*     */   private final Map<Type, DateTimeFormatterFactory> factories;
/*     */ 
/*     */   public JodaTimeFormatterRegistrar()
/*     */   {
/*  72 */     this.factories = new HashMap();
/*  73 */     for (Type type : Type.values())
/*  74 */       this.factories.put(type, new DateTimeFormatterFactory());
/*     */   }
/*     */ 
/*     */   public void setUseIsoFormat(boolean useIsoFormat)
/*     */   {
/*  86 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE : null);
/*  87 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.TIME : null);
/*  88 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE_TIME : null);
/*     */   }
/*     */ 
/*     */   public void setDateStyle(String dateStyle)
/*     */   {
/*  96 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setStyle(dateStyle + "-");
/*     */   }
/*     */ 
/*     */   public void setTimeStyle(String timeStyle)
/*     */   {
/* 104 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setStyle("-" + timeStyle);
/*     */   }
/*     */ 
/*     */   public void setDateTimeStyle(String dateTimeStyle)
/*     */   {
/* 113 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setStyle(dateTimeStyle);
/*     */   }
/*     */ 
/*     */   public void setDateFormatter(DateTimeFormatter formatter)
/*     */   {
/* 127 */     this.formatters.put(Type.DATE, formatter);
/*     */   }
/*     */ 
/*     */   public void setTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 141 */     this.formatters.put(Type.TIME, formatter);
/*     */   }
/*     */ 
/*     */   public void setDateTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 156 */     this.formatters.put(Type.DATE_TIME, formatter);
/*     */   }
/*     */ 
/*     */   public void registerFormatters(FormatterRegistry registry)
/*     */   {
/* 162 */     JodaTimeConverters.registerConverters(registry);
/*     */ 
/* 164 */     DateTimeFormatter dateFormatter = getFormatter(Type.DATE);
/* 165 */     DateTimeFormatter timeFormatter = getFormatter(Type.TIME);
/* 166 */     DateTimeFormatter dateTimeFormatter = getFormatter(Type.DATE_TIME);
/*     */ 
/* 168 */     addFormatterForFields(registry, new ReadablePartialPrinter(dateFormatter), new LocalDateParser(dateFormatter), new Class[] { LocalDate.class });
/*     */ 
/* 173 */     addFormatterForFields(registry, new ReadablePartialPrinter(timeFormatter), new LocalTimeParser(timeFormatter), new Class[] { LocalTime.class });
/*     */ 
/* 178 */     addFormatterForFields(registry, new ReadablePartialPrinter(dateTimeFormatter), new LocalDateTimeParser(dateTimeFormatter), new Class[] { LocalDateTime.class });
/*     */ 
/* 183 */     addFormatterForFields(registry, new ReadableInstantPrinter(dateTimeFormatter), new DateTimeParser(dateTimeFormatter), new Class[] { ReadableInstant.class });
/*     */ 
/* 190 */     if (this.formatters.containsKey(Type.DATE_TIME)) {
/* 191 */       addFormatterForFields(registry, new ReadableInstantPrinter(dateTimeFormatter), new DateTimeParser(dateTimeFormatter), new Class[] { Date.class, Calendar.class });
/*     */     }
/*     */ 
/* 197 */     registry.addFormatterForFieldAnnotation(new JodaDateTimeFormatAnnotationFormatterFactory());
/*     */   }
/*     */ 
/*     */   private DateTimeFormatter getFormatter(Type type) {
/* 201 */     DateTimeFormatter formatter = (DateTimeFormatter)this.formatters.get(type);
/* 202 */     if (formatter != null) {
/* 203 */       return formatter;
/*     */     }
/* 205 */     DateTimeFormatter fallbackFormatter = getFallbackFormatter(type);
/* 206 */     return ((DateTimeFormatterFactory)this.factories.get(type)).createDateTimeFormatter(fallbackFormatter);
/*     */   }
/*     */ 
/*     */   private DateTimeFormatter getFallbackFormatter(Type type) {
/* 210 */     switch (1.$SwitchMap$org$springframework$format$datetime$joda$JodaTimeFormatterRegistrar$Type[type.ordinal()]) { case 1:
/* 211 */       return DateTimeFormat.shortDate();
/*     */     case 2:
/* 212 */       return DateTimeFormat.shortTime(); }
/* 213 */     return DateTimeFormat.shortDateTime();
/*     */   }
/*     */ 
/*     */   private void addFormatterForFields(FormatterRegistry registry, Printer<?> printer, Parser<?> parser, Class<?>[] fieldTypes)
/*     */   {
/* 220 */     for (Class fieldType : fieldTypes)
/* 221 */       registry.addFormatterForFieldType(fieldType, printer, parser);
/*     */   }
/*     */ 
/*     */   private static enum Type
/*     */   {
/*  57 */     DATE, TIME, DATE_TIME;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.JodaTimeFormatterRegistrar
 * JD-Core Version:    0.6.2
 */