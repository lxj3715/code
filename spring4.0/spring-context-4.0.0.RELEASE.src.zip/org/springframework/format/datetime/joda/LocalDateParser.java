/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.joda.time.LocalDate;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Parser;
/*    */ 
/*    */ public final class LocalDateParser
/*    */   implements Parser<LocalDate>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */ 
/*    */   public LocalDateParser(DateTimeFormatter formatter)
/*    */   {
/* 44 */     this.formatter = formatter;
/*    */   }
/*    */ 
/*    */   public LocalDate parse(String text, Locale locale)
/*    */     throws ParseException
/*    */   {
/* 50 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).parseLocalDate(text);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.LocalDateParser
 * JD-Core Version:    0.6.2
 */