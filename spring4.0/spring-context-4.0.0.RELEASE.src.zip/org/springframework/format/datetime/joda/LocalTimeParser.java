/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.joda.time.LocalTime;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Parser;
/*    */ 
/*    */ public final class LocalTimeParser
/*    */   implements Parser<LocalTime>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */ 
/*    */   public LocalTimeParser(DateTimeFormatter formatter)
/*    */   {
/* 44 */     this.formatter = formatter;
/*    */   }
/*    */ 
/*    */   public LocalTime parse(String text, Locale locale)
/*    */     throws ParseException
/*    */   {
/* 50 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).parseLocalTime(text);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.LocalTimeParser
 * JD-Core Version:    0.6.2
 */