/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Printer;
/*    */ 
/*    */ public final class MillisecondInstantPrinter
/*    */   implements Printer<Long>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */ 
/*    */   public MillisecondInstantPrinter(DateTimeFormatter formatter)
/*    */   {
/* 41 */     this.formatter = formatter;
/*    */   }
/*    */ 
/*    */   public String print(Long instant, Locale locale)
/*    */   {
/* 47 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).print(instant.longValue());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.MillisecondInstantPrinter
 * JD-Core Version:    0.6.2
 */