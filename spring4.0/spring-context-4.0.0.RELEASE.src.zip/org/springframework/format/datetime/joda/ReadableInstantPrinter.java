/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.joda.time.ReadableInstant;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Printer;
/*    */ 
/*    */ public final class ReadableInstantPrinter
/*    */   implements Printer<ReadableInstant>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */ 
/*    */   public ReadableInstantPrinter(DateTimeFormatter formatter)
/*    */   {
/* 42 */     this.formatter = formatter;
/*    */   }
/*    */ 
/*    */   public String print(ReadableInstant instant, Locale locale)
/*    */   {
/* 48 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).print(instant);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.ReadableInstantPrinter
 * JD-Core Version:    0.6.2
 */