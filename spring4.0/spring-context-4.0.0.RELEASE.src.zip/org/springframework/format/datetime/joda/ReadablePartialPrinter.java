/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.joda.time.ReadablePartial;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Printer;
/*    */ 
/*    */ public final class ReadablePartialPrinter
/*    */   implements Printer<ReadablePartial>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */ 
/*    */   public ReadablePartialPrinter(DateTimeFormatter formatter)
/*    */   {
/* 42 */     this.formatter = formatter;
/*    */   }
/*    */ 
/*    */   public String print(ReadablePartial partial, Locale locale)
/*    */   {
/* 48 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).print(partial);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.ReadablePartialPrinter
 * JD-Core Version:    0.6.2
 */