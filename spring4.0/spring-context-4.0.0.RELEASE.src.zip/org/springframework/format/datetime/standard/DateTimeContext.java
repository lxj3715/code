/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.time.ZoneId;
/*     */ import java.time.chrono.Chronology;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ 
/*     */ public class DateTimeContext
/*     */ {
/*     */   private Chronology chronology;
/*     */   private ZoneId timeZone;
/*     */ 
/*     */   public void setChronology(Chronology chronology)
/*     */   {
/*  48 */     this.chronology = chronology;
/*     */   }
/*     */ 
/*     */   public Chronology getChronology()
/*     */   {
/*  55 */     return this.chronology;
/*     */   }
/*     */ 
/*     */   public void setTimeZone(ZoneId timeZone)
/*     */   {
/*  67 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */   public ZoneId getTimeZone()
/*     */   {
/*  74 */     return this.timeZone;
/*     */   }
/*     */ 
/*     */   public DateTimeFormatter getFormatter(DateTimeFormatter formatter)
/*     */   {
/*  86 */     if (this.chronology != null) {
/*  87 */       formatter = formatter.withChronology(this.chronology);
/*     */     }
/*  89 */     if (this.timeZone != null) {
/*  90 */       formatter = formatter.withZone(this.timeZone);
/*     */     }
/*     */     else {
/*  93 */       LocaleContext localeContext = LocaleContextHolder.getLocaleContext();
/*  94 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/*  95 */         TimeZone timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*  96 */         if (timeZone != null) {
/*  97 */           formatter = formatter.withZone(timeZone.toZoneId());
/*     */         }
/*     */       }
/*     */     }
/* 101 */     return formatter;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.standard.DateTimeContext
 * JD-Core Version:    0.6.2
 */