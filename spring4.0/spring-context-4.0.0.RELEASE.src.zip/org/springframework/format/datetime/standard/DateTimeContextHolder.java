/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Locale;
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ 
/*    */ public final class DateTimeContextHolder
/*    */ {
/* 32 */   private static final ThreadLocal<DateTimeContext> dateTimeContextHolder = new NamedThreadLocal("DateTime Context");
/*    */ 
/*    */   public static void resetDateTimeContext()
/*    */   {
/* 40 */     dateTimeContextHolder.remove();
/*    */   }
/*    */ 
/*    */   public static void setDateTimeContext(DateTimeContext dateTimeContext)
/*    */   {
/* 49 */     if (dateTimeContext == null) {
/* 50 */       resetDateTimeContext();
/*    */     }
/*    */     else
/* 53 */       dateTimeContextHolder.set(dateTimeContext);
/*    */   }
/*    */ 
/*    */   public static DateTimeContext getDateTimeContext()
/*    */   {
/* 62 */     return (DateTimeContext)dateTimeContextHolder.get();
/*    */   }
/*    */ 
/*    */   public static DateTimeFormatter getFormatter(DateTimeFormatter formatter, Locale locale)
/*    */   {
/* 74 */     DateTimeFormatter formatterToUse = locale != null ? formatter.withLocale(locale) : formatter;
/* 75 */     DateTimeContext context = getDateTimeContext();
/* 76 */     return context != null ? context.getFormatter(formatterToUse) : formatterToUse;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.standard.DateTimeContextHolder
 * JD-Core Version:    0.6.2
 */