/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class DateTimeFormatterFactory
/*     */ {
/*     */   private String pattern;
/*     */   private DateTimeFormat.ISO iso;
/*     */   private FormatStyle dateStyle;
/*     */   private FormatStyle timeStyle;
/*     */   private TimeZone timeZone;
/*     */ 
/*     */   public DateTimeFormatterFactory()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DateTimeFormatterFactory(String pattern)
/*     */   {
/*  69 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/*  78 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */   public void setIso(DateTimeFormat.ISO iso)
/*     */   {
/*  86 */     this.iso = iso;
/*     */   }
/*     */ 
/*     */   public void setDateStyle(FormatStyle dateStyle)
/*     */   {
/*  93 */     this.dateStyle = dateStyle;
/*     */   }
/*     */ 
/*     */   public void setTimeStyle(FormatStyle timeStyle)
/*     */   {
/* 100 */     this.timeStyle = timeStyle;
/*     */   }
/*     */ 
/*     */   public void setDateTimeStyle(FormatStyle dateTimeStyle)
/*     */   {
/* 107 */     this.dateStyle = dateTimeStyle;
/* 108 */     this.timeStyle = dateTimeStyle;
/*     */   }
/*     */ 
/*     */   public void setStylePattern(String style)
/*     */   {
/* 128 */     Assert.isTrue((style != null) && (style.length() == 2));
/* 129 */     this.dateStyle = convertStyleCharacter(style.charAt(0));
/* 130 */     this.timeStyle = convertStyleCharacter(style.charAt(1));
/*     */   }
/*     */ 
/*     */   private FormatStyle convertStyleCharacter(char c) {
/* 134 */     switch (c) { case 'S':
/* 135 */       return FormatStyle.SHORT;
/*     */     case 'M':
/* 136 */       return FormatStyle.MEDIUM;
/*     */     case 'L':
/* 137 */       return FormatStyle.LONG;
/*     */     case 'F':
/* 138 */       return FormatStyle.FULL;
/*     */     case '-':
/* 139 */       return null; }
/* 140 */     throw new IllegalArgumentException("Invalid style character '" + c + "'");
/*     */   }
/*     */ 
/*     */   public void setTimeZone(TimeZone timeZone)
/*     */   {
/* 149 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */   public DateTimeFormatter createDateTimeFormatter()
/*     */   {
/* 161 */     return createDateTimeFormatter(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM));
/*     */   }
/*     */ 
/*     */   public DateTimeFormatter createDateTimeFormatter(DateTimeFormatter fallbackFormatter)
/*     */   {
/* 173 */     DateTimeFormatter dateTimeFormatter = null;
/* 174 */     if (StringUtils.hasLength(this.pattern)) {
/* 175 */       dateTimeFormatter = DateTimeFormatter.ofPattern(this.pattern);
/*     */     } else {
/* 177 */       if ((this.iso != null) && (this.iso != DateTimeFormat.ISO.NONE));
/* 178 */       switch (1.$SwitchMap$org$springframework$format$annotation$DateTimeFormat$ISO[this.iso.ordinal()]) {
/*     */       case 1:
/* 180 */         dateTimeFormatter = DateTimeFormatter.ISO_DATE;
/* 181 */         break;
/*     */       case 2:
/* 183 */         dateTimeFormatter = DateTimeFormatter.ISO_TIME;
/* 184 */         break;
/*     */       case 3:
/* 186 */         dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;
/* 187 */         break;
/*     */       case 4:
/* 190 */         break;
/*     */       default:
/* 192 */         throw new IllegalStateException("Unsupported ISO format: " + this.iso);
/*     */ 
/* 195 */         if ((this.dateStyle != null) && (this.timeStyle != null)) {
/* 196 */           dateTimeFormatter = DateTimeFormatter.ofLocalizedDateTime(this.dateStyle, this.timeStyle);
/*     */         }
/* 198 */         else if (this.dateStyle != null) {
/* 199 */           dateTimeFormatter = DateTimeFormatter.ofLocalizedDate(this.dateStyle);
/*     */         }
/* 201 */         else if (this.timeStyle != null)
/* 202 */           dateTimeFormatter = DateTimeFormatter.ofLocalizedTime(this.timeStyle); break;
/*     */       }
/*     */     }
/* 205 */     if ((dateTimeFormatter != null) && (this.timeZone != null)) {
/* 206 */       dateTimeFormatter = dateTimeFormatter.withZone(this.timeZone.toZoneId());
/*     */     }
/* 208 */     return dateTimeFormatter != null ? dateTimeFormatter : fallbackFormatter;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.standard.DateTimeFormatterFactory
 * JD-Core Version:    0.6.2
 */