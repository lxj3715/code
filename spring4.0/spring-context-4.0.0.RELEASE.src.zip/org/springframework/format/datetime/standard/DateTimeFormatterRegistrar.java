/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.format.FormatterRegistrar;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ 
/*     */ public class DateTimeFormatterRegistrar
/*     */   implements FormatterRegistrar
/*     */ {
/*  57 */   private final Map<Type, DateTimeFormatter> formatters = new HashMap();
/*     */   private final Map<Type, DateTimeFormatterFactory> factories;
/*     */ 
/*     */   public DateTimeFormatterRegistrar()
/*     */   {
/*  66 */     this.factories = new HashMap();
/*  67 */     for (Type type : Type.values())
/*  68 */       this.factories.put(type, new DateTimeFormatterFactory());
/*     */   }
/*     */ 
/*     */   public void setUseIsoFormat(boolean useIsoFormat)
/*     */   {
/*  80 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE : null);
/*  81 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.TIME : null);
/*  82 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE_TIME : null);
/*     */   }
/*     */ 
/*     */   public void setDateStyle(FormatStyle dateStyle)
/*     */   {
/*  90 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setDateStyle(dateStyle);
/*     */   }
/*     */ 
/*     */   public void setTimeStyle(FormatStyle timeStyle)
/*     */   {
/*  98 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setTimeStyle(timeStyle);
/*     */   }
/*     */ 
/*     */   public void setDateTimeStyle(FormatStyle dateTimeStyle)
/*     */   {
/* 106 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setDateTimeStyle(dateTimeStyle);
/*     */   }
/*     */ 
/*     */   public void setDateFormatter(DateTimeFormatter formatter)
/*     */   {
/* 119 */     this.formatters.put(Type.DATE, formatter);
/*     */   }
/*     */ 
/*     */   public void setTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 132 */     this.formatters.put(Type.TIME, formatter);
/*     */   }
/*     */ 
/*     */   public void setDateTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 146 */     this.formatters.put(Type.DATE_TIME, formatter);
/*     */   }
/*     */ 
/*     */   public void registerFormatters(FormatterRegistry registry)
/*     */   {
/* 152 */     DateTimeFormatter dateFormatter = getFormatter(Type.DATE);
/* 153 */     DateTimeFormatter timeFormatter = getFormatter(Type.TIME);
/* 154 */     DateTimeFormatter dateTimeFormatter = getFormatter(Type.DATE_TIME);
/*     */ 
/* 156 */     registry.addFormatterForFieldType(LocalDate.class, new TemporalAccessorPrinter(dateFormatter), new TemporalAccessorParser(LocalDate.class, dateFormatter));
/*     */ 
/* 160 */     registry.addFormatterForFieldType(LocalTime.class, new TemporalAccessorPrinter(timeFormatter), new TemporalAccessorParser(LocalTime.class, timeFormatter));
/*     */ 
/* 164 */     registry.addFormatterForFieldType(LocalDateTime.class, new TemporalAccessorPrinter(dateTimeFormatter), new TemporalAccessorParser(LocalDateTime.class, dateTimeFormatter));
/*     */ 
/* 168 */     registry.addFormatterForFieldType(ZonedDateTime.class, new TemporalAccessorPrinter(dateTimeFormatter), new TemporalAccessorParser(ZonedDateTime.class, dateTimeFormatter));
/*     */ 
/* 172 */     registry.addFormatterForFieldType(OffsetDateTime.class, new TemporalAccessorPrinter(dateTimeFormatter), new TemporalAccessorParser(OffsetDateTime.class, dateTimeFormatter));
/*     */ 
/* 176 */     registry.addFormatterForFieldType(OffsetTime.class, new TemporalAccessorPrinter(timeFormatter), new TemporalAccessorParser(OffsetTime.class, timeFormatter));
/*     */ 
/* 180 */     registry.addFormatterForFieldType(Instant.class, new InstantFormatter());
/*     */ 
/* 182 */     registry.addFormatterForFieldAnnotation(new Jsr310DateTimeFormatAnnotationFormatterFactory());
/*     */   }
/*     */ 
/*     */   private DateTimeFormatter getFormatter(Type type) {
/* 186 */     DateTimeFormatter formatter = (DateTimeFormatter)this.formatters.get(type);
/* 187 */     if (formatter != null) {
/* 188 */       return formatter;
/*     */     }
/* 190 */     DateTimeFormatter fallbackFormatter = getFallbackFormatter(type);
/* 191 */     return ((DateTimeFormatterFactory)this.factories.get(type)).createDateTimeFormatter(fallbackFormatter);
/*     */   }
/*     */ 
/*     */   private DateTimeFormatter getFallbackFormatter(Type type) {
/* 195 */     switch (1.$SwitchMap$org$springframework$format$datetime$standard$DateTimeFormatterRegistrar$Type[type.ordinal()]) { case 1:
/* 196 */       return DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
/*     */     case 2:
/* 197 */       return DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT); }
/* 198 */     return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);
/*     */   }
/*     */ 
/*     */   private static enum Type
/*     */   {
/*  51 */     DATE, TIME, DATE_TIME;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.standard.DateTimeFormatterRegistrar
 * JD-Core Version:    0.6.2
 */