/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.time.Instant;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ public class InstantFormatter
/*    */   implements Formatter<Instant>
/*    */ {
/*    */   public Instant parse(String text, Locale locale)
/*    */     throws ParseException
/*    */   {
/* 38 */     return Instant.parse(text);
/*    */   }
/*    */ 
/*    */   public String print(Instant object, Locale locale)
/*    */   {
/* 43 */     return object.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.standard.InstantFormatter
 * JD-Core Version:    0.6.2
 */