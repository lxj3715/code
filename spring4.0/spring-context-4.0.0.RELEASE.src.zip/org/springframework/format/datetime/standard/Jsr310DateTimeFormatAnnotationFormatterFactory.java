/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class Jsr310DateTimeFormatAnnotationFormatterFactory
/*     */   implements AnnotationFormatterFactory<DateTimeFormat>, EmbeddedValueResolverAware
/*     */ {
/*  59 */   private static final Set<Class<?>> FIELD_TYPES = Collections.unmodifiableSet(fieldTypes);
/*     */   private StringValueResolver embeddedValueResolver;
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/*  68 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   protected String resolveEmbeddedValue(String value) {
/*  72 */     return this.embeddedValueResolver != null ? this.embeddedValueResolver.resolveStringValue(value) : value;
/*     */   }
/*     */ 
/*     */   public final Set<Class<?>> getFieldTypes()
/*     */   {
/*  78 */     return FIELD_TYPES;
/*     */   }
/*     */ 
/*     */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/*  83 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/*  84 */     return new TemporalAccessorPrinter(formatter);
/*     */   }
/*     */ 
/*     */   public Parser<?> getParser(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/*  90 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/*  91 */     return new TemporalAccessorParser(fieldType, formatter);
/*     */   }
/*     */ 
/*     */   protected DateTimeFormatter getFormatter(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/* 101 */     DateTimeFormatterFactory factory = new DateTimeFormatterFactory();
/* 102 */     factory.setStylePattern(resolveEmbeddedValue(annotation.style()));
/* 103 */     factory.setIso(annotation.iso());
/* 104 */     factory.setPattern(resolveEmbeddedValue(annotation.pattern()));
/* 105 */     return factory.createDateTimeFormatter();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  52 */     Set fieldTypes = new HashSet(8);
/*  53 */     fieldTypes.add(LocalDate.class);
/*  54 */     fieldTypes.add(LocalTime.class);
/*  55 */     fieldTypes.add(LocalDateTime.class);
/*  56 */     fieldTypes.add(ZonedDateTime.class);
/*  57 */     fieldTypes.add(OffsetDateTime.class);
/*  58 */     fieldTypes.add(OffsetTime.class);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.standard.Jsr310DateTimeFormatAnnotationFormatterFactory
 * JD-Core Version:    0.6.2
 */