/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.time.temporal.TemporalAccessor;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Printer;
/*    */ 
/*    */ public final class TemporalAccessorPrinter
/*    */   implements Printer<TemporalAccessor>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */ 
/*    */   public TemporalAccessorPrinter(DateTimeFormatter formatter)
/*    */   {
/* 44 */     this.formatter = formatter;
/*    */   }
/*    */ 
/*    */   public String print(TemporalAccessor partial, Locale locale)
/*    */   {
/* 50 */     return DateTimeContextHolder.getFormatter(this.formatter, locale).format(partial);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.standard.TemporalAccessorPrinter
 * JD-Core Version:    0.6.2
 */