/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.text.NumberFormat;
/*    */ import java.text.ParseException;
/*    */ import java.text.ParsePosition;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ public abstract class AbstractNumberFormatter
/*    */   implements Formatter<Number>
/*    */ {
/* 36 */   private boolean lenient = false;
/*    */ 
/*    */   public void setLenient(boolean lenient)
/*    */   {
/* 44 */     this.lenient = lenient;
/*    */   }
/*    */ 
/*    */   public String print(Number number, Locale locale)
/*    */   {
/* 49 */     return getNumberFormat(locale).format(number);
/*    */   }
/*    */ 
/*    */   public Number parse(String text, Locale locale) throws ParseException
/*    */   {
/* 54 */     NumberFormat format = getNumberFormat(locale);
/* 55 */     ParsePosition position = new ParsePosition(0);
/* 56 */     Number number = format.parse(text, position);
/* 57 */     if (position.getErrorIndex() != -1) {
/* 58 */       throw new ParseException(text, position.getIndex());
/*    */     }
/* 60 */     if ((!this.lenient) && 
/* 61 */       (text.length() != position.getIndex()))
/*    */     {
/* 63 */       throw new ParseException(text, position.getIndex());
/*    */     }
/*    */ 
/* 66 */     return number;
/*    */   }
/*    */ 
/*    */   protected abstract NumberFormat getNumberFormat(Locale paramLocale);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.AbstractNumberFormatter
 * JD-Core Version:    0.6.2
 */