/*     */ package org.springframework.format.number;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.Currency;
/*     */ import java.util.Locale;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class CurrencyFormatter extends AbstractNumberFormatter
/*     */ {
/*  45 */   private static final boolean roundingModeOnDecimalFormat = ClassUtils.hasMethod(DecimalFormat.class, "setRoundingMode", new Class[] { RoundingMode.class })
/*  45 */     ;
/*     */ 
/*  47 */   private int fractionDigits = 2;
/*     */   private RoundingMode roundingMode;
/*     */   private Currency currency;
/*     */ 
/*     */   public void setFractionDigits(int fractionDigits)
/*     */   {
/*  59 */     this.fractionDigits = fractionDigits;
/*     */   }
/*     */ 
/*     */   public void setRoundingMode(RoundingMode roundingMode)
/*     */   {
/*  67 */     this.roundingMode = roundingMode;
/*     */   }
/*     */ 
/*     */   public void setCurrency(Currency currency)
/*     */   {
/*  74 */     this.currency = currency;
/*     */   }
/*     */ 
/*     */   public BigDecimal parse(String text, Locale locale)
/*     */     throws ParseException
/*     */   {
/*  80 */     BigDecimal decimal = (BigDecimal)super.parse(text, locale);
/*  81 */     if (decimal != null) {
/*  82 */       if (this.roundingMode != null) {
/*  83 */         decimal = decimal.setScale(this.fractionDigits, this.roundingMode);
/*     */       }
/*     */       else {
/*  86 */         decimal = decimal.setScale(this.fractionDigits);
/*     */       }
/*     */     }
/*  89 */     return decimal;
/*     */   }
/*     */ 
/*     */   protected NumberFormat getNumberFormat(Locale locale)
/*     */   {
/*  94 */     DecimalFormat format = (DecimalFormat)NumberFormat.getCurrencyInstance(locale);
/*  95 */     format.setParseBigDecimal(true);
/*  96 */     format.setMaximumFractionDigits(this.fractionDigits);
/*  97 */     format.setMinimumFractionDigits(this.fractionDigits);
/*  98 */     if ((this.roundingMode != null) && (roundingModeOnDecimalFormat)) {
/*  99 */       format.setRoundingMode(this.roundingMode);
/*     */     }
/* 101 */     if (this.currency != null) {
/* 102 */       format.setCurrency(this.currency);
/*     */     }
/* 104 */     return format;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.CurrencyFormatter
 * JD-Core Version:    0.6.2
 */