/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class NumberFormatter extends AbstractNumberFormatter
/*    */ {
/*    */   private String pattern;
/*    */ 
/*    */   public NumberFormatter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NumberFormatter(String pattern)
/*    */   {
/* 54 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   public void setPattern(String pattern)
/*    */   {
/* 64 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   public NumberFormat getNumberFormat(Locale locale)
/*    */   {
/* 70 */     NumberFormat format = NumberFormat.getInstance(locale);
/* 71 */     if (!(format instanceof DecimalFormat)) {
/* 72 */       if (this.pattern != null) {
/* 73 */         throw new IllegalStateException("Cannot support pattern for non-DecimalFormat: " + format);
/*    */       }
/* 75 */       return format;
/*    */     }
/* 77 */     DecimalFormat decimalFormat = (DecimalFormat)format;
/* 78 */     decimalFormat.setParseBigDecimal(true);
/* 79 */     if (this.pattern != null) {
/* 80 */       decimalFormat.applyPattern(this.pattern);
/*    */     }
/* 82 */     return decimalFormat;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.NumberFormatter
 * JD-Core Version:    0.6.2
 */