/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class PercentFormatter extends AbstractNumberFormatter
/*    */ {
/*    */   protected NumberFormat getNumberFormat(Locale locale)
/*    */   {
/* 39 */     NumberFormat format = NumberFormat.getPercentInstance(locale);
/* 40 */     if ((format instanceof DecimalFormat)) {
/* 41 */       ((DecimalFormat)format).setParseBigDecimal(true);
/*    */     }
/* 43 */     return format;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.PercentFormatter
 * JD-Core Version:    0.6.2
 */