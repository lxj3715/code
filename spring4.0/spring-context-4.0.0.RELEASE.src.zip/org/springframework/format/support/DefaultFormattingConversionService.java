/*    */ package org.springframework.format.support;
/*    */ 
/*    */ import org.springframework.core.convert.support.DefaultConversionService;
/*    */ import org.springframework.format.FormatterRegistry;
/*    */ import org.springframework.format.datetime.DateFormatterRegistrar;
/*    */ import org.springframework.format.datetime.joda.JodaTimeFormatterRegistrar;
/*    */ import org.springframework.format.datetime.standard.DateTimeFormatterRegistrar;
/*    */ import org.springframework.format.number.NumberFormatAnnotationFormatterFactory;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.StringValueResolver;
/*    */ 
/*    */ public class DefaultFormattingConversionService extends FormattingConversionService
/*    */ {
/* 43 */   private static final boolean jsr310Present = ClassUtils.isPresent("java.time.LocalDate", DefaultFormattingConversionService.class
/* 44 */     .getClassLoader());
/*    */ 
/* 46 */   private static final boolean jodaTimePresent = ClassUtils.isPresent("org.joda.time.LocalDate", DefaultFormattingConversionService.class
/* 47 */     .getClassLoader());
/*    */ 
/*    */   public DefaultFormattingConversionService()
/*    */   {
/* 56 */     this(null, true);
/*    */   }
/*    */ 
/*    */   public DefaultFormattingConversionService(boolean registerDefaultFormatters)
/*    */   {
/* 67 */     this(null, registerDefaultFormatters);
/*    */   }
/*    */ 
/*    */   public DefaultFormattingConversionService(StringValueResolver embeddedValueResolver, boolean registerDefaultFormatters)
/*    */   {
/* 80 */     setEmbeddedValueResolver(embeddedValueResolver);
/* 81 */     DefaultConversionService.addDefaultConverters(this);
/* 82 */     if (registerDefaultFormatters)
/* 83 */       addDefaultFormatters(this);
/*    */   }
/*    */ 
/*    */   public static void addDefaultFormatters(FormatterRegistry formatterRegistry)
/*    */   {
/* 94 */     formatterRegistry.addFormatterForFieldAnnotation(new NumberFormatAnnotationFormatterFactory());
/* 95 */     if (jsr310Present)
/*    */     {
/* 97 */       new DateTimeFormatterRegistrar().registerFormatters(formatterRegistry);
/*    */     }
/* 99 */     if (jodaTimePresent)
/*    */     {
/* 101 */       new JodaTimeFormatterRegistrar().registerFormatters(formatterRegistry);
/*    */     }
/*    */     else
/*    */     {
/* 105 */       new DateFormatterRegistrar().registerFormatters(formatterRegistry);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.support.DefaultFormattingConversionService
 * JD-Core Version:    0.6.2
 */