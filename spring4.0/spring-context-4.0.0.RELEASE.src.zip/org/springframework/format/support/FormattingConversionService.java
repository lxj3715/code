/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.text.ParseException;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class FormattingConversionService extends GenericConversionService
/*     */   implements FormatterRegistry, EmbeddedValueResolverAware
/*     */ {
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   private final Map<AnnotationConverterKey, GenericConverter> cachedPrinters;
/*     */   private final Map<AnnotationConverterKey, GenericConverter> cachedParsers;
/*     */ 
/*     */   public FormattingConversionService()
/*     */   {
/*  55 */     this.cachedPrinters = new ConcurrentHashMap(64);
/*     */ 
/*  58 */     this.cachedParsers = new ConcurrentHashMap(64);
/*     */   }
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/*  64 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   public void addFormatter(Formatter<?> formatter)
/*     */   {
/*  70 */     Class fieldType = GenericTypeResolver.resolveTypeArgument(formatter.getClass(), Formatter.class);
/*  71 */     if (fieldType == null)
/*     */     {
/*  73 */       throw new IllegalArgumentException("Unable to extract parameterized field type argument from Formatter [" + formatter
/*  73 */         .getClass().getName() + "]; does the formatter parameterize the <T> generic type?");
/*     */     }
/*  75 */     addFormatterForFieldType(fieldType, formatter);
/*     */   }
/*     */ 
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Formatter<?> formatter)
/*     */   {
/*  80 */     addConverter(new PrinterConverter(fieldType, formatter, this));
/*  81 */     addConverter(new ParserConverter(fieldType, formatter, this));
/*     */   }
/*     */ 
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Printer<?> printer, Parser<?> parser)
/*     */   {
/*  86 */     addConverter(new PrinterConverter(fieldType, printer, this));
/*  87 */     addConverter(new ParserConverter(fieldType, parser, this));
/*     */   }
/*     */ 
/*     */   public void addFormatterForFieldAnnotation(AnnotationFormatterFactory annotationFormatterFactory)
/*     */   {
/*  94 */     Class annotationType = GenericTypeResolver.resolveTypeArgument(annotationFormatterFactory
/*  94 */       .getClass(), AnnotationFormatterFactory.class);
/*  95 */     if (annotationType == null)
/*     */     {
/*  97 */       throw new IllegalArgumentException("Unable to extract parameterized Annotation type argument from AnnotationFormatterFactory [" + annotationFormatterFactory
/*  97 */         .getClass().getName() + "]; does the factory parameterize the <A extends Annotation> generic type?");
/*     */     }
/*  99 */     if ((this.embeddedValueResolver != null) && ((annotationFormatterFactory instanceof EmbeddedValueResolverAware))) {
/* 100 */       ((EmbeddedValueResolverAware)annotationFormatterFactory).setEmbeddedValueResolver(this.embeddedValueResolver);
/*     */     }
/* 102 */     Set fieldTypes = annotationFormatterFactory.getFieldTypes();
/* 103 */     for (Class fieldType : fieldTypes) {
/* 104 */       addConverter(new AnnotationPrinterConverter(annotationType, annotationFormatterFactory, fieldType));
/* 105 */       addConverter(new AnnotationParserConverter(annotationType, annotationFormatterFactory, fieldType));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class AnnotationConverterKey
/*     */   {
/*     */     private final Annotation annotation;
/*     */     private final Class<?> fieldType;
/*     */ 
/*     */     public AnnotationConverterKey(Annotation annotation, Class<?> fieldType)
/*     */     {
/* 310 */       this.annotation = annotation;
/* 311 */       this.fieldType = fieldType;
/*     */     }
/*     */ 
/*     */     public Annotation getAnnotation() {
/* 315 */       return this.annotation;
/*     */     }
/*     */ 
/*     */     public Class<?> getFieldType() {
/* 319 */       return this.fieldType;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o)
/*     */     {
/* 324 */       if (!(o instanceof AnnotationConverterKey)) {
/* 325 */         return false;
/*     */       }
/* 327 */       AnnotationConverterKey key = (AnnotationConverterKey)o;
/* 328 */       return (this.annotation.equals(key.annotation)) && (this.fieldType.equals(key.fieldType));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 333 */       return this.annotation.hashCode() + 29 * this.fieldType.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AnnotationParserConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private Class<? extends Annotation> annotationType;
/*     */     private AnnotationFormatterFactory annotationFormatterFactory;
/*     */     private Class<?> fieldType;
/*     */ 
/*     */     public AnnotationParserConverter(AnnotationFormatterFactory<?> annotationType, Class<?> annotationFormatterFactory)
/*     */     {
/* 265 */       this.annotationType = annotationType;
/* 266 */       this.annotationFormatterFactory = annotationFormatterFactory;
/* 267 */       this.fieldType = fieldType;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 272 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */     }
/*     */ 
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 277 */       return targetType.hasAnnotation(this.annotationType);
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 284 */       FormattingConversionService.AnnotationConverterKey converterKey = new FormattingConversionService.AnnotationConverterKey(targetType
/* 284 */         .getAnnotation(this.annotationType), 
/* 284 */         targetType.getObjectType());
/* 285 */       GenericConverter converter = (GenericConverter)FormattingConversionService.this.cachedParsers.get(converterKey);
/* 286 */       if (converter == null) {
/* 287 */         Parser parser = this.annotationFormatterFactory.getParser(converterKey
/* 288 */           .getAnnotation(), converterKey.getFieldType());
/* 289 */         converter = new FormattingConversionService.ParserConverter(this.fieldType, parser, FormattingConversionService.this);
/* 290 */         FormattingConversionService.this.cachedParsers.put(converterKey, converter);
/*     */       }
/* 292 */       return converter.convert(source, sourceType, targetType);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 298 */       return String.class.getName() + " -> @" + this.annotationType.getName() + " " + this.fieldType
/* 298 */         .getName() + ": " + this.annotationFormatterFactory;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AnnotationPrinterConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private Class<? extends Annotation> annotationType;
/*     */     private AnnotationFormatterFactory annotationFormatterFactory;
/*     */     private Class<?> fieldType;
/*     */ 
/*     */     public AnnotationPrinterConverter(AnnotationFormatterFactory<?> annotationType, Class<?> annotationFormatterFactory)
/*     */     {
/* 216 */       this.annotationType = annotationType;
/* 217 */       this.annotationFormatterFactory = annotationFormatterFactory;
/* 218 */       this.fieldType = fieldType;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 223 */       return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */     }
/*     */ 
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 228 */       return sourceType.hasAnnotation(this.annotationType);
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 235 */       FormattingConversionService.AnnotationConverterKey converterKey = new FormattingConversionService.AnnotationConverterKey(sourceType
/* 235 */         .getAnnotation(this.annotationType), 
/* 235 */         sourceType.getObjectType());
/* 236 */       GenericConverter converter = (GenericConverter)FormattingConversionService.this.cachedPrinters.get(converterKey);
/* 237 */       if (converter == null) {
/* 238 */         Printer printer = this.annotationFormatterFactory.getPrinter(converterKey
/* 239 */           .getAnnotation(), converterKey.getFieldType());
/* 240 */         converter = new FormattingConversionService.PrinterConverter(this.fieldType, printer, FormattingConversionService.this);
/* 241 */         FormattingConversionService.this.cachedPrinters.put(converterKey, converter);
/*     */       }
/* 243 */       return converter.convert(source, sourceType, targetType);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 249 */       return "@" + this.annotationType.getName() + " " + this.fieldType.getName() + " -> " + String.class
/* 249 */         .getName() + ": " + this.annotationFormatterFactory;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ParserConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private Class<?> fieldType;
/*     */     private Parser<?> parser;
/*     */     private ConversionService conversionService;
/*     */ 
/*     */     public ParserConverter(Class<?> fieldType, Parser<?> parser, ConversionService conversionService)
/*     */     {
/* 165 */       this.fieldType = fieldType;
/* 166 */       this.parser = parser;
/* 167 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 172 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 177 */       String text = (String)source;
/* 178 */       if (!StringUtils.hasText(text)) {
/* 179 */         return null;
/*     */       }
/*     */       try
/*     */       {
/* 183 */         result = this.parser.parse(text, LocaleContextHolder.getLocale());
/*     */       }
/*     */       catch (ParseException ex)
/*     */       {
/*     */         Object result;
/* 186 */         throw new IllegalArgumentException("Unable to parse '" + text + "'", ex);
/*     */       }
/*     */       Object result;
/* 188 */       if (result == null) {
/* 189 */         throw new IllegalStateException("Parsers are not allowed to return null");
/*     */       }
/* 191 */       TypeDescriptor resultType = TypeDescriptor.valueOf(result.getClass());
/* 192 */       if (!resultType.isAssignableTo(targetType)) {
/* 193 */         result = this.conversionService.convert(result, resultType, targetType);
/*     */       }
/* 195 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 200 */       return String.class.getName() + " -> " + this.fieldType.getName() + ": " + this.parser;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PrinterConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private Class<?> fieldType;
/*     */     private TypeDescriptor printerObjectType;
/*     */     private Printer printer;
/*     */     private ConversionService conversionService;
/*     */ 
/*     */     public PrinterConverter(Class<?> fieldType, Printer<?> printer, ConversionService conversionService)
/*     */     {
/* 122 */       this.fieldType = fieldType;
/* 123 */       this.printerObjectType = TypeDescriptor.valueOf(resolvePrinterObjectType(printer));
/* 124 */       this.printer = printer;
/* 125 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 130 */       return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 136 */       if (source == null) {
/* 137 */         return "";
/*     */       }
/* 139 */       if (!sourceType.isAssignableTo(this.printerObjectType)) {
/* 140 */         source = this.conversionService.convert(source, sourceType, this.printerObjectType);
/*     */       }
/* 142 */       return this.printer.print(source, LocaleContextHolder.getLocale());
/*     */     }
/*     */ 
/*     */     private Class<?> resolvePrinterObjectType(Printer<?> printer) {
/* 146 */       return GenericTypeResolver.resolveTypeArgument(printer.getClass(), Printer.class);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 151 */       return this.fieldType.getName() + " -> " + String.class.getName() + " : " + this.printer;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.support.FormattingConversionService
 * JD-Core Version:    0.6.2
 */