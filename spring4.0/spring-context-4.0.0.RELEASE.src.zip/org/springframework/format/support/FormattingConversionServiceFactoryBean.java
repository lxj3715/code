/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.core.convert.support.ConversionServiceFactory;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistrar;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class FormattingConversionServiceFactoryBean
/*     */   implements FactoryBean<FormattingConversionService>, EmbeddedValueResolverAware, InitializingBean
/*     */ {
/*     */   private Set<?> converters;
/*     */   private Set<?> formatters;
/*     */   private Set<FormatterRegistrar> formatterRegistrars;
/*  72 */   private boolean registerDefaultFormatters = true;
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   private FormattingConversionService conversionService;
/*     */ 
/*     */   public void setConverters(Set<?> converters)
/*     */   {
/*  87 */     this.converters = converters;
/*     */   }
/*     */ 
/*     */   public void setFormatters(Set<?> formatters)
/*     */   {
/*  95 */     this.formatters = formatters;
/*     */   }
/*     */ 
/*     */   public void setFormatterRegistrars(Set<FormatterRegistrar> formatterRegistrars)
/*     */   {
/* 113 */     this.formatterRegistrars = formatterRegistrars;
/*     */   }
/*     */ 
/*     */   public void setRegisterDefaultFormatters(boolean registerDefaultFormatters)
/*     */   {
/* 124 */     this.registerDefaultFormatters = registerDefaultFormatters;
/*     */   }
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver embeddedValueResolver)
/*     */   {
/* 129 */     this.embeddedValueResolver = embeddedValueResolver;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 135 */     this.conversionService = new DefaultFormattingConversionService(this.embeddedValueResolver, this.registerDefaultFormatters);
/* 136 */     ConversionServiceFactory.registerConverters(this.converters, this.conversionService);
/* 137 */     registerFormatters();
/*     */   }
/*     */ 
/*     */   private void registerFormatters()
/*     */   {
/*     */     Iterator localIterator;
/* 141 */     if (this.formatters != null) {
/* 142 */       for (localIterator = this.formatters.iterator(); localIterator.hasNext(); ) { Object formatter = localIterator.next();
/* 143 */         if ((formatter instanceof Formatter)) {
/* 144 */           this.conversionService.addFormatter((Formatter)formatter);
/*     */         }
/* 146 */         else if ((formatter instanceof AnnotationFormatterFactory)) {
/* 147 */           this.conversionService.addFormatterForFieldAnnotation((AnnotationFormatterFactory)formatter);
/*     */         }
/*     */         else {
/* 150 */           throw new IllegalArgumentException("Custom formatters must be implementations of Formatter or AnnotationFormatterFactory");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 155 */     if (this.formatterRegistrars != null) {
/* 156 */       for (FormatterRegistrar registrar : this.formatterRegistrars) {
/* 157 */         registrar.registerFormatters(this.conversionService);
/*     */       }
/*     */     }
/* 160 */     installFormatters(this.conversionService);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected void installFormatters(FormatterRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   public FormattingConversionService getObject()
/*     */   {
/* 178 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */   public Class<? extends FormattingConversionService> getObjectType()
/*     */   {
/* 183 */     return FormattingConversionService.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 188 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.format.support.FormattingConversionServiceFactoryBean
 * JD-Core Version:    0.6.2
 */