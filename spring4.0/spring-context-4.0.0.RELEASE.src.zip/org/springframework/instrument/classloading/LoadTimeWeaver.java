package org.springframework.instrument.classloading;

import java.lang.instrument.ClassFileTransformer;

public abstract interface LoadTimeWeaver
{
  public abstract void addTransformer(ClassFileTransformer paramClassFileTransformer);

  public abstract ClassLoader getInstrumentableClassLoader();

  public abstract ClassLoader getThrowawayClassLoader();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.LoadTimeWeaver
 * JD-Core Version:    0.6.2
 */