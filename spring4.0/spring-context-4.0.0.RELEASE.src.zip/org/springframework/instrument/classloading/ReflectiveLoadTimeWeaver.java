/*     */ package org.springframework.instrument.classloading;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class ReflectiveLoadTimeWeaver
/*     */   implements LoadTimeWeaver
/*     */ {
/*     */   private static final String ADD_TRANSFORMER_METHOD_NAME = "addTransformer";
/*     */   private static final String GET_THROWAWAY_CLASS_LOADER_METHOD_NAME = "getThrowawayClassLoader";
/*  71 */   private static final Log logger = LogFactory.getLog(ReflectiveLoadTimeWeaver.class);
/*     */   private final ClassLoader classLoader;
/*     */   private final Method addTransformerMethod;
/*     */   private final Method getThrowawayClassLoaderMethod;
/*     */ 
/*     */   public ReflectiveLoadTimeWeaver()
/*     */   {
/*  86 */     this(ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public ReflectiveLoadTimeWeaver(ClassLoader classLoader)
/*     */   {
/*  97 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/*  98 */     this.classLoader = classLoader;
/*  99 */     this.addTransformerMethod = ClassUtils.getMethodIfAvailable(this.classLoader
/* 100 */       .getClass(), "addTransformer", new Class[] { ClassFileTransformer.class });
/*     */ 
/* 102 */     if (this.addTransformerMethod == null)
/*     */     {
/* 104 */       throw new IllegalStateException("ClassLoader [" + classLoader
/* 104 */         .getClass().getName() + "] does NOT provide an " + "'addTransformer(ClassFileTransformer)' method.");
/*     */     }
/*     */ 
/* 107 */     this.getThrowawayClassLoaderMethod = ClassUtils.getMethodIfAvailable(this.classLoader
/* 108 */       .getClass(), "getThrowawayClassLoader", new Class[0]);
/*     */ 
/* 110 */     if ((this.getThrowawayClassLoaderMethod == null) && 
/* 111 */       (logger.isInfoEnabled()))
/* 112 */       logger.info("The ClassLoader [" + classLoader.getClass().getName() + "] does NOT provide a " + "'getThrowawayClassLoader()' method; SimpleThrowawayClassLoader will be used instead.");
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/* 121 */     Assert.notNull(transformer, "Transformer must not be null");
/* 122 */     ReflectionUtils.invokeMethod(this.addTransformerMethod, this.classLoader, new Object[] { transformer });
/*     */   }
/*     */ 
/*     */   public ClassLoader getInstrumentableClassLoader()
/*     */   {
/* 127 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getThrowawayClassLoader()
/*     */   {
/* 132 */     if (this.getThrowawayClassLoaderMethod != null) {
/* 133 */       return (ClassLoader)ReflectionUtils.invokeMethod(this.getThrowawayClassLoaderMethod, this.classLoader);
/*     */     }
/*     */ 
/* 136 */     return new SimpleThrowawayClassLoader(this.classLoader);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.ReflectiveLoadTimeWeaver
 * JD-Core Version:    0.6.2
 */