/*    */ package org.springframework.instrument.classloading;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import org.springframework.core.OverridingClassLoader;
/*    */ 
/*    */ public class SimpleInstrumentableClassLoader extends OverridingClassLoader
/*    */ {
/*    */   private final WeavingTransformer weavingTransformer;
/*    */ 
/*    */   public SimpleInstrumentableClassLoader(ClassLoader parent)
/*    */   {
/* 44 */     super(parent);
/* 45 */     this.weavingTransformer = new WeavingTransformer(parent);
/*    */   }
/*    */ 
/*    */   public void addTransformer(ClassFileTransformer transformer)
/*    */   {
/* 55 */     this.weavingTransformer.addTransformer(transformer);
/*    */   }
/*    */ 
/*    */   protected byte[] transformIfNecessary(String name, byte[] bytes)
/*    */   {
/* 61 */     return this.weavingTransformer.transformIfNecessary(name, bytes);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.SimpleInstrumentableClassLoader
 * JD-Core Version:    0.6.2
 */