/*    */ package org.springframework.instrument.classloading;
/*    */ 
/*    */ import org.springframework.core.OverridingClassLoader;
/*    */ 
/*    */ public class SimpleThrowawayClassLoader extends OverridingClassLoader
/*    */ {
/*    */   public SimpleThrowawayClassLoader(ClassLoader parent)
/*    */   {
/* 36 */     super(parent);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.SimpleThrowawayClassLoader
 * JD-Core Version:    0.6.2
 */