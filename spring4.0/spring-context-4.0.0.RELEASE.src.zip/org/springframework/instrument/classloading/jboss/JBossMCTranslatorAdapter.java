/*    */ package org.springframework.instrument.classloading.jboss;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.ProtectionDomain;
/*    */ 
/*    */ class JBossMCTranslatorAdapter
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final ClassFileTransformer transformer;
/*    */ 
/*    */   public JBossMCTranslatorAdapter(ClassFileTransformer transformer)
/*    */   {
/* 43 */     this.transformer = transformer;
/*    */   }
/*    */ 
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*    */   {
/* 48 */     String name = method.getName();
/*    */ 
/* 50 */     if ("equals".equals(name))
/* 51 */       return Boolean.valueOf(proxy == args[0]);
/* 52 */     if ("hashCode".equals(name))
/* 53 */       return Integer.valueOf(hashCode());
/* 54 */     if ("toString".equals(name))
/* 55 */       return toString();
/* 56 */     if ("transform".equals(name)) {
/* 57 */       return transform((ClassLoader)args[0], (String)args[1], (Class)args[2], (ProtectionDomain)args[3], (byte[])args[4]);
/*    */     }
/* 59 */     if ("unregisterClassLoader".equals(name)) {
/* 60 */       unregisterClassLoader((ClassLoader)args[0]);
/* 61 */       return null;
/*    */     }
/*    */ 
/* 64 */     throw new IllegalArgumentException("Unknown method: " + method);
/*    */   }
/*    */ 
/*    */   public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer)
/*    */     throws Exception
/*    */   {
/* 70 */     return this.transformer.transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
/*    */   }
/*    */ 
/*    */   public void unregisterClassLoader(ClassLoader loader)
/*    */   {
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 78 */     StringBuilder builder = new StringBuilder(getClass().getName());
/* 79 */     builder.append(" for transformer: ");
/* 80 */     builder.append(this.transformer);
/* 81 */     return builder.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.jboss.JBossMCTranslatorAdapter
 * JD-Core Version:    0.6.2
 */