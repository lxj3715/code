/*    */ package org.springframework.jmx;
/*    */ 
/*    */ public class MBeanServerNotFoundException extends JmxException
/*    */ {
/*    */   public MBeanServerNotFoundException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MBeanServerNotFoundException(String msg, Throwable cause)
/*    */   {
/* 47 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.MBeanServerNotFoundException
 * JD-Core Version:    0.6.2
 */