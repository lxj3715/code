/*    */ package org.springframework.jmx.access;
/*    */ 
/*    */ import javax.management.JMRuntimeException;
/*    */ 
/*    */ public class InvalidInvocationException extends JMRuntimeException
/*    */ {
/*    */   public InvalidInvocationException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.InvalidInvocationException
 * JD-Core Version:    0.6.2
 */