/*    */ package org.springframework.jmx.access;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class InvocationFailureException extends JmxException
/*    */ {
/*    */   public InvocationFailureException(String msg)
/*    */   {
/* 38 */     super(msg);
/*    */   }
/*    */ 
/*    */   public InvocationFailureException(String msg, Throwable cause)
/*    */   {
/* 48 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.InvocationFailureException
 * JD-Core Version:    0.6.2
 */