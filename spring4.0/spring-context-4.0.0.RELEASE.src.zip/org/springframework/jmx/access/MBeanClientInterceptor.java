/*     */ package org.springframework.jmx.access;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.JMX;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.MBeanServerInvocationHandler;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.OperationsException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import javax.management.openmbean.CompositeData;
/*     */ import javax.management.openmbean.TabularData;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.GenericCollectionTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.jmx.support.JmxUtils;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class MBeanClientInterceptor
/*     */   implements MethodInterceptor, BeanClassLoaderAware, InitializingBean, DisposableBean
/*     */ {
/*     */   protected final Log logger;
/*     */   private MBeanServerConnection server;
/*     */   private JMXServiceURL serviceUrl;
/*     */   private Map<String, ?> environment;
/*     */   private String agentId;
/*     */   private boolean connectOnStartup;
/*     */   private boolean refreshOnConnectFailure;
/*     */   private ObjectName objectName;
/*     */   private boolean useStrictCasing;
/*     */   private Class<?> managementInterface;
/*     */   private ClassLoader beanClassLoader;
/*     */   private final ConnectorDelegate connector;
/*     */   private MBeanServerConnection serverToUse;
/*     */   private MBeanServerInvocationHandler invocationHandler;
/*     */   private Map<String, MBeanAttributeInfo> allowedAttributes;
/*     */   private Map<MethodCacheKey, MBeanOperationInfo> allowedOperations;
/*     */   private final Map<Method, String[]> signatureCache;
/*     */   private final Object preparationMonitor;
/*     */ 
/*     */   public MBeanClientInterceptor()
/*     */   {
/*  92 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/* 102 */     this.connectOnStartup = true;
/*     */ 
/* 104 */     this.refreshOnConnectFailure = false;
/*     */ 
/* 108 */     this.useStrictCasing = true;
/*     */ 
/* 112 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/* 114 */     this.connector = new ConnectorDelegate();
/*     */ 
/* 124 */     this.signatureCache = new HashMap();
/*     */ 
/* 126 */     this.preparationMonitor = new Object();
/*     */   }
/*     */ 
/*     */   public void setServer(MBeanServerConnection server)
/*     */   {
/* 134 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public void setServiceUrl(String url)
/*     */     throws MalformedURLException
/*     */   {
/* 141 */     this.serviceUrl = new JMXServiceURL(url);
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Map<String, ?> environment)
/*     */   {
/* 149 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public Map<String, ?> getEnvironment()
/*     */   {
/* 160 */     return this.environment;
/*     */   }
/*     */ 
/*     */   public void setAgentId(String agentId)
/*     */   {
/* 172 */     this.agentId = agentId;
/*     */   }
/*     */ 
/*     */   public void setConnectOnStartup(boolean connectOnStartup)
/*     */   {
/* 181 */     this.connectOnStartup = connectOnStartup;
/*     */   }
/*     */ 
/*     */   public void setRefreshOnConnectFailure(boolean refreshOnConnectFailure)
/*     */   {
/* 191 */     this.refreshOnConnectFailure = refreshOnConnectFailure;
/*     */   }
/*     */ 
/*     */   public void setObjectName(Object objectName)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 199 */     this.objectName = ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */ 
/*     */   public void setUseStrictCasing(boolean useStrictCasing)
/*     */   {
/* 210 */     this.useStrictCasing = useStrictCasing;
/*     */   }
/*     */ 
/*     */   public void setManagementInterface(Class<?> managementInterface)
/*     */   {
/* 219 */     this.managementInterface = managementInterface;
/*     */   }
/*     */ 
/*     */   protected final Class<?> getManagementInterface()
/*     */   {
/* 227 */     return this.managementInterface;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/* 232 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 242 */     if ((this.server != null) && (this.refreshOnConnectFailure)) {
/* 243 */       throw new IllegalArgumentException("'refreshOnConnectFailure' does not work when setting a 'server' reference. Prefer 'serviceUrl' etc instead.");
/*     */     }
/*     */ 
/* 246 */     if (this.connectOnStartup)
/* 247 */       prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 256 */     synchronized (this.preparationMonitor) {
/* 257 */       if (this.server != null) {
/* 258 */         this.serverToUse = this.server;
/*     */       }
/*     */       else {
/* 261 */         this.serverToUse = null;
/* 262 */         this.serverToUse = this.connector.connect(this.serviceUrl, this.environment, this.agentId);
/*     */       }
/* 264 */       this.invocationHandler = null;
/* 265 */       if (this.useStrictCasing)
/*     */       {
/* 268 */         if (JmxUtils.isMXBeanSupportAvailable()) {
/* 269 */           if (this.managementInterface != null);
/* 269 */           this.invocationHandler = new MBeanServerInvocationHandler(this.serverToUse, this.objectName, 
/* 271 */             JMX.isMXBeanInterface(this.managementInterface));
/*     */         }
/*     */         else
/*     */         {
/* 274 */           this.invocationHandler = new MBeanServerInvocationHandler(this.serverToUse, this.objectName);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 280 */         retrieveMBeanInfo();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void retrieveMBeanInfo()
/*     */     throws MBeanInfoRetrievalException
/*     */   {
/*     */     try
/*     */     {
/* 291 */       MBeanInfo info = this.serverToUse.getMBeanInfo(this.objectName);
/*     */ 
/* 293 */       MBeanAttributeInfo[] attributeInfo = info.getAttributes();
/* 294 */       this.allowedAttributes = new HashMap(attributeInfo.length);
/* 295 */       MBeanAttributeInfo[] arrayOfMBeanAttributeInfo1 = attributeInfo; int i = arrayOfMBeanAttributeInfo1.length; for (MBeanAttributeInfo localMBeanAttributeInfo1 = 0; localMBeanAttributeInfo1 < i; localMBeanAttributeInfo1++) { infoEle = arrayOfMBeanAttributeInfo1[localMBeanAttributeInfo1];
/* 296 */         this.allowedAttributes.put(infoEle.getName(), infoEle);
/*     */       }
/*     */ 
/* 299 */       MBeanOperationInfo[] operationInfo = info.getOperations();
/* 300 */       this.allowedOperations = new HashMap(operationInfo.length);
/* 301 */       MBeanOperationInfo[] arrayOfMBeanOperationInfo1 = operationInfo; localMBeanAttributeInfo1 = arrayOfMBeanOperationInfo1.length; for (MBeanAttributeInfo infoEle = 0; infoEle < localMBeanAttributeInfo1; infoEle++) { MBeanOperationInfo infoEle = arrayOfMBeanOperationInfo1[infoEle];
/* 302 */         Class[] paramTypes = JmxUtils.parameterInfoToTypes(infoEle.getSignature(), this.beanClassLoader);
/* 303 */         this.allowedOperations.put(new MethodCacheKey(infoEle.getName(), paramTypes), infoEle); }
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/* 307 */       throw new MBeanInfoRetrievalException("Unable to locate class specified in method signature", ex);
/*     */     }
/*     */     catch (IntrospectionException ex) {
/* 310 */       throw new MBeanInfoRetrievalException("Unable to obtain MBean info for bean [" + this.objectName + "]", ex);
/*     */     }
/*     */     catch (InstanceNotFoundException ex)
/*     */     {
/* 314 */       throw new MBeanInfoRetrievalException("Unable to obtain MBean info for bean [" + this.objectName + "]: it is likely that this bean was unregistered during the proxy creation process", ex);
/*     */     }
/*     */     catch (ReflectionException ex)
/*     */     {
/* 319 */       throw new MBeanInfoRetrievalException("Unable to read MBean info for bean [ " + this.objectName + "]", ex);
/*     */     }
/*     */     catch (IOException ex) {
/* 322 */       throw new MBeanInfoRetrievalException("An IOException occurred when communicating with the MBeanServer. It is likely that you are communicating with a remote MBeanServer. Check the inner exception for exact details.", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isPrepared()
/*     */   {
/* 333 */     synchronized (this.preparationMonitor) {
/* 334 */       return this.serverToUse != null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 350 */     synchronized (this.preparationMonitor) {
/* 351 */       if (!isPrepared())
/* 352 */         prepare();
/*     */     }
/*     */     try
/*     */     {
/* 356 */       return doInvoke(invocation);
/*     */     }
/*     */     catch (MBeanConnectFailureException ex) {
/* 359 */       return handleConnectFailure(invocation, ex);
/*     */     }
/*     */     catch (IOException ex) {
/* 362 */       return handleConnectFailure(invocation, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object handleConnectFailure(MethodInvocation invocation, Exception ex)
/*     */     throws Throwable
/*     */   {
/* 379 */     if (this.refreshOnConnectFailure) {
/* 380 */       String msg = "Could not connect to JMX server - retrying";
/* 381 */       if (this.logger.isDebugEnabled()) {
/* 382 */         this.logger.warn(msg, ex);
/*     */       }
/* 384 */       else if (this.logger.isWarnEnabled()) {
/* 385 */         this.logger.warn(msg);
/*     */       }
/* 387 */       prepare();
/* 388 */       return doInvoke(invocation);
/*     */     }
/*     */ 
/* 391 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 404 */     Method method = invocation.getMethod();
/*     */     try {
/* 406 */       Object result = null;
/* 407 */       if (this.invocationHandler != null) {
/* 408 */         result = this.invocationHandler.invoke(invocation.getThis(), method, invocation.getArguments());
/*     */       }
/*     */       else {
/* 411 */         PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 412 */         if (pd != null) {
/* 413 */           result = invokeAttribute(pd, invocation);
/*     */         }
/*     */         else {
/* 416 */           result = invokeOperation(method, invocation.getArguments());
/*     */         }
/*     */       }
/* 419 */       return convertResultValueIfNecessary(result, new MethodParameter(method, -1));
/*     */     }
/*     */     catch (MBeanException ex) {
/* 422 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (RuntimeMBeanException ex) {
/* 425 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (RuntimeErrorException ex) {
/* 428 */       throw ex.getTargetError();
/*     */     }
/*     */     catch (RuntimeOperationsException ex)
/*     */     {
/* 432 */       RuntimeException rex = ex.getTargetException();
/* 433 */       if ((rex instanceof RuntimeMBeanException)) {
/* 434 */         throw ((RuntimeMBeanException)rex).getTargetException();
/*     */       }
/* 436 */       if ((rex instanceof RuntimeErrorException)) {
/* 437 */         throw ((RuntimeErrorException)rex).getTargetError();
/*     */       }
/*     */ 
/* 440 */       throw rex;
/*     */     }
/*     */     catch (OperationsException ex)
/*     */     {
/* 444 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 445 */         throw ex;
/*     */       }
/*     */ 
/* 448 */       throw new InvalidInvocationException(ex.getMessage());
/*     */     }
/*     */     catch (JMException ex)
/*     */     {
/* 452 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 453 */         throw ex;
/*     */       }
/*     */ 
/* 456 */       throw new InvocationFailureException("JMX access failed", ex);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 460 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 461 */         throw ex;
/*     */       }
/*     */ 
/* 464 */       throw new MBeanConnectFailureException("I/O failure during JMX access", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object invokeAttribute(PropertyDescriptor pd, MethodInvocation invocation)
/*     */     throws JMException, IOException
/*     */   {
/* 472 */     String attributeName = JmxUtils.getAttributeName(pd, this.useStrictCasing);
/* 473 */     MBeanAttributeInfo inf = (MBeanAttributeInfo)this.allowedAttributes.get(attributeName);
/*     */ 
/* 476 */     if (inf == null)
/*     */     {
/* 478 */       throw new InvalidInvocationException("Attribute '" + pd
/* 478 */         .getName() + "' is not exposed on the management interface");
/*     */     }
/* 480 */     if (invocation.getMethod().equals(pd.getReadMethod())) {
/* 481 */       if (inf.isReadable()) {
/* 482 */         return this.serverToUse.getAttribute(this.objectName, attributeName);
/*     */       }
/*     */ 
/* 485 */       throw new InvalidInvocationException("Attribute '" + attributeName + "' is not readable");
/*     */     }
/*     */ 
/* 488 */     if (invocation.getMethod().equals(pd.getWriteMethod())) {
/* 489 */       if (inf.isWritable()) {
/* 490 */         this.serverToUse.setAttribute(this.objectName, new Attribute(attributeName, invocation.getArguments()[0]));
/* 491 */         return null;
/*     */       }
/*     */ 
/* 494 */       throw new InvalidInvocationException("Attribute '" + attributeName + "' is not writable");
/*     */     }
/*     */ 
/* 499 */     throw new IllegalStateException("Method [" + invocation
/* 499 */       .getMethod() + "] is neither a bean property getter nor a setter");
/*     */   }
/*     */ 
/*     */   private Object invokeOperation(Method method, Object[] args)
/*     */     throws JMException, IOException
/*     */   {
/* 511 */     MethodCacheKey key = new MethodCacheKey(method.getName(), method.getParameterTypes());
/* 512 */     MBeanOperationInfo info = (MBeanOperationInfo)this.allowedOperations.get(key);
/* 513 */     if (info == null) {
/* 514 */       throw new InvalidInvocationException("Operation '" + method.getName() + "' is not exposed on the management interface");
/*     */     }
/*     */ 
/* 517 */     String[] signature = null;
/* 518 */     synchronized (this.signatureCache) {
/* 519 */       signature = (String[])this.signatureCache.get(method);
/* 520 */       if (signature == null) {
/* 521 */         signature = JmxUtils.getMethodSignature(method);
/* 522 */         this.signatureCache.put(method, signature);
/*     */       }
/*     */     }
/* 525 */     return this.serverToUse.invoke(this.objectName, method.getName(), args, signature);
/*     */   }
/*     */ 
/*     */   protected Object convertResultValueIfNecessary(Object result, MethodParameter parameter)
/*     */   {
/* 537 */     Class targetClass = parameter.getParameterType();
/*     */     try {
/* 539 */       if (result == null) {
/* 540 */         return null;
/*     */       }
/* 542 */       if (ClassUtils.isAssignableValue(targetClass, result)) {
/* 543 */         return result;
/*     */       }
/* 545 */       if ((result instanceof CompositeData)) {
/* 546 */         Method fromMethod = targetClass.getMethod("from", new Class[] { CompositeData.class });
/* 547 */         return ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { result });
/*     */       }
/* 549 */       if ((result instanceof CompositeData[])) {
/* 550 */         CompositeData[] array = (CompositeData[])result;
/* 551 */         if (targetClass.isArray()) {
/* 552 */           return convertDataArrayToTargetArray(array, targetClass);
/*     */         }
/* 554 */         if (Collection.class.isAssignableFrom(targetClass)) {
/* 555 */           Class elementType = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 556 */           if (elementType != null)
/* 557 */             return convertDataArrayToTargetCollection(array, targetClass, elementType);
/*     */         }
/*     */       }
/*     */       else {
/* 561 */         if ((result instanceof TabularData)) {
/* 562 */           Method fromMethod = targetClass.getMethod("from", new Class[] { TabularData.class });
/* 563 */           return ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { result });
/*     */         }
/* 565 */         if ((result instanceof TabularData[])) {
/* 566 */           TabularData[] array = (TabularData[])result;
/* 567 */           if (targetClass.isArray()) {
/* 568 */             return convertDataArrayToTargetArray(array, targetClass);
/*     */           }
/* 570 */           if (Collection.class.isAssignableFrom(targetClass)) {
/* 571 */             Class elementType = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 572 */             if (elementType != null) {
/* 573 */               return convertDataArrayToTargetCollection(array, targetClass, elementType);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 578 */       throw new InvocationFailureException("Incompatible result value [" + result + "] for target type [" + targetClass
/* 578 */         .getName() + "]");
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/*     */     }
/* 583 */     throw new InvocationFailureException("Could not obtain 'from(CompositeData)' / 'from(TabularData)' method on target type [" + targetClass
/* 583 */       .getName() + "] for conversion of MXBean data structure [" + result + "]");
/*     */   }
/*     */ 
/*     */   private Object convertDataArrayToTargetArray(Object[] array, Class<?> targetClass) throws NoSuchMethodException
/*     */   {
/* 588 */     Class targetType = targetClass.getComponentType();
/* 589 */     Method fromMethod = targetType.getMethod("from", new Class[] { array.getClass().getComponentType() });
/* 590 */     Object resultArray = Array.newInstance(targetType, array.length);
/* 591 */     for (int i = 0; i < array.length; i++) {
/* 592 */       Array.set(resultArray, i, ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { array[i] }));
/*     */     }
/* 594 */     return resultArray;
/*     */   }
/*     */ 
/*     */   private Collection<?> convertDataArrayToTargetCollection(Object[] array, Class<?> collectionType, Class<?> elementType)
/*     */     throws NoSuchMethodException
/*     */   {
/* 600 */     Method fromMethod = elementType.getMethod("from", new Class[] { array.getClass().getComponentType() });
/* 601 */     Collection resultColl = CollectionFactory.createCollection(collectionType, Array.getLength(array));
/* 602 */     for (int i = 0; i < array.length; i++) {
/* 603 */       resultColl.add(ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { array[i] }));
/*     */     }
/* 605 */     return resultColl;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 611 */     this.connector.close();
/*     */   }
/*     */ 
/*     */   private static class MethodCacheKey
/*     */   {
/*     */     private final String name;
/*     */     private final Class<?>[] parameterTypes;
/*     */ 
/*     */     public MethodCacheKey(String name, Class<?>[] parameterTypes)
/*     */     {
/* 631 */       this.name = name;
/* 632 */       this.parameterTypes = (parameterTypes != null ? parameterTypes : new Class[0]);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 637 */       if (other == this) {
/* 638 */         return true;
/*     */       }
/* 640 */       MethodCacheKey otherKey = (MethodCacheKey)other;
/* 641 */       return (this.name.equals(otherKey.name)) && (Arrays.equals(this.parameterTypes, otherKey.parameterTypes));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 646 */       return this.name.hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.MBeanClientInterceptor
 * JD-Core Version:    0.6.2
 */