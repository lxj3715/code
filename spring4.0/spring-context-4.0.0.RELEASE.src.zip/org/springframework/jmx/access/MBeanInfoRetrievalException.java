/*    */ package org.springframework.jmx.access;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class MBeanInfoRetrievalException extends JmxException
/*    */ {
/*    */   public MBeanInfoRetrievalException(String msg)
/*    */   {
/* 40 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MBeanInfoRetrievalException(String msg, Throwable cause)
/*    */   {
/* 50 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.MBeanInfoRetrievalException
 * JD-Core Version:    0.6.2
 */