/*     */ package org.springframework.jmx.access;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.JmxException;
/*     */ import org.springframework.jmx.MBeanServerNotFoundException;
/*     */ import org.springframework.jmx.support.NotificationListenerHolder;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class NotificationListenerRegistrar extends NotificationListenerHolder
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*  53 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private MBeanServerConnection server;
/*     */   private JMXServiceURL serviceUrl;
/*     */   private Map<String, ?> environment;
/*     */   private String agentId;
/*  63 */   private final ConnectorDelegate connector = new ConnectorDelegate();
/*     */   private ObjectName[] actualObjectNames;
/*     */ 
/*     */   public void setServer(MBeanServerConnection server)
/*     */   {
/*  73 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Map<String, ?> environment)
/*     */   {
/*  81 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public Map<String, ?> getEnvironment()
/*     */   {
/*  92 */     return this.environment;
/*     */   }
/*     */ 
/*     */   public void setServiceUrl(String url)
/*     */     throws MalformedURLException
/*     */   {
/*  99 */     this.serviceUrl = new JMXServiceURL(url);
/*     */   }
/*     */ 
/*     */   public void setAgentId(String agentId)
/*     */   {
/* 111 */     this.agentId = agentId;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 117 */     if (getNotificationListener() == null) {
/* 118 */       throw new IllegalArgumentException("Property 'notificationListener' is required");
/*     */     }
/* 120 */     if (CollectionUtils.isEmpty(this.mappedObjectNames)) {
/* 121 */       throw new IllegalArgumentException("Property 'mappedObjectName' is required");
/*     */     }
/* 123 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 132 */     if (this.server == null)
/* 133 */       this.server = this.connector.connect(this.serviceUrl, this.environment, this.agentId);
/*     */     try
/*     */     {
/* 136 */       this.actualObjectNames = getResolvedObjectNames();
/* 137 */       if (this.logger.isDebugEnabled()) {
/* 138 */         this.logger.debug("Registering NotificationListener for MBeans " + Arrays.asList(this.actualObjectNames));
/*     */       }
/* 140 */       for (ObjectName actualObjectName : this.actualObjectNames)
/* 141 */         this.server.addNotificationListener(actualObjectName, 
/* 142 */           getNotificationListener(), getNotificationFilter(), getHandback());
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 146 */       throw new MBeanServerNotFoundException("Could not connect to remote MBeanServer at URL [" + this.serviceUrl + "]", ex);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 150 */       throw new JmxException("Unable to register NotificationListener", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */     try
/*     */     {
/* 160 */       if (this.actualObjectNames != null) {
/* 161 */         for (ObjectName actualObjectName : this.actualObjectNames) {
/*     */           try {
/* 163 */             this.server.removeNotificationListener(actualObjectName, 
/* 164 */               getNotificationListener(), getNotificationFilter(), getHandback());
/*     */           }
/*     */           catch (Exception ex) {
/* 167 */             if (this.logger.isDebugEnabled())
/* 168 */               this.logger.debug("Unable to unregister NotificationListener", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 175 */       this.connector.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.NotificationListenerRegistrar
 * JD-Core Version:    0.6.2
 */