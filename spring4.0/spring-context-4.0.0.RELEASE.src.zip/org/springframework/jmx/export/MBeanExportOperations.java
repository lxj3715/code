package org.springframework.jmx.export;

import javax.management.ObjectName;

public abstract interface MBeanExportOperations
{
  public abstract ObjectName registerManagedResource(Object paramObject)
    throws MBeanExportException;

  public abstract void registerManagedResource(Object paramObject, ObjectName paramObjectName)
    throws MBeanExportException;

  public abstract void unregisterManagedResource(ObjectName paramObjectName);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.MBeanExportOperations
 * JD-Core Version:    0.6.2
 */