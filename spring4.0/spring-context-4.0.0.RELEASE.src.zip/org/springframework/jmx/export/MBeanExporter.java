/*      */ package org.springframework.jmx.export;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.management.DynamicMBean;
/*      */ import javax.management.JMException;
/*      */ import javax.management.MBeanException;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.NotCompliantMBeanException;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.management.ObjectName;
/*      */ import javax.management.StandardMBean;
/*      */ import javax.management.modelmbean.ModelMBean;
/*      */ import javax.management.modelmbean.ModelMBeanInfo;
/*      */ import javax.management.modelmbean.RequiredModelMBean;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.aop.framework.ProxyFactory;
/*      */ import org.springframework.aop.support.AopUtils;
/*      */ import org.springframework.aop.target.LazyInitTargetSource;
/*      */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*      */ import org.springframework.beans.factory.DisposableBean;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.beans.factory.ListableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.core.Constants;
/*      */ import org.springframework.jmx.export.assembler.AutodetectCapableMBeanInfoAssembler;
/*      */ import org.springframework.jmx.export.assembler.MBeanInfoAssembler;
/*      */ import org.springframework.jmx.export.assembler.SimpleReflectiveMBeanInfoAssembler;
/*      */ import org.springframework.jmx.export.naming.KeyNamingStrategy;
/*      */ import org.springframework.jmx.export.naming.ObjectNamingStrategy;
/*      */ import org.springframework.jmx.export.naming.SelfNaming;
/*      */ import org.springframework.jmx.export.notification.ModelMBeanNotificationPublisher;
/*      */ import org.springframework.jmx.export.notification.NotificationPublisherAware;
/*      */ import org.springframework.jmx.support.JmxUtils;
/*      */ import org.springframework.jmx.support.MBeanRegistrationSupport;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ 
/*      */ public class MBeanExporter extends MBeanRegistrationSupport
/*      */   implements MBeanExportOperations, BeanClassLoaderAware, BeanFactoryAware, InitializingBean, DisposableBean
/*      */ {
/*      */   public static final int AUTODETECT_NONE = 0;
/*      */   public static final int AUTODETECT_MBEAN = 1;
/*      */   public static final int AUTODETECT_ASSEMBLER = 2;
/*      */   public static final int AUTODETECT_ALL = 3;
/*      */   private static final String WILDCARD = "*";
/*      */   private static final String MR_TYPE_OBJECT_REFERENCE = "ObjectReference";
/*      */   private static final String CONSTANT_PREFIX_AUTODETECT = "AUTODETECT_";
/*  139 */   private static final Constants constants = new Constants(MBeanExporter.class);
/*      */   private Map<String, Object> beans;
/*      */   private Integer autodetectMode;
/*      */   private boolean allowEagerInit;
/*      */   private boolean ensureUniqueRuntimeObjectNames;
/*      */   private boolean exposeManagedResourceClassLoader;
/*      */   private Set<String> excludedBeans;
/*      */   private MBeanExporterListener[] listeners;
/*      */   private NotificationListenerBean[] notificationListeners;
/*      */   private final Map<NotificationListenerBean, ObjectName[]> registeredNotificationListeners;
/*      */   private MBeanInfoAssembler assembler;
/*      */   private ObjectNamingStrategy namingStrategy;
/*      */   private ClassLoader beanClassLoader;
/*      */   private ListableBeanFactory beanFactory;
/*      */ 
/*      */   public MBeanExporter()
/*      */   {
/*  148 */     this.allowEagerInit = false;
/*      */ 
/*  151 */     this.ensureUniqueRuntimeObjectNames = true;
/*      */ 
/*  154 */     this.exposeManagedResourceClassLoader = true;
/*      */ 
/*  166 */     this.registeredNotificationListeners = new LinkedHashMap();
/*      */ 
/*  170 */     this.assembler = new SimpleReflectiveMBeanInfoAssembler();
/*      */ 
/*  173 */     this.namingStrategy = new KeyNamingStrategy();
/*      */ 
/*  176 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*      */   }
/*      */ 
/*      */   public void setBeans(Map<String, Object> beans)
/*      */   {
/*  200 */     this.beans = beans;
/*      */   }
/*      */ 
/*      */   public void setAutodetect(boolean autodetect)
/*      */   {
/*  214 */     this.autodetectMode = Integer.valueOf(autodetect ? 3 : 0);
/*      */   }
/*      */ 
/*      */   public void setAutodetectMode(int autodetectMode)
/*      */   {
/*  228 */     if (!constants.getValues("AUTODETECT_").contains(Integer.valueOf(autodetectMode))) {
/*  229 */       throw new IllegalArgumentException("Only values of autodetect constants allowed");
/*      */     }
/*  231 */     this.autodetectMode = Integer.valueOf(autodetectMode);
/*      */   }
/*      */ 
/*      */   public void setAutodetectModeName(String constantName)
/*      */   {
/*  245 */     if ((constantName == null) || (!constantName.startsWith("AUTODETECT_"))) {
/*  246 */       throw new IllegalArgumentException("Only autodetect constants allowed");
/*      */     }
/*  248 */     this.autodetectMode = ((Integer)constants.asNumber(constantName));
/*      */   }
/*      */ 
/*      */   public void setAllowEagerInit(boolean allowEagerInit)
/*      */   {
/*  259 */     this.allowEagerInit = allowEagerInit;
/*      */   }
/*      */ 
/*      */   public void setAssembler(MBeanInfoAssembler assembler)
/*      */   {
/*  274 */     this.assembler = assembler;
/*      */   }
/*      */ 
/*      */   public void setNamingStrategy(ObjectNamingStrategy namingStrategy)
/*      */   {
/*  284 */     this.namingStrategy = namingStrategy;
/*      */   }
/*      */ 
/*      */   public void setListeners(MBeanExporterListener[] listeners)
/*      */   {
/*  293 */     this.listeners = listeners;
/*      */   }
/*      */ 
/*      */   public void setExcludedBeans(String[] excludedBeans)
/*      */   {
/*  300 */     this.excludedBeans = (excludedBeans != null ? new HashSet(Arrays.asList(excludedBeans)) : null);
/*      */   }
/*      */ 
/*      */   public void setEnsureUniqueRuntimeObjectNames(boolean ensureUniqueRuntimeObjectNames)
/*      */   {
/*  313 */     this.ensureUniqueRuntimeObjectNames = ensureUniqueRuntimeObjectNames;
/*      */   }
/*      */ 
/*      */   public void setExposeManagedResourceClassLoader(boolean exposeManagedResourceClassLoader)
/*      */   {
/*  325 */     this.exposeManagedResourceClassLoader = exposeManagedResourceClassLoader;
/*      */   }
/*      */ 
/*      */   public void setNotificationListeners(NotificationListenerBean[] notificationListeners)
/*      */   {
/*  337 */     this.notificationListeners = notificationListeners;
/*      */   }
/*      */ 
/*      */   public void setNotificationListenerMappings(Map<?, ? extends NotificationListener> listeners)
/*      */   {
/*  355 */     Assert.notNull(listeners, "'listeners' must not be null");
/*      */ 
/*  357 */     List notificationListeners = new ArrayList(listeners
/*  357 */       .size());
/*      */ 
/*  359 */     for (Map.Entry entry : listeners.entrySet())
/*      */     {
/*  361 */       NotificationListenerBean bean = new NotificationListenerBean((NotificationListener)entry.getValue());
/*      */ 
/*  363 */       Object key = entry.getKey();
/*  364 */       if ((key != null) && (!"*".equals(key)))
/*      */       {
/*  366 */         bean.setMappedObjectName(entry.getKey());
/*      */       }
/*  368 */       notificationListeners.add(bean);
/*      */     }
/*      */ 
/*  371 */     this.notificationListeners = 
/*  372 */       ((NotificationListenerBean[])notificationListeners
/*  372 */       .toArray(new NotificationListenerBean[notificationListeners
/*  372 */       .size()]));
/*      */   }
/*      */ 
/*      */   public void setBeanClassLoader(ClassLoader classLoader)
/*      */   {
/*  377 */     this.beanClassLoader = classLoader;
/*      */   }
/*      */ 
/*      */   public void setBeanFactory(BeanFactory beanFactory)
/*      */   {
/*  390 */     if ((beanFactory instanceof ListableBeanFactory)) {
/*  391 */       this.beanFactory = ((ListableBeanFactory)beanFactory);
/*      */     }
/*      */     else
/*  394 */       this.logger.info("MBeanExporter not running in a ListableBeanFactory: autodetection of MBeans not available.");
/*      */   }
/*      */ 
/*      */   public void afterPropertiesSet()
/*      */   {
/*  412 */     if (this.server == null)
/*  413 */       this.server = JmxUtils.locateMBeanServer();
/*      */     try
/*      */     {
/*  416 */       this.logger.info("Registering beans for JMX exposure on startup");
/*  417 */       registerBeans();
/*  418 */       registerNotificationListeners();
/*      */     }
/*      */     catch (RuntimeException ex)
/*      */     {
/*  422 */       unregisterNotificationListeners();
/*  423 */       unregisterBeans();
/*  424 */       throw ex;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void destroy()
/*      */   {
/*  434 */     this.logger.info("Unregistering JMX-exposed beans on shutdown");
/*  435 */     unregisterNotificationListeners();
/*  436 */     unregisterBeans();
/*      */   }
/*      */ 
/*      */   public ObjectName registerManagedResource(Object managedResource)
/*      */     throws MBeanExportException
/*      */   {
/*  446 */     Assert.notNull(managedResource, "Managed resource must not be null");
/*      */     try
/*      */     {
/*  449 */       ObjectName objectName = getObjectName(managedResource, null);
/*  450 */       if (this.ensureUniqueRuntimeObjectNames)
/*  451 */         objectName = JmxUtils.appendIdentityToObjectName(objectName, managedResource);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  455 */       throw new MBeanExportException("Unable to generate ObjectName for MBean [" + managedResource + "]", ex);
/*      */     }
/*      */     ObjectName objectName;
/*  457 */     registerManagedResource(managedResource, objectName);
/*  458 */     return objectName;
/*      */   }
/*      */ 
/*      */   public void registerManagedResource(Object managedResource, ObjectName objectName) throws MBeanExportException
/*      */   {
/*  463 */     Assert.notNull(managedResource, "Managed resource must not be null");
/*  464 */     Assert.notNull(objectName, "ObjectName must not be null");
/*      */     try {
/*  466 */       if (isMBean(managedResource.getClass())) {
/*  467 */         doRegister(managedResource, objectName);
/*      */       }
/*      */       else {
/*  470 */         ModelMBean mbean = createAndConfigureMBean(managedResource, managedResource.getClass().getName());
/*  471 */         doRegister(mbean, objectName);
/*  472 */         injectNotificationPublisherIfNecessary(managedResource, mbean, objectName);
/*      */       }
/*      */     }
/*      */     catch (JMException ex) {
/*  476 */       throw new UnableToRegisterMBeanException("Unable to register MBean [" + managedResource + "] with object name [" + objectName + "]", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void unregisterManagedResource(ObjectName objectName)
/*      */   {
/*  483 */     Assert.notNull(objectName, "ObjectName must not be null");
/*  484 */     doUnregister(objectName);
/*      */   }
/*      */ 
/*      */   protected void registerBeans()
/*      */   {
/*  507 */     if (this.beans == null) {
/*  508 */       this.beans = new HashMap();
/*      */ 
/*  510 */       if (this.autodetectMode == null) {
/*  511 */         this.autodetectMode = Integer.valueOf(3);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  516 */     int mode = this.autodetectMode != null ? this.autodetectMode.intValue() : 0;
/*  517 */     if (mode != 0) {
/*  518 */       if (this.beanFactory == null) {
/*  519 */         throw new MBeanExportException("Cannot autodetect MBeans if not running in a BeanFactory");
/*      */       }
/*  521 */       if ((mode == 1) || (mode == 3))
/*      */       {
/*  523 */         this.logger.debug("Autodetecting user-defined JMX MBeans");
/*  524 */         autodetectMBeans();
/*      */       }
/*      */ 
/*  527 */       if (((mode == 2) || (mode == 3)) && ((this.assembler instanceof AutodetectCapableMBeanInfoAssembler)))
/*      */       {
/*  529 */         autodetectBeans((AutodetectCapableMBeanInfoAssembler)this.assembler);
/*      */       }
/*      */     }
/*      */ 
/*  533 */     if (!this.beans.isEmpty())
/*  534 */       for (Map.Entry entry : this.beans.entrySet())
/*  535 */         registerBeanNameOrInstance(entry.getValue(), (String)entry.getKey());
/*      */   }
/*      */ 
/*      */   protected boolean isBeanDefinitionLazyInit(ListableBeanFactory beanFactory, String beanName)
/*      */   {
/*  549 */     return ((beanFactory instanceof ConfigurableListableBeanFactory)) && (beanFactory.containsBeanDefinition(beanName)) && 
/*  549 */       (((ConfigurableListableBeanFactory)beanFactory)
/*  549 */       .getBeanDefinition(beanName)
/*  549 */       .isLazyInit());
/*      */   }
/*      */ 
/*      */   protected ObjectName registerBeanNameOrInstance(Object mapValue, String beanKey)
/*      */     throws MBeanExportException
/*      */   {
/*      */     try
/*      */     {
/*      */       Object bean;
/*  574 */       if ((mapValue instanceof String))
/*      */       {
/*  576 */         if (this.beanFactory == null) {
/*  577 */           throw new MBeanExportException("Cannot resolve bean names if not running in a BeanFactory");
/*      */         }
/*  579 */         String beanName = (String)mapValue;
/*  580 */         if (isBeanDefinitionLazyInit(this.beanFactory, beanName)) {
/*  581 */           ObjectName objectName = registerLazyInit(beanName, beanKey);
/*  582 */           replaceNotificationListenerBeanNameKeysIfNecessary(beanName, objectName);
/*  583 */           return objectName;
/*      */         }
/*      */ 
/*  586 */         bean = this.beanFactory.getBean(beanName);
/*  587 */         ObjectName objectName = registerBeanInstance(bean, beanKey);
/*  588 */         replaceNotificationListenerBeanNameKeysIfNecessary(beanName, objectName);
/*  589 */         return objectName;
/*      */       }
/*      */ 
/*  594 */       if (this.beanFactory != null)
/*      */       {
/*  596 */         Map beansOfSameType = this.beanFactory
/*  596 */           .getBeansOfType(mapValue
/*  596 */           .getClass(), false, this.allowEagerInit);
/*  597 */         for (Map.Entry entry : beansOfSameType.entrySet()) {
/*  598 */           if (entry.getValue() == mapValue) {
/*  599 */             String beanName = (String)entry.getKey();
/*  600 */             ObjectName objectName = registerBeanInstance(mapValue, beanKey);
/*  601 */             replaceNotificationListenerBeanNameKeysIfNecessary(beanName, objectName);
/*  602 */             return objectName;
/*      */           }
/*      */         }
/*      */       }
/*  606 */       return registerBeanInstance(mapValue, beanKey);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  610 */       throw new UnableToRegisterMBeanException("Unable to register MBean [" + mapValue + "] with key '" + beanKey + "'", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void replaceNotificationListenerBeanNameKeysIfNecessary(String beanName, ObjectName objectName)
/*      */   {
/*  623 */     if (this.notificationListeners != null)
/*  624 */       for (NotificationListenerBean notificationListener : this.notificationListeners)
/*  625 */         notificationListener.replaceObjectName(beanName, objectName);
/*      */   }
/*      */ 
/*      */   private ObjectName registerBeanInstance(Object bean, String beanKey)
/*      */     throws JMException
/*      */   {
/*  639 */     ObjectName objectName = getObjectName(bean, beanKey);
/*  640 */     Object mbeanToExpose = null;
/*  641 */     if (isMBean(bean.getClass())) {
/*  642 */       mbeanToExpose = bean;
/*      */     }
/*      */     else {
/*  645 */       DynamicMBean adaptedBean = adaptMBeanIfPossible(bean);
/*  646 */       if (adaptedBean != null) {
/*  647 */         mbeanToExpose = adaptedBean;
/*      */       }
/*      */     }
/*  650 */     if (mbeanToExpose != null) {
/*  651 */       if (this.logger.isInfoEnabled()) {
/*  652 */         this.logger.info("Located MBean '" + beanKey + "': registering with JMX server as MBean [" + objectName + "]");
/*      */       }
/*      */ 
/*  655 */       doRegister(mbeanToExpose, objectName);
/*      */     }
/*      */     else {
/*  658 */       if (this.logger.isInfoEnabled()) {
/*  659 */         this.logger.info("Located managed bean '" + beanKey + "': registering with JMX server as MBean [" + objectName + "]");
/*      */       }
/*      */ 
/*  662 */       ModelMBean mbean = createAndConfigureMBean(bean, beanKey);
/*  663 */       doRegister(mbean, objectName);
/*  664 */       injectNotificationPublisherIfNecessary(bean, mbean, objectName);
/*      */     }
/*  666 */     return objectName;
/*      */   }
/*      */ 
/*      */   private ObjectName registerLazyInit(String beanName, String beanKey)
/*      */     throws JMException
/*      */   {
/*  678 */     ProxyFactory proxyFactory = new ProxyFactory();
/*  679 */     proxyFactory.setProxyTargetClass(true);
/*  680 */     proxyFactory.setFrozen(true);
/*      */ 
/*  682 */     if (isMBean(this.beanFactory.getType(beanName)))
/*      */     {
/*  684 */       LazyInitTargetSource targetSource = new LazyInitTargetSource();
/*  685 */       targetSource.setTargetBeanName(beanName);
/*  686 */       targetSource.setBeanFactory(this.beanFactory);
/*  687 */       proxyFactory.setTargetSource(targetSource);
/*      */ 
/*  689 */       Object proxy = proxyFactory.getProxy(this.beanClassLoader);
/*  690 */       ObjectName objectName = getObjectName(proxy, beanKey);
/*  691 */       if (this.logger.isDebugEnabled()) {
/*  692 */         this.logger.debug("Located MBean '" + beanKey + "': registering with JMX server as lazy-init MBean [" + objectName + "]");
/*      */       }
/*      */ 
/*  695 */       doRegister(proxy, objectName);
/*  696 */       return objectName;
/*      */     }
/*      */ 
/*  701 */     NotificationPublisherAwareLazyTargetSource targetSource = new NotificationPublisherAwareLazyTargetSource(null);
/*  702 */     targetSource.setTargetBeanName(beanName);
/*  703 */     targetSource.setBeanFactory(this.beanFactory);
/*  704 */     proxyFactory.setTargetSource(targetSource);
/*      */ 
/*  706 */     Object proxy = proxyFactory.getProxy(this.beanClassLoader);
/*  707 */     ObjectName objectName = getObjectName(proxy, beanKey);
/*  708 */     if (this.logger.isDebugEnabled()) {
/*  709 */       this.logger.debug("Located simple bean '" + beanKey + "': registering with JMX server as lazy-init MBean [" + objectName + "]");
/*      */     }
/*      */ 
/*  712 */     ModelMBean mbean = createAndConfigureMBean(proxy, beanKey);
/*  713 */     targetSource.setModelMBean(mbean);
/*  714 */     targetSource.setObjectName(objectName);
/*  715 */     doRegister(mbean, objectName);
/*  716 */     return objectName;
/*      */   }
/*      */ 
/*      */   protected ObjectName getObjectName(Object bean, String beanKey)
/*      */     throws MalformedObjectNameException
/*      */   {
/*  732 */     if ((bean instanceof SelfNaming)) {
/*  733 */       return ((SelfNaming)bean).getObjectName();
/*      */     }
/*      */ 
/*  736 */     return this.namingStrategy.getObjectName(bean, beanKey);
/*      */   }
/*      */ 
/*      */   protected boolean isMBean(Class<?> beanClass)
/*      */   {
/*  751 */     return JmxUtils.isMBean(beanClass);
/*      */   }
/*      */ 
/*      */   protected DynamicMBean adaptMBeanIfPossible(Object bean)
/*      */     throws JMException
/*      */   {
/*  764 */     Class targetClass = AopUtils.getTargetClass(bean);
/*  765 */     if (targetClass != bean.getClass()) {
/*  766 */       Class ifc = JmxUtils.getMXBeanInterface(targetClass);
/*  767 */       if (ifc != null) {
/*  768 */         if (!ifc.isInstance(bean)) {
/*  769 */           throw new NotCompliantMBeanException("Managed bean [" + bean + "] has a target class with an MXBean interface but does not expose it in the proxy");
/*      */         }
/*      */ 
/*  772 */         return new StandardMBean(bean, ifc, true);
/*      */       }
/*      */ 
/*  775 */       ifc = JmxUtils.getMBeanInterface(targetClass);
/*  776 */       if (ifc != null) {
/*  777 */         if (!ifc.isInstance(bean)) {
/*  778 */           throw new NotCompliantMBeanException("Managed bean [" + bean + "] has a target class with an MBean interface but does not expose it in the proxy");
/*      */         }
/*      */ 
/*  781 */         return new StandardMBean(bean, ifc);
/*      */       }
/*      */     }
/*      */ 
/*  785 */     return null;
/*      */   }
/*      */ 
/*      */   protected ModelMBean createAndConfigureMBean(Object managedResource, String beanKey)
/*      */     throws MBeanExportException
/*      */   {
/*      */     try
/*      */     {
/*  799 */       ModelMBean mbean = createModelMBean();
/*  800 */       mbean.setModelMBeanInfo(getMBeanInfo(managedResource, beanKey));
/*  801 */       mbean.setManagedResource(managedResource, "ObjectReference");
/*  802 */       return mbean;
/*      */     }
/*      */     catch (Exception ex) {
/*  805 */       throw new MBeanExportException("Could not create ModelMBean for managed resource [" + managedResource + "] with key '" + beanKey + "'", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected ModelMBean createModelMBean()
/*      */     throws MBeanException
/*      */   {
/*  819 */     return this.exposeManagedResourceClassLoader ? new SpringModelMBean() : new RequiredModelMBean();
/*      */   }
/*      */ 
/*      */   private ModelMBeanInfo getMBeanInfo(Object managedBean, String beanKey)
/*      */     throws JMException
/*      */   {
/*  827 */     ModelMBeanInfo info = this.assembler.getMBeanInfo(managedBean, beanKey);
/*  828 */     if ((this.logger.isWarnEnabled()) && (ObjectUtils.isEmpty(info.getAttributes())) && 
/*  829 */       (ObjectUtils.isEmpty(info
/*  829 */       .getOperations()))) {
/*  830 */       this.logger.warn("Bean with key '" + beanKey + "' has been registered as an MBean but has no exposed attributes or operations");
/*      */     }
/*      */ 
/*  833 */     return info;
/*      */   }
/*      */ 
/*      */   private void autodetectBeans(final AutodetectCapableMBeanInfoAssembler assembler)
/*      */   {
/*  850 */     autodetect(new AutodetectCallback()
/*      */     {
/*      */       public boolean include(Class<?> beanClass, String beanName) {
/*  853 */         return assembler.includeBean(beanClass, beanName);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private void autodetectMBeans()
/*      */   {
/*  863 */     autodetect(new AutodetectCallback()
/*      */     {
/*      */       public boolean include(Class<?> beanClass, String beanName) {
/*  866 */         return MBeanExporter.this.isMBean(beanClass);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private void autodetect(AutodetectCallback callback)
/*      */   {
/*  879 */     Set beanNames = new LinkedHashSet(this.beanFactory.getBeanDefinitionCount());
/*  880 */     beanNames.addAll(Arrays.asList(this.beanFactory.getBeanDefinitionNames()));
/*  881 */     if ((this.beanFactory instanceof ConfigurableBeanFactory)) {
/*  882 */       beanNames.addAll(Arrays.asList(((ConfigurableBeanFactory)this.beanFactory).getSingletonNames()));
/*      */     }
/*  884 */     for (String beanName : beanNames)
/*  885 */       if ((!isExcluded(beanName)) && (!isBeanDefinitionAbstract(this.beanFactory, beanName)))
/*      */         try {
/*  887 */           Class beanClass = this.beanFactory.getType(beanName);
/*  888 */           if ((beanClass != null) && (callback.include(beanClass, beanName))) {
/*  889 */             boolean lazyInit = isBeanDefinitionLazyInit(this.beanFactory, beanName);
/*  890 */             Object beanInstance = !lazyInit ? this.beanFactory.getBean(beanName) : null;
/*  891 */             if ((!this.beans.containsValue(beanName)) && ((beanInstance == null) || 
/*  892 */               (!CollectionUtils.containsInstance(this.beans
/*  892 */               .values(), beanInstance))))
/*      */             {
/*  894 */               this.beans.put(beanName, beanInstance != null ? beanInstance : beanName);
/*  895 */               if (this.logger.isInfoEnabled()) {
/*  896 */                 this.logger.info("Bean with name '" + beanName + "' has been autodetected for JMX exposure");
/*      */               }
/*      */ 
/*      */             }
/*  900 */             else if (this.logger.isDebugEnabled()) {
/*  901 */               this.logger.debug("Bean with name '" + beanName + "' is already registered for JMX exposure");
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (CannotLoadBeanClassException ex)
/*      */         {
/*  907 */           if (this.allowEagerInit)
/*  908 */             throw ex;
/*      */         }
/*      */   }
/*      */ 
/*      */   private boolean isExcluded(String beanName)
/*      */   {
/*  923 */     return (this.excludedBeans != null) && (
/*  921 */       (this.excludedBeans
/*  921 */       .contains(beanName)) || 
/*  921 */       (
/*  922 */       (beanName
/*  922 */       .startsWith("&")) && 
/*  923 */       (this.excludedBeans
/*  923 */       .contains(beanName
/*  923 */       .substring("&"
/*  923 */       .length())))));
/*      */   }
/*      */ 
/*      */   private boolean isBeanDefinitionAbstract(ListableBeanFactory beanFactory, String beanName)
/*      */   {
/*  931 */     return ((beanFactory instanceof ConfigurableListableBeanFactory)) && (beanFactory.containsBeanDefinition(beanName)) && 
/*  931 */       (((ConfigurableListableBeanFactory)beanFactory)
/*  931 */       .getBeanDefinition(beanName)
/*  931 */       .isAbstract());
/*      */   }
/*      */ 
/*      */   private void injectNotificationPublisherIfNecessary(Object managedResource, ModelMBean modelMBean, ObjectName objectName)
/*      */   {
/*  946 */     if ((managedResource instanceof NotificationPublisherAware))
/*  947 */       ((NotificationPublisherAware)managedResource).setNotificationPublisher(new ModelMBeanNotificationPublisher(modelMBean, objectName, managedResource));
/*      */   }
/*      */ 
/*      */   private void registerNotificationListeners()
/*      */     throws MBeanExportException
/*      */   {
/*  957 */     if (this.notificationListeners != null)
/*  958 */       for (NotificationListenerBean bean : this.notificationListeners)
/*      */         try {
/*  960 */           ObjectName[] mappedObjectNames = bean.getResolvedObjectNames();
/*  961 */           if (mappedObjectNames == null)
/*      */           {
/*  963 */             mappedObjectNames = getRegisteredObjectNames();
/*      */           }
/*  965 */           if (this.registeredNotificationListeners.put(bean, mappedObjectNames) == null) {
/*  966 */             for (ObjectName mappedObjectName : mappedObjectNames)
/*  967 */               this.server.addNotificationListener(mappedObjectName, bean.getNotificationListener(), bean
/*  968 */                 .getNotificationFilter(), bean.getHandback());
/*      */           }
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*  973 */           throw new MBeanExportException("Unable to register NotificationListener", ex);
/*      */         }
/*      */   }
/*      */ 
/*      */   private void unregisterNotificationListeners()
/*      */   {
/*  984 */     for (Map.Entry entry : this.registeredNotificationListeners.entrySet()) {
/*  985 */       NotificationListenerBean bean = (NotificationListenerBean)entry.getKey();
/*  986 */       ObjectName[] mappedObjectNames = (ObjectName[])entry.getValue();
/*  987 */       for (ObjectName mappedObjectName : mappedObjectNames) {
/*      */         try {
/*  989 */           this.server.removeNotificationListener(mappedObjectName, bean.getNotificationListener(), bean
/*  990 */             .getNotificationFilter(), bean.getHandback());
/*      */         }
/*      */         catch (Exception ex) {
/*  993 */           if (this.logger.isDebugEnabled()) {
/*  994 */             this.logger.debug("Unable to unregister NotificationListener", ex);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  999 */     this.registeredNotificationListeners.clear();
/*      */   }
/*      */ 
/*      */   protected void onRegister(ObjectName objectName)
/*      */   {
/* 1014 */     notifyListenersOfRegistration(objectName);
/*      */   }
/*      */ 
/*      */   protected void onUnregister(ObjectName objectName)
/*      */   {
/* 1029 */     notifyListenersOfUnregistration(objectName);
/*      */   }
/*      */ 
/*      */   private void notifyListenersOfRegistration(ObjectName objectName)
/*      */   {
/* 1038 */     if (this.listeners != null)
/* 1039 */       for (MBeanExporterListener listener : this.listeners)
/* 1040 */         listener.mbeanRegistered(objectName);
/*      */   }
/*      */ 
/*      */   private void notifyListenersOfUnregistration(ObjectName objectName)
/*      */   {
/* 1050 */     if (this.listeners != null)
/* 1051 */       for (MBeanExporterListener listener : this.listeners)
/* 1052 */         listener.mbeanUnregistered(objectName);
/*      */   }
/*      */ 
/*      */   private class NotificationPublisherAwareLazyTargetSource extends LazyInitTargetSource
/*      */   {
/*      */     private ModelMBean modelMBean;
/*      */     private ObjectName objectName;
/*      */ 
/*      */     private NotificationPublisherAwareLazyTargetSource()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void setModelMBean(ModelMBean modelMBean)
/*      */     {
/* 1090 */       this.modelMBean = modelMBean;
/*      */     }
/*      */ 
/*      */     public void setObjectName(ObjectName objectName) {
/* 1094 */       this.objectName = objectName;
/*      */     }
/*      */ 
/*      */     protected void postProcessTargetObject(Object targetObject)
/*      */     {
/* 1099 */       MBeanExporter.this.injectNotificationPublisherIfNecessary(targetObject, this.modelMBean, this.objectName);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract interface AutodetectCallback
/*      */   {
/*      */     public abstract boolean include(Class<?> paramClass, String paramString);
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.MBeanExporter
 * JD-Core Version:    0.6.2
 */