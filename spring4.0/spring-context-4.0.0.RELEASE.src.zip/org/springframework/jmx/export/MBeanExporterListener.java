package org.springframework.jmx.export;

import javax.management.ObjectName;

public abstract interface MBeanExporterListener
{
  public abstract void mbeanRegistered(ObjectName paramObjectName);

  public abstract void mbeanUnregistered(ObjectName paramObjectName);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.MBeanExporterListener
 * JD-Core Version:    0.6.2
 */