/*    */ package org.springframework.jmx.export;
/*    */ 
/*    */ public class UnableToRegisterMBeanException extends MBeanExportException
/*    */ {
/*    */   public UnableToRegisterMBeanException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ 
/*    */   public UnableToRegisterMBeanException(String msg, Throwable cause)
/*    */   {
/* 45 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.UnableToRegisterMBeanException
 * JD-Core Version:    0.6.2
 */