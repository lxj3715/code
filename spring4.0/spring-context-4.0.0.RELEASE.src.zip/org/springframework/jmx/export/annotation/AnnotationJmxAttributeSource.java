/*     */ package org.springframework.jmx.export.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.annotation.AnnotationBeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.jmx.export.metadata.InvalidMetadataException;
/*     */ import org.springframework.jmx.export.metadata.JmxAttributeSource;
/*     */ import org.springframework.jmx.export.metadata.ManagedNotification;
/*     */ import org.springframework.jmx.export.metadata.ManagedOperationParameter;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class AnnotationJmxAttributeSource
/*     */   implements JmxAttributeSource, BeanFactoryAware
/*     */ {
/*     */   private StringValueResolver embeddedValueResolver;
/*     */ 
/*     */   public void setBeanFactory(final BeanFactory beanFactory)
/*     */   {
/*  57 */     if ((beanFactory instanceof ConfigurableBeanFactory))
/*     */     {
/*  60 */       this.embeddedValueResolver = new StringValueResolver()
/*     */       {
/*     */         public String resolveStringValue(String strVal) {
/*  63 */           return ((ConfigurableBeanFactory)beanFactory).resolveEmbeddedValue(strVal);
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ 
/*     */   public org.springframework.jmx.export.metadata.ManagedResource getManagedResource(Class<?> beanClass)
/*     */     throws InvalidMetadataException
/*     */   {
/*  73 */     ManagedResource ann = (ManagedResource)beanClass
/*  73 */       .getAnnotation(ManagedResource.class);
/*     */ 
/*  74 */     if (ann == null) {
/*  75 */       return null;
/*     */     }
/*  77 */     org.springframework.jmx.export.metadata.ManagedResource managedResource = new org.springframework.jmx.export.metadata.ManagedResource();
/*  78 */     AnnotationBeanUtils.copyPropertiesToBean(ann, managedResource, this.embeddedValueResolver, new String[0]);
/*  79 */     if ((!"".equals(ann.value())) && (!StringUtils.hasLength(managedResource.getObjectName()))) {
/*  80 */       String value = ann.value();
/*  81 */       if (this.embeddedValueResolver != null) {
/*  82 */         value = this.embeddedValueResolver.resolveStringValue(value);
/*     */       }
/*  84 */       managedResource.setObjectName(value);
/*     */     }
/*  86 */     return managedResource;
/*     */   }
/*     */ 
/*     */   public org.springframework.jmx.export.metadata.ManagedAttribute getManagedAttribute(Method method)
/*     */     throws InvalidMetadataException
/*     */   {
/*  92 */     ManagedAttribute ann = (ManagedAttribute)AnnotationUtils.findAnnotation(method, ManagedAttribute.class);
/*     */ 
/*  93 */     if (ann == null) {
/*  94 */       return null;
/*     */     }
/*  96 */     org.springframework.jmx.export.metadata.ManagedAttribute managedAttribute = new org.springframework.jmx.export.metadata.ManagedAttribute();
/*  97 */     AnnotationBeanUtils.copyPropertiesToBean(ann, managedAttribute, new String[] { "defaultValue" });
/*  98 */     if (ann.defaultValue().length() > 0) {
/*  99 */       managedAttribute.setDefaultValue(ann.defaultValue());
/*     */     }
/* 101 */     return managedAttribute;
/*     */   }
/*     */ 
/*     */   public org.springframework.jmx.export.metadata.ManagedMetric getManagedMetric(Method method)
/*     */     throws InvalidMetadataException
/*     */   {
/* 107 */     ManagedMetric ann = (ManagedMetric)AnnotationUtils.findAnnotation(method, ManagedMetric.class);
/*     */ 
/* 108 */     if (ann == null) {
/* 109 */       return null;
/*     */     }
/* 111 */     org.springframework.jmx.export.metadata.ManagedMetric managedMetric = new org.springframework.jmx.export.metadata.ManagedMetric();
/* 112 */     AnnotationBeanUtils.copyPropertiesToBean(ann, managedMetric, new String[0]);
/* 113 */     return managedMetric;
/*     */   }
/*     */ 
/*     */   public org.springframework.jmx.export.metadata.ManagedOperation getManagedOperation(Method method) throws InvalidMetadataException
/*     */   {
/* 118 */     Annotation ann = AnnotationUtils.findAnnotation(method, ManagedOperation.class);
/* 119 */     if (ann == null) {
/* 120 */       return null;
/*     */     }
/* 122 */     org.springframework.jmx.export.metadata.ManagedOperation op = new org.springframework.jmx.export.metadata.ManagedOperation();
/* 123 */     AnnotationBeanUtils.copyPropertiesToBean(ann, op, new String[0]);
/* 124 */     return op;
/*     */   }
/*     */ 
/*     */   public ManagedOperationParameter[] getManagedOperationParameters(Method method)
/*     */     throws InvalidMetadataException
/*     */   {
/* 131 */     ManagedOperationParameters params = (ManagedOperationParameters)AnnotationUtils.findAnnotation(method, ManagedOperationParameters.class);
/* 132 */     ManagedOperationParameter[] result = null;
/* 133 */     if (params == null) {
/* 134 */       result = new ManagedOperationParameter[0];
/*     */     }
/*     */     else {
/* 137 */       Annotation[] paramData = params.value();
/* 138 */       result = new ManagedOperationParameter[paramData.length];
/* 139 */       for (int i = 0; i < paramData.length; i++) {
/* 140 */         Annotation annotation = paramData[i];
/* 141 */         ManagedOperationParameter managedOperationParameter = new ManagedOperationParameter();
/* 142 */         AnnotationBeanUtils.copyPropertiesToBean(annotation, managedOperationParameter, new String[0]);
/* 143 */         result[i] = managedOperationParameter;
/*     */       }
/*     */     }
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */   public ManagedNotification[] getManagedNotifications(Class<?> clazz) throws InvalidMetadataException
/*     */   {
/* 151 */     ManagedNotifications notificationsAnn = (ManagedNotifications)clazz.getAnnotation(ManagedNotifications.class);
/* 152 */     if (notificationsAnn == null) {
/* 153 */       return new ManagedNotification[0];
/*     */     }
/* 155 */     Annotation[] notifications = notificationsAnn.value();
/* 156 */     ManagedNotification[] result = new ManagedNotification[notifications.length];
/* 157 */     for (int i = 0; i < notifications.length; i++) {
/* 158 */       Annotation notification = notifications[i];
/* 159 */       ManagedNotification managedNotification = new ManagedNotification();
/* 160 */       AnnotationBeanUtils.copyPropertiesToBean(notification, managedNotification, new String[0]);
/* 161 */       result[i] = managedNotification;
/*     */     }
/* 163 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.annotation.AnnotationJmxAttributeSource
 * JD-Core Version:    0.6.2
 */