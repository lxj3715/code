package org.springframework.jmx.export.assembler;

public abstract interface AutodetectCapableMBeanInfoAssembler extends MBeanInfoAssembler
{
  public abstract boolean includeBean(Class<?> paramClass, String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.assembler.AutodetectCapableMBeanInfoAssembler
 * JD-Core Version:    0.6.2
 */