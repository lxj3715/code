/*     */ package org.springframework.jmx.export.assembler;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.modelmbean.ModelMBeanNotificationInfo;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.export.metadata.InvalidMetadataException;
/*     */ import org.springframework.jmx.export.metadata.JmxAttributeSource;
/*     */ import org.springframework.jmx.export.metadata.JmxMetadataUtils;
/*     */ import org.springframework.jmx.export.metadata.ManagedAttribute;
/*     */ import org.springframework.jmx.export.metadata.ManagedMetric;
/*     */ import org.springframework.jmx.export.metadata.ManagedNotification;
/*     */ import org.springframework.jmx.export.metadata.ManagedOperation;
/*     */ import org.springframework.jmx.export.metadata.ManagedOperationParameter;
/*     */ import org.springframework.jmx.export.metadata.ManagedResource;
/*     */ import org.springframework.jmx.support.MetricType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class MetadataMBeanInfoAssembler extends AbstractReflectiveMBeanInfoAssembler
/*     */   implements AutodetectCapableMBeanInfoAssembler, InitializingBean
/*     */ {
/*     */   private JmxAttributeSource attributeSource;
/*     */ 
/*     */   public MetadataMBeanInfoAssembler()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MetadataMBeanInfoAssembler(JmxAttributeSource attributeSource)
/*     */   {
/*  77 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  78 */     this.attributeSource = attributeSource;
/*     */   }
/*     */ 
/*     */   public void setAttributeSource(JmxAttributeSource attributeSource)
/*     */   {
/*  88 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  89 */     this.attributeSource = attributeSource;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/*  94 */     if (this.attributeSource == null)
/*  95 */       throw new IllegalArgumentException("Property 'attributeSource' is required");
/*     */   }
/*     */ 
/*     */   protected void checkManagedBean(Object managedBean)
/*     */     throws IllegalArgumentException
/*     */   {
/* 106 */     if (AopUtils.isJdkDynamicProxy(managedBean))
/* 107 */       throw new IllegalArgumentException("MetadataMBeanInfoAssembler does not support JDK dynamic proxies - export the target beans directly or use CGLIB proxies instead");
/*     */   }
/*     */ 
/*     */   public boolean includeBean(Class<?> beanClass, String beanName)
/*     */   {
/* 121 */     return this.attributeSource.getManagedResource(getClassToExpose(beanClass)) != null;
/*     */   }
/*     */ 
/*     */   protected boolean includeReadAttribute(Method method, String beanKey)
/*     */   {
/* 132 */     return (hasManagedAttribute(method)) || (hasManagedMetric(method));
/*     */   }
/*     */ 
/*     */   protected boolean includeWriteAttribute(Method method, String beanKey)
/*     */   {
/* 143 */     return hasManagedAttribute(method);
/*     */   }
/*     */ 
/*     */   protected boolean includeOperation(Method method, String beanKey)
/*     */   {
/* 154 */     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 155 */     if ((pd != null) && 
/* 156 */       (hasManagedAttribute(method))) {
/* 157 */       return true;
/*     */     }
/*     */ 
/* 160 */     return hasManagedOperation(method);
/*     */   }
/*     */ 
/*     */   private boolean hasManagedAttribute(Method method)
/*     */   {
/* 167 */     return this.attributeSource.getManagedAttribute(method) != null;
/*     */   }
/*     */ 
/*     */   private boolean hasManagedMetric(Method method)
/*     */   {
/* 174 */     return this.attributeSource.getManagedMetric(method) != null;
/*     */   }
/*     */ 
/*     */   private boolean hasManagedOperation(Method method)
/*     */   {
/* 182 */     return this.attributeSource.getManagedOperation(method) != null;
/*     */   }
/*     */ 
/*     */   protected String getDescription(Object managedBean, String beanKey)
/*     */   {
/* 192 */     ManagedResource mr = this.attributeSource.getManagedResource(getClassToExpose(managedBean));
/* 193 */     return mr != null ? mr.getDescription() : "";
/*     */   }
/*     */ 
/*     */   protected String getAttributeDescription(PropertyDescriptor propertyDescriptor, String beanKey)
/*     */   {
/* 203 */     Method readMethod = propertyDescriptor.getReadMethod();
/* 204 */     Method writeMethod = propertyDescriptor.getWriteMethod();
/*     */ 
/* 207 */     ManagedAttribute getter = readMethod != null ? this.attributeSource
/* 207 */       .getManagedAttribute(readMethod) : 
/* 207 */       null;
/*     */ 
/* 209 */     ManagedAttribute setter = writeMethod != null ? this.attributeSource
/* 209 */       .getManagedAttribute(writeMethod) : 
/* 209 */       null;
/*     */ 
/* 211 */     if ((getter != null) && (StringUtils.hasText(getter.getDescription()))) {
/* 212 */       return getter.getDescription();
/*     */     }
/* 214 */     if ((setter != null) && (StringUtils.hasText(setter.getDescription()))) {
/* 215 */       return setter.getDescription();
/*     */     }
/*     */ 
/* 218 */     ManagedMetric metric = readMethod != null ? this.attributeSource.getManagedMetric(readMethod) : null;
/* 219 */     if ((metric != null) && (StringUtils.hasText(metric.getDescription()))) {
/* 220 */       return metric.getDescription();
/*     */     }
/*     */ 
/* 223 */     return propertyDescriptor.getDisplayName();
/*     */   }
/*     */ 
/*     */   protected String getOperationDescription(Method method, String beanKey)
/*     */   {
/* 232 */     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 233 */     if (pd != null) {
/* 234 */       ManagedAttribute ma = this.attributeSource.getManagedAttribute(method);
/* 235 */       if ((ma != null) && (StringUtils.hasText(ma.getDescription()))) {
/* 236 */         return ma.getDescription();
/*     */       }
/* 238 */       ManagedMetric metric = this.attributeSource.getManagedMetric(method);
/* 239 */       if ((metric != null) && (StringUtils.hasText(metric.getDescription()))) {
/* 240 */         return metric.getDescription();
/*     */       }
/* 242 */       return method.getName();
/*     */     }
/*     */ 
/* 245 */     ManagedOperation mo = this.attributeSource.getManagedOperation(method);
/* 246 */     if ((mo != null) && (StringUtils.hasText(mo.getDescription()))) {
/* 247 */       return mo.getDescription();
/*     */     }
/* 249 */     return method.getName();
/*     */   }
/*     */ 
/*     */   protected MBeanParameterInfo[] getOperationParameters(Method method, String beanKey)
/*     */   {
/* 260 */     ManagedOperationParameter[] params = this.attributeSource.getManagedOperationParameters(method);
/* 261 */     if (ObjectUtils.isEmpty(params)) {
/* 262 */       return super.getOperationParameters(method, beanKey);
/*     */     }
/*     */ 
/* 265 */     MBeanParameterInfo[] parameterInfo = new MBeanParameterInfo[params.length];
/* 266 */     Class[] methodParameters = method.getParameterTypes();
/* 267 */     for (int i = 0; i < params.length; i++) {
/* 268 */       ManagedOperationParameter param = params[i];
/* 269 */       parameterInfo[i] = new MBeanParameterInfo(param
/* 270 */         .getName(), methodParameters[i].getName(), param.getDescription());
/*     */     }
/* 272 */     return parameterInfo;
/*     */   }
/*     */ 
/*     */   protected ModelMBeanNotificationInfo[] getNotificationInfo(Object managedBean, String beanKey)
/*     */   {
/* 282 */     ManagedNotification[] notificationAttributes = this.attributeSource
/* 282 */       .getManagedNotifications(getClassToExpose(managedBean));
/*     */ 
/* 283 */     ModelMBeanNotificationInfo[] notificationInfos = new ModelMBeanNotificationInfo[notificationAttributes.length];
/*     */ 
/* 286 */     for (int i = 0; i < notificationAttributes.length; i++) {
/* 287 */       ManagedNotification attribute = notificationAttributes[i];
/* 288 */       notificationInfos[i] = JmxMetadataUtils.convertToModelMBeanNotificationInfo(attribute);
/*     */     }
/*     */ 
/* 291 */     return notificationInfos;
/*     */   }
/*     */ 
/*     */   protected void populateMBeanDescriptor(Descriptor desc, Object managedBean, String beanKey)
/*     */   {
/* 302 */     ManagedResource mr = this.attributeSource.getManagedResource(getClassToExpose(managedBean));
/* 303 */     if (mr == null)
/*     */     {
/* 305 */       throw new InvalidMetadataException("No ManagedResource attribute found for class: " + 
/* 305 */         getClassToExpose(managedBean));
/*     */     }
/*     */ 
/* 308 */     applyCurrencyTimeLimit(desc, mr.getCurrencyTimeLimit());
/*     */ 
/* 310 */     if (mr.isLog()) {
/* 311 */       desc.setField("log", "true");
/*     */     }
/* 313 */     if (StringUtils.hasLength(mr.getLogFile())) {
/* 314 */       desc.setField("logFile", mr.getLogFile());
/*     */     }
/*     */ 
/* 317 */     if (StringUtils.hasLength(mr.getPersistPolicy())) {
/* 318 */       desc.setField("persistPolicy", mr.getPersistPolicy());
/*     */     }
/* 320 */     if (mr.getPersistPeriod() >= 0) {
/* 321 */       desc.setField("persistPeriod", Integer.toString(mr.getPersistPeriod()));
/*     */     }
/* 323 */     if (StringUtils.hasLength(mr.getPersistName())) {
/* 324 */       desc.setField("persistName", mr.getPersistName());
/*     */     }
/* 326 */     if (StringUtils.hasLength(mr.getPersistLocation()))
/* 327 */       desc.setField("persistLocation", mr.getPersistLocation());
/*     */   }
/*     */ 
/*     */   protected void populateAttributeDescriptor(Descriptor desc, Method getter, Method setter, String beanKey)
/*     */   {
/* 337 */     if ((getter != null) && (hasManagedMetric(getter))) {
/* 338 */       populateMetricDescriptor(desc, this.attributeSource.getManagedMetric(getter));
/*     */     }
/*     */     else
/*     */     {
/* 342 */       ManagedAttribute gma = getter == null ? ManagedAttribute.EMPTY : this.attributeSource
/* 342 */         .getManagedAttribute(getter);
/*     */ 
/* 344 */       ManagedAttribute sma = setter == null ? ManagedAttribute.EMPTY : this.attributeSource
/* 344 */         .getManagedAttribute(setter);
/*     */ 
/* 345 */       populateAttributeDescriptor(desc, gma, sma);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void populateAttributeDescriptor(Descriptor desc, ManagedAttribute gma, ManagedAttribute sma) {
/* 350 */     applyCurrencyTimeLimit(desc, resolveIntDescriptor(gma.getCurrencyTimeLimit(), sma.getCurrencyTimeLimit()));
/*     */ 
/* 352 */     Object defaultValue = resolveObjectDescriptor(gma.getDefaultValue(), sma.getDefaultValue());
/* 353 */     desc.setField("default", defaultValue);
/*     */ 
/* 355 */     String persistPolicy = resolveStringDescriptor(gma.getPersistPolicy(), sma.getPersistPolicy());
/* 356 */     if (StringUtils.hasLength(persistPolicy)) {
/* 357 */       desc.setField("persistPolicy", persistPolicy);
/*     */     }
/* 359 */     int persistPeriod = resolveIntDescriptor(gma.getPersistPeriod(), sma.getPersistPeriod());
/* 360 */     if (persistPeriod >= 0)
/* 361 */       desc.setField("persistPeriod", Integer.toString(persistPeriod));
/*     */   }
/*     */ 
/*     */   private void populateMetricDescriptor(Descriptor desc, ManagedMetric metric)
/*     */   {
/* 366 */     applyCurrencyTimeLimit(desc, metric.getCurrencyTimeLimit());
/*     */ 
/* 368 */     if (StringUtils.hasLength(metric.getPersistPolicy())) {
/* 369 */       desc.setField("persistPolicy", metric.getPersistPolicy());
/*     */     }
/* 371 */     if (metric.getPersistPeriod() >= 0) {
/* 372 */       desc.setField("persistPeriod", Integer.toString(metric.getPersistPeriod()));
/*     */     }
/*     */ 
/* 375 */     if (StringUtils.hasLength(metric.getDisplayName())) {
/* 376 */       desc.setField("displayName", metric.getDisplayName());
/*     */     }
/*     */ 
/* 379 */     if (StringUtils.hasLength(metric.getUnit())) {
/* 380 */       desc.setField("units", metric.getUnit());
/*     */     }
/*     */ 
/* 383 */     if (StringUtils.hasLength(metric.getCategory())) {
/* 384 */       desc.setField("metricCategory", metric.getCategory());
/*     */     }
/*     */ 
/* 387 */     String metricType = metric.getMetricType() == null ? MetricType.GAUGE.toString() : metric.getMetricType().toString();
/* 388 */     desc.setField("metricType", metricType);
/*     */   }
/*     */ 
/*     */   protected void populateOperationDescriptor(Descriptor desc, Method method, String beanKey)
/*     */   {
/* 398 */     ManagedOperation mo = this.attributeSource.getManagedOperation(method);
/* 399 */     if (mo != null)
/* 400 */       applyCurrencyTimeLimit(desc, mo.getCurrencyTimeLimit());
/*     */   }
/*     */ 
/*     */   private int resolveIntDescriptor(int getter, int setter)
/*     */   {
/* 414 */     return getter >= setter ? getter : setter;
/*     */   }
/*     */ 
/*     */   private Object resolveObjectDescriptor(Object getter, Object setter)
/*     */   {
/* 426 */     return getter != null ? getter : setter;
/*     */   }
/*     */ 
/*     */   private String resolveStringDescriptor(String getter, String setter)
/*     */   {
/* 440 */     return StringUtils.hasLength(getter) ? getter : setter;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.assembler.MetadataMBeanInfoAssembler
 * JD-Core Version:    0.6.2
 */