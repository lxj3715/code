/*    */ package org.springframework.jmx.export.metadata;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class InvalidMetadataException extends JmxException
/*    */ {
/*    */   public InvalidMetadataException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.InvalidMetadataException
 * JD-Core Version:    0.6.2
 */