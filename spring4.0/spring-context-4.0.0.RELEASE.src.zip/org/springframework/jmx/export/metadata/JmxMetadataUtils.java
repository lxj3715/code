/*    */ package org.springframework.jmx.export.metadata;
/*    */ 
/*    */ import javax.management.modelmbean.ModelMBeanNotificationInfo;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public abstract class JmxMetadataUtils
/*    */ {
/*    */   public static ModelMBeanNotificationInfo convertToModelMBeanNotificationInfo(ManagedNotification notificationInfo)
/*    */   {
/* 37 */     String name = notificationInfo.getName();
/* 38 */     if (!StringUtils.hasText(name)) {
/* 39 */       throw new IllegalArgumentException("Must specify notification name");
/*    */     }
/*    */ 
/* 42 */     String[] notifTypes = notificationInfo.getNotificationTypes();
/* 43 */     if ((notifTypes == null) || (notifTypes.length == 0)) {
/* 44 */       throw new IllegalArgumentException("Must specify at least one notification type");
/*    */     }
/*    */ 
/* 47 */     String description = notificationInfo.getDescription();
/* 48 */     return new ModelMBeanNotificationInfo(notifTypes, name, description);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.JmxMetadataUtils
 * JD-Core Version:    0.6.2
 */