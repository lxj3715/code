/*    */ package org.springframework.jmx.export.metadata;
/*    */ 
/*    */ public class ManagedAttribute extends AbstractJmxAttribute
/*    */ {
/* 30 */   public static final ManagedAttribute EMPTY = new ManagedAttribute();
/*    */   private Object defaultValue;
/*    */   private String persistPolicy;
/* 37 */   private int persistPeriod = -1;
/*    */ 
/*    */   public void setDefaultValue(Object defaultValue)
/*    */   {
/* 44 */     this.defaultValue = defaultValue;
/*    */   }
/*    */ 
/*    */   public Object getDefaultValue()
/*    */   {
/* 51 */     return this.defaultValue;
/*    */   }
/*    */ 
/*    */   public void setPersistPolicy(String persistPolicy) {
/* 55 */     this.persistPolicy = persistPolicy;
/*    */   }
/*    */ 
/*    */   public String getPersistPolicy() {
/* 59 */     return this.persistPolicy;
/*    */   }
/*    */ 
/*    */   public void setPersistPeriod(int persistPeriod) {
/* 63 */     this.persistPeriod = persistPeriod;
/*    */   }
/*    */ 
/*    */   public int getPersistPeriod() {
/* 67 */     return this.persistPeriod;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.ManagedAttribute
 * JD-Core Version:    0.6.2
 */