/*     */ package org.springframework.jmx.export.metadata;
/*     */ 
/*     */ import org.springframework.jmx.support.MetricType;
/*     */ 
/*     */ public class ManagedMetric extends AbstractJmxAttribute
/*     */ {
/*  32 */   private String category = "";
/*     */ 
/*  34 */   private String displayName = "";
/*     */ 
/*  36 */   private MetricType metricType = MetricType.GAUGE;
/*     */ 
/*  38 */   private int persistPeriod = -1;
/*     */ 
/*  40 */   private String persistPolicy = "";
/*     */ 
/*  42 */   private String unit = "";
/*     */ 
/*     */   public void setCategory(String category)
/*     */   {
/*  49 */     this.category = category;
/*     */   }
/*     */ 
/*     */   public String getCategory()
/*     */   {
/*  56 */     return this.category;
/*     */   }
/*     */ 
/*     */   public void setDisplayName(String displayName)
/*     */   {
/*  63 */     this.displayName = displayName;
/*     */   }
/*     */ 
/*     */   public String getDisplayName()
/*     */   {
/*  70 */     return this.displayName;
/*     */   }
/*     */ 
/*     */   public void setMetricType(MetricType metricType)
/*     */   {
/*  77 */     this.metricType = metricType;
/*     */   }
/*     */ 
/*     */   public MetricType getMetricType()
/*     */   {
/*  84 */     return this.metricType;
/*     */   }
/*     */ 
/*     */   public void setPersistPeriod(int persistPeriod)
/*     */   {
/*  91 */     this.persistPeriod = persistPeriod;
/*     */   }
/*     */ 
/*     */   public int getPersistPeriod()
/*     */   {
/*  98 */     return this.persistPeriod;
/*     */   }
/*     */ 
/*     */   public void setPersistPolicy(String persistPolicy)
/*     */   {
/* 105 */     this.persistPolicy = persistPolicy;
/*     */   }
/*     */ 
/*     */   public String getPersistPolicy()
/*     */   {
/* 112 */     return this.persistPolicy;
/*     */   }
/*     */ 
/*     */   public void setUnit(String unit)
/*     */   {
/* 119 */     this.unit = unit;
/*     */   }
/*     */ 
/*     */   public String getUnit()
/*     */   {
/* 126 */     return this.unit;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.ManagedMetric
 * JD-Core Version:    0.6.2
 */