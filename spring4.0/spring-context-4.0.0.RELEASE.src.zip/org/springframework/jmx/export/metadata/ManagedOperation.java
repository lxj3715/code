package org.springframework.jmx.export.metadata;

public class ManagedOperation extends AbstractJmxAttribute
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.ManagedOperation
 * JD-Core Version:    0.6.2
 */