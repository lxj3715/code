/*     */ package org.springframework.jmx.export.naming;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class KeyNamingStrategy
/*     */   implements ObjectNamingStrategy, InitializingBean
/*     */ {
/*  58 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Properties mappings;
/*     */   private Resource[] mappingLocations;
/*     */   private Properties mergedMappings;
/*     */ 
/*     */   public void setMappings(Properties mappings)
/*     */   {
/*  85 */     this.mappings = mappings;
/*     */   }
/*     */ 
/*     */   public void setMappingLocation(Resource location)
/*     */   {
/*  93 */     this.mappingLocations = new Resource[] { location };
/*     */   }
/*     */ 
/*     */   public void setMappingLocations(Resource[] mappingLocations)
/*     */   {
/* 101 */     this.mappingLocations = mappingLocations;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IOException
/*     */   {
/* 113 */     this.mergedMappings = new Properties();
/*     */ 
/* 115 */     CollectionUtils.mergePropertiesIntoMap(this.mappings, this.mergedMappings);
/*     */ 
/* 117 */     if (this.mappingLocations != null)
/* 118 */       for (int i = 0; i < this.mappingLocations.length; i++) {
/* 119 */         Resource location = this.mappingLocations[i];
/* 120 */         if (this.logger.isInfoEnabled()) {
/* 121 */           this.logger.info("Loading JMX object name mappings file from " + location);
/*     */         }
/* 123 */         PropertiesLoaderUtils.fillProperties(this.mergedMappings, location);
/*     */       }
/*     */   }
/*     */ 
/*     */   public ObjectName getObjectName(Object managedBean, String beanKey)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 135 */     String objectName = null;
/* 136 */     if (this.mergedMappings != null) {
/* 137 */       objectName = this.mergedMappings.getProperty(beanKey);
/*     */     }
/* 139 */     if (objectName == null) {
/* 140 */       objectName = beanKey;
/*     */     }
/* 142 */     return ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.naming.KeyNamingStrategy
 * JD-Core Version:    0.6.2
 */