package org.springframework.jmx.export.notification;

import javax.management.Notification;

public abstract interface NotificationPublisher
{
  public abstract void sendNotification(Notification paramNotification)
    throws UnableToSendNotificationException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.notification.NotificationPublisher
 * JD-Core Version:    0.6.2
 */