package org.springframework.jmx.export.notification;

import org.springframework.beans.factory.Aware;

public abstract interface NotificationPublisherAware extends Aware
{
  public abstract void setNotificationPublisher(NotificationPublisher paramNotificationPublisher);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.notification.NotificationPublisherAware
 * JD-Core Version:    0.6.2
 */