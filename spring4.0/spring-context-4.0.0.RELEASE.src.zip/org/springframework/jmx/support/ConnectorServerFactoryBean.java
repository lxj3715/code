/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXConnectorServer;
/*     */ import javax.management.remote.JMXConnectorServerFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.management.remote.MBeanServerForwarder;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.JmxException;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class ConnectorServerFactoryBean extends MBeanRegistrationSupport
/*     */   implements FactoryBean<JMXConnectorServer>, InitializingBean, DisposableBean
/*     */ {
/*     */   public static final String DEFAULT_SERVICE_URL = "service:jmx:jmxmp://localhost:9875";
/*  63 */   private String serviceUrl = "service:jmx:jmxmp://localhost:9875";
/*     */ 
/*  65 */   private Map<String, Object> environment = new HashMap();
/*     */   private MBeanServerForwarder forwarder;
/*     */   private ObjectName objectName;
/*  71 */   private boolean threaded = false;
/*     */ 
/*  73 */   private boolean daemon = false;
/*     */   private JMXConnectorServer connectorServer;
/*     */ 
/*     */   public void setServiceUrl(String serviceUrl)
/*     */   {
/*  82 */     this.serviceUrl = serviceUrl;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Properties environment)
/*     */   {
/*  90 */     CollectionUtils.mergePropertiesIntoMap(environment, this.environment);
/*     */   }
/*     */ 
/*     */   public void setEnvironmentMap(Map<String, ?> environment)
/*     */   {
/*  98 */     if (environment != null)
/*  99 */       this.environment.putAll(environment);
/*     */   }
/*     */ 
/*     */   public void setForwarder(MBeanServerForwarder forwarder)
/*     */   {
/* 107 */     this.forwarder = forwarder;
/*     */   }
/*     */ 
/*     */   public void setObjectName(Object objectName)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 117 */     this.objectName = ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */ 
/*     */   public void setThreaded(boolean threaded)
/*     */   {
/* 124 */     this.threaded = threaded;
/*     */   }
/*     */ 
/*     */   public void setDaemon(boolean daemon)
/*     */   {
/* 132 */     this.daemon = daemon;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws JMException, IOException
/*     */   {
/* 147 */     if (this.server == null) {
/* 148 */       this.server = JmxUtils.locateMBeanServer();
/*     */     }
/*     */ 
/* 152 */     JMXServiceURL url = new JMXServiceURL(this.serviceUrl);
/*     */ 
/* 155 */     this.connectorServer = JMXConnectorServerFactory.newJMXConnectorServer(url, this.environment, this.server);
/*     */ 
/* 158 */     if (this.forwarder != null) {
/* 159 */       this.connectorServer.setMBeanServerForwarder(this.forwarder);
/*     */     }
/*     */ 
/* 163 */     if (this.objectName != null) {
/* 164 */       doRegister(this.connectorServer, this.objectName);
/*     */     }
/*     */     try
/*     */     {
/* 168 */       if (this.threaded)
/*     */       {
/* 170 */         Thread connectorThread = new Thread()
/*     */         {
/*     */           public void run() {
/*     */             try {
/* 174 */               ConnectorServerFactoryBean.this.connectorServer.start();
/*     */             }
/*     */             catch (IOException ex) {
/* 177 */               throw new JmxException("Could not start JMX connector server after delay", ex);
/*     */             }
/*     */           }
/*     */         };
/* 182 */         connectorThread.setName("JMX Connector Thread [" + this.serviceUrl + "]");
/* 183 */         connectorThread.setDaemon(this.daemon);
/* 184 */         connectorThread.start();
/*     */       }
/*     */       else
/*     */       {
/* 188 */         this.connectorServer.start();
/*     */       }
/*     */ 
/* 191 */       if (this.logger.isInfoEnabled()) {
/* 192 */         this.logger.info("JMX connector server started: " + this.connectorServer);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 198 */       unregisterBeans();
/* 199 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public JMXConnectorServer getObject()
/*     */   {
/* 206 */     return this.connectorServer;
/*     */   }
/*     */ 
/*     */   public Class<? extends JMXConnectorServer> getObjectType()
/*     */   {
/* 211 */     return this.connectorServer != null ? this.connectorServer.getClass() : JMXConnectorServer.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 216 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws IOException
/*     */   {
/* 227 */     if (this.logger.isInfoEnabled())
/* 228 */       this.logger.info("Stopping JMX connector server: " + this.connectorServer);
/*     */     try
/*     */     {
/* 231 */       this.connectorServer.stop();
/*     */ 
/* 234 */       unregisterBeans(); } finally { unregisterBeans(); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.support.ConnectorServerFactoryBean
 * JD-Core Version:    0.6.2
 */