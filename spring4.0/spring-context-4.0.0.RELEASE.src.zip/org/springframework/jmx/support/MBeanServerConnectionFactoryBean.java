/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.remote.JMXConnector;
/*     */ import javax.management.remote.JMXConnectorFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.target.AbstractLazyCreationTargetSource;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class MBeanServerConnectionFactoryBean
/*     */   implements FactoryBean<MBeanServerConnection>, BeanClassLoaderAware, InitializingBean, DisposableBean
/*     */ {
/*     */   private JMXServiceURL serviceUrl;
/*     */   private Map<String, Object> environment;
/*     */   private boolean connectOnStartup;
/*     */   private ClassLoader beanClassLoader;
/*     */   private JMXConnector connector;
/*     */   private MBeanServerConnection connection;
/*     */   private JMXConnectorLazyInitTargetSource connectorTargetSource;
/*     */ 
/*     */   public MBeanServerConnectionFactoryBean()
/*     */   {
/*  57 */     this.environment = new HashMap();
/*     */ 
/*  59 */     this.connectOnStartup = true;
/*     */ 
/*  61 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   public void setServiceUrl(String url)
/*     */     throws MalformedURLException
/*     */   {
/*  74 */     this.serviceUrl = new JMXServiceURL(url);
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Properties environment)
/*     */   {
/*  82 */     CollectionUtils.mergePropertiesIntoMap(environment, this.environment);
/*     */   }
/*     */ 
/*     */   public void setEnvironmentMap(Map<String, ?> environment)
/*     */   {
/*  90 */     if (environment != null)
/*  91 */       this.environment.putAll(environment);
/*     */   }
/*     */ 
/*     */   public void setConnectOnStartup(boolean connectOnStartup)
/*     */   {
/* 101 */     this.connectOnStartup = connectOnStartup;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 106 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IOException
/*     */   {
/* 116 */     if (this.serviceUrl == null) {
/* 117 */       throw new IllegalArgumentException("Property 'serviceUrl' is required");
/*     */     }
/*     */ 
/* 120 */     if (this.connectOnStartup) {
/* 121 */       connect();
/*     */     }
/*     */     else
/* 124 */       createLazyConnection();
/*     */   }
/*     */ 
/*     */   private void connect()
/*     */     throws IOException
/*     */   {
/* 133 */     this.connector = JMXConnectorFactory.connect(this.serviceUrl, this.environment);
/* 134 */     this.connection = this.connector.getMBeanServerConnection();
/*     */   }
/*     */ 
/*     */   private void createLazyConnection()
/*     */   {
/* 141 */     this.connectorTargetSource = new JMXConnectorLazyInitTargetSource(null);
/* 142 */     TargetSource connectionTargetSource = new MBeanServerConnectionLazyInitTargetSource(null);
/*     */ 
/* 144 */     this.connector = 
/* 145 */       ((JMXConnector)new ProxyFactory(JMXConnector.class, this.connectorTargetSource)
/* 145 */       .getProxy(this.beanClassLoader));
/*     */ 
/* 146 */     this.connection = 
/* 147 */       ((MBeanServerConnection)new ProxyFactory(MBeanServerConnection.class, connectionTargetSource)
/* 147 */       .getProxy(this.beanClassLoader));
/*     */   }
/*     */ 
/*     */   public MBeanServerConnection getObject()
/*     */   {
/* 153 */     return this.connection;
/*     */   }
/*     */ 
/*     */   public Class<? extends MBeanServerConnection> getObjectType()
/*     */   {
/* 158 */     return this.connection != null ? this.connection.getClass() : MBeanServerConnection.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 163 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws IOException
/*     */   {
/* 172 */     if ((this.connectorTargetSource == null) || (this.connectorTargetSource.isInitialized()))
/* 173 */       this.connector.close();
/*     */   }
/*     */ 
/*     */   private class MBeanServerConnectionLazyInitTargetSource extends AbstractLazyCreationTargetSource
/*     */   {
/*     */     private MBeanServerConnectionLazyInitTargetSource()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Object createObject()
/*     */       throws Exception
/*     */     {
/* 205 */       return MBeanServerConnectionFactoryBean.this.connector.getMBeanServerConnection();
/*     */     }
/*     */ 
/*     */     public Class<?> getTargetClass()
/*     */     {
/* 210 */       return MBeanServerConnection.class;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class JMXConnectorLazyInitTargetSource extends AbstractLazyCreationTargetSource
/*     */   {
/*     */     private JMXConnectorLazyInitTargetSource()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Object createObject()
/*     */       throws Exception
/*     */     {
/* 188 */       return JMXConnectorFactory.connect(MBeanServerConnectionFactoryBean.this.serviceUrl, MBeanServerConnectionFactoryBean.this.environment);
/*     */     }
/*     */ 
/*     */     public Class<?> getTargetClass()
/*     */     {
/* 193 */       return JMXConnector.class;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.support.MBeanServerConnectionFactoryBean
 * JD-Core Version:    0.6.2
 */