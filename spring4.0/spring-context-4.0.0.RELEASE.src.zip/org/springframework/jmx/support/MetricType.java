/*    */ package org.springframework.jmx.support;
/*    */ 
/*    */ public enum MetricType
/*    */ {
/* 29 */   GAUGE, 
/*    */ 
/* 34 */   COUNTER;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.support.MetricType
 * JD-Core Version:    0.6.2
 */