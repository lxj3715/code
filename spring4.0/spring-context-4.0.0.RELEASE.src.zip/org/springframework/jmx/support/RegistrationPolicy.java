/*    */ package org.springframework.jmx.support;
/*    */ 
/*    */ public enum RegistrationPolicy
/*    */ {
/* 33 */   FAIL_ON_EXISTING, 
/*    */ 
/* 39 */   IGNORE_EXISTING, 
/*    */ 
/* 45 */   REPLACE_EXISTING;
/*    */ 
/*    */   static RegistrationPolicy valueOf(int registrationBehavior)
/*    */   {
/* 55 */     switch (registrationBehavior) {
/*    */     case 1:
/* 57 */       return IGNORE_EXISTING;
/*    */     case 2:
/* 59 */       return REPLACE_EXISTING;
/*    */     case 0:
/* 61 */       return FAIL_ON_EXISTING;
/*    */     }
/* 63 */     throw new IllegalArgumentException("Unknown MBean registration behavior: " + registrationBehavior);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.support.RegistrationPolicy
 * JD-Core Version:    0.6.2
 */