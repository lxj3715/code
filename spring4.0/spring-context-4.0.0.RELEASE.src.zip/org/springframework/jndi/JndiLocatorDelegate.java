/*    */ package org.springframework.jndi;
/*    */ 
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ public class JndiLocatorDelegate extends JndiLocatorSupport
/*    */ {
/*    */   public Object lookup(String jndiName)
/*    */     throws NamingException
/*    */   {
/* 33 */     return super.lookup(jndiName);
/*    */   }
/*    */ 
/*    */   public <T> T lookup(String jndiName, Class<T> requiredType) throws NamingException
/*    */   {
/* 38 */     return super.lookup(jndiName, requiredType);
/*    */   }
/*    */ 
/*    */   public static JndiLocatorDelegate createDefaultResourceRefLocator()
/*    */   {
/* 48 */     JndiLocatorDelegate jndiLocator = new JndiLocatorDelegate();
/* 49 */     jndiLocator.setResourceRef(true);
/* 50 */     return jndiLocator;
/*    */   }
/*    */ 
/*    */   public static boolean isDefaultJndiEnvironmentAvailable()
/*    */   {
/*    */     try
/*    */     {
/* 61 */       new InitialContext();
/* 62 */       return true;
/*    */     } catch (Throwable ex) {
/*    */     }
/* 65 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiLocatorDelegate
 * JD-Core Version:    0.6.2
 */