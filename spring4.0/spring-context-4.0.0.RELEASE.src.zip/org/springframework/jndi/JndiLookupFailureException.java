/*    */ package org.springframework.jndi;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class JndiLookupFailureException extends NestedRuntimeException
/*    */ {
/*    */   public JndiLookupFailureException(String msg, NamingException cause)
/*    */   {
/* 42 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiLookupFailureException
 * JD-Core Version:    0.6.2
 */