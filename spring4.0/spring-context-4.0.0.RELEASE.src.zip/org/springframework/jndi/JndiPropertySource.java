/*    */ package org.springframework.jndi;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ public class JndiPropertySource extends PropertySource<JndiLocatorDelegate>
/*    */ {
/*    */   public JndiPropertySource(String name)
/*    */   {
/* 61 */     this(name, JndiLocatorDelegate.createDefaultResourceRefLocator());
/*    */   }
/*    */ 
/*    */   public JndiPropertySource(String name, JndiLocatorDelegate jndiLocator)
/*    */   {
/* 69 */     super(name, jndiLocator);
/*    */   }
/*    */ 
/*    */   public Object getProperty(String name)
/*    */   {
/*    */     try
/*    */     {
/* 82 */       Object value = ((JndiLocatorDelegate)this.source).lookup(name);
/* 83 */       this.logger.debug("JNDI lookup for name [" + name + "] returned: [" + value + "]");
/* 84 */       return value;
/*    */     }
/*    */     catch (NamingException ex) {
/* 87 */       this.logger.debug("JNDI lookup for name [" + name + "] threw NamingException " + "with message: " + ex
/* 88 */         .getMessage() + ". Returning null.");
/* 89 */     }return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiPropertySource
 * JD-Core Version:    0.6.2
 */