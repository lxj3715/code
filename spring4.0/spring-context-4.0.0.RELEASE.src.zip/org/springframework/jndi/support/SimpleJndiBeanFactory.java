/*     */ package org.springframework.jndi.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.naming.NameNotFoundException;
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ import org.springframework.jndi.TypeMismatchNamingException;
/*     */ 
/*     */ public class SimpleJndiBeanFactory extends JndiLocatorSupport
/*     */   implements BeanFactory
/*     */ {
/*  63 */   private final Set<String> shareableResources = new HashSet();
/*     */ 
/*  66 */   private final Map<String, Object> singletonObjects = new HashMap();
/*     */ 
/*  69 */   private final Map<String, Class<?>> resourceTypes = new HashMap();
/*     */ 
/*     */   public SimpleJndiBeanFactory()
/*     */   {
/*  73 */     setResourceRef(true);
/*     */   }
/*     */ 
/*     */   public void setShareableResources(String[] shareableResources)
/*     */   {
/*  84 */     this.shareableResources.addAll(Arrays.asList(shareableResources));
/*     */   }
/*     */ 
/*     */   public void addShareableResource(String shareableResource)
/*     */   {
/*  94 */     this.shareableResources.add(shareableResource);
/*     */   }
/*     */ 
/*     */   public Object getBean(String name)
/*     */     throws BeansException
/*     */   {
/* 105 */     return getBean(name, Object.class);
/*     */   }
/*     */ 
/*     */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException
/*     */   {
/*     */     try {
/* 111 */       if (isSingleton(name)) {
/* 112 */         return doGetSingleton(name, requiredType);
/*     */       }
/*     */ 
/* 115 */       return lookup(name, requiredType);
/*     */     }
/*     */     catch (NameNotFoundException ex)
/*     */     {
/* 119 */       throw new NoSuchBeanDefinitionException(name, "not found in JNDI environment");
/*     */     }
/*     */     catch (TypeMismatchNamingException ex) {
/* 122 */       throw new BeanNotOfRequiredTypeException(name, ex.getRequiredType(), ex.getActualType());
/*     */     }
/*     */     catch (NamingException ex) {
/* 125 */       throw new BeanDefinitionStoreException("JNDI environment", name, "JNDI lookup failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T getBean(Class<T> requiredType) throws BeansException
/*     */   {
/* 131 */     return getBean(requiredType.getSimpleName(), requiredType);
/*     */   }
/*     */ 
/*     */   public Object getBean(String name, Object[] args) throws BeansException
/*     */   {
/* 136 */     if (args != null) {
/* 137 */       throw new UnsupportedOperationException("SimpleJndiBeanFactory does not support explicit bean creation arguments)");
/*     */     }
/*     */ 
/* 140 */     return getBean(name);
/*     */   }
/*     */ 
/*     */   public boolean containsBean(String name)
/*     */   {
/* 145 */     if ((this.singletonObjects.containsKey(name)) || (this.resourceTypes.containsKey(name)))
/* 146 */       return true;
/*     */     try
/*     */     {
/* 149 */       doGetType(name);
/* 150 */       return true;
/*     */     } catch (NamingException ex) {
/*     */     }
/* 153 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton(String name)
/*     */     throws NoSuchBeanDefinitionException
/*     */   {
/* 159 */     return this.shareableResources.contains(name);
/*     */   }
/*     */ 
/*     */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException
/*     */   {
/* 164 */     return !this.shareableResources.contains(name);
/*     */   }
/*     */ 
/*     */   public boolean isTypeMatch(String name, Class<?> targetType) throws NoSuchBeanDefinitionException
/*     */   {
/* 169 */     Class type = getType(name);
/* 170 */     return (targetType == null) || ((type != null) && (targetType.isAssignableFrom(type)));
/*     */   }
/*     */ 
/*     */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException
/*     */   {
/*     */     try {
/* 176 */       return doGetType(name);
/*     */     }
/*     */     catch (NameNotFoundException ex) {
/* 179 */       throw new NoSuchBeanDefinitionException(name, "not found in JNDI environment");
/*     */     } catch (NamingException ex) {
/*     */     }
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */   public String[] getAliases(String name)
/*     */   {
/* 188 */     return new String[0];
/*     */   }
/*     */ 
/*     */   private <T> T doGetSingleton(String name, Class<T> requiredType)
/*     */     throws NamingException
/*     */   {
/* 194 */     synchronized (this.singletonObjects) {
/* 195 */       if (this.singletonObjects.containsKey(name)) {
/* 196 */         Object jndiObject = this.singletonObjects.get(name);
/* 197 */         if ((requiredType != null) && (!requiredType.isInstance(jndiObject)))
/*     */         {
/* 199 */           throw new TypeMismatchNamingException(
/* 199 */             convertJndiName(name), 
/* 199 */             requiredType, jndiObject != null ? jndiObject.getClass() : null);
/*     */         }
/* 201 */         return jndiObject;
/*     */       }
/* 203 */       Object jndiObject = lookup(name, requiredType);
/* 204 */       this.singletonObjects.put(name, jndiObject);
/* 205 */       return jndiObject;
/*     */     }
/*     */   }
/*     */ 
/*     */   private Class<?> doGetType(String name) throws NamingException {
/* 210 */     if (isSingleton(name)) {
/* 211 */       Object jndiObject = doGetSingleton(name, null);
/* 212 */       return jndiObject != null ? jndiObject.getClass() : null;
/*     */     }
/*     */ 
/* 215 */     synchronized (this.resourceTypes) {
/* 216 */       if (this.resourceTypes.containsKey(name)) {
/* 217 */         return (Class)this.resourceTypes.get(name);
/*     */       }
/*     */ 
/* 220 */       Object jndiObject = lookup(name, null);
/* 221 */       Class type = jndiObject != null ? jndiObject.getClass() : null;
/* 222 */       this.resourceTypes.put(name, type);
/* 223 */       return type;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.support.SimpleJndiBeanFactory
 * JD-Core Version:    0.6.2
 */