/*    */ package org.springframework.remoting;
/*    */ 
/*    */ public class RemoteConnectFailureException extends RemoteAccessException
/*    */ {
/*    */   public RemoteConnectFailureException(String msg, Throwable cause)
/*    */   {
/* 35 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteConnectFailureException
 * JD-Core Version:    0.6.2
 */