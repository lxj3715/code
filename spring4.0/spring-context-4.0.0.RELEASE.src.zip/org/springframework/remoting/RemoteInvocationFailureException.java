/*    */ package org.springframework.remoting;
/*    */ 
/*    */ public class RemoteInvocationFailureException extends RemoteAccessException
/*    */ {
/*    */   public RemoteInvocationFailureException(String msg, Throwable cause)
/*    */   {
/* 37 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteInvocationFailureException
 * JD-Core Version:    0.6.2
 */