/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.omg.CORBA.OBJECT_NOT_EXIST;
/*     */ import org.omg.CORBA.SystemException;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jndi.JndiObjectLocator;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ import org.springframework.remoting.RemoteAccessException;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteInvocationFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.support.DefaultRemoteInvocationFactory;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationFactory;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class JndiRmiClientInterceptor extends JndiObjectLocator
/*     */   implements MethodInterceptor, InitializingBean
/*     */ {
/*     */   private Class<?> serviceInterface;
/*  83 */   private RemoteInvocationFactory remoteInvocationFactory = new DefaultRemoteInvocationFactory();
/*     */ 
/*  85 */   private boolean lookupStubOnStartup = true;
/*     */ 
/*  87 */   private boolean cacheStub = true;
/*     */ 
/*  89 */   private boolean refreshStubOnConnectFailure = false;
/*     */ 
/*  91 */   private boolean exposeAccessContext = false;
/*     */   private Object cachedStub;
/*  95 */   private final Object stubMonitor = new Object();
/*     */ 
/*     */   public void setServiceInterface(Class<?> serviceInterface)
/*     */   {
/* 105 */     if ((serviceInterface != null) && (!serviceInterface.isInterface())) {
/* 106 */       throw new IllegalArgumentException("'serviceInterface' must be an interface");
/*     */     }
/* 108 */     this.serviceInterface = serviceInterface;
/*     */   }
/*     */ 
/*     */   public Class<?> getServiceInterface()
/*     */   {
/* 115 */     return this.serviceInterface;
/*     */   }
/*     */ 
/*     */   public void setRemoteInvocationFactory(RemoteInvocationFactory remoteInvocationFactory)
/*     */   {
/* 125 */     this.remoteInvocationFactory = remoteInvocationFactory;
/*     */   }
/*     */ 
/*     */   public RemoteInvocationFactory getRemoteInvocationFactory()
/*     */   {
/* 132 */     return this.remoteInvocationFactory;
/*     */   }
/*     */ 
/*     */   public void setLookupStubOnStartup(boolean lookupStubOnStartup)
/*     */   {
/* 142 */     this.lookupStubOnStartup = lookupStubOnStartup;
/*     */   }
/*     */ 
/*     */   public void setCacheStub(boolean cacheStub)
/*     */   {
/* 153 */     this.cacheStub = cacheStub;
/*     */   }
/*     */ 
/*     */   public void setRefreshStubOnConnectFailure(boolean refreshStubOnConnectFailure)
/*     */   {
/* 168 */     this.refreshStubOnConnectFailure = refreshStubOnConnectFailure;
/*     */   }
/*     */ 
/*     */   public void setExposeAccessContext(boolean exposeAccessContext)
/*     */   {
/* 180 */     this.exposeAccessContext = exposeAccessContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException
/*     */   {
/* 186 */     super.afterPropertiesSet();
/* 187 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteLookupFailureException
/*     */   {
/* 198 */     if (this.lookupStubOnStartup) {
/* 199 */       Object remoteObj = lookupStub();
/* 200 */       if (this.logger.isDebugEnabled()) {
/* 201 */         if ((remoteObj instanceof RmiInvocationHandler)) {
/* 202 */           this.logger.debug(new StringBuilder().append("JNDI RMI object [").append(getJndiName()).append("] is an RMI invoker").toString());
/*     */         }
/* 204 */         else if (getServiceInterface() != null) {
/* 205 */           boolean isImpl = getServiceInterface().isInstance(remoteObj);
/* 206 */           this.logger.debug(new StringBuilder().append("Using service interface [").append(getServiceInterface().getName()).append("] for JNDI RMI object [")
/* 207 */             .append(getJndiName()).append("] - ").append(!isImpl ? "not " : "").append("directly implemented").toString());
/*     */         }
/*     */       }
/*     */ 
/* 211 */       if (this.cacheStub)
/* 212 */         this.cachedStub = remoteObj;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object lookupStub()
/*     */     throws RemoteLookupFailureException
/*     */   {
/*     */     try
/*     */     {
/* 230 */       Object stub = lookup();
/* 231 */       if ((getServiceInterface() != null) && (!(stub instanceof RmiInvocationHandler))) {
/*     */         try {
/* 233 */           stub = PortableRemoteObject.narrow(stub, getServiceInterface());
/*     */         }
/*     */         catch (ClassCastException ex)
/*     */         {
/* 237 */           throw new RemoteLookupFailureException(new StringBuilder().append("Could not narrow RMI stub to service interface [")
/* 237 */             .append(getServiceInterface().getName()).append("]").toString(), ex);
/*     */         }
/*     */       }
/* 240 */       return stub;
/*     */     }
/*     */     catch (NamingException ex) {
/* 243 */       throw new RemoteLookupFailureException(new StringBuilder().append("JNDI lookup for RMI service [").append(getJndiName()).append("] failed").toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object getStub()
/*     */     throws NamingException, RemoteLookupFailureException
/*     */   {
/* 259 */     if ((!this.cacheStub) || ((this.lookupStubOnStartup) && (!this.refreshStubOnConnectFailure))) {
/* 260 */       return this.cachedStub != null ? this.cachedStub : lookupStub();
/*     */     }
/*     */ 
/* 263 */     synchronized (this.stubMonitor) {
/* 264 */       if (this.cachedStub == null) {
/* 265 */         this.cachedStub = lookupStub();
/*     */       }
/* 267 */       return this.cachedStub;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 288 */       stub = getStub();
/*     */     }
/*     */     catch (NamingException ex)
/*     */     {
/*     */       Object stub;
/* 291 */       throw new RemoteLookupFailureException(new StringBuilder().append("JNDI lookup for RMI service [").append(getJndiName()).append("] failed").toString(), ex);
/*     */     }
/*     */     Object stub;
/* 294 */     Context ctx = this.exposeAccessContext ? getJndiTemplate().getContext() : null;
/*     */     try {
/* 296 */       return doInvoke(invocation, stub);
/*     */     }
/*     */     catch (RemoteConnectFailureException ex) {
/* 299 */       return handleRemoteConnectFailure(invocation, ex);
/*     */     }
/*     */     catch (RemoteException ex) {
/* 302 */       if (isConnectFailure(ex)) {
/* 303 */         return handleRemoteConnectFailure(invocation, ex);
/*     */       }
/*     */ 
/* 306 */       throw ex;
/*     */     }
/*     */     catch (SystemException ex)
/*     */     {
/*     */       Object localObject2;
/* 310 */       if (isConnectFailure(ex)) {
/* 311 */         return handleRemoteConnectFailure(invocation, ex);
/*     */       }
/*     */ 
/* 314 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/* 318 */       getJndiTemplate().releaseContext(ctx);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 330 */     return RmiClientInterceptorUtils.isConnectFailure(ex);
/*     */   }
/*     */ 
/*     */   protected boolean isConnectFailure(SystemException ex)
/*     */   {
/* 341 */     return ex instanceof OBJECT_NOT_EXIST;
/*     */   }
/*     */ 
/*     */   private Object handleRemoteConnectFailure(MethodInvocation invocation, Exception ex)
/*     */     throws Throwable
/*     */   {
/* 354 */     if (this.refreshStubOnConnectFailure) {
/* 355 */       if (this.logger.isDebugEnabled()) {
/* 356 */         this.logger.debug(new StringBuilder().append("Could not connect to RMI service [").append(getJndiName()).append("] - retrying").toString(), ex);
/*     */       }
/* 358 */       else if (this.logger.isWarnEnabled()) {
/* 359 */         this.logger.warn(new StringBuilder().append("Could not connect to RMI service [").append(getJndiName()).append("] - retrying").toString());
/*     */       }
/* 361 */       return refreshAndRetry(invocation);
/*     */     }
/*     */ 
/* 364 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected Object refreshAndRetry(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     Object freshStub;
/* 378 */     synchronized (this.stubMonitor) {
/* 379 */       this.cachedStub = null;
/* 380 */       freshStub = lookupStub();
/* 381 */       if (this.cacheStub) {
/* 382 */         this.cachedStub = freshStub;
/*     */       }
/*     */     }
/* 385 */     return doInvoke(invocation, freshStub);
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation, Object stub)
/*     */     throws Throwable
/*     */   {
/* 397 */     if ((stub instanceof RmiInvocationHandler)) {
/*     */       try
/*     */       {
/* 400 */         return doInvoke(invocation, (RmiInvocationHandler)stub);
/*     */       }
/*     */       catch (RemoteException ex) {
/* 403 */         throw convertRmiAccessException(ex, invocation.getMethod());
/*     */       }
/*     */       catch (SystemException ex) {
/* 406 */         throw convertCorbaAccessException(ex, invocation.getMethod());
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 409 */         throw ex.getTargetException();
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 413 */         throw new RemoteInvocationFailureException(new StringBuilder().append("Invocation of method [").append(invocation.getMethod()).append("] failed in RMI service [")
/* 413 */           .append(getJndiName()).append("]").toString(), ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 419 */       return RmiClientInterceptorUtils.invokeRemoteMethod(invocation, stub);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 422 */       Throwable targetEx = ex.getTargetException();
/* 423 */       if ((targetEx instanceof RemoteException)) {
/* 424 */         throw convertRmiAccessException((RemoteException)targetEx, invocation.getMethod());
/*     */       }
/* 426 */       if ((targetEx instanceof SystemException)) {
/* 427 */         throw convertCorbaAccessException((SystemException)targetEx, invocation.getMethod());
/*     */       }
/*     */ 
/* 430 */       throw targetEx;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation methodInvocation, RmiInvocationHandler invocationHandler)
/*     */     throws RemoteException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 451 */     if (AopUtils.isToStringMethod(methodInvocation.getMethod())) {
/* 452 */       return new StringBuilder().append("RMI invoker proxy for service URL [").append(getJndiName()).append("]").toString();
/*     */     }
/*     */ 
/* 455 */     return invocationHandler.invoke(createRemoteInvocation(methodInvocation));
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation createRemoteInvocation(MethodInvocation methodInvocation)
/*     */   {
/* 471 */     return getRemoteInvocationFactory().createRemoteInvocation(methodInvocation);
/*     */   }
/*     */ 
/*     */   private Exception convertRmiAccessException(RemoteException ex, Method method)
/*     */   {
/* 483 */     return RmiClientInterceptorUtils.convertRmiAccessException(method, ex, isConnectFailure(ex), getJndiName());
/*     */   }
/*     */ 
/*     */   private Exception convertCorbaAccessException(SystemException ex, Method method)
/*     */   {
/* 495 */     if (ReflectionUtils.declaresException(method, RemoteException.class))
/*     */     {
/* 497 */       return new RemoteException(new StringBuilder().append("Failed to access CORBA service [").append(getJndiName()).append("]").toString(), ex);
/*     */     }
/*     */ 
/* 500 */     if (isConnectFailure(ex)) {
/* 501 */       return new RemoteConnectFailureException(new StringBuilder().append("Could not connect to CORBA service [").append(getJndiName()).append("]").toString(), ex);
/*     */     }
/*     */ 
/* 504 */     return new RemoteAccessException(new StringBuilder().append("Could not access CORBA service [").append(getJndiName()).append("]").toString(), ex);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.JndiRmiClientInterceptor
 * JD-Core Version:    0.6.2
 */