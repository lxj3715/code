/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.rmi.NoSuchObjectException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Properties;
/*     */ import javax.naming.NamingException;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ 
/*     */ public class JndiRmiServiceExporter extends RmiBasedExporter
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*  71 */   private JndiTemplate jndiTemplate = new JndiTemplate();
/*     */   private String jndiName;
/*     */   private Remote exportedObject;
/*     */ 
/*     */   public void setJndiTemplate(JndiTemplate jndiTemplate)
/*     */   {
/*  84 */     this.jndiTemplate = (jndiTemplate != null ? jndiTemplate : new JndiTemplate());
/*     */   }
/*     */ 
/*     */   public void setJndiEnvironment(Properties jndiEnvironment)
/*     */   {
/*  93 */     this.jndiTemplate = new JndiTemplate(jndiEnvironment);
/*     */   }
/*     */ 
/*     */   public void setJndiName(String jndiName)
/*     */   {
/* 100 */     this.jndiName = jndiName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException, RemoteException
/*     */   {
/* 106 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws NamingException, RemoteException
/*     */   {
/* 115 */     if (this.jndiName == null) {
/* 116 */       throw new IllegalArgumentException("Property 'jndiName' is required");
/*     */     }
/*     */ 
/* 120 */     this.exportedObject = getObjectToExport();
/* 121 */     PortableRemoteObject.exportObject(this.exportedObject);
/*     */ 
/* 123 */     rebind();
/*     */   }
/*     */ 
/*     */   public void rebind()
/*     */     throws NamingException
/*     */   {
/* 132 */     if (this.logger.isInfoEnabled()) {
/* 133 */       this.logger.info("Binding RMI service to JNDI location [" + this.jndiName + "]");
/*     */     }
/* 135 */     this.jndiTemplate.rebind(this.jndiName, this.exportedObject);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws NamingException, NoSuchObjectException
/*     */   {
/* 143 */     if (this.logger.isInfoEnabled()) {
/* 144 */       this.logger.info("Unbinding RMI service from JNDI location [" + this.jndiName + "]");
/*     */     }
/* 146 */     this.jndiTemplate.unbind(this.jndiName);
/* 147 */     PortableRemoteObject.unexportObject(this.exportedObject);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.JndiRmiServiceExporter
 * JD-Core Version:    0.6.2
 */