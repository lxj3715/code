/*     */ package org.springframework.remoting.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class RemoteInvocation
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6876024250231820554L;
/*     */   private String methodName;
/*     */   private Class<?>[] parameterTypes;
/*     */   private Object[] arguments;
/*     */   private Map<String, Serializable> attributes;
/*     */ 
/*     */   public RemoteInvocation()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RemoteInvocation(String methodName, Class<?>[] parameterTypes, Object[] arguments)
/*     */   {
/*  74 */     this.methodName = methodName;
/*  75 */     this.parameterTypes = parameterTypes;
/*  76 */     this.arguments = arguments;
/*     */   }
/*     */ 
/*     */   public RemoteInvocation(MethodInvocation methodInvocation)
/*     */   {
/*  84 */     this.methodName = methodInvocation.getMethod().getName();
/*  85 */     this.parameterTypes = methodInvocation.getMethod().getParameterTypes();
/*  86 */     this.arguments = methodInvocation.getArguments();
/*     */   }
/*     */ 
/*     */   public void setMethodName(String methodName)
/*     */   {
/*  94 */     this.methodName = methodName;
/*     */   }
/*     */ 
/*     */   public String getMethodName()
/*     */   {
/* 101 */     return this.methodName;
/*     */   }
/*     */ 
/*     */   public void setParameterTypes(Class<?>[] parameterTypes)
/*     */   {
/* 108 */     this.parameterTypes = parameterTypes;
/*     */   }
/*     */ 
/*     */   public Class<?>[] getParameterTypes()
/*     */   {
/* 115 */     return this.parameterTypes;
/*     */   }
/*     */ 
/*     */   public void setArguments(Object[] arguments)
/*     */   {
/* 122 */     this.arguments = arguments;
/*     */   }
/*     */ 
/*     */   public Object[] getArguments()
/*     */   {
/* 129 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   public void addAttribute(String key, Serializable value)
/*     */     throws IllegalStateException
/*     */   {
/* 145 */     if (this.attributes == null) {
/* 146 */       this.attributes = new HashMap();
/*     */     }
/* 148 */     if (this.attributes.containsKey(key)) {
/* 149 */       throw new IllegalStateException("There is already an attribute with key '" + key + "' bound");
/*     */     }
/* 151 */     this.attributes.put(key, value);
/*     */   }
/*     */ 
/*     */   public Serializable getAttribute(String key)
/*     */   {
/* 162 */     if (this.attributes == null) {
/* 163 */       return null;
/*     */     }
/* 165 */     return (Serializable)this.attributes.get(key);
/*     */   }
/*     */ 
/*     */   public void setAttributes(Map<String, Serializable> attributes)
/*     */   {
/* 176 */     this.attributes = attributes;
/*     */   }
/*     */ 
/*     */   public Map<String, Serializable> getAttributes()
/*     */   {
/* 187 */     return this.attributes;
/*     */   }
/*     */ 
/*     */   public Object invoke(Object targetObject)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 204 */     Method method = targetObject.getClass().getMethod(this.methodName, this.parameterTypes);
/* 205 */     return method.invoke(targetObject, this.arguments);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 212 */     return "RemoteInvocation: method name '" + this.methodName + "'; parameter types " + 
/* 212 */       ClassUtils.classNamesToString(this.parameterTypes);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemoteInvocation
 * JD-Core Version:    0.6.2
 */