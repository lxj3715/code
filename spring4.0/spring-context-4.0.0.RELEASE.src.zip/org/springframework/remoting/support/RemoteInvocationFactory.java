package org.springframework.remoting.support;

import org.aopalliance.intercept.MethodInvocation;

public abstract interface RemoteInvocationFactory
{
  public abstract RemoteInvocation createRemoteInvocation(MethodInvocation paramMethodInvocation);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemoteInvocationFactory
 * JD-Core Version:    0.6.2
 */