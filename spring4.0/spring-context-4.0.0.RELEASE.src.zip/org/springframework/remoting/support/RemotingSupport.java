/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public abstract class RemotingSupport
/*    */   implements BeanClassLoaderAware
/*    */ {
/* 35 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/* 37 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader classLoader)
/*    */   {
/* 42 */     this.beanClassLoader = classLoader;
/*    */   }
/*    */ 
/*    */   protected ClassLoader getBeanClassLoader()
/*    */   {
/* 50 */     return this.beanClassLoader;
/*    */   }
/*    */ 
/*    */   protected ClassLoader overrideThreadContextClassLoader()
/*    */   {
/* 61 */     return ClassUtils.overrideThreadContextClassLoader(getBeanClassLoader());
/*    */   }
/*    */ 
/*    */   protected void resetThreadContextClassLoader(ClassLoader original)
/*    */   {
/* 70 */     if (original != null)
/* 71 */       Thread.currentThread().setContextClassLoader(original);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemotingSupport
 * JD-Core Version:    0.6.2
 */