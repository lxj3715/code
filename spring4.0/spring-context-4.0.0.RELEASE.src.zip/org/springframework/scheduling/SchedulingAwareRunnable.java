package org.springframework.scheduling;

public abstract interface SchedulingAwareRunnable extends Runnable
{
  public abstract boolean isLongLived();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.SchedulingAwareRunnable
 * JD-Core Version:    0.6.2
 */