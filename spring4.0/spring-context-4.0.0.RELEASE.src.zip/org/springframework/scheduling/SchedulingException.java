/*    */ package org.springframework.scheduling;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class SchedulingException extends NestedRuntimeException
/*    */ {
/*    */   public SchedulingException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public SchedulingException(String msg, Throwable cause)
/*    */   {
/* 47 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.SchedulingException
 * JD-Core Version:    0.6.2
 */