package org.springframework.scheduling;

import org.springframework.core.task.AsyncTaskExecutor;

public abstract interface SchedulingTaskExecutor extends AsyncTaskExecutor
{
  public abstract boolean prefersShortLivedTasks();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.SchedulingTaskExecutor
 * JD-Core Version:    0.6.2
 */