package org.springframework.scheduling;

import java.util.Date;

public abstract interface Trigger
{
  public abstract Date nextExecutionTime(TriggerContext paramTriggerContext);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.Trigger
 * JD-Core Version:    0.6.2
 */