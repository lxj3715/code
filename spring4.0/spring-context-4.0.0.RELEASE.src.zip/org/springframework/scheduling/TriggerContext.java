package org.springframework.scheduling;

import java.util.Date;

public abstract interface TriggerContext
{
  public abstract Date lastScheduledExecutionTime();

  public abstract Date lastActualExecutionTime();

  public abstract Date lastCompletionTime();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.TriggerContext
 * JD-Core Version:    0.6.2
 */