/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ImportAware;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ @Configuration
/*    */ public abstract class AbstractAsyncConfiguration
/*    */   implements ImportAware
/*    */ {
/*    */   protected AnnotationAttributes enableAsync;
/*    */   protected Executor executor;
/*    */ 
/*    */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*    */   {
/* 48 */     this.enableAsync = AnnotationAttributes.fromMap(importMetadata
/* 49 */       .getAnnotationAttributes(EnableAsync.class
/* 49 */       .getName(), false));
/* 50 */     Assert.notNull(this.enableAsync, "@EnableAsync is not present on importing class " + importMetadata
/* 51 */       .getClassName());
/*    */   }
/*    */ 
/*    */   @Autowired(required=false)
/*    */   void setConfigurers(Collection<AsyncConfigurer> configurers)
/*    */   {
/* 59 */     if (CollectionUtils.isEmpty(configurers)) {
/* 60 */       return;
/*    */     }
/* 62 */     if (configurers.size() > 1) {
/* 63 */       throw new IllegalStateException("Only one AsyncConfigurer may exist");
/*    */     }
/* 65 */     AsyncConfigurer configurer = (AsyncConfigurer)configurers.iterator().next();
/* 66 */     this.executor = configurer.getAsyncExecutor();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AbstractAsyncConfiguration
 * JD-Core Version:    0.6.2
 */