/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AsyncAnnotationBeanPostProcessor extends AbstractAdvisingBeanPostProcessor
/*    */   implements BeanFactoryAware
/*    */ {
/*    */   private Class<? extends Annotation> asyncAnnotationType;
/*    */   private Executor executor;
/*    */ 
/*    */   public AsyncAnnotationBeanPostProcessor()
/*    */   {
/* 61 */     setBeforeExistingAdvisors(true);
/*    */   }
/*    */ 
/*    */   public void setAsyncAnnotationType(Class<? extends Annotation> asyncAnnotationType)
/*    */   {
/* 74 */     Assert.notNull(asyncAnnotationType, "'asyncAnnotationType' must not be null");
/* 75 */     this.asyncAnnotationType = asyncAnnotationType;
/*    */   }
/*    */ 
/*    */   public void setExecutor(Executor executor)
/*    */   {
/* 82 */     this.executor = executor;
/*    */   }
/*    */ 
/*    */   public void setBeanFactory(BeanFactory beanFactory)
/*    */   {
/* 87 */     AsyncAnnotationAdvisor advisor = this.executor != null ? new AsyncAnnotationAdvisor(this.executor) : new AsyncAnnotationAdvisor();
/*    */ 
/* 89 */     if (this.asyncAnnotationType != null) {
/* 90 */       advisor.setAsyncAnnotationType(this.asyncAnnotationType);
/*    */     }
/* 92 */     advisor.setBeanFactory(beanFactory);
/* 93 */     this.advisor = advisor;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.2
 */