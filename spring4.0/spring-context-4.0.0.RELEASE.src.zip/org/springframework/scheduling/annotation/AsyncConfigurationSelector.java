/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ 
/*    */ public class AsyncConfigurationSelector extends AdviceModeImportSelector<EnableAsync>
/*    */ {
/*    */   public String[] selectImports(AdviceMode adviceMode)
/*    */   {
/* 42 */     switch (1.$SwitchMap$org$springframework$context$annotation$AdviceMode[adviceMode.ordinal()]) {
/*    */     case 1:
/* 44 */       return new String[] { ProxyAsyncConfiguration.class.getName() };
/*    */     case 2:
/* 46 */       return new String[] { "org.springframework.scheduling.aspectj.AspectJAsyncConfiguration" };
/*    */     }
/* 48 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncConfigurationSelector
 * JD-Core Version:    0.6.2
 */