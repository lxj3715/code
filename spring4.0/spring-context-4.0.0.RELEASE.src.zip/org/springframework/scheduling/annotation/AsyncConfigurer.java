package org.springframework.scheduling.annotation;

import java.util.concurrent.Executor;

public abstract interface AsyncConfigurer
{
  public abstract Executor getAsyncExecutor();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncConfigurer
 * JD-Core Version:    0.6.2
 */