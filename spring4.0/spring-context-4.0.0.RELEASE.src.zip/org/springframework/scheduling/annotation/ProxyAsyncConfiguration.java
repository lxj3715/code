/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ @Configuration
/*    */ public class ProxyAsyncConfiguration extends AbstractAsyncConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.context.annotation.internalAsyncAnnotationProcessor"})
/*    */   @Role(2)
/*    */   public AsyncAnnotationBeanPostProcessor asyncAdvisor()
/*    */   {
/* 44 */     Assert.notNull(this.enableAsync, "@EnableAsync annotation metadata was not injected");
/*    */ 
/* 46 */     AsyncAnnotationBeanPostProcessor bpp = new AsyncAnnotationBeanPostProcessor();
/*    */ 
/* 48 */     Class customAsyncAnnotation = this.enableAsync.getClass("annotation");
/* 49 */     if (customAsyncAnnotation != AnnotationUtils.getDefaultValue(EnableAsync.class, "annotation")) {
/* 50 */       bpp.setAsyncAnnotationType(customAsyncAnnotation);
/*    */     }
/*    */ 
/* 53 */     if (this.executor != null) {
/* 54 */       bpp.setExecutor(this.executor);
/*    */     }
/*    */ 
/* 57 */     bpp.setProxyTargetClass(this.enableAsync.getBoolean("proxyTargetClass"));
/* 58 */     bpp.setOrder(((Integer)this.enableAsync.getNumber("order")).intValue());
/*    */ 
/* 60 */     return bpp;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.ProxyAsyncConfiguration
 * JD-Core Version:    0.6.2
 */