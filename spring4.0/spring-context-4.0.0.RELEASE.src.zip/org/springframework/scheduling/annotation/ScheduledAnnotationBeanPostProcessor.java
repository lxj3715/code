/*     */ package org.springframework.scheduling.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.event.ContextRefreshedEvent;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.config.CronTask;
/*     */ import org.springframework.scheduling.config.IntervalTask;
/*     */ import org.springframework.scheduling.config.ScheduledTaskRegistrar;
/*     */ import org.springframework.scheduling.support.CronTrigger;
/*     */ import org.springframework.scheduling.support.ScheduledMethodRunnable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class ScheduledAnnotationBeanPostProcessor
/*     */   implements BeanPostProcessor, Ordered, EmbeddedValueResolverAware, ApplicationContextAware, ApplicationListener<ContextRefreshedEvent>, DisposableBean
/*     */ {
/*     */   private Object scheduler;
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   private ApplicationContext applicationContext;
/*  82 */   private final ScheduledTaskRegistrar registrar = new ScheduledTaskRegistrar();
/*     */ 
/*     */   public void setScheduler(Object scheduler)
/*     */   {
/*  91 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/*  96 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 101 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 106 */     return 2147483647;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */   {
/* 111 */     return bean;
/*     */   }
/*     */ 
/*     */   public Object postProcessAfterInitialization(final Object bean, String beanName)
/*     */   {
/* 116 */     Class targetClass = AopUtils.getTargetClass(bean);
/* 117 */     ReflectionUtils.doWithMethods(targetClass, new ReflectionUtils.MethodCallback()
/*     */     {
/*     */       public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException {
/* 120 */         for (Scheduled scheduled : AnnotationUtils.getRepeatableAnnotation(method, Schedules.class, Scheduled.class))
/* 121 */           ScheduledAnnotationBeanPostProcessor.this.processScheduled(scheduled, method, bean);
/*     */       }
/*     */     });
/* 125 */     return bean;
/*     */   }
/*     */ 
/*     */   protected void processScheduled(Scheduled scheduled, Method method, Object bean) {
/*     */     try {
/* 130 */       Assert.isTrue(Void.TYPE.equals(method.getReturnType()), "Only void-returning methods may be annotated with @Scheduled");
/*     */ 
/* 132 */       Assert.isTrue(method.getParameterTypes().length == 0, "Only no-arg methods may be annotated with @Scheduled");
/*     */ 
/* 135 */       if (AopUtils.isJdkDynamicProxy(bean))
/*     */       {
/*     */         try
/*     */         {
/* 139 */           method = bean.getClass().getMethod(method.getName(), method.getParameterTypes());
/*     */         }
/*     */         catch (SecurityException ex) {
/* 142 */           ReflectionUtils.handleReflectionException(ex);
/*     */         }
/*     */         catch (NoSuchMethodException ex) {
/* 145 */           throw new IllegalStateException(String.format("@Scheduled method '%s' found on bean target class '%s', but not found in any interface(s) for bean JDK proxy. Either pull the method up to an interface or switch to subclass (CGLIB) proxies by setting proxy-target-class/proxyTargetClass attribute to 'true'", new Object[] { method
/* 150 */             .getName(), method.getDeclaringClass().getSimpleName() }));
/*     */         }
/*     */       }
/*     */ 
/* 154 */       Runnable runnable = new ScheduledMethodRunnable(bean, method);
/* 155 */       boolean processedSchedule = false;
/* 156 */       String errorMessage = "Exactly one of the 'cron', 'fixedDelay(String)', or 'fixedRate(String)' attributes is required";
/*     */ 
/* 159 */       long initialDelay = scheduled.initialDelay();
/* 160 */       String initialDelayString = scheduled.initialDelayString();
/* 161 */       if (!"".equals(initialDelayString)) {
/* 162 */         Assert.isTrue(initialDelay < 0L, "Specify 'initialDelay' or 'initialDelayString', not both");
/* 163 */         if (this.embeddedValueResolver != null)
/* 164 */           initialDelayString = this.embeddedValueResolver.resolveStringValue(initialDelayString);
/*     */         try
/*     */         {
/* 167 */           initialDelay = Integer.parseInt(initialDelayString);
/*     */         }
/*     */         catch (NumberFormatException ex) {
/* 170 */           throw new IllegalArgumentException("Invalid initialDelayString value \"" + initialDelayString + "\" - cannot parse into integer");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 176 */       String cron = scheduled.cron();
/* 177 */       if (!"".equals(cron)) {
/* 178 */         Assert.isTrue(initialDelay == -1L, "'initialDelay' not supported for cron triggers");
/* 179 */         processedSchedule = true;
/* 180 */         String zone = scheduled.zone();
/* 181 */         if (this.embeddedValueResolver != null) {
/* 182 */           cron = this.embeddedValueResolver.resolveStringValue(cron);
/* 183 */           zone = this.embeddedValueResolver.resolveStringValue(zone);
/*     */         }
/*     */         TimeZone timeZone;
/*     */         TimeZone timeZone;
/* 186 */         if (!"".equals(zone)) {
/* 187 */           timeZone = StringUtils.parseTimeZoneString(zone);
/*     */         }
/*     */         else {
/* 190 */           timeZone = TimeZone.getDefault();
/*     */         }
/* 192 */         this.registrar.addCronTask(new CronTask(runnable, new CronTrigger(cron, timeZone)));
/*     */       }
/*     */ 
/* 196 */       if (initialDelay < 0L) {
/* 197 */         initialDelay = 0L;
/*     */       }
/*     */ 
/* 201 */       long fixedDelay = scheduled.fixedDelay();
/* 202 */       if (fixedDelay >= 0L) {
/* 203 */         Assert.isTrue(!processedSchedule, errorMessage);
/* 204 */         processedSchedule = true;
/* 205 */         this.registrar.addFixedDelayTask(new IntervalTask(runnable, fixedDelay, initialDelay));
/*     */       }
/* 207 */       String fixedDelayString = scheduled.fixedDelayString();
/* 208 */       if (!"".equals(fixedDelayString)) {
/* 209 */         Assert.isTrue(!processedSchedule, errorMessage);
/* 210 */         processedSchedule = true;
/* 211 */         if (this.embeddedValueResolver != null)
/* 212 */           fixedDelayString = this.embeddedValueResolver.resolveStringValue(fixedDelayString);
/*     */         try
/*     */         {
/* 215 */           fixedDelay = Integer.parseInt(fixedDelayString);
/*     */         }
/*     */         catch (NumberFormatException ex) {
/* 218 */           throw new IllegalArgumentException("Invalid fixedDelayString value \"" + fixedDelayString + "\" - cannot parse into integer");
/*     */         }
/*     */ 
/* 221 */         this.registrar.addFixedDelayTask(new IntervalTask(runnable, fixedDelay, initialDelay));
/*     */       }
/*     */ 
/* 225 */       long fixedRate = scheduled.fixedRate();
/* 226 */       if (fixedRate >= 0L) {
/* 227 */         Assert.isTrue(!processedSchedule, errorMessage);
/* 228 */         processedSchedule = true;
/* 229 */         this.registrar.addFixedRateTask(new IntervalTask(runnable, fixedRate, initialDelay));
/*     */       }
/* 231 */       String fixedRateString = scheduled.fixedRateString();
/* 232 */       if (!"".equals(fixedRateString)) {
/* 233 */         Assert.isTrue(!processedSchedule, errorMessage);
/* 234 */         processedSchedule = true;
/* 235 */         if (this.embeddedValueResolver != null)
/* 236 */           fixedRateString = this.embeddedValueResolver.resolveStringValue(fixedRateString);
/*     */         try
/*     */         {
/* 239 */           fixedRate = Integer.parseInt(fixedRateString);
/*     */         }
/*     */         catch (NumberFormatException ex) {
/* 242 */           throw new IllegalArgumentException("Invalid fixedRateString value \"" + fixedRateString + "\" - cannot parse into integer");
/*     */         }
/*     */ 
/* 245 */         this.registrar.addFixedRateTask(new IntervalTask(runnable, fixedRate, initialDelay));
/*     */       }
/*     */ 
/* 249 */       Assert.isTrue(processedSchedule, errorMessage);
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 253 */       throw new IllegalStateException("Encountered invalid @Scheduled method '" + method
/* 253 */         .getName() + "': " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onApplicationEvent(ContextRefreshedEvent event)
/*     */   {
/* 259 */     if (event.getApplicationContext() != this.applicationContext) {
/* 260 */       return;
/*     */     }
/*     */ 
/* 263 */     if (this.scheduler != null) {
/* 264 */       this.registrar.setScheduler(this.scheduler);
/*     */     }
/*     */ 
/* 268 */     Map configurers = this.applicationContext
/* 268 */       .getBeansOfType(SchedulingConfigurer.class);
/*     */ 
/* 269 */     for (SchedulingConfigurer configurer : configurers.values()) {
/* 270 */       configurer.configureTasks(this.registrar);
/*     */     }
/*     */ 
/* 273 */     if ((this.registrar.hasTasks()) && (this.registrar.getScheduler() == null)) {
/* 274 */       Object schedulers = new HashMap();
/* 275 */       ((Map)schedulers).putAll(this.applicationContext.getBeansOfType(TaskScheduler.class));
/* 276 */       ((Map)schedulers).putAll(this.applicationContext.getBeansOfType(ScheduledExecutorService.class));
/* 277 */       if (((Map)schedulers).size() != 0)
/*     */       {
/* 280 */         if (((Map)schedulers).size() == 1) {
/* 281 */           this.registrar.setScheduler(((Map)schedulers).values().iterator().next());
/*     */         }
/* 283 */         else if (((Map)schedulers).size() >= 2)
/*     */         {
/* 289 */           throw new IllegalStateException("More than one TaskScheduler and/or ScheduledExecutorService  exist within the context. Remove all but one of the beans; or implement the SchedulingConfigurer interface and call ScheduledTaskRegistrar#setScheduler explicitly within the configureTasks() callback. Found the following beans: " + ((Map)schedulers)
/* 289 */             .keySet());
/*     */         }
/*     */       }
/*     */     }
/* 293 */     this.registrar.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 298 */     this.registrar.destroy();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.ScheduledAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.2
 */