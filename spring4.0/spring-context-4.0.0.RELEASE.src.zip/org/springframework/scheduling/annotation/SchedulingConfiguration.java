/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ 
/*    */ @Configuration
/*    */ public class SchedulingConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.context.annotation.internalScheduledAnnotationProcessor"})
/*    */   @Role(2)
/*    */   public ScheduledAnnotationBeanPostProcessor scheduledAnnotationProcessor()
/*    */   {
/* 45 */     return new ScheduledAnnotationBeanPostProcessor();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.SchedulingConfiguration
 * JD-Core Version:    0.6.2
 */