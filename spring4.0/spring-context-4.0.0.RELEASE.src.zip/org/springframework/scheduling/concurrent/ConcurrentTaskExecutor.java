/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import javax.enterprise.concurrent.ManagedExecutors;
/*     */ import org.springframework.core.task.support.TaskExecutorAdapter;
/*     */ import org.springframework.scheduling.SchedulingAwareRunnable;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class ConcurrentTaskExecutor
/*     */   implements SchedulingTaskExecutor
/*     */ {
/*     */   private static Class<?> managedExecutorServiceClass;
/*     */   private Executor concurrentExecutor;
/*     */   private TaskExecutorAdapter adaptedExecutor;
/*     */ 
/*     */   public ConcurrentTaskExecutor()
/*     */   {
/*  86 */     setConcurrentExecutor(null);
/*     */   }
/*     */ 
/*     */   public ConcurrentTaskExecutor(Executor concurrentExecutor)
/*     */   {
/*  96 */     setConcurrentExecutor(concurrentExecutor);
/*     */   }
/*     */ 
/*     */   public final void setConcurrentExecutor(Executor concurrentExecutor)
/*     */   {
/* 106 */     if (concurrentExecutor != null) {
/* 107 */       this.concurrentExecutor = concurrentExecutor;
/* 108 */       if ((managedExecutorServiceClass != null) && (managedExecutorServiceClass.isInstance(concurrentExecutor))) {
/* 109 */         this.adaptedExecutor = new ManagedTaskExecutorAdapter(concurrentExecutor);
/*     */       }
/*     */       else
/* 112 */         this.adaptedExecutor = new TaskExecutorAdapter(concurrentExecutor);
/*     */     }
/*     */     else
/*     */     {
/* 116 */       this.concurrentExecutor = Executors.newSingleThreadExecutor();
/* 117 */       this.adaptedExecutor = new TaskExecutorAdapter(this.concurrentExecutor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final Executor getConcurrentExecutor()
/*     */   {
/* 125 */     return this.concurrentExecutor;
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 131 */     this.adaptedExecutor.execute(task);
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout)
/*     */   {
/* 136 */     this.adaptedExecutor.execute(task, startTimeout);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task)
/*     */   {
/* 141 */     return this.adaptedExecutor.submit(task);
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task)
/*     */   {
/* 146 */     return this.adaptedExecutor.submit(task);
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 154 */     return true;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  66 */       managedExecutorServiceClass = ClassUtils.forName("javax.enterprise.concurrent.ManagedExecutorService", ConcurrentTaskScheduler.class
/*  68 */         .getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*  72 */       managedExecutorServiceClass = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class ManagedTaskBuilder
/*     */   {
/*     */     public static Runnable buildManagedTask(Runnable task, String identityName)
/*     */     {
/* 195 */       Map properties = new HashMap(2);
/* 196 */       if ((task instanceof SchedulingAwareRunnable)) {
/* 197 */         properties.put("javax.enterprise.concurrent.LONGRUNNING_HINT", 
/* 198 */           Boolean.toString(((SchedulingAwareRunnable)task)
/* 198 */           .isLongLived()));
/*     */       }
/* 200 */       properties.put("javax.enterprise.concurrent.IDENTITY_NAME", identityName);
/* 201 */       return ManagedExecutors.managedTask(task, properties, null);
/*     */     }
/*     */ 
/*     */     public static <T> Callable<T> buildManagedTask(Callable<T> task, String identityName) {
/* 205 */       Map properties = new HashMap(1);
/* 206 */       properties.put("javax.enterprise.concurrent.IDENTITY_NAME", identityName);
/* 207 */       return ManagedExecutors.managedTask(task, properties, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ManagedTaskExecutorAdapter extends TaskExecutorAdapter
/*     */   {
/*     */     public ManagedTaskExecutorAdapter(Executor concurrentExecutor)
/*     */     {
/* 167 */       super();
/*     */     }
/*     */ 
/*     */     public void execute(Runnable task)
/*     */     {
/* 172 */       super.execute(ConcurrentTaskExecutor.ManagedTaskBuilder.buildManagedTask(task, task.toString()));
/*     */     }
/*     */ 
/*     */     public Future<?> submit(Runnable task)
/*     */     {
/* 177 */       return super.submit(ConcurrentTaskExecutor.ManagedTaskBuilder.buildManagedTask(task, task.toString()));
/*     */     }
/*     */ 
/*     */     public <T> Future<T> submit(Callable<T> task)
/*     */     {
/* 182 */       return super.submit(ConcurrentTaskExecutor.ManagedTaskBuilder.buildManagedTask(task, task.toString()));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ConcurrentTaskExecutor
 * JD-Core Version:    0.6.2
 */