/*    */ package org.springframework.scheduling.concurrent;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import org.springframework.util.CustomizableThreadCreator;
/*    */ 
/*    */ public class CustomizableThreadFactory extends CustomizableThreadCreator
/*    */   implements ThreadFactory
/*    */ {
/*    */   public CustomizableThreadFactory()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CustomizableThreadFactory(String threadNamePrefix)
/*    */   {
/* 50 */     super(threadNamePrefix);
/*    */   }
/*    */ 
/*    */   public Thread newThread(Runnable runnable)
/*    */   {
/* 56 */     return createThread(runnable);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.CustomizableThreadFactory
 * JD-Core Version:    0.6.2
 */