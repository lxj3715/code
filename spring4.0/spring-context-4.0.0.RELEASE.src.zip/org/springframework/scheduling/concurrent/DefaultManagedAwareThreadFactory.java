/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jndi.JndiLocatorDelegate;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ 
/*     */ public class DefaultManagedAwareThreadFactory extends CustomizableThreadFactory
/*     */   implements InitializingBean
/*     */ {
/*  47 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  49 */   private JndiLocatorDelegate jndiLocator = new JndiLocatorDelegate();
/*     */ 
/*  51 */   private String jndiName = "java:comp/DefaultManagedThreadFactory";
/*     */ 
/*  53 */   private ThreadFactory threadFactory = this;
/*     */ 
/*     */   public void setJndiTemplate(JndiTemplate jndiTemplate)
/*     */   {
/*  61 */     this.jndiLocator.setJndiTemplate(jndiTemplate);
/*     */   }
/*     */ 
/*     */   public void setJndiEnvironment(Properties jndiEnvironment)
/*     */   {
/*  69 */     this.jndiLocator.setJndiEnvironment(jndiEnvironment);
/*     */   }
/*     */ 
/*     */   public void setResourceRef(boolean resourceRef)
/*     */   {
/*  79 */     this.jndiLocator.setResourceRef(resourceRef);
/*     */   }
/*     */ 
/*     */   public void setJndiName(String jndiName)
/*     */   {
/*  90 */     this.jndiName = jndiName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws NamingException
/*     */   {
/*  95 */     if (this.jndiName != null)
/*     */       try {
/*  97 */         this.threadFactory = ((ThreadFactory)this.jndiLocator.lookup(this.jndiName, ThreadFactory.class));
/*     */       }
/*     */       catch (NamingException ex) {
/* 100 */         if (this.logger.isDebugEnabled()) {
/* 101 */           this.logger.debug("Failed to find [java:comp/DefaultManagedThreadFactory] in JNDI", ex);
/*     */         }
/* 103 */         if (this.logger.isInfoEnabled())
/* 104 */           this.logger.info("Could not find default managed thread factory in JNDI - proceeding with default local thread factory");
/*     */       }
/*     */   }
/*     */ 
/*     */   public Thread newThread(Runnable runnable)
/*     */   {
/* 114 */     return this.threadFactory.newThread(runnable);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.DefaultManagedAwareThreadFactory
 * JD-Core Version:    0.6.2
 */