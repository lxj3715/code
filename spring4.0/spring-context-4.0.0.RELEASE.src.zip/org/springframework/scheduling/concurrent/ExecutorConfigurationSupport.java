/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public abstract class ExecutorConfigurationSupport extends CustomizableThreadFactory
/*     */   implements BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*  48 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  50 */   private ThreadFactory threadFactory = this;
/*     */ 
/*  52 */   private boolean threadNamePrefixSet = false;
/*     */ 
/*  54 */   private RejectedExecutionHandler rejectedExecutionHandler = new ThreadPoolExecutor.AbortPolicy();
/*     */ 
/*  56 */   private boolean waitForTasksToCompleteOnShutdown = false;
/*     */ 
/*  58 */   private int awaitTerminationSeconds = 0;
/*     */   private String beanName;
/*     */   private ExecutorService executor;
/*     */ 
/*     */   public void setThreadFactory(ThreadFactory threadFactory)
/*     */   {
/*  80 */     this.threadFactory = (threadFactory != null ? threadFactory : this);
/*     */   }
/*     */ 
/*     */   public void setThreadNamePrefix(String threadNamePrefix)
/*     */   {
/*  85 */     super.setThreadNamePrefix(threadNamePrefix);
/*  86 */     this.threadNamePrefixSet = true;
/*     */   }
/*     */ 
/*     */   public void setRejectedExecutionHandler(RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/*  95 */     this.rejectedExecutionHandler = (rejectedExecutionHandler != null ? rejectedExecutionHandler : new ThreadPoolExecutor.AbortPolicy());
/*     */   }
/*     */ 
/*     */   public void setWaitForTasksToCompleteOnShutdown(boolean waitForJobsToCompleteOnShutdown)
/*     */   {
/* 115 */     this.waitForTasksToCompleteOnShutdown = waitForJobsToCompleteOnShutdown;
/*     */   }
/*     */ 
/*     */   public void setAwaitTerminationSeconds(int awaitTerminationSeconds)
/*     */   {
/* 142 */     this.awaitTerminationSeconds = awaitTerminationSeconds;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String name)
/*     */   {
/* 147 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 157 */     initialize();
/*     */   }
/*     */ 
/*     */   public void initialize()
/*     */   {
/* 164 */     if (this.logger.isInfoEnabled()) {
/* 165 */       this.logger.info(new StringBuilder().append("Initializing ExecutorService ").append(this.beanName != null ? new StringBuilder().append(" '").append(this.beanName).append("'").toString() : "").toString());
/*     */     }
/* 167 */     if ((!this.threadNamePrefixSet) && (this.beanName != null)) {
/* 168 */       setThreadNamePrefix(new StringBuilder().append(this.beanName).append("-").toString());
/*     */     }
/* 170 */     this.executor = initializeExecutor(this.threadFactory, this.rejectedExecutionHandler);
/*     */   }
/*     */ 
/*     */   protected abstract ExecutorService initializeExecutor(ThreadFactory paramThreadFactory, RejectedExecutionHandler paramRejectedExecutionHandler);
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 192 */     shutdown();
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 202 */     if (this.logger.isInfoEnabled()) {
/* 203 */       this.logger.info(new StringBuilder().append("Shutting down ExecutorService").append(this.beanName != null ? new StringBuilder().append(" '").append(this.beanName).append("'").toString() : "").toString());
/*     */     }
/* 205 */     if (this.waitForTasksToCompleteOnShutdown) {
/* 206 */       this.executor.shutdown();
/*     */     }
/*     */     else {
/* 209 */       this.executor.shutdownNow();
/*     */     }
/* 211 */     awaitTerminationIfNecessary();
/*     */   }
/*     */ 
/*     */   private void awaitTerminationIfNecessary()
/*     */   {
/* 219 */     if (this.awaitTerminationSeconds > 0)
/*     */       try {
/* 221 */         if ((!this.executor.awaitTermination(this.awaitTerminationSeconds, TimeUnit.SECONDS)) && 
/* 222 */           (this.logger.isWarnEnabled())) {
/* 223 */           this.logger.warn(new StringBuilder().append("Timed out while waiting for executor").append(this.beanName != null ? new StringBuilder().append(" '").append(this.beanName).append("'").toString() : "").append(" to terminate").toString());
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (InterruptedException ex)
/*     */       {
/* 229 */         if (this.logger.isWarnEnabled()) {
/* 230 */           this.logger.warn(new StringBuilder().append("Interrupted while waiting for executor").append(this.beanName != null ? new StringBuilder().append(" '").append(this.beanName).append("'").toString() : "").append(" to terminate").toString());
/*     */         }
/*     */ 
/* 233 */         Thread.currentThread().interrupt();
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ExecutorConfigurationSupport
 * JD-Core Version:    0.6.2
 */