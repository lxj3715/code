/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.ForkJoinPool;
/*     */ import java.util.concurrent.ForkJoinPool.ForkJoinWorkerThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class ForkJoinPoolFactoryBean
/*     */   implements FactoryBean<ForkJoinPool>, InitializingBean, DisposableBean
/*     */ {
/*  42 */   private boolean commonPool = false;
/*     */ 
/*  44 */   private int parallelism = Runtime.getRuntime().availableProcessors();
/*     */ 
/*  46 */   private ForkJoinPool.ForkJoinWorkerThreadFactory threadFactory = ForkJoinPool.defaultForkJoinWorkerThreadFactory;
/*     */   private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;
/*  50 */   private boolean asyncMode = false;
/*     */ 
/*  52 */   private int awaitTerminationSeconds = 0;
/*     */   private ForkJoinPool forkJoinPool;
/*     */ 
/*     */   public void setCommonPool(boolean commonPool)
/*     */   {
/*  71 */     this.commonPool = commonPool;
/*     */   }
/*     */ 
/*     */   public void setParallelism(int parallelism)
/*     */   {
/*  78 */     this.parallelism = parallelism;
/*     */   }
/*     */ 
/*     */   public void setThreadFactory(ForkJoinPool.ForkJoinWorkerThreadFactory threadFactory)
/*     */   {
/*  86 */     this.threadFactory = threadFactory;
/*     */   }
/*     */ 
/*     */   public void setUncaughtExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler)
/*     */   {
/*  94 */     this.uncaughtExceptionHandler = uncaughtExceptionHandler;
/*     */   }
/*     */ 
/*     */   public void setAsyncMode(boolean asyncMode)
/*     */   {
/* 104 */     this.asyncMode = asyncMode;
/*     */   }
/*     */ 
/*     */   public void setAwaitTerminationSeconds(int awaitTerminationSeconds)
/*     */   {
/* 125 */     this.awaitTerminationSeconds = awaitTerminationSeconds;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 130 */     this.forkJoinPool = (this.commonPool ? ForkJoinPool.commonPool() : new ForkJoinPool(this.parallelism, this.threadFactory, this.uncaughtExceptionHandler, this.asyncMode));
/*     */   }
/*     */ 
/*     */   public ForkJoinPool getObject()
/*     */   {
/* 137 */     return this.forkJoinPool;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 142 */     return ForkJoinPool.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 147 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 154 */     this.forkJoinPool.shutdown();
/*     */ 
/* 157 */     if (this.awaitTerminationSeconds > 0)
/*     */       try {
/* 159 */         this.forkJoinPool.awaitTermination(this.awaitTerminationSeconds, TimeUnit.SECONDS);
/*     */       }
/*     */       catch (InterruptedException ex) {
/* 162 */         Thread.currentThread().interrupt();
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ForkJoinPoolFactoryBean
 * JD-Core Version:    0.6.2
 */