/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.scheduling.support.DelegatingErrorHandlingRunnable;
/*     */ import org.springframework.scheduling.support.TaskUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class ScheduledExecutorFactoryBean extends ExecutorConfigurationSupport
/*     */   implements FactoryBean<ScheduledExecutorService>
/*     */ {
/*  68 */   private int poolSize = 1;
/*     */   private ScheduledExecutorTask[] scheduledExecutorTasks;
/*  72 */   private boolean continueScheduledExecutionAfterException = false;
/*     */ 
/*  74 */   private boolean exposeUnconfigurableExecutor = false;
/*     */   private ScheduledExecutorService exposedExecutor;
/*     */ 
/*     */   public void setPoolSize(int poolSize)
/*     */   {
/*  84 */     Assert.isTrue(poolSize > 0, "'poolSize' must be 1 or higher");
/*  85 */     this.poolSize = poolSize;
/*     */   }
/*     */ 
/*     */   public void setScheduledExecutorTasks(ScheduledExecutorTask[] scheduledExecutorTasks)
/*     */   {
/*  97 */     this.scheduledExecutorTasks = scheduledExecutorTasks;
/*     */   }
/*     */ 
/*     */   public void setContinueScheduledExecutionAfterException(boolean continueScheduledExecutionAfterException)
/*     */   {
/* 110 */     this.continueScheduledExecutionAfterException = continueScheduledExecutionAfterException;
/*     */   }
/*     */ 
/*     */   public void setExposeUnconfigurableExecutor(boolean exposeUnconfigurableExecutor)
/*     */   {
/* 122 */     this.exposeUnconfigurableExecutor = exposeUnconfigurableExecutor;
/*     */   }
/*     */ 
/*     */   protected ExecutorService initializeExecutor(ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 131 */     ScheduledExecutorService executor = createExecutor(this.poolSize, threadFactory, rejectedExecutionHandler);
/*     */ 
/* 134 */     if (!ObjectUtils.isEmpty(this.scheduledExecutorTasks)) {
/* 135 */       registerTasks(this.scheduledExecutorTasks, executor);
/*     */     }
/*     */ 
/* 139 */     this.exposedExecutor = (this.exposeUnconfigurableExecutor ? 
/* 140 */       Executors.unconfigurableScheduledExecutorService(executor) : 
/* 140 */       executor);
/*     */ 
/* 142 */     return executor;
/*     */   }
/*     */ 
/*     */   protected ScheduledExecutorService createExecutor(int poolSize, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 159 */     return new ScheduledThreadPoolExecutor(poolSize, threadFactory, rejectedExecutionHandler);
/*     */   }
/*     */ 
/*     */   protected void registerTasks(ScheduledExecutorTask[] tasks, ScheduledExecutorService executor)
/*     */   {
/* 169 */     for (ScheduledExecutorTask task : tasks) {
/* 170 */       Runnable runnable = getRunnableToSchedule(task);
/* 171 */       if (task.isOneTimeTask()) {
/* 172 */         executor.schedule(runnable, task.getDelay(), task.getTimeUnit());
/*     */       }
/* 175 */       else if (task.isFixedRate()) {
/* 176 */         executor.scheduleAtFixedRate(runnable, task.getDelay(), task.getPeriod(), task.getTimeUnit());
/*     */       }
/*     */       else
/* 179 */         executor.scheduleWithFixedDelay(runnable, task.getDelay(), task.getPeriod(), task.getTimeUnit());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Runnable getRunnableToSchedule(ScheduledExecutorTask task)
/*     */   {
/* 199 */     return this.continueScheduledExecutionAfterException ? new DelegatingErrorHandlingRunnable(task
/* 198 */       .getRunnable(), TaskUtils.LOG_AND_SUPPRESS_ERROR_HANDLER) : new DelegatingErrorHandlingRunnable(task
/* 199 */       .getRunnable(), TaskUtils.LOG_AND_PROPAGATE_ERROR_HANDLER);
/*     */   }
/*     */ 
/*     */   public ScheduledExecutorService getObject()
/*     */   {
/* 205 */     return this.exposedExecutor;
/*     */   }
/*     */ 
/*     */   public Class<? extends ScheduledExecutorService> getObjectType()
/*     */   {
/* 210 */     return this.exposedExecutor != null ? this.exposedExecutor.getClass() : ScheduledExecutorService.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 215 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ScheduledExecutorFactoryBean
 * JD-Core Version:    0.6.2
 */