/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ThreadPoolTaskExecutor extends ExecutorConfigurationSupport
/*     */   implements SchedulingTaskExecutor
/*     */ {
/*  69 */   private final Object poolSizeMonitor = new Object();
/*     */ 
/*  71 */   private int corePoolSize = 1;
/*     */ 
/*  73 */   private int maxPoolSize = 2147483647;
/*     */ 
/*  75 */   private int keepAliveSeconds = 60;
/*     */ 
/*  77 */   private boolean allowCoreThreadTimeOut = false;
/*     */ 
/*  79 */   private int queueCapacity = 2147483647;
/*     */   private ThreadPoolExecutor threadPoolExecutor;
/*     */ 
/*     */   public void setCorePoolSize(int corePoolSize)
/*     */   {
/*  90 */     synchronized (this.poolSizeMonitor) {
/*  91 */       this.corePoolSize = corePoolSize;
/*  92 */       if (this.threadPoolExecutor != null)
/*  93 */         this.threadPoolExecutor.setCorePoolSize(corePoolSize);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getCorePoolSize()
/*     */   {
/* 102 */     synchronized (this.poolSizeMonitor) {
/* 103 */       return this.corePoolSize;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMaxPoolSize(int maxPoolSize)
/*     */   {
/* 113 */     synchronized (this.poolSizeMonitor) {
/* 114 */       this.maxPoolSize = maxPoolSize;
/* 115 */       if (this.threadPoolExecutor != null)
/* 116 */         this.threadPoolExecutor.setMaximumPoolSize(maxPoolSize);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMaxPoolSize()
/*     */   {
/* 125 */     synchronized (this.poolSizeMonitor) {
/* 126 */       return this.maxPoolSize;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setKeepAliveSeconds(int keepAliveSeconds)
/*     */   {
/* 136 */     synchronized (this.poolSizeMonitor) {
/* 137 */       this.keepAliveSeconds = keepAliveSeconds;
/* 138 */       if (this.threadPoolExecutor != null)
/* 139 */         this.threadPoolExecutor.setKeepAliveTime(keepAliveSeconds, TimeUnit.SECONDS);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getKeepAliveSeconds()
/*     */   {
/* 148 */     synchronized (this.poolSizeMonitor) {
/* 149 */       return this.keepAliveSeconds;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAllowCoreThreadTimeOut(boolean allowCoreThreadTimeOut)
/*     */   {
/* 161 */     this.allowCoreThreadTimeOut = allowCoreThreadTimeOut;
/*     */   }
/*     */ 
/*     */   public void setQueueCapacity(int queueCapacity)
/*     */   {
/* 173 */     this.queueCapacity = queueCapacity;
/*     */   }
/*     */ 
/*     */   protected ExecutorService initializeExecutor(ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 181 */     BlockingQueue queue = createQueue(this.queueCapacity);
/* 182 */     ThreadPoolExecutor executor = new ThreadPoolExecutor(this.corePoolSize, this.maxPoolSize, this.keepAliveSeconds, TimeUnit.SECONDS, queue, threadFactory, rejectedExecutionHandler);
/*     */ 
/* 185 */     if (this.allowCoreThreadTimeOut) {
/* 186 */       executor.allowCoreThreadTimeOut(true);
/*     */     }
/*     */ 
/* 189 */     this.threadPoolExecutor = executor;
/* 190 */     return executor;
/*     */   }
/*     */ 
/*     */   protected BlockingQueue<Runnable> createQueue(int queueCapacity)
/*     */   {
/* 203 */     if (queueCapacity > 0) {
/* 204 */       return new LinkedBlockingQueue(queueCapacity);
/*     */     }
/*     */ 
/* 207 */     return new SynchronousQueue();
/*     */   }
/*     */ 
/*     */   public ThreadPoolExecutor getThreadPoolExecutor()
/*     */     throws IllegalStateException
/*     */   {
/* 217 */     Assert.state(this.threadPoolExecutor != null, "ThreadPoolTaskExecutor not initialized");
/* 218 */     return this.threadPoolExecutor;
/*     */   }
/*     */ 
/*     */   public int getPoolSize()
/*     */   {
/* 226 */     if (this.threadPoolExecutor == null)
/*     */     {
/* 228 */       return this.corePoolSize;
/*     */     }
/* 230 */     return this.threadPoolExecutor.getPoolSize();
/*     */   }
/*     */ 
/*     */   public int getActiveCount()
/*     */   {
/* 238 */     if (this.threadPoolExecutor == null)
/*     */     {
/* 240 */       return 0;
/*     */     }
/* 242 */     return this.threadPoolExecutor.getActiveCount();
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 248 */     Executor executor = getThreadPoolExecutor();
/*     */     try {
/* 250 */       executor.execute(task);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 253 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout)
/*     */   {
/* 259 */     execute(task);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task)
/*     */   {
/* 264 */     ExecutorService executor = getThreadPoolExecutor();
/*     */     try {
/* 266 */       return executor.submit(task);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 269 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task)
/*     */   {
/* 275 */     ExecutorService executor = getThreadPoolExecutor();
/*     */     try {
/* 277 */       return executor.submit(task);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 280 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 289 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor
 * JD-Core Version:    0.6.2
 */