/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.Trigger;
/*     */ import org.springframework.scheduling.support.TaskUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ public class ThreadPoolTaskScheduler extends ExecutorConfigurationSupport
/*     */   implements TaskScheduler, SchedulingTaskExecutor
/*     */ {
/*     */   private volatile int poolSize;
/*     */   private volatile ScheduledExecutorService scheduledExecutor;
/*     */   private volatile ErrorHandler errorHandler;
/*     */ 
/*     */   public ThreadPoolTaskScheduler()
/*     */   {
/*  55 */     this.poolSize = 1;
/*     */   }
/*     */ 
/*     */   public void setPoolSize(int poolSize)
/*     */   {
/*  68 */     Assert.isTrue(poolSize > 0, "'poolSize' must be 1 or higher");
/*  69 */     this.poolSize = poolSize;
/*  70 */     if ((this.scheduledExecutor instanceof ScheduledThreadPoolExecutor))
/*  71 */       ((ScheduledThreadPoolExecutor)this.scheduledExecutor).setCorePoolSize(poolSize);
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/*  79 */     Assert.notNull(errorHandler, "'errorHandler' must not be null");
/*  80 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   protected ExecutorService initializeExecutor(ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/*  87 */     this.scheduledExecutor = createExecutor(this.poolSize, threadFactory, rejectedExecutionHandler);
/*  88 */     return this.scheduledExecutor;
/*     */   }
/*     */ 
/*     */   protected ScheduledExecutorService createExecutor(int poolSize, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 105 */     return new ScheduledThreadPoolExecutor(poolSize, threadFactory, rejectedExecutionHandler);
/*     */   }
/*     */ 
/*     */   public ScheduledExecutorService getScheduledExecutor()
/*     */     throws IllegalStateException
/*     */   {
/* 114 */     Assert.state(this.scheduledExecutor != null, "ThreadPoolTaskScheduler not initialized");
/* 115 */     return this.scheduledExecutor;
/*     */   }
/*     */ 
/*     */   public ScheduledThreadPoolExecutor getScheduledThreadPoolExecutor()
/*     */     throws IllegalStateException
/*     */   {
/* 126 */     Assert.state(this.scheduledExecutor instanceof ScheduledThreadPoolExecutor, "No ScheduledThreadPoolExecutor available");
/*     */ 
/* 128 */     return (ScheduledThreadPoolExecutor)this.scheduledExecutor;
/*     */   }
/*     */ 
/*     */   public int getPoolSize()
/*     */   {
/* 138 */     if (this.scheduledExecutor == null)
/*     */     {
/* 140 */       return this.poolSize;
/*     */     }
/* 142 */     return getScheduledThreadPoolExecutor().getPoolSize();
/*     */   }
/*     */ 
/*     */   public int getActiveCount()
/*     */   {
/* 152 */     if (this.scheduledExecutor == null)
/*     */     {
/* 154 */       return 0;
/*     */     }
/* 156 */     return getScheduledThreadPoolExecutor().getActiveCount();
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 164 */     Executor executor = getScheduledExecutor();
/*     */     try {
/* 166 */       executor.execute(errorHandlingTask(task, false));
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 169 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout)
/*     */   {
/* 175 */     execute(task);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task)
/*     */   {
/* 180 */     ExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 182 */       return executor.submit(errorHandlingTask(task, false));
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 185 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task)
/*     */   {
/* 191 */     ExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 193 */       if (this.errorHandler != null) {
/* 194 */         task = new DelegatingErrorHandlingCallable(task, this.errorHandler);
/*     */       }
/* 196 */       return executor.submit(task);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 199 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> schedule(Runnable task, Trigger trigger)
/*     */   {
/* 213 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try
/*     */     {
/* 216 */       ErrorHandler errorHandler = this.errorHandler != null ? this.errorHandler : 
/* 216 */         TaskUtils.getDefaultErrorHandler(true);
/*     */ 
/* 217 */       return new ReschedulingRunnable(task, trigger, executor, errorHandler).schedule();
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 220 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> schedule(Runnable task, Date startTime)
/*     */   {
/* 226 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 227 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 229 */       return executor.schedule(errorHandlingTask(task, false), initialDelay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 232 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, Date startTime, long period)
/*     */   {
/* 238 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 239 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 241 */       return executor.scheduleAtFixedRate(errorHandlingTask(task, true), initialDelay, period, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 244 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, long period)
/*     */   {
/* 250 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 252 */       return executor.scheduleAtFixedRate(errorHandlingTask(task, true), 0L, period, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 255 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable task, Date startTime, long delay)
/*     */   {
/* 261 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 262 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 264 */       return executor.scheduleWithFixedDelay(errorHandlingTask(task, true), initialDelay, delay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 267 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable task, long delay)
/*     */   {
/* 273 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 275 */       return executor.scheduleWithFixedDelay(errorHandlingTask(task, true), 0L, delay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 278 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Runnable errorHandlingTask(Runnable task, boolean isRepeatingTask) {
/* 283 */     return TaskUtils.decorateTaskWithErrorHandler(task, this.errorHandler, isRepeatingTask);
/*     */   }
/*     */ 
/*     */   private static class DelegatingErrorHandlingCallable<V> implements Callable<V>
/*     */   {
/*     */     private final Callable<V> delegate;
/*     */     private final ErrorHandler errorHandler;
/*     */ 
/*     */     DelegatingErrorHandlingCallable(Callable<V> delegate, ErrorHandler errorHandler)
/*     */     {
/* 294 */       this.delegate = delegate;
/* 295 */       this.errorHandler = errorHandler;
/*     */     }
/*     */ 
/*     */     public V call() throws Exception
/*     */     {
/*     */       try {
/* 301 */         return this.delegate.call();
/*     */       }
/*     */       catch (Throwable t) {
/* 304 */         this.errorHandler.handleError(t);
/* 305 */       }return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler
 * JD-Core Version:    0.6.2
 */