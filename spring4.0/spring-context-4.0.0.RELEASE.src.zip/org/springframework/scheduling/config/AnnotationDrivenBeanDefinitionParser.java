/*     */ package org.springframework.scheduling.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public class AnnotationDrivenBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */ 
/*     */   @Deprecated
/*     */   public static final String ASYNC_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalAsyncAnnotationProcessor";
/*     */ 
/*     */   @Deprecated
/*     */   public static final String ASYNC_EXECUTION_ASPECT_BEAN_NAME = "org.springframework.scheduling.config.internalAsyncExecutionAspect";
/*     */ 
/*     */   @Deprecated
/*     */   public static final String SCHEDULED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalScheduledAnnotationProcessor";
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  74 */     Object source = parserContext.extractSource(element);
/*     */ 
/*  77 */     CompositeComponentDefinition compDefinition = new CompositeComponentDefinition(element.getTagName(), source);
/*  78 */     parserContext.pushContainingComponent(compDefinition);
/*     */ 
/*  81 */     BeanDefinitionRegistry registry = parserContext.getRegistry();
/*     */ 
/*  83 */     String mode = element.getAttribute("mode");
/*  84 */     if ("aspectj".equals(mode))
/*     */     {
/*  86 */       registerAsyncExecutionAspect(element, parserContext);
/*     */     }
/*  90 */     else if (registry.containsBeanDefinition("org.springframework.context.annotation.internalAsyncAnnotationProcessor")) {
/*  91 */       parserContext.getReaderContext().error("Only one AsyncAnnotationBeanPostProcessor may exist within the context.", source);
/*     */     }
/*     */     else
/*     */     {
/*  95 */       BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition("org.springframework.scheduling.annotation.AsyncAnnotationBeanPostProcessor");
/*     */ 
/*  97 */       builder.getRawBeanDefinition().setSource(source);
/*  98 */       String executor = element.getAttribute("executor");
/*  99 */       if (StringUtils.hasText(executor)) {
/* 100 */         builder.addPropertyReference("executor", executor);
/*     */       }
/* 102 */       if (Boolean.valueOf(element.getAttribute("proxy-target-class")).booleanValue()) {
/* 103 */         builder.addPropertyValue("proxyTargetClass", Boolean.valueOf(true));
/*     */       }
/* 105 */       registerPostProcessor(parserContext, builder, "org.springframework.context.annotation.internalAsyncAnnotationProcessor");
/*     */     }
/*     */ 
/* 109 */     if (registry.containsBeanDefinition("org.springframework.context.annotation.internalScheduledAnnotationProcessor")) {
/* 110 */       parserContext.getReaderContext().error("Only one ScheduledAnnotationBeanPostProcessor may exist within the context.", source);
/*     */     }
/*     */     else
/*     */     {
/* 114 */       BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition("org.springframework.scheduling.annotation.ScheduledAnnotationBeanPostProcessor");
/*     */ 
/* 116 */       builder.getRawBeanDefinition().setSource(source);
/* 117 */       String scheduler = element.getAttribute("scheduler");
/* 118 */       if (StringUtils.hasText(scheduler)) {
/* 119 */         builder.addPropertyReference("scheduler", scheduler);
/*     */       }
/* 121 */       registerPostProcessor(parserContext, builder, "org.springframework.context.annotation.internalScheduledAnnotationProcessor");
/*     */     }
/*     */ 
/* 125 */     parserContext.popAndRegisterContainingComponent();
/*     */ 
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   private void registerAsyncExecutionAspect(Element element, ParserContext parserContext) {
/* 131 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.scheduling.config.internalAsyncExecutionAspect")) {
/* 132 */       BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition("org.springframework.scheduling.aspectj.AnnotationAsyncExecutionAspect");
/*     */ 
/* 134 */       builder.setFactoryMethod("aspectOf");
/* 135 */       String executor = element.getAttribute("executor");
/* 136 */       if (StringUtils.hasText(executor)) {
/* 137 */         builder.addPropertyReference("executor", executor);
/*     */       }
/* 139 */       parserContext.registerBeanComponent(new BeanComponentDefinition(builder
/* 140 */         .getBeanDefinition(), "org.springframework.scheduling.config.internalAsyncExecutionAspect"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void registerPostProcessor(ParserContext parserContext, BeanDefinitionBuilder builder, String beanName)
/*     */   {
/* 148 */     builder.setRole(2);
/* 149 */     parserContext.getRegistry().registerBeanDefinition(beanName, builder.getBeanDefinition());
/* 150 */     BeanDefinitionHolder holder = new BeanDefinitionHolder(builder.getBeanDefinition(), beanName);
/* 151 */     parserContext.registerComponent(new BeanComponentDefinition(holder));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.AnnotationDrivenBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */