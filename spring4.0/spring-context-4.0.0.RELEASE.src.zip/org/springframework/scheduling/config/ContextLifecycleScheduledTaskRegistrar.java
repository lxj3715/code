/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.event.ContextRefreshedEvent;
/*    */ 
/*    */ public class ContextLifecycleScheduledTaskRegistrar extends ScheduledTaskRegistrar
/*    */   implements ApplicationContextAware, ApplicationListener<ContextRefreshedEvent>
/*    */ {
/*    */   private ApplicationContext applicationContext;
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext applicationContext)
/*    */   {
/* 40 */     this.applicationContext = applicationContext;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 50 */     if (this.applicationContext == null)
/* 51 */       scheduleTasks();
/*    */   }
/*    */ 
/*    */   public void onApplicationEvent(ContextRefreshedEvent event)
/*    */   {
/* 61 */     if (event.getApplicationContext() != this.applicationContext) {
/* 62 */       return;
/*    */     }
/* 64 */     scheduleTasks();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.ContextLifecycleScheduledTaskRegistrar
 * JD-Core Version:    0.6.2
 */