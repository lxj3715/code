/*     */ package org.springframework.scheduling.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.Trigger;
/*     */ import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ScheduledTaskRegistrar
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*     */   private TaskScheduler taskScheduler;
/*     */   private ScheduledExecutorService localExecutor;
/*     */   private List<TriggerTask> triggerTasks;
/*     */   private List<CronTask> cronTasks;
/*     */   private List<IntervalTask> fixedRateTasks;
/*     */   private List<IntervalTask> fixedDelayTasks;
/*  67 */   private final Set<ScheduledFuture<?>> scheduledFutures = new LinkedHashSet();
/*     */ 
/*     */   public void setTaskScheduler(TaskScheduler taskScheduler)
/*     */   {
/*  74 */     Assert.notNull(taskScheduler, "TaskScheduler must not be null");
/*  75 */     this.taskScheduler = taskScheduler;
/*     */   }
/*     */ 
/*     */   public void setScheduler(Object scheduler)
/*     */   {
/*  84 */     Assert.notNull(scheduler, "Scheduler object must not be null");
/*  85 */     if ((scheduler instanceof TaskScheduler)) {
/*  86 */       this.taskScheduler = ((TaskScheduler)scheduler);
/*     */     }
/*  88 */     else if ((scheduler instanceof ScheduledExecutorService)) {
/*  89 */       this.taskScheduler = new ConcurrentTaskScheduler((ScheduledExecutorService)scheduler);
/*     */     }
/*     */     else
/*  92 */       throw new IllegalArgumentException("Unsupported scheduler type: " + scheduler.getClass());
/*     */   }
/*     */ 
/*     */   public TaskScheduler getScheduler()
/*     */   {
/* 100 */     return this.taskScheduler;
/*     */   }
/*     */ 
/*     */   public void setTriggerTasks(Map<Runnable, Trigger> triggerTasks)
/*     */   {
/* 109 */     this.triggerTasks = new ArrayList();
/* 110 */     for (Map.Entry task : triggerTasks.entrySet())
/* 111 */       this.triggerTasks.add(new TriggerTask((Runnable)task.getKey(), (Trigger)task.getValue()));
/*     */   }
/*     */ 
/*     */   public void setTriggerTasksList(List<TriggerTask> triggerTasks)
/*     */   {
/* 122 */     this.triggerTasks = triggerTasks;
/*     */   }
/*     */ 
/*     */   public void setCronTasks(Map<Runnable, String> cronTasks)
/*     */   {
/* 130 */     this.cronTasks = new ArrayList();
/* 131 */     for (Map.Entry task : cronTasks.entrySet())
/* 132 */       addCronTask((Runnable)task.getKey(), (String)task.getValue());
/*     */   }
/*     */ 
/*     */   public void setCronTasksList(List<CronTask> cronTasks)
/*     */   {
/* 143 */     this.cronTasks = cronTasks;
/*     */   }
/*     */ 
/*     */   public void setFixedRateTasks(Map<Runnable, Long> fixedRateTasks)
/*     */   {
/* 151 */     this.fixedRateTasks = new ArrayList();
/* 152 */     for (Map.Entry task : fixedRateTasks.entrySet())
/* 153 */       addFixedRateTask((Runnable)task.getKey(), ((Long)task.getValue()).longValue());
/*     */   }
/*     */ 
/*     */   public void setFixedRateTasksList(List<IntervalTask> fixedRateTasks)
/*     */   {
/* 164 */     this.fixedRateTasks = fixedRateTasks;
/*     */   }
/*     */ 
/*     */   public void setFixedDelayTasks(Map<Runnable, Long> fixedDelayTasks)
/*     */   {
/* 172 */     this.fixedDelayTasks = new ArrayList();
/* 173 */     for (Map.Entry task : fixedDelayTasks.entrySet())
/* 174 */       addFixedDelayTask((Runnable)task.getKey(), ((Long)task.getValue()).longValue());
/*     */   }
/*     */ 
/*     */   public void setFixedDelayTasksList(List<IntervalTask> fixedDelayTasks)
/*     */   {
/* 185 */     this.fixedDelayTasks = fixedDelayTasks;
/*     */   }
/*     */ 
/*     */   public void addTriggerTask(Runnable task, Trigger trigger)
/*     */   {
/* 193 */     addTriggerTask(new TriggerTask(task, trigger));
/*     */   }
/*     */ 
/*     */   public void addTriggerTask(TriggerTask task)
/*     */   {
/* 202 */     if (this.triggerTasks == null) {
/* 203 */       this.triggerTasks = new ArrayList();
/*     */     }
/* 205 */     this.triggerTasks.add(task);
/*     */   }
/*     */ 
/*     */   public void addCronTask(Runnable task, String expression)
/*     */   {
/* 212 */     addCronTask(new CronTask(task, expression));
/*     */   }
/*     */ 
/*     */   public void addCronTask(CronTask task)
/*     */   {
/* 220 */     if (this.cronTasks == null) {
/* 221 */       this.cronTasks = new ArrayList();
/*     */     }
/* 223 */     this.cronTasks.add(task);
/*     */   }
/*     */ 
/*     */   public void addFixedRateTask(Runnable task, long period)
/*     */   {
/* 231 */     addFixedRateTask(new IntervalTask(task, period, 0L));
/*     */   }
/*     */ 
/*     */   public void addFixedRateTask(IntervalTask task)
/*     */   {
/* 240 */     if (this.fixedRateTasks == null) {
/* 241 */       this.fixedRateTasks = new ArrayList();
/*     */     }
/* 243 */     this.fixedRateTasks.add(task);
/*     */   }
/*     */ 
/*     */   public void addFixedDelayTask(Runnable task, long delay)
/*     */   {
/* 251 */     addFixedDelayTask(new IntervalTask(task, delay, 0L));
/*     */   }
/*     */ 
/*     */   public void addFixedDelayTask(IntervalTask task)
/*     */   {
/* 260 */     if (this.fixedDelayTasks == null) {
/* 261 */       this.fixedDelayTasks = new ArrayList();
/*     */     }
/* 263 */     this.fixedDelayTasks.add(task);
/*     */   }
/*     */ 
/*     */   public boolean hasTasks()
/*     */   {
/* 274 */     return ((this.fixedRateTasks != null) && (!this.fixedRateTasks.isEmpty())) || ((this.fixedDelayTasks != null) && 
/* 272 */       (!this.fixedDelayTasks
/* 272 */       .isEmpty())) || ((this.cronTasks != null) && 
/* 273 */       (!this.cronTasks
/* 273 */       .isEmpty())) || (
/* 273 */       (this.triggerTasks != null) && 
/* 274 */       (!this.triggerTasks
/* 274 */       .isEmpty()));
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 283 */     scheduleTasks();
/*     */   }
/*     */ 
/*     */   protected void scheduleTasks()
/*     */   {
/* 291 */     long now = System.currentTimeMillis();
/*     */ 
/* 293 */     if (this.taskScheduler == null) {
/* 294 */       this.localExecutor = Executors.newSingleThreadScheduledExecutor();
/* 295 */       this.taskScheduler = new ConcurrentTaskScheduler(this.localExecutor);
/*     */     }
/* 297 */     if (this.triggerTasks != null) {
/* 298 */       for (TriggerTask task : this.triggerTasks) {
/* 299 */         this.scheduledFutures.add(this.taskScheduler.schedule(task
/* 300 */           .getRunnable(), task.getTrigger()));
/*     */       }
/*     */     }
/* 303 */     if (this.cronTasks != null) {
/* 304 */       for (CronTask task : this.cronTasks) {
/* 305 */         this.scheduledFutures.add(this.taskScheduler.schedule(task
/* 306 */           .getRunnable(), task.getTrigger()));
/*     */       }
/*     */     }
/* 309 */     if (this.fixedRateTasks != null) {
/* 310 */       for (IntervalTask task : this.fixedRateTasks) {
/* 311 */         if (task.getInitialDelay() > 0L) {
/* 312 */           Date startTime = new Date(now + task.getInitialDelay());
/* 313 */           this.scheduledFutures.add(this.taskScheduler.scheduleAtFixedRate(task
/* 314 */             .getRunnable(), startTime, task.getInterval()));
/*     */         }
/*     */         else {
/* 317 */           this.scheduledFutures.add(this.taskScheduler.scheduleAtFixedRate(task
/* 318 */             .getRunnable(), task.getInterval()));
/*     */         }
/*     */       }
/*     */     }
/* 322 */     if (this.fixedDelayTasks != null)
/* 323 */       for (IntervalTask task : this.fixedDelayTasks)
/* 324 */         if (task.getInitialDelay() > 0L) {
/* 325 */           Date startTime = new Date(now + task.getInitialDelay());
/* 326 */           this.scheduledFutures.add(this.taskScheduler.scheduleWithFixedDelay(task
/* 327 */             .getRunnable(), startTime, task.getInterval()));
/*     */         }
/*     */         else {
/* 330 */           this.scheduledFutures.add(this.taskScheduler.scheduleWithFixedDelay(task
/* 331 */             .getRunnable(), task.getInterval()));
/*     */         }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 339 */     for (ScheduledFuture future : this.scheduledFutures) {
/* 340 */       future.cancel(true);
/*     */     }
/* 342 */     if (this.localExecutor != null)
/* 343 */       this.localExecutor.shutdownNow();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.ScheduledTaskRegistrar
 * JD-Core Version:    0.6.2
 */