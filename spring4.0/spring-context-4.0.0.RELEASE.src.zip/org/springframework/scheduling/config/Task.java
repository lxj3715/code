/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ public class Task
/*    */ {
/*    */   private final Runnable runnable;
/*    */ 
/*    */   public Task(Runnable runnable)
/*    */   {
/* 36 */     this.runnable = runnable;
/*    */   }
/*    */ 
/*    */   public Runnable getRunnable()
/*    */   {
/* 41 */     return this.runnable;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.Task
 * JD-Core Version:    0.6.2
 */