/*     */ package org.springframework.scheduling.config;
/*     */ 
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class TaskExecutorFactoryBean
/*     */   implements FactoryBean<TaskExecutor>, BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*     */   private String poolSize;
/*     */   private Integer queueCapacity;
/*     */   private Object rejectedExecutionHandler;
/*     */   private Integer keepAliveSeconds;
/*     */   private String beanName;
/*     */   private TaskExecutor target;
/*     */ 
/*     */   public void setPoolSize(String poolSize)
/*     */   {
/*  54 */     this.poolSize = poolSize;
/*     */   }
/*     */ 
/*     */   public void setQueueCapacity(int queueCapacity) {
/*  58 */     this.queueCapacity = Integer.valueOf(queueCapacity);
/*     */   }
/*     */ 
/*     */   public void setRejectedExecutionHandler(Object rejectedExecutionHandler) {
/*  62 */     this.rejectedExecutionHandler = rejectedExecutionHandler;
/*     */   }
/*     */ 
/*     */   public void setKeepAliveSeconds(int keepAliveSeconds) {
/*  66 */     this.keepAliveSeconds = Integer.valueOf(keepAliveSeconds);
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName)
/*     */   {
/*  71 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/*  77 */     BeanWrapper bw = new BeanWrapperImpl(ThreadPoolTaskExecutor.class);
/*  78 */     determinePoolSizeRange(bw);
/*  79 */     if (this.queueCapacity != null) {
/*  80 */       bw.setPropertyValue("queueCapacity", this.queueCapacity);
/*     */     }
/*  82 */     if (this.keepAliveSeconds != null) {
/*  83 */       bw.setPropertyValue("keepAliveSeconds", this.keepAliveSeconds);
/*     */     }
/*  85 */     if (this.rejectedExecutionHandler != null) {
/*  86 */       bw.setPropertyValue("rejectedExecutionHandler", this.rejectedExecutionHandler);
/*     */     }
/*  88 */     if (this.beanName != null) {
/*  89 */       bw.setPropertyValue("threadNamePrefix", this.beanName + "-");
/*     */     }
/*  91 */     this.target = ((TaskExecutor)bw.getWrappedInstance());
/*  92 */     if ((this.target instanceof InitializingBean))
/*  93 */       ((InitializingBean)this.target).afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   private void determinePoolSizeRange(BeanWrapper bw)
/*     */   {
/*  98 */     if (StringUtils.hasText(this.poolSize))
/*     */     {
/*     */       try
/*     */       {
/* 102 */         int separatorIndex = this.poolSize.indexOf('-');
/*     */         int corePoolSize;
/*     */         int maxPoolSize;
/* 103 */         if (separatorIndex != -1) {
/* 104 */           int corePoolSize = Integer.valueOf(this.poolSize.substring(0, separatorIndex)).intValue();
/* 105 */           int maxPoolSize = Integer.valueOf(this.poolSize.substring(separatorIndex + 1, this.poolSize.length())).intValue();
/* 106 */           if (corePoolSize > maxPoolSize) {
/* 107 */             throw new IllegalArgumentException("Lower bound of pool-size range must not exceed the upper bound");
/*     */           }
/*     */ 
/* 110 */           if (this.queueCapacity == null)
/*     */           {
/* 112 */             if (corePoolSize == 0)
/*     */             {
/* 115 */               bw.setPropertyValue("allowCoreThreadTimeOut", Boolean.valueOf(true));
/* 116 */               corePoolSize = maxPoolSize;
/*     */             }
/*     */             else
/*     */             {
/* 120 */               throw new IllegalArgumentException("A non-zero lower bound for the size range requires a queue-capacity value");
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 126 */           Integer value = Integer.valueOf(this.poolSize);
/* 127 */           corePoolSize = value.intValue();
/* 128 */           maxPoolSize = value.intValue();
/*     */         }
/* 130 */         bw.setPropertyValue("corePoolSize", Integer.valueOf(corePoolSize));
/* 131 */         bw.setPropertyValue("maxPoolSize", Integer.valueOf(maxPoolSize));
/*     */       }
/*     */       catch (NumberFormatException ex) {
/* 134 */         throw new IllegalArgumentException("Invalid pool-size value [" + this.poolSize + "]: only single " + "maximum integer (e.g. \"5\") and minimum-maximum range (e.g. \"3-5\") are supported", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public TaskExecutor getObject()
/*     */   {
/* 143 */     return this.target;
/*     */   }
/*     */ 
/*     */   public Class<? extends TaskExecutor> getObjectType()
/*     */   {
/* 148 */     return this.target != null ? this.target.getClass() : ThreadPoolTaskExecutor.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 153 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws Exception
/*     */   {
/* 159 */     if ((this.target instanceof DisposableBean))
/* 160 */       ((DisposableBean)this.target).destroy();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.TaskExecutorFactoryBean
 * JD-Core Version:    0.6.2
 */