/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class TaskNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 31 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
/* 32 */     registerBeanDefinitionParser("executor", new ExecutorBeanDefinitionParser());
/* 33 */     registerBeanDefinitionParser("scheduled-tasks", new ScheduledTasksBeanDefinitionParser());
/* 34 */     registerBeanDefinitionParser("scheduler", new SchedulerBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.TaskNamespaceHandler
 * JD-Core Version:    0.6.2
 */