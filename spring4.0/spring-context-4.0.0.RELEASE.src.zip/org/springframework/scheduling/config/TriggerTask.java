/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.scheduling.Trigger;
/*    */ 
/*    */ public class TriggerTask extends Task
/*    */ {
/*    */   private final Trigger trigger;
/*    */ 
/*    */   public TriggerTask(Runnable runnable, Trigger trigger)
/*    */   {
/* 42 */     super(runnable);
/* 43 */     this.trigger = trigger;
/*    */   }
/*    */ 
/*    */   public Trigger getTrigger()
/*    */   {
/* 48 */     return this.trigger;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.TriggerTask
 * JD-Core Version:    0.6.2
 */