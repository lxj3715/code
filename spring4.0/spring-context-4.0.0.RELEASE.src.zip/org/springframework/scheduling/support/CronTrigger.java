/*    */ package org.springframework.scheduling.support;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.TimeZone;
/*    */ import org.springframework.scheduling.Trigger;
/*    */ import org.springframework.scheduling.TriggerContext;
/*    */ 
/*    */ public class CronTrigger
/*    */   implements Trigger
/*    */ {
/*    */   private final CronSequenceGenerator sequenceGenerator;
/*    */ 
/*    */   public CronTrigger(String cronExpression)
/*    */   {
/* 44 */     this.sequenceGenerator = new CronSequenceGenerator(cronExpression);
/*    */   }
/*    */ 
/*    */   public CronTrigger(String cronExpression, TimeZone timeZone)
/*    */   {
/* 54 */     this.sequenceGenerator = new CronSequenceGenerator(cronExpression, timeZone);
/*    */   }
/*    */ 
/*    */   public Date nextExecutionTime(TriggerContext triggerContext)
/*    */   {
/* 66 */     Date date = triggerContext.lastCompletionTime();
/* 67 */     if (date != null) {
/* 68 */       Date scheduled = triggerContext.lastScheduledExecutionTime();
/* 69 */       if ((scheduled != null) && (date.before(scheduled)))
/*    */       {
/* 73 */         date = scheduled;
/*    */       }
/*    */     }
/*    */     else {
/* 77 */       date = new Date();
/*    */     }
/* 79 */     return this.sequenceGenerator.next(date);
/*    */   }
/*    */ 
/*    */   public String getExpression() {
/* 83 */     return this.sequenceGenerator.getExpression();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 89 */     return (this == obj) || (((obj instanceof CronTrigger)) && 
/* 89 */       (this.sequenceGenerator
/* 89 */       .equals(((CronTrigger)obj).sequenceGenerator)));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 94 */     return this.sequenceGenerator.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 99 */     return this.sequenceGenerator.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.support.CronTrigger
 * JD-Core Version:    0.6.2
 */