/*    */ package org.springframework.scripting;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class ScriptCompilationException extends NestedRuntimeException
/*    */ {
/*    */   private ScriptSource scriptSource;
/*    */ 
/*    */   public ScriptCompilationException(String msg)
/*    */   {
/* 38 */     super(msg);
/*    */   }
/*    */ 
/*    */   public ScriptCompilationException(String msg, Throwable cause)
/*    */   {
/* 48 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public ScriptCompilationException(ScriptSource scriptSource, Throwable cause)
/*    */   {
/* 58 */     super("Could not compile script", cause);
/* 59 */     this.scriptSource = scriptSource;
/*    */   }
/*    */ 
/*    */   public ScriptCompilationException(ScriptSource scriptSource, String msg, Throwable cause)
/*    */   {
/* 70 */     super("Could not compile script [" + scriptSource + "]: " + msg, cause);
/* 71 */     this.scriptSource = scriptSource;
/*    */   }
/*    */ 
/*    */   public ScriptSource getScriptSource()
/*    */   {
/* 80 */     return this.scriptSource;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.ScriptCompilationException
 * JD-Core Version:    0.6.2
 */