package org.springframework.scripting;

import java.util.Map;

public abstract interface ScriptEvaluator
{
  public abstract Object evaluate(ScriptSource paramScriptSource)
    throws ScriptCompilationException;

  public abstract Object evaluate(ScriptSource paramScriptSource, Map<String, Object> paramMap)
    throws ScriptCompilationException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.ScriptEvaluator
 * JD-Core Version:    0.6.2
 */