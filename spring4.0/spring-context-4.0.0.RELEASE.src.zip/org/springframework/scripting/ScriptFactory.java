package org.springframework.scripting;

import java.io.IOException;

public abstract interface ScriptFactory
{
  public abstract String getScriptSourceLocator();

  public abstract Class<?>[] getScriptInterfaces();

  public abstract boolean requiresConfigInterface();

  public abstract Object getScriptedObject(ScriptSource paramScriptSource, Class<?>[] paramArrayOfClass)
    throws IOException, ScriptCompilationException;

  public abstract Class<?> getScriptedObjectType(ScriptSource paramScriptSource)
    throws IOException, ScriptCompilationException;

  public abstract boolean requiresScriptedObjectRefresh(ScriptSource paramScriptSource);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.ScriptFactory
 * JD-Core Version:    0.6.2
 */