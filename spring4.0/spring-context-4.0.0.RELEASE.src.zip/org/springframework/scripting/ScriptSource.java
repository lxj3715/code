package org.springframework.scripting;

import java.io.IOException;

public abstract interface ScriptSource
{
  public abstract String getScriptAsString()
    throws IOException;

  public abstract boolean isModified();

  public abstract String suggestedClassName();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.ScriptSource
 * JD-Core Version:    0.6.2
 */