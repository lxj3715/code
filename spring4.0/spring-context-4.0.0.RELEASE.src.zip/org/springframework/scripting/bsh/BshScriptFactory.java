/*     */ package org.springframework.scripting.bsh;
/*     */ 
/*     */ import bsh.EvalError;
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.scripting.ScriptCompilationException;
/*     */ import org.springframework.scripting.ScriptFactory;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class BshScriptFactory
/*     */   implements ScriptFactory, BeanClassLoaderAware
/*     */ {
/*     */   private final String scriptSourceLocator;
/*     */   private final Class<?>[] scriptInterfaces;
/*  50 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   private Class<?> scriptClass;
/*  54 */   private final Object scriptClassMonitor = new Object();
/*     */ 
/*  56 */   private boolean wasModifiedForTypeCheck = false;
/*     */ 
/*     */   public BshScriptFactory(String scriptSourceLocator)
/*     */   {
/*  67 */     Assert.hasText(scriptSourceLocator, "'scriptSourceLocator' must not be empty");
/*  68 */     this.scriptSourceLocator = scriptSourceLocator;
/*  69 */     this.scriptInterfaces = null;
/*     */   }
/*     */ 
/*     */   public BshScriptFactory(String scriptSourceLocator, Class<?>[] scriptInterfaces)
/*     */   {
/*  84 */     Assert.hasText(scriptSourceLocator, "'scriptSourceLocator' must not be empty");
/*  85 */     this.scriptSourceLocator = scriptSourceLocator;
/*  86 */     this.scriptInterfaces = scriptInterfaces;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  91 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public String getScriptSourceLocator()
/*     */   {
/*  97 */     return this.scriptSourceLocator;
/*     */   }
/*     */ 
/*     */   public Class<?>[] getScriptInterfaces()
/*     */   {
/* 102 */     return this.scriptInterfaces;
/*     */   }
/*     */ 
/*     */   public boolean requiresConfigInterface()
/*     */   {
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   public Object getScriptedObject(ScriptSource scriptSource, Class<?>[] actualInterfaces)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/*     */       Class clazz;
/* 124 */       synchronized (this.scriptClassMonitor) {
/* 125 */         boolean requiresScriptEvaluation = (this.wasModifiedForTypeCheck) && (this.scriptClass == null);
/* 126 */         this.wasModifiedForTypeCheck = false;
/*     */ 
/* 128 */         if ((scriptSource.isModified()) || (requiresScriptEvaluation))
/*     */         {
/* 130 */           Object result = BshScriptUtils.evaluateBshScript(scriptSource
/* 131 */             .getScriptAsString(), actualInterfaces, this.beanClassLoader);
/* 132 */           if ((result instanceof Class))
/*     */           {
/* 135 */             this.scriptClass = ((Class)result);
/*     */           }
/*     */           else
/*     */           {
/* 142 */             return result;
/*     */           }
/*     */         }
/* 145 */         clazz = this.scriptClass;
/*     */       }
/*     */ 
/* 148 */       if (clazz != null) {
/*     */         try
/*     */         {
/* 151 */           return clazz.newInstance();
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/* 155 */           throw new ScriptCompilationException(scriptSource, "Could not instantiate script class: " + clazz
/* 155 */             .getName(), ex);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 160 */       return BshScriptUtils.createBshObject(scriptSource
/* 161 */         .getScriptAsString(), actualInterfaces, this.beanClassLoader);
/*     */     }
/*     */     catch (EvalError ex)
/*     */     {
/* 165 */       throw new ScriptCompilationException(scriptSource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<?> getScriptedObjectType(ScriptSource scriptSource)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 174 */       synchronized (this.scriptClassMonitor) {
/* 175 */         if (scriptSource.isModified())
/*     */         {
/* 177 */           this.wasModifiedForTypeCheck = true;
/* 178 */           this.scriptClass = BshScriptUtils.determineBshObjectType(scriptSource
/* 179 */             .getScriptAsString(), this.beanClassLoader);
/*     */         }
/* 181 */         return this.scriptClass;
/*     */       }
/*     */     }
/*     */     catch (EvalError ex) {
/* 185 */       throw new ScriptCompilationException(scriptSource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean requiresScriptedObjectRefresh(ScriptSource scriptSource)
/*     */   {
/* 191 */     synchronized (this.scriptClassMonitor) {
/* 192 */       return (scriptSource.isModified()) || (this.wasModifiedForTypeCheck);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 199 */     return "BshScriptFactory: script source locator [" + this.scriptSourceLocator + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.bsh.BshScriptFactory
 * JD-Core Version:    0.6.2
 */