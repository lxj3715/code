/*     */ package org.springframework.scripting.bsh;
/*     */ 
/*     */ import bsh.EvalError;
/*     */ import bsh.Interpreter;
/*     */ import bsh.Primitive;
/*     */ import bsh.XThis;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import org.springframework.core.NestedRuntimeException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class BshScriptUtils
/*     */ {
/*     */   public static Object createBshObject(String scriptSource)
/*     */     throws EvalError
/*     */   {
/*  51 */     return createBshObject(scriptSource, null, null);
/*     */   }
/*     */ 
/*     */   public static Object createBshObject(String scriptSource, Class<?>[] scriptInterfaces)
/*     */     throws EvalError
/*     */   {
/*  70 */     return createBshObject(scriptSource, scriptInterfaces, ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public static Object createBshObject(String scriptSource, Class<?>[] scriptInterfaces, ClassLoader classLoader)
/*     */     throws EvalError
/*     */   {
/*  90 */     Object result = evaluateBshScript(scriptSource, scriptInterfaces, classLoader);
/*  91 */     if ((result instanceof Class)) {
/*  92 */       Class clazz = (Class)result;
/*     */       try {
/*  94 */         return clazz.newInstance();
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/*  98 */         throw new IllegalStateException("Could not instantiate script class [" + clazz
/*  98 */           .getName() + "]. Root cause is " + ex);
/*     */       }
/*     */     }
/*     */ 
/* 102 */     return result;
/*     */   }
/*     */ 
/*     */   static Class<?> determineBshObjectType(String scriptSource, ClassLoader classLoader)
/*     */     throws EvalError
/*     */   {
/* 118 */     Assert.hasText(scriptSource, "Script source must not be empty");
/* 119 */     Interpreter interpreter = new Interpreter();
/* 120 */     interpreter.setClassLoader(classLoader);
/* 121 */     Object result = interpreter.eval(scriptSource);
/* 122 */     if ((result instanceof Class)) {
/* 123 */       return (Class)result;
/*     */     }
/* 125 */     if (result != null) {
/* 126 */       return result.getClass();
/*     */     }
/*     */ 
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   static Object evaluateBshScript(String scriptSource, Class<?>[] scriptInterfaces, ClassLoader classLoader)
/*     */     throws EvalError
/*     */   {
/* 151 */     Assert.hasText(scriptSource, "Script source must not be empty");
/* 152 */     Interpreter interpreter = new Interpreter();
/* 153 */     interpreter.setClassLoader(classLoader);
/* 154 */     Object result = interpreter.eval(scriptSource);
/* 155 */     if (result != null) {
/* 156 */       return result;
/*     */     }
/*     */ 
/* 160 */     Assert.notEmpty(scriptInterfaces, "Given script requires a script proxy: At least one script interface is required.");
/*     */ 
/* 162 */     XThis xt = (XThis)interpreter.eval("return this");
/* 163 */     return Proxy.newProxyInstance(classLoader, scriptInterfaces, new BshObjectInvocationHandler(xt));
/*     */   }
/*     */ 
/*     */   public static class BshExecutionException extends NestedRuntimeException
/*     */   {
/*     */     private BshExecutionException(EvalError ex)
/*     */     {
/* 223 */       super(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BshObjectInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final XThis xt;
/*     */ 
/*     */     public BshObjectInvocationHandler(XThis xt)
/*     */     {
/* 176 */       this.xt = xt;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */     {
/* 181 */       if (ReflectionUtils.isEqualsMethod(method)) {
/* 182 */         return Boolean.valueOf(isProxyForSameBshObject(args[0]));
/*     */       }
/* 184 */       if (ReflectionUtils.isHashCodeMethod(method)) {
/* 185 */         return Integer.valueOf(this.xt.hashCode());
/*     */       }
/* 187 */       if (ReflectionUtils.isToStringMethod(method))
/* 188 */         return "BeanShell object [" + this.xt + "]";
/*     */       try
/*     */       {
/* 191 */         Object result = this.xt.invokeMethod(method.getName(), args);
/* 192 */         if ((result == Primitive.NULL) || (result == Primitive.VOID)) {
/* 193 */           return null;
/*     */         }
/* 195 */         if ((result instanceof Primitive)) {
/* 196 */           return ((Primitive)result).getValue();
/*     */         }
/* 198 */         return result;
/*     */       }
/*     */       catch (EvalError ex) {
/* 201 */         throw new BshScriptUtils.BshExecutionException(ex, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     private boolean isProxyForSameBshObject(Object other) {
/* 206 */       if (!Proxy.isProxyClass(other.getClass())) {
/* 207 */         return false;
/*     */       }
/* 209 */       InvocationHandler ih = Proxy.getInvocationHandler(other);
/*     */ 
/* 211 */       return ((ih instanceof BshObjectInvocationHandler)) && 
/* 211 */         (this.xt
/* 211 */         .equals(((BshObjectInvocationHandler)ih).xt));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.bsh.BshScriptUtils
 * JD-Core Version:    0.6.2
 */