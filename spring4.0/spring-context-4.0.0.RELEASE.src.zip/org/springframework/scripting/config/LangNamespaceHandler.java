/*    */ package org.springframework.scripting.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class LangNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 44 */     registerScriptBeanDefinitionParser("groovy", "org.springframework.scripting.groovy.GroovyScriptFactory");
/* 45 */     registerScriptBeanDefinitionParser("jruby", "org.springframework.scripting.jruby.JRubyScriptFactory");
/* 46 */     registerScriptBeanDefinitionParser("bsh", "org.springframework.scripting.bsh.BshScriptFactory");
/* 47 */     registerBeanDefinitionParser("defaults", new ScriptingDefaultsParser());
/*    */   }
/*    */ 
/*    */   private void registerScriptBeanDefinitionParser(String key, String scriptFactoryClassName) {
/* 51 */     registerBeanDefinitionParser(key, new ScriptBeanDefinitionParser(scriptFactoryClassName));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.config.LangNamespaceHandler
 * JD-Core Version:    0.6.2
 */