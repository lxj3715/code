/*    */ package org.springframework.scripting.groovy;
/*    */ 
/*    */ import groovy.lang.Binding;
/*    */ import groovy.lang.GroovyShell;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import org.codehaus.groovy.control.CompilationFailedException;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.scripting.ScriptCompilationException;
/*    */ import org.springframework.scripting.ScriptEvaluator;
/*    */ import org.springframework.scripting.ScriptSource;
/*    */ import org.springframework.scripting.support.ResourceScriptSource;
/*    */ 
/*    */ public class GroovyScriptEvaluator
/*    */   implements ScriptEvaluator, BeanClassLoaderAware
/*    */ {
/*    */   private ClassLoader classLoader;
/*    */ 
/*    */   public GroovyScriptEvaluator()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GroovyScriptEvaluator(ClassLoader classLoader)
/*    */   {
/* 39 */     this.classLoader = classLoader;
/*    */   }
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader classLoader)
/*    */   {
/* 45 */     this.classLoader = classLoader;
/*    */   }
/*    */ 
/*    */   public Object evaluate(ScriptSource script)
/*    */   {
/* 51 */     return evaluate(script, null);
/*    */   }
/*    */ 
/*    */   public Object evaluate(ScriptSource script, Map<String, Object> arguments)
/*    */   {
/* 56 */     GroovyShell groovyShell = new GroovyShell(this.classLoader, new Binding(arguments));
/*    */     try
/*    */     {
/* 59 */       String filename = (script instanceof ResourceScriptSource) ? ((ResourceScriptSource)script)
/* 59 */         .getResource().getFilename() : null;
/* 60 */       if (filename != null) {
/* 61 */         return groovyShell.evaluate(script.getScriptAsString(), filename);
/*    */       }
/*    */ 
/* 64 */       return groovyShell.evaluate(script.getScriptAsString());
/*    */     }
/*    */     catch (IOException ex)
/*    */     {
/* 68 */       throw new ScriptCompilationException(script, "Cannot access script", ex);
/*    */     }
/*    */     catch (CompilationFailedException ex) {
/* 71 */       throw new ScriptCompilationException(script, "Evaluation failure", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.groovy.GroovyScriptEvaluator
 * JD-Core Version:    0.6.2
 */