/*     */ package org.springframework.scripting.groovy;
/*     */ 
/*     */ import groovy.lang.GroovyClassLoader;
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.lang.MetaClass;
/*     */ import groovy.lang.Script;
/*     */ import java.io.IOException;
/*     */ import org.codehaus.groovy.control.CompilationFailedException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.scripting.ScriptCompilationException;
/*     */ import org.springframework.scripting.ScriptFactory;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class GroovyScriptFactory
/*     */   implements ScriptFactory, BeanFactoryAware, BeanClassLoaderAware
/*     */ {
/*     */   private final String scriptSourceLocator;
/*     */   private final GroovyObjectCustomizer groovyObjectCustomizer;
/*     */   private GroovyClassLoader groovyClassLoader;
/*     */   private Class<?> scriptClass;
/*     */   private Class<?> scriptResultClass;
/*     */   private CachedResultHolder cachedResult;
/*  69 */   private final Object scriptClassMonitor = new Object();
/*     */ 
/*  71 */   private boolean wasModifiedForTypeCheck = false;
/*     */ 
/*     */   public GroovyScriptFactory(String scriptSourceLocator)
/*     */   {
/*  82 */     this(scriptSourceLocator, null);
/*     */   }
/*     */ 
/*     */   public GroovyScriptFactory(String scriptSourceLocator, GroovyObjectCustomizer groovyObjectCustomizer)
/*     */   {
/*  98 */     Assert.hasText(scriptSourceLocator, "'scriptSourceLocator' must not be empty");
/*  99 */     this.scriptSourceLocator = scriptSourceLocator;
/* 100 */     this.groovyObjectCustomizer = groovyObjectCustomizer;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */     throws BeansException
/*     */   {
/* 106 */     if ((beanFactory instanceof ConfigurableListableBeanFactory))
/* 107 */       ((ConfigurableListableBeanFactory)beanFactory).ignoreDependencyType(MetaClass.class);
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 113 */     this.groovyClassLoader = new GroovyClassLoader(classLoader);
/*     */   }
/*     */ 
/*     */   public GroovyClassLoader getGroovyClassLoader()
/*     */   {
/* 120 */     synchronized (this.scriptClassMonitor) {
/* 121 */       if (this.groovyClassLoader == null) {
/* 122 */         this.groovyClassLoader = new GroovyClassLoader(ClassUtils.getDefaultClassLoader());
/*     */       }
/* 124 */       return this.groovyClassLoader;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getScriptSourceLocator()
/*     */   {
/* 131 */     return this.scriptSourceLocator;
/*     */   }
/*     */ 
/*     */   public Class<?>[] getScriptInterfaces()
/*     */   {
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean requiresConfigInterface()
/*     */   {
/* 150 */     return false;
/*     */   }
/*     */ 
/*     */   public Object getScriptedObject(ScriptSource scriptSource, Class<?>[] actualInterfaces)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/*     */       Class scriptClassToExecute;
/* 165 */       synchronized (this.scriptClassMonitor) {
/* 166 */         this.wasModifiedForTypeCheck = false;
/*     */ 
/* 168 */         if (this.cachedResult != null) {
/* 169 */           Object result = this.cachedResult.object;
/* 170 */           this.cachedResult = null;
/* 171 */           return result;
/*     */         }
/*     */ 
/* 174 */         if ((this.scriptClass == null) || (scriptSource.isModified()))
/*     */         {
/* 176 */           this.scriptClass = getGroovyClassLoader().parseClass(scriptSource
/* 177 */             .getScriptAsString(), scriptSource.suggestedClassName());
/*     */ 
/* 179 */           if (Script.class.isAssignableFrom(this.scriptClass))
/*     */           {
/* 181 */             Object result = executeScript(scriptSource, this.scriptClass);
/* 182 */             this.scriptResultClass = (result != null ? result.getClass() : null);
/* 183 */             return result;
/*     */           }
/*     */ 
/* 186 */           this.scriptResultClass = this.scriptClass;
/*     */         }
/*     */ 
/* 189 */         scriptClassToExecute = this.scriptClass;
/*     */       }
/*     */ 
/* 193 */       return executeScript(scriptSource, scriptClassToExecute);
/*     */     }
/*     */     catch (CompilationFailedException ex) {
/* 196 */       throw new ScriptCompilationException(scriptSource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<?> getScriptedObjectType(ScriptSource scriptSource)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 205 */       synchronized (this.scriptClassMonitor) {
/* 206 */         if ((this.scriptClass == null) || (scriptSource.isModified()))
/*     */         {
/* 208 */           this.wasModifiedForTypeCheck = true;
/* 209 */           this.scriptClass = getGroovyClassLoader().parseClass(scriptSource
/* 210 */             .getScriptAsString(), scriptSource.suggestedClassName());
/*     */ 
/* 212 */           if (Script.class.isAssignableFrom(this.scriptClass))
/*     */           {
/* 214 */             Object result = executeScript(scriptSource, this.scriptClass);
/* 215 */             this.scriptResultClass = (result != null ? result.getClass() : null);
/* 216 */             this.cachedResult = new CachedResultHolder(result);
/*     */           }
/*     */           else {
/* 219 */             this.scriptResultClass = this.scriptClass;
/*     */           }
/*     */         }
/* 222 */         return this.scriptResultClass;
/*     */       }
/*     */     }
/*     */     catch (CompilationFailedException ex) {
/* 226 */       throw new ScriptCompilationException(scriptSource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean requiresScriptedObjectRefresh(ScriptSource scriptSource)
/*     */   {
/* 232 */     synchronized (this.scriptClassMonitor) {
/* 233 */       return (scriptSource.isModified()) || (this.wasModifiedForTypeCheck);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object executeScript(ScriptSource scriptSource, Class<?> scriptClass)
/*     */     throws ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 248 */       GroovyObject goo = (GroovyObject)scriptClass.newInstance();
/*     */ 
/* 250 */       if (this.groovyObjectCustomizer != null)
/*     */       {
/* 252 */         this.groovyObjectCustomizer.customize(goo);
/*     */       }
/*     */ 
/* 255 */       if ((goo instanceof Script))
/*     */       {
/* 257 */         return ((Script)goo).run();
/*     */       }
/*     */ 
/* 261 */       return goo;
/*     */     }
/*     */     catch (InstantiationException ex)
/*     */     {
/* 266 */       throw new ScriptCompilationException(scriptSource, "Could not instantiate Groovy script class: " + scriptClass
/* 266 */         .getName(), ex);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 270 */       throw new ScriptCompilationException(scriptSource, "Could not access Groovy script constructor: " + scriptClass
/* 270 */         .getName(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 277 */     return "GroovyScriptFactory: script source locator [" + this.scriptSourceLocator + "]";
/*     */   }
/*     */ 
/*     */   private static class CachedResultHolder
/*     */   {
/*     */     public final Object object;
/*     */ 
/*     */     public CachedResultHolder(Object object)
/*     */     {
/* 289 */       this.object = object;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.groovy.GroovyScriptFactory
 * JD-Core Version:    0.6.2
 */