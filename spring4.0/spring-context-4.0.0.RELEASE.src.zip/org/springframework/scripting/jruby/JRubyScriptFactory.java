/*     */ package org.springframework.scripting.jruby;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.jruby.RubyException;
/*     */ import org.jruby.exceptions.JumpException;
/*     */ import org.jruby.exceptions.RaiseException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.scripting.ScriptCompilationException;
/*     */ import org.springframework.scripting.ScriptFactory;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class JRubyScriptFactory
/*     */   implements ScriptFactory, BeanClassLoaderAware
/*     */ {
/*     */   private final String scriptSourceLocator;
/*     */   private final Class<?>[] scriptInterfaces;
/*  54 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */   public JRubyScriptFactory(String scriptSourceLocator, Class<?>[] scriptInterfaces)
/*     */   {
/*  65 */     Assert.hasText(scriptSourceLocator, "'scriptSourceLocator' must not be empty");
/*  66 */     Assert.notEmpty(scriptInterfaces, "'scriptInterfaces' must not be empty");
/*  67 */     this.scriptSourceLocator = scriptSourceLocator;
/*  68 */     this.scriptInterfaces = scriptInterfaces;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  74 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public String getScriptSourceLocator()
/*     */   {
/*  80 */     return this.scriptSourceLocator;
/*     */   }
/*     */ 
/*     */   public Class<?>[] getScriptInterfaces()
/*     */   {
/*  85 */     return this.scriptInterfaces;
/*     */   }
/*     */ 
/*     */   public boolean requiresConfigInterface()
/*     */   {
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */   public Object getScriptedObject(ScriptSource scriptSource, Class<?>[] actualInterfaces)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 104 */       return JRubyScriptUtils.createJRubyObject(scriptSource
/* 105 */         .getScriptAsString(), actualInterfaces, this.beanClassLoader);
/*     */     }
/*     */     catch (RaiseException ex) {
/* 108 */       RubyException rubyEx = ex.getException();
/*     */ 
/* 110 */       String msg = (rubyEx != null) && (rubyEx.message != null) ? rubyEx.message
/* 110 */         .toString() : "Unexpected JRuby error";
/* 111 */       throw new ScriptCompilationException(scriptSource, msg, ex);
/*     */     }
/*     */     catch (JumpException ex) {
/* 114 */       throw new ScriptCompilationException(scriptSource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<?> getScriptedObjectType(ScriptSource scriptSource)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean requiresScriptedObjectRefresh(ScriptSource scriptSource)
/*     */   {
/* 127 */     return scriptSource.isModified();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 133 */     return "JRubyScriptFactory: script source locator [" + this.scriptSourceLocator + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.jruby.JRubyScriptFactory
 * JD-Core Version:    0.6.2
 */