/*     */ package org.springframework.scripting.jruby;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.jruby.Ruby;
/*     */ import org.jruby.RubyArray;
/*     */ import org.jruby.RubyException;
/*     */ import org.jruby.RubyNil;
/*     */ import org.jruby.ast.ClassNode;
/*     */ import org.jruby.ast.Colon2Node;
/*     */ import org.jruby.ast.NewlineNode;
/*     */ import org.jruby.ast.Node;
/*     */ import org.jruby.exceptions.JumpException;
/*     */ import org.jruby.exceptions.RaiseException;
/*     */ import org.jruby.javasupport.JavaEmbedUtils;
/*     */ import org.jruby.runtime.builtin.IRubyObject;
/*     */ import org.springframework.core.NestedRuntimeException;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class JRubyScriptUtils
/*     */ {
/*     */   public static Object createJRubyObject(String scriptSource, Class<?>[] interfaces)
/*     */     throws JumpException
/*     */   {
/*  67 */     return createJRubyObject(scriptSource, interfaces, ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public static Object createJRubyObject(String scriptSource, Class<?>[] interfaces, ClassLoader classLoader)
/*     */   {
/*  79 */     Ruby ruby = initializeRuntime();
/*     */ 
/*  81 */     Node scriptRootNode = ruby.parseEval(scriptSource, "", null, 0);
/*  82 */     IRubyObject rubyObject = ruby.runNormally(scriptRootNode);
/*     */ 
/*  84 */     if ((rubyObject instanceof RubyNil)) {
/*  85 */       String className = findClassName(scriptRootNode);
/*  86 */       rubyObject = ruby.evalScriptlet("\n" + className + ".new");
/*     */     }
/*     */ 
/*  89 */     if ((rubyObject instanceof RubyNil)) {
/*  90 */       throw new IllegalStateException("Compilation of JRuby script returned RubyNil: " + rubyObject);
/*     */     }
/*     */ 
/*  93 */     return Proxy.newProxyInstance(classLoader, interfaces, new RubyObjectInvocationHandler(rubyObject, ruby));
/*     */   }
/*     */ 
/*     */   private static Ruby initializeRuntime()
/*     */   {
/* 100 */     return JavaEmbedUtils.initialize(Collections.EMPTY_LIST);
/*     */   }
/*     */ 
/*     */   private static String findClassName(Node rootNode)
/*     */   {
/* 109 */     ClassNode classNode = findClassNode(rootNode);
/* 110 */     if (classNode == null) {
/* 111 */       throw new IllegalArgumentException("Unable to determine class name for root node '" + rootNode + "'");
/*     */     }
/* 113 */     Colon2Node node = (Colon2Node)classNode.getCPath();
/* 114 */     return node.getName();
/*     */   }
/*     */ 
/*     */   private static ClassNode findClassNode(Node node)
/*     */   {
/* 123 */     if ((node instanceof ClassNode)) {
/* 124 */       return (ClassNode)node;
/*     */     }
/* 126 */     List children = node.childNodes();
/* 127 */     for (Node child : children) {
/* 128 */       if ((child instanceof ClassNode)) {
/* 129 */         return (ClassNode)child;
/*     */       }
/* 131 */       if ((child instanceof NewlineNode)) {
/* 132 */         NewlineNode nn = (NewlineNode)child;
/* 133 */         ClassNode found = findClassNode(nn.getNextNode());
/* 134 */         if (found != null) {
/* 135 */           return found;
/*     */         }
/*     */       }
/*     */     }
/* 139 */     for (Node child : children) {
/* 140 */       ClassNode found = findClassNode(child);
/* 141 */       if (found != null) {
/* 142 */         return found;
/*     */       }
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */   public static class JRubyExecutionException extends NestedRuntimeException
/*     */   {
/*     */     public JRubyExecutionException(RaiseException ex)
/*     */     {
/* 245 */       super(ex);
/*     */     }
/*     */ 
/*     */     private static String buildMessage(RaiseException ex) {
/* 249 */       RubyException rubyEx = ex.getException();
/* 250 */       return (rubyEx != null) && (rubyEx.message != null) ? rubyEx.message.toString() : "Unexpected JRuby error";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RubyObjectInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final IRubyObject rubyObject;
/*     */     private final Ruby ruby;
/*     */ 
/*     */     public RubyObjectInvocationHandler(IRubyObject rubyObject, Ruby ruby)
/*     */     {
/* 159 */       this.rubyObject = rubyObject;
/* 160 */       this.ruby = ruby;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */     {
/* 165 */       if (ReflectionUtils.isEqualsMethod(method)) {
/* 166 */         return Boolean.valueOf(isProxyForSameRubyObject(args[0]));
/*     */       }
/* 168 */       if (ReflectionUtils.isHashCodeMethod(method)) {
/* 169 */         return Integer.valueOf(this.rubyObject.hashCode());
/*     */       }
/* 171 */       if (ReflectionUtils.isToStringMethod(method)) {
/* 172 */         String toStringResult = this.rubyObject.toString();
/* 173 */         if (!StringUtils.hasText(toStringResult)) {
/* 174 */           toStringResult = ObjectUtils.identityToString(this.rubyObject);
/*     */         }
/* 176 */         return "JRuby object [" + toStringResult + "]";
/*     */       }
/*     */       try {
/* 179 */         IRubyObject[] rubyArgs = convertToRuby(args);
/*     */ 
/* 181 */         IRubyObject rubyResult = this.rubyObject
/* 181 */           .callMethod(this.ruby
/* 181 */           .getCurrentContext(), method.getName(), rubyArgs);
/* 182 */         return convertFromRuby(rubyResult, method.getReturnType());
/*     */       }
/*     */       catch (RaiseException ex) {
/* 185 */         throw new JRubyScriptUtils.JRubyExecutionException(ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     private boolean isProxyForSameRubyObject(Object other) {
/* 190 */       if (!Proxy.isProxyClass(other.getClass())) {
/* 191 */         return false;
/*     */       }
/* 193 */       InvocationHandler ih = Proxy.getInvocationHandler(other);
/*     */ 
/* 195 */       return ((ih instanceof RubyObjectInvocationHandler)) && 
/* 195 */         (this.rubyObject
/* 195 */         .equals(((RubyObjectInvocationHandler)ih).rubyObject));
/*     */     }
/*     */ 
/*     */     private IRubyObject[] convertToRuby(Object[] javaArgs)
/*     */     {
/* 199 */       if ((javaArgs == null) || (javaArgs.length == 0)) {
/* 200 */         return new IRubyObject[0];
/*     */       }
/* 202 */       IRubyObject[] rubyArgs = new IRubyObject[javaArgs.length];
/* 203 */       for (int i = 0; i < javaArgs.length; i++) {
/* 204 */         rubyArgs[i] = JavaEmbedUtils.javaToRuby(this.ruby, javaArgs[i]);
/*     */       }
/* 206 */       return rubyArgs;
/*     */     }
/*     */ 
/*     */     private Object convertFromRuby(IRubyObject rubyResult, Class<?> returnType) {
/* 210 */       Object result = JavaEmbedUtils.rubyToJava(this.ruby, rubyResult, returnType);
/* 211 */       if (((result instanceof RubyArray)) && (returnType.isArray())) {
/* 212 */         result = convertFromRubyArray(((RubyArray)result).toJavaArray(), returnType);
/*     */       }
/* 214 */       return result;
/*     */     }
/*     */ 
/*     */     private Object convertFromRubyArray(IRubyObject[] rubyArray, Class<?> returnType) {
/* 218 */       Class targetType = returnType.getComponentType();
/* 219 */       Object javaArray = Array.newInstance(targetType, rubyArray.length);
/* 220 */       for (int i = 0; i < rubyArray.length; i++) {
/* 221 */         IRubyObject rubyObject = rubyArray[i];
/* 222 */         Array.set(javaArray, i, convertFromRuby(rubyObject, targetType));
/*     */       }
/* 224 */       return javaArray;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.jruby.JRubyScriptUtils
 * JD-Core Version:    0.6.2
 */