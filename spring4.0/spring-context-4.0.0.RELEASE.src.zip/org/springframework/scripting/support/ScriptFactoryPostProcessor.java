/*     */ package org.springframework.scripting.support;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.support.DelegatingIntroductionInterceptor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionValidationException;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.proxy.InterfaceMaker;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.scripting.ScriptFactory;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ScriptFactoryPostProcessor extends InstantiationAwareBeanPostProcessorAdapter
/*     */   implements BeanClassLoaderAware, BeanFactoryAware, ResourceLoaderAware, DisposableBean, Ordered
/*     */ {
/*     */   public static final String INLINE_SCRIPT_PREFIX = "inline:";
/* 152 */   public static final String REFRESH_CHECK_DELAY_ATTRIBUTE = Conventions.getQualifiedAttributeName(ScriptFactoryPostProcessor.class, "refreshCheckDelay");
/*     */ 
/* 155 */   public static final String PROXY_TARGET_CLASS_ATTRIBUTE = Conventions.getQualifiedAttributeName(ScriptFactoryPostProcessor.class, "proxyTargetClass");
/*     */ 
/* 158 */   public static final String LANGUAGE_ATTRIBUTE = Conventions.getQualifiedAttributeName(ScriptFactoryPostProcessor.class, "language");
/*     */   private static final String SCRIPT_FACTORY_NAME_PREFIX = "scriptFactory.";
/*     */   private static final String SCRIPTED_OBJECT_NAME_PREFIX = "scriptedObject.";
/* 166 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/* 168 */   private long defaultRefreshCheckDelay = -1L;
/*     */ 
/* 170 */   private boolean defaultProxyTargetClass = false;
/*     */ 
/* 172 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   private ConfigurableBeanFactory beanFactory;
/* 176 */   private ResourceLoader resourceLoader = new DefaultResourceLoader();
/*     */ 
/* 178 */   final DefaultListableBeanFactory scriptBeanFactory = new DefaultListableBeanFactory();
/*     */ 
/* 181 */   private final Map<String, ScriptSource> scriptSourceCache = new HashMap();
/*     */ 
/*     */   public void setDefaultRefreshCheckDelay(long defaultRefreshCheckDelay)
/*     */   {
/* 192 */     this.defaultRefreshCheckDelay = defaultRefreshCheckDelay;
/*     */   }
/*     */ 
/*     */   public void setDefaultProxyTargetClass(boolean defaultProxyTargetClass)
/*     */   {
/* 200 */     this.defaultProxyTargetClass = defaultProxyTargetClass;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 205 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 210 */     if (!(beanFactory instanceof ConfigurableBeanFactory))
/*     */     {
/* 212 */       throw new IllegalStateException("ScriptFactoryPostProcessor doesn't work with a BeanFactory which does not implement ConfigurableBeanFactory: " + beanFactory
/* 212 */         .getClass());
/*     */     }
/* 214 */     this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*     */ 
/* 217 */     this.scriptBeanFactory.setParentBeanFactory(this.beanFactory);
/*     */ 
/* 220 */     this.scriptBeanFactory.copyConfigurationFrom(this.beanFactory);
/*     */ 
/* 224 */     for (Iterator it = this.scriptBeanFactory.getBeanPostProcessors().iterator(); it.hasNext(); )
/* 225 */       if ((it.next() instanceof AopInfrastructureBean))
/* 226 */         it.remove();
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 233 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 238 */     return -2147483648;
/*     */   }
/*     */ 
/*     */   public Class<?> predictBeanType(Class<?> beanClass, String beanName)
/*     */   {
/* 244 */     if (!ScriptFactory.class.isAssignableFrom(beanClass)) {
/* 245 */       return null;
/*     */     }
/*     */ 
/* 248 */     BeanDefinition bd = this.beanFactory.getMergedBeanDefinition(beanName);
/*     */     try
/*     */     {
/* 251 */       String scriptFactoryBeanName = "scriptFactory." + beanName;
/* 252 */       String scriptedObjectBeanName = "scriptedObject." + beanName;
/* 253 */       prepareScriptBeans(bd, scriptFactoryBeanName, scriptedObjectBeanName);
/*     */ 
/* 255 */       ScriptFactory scriptFactory = (ScriptFactory)this.scriptBeanFactory.getBean(scriptFactoryBeanName, ScriptFactory.class);
/* 256 */       ScriptSource scriptSource = getScriptSource(scriptFactoryBeanName, scriptFactory.getScriptSourceLocator());
/* 257 */       Class[] interfaces = scriptFactory.getScriptInterfaces();
/*     */ 
/* 259 */       Class scriptedType = scriptFactory.getScriptedObjectType(scriptSource);
/* 260 */       if (scriptedType != null)
/* 261 */         return scriptedType;
/* 262 */       if (!ObjectUtils.isEmpty(interfaces)) {
/* 263 */         return interfaces.length == 1 ? interfaces[0] : createCompositeInterface(interfaces);
/*     */       }
/* 265 */       if (bd.isSingleton()) {
/* 266 */         Object bean = this.scriptBeanFactory.getBean(scriptedObjectBeanName);
/* 267 */         if (bean != null)
/* 268 */           return bean.getClass();
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 273 */       if (((ex instanceof BeanCreationException)) && 
/* 274 */         ((((BeanCreationException)ex)
/* 274 */         .getMostSpecificCause() instanceof BeanCurrentlyInCreationException))) {
/* 275 */         if (this.logger.isTraceEnabled()) {
/* 276 */           this.logger.trace("Could not determine scripted object type for bean '" + beanName + "': " + ex
/* 277 */             .getMessage());
/*     */         }
/*     */       }
/* 280 */       else if (this.logger.isDebugEnabled()) {
/* 281 */         this.logger.debug("Could not determine scripted object type for bean '" + beanName + "'", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName)
/*     */   {
/* 292 */     if (!ScriptFactory.class.isAssignableFrom(beanClass)) {
/* 293 */       return null;
/*     */     }
/*     */ 
/* 296 */     BeanDefinition bd = this.beanFactory.getMergedBeanDefinition(beanName);
/* 297 */     String scriptFactoryBeanName = "scriptFactory." + beanName;
/* 298 */     String scriptedObjectBeanName = "scriptedObject." + beanName;
/* 299 */     prepareScriptBeans(bd, scriptFactoryBeanName, scriptedObjectBeanName);
/*     */ 
/* 301 */     ScriptFactory scriptFactory = (ScriptFactory)this.scriptBeanFactory.getBean(scriptFactoryBeanName, ScriptFactory.class);
/* 302 */     ScriptSource scriptSource = getScriptSource(scriptFactoryBeanName, scriptFactory.getScriptSourceLocator());
/* 303 */     boolean isFactoryBean = false;
/*     */     try {
/* 305 */       Class scriptedObjectType = scriptFactory.getScriptedObjectType(scriptSource);
/*     */ 
/* 307 */       if (scriptedObjectType != null)
/* 308 */         isFactoryBean = FactoryBean.class.isAssignableFrom(scriptedObjectType);
/*     */     }
/*     */     catch (Exception ex) {
/* 311 */       throw new BeanCreationException(beanName, "Could not determine scripted object type for " + scriptFactory, ex);
/*     */     }
/*     */ 
/* 315 */     long refreshCheckDelay = resolveRefreshCheckDelay(bd);
/* 316 */     if (refreshCheckDelay >= 0L) {
/* 317 */       Class[] interfaces = scriptFactory.getScriptInterfaces();
/* 318 */       RefreshableScriptTargetSource ts = new RefreshableScriptTargetSource(this.scriptBeanFactory, scriptedObjectBeanName, scriptFactory, scriptSource, isFactoryBean);
/*     */ 
/* 320 */       boolean proxyTargetClass = resolveProxyTargetClass(bd);
/* 321 */       String language = (String)bd.getAttribute(LANGUAGE_ATTRIBUTE);
/* 322 */       if ((proxyTargetClass) && ((language == null) || (!language.equals("groovy")))) {
/* 323 */         throw new BeanDefinitionValidationException("Cannot use proxyTargetClass=true with script beans where language is not groovy (found " + language + ")");
/*     */       }
/*     */ 
/* 327 */       ts.setRefreshCheckDelay(refreshCheckDelay);
/* 328 */       return createRefreshableProxy(ts, interfaces, proxyTargetClass);
/*     */     }
/*     */ 
/* 331 */     if (isFactoryBean) {
/* 332 */       scriptedObjectBeanName = "&" + scriptedObjectBeanName;
/*     */     }
/* 334 */     return this.scriptBeanFactory.getBean(scriptedObjectBeanName);
/*     */   }
/*     */ 
/*     */   protected void prepareScriptBeans(BeanDefinition bd, String scriptFactoryBeanName, String scriptedObjectBeanName)
/*     */   {
/* 348 */     synchronized (this.scriptBeanFactory) {
/* 349 */       if (!this.scriptBeanFactory.containsBeanDefinition(scriptedObjectBeanName))
/*     */       {
/* 351 */         this.scriptBeanFactory.registerBeanDefinition(scriptFactoryBeanName, 
/* 352 */           createScriptFactoryBeanDefinition(bd));
/*     */ 
/* 354 */         ScriptFactory scriptFactory = (ScriptFactory)this.scriptBeanFactory
/* 354 */           .getBean(scriptFactoryBeanName, ScriptFactory.class);
/*     */ 
/* 355 */         ScriptSource scriptSource = getScriptSource(scriptFactoryBeanName, scriptFactory
/* 356 */           .getScriptSourceLocator());
/* 357 */         Class[] interfaces = scriptFactory.getScriptInterfaces();
/*     */ 
/* 359 */         Class[] scriptedInterfaces = interfaces;
/* 360 */         if ((scriptFactory.requiresConfigInterface()) && (!bd.getPropertyValues().isEmpty())) {
/* 361 */           Class configInterface = createConfigInterface(bd, interfaces);
/* 362 */           scriptedInterfaces = (Class[])ObjectUtils.addObjectToArray(interfaces, configInterface);
/*     */         }
/*     */ 
/* 365 */         BeanDefinition objectBd = createScriptedObjectBeanDefinition(bd, scriptFactoryBeanName, scriptSource, scriptedInterfaces);
/*     */ 
/* 367 */         long refreshCheckDelay = resolveRefreshCheckDelay(bd);
/* 368 */         if (refreshCheckDelay >= 0L) {
/* 369 */           objectBd.setScope("prototype");
/*     */         }
/*     */ 
/* 372 */         this.scriptBeanFactory.registerBeanDefinition(scriptedObjectBeanName, objectBd);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected long resolveRefreshCheckDelay(BeanDefinition beanDefinition)
/*     */   {
/* 388 */     long refreshCheckDelay = this.defaultRefreshCheckDelay;
/* 389 */     Object attributeValue = beanDefinition.getAttribute(REFRESH_CHECK_DELAY_ATTRIBUTE);
/* 390 */     if ((attributeValue instanceof Number))
/* 391 */       refreshCheckDelay = ((Number)attributeValue).longValue();
/* 392 */     else if ((attributeValue instanceof String))
/* 393 */       refreshCheckDelay = Long.parseLong((String)attributeValue);
/* 394 */     else if (attributeValue != null) {
/* 395 */       throw new BeanDefinitionStoreException("Invalid refresh check delay attribute [" + REFRESH_CHECK_DELAY_ATTRIBUTE + "] with value [" + attributeValue + "]: needs to be of type Number or String");
/*     */     }
/*     */ 
/* 399 */     return refreshCheckDelay;
/*     */   }
/*     */ 
/*     */   protected boolean resolveProxyTargetClass(BeanDefinition beanDefinition) {
/* 403 */     boolean proxyTargetClass = this.defaultProxyTargetClass;
/* 404 */     Object attributeValue = beanDefinition.getAttribute(PROXY_TARGET_CLASS_ATTRIBUTE);
/* 405 */     if ((attributeValue instanceof Boolean))
/* 406 */       proxyTargetClass = ((Boolean)attributeValue).booleanValue();
/* 407 */     else if ((attributeValue instanceof String))
/* 408 */       proxyTargetClass = new Boolean((String)attributeValue).booleanValue();
/* 409 */     else if (attributeValue != null) {
/* 410 */       throw new BeanDefinitionStoreException("Invalid refresh check delay attribute [" + REFRESH_CHECK_DELAY_ATTRIBUTE + "] with value [" + attributeValue + "]: needs to be of type Number or String");
/*     */     }
/*     */ 
/* 414 */     return proxyTargetClass;
/*     */   }
/*     */ 
/*     */   protected BeanDefinition createScriptFactoryBeanDefinition(BeanDefinition bd)
/*     */   {
/* 426 */     GenericBeanDefinition scriptBd = new GenericBeanDefinition();
/* 427 */     scriptBd.setBeanClassName(bd.getBeanClassName());
/* 428 */     scriptBd.getConstructorArgumentValues().addArgumentValues(bd.getConstructorArgumentValues());
/* 429 */     return scriptBd;
/*     */   }
/*     */ 
/*     */   protected ScriptSource getScriptSource(String beanName, String scriptSourceLocator)
/*     */   {
/* 441 */     synchronized (this.scriptSourceCache) {
/* 442 */       ScriptSource scriptSource = (ScriptSource)this.scriptSourceCache.get(beanName);
/* 443 */       if (scriptSource == null) {
/* 444 */         scriptSource = convertToScriptSource(beanName, scriptSourceLocator, this.resourceLoader);
/* 445 */         this.scriptSourceCache.put(beanName, scriptSource);
/*     */       }
/* 447 */       return scriptSource;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ScriptSource convertToScriptSource(String beanName, String scriptSourceLocator, ResourceLoader resourceLoader)
/*     */   {
/* 464 */     if (scriptSourceLocator.startsWith("inline:")) {
/* 465 */       return new StaticScriptSource(scriptSourceLocator.substring("inline:".length()), beanName);
/*     */     }
/* 467 */     return new ResourceScriptSource(resourceLoader.getResource(scriptSourceLocator));
/*     */   }
/*     */ 
/*     */   protected Class<?> createConfigInterface(BeanDefinition bd, Class<?>[] interfaces)
/*     */   {
/* 486 */     InterfaceMaker maker = new InterfaceMaker();
/* 487 */     PropertyValue[] pvs = bd.getPropertyValues().getPropertyValues();
/* 488 */     for (PropertyValue pv : pvs) {
/* 489 */       String propertyName = pv.getName();
/* 490 */       Class propertyType = BeanUtils.findPropertyType(propertyName, interfaces);
/* 491 */       String setterName = "set" + StringUtils.capitalize(propertyName);
/* 492 */       Signature signature = new Signature(setterName, Type.VOID_TYPE, new Type[] { Type.getType(propertyType) });
/* 493 */       maker.add(signature, new Type[0]);
/*     */     }
/* 495 */     if ((bd instanceof AbstractBeanDefinition)) {
/* 496 */       AbstractBeanDefinition abd = (AbstractBeanDefinition)bd;
/* 497 */       if (abd.getInitMethodName() != null) {
/* 498 */         Signature signature = new Signature(abd.getInitMethodName(), Type.VOID_TYPE, new Type[0]);
/* 499 */         maker.add(signature, new Type[0]);
/*     */       }
/* 501 */       if (abd.getDestroyMethodName() != null) {
/* 502 */         Signature signature = new Signature(abd.getDestroyMethodName(), Type.VOID_TYPE, new Type[0]);
/* 503 */         maker.add(signature, new Type[0]);
/*     */       }
/*     */     }
/* 506 */     return maker.create();
/*     */   }
/*     */ 
/*     */   protected Class<?> createCompositeInterface(Class<?>[] interfaces)
/*     */   {
/* 519 */     return ClassUtils.createCompositeInterface(interfaces, this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   protected BeanDefinition createScriptedObjectBeanDefinition(BeanDefinition bd, String scriptFactoryBeanName, ScriptSource scriptSource, Class<?>[] interfaces)
/*     */   {
/* 536 */     GenericBeanDefinition objectBd = new GenericBeanDefinition(bd);
/* 537 */     objectBd.setFactoryBeanName(scriptFactoryBeanName);
/* 538 */     objectBd.setFactoryMethodName("getScriptedObject");
/* 539 */     objectBd.getConstructorArgumentValues().clear();
/* 540 */     objectBd.getConstructorArgumentValues().addIndexedArgumentValue(0, scriptSource);
/* 541 */     objectBd.getConstructorArgumentValues().addIndexedArgumentValue(1, interfaces);
/* 542 */     return objectBd;
/*     */   }
/*     */ 
/*     */   protected Object createRefreshableProxy(TargetSource ts, Class<?>[] interfaces, boolean proxyTargetClass)
/*     */   {
/* 554 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 555 */     proxyFactory.setTargetSource(ts);
/* 556 */     ClassLoader classLoader = this.beanClassLoader;
/*     */ 
/* 558 */     if (interfaces == null) {
/* 559 */       interfaces = ClassUtils.getAllInterfacesForClass(ts.getTargetClass(), this.beanClassLoader);
/*     */     }
/* 561 */     proxyFactory.setInterfaces(interfaces);
/* 562 */     if (proxyTargetClass) {
/* 563 */       classLoader = null;
/* 564 */       proxyFactory.setProxyTargetClass(proxyTargetClass);
/*     */     }
/*     */ 
/* 567 */     DelegatingIntroductionInterceptor introduction = new DelegatingIntroductionInterceptor(ts);
/* 568 */     introduction.suppressInterface(TargetSource.class);
/* 569 */     proxyFactory.addAdvice(introduction);
/*     */ 
/* 571 */     return proxyFactory.getProxy(classLoader);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 579 */     this.scriptBeanFactory.destroySingletons();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.support.ScriptFactoryPostProcessor
 * JD-Core Version:    0.6.2
 */