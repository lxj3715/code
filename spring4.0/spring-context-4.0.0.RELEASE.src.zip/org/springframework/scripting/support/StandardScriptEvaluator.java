/*     */ package org.springframework.scripting.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.script.Bindings;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.ScriptException;
/*     */ import javax.script.SimpleBindings;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.scripting.ScriptCompilationException;
/*     */ import org.springframework.scripting.ScriptEvaluator;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class StandardScriptEvaluator
/*     */   implements ScriptEvaluator, BeanClassLoaderAware
/*     */ {
/*     */   private volatile ScriptEngineManager scriptEngineManager;
/*     */   private String language;
/*     */ 
/*     */   public StandardScriptEvaluator()
/*     */   {
/*     */   }
/*     */ 
/*     */   public StandardScriptEvaluator(ClassLoader classLoader)
/*     */   {
/*  62 */     this.scriptEngineManager = new ScriptEngineManager(classLoader);
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  68 */     this.scriptEngineManager = new ScriptEngineManager(classLoader);
/*     */   }
/*     */ 
/*     */   public void setLanguage(String language)
/*     */   {
/*  75 */     this.language = language;
/*     */   }
/*     */ 
/*     */   public Object evaluate(ScriptSource script)
/*     */   {
/*  81 */     return evaluate(script, null);
/*     */   }
/*     */ 
/*     */   public Object evaluate(ScriptSource script, Map<String, Object> arguments)
/*     */   {
/*  86 */     ScriptEngine engine = getScriptEngine(script);
/*  87 */     Bindings bindings = !CollectionUtils.isEmpty(arguments) ? new SimpleBindings(arguments) : null;
/*     */     try
/*     */     {
/*  90 */       return bindings != null ? engine.eval(script.getScriptAsString(), bindings) : engine
/*  90 */         .eval(script
/*  90 */         .getScriptAsString());
/*     */     }
/*     */     catch (IOException ex) {
/*  93 */       throw new ScriptCompilationException(script, "Cannot access script", ex);
/*     */     }
/*     */     catch (ScriptException ex) {
/*  96 */       throw new ScriptCompilationException(script, "Evaluation failure", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ScriptEngine getScriptEngine(ScriptSource script)
/*     */   {
/* 106 */     if (this.scriptEngineManager == null) {
/* 107 */       this.scriptEngineManager = new ScriptEngineManager();
/*     */     }
/* 109 */     if (StringUtils.hasText(this.language)) {
/* 110 */       ScriptEngine engine = this.scriptEngineManager.getEngineByName(this.language);
/* 111 */       if (engine == null) {
/* 112 */         throw new IllegalStateException("No matching engine found for language '" + this.language + "'");
/*     */       }
/* 114 */       return engine;
/*     */     }
/* 116 */     if ((script instanceof ResourceScriptSource)) {
/* 117 */       Resource resource = ((ResourceScriptSource)script).getResource();
/* 118 */       String extension = StringUtils.getFilenameExtension(resource.getFilename());
/* 119 */       if (extension == null) {
/* 120 */         throw new IllegalStateException("No script language defined, and no file extension defined for resource: " + resource);
/*     */       }
/*     */ 
/* 123 */       ScriptEngine engine = this.scriptEngineManager.getEngineByExtension(extension);
/* 124 */       if (engine == null) {
/* 125 */         throw new IllegalStateException("No matching engine found for file extension '" + extension + "'");
/*     */       }
/* 127 */       return engine;
/*     */     }
/*     */ 
/* 130 */     throw new IllegalStateException("No script language defined, and no resource associated with script: " + script);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.support.StandardScriptEvaluator
 * JD-Core Version:    0.6.2
 */