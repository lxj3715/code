package org.springframework.ui;

import java.util.Collection;
import java.util.Map;

public abstract interface Model
{
  public abstract Model addAttribute(String paramString, Object paramObject);

  public abstract Model addAttribute(Object paramObject);

  public abstract Model addAllAttributes(Collection<?> paramCollection);

  public abstract Model addAllAttributes(Map<String, ?> paramMap);

  public abstract Model mergeAttributes(Map<String, ?> paramMap);

  public abstract boolean containsAttribute(String paramString);

  public abstract Map<String, Object> asMap();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.ui.Model
 * JD-Core Version:    0.6.2
 */