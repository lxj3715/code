package org.springframework.ui.context;

public abstract interface HierarchicalThemeSource extends ThemeSource
{
  public abstract void setParentThemeSource(ThemeSource paramThemeSource);

  public abstract ThemeSource getParentThemeSource();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.HierarchicalThemeSource
 * JD-Core Version:    0.6.2
 */