package org.springframework.ui.context;

import org.springframework.context.MessageSource;

public abstract interface Theme
{
  public abstract String getName();

  public abstract MessageSource getMessageSource();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.Theme
 * JD-Core Version:    0.6.2
 */