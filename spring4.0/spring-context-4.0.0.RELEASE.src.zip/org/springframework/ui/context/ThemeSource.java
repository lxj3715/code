package org.springframework.ui.context;

public abstract interface ThemeSource
{
  public abstract Theme getTheme(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.ThemeSource
 * JD-Core Version:    0.6.2
 */