/*    */ package org.springframework.ui.context.support;
/*    */ 
/*    */ import org.springframework.ui.context.HierarchicalThemeSource;
/*    */ import org.springframework.ui.context.Theme;
/*    */ import org.springframework.ui.context.ThemeSource;
/*    */ 
/*    */ public class DelegatingThemeSource
/*    */   implements HierarchicalThemeSource
/*    */ {
/*    */   private ThemeSource parentThemeSource;
/*    */ 
/*    */   public void setParentThemeSource(ThemeSource parentThemeSource)
/*    */   {
/* 41 */     this.parentThemeSource = parentThemeSource;
/*    */   }
/*    */ 
/*    */   public ThemeSource getParentThemeSource()
/*    */   {
/* 46 */     return this.parentThemeSource;
/*    */   }
/*    */ 
/*    */   public Theme getTheme(String themeName)
/*    */   {
/* 52 */     if (this.parentThemeSource != null) {
/* 53 */       return this.parentThemeSource.getTheme(themeName);
/*    */     }
/*    */ 
/* 56 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.support.DelegatingThemeSource
 * JD-Core Version:    0.6.2
 */