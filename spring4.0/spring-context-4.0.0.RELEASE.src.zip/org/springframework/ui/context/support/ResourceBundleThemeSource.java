/*     */ package org.springframework.ui.context.support;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.HierarchicalMessageSource;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.support.ResourceBundleMessageSource;
/*     */ import org.springframework.ui.context.HierarchicalThemeSource;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ 
/*     */ public class ResourceBundleThemeSource
/*     */   implements HierarchicalThemeSource
/*     */ {
/*  46 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private ThemeSource parentThemeSource;
/*  50 */   private String basenamePrefix = "";
/*     */ 
/*  53 */   private final Map<String, Theme> themeCache = new HashMap();
/*     */ 
/*     */   public void setParentThemeSource(ThemeSource parent)
/*     */   {
/*  58 */     this.parentThemeSource = parent;
/*     */ 
/*  62 */     synchronized (this.themeCache) {
/*  63 */       for (Theme theme : this.themeCache.values())
/*  64 */         initParent(theme);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ThemeSource getParentThemeSource()
/*     */   {
/*  71 */     return this.parentThemeSource;
/*     */   }
/*     */ 
/*     */   public void setBasenamePrefix(String basenamePrefix)
/*     */   {
/*  85 */     this.basenamePrefix = (basenamePrefix != null ? basenamePrefix : "");
/*     */   }
/*     */ 
/*     */   public Theme getTheme(String themeName)
/*     */   {
/* 100 */     if (themeName == null) {
/* 101 */       return null;
/*     */     }
/* 103 */     synchronized (this.themeCache) {
/* 104 */       Theme theme = (Theme)this.themeCache.get(themeName);
/* 105 */       if (theme == null) {
/* 106 */         String basename = this.basenamePrefix + themeName;
/* 107 */         MessageSource messageSource = createMessageSource(basename);
/* 108 */         theme = new SimpleTheme(themeName, messageSource);
/* 109 */         initParent(theme);
/* 110 */         this.themeCache.put(themeName, theme);
/* 111 */         if (this.logger.isDebugEnabled()) {
/* 112 */           this.logger.debug("Theme created: name '" + themeName + "', basename [" + basename + "]");
/*     */         }
/*     */       }
/* 115 */       return theme;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected MessageSource createMessageSource(String basename)
/*     */   {
/* 131 */     ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
/* 132 */     messageSource.setBasename(basename);
/* 133 */     return messageSource;
/*     */   }
/*     */ 
/*     */   protected void initParent(Theme theme)
/*     */   {
/* 142 */     if ((theme.getMessageSource() instanceof HierarchicalMessageSource)) {
/* 143 */       HierarchicalMessageSource messageSource = (HierarchicalMessageSource)theme.getMessageSource();
/* 144 */       if ((getParentThemeSource() != null) && (messageSource.getParentMessageSource() == null)) {
/* 145 */         Theme parentTheme = getParentThemeSource().getTheme(theme.getName());
/* 146 */         if (parentTheme != null)
/* 147 */           messageSource.setParentMessageSource(parentTheme.getMessageSource());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.support.ResourceBundleThemeSource
 * JD-Core Version:    0.6.2
 */