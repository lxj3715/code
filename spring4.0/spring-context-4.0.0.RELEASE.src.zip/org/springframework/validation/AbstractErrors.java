/*     */ package org.springframework.validation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractErrors
/*     */   implements Errors, Serializable
/*     */ {
/*  39 */   private String nestedPath = "";
/*     */ 
/*  41 */   private final Stack<String> nestedPathStack = new Stack();
/*     */ 
/*     */   public void setNestedPath(String nestedPath)
/*     */   {
/*  46 */     doSetNestedPath(nestedPath);
/*  47 */     this.nestedPathStack.clear();
/*     */   }
/*     */ 
/*     */   public String getNestedPath()
/*     */   {
/*  52 */     return this.nestedPath;
/*     */   }
/*     */ 
/*     */   public void pushNestedPath(String subPath)
/*     */   {
/*  57 */     this.nestedPathStack.push(getNestedPath());
/*  58 */     doSetNestedPath(new StringBuilder().append(getNestedPath()).append(subPath).toString());
/*     */   }
/*     */ 
/*     */   public void popNestedPath() throws IllegalArgumentException
/*     */   {
/*     */     try {
/*  64 */       String formerNestedPath = (String)this.nestedPathStack.pop();
/*  65 */       doSetNestedPath(formerNestedPath);
/*     */     }
/*     */     catch (EmptyStackException ex) {
/*  68 */       throw new IllegalStateException("Cannot pop nested path: no nested path on stack");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doSetNestedPath(String nestedPath)
/*     */   {
/*  77 */     if (nestedPath == null) {
/*  78 */       nestedPath = "";
/*     */     }
/*  80 */     nestedPath = canonicalFieldName(nestedPath);
/*  81 */     if ((nestedPath.length() > 0) && (!nestedPath.endsWith("."))) {
/*  82 */       nestedPath = new StringBuilder().append(nestedPath).append(".").toString();
/*     */     }
/*  84 */     this.nestedPath = nestedPath;
/*     */   }
/*     */ 
/*     */   protected String fixedField(String field)
/*     */   {
/*  92 */     if (StringUtils.hasLength(field)) {
/*  93 */       return new StringBuilder().append(getNestedPath()).append(canonicalFieldName(field)).toString();
/*     */     }
/*     */ 
/*  96 */     String path = getNestedPath();
/*     */ 
/*  98 */     return path.endsWith(".") ? path
/*  98 */       .substring(0, path
/*  98 */       .length() - ".".length()) : path;
/*     */   }
/*     */ 
/*     */   protected String canonicalFieldName(String field)
/*     */   {
/* 109 */     return field;
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode)
/*     */   {
/* 115 */     reject(errorCode, null, null);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, String defaultMessage)
/*     */   {
/* 120 */     reject(errorCode, null, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode)
/*     */   {
/* 125 */     rejectValue(field, errorCode, null, null);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, String defaultMessage)
/*     */   {
/* 130 */     rejectValue(field, errorCode, null, defaultMessage);
/*     */   }
/*     */ 
/*     */   public boolean hasErrors()
/*     */   {
/* 136 */     return !getAllErrors().isEmpty();
/*     */   }
/*     */ 
/*     */   public int getErrorCount()
/*     */   {
/* 141 */     return getAllErrors().size();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getAllErrors()
/*     */   {
/* 146 */     List result = new LinkedList();
/* 147 */     result.addAll(getGlobalErrors());
/* 148 */     result.addAll(getFieldErrors());
/* 149 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public boolean hasGlobalErrors()
/*     */   {
/* 154 */     return getGlobalErrorCount() > 0;
/*     */   }
/*     */ 
/*     */   public int getGlobalErrorCount()
/*     */   {
/* 159 */     return getGlobalErrors().size();
/*     */   }
/*     */ 
/*     */   public ObjectError getGlobalError()
/*     */   {
/* 164 */     List globalErrors = getGlobalErrors();
/* 165 */     return !globalErrors.isEmpty() ? (ObjectError)globalErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors()
/*     */   {
/* 170 */     return getFieldErrorCount() > 0;
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount()
/*     */   {
/* 175 */     return getFieldErrors().size();
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError()
/*     */   {
/* 180 */     List fieldErrors = getFieldErrors();
/* 181 */     return !fieldErrors.isEmpty() ? (FieldError)fieldErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors(String field)
/*     */   {
/* 186 */     return getFieldErrorCount(field) > 0;
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount(String field)
/*     */   {
/* 191 */     return getFieldErrors(field).size();
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors(String field)
/*     */   {
/* 196 */     List fieldErrors = getFieldErrors();
/* 197 */     List result = new LinkedList();
/* 198 */     String fixedField = fixedField(field);
/* 199 */     for (FieldError error : fieldErrors) {
/* 200 */       if (isMatchingFieldError(fixedField, error)) {
/* 201 */         result.add(error);
/*     */       }
/*     */     }
/* 204 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError(String field)
/*     */   {
/* 209 */     List fieldErrors = getFieldErrors(field);
/* 210 */     return !fieldErrors.isEmpty() ? (FieldError)fieldErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public Class<?> getFieldType(String field)
/*     */   {
/* 216 */     Object value = getFieldValue(field);
/* 217 */     if (value != null) {
/* 218 */       return value.getClass();
/*     */     }
/* 220 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean isMatchingFieldError(String field, FieldError fieldError)
/*     */   {
/* 231 */     return (field.equals(fieldError.getField())) || (
/* 231 */       (field
/* 231 */       .endsWith("*")) && 
/* 231 */       (fieldError.getField().startsWith(field.substring(0, field.length() - 1))));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 237 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 238 */     sb.append(": ").append(getErrorCount()).append(" errors");
/* 239 */     for (ObjectError error : getAllErrors()) {
/* 240 */       sb.append('\n').append(error);
/*     */     }
/* 242 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.AbstractErrors
 * JD-Core Version:    0.6.2
 */