package org.springframework.validation;

import org.springframework.beans.PropertyAccessException;

public abstract interface BindingErrorProcessor
{
  public abstract void processMissingFieldError(String paramString, BindingResult paramBindingResult);

  public abstract void processPropertyAccessException(PropertyAccessException paramPropertyAccessException, BindingResult paramBindingResult);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.BindingErrorProcessor
 * JD-Core Version:    0.6.2
 */