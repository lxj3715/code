/*     */ package org.springframework.validation;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConfigurablePropertyAccessor;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyAccessException;
/*     */ import org.springframework.beans.PropertyAccessorUtils;
/*     */ import org.springframework.beans.PropertyBatchUpdateException;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class DataBinder
/*     */   implements PropertyEditorRegistry, TypeConverter
/*     */ {
/*     */   public static final String DEFAULT_OBJECT_NAME = "target";
/*     */   public static final int DEFAULT_AUTO_GROW_COLLECTION_LIMIT = 256;
/* 120 */   protected static final Log logger = LogFactory.getLog(DataBinder.class);
/*     */   private final Object target;
/*     */   private final String objectName;
/*     */   private AbstractPropertyBindingResult bindingResult;
/*     */   private SimpleTypeConverter typeConverter;
/* 130 */   private boolean ignoreUnknownFields = true;
/*     */ 
/* 132 */   private boolean ignoreInvalidFields = false;
/*     */ 
/* 134 */   private boolean autoGrowNestedPaths = true;
/*     */ 
/* 136 */   private int autoGrowCollectionLimit = 256;
/*     */   private String[] allowedFields;
/*     */   private String[] disallowedFields;
/*     */   private String[] requiredFields;
/* 144 */   private BindingErrorProcessor bindingErrorProcessor = new DefaultBindingErrorProcessor();
/*     */ 
/* 146 */   private final List<Validator> validators = new ArrayList();
/*     */   private ConversionService conversionService;
/*     */ 
/*     */   public DataBinder(Object target)
/*     */   {
/* 158 */     this(target, "target");
/*     */   }
/*     */ 
/*     */   public DataBinder(Object target, String objectName)
/*     */   {
/* 168 */     this.target = target;
/* 169 */     this.objectName = objectName;
/*     */   }
/*     */ 
/*     */   public Object getTarget()
/*     */   {
/* 177 */     return this.target;
/*     */   }
/*     */ 
/*     */   public String getObjectName()
/*     */   {
/* 184 */     return this.objectName;
/*     */   }
/*     */ 
/*     */   public void setAutoGrowNestedPaths(boolean autoGrowNestedPaths)
/*     */   {
/* 198 */     Assert.state(this.bindingResult == null, "DataBinder is already initialized - call setAutoGrowNestedPaths before other configuration methods");
/*     */ 
/* 200 */     this.autoGrowNestedPaths = autoGrowNestedPaths;
/*     */   }
/*     */ 
/*     */   public boolean isAutoGrowNestedPaths()
/*     */   {
/* 207 */     return this.autoGrowNestedPaths;
/*     */   }
/*     */ 
/*     */   public void setAutoGrowCollectionLimit(int autoGrowCollectionLimit)
/*     */   {
/* 216 */     this.autoGrowCollectionLimit = autoGrowCollectionLimit;
/*     */   }
/*     */ 
/*     */   public int getAutoGrowCollectionLimit()
/*     */   {
/* 223 */     return this.autoGrowCollectionLimit;
/*     */   }
/*     */ 
/*     */   public void initBeanPropertyAccess()
/*     */   {
/* 232 */     Assert.state(this.bindingResult == null, "DataBinder is already initialized - call initBeanPropertyAccess before other configuration methods");
/*     */ 
/* 234 */     this.bindingResult = new BeanPropertyBindingResult(
/* 235 */       getTarget(), getObjectName(), isAutoGrowNestedPaths(), getAutoGrowCollectionLimit());
/* 236 */     if (this.conversionService != null)
/* 237 */       this.bindingResult.initConversion(this.conversionService);
/*     */   }
/*     */ 
/*     */   public void initDirectFieldAccess()
/*     */   {
/* 247 */     Assert.state(this.bindingResult == null, "DataBinder is already initialized - call initDirectFieldAccess before other configuration methods");
/*     */ 
/* 249 */     this.bindingResult = new DirectFieldBindingResult(getTarget(), getObjectName());
/* 250 */     if (this.conversionService != null)
/* 251 */       this.bindingResult.initConversion(this.conversionService);
/*     */   }
/*     */ 
/*     */   protected AbstractPropertyBindingResult getInternalBindingResult()
/*     */   {
/* 260 */     if (this.bindingResult == null) {
/* 261 */       initBeanPropertyAccess();
/*     */     }
/* 263 */     return this.bindingResult;
/*     */   }
/*     */ 
/*     */   protected ConfigurablePropertyAccessor getPropertyAccessor()
/*     */   {
/* 270 */     return getInternalBindingResult().getPropertyAccessor();
/*     */   }
/*     */ 
/*     */   protected SimpleTypeConverter getSimpleTypeConverter()
/*     */   {
/* 277 */     if (this.typeConverter == null) {
/* 278 */       this.typeConverter = new SimpleTypeConverter();
/* 279 */       if (this.conversionService != null) {
/* 280 */         this.typeConverter.setConversionService(this.conversionService);
/*     */       }
/*     */     }
/* 283 */     return this.typeConverter;
/*     */   }
/*     */ 
/*     */   protected PropertyEditorRegistry getPropertyEditorRegistry()
/*     */   {
/* 290 */     if (getTarget() != null) {
/* 291 */       return getInternalBindingResult().getPropertyAccessor();
/*     */     }
/*     */ 
/* 294 */     return getSimpleTypeConverter();
/*     */   }
/*     */ 
/*     */   protected TypeConverter getTypeConverter()
/*     */   {
/* 302 */     if (getTarget() != null) {
/* 303 */       return getInternalBindingResult().getPropertyAccessor();
/*     */     }
/*     */ 
/* 306 */     return getSimpleTypeConverter();
/*     */   }
/*     */ 
/*     */   public BindingResult getBindingResult()
/*     */   {
/* 320 */     return getInternalBindingResult();
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnknownFields(boolean ignoreUnknownFields)
/*     */   {
/* 335 */     this.ignoreUnknownFields = ignoreUnknownFields;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreUnknownFields()
/*     */   {
/* 342 */     return this.ignoreUnknownFields;
/*     */   }
/*     */ 
/*     */   public void setIgnoreInvalidFields(boolean ignoreInvalidFields)
/*     */   {
/* 357 */     this.ignoreInvalidFields = ignoreInvalidFields;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreInvalidFields()
/*     */   {
/* 364 */     return this.ignoreInvalidFields;
/*     */   }
/*     */ 
/*     */   public void setAllowedFields(String[] allowedFields)
/*     */   {
/* 380 */     this.allowedFields = PropertyAccessorUtils.canonicalPropertyNames(allowedFields);
/*     */   }
/*     */ 
/*     */   public String[] getAllowedFields()
/*     */   {
/* 388 */     return this.allowedFields;
/*     */   }
/*     */ 
/*     */   public void setDisallowedFields(String[] disallowedFields)
/*     */   {
/* 404 */     this.disallowedFields = PropertyAccessorUtils.canonicalPropertyNames(disallowedFields);
/*     */   }
/*     */ 
/*     */   public String[] getDisallowedFields()
/*     */   {
/* 412 */     return this.disallowedFields;
/*     */   }
/*     */ 
/*     */   public void setRequiredFields(String[] requiredFields)
/*     */   {
/* 426 */     this.requiredFields = PropertyAccessorUtils.canonicalPropertyNames(requiredFields);
/* 427 */     if (logger.isDebugEnabled())
/* 428 */       logger.debug("DataBinder requires binding of required fields [" + 
/* 429 */         StringUtils.arrayToCommaDelimitedString(requiredFields) + 
/* 429 */         "]");
/*     */   }
/*     */ 
/*     */   public String[] getRequiredFields()
/*     */   {
/* 438 */     return this.requiredFields;
/*     */   }
/*     */ 
/*     */   public void setExtractOldValueForEditor(boolean extractOldValueForEditor)
/*     */   {
/* 448 */     getPropertyAccessor().setExtractOldValueForEditor(extractOldValueForEditor);
/*     */   }
/*     */ 
/*     */   public void setMessageCodesResolver(MessageCodesResolver messageCodesResolver)
/*     */   {
/* 459 */     getInternalBindingResult().setMessageCodesResolver(messageCodesResolver);
/*     */   }
/*     */ 
/*     */   public void setBindingErrorProcessor(BindingErrorProcessor bindingErrorProcessor)
/*     */   {
/* 469 */     Assert.notNull(bindingErrorProcessor, "BindingErrorProcessor must not be null");
/* 470 */     this.bindingErrorProcessor = bindingErrorProcessor;
/*     */   }
/*     */ 
/*     */   public BindingErrorProcessor getBindingErrorProcessor()
/*     */   {
/* 477 */     return this.bindingErrorProcessor;
/*     */   }
/*     */ 
/*     */   public void setValidator(Validator validator)
/*     */   {
/* 486 */     assertValidators(new Validator[] { validator });
/* 487 */     this.validators.clear();
/* 488 */     this.validators.add(validator);
/*     */   }
/*     */ 
/*     */   private void assertValidators(Validator[] validators) {
/* 492 */     Assert.notNull(validators, "Validators required");
/* 493 */     for (Validator validator : validators)
/* 494 */       if ((validator != null) && (getTarget() != null) && (!validator.supports(getTarget().getClass())))
/* 495 */         throw new IllegalStateException("Invalid target for Validator [" + validator + "]: " + getTarget());
/*     */   }
/*     */ 
/*     */   public void addValidators(Validator[] validators)
/*     */   {
/* 506 */     assertValidators(validators);
/* 507 */     this.validators.addAll(Arrays.asList(validators));
/*     */   }
/*     */ 
/*     */   public void replaceValidators(Validator[] validators)
/*     */   {
/* 516 */     assertValidators(validators);
/* 517 */     this.validators.clear();
/* 518 */     this.validators.addAll(Arrays.asList(validators));
/*     */   }
/*     */ 
/*     */   public Validator getValidator()
/*     */   {
/* 525 */     return this.validators.size() > 0 ? (Validator)this.validators.get(0) : null;
/*     */   }
/*     */ 
/*     */   public List<Validator> getValidators()
/*     */   {
/* 532 */     return Collections.unmodifiableList(this.validators);
/*     */   }
/*     */ 
/*     */   public void setConversionService(ConversionService conversionService)
/*     */   {
/* 544 */     Assert.state(this.conversionService == null, "DataBinder is already initialized with ConversionService");
/* 545 */     this.conversionService = conversionService;
/* 546 */     if ((this.bindingResult != null) && (conversionService != null))
/* 547 */       this.bindingResult.initConversion(conversionService);
/*     */   }
/*     */ 
/*     */   public ConversionService getConversionService()
/*     */   {
/* 555 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */   public void registerCustomEditor(Class<?> requiredType, PropertyEditor propertyEditor)
/*     */   {
/* 560 */     getPropertyEditorRegistry().registerCustomEditor(requiredType, propertyEditor);
/*     */   }
/*     */ 
/*     */   public void registerCustomEditor(Class<?> requiredType, String field, PropertyEditor propertyEditor)
/*     */   {
/* 565 */     getPropertyEditorRegistry().registerCustomEditor(requiredType, field, propertyEditor);
/*     */   }
/*     */ 
/*     */   public PropertyEditor findCustomEditor(Class<?> requiredType, String propertyPath)
/*     */   {
/* 570 */     return getPropertyEditorRegistry().findCustomEditor(requiredType, propertyPath);
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(Object value, Class<T> requiredType) throws TypeMismatchException
/*     */   {
/* 575 */     return getTypeConverter().convertIfNecessary(value, requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(Object value, Class<T> requiredType, MethodParameter methodParam)
/*     */     throws TypeMismatchException
/*     */   {
/* 582 */     return getTypeConverter().convertIfNecessary(value, requiredType, methodParam);
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(Object value, Class<T> requiredType, Field field)
/*     */     throws TypeMismatchException
/*     */   {
/* 589 */     return getTypeConverter().convertIfNecessary(value, requiredType, field);
/*     */   }
/*     */ 
/*     */   public void bind(PropertyValues pvs)
/*     */   {
/* 607 */     MutablePropertyValues mpvs = (pvs instanceof MutablePropertyValues) ? (MutablePropertyValues)pvs : new MutablePropertyValues(pvs);
/*     */ 
/* 609 */     doBind(mpvs);
/*     */   }
/*     */ 
/*     */   protected void doBind(MutablePropertyValues mpvs)
/*     */   {
/* 622 */     checkAllowedFields(mpvs);
/* 623 */     checkRequiredFields(mpvs);
/* 624 */     applyPropertyValues(mpvs);
/*     */   }
/*     */ 
/*     */   protected void checkAllowedFields(MutablePropertyValues mpvs)
/*     */   {
/* 635 */     PropertyValue[] pvs = mpvs.getPropertyValues();
/* 636 */     for (PropertyValue pv : pvs) {
/* 637 */       String field = PropertyAccessorUtils.canonicalPropertyName(pv.getName());
/* 638 */       if (!isAllowed(field)) {
/* 639 */         mpvs.removePropertyValue(pv);
/* 640 */         getBindingResult().recordSuppressedField(field);
/* 641 */         if (logger.isDebugEnabled())
/* 642 */           logger.debug("Field [" + field + "] has been removed from PropertyValues " + "and will not be bound, because it has not been found in the list of allowed fields");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isAllowed(String field)
/*     */   {
/* 664 */     String[] allowed = getAllowedFields();
/* 665 */     String[] disallowed = getDisallowedFields();
/*     */ 
/* 667 */     return ((ObjectUtils.isEmpty(allowed)) || (PatternMatchUtils.simpleMatch(allowed, field))) && (
/* 667 */       (ObjectUtils.isEmpty(disallowed)) || 
/* 667 */       (!PatternMatchUtils.simpleMatch(disallowed, field)));
/*     */   }
/*     */ 
/*     */   protected void checkRequiredFields(MutablePropertyValues mpvs)
/*     */   {
/* 679 */     String[] requiredFields = getRequiredFields();
/* 680 */     if (!ObjectUtils.isEmpty(requiredFields)) {
/* 681 */       Map propertyValues = new HashMap();
/* 682 */       PropertyValue[] pvs = mpvs.getPropertyValues();
/* 683 */       for (PropertyValue pv : pvs) {
/* 684 */         String canonicalName = PropertyAccessorUtils.canonicalPropertyName(pv.getName());
/* 685 */         propertyValues.put(canonicalName, pv);
/*     */       }
/* 687 */       for (String field : requiredFields) {
/* 688 */         PropertyValue pv = (PropertyValue)propertyValues.get(field);
/* 689 */         boolean empty = (pv == null) || (pv.getValue() == null);
/* 690 */         if (!empty) {
/* 691 */           if ((pv.getValue() instanceof String)) {
/* 692 */             empty = !StringUtils.hasText((String)pv.getValue());
/*     */           }
/* 694 */           else if ((pv.getValue() instanceof String[])) {
/* 695 */             String[] values = (String[])pv.getValue();
/* 696 */             empty = (values.length == 0) || (!StringUtils.hasText(values[0]));
/*     */           }
/*     */         }
/* 699 */         if (empty)
/*     */         {
/* 701 */           getBindingErrorProcessor().processMissingFieldError(field, getInternalBindingResult());
/*     */ 
/* 704 */           if (pv != null) {
/* 705 */             mpvs.removePropertyValue(pv);
/* 706 */             propertyValues.remove(field);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void applyPropertyValues(MutablePropertyValues mpvs)
/*     */   {
/*     */     try
/*     */     {
/* 728 */       getPropertyAccessor().setPropertyValues(mpvs, isIgnoreUnknownFields(), isIgnoreInvalidFields());
/*     */     }
/*     */     catch (PropertyBatchUpdateException ex)
/*     */     {
/* 732 */       for (PropertyAccessException pae : ex.getPropertyAccessExceptions())
/* 733 */         getBindingErrorProcessor().processPropertyAccessException(pae, getInternalBindingResult());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 745 */     for (Validator validator : this.validators)
/* 746 */       validator.validate(getTarget(), getBindingResult());
/*     */   }
/*     */ 
/*     */   public void validate(Object[] validationHints)
/*     */   {
/* 758 */     for (Validator validator : getValidators())
/* 759 */       if ((!ObjectUtils.isEmpty(validationHints)) && ((validator instanceof SmartValidator))) {
/* 760 */         ((SmartValidator)validator).validate(getTarget(), getBindingResult(), validationHints);
/*     */       }
/* 762 */       else if (validator != null)
/* 763 */         validator.validate(getTarget(), getBindingResult());
/*     */   }
/*     */ 
/*     */   public Map<?, ?> close()
/*     */     throws BindException
/*     */   {
/* 776 */     if (getBindingResult().hasErrors()) {
/* 777 */       throw new BindException(getBindingResult());
/*     */     }
/* 779 */     return getBindingResult().getModel();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.DataBinder
 * JD-Core Version:    0.6.2
 */