package org.springframework.validation;

public abstract interface MessageCodeFormatter
{
  public abstract String format(String paramString1, String paramString2, String paramString3);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.MessageCodeFormatter
 * JD-Core Version:    0.6.2
 */