/*     */ package org.springframework.validation.beanvalidation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.validation.Configuration;
/*     */ import javax.validation.ConstraintValidatorFactory;
/*     */ import javax.validation.MessageInterpolator;
/*     */ import javax.validation.TraversableResolver;
/*     */ import javax.validation.Validation;
/*     */ import javax.validation.Validator;
/*     */ import javax.validation.ValidatorContext;
/*     */ import javax.validation.ValidatorFactory;
/*     */ import javax.validation.bootstrap.GenericBootstrap;
/*     */ import javax.validation.bootstrap.ProviderSpecificBootstrap;
/*     */ import org.hibernate.validator.messageinterpolation.ResourceBundleMessageInterpolator;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class LocalValidatorFactoryBean extends SpringValidatorAdapter
/*     */   implements ValidatorFactory, ApplicationContextAware, InitializingBean, DisposableBean
/*     */ {
/*  84 */   private static final Method closeMethod = ClassUtils.getMethodIfAvailable(DisposableBean.class, "close", new Class[0]);
/*     */   private Class providerClass;
/*     */   private MessageInterpolator messageInterpolator;
/*     */   private TraversableResolver traversableResolver;
/*     */   private ConstraintValidatorFactory constraintValidatorFactory;
/*     */   private ParameterNameDiscoverer parameterNameDiscoverer;
/*     */   private Resource[] mappingLocations;
/*     */   private final Map<String, String> validationPropertyMap;
/*     */   private ApplicationContext applicationContext;
/*     */   private ValidatorFactory validatorFactory;
/*     */ 
/*     */   public LocalValidatorFactoryBean()
/*     */   {
/*  96 */     this.parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */ 
/* 100 */     this.validationPropertyMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public void setProviderClass(Class providerClass)
/*     */   {
/* 115 */     this.providerClass = providerClass;
/*     */   }
/*     */ 
/*     */   public void setMessageInterpolator(MessageInterpolator messageInterpolator)
/*     */   {
/* 123 */     this.messageInterpolator = messageInterpolator;
/*     */   }
/*     */ 
/*     */   public void setValidationMessageSource(MessageSource messageSource)
/*     */   {
/* 141 */     this.messageInterpolator = HibernateValidatorDelegate.buildMessageInterpolator(messageSource);
/*     */   }
/*     */ 
/*     */   public void setTraversableResolver(TraversableResolver traversableResolver)
/*     */   {
/* 149 */     this.traversableResolver = traversableResolver;
/*     */   }
/*     */ 
/*     */   public void setConstraintValidatorFactory(ConstraintValidatorFactory constraintValidatorFactory)
/*     */   {
/* 158 */     this.constraintValidatorFactory = constraintValidatorFactory;
/*     */   }
/*     */ 
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 167 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */   public void setMappingLocations(Resource[] mappingLocations)
/*     */   {
/* 174 */     this.mappingLocations = mappingLocations;
/*     */   }
/*     */ 
/*     */   public void setValidationProperties(Properties jpaProperties)
/*     */   {
/* 184 */     CollectionUtils.mergePropertiesIntoMap(jpaProperties, this.validationPropertyMap);
/*     */   }
/*     */ 
/*     */   public void setValidationPropertyMap(Map<String, String> validationProperties)
/*     */   {
/* 193 */     if (validationProperties != null)
/* 194 */       this.validationPropertyMap.putAll(validationProperties);
/*     */   }
/*     */ 
/*     */   public Map<String, String> getValidationPropertyMap()
/*     */   {
/* 204 */     return this.validationPropertyMap;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 209 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 219 */     Configuration configuration = this.providerClass != null ? 
/* 218 */       Validation.byProvider(this.providerClass)
/* 218 */       .configure() : 
/* 219 */       Validation.byDefaultProvider().configure();
/*     */ 
/* 221 */     MessageInterpolator targetInterpolator = this.messageInterpolator;
/* 222 */     if (targetInterpolator == null) {
/* 223 */       targetInterpolator = configuration.getDefaultMessageInterpolator();
/*     */     }
/* 225 */     configuration.messageInterpolator(new LocaleContextMessageInterpolator(targetInterpolator));
/*     */ 
/* 227 */     if (this.traversableResolver != null) {
/* 228 */       configuration.traversableResolver(this.traversableResolver);
/*     */     }
/*     */ 
/* 231 */     ConstraintValidatorFactory targetConstraintValidatorFactory = this.constraintValidatorFactory;
/* 232 */     if ((targetConstraintValidatorFactory == null) && (this.applicationContext != null))
/*     */     {
/* 234 */       targetConstraintValidatorFactory = new SpringConstraintValidatorFactory(this.applicationContext
/* 234 */         .getAutowireCapableBeanFactory());
/*     */     }
/* 236 */     if (targetConstraintValidatorFactory != null) {
/* 237 */       configuration.constraintValidatorFactory(targetConstraintValidatorFactory);
/*     */     }
/*     */ 
/* 240 */     configureParameterNameProviderIfPossible(configuration);
/*     */ 
/* 242 */     if (this.mappingLocations != null) {
/* 243 */       for (Resource location : this.mappingLocations) {
/*     */         try {
/* 245 */           configuration.addMapping(location.getInputStream());
/*     */         }
/*     */         catch (IOException ex) {
/* 248 */           throw new IllegalStateException("Cannot read mapping resource: " + location);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 253 */     for (??? = this.validationPropertyMap.entrySet().iterator(); ((Iterator)???).hasNext(); ) { Map.Entry entry = (Map.Entry)((Iterator)???).next();
/* 254 */       configuration.addProperty((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */ 
/* 258 */     postProcessConfiguration(configuration);
/*     */ 
/* 260 */     this.validatorFactory = configuration.buildValidatorFactory();
/* 261 */     setTargetValidator(this.validatorFactory.getValidator());
/*     */   }
/*     */ 
/*     */   private void configureParameterNameProviderIfPossible(Configuration<?> configuration)
/*     */   {
/*     */     try {
/* 267 */       Class parameterNameProviderClass = ClassUtils.forName("javax.validation.ParameterNameProvider", 
/* 267 */         getClass().getClassLoader());
/*     */ 
/* 269 */       Method parameterNameProviderMethod = Configuration.class
/* 269 */         .getMethod("parameterNameProvider", new Class[] { parameterNameProviderClass });
/*     */ 
/* 270 */       final Object defaultProvider = ReflectionUtils.invokeMethod(Configuration.class
/* 271 */         .getMethod("getDefaultParameterNameProvider", new Class[0]), 
/* 271 */         configuration);
/* 272 */       final ParameterNameDiscoverer discoverer = this.parameterNameDiscoverer;
/* 273 */       Object parameterNameProvider = Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { parameterNameProviderClass }, new InvocationHandler()
/*     */       {
/*     */         public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */         {
/* 277 */           if (method.getName().equals("getParameterNames")) {
/* 278 */             String[] result = null;
/* 279 */             if ((args[0] instanceof Constructor)) {
/* 280 */               result = discoverer.getParameterNames((Constructor)args[0]);
/*     */             }
/* 282 */             else if ((args[0] instanceof Method)) {
/* 283 */               result = discoverer.getParameterNames((Method)args[0]);
/*     */             }
/* 285 */             if (result != null) {
/* 286 */               return Arrays.asList(result);
/*     */             }
/*     */             try
/*     */             {
/* 290 */               return method.invoke(defaultProvider, args);
/*     */             }
/*     */             catch (InvocationTargetException ex) {
/* 293 */               throw ex.getTargetException();
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */           try
/*     */           {
/* 300 */             return method.invoke(this, args);
/*     */           }
/*     */           catch (InvocationTargetException ex) {
/* 303 */             throw ex.getTargetException();
/*     */           }
/*     */         }
/*     */       });
/* 308 */       ReflectionUtils.invokeMethod(parameterNameProviderMethod, configuration, new Object[] { parameterNameProvider });
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void postProcessConfiguration(Configuration<?> configuration)
/*     */   {
/*     */   }
/*     */ 
/*     */   public Validator getValidator()
/*     */   {
/* 329 */     return this.validatorFactory.getValidator();
/*     */   }
/*     */ 
/*     */   public ValidatorContext usingContext()
/*     */   {
/* 334 */     return this.validatorFactory.usingContext();
/*     */   }
/*     */ 
/*     */   public MessageInterpolator getMessageInterpolator()
/*     */   {
/* 339 */     return this.validatorFactory.getMessageInterpolator();
/*     */   }
/*     */ 
/*     */   public TraversableResolver getTraversableResolver()
/*     */   {
/* 344 */     return this.validatorFactory.getTraversableResolver();
/*     */   }
/*     */ 
/*     */   public ConstraintValidatorFactory getConstraintValidatorFactory()
/*     */   {
/* 349 */     return this.validatorFactory.getConstraintValidatorFactory();
/*     */   }
/*     */ 
/*     */   public void close() {
/* 353 */     if (closeMethod != null)
/* 354 */       ReflectionUtils.invokeMethod(closeMethod, this.validatorFactory);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 360 */     close();
/*     */   }
/*     */ 
/*     */   private static class HibernateValidatorDelegate
/*     */   {
/*     */     public static MessageInterpolator buildMessageInterpolator(MessageSource messageSource)
/*     */     {
/* 370 */       return new ResourceBundleMessageInterpolator(new MessageSourceResourceBundleLocator(messageSource));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.LocalValidatorFactoryBean
 * JD-Core Version:    0.6.2
 */