/*    */ package org.springframework.validation.beanvalidation;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.validation.MessageInterpolator;
/*    */ import javax.validation.MessageInterpolator.Context;
/*    */ import org.springframework.context.i18n.LocaleContextHolder;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class LocaleContextMessageInterpolator
/*    */   implements MessageInterpolator
/*    */ {
/*    */   private final MessageInterpolator targetInterpolator;
/*    */ 
/*    */   public LocaleContextMessageInterpolator(MessageInterpolator targetInterpolator)
/*    */   {
/* 43 */     Assert.notNull(targetInterpolator, "Target MessageInterpolator must not be null");
/* 44 */     this.targetInterpolator = targetInterpolator;
/*    */   }
/*    */ 
/*    */   public String interpolate(String message, MessageInterpolator.Context context)
/*    */   {
/* 50 */     return this.targetInterpolator.interpolate(message, context, LocaleContextHolder.getLocale());
/*    */   }
/*    */ 
/*    */   public String interpolate(String message, MessageInterpolator.Context context, Locale locale)
/*    */   {
/* 55 */     return this.targetInterpolator.interpolate(message, context, locale);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.LocaleContextMessageInterpolator
 * JD-Core Version:    0.6.2
 */