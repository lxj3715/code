/*     */ package org.springframework.validation.beanvalidation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Set;
/*     */ import javax.validation.ConstraintViolationException;
/*     */ import javax.validation.Validation;
/*     */ import javax.validation.Validator;
/*     */ import javax.validation.ValidatorFactory;
/*     */ import javax.validation.bootstrap.ProviderSpecificBootstrap;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.hibernate.validator.HibernateValidator;
/*     */ import org.hibernate.validator.HibernateValidatorConfiguration;
/*     */ import org.hibernate.validator.method.MethodConstraintViolationException;
/*     */ import org.hibernate.validator.method.MethodValidator;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ 
/*     */ public class MethodValidationInterceptor
/*     */   implements MethodInterceptor
/*     */ {
/*     */   private static Method forExecutablesMethod;
/*     */   private static Method validateParametersMethod;
/*     */   private static Method validateReturnValueMethod;
/*     */   private final Validator validator;
/*     */ 
/*     */   public MethodValidationInterceptor()
/*     */   {
/*  89 */     this(forExecutablesMethod != null ? Validation.buildDefaultValidatorFactory() : 
/*  90 */       HibernateValidatorDelegate.buildValidatorFactory());
/*     */   }
/*     */ 
/*     */   public MethodValidationInterceptor(ValidatorFactory validatorFactory)
/*     */   {
/*  98 */     this(validatorFactory.getValidator());
/*     */   }
/*     */ 
/*     */   public MethodValidationInterceptor(Validator validator)
/*     */   {
/* 106 */     this.validator = validator;
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 113 */     Class[] groups = determineValidationGroups(invocation);
/* 114 */     if (forExecutablesMethod != null) {
/* 115 */       Object executableValidator = ReflectionUtils.invokeMethod(forExecutablesMethod, this.validator);
/*     */ 
/* 117 */       Set result = (Set)ReflectionUtils.invokeMethod(validateParametersMethod, executableValidator, new Object[] { invocation
/* 118 */         .getThis(), invocation.getMethod(), invocation.getArguments(), groups });
/* 119 */       if (!result.isEmpty()) {
/* 120 */         throw new ConstraintViolationException(result);
/*     */       }
/* 122 */       Object returnValue = invocation.proceed();
/*     */ 
/* 124 */       result = (Set)ReflectionUtils.invokeMethod(validateReturnValueMethod, executableValidator, new Object[] { invocation
/* 125 */         .getThis(), invocation.getMethod(), returnValue, groups });
/* 126 */       if (!result.isEmpty()) {
/* 127 */         throw new ConstraintViolationException(result);
/*     */       }
/* 129 */       return returnValue;
/*     */     }
/*     */ 
/* 132 */     return HibernateValidatorDelegate.invokeWithinValidation(invocation, this.validator, groups);
/*     */   }
/*     */ 
/*     */   protected Class<?>[] determineValidationGroups(MethodInvocation invocation)
/*     */   {
/* 144 */     Validated valid = (Validated)AnnotationUtils.findAnnotation(invocation.getThis().getClass(), Validated.class);
/* 145 */     return valid != null ? valid.value() : new Class[0];
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  69 */       forExecutablesMethod = Validator.class.getMethod("forExecutables", new Class[0]);
/*  70 */       Class executableValidatorClass = forExecutablesMethod.getReturnType();
/*  71 */       validateParametersMethod = executableValidatorClass.getMethod("validateParameters", new Class[] { Object.class, Method.class, [Ljava.lang.Object.class, [Ljava.lang.Class.class });
/*     */ 
/*  73 */       validateReturnValueMethod = executableValidatorClass.getMethod("validateReturnValue", new Class[] { Object.class, Method.class, Object.class, [Ljava.lang.Class.class });
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class HibernateValidatorDelegate
/*     */   {
/*     */     public static ValidatorFactory buildValidatorFactory()
/*     */     {
/* 155 */       return ((HibernateValidatorConfiguration)Validation.byProvider(HibernateValidator.class).configure()).buildValidatorFactory();
/*     */     }
/*     */ 
/*     */     public static Object invokeWithinValidation(MethodInvocation invocation, Validator validator, Class<?>[] groups)
/*     */       throws Throwable
/*     */     {
/* 162 */       MethodValidator methodValidator = (MethodValidator)validator.unwrap(MethodValidator.class);
/* 163 */       Set result = methodValidator.validateAllParameters(invocation
/* 164 */         .getThis(), invocation.getMethod(), invocation.getArguments(), groups);
/* 165 */       if (!result.isEmpty()) {
/* 166 */         throw new MethodConstraintViolationException(result);
/*     */       }
/* 168 */       Object returnValue = invocation.proceed();
/* 169 */       result = methodValidator.validateReturnValue(invocation
/* 170 */         .getThis(), invocation.getMethod(), returnValue, groups);
/* 171 */       if (!result.isEmpty()) {
/* 172 */         throw new MethodConstraintViolationException(result);
/*     */       }
/* 174 */       return returnValue;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.MethodValidationInterceptor
 * JD-Core Version:    0.6.2
 */