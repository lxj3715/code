/*     */ package org.springframework.validation.beanvalidation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import javax.validation.Validator;
/*     */ import javax.validation.ValidatorFactory;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ 
/*     */ public class MethodValidationPostProcessor extends AbstractAdvisingBeanPostProcessor
/*     */   implements InitializingBean
/*     */ {
/*  63 */   private Class<? extends Annotation> validatedAnnotationType = Validated.class;
/*     */   private Validator validator;
/*     */ 
/*     */   public void setValidatedAnnotationType(Class<? extends Annotation> validatedAnnotationType)
/*     */   {
/*  77 */     Assert.notNull(validatedAnnotationType, "'validatedAnnotationType' must not be null");
/*  78 */     this.validatedAnnotationType = validatedAnnotationType;
/*     */   }
/*     */ 
/*     */   public void setValidator(Validator validator)
/*     */   {
/*  86 */     if ((validator instanceof LocalValidatorFactoryBean)) {
/*  87 */       this.validator = ((LocalValidatorFactoryBean)validator).getValidator();
/*     */     }
/*     */     else
/*  90 */       this.validator = validator;
/*     */   }
/*     */ 
/*     */   public void setValidatorFactory(ValidatorFactory validatorFactory)
/*     */   {
/* 101 */     this.validator = validatorFactory.getValidator();
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 106 */     Pointcut pointcut = new AnnotationMatchingPointcut(this.validatedAnnotationType, true);
/* 107 */     Advice advice = this.validator != null ? new MethodValidationInterceptor(this.validator) : new MethodValidationInterceptor();
/*     */ 
/* 109 */     this.advisor = new DefaultPointcutAdvisor(pointcut, advice);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.MethodValidationPostProcessor
 * JD-Core Version:    0.6.2
 */