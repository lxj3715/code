/*     */ package org.springframework.validation.beanvalidation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import javax.validation.ConstraintViolation;
/*     */ import javax.validation.Validator;
/*     */ import javax.validation.metadata.BeanDescriptor;
/*     */ import javax.validation.metadata.ConstraintDescriptor;
/*     */ import org.springframework.beans.NotReadablePropertyException;
/*     */ import org.springframework.context.support.DefaultMessageSourceResolvable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.FieldError;
/*     */ import org.springframework.validation.ObjectError;
/*     */ import org.springframework.validation.SmartValidator;
/*     */ 
/*     */ public class SpringValidatorAdapter
/*     */   implements SmartValidator, Validator
/*     */ {
/*  52 */   private static final Set<String> internalAnnotationAttributes = new HashSet(3);
/*     */   private Validator targetValidator;
/*     */ 
/*     */   public SpringValidatorAdapter(Validator targetValidator)
/*     */   {
/*  68 */     Assert.notNull(targetValidator, "Target Validator must not be null");
/*  69 */     this.targetValidator = targetValidator;
/*     */   }
/*     */ 
/*     */   SpringValidatorAdapter() {
/*     */   }
/*     */ 
/*     */   void setTargetValidator(Validator targetValidator) {
/*  76 */     this.targetValidator = targetValidator;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   public void validate(Object target, Errors errors)
/*     */   {
/*  91 */     processConstraintViolations(this.targetValidator.validate(target, new Class[0]), errors);
/*     */   }
/*     */ 
/*     */   public void validate(Object target, Errors errors, Object[] validationHints)
/*     */   {
/*  97 */     Set groups = new LinkedHashSet();
/*  98 */     if (validationHints != null) {
/*  99 */       for (Object hint : validationHints) {
/* 100 */         if ((hint instanceof Class)) {
/* 101 */           groups.add((Class)hint);
/*     */         }
/*     */       }
/*     */     }
/* 105 */     processConstraintViolations(this.targetValidator
/* 106 */       .validate(target, 
/* 106 */       (Class[])groups
/* 106 */       .toArray(new Class[groups
/* 106 */       .size()])), errors);
/*     */   }
/*     */ 
/*     */   protected void processConstraintViolations(Set<ConstraintViolation<Object>> violations, Errors errors)
/*     */   {
/* 116 */     for (ConstraintViolation violation : violations) {
/* 117 */       String field = violation.getPropertyPath().toString();
/* 118 */       FieldError fieldError = errors.getFieldError(field);
/* 119 */       if ((fieldError == null) || (!fieldError.isBindingFailure()))
/*     */         try {
/* 121 */           ConstraintDescriptor cd = violation.getConstraintDescriptor();
/* 122 */           String errorCode = cd.getAnnotation().annotationType().getSimpleName();
/* 123 */           Object[] errorArgs = getArgumentsForConstraint(errors.getObjectName(), field, cd);
/* 124 */           if ((errors instanceof BindingResult))
/*     */           {
/* 127 */             BindingResult bindingResult = (BindingResult)errors;
/* 128 */             String nestedField = bindingResult.getNestedPath() + field;
/* 129 */             if ("".equals(nestedField)) {
/* 130 */               String[] errorCodes = bindingResult.resolveMessageCodes(errorCode);
/* 131 */               bindingResult.addError(new ObjectError(errors
/* 132 */                 .getObjectName(), errorCodes, errorArgs, violation.getMessage()));
/*     */             }
/*     */             else {
/* 135 */               Object invalidValue = violation.getInvalidValue();
/* 136 */               if ((!"".equals(field)) && ((invalidValue == violation.getLeafBean()) || (
/* 137 */                 (field
/* 137 */                 .contains(".")) && 
/* 137 */                 (!field.contains("[]")))))
/*     */               {
/* 140 */                 invalidValue = bindingResult.getRawFieldValue(field);
/*     */               }
/* 142 */               String[] errorCodes = bindingResult.resolveMessageCodes(errorCode, field);
/* 143 */               bindingResult.addError(new FieldError(errors
/* 144 */                 .getObjectName(), nestedField, invalidValue, false, errorCodes, errorArgs, violation
/* 145 */                 .getMessage()));
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 151 */             errors.rejectValue(field, errorCode, errorArgs, violation.getMessage());
/*     */           }
/*     */         }
/*     */         catch (NotReadablePropertyException ex) {
/* 155 */           throw new IllegalStateException("JSR-303 validated property '" + field + "' does not have a corresponding accessor for Spring data binding - " + "check your DataBinder's configuration (bean property versus direct field access)", ex);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object[] getArgumentsForConstraint(String objectName, String field, ConstraintDescriptor<?> descriptor)
/*     */   {
/* 180 */     List arguments = new LinkedList();
/* 181 */     String[] codes = { objectName + "." + field, field };
/* 182 */     arguments.add(new DefaultMessageSourceResolvable(codes, field));
/*     */ 
/* 184 */     Map attributesToExpose = new TreeMap();
/* 185 */     for (Map.Entry entry : descriptor.getAttributes().entrySet()) {
/* 186 */       String attributeName = (String)entry.getKey();
/* 187 */       Object attributeValue = entry.getValue();
/* 188 */       if (!internalAnnotationAttributes.contains(attributeName)) {
/* 189 */         attributesToExpose.put(attributeName, attributeValue);
/*     */       }
/*     */     }
/* 192 */     arguments.addAll(attributesToExpose.values());
/* 193 */     return arguments.toArray(new Object[arguments.size()]);
/*     */   }
/*     */ 
/*     */   public <T> Set<ConstraintViolation<T>> validate(T object, Class<?>[] groups)
/*     */   {
/* 203 */     return this.targetValidator.validate(object, groups);
/*     */   }
/*     */ 
/*     */   public <T> Set<ConstraintViolation<T>> validateProperty(T object, String propertyName, Class<?>[] groups)
/*     */   {
/* 208 */     return this.targetValidator.validateProperty(object, propertyName, groups);
/*     */   }
/*     */ 
/*     */   public <T> Set<ConstraintViolation<T>> validateValue(Class<T> beanType, String propertyName, Object value, Class<?>[] groups)
/*     */   {
/* 215 */     return this.targetValidator.validateValue(beanType, propertyName, value, groups);
/*     */   }
/*     */ 
/*     */   public BeanDescriptor getConstraintsForClass(Class<?> clazz)
/*     */   {
/* 220 */     return this.targetValidator.getConstraintsForClass(clazz);
/*     */   }
/*     */ 
/*     */   public <T> T unwrap(Class<T> type)
/*     */   {
/* 225 */     return this.targetValidator.unwrap(type);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  55 */     internalAnnotationAttributes.add("message");
/*  56 */     internalAnnotationAttributes.add("groups");
/*  57 */     internalAnnotationAttributes.add("payload");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.SpringValidatorAdapter
 * JD-Core Version:    0.6.2
 */