/*    */ package org.springframework.validation.support;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.ui.ExtendedModelMap;
/*    */ import org.springframework.validation.BindingResult;
/*    */ 
/*    */ public class BindingAwareModelMap extends ExtendedModelMap
/*    */ {
/*    */   public Object put(String key, Object value)
/*    */   {
/* 41 */     removeBindingResultIfNecessary(key, value);
/* 42 */     return super.put(key, value);
/*    */   }
/*    */ 
/*    */   public void putAll(Map<? extends String, ?> map)
/*    */   {
/* 47 */     for (Map.Entry entry : map.entrySet()) {
/* 48 */       removeBindingResultIfNecessary(entry.getKey(), entry.getValue());
/*    */     }
/* 50 */     super.putAll(map);
/*    */   }
/*    */ 
/*    */   private void removeBindingResultIfNecessary(Object key, Object value) {
/* 54 */     if ((key instanceof String)) {
/* 55 */       String attributeName = (String)key;
/* 56 */       if (!attributeName.startsWith(BindingResult.MODEL_KEY_PREFIX)) {
/* 57 */         String bindingResultKey = BindingResult.MODEL_KEY_PREFIX + attributeName;
/* 58 */         BindingResult bindingResult = (BindingResult)get(bindingResultKey);
/* 59 */         if ((bindingResult != null) && (bindingResult.getTarget() != value))
/* 60 */           remove(bindingResultKey);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-context-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.validation.support.BindingAwareModelMap
 * JD-Core Version:    0.6.2
 */