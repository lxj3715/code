/*     */ package org.springframework.asm;
/*     */ 
/*     */ public class ByteVector
/*     */ {
/*     */   byte[] data;
/*     */   int length;
/*     */ 
/*     */   public ByteVector()
/*     */   {
/*  55 */     this.data = new byte[64];
/*     */   }
/*     */ 
/*     */   public ByteVector(int initialSize)
/*     */   {
/*  66 */     this.data = new byte[initialSize];
/*     */   }
/*     */ 
/*     */   public ByteVector putByte(int b)
/*     */   {
/*  78 */     int length = this.length;
/*  79 */     if (length + 1 > this.data.length) {
/*  80 */       enlarge(1);
/*     */     }
/*  82 */     this.data[(length++)] = ((byte)b);
/*  83 */     this.length = length;
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   ByteVector put11(int b1, int b2)
/*     */   {
/*  98 */     int length = this.length;
/*  99 */     if (length + 2 > this.data.length) {
/* 100 */       enlarge(2);
/*     */     }
/* 102 */     byte[] data = this.data;
/* 103 */     data[(length++)] = ((byte)b1);
/* 104 */     data[(length++)] = ((byte)b2);
/* 105 */     this.length = length;
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   public ByteVector putShort(int s)
/*     */   {
/* 118 */     int length = this.length;
/* 119 */     if (length + 2 > this.data.length) {
/* 120 */       enlarge(2);
/*     */     }
/* 122 */     byte[] data = this.data;
/* 123 */     data[(length++)] = ((byte)(s >>> 8));
/* 124 */     data[(length++)] = ((byte)s);
/* 125 */     this.length = length;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */   ByteVector put12(int b, int s)
/*     */   {
/* 140 */     int length = this.length;
/* 141 */     if (length + 3 > this.data.length) {
/* 142 */       enlarge(3);
/*     */     }
/* 144 */     byte[] data = this.data;
/* 145 */     data[(length++)] = ((byte)b);
/* 146 */     data[(length++)] = ((byte)(s >>> 8));
/* 147 */     data[(length++)] = ((byte)s);
/* 148 */     this.length = length;
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */   public ByteVector putInt(int i)
/*     */   {
/* 161 */     int length = this.length;
/* 162 */     if (length + 4 > this.data.length) {
/* 163 */       enlarge(4);
/*     */     }
/* 165 */     byte[] data = this.data;
/* 166 */     data[(length++)] = ((byte)(i >>> 24));
/* 167 */     data[(length++)] = ((byte)(i >>> 16));
/* 168 */     data[(length++)] = ((byte)(i >>> 8));
/* 169 */     data[(length++)] = ((byte)i);
/* 170 */     this.length = length;
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */   public ByteVector putLong(long l)
/*     */   {
/* 183 */     int length = this.length;
/* 184 */     if (length + 8 > this.data.length) {
/* 185 */       enlarge(8);
/*     */     }
/* 187 */     byte[] data = this.data;
/* 188 */     int i = (int)(l >>> 32);
/* 189 */     data[(length++)] = ((byte)(i >>> 24));
/* 190 */     data[(length++)] = ((byte)(i >>> 16));
/* 191 */     data[(length++)] = ((byte)(i >>> 8));
/* 192 */     data[(length++)] = ((byte)i);
/* 193 */     i = (int)l;
/* 194 */     data[(length++)] = ((byte)(i >>> 24));
/* 195 */     data[(length++)] = ((byte)(i >>> 16));
/* 196 */     data[(length++)] = ((byte)(i >>> 8));
/* 197 */     data[(length++)] = ((byte)i);
/* 198 */     this.length = length;
/* 199 */     return this;
/*     */   }
/*     */ 
/*     */   public ByteVector putUTF8(String s)
/*     */   {
/* 211 */     int charLength = s.length();
/* 212 */     if (charLength > 65535) {
/* 213 */       throw new IllegalArgumentException();
/*     */     }
/* 215 */     int len = this.length;
/* 216 */     if (len + 2 + charLength > this.data.length) {
/* 217 */       enlarge(2 + charLength);
/*     */     }
/* 219 */     byte[] data = this.data;
/*     */ 
/* 226 */     data[(len++)] = ((byte)(charLength >>> 8));
/* 227 */     data[(len++)] = ((byte)charLength);
/* 228 */     for (int i = 0; i < charLength; i++) {
/* 229 */       char c = s.charAt(i);
/* 230 */       if ((c >= '\001') && (c <= '')) {
/* 231 */         data[(len++)] = ((byte)c);
/*     */       } else {
/* 233 */         int byteLength = i;
/* 234 */         for (int j = i; j < charLength; j++) {
/* 235 */           c = s.charAt(j);
/* 236 */           if ((c >= '\001') && (c <= ''))
/* 237 */             byteLength++;
/* 238 */           else if (c > '߿')
/* 239 */             byteLength += 3;
/*     */           else {
/* 241 */             byteLength += 2;
/*     */           }
/*     */         }
/* 244 */         if (byteLength > 65535) {
/* 245 */           throw new IllegalArgumentException();
/*     */         }
/* 247 */         data[this.length] = ((byte)(byteLength >>> 8));
/* 248 */         data[(this.length + 1)] = ((byte)byteLength);
/* 249 */         if (this.length + 2 + byteLength > data.length) {
/* 250 */           this.length = len;
/* 251 */           enlarge(2 + byteLength);
/* 252 */           data = this.data;
/*     */         }
/* 254 */         for (int j = i; j < charLength; j++) {
/* 255 */           c = s.charAt(j);
/* 256 */           if ((c >= '\001') && (c <= '')) {
/* 257 */             data[(len++)] = ((byte)c);
/* 258 */           } else if (c > '߿') {
/* 259 */             data[(len++)] = ((byte)(0xE0 | c >> '\f' & 0xF));
/* 260 */             data[(len++)] = ((byte)(0x80 | c >> '\006' & 0x3F));
/* 261 */             data[(len++)] = ((byte)(0x80 | c & 0x3F));
/*     */           } else {
/* 263 */             data[(len++)] = ((byte)(0xC0 | c >> '\006' & 0x1F));
/* 264 */             data[(len++)] = ((byte)(0x80 | c & 0x3F));
/*     */           }
/*     */         }
/* 267 */         break;
/*     */       }
/*     */     }
/* 270 */     this.length = len;
/* 271 */     return this;
/*     */   }
/*     */ 
/*     */   public ByteVector putByteArray(byte[] b, int off, int len)
/*     */   {
/* 288 */     if (this.length + len > this.data.length) {
/* 289 */       enlarge(len);
/*     */     }
/* 291 */     if (b != null) {
/* 292 */       System.arraycopy(b, off, this.data, this.length, len);
/*     */     }
/* 294 */     this.length += len;
/* 295 */     return this;
/*     */   }
/*     */ 
/*     */   private void enlarge(int size)
/*     */   {
/* 306 */     int length1 = 2 * this.data.length;
/* 307 */     int length2 = this.length + size;
/* 308 */     byte[] newData = new byte[length1 > length2 ? length1 : length2];
/* 309 */     System.arraycopy(this.data, 0, newData, 0, this.length);
/* 310 */     this.data = newData;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.ByteVector
 * JD-Core Version:    0.6.2
 */