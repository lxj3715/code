/*      */ package org.springframework.asm;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ 
/*      */ public class ClassReader
/*      */ {
/*      */   static final boolean SIGNATURES = true;
/*      */   static final boolean ANNOTATIONS = true;
/*      */   static final boolean FRAMES = true;
/*      */   static final boolean WRITER = true;
/*      */   static final boolean RESIZE = true;
/*      */   public static final int SKIP_CODE = 1;
/*      */   public static final int SKIP_DEBUG = 2;
/*      */   public static final int SKIP_FRAMES = 4;
/*      */   public static final int EXPAND_FRAMES = 8;
/*      */   public final byte[] b;
/*      */   private final int[] items;
/*      */   private final String[] strings;
/*      */   private final int maxStringLength;
/*      */   public final int header;
/*      */ 
/*      */   public ClassReader(byte[] b)
/*      */   {
/*  153 */     this(b, 0, b.length);
/*      */   }
/*      */ 
/*      */   public ClassReader(byte[] b, int off, int len)
/*      */   {
/*  167 */     this.b = b;
/*      */ 
/*  175 */     this.items = new int[readUnsignedShort(off + 8)];
/*  176 */     int n = this.items.length;
/*  177 */     this.strings = new String[n];
/*  178 */     int max = 0;
/*  179 */     int index = off + 10;
/*  180 */     for (int i = 1; i < n; i++) {
/*  181 */       this.items[i] = (index + 1);
/*      */       int size;
/*      */       int size;
/*      */       int size;
/*  183 */       switch (b[index]) {
/*      */       case 3:
/*      */       case 4:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 18:
/*  191 */         size = 5;
/*  192 */         break;
/*      */       case 5:
/*      */       case 6:
/*  195 */         int size = 9;
/*  196 */         i++;
/*  197 */         break;
/*      */       case 1:
/*  199 */         int size = 3 + readUnsignedShort(index + 1);
/*  200 */         if (size > max)
/*  201 */           max = size; break;
/*      */       case 15:
/*  205 */         size = 4;
/*  206 */         break;
/*      */       case 2:
/*      */       case 7:
/*      */       case 8:
/*      */       case 13:
/*      */       case 14:
/*      */       case 16:
/*      */       case 17:
/*      */       default:
/*  211 */         size = 3;
/*      */       }
/*      */ 
/*  214 */       index += size;
/*      */     }
/*  216 */     this.maxStringLength = max;
/*      */ 
/*  218 */     this.header = index;
/*      */   }
/*      */ 
/*      */   public int getAccess()
/*      */   {
/*  231 */     return readUnsignedShort(this.header);
/*      */   }
/*      */ 
/*      */   public String getClassName()
/*      */   {
/*  243 */     return readClass(this.header + 2, new char[this.maxStringLength]);
/*      */   }
/*      */ 
/*      */   public String getSuperName()
/*      */   {
/*  257 */     return readClass(this.header + 4, new char[this.maxStringLength]);
/*      */   }
/*      */ 
/*      */   public String[] getInterfaces()
/*      */   {
/*  270 */     int index = this.header + 6;
/*  271 */     int n = readUnsignedShort(index);
/*  272 */     String[] interfaces = new String[n];
/*  273 */     if (n > 0) {
/*  274 */       char[] buf = new char[this.maxStringLength];
/*  275 */       for (int i = 0; i < n; i++) {
/*  276 */         index += 2;
/*  277 */         interfaces[i] = readClass(index, buf);
/*      */       }
/*      */     }
/*  280 */     return interfaces;
/*      */   }
/*      */ 
/*      */   void copyPool(ClassWriter classWriter)
/*      */   {
/*  291 */     char[] buf = new char[this.maxStringLength];
/*  292 */     int ll = this.items.length;
/*  293 */     Item[] items2 = new Item[ll];
/*  294 */     for (int i = 1; i < ll; i++) {
/*  295 */       int index = this.items[i];
/*  296 */       int tag = this.b[(index - 1)];
/*  297 */       Item item = new Item(i);
/*      */ 
/*  299 */       switch (tag) {
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*  303 */         int nameType = this.items[readUnsignedShort(index + 2)];
/*  304 */         item.set(tag, readClass(index, buf), readUTF8(nameType, buf), 
/*  305 */           readUTF8(nameType + 2, buf));
/*      */ 
/*  306 */         break;
/*      */       case 3:
/*  308 */         item.set(readInt(index));
/*  309 */         break;
/*      */       case 4:
/*  311 */         item.set(Float.intBitsToFloat(readInt(index)));
/*  312 */         break;
/*      */       case 12:
/*  314 */         item.set(tag, readUTF8(index, buf), readUTF8(index + 2, buf), null);
/*      */ 
/*  316 */         break;
/*      */       case 5:
/*  318 */         item.set(readLong(index));
/*  319 */         i++;
/*  320 */         break;
/*      */       case 6:
/*  322 */         item.set(Double.longBitsToDouble(readLong(index)));
/*  323 */         i++;
/*  324 */         break;
/*      */       case 1:
/*  326 */         String s = this.strings[i];
/*  327 */         if (s == null) {
/*  328 */           index = this.items[i];
/*  329 */           s = this.strings[i] =  = readUTF(index + 2, 
/*  330 */             readUnsignedShort(index), 
/*  330 */             buf);
/*      */         }
/*  332 */         item.set(tag, s, null, null);
/*  333 */         break;
/*      */       case 15:
/*  336 */         int fieldOrMethodRef = this.items[readUnsignedShort(index + 1)];
/*  337 */         int nameType = this.items[readUnsignedShort(fieldOrMethodRef + 2)];
/*  338 */         item.set(20 + readByte(index), 
/*  339 */           readClass(fieldOrMethodRef, buf), 
/*  340 */           readUTF8(nameType, buf), 
/*  340 */           readUTF8(nameType + 2, buf));
/*  341 */         break;
/*      */       case 18:
/*  344 */         if (classWriter.bootstrapMethods == null) {
/*  345 */           copyBootstrapMethods(classWriter, items2, buf);
/*      */         }
/*  347 */         int nameType = this.items[readUnsignedShort(index + 2)];
/*  348 */         item.set(readUTF8(nameType, buf), readUTF8(nameType + 2, buf), 
/*  349 */           readUnsignedShort(index));
/*      */ 
/*  350 */         break;
/*      */       case 2:
/*      */       case 7:
/*      */       case 8:
/*      */       case 13:
/*      */       case 14:
/*      */       case 16:
/*      */       case 17:
/*      */       default:
/*  355 */         item.set(tag, readUTF8(index, buf), null, null);
/*      */       }
/*      */ 
/*  359 */       int index2 = item.hashCode % items2.length;
/*  360 */       item.next = items2[index2];
/*  361 */       items2[index2] = item;
/*      */     }
/*      */ 
/*  364 */     int off = this.items[1] - 1;
/*  365 */     classWriter.pool.putByteArray(this.b, off, this.header - off);
/*  366 */     classWriter.items = items2;
/*  367 */     classWriter.threshold = ((int)(0.75D * ll));
/*  368 */     classWriter.index = ll;
/*      */   }
/*      */ 
/*      */   private void copyBootstrapMethods(ClassWriter classWriter, Item[] items, char[] c)
/*      */   {
/*  381 */     int u = getAttributes();
/*  382 */     boolean found = false;
/*  383 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  384 */       String attrName = readUTF8(u + 2, c);
/*  385 */       if ("BootstrapMethods".equals(attrName)) {
/*  386 */         found = true;
/*  387 */         break;
/*      */       }
/*  389 */       u += 6 + readInt(u + 4);
/*      */     }
/*  391 */     if (!found) {
/*  392 */       return;
/*      */     }
/*      */ 
/*  395 */     int boostrapMethodCount = readUnsignedShort(u + 8);
/*  396 */     int j = 0; for (int v = u + 10; j < boostrapMethodCount; j++) {
/*  397 */       int position = v - u - 10;
/*  398 */       int hashCode = readConst(readUnsignedShort(v), c).hashCode();
/*  399 */       for (int k = readUnsignedShort(v + 2); k > 0; k--) {
/*  400 */         hashCode ^= readConst(readUnsignedShort(v + 4), c).hashCode();
/*  401 */         v += 2;
/*      */       }
/*  403 */       v += 4;
/*  404 */       Item item = new Item(j);
/*  405 */       item.set(position, hashCode & 0x7FFFFFFF);
/*  406 */       int index = item.hashCode % items.length;
/*  407 */       item.next = items[index];
/*  408 */       items[index] = item;
/*      */     }
/*  410 */     int attrSize = readInt(u + 4);
/*  411 */     ByteVector bootstrapMethods = new ByteVector(attrSize + 62);
/*  412 */     bootstrapMethods.putByteArray(this.b, u + 10, attrSize - 2);
/*  413 */     classWriter.bootstrapMethodsCount = boostrapMethodCount;
/*  414 */     classWriter.bootstrapMethods = bootstrapMethods;
/*      */   }
/*      */ 
/*      */   public ClassReader(InputStream is)
/*      */     throws IOException
/*      */   {
/*  426 */     this(readClass(is, false));
/*      */   }
/*      */ 
/*      */   public ClassReader(String name)
/*      */     throws IOException
/*      */   {
/*  438 */     this(readClass(
/*  439 */       ClassLoader.getSystemResourceAsStream(name
/*  439 */       .replace('.', '/') + 
/*  439 */       ".class"), true));
/*      */   }
/*      */ 
/*      */   private static byte[] readClass(InputStream is, boolean close)
/*      */     throws IOException
/*      */   {
/*  456 */     if (is == null)
/*  457 */       throw new IOException("Class not found");
/*      */     try
/*      */     {
/*  460 */       byte[] b = new byte[is.available()];
/*  461 */       int len = 0;
/*      */       while (true) {
/*  463 */         int n = is.read(b, len, b.length - len);
/*  464 */         if (n == -1)
/*      */         {
/*      */           byte[] c;
/*  465 */           if (len < b.length) {
/*  466 */             c = new byte[len];
/*  467 */             System.arraycopy(b, 0, c, 0, len);
/*  468 */             b = c;
/*      */           }
/*  470 */           return b;
/*      */         }
/*  472 */         len += n;
/*  473 */         if (len == b.length) {
/*  474 */           int last = is.read();
/*  475 */           if (last < 0) {
/*  476 */             return b;
/*      */           }
/*  478 */           byte[] c = new byte[b.length + 1000];
/*  479 */           System.arraycopy(b, 0, c, 0, len);
/*  480 */           c[(len++)] = ((byte)last);
/*  481 */           b = c;
/*      */         }
/*      */       }
/*      */     } finally {
/*  485 */       if (close)
/*  486 */         is.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void accept(ClassVisitor classVisitor, int flags)
/*      */   {
/*  508 */     accept(classVisitor, new Attribute[0], flags);
/*      */   }
/*      */ 
/*      */   public void accept(ClassVisitor classVisitor, Attribute[] attrs, int flags)
/*      */   {
/*  534 */     int u = this.header;
/*  535 */     char[] c = new char[this.maxStringLength];
/*      */ 
/*  537 */     Context context = new Context();
/*  538 */     context.attrs = attrs;
/*  539 */     context.flags = flags;
/*  540 */     context.buffer = c;
/*      */ 
/*  543 */     int access = readUnsignedShort(u);
/*  544 */     String name = readClass(u + 2, c);
/*  545 */     String superClass = readClass(u + 4, c);
/*  546 */     String[] interfaces = new String[readUnsignedShort(u + 6)];
/*  547 */     u += 8;
/*  548 */     for (int i = 0; i < interfaces.length; i++) {
/*  549 */       interfaces[i] = readClass(u, c);
/*  550 */       u += 2;
/*      */     }
/*      */ 
/*  554 */     String signature = null;
/*  555 */     String sourceFile = null;
/*  556 */     String sourceDebug = null;
/*  557 */     String enclosingOwner = null;
/*  558 */     String enclosingName = null;
/*  559 */     String enclosingDesc = null;
/*  560 */     int anns = 0;
/*  561 */     int ianns = 0;
/*  562 */     int innerClasses = 0;
/*  563 */     Attribute attributes = null;
/*      */ 
/*  565 */     u = getAttributes();
/*  566 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  567 */       String attrName = readUTF8(u + 2, c);
/*      */ 
/*  570 */       if ("SourceFile".equals(attrName)) {
/*  571 */         sourceFile = readUTF8(u + 8, c);
/*  572 */       } else if ("InnerClasses".equals(attrName)) {
/*  573 */         innerClasses = u + 8;
/*  574 */       } else if ("EnclosingMethod".equals(attrName)) {
/*  575 */         enclosingOwner = readClass(u + 8, c);
/*  576 */         int item = readUnsignedShort(u + 10);
/*  577 */         if (item != 0) {
/*  578 */           enclosingName = readUTF8(this.items[item], c);
/*  579 */           enclosingDesc = readUTF8(this.items[item] + 2, c);
/*      */         }
/*  581 */       } else if ("Signature".equals(attrName)) {
/*  582 */         signature = readUTF8(u + 8, c);
/*      */       }
/*  584 */       else if ("RuntimeVisibleAnnotations"
/*  584 */         .equals(attrName))
/*      */       {
/*  585 */         anns = u + 8;
/*  586 */       } else if ("Deprecated".equals(attrName)) {
/*  587 */         access |= 131072;
/*  588 */       } else if ("Synthetic".equals(attrName)) {
/*  589 */         access |= 266240;
/*      */       }
/*  591 */       else if ("SourceDebugExtension".equals(attrName)) {
/*  592 */         int len = readInt(u + 4);
/*  593 */         sourceDebug = readUTF(u + 8, len, new char[len]);
/*      */       }
/*  595 */       else if ("RuntimeInvisibleAnnotations"
/*  595 */         .equals(attrName))
/*      */       {
/*  596 */         ianns = u + 8;
/*  597 */       } else if ("BootstrapMethods".equals(attrName)) {
/*  598 */         int[] bootstrapMethods = new int[readUnsignedShort(u + 8)];
/*  599 */         int j = 0; for (int v = u + 10; j < bootstrapMethods.length; j++) {
/*  600 */           bootstrapMethods[j] = v;
/*  601 */           v += (2 + readUnsignedShort(v + 2) << 1);
/*      */         }
/*  603 */         context.bootstrapMethods = bootstrapMethods;
/*      */       } else {
/*  605 */         Attribute attr = readAttribute(attrs, attrName, u + 8, 
/*  606 */           readInt(u + 4), 
/*  606 */           c, -1, null);
/*  607 */         if (attr != null) {
/*  608 */           attr.next = attributes;
/*  609 */           attributes = attr;
/*      */         }
/*      */       }
/*  612 */       u += 6 + readInt(u + 4);
/*      */     }
/*      */ 
/*  616 */     classVisitor.visit(readInt(this.items[1] - 7), access, name, signature, superClass, interfaces);
/*      */ 
/*  620 */     if (((flags & 0x2) == 0) && ((sourceFile != null) || (sourceDebug != null)))
/*      */     {
/*  622 */       classVisitor.visitSource(sourceFile, sourceDebug);
/*      */     }
/*      */ 
/*  626 */     if (enclosingOwner != null) {
/*  627 */       classVisitor.visitOuterClass(enclosingOwner, enclosingName, enclosingDesc);
/*      */     }
/*      */ 
/*  632 */     if (anns != 0) {
/*  633 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  634 */         v = readAnnotationValues(v + 2, c, true, classVisitor
/*  635 */           .visitAnnotation(readUTF8(v, c), 
/*  635 */           true));
/*      */       }
/*      */     }
/*  638 */     if (ianns != 0) {
/*  639 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  640 */         v = readAnnotationValues(v + 2, c, true, classVisitor
/*  641 */           .visitAnnotation(readUTF8(v, c), 
/*  641 */           false));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  646 */     while (attributes != null) {
/*  647 */       Attribute attr = attributes.next;
/*  648 */       attributes.next = null;
/*  649 */       classVisitor.visitAttribute(attributes);
/*  650 */       attributes = attr;
/*      */     }
/*      */ 
/*  654 */     if (innerClasses != 0) {
/*  655 */       int v = innerClasses + 2;
/*  656 */       for (int i = readUnsignedShort(innerClasses); i > 0; i--) {
/*  657 */         classVisitor.visitInnerClass(readClass(v, c), 
/*  658 */           readClass(v + 2, c), 
/*  658 */           readUTF8(v + 4, c), 
/*  659 */           readUnsignedShort(v + 6));
/*      */ 
/*  660 */         v += 8;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  665 */     u = this.header + 10 + 2 * interfaces.length;
/*  666 */     for (int i = readUnsignedShort(u - 2); i > 0; i--) {
/*  667 */       u = readField(classVisitor, context, u);
/*      */     }
/*  669 */     u += 2;
/*  670 */     for (int i = readUnsignedShort(u - 2); i > 0; i--) {
/*  671 */       u = readMethod(classVisitor, context, u);
/*      */     }
/*      */ 
/*  675 */     classVisitor.visitEnd();
/*      */   }
/*      */ 
/*      */   private int readField(ClassVisitor classVisitor, Context context, int u)
/*      */   {
/*  692 */     char[] c = context.buffer;
/*  693 */     int access = readUnsignedShort(u);
/*  694 */     String name = readUTF8(u + 2, c);
/*  695 */     String desc = readUTF8(u + 4, c);
/*  696 */     u += 6;
/*      */ 
/*  699 */     String signature = null;
/*  700 */     int anns = 0;
/*  701 */     int ianns = 0;
/*  702 */     Object value = null;
/*  703 */     Attribute attributes = null;
/*      */ 
/*  705 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  706 */       String attrName = readUTF8(u + 2, c);
/*      */ 
/*  709 */       if ("ConstantValue".equals(attrName)) {
/*  710 */         int item = readUnsignedShort(u + 8);
/*  711 */         value = item == 0 ? null : readConst(item, c);
/*  712 */       } else if ("Signature".equals(attrName)) {
/*  713 */         signature = readUTF8(u + 8, c);
/*  714 */       } else if ("Deprecated".equals(attrName)) {
/*  715 */         access |= 131072;
/*  716 */       } else if ("Synthetic".equals(attrName)) {
/*  717 */         access |= 266240;
/*      */       }
/*  720 */       else if ("RuntimeVisibleAnnotations"
/*  720 */         .equals(attrName))
/*      */       {
/*  721 */         anns = u + 8;
/*      */       }
/*  723 */       else if ("RuntimeInvisibleAnnotations"
/*  723 */         .equals(attrName))
/*      */       {
/*  724 */         ianns = u + 8;
/*      */       } else {
/*  726 */         Attribute attr = readAttribute(context.attrs, attrName, u + 8, 
/*  727 */           readInt(u + 4), 
/*  727 */           c, -1, null);
/*  728 */         if (attr != null) {
/*  729 */           attr.next = attributes;
/*  730 */           attributes = attr;
/*      */         }
/*      */       }
/*  733 */       u += 6 + readInt(u + 4);
/*      */     }
/*  735 */     u += 2;
/*      */ 
/*  738 */     FieldVisitor fv = classVisitor.visitField(access, name, desc, signature, value);
/*      */ 
/*  740 */     if (fv == null) {
/*  741 */       return u;
/*      */     }
/*      */ 
/*  745 */     if (anns != 0) {
/*  746 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  747 */         v = readAnnotationValues(v + 2, c, true, fv
/*  748 */           .visitAnnotation(readUTF8(v, c), 
/*  748 */           true));
/*      */       }
/*      */     }
/*  751 */     if (ianns != 0) {
/*  752 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  753 */         v = readAnnotationValues(v + 2, c, true, fv
/*  754 */           .visitAnnotation(readUTF8(v, c), 
/*  754 */           false));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  759 */     while (attributes != null) {
/*  760 */       Attribute attr = attributes.next;
/*  761 */       attributes.next = null;
/*  762 */       fv.visitAttribute(attributes);
/*  763 */       attributes = attr;
/*      */     }
/*      */ 
/*  767 */     fv.visitEnd();
/*      */ 
/*  769 */     return u;
/*      */   }
/*      */ 
/*      */   private int readMethod(ClassVisitor classVisitor, Context context, int u)
/*      */   {
/*  786 */     char[] c = context.buffer;
/*  787 */     int access = readUnsignedShort(u);
/*  788 */     String name = readUTF8(u + 2, c);
/*  789 */     String desc = readUTF8(u + 4, c);
/*  790 */     u += 6;
/*      */ 
/*  793 */     int code = 0;
/*  794 */     int exception = 0;
/*  795 */     String[] exceptions = null;
/*  796 */     String signature = null;
/*  797 */     int anns = 0;
/*  798 */     int ianns = 0;
/*  799 */     int dann = 0;
/*  800 */     int mpanns = 0;
/*  801 */     int impanns = 0;
/*  802 */     int firstAttribute = u;
/*  803 */     Attribute attributes = null;
/*      */ 
/*  805 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  806 */       String attrName = readUTF8(u + 2, c);
/*      */ 
/*  809 */       if ("Code".equals(attrName)) {
/*  810 */         if ((context.flags & 0x1) == 0)
/*  811 */           code = u + 8;
/*      */       }
/*  813 */       else if ("Exceptions".equals(attrName)) {
/*  814 */         exceptions = new String[readUnsignedShort(u + 8)];
/*  815 */         exception = u + 10;
/*  816 */         for (int j = 0; j < exceptions.length; j++) {
/*  817 */           exceptions[j] = readClass(exception, c);
/*  818 */           exception += 2;
/*      */         }
/*  820 */       } else if ("Signature".equals(attrName)) {
/*  821 */         signature = readUTF8(u + 8, c);
/*  822 */       } else if ("Deprecated".equals(attrName)) {
/*  823 */         access |= 131072;
/*      */       }
/*  825 */       else if ("RuntimeVisibleAnnotations"
/*  825 */         .equals(attrName))
/*      */       {
/*  826 */         anns = u + 8;
/*  827 */       } else if ("AnnotationDefault".equals(attrName)) {
/*  828 */         dann = u + 8;
/*  829 */       } else if ("Synthetic".equals(attrName)) {
/*  830 */         access |= 266240;
/*      */       }
/*  833 */       else if ("RuntimeInvisibleAnnotations"
/*  833 */         .equals(attrName))
/*      */       {
/*  834 */         ianns = u + 8;
/*      */       }
/*  836 */       else if ("RuntimeVisibleParameterAnnotations"
/*  836 */         .equals(attrName))
/*      */       {
/*  837 */         mpanns = u + 8;
/*      */       }
/*  839 */       else if ("RuntimeInvisibleParameterAnnotations"
/*  839 */         .equals(attrName))
/*      */       {
/*  840 */         impanns = u + 8;
/*      */       } else {
/*  842 */         Attribute attr = readAttribute(context.attrs, attrName, u + 8, 
/*  843 */           readInt(u + 4), 
/*  843 */           c, -1, null);
/*  844 */         if (attr != null) {
/*  845 */           attr.next = attributes;
/*  846 */           attributes = attr;
/*      */         }
/*      */       }
/*  849 */       u += 6 + readInt(u + 4);
/*      */     }
/*  851 */     u += 2;
/*      */ 
/*  854 */     MethodVisitor mv = classVisitor.visitMethod(access, name, desc, signature, exceptions);
/*      */ 
/*  856 */     if (mv == null) {
/*  857 */       return u;
/*      */     }
/*      */ 
/*  870 */     if ((mv instanceof MethodWriter)) {
/*  871 */       MethodWriter mw = (MethodWriter)mv;
/*  872 */       if ((mw.cw.cr == this) && (signature == mw.signature)) {
/*  873 */         boolean sameExceptions = false;
/*  874 */         if (exceptions == null) {
/*  875 */           sameExceptions = mw.exceptionCount == 0;
/*  876 */         } else if (exceptions.length == mw.exceptionCount) {
/*  877 */           sameExceptions = true;
/*  878 */           for (int j = exceptions.length - 1; j >= 0; j--) {
/*  879 */             exception -= 2;
/*  880 */             if (mw.exceptions[j] != readUnsignedShort(exception)) {
/*  881 */               sameExceptions = false;
/*  882 */               break;
/*      */             }
/*      */           }
/*      */         }
/*  886 */         if (sameExceptions)
/*      */         {
/*  892 */           mw.classReaderOffset = firstAttribute;
/*  893 */           mw.classReaderLength = (u - firstAttribute);
/*  894 */           return u;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  900 */     if (dann != 0) {
/*  901 */       AnnotationVisitor dv = mv.visitAnnotationDefault();
/*  902 */       readAnnotationValue(dann, c, null, dv);
/*  903 */       if (dv != null) {
/*  904 */         dv.visitEnd();
/*      */       }
/*      */     }
/*  907 */     if (anns != 0) {
/*  908 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  909 */         v = readAnnotationValues(v + 2, c, true, mv
/*  910 */           .visitAnnotation(readUTF8(v, c), 
/*  910 */           true));
/*      */       }
/*      */     }
/*  913 */     if (ianns != 0) {
/*  914 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  915 */         v = readAnnotationValues(v + 2, c, true, mv
/*  916 */           .visitAnnotation(readUTF8(v, c), 
/*  916 */           false));
/*      */       }
/*      */     }
/*  919 */     if (mpanns != 0) {
/*  920 */       readParameterAnnotations(mpanns, desc, c, true, mv);
/*      */     }
/*  922 */     if (impanns != 0) {
/*  923 */       readParameterAnnotations(impanns, desc, c, false, mv);
/*      */     }
/*      */ 
/*  927 */     while (attributes != null) {
/*  928 */       Attribute attr = attributes.next;
/*  929 */       attributes.next = null;
/*  930 */       mv.visitAttribute(attributes);
/*  931 */       attributes = attr;
/*      */     }
/*      */ 
/*  935 */     if (code != 0) {
/*  936 */       context.access = access;
/*  937 */       context.name = name;
/*  938 */       context.desc = desc;
/*  939 */       mv.visitCode();
/*  940 */       readCode(mv, context, code);
/*      */     }
/*      */ 
/*  944 */     mv.visitEnd();
/*      */ 
/*  946 */     return u;
/*      */   }
/*      */ 
/*      */   private void readCode(MethodVisitor mv, Context context, int u)
/*      */   {
/*  961 */     byte[] b = this.b;
/*  962 */     char[] c = context.buffer;
/*  963 */     int maxStack = readUnsignedShort(u);
/*  964 */     int maxLocals = readUnsignedShort(u + 2);
/*  965 */     int codeLength = readInt(u + 4);
/*  966 */     u += 8;
/*      */ 
/*  969 */     int codeStart = u;
/*  970 */     int codeEnd = u + codeLength;
/*  971 */     Label[] labels = new Label[codeLength + 2];
/*  972 */     readLabel(codeLength + 1, labels);
/*  973 */     while (u < codeEnd) {
/*  974 */       int offset = u - codeStart;
/*  975 */       int opcode = b[u] & 0xFF;
/*  976 */       switch (ClassWriter.TYPE[opcode]) {
/*      */       case 0:
/*      */       case 4:
/*  979 */         u++;
/*  980 */         break;
/*      */       case 9:
/*  982 */         readLabel(offset + readShort(u + 1), labels);
/*  983 */         u += 3;
/*  984 */         break;
/*      */       case 10:
/*  986 */         readLabel(offset + readInt(u + 1), labels);
/*  987 */         u += 5;
/*  988 */         break;
/*      */       case 17:
/*  990 */         opcode = b[(u + 1)] & 0xFF;
/*  991 */         if (opcode == 132)
/*  992 */           u += 6;
/*      */         else {
/*  994 */           u += 4;
/*      */         }
/*  996 */         break;
/*      */       case 14:
/*  999 */         u = u + 4 - (offset & 0x3);
/*      */ 
/* 1001 */         readLabel(offset + readInt(u), labels);
/* 1002 */         for (int i = readInt(u + 8) - readInt(u + 4) + 1; i > 0; i--) {
/* 1003 */           readLabel(offset + readInt(u + 12), labels);
/* 1004 */           u += 4;
/*      */         }
/* 1006 */         u += 12;
/* 1007 */         break;
/*      */       case 15:
/* 1010 */         u = u + 4 - (offset & 0x3);
/*      */ 
/* 1012 */         readLabel(offset + readInt(u), labels);
/* 1013 */         for (int i = readInt(u + 4); i > 0; i--) {
/* 1014 */           readLabel(offset + readInt(u + 12), labels);
/* 1015 */           u += 8;
/*      */         }
/* 1017 */         u += 8;
/* 1018 */         break;
/*      */       case 1:
/*      */       case 3:
/*      */       case 11:
/* 1022 */         u += 2;
/* 1023 */         break;
/*      */       case 2:
/*      */       case 5:
/*      */       case 6:
/*      */       case 12:
/*      */       case 13:
/* 1029 */         u += 3;
/* 1030 */         break;
/*      */       case 7:
/*      */       case 8:
/* 1033 */         u += 5;
/* 1034 */         break;
/*      */       case 16:
/*      */       default:
/* 1037 */         u += 4;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1043 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1044 */       Label start = readLabel(readUnsignedShort(u + 2), labels);
/* 1045 */       Label end = readLabel(readUnsignedShort(u + 4), labels);
/* 1046 */       Label handler = readLabel(readUnsignedShort(u + 6), labels);
/* 1047 */       String type = readUTF8(this.items[readUnsignedShort(u + 8)], c);
/* 1048 */       mv.visitTryCatchBlock(start, end, handler, type);
/* 1049 */       u += 8;
/*      */     }
/* 1051 */     u += 2;
/*      */ 
/* 1054 */     int varTable = 0;
/* 1055 */     int varTypeTable = 0;
/* 1056 */     boolean zip = true;
/* 1057 */     boolean unzip = (context.flags & 0x8) != 0;
/* 1058 */     int stackMap = 0;
/* 1059 */     int stackMapSize = 0;
/* 1060 */     int frameCount = 0;
/* 1061 */     Context frame = null;
/* 1062 */     Attribute attributes = null;
/*      */ 
/* 1064 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1065 */       String attrName = readUTF8(u + 2, c);
/* 1066 */       if ("LocalVariableTable".equals(attrName)) {
/* 1067 */         if ((context.flags & 0x2) == 0) {
/* 1068 */           varTable = u + 8;
/* 1069 */           int j = readUnsignedShort(u + 8); for (int v = u; j > 0; j--) {
/* 1070 */             int label = readUnsignedShort(v + 10);
/* 1071 */             if (labels[label] == null) {
/* 1072 */               readLabel(label, labels).status |= 1;
/*      */             }
/* 1074 */             label += readUnsignedShort(v + 12);
/* 1075 */             if (labels[label] == null) {
/* 1076 */               readLabel(label, labels).status |= 1;
/*      */             }
/* 1078 */             v += 10;
/*      */           }
/*      */         }
/* 1081 */       } else if ("LocalVariableTypeTable".equals(attrName))
/* 1082 */         varTypeTable = u + 8;
/* 1083 */       else if ("LineNumberTable".equals(attrName)) {
/* 1084 */         if ((context.flags & 0x2) == 0) {
/* 1085 */           int j = readUnsignedShort(u + 8); for (int v = u; j > 0; j--) {
/* 1086 */             int label = readUnsignedShort(v + 10);
/* 1087 */             if (labels[label] == null) {
/* 1088 */               readLabel(label, labels).status |= 1;
/*      */             }
/* 1090 */             labels[label].line = readUnsignedShort(v + 12);
/* 1091 */             v += 4;
/*      */           }
/*      */         }
/* 1094 */       } else if ("StackMapTable".equals(attrName)) {
/* 1095 */         if ((context.flags & 0x4) == 0) {
/* 1096 */           stackMap = u + 10;
/* 1097 */           stackMapSize = readInt(u + 4);
/* 1098 */           frameCount = readUnsignedShort(u + 8);
/*      */         }
/*      */ 
/*      */       }
/* 1118 */       else if ("StackMap".equals(attrName)) {
/* 1119 */         if ((context.flags & 0x4) == 0) {
/* 1120 */           zip = false;
/* 1121 */           stackMap = u + 10;
/* 1122 */           stackMapSize = readInt(u + 4);
/* 1123 */           frameCount = readUnsignedShort(u + 8);
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1131 */         for (int j = 0; j < context.attrs.length; j++) {
/* 1132 */           if (context.attrs[j].type.equals(attrName)) {
/* 1133 */             Attribute attr = context.attrs[j].read(this, u + 8, 
/* 1134 */               readInt(u + 4), 
/* 1134 */               c, codeStart - 8, labels);
/* 1135 */             if (attr != null) {
/* 1136 */               attr.next = attributes;
/* 1137 */               attributes = attr;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1142 */       u += 6 + readInt(u + 4);
/*      */     }
/* 1144 */     u += 2;
/*      */ 
/* 1147 */     if (stackMap != 0)
/*      */     {
/* 1153 */       frame = context;
/* 1154 */       frame.offset = -1;
/* 1155 */       frame.mode = 0;
/* 1156 */       frame.localCount = 0;
/* 1157 */       frame.localDiff = 0;
/* 1158 */       frame.stackCount = 0;
/* 1159 */       frame.local = new Object[maxLocals];
/* 1160 */       frame.stack = new Object[maxStack];
/* 1161 */       if (unzip) {
/* 1162 */         getImplicitFrame(context);
/*      */       }
/*      */ 
/* 1175 */       for (int i = stackMap; i < stackMap + stackMapSize - 2; i++) {
/* 1176 */         if (b[i] == 8) {
/* 1177 */           int v = readUnsignedShort(i + 1);
/* 1178 */           if ((v >= 0) && (v < codeLength) && 
/* 1179 */             ((b[(codeStart + v)] & 0xFF) == 187)) {
/* 1180 */             readLabel(v, labels);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1188 */     u = codeStart;
/* 1189 */     while (u < codeEnd) {
/* 1190 */       int offset = u - codeStart;
/*      */ 
/* 1193 */       Label l = labels[offset];
/* 1194 */       if (l != null) {
/* 1195 */         mv.visitLabel(l);
/* 1196 */         if (((context.flags & 0x2) == 0) && (l.line > 0)) {
/* 1197 */           mv.visitLineNumber(l.line, l);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1202 */       while ((frame != null) && ((frame.offset == offset) || (frame.offset == -1)))
/*      */       {
/* 1206 */         if (frame.offset != -1) {
/* 1207 */           if ((!zip) || (unzip)) {
/* 1208 */             mv.visitFrame(-1, frame.localCount, frame.local, frame.stackCount, frame.stack);
/*      */           }
/*      */           else {
/* 1211 */             mv.visitFrame(frame.mode, frame.localDiff, frame.local, frame.stackCount, frame.stack);
/*      */           }
/*      */         }
/*      */ 
/* 1215 */         if (frameCount > 0) {
/* 1216 */           stackMap = readFrame(stackMap, zip, unzip, labels, frame);
/* 1217 */           frameCount--;
/*      */         } else {
/* 1219 */           frame = null;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1224 */       int opcode = b[u] & 0xFF;
/* 1225 */       switch (ClassWriter.TYPE[opcode]) {
/*      */       case 0:
/* 1227 */         mv.visitInsn(opcode);
/* 1228 */         u++;
/* 1229 */         break;
/*      */       case 4:
/* 1231 */         if (opcode > 54) {
/* 1232 */           opcode -= 59;
/* 1233 */           mv.visitVarInsn(54 + (opcode >> 2), opcode & 0x3);
/*      */         }
/*      */         else {
/* 1236 */           opcode -= 26;
/* 1237 */           mv.visitVarInsn(21 + (opcode >> 2), opcode & 0x3);
/*      */         }
/* 1239 */         u++;
/* 1240 */         break;
/*      */       case 9:
/* 1242 */         mv.visitJumpInsn(opcode, labels[(offset + readShort(u + 1))]);
/* 1243 */         u += 3;
/* 1244 */         break;
/*      */       case 10:
/* 1246 */         mv.visitJumpInsn(opcode - 33, labels[(offset + readInt(u + 1))]);
/* 1247 */         u += 5;
/* 1248 */         break;
/*      */       case 17:
/* 1250 */         opcode = b[(u + 1)] & 0xFF;
/* 1251 */         if (opcode == 132) {
/* 1252 */           mv.visitIincInsn(readUnsignedShort(u + 2), readShort(u + 4));
/* 1253 */           u += 6;
/*      */         } else {
/* 1255 */           mv.visitVarInsn(opcode, readUnsignedShort(u + 2));
/* 1256 */           u += 4;
/*      */         }
/* 1258 */         break;
/*      */       case 14:
/* 1261 */         u = u + 4 - (offset & 0x3);
/*      */ 
/* 1263 */         int label = offset + readInt(u);
/* 1264 */         int min = readInt(u + 4);
/* 1265 */         int max = readInt(u + 8);
/* 1266 */         Label[] table = new Label[max - min + 1];
/* 1267 */         u += 12;
/* 1268 */         for (int i = 0; i < table.length; i++) {
/* 1269 */           table[i] = labels[(offset + readInt(u))];
/* 1270 */           u += 4;
/*      */         }
/* 1272 */         mv.visitTableSwitchInsn(min, max, labels[label], table);
/* 1273 */         break;
/*      */       case 15:
/* 1277 */         u = u + 4 - (offset & 0x3);
/*      */ 
/* 1279 */         int label = offset + readInt(u);
/* 1280 */         int len = readInt(u + 4);
/* 1281 */         int[] keys = new int[len];
/* 1282 */         Label[] values = new Label[len];
/* 1283 */         u += 8;
/* 1284 */         for (int i = 0; i < len; i++) {
/* 1285 */           keys[i] = readInt(u);
/* 1286 */           values[i] = labels[(offset + readInt(u + 4))];
/* 1287 */           u += 8;
/*      */         }
/* 1289 */         mv.visitLookupSwitchInsn(labels[label], keys, values);
/* 1290 */         break;
/*      */       case 3:
/* 1293 */         mv.visitVarInsn(opcode, b[(u + 1)] & 0xFF);
/* 1294 */         u += 2;
/* 1295 */         break;
/*      */       case 1:
/* 1297 */         mv.visitIntInsn(opcode, b[(u + 1)]);
/* 1298 */         u += 2;
/* 1299 */         break;
/*      */       case 2:
/* 1301 */         mv.visitIntInsn(opcode, readShort(u + 1));
/* 1302 */         u += 3;
/* 1303 */         break;
/*      */       case 11:
/* 1305 */         mv.visitLdcInsn(readConst(b[(u + 1)] & 0xFF, c));
/* 1306 */         u += 2;
/* 1307 */         break;
/*      */       case 12:
/* 1309 */         mv.visitLdcInsn(readConst(readUnsignedShort(u + 1), c));
/* 1310 */         u += 3;
/* 1311 */         break;
/*      */       case 6:
/*      */       case 7:
/* 1314 */         int cpIndex = this.items[readUnsignedShort(u + 1)];
/* 1315 */         String iowner = readClass(cpIndex, c);
/* 1316 */         cpIndex = this.items[readUnsignedShort(cpIndex + 2)];
/* 1317 */         String iname = readUTF8(cpIndex, c);
/* 1318 */         String idesc = readUTF8(cpIndex + 2, c);
/* 1319 */         if (opcode < 182)
/* 1320 */           mv.visitFieldInsn(opcode, iowner, iname, idesc);
/*      */         else {
/* 1322 */           mv.visitMethodInsn(opcode, iowner, iname, idesc);
/*      */         }
/* 1324 */         if (opcode == 185)
/* 1325 */           u += 5;
/*      */         else {
/* 1327 */           u += 3;
/*      */         }
/* 1329 */         break;
/*      */       case 8:
/* 1332 */         int cpIndex = this.items[readUnsignedShort(u + 1)];
/* 1333 */         int bsmIndex = context.bootstrapMethods[readUnsignedShort(cpIndex)];
/* 1334 */         Handle bsm = (Handle)readConst(readUnsignedShort(bsmIndex), c);
/* 1335 */         int bsmArgCount = readUnsignedShort(bsmIndex + 2);
/* 1336 */         Object[] bsmArgs = new Object[bsmArgCount];
/* 1337 */         bsmIndex += 4;
/* 1338 */         for (int i = 0; i < bsmArgCount; i++) {
/* 1339 */           bsmArgs[i] = readConst(readUnsignedShort(bsmIndex), c);
/* 1340 */           bsmIndex += 2;
/*      */         }
/* 1342 */         cpIndex = this.items[readUnsignedShort(cpIndex + 2)];
/* 1343 */         String iname = readUTF8(cpIndex, c);
/* 1344 */         String idesc = readUTF8(cpIndex + 2, c);
/* 1345 */         mv.visitInvokeDynamicInsn(iname, idesc, bsm, bsmArgs);
/* 1346 */         u += 5;
/* 1347 */         break;
/*      */       case 5:
/* 1350 */         mv.visitTypeInsn(opcode, readClass(u + 1, c));
/* 1351 */         u += 3;
/* 1352 */         break;
/*      */       case 13:
/* 1354 */         mv.visitIincInsn(b[(u + 1)] & 0xFF, b[(u + 2)]);
/* 1355 */         u += 3;
/* 1356 */         break;
/*      */       case 16:
/*      */       default:
/* 1359 */         mv.visitMultiANewArrayInsn(readClass(u + 1, c), b[(u + 3)] & 0xFF);
/* 1360 */         u += 4;
/*      */       }
/*      */     }
/*      */ 
/* 1364 */     if (labels[codeLength] != null) {
/* 1365 */       mv.visitLabel(labels[codeLength]);
/*      */     }
/*      */ 
/* 1369 */     if (((context.flags & 0x2) == 0) && (varTable != 0)) {
/* 1370 */       int[] typeTable = null;
/*      */       int i;
/* 1371 */       if (varTypeTable != 0) {
/* 1372 */         u = varTypeTable + 2;
/* 1373 */         typeTable = new int[readUnsignedShort(varTypeTable) * 3];
/* 1374 */         for (i = typeTable.length; i > 0; ) {
/* 1375 */           typeTable[(--i)] = (u + 6);
/* 1376 */           typeTable[(--i)] = readUnsignedShort(u + 8);
/* 1377 */           typeTable[(--i)] = readUnsignedShort(u);
/* 1378 */           u += 10;
/*      */         }
/*      */       }
/* 1381 */       u = varTable + 2;
/* 1382 */       for (int i = readUnsignedShort(varTable); i > 0; i--) {
/* 1383 */         int start = readUnsignedShort(u);
/* 1384 */         int length = readUnsignedShort(u + 2);
/* 1385 */         int index = readUnsignedShort(u + 8);
/* 1386 */         String vsignature = null;
/* 1387 */         if (typeTable != null) {
/* 1388 */           for (int j = 0; j < typeTable.length; j += 3) {
/* 1389 */             if ((typeTable[j] == start) && (typeTable[(j + 1)] == index)) {
/* 1390 */               vsignature = readUTF8(typeTable[(j + 2)], c);
/* 1391 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 1395 */         mv.visitLocalVariable(readUTF8(u + 4, c), readUTF8(u + 6, c), vsignature, labels[start], labels[(start + length)], index);
/*      */ 
/* 1398 */         u += 10;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1403 */     while (attributes != null) {
/* 1404 */       Attribute attr = attributes.next;
/* 1405 */       attributes.next = null;
/* 1406 */       mv.visitAttribute(attributes);
/* 1407 */       attributes = attr;
/*      */     }
/*      */ 
/* 1411 */     mv.visitMaxs(maxStack, maxLocals);
/*      */   }
/*      */ 
/*      */   private void readParameterAnnotations(int v, String desc, char[] buf, boolean visible, MethodVisitor mv)
/*      */   {
/* 1434 */     int n = this.b[(v++)] & 0xFF;
/*      */ 
/* 1441 */     int synthetics = Type.getArgumentTypes(desc).length - n;
/*      */ 
/* 1443 */     for (int i = 0; i < synthetics; i++)
/*      */     {
/* 1445 */       AnnotationVisitor av = mv.visitParameterAnnotation(i, "Ljava/lang/Synthetic;", false);
/* 1446 */       if (av != null) {
/* 1447 */         av.visitEnd();
/*      */       }
/*      */     }
/* 1450 */     for (; i < n + synthetics; i++) {
/* 1451 */       int j = readUnsignedShort(v);
/* 1452 */       v += 2;
/* 1453 */       for (; j > 0; j--) {
/* 1454 */         AnnotationVisitor av = mv.visitParameterAnnotation(i, readUTF8(v, buf), visible);
/* 1455 */         v = readAnnotationValues(v + 2, buf, true, av);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private int readAnnotationValues(int v, char[] buf, boolean named, AnnotationVisitor av)
/*      */   {
/* 1479 */     int i = readUnsignedShort(v);
/* 1480 */     v += 2;
/* 1481 */     if (named) {
/* 1482 */       for (; i > 0; i--) {
/* 1483 */         v = readAnnotationValue(v + 2, buf, readUTF8(v, buf), av);
/*      */       }
/*      */     }
/* 1486 */     for (; i > 0; i--) {
/* 1487 */       v = readAnnotationValue(v, buf, null, av);
/*      */     }
/*      */ 
/* 1490 */     if (av != null) {
/* 1491 */       av.visitEnd();
/*      */     }
/* 1493 */     return v;
/*      */   }
/*      */ 
/*      */   private int readAnnotationValue(int v, char[] buf, String name, AnnotationVisitor av)
/*      */   {
/* 1515 */     if (av == null) {
/* 1516 */       switch (this.b[v] & 0xFF) {
/*      */       case 101:
/* 1518 */         return v + 5;
/*      */       case 64:
/* 1520 */         return readAnnotationValues(v + 3, buf, true, null);
/*      */       case 91:
/* 1522 */         return readAnnotationValues(v + 1, buf, false, null);
/*      */       }
/* 1524 */       return v + 3;
/*      */     }
/*      */ 
/* 1527 */     switch (this.b[(v++)] & 0xFF) {
/*      */     case 68:
/*      */     case 70:
/*      */     case 73:
/*      */     case 74:
/* 1532 */       av.visit(name, readConst(readUnsignedShort(v), buf));
/* 1533 */       v += 2;
/* 1534 */       break;
/*      */     case 66:
/* 1536 */       av.visit(name, new Byte(
/* 1537 */         (byte)readInt(this.items[
/* 1537 */         readUnsignedShort(v)])));
/*      */ 
/* 1538 */       v += 2;
/* 1539 */       break;
/*      */     case 90:
/* 1541 */       av.visit(name, 
/* 1542 */         readInt(this.items[
/* 1542 */         readUnsignedShort(v)]) == 0 ? 
/* 1542 */         Boolean.FALSE : Boolean.TRUE);
/*      */ 
/* 1544 */       v += 2;
/* 1545 */       break;
/*      */     case 83:
/* 1547 */       av.visit(name, new Short(
/* 1548 */         (short)readInt(this.items[
/* 1548 */         readUnsignedShort(v)])));
/*      */ 
/* 1549 */       v += 2;
/* 1550 */       break;
/*      */     case 67:
/* 1552 */       av.visit(name, new Character(
/* 1553 */         (char)readInt(this.items[
/* 1553 */         readUnsignedShort(v)])));
/*      */ 
/* 1554 */       v += 2;
/* 1555 */       break;
/*      */     case 115:
/* 1557 */       av.visit(name, readUTF8(v, buf));
/* 1558 */       v += 2;
/* 1559 */       break;
/*      */     case 101:
/* 1561 */       av.visitEnum(name, readUTF8(v, buf), readUTF8(v + 2, buf));
/* 1562 */       v += 4;
/* 1563 */       break;
/*      */     case 99:
/* 1565 */       av.visit(name, Type.getType(readUTF8(v, buf)));
/* 1566 */       v += 2;
/* 1567 */       break;
/*      */     case 64:
/* 1569 */       v = readAnnotationValues(v + 2, buf, true, av
/* 1570 */         .visitAnnotation(name, 
/* 1570 */         readUTF8(v, buf)));
/*      */ 
/* 1571 */       break;
/*      */     case 91:
/* 1573 */       int size = readUnsignedShort(v);
/* 1574 */       v += 2;
/* 1575 */       if (size == 0) {
/* 1576 */         return readAnnotationValues(v - 2, buf, false, av
/* 1577 */           .visitArray(name));
/*      */       }
/*      */ 
/* 1579 */       switch (this.b[(v++)] & 0xFF) {
/*      */       case 66:
/* 1581 */         byte[] bv = new byte[size];
/* 1582 */         for (int i = 0; i < size; i++) {
/* 1583 */           bv[i] = ((byte)readInt(this.items[readUnsignedShort(v)]));
/* 1584 */           v += 3;
/*      */         }
/* 1586 */         av.visit(name, bv);
/* 1587 */         v--;
/* 1588 */         break;
/*      */       case 90:
/* 1590 */         boolean[] zv = new boolean[size];
/* 1591 */         for (int i = 0; i < size; i++) {
/* 1592 */           zv[i] = (readInt(this.items[readUnsignedShort(v)]) != 0 ? 1 : false);
/* 1593 */           v += 3;
/*      */         }
/* 1595 */         av.visit(name, zv);
/* 1596 */         v--;
/* 1597 */         break;
/*      */       case 83:
/* 1599 */         short[] sv = new short[size];
/* 1600 */         for (int i = 0; i < size; i++) {
/* 1601 */           sv[i] = ((short)readInt(this.items[readUnsignedShort(v)]));
/* 1602 */           v += 3;
/*      */         }
/* 1604 */         av.visit(name, sv);
/* 1605 */         v--;
/* 1606 */         break;
/*      */       case 67:
/* 1608 */         char[] cv = new char[size];
/* 1609 */         for (int i = 0; i < size; i++) {
/* 1610 */           cv[i] = ((char)readInt(this.items[readUnsignedShort(v)]));
/* 1611 */           v += 3;
/*      */         }
/* 1613 */         av.visit(name, cv);
/* 1614 */         v--;
/* 1615 */         break;
/*      */       case 73:
/* 1617 */         int[] iv = new int[size];
/* 1618 */         for (int i = 0; i < size; i++) {
/* 1619 */           iv[i] = readInt(this.items[readUnsignedShort(v)]);
/* 1620 */           v += 3;
/*      */         }
/* 1622 */         av.visit(name, iv);
/* 1623 */         v--;
/* 1624 */         break;
/*      */       case 74:
/* 1626 */         long[] lv = new long[size];
/* 1627 */         for (int i = 0; i < size; i++) {
/* 1628 */           lv[i] = readLong(this.items[readUnsignedShort(v)]);
/* 1629 */           v += 3;
/*      */         }
/* 1631 */         av.visit(name, lv);
/* 1632 */         v--;
/* 1633 */         break;
/*      */       case 70:
/* 1635 */         float[] fv = new float[size];
/* 1636 */         for (int i = 0; i < size; i++) {
/* 1637 */           fv[i] = 
/* 1638 */             Float.intBitsToFloat(readInt(this.items[
/* 1638 */             readUnsignedShort(v)]));
/*      */ 
/* 1639 */           v += 3;
/*      */         }
/* 1641 */         av.visit(name, fv);
/* 1642 */         v--;
/* 1643 */         break;
/*      */       case 68:
/* 1645 */         double[] dv = new double[size];
/* 1646 */         for (int i = 0; i < size; i++) {
/* 1647 */           dv[i] = 
/* 1648 */             Double.longBitsToDouble(readLong(this.items[
/* 1648 */             readUnsignedShort(v)]));
/*      */ 
/* 1649 */           v += 3;
/*      */         }
/* 1651 */         av.visit(name, dv);
/* 1652 */         v--;
/* 1653 */         break;
/*      */       case 69:
/*      */       case 71:
/*      */       case 72:
/*      */       case 75:
/*      */       case 76:
/*      */       case 77:
/*      */       case 78:
/*      */       case 79:
/*      */       case 80:
/*      */       case 81:
/*      */       case 82:
/*      */       case 84:
/*      */       case 85:
/*      */       case 86:
/*      */       case 87:
/*      */       case 88:
/*      */       case 89:
/*      */       default:
/* 1655 */         v = readAnnotationValues(v - 3, buf, false, av.visitArray(name)); } break;
/*      */     case 65:
/*      */     case 69:
/*      */     case 71:
/*      */     case 72:
/*      */     case 75:
/*      */     case 76:
/*      */     case 77:
/*      */     case 78:
/*      */     case 79:
/*      */     case 80:
/*      */     case 81:
/*      */     case 82:
/*      */     case 84:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 89:
/*      */     case 92:
/*      */     case 93:
/*      */     case 94:
/*      */     case 95:
/*      */     case 96:
/*      */     case 97:
/*      */     case 98:
/*      */     case 100:
/*      */     case 102:
/*      */     case 103:
/*      */     case 104:
/*      */     case 105:
/*      */     case 106:
/*      */     case 107:
/*      */     case 108:
/*      */     case 109:
/*      */     case 110:
/*      */     case 111:
/*      */     case 112:
/*      */     case 113:
/* 1658 */     case 114: } return v;
/*      */   }
/*      */ 
/*      */   private void getImplicitFrame(Context frame)
/*      */   {
/* 1669 */     String desc = frame.desc;
/* 1670 */     Object[] locals = frame.local;
/* 1671 */     int local = 0;
/* 1672 */     if ((frame.access & 0x8) == 0) {
/* 1673 */       if ("<init>".equals(frame.name))
/* 1674 */         locals[(local++)] = Opcodes.UNINITIALIZED_THIS;
/*      */       else {
/* 1676 */         locals[(local++)] = readClass(this.header + 2, frame.buffer);
/*      */       }
/*      */     }
/* 1679 */     int i = 1;
/*      */     while (true) {
/* 1681 */       int j = i;
/* 1682 */       switch (desc.charAt(i++)) {
/*      */       case 'B':
/*      */       case 'C':
/*      */       case 'I':
/*      */       case 'S':
/*      */       case 'Z':
/* 1688 */         locals[(local++)] = Opcodes.INTEGER;
/* 1689 */         break;
/*      */       case 'F':
/* 1691 */         locals[(local++)] = Opcodes.FLOAT;
/* 1692 */         break;
/*      */       case 'J':
/* 1694 */         locals[(local++)] = Opcodes.LONG;
/* 1695 */         break;
/*      */       case 'D':
/* 1697 */         locals[(local++)] = Opcodes.DOUBLE;
/* 1698 */         break;
/*      */       case '[':
/* 1700 */         while (desc.charAt(i) == '[') {
/* 1701 */           i++;
/*      */         }
/* 1703 */         if (desc.charAt(i) == 'L') {
/* 1704 */           i++;
/* 1705 */           while (desc.charAt(i) != ';') {
/* 1706 */             i++;
/*      */           }
/*      */         }
/* 1709 */         locals[(local++)] = desc.substring(j, ++i);
/* 1710 */         break;
/*      */       case 'L':
/* 1712 */         while (desc.charAt(i) != ';') {
/* 1713 */           i++;
/*      */         }
/* 1715 */         locals[(local++)] = desc.substring(j + 1, i++);
/* 1716 */         break;
/*      */       case 'E':
/*      */       case 'G':
/*      */       case 'H':
/*      */       case 'K':
/*      */       case 'M':
/*      */       case 'N':
/*      */       case 'O':
/*      */       case 'P':
/*      */       case 'Q':
/*      */       case 'R':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       default:
/* 1718 */         break label371;
/*      */       }
/*      */     }
/* 1721 */     label371: frame.localCount = local;
/*      */   }
/*      */ 
/*      */   private int readFrame(int stackMap, boolean zip, boolean unzip, Label[] labels, Context frame)
/*      */   {
/* 1744 */     char[] c = frame.buffer;
/*      */     int tag;
/*      */     int tag;
/* 1747 */     if (zip) {
/* 1748 */       tag = this.b[(stackMap++)] & 0xFF;
/*      */     } else {
/* 1750 */       tag = 255;
/* 1751 */       frame.offset = -1;
/*      */     }
/* 1753 */     frame.localDiff = 0;
/*      */     int delta;
/* 1754 */     if (tag < 64) {
/* 1755 */       int delta = tag;
/* 1756 */       frame.mode = 3;
/* 1757 */       frame.stackCount = 0;
/* 1758 */     } else if (tag < 128) {
/* 1759 */       int delta = tag - 64;
/* 1760 */       stackMap = readFrameType(frame.stack, 0, stackMap, c, labels);
/* 1761 */       frame.mode = 4;
/* 1762 */       frame.stackCount = 1;
/*      */     } else {
/* 1764 */       delta = readUnsignedShort(stackMap);
/* 1765 */       stackMap += 2;
/* 1766 */       if (tag == 247) {
/* 1767 */         stackMap = readFrameType(frame.stack, 0, stackMap, c, labels);
/* 1768 */         frame.mode = 4;
/* 1769 */         frame.stackCount = 1;
/* 1770 */       } else if ((tag >= 248) && (tag < 251))
/*      */       {
/* 1772 */         frame.mode = 2;
/* 1773 */         frame.localDiff = (251 - tag);
/* 1774 */         frame.localCount -= frame.localDiff;
/* 1775 */         frame.stackCount = 0;
/* 1776 */       } else if (tag == 251) {
/* 1777 */         frame.mode = 3;
/* 1778 */         frame.stackCount = 0;
/* 1779 */       } else if (tag < 255) {
/* 1780 */         int local = unzip ? frame.localCount : 0;
/* 1781 */         for (int i = tag - 251; i > 0; i--) {
/* 1782 */           stackMap = readFrameType(frame.local, local++, stackMap, c, labels);
/*      */         }
/*      */ 
/* 1785 */         frame.mode = 1;
/* 1786 */         frame.localDiff = (tag - 251);
/* 1787 */         frame.localCount += frame.localDiff;
/* 1788 */         frame.stackCount = 0;
/*      */       } else {
/* 1790 */         frame.mode = 0;
/* 1791 */         int n = readUnsignedShort(stackMap);
/* 1792 */         stackMap += 2;
/* 1793 */         frame.localDiff = n;
/* 1794 */         frame.localCount = n;
/* 1795 */         for (int local = 0; n > 0; n--) {
/* 1796 */           stackMap = readFrameType(frame.local, local++, stackMap, c, labels);
/*      */         }
/*      */ 
/* 1799 */         n = readUnsignedShort(stackMap);
/* 1800 */         stackMap += 2;
/* 1801 */         frame.stackCount = n;
/* 1802 */         for (int stack = 0; n > 0; n--) {
/* 1803 */           stackMap = readFrameType(frame.stack, stack++, stackMap, c, labels);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1808 */     frame.offset += delta + 1;
/* 1809 */     readLabel(frame.offset, labels);
/* 1810 */     return stackMap;
/*      */   }
/*      */ 
/*      */   private int readFrameType(Object[] frame, int index, int v, char[] buf, Label[] labels)
/*      */   {
/* 1834 */     int type = this.b[(v++)] & 0xFF;
/* 1835 */     switch (type) {
/*      */     case 0:
/* 1837 */       frame[index] = Opcodes.TOP;
/* 1838 */       break;
/*      */     case 1:
/* 1840 */       frame[index] = Opcodes.INTEGER;
/* 1841 */       break;
/*      */     case 2:
/* 1843 */       frame[index] = Opcodes.FLOAT;
/* 1844 */       break;
/*      */     case 3:
/* 1846 */       frame[index] = Opcodes.DOUBLE;
/* 1847 */       break;
/*      */     case 4:
/* 1849 */       frame[index] = Opcodes.LONG;
/* 1850 */       break;
/*      */     case 5:
/* 1852 */       frame[index] = Opcodes.NULL;
/* 1853 */       break;
/*      */     case 6:
/* 1855 */       frame[index] = Opcodes.UNINITIALIZED_THIS;
/* 1856 */       break;
/*      */     case 7:
/* 1858 */       frame[index] = readClass(v, buf);
/* 1859 */       v += 2;
/* 1860 */       break;
/*      */     default:
/* 1862 */       frame[index] = readLabel(readUnsignedShort(v), labels);
/* 1863 */       v += 2;
/*      */     }
/* 1865 */     return v;
/*      */   }
/*      */ 
/*      */   protected Label readLabel(int offset, Label[] labels)
/*      */   {
/* 1882 */     if (labels[offset] == null) {
/* 1883 */       labels[offset] = new Label();
/*      */     }
/* 1885 */     return labels[offset];
/*      */   }
/*      */ 
/*      */   private int getAttributes()
/*      */   {
/* 1895 */     int u = this.header + 8 + readUnsignedShort(this.header + 6) * 2;
/*      */ 
/* 1897 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1898 */       for (int j = readUnsignedShort(u + 8); j > 0; j--) {
/* 1899 */         u += 6 + readInt(u + 12);
/*      */       }
/* 1901 */       u += 8;
/*      */     }
/* 1903 */     u += 2;
/* 1904 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1905 */       for (int j = readUnsignedShort(u + 8); j > 0; j--) {
/* 1906 */         u += 6 + readInt(u + 12);
/*      */       }
/* 1908 */       u += 8;
/*      */     }
/*      */ 
/* 1911 */     return u + 2;
/*      */   }
/*      */ 
/*      */   private Attribute readAttribute(Attribute[] attrs, String type, int off, int len, char[] buf, int codeOff, Label[] labels)
/*      */   {
/* 1950 */     for (int i = 0; i < attrs.length; i++) {
/* 1951 */       if (attrs[i].type.equals(type)) {
/* 1952 */         return attrs[i].read(this, off, len, buf, codeOff, labels);
/*      */       }
/*      */     }
/* 1955 */     return new Attribute(type).read(this, off, len, null, -1, null);
/*      */   }
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/* 1968 */     return this.items.length;
/*      */   }
/*      */ 
/*      */   public int getItem(int item)
/*      */   {
/* 1982 */     return this.items[item];
/*      */   }
/*      */ 
/*      */   public int getMaxStringLength()
/*      */   {
/* 1993 */     return this.maxStringLength;
/*      */   }
/*      */ 
/*      */   public int readByte(int index)
/*      */   {
/* 2006 */     return this.b[index] & 0xFF;
/*      */   }
/*      */ 
/*      */   public int readUnsignedShort(int index)
/*      */   {
/* 2019 */     byte[] b = this.b;
/* 2020 */     return (b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF;
/*      */   }
/*      */ 
/*      */   public short readShort(int index)
/*      */   {
/* 2033 */     byte[] b = this.b;
/* 2034 */     return (short)((b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF);
/*      */   }
/*      */ 
/*      */   public int readInt(int index)
/*      */   {
/* 2047 */     byte[] b = this.b;
/* 2048 */     return (b[index] & 0xFF) << 24 | (b[(index + 1)] & 0xFF) << 16 | (b[(index + 2)] & 0xFF) << 8 | b[(index + 3)] & 0xFF;
/*      */   }
/*      */ 
/*      */   public long readLong(int index)
/*      */   {
/* 2062 */     long l1 = readInt(index);
/* 2063 */     long l0 = readInt(index + 4) & 0xFFFFFFFF;
/* 2064 */     return l1 << 32 | l0;
/*      */   }
/*      */ 
/*      */   public String readUTF8(int index, char[] buf)
/*      */   {
/* 2081 */     int item = readUnsignedShort(index);
/* 2082 */     if ((index == 0) || (item == 0)) {
/* 2083 */       return null;
/*      */     }
/* 2085 */     String s = this.strings[item];
/* 2086 */     if (s != null) {
/* 2087 */       return s;
/*      */     }
/* 2089 */     index = this.items[item];
/* 2090 */     return this.strings[item] =  = readUTF(index + 2, readUnsignedShort(index), buf);
/*      */   }
/*      */ 
/*      */   private String readUTF(int index, int utfLen, char[] buf)
/*      */   {
/* 2106 */     int endIndex = index + utfLen;
/* 2107 */     byte[] b = this.b;
/* 2108 */     int strLen = 0;
/*      */ 
/* 2110 */     int st = 0;
/* 2111 */     char cc = '\000';
/* 2112 */     while (index < endIndex) {
/* 2113 */       int c = b[(index++)];
/* 2114 */       switch (st) {
/*      */       case 0:
/* 2116 */         c &= 255;
/* 2117 */         if (c < 128) {
/* 2118 */           buf[(strLen++)] = ((char)c);
/* 2119 */         } else if ((c < 224) && (c > 191)) {
/* 2120 */           cc = (char)(c & 0x1F);
/* 2121 */           st = 1;
/*      */         } else {
/* 2123 */           cc = (char)(c & 0xF);
/* 2124 */           st = 2;
/*      */         }
/* 2126 */         break;
/*      */       case 1:
/* 2129 */         buf[(strLen++)] = ((char)(cc << '\006' | c & 0x3F));
/* 2130 */         st = 0;
/* 2131 */         break;
/*      */       case 2:
/* 2134 */         cc = (char)(cc << '\006' | c & 0x3F);
/* 2135 */         st = 1;
/*      */       }
/*      */     }
/*      */ 
/* 2139 */     return new String(buf, 0, strLen);
/*      */   }
/*      */ 
/*      */   public String readClass(int index, char[] buf)
/*      */   {
/* 2159 */     return readUTF8(this.items[readUnsignedShort(index)], buf);
/*      */   }
/*      */ 
/*      */   public Object readConst(int item, char[] buf)
/*      */   {
/* 2177 */     int index = this.items[item];
/* 2178 */     switch (this.b[(index - 1)]) {
/*      */     case 3:
/* 2180 */       return new Integer(readInt(index));
/*      */     case 4:
/* 2182 */       return new Float(Float.intBitsToFloat(readInt(index)));
/*      */     case 5:
/* 2184 */       return new Long(readLong(index));
/*      */     case 6:
/* 2186 */       return new Double(Double.longBitsToDouble(readLong(index)));
/*      */     case 7:
/* 2188 */       return Type.getObjectType(readUTF8(index, buf));
/*      */     case 8:
/* 2190 */       return readUTF8(index, buf);
/*      */     case 16:
/* 2192 */       return Type.getMethodType(readUTF8(index, buf));
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/* 2194 */     case 15: } int tag = readByte(index);
/* 2195 */     int[] items = this.items;
/* 2196 */     int cpIndex = items[readUnsignedShort(index + 1)];
/* 2197 */     String owner = readClass(cpIndex, buf);
/* 2198 */     cpIndex = items[readUnsignedShort(cpIndex + 2)];
/* 2199 */     String name = readUTF8(cpIndex, buf);
/* 2200 */     String desc = readUTF8(cpIndex + 2, buf);
/* 2201 */     return new Handle(tag, owner, name, desc);
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.ClassReader
 * JD-Core Version:    0.6.2
 */