/*     */ package org.springframework.asm;
/*     */ 
/*     */ public abstract class ClassVisitor
/*     */ {
/*     */   protected final int api;
/*     */   protected ClassVisitor cv;
/*     */ 
/*     */   public ClassVisitor(int api)
/*     */   {
/*  63 */     this(api, null);
/*     */   }
/*     */ 
/*     */   public ClassVisitor(int api, ClassVisitor cv)
/*     */   {
/*  82 */     this.api = api;
/*  83 */     this.cv = cv;
/*     */   }
/*     */ 
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*     */   {
/* 113 */     if (this.cv != null)
/* 114 */       this.cv.visit(version, access, name, signature, superName, interfaces);
/*     */   }
/*     */ 
/*     */   public void visitSource(String source, String debug)
/*     */   {
/* 130 */     if (this.cv != null)
/* 131 */       this.cv.visitSource(source, debug);
/*     */   }
/*     */ 
/*     */   public void visitOuterClass(String owner, String name, String desc)
/*     */   {
/* 151 */     if (this.cv != null)
/* 152 */       this.cv.visitOuterClass(owner, name, desc);
/*     */   }
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*     */   {
/* 167 */     if (this.cv != null) {
/* 168 */       return this.cv.visitAnnotation(desc, visible);
/*     */     }
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */   public void visitAttribute(Attribute attr)
/*     */   {
/* 180 */     if (this.cv != null)
/* 181 */       this.cv.visitAttribute(attr);
/*     */   }
/*     */ 
/*     */   public void visitInnerClass(String name, String outerName, String innerName, int access)
/*     */   {
/* 205 */     if (this.cv != null)
/* 206 */       this.cv.visitInnerClass(name, outerName, innerName, access);
/*     */   }
/*     */ 
/*     */   public FieldVisitor visitField(int access, String name, String desc, String signature, Object value)
/*     */   {
/* 239 */     if (this.cv != null) {
/* 240 */       return this.cv.visitField(access, name, desc, signature, value);
/*     */     }
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*     */   {
/* 272 */     if (this.cv != null) {
/* 273 */       return this.cv.visitMethod(access, name, desc, signature, exceptions);
/*     */     }
/* 275 */     return null;
/*     */   }
/*     */ 
/*     */   public void visitEnd()
/*     */   {
/* 284 */     if (this.cv != null)
/* 285 */       this.cv.visitEnd();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.ClassVisitor
 * JD-Core Version:    0.6.2
 */