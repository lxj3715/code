/*      */ package org.springframework.asm;
/*      */ 
/*      */ public class ClassWriter extends ClassVisitor
/*      */ {
/*      */   public static final int COMPUTE_MAXS = 1;
/*      */   public static final int COMPUTE_FRAMES = 2;
/*      */   static final int ACC_SYNTHETIC_ATTRIBUTE = 262144;
/*      */   static final int TO_ACC_SYNTHETIC = 64;
/*      */   static final int NOARG_INSN = 0;
/*      */   static final int SBYTE_INSN = 1;
/*      */   static final int SHORT_INSN = 2;
/*      */   static final int VAR_INSN = 3;
/*      */   static final int IMPLVAR_INSN = 4;
/*      */   static final int TYPE_INSN = 5;
/*      */   static final int FIELDORMETH_INSN = 6;
/*      */   static final int ITFMETH_INSN = 7;
/*      */   static final int INDYMETH_INSN = 8;
/*      */   static final int LABEL_INSN = 9;
/*      */   static final int LABELW_INSN = 10;
/*      */   static final int LDC_INSN = 11;
/*      */   static final int LDCW_INSN = 12;
/*      */   static final int IINC_INSN = 13;
/*      */   static final int TABL_INSN = 14;
/*      */   static final int LOOK_INSN = 15;
/*      */   static final int MANA_INSN = 16;
/*      */   static final int WIDE_INSN = 17;
/*  514 */   static final byte[] TYPE = b;
/*      */   static final int CLASS = 7;
/*      */   static final int FIELD = 9;
/*      */   static final int METH = 10;
/*      */   static final int IMETH = 11;
/*      */   static final int STR = 8;
/*      */   static final int INT = 3;
/*      */   static final int FLOAT = 4;
/*      */   static final int LONG = 5;
/*      */   static final int DOUBLE = 6;
/*      */   static final int NAME_TYPE = 12;
/*      */   static final int UTF8 = 1;
/*      */   static final int MTYPE = 16;
/*      */   static final int HANDLE = 15;
/*      */   static final int INDY = 18;
/*      */   static final int HANDLE_BASE = 20;
/*      */   static final int TYPE_NORMAL = 30;
/*      */   static final int TYPE_UNINIT = 31;
/*      */   static final int TYPE_MERGED = 32;
/*      */   static final int BSM = 33;
/*      */   ClassReader cr;
/*      */   int version;
/*      */   int index;
/*      */   final ByteVector pool;
/*      */   Item[] items;
/*      */   int threshold;
/*      */   final Item key;
/*      */   final Item key2;
/*      */   final Item key3;
/*      */   final Item key4;
/*      */   Item[] typeTable;
/*      */   private short typeCount;
/*      */   private int access;
/*      */   private int name;
/*      */   String thisName;
/*      */   private int signature;
/*      */   private int superName;
/*      */   private int interfaceCount;
/*      */   private int[] interfaces;
/*      */   private int sourceFile;
/*      */   private ByteVector sourceDebug;
/*      */   private int enclosingMethodOwner;
/*      */   private int enclosingMethod;
/*      */   private AnnotationWriter anns;
/*      */   private AnnotationWriter ianns;
/*      */   private Attribute attrs;
/*      */   private int innerClassesCount;
/*      */   private ByteVector innerClasses;
/*      */   int bootstrapMethodsCount;
/*      */   ByteVector bootstrapMethods;
/*      */   FieldWriter firstField;
/*      */   FieldWriter lastField;
/*      */   MethodWriter firstMethod;
/*      */   MethodWriter lastMethod;
/*      */   private boolean computeMaxs;
/*      */   private boolean computeFrames;
/*      */   boolean invalidFrames;
/*      */ 
/*      */   public ClassWriter(int flags)
/*      */   {
/*  598 */     super(262144);
/*  599 */     this.index = 1;
/*  600 */     this.pool = new ByteVector();
/*  601 */     this.items = new Item[256];
/*  602 */     this.threshold = ((int)(0.75D * this.items.length));
/*  603 */     this.key = new Item();
/*  604 */     this.key2 = new Item();
/*  605 */     this.key3 = new Item();
/*  606 */     this.key4 = new Item();
/*  607 */     this.computeMaxs = ((flags & 0x1) != 0);
/*  608 */     this.computeFrames = ((flags & 0x2) != 0);
/*      */   }
/*      */ 
/*      */   public ClassWriter(ClassReader classReader, int flags)
/*      */   {
/*  644 */     this(flags);
/*  645 */     classReader.copyPool(this);
/*  646 */     this.cr = classReader;
/*      */   }
/*      */ 
/*      */   public final void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*      */   {
/*  657 */     this.version = version;
/*  658 */     this.access = access;
/*  659 */     this.name = newClass(name);
/*  660 */     this.thisName = name;
/*  661 */     if (signature != null) {
/*  662 */       this.signature = newUTF8(signature);
/*      */     }
/*  664 */     this.superName = (superName == null ? 0 : newClass(superName));
/*  665 */     if ((interfaces != null) && (interfaces.length > 0)) {
/*  666 */       this.interfaceCount = interfaces.length;
/*  667 */       this.interfaces = new int[this.interfaceCount];
/*  668 */       for (int i = 0; i < this.interfaceCount; i++)
/*  669 */         this.interfaces[i] = newClass(interfaces[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void visitSource(String file, String debug)
/*      */   {
/*  676 */     if (file != null) {
/*  677 */       this.sourceFile = newUTF8(file);
/*      */     }
/*  679 */     if (debug != null)
/*  680 */       this.sourceDebug = new ByteVector().putUTF8(debug);
/*      */   }
/*      */ 
/*      */   public final void visitOuterClass(String owner, String name, String desc)
/*      */   {
/*  687 */     this.enclosingMethodOwner = newClass(owner);
/*  688 */     if ((name != null) && (desc != null))
/*  689 */       this.enclosingMethod = newNameType(name, desc);
/*      */   }
/*      */ 
/*      */   public final AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*      */   {
/*  699 */     ByteVector bv = new ByteVector();
/*      */ 
/*  701 */     bv.putShort(newUTF8(desc)).putShort(0);
/*  702 */     AnnotationWriter aw = new AnnotationWriter(this, true, bv, bv, 2);
/*  703 */     if (visible) {
/*  704 */       aw.next = this.anns;
/*  705 */       this.anns = aw;
/*      */     } else {
/*  707 */       aw.next = this.ianns;
/*  708 */       this.ianns = aw;
/*      */     }
/*  710 */     return aw;
/*      */   }
/*      */ 
/*      */   public final void visitAttribute(Attribute attr)
/*      */   {
/*  715 */     attr.next = this.attrs;
/*  716 */     this.attrs = attr;
/*      */   }
/*      */ 
/*      */   public final void visitInnerClass(String name, String outerName, String innerName, int access)
/*      */   {
/*  722 */     if (this.innerClasses == null) {
/*  723 */       this.innerClasses = new ByteVector();
/*      */     }
/*  725 */     this.innerClassesCount += 1;
/*  726 */     this.innerClasses.putShort(name == null ? 0 : newClass(name));
/*  727 */     this.innerClasses.putShort(outerName == null ? 0 : newClass(outerName));
/*  728 */     this.innerClasses.putShort(innerName == null ? 0 : newUTF8(innerName));
/*  729 */     this.innerClasses.putShort(access);
/*      */   }
/*      */ 
/*      */   public final FieldVisitor visitField(int access, String name, String desc, String signature, Object value)
/*      */   {
/*  735 */     return new FieldWriter(this, access, name, desc, signature, value);
/*      */   }
/*      */ 
/*      */   public final MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*      */   {
/*  741 */     return new MethodWriter(this, access, name, desc, signature, exceptions, this.computeMaxs, this.computeFrames);
/*      */   }
/*      */ 
/*      */   public final void visitEnd()
/*      */   {
/*      */   }
/*      */ 
/*      */   public byte[] toByteArray()
/*      */   {
/*  759 */     if (this.index > 65535) {
/*  760 */       throw new RuntimeException("Class file too large!");
/*      */     }
/*      */ 
/*  763 */     int size = 24 + 2 * this.interfaceCount;
/*  764 */     int nbFields = 0;
/*  765 */     FieldWriter fb = this.firstField;
/*  766 */     while (fb != null) {
/*  767 */       nbFields++;
/*  768 */       size += fb.getSize();
/*  769 */       fb = (FieldWriter)fb.fv;
/*      */     }
/*  771 */     int nbMethods = 0;
/*  772 */     MethodWriter mb = this.firstMethod;
/*  773 */     while (mb != null) {
/*  774 */       nbMethods++;
/*  775 */       size += mb.getSize();
/*  776 */       mb = (MethodWriter)mb.mv;
/*      */     }
/*  778 */     int attributeCount = 0;
/*  779 */     if (this.bootstrapMethods != null)
/*      */     {
/*  782 */       attributeCount++;
/*  783 */       size += 8 + this.bootstrapMethods.length;
/*  784 */       newUTF8("BootstrapMethods");
/*      */     }
/*  786 */     if (this.signature != 0) {
/*  787 */       attributeCount++;
/*  788 */       size += 8;
/*  789 */       newUTF8("Signature");
/*      */     }
/*  791 */     if (this.sourceFile != 0) {
/*  792 */       attributeCount++;
/*  793 */       size += 8;
/*  794 */       newUTF8("SourceFile");
/*      */     }
/*  796 */     if (this.sourceDebug != null) {
/*  797 */       attributeCount++;
/*  798 */       size += this.sourceDebug.length + 4;
/*  799 */       newUTF8("SourceDebugExtension");
/*      */     }
/*  801 */     if (this.enclosingMethodOwner != 0) {
/*  802 */       attributeCount++;
/*  803 */       size += 10;
/*  804 */       newUTF8("EnclosingMethod");
/*      */     }
/*  806 */     if ((this.access & 0x20000) != 0) {
/*  807 */       attributeCount++;
/*  808 */       size += 6;
/*  809 */       newUTF8("Deprecated");
/*      */     }
/*  811 */     if (((this.access & 0x1000) != 0) && (
/*  812 */       ((this.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/*  814 */       attributeCount++;
/*  815 */       size += 6;
/*  816 */       newUTF8("Synthetic");
/*      */     }
/*      */ 
/*  819 */     if (this.innerClasses != null) {
/*  820 */       attributeCount++;
/*  821 */       size += 8 + this.innerClasses.length;
/*  822 */       newUTF8("InnerClasses");
/*      */     }
/*  824 */     if (this.anns != null) {
/*  825 */       attributeCount++;
/*  826 */       size += 8 + this.anns.getSize();
/*  827 */       newUTF8("RuntimeVisibleAnnotations");
/*      */     }
/*  829 */     if (this.ianns != null) {
/*  830 */       attributeCount++;
/*  831 */       size += 8 + this.ianns.getSize();
/*  832 */       newUTF8("RuntimeInvisibleAnnotations");
/*      */     }
/*  834 */     if (this.attrs != null) {
/*  835 */       attributeCount += this.attrs.getCount();
/*  836 */       size += this.attrs.getSize(this, null, 0, -1, -1);
/*      */     }
/*  838 */     size += this.pool.length;
/*      */ 
/*  841 */     ByteVector out = new ByteVector(size);
/*  842 */     out.putInt(-889275714).putInt(this.version);
/*  843 */     out.putShort(this.index).putByteArray(this.pool.data, 0, this.pool.length);
/*  844 */     int mask = 0x60000 | (this.access & 0x40000) / 64;
/*      */ 
/*  846 */     out.putShort(this.access & (mask ^ 0xFFFFFFFF)).putShort(this.name).putShort(this.superName);
/*  847 */     out.putShort(this.interfaceCount);
/*  848 */     for (int i = 0; i < this.interfaceCount; i++) {
/*  849 */       out.putShort(this.interfaces[i]);
/*      */     }
/*  851 */     out.putShort(nbFields);
/*  852 */     fb = this.firstField;
/*  853 */     while (fb != null) {
/*  854 */       fb.put(out);
/*  855 */       fb = (FieldWriter)fb.fv;
/*      */     }
/*  857 */     out.putShort(nbMethods);
/*  858 */     mb = this.firstMethod;
/*  859 */     while (mb != null) {
/*  860 */       mb.put(out);
/*  861 */       mb = (MethodWriter)mb.mv;
/*      */     }
/*  863 */     out.putShort(attributeCount);
/*  864 */     if (this.bootstrapMethods != null) {
/*  865 */       out.putShort(newUTF8("BootstrapMethods"));
/*  866 */       out.putInt(this.bootstrapMethods.length + 2).putShort(this.bootstrapMethodsCount);
/*      */ 
/*  868 */       out.putByteArray(this.bootstrapMethods.data, 0, this.bootstrapMethods.length);
/*      */     }
/*  870 */     if (this.signature != 0) {
/*  871 */       out.putShort(newUTF8("Signature")).putInt(2).putShort(this.signature);
/*      */     }
/*  873 */     if (this.sourceFile != 0) {
/*  874 */       out.putShort(newUTF8("SourceFile")).putInt(2).putShort(this.sourceFile);
/*      */     }
/*  876 */     if (this.sourceDebug != null) {
/*  877 */       int len = this.sourceDebug.length - 2;
/*  878 */       out.putShort(newUTF8("SourceDebugExtension")).putInt(len);
/*  879 */       out.putByteArray(this.sourceDebug.data, 2, len);
/*      */     }
/*  881 */     if (this.enclosingMethodOwner != 0) {
/*  882 */       out.putShort(newUTF8("EnclosingMethod")).putInt(4);
/*  883 */       out.putShort(this.enclosingMethodOwner).putShort(this.enclosingMethod);
/*      */     }
/*  885 */     if ((this.access & 0x20000) != 0) {
/*  886 */       out.putShort(newUTF8("Deprecated")).putInt(0);
/*      */     }
/*  888 */     if (((this.access & 0x1000) != 0) && (
/*  889 */       ((this.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/*  891 */       out.putShort(newUTF8("Synthetic")).putInt(0);
/*      */     }
/*      */ 
/*  894 */     if (this.innerClasses != null) {
/*  895 */       out.putShort(newUTF8("InnerClasses"));
/*  896 */       out.putInt(this.innerClasses.length + 2).putShort(this.innerClassesCount);
/*  897 */       out.putByteArray(this.innerClasses.data, 0, this.innerClasses.length);
/*      */     }
/*  899 */     if (this.anns != null) {
/*  900 */       out.putShort(newUTF8("RuntimeVisibleAnnotations"));
/*  901 */       this.anns.put(out);
/*      */     }
/*  903 */     if (this.ianns != null) {
/*  904 */       out.putShort(newUTF8("RuntimeInvisibleAnnotations"));
/*  905 */       this.ianns.put(out);
/*      */     }
/*  907 */     if (this.attrs != null) {
/*  908 */       this.attrs.put(this, null, 0, -1, -1, out);
/*      */     }
/*  910 */     if (this.invalidFrames) {
/*  911 */       this.anns = null;
/*  912 */       this.ianns = null;
/*  913 */       this.attrs = null;
/*  914 */       this.innerClassesCount = 0;
/*  915 */       this.innerClasses = null;
/*  916 */       this.bootstrapMethodsCount = 0;
/*  917 */       this.bootstrapMethods = null;
/*  918 */       this.firstField = null;
/*  919 */       this.lastField = null;
/*  920 */       this.firstMethod = null;
/*  921 */       this.lastMethod = null;
/*  922 */       this.computeMaxs = false;
/*  923 */       this.computeFrames = true;
/*  924 */       this.invalidFrames = false;
/*  925 */       new ClassReader(out.data).accept(this, 4);
/*  926 */       return toByteArray();
/*      */     }
/*  928 */     return out.data;
/*      */   }
/*      */ 
/*      */   Item newConstItem(Object cst)
/*      */   {
/*  947 */     if ((cst instanceof Integer)) {
/*  948 */       int val = ((Integer)cst).intValue();
/*  949 */       return newInteger(val);
/*  950 */     }if ((cst instanceof Byte)) {
/*  951 */       int val = ((Byte)cst).intValue();
/*  952 */       return newInteger(val);
/*  953 */     }if ((cst instanceof Character)) {
/*  954 */       int val = ((Character)cst).charValue();
/*  955 */       return newInteger(val);
/*  956 */     }if ((cst instanceof Short)) {
/*  957 */       int val = ((Short)cst).intValue();
/*  958 */       return newInteger(val);
/*  959 */     }if ((cst instanceof Boolean)) {
/*  960 */       int val = ((Boolean)cst).booleanValue() ? 1 : 0;
/*  961 */       return newInteger(val);
/*  962 */     }if ((cst instanceof Float)) {
/*  963 */       float val = ((Float)cst).floatValue();
/*  964 */       return newFloat(val);
/*  965 */     }if ((cst instanceof Long)) {
/*  966 */       long val = ((Long)cst).longValue();
/*  967 */       return newLong(val);
/*  968 */     }if ((cst instanceof Double)) {
/*  969 */       double val = ((Double)cst).doubleValue();
/*  970 */       return newDouble(val);
/*  971 */     }if ((cst instanceof String))
/*  972 */       return newString((String)cst);
/*  973 */     if ((cst instanceof Type)) {
/*  974 */       Type t = (Type)cst;
/*  975 */       int s = t.getSort();
/*  976 */       if (s == 10)
/*  977 */         return newClassItem(t.getInternalName());
/*  978 */       if (s == 11) {
/*  979 */         return newMethodTypeItem(t.getDescriptor());
/*      */       }
/*  981 */       return newClassItem(t.getDescriptor());
/*      */     }
/*  983 */     if ((cst instanceof Handle)) {
/*  984 */       Handle h = (Handle)cst;
/*  985 */       return newHandleItem(h.tag, h.owner, h.name, h.desc);
/*      */     }
/*  987 */     throw new IllegalArgumentException("value " + cst);
/*      */   }
/*      */ 
/*      */   public int newConst(Object cst)
/*      */   {
/* 1005 */     return newConstItem(cst).index;
/*      */   }
/*      */ 
/*      */   public int newUTF8(String value)
/*      */   {
/* 1019 */     this.key.set(1, value, null, null);
/* 1020 */     Item result = get(this.key);
/* 1021 */     if (result == null) {
/* 1022 */       this.pool.putByte(1).putUTF8(value);
/* 1023 */       result = new Item(this.index++, this.key);
/* 1024 */       put(result);
/*      */     }
/* 1026 */     return result.index;
/*      */   }
/*      */ 
/*      */   Item newClassItem(String value)
/*      */   {
/* 1040 */     this.key2.set(7, value, null, null);
/* 1041 */     Item result = get(this.key2);
/* 1042 */     if (result == null) {
/* 1043 */       this.pool.put12(7, newUTF8(value));
/* 1044 */       result = new Item(this.index++, this.key2);
/* 1045 */       put(result);
/*      */     }
/* 1047 */     return result;
/*      */   }
/*      */ 
/*      */   public int newClass(String value)
/*      */   {
/* 1061 */     return newClassItem(value).index;
/*      */   }
/*      */ 
/*      */   Item newMethodTypeItem(String methodDesc)
/*      */   {
/* 1075 */     this.key2.set(16, methodDesc, null, null);
/* 1076 */     Item result = get(this.key2);
/* 1077 */     if (result == null) {
/* 1078 */       this.pool.put12(16, newUTF8(methodDesc));
/* 1079 */       result = new Item(this.index++, this.key2);
/* 1080 */       put(result);
/*      */     }
/* 1082 */     return result;
/*      */   }
/*      */ 
/*      */   public int newMethodType(String methodDesc)
/*      */   {
/* 1097 */     return newMethodTypeItem(methodDesc).index;
/*      */   }
/*      */ 
/*      */   Item newHandleItem(int tag, String owner, String name, String desc)
/*      */   {
/* 1124 */     this.key4.set(20 + tag, owner, name, desc);
/* 1125 */     Item result = get(this.key4);
/* 1126 */     if (result == null) {
/* 1127 */       if (tag <= 4)
/* 1128 */         put112(15, tag, newField(owner, name, desc));
/*      */       else {
/* 1130 */         put112(15, tag, 
/* 1132 */           newMethod(owner, name, desc, tag == 9));
/*      */       }
/*      */ 
/* 1135 */       result = new Item(this.index++, this.key4);
/* 1136 */       put(result);
/*      */     }
/* 1138 */     return result;
/*      */   }
/*      */ 
/*      */   public int newHandle(int tag, String owner, String name, String desc)
/*      */   {
/* 1166 */     return newHandleItem(tag, owner, name, desc).index;
/*      */   }
/*      */ 
/*      */   Item newInvokeDynamicItem(String name, String desc, Handle bsm, Object[] bsmArgs)
/*      */   {
/* 1189 */     ByteVector bootstrapMethods = this.bootstrapMethods;
/* 1190 */     if (bootstrapMethods == null) {
/* 1191 */       bootstrapMethods = this.bootstrapMethods = new ByteVector();
/*      */     }
/*      */ 
/* 1194 */     int position = bootstrapMethods.length;
/*      */ 
/* 1196 */     int hashCode = bsm.hashCode();
/* 1197 */     bootstrapMethods.putShort(newHandle(bsm.tag, bsm.owner, bsm.name, bsm.desc));
/*      */ 
/* 1200 */     int argsLength = bsmArgs.length;
/* 1201 */     bootstrapMethods.putShort(argsLength);
/*      */ 
/* 1203 */     for (int i = 0; i < argsLength; i++) {
/* 1204 */       Object bsmArg = bsmArgs[i];
/* 1205 */       hashCode ^= bsmArg.hashCode();
/* 1206 */       bootstrapMethods.putShort(newConst(bsmArg));
/*      */     }
/*      */ 
/* 1209 */     byte[] data = bootstrapMethods.data;
/* 1210 */     int length = 2 + argsLength << 1;
/* 1211 */     hashCode &= 2147483647;
/* 1212 */     Item result = this.items[(hashCode % this.items.length)];
/* 1213 */     label246: while (result != null)
/* 1214 */       if ((result.type != 33) || (result.hashCode != hashCode)) {
/* 1215 */         result = result.next;
/*      */       }
/*      */       else
/*      */       {
/* 1221 */         int resultPosition = result.intVal;
/* 1222 */         for (int p = 0; ; p++) { if (p >= length) break label246;
/* 1223 */           if (data[(position + p)] != data[(resultPosition + p)]) {
/* 1224 */             result = result.next;
/* 1225 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     int bootstrapMethodIndex;
/* 1232 */     if (result != null) {
/* 1233 */       int bootstrapMethodIndex = result.index;
/* 1234 */       bootstrapMethods.length = position;
/*      */     } else {
/* 1236 */       bootstrapMethodIndex = this.bootstrapMethodsCount++;
/* 1237 */       result = new Item(bootstrapMethodIndex);
/* 1238 */       result.set(position, hashCode);
/* 1239 */       put(result);
/*      */     }
/*      */ 
/* 1243 */     this.key3.set(name, desc, bootstrapMethodIndex);
/* 1244 */     result = get(this.key3);
/* 1245 */     if (result == null) {
/* 1246 */       put122(18, bootstrapMethodIndex, newNameType(name, desc));
/* 1247 */       result = new Item(this.index++, this.key3);
/* 1248 */       put(result);
/*      */     }
/* 1250 */     return result;
/*      */   }
/*      */ 
/*      */   public int newInvokeDynamic(String name, String desc, Handle bsm, Object[] bsmArgs)
/*      */   {
/* 1273 */     return newInvokeDynamicItem(name, desc, bsm, bsmArgs).index;
/*      */   }
/*      */ 
/*      */   Item newFieldItem(String owner, String name, String desc)
/*      */   {
/* 1289 */     this.key3.set(9, owner, name, desc);
/* 1290 */     Item result = get(this.key3);
/* 1291 */     if (result == null) {
/* 1292 */       put122(9, newClass(owner), newNameType(name, desc));
/* 1293 */       result = new Item(this.index++, this.key3);
/* 1294 */       put(result);
/*      */     }
/* 1296 */     return result;
/*      */   }
/*      */ 
/*      */   public int newField(String owner, String name, String desc)
/*      */   {
/* 1314 */     return newFieldItem(owner, name, desc).index;
/*      */   }
/*      */ 
/*      */   Item newMethodItem(String owner, String name, String desc, boolean itf)
/*      */   {
/* 1333 */     int type = itf ? 11 : 10;
/* 1334 */     this.key3.set(type, owner, name, desc);
/* 1335 */     Item result = get(this.key3);
/* 1336 */     if (result == null) {
/* 1337 */       put122(type, newClass(owner), newNameType(name, desc));
/* 1338 */       result = new Item(this.index++, this.key3);
/* 1339 */       put(result);
/*      */     }
/* 1341 */     return result;
/*      */   }
/*      */ 
/*      */   public int newMethod(String owner, String name, String desc, boolean itf)
/*      */   {
/* 1362 */     return newMethodItem(owner, name, desc, itf).index;
/*      */   }
/*      */ 
/*      */   Item newInteger(int value)
/*      */   {
/* 1374 */     this.key.set(value);
/* 1375 */     Item result = get(this.key);
/* 1376 */     if (result == null) {
/* 1377 */       this.pool.putByte(3).putInt(value);
/* 1378 */       result = new Item(this.index++, this.key);
/* 1379 */       put(result);
/*      */     }
/* 1381 */     return result;
/*      */   }
/*      */ 
/*      */   Item newFloat(float value)
/*      */   {
/* 1393 */     this.key.set(value);
/* 1394 */     Item result = get(this.key);
/* 1395 */     if (result == null) {
/* 1396 */       this.pool.putByte(4).putInt(this.key.intVal);
/* 1397 */       result = new Item(this.index++, this.key);
/* 1398 */       put(result);
/*      */     }
/* 1400 */     return result;
/*      */   }
/*      */ 
/*      */   Item newLong(long value)
/*      */   {
/* 1412 */     this.key.set(value);
/* 1413 */     Item result = get(this.key);
/* 1414 */     if (result == null) {
/* 1415 */       this.pool.putByte(5).putLong(value);
/* 1416 */       result = new Item(this.index, this.key);
/* 1417 */       this.index += 2;
/* 1418 */       put(result);
/*      */     }
/* 1420 */     return result;
/*      */   }
/*      */ 
/*      */   Item newDouble(double value)
/*      */   {
/* 1432 */     this.key.set(value);
/* 1433 */     Item result = get(this.key);
/* 1434 */     if (result == null) {
/* 1435 */       this.pool.putByte(6).putLong(this.key.longVal);
/* 1436 */       result = new Item(this.index, this.key);
/* 1437 */       this.index += 2;
/* 1438 */       put(result);
/*      */     }
/* 1440 */     return result;
/*      */   }
/*      */ 
/*      */   private Item newString(String value)
/*      */   {
/* 1452 */     this.key2.set(8, value, null, null);
/* 1453 */     Item result = get(this.key2);
/* 1454 */     if (result == null) {
/* 1455 */       this.pool.put12(8, newUTF8(value));
/* 1456 */       result = new Item(this.index++, this.key2);
/* 1457 */       put(result);
/*      */     }
/* 1459 */     return result;
/*      */   }
/*      */ 
/*      */   public int newNameType(String name, String desc)
/*      */   {
/* 1475 */     return newNameTypeItem(name, desc).index;
/*      */   }
/*      */ 
/*      */   Item newNameTypeItem(String name, String desc)
/*      */   {
/* 1489 */     this.key2.set(12, name, desc, null);
/* 1490 */     Item result = get(this.key2);
/* 1491 */     if (result == null) {
/* 1492 */       put122(12, newUTF8(name), newUTF8(desc));
/* 1493 */       result = new Item(this.index++, this.key2);
/* 1494 */       put(result);
/*      */     }
/* 1496 */     return result;
/*      */   }
/*      */ 
/*      */   int addType(String type)
/*      */   {
/* 1508 */     this.key.set(30, type, null, null);
/* 1509 */     Item result = get(this.key);
/* 1510 */     if (result == null) {
/* 1511 */       result = addType(this.key);
/*      */     }
/* 1513 */     return result.index;
/*      */   }
/*      */ 
/*      */   int addUninitializedType(String type, int offset)
/*      */   {
/* 1529 */     this.key.type = 31;
/* 1530 */     this.key.intVal = offset;
/* 1531 */     this.key.strVal1 = type;
/* 1532 */     this.key.hashCode = (0x7FFFFFFF & 31 + type.hashCode() + offset);
/* 1533 */     Item result = get(this.key);
/* 1534 */     if (result == null) {
/* 1535 */       result = addType(this.key);
/*      */     }
/* 1537 */     return result.index;
/*      */   }
/*      */ 
/*      */   private Item addType(Item item)
/*      */   {
/* 1549 */     this.typeCount = ((short)(this.typeCount + 1));
/* 1550 */     Item result = new Item(this.typeCount, this.key);
/* 1551 */     put(result);
/* 1552 */     if (this.typeTable == null) {
/* 1553 */       this.typeTable = new Item[16];
/*      */     }
/* 1555 */     if (this.typeCount == this.typeTable.length) {
/* 1556 */       Item[] newTable = new Item[2 * this.typeTable.length];
/* 1557 */       System.arraycopy(this.typeTable, 0, newTable, 0, this.typeTable.length);
/* 1558 */       this.typeTable = newTable;
/*      */     }
/* 1560 */     this.typeTable[this.typeCount] = result;
/* 1561 */     return result;
/*      */   }
/*      */ 
/*      */   int getMergedType(int type1, int type2)
/*      */   {
/* 1577 */     this.key2.type = 32;
/* 1578 */     this.key2.longVal = (type1 | type2 << 32);
/* 1579 */     this.key2.hashCode = (0x7FFFFFFF & 32 + type1 + type2);
/* 1580 */     Item result = get(this.key2);
/* 1581 */     if (result == null) {
/* 1582 */       String t = this.typeTable[type1].strVal1;
/* 1583 */       String u = this.typeTable[type2].strVal1;
/* 1584 */       this.key2.intVal = addType(getCommonSuperClass(t, u));
/* 1585 */       result = new Item(0, this.key2);
/* 1586 */       put(result);
/*      */     }
/* 1588 */     return result.intVal;
/*      */   }
/*      */ 
/*      */   protected String getCommonSuperClass(String type1, String type2)
/*      */   {
/* 1609 */     ClassLoader classLoader = getClass().getClassLoader();
/*      */     try {
/* 1611 */       Class c = Class.forName(type1.replace('/', '.'), false, classLoader);
/* 1612 */       d = Class.forName(type2.replace('/', '.'), false, classLoader);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       Class d;
/* 1614 */       throw new RuntimeException(e.toString());
/*      */     }
/*      */     Class d;
/*      */     Class c;
/* 1616 */     if (c.isAssignableFrom(d)) {
/* 1617 */       return type1;
/*      */     }
/* 1619 */     if (d.isAssignableFrom(c)) {
/* 1620 */       return type2;
/*      */     }
/* 1622 */     if ((c.isInterface()) || (d.isInterface())) {
/* 1623 */       return "java/lang/Object";
/*      */     }
/*      */     do
/* 1626 */       c = c.getSuperclass();
/* 1627 */     while (!c.isAssignableFrom(d));
/* 1628 */     return c.getName().replace('.', '/');
/*      */   }
/*      */ 
/*      */   private Item get(Item key)
/*      */   {
/* 1642 */     Item i = this.items[(key.hashCode % this.items.length)];
/* 1643 */     while ((i != null) && ((i.type != key.type) || (!key.isEqualTo(i)))) {
/* 1644 */       i = i.next;
/*      */     }
/* 1646 */     return i;
/*      */   }
/*      */ 
/*      */   private void put(Item i)
/*      */   {
/* 1657 */     if (this.index + this.typeCount > this.threshold) {
/* 1658 */       int ll = this.items.length;
/* 1659 */       int nl = ll * 2 + 1;
/* 1660 */       Item[] newItems = new Item[nl];
/* 1661 */       for (int l = ll - 1; l >= 0; l--) {
/* 1662 */         Item j = this.items[l];
/* 1663 */         while (j != null) {
/* 1664 */           int index = j.hashCode % newItems.length;
/* 1665 */           Item k = j.next;
/* 1666 */           j.next = newItems[index];
/* 1667 */           newItems[index] = j;
/* 1668 */           j = k;
/*      */         }
/*      */       }
/* 1671 */       this.items = newItems;
/* 1672 */       this.threshold = ((int)(nl * 0.75D));
/*      */     }
/* 1674 */     int index = i.hashCode % this.items.length;
/* 1675 */     i.next = this.items[index];
/* 1676 */     this.items[index] = i;
/*      */   }
/*      */ 
/*      */   private void put122(int b, int s1, int s2)
/*      */   {
/* 1690 */     this.pool.put12(b, s1).putShort(s2);
/*      */   }
/*      */ 
/*      */   private void put112(int b1, int b2, int s)
/*      */   {
/* 1704 */     this.pool.put11(b1, b2).putShort(s);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  506 */     byte[] b = new byte['Ü'];
/*  507 */     String s = "AAAAAAAAAAAAAAAABCLMMDDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAADDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANAAAAAAAAAAAAAAAAAAAAJJJJJJJJJJJJJJJJDOPAAAAAAGGGGGGGHIFBFAAFFAARQJJKKJJJJJJJJJJJJJJJJJJ";
/*      */ 
/*  511 */     for (int i = 0; i < b.length; i++)
/*  512 */       b[i] = ((byte)(s.charAt(i) - 'A'));
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.ClassWriter
 * JD-Core Version:    0.6.2
 */