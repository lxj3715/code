package org.springframework.asm;

class Context
{
  Attribute[] attrs;
  int flags;
  char[] buffer;
  int[] bootstrapMethods;
  int access;
  String name;
  String desc;
  int offset;
  int mode;
  int localCount;
  int localDiff;
  Object[] local;
  int stackCount;
  Object[] stack;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.Context
 * JD-Core Version:    0.6.2
 */