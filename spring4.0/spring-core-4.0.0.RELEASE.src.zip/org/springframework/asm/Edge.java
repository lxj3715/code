package org.springframework.asm;

class Edge
{
  static final int NORMAL = 0;
  static final int EXCEPTION = 2147483647;
  int info;
  Label successor;
  Edge next;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.Edge
 * JD-Core Version:    0.6.2
 */