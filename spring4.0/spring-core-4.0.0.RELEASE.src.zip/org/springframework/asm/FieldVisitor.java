/*     */ package org.springframework.asm;
/*     */ 
/*     */ public abstract class FieldVisitor
/*     */ {
/*     */   protected final int api;
/*     */   protected FieldVisitor fv;
/*     */ 
/*     */   public FieldVisitor(int api)
/*     */   {
/*  61 */     this(api, null);
/*     */   }
/*     */ 
/*     */   public FieldVisitor(int api, FieldVisitor fv)
/*     */   {
/*  75 */     if (api != 262144) {
/*  76 */       throw new IllegalArgumentException();
/*     */     }
/*  78 */     this.api = api;
/*  79 */     this.fv = fv;
/*     */   }
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*     */   {
/*  93 */     if (this.fv != null) {
/*  94 */       return this.fv.visitAnnotation(desc, visible);
/*     */     }
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */   public void visitAttribute(Attribute attr)
/*     */   {
/* 106 */     if (this.fv != null)
/* 107 */       this.fv.visitAttribute(attr);
/*     */   }
/*     */ 
/*     */   public void visitEnd()
/*     */   {
/* 117 */     if (this.fv != null)
/* 118 */       this.fv.visitEnd();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.FieldVisitor
 * JD-Core Version:    0.6.2
 */