/*     */ package org.springframework.asm;
/*     */ 
/*     */ public final class Handle
/*     */ {
/*     */   final int tag;
/*     */   final String owner;
/*     */   final String name;
/*     */   final String desc;
/*     */ 
/*     */   public Handle(int tag, String owner, String name, String desc)
/*     */   {
/*  89 */     this.tag = tag;
/*  90 */     this.owner = owner;
/*  91 */     this.name = name;
/*  92 */     this.desc = desc;
/*     */   }
/*     */ 
/*     */   public int getTag()
/*     */   {
/* 106 */     return this.tag;
/*     */   }
/*     */ 
/*     */   public String getOwner()
/*     */   {
/* 117 */     return this.owner;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 126 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getDesc()
/*     */   {
/* 135 */     return this.desc;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 140 */     if (obj == this) {
/* 141 */       return true;
/*     */     }
/* 143 */     if (!(obj instanceof Handle)) {
/* 144 */       return false;
/*     */     }
/* 146 */     Handle h = (Handle)obj;
/*     */ 
/* 148 */     return (this.tag == h.tag) && (this.owner.equals(h.owner)) && (this.name.equals(h.name)) && 
/* 148 */       (this.desc
/* 148 */       .equals(h.desc));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 153 */     return this.tag + this.owner.hashCode() * this.name.hashCode() * this.desc.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 168 */     return this.owner + '.' + this.name + this.desc + " (" + this.tag + ')';
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.Handle
 * JD-Core Version:    0.6.2
 */