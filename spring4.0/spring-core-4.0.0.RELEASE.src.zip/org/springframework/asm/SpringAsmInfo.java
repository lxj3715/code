package org.springframework.asm;

public final class SpringAsmInfo
{
  public static final int ASM_VERSION = 262144;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.SpringAsmInfo
 * JD-Core Version:    0.6.2
 */