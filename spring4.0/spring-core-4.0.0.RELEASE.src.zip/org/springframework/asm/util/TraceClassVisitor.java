/*    */ package org.springframework.asm.util;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ public class TraceClassVisitor extends ClassVisitor
/*    */ {
/*    */   public TraceClassVisitor(Object object, PrintWriter pw)
/*    */   {
/* 34 */     super(262144);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.asm.util.TraceClassVisitor
 * JD-Core Version:    0.6.2
 */