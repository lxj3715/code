package org.springframework.cglib.core;

import org.springframework.asm.ClassVisitor;

public abstract interface ClassGenerator
{
  public abstract void generateClass(ClassVisitor paramClassVisitor)
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.ClassGenerator
 * JD-Core Version:    0.6.2
 */