/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.asm.ClassReader;
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ public class ClassNameReader
/*    */ {
/* 29 */   private static final EarlyExitException EARLY_EXIT = new EarlyExitException(null);
/*    */ 
/*    */   public static String getClassName(ClassReader r)
/*    */   {
/* 34 */     return getClassInfo(r)[0];
/*    */   }
/*    */ 
/*    */   public static String[] getClassInfo(ClassReader r)
/*    */   {
/* 39 */     List array = new ArrayList();
/*    */     try {
/* 41 */       r.accept(new ClassVisitor(262144, null)
/*    */       {
/*    */         private final List val$array;
/*    */ 
/*    */         public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*    */         {
/* 48 */           this.val$array.add(name.replace('/', '.'));
/* 49 */           if (superName != null) {
/* 50 */             this.val$array.add(superName.replace('/', '.'));
/*    */           }
/* 52 */           for (int i = 0; i < interfaces.length; i++) {
/* 53 */             this.val$array.add(interfaces[i].replace('/', '.'));
/*    */           }
/*    */ 
/* 56 */           throw ClassNameReader.EARLY_EXIT;
/*    */         }
/*    */       }
/*    */       , 6);
/*    */     }
/*    */     catch (EarlyExitException e)
/*    */     {
/*    */     }
/*    */ 
/* 61 */     return (String[])array.toArray(new String[0]);
/*    */   }
/*    */ 
/*    */   private static class EarlyExitException extends RuntimeException
/*    */   {
/*    */     private EarlyExitException()
/*    */     {
/*    */     }
/*    */ 
/*    */     EarlyExitException(ClassNameReader.1 x0)
/*    */     {
/* 30 */       this();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.ClassNameReader
 * JD-Core Version:    0.6.2
 */