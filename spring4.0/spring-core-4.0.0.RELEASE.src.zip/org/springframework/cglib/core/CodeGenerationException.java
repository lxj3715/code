/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ public class CodeGenerationException extends RuntimeException
/*    */ {
/*    */   private Throwable cause;
/*    */ 
/*    */   public CodeGenerationException(Throwable cause)
/*    */   {
/* 25 */     super(cause.getClass().getName() + "-->" + cause.getMessage());
/* 26 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public Throwable getCause() {
/* 30 */     return this.cause;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.CodeGenerationException
 * JD-Core Version:    0.6.2
 */