package org.springframework.cglib.core;

public abstract interface Converter
{
  public abstract Object convert(Object paramObject1, Class paramClass, Object paramObject2);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.Converter
 * JD-Core Version:    0.6.2
 */