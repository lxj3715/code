package org.springframework.cglib.core;

public abstract interface GeneratorStrategy
{
  public abstract byte[] generate(ClassGenerator paramClassGenerator)
    throws Exception;

  public abstract boolean equals(Object paramObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.GeneratorStrategy
 * JD-Core Version:    0.6.2
 */