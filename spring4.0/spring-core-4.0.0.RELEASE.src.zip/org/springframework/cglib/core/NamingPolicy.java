package org.springframework.cglib.core;

public abstract interface NamingPolicy
{
  public abstract String getClassName(String paramString1, String paramString2, Object paramObject, Predicate paramPredicate);

  public abstract boolean equals(Object paramObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.NamingPolicy
 * JD-Core Version:    0.6.2
 */