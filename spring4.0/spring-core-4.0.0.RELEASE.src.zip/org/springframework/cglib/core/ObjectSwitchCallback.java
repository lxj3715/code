package org.springframework.cglib.core;

import org.springframework.asm.Label;

public abstract interface ObjectSwitchCallback
{
  public abstract void processCase(Object paramObject, Label paramLabel)
    throws Exception;

  public abstract void processDefault()
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.ObjectSwitchCallback
 * JD-Core Version:    0.6.2
 */