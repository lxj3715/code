package org.springframework.cglib.core;

import org.springframework.asm.Type;

public abstract interface ProcessArrayCallback
{
  public abstract void processElement(Type paramType);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.ProcessArrayCallback
 * JD-Core Version:    0.6.2
 */