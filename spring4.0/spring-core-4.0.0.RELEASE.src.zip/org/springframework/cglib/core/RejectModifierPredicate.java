/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ 
/*    */ public class RejectModifierPredicate
/*    */   implements Predicate
/*    */ {
/*    */   private int rejectMask;
/*    */ 
/*    */   public RejectModifierPredicate(int rejectMask)
/*    */   {
/* 24 */     this.rejectMask = rejectMask;
/*    */   }
/*    */ 
/*    */   public boolean evaluate(Object arg) {
/* 28 */     return (((Member)arg).getModifiers() & this.rejectMask) == 0;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.RejectModifierPredicate
 * JD-Core Version:    0.6.2
 */