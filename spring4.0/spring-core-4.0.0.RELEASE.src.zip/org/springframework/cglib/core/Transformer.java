package org.springframework.cglib.core;

public abstract interface Transformer
{
  public abstract Object transform(Object paramObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.core.Transformer
 * JD-Core Version:    0.6.2
 */