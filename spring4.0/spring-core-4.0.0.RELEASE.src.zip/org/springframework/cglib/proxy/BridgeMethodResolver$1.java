/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.asm.MethodVisitor;
/*    */ import org.springframework.cglib.core.Signature;
/*    */ 
/*    */ class BridgeMethodResolver$1 extends MethodVisitor
/*    */ {
/*    */   private final BridgeMethodResolver.BridgedFinder this$0;
/*    */ 
/*    */   BridgeMethodResolver$1(BridgeMethodResolver.BridgedFinder this$0, int x0)
/*    */   {
/* 91 */     super(x0); this.this$0 = this$0;
/*    */   }
/* 93 */   public void visitMethodInsn(int opcode, String owner, String name, String desc) { if ((opcode == 183) && (BridgeMethodResolver.BridgedFinder.access$000(this.this$0) != null)) {
/* 94 */       Signature target = new Signature(name, desc);
/*    */ 
/* 101 */       if (!target.equals(BridgeMethodResolver.BridgedFinder.access$000(this.this$0))) {
/* 102 */         BridgeMethodResolver.BridgedFinder.access$100(this.this$0).put(BridgeMethodResolver.BridgedFinder.access$000(this.this$0), target);
/*    */       }
/* 104 */       BridgeMethodResolver.BridgedFinder.access$002(this.this$0, null);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.BridgeMethodResolver.1
 * JD-Core Version:    0.6.2
 */