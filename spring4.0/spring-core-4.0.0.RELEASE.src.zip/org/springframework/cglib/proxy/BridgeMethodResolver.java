/*     */ package org.springframework.cglib.proxy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.ClassReader;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ 
/*     */ class BridgeMethodResolver
/*     */ {
/*     */   private final Map declToBridge;
/*     */ 
/*     */   public BridgeMethodResolver(Map declToBridge)
/*     */   {
/*  47 */     this.declToBridge = declToBridge;
/*     */   }
/*     */ 
/*     */   public Map resolveAll()
/*     */   {
/*  55 */     Map resolved = new HashMap();
/*  56 */     for (Iterator entryIter = this.declToBridge.entrySet().iterator(); entryIter.hasNext(); ) {
/*  57 */       Map.Entry entry = (Map.Entry)entryIter.next();
/*  58 */       Class owner = (Class)entry.getKey();
/*  59 */       Set bridges = (Set)entry.getValue();
/*     */       try {
/*  61 */         new ClassReader(owner.getName()).accept(new BridgedFinder(bridges, resolved), 6);
/*     */       }
/*     */       catch (IOException ignored) {
/*     */       }
/*     */     }
/*  66 */     return resolved;
/*     */   }
/*     */ 
/*     */   private static class BridgedFinder extends ClassVisitor
/*     */   {
/*     */     private Map resolved;
/*     */     private Set eligableMethods;
/*  73 */     private Signature currentMethod = null;
/*     */ 
/*     */     BridgedFinder(Set eligableMethods, Map resolved) {
/*  76 */       super();
/*  77 */       this.resolved = resolved;
/*  78 */       this.eligableMethods = eligableMethods;
/*     */     }
/*     */ 
/*     */     public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*     */     {
/*     */     }
/*     */ 
/*     */     public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*     */     {
/*  87 */       Signature sig = new Signature(name, desc);
/*  88 */       if (this.eligableMethods.remove(sig)) {
/*  89 */         this.currentMethod = sig;
/*  90 */         return new BridgeMethodResolver.1(this, 262144);
/*     */       }
/*     */ 
/* 109 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.BridgeMethodResolver
 * JD-Core Version:    0.6.2
 */