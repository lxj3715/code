package org.springframework.cglib.proxy;

public abstract interface Callback
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.Callback
 * JD-Core Version:    0.6.2
 */