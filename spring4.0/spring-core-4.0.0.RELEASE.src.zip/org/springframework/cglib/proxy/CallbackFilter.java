package org.springframework.cglib.proxy;

import java.lang.reflect.Method;

public abstract interface CallbackFilter
{
  public abstract int accept(Method paramMethod);

  public abstract boolean equals(Object paramObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.CallbackFilter
 * JD-Core Version:    0.6.2
 */