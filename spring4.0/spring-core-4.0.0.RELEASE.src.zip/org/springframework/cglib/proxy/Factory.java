package org.springframework.cglib.proxy;

public abstract interface Factory
{
  public abstract Object newInstance(Callback paramCallback);

  public abstract Object newInstance(Callback[] paramArrayOfCallback);

  public abstract Object newInstance(Class[] paramArrayOfClass, Object[] paramArrayOfObject, Callback[] paramArrayOfCallback);

  public abstract Callback getCallback(int paramInt);

  public abstract void setCallback(int paramInt, Callback paramCallback);

  public abstract void setCallbacks(Callback[] paramArrayOfCallback);

  public abstract Callback[] getCallbacks();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.Factory
 * JD-Core Version:    0.6.2
 */