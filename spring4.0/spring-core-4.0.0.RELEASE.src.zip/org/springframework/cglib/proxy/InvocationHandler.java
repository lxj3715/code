package org.springframework.cglib.proxy;

import java.lang.reflect.Method;

public abstract interface InvocationHandler extends Callback
{
  public abstract Object invoke(Object paramObject, Method paramMethod, Object[] paramArrayOfObject)
    throws Throwable;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.InvocationHandler
 * JD-Core Version:    0.6.2
 */