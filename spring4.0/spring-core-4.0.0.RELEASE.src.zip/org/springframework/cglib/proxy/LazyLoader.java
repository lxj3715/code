package org.springframework.cglib.proxy;

public abstract interface LazyLoader extends Callback
{
  public abstract Object loadObject()
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.LazyLoader
 * JD-Core Version:    0.6.2
 */