package org.springframework.cglib.proxy;

import java.lang.reflect.Method;

public abstract interface MethodInterceptor extends Callback
{
  public abstract Object intercept(Object paramObject, Method paramMethod, Object[] paramArrayOfObject, MethodProxy paramMethodProxy)
    throws Throwable;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.MethodInterceptor
 * JD-Core Version:    0.6.2
 */