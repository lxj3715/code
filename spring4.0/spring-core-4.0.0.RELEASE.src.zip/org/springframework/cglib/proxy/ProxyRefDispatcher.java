package org.springframework.cglib.proxy;

public abstract interface ProxyRefDispatcher extends Callback
{
  public abstract Object loadObject(Object paramObject)
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.ProxyRefDispatcher
 * JD-Core Version:    0.6.2
 */