/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ import org.springframework.cglib.core.CodeGenerationException;
/*    */ 
/*    */ public class UndeclaredThrowableException extends CodeGenerationException
/*    */ {
/*    */   public UndeclaredThrowableException(Throwable t)
/*    */   {
/* 30 */     super(t);
/*    */   }
/*    */ 
/*    */   public Throwable getUndeclaredThrowable() {
/* 34 */     return getCause();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.proxy.UndeclaredThrowableException
 * JD-Core Version:    0.6.2
 */