/*     */ package org.springframework.cglib.reflect;
/*     */ 
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.Local;
/*     */ import org.springframework.cglib.core.MethodInfo;
/*     */ import org.springframework.cglib.core.ProcessArrayCallback;
/*     */ 
/*     */ class MulticastDelegate$1
/*     */   implements ProcessArrayCallback
/*     */ {
/*     */   private final CodeEmitter val$e;
/*     */   private final MethodInfo val$method;
/*     */   private final boolean val$returns;
/*     */   private final Local val$result2;
/*     */   private final MulticastDelegate.Generator this$0;
/*     */ 
/*     */   MulticastDelegate$1(MulticastDelegate.Generator this$0, CodeEmitter val$e, MethodInfo val$method, boolean val$returns, Local val$result2)
/*     */   {
/* 145 */     this.this$0 = this$0; this.val$e = val$e; this.val$method = val$method; this.val$returns = val$returns; this.val$result2 = val$result2; } 
/* 146 */   public void processElement(Type type) { this.val$e.checkcast(Type.getType(MulticastDelegate.Generator.access$000(this.this$0)));
/* 147 */     this.val$e.load_args();
/* 148 */     this.val$e.invoke(this.val$method);
/* 149 */     if (this.val$returns)
/* 150 */       this.val$e.store_local(this.val$result2);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.reflect.MulticastDelegate.1
 * JD-Core Version:    0.6.2
 */