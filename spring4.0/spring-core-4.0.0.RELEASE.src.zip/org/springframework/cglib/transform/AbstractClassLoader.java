/*     */ package org.springframework.cglib.transform;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.springframework.asm.Attribute;
/*     */ import org.springframework.asm.ClassReader;
/*     */ import org.springframework.cglib.core.ClassGenerator;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.core.DebuggingClassWriter;
/*     */ 
/*     */ public abstract class AbstractClassLoader extends ClassLoader
/*     */ {
/*     */   private ClassFilter filter;
/*     */   private ClassLoader classPath;
/*  35 */   private static ProtectionDomain DOMAIN = (ProtectionDomain)AccessController.doPrivileged(new PrivilegedAction()
/*     */   {
/*     */     public Object run()
/*     */     {
/*  39 */       return AbstractClassLoader.class.getProtectionDomain();
/*     */     }
/*     */   });
/*     */ 
/*     */   protected AbstractClassLoader(ClassLoader parent, ClassLoader classPath, ClassFilter filter)
/*     */   {
/*  45 */     super(parent);
/*  46 */     this.filter = filter;
/*  47 */     this.classPath = classPath;
/*     */   }
/*     */ 
/*     */   public Class loadClass(String name) throws ClassNotFoundException
/*     */   {
/*  52 */     Class loaded = findLoadedClass(name);
/*     */ 
/*  54 */     if ((loaded != null) && 
/*  55 */       (loaded.getClassLoader() == this)) {
/*  56 */       return loaded;
/*     */     }
/*     */ 
/*  60 */     if (!this.filter.accept(name)) {
/*  61 */       return super.loadClass(name);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  66 */       InputStream is = this.classPath.getResourceAsStream(name.replace('.', '/') + ".class");
/*     */ 
/*  70 */       if (is == null)
/*     */       {
/*  72 */         throw new ClassNotFoundException(name);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/*  77 */         r = new ClassReader(is);
/*     */       }
/*     */       finally
/*     */       {
/*     */         ClassReader r;
/*  81 */         is.close();
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */       ClassReader r;
/*  85 */       throw new ClassNotFoundException(name + ":" + e.getMessage());
/*     */     }
/*     */     try
/*     */     {
/*     */       ClassReader r;
/*  89 */       DebuggingClassWriter w = new DebuggingClassWriter(1);
/*     */ 
/*  91 */       getGenerator(r).generateClass(w);
/*  92 */       byte[] b = w.toByteArray();
/*  93 */       Class c = super.defineClass(name, b, 0, b.length, DOMAIN);
/*  94 */       postProcess(c);
/*  95 */       return c;
/*     */     } catch (RuntimeException e) {
/*  97 */       throw e;
/*     */     } catch (Error e) {
/*  99 */       throw e;
/*     */     } catch (Exception e) {
/* 101 */       throw new CodeGenerationException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ClassGenerator getGenerator(ClassReader r) {
/* 106 */     return new ClassReaderGenerator(r, attributes(), getFlags());
/*     */   }
/*     */ 
/*     */   protected int getFlags() {
/* 110 */     return 0;
/*     */   }
/*     */ 
/*     */   protected Attribute[] attributes() {
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   protected void postProcess(Class c)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.AbstractClassLoader
 * JD-Core Version:    0.6.2
 */