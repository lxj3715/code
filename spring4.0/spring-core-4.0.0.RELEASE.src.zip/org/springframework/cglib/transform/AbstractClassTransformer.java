/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ public abstract class AbstractClassTransformer extends ClassTransformer
/*    */ {
/*    */   protected AbstractClassTransformer()
/*    */   {
/* 23 */     super(262144);
/*    */   }
/*    */ 
/*    */   public void setTarget(ClassVisitor target) {
/* 27 */     this.cv = target;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.AbstractClassTransformer
 * JD-Core Version:    0.6.2
 */