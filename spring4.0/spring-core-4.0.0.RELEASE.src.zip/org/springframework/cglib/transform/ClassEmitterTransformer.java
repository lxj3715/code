package org.springframework.cglib.transform;

import org.springframework.cglib.core.ClassEmitter;

public abstract class ClassEmitterTransformer extends ClassEmitter
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.ClassEmitterTransformer
 * JD-Core Version:    0.6.2
 */