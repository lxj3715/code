package org.springframework.cglib.transform;

public abstract interface ClassFilter
{
  public abstract boolean accept(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.ClassFilter
 * JD-Core Version:    0.6.2
 */