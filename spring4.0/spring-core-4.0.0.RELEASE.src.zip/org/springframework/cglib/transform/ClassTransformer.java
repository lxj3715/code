/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ public abstract class ClassTransformer extends ClassVisitor
/*    */ {
/*    */   public ClassTransformer()
/*    */   {
/* 23 */     super(262144);
/*    */   }
/*    */   public ClassTransformer(int opcode) {
/* 26 */     super(opcode);
/*    */   }
/*    */ 
/*    */   public abstract void setTarget(ClassVisitor paramClassVisitor);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.ClassTransformer
 * JD-Core Version:    0.6.2
 */