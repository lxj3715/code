package org.springframework.cglib.transform;

public abstract interface ClassTransformerFactory
{
  public abstract ClassTransformer newInstance();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.ClassTransformerFactory
 * JD-Core Version:    0.6.2
 */