/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ public class ClassTransformerTee extends ClassTransformer
/*    */ {
/*    */   private ClassVisitor branch;
/*    */ 
/*    */   public ClassTransformerTee(ClassVisitor branch)
/*    */   {
/* 25 */     super(262144);
/* 26 */     this.branch = branch;
/*    */   }
/*    */ 
/*    */   public void setTarget(ClassVisitor target) {
/* 30 */     this.cv = new ClassVisitorTee(this.branch, target);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.ClassTransformerTee
 * JD-Core Version:    0.6.2
 */