/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.AnnotationVisitor;
/*    */ import org.springframework.asm.Attribute;
/*    */ import org.springframework.asm.FieldVisitor;
/*    */ 
/*    */ public class FieldVisitorTee extends FieldVisitor
/*    */ {
/*    */   private FieldVisitor fv1;
/*    */   private FieldVisitor fv2;
/*    */ 
/*    */   public FieldVisitorTee(FieldVisitor fv1, FieldVisitor fv2)
/*    */   {
/* 27 */     super(262144);
/* 28 */     this.fv1 = fv1;
/* 29 */     this.fv2 = fv2;
/*    */   }
/*    */ 
/*    */   public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
/* 33 */     return AnnotationVisitorTee.getInstance(this.fv1.visitAnnotation(desc, visible), this.fv2.visitAnnotation(desc, visible));
/*    */   }
/*    */ 
/*    */   public void visitAttribute(Attribute attr)
/*    */   {
/* 38 */     this.fv1.visitAttribute(attr);
/* 39 */     this.fv2.visitAttribute(attr);
/*    */   }
/*    */ 
/*    */   public void visitEnd() {
/* 43 */     this.fv1.visitEnd();
/* 44 */     this.fv2.visitEnd();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.FieldVisitorTee
 * JD-Core Version:    0.6.2
 */