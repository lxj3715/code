package org.springframework.cglib.transform;

public abstract interface MethodFilter
{
  public abstract boolean accept(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.MethodFilter
 * JD-Core Version:    0.6.2
 */