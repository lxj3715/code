package org.springframework.cglib.transform.impl;

public abstract interface FieldProvider
{
  public abstract String[] getFieldNames();

  public abstract Class[] getFieldTypes();

  public abstract void setField(int paramInt, Object paramObject);

  public abstract Object getField(int paramInt);

  public abstract void setField(String paramString, Object paramObject);

  public abstract Object getField(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.impl.FieldProvider
 * JD-Core Version:    0.6.2
 */