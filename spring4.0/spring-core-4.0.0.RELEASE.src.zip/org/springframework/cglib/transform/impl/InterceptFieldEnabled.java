package org.springframework.cglib.transform.impl;

public abstract interface InterceptFieldEnabled
{
  public abstract void setInterceptFieldCallback(InterceptFieldCallback paramInterceptFieldCallback);

  public abstract InterceptFieldCallback getInterceptFieldCallback();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.impl.InterceptFieldEnabled
 * JD-Core Version:    0.6.2
 */