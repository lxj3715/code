package org.springframework.cglib.transform.impl;

import org.springframework.asm.Type;

public abstract interface InterceptFieldFilter
{
  public abstract boolean acceptRead(Type paramType, String paramString);

  public abstract boolean acceptWrite(Type paramType, String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.impl.InterceptFieldFilter
 * JD-Core Version:    0.6.2
 */