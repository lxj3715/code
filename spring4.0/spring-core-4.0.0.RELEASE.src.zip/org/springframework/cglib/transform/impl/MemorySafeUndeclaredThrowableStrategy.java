/*    */ package org.springframework.cglib.transform.impl;
/*    */ 
/*    */ import org.springframework.cglib.core.ClassGenerator;
/*    */ import org.springframework.cglib.core.DefaultGeneratorStrategy;
/*    */ import org.springframework.cglib.core.TypeUtils;
/*    */ import org.springframework.cglib.transform.ClassTransformer;
/*    */ import org.springframework.cglib.transform.MethodFilter;
/*    */ import org.springframework.cglib.transform.MethodFilterTransformer;
/*    */ import org.springframework.cglib.transform.TransformingClassGenerator;
/*    */ 
/*    */ public class MemorySafeUndeclaredThrowableStrategy extends DefaultGeneratorStrategy
/*    */ {
/* 33 */   private static final MethodFilter TRANSFORM_FILTER = new MethodFilter()
/*    */   {
/*    */     public boolean accept(int access, String name, String desc, String signature, String[] exceptions) {
/* 36 */       return (!TypeUtils.isPrivate(access)) && (name.indexOf('$') < 0);
/*    */     }
/* 33 */   };
/*    */   private Class<?> wrapper;
/*    */ 
/*    */   public MemorySafeUndeclaredThrowableStrategy(Class<?> wrapper)
/*    */   {
/* 45 */     this.wrapper = wrapper;
/*    */   }
/*    */ 
/*    */   protected ClassGenerator transform(ClassGenerator cg) throws Exception
/*    */   {
/* 50 */     ClassTransformer tr = new UndeclaredThrowableTransformer(this.wrapper);
/* 51 */     tr = new MethodFilterTransformer(TRANSFORM_FILTER, tr);
/* 52 */     return new TransformingClassGenerator(cg, tr);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.transform.impl.MemorySafeUndeclaredThrowableStrategy
 * JD-Core Version:    0.6.2
 */