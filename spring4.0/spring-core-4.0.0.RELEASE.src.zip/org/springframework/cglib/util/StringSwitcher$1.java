/*     */ package org.springframework.cglib.util;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.cglib.core.CodeEmitter;
/*     */ import org.springframework.cglib.core.ObjectSwitchCallback;
/*     */ 
/*     */ class StringSwitcher$1
/*     */   implements ObjectSwitchCallback
/*     */ {
/*     */   private final CodeEmitter val$e;
/*     */   private final List val$stringList;
/*     */   private final StringSwitcher.Generator this$0;
/*     */ 
/*     */   StringSwitcher$1(StringSwitcher.Generator this$0, CodeEmitter val$e, List val$stringList)
/*     */   {
/* 137 */     this.this$0 = this$0; this.val$e = val$e; this.val$stringList = val$stringList;
/*     */   }
/*     */ 
/*     */   public void processCase(Object key, Label end)
/*     */   {
/* 134 */     this.val$e.push(StringSwitcher.Generator.access$300(this.this$0)[this.val$stringList.indexOf(key)]);
/* 135 */     this.val$e.return_value();
/*     */   }
/*     */   public void processDefault() {
/* 138 */     this.val$e.push(-1);
/* 139 */     this.val$e.return_value();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.cglib.util.StringSwitcher.1
 * JD-Core Version:    0.6.2
 */