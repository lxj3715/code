package org.springframework.core;

public abstract interface AliasRegistry
{
  public abstract void registerAlias(String paramString1, String paramString2);

  public abstract void removeAlias(String paramString);

  public abstract boolean isAlias(String paramString);

  public abstract String[] getAliases(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.AliasRegistry
 * JD-Core Version:    0.6.2
 */