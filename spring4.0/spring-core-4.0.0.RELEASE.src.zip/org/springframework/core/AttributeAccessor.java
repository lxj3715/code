package org.springframework.core;

public abstract interface AttributeAccessor
{
  public abstract void setAttribute(String paramString, Object paramObject);

  public abstract Object getAttribute(String paramString);

  public abstract Object removeAttribute(String paramString);

  public abstract boolean hasAttribute(String paramString);

  public abstract String[] attributeNames();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.AttributeAccessor
 * JD-Core Version:    0.6.2
 */