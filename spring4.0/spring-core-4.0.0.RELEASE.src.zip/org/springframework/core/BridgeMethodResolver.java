/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class BridgeMethodResolver
/*     */ {
/*     */   public static Method findBridgedMethod(Method bridgeMethod)
/*     */   {
/*  59 */     if ((bridgeMethod == null) || (!bridgeMethod.isBridge())) {
/*  60 */       return bridgeMethod;
/*     */     }
/*     */ 
/*  63 */     List candidateMethods = new ArrayList();
/*  64 */     Method[] methods = ReflectionUtils.getAllDeclaredMethods(bridgeMethod.getDeclaringClass());
/*  65 */     for (Method candidateMethod : methods) {
/*  66 */       if (isBridgedCandidateFor(candidateMethod, bridgeMethod)) {
/*  67 */         candidateMethods.add(candidateMethod);
/*     */       }
/*     */     }
/*     */ 
/*  71 */     if (candidateMethods.size() == 1) {
/*  72 */       return (Method)candidateMethods.get(0);
/*     */     }
/*     */ 
/*  75 */     Method bridgedMethod = searchCandidates(candidateMethods, bridgeMethod);
/*  76 */     if (bridgedMethod != null)
/*     */     {
/*  78 */       return bridgedMethod;
/*     */     }
/*     */ 
/*  83 */     return bridgeMethod;
/*     */   }
/*     */ 
/*     */   private static boolean isBridgedCandidateFor(Method candidateMethod, Method bridgeMethod)
/*     */   {
/*  96 */     return (!candidateMethod.isBridge()) && (!candidateMethod.equals(bridgeMethod)) && 
/*  95 */       (candidateMethod
/*  95 */       .getName().equals(bridgeMethod.getName())) && 
/*  96 */       (candidateMethod
/*  96 */       .getParameterTypes().length == bridgeMethod.getParameterTypes().length);
/*     */   }
/*     */ 
/*     */   private static Method searchCandidates(List<Method> candidateMethods, Method bridgeMethod)
/*     */   {
/* 106 */     if (candidateMethods.isEmpty()) {
/* 107 */       return null;
/*     */     }
/* 109 */     Method previousMethod = null;
/* 110 */     boolean sameSig = true;
/* 111 */     for (Method candidateMethod : candidateMethods) {
/* 112 */       if (isBridgeMethodFor(bridgeMethod, candidateMethod, bridgeMethod.getDeclaringClass())) {
/* 113 */         return candidateMethod;
/*     */       }
/* 115 */       if (previousMethod != null)
/*     */       {
/* 117 */         sameSig = (sameSig) && 
/* 117 */           (Arrays.equals(candidateMethod
/* 117 */           .getGenericParameterTypes(), previousMethod.getGenericParameterTypes()));
/*     */       }
/* 119 */       previousMethod = candidateMethod;
/*     */     }
/* 121 */     return sameSig ? (Method)candidateMethods.get(0) : null;
/*     */   }
/*     */ 
/*     */   static boolean isBridgeMethodFor(Method bridgeMethod, Method candidateMethod, Class<?> declaringClass)
/*     */   {
/* 129 */     if (isResolvedTypeMatch(candidateMethod, bridgeMethod, declaringClass)) {
/* 130 */       return true;
/*     */     }
/* 132 */     Method method = findGenericDeclaration(bridgeMethod);
/* 133 */     return (method != null) && (isResolvedTypeMatch(method, candidateMethod, declaringClass));
/*     */   }
/*     */ 
/*     */   private static Method findGenericDeclaration(Method bridgeMethod)
/*     */   {
/* 143 */     Class superclass = bridgeMethod.getDeclaringClass().getSuperclass();
/* 144 */     while ((superclass != null) && (!Object.class.equals(superclass))) {
/* 145 */       Method method = searchForMatch(superclass, bridgeMethod);
/* 146 */       if ((method != null) && (!method.isBridge())) {
/* 147 */         return method;
/*     */       }
/* 149 */       superclass = superclass.getSuperclass();
/*     */     }
/*     */ 
/* 153 */     Class[] interfaces = ClassUtils.getAllInterfacesForClass(bridgeMethod.getDeclaringClass());
/* 154 */     for (Class ifc : interfaces) {
/* 155 */       Method method = searchForMatch(ifc, bridgeMethod);
/* 156 */       if ((method != null) && (!method.isBridge())) {
/* 157 */         return method;
/*     */       }
/*     */     }
/*     */ 
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */   private static boolean isResolvedTypeMatch(Method genericMethod, Method candidateMethod, Class<?> declaringClass)
/*     */   {
/* 172 */     Type[] genericParameters = genericMethod.getGenericParameterTypes();
/* 173 */     Class[] candidateParameters = candidateMethod.getParameterTypes();
/* 174 */     if (genericParameters.length != candidateParameters.length) {
/* 175 */       return false;
/*     */     }
/* 177 */     for (int i = 0; i < candidateParameters.length; i++) {
/* 178 */       ResolvableType genericParameter = ResolvableType.forMethodParameter(genericMethod, i, declaringClass);
/* 179 */       Class candidateParameter = candidateParameters[i];
/* 180 */       if (candidateParameter.isArray())
/*     */       {
/* 182 */         if (!candidateParameter.getComponentType().equals(genericParameter.getComponentType().resolve(Object.class))) {
/* 183 */           return false;
/*     */         }
/*     */       }
/*     */ 
/* 187 */       if (!candidateParameter.equals(genericParameter.resolve(Object.class))) {
/* 188 */         return false;
/*     */       }
/*     */     }
/* 191 */     return true;
/*     */   }
/*     */ 
/*     */   private static Method searchForMatch(Class<?> type, Method bridgeMethod)
/*     */   {
/* 200 */     return ReflectionUtils.findMethod(type, bridgeMethod.getName(), bridgeMethod.getParameterTypes());
/*     */   }
/*     */ 
/*     */   public static boolean isVisibilityBridgeMethodPair(Method bridgeMethod, Method bridgedMethod)
/*     */   {
/* 211 */     if (bridgeMethod == bridgedMethod) {
/* 212 */       return true;
/*     */     }
/*     */ 
/* 215 */     return (Arrays.equals(bridgeMethod.getParameterTypes(), bridgedMethod.getParameterTypes())) && 
/* 215 */       (bridgeMethod
/* 215 */       .getReturnType().equals(bridgedMethod.getReturnType()));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.BridgeMethodResolver
 * JD-Core Version:    0.6.2
 */