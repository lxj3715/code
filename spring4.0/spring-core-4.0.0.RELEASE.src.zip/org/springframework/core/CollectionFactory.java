/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NavigableMap;
/*     */ import java.util.NavigableSet;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public abstract class CollectionFactory
/*     */ {
/*  53 */   private static Class<?> navigableSetClass = null;
/*     */ 
/*  55 */   private static Class<?> navigableMapClass = null;
/*     */ 
/*  57 */   private static final Set<Class<?>> approximableCollectionTypes = new HashSet(10);
/*     */ 
/*  59 */   private static final Set<Class<?>> approximableMapTypes = new HashSet(6);
/*     */ 
/*     */   public static boolean isApproximableCollectionType(Class<?> collectionType)
/*     */   {
/*  93 */     return (collectionType != null) && (approximableCollectionTypes.contains(collectionType));
/*     */   }
/*     */ 
/*     */   public static <E> Collection<E> createApproximateCollection(Object collection, int initialCapacity)
/*     */   {
/* 109 */     if ((collection instanceof LinkedList)) {
/* 110 */       return new LinkedList();
/*     */     }
/* 112 */     if ((collection instanceof List)) {
/* 113 */       return new ArrayList(initialCapacity);
/*     */     }
/* 115 */     if ((collection instanceof SortedSet)) {
/* 116 */       return new TreeSet(((SortedSet)collection).comparator());
/*     */     }
/*     */ 
/* 119 */     return new LinkedHashSet(initialCapacity);
/*     */   }
/*     */ 
/*     */   public static <E> Collection<E> createCollection(Class<?> collectionType, int initialCapacity)
/*     */   {
/* 136 */     if (collectionType.isInterface()) {
/* 137 */       if (List.class.equals(collectionType)) {
/* 138 */         return new ArrayList(initialCapacity);
/*     */       }
/* 140 */       if ((SortedSet.class.equals(collectionType)) || (collectionType.equals(navigableSetClass))) {
/* 141 */         return new TreeSet();
/*     */       }
/* 143 */       if ((Set.class.equals(collectionType)) || (Collection.class.equals(collectionType))) {
/* 144 */         return new LinkedHashSet(initialCapacity);
/*     */       }
/*     */ 
/* 147 */       throw new IllegalArgumentException("Unsupported Collection interface: " + collectionType.getName());
/*     */     }
/*     */ 
/* 151 */     if (!Collection.class.isAssignableFrom(collectionType))
/* 152 */       throw new IllegalArgumentException("Unsupported Collection type: " + collectionType.getName());
/*     */     try
/*     */     {
/* 155 */       return (Collection)collectionType.newInstance();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 159 */       throw new IllegalArgumentException("Could not instantiate Collection type: " + collectionType
/* 159 */         .getName(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isApproximableMapType(Class<?> mapType)
/*     */   {
/* 172 */     return (mapType != null) && (approximableMapTypes.contains(mapType));
/*     */   }
/*     */ 
/*     */   public static <K, V> Map<K, V> createApproximateMap(Object map, int initialCapacity)
/*     */   {
/* 186 */     if ((map instanceof SortedMap)) {
/* 187 */       return new TreeMap(((SortedMap)map).comparator());
/*     */     }
/*     */ 
/* 190 */     return new LinkedHashMap(initialCapacity);
/*     */   }
/*     */ 
/*     */   public static <K, V> Map<K, V> createMap(Class<?> mapType, int initialCapacity)
/*     */   {
/* 205 */     if (mapType.isInterface()) {
/* 206 */       if (Map.class.equals(mapType)) {
/* 207 */         return new LinkedHashMap(initialCapacity);
/*     */       }
/* 209 */       if ((SortedMap.class.equals(mapType)) || (mapType.equals(navigableMapClass))) {
/* 210 */         return new TreeMap();
/*     */       }
/* 212 */       if (MultiValueMap.class.equals(mapType)) {
/* 213 */         return new LinkedMultiValueMap();
/*     */       }
/*     */ 
/* 216 */       throw new IllegalArgumentException("Unsupported Map interface: " + mapType.getName());
/*     */     }
/*     */ 
/* 220 */     if (!Map.class.isAssignableFrom(mapType))
/* 221 */       throw new IllegalArgumentException("Unsupported Map type: " + mapType.getName());
/*     */     try
/*     */     {
/* 224 */       return (Map)mapType.newInstance();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 228 */       throw new IllegalArgumentException("Could not instantiate Map type: " + mapType
/* 228 */         .getName(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  64 */     approximableCollectionTypes.add(Collection.class);
/*  65 */     approximableCollectionTypes.add(List.class);
/*  66 */     approximableCollectionTypes.add(Set.class);
/*  67 */     approximableCollectionTypes.add(SortedSet.class);
/*  68 */     approximableCollectionTypes.add(NavigableSet.class);
/*  69 */     approximableMapTypes.add(Map.class);
/*  70 */     approximableMapTypes.add(SortedMap.class);
/*  71 */     approximableMapTypes.add(NavigableMap.class);
/*     */ 
/*  74 */     approximableCollectionTypes.add(ArrayList.class);
/*  75 */     approximableCollectionTypes.add(LinkedList.class);
/*  76 */     approximableCollectionTypes.add(HashSet.class);
/*  77 */     approximableCollectionTypes.add(LinkedHashSet.class);
/*  78 */     approximableCollectionTypes.add(TreeSet.class);
/*  79 */     approximableMapTypes.add(HashMap.class);
/*  80 */     approximableMapTypes.add(LinkedHashMap.class);
/*  81 */     approximableMapTypes.add(TreeMap.class);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.CollectionFactory
 * JD-Core Version:    0.6.2
 */