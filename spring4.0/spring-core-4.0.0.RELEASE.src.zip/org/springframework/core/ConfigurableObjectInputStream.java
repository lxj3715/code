/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.lang.reflect.Proxy;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class ConfigurableObjectInputStream extends ObjectInputStream
/*     */ {
/*     */   private final ClassLoader classLoader;
/*     */   private final boolean acceptProxyClasses;
/*     */ 
/*     */   public ConfigurableObjectInputStream(InputStream in, ClassLoader classLoader)
/*     */     throws IOException
/*     */   {
/*  50 */     this(in, classLoader, true);
/*     */   }
/*     */ 
/*     */   public ConfigurableObjectInputStream(InputStream in, ClassLoader classLoader, boolean acceptProxyClasses)
/*     */     throws IOException
/*     */   {
/*  64 */     super(in);
/*  65 */     this.classLoader = classLoader;
/*  66 */     this.acceptProxyClasses = acceptProxyClasses;
/*     */   }
/*     */ 
/*     */   protected Class<?> resolveClass(ObjectStreamClass classDesc) throws IOException, ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/*  73 */       if (this.classLoader != null)
/*     */       {
/*  75 */         return ClassUtils.forName(classDesc.getName(), this.classLoader);
/*     */       }
/*     */ 
/*  79 */       return super.resolveClass(classDesc);
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*  83 */       return resolveFallbackIfPossible(classDesc.getName(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Class<?> resolveProxyClass(String[] interfaces) throws IOException, ClassNotFoundException
/*     */   {
/*  89 */     if (!this.acceptProxyClasses) {
/*  90 */       throw new NotSerializableException("Not allowed to accept serialized proxy classes");
/*     */     }
/*  92 */     if (this.classLoader != null)
/*     */     {
/*  94 */       Class[] resolvedInterfaces = new Class[interfaces.length];
/*  95 */       for (int i = 0; i < interfaces.length; i++)
/*     */         try {
/*  97 */           resolvedInterfaces[i] = ClassUtils.forName(interfaces[i], this.classLoader);
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 100 */           resolvedInterfaces[i] = resolveFallbackIfPossible(interfaces[i], ex);
/*     */         }
/*     */       try
/*     */       {
/* 104 */         return Proxy.getProxyClass(this.classLoader, resolvedInterfaces);
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 107 */         throw new ClassNotFoundException(null, ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 113 */       return super.resolveProxyClass(interfaces);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 116 */       Class[] resolvedInterfaces = new Class[interfaces.length];
/* 117 */       for (int i = 0; i < interfaces.length; i++) {
/* 118 */         resolvedInterfaces[i] = resolveFallbackIfPossible(interfaces[i], ex);
/*     */       }
/* 120 */       return Proxy.getProxyClass(getFallbackClassLoader(), resolvedInterfaces);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Class<?> resolveFallbackIfPossible(String className, ClassNotFoundException ex)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 137 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected ClassLoader getFallbackClassLoader()
/*     */     throws IOException
/*     */   {
/* 146 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ConfigurableObjectInputStream
 * JD-Core Version:    0.6.2
 */