/*    */ package org.springframework.core;
/*    */ 
/*    */ public class ConstantException extends IllegalArgumentException
/*    */ {
/*    */   public ConstantException(String className, String field, String message)
/*    */   {
/* 37 */     super("Field '" + field + "' " + message + " in class [" + className + "]");
/*    */   }
/*    */ 
/*    */   public ConstantException(String className, String namePrefix, Object value)
/*    */   {
/* 47 */     super("No '" + namePrefix + "' field with value '" + value + "' found in class [" + className + "]");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ConstantException
 * JD-Core Version:    0.6.2
 */