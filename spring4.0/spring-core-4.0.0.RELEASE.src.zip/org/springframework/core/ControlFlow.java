package org.springframework.core;

public abstract interface ControlFlow
{
  public abstract boolean under(Class<?> paramClass);

  public abstract boolean under(Class<?> paramClass, String paramString);

  public abstract boolean underToken(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ControlFlow
 * JD-Core Version:    0.6.2
 */