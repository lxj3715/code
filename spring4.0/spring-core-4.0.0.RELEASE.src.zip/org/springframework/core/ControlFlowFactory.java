/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class ControlFlowFactory
/*     */ {
/*     */   public static ControlFlow createControlFlow()
/*     */   {
/*  41 */     return new Jdk14ControlFlow();
/*     */   }
/*     */ 
/*     */   static class Jdk14ControlFlow
/*     */     implements ControlFlow
/*     */   {
/*     */     private StackTraceElement[] stack;
/*     */ 
/*     */     public Jdk14ControlFlow()
/*     */     {
/*  58 */       this.stack = new Throwable().getStackTrace();
/*     */     }
/*     */ 
/*     */     public boolean under(Class<?> clazz)
/*     */     {
/*  66 */       Assert.notNull(clazz, "Class must not be null");
/*  67 */       String className = clazz.getName();
/*  68 */       for (int i = 0; i < this.stack.length; i++) {
/*  69 */         if (this.stack[i].getClassName().equals(className)) {
/*  70 */           return true;
/*     */         }
/*     */       }
/*  73 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean under(Class<?> clazz, String methodName)
/*     */     {
/*  82 */       Assert.notNull(clazz, "Class must not be null");
/*  83 */       Assert.notNull(methodName, "Method name must not be null");
/*  84 */       String className = clazz.getName();
/*  85 */       for (int i = 0; i < this.stack.length; i++) {
/*  86 */         if ((this.stack[i].getClassName().equals(className)) && 
/*  87 */           (this.stack[i]
/*  87 */           .getMethodName().equals(methodName))) {
/*  88 */           return true;
/*     */         }
/*     */       }
/*  91 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean underToken(String token)
/*     */     {
/* 100 */       if (token == null) {
/* 101 */         return false;
/*     */       }
/* 103 */       StringWriter sw = new StringWriter();
/* 104 */       new Throwable().printStackTrace(new PrintWriter(sw));
/* 105 */       String stackTrace = sw.toString();
/* 106 */       return stackTrace.indexOf(token) != -1;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 111 */       StringBuilder sb = new StringBuilder("Jdk14ControlFlow: ");
/* 112 */       for (int i = 0; i < this.stack.length; i++) {
/* 113 */         if (i > 0) {
/* 114 */           sb.append("\n\t@");
/*     */         }
/* 116 */         sb.append(this.stack[i]);
/*     */       }
/* 118 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ControlFlowFactory
 * JD-Core Version:    0.6.2
 */