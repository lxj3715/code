/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class DecoratingClassLoader extends ClassLoader
/*     */ {
/*  35 */   private final Set<String> excludedPackages = new HashSet();
/*     */ 
/*  37 */   private final Set<String> excludedClasses = new HashSet();
/*     */ 
/*  39 */   private final Object exclusionMonitor = new Object();
/*     */ 
/*     */   public DecoratingClassLoader()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DecoratingClassLoader(ClassLoader parent)
/*     */   {
/*  53 */     super(parent);
/*     */   }
/*     */ 
/*     */   public void excludePackage(String packageName)
/*     */   {
/*  64 */     Assert.notNull(packageName, "Package name must not be null");
/*  65 */     synchronized (this.exclusionMonitor) {
/*  66 */       this.excludedPackages.add(packageName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void excludeClass(String className)
/*     */   {
/*  77 */     Assert.notNull(className, "Class name must not be null");
/*  78 */     synchronized (this.exclusionMonitor) {
/*  79 */       this.excludedClasses.add(className);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isExcluded(String className)
/*     */   {
/*  93 */     synchronized (this.exclusionMonitor) {
/*  94 */       if (this.excludedClasses.contains(className)) {
/*  95 */         return true;
/*     */       }
/*  97 */       for (String packageName : this.excludedPackages) {
/*  98 */         if (className.startsWith(packageName)) {
/*  99 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 103 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.DecoratingClassLoader
 * JD-Core Version:    0.6.2
 */