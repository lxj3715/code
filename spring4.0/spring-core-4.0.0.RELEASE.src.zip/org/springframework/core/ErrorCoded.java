package org.springframework.core;

public abstract interface ErrorCoded
{
  public abstract String getErrorCode();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ErrorCoded
 * JD-Core Version:    0.6.2
 */