/*    */ package org.springframework.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ExceptionDepthComparator
/*    */   implements Comparator<Class<? extends Throwable>>
/*    */ {
/*    */   private final Class<? extends Throwable> targetException;
/*    */ 
/*    */   public ExceptionDepthComparator(Throwable exception)
/*    */   {
/* 44 */     Assert.notNull(exception, "Target exception must not be null");
/* 45 */     this.targetException = exception.getClass();
/*    */   }
/*    */ 
/*    */   public ExceptionDepthComparator(Class<? extends Throwable> exceptionType)
/*    */   {
/* 53 */     Assert.notNull(exceptionType, "Target exception type must not be null");
/* 54 */     this.targetException = exceptionType;
/*    */   }
/*    */ 
/*    */   public int compare(Class<? extends Throwable> o1, Class<? extends Throwable> o2)
/*    */   {
/* 60 */     int depth1 = getDepth(o1, this.targetException, 0);
/* 61 */     int depth2 = getDepth(o2, this.targetException, 0);
/* 62 */     return depth1 - depth2;
/*    */   }
/*    */ 
/*    */   private int getDepth(Class<?> declaredException, Class<?> exceptionToMatch, int depth) {
/* 66 */     if (declaredException.equals(exceptionToMatch))
/*    */     {
/* 68 */       return depth;
/*    */     }
/*    */ 
/* 71 */     if (Throwable.class.equals(exceptionToMatch)) {
/* 72 */       return 2147483647;
/*    */     }
/* 74 */     return getDepth(declaredException, exceptionToMatch.getSuperclass(), depth + 1);
/*    */   }
/*    */ 
/*    */   public static Class<? extends Throwable> findClosestMatch(Collection<Class<? extends Throwable>> exceptionTypes, Throwable targetException)
/*    */   {
/* 87 */     Assert.notEmpty(exceptionTypes, "Exception types must not be empty");
/* 88 */     if (exceptionTypes.size() == 1) {
/* 89 */       return (Class)exceptionTypes.iterator().next();
/*    */     }
/* 91 */     List handledExceptions = new ArrayList(exceptionTypes);
/*    */ 
/* 93 */     Collections.sort(handledExceptions, new ExceptionDepthComparator(targetException));
/* 94 */     return (Class)handledExceptions.get(0);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ExceptionDepthComparator
 * JD-Core Version:    0.6.2
 */