/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ public abstract class GenericTypeResolver
/*     */ {
/*  48 */   private static final Map<Class<?>, Map<TypeVariable, Type>> typeVariableCache = new ConcurrentReferenceHashMap();
/*     */ 
/*     */   @Deprecated
/*     */   public static Type getTargetType(MethodParameter methodParam)
/*     */   {
/*  60 */     Assert.notNull(methodParam, "MethodParameter must not be null");
/*  61 */     return methodParam.getGenericParameterType();
/*     */   }
/*     */ 
/*     */   public static Class<?> resolveParameterType(MethodParameter methodParam, Class<?> clazz)
/*     */   {
/*  71 */     Assert.notNull(methodParam, "MethodParameter must not be null");
/*  72 */     Assert.notNull(clazz, "Class must not be null");
/*  73 */     methodParam.setContainingClass(clazz);
/*  74 */     methodParam.setParameterType(ResolvableType.forMethodParameter(methodParam).resolve());
/*  75 */     return methodParam.getParameterType();
/*     */   }
/*     */ 
/*     */   public static Class<?> resolveReturnType(Method method, Class<?> clazz)
/*     */   {
/*  87 */     Assert.notNull(method, "Method must not be null");
/*  88 */     Assert.notNull(clazz, "Class must not be null");
/*  89 */     return ResolvableType.forMethodReturnType(method, clazz).resolve(method.getReturnType());
/*     */   }
/*     */ 
/*     */   public static Class<?> resolveReturnTypeForGenericMethod(Method method, Object[] args, ClassLoader classLoader)
/*     */   {
/* 125 */     Assert.notNull(method, "Method must not be null");
/* 126 */     Assert.notNull(args, "Argument array must not be null");
/*     */ 
/* 128 */     TypeVariable[] declaredTypeVariables = method.getTypeParameters();
/* 129 */     Type genericReturnType = method.getGenericReturnType();
/* 130 */     Type[] methodArgumentTypes = method.getGenericParameterTypes();
/*     */ 
/* 133 */     if (declaredTypeVariables.length == 0) {
/* 134 */       return method.getReturnType();
/*     */     }
/*     */ 
/* 139 */     if (args.length < methodArgumentTypes.length) {
/* 140 */       return null;
/*     */     }
/*     */ 
/* 145 */     boolean locallyDeclaredTypeVariableMatchesReturnType = false;
/* 146 */     for (TypeVariable currentTypeVariable : declaredTypeVariables) {
/* 147 */       if (currentTypeVariable.equals(genericReturnType)) {
/* 148 */         locallyDeclaredTypeVariableMatchesReturnType = true;
/* 149 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 153 */     if (locallyDeclaredTypeVariableMatchesReturnType) {
/* 154 */       for (int i = 0; i < methodArgumentTypes.length; i++) {
/* 155 */         Type currentMethodArgumentType = methodArgumentTypes[i];
/* 156 */         if (currentMethodArgumentType.equals(genericReturnType)) {
/* 157 */           return args[i].getClass();
/*     */         }
/* 159 */         if ((currentMethodArgumentType instanceof ParameterizedType)) {
/* 160 */           ParameterizedType parameterizedType = (ParameterizedType)currentMethodArgumentType;
/* 161 */           Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
/* 162 */           for (Type typeArg : actualTypeArguments) {
/* 163 */             if (typeArg.equals(genericReturnType)) {
/* 164 */               Object arg = args[i];
/* 165 */               if ((arg instanceof Class)) {
/* 166 */                 return (Class)arg;
/*     */               }
/* 168 */               if (((arg instanceof String)) && (classLoader != null)) {
/*     */                 try {
/* 170 */                   return classLoader.loadClass((String)arg);
/*     */                 }
/*     */                 catch (ClassNotFoundException ex) {
/* 173 */                   throw new IllegalStateException("Could not resolve specific class name argument [" + arg + "]", ex);
/*     */                 }
/*     */ 
/*     */               }
/*     */ 
/* 180 */               return method.getReturnType();
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 189 */     return method.getReturnType();
/*     */   }
/*     */ 
/*     */   public static Class<?> resolveReturnTypeArgument(Method method, Class<?> genericIfc)
/*     */   {
/* 202 */     Assert.notNull(method, "method must not be null");
/* 203 */     ResolvableType resolvableType = ResolvableType.forMethodReturnType(method).as(genericIfc);
/* 204 */     if ((!resolvableType.hasGenerics()) || ((resolvableType.getType() instanceof WildcardType))) {
/* 205 */       return null;
/*     */     }
/* 207 */     return getSingleGeneric(resolvableType);
/*     */   }
/*     */ 
/*     */   public static Class<?> resolveTypeArgument(Class<?> clazz, Class<?> genericIfc)
/*     */   {
/* 219 */     ResolvableType resolvableType = ResolvableType.forClass(clazz).as(genericIfc);
/* 220 */     if (!resolvableType.hasGenerics()) {
/* 221 */       return null;
/*     */     }
/* 223 */     return getSingleGeneric(resolvableType);
/*     */   }
/*     */ 
/*     */   private static Class<?> getSingleGeneric(ResolvableType resolvableType) {
/* 227 */     if (resolvableType.getGenerics().length > 1)
/*     */     {
/* 229 */       throw new IllegalArgumentException("Expected 1 type argument on generic interface [" + resolvableType + "] but found " + resolvableType
/* 229 */         .getGenerics().length);
/*     */     }
/* 231 */     return resolvableType.getGeneric(new int[0]).resolve();
/*     */   }
/*     */ 
/*     */   public static Class<?>[] resolveTypeArguments(Class<?> clazz, Class<?> genericIfc)
/*     */   {
/* 245 */     ResolvableType type = ResolvableType.forClass(clazz).as(genericIfc);
/* 246 */     if ((!type.hasGenerics()) || (type.hasUnresolvableGenerics())) {
/* 247 */       return null;
/*     */     }
/* 249 */     return type.resolveGenerics();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static Class<?> resolveType(Type genericType, Map<TypeVariable, Type> map)
/*     */   {
/* 262 */     return ResolvableType.forType(genericType, new TypeVariableMapVariableResolver(map)).resolve(Object.class);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static Map<TypeVariable, Type> getTypeVariableMap(Class<?> clazz)
/*     */   {
/* 274 */     Map typeVariableMap = (Map)typeVariableCache.get(clazz);
/* 275 */     if (typeVariableMap == null) {
/* 276 */       typeVariableMap = new HashMap();
/* 277 */       buildTypeVariableMap(ResolvableType.forClass(clazz), typeVariableMap);
/* 278 */       typeVariableCache.put(clazz, Collections.unmodifiableMap(typeVariableMap));
/*     */     }
/* 280 */     return typeVariableMap;
/*     */   }
/*     */ 
/*     */   private static void buildTypeVariableMap(ResolvableType type, Map<TypeVariable, Type> typeVariableMap)
/*     */   {
/* 285 */     if (type != ResolvableType.NONE) {
/* 286 */       if ((type.getType() instanceof ParameterizedType)) {
/* 287 */         variables = type.resolve().getTypeParameters();
/* 288 */         for (i = 0; i < variables.length; i++) {
/* 289 */           generic = type.getGeneric(new int[] { i });
/* 290 */           while ((generic.getType() instanceof TypeVariable)) {
/* 291 */             generic = generic.resolveType();
/*     */           }
/* 293 */           if (generic != ResolvableType.NONE) {
/* 294 */             typeVariableMap.put(variables[i], generic.getType());
/*     */           }
/*     */         }
/*     */       }
/* 298 */       buildTypeVariableMap(type.getSuperType(), typeVariableMap);
/* 299 */       TypeVariable[] variables = type.getInterfaces(); int i = variables.length; for (ResolvableType generic = 0; generic < i; generic++) { ResolvableType interfaceType = variables[generic];
/* 300 */         buildTypeVariableMap(interfaceType, typeVariableMap);
/*     */       }
/* 302 */       if (type.resolve().isMemberClass())
/* 303 */         buildTypeVariableMap(ResolvableType.forClass(type.resolve().getEnclosingClass()), typeVariableMap);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TypeVariableMapVariableResolver
/*     */     implements ResolvableType.VariableResolver
/*     */   {
/*     */     private final Map<TypeVariable, Type> typeVariableMap;
/*     */ 
/*     */     public TypeVariableMapVariableResolver(Map<TypeVariable, Type> typeVariableMap)
/*     */     {
/* 315 */       this.typeVariableMap = typeVariableMap;
/*     */     }
/*     */ 
/*     */     public ResolvableType resolveVariable(TypeVariable<?> variable)
/*     */     {
/* 320 */       Type type = (Type)this.typeVariableMap.get(variable);
/* 321 */       return type != null ? ResolvableType.forType(type) : null;
/*     */     }
/*     */ 
/*     */     public Object getSource()
/*     */     {
/* 326 */       return this.typeVariableMap;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.GenericTypeResolver
 * JD-Core Version:    0.6.2
 */