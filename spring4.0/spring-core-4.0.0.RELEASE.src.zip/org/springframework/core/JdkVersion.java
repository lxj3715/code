/*     */ package org.springframework.core;
/*     */ 
/*     */ public abstract class JdkVersion
/*     */ {
/*     */   public static final int JAVA_13 = 0;
/*     */   public static final int JAVA_14 = 1;
/*     */   public static final int JAVA_15 = 2;
/*     */   public static final int JAVA_16 = 3;
/*     */   public static final int JAVA_17 = 4;
/*     */   public static final int JAVA_18 = 5;
/*     */   public static final int JAVA_19 = 6;
/*  74 */   private static final String javaVersion = System.getProperty("java.version");
/*     */   private static final int majorJavaVersion;
/*     */ 
/*     */   public static String getJavaVersion()
/*     */   {
/*  99 */     return javaVersion;
/*     */   }
/*     */ 
/*     */   public static int getMajorJavaVersion()
/*     */   {
/* 112 */     return majorJavaVersion;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  76 */     if (javaVersion.contains("1.9.")) {
/*  77 */       majorJavaVersion = 6;
/*     */     }
/*  79 */     else if (javaVersion.contains("1.8.")) {
/*  80 */       majorJavaVersion = 5;
/*     */     }
/*  82 */     else if (javaVersion.contains("1.7.")) {
/*  83 */       majorJavaVersion = 4;
/*     */     }
/*     */     else
/*     */     {
/*  87 */       majorJavaVersion = 3;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.JdkVersion
 * JD-Core Version:    0.6.2
 */