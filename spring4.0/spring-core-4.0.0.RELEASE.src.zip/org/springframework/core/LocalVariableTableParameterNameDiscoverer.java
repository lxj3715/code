/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.asm.ClassReader;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.Label;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class LocalVariableTableParameterNameDiscoverer
/*     */   implements ParameterNameDiscoverer
/*     */ {
/*  57 */   private static Log logger = LogFactory.getLog(LocalVariableTableParameterNameDiscoverer.class);
/*     */ 
/*  60 */   private static final Map<Member, String[]> NO_DEBUG_INFO_MAP = Collections.emptyMap();
/*     */   private final Map<Class<?>, Map<Member, String[]>> parameterNamesCache;
/*     */ 
/*     */   public LocalVariableTableParameterNameDiscoverer()
/*     */   {
/*  63 */     this.parameterNamesCache = new ConcurrentHashMap(32);
/*     */   }
/*     */ 
/*     */   public String[] getParameterNames(Method method)
/*     */   {
/*  69 */     Method originalMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  70 */     Class declaringClass = originalMethod.getDeclaringClass();
/*  71 */     Map map = (Map)this.parameterNamesCache.get(declaringClass);
/*  72 */     if (map == null) {
/*  73 */       map = inspectClass(declaringClass);
/*  74 */       this.parameterNamesCache.put(declaringClass, map);
/*     */     }
/*  76 */     if (map != NO_DEBUG_INFO_MAP) {
/*  77 */       return (String[])map.get(originalMethod);
/*     */     }
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   public String[] getParameterNames(Constructor<?> ctor)
/*     */   {
/*  84 */     Class declaringClass = ctor.getDeclaringClass();
/*  85 */     Map map = (Map)this.parameterNamesCache.get(declaringClass);
/*  86 */     if (map == null) {
/*  87 */       map = inspectClass(declaringClass);
/*  88 */       this.parameterNamesCache.put(declaringClass, map);
/*     */     }
/*  90 */     if (map != NO_DEBUG_INFO_MAP) {
/*  91 */       return (String[])map.get(ctor);
/*     */     }
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   private Map<Member, String[]> inspectClass(Class<?> clazz)
/*     */   {
/* 101 */     InputStream is = clazz.getResourceAsStream(ClassUtils.getClassFileName(clazz));
/* 102 */     if (is == null)
/*     */     {
/* 105 */       if (logger.isDebugEnabled()) {
/* 106 */         logger.debug("Cannot find '.class' file for class [" + clazz + "] - unable to determine constructors/methods parameter names");
/*     */       }
/*     */ 
/* 109 */       return NO_DEBUG_INFO_MAP;
/*     */     }
/*     */     try {
/* 112 */       ClassReader classReader = new ClassReader(is);
/* 113 */       Map map = new ConcurrentHashMap(32);
/* 114 */       classReader.accept(new ParameterNameDiscoveringVisitor(clazz, map), 0);
/* 115 */       return map;
/*     */     }
/*     */     catch (IOException ex) {
/* 118 */       if (logger.isDebugEnabled()) {
/* 119 */         logger.debug("Exception thrown while reading '.class' file for class [" + clazz + "] - unable to determine constructors/methods parameter names", ex);
/*     */       }
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 124 */       if (logger.isDebugEnabled()) {
/* 125 */         logger.debug("ASM ClassReader failed to parse class file [" + clazz + "], probably due to a new Java class file version that isn't supported yet " + "- unable to determine constructors/methods parameter names", ex);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 132 */         is.close();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/* 138 */     return NO_DEBUG_INFO_MAP;
/*     */   }
/*     */ 
/*     */   private static class LocalVariableTableVisitor extends MethodVisitor
/*     */   {
/*     */     private static final String CONSTRUCTOR = "<init>";
/*     */     private final Class<?> clazz;
/*     */     private final Map<Member, String[]> memberMap;
/*     */     private final String name;
/*     */     private final Type[] args;
/*     */     private final boolean isStatic;
/*     */     private String[] parameterNames;
/* 189 */     private boolean hasLvtInfo = false;
/*     */     private final int[] lvtSlotIndex;
/*     */ 
/*     */     public LocalVariableTableVisitor(Class<?> clazz, Map<Member, String[]> map, String name, String desc, boolean isStatic)
/*     */     {
/* 199 */       super();
/* 200 */       this.clazz = clazz;
/* 201 */       this.memberMap = map;
/* 202 */       this.name = name;
/*     */ 
/* 204 */       this.args = Type.getArgumentTypes(desc);
/* 205 */       this.parameterNames = new String[this.args.length];
/* 206 */       this.isStatic = isStatic;
/* 207 */       this.lvtSlotIndex = computeLvtSlotIndices(isStatic, this.args);
/*     */     }
/*     */ 
/*     */     public void visitLocalVariable(String name, String description, String signature, Label start, Label end, int index)
/*     */     {
/* 213 */       this.hasLvtInfo = true;
/* 214 */       for (int i = 0; i < this.lvtSlotIndex.length; i++)
/* 215 */         if (this.lvtSlotIndex[i] == index)
/* 216 */           this.parameterNames[i] = name;
/*     */     }
/*     */ 
/*     */     public void visitEnd()
/*     */     {
/* 223 */       if ((this.hasLvtInfo) || ((this.isStatic) && (this.parameterNames.length == 0)))
/*     */       {
/* 228 */         this.memberMap.put(resolveMember(), this.parameterNames);
/*     */       }
/*     */     }
/*     */ 
/*     */     private Member resolveMember() {
/* 233 */       ClassLoader loader = this.clazz.getClassLoader();
/* 234 */       Class[] classes = new Class[this.args.length];
/*     */ 
/* 237 */       for (int i = 0; i < this.args.length; i++)
/* 238 */         classes[i] = ClassUtils.resolveClassName(this.args[i].getClassName(), loader);
/*     */       try
/*     */       {
/* 241 */         if ("<init>".equals(this.name)) {
/* 242 */           return this.clazz.getDeclaredConstructor(classes);
/*     */         }
/*     */ 
/* 245 */         return this.clazz.getDeclaredMethod(this.name, classes);
/*     */       } catch (NoSuchMethodException ex) {
/* 247 */         throw new IllegalStateException("Method [" + this.name + "] was discovered in the .class file but cannot be resolved in the class object", ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     private static int[] computeLvtSlotIndices(boolean isStatic, Type[] paramTypes)
/*     */     {
/* 253 */       int[] lvtIndex = new int[paramTypes.length];
/* 254 */       int nextIndex = isStatic ? 0 : 1;
/* 255 */       for (int i = 0; i < paramTypes.length; i++) {
/* 256 */         lvtIndex[i] = nextIndex;
/* 257 */         if (isWideType(paramTypes[i]))
/* 258 */           nextIndex += 2;
/*     */         else {
/* 260 */           nextIndex++;
/*     */         }
/*     */       }
/* 263 */       return lvtIndex;
/*     */     }
/*     */ 
/*     */     private static boolean isWideType(Type aType)
/*     */     {
/* 268 */       return (aType == Type.LONG_TYPE) || (aType == Type.DOUBLE_TYPE);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ParameterNameDiscoveringVisitor extends ClassVisitor
/*     */   {
/*     */     private static final String STATIC_CLASS_INIT = "<clinit>";
/*     */     private final Class<?> clazz;
/*     */     private final Map<Member, String[]> memberMap;
/*     */ 
/*     */     public ParameterNameDiscoveringVisitor(Class<?> clazz, Map<Member, String[]> memberMap)
/*     */     {
/* 154 */       super();
/* 155 */       this.clazz = clazz;
/* 156 */       this.memberMap = memberMap;
/*     */     }
/*     */ 
/*     */     public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*     */     {
/* 162 */       if ((!isSyntheticOrBridged(access)) && (!"<clinit>".equals(name))) {
/* 163 */         return new LocalVariableTableParameterNameDiscoverer.LocalVariableTableVisitor(this.clazz, this.memberMap, name, desc, isStatic(access));
/*     */       }
/* 165 */       return null;
/*     */     }
/*     */ 
/*     */     private static boolean isSyntheticOrBridged(int access) {
/* 169 */       return (access & 0x1000 | access & 0x40) > 0;
/*     */     }
/*     */ 
/*     */     private static boolean isStatic(int access) {
/* 173 */       return (access & 0x8) > 0;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.LocalVariableTableParameterNameDiscoverer
 * JD-Core Version:    0.6.2
 */