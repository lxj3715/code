/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MethodParameter
/*     */ {
/*     */   private final Method method;
/*     */   private final Constructor<?> constructor;
/*     */   private final int parameterIndex;
/*     */   private Class<?> containingClass;
/*     */   private Class<?> parameterType;
/*     */   private Type genericParameterType;
/*     */   private Annotation[] parameterAnnotations;
/*     */   private ParameterNameDiscoverer parameterNameDiscoverer;
/*     */   private String parameterName;
/*  62 */   private int nestingLevel = 1;
/*     */   Map<Integer, Integer> typeIndexesPerLevel;
/*  67 */   private int hash = 0;
/*     */ 
/*     */   public MethodParameter(Method method, int parameterIndex)
/*     */   {
/*  76 */     this(method, parameterIndex, 1);
/*     */   }
/*     */ 
/*     */   public MethodParameter(Method method, int parameterIndex, int nestingLevel)
/*     */   {
/*  90 */     Assert.notNull(method, "Method must not be null");
/*  91 */     this.method = method;
/*  92 */     this.parameterIndex = parameterIndex;
/*  93 */     this.nestingLevel = nestingLevel;
/*  94 */     this.constructor = null;
/*     */   }
/*     */ 
/*     */   public MethodParameter(Constructor<?> constructor, int parameterIndex)
/*     */   {
/* 103 */     this(constructor, parameterIndex, 1);
/*     */   }
/*     */ 
/*     */   public MethodParameter(Constructor<?> constructor, int parameterIndex, int nestingLevel)
/*     */   {
/* 115 */     Assert.notNull(constructor, "Constructor must not be null");
/* 116 */     this.constructor = constructor;
/* 117 */     this.parameterIndex = parameterIndex;
/* 118 */     this.nestingLevel = nestingLevel;
/* 119 */     this.method = null;
/*     */   }
/*     */ 
/*     */   public MethodParameter(MethodParameter original)
/*     */   {
/* 128 */     Assert.notNull(original, "Original must not be null");
/* 129 */     this.method = original.method;
/* 130 */     this.constructor = original.constructor;
/* 131 */     this.parameterIndex = original.parameterIndex;
/* 132 */     this.containingClass = original.containingClass;
/* 133 */     this.parameterType = original.parameterType;
/* 134 */     this.genericParameterType = original.genericParameterType;
/* 135 */     this.parameterAnnotations = original.parameterAnnotations;
/* 136 */     this.parameterNameDiscoverer = original.parameterNameDiscoverer;
/* 137 */     this.parameterName = original.parameterName;
/* 138 */     this.nestingLevel = original.nestingLevel;
/* 139 */     this.typeIndexesPerLevel = original.typeIndexesPerLevel;
/* 140 */     this.hash = original.hash;
/*     */   }
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/* 150 */     return this.method;
/*     */   }
/*     */ 
/*     */   public Constructor<?> getConstructor()
/*     */   {
/* 159 */     return this.constructor;
/*     */   }
/*     */ 
/*     */   public Member getMember()
/*     */   {
/* 170 */     if (this.method != null) {
/* 171 */       return this.method;
/*     */     }
/*     */ 
/* 174 */     return this.constructor;
/*     */   }
/*     */ 
/*     */   public AnnotatedElement getAnnotatedElement()
/*     */   {
/* 186 */     if (this.method != null) {
/* 187 */       return this.method;
/*     */     }
/*     */ 
/* 190 */     return this.constructor;
/*     */   }
/*     */ 
/*     */   public Class<?> getDeclaringClass()
/*     */   {
/* 198 */     return getMember().getDeclaringClass();
/*     */   }
/*     */ 
/*     */   public int getParameterIndex()
/*     */   {
/* 206 */     return this.parameterIndex;
/*     */   }
/*     */ 
/*     */   void setContainingClass(Class<?> containingClass)
/*     */   {
/* 213 */     this.containingClass = containingClass;
/*     */   }
/*     */ 
/*     */   public Class<?> getContainingClass() {
/* 217 */     return this.containingClass != null ? this.containingClass : getDeclaringClass();
/*     */   }
/*     */ 
/*     */   void setParameterType(Class<?> parameterType)
/*     */   {
/* 224 */     this.parameterType = parameterType;
/*     */   }
/*     */ 
/*     */   public Class<?> getParameterType()
/*     */   {
/* 232 */     if (this.parameterType == null) {
/* 233 */       if (this.parameterIndex < 0) {
/* 234 */         this.parameterType = (this.method != null ? this.method.getReturnType() : null);
/*     */       }
/*     */       else {
/* 237 */         this.parameterType = (this.method != null ? this.method
/* 238 */           .getParameterTypes()[this.parameterIndex] : this.constructor
/* 239 */           .getParameterTypes()[this.parameterIndex]);
/*     */       }
/*     */     }
/* 242 */     return this.parameterType;
/*     */   }
/*     */ 
/*     */   public Type getGenericParameterType()
/*     */   {
/* 250 */     if (this.genericParameterType == null) {
/* 251 */       if (this.parameterIndex < 0) {
/* 252 */         this.genericParameterType = (this.method != null ? this.method.getGenericReturnType() : null);
/*     */       }
/*     */       else {
/* 255 */         this.genericParameterType = (this.method != null ? this.method
/* 256 */           .getGenericParameterTypes()[this.parameterIndex] : this.constructor
/* 257 */           .getGenericParameterTypes()[this.parameterIndex]);
/*     */       }
/*     */     }
/* 260 */     return this.genericParameterType;
/*     */   }
/*     */ 
/*     */   public Class<?> getNestedParameterType() {
/* 264 */     if (this.nestingLevel > 1) {
/* 265 */       Type type = getGenericParameterType();
/* 266 */       if ((type instanceof ParameterizedType)) {
/* 267 */         Integer index = getTypeIndexForCurrentLevel();
/* 268 */         Type[] args = ((ParameterizedType)type).getActualTypeArguments();
/* 269 */         Type arg = args[(args.length - 1)];
/* 270 */         if ((arg instanceof Class)) {
/* 271 */           return (Class)arg;
/*     */         }
/* 273 */         if ((arg instanceof ParameterizedType)) {
/* 274 */           arg = ((ParameterizedType)arg).getRawType();
/* 275 */           if ((arg instanceof Class)) {
/* 276 */             return (Class)arg;
/*     */           }
/*     */         }
/*     */       }
/* 280 */       return Object.class;
/*     */     }
/*     */ 
/* 283 */     return getParameterType();
/*     */   }
/*     */ 
/*     */   public Annotation[] getMethodAnnotations()
/*     */   {
/* 291 */     return getAnnotatedElement().getAnnotations();
/*     */   }
/*     */ 
/*     */   public <T extends Annotation> T getMethodAnnotation(Class<T> annotationType)
/*     */   {
/* 300 */     return getAnnotatedElement().getAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */   public Annotation[] getParameterAnnotations()
/*     */   {
/* 307 */     if (this.parameterAnnotations == null)
/*     */     {
/* 309 */       Annotation[][] annotationArray = this.method != null ? this.method
/* 309 */         .getParameterAnnotations() : this.constructor.getParameterAnnotations();
/* 310 */       if ((this.parameterIndex >= 0) && (this.parameterIndex < annotationArray.length)) {
/* 311 */         this.parameterAnnotations = annotationArray[this.parameterIndex];
/*     */       }
/*     */       else {
/* 314 */         this.parameterAnnotations = new Annotation[0];
/*     */       }
/*     */     }
/* 317 */     return this.parameterAnnotations;
/*     */   }
/*     */ 
/*     */   public <T extends Annotation> T getParameterAnnotation(Class<T> annotationType)
/*     */   {
/* 327 */     Annotation[] anns = getParameterAnnotations();
/* 328 */     for (Annotation ann : anns) {
/* 329 */       if (annotationType.isInstance(ann)) {
/* 330 */         return ann;
/*     */       }
/*     */     }
/* 333 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean hasParameterAnnotations()
/*     */   {
/* 340 */     return getParameterAnnotations().length != 0;
/*     */   }
/*     */ 
/*     */   public <T extends Annotation> boolean hasParameterAnnotation(Class<T> annotationType)
/*     */   {
/* 347 */     return getParameterAnnotation(annotationType) != null;
/*     */   }
/*     */ 
/*     */   public void initParameterNameDiscovery(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 357 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */   public String getParameterName()
/*     */   {
/* 368 */     if (this.parameterNameDiscoverer != null)
/*     */     {
/* 371 */       String[] parameterNames = this.method != null ? this.parameterNameDiscoverer
/* 370 */         .getParameterNames(this.method) : 
/* 370 */         this.parameterNameDiscoverer
/* 371 */         .getParameterNames(this.constructor);
/*     */ 
/* 372 */       if (parameterNames != null) {
/* 373 */         this.parameterName = parameterNames[this.parameterIndex];
/*     */       }
/* 375 */       this.parameterNameDiscoverer = null;
/*     */     }
/* 377 */     return this.parameterName;
/*     */   }
/*     */ 
/*     */   public void increaseNestingLevel()
/*     */   {
/* 385 */     this.nestingLevel += 1;
/*     */   }
/*     */ 
/*     */   public void decreaseNestingLevel()
/*     */   {
/* 393 */     getTypeIndexesPerLevel().remove(Integer.valueOf(this.nestingLevel));
/* 394 */     this.nestingLevel -= 1;
/*     */   }
/*     */ 
/*     */   public int getNestingLevel()
/*     */   {
/* 403 */     return this.nestingLevel;
/*     */   }
/*     */ 
/*     */   public void setTypeIndexForCurrentLevel(int typeIndex)
/*     */   {
/* 413 */     getTypeIndexesPerLevel().put(Integer.valueOf(this.nestingLevel), Integer.valueOf(typeIndex));
/*     */   }
/*     */ 
/*     */   public Integer getTypeIndexForCurrentLevel()
/*     */   {
/* 423 */     return getTypeIndexForLevel(this.nestingLevel);
/*     */   }
/*     */ 
/*     */   public Integer getTypeIndexForLevel(int nestingLevel)
/*     */   {
/* 433 */     return (Integer)getTypeIndexesPerLevel().get(Integer.valueOf(nestingLevel));
/*     */   }
/*     */ 
/*     */   private Map<Integer, Integer> getTypeIndexesPerLevel()
/*     */   {
/* 440 */     if (this.typeIndexesPerLevel == null) {
/* 441 */       this.typeIndexesPerLevel = new HashMap(4);
/*     */     }
/* 443 */     return this.typeIndexesPerLevel;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 448 */     if (this == obj) {
/* 449 */       return true;
/*     */     }
/* 451 */     if ((obj != null) && ((obj instanceof MethodParameter))) {
/* 452 */       MethodParameter other = (MethodParameter)obj;
/*     */ 
/* 454 */       if (this.parameterIndex != other.parameterIndex) {
/* 455 */         return false;
/*     */       }
/* 457 */       if (getMember().equals(other.getMember())) {
/* 458 */         return true;
/*     */       }
/*     */ 
/* 461 */       return false;
/*     */     }
/*     */ 
/* 464 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 469 */     int result = this.hash;
/* 470 */     if (result == 0) {
/* 471 */       result = getMember().hashCode();
/* 472 */       result = 31 * result + this.parameterIndex;
/* 473 */       this.hash = result;
/*     */     }
/* 475 */     return result;
/*     */   }
/*     */ 
/*     */   public static MethodParameter forMethodOrConstructor(Object methodOrConstructor, int parameterIndex)
/*     */   {
/* 488 */     if ((methodOrConstructor instanceof Method)) {
/* 489 */       return new MethodParameter((Method)methodOrConstructor, parameterIndex);
/*     */     }
/* 491 */     if ((methodOrConstructor instanceof Constructor)) {
/* 492 */       return new MethodParameter((Constructor)methodOrConstructor, parameterIndex);
/*     */     }
/*     */ 
/* 495 */     throw new IllegalArgumentException("Given object [" + methodOrConstructor + "] is neither a Method nor a Constructor");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.MethodParameter
 * JD-Core Version:    0.6.2
 */