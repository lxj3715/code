/*    */ package org.springframework.core;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class NamedInheritableThreadLocal<T> extends InheritableThreadLocal<T>
/*    */ {
/*    */   private final String name;
/*    */ 
/*    */   public NamedInheritableThreadLocal(String name)
/*    */   {
/* 39 */     Assert.hasText(name, "Name must not be empty");
/* 40 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 45 */     return this.name;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.NamedInheritableThreadLocal
 * JD-Core Version:    0.6.2
 */