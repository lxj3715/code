/*    */ package org.springframework.core;
/*    */ 
/*    */ public abstract class NestedExceptionUtils
/*    */ {
/*    */   public static String buildMessage(String message, Throwable cause)
/*    */   {
/* 42 */     if (cause != null) {
/* 43 */       StringBuilder sb = new StringBuilder();
/* 44 */       if (message != null) {
/* 45 */         sb.append(message).append("; ");
/*    */       }
/* 47 */       sb.append("nested exception is ").append(cause);
/* 48 */       return sb.toString();
/*    */     }
/*    */ 
/* 51 */     return message;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.NestedExceptionUtils
 * JD-Core Version:    0.6.2
 */