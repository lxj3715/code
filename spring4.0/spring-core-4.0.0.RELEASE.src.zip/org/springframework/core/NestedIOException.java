/*    */ package org.springframework.core;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class NestedIOException extends IOException
/*    */ {
/*    */   public NestedIOException(String msg)
/*    */   {
/* 53 */     super(msg);
/*    */   }
/*    */ 
/*    */   public NestedIOException(String msg, Throwable cause)
/*    */   {
/* 63 */     super(msg);
/* 64 */     initCause(cause);
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 74 */     return NestedExceptionUtils.buildMessage(super.getMessage(), getCause());
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 44 */     NestedExceptionUtils.class.getName();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.NestedIOException
 * JD-Core Version:    0.6.2
 */