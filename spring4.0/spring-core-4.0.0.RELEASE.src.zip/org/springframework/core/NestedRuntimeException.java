/*     */ package org.springframework.core;
/*     */ 
/*     */ public abstract class NestedRuntimeException extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 5439915454935047936L;
/*     */ 
/*     */   public NestedRuntimeException(String msg)
/*     */   {
/*  54 */     super(msg);
/*     */   }
/*     */ 
/*     */   public NestedRuntimeException(String msg, Throwable cause)
/*     */   {
/*  64 */     super(msg, cause);
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */   {
/*  74 */     return NestedExceptionUtils.buildMessage(super.getMessage(), getCause());
/*     */   }
/*     */ 
/*     */   public Throwable getRootCause()
/*     */   {
/*  84 */     Throwable rootCause = null;
/*  85 */     Throwable cause = getCause();
/*  86 */     while ((cause != null) && (cause != rootCause)) {
/*  87 */       rootCause = cause;
/*  88 */       cause = cause.getCause();
/*     */     }
/*  90 */     return rootCause;
/*     */   }
/*     */ 
/*     */   public Throwable getMostSpecificCause()
/*     */   {
/* 102 */     Throwable rootCause = getRootCause();
/* 103 */     return rootCause != null ? rootCause : this;
/*     */   }
/*     */ 
/*     */   public boolean contains(Class<?> exType)
/*     */   {
/* 114 */     if (exType == null) {
/* 115 */       return false;
/*     */     }
/* 117 */     if (exType.isInstance(this)) {
/* 118 */       return true;
/*     */     }
/* 120 */     Throwable cause = getCause();
/* 121 */     if (cause == this) {
/* 122 */       return false;
/*     */     }
/* 124 */     if ((cause instanceof NestedRuntimeException)) {
/* 125 */       return ((NestedRuntimeException)cause).contains(exType);
/*     */     }
/*     */ 
/* 128 */     while (cause != null) {
/* 129 */       if (exType.isInstance(cause)) {
/* 130 */         return true;
/*     */       }
/* 132 */       if (cause.getCause() == cause) {
/*     */         break;
/*     */       }
/* 135 */       cause = cause.getCause();
/*     */     }
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  45 */     NestedExceptionUtils.class.getName();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.NestedRuntimeException
 * JD-Core Version:    0.6.2
 */