/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class OrderComparator
/*     */   implements Comparator<Object>
/*     */ {
/*  43 */   public static final OrderComparator INSTANCE = new OrderComparator();
/*     */ 
/*     */   public int compare(Object o1, Object o2)
/*     */   {
/*  48 */     boolean p1 = o1 instanceof PriorityOrdered;
/*  49 */     boolean p2 = o2 instanceof PriorityOrdered;
/*  50 */     if ((p1) && (!p2)) {
/*  51 */       return -1;
/*     */     }
/*  53 */     if ((p2) && (!p1)) {
/*  54 */       return 1;
/*     */     }
/*     */ 
/*  58 */     int i1 = getOrder(o1);
/*  59 */     int i2 = getOrder(o2);
/*  60 */     return i1 > i2 ? 1 : i1 < i2 ? -1 : 0;
/*     */   }
/*     */ 
/*     */   protected int getOrder(Object obj)
/*     */   {
/*  71 */     return (obj instanceof Ordered) ? ((Ordered)obj).getOrder() : 2147483647;
/*     */   }
/*     */ 
/*     */   public static void sort(List<?> list)
/*     */   {
/*  83 */     if (list.size() > 1)
/*  84 */       Collections.sort(list, INSTANCE);
/*     */   }
/*     */ 
/*     */   public static void sort(Object[] array)
/*     */   {
/*  96 */     if (array.length > 1)
/*  97 */       Arrays.sort(array, INSTANCE);
/*     */   }
/*     */ 
/*     */   public static void sortIfNecessary(Object value)
/*     */   {
/* 110 */     if ((value instanceof Object[])) {
/* 111 */       sort((Object[])value);
/*     */     }
/* 113 */     else if ((value instanceof List))
/* 114 */       sort((List)value);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.OrderComparator
 * JD-Core Version:    0.6.2
 */