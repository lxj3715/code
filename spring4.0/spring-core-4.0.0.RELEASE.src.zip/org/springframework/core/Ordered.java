package org.springframework.core;

public abstract interface Ordered
{
  public static final int HIGHEST_PRECEDENCE = -2147483648;
  public static final int LOWEST_PRECEDENCE = 2147483647;

  public abstract int getOrder();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.Ordered
 * JD-Core Version:    0.6.2
 */