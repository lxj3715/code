/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ public class OverridingClassLoader extends DecoratingClassLoader
/*     */ {
/*  39 */   public static final String[] DEFAULT_EXCLUDED_PACKAGES = { "java.", "javax.", "sun.", "oracle." };
/*     */   private static final String CLASS_FILE_SUFFIX = ".class";
/*     */ 
/*     */   public OverridingClassLoader(ClassLoader parent)
/*     */   {
/*  50 */     super(parent);
/*  51 */     for (String packageName : DEFAULT_EXCLUDED_PACKAGES)
/*  52 */       excludePackage(packageName);
/*     */   }
/*     */ 
/*     */   protected Class<?> loadClass(String name, boolean resolve)
/*     */     throws ClassNotFoundException
/*     */   {
/*  59 */     Class result = null;
/*  60 */     if (isEligibleForOverriding(name)) {
/*  61 */       result = loadClassForOverriding(name);
/*     */     }
/*  63 */     if (result != null) {
/*  64 */       if (resolve) {
/*  65 */         resolveClass(result);
/*     */       }
/*  67 */       return result;
/*     */     }
/*     */ 
/*  70 */     return super.loadClass(name, resolve);
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleForOverriding(String className)
/*     */   {
/*  82 */     return !isExcluded(className);
/*     */   }
/*     */ 
/*     */   protected Class<?> loadClassForOverriding(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*  94 */     Class result = findLoadedClass(name);
/*  95 */     if (result == null) {
/*  96 */       byte[] bytes = loadBytesForClass(name);
/*  97 */       if (bytes != null) {
/*  98 */         result = defineClass(name, bytes, 0, bytes.length);
/*     */       }
/*     */     }
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */   protected byte[] loadBytesForClass(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/* 115 */     InputStream is = openStreamForClass(name);
/* 116 */     if (is == null) {
/* 117 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 121 */       byte[] bytes = FileCopyUtils.copyToByteArray(is);
/*     */ 
/* 123 */       return transformIfNecessary(name, bytes);
/*     */     }
/*     */     catch (IOException ex) {
/* 126 */       throw new ClassNotFoundException("Cannot load resource for class [" + name + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected InputStream openStreamForClass(String name)
/*     */   {
/* 138 */     String internalName = name.replace('.', '/') + ".class";
/* 139 */     return getParent().getResourceAsStream(internalName);
/*     */   }
/*     */ 
/*     */   protected byte[] transformIfNecessary(String name, byte[] bytes)
/*     */   {
/* 152 */     return bytes;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.OverridingClassLoader
 * JD-Core Version:    0.6.2
 */