package org.springframework.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public abstract interface ParameterNameDiscoverer
{
  public abstract String[] getParameterNames(Method paramMethod);

  public abstract String[] getParameterNames(Constructor<?> paramConstructor);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ParameterNameDiscoverer
 * JD-Core Version:    0.6.2
 */