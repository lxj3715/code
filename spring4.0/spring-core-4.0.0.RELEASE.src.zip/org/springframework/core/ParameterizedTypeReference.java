/*    */ package org.springframework.core;
/*    */ 
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class ParameterizedTypeReference<T>
/*    */ {
/*    */   private final Type type;
/*    */ 
/*    */   protected ParameterizedTypeReference()
/*    */   {
/* 48 */     Class parameterizedTypeReferenceSubclass = findParameterizedTypeReferenceSubclass(getClass());
/* 49 */     Type type = parameterizedTypeReferenceSubclass.getGenericSuperclass();
/* 50 */     Assert.isInstanceOf(ParameterizedType.class, type);
/* 51 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/* 52 */     Assert.isTrue(parameterizedType.getActualTypeArguments().length == 1);
/* 53 */     this.type = parameterizedType.getActualTypeArguments()[0];
/*    */   }
/*    */ 
/*    */   public Type getType()
/*    */   {
/* 58 */     return this.type;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 64 */     return (this == obj) || (((obj instanceof ParameterizedTypeReference)) && 
/* 64 */       (this.type
/* 64 */       .equals(((ParameterizedTypeReference)obj).type)));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 69 */     return this.type.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 74 */     return "ParameterizedTypeReference<" + this.type + ">";
/*    */   }
/*    */ 
/*    */   private static Class<?> findParameterizedTypeReferenceSubclass(Class<?> child)
/*    */   {
/* 79 */     Class parent = child.getSuperclass();
/* 80 */     if (Object.class.equals(parent)) {
/* 81 */       throw new IllegalStateException("Expected ParameterizedTypeReference superclass");
/*    */     }
/* 83 */     if (ParameterizedTypeReference.class.equals(parent)) {
/* 84 */       return child;
/*    */     }
/*    */ 
/* 87 */     return findParameterizedTypeReferenceSubclass(parent);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ParameterizedTypeReference
 * JD-Core Version:    0.6.2
 */