/*      */ package org.springframework.core;
/*      */ 
/*      */ import java.io.ObjectStreamException;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.GenericArrayType;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.lang.reflect.WildcardType;
/*      */ import java.util.Collection;
/*      */ import java.util.Map;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ConcurrentReferenceHashMap;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public final class ResolvableType
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   81 */   private static ConcurrentReferenceHashMap<ResolvableType, ResolvableType> cache = new ConcurrentReferenceHashMap();
/*      */ 
/*   89 */   public static final ResolvableType NONE = new ResolvableType(null, null, null, null);
/*      */ 
/*   92 */   private static final ResolvableType[] EMPTY_TYPES_ARRAY = new ResolvableType[0];
/*      */   private final Type type;
/*      */   private SerializableTypeWrapper.TypeProvider typeProvider;
/*      */   private final VariableResolver variableResolver;
/*  113 */   private boolean isResolved = false;
/*      */   private Class<?> resolved;
/*      */   private final ResolvableType componentType;
/*      */ 
/*      */   private ResolvableType(Type type, SerializableTypeWrapper.TypeProvider typeProvider, VariableResolver variableResolver, ResolvableType componentType)
/*      */   {
/*  134 */     this.type = type;
/*  135 */     this.typeProvider = typeProvider;
/*  136 */     this.variableResolver = variableResolver;
/*  137 */     this.componentType = componentType;
/*      */   }
/*      */ 
/*      */   public Type getType()
/*      */   {
/*  146 */     return this.type;
/*      */   }
/*      */ 
/*      */   public Class<?> getRawClass()
/*      */   {
/*  154 */     Type rawType = this.type;
/*  155 */     if ((rawType instanceof ParameterizedType)) {
/*  156 */       rawType = ((ParameterizedType)rawType).getRawType();
/*      */     }
/*  158 */     return (rawType instanceof Class) ? (Class)rawType : null;
/*      */   }
/*      */ 
/*      */   public Object getSource()
/*      */   {
/*  169 */     Object source = this.typeProvider == null ? null : this.typeProvider.getSource();
/*  170 */     return source == null ? this.type : source;
/*      */   }
/*      */ 
/*      */   public boolean isAssignableFrom(ResolvableType type)
/*      */   {
/*  183 */     return isAssignableFrom(type, false);
/*      */   }
/*      */ 
/*      */   private boolean isAssignableFrom(ResolvableType type, boolean checkingGeneric) {
/*  187 */     Assert.notNull(type, "Type must not be null");
/*      */ 
/*  190 */     if ((this == NONE) || (type == NONE)) {
/*  191 */       return false;
/*      */     }
/*      */ 
/*  195 */     if (isArray()) {
/*  196 */       return (type.isArray()) && (getComponentType().isAssignableFrom(type.getComponentType()));
/*      */     }
/*      */ 
/*  200 */     WildcardBounds ourBounds = WildcardBounds.get(this);
/*  201 */     WildcardBounds typeBounds = WildcardBounds.get(type);
/*      */ 
/*  204 */     if (typeBounds != null)
/*      */     {
/*  206 */       return (ourBounds != null) && (ourBounds.isSameKind(typeBounds)) && 
/*  206 */         (ourBounds
/*  206 */         .isAssignableFrom(typeBounds
/*  206 */         .getBounds()));
/*      */     }
/*      */ 
/*  210 */     if (ourBounds != null) {
/*  211 */       return ourBounds.isAssignableFrom(new ResolvableType[] { type });
/*      */     }
/*      */ 
/*  215 */     boolean rtn = resolve(Object.class).isAssignableFrom(type.resolve(Object.class));
/*      */ 
/*  219 */     rtn &= ((!checkingGeneric) || (resolve(Object.class).equals(type.resolve(Object.class))));
/*      */ 
/*  222 */     for (int i = 0; i < getGenerics().length; i++) {
/*  223 */       rtn &= getGeneric(new int[] { i }).isAssignableFrom(type.as(resolve(Object.class)).getGeneric(new int[] { i }), true);
/*      */     }
/*      */ 
/*  226 */     return rtn;
/*      */   }
/*      */ 
/*      */   public boolean isArray()
/*      */   {
/*  235 */     if (this == NONE) {
/*  236 */       return false;
/*      */     }
/*      */ 
/*  241 */     return (((this.type instanceof Class)) && 
/*  239 */       (((Class)this.type)
/*  239 */       .isArray())) || ((this.type instanceof GenericArrayType)) || 
/*  241 */       (resolveType().isArray());
/*      */   }
/*      */ 
/*      */   public ResolvableType getComponentType()
/*      */   {
/*  250 */     if (this == NONE) {
/*  251 */       return NONE;
/*      */     }
/*  253 */     if (this.componentType != null) {
/*  254 */       return this.componentType;
/*      */     }
/*  256 */     if ((this.type instanceof Class)) {
/*  257 */       Class componentType = ((Class)this.type).getComponentType();
/*  258 */       return forType(componentType, this.variableResolver);
/*      */     }
/*  260 */     if ((this.type instanceof GenericArrayType)) {
/*  261 */       return forType(((GenericArrayType)this.type).getGenericComponentType(), this.variableResolver);
/*      */     }
/*  263 */     return resolveType().getComponentType();
/*      */   }
/*      */ 
/*      */   public ResolvableType asCollection()
/*      */   {
/*  274 */     return as(Collection.class);
/*      */   }
/*      */ 
/*      */   public ResolvableType asMap()
/*      */   {
/*  285 */     return as(Map.class);
/*      */   }
/*      */ 
/*      */   public ResolvableType as(Class<?> type)
/*      */   {
/*  302 */     if (this == NONE) {
/*  303 */       return NONE;
/*      */     }
/*  305 */     if (ObjectUtils.nullSafeEquals(resolve(), type)) {
/*  306 */       return this;
/*      */     }
/*  308 */     for (ResolvableType interfaceType : getInterfaces()) {
/*  309 */       ResolvableType interfaceAsType = interfaceType.as(type);
/*  310 */       if (interfaceAsType != NONE) {
/*  311 */         return interfaceAsType;
/*      */       }
/*      */     }
/*  314 */     return getSuperType().as(type);
/*      */   }
/*      */ 
/*      */   public ResolvableType getSuperType()
/*      */   {
/*  323 */     Class resolved = resolve();
/*  324 */     if ((resolved == null) || (resolved.getGenericSuperclass() == null)) {
/*  325 */       return NONE;
/*      */     }
/*  327 */     return forType(SerializableTypeWrapper.forGenericSuperclass(resolved), asVariableResolver());
/*      */   }
/*      */ 
/*      */   public ResolvableType[] getInterfaces()
/*      */   {
/*  337 */     Class resolved = resolve();
/*  338 */     if ((resolved == null) || (ObjectUtils.isEmpty(resolved.getGenericInterfaces()))) {
/*  339 */       return EMPTY_TYPES_ARRAY;
/*      */     }
/*  341 */     return forTypes(SerializableTypeWrapper.forGenericInterfaces(resolved), asVariableResolver());
/*      */   }
/*      */ 
/*      */   public boolean hasGenerics()
/*      */   {
/*  350 */     return getGenerics().length > 0;
/*      */   }
/*      */ 
/*      */   public boolean hasUnresolvableGenerics()
/*      */   {
/*  361 */     Class[] arrayOfClass = resolveGenerics(); int i = arrayOfClass.length;
/*      */     Class generic;
/*  361 */     for (Class localClass1 = 0; localClass1 < i; localClass1++) { generic = arrayOfClass[localClass1];
/*  362 */       if (generic == null) {
/*  363 */         return true;
/*      */       }
/*      */     }
/*  366 */     Class resolved = resolve();
/*  367 */     if (resolved != null) {
/*  368 */       Type[] arrayOfType = resolved.getGenericInterfaces(); localClass1 = arrayOfType.length; for (generic = 0; generic < localClass1; generic++) { Type genericInterface = arrayOfType[generic];
/*  369 */         if (((genericInterface instanceof Class)) && 
/*  370 */           (forClass((Class)genericInterface).hasGenerics())) {
/*  371 */           return true;
/*      */         }
/*      */       }
/*      */ 
/*  375 */       if (resolved.getGenericSuperclass() != null) {
/*  376 */         return getSuperType().hasUnresolvableGenerics();
/*      */       }
/*      */     }
/*  379 */     return false;
/*      */   }
/*      */ 
/*      */   public ResolvableType getNested(int nestingLevel)
/*      */   {
/*  389 */     return getNested(nestingLevel, null);
/*      */   }
/*      */ 
/*      */   public ResolvableType getNested(int nestingLevel, Map<Integer, Integer> typeIndexesPerLevel)
/*      */   {
/*  413 */     ResolvableType result = this;
/*  414 */     for (int i = 2; i <= nestingLevel; i++) {
/*  415 */       if (result.isArray()) {
/*  416 */         result = result.getComponentType();
/*      */       }
/*      */       else
/*      */       {
/*  420 */         while ((result != NONE) && (!result.hasGenerics())) {
/*  421 */           result = result.getSuperType();
/*      */         }
/*  423 */         Integer index = typeIndexesPerLevel != null ? (Integer)typeIndexesPerLevel.get(Integer.valueOf(i)) : null;
/*  424 */         index = Integer.valueOf(index == null ? result.getGenerics().length - 1 : index.intValue());
/*  425 */         result = result.getGeneric(new int[] { index.intValue() });
/*      */       }
/*      */     }
/*  428 */     return result;
/*      */   }
/*      */ 
/*      */   public ResolvableType getGeneric(int[] indexes)
/*      */   {
/*      */     try
/*      */     {
/*  450 */       if ((indexes == null) || (indexes.length == 0)) {
/*  451 */         return getGenerics()[0];
/*      */       }
/*  453 */       ResolvableType rtn = this;
/*  454 */       for (int index : indexes) {
/*  455 */         rtn = rtn.getGenerics()[index];
/*      */       }
/*  457 */       return rtn;
/*      */     } catch (IndexOutOfBoundsException ex) {
/*      */     }
/*  460 */     return NONE;
/*      */   }
/*      */ 
/*      */   public ResolvableType[] getGenerics()
/*      */   {
/*  478 */     if (this == NONE) {
/*  479 */       return EMPTY_TYPES_ARRAY;
/*      */     }
/*  481 */     if ((this.type instanceof Class)) {
/*  482 */       Class typeClass = (Class)this.type;
/*  483 */       return forTypes(SerializableTypeWrapper.forTypeParameters(typeClass), this.variableResolver);
/*      */     }
/*  485 */     if ((this.type instanceof ParameterizedType)) {
/*  486 */       Type[] actualTypeArguments = ((ParameterizedType)this.type).getActualTypeArguments();
/*  487 */       ResolvableType[] generics = new ResolvableType[actualTypeArguments.length];
/*  488 */       for (int i = 0; i < actualTypeArguments.length; i++) {
/*  489 */         generics[i] = forType(actualTypeArguments[i], this.variableResolver);
/*      */       }
/*  491 */       return generics;
/*      */     }
/*  493 */     return resolveType().getGenerics();
/*      */   }
/*      */ 
/*      */   public Class<?>[] resolveGenerics()
/*      */   {
/*  505 */     return resolveGenerics(null);
/*      */   }
/*      */ 
/*      */   public Class<?>[] resolveGenerics(Class<?> fallback)
/*      */   {
/*  519 */     ResolvableType[] generics = getGenerics();
/*  520 */     Class[] resolvedGenerics = new Class[generics.length];
/*  521 */     for (int i = 0; i < generics.length; i++) {
/*  522 */       resolvedGenerics[i] = generics[i].resolve(fallback);
/*      */     }
/*  524 */     return resolvedGenerics;
/*      */   }
/*      */ 
/*      */   public Class<?> resolveGeneric(int[] indexes)
/*      */   {
/*  537 */     return getGeneric(indexes).resolve();
/*      */   }
/*      */ 
/*      */   public Class<?> resolve()
/*      */   {
/*  551 */     return resolve(null);
/*      */   }
/*      */ 
/*      */   public Class<?> resolve(Class<?> fallback)
/*      */   {
/*  566 */     if (!this.isResolved) {
/*  567 */       this.resolved = resolveClass();
/*  568 */       this.isResolved = true;
/*      */     }
/*  570 */     return this.resolved != null ? this.resolved : fallback;
/*      */   }
/*      */ 
/*      */   private Class<?> resolveClass() {
/*  574 */     if (((this.type instanceof Class)) || (this.type == null)) {
/*  575 */       return (Class)this.type;
/*      */     }
/*  577 */     if ((this.type instanceof GenericArrayType)) {
/*  578 */       Class resolvedComponent = getComponentType().resolve();
/*  579 */       return resolvedComponent != null ? Array.newInstance(resolvedComponent, 0).getClass() : null;
/*      */     }
/*  581 */     return resolveType().resolve();
/*      */   }
/*      */ 
/*      */   ResolvableType resolveType()
/*      */   {
/*  590 */     if ((this.type instanceof ParameterizedType)) {
/*  591 */       return forType(((ParameterizedType)this.type).getRawType(), this.variableResolver);
/*      */     }
/*      */ 
/*  594 */     if ((this.type instanceof WildcardType)) {
/*  595 */       Type resolved = resolveBounds(((WildcardType)this.type).getUpperBounds());
/*  596 */       if (resolved == null) {
/*  597 */         resolved = resolveBounds(((WildcardType)this.type).getLowerBounds());
/*      */       }
/*  599 */       return forType(resolved, this.variableResolver);
/*      */     }
/*      */ 
/*  602 */     if ((this.type instanceof TypeVariable)) {
/*  603 */       TypeVariable variable = (TypeVariable)this.type;
/*      */ 
/*  606 */       if (this.variableResolver != null) {
/*  607 */         ResolvableType resolved = this.variableResolver.resolveVariable(variable);
/*  608 */         if (resolved != null) {
/*  609 */           return resolved;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  614 */       return forType(resolveBounds(variable.getBounds()), this.variableResolver);
/*      */     }
/*      */ 
/*  617 */     return NONE;
/*      */   }
/*      */ 
/*      */   private Type resolveBounds(Type[] bounds) {
/*  621 */     if ((ObjectUtils.isEmpty(bounds)) || (Object.class.equals(bounds[0]))) {
/*  622 */       return null;
/*      */     }
/*  624 */     return bounds[0];
/*      */   }
/*      */ 
/*      */   private ResolvableType resolveVariable(TypeVariable<?> variable) {
/*  628 */     if ((this.type instanceof TypeVariable)) {
/*  629 */       return resolveType().resolveVariable(variable);
/*      */     }
/*      */ 
/*  632 */     if ((this.type instanceof ParameterizedType)) {
/*  633 */       ParameterizedType parameterizedType = (ParameterizedType)this.type;
/*  634 */       TypeVariable[] variables = resolve().getTypeParameters();
/*  635 */       for (int i = 0; i < variables.length; i++) {
/*  636 */         if (ObjectUtils.nullSafeEquals(variables[i].getName(), variable.getName())) {
/*  637 */           Type actualType = parameterizedType.getActualTypeArguments()[i];
/*  638 */           return forType(actualType, this.variableResolver);
/*      */         }
/*      */       }
/*      */ 
/*  642 */       if (parameterizedType.getOwnerType() != null) {
/*  643 */         return forType(parameterizedType.getOwnerType(), this.variableResolver).resolveVariable(variable);
/*      */       }
/*      */     }
/*      */ 
/*  647 */     if (this.variableResolver != null) {
/*  648 */       return this.variableResolver.resolveVariable(variable);
/*      */     }
/*      */ 
/*  651 */     return null;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  661 */     if (isArray()) {
/*  662 */       return new StringBuilder().append(getComponentType()).append("[]").toString();
/*      */     }
/*  664 */     StringBuilder result = new StringBuilder();
/*  665 */     result.append(resolve() == null ? "?" : resolve().getName());
/*  666 */     if (hasGenerics()) {
/*  667 */       result.append('<');
/*  668 */       result.append(StringUtils.arrayToDelimitedString(getGenerics(), ", "));
/*  669 */       result.append('>');
/*      */     }
/*  671 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public boolean equals(Object obj)
/*      */   {
/*  676 */     if (obj == this) {
/*  677 */       return true;
/*      */     }
/*  679 */     if ((obj instanceof ResolvableType)) {
/*  680 */       ResolvableType other = (ResolvableType)obj;
/*  681 */       boolean equals = ObjectUtils.nullSafeEquals(this.type, other.type);
/*  682 */       equals &= ObjectUtils.nullSafeEquals(getSource(), other.getSource());
/*  683 */       equals &= variableResolverSourceEquals(this.variableResolver, other.variableResolver);
/*  684 */       equals &= ObjectUtils.nullSafeEquals(this.componentType, other.componentType);
/*  685 */       return equals;
/*      */     }
/*  687 */     return false;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/*  692 */     int hashCode = ObjectUtils.nullSafeHashCode(this.type);
/*  693 */     hashCode = hashCode * 31 + ObjectUtils.nullSafeHashCode(this.variableResolver == null ? null : this.variableResolver
/*  694 */       .getSource());
/*  695 */     hashCode = hashCode * 31 + ObjectUtils.nullSafeHashCode(this.componentType);
/*  696 */     return hashCode;
/*      */   }
/*      */ 
/*      */   private Object readResolve()
/*      */     throws ObjectStreamException
/*      */   {
/*  703 */     return this.type == null ? NONE : this;
/*      */   }
/*      */ 
/*      */   VariableResolver asVariableResolver()
/*      */   {
/*  710 */     if (this == NONE) {
/*  711 */       return null;
/*      */     }
/*  713 */     return new DefaultVariableResolver(null);
/*      */   }
/*      */ 
/*      */   private static boolean variableResolverSourceEquals(VariableResolver o1, VariableResolver o2) {
/*  717 */     Object s1 = o1 == null ? null : o1.getSource();
/*  718 */     Object s2 = o2 == null ? null : o2.getSource();
/*  719 */     return ObjectUtils.nullSafeEquals(s1, s2);
/*      */   }
/*      */ 
/*      */   private static ResolvableType[] forTypes(Type[] types, VariableResolver owner) {
/*  723 */     ResolvableType[] result = new ResolvableType[types.length];
/*  724 */     for (int i = 0; i < types.length; i++) {
/*  725 */       result[i] = forType(types[i], owner);
/*      */     }
/*  727 */     return result;
/*      */   }
/*      */ 
/*      */   public static ResolvableType forClass(Class<?> sourceClass)
/*      */   {
/*  739 */     Assert.notNull(sourceClass, "Source class must not be null");
/*  740 */     return forType(sourceClass);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forClass(Class<?> sourceClass, Class<?> implementationClass)
/*      */   {
/*  755 */     Assert.notNull(sourceClass, "Source class must not be null");
/*  756 */     ResolvableType asType = forType(implementationClass).as(sourceClass);
/*  757 */     return asType == NONE ? forType(sourceClass) : asType;
/*      */   }
/*      */ 
/*      */   public static ResolvableType forField(Field field)
/*      */   {
/*  767 */     Assert.notNull(field, "Field must not be null");
/*  768 */     return forType(null, new SerializableTypeWrapper.FieldTypeProvider(field), null);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forField(Field field, Class<?> implementationClass)
/*      */   {
/*  782 */     Assert.notNull(field, "Field must not be null");
/*  783 */     ResolvableType owner = forType(implementationClass).as(field.getDeclaringClass());
/*  784 */     return forType(null, new SerializableTypeWrapper.FieldTypeProvider(field), owner.asVariableResolver());
/*      */   }
/*      */ 
/*      */   public static ResolvableType forField(Field field, int nestingLevel)
/*      */   {
/*  796 */     Assert.notNull(field, "Field must not be null");
/*  797 */     return forType(null, new SerializableTypeWrapper.FieldTypeProvider(field), null).getNested(nestingLevel);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forField(Field field, int nestingLevel, Class<?> implementationClass)
/*      */   {
/*  813 */     Assert.notNull(field, "Field must not be null");
/*  814 */     ResolvableType owner = forType(implementationClass).as(field.getDeclaringClass());
/*  815 */     return forType(null, new SerializableTypeWrapper.FieldTypeProvider(field), owner.asVariableResolver()).getNested(nestingLevel);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forConstructorParameter(Constructor<?> constructor, int parameterIndex)
/*      */   {
/*  826 */     Assert.notNull(constructor, "Constructor must not be null");
/*  827 */     return forMethodParameter(new MethodParameter(constructor, parameterIndex));
/*      */   }
/*      */ 
/*      */   public static ResolvableType forConstructorParameter(Constructor<?> constructor, int parameterIndex, Class<?> implementationClass)
/*      */   {
/*  843 */     Assert.notNull(constructor, "Constructor must not be null");
/*  844 */     MethodParameter methodParameter = new MethodParameter(constructor, parameterIndex);
/*  845 */     methodParameter.setContainingClass(implementationClass);
/*  846 */     return forMethodParameter(methodParameter);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forMethodReturnType(Method method)
/*      */   {
/*  856 */     Assert.notNull(method, "Method must not be null");
/*  857 */     return forMethodParameter(MethodParameter.forMethodOrConstructor(method, -1));
/*      */   }
/*      */ 
/*      */   public static ResolvableType forMethodReturnType(Method method, Class<?> implementationClass)
/*      */   {
/*  870 */     Assert.notNull(method, "Method must not be null");
/*  871 */     MethodParameter methodParameter = MethodParameter.forMethodOrConstructor(method, -1);
/*  872 */     methodParameter.setContainingClass(implementationClass);
/*  873 */     return forMethodParameter(methodParameter);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forMethodParameter(Method method, int parameterIndex)
/*      */   {
/*  885 */     Assert.notNull(method, "Method must not be null");
/*  886 */     return forMethodParameter(new MethodParameter(method, parameterIndex));
/*      */   }
/*      */ 
/*      */   public static ResolvableType forMethodParameter(Method method, int parameterIndex, Class<?> implementationClass)
/*      */   {
/*  901 */     Assert.notNull(method, "Method must not be null");
/*  902 */     MethodParameter methodParameter = new MethodParameter(method, parameterIndex);
/*  903 */     methodParameter.setContainingClass(implementationClass);
/*  904 */     return forMethodParameter(methodParameter);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forMethodParameter(MethodParameter methodParameter)
/*      */   {
/*  914 */     Assert.notNull(methodParameter, "MethodParameter must not be null");
/*  915 */     ResolvableType owner = forType(methodParameter.getContainingClass()).as(methodParameter.getDeclaringClass());
/*      */ 
/*  917 */     return forType(null, new SerializableTypeWrapper.MethodParameterTypeProvider(methodParameter), owner
/*  917 */       .asVariableResolver()).getNested(methodParameter
/*  917 */       .getNestingLevel(), methodParameter.typeIndexesPerLevel);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forArrayComponent(ResolvableType componentType)
/*      */   {
/*  927 */     Assert.notNull(componentType, "ComponentType must not be null");
/*  928 */     Class arrayClass = Array.newInstance(componentType.resolve(), 0).getClass();
/*  929 */     return new ResolvableType(arrayClass, null, null, componentType);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forClassWithGenerics(Class<?> sourceClass, Class<?>[] generics)
/*      */   {
/*  940 */     Assert.notNull(sourceClass, "Source class must not be null");
/*  941 */     Assert.notNull(generics, "Generics must not be null");
/*  942 */     ResolvableType[] resolvableGenerics = new ResolvableType[generics.length];
/*  943 */     for (int i = 0; i < generics.length; i++) {
/*  944 */       resolvableGenerics[i] = forClass(generics[i]);
/*      */     }
/*  946 */     return forClassWithGenerics(sourceClass, resolvableGenerics);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forClassWithGenerics(Class<?> sourceClass, ResolvableType[] generics)
/*      */   {
/*  957 */     Assert.notNull(sourceClass, "Source class must not be null");
/*  958 */     Assert.notNull(generics, "Generics must not be null");
/*  959 */     TypeVariable[] typeVariables = sourceClass.getTypeParameters();
/*  960 */     return forType(sourceClass, new TypeVariablesVariableResolver(typeVariables, generics));
/*      */   }
/*      */ 
/*      */   public static ResolvableType forType(Type type)
/*      */   {
/*  971 */     return forType(type, (VariableResolver)null);
/*      */   }
/*      */ 
/*      */   public static ResolvableType forType(Type type, ResolvableType owner)
/*      */   {
/*  983 */     VariableResolver variableResolver = null;
/*  984 */     if (owner != null) {
/*  985 */       variableResolver = owner.asVariableResolver();
/*      */     }
/*  987 */     return forType(type, variableResolver);
/*      */   }
/*      */ 
/*      */   static ResolvableType forType(Type type, VariableResolver variableResolver)
/*      */   {
/*  998 */     return forType(type, null, variableResolver);
/*      */   }
/*      */ 
/*      */   static ResolvableType forType(Type type, SerializableTypeWrapper.TypeProvider typeProvider, VariableResolver variableResolver)
/*      */   {
/* 1010 */     if ((type == null) && (typeProvider != null)) {
/* 1011 */       type = SerializableTypeWrapper.forTypeProvider(typeProvider);
/*      */     }
/* 1013 */     if (type == null) {
/* 1014 */       return NONE;
/*      */     }
/*      */ 
/* 1017 */     ResolvableType key = new ResolvableType(type, typeProvider, variableResolver, null);
/* 1018 */     ResolvableType resolvableType = (ResolvableType)cache.get(key);
/* 1019 */     if (resolvableType == null) {
/* 1020 */       resolvableType = key;
/* 1021 */       cache.put(key, resolvableType);
/*      */     }
/* 1023 */     return resolvableType;
/*      */   }
/*      */ 
/*      */   private static class WildcardBounds
/*      */   {
/*      */     private final Kind kind;
/*      */     private final ResolvableType[] bounds;
/*      */ 
/*      */     public WildcardBounds(Kind kind, ResolvableType[] bounds)
/*      */     {
/* 1107 */       this.kind = kind;
/* 1108 */       this.bounds = bounds;
/*      */     }
/*      */ 
/*      */     public boolean isSameKind(WildcardBounds bounds)
/*      */     {
/* 1115 */       return this.kind == bounds.kind;
/*      */     }
/*      */ 
/*      */     public boolean isAssignableFrom(ResolvableType[] types)
/*      */     {
/* 1124 */       for (ResolvableType bound : this.bounds) {
/* 1125 */         for (ResolvableType type : types) {
/* 1126 */           if (!isAssignable(bound, type)) {
/* 1127 */             return false;
/*      */           }
/*      */         }
/*      */       }
/* 1131 */       return true;
/*      */     }
/*      */ 
/*      */     private boolean isAssignable(ResolvableType source, ResolvableType from) {
/* 1135 */       return this.kind == Kind.UPPER ? source.isAssignableFrom(from) : from.isAssignableFrom(source);
/*      */     }
/*      */ 
/*      */     public ResolvableType[] getBounds()
/*      */     {
/* 1142 */       return this.bounds;
/*      */     }
/*      */ 
/*      */     public static WildcardBounds get(ResolvableType type)
/*      */     {
/* 1152 */       ResolvableType resolveToWildcard = type;
/* 1153 */       while (!(resolveToWildcard.getType() instanceof WildcardType)) {
/* 1154 */         if (resolveToWildcard == ResolvableType.NONE) {
/* 1155 */           return null;
/*      */         }
/* 1157 */         resolveToWildcard = resolveToWildcard.resolveType();
/*      */       }
/* 1159 */       WildcardType wildcardType = (WildcardType)resolveToWildcard.type;
/* 1160 */       Kind boundsType = wildcardType.getLowerBounds().length > 0 ? Kind.LOWER : Kind.UPPER;
/* 1161 */       Type[] bounds = boundsType == Kind.UPPER ? wildcardType.getUpperBounds() : wildcardType.getLowerBounds();
/* 1162 */       ResolvableType[] resolvableBounds = new ResolvableType[bounds.length];
/* 1163 */       for (int i = 0; i < bounds.length; i++) {
/* 1164 */         resolvableBounds[i] = ResolvableType.forType(bounds[i], type.variableResolver);
/*      */       }
/* 1166 */       return new WildcardBounds(boundsType, resolvableBounds);
/*      */     }
/*      */ 
/*      */     static enum Kind
/*      */     {
/* 1172 */       UPPER, LOWER;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class TypeVariablesVariableResolver
/*      */     implements ResolvableType.VariableResolver
/*      */   {
/*      */     private final TypeVariable<?>[] typeVariables;
/*      */     private final ResolvableType[] generics;
/*      */ 
/*      */     public TypeVariablesVariableResolver(TypeVariable<?>[] typeVariables, ResolvableType[] generics)
/*      */     {
/* 1069 */       Assert.isTrue(typeVariables.length == generics.length, "Mismatched number of generics specified");
/* 1070 */       this.typeVariables = typeVariables;
/* 1071 */       this.generics = generics;
/*      */     }
/*      */ 
/*      */     public ResolvableType resolveVariable(TypeVariable<?> variable)
/*      */     {
/* 1076 */       for (int i = 0; i < this.typeVariables.length; i++) {
/* 1077 */         if (this.typeVariables[i].equals(variable)) {
/* 1078 */           return this.generics[i];
/*      */         }
/*      */       }
/* 1081 */       return null;
/*      */     }
/*      */ 
/*      */     public Object getSource()
/*      */     {
/* 1086 */       return this.generics;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class DefaultVariableResolver
/*      */     implements ResolvableType.VariableResolver
/*      */   {
/*      */     private DefaultVariableResolver()
/*      */     {
/*      */     }
/*      */ 
/*      */     public ResolvableType resolveVariable(TypeVariable<?> variable)
/*      */     {
/* 1051 */       return ResolvableType.this.resolveVariable(variable);
/*      */     }
/*      */ 
/*      */     public Object getSource()
/*      */     {
/* 1056 */       return ResolvableType.this;
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract interface VariableResolver extends Serializable
/*      */   {
/*      */     public abstract Object getSource();
/*      */ 
/*      */     public abstract ResolvableType resolveVariable(TypeVariable<?> paramTypeVariable);
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.ResolvableType
 * JD-Core Version:    0.6.2
 */