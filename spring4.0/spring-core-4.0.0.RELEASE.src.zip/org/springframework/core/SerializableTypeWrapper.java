/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ abstract class SerializableTypeWrapper
/*     */ {
/*  56 */   private static final Class<?>[] SUPPORTED_SERIALAZABLE_TYPES = { GenericArrayType.class, ParameterizedType.class, TypeVariable.class, WildcardType.class };
/*     */ 
/*     */   public static Type forField(Field field)
/*     */   {
/*  64 */     Assert.notNull(field, "Field must not be null");
/*  65 */     return forTypeProvider(new FieldTypeProvider(field));
/*     */   }
/*     */ 
/*     */   public static Type forMethodParameter(MethodParameter methodParameter)
/*     */   {
/*  73 */     return forTypeProvider(new MethodParameterTypeProvider(methodParameter));
/*     */   }
/*     */ 
/*     */   public static Type forGenericSuperclass(Class<?> type)
/*     */   {
/*  80 */     return forTypeProvider(new DefaultTypeProvider()
/*     */     {
/*     */       private static final long serialVersionUID = 1L;
/*     */ 
/*     */       public Type getType()
/*     */       {
/*  87 */         return this.val$type.getGenericSuperclass();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static Type[] forGenericInterfaces(Class<?> type)
/*     */   {
/*  96 */     Type[] result = new Type[type.getGenericInterfaces().length];
/*  97 */     for (int i = 0; i < result.length; i++) {
/*  98 */       final int index = i;
/*  99 */       result[i] = forTypeProvider(new DefaultTypeProvider()
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */         public Type getType()
/*     */         {
/* 106 */           return this.val$type.getGenericInterfaces()[index];
/*     */         }
/*     */       });
/*     */     }
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */   public static Type[] forTypeParameters(Class<?> type)
/*     */   {
/* 117 */     Type[] result = new Type[type.getTypeParameters().length];
/* 118 */     for (int i = 0; i < result.length; i++) {
/* 119 */       final int index = i;
/* 120 */       result[i] = forTypeProvider(new DefaultTypeProvider()
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */         public Type getType()
/*     */         {
/* 127 */           return this.val$type.getTypeParameters()[index];
/*     */         }
/*     */       });
/*     */     }
/* 131 */     return result;
/*     */   }
/*     */ 
/*     */   static Type forTypeProvider(TypeProvider provider)
/*     */   {
/* 139 */     Assert.notNull(provider, "Provider must not be null");
/* 140 */     if (((provider.getType() instanceof Serializable)) || (provider.getType() == null)) {
/* 141 */       return provider.getType();
/*     */     }
/* 143 */     for (Class type : SUPPORTED_SERIALAZABLE_TYPES) {
/* 144 */       if (type.isAssignableFrom(provider.getType().getClass())) {
/* 145 */         ClassLoader classLoader = provider.getClass().getClassLoader();
/* 146 */         Class[] interfaces = { type, Serializable.class };
/* 147 */         InvocationHandler handler = new TypeProxyInvocationHandler(provider);
/* 148 */         return (Type)Proxy.newProxyInstance(classLoader, interfaces, handler);
/*     */       }
/*     */     }
/*     */ 
/* 152 */     throw new IllegalArgumentException("Unsupported Type class " + provider
/* 152 */       .getType().getClass().getName());
/*     */   }
/*     */ 
/*     */   static class MethodInvokeTypeProvider
/*     */     implements SerializableTypeWrapper.TypeProvider
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final SerializableTypeWrapper.TypeProvider provider;
/*     */     private final String methodName;
/*     */     private final int index;
/*     */     private transient Object result;
/*     */ 
/*     */     public MethodInvokeTypeProvider(SerializableTypeWrapper.TypeProvider provider, Method method, int index)
/*     */     {
/* 360 */       this.provider = provider;
/* 361 */       this.methodName = method.getName();
/* 362 */       this.index = index;
/* 363 */       this.result = ReflectionUtils.invokeMethod(method, provider.getType());
/*     */     }
/*     */ 
/*     */     public Type getType()
/*     */     {
/* 369 */       if (((this.result instanceof Type)) || (this.result == null)) {
/* 370 */         return (Type)this.result;
/*     */       }
/* 372 */       return ((Type[])(Type[])this.result)[this.index];
/*     */     }
/*     */ 
/*     */     public Object getSource()
/*     */     {
/* 377 */       return null;
/*     */     }
/*     */ 
/*     */     private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException
/*     */     {
/* 382 */       inputStream.defaultReadObject();
/* 383 */       Method method = ReflectionUtils.findMethod(this.provider
/* 384 */         .getType().getClass(), this.methodName);
/* 385 */       this.result = ReflectionUtils.invokeMethod(method, this.provider.getType());
/*     */     }
/*     */   }
/*     */ 
/*     */   static class MethodParameterTypeProvider
/*     */     implements SerializableTypeWrapper.TypeProvider
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final String methodName;
/*     */     private final Class<?>[] parameterTypes;
/*     */     private final Class<?> declaringClass;
/*     */     private final int parameterIndex;
/*     */     private transient MethodParameter methodParameter;
/*     */ 
/*     */     public MethodParameterTypeProvider(MethodParameter methodParameter)
/*     */     {
/* 294 */       if (methodParameter.getMethod() != null) {
/* 295 */         this.methodName = methodParameter.getMethod().getName();
/* 296 */         this.parameterTypes = methodParameter.getMethod().getParameterTypes();
/*     */       }
/*     */       else {
/* 299 */         this.methodName = null;
/* 300 */         this.parameterTypes = methodParameter.getConstructor().getParameterTypes();
/*     */       }
/* 302 */       this.declaringClass = methodParameter.getDeclaringClass();
/* 303 */       this.parameterIndex = methodParameter.getParameterIndex();
/* 304 */       this.methodParameter = methodParameter;
/*     */     }
/*     */ 
/*     */     public Type getType()
/*     */     {
/* 310 */       return this.methodParameter.getGenericParameterType();
/*     */     }
/*     */ 
/*     */     public Object getSource()
/*     */     {
/* 315 */       return this.methodParameter;
/*     */     }
/*     */ 
/*     */     private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException
/*     */     {
/* 320 */       inputStream.defaultReadObject();
/*     */       try {
/* 322 */         if (this.methodName != null) {
/* 323 */           this.methodParameter = new MethodParameter(this.declaringClass
/* 324 */             .getDeclaredMethod(this.methodName, this.parameterTypes), 
/* 324 */             this.parameterIndex);
/*     */         }
/*     */         else
/*     */         {
/* 328 */           this.methodParameter = new MethodParameter(this.declaringClass
/* 329 */             .getDeclaredConstructor(this.parameterTypes), 
/* 329 */             this.parameterIndex);
/*     */         }
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 334 */         throw new IllegalStateException("Could not find original class structure", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class FieldTypeProvider
/*     */     implements SerializableTypeWrapper.TypeProvider
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final String fieldName;
/*     */     private final Class<?> declaringClass;
/*     */     private transient Field field;
/*     */ 
/*     */     public FieldTypeProvider(Field field)
/*     */     {
/* 243 */       this.fieldName = field.getName();
/* 244 */       this.declaringClass = field.getDeclaringClass();
/* 245 */       this.field = field;
/*     */     }
/*     */ 
/*     */     public Type getType()
/*     */     {
/* 251 */       return this.field.getGenericType();
/*     */     }
/*     */ 
/*     */     public Object getSource()
/*     */     {
/* 256 */       return this.field;
/*     */     }
/*     */ 
/*     */     private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException
/*     */     {
/* 261 */       inputStream.defaultReadObject();
/*     */       try {
/* 263 */         this.field = this.declaringClass.getDeclaredField(this.fieldName);
/*     */       }
/*     */       catch (Throwable ex) {
/* 266 */         throw new IllegalStateException("Could not find original class structure", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TypeProxyInvocationHandler
/*     */     implements InvocationHandler, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final SerializableTypeWrapper.TypeProvider provider;
/*     */ 
/*     */     public TypeProxyInvocationHandler(SerializableTypeWrapper.TypeProvider provider)
/*     */     {
/* 204 */       this.provider = provider;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args)
/*     */       throws Throwable
/*     */     {
/* 210 */       if ((Type.class.equals(method.getReturnType())) && (args == null)) {
/* 211 */         return SerializableTypeWrapper.forTypeProvider(new SerializableTypeWrapper.MethodInvokeTypeProvider(this.provider, method, -1));
/*     */       }
/* 213 */       if (([Ljava.lang.reflect.Type.class.equals(method.getReturnType())) && (args == null)) {
/* 214 */         Type[] result = new Type[((Type[])method.invoke(this.provider.getType(), args)).length];
/* 215 */         for (int i = 0; i < result.length; i++) {
/* 216 */           result[i] = SerializableTypeWrapper.forTypeProvider(new SerializableTypeWrapper.MethodInvokeTypeProvider(this.provider, method, i));
/*     */         }
/* 218 */         return result;
/*     */       }
/* 220 */       return method.invoke(this.provider.getType(), args);
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract class DefaultTypeProvider
/*     */     implements SerializableTypeWrapper.TypeProvider
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public Object getSource()
/*     */     {
/* 184 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface TypeProvider extends Serializable
/*     */   {
/*     */     public abstract Type getType();
/*     */ 
/*     */     public abstract Object getSource();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.SerializableTypeWrapper
 * JD-Core Version:    0.6.2
 */