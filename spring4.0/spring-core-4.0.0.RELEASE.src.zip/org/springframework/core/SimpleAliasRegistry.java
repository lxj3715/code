/*     */ package org.springframework.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class SimpleAliasRegistry
/*     */   implements AliasRegistry
/*     */ {
/*  41 */   private final Map<String, String> aliasMap = new ConcurrentHashMap(16);
/*     */ 
/*     */   public void registerAlias(String name, String alias)
/*     */   {
/*  46 */     Assert.hasText(name, "'name' must not be empty");
/*  47 */     Assert.hasText(alias, "'alias' must not be empty");
/*  48 */     if (alias.equals(name)) {
/*  49 */       this.aliasMap.remove(alias);
/*     */     }
/*     */     else {
/*  52 */       if (!allowAliasOverriding()) {
/*  53 */         String registeredName = (String)this.aliasMap.get(alias);
/*  54 */         if ((registeredName != null) && (!registeredName.equals(name))) {
/*  55 */           throw new IllegalStateException("Cannot register alias '" + alias + "' for name '" + name + "': It is already registered for name '" + registeredName + "'.");
/*     */         }
/*     */       }
/*     */ 
/*  59 */       checkForAliasCircle(name, alias);
/*  60 */       this.aliasMap.put(alias, name);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean allowAliasOverriding()
/*     */   {
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */   public void removeAlias(String alias)
/*     */   {
/*  74 */     String name = (String)this.aliasMap.remove(alias);
/*  75 */     if (name == null)
/*  76 */       throw new IllegalStateException("No alias '" + alias + "' registered");
/*     */   }
/*     */ 
/*     */   public boolean isAlias(String name)
/*     */   {
/*  82 */     return this.aliasMap.containsKey(name);
/*     */   }
/*     */ 
/*     */   public String[] getAliases(String name)
/*     */   {
/*  87 */     List result = new ArrayList();
/*  88 */     synchronized (this.aliasMap) {
/*  89 */       retrieveAliases(name, result);
/*     */     }
/*  91 */     return StringUtils.toStringArray(result);
/*     */   }
/*     */ 
/*     */   private void retrieveAliases(String name, List<String> result)
/*     */   {
/* 100 */     for (Map.Entry entry : this.aliasMap.entrySet()) {
/* 101 */       String registeredName = (String)entry.getValue();
/* 102 */       if (registeredName.equals(name)) {
/* 103 */         String alias = (String)entry.getKey();
/* 104 */         result.add(alias);
/* 105 */         retrieveAliases(alias, result);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resolveAliases(StringValueResolver valueResolver)
/*     */   {
/* 118 */     Assert.notNull(valueResolver, "StringValueResolver must not be null");
/*     */     Map aliasCopy;
/* 119 */     synchronized (this.aliasMap) {
/* 120 */       aliasCopy = new HashMap(this.aliasMap);
/* 121 */       for (String alias : aliasCopy.keySet()) {
/* 122 */         String registeredName = (String)aliasCopy.get(alias);
/* 123 */         String resolvedAlias = valueResolver.resolveStringValue(alias);
/* 124 */         String resolvedName = valueResolver.resolveStringValue(registeredName);
/* 125 */         if (resolvedAlias.equals(resolvedName)) {
/* 126 */           this.aliasMap.remove(alias);
/*     */         }
/* 128 */         else if (!resolvedAlias.equals(alias)) {
/* 129 */           String existingName = (String)this.aliasMap.get(resolvedAlias);
/* 130 */           if ((existingName != null) && (!existingName.equals(resolvedName))) {
/* 131 */             throw new IllegalStateException("Cannot register resolved alias '" + resolvedAlias + "' (original: '" + alias + "') for name '" + resolvedName + "': It is already registered for name '" + registeredName + "'.");
/*     */           }
/*     */ 
/* 136 */           checkForAliasCircle(resolvedName, resolvedAlias);
/* 137 */           this.aliasMap.remove(alias);
/* 138 */           this.aliasMap.put(resolvedAlias, resolvedName);
/*     */         }
/* 140 */         else if (!registeredName.equals(resolvedName)) {
/* 141 */           this.aliasMap.put(alias, resolvedName);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String canonicalName(String name)
/*     */   {
/* 153 */     String canonicalName = name;
/*     */     String resolvedName;
/*     */     do
/*     */     {
/* 157 */       resolvedName = (String)this.aliasMap.get(canonicalName);
/* 158 */       if (resolvedName != null) {
/* 159 */         canonicalName = resolvedName;
/*     */       }
/*     */     }
/* 162 */     while (resolvedName != null);
/* 163 */     return canonicalName;
/*     */   }
/*     */ 
/*     */   protected void checkForAliasCircle(String name, String alias)
/*     */   {
/* 175 */     if (alias.equals(canonicalName(name)))
/* 176 */       throw new IllegalStateException("Cannot register alias '" + alias + "' for name '" + name + "': Circular reference - '" + name + "' is a direct or indirect alias for '" + alias + "' already");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.SimpleAliasRegistry
 * JD-Core Version:    0.6.2
 */