package org.springframework.core;

public abstract interface SmartClassLoader
{
  public abstract boolean isClassReloadable(Class<?> paramClass);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.SmartClassLoader
 * JD-Core Version:    0.6.2
 */