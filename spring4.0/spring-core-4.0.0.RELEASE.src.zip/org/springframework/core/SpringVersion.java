/*    */ package org.springframework.core;
/*    */ 
/*    */ public class SpringVersion
/*    */ {
/*    */   public static String getVersion()
/*    */   {
/* 40 */     Package pkg = SpringVersion.class.getPackage();
/* 41 */     return pkg != null ? pkg.getImplementationVersion() : null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.SpringVersion
 * JD-Core Version:    0.6.2
 */