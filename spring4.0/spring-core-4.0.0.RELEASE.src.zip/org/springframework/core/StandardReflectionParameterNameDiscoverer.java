/*    */ package org.springframework.core;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Parameter;
/*    */ 
/*    */ public class StandardReflectionParameterNameDiscoverer
/*    */   implements ParameterNameDiscoverer
/*    */ {
/*    */   public String[] getParameterNames(Method method)
/*    */   {
/* 35 */     Parameter[] parameters = method.getParameters();
/* 36 */     String[] parameterNames = new String[parameters.length];
/* 37 */     for (int i = 0; i < parameters.length; i++) {
/* 38 */       Parameter param = parameters[i];
/* 39 */       if (!param.isNamePresent()) {
/* 40 */         return null;
/*    */       }
/* 42 */       parameterNames[i] = param.getName();
/*    */     }
/* 44 */     return parameterNames;
/*    */   }
/*    */ 
/*    */   public String[] getParameterNames(Constructor<?> ctor)
/*    */   {
/* 49 */     Parameter[] parameters = ctor.getParameters();
/* 50 */     String[] parameterNames = new String[parameters.length];
/* 51 */     for (int i = 0; i < parameters.length; i++) {
/* 52 */       Parameter param = parameters[i];
/* 53 */       if (!param.isNamePresent()) {
/* 54 */         return null;
/*    */       }
/* 56 */       parameterNames[i] = param.getName();
/*    */     }
/* 58 */     return parameterNames;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.StandardReflectionParameterNameDiscoverer
 * JD-Core Version:    0.6.2
 */