/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public class AnnotatedElementUtils
/*     */ {
/*     */   public static Set<String> getMetaAnnotationTypes(AnnotatedElement element, String annotationType)
/*     */   {
/*  40 */     Set types = new LinkedHashSet();
/*  41 */     process(element, annotationType, new Processor()
/*     */     {
/*     */       public Object process(Annotation annotation, int depth) {
/*  44 */         if (depth > 0) {
/*  45 */           this.val$types.add(annotation.annotationType().getName());
/*     */         }
/*  47 */         return null;
/*     */       }
/*     */ 
/*     */       public void postProcess(Annotation annotation, Object result)
/*     */       {
/*     */       }
/*     */     });
/*  53 */     return types.isEmpty() ? null : types;
/*     */   }
/*     */ 
/*     */   public static boolean hasMetaAnnotationTypes(AnnotatedElement element, String annotationType) {
/*  57 */     return Boolean.TRUE.equals(process(element, annotationType, new Processor()
/*     */     {
/*     */       public Boolean process(Annotation annotation, int depth) {
/*  60 */         if (depth > 0) {
/*  61 */           return Boolean.valueOf(true);
/*     */         }
/*  63 */         return null;
/*     */       }
/*     */ 
/*     */       public void postProcess(Annotation annotation, Boolean result) {
/*     */       }
/*     */     }));
/*     */   }
/*     */ 
/*     */   public static boolean isAnnotated(AnnotatedElement element, String annotationType) {
/*  72 */     return Boolean.TRUE.equals(process(element, annotationType, new Processor()
/*     */     {
/*     */       public Boolean process(Annotation annotation, int depth) {
/*  75 */         return Boolean.valueOf(true);
/*     */       }
/*     */ 
/*     */       public void postProcess(Annotation annotation, Boolean result) {
/*     */       }
/*     */     }));
/*     */   }
/*     */ 
/*     */   public static AnnotationAttributes getAnnotationAttributes(AnnotatedElement element, String annotationType) {
/*  84 */     return getAnnotationAttributes(element, annotationType, false, false);
/*     */   }
/*     */ 
/*     */   public static AnnotationAttributes getAnnotationAttributes(AnnotatedElement element, String annotationType, boolean classValuesAsString, final boolean nestedAnnotationsAsMap)
/*     */   {
/*  91 */     return (AnnotationAttributes)process(element, annotationType, new Processor()
/*     */     {
/*     */       public AnnotationAttributes process(Annotation annotation, int depth) {
/*  94 */         return AnnotationUtils.getAnnotationAttributes(annotation, this.val$classValuesAsString, nestedAnnotationsAsMap);
/*     */       }
/*     */ 
/*     */       public void postProcess(Annotation annotation, AnnotationAttributes result) {
/*  98 */         for (String key : result.keySet())
/*  99 */           if (!"value".equals(key)) {
/* 100 */             Object value = AnnotationUtils.getValue(annotation, key);
/* 101 */             if (value != null)
/* 102 */               result.put(key, value);
/*     */           }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static MultiValueMap<String, Object> getAllAnnotationAttributes(AnnotatedElement element, String annotationType, final boolean classValuesAsString, final boolean nestedAnnotationsAsMap)
/*     */   {
/* 114 */     final MultiValueMap attributes = new LinkedMultiValueMap();
/* 115 */     process(element, annotationType, new Processor()
/*     */     {
/*     */       public Void process(Annotation annotation, int depth) {
/* 118 */         if (annotation.annotationType().getName().equals(this.val$annotationType))
/*     */         {
/* 120 */           for (Map.Entry entry : AnnotationUtils.getAnnotationAttributes(annotation, classValuesAsString, nestedAnnotationsAsMap)
/* 121 */             .entrySet()) {
/* 122 */             attributes.add(entry.getKey(), entry.getValue());
/*     */           }
/*     */         }
/* 125 */         return null;
/*     */       }
/*     */ 
/*     */       public void postProcess(Annotation annotation, Void result) {
/* 129 */         for (String key : attributes.keySet())
/* 130 */           if (!"value".equals(key)) {
/* 131 */             Object value = AnnotationUtils.getValue(annotation, key);
/* 132 */             if (value != null)
/* 133 */               attributes.add(key, value);
/*     */           }
/*     */       }
/*     */     });
/* 139 */     return attributes.isEmpty() ? null : attributes;
/*     */   }
/*     */ 
/*     */   private static <T> T process(AnnotatedElement element, String annotationType, Processor<T> processor)
/*     */   {
/* 152 */     return doProcess(element, annotationType, processor, new HashSet(), 0);
/*     */   }
/*     */ 
/*     */   private static <T> T doProcess(AnnotatedElement element, String annotationType, Processor<T> processor, Set<AnnotatedElement> visited, int depth)
/*     */   {
/* 158 */     if (visited.add(element)) {
/* 159 */       for (Annotation annotation : element.getAnnotations()) {
/* 160 */         if ((annotation.annotationType().getName().equals(annotationType)) || (depth > 0)) {
/* 161 */           Object result = processor.process(annotation, depth);
/* 162 */           if (result != null) {
/* 163 */             return result;
/*     */           }
/* 165 */           result = doProcess(annotation.annotationType(), annotationType, processor, visited, depth + 1);
/* 166 */           if (result != null) {
/* 167 */             processor.postProcess(annotation, result);
/* 168 */             return result;
/*     */           }
/*     */         }
/*     */       }
/* 172 */       for (Annotation annotation : element.getAnnotations()) {
/* 173 */         Object result = doProcess(annotation.annotationType(), annotationType, processor, visited, depth);
/* 174 */         if (result != null) {
/* 175 */           processor.postProcess(annotation, result);
/* 176 */           return result;
/*     */         }
/*     */       }
/*     */     }
/* 180 */     return null;
/*     */   }
/*     */ 
/*     */   private static abstract interface Processor<T>
/*     */   {
/*     */     public abstract T process(Annotation paramAnnotation, int paramInt);
/*     */ 
/*     */     public abstract void postProcess(Annotation paramAnnotation, T paramT);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.annotation.AnnotatedElementUtils
 * JD-Core Version:    0.6.2
 */