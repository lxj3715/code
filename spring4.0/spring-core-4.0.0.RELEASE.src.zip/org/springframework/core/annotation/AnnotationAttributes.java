/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AnnotationAttributes extends LinkedHashMap<String, Object>
/*     */ {
/*     */   public AnnotationAttributes()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AnnotationAttributes(int initialCapacity)
/*     */   {
/*  51 */     super(initialCapacity);
/*     */   }
/*     */ 
/*     */   public AnnotationAttributes(Map<String, Object> map)
/*     */   {
/*  61 */     super(map);
/*     */   }
/*     */ 
/*     */   public String getString(String attributeName)
/*     */   {
/*  66 */     return (String)doGet(attributeName, String.class);
/*     */   }
/*     */ 
/*     */   public String[] getStringArray(String attributeName) {
/*  70 */     return (String[])doGet(attributeName, [Ljava.lang.String.class);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String attributeName) {
/*  74 */     return ((Boolean)doGet(attributeName, Boolean.class)).booleanValue();
/*     */   }
/*     */ 
/*     */   public <N extends Number> N getNumber(String attributeName)
/*     */   {
/*  79 */     return (Number)doGet(attributeName, Number.class);
/*     */   }
/*     */ 
/*     */   public <E extends Enum<?>> E getEnum(String attributeName)
/*     */   {
/*  84 */     return (Enum)doGet(attributeName, Enum.class);
/*     */   }
/*     */ 
/*     */   public <T> Class<? extends T> getClass(String attributeName)
/*     */   {
/*  89 */     return (Class)doGet(attributeName, Class.class);
/*     */   }
/*     */ 
/*     */   public Class<?>[] getClassArray(String attributeName) {
/*  93 */     return (Class[])doGet(attributeName, [Ljava.lang.Class.class);
/*     */   }
/*     */ 
/*     */   public AnnotationAttributes getAnnotation(String attributeName) {
/*  97 */     return (AnnotationAttributes)doGet(attributeName, AnnotationAttributes.class);
/*     */   }
/*     */ 
/*     */   public AnnotationAttributes[] getAnnotationArray(String attributeName) {
/* 101 */     return (AnnotationAttributes[])doGet(attributeName, [Lorg.springframework.core.annotation.AnnotationAttributes.class);
/*     */   }
/*     */ 
/*     */   private <T> T doGet(String attributeName, Class<T> expectedType)
/*     */   {
/* 106 */     Assert.hasText(attributeName, "attributeName must not be null or empty");
/* 107 */     Object value = get(attributeName);
/* 108 */     Assert.notNull(value, String.format("Attribute '%s' not found", new Object[] { attributeName }));
/* 109 */     if (!expectedType.isInstance(value)) {
/* 110 */       if ((expectedType.isArray()) && (expectedType.getComponentType().isInstance(value))) {
/* 111 */         Object arrayValue = Array.newInstance(expectedType.getComponentType(), 1);
/* 112 */         Array.set(arrayValue, 0, value);
/* 113 */         value = arrayValue;
/*     */       }
/*     */       else
/*     */       {
/* 117 */         throw new IllegalArgumentException(
/* 117 */           String.format("Attribute '%s' is of type [%s], but [%s] was expected. Cause: ", new Object[] { attributeName, value
/* 118 */           .getClass().getSimpleName(), expectedType.getSimpleName() }));
/*     */       }
/*     */     }
/* 121 */     return value;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 126 */     Iterator entries = entrySet().iterator();
/* 127 */     StringBuilder sb = new StringBuilder("{");
/* 128 */     while (entries.hasNext()) {
/* 129 */       Map.Entry entry = (Map.Entry)entries.next();
/* 130 */       sb.append((String)entry.getKey());
/* 131 */       sb.append('=');
/* 132 */       sb.append(valueToString(entry.getValue()));
/* 133 */       sb.append(entries.hasNext() ? ", " : "");
/*     */     }
/* 135 */     sb.append("}");
/* 136 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private String valueToString(Object value) {
/* 140 */     if (value == this) {
/* 141 */       return "(this Map)";
/*     */     }
/* 143 */     if ((value instanceof Object[])) {
/* 144 */       return new StringBuilder().append("[").append(StringUtils.arrayToCommaDelimitedString((Object[])value)).append("]").toString();
/*     */     }
/* 146 */     return String.valueOf(value);
/*     */   }
/*     */ 
/*     */   public static AnnotationAttributes fromMap(Map<String, Object> map)
/*     */   {
/* 158 */     if (map == null) {
/* 159 */       return null;
/*     */     }
/* 161 */     if ((map instanceof AnnotationAttributes)) {
/* 162 */       return (AnnotationAttributes)map;
/*     */     }
/* 164 */     return new AnnotationAttributes(map);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.annotation.AnnotationAttributes
 * JD-Core Version:    0.6.2
 */