/*    */ package org.springframework.core.annotation;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.core.OrderComparator;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ public class AnnotationAwareOrderComparator extends OrderComparator
/*    */ {
/* 44 */   public static final AnnotationAwareOrderComparator INSTANCE = new AnnotationAwareOrderComparator();
/*    */ 
/*    */   protected int getOrder(Object obj)
/*    */   {
/* 49 */     if ((obj instanceof Ordered)) {
/* 50 */       return ((Ordered)obj).getOrder();
/*    */     }
/* 52 */     if (obj != null) {
/* 53 */       Class clazz = (obj instanceof Class) ? (Class)obj : obj.getClass();
/* 54 */       Order order = (Order)AnnotationUtils.findAnnotation(clazz, Order.class);
/* 55 */       if (order != null) {
/* 56 */         return order.value();
/*    */       }
/*    */     }
/* 59 */     return 2147483647;
/*    */   }
/*    */ 
/*    */   public static void sort(List<?> list)
/*    */   {
/* 71 */     if (list.size() > 1)
/* 72 */       Collections.sort(list, INSTANCE);
/*    */   }
/*    */ 
/*    */   public static void sort(Object[] array)
/*    */   {
/* 84 */     if (array.length > 1)
/* 85 */       Arrays.sort(array, INSTANCE);
/*    */   }
/*    */ 
/*    */   public static void sortIfNecessary(Object value)
/*    */   {
/* 98 */     if ((value instanceof Object[])) {
/* 99 */       sort((Object[])value);
/*    */     }
/* 101 */     else if ((value instanceof List))
/* 102 */       sort((List)value);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.annotation.AnnotationAwareOrderComparator
 * JD-Core Version:    0.6.2
 */