/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class AnnotationUtils
/*     */ {
/*     */   static final String VALUE = "value";
/*  66 */   private static final Map<Class<?>, Boolean> annotatedInterfaceCache = new WeakHashMap();
/*     */ 
/*     */   public static <T extends Annotation> T getAnnotation(Annotation ann, Class<T> annotationType)
/*     */   {
/*  79 */     if (annotationType.isInstance(ann)) {
/*  80 */       return ann;
/*     */     }
/*  82 */     return ann.annotationType().getAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */   public static <T extends Annotation> T getAnnotation(AnnotatedElement ae, Class<T> annotationType)
/*     */   {
/*  95 */     Annotation ann = ae.getAnnotation(annotationType);
/*  96 */     if (ann == null) {
/*  97 */       for (Annotation metaAnn : ae.getAnnotations()) {
/*  98 */         ann = metaAnn.annotationType().getAnnotation(annotationType);
/*  99 */         if (ann != null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 104 */     return ann;
/*     */   }
/*     */ 
/*     */   public static Annotation[] getAnnotations(Method method)
/*     */   {
/* 115 */     return BridgeMethodResolver.findBridgedMethod(method).getAnnotations();
/*     */   }
/*     */ 
/*     */   public static <A extends Annotation> A getAnnotation(Method method, Class<A> annotationType)
/*     */   {
/* 127 */     Method resolvedMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 128 */     return getAnnotation(resolvedMethod, annotationType);
/*     */   }
/*     */ 
/*     */   public static <A extends Annotation> Set<A> getRepeatableAnnotation(Method method, Class<? extends Annotation> containerAnnotationType, Class<A> annotationType)
/*     */   {
/* 145 */     Method resolvedMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 146 */     return getRepeatableAnnotation(resolvedMethod, containerAnnotationType, annotationType);
/*     */   }
/*     */ 
/*     */   public static <A extends Annotation> Set<A> getRepeatableAnnotation(AnnotatedElement annotatedElement, Class<? extends Annotation> containerAnnotationType, Class<A> annotationType)
/*     */   {
/* 164 */     if (annotatedElement.getAnnotations().length == 0) {
/* 165 */       return Collections.emptySet();
/*     */     }
/* 167 */     return new AnnotationCollector(containerAnnotationType, annotationType).getResult(annotatedElement);
/*     */   }
/*     */ 
/*     */   public static <A extends Annotation> A findAnnotation(Method method, Class<A> annotationType)
/*     */   {
/* 181 */     Annotation annotation = getAnnotation(method, annotationType);
/* 182 */     Class clazz = method.getDeclaringClass();
/* 183 */     if (annotation == null) {
/* 184 */       annotation = searchOnInterfaces(method, annotationType, clazz.getInterfaces());
/*     */     }
/* 186 */     while (annotation == null) {
/* 187 */       clazz = clazz.getSuperclass();
/* 188 */       if ((clazz == null) || (clazz.equals(Object.class)))
/*     */         break;
/*     */       try
/*     */       {
/* 192 */         Method equivalentMethod = clazz.getDeclaredMethod(method.getName(), method.getParameterTypes());
/* 193 */         annotation = getAnnotation(equivalentMethod, annotationType);
/*     */       }
/*     */       catch (NoSuchMethodException ex)
/*     */       {
/*     */       }
/* 198 */       if (annotation == null) {
/* 199 */         annotation = searchOnInterfaces(method, annotationType, clazz.getInterfaces());
/*     */       }
/*     */     }
/* 202 */     return annotation;
/*     */   }
/*     */ 
/*     */   private static <A extends Annotation> A searchOnInterfaces(Method method, Class<A> annotationType, Class<?>[] ifcs) {
/* 206 */     Annotation annotation = null;
/* 207 */     for (Class iface : ifcs) {
/* 208 */       if (isInterfaceWithAnnotatedMethods(iface)) {
/*     */         try {
/* 210 */           Method equivalentMethod = iface.getMethod(method.getName(), method.getParameterTypes());
/* 211 */           annotation = getAnnotation(equivalentMethod, annotationType);
/*     */         }
/*     */         catch (NoSuchMethodException ex)
/*     */         {
/*     */         }
/* 216 */         if (annotation != null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 221 */     return annotation;
/*     */   }
/*     */ 
/*     */   private static boolean isInterfaceWithAnnotatedMethods(Class<?> iface) {
/* 225 */     synchronized (annotatedInterfaceCache) {
/* 226 */       Boolean flag = (Boolean)annotatedInterfaceCache.get(iface);
/* 227 */       if (flag != null) {
/* 228 */         return flag.booleanValue();
/*     */       }
/* 230 */       boolean found = false;
/* 231 */       for (Method ifcMethod : iface.getMethods()) {
/* 232 */         if (ifcMethod.getAnnotations().length > 0) {
/* 233 */           found = true;
/* 234 */           break;
/*     */         }
/*     */       }
/* 237 */       annotatedInterfaceCache.put(iface, Boolean.valueOf(found));
/* 238 */       return found;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <A extends Annotation> A findAnnotation(Class<?> clazz, Class<A> annotationType)
/*     */   {
/* 265 */     Assert.notNull(clazz, "Class must not be null");
/* 266 */     Annotation annotation = clazz.getAnnotation(annotationType);
/* 267 */     if (annotation != null) {
/* 268 */       return annotation;
/*     */     }
/* 270 */     for (Class ifc : clazz.getInterfaces()) {
/* 271 */       annotation = findAnnotation(ifc, annotationType);
/* 272 */       if (annotation != null) {
/* 273 */         return annotation;
/*     */       }
/*     */     }
/* 276 */     if (!Annotation.class.isAssignableFrom(clazz)) {
/* 277 */       for (Annotation ann : clazz.getAnnotations()) {
/* 278 */         annotation = findAnnotation(ann.annotationType(), annotationType);
/* 279 */         if (annotation != null) {
/* 280 */           return annotation;
/*     */         }
/*     */       }
/*     */     }
/* 284 */     Class superClass = clazz.getSuperclass();
/* 285 */     if ((superClass == null) || (superClass.equals(Object.class))) {
/* 286 */       return null;
/*     */     }
/* 288 */     return findAnnotation(superClass, annotationType);
/*     */   }
/*     */ 
/*     */   public static Class<?> findAnnotationDeclaringClass(Class<? extends Annotation> annotationType, Class<?> clazz)
/*     */   {
/* 312 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 313 */     if ((clazz == null) || (clazz.equals(Object.class))) {
/* 314 */       return null;
/*     */     }
/* 316 */     if (isAnnotationDeclaredLocally(annotationType, clazz)) {
/* 317 */       return clazz;
/*     */     }
/* 319 */     return findAnnotationDeclaringClass(annotationType, clazz.getSuperclass());
/*     */   }
/*     */ 
/*     */   public static Class<?> findAnnotationDeclaringClassForTypes(List<Class<? extends Annotation>> annotationTypes, Class<?> clazz)
/*     */   {
/* 349 */     Assert.notEmpty(annotationTypes, "The list of annotation types must not be empty");
/* 350 */     if ((clazz == null) || (clazz.equals(Object.class))) {
/* 351 */       return null;
/*     */     }
/* 353 */     for (Class annotationType : annotationTypes) {
/* 354 */       if (isAnnotationDeclaredLocally(annotationType, clazz)) {
/* 355 */         return clazz;
/*     */       }
/*     */     }
/* 358 */     return findAnnotationDeclaringClassForTypes(annotationTypes, clazz.getSuperclass());
/*     */   }
/*     */ 
/*     */   public static boolean isAnnotationDeclaredLocally(Class<? extends Annotation> annotationType, Class<?> clazz)
/*     */   {
/* 377 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 378 */     Assert.notNull(clazz, "Class must not be null");
/* 379 */     boolean declaredLocally = false;
/* 380 */     for (Annotation annotation : clazz.getDeclaredAnnotations()) {
/* 381 */       if (annotation.annotationType().equals(annotationType)) {
/* 382 */         declaredLocally = true;
/* 383 */         break;
/*     */       }
/*     */     }
/* 386 */     return declaredLocally;
/*     */   }
/*     */ 
/*     */   public static boolean isAnnotationInherited(Class<? extends Annotation> annotationType, Class<?> clazz)
/*     */   {
/* 405 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 406 */     Assert.notNull(clazz, "Class must not be null");
/* 407 */     return (clazz.isAnnotationPresent(annotationType)) && (!isAnnotationDeclaredLocally(annotationType, clazz));
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> getAnnotationAttributes(Annotation annotation)
/*     */   {
/* 421 */     return getAnnotationAttributes(annotation, false, false);
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> getAnnotationAttributes(Annotation annotation, boolean classValuesAsString)
/*     */   {
/* 439 */     return getAnnotationAttributes(annotation, classValuesAsString, false);
/*     */   }
/*     */ 
/*     */   public static AnnotationAttributes getAnnotationAttributes(Annotation annotation, boolean classValuesAsString, boolean nestedAnnotationsAsMap)
/*     */   {
/* 462 */     AnnotationAttributes attrs = new AnnotationAttributes();
/* 463 */     Method[] methods = annotation.annotationType().getDeclaredMethods();
/* 464 */     for (Method method : methods) {
/* 465 */       if ((method.getParameterTypes().length == 0) && (method.getReturnType() != Void.TYPE)) {
/*     */         try {
/* 467 */           Object value = method.invoke(annotation, new Object[0]);
/* 468 */           if (classValuesAsString) {
/* 469 */             if ((value instanceof Class)) {
/* 470 */               value = ((Class)value).getName();
/*     */             }
/* 472 */             else if ((value instanceof Class[])) {
/* 473 */               Class[] clazzArray = (Class[])value;
/* 474 */               String[] newValue = new String[clazzArray.length];
/* 475 */               for (int i = 0; i < clazzArray.length; i++) {
/* 476 */                 newValue[i] = clazzArray[i].getName();
/*     */               }
/* 478 */               value = newValue;
/*     */             }
/*     */           }
/* 481 */           if ((nestedAnnotationsAsMap) && ((value instanceof Annotation))) {
/* 482 */             attrs.put(method.getName(), 
/* 483 */               getAnnotationAttributes((Annotation)value, classValuesAsString, nestedAnnotationsAsMap));
/*     */           }
/* 485 */           else if ((nestedAnnotationsAsMap) && ((value instanceof Annotation[]))) {
/* 486 */             Annotation[] realAnnotations = (Annotation[])value;
/* 487 */             AnnotationAttributes[] mappedAnnotations = new AnnotationAttributes[realAnnotations.length];
/* 488 */             for (int i = 0; i < realAnnotations.length; i++) {
/* 489 */               mappedAnnotations[i] = getAnnotationAttributes(realAnnotations[i], classValuesAsString, nestedAnnotationsAsMap);
/*     */             }
/*     */ 
/* 492 */             attrs.put(method.getName(), mappedAnnotations);
/*     */           }
/*     */           else {
/* 495 */             attrs.put(method.getName(), value);
/*     */           }
/*     */         }
/*     */         catch (Exception ex) {
/* 499 */           throw new IllegalStateException("Could not obtain annotation attribute values", ex);
/*     */         }
/*     */       }
/*     */     }
/* 503 */     return attrs;
/*     */   }
/*     */ 
/*     */   public static Object getValue(Annotation annotation)
/*     */   {
/* 514 */     return getValue(annotation, "value");
/*     */   }
/*     */ 
/*     */   public static Object getValue(Annotation annotation, String attributeName)
/*     */   {
/*     */     try
/*     */     {
/* 526 */       Method method = annotation.annotationType().getDeclaredMethod(attributeName, new Class[0]);
/* 527 */       ReflectionUtils.makeAccessible(method);
/* 528 */       return method.invoke(annotation, new Object[0]);
/*     */     } catch (Exception ex) {
/*     */     }
/* 531 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object getDefaultValue(Annotation annotation)
/*     */   {
/* 543 */     return getDefaultValue(annotation, "value");
/*     */   }
/*     */ 
/*     */   public static Object getDefaultValue(Annotation annotation, String attributeName)
/*     */   {
/* 554 */     return getDefaultValue(annotation.annotationType(), attributeName);
/*     */   }
/*     */ 
/*     */   public static Object getDefaultValue(Class<? extends Annotation> annotationType)
/*     */   {
/* 565 */     return getDefaultValue(annotationType, "value");
/*     */   }
/*     */ 
/*     */   public static Object getDefaultValue(Class<? extends Annotation> annotationType, String attributeName)
/*     */   {
/*     */     try
/*     */     {
/* 577 */       Method method = annotationType.getDeclaredMethod(attributeName, new Class[0]);
/* 578 */       return method.getDefaultValue();
/*     */     } catch (Exception ex) {
/*     */     }
/* 581 */     return null;
/*     */   }
/*     */ 
/*     */   private static class AnnotationCollector<A extends Annotation>
/*     */   {
/*     */     private final Class<? extends Annotation> containerAnnotationType;
/*     */     private final Class<A> annotationType;
/* 592 */     private final Set<AnnotatedElement> visited = new HashSet();
/*     */ 
/* 594 */     private final Set<A> result = new LinkedHashSet();
/*     */ 
/*     */     public AnnotationCollector(Class<? extends Annotation> containerAnnotationType, Class<A> annotationType)
/*     */     {
/* 599 */       this.containerAnnotationType = containerAnnotationType;
/* 600 */       this.annotationType = annotationType;
/*     */     }
/*     */ 
/*     */     public Set<A> getResult(AnnotatedElement element)
/*     */     {
/* 605 */       process(element);
/* 606 */       return Collections.unmodifiableSet(this.result);
/*     */     }
/*     */ 
/*     */     private void process(AnnotatedElement annotatedElement)
/*     */     {
/* 611 */       if (this.visited.add(annotatedElement))
/* 612 */         for (Annotation annotation : annotatedElement.getAnnotations())
/* 613 */           if (ObjectUtils.nullSafeEquals(this.annotationType, annotation.annotationType())) {
/* 614 */             this.result.add(annotation);
/*     */           }
/* 616 */           else if (ObjectUtils.nullSafeEquals(this.containerAnnotationType, annotation.annotationType())) {
/* 617 */             this.result.addAll(Arrays.asList(getValue(annotation)));
/*     */           }
/*     */           else
/* 620 */             process(annotation.annotationType());
/*     */     }
/*     */ 
/*     */     private A[] getValue(Annotation annotation)
/*     */     {
/*     */       try
/*     */       {
/* 629 */         Method method = annotation.annotationType().getDeclaredMethod("value", new Class[0]);
/* 630 */         ReflectionUtils.makeAccessible(method);
/* 631 */         return (Annotation[])method.invoke(annotation, new Object[0]);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 635 */         throw new IllegalStateException("Unable to read value from repeating annotation container " + this.containerAnnotationType
/* 635 */           .getName(), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.annotation.AnnotationUtils
 * JD-Core Version:    0.6.2
 */