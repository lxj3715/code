/*    */ package org.springframework.core.convert;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public abstract class ConversionException extends NestedRuntimeException
/*    */ {
/*    */   public ConversionException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConversionException(String message, Throwable cause)
/*    */   {
/* 44 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.ConversionException
 * JD-Core Version:    0.6.2
 */