/*    */ package org.springframework.core.convert;
/*    */ 
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ public final class ConversionFailedException extends ConversionException
/*    */ {
/*    */   private final TypeDescriptor sourceType;
/*    */   private final TypeDescriptor targetType;
/*    */   private final Object value;
/*    */ 
/*    */   public ConversionFailedException(TypeDescriptor sourceType, TypeDescriptor targetType, Object value, Throwable cause)
/*    */   {
/* 46 */     super("Failed to convert from type " + sourceType + " to type " + targetType + " for value '" + ObjectUtils.nullSafeToString(value) + "'", cause);
/* 47 */     this.sourceType = sourceType;
/* 48 */     this.targetType = targetType;
/* 49 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public TypeDescriptor getSourceType()
/*    */   {
/* 57 */     return this.sourceType;
/*    */   }
/*    */ 
/*    */   public TypeDescriptor getTargetType()
/*    */   {
/* 64 */     return this.targetType;
/*    */   }
/*    */ 
/*    */   public Object getValue()
/*    */   {
/* 71 */     return this.value;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.ConversionFailedException
 * JD-Core Version:    0.6.2
 */