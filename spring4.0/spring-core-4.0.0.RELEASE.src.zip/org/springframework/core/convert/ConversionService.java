package org.springframework.core.convert;

public abstract interface ConversionService
{
  public abstract boolean canConvert(Class<?> paramClass1, Class<?> paramClass2);

  public abstract boolean canConvert(TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);

  public abstract <T> T convert(Object paramObject, Class<T> paramClass);

  public abstract Object convert(Object paramObject, TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.ConversionService
 * JD-Core Version:    0.6.2
 */