/*    */ package org.springframework.core.convert;
/*    */ 
/*    */ public final class ConverterNotFoundException extends ConversionException
/*    */ {
/*    */   private final TypeDescriptor sourceType;
/*    */   private final TypeDescriptor targetType;
/*    */ 
/*    */   public ConverterNotFoundException(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 39 */     super("No converter found capable of converting from type " + sourceType + " to type " + targetType);
/* 40 */     this.sourceType = sourceType;
/* 41 */     this.targetType = targetType;
/*    */   }
/*    */ 
/*    */   public TypeDescriptor getSourceType()
/*    */   {
/* 49 */     return this.sourceType;
/*    */   }
/*    */ 
/*    */   public TypeDescriptor getTargetType()
/*    */   {
/* 56 */     return this.targetType;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.ConverterNotFoundException
 * JD-Core Version:    0.6.2
 */