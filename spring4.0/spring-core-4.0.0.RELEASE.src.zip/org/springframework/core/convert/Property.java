/*     */ package org.springframework.core.convert;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public final class Property
/*     */ {
/*  50 */   private static Map<Property, Annotation[]> annotationCache = new ConcurrentReferenceHashMap();
/*     */   private final Class<?> objectType;
/*     */   private final Method readMethod;
/*     */   private final Method writeMethod;
/*     */   private final String name;
/*     */   private final MethodParameter methodParameter;
/*     */   private Annotation[] annotations;
/*     */ 
/*     */   public Property(Class<?> objectType, Method readMethod, Method writeMethod)
/*     */   {
/*  66 */     this(objectType, readMethod, writeMethod, null);
/*     */   }
/*     */ 
/*     */   public Property(Class<?> objectType, Method readMethod, Method writeMethod, String name) {
/*  70 */     this.objectType = objectType;
/*  71 */     this.readMethod = readMethod;
/*  72 */     this.writeMethod = writeMethod;
/*  73 */     this.methodParameter = resolveMethodParameter();
/*  74 */     this.name = (name == null ? resolveName() : name);
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/*  82 */     return this.objectType;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  89 */     return this.name;
/*     */   }
/*     */ 
/*     */   public Class<?> getType()
/*     */   {
/*  96 */     return this.methodParameter.getParameterType();
/*     */   }
/*     */ 
/*     */   public Method getReadMethod()
/*     */   {
/* 103 */     return this.readMethod;
/*     */   }
/*     */ 
/*     */   public Method getWriteMethod()
/*     */   {
/* 110 */     return this.writeMethod;
/*     */   }
/*     */ 
/*     */   MethodParameter getMethodParameter()
/*     */   {
/* 117 */     return this.methodParameter;
/*     */   }
/*     */ 
/*     */   Annotation[] getAnnotations() {
/* 121 */     if (this.annotations == null) {
/* 122 */       this.annotations = resolveAnnotations();
/*     */     }
/* 124 */     return this.annotations;
/*     */   }
/*     */ 
/*     */   private String resolveName()
/*     */   {
/* 131 */     if (this.readMethod != null) {
/* 132 */       int index = this.readMethod.getName().indexOf("get");
/* 133 */       if (index != -1) {
/* 134 */         index += 3;
/*     */       }
/*     */       else {
/* 137 */         index = this.readMethod.getName().indexOf("is");
/* 138 */         if (index == -1) {
/* 139 */           throw new IllegalArgumentException("Not a getter method");
/*     */         }
/* 141 */         index += 2;
/*     */       }
/* 143 */       return StringUtils.uncapitalize(this.readMethod.getName().substring(index));
/*     */     }
/*     */ 
/* 146 */     int index = this.writeMethod.getName().indexOf("set") + 3;
/* 147 */     if (index == -1) {
/* 148 */       throw new IllegalArgumentException("Not a setter method");
/*     */     }
/* 150 */     return StringUtils.uncapitalize(this.writeMethod.getName().substring(index));
/*     */   }
/*     */ 
/*     */   private MethodParameter resolveMethodParameter()
/*     */   {
/* 155 */     MethodParameter read = resolveReadMethodParameter();
/* 156 */     MethodParameter write = resolveWriteMethodParameter();
/* 157 */     if (write == null) {
/* 158 */       if (read == null) {
/* 159 */         throw new IllegalStateException("Property is neither readable nor writeable");
/*     */       }
/* 161 */       return read;
/*     */     }
/* 163 */     if (read != null) {
/* 164 */       Class readType = read.getParameterType();
/* 165 */       Class writeType = write.getParameterType();
/* 166 */       if ((!writeType.equals(readType)) && (writeType.isAssignableFrom(readType))) {
/* 167 */         return read;
/*     */       }
/*     */     }
/* 170 */     return write;
/*     */   }
/*     */ 
/*     */   private MethodParameter resolveReadMethodParameter() {
/* 174 */     if (getReadMethod() == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     return resolveParameterType(new MethodParameter(getReadMethod(), -1));
/*     */   }
/*     */ 
/*     */   private MethodParameter resolveWriteMethodParameter() {
/* 181 */     if (getWriteMethod() == null) {
/* 182 */       return null;
/*     */     }
/* 184 */     return resolveParameterType(new MethodParameter(getWriteMethod(), 0));
/*     */   }
/*     */ 
/*     */   private MethodParameter resolveParameterType(MethodParameter parameter)
/*     */   {
/* 189 */     GenericTypeResolver.resolveParameterType(parameter, getObjectType());
/* 190 */     return parameter;
/*     */   }
/*     */ 
/*     */   private Annotation[] resolveAnnotations() {
/* 194 */     Annotation[] annotations = (Annotation[])annotationCache.get(this);
/* 195 */     if (annotations == null) {
/* 196 */       Map annotationMap = new LinkedHashMap();
/* 197 */       addAnnotationsToMap(annotationMap, getReadMethod());
/* 198 */       addAnnotationsToMap(annotationMap, getWriteMethod());
/* 199 */       addAnnotationsToMap(annotationMap, getField());
/* 200 */       annotations = (Annotation[])annotationMap.values().toArray(new Annotation[annotationMap.size()]);
/* 201 */       annotationCache.put(this, annotations);
/*     */     }
/* 203 */     return annotations;
/*     */   }
/*     */ 
/*     */   private void addAnnotationsToMap(Map<Class<? extends Annotation>, Annotation> annotationMap, AnnotatedElement object)
/*     */   {
/* 209 */     if (object != null)
/* 210 */       for (Annotation annotation : object.getAnnotations())
/* 211 */         annotationMap.put(annotation.annotationType(), annotation);
/*     */   }
/*     */ 
/*     */   private Field getField()
/*     */   {
/* 217 */     String name = getName();
/* 218 */     if (!StringUtils.hasLength(name)) {
/* 219 */       return null;
/*     */     }
/* 221 */     Class declaringClass = declaringClass();
/* 222 */     Field field = ReflectionUtils.findField(declaringClass, name);
/* 223 */     if (field == null)
/*     */     {
/* 225 */       field = ReflectionUtils.findField(declaringClass, name
/* 226 */         .substring(0, 1)
/* 226 */         .toLowerCase() + name.substring(1));
/* 227 */       if (field == null) {
/* 228 */         field = ReflectionUtils.findField(declaringClass, name
/* 229 */           .substring(0, 1)
/* 229 */           .toUpperCase() + name.substring(1));
/*     */       }
/*     */     }
/* 232 */     return field;
/*     */   }
/*     */ 
/*     */   private Class<?> declaringClass() {
/* 236 */     if (getReadMethod() != null) {
/* 237 */       return getReadMethod().getDeclaringClass();
/*     */     }
/*     */ 
/* 240 */     return getWriteMethod().getDeclaringClass();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 246 */     int prime = 31;
/* 247 */     int hashCode = 1;
/* 248 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.objectType);
/* 249 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.readMethod);
/* 250 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.writeMethod);
/* 251 */     hashCode = 31 * hashCode + ObjectUtils.nullSafeHashCode(this.name);
/* 252 */     return hashCode;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 257 */     if (this == obj) {
/* 258 */       return true;
/*     */     }
/* 260 */     if (obj == null) {
/* 261 */       return false;
/*     */     }
/* 263 */     if (getClass() != obj.getClass()) {
/* 264 */       return false;
/*     */     }
/* 266 */     Property other = (Property)obj;
/* 267 */     boolean equals = true;
/* 268 */     equals &= ObjectUtils.nullSafeEquals(this.objectType, other.objectType);
/* 269 */     equals &= ObjectUtils.nullSafeEquals(this.readMethod, other.readMethod);
/* 270 */     equals &= ObjectUtils.nullSafeEquals(this.writeMethod, other.writeMethod);
/* 271 */     equals &= ObjectUtils.nullSafeEquals(this.name, other.name);
/* 272 */     return equals;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.Property
 * JD-Core Version:    0.6.2
 */