/*     */ package org.springframework.core.convert;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class TypeDescriptor
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  48 */   static final Annotation[] EMPTY_ANNOTATION_ARRAY = new Annotation[0];
/*     */ 
/*  50 */   private static final Map<Class<?>, TypeDescriptor> commonTypesCache = new HashMap();
/*     */ 
/*  52 */   private static final Class<?>[] CACHED_COMMON_TYPES = { Boolean.class, Byte.TYPE, Byte.class, Character.TYPE, Character.class, Short.TYPE, Short.class, Integer.TYPE, Integer.class, Long.TYPE, Long.class, Float.TYPE, Float.class, Double.TYPE, Double.class, String.class };
/*     */   private final Class<?> type;
/*     */   private final ResolvableType resolvableType;
/*     */   private final Annotation[] annotations;
/*     */ 
/*     */   public TypeDescriptor(MethodParameter methodParameter)
/*     */   {
/*  77 */     Assert.notNull(methodParameter, "MethodParameter must not be null");
/*  78 */     if (methodParameter.getNestingLevel() != 1) {
/*  79 */       throw new IllegalArgumentException("MethodParameter argument must have its nestingLevel set to 1");
/*     */     }
/*  81 */     this.resolvableType = ResolvableType.forMethodParameter(methodParameter);
/*  82 */     this.type = this.resolvableType.resolve(Object.class);
/*  83 */     this.annotations = (methodParameter.getParameterIndex() == -1 ? 
/*  84 */       nullSafeAnnotations(methodParameter
/*  84 */       .getMethodAnnotations()) : 
/*  85 */       nullSafeAnnotations(methodParameter
/*  85 */       .getParameterAnnotations()));
/*     */   }
/*     */ 
/*     */   public TypeDescriptor(Field field)
/*     */   {
/*  94 */     Assert.notNull(field, "Field must not be null");
/*  95 */     this.resolvableType = ResolvableType.forField(field);
/*  96 */     this.type = this.resolvableType.resolve(Object.class);
/*  97 */     this.annotations = nullSafeAnnotations(field.getAnnotations());
/*     */   }
/*     */ 
/*     */   public TypeDescriptor(Property property)
/*     */   {
/* 107 */     Assert.notNull(property, "Property must not be null");
/* 108 */     this.resolvableType = ResolvableType.forMethodParameter(property.getMethodParameter());
/* 109 */     this.type = this.resolvableType.resolve(Object.class);
/* 110 */     this.annotations = nullSafeAnnotations(property.getAnnotations());
/*     */   }
/*     */ 
/*     */   private TypeDescriptor(ResolvableType resolvableType, Class<?> type, Annotation[] annotations) {
/* 114 */     this.resolvableType = resolvableType;
/* 115 */     this.type = (type != null ? type : resolvableType.resolve(Object.class));
/* 116 */     this.annotations = nullSafeAnnotations(annotations);
/*     */   }
/*     */ 
/*     */   private Annotation[] nullSafeAnnotations(Annotation[] annotations)
/*     */   {
/* 121 */     return annotations != null ? annotations : EMPTY_ANNOTATION_ARRAY;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 130 */     return ClassUtils.resolvePrimitiveIfNecessary(getType());
/*     */   }
/*     */ 
/*     */   public Class<?> getType()
/*     */   {
/* 142 */     return this.type;
/*     */   }
/*     */ 
/*     */   public Object getSource()
/*     */   {
/* 152 */     return this.resolvableType == null ? null : this.resolvableType.getSource();
/*     */   }
/*     */ 
/*     */   public TypeDescriptor narrow(Object value)
/*     */   {
/* 167 */     if (value == null) {
/* 168 */       return this;
/*     */     }
/* 170 */     ResolvableType narrowed = ResolvableType.forType(value.getClass(), this.resolvableType);
/* 171 */     return new TypeDescriptor(narrowed, null, this.annotations);
/*     */   }
/*     */ 
/*     */   public TypeDescriptor upcast(Class<?> superType)
/*     */   {
/* 183 */     if (superType == null) {
/* 184 */       return null;
/*     */     }
/* 186 */     Assert.isAssignable(superType, getType());
/* 187 */     return new TypeDescriptor(this.resolvableType.as(superType), superType, this.annotations);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 194 */     return ClassUtils.getQualifiedName(getType());
/*     */   }
/*     */ 
/*     */   public boolean isPrimitive()
/*     */   {
/* 201 */     return getType().isPrimitive();
/*     */   }
/*     */ 
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 209 */     return this.annotations;
/*     */   }
/*     */ 
/*     */   public boolean hasAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 218 */     return getAnnotation(annotationType) != null;
/*     */   }
/*     */ 
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType)
/*     */   {
/* 228 */     for (Annotation annotation : getAnnotations()) {
/* 229 */       if (annotation.annotationType().equals(annotationType)) {
/* 230 */         return annotation;
/*     */       }
/*     */     }
/* 233 */     for (Annotation metaAnn : getAnnotations()) {
/* 234 */       Annotation ann = metaAnn.annotationType().getAnnotation(annotationType);
/* 235 */       if (ann != null) {
/* 236 */         return ann;
/*     */       }
/*     */     }
/* 239 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isAssignableTo(TypeDescriptor typeDescriptor)
/*     */   {
/* 253 */     boolean typesAssignable = typeDescriptor.getObjectType().isAssignableFrom(getObjectType());
/* 254 */     if (!typesAssignable) {
/* 255 */       return false;
/*     */     }
/* 257 */     if ((isArray()) && (typeDescriptor.isArray())) {
/* 258 */       return getElementTypeDescriptor().isAssignableTo(typeDescriptor.getElementTypeDescriptor());
/*     */     }
/* 260 */     if ((isCollection()) && (typeDescriptor.isCollection())) {
/* 261 */       return isNestedAssignable(getElementTypeDescriptor(), typeDescriptor.getElementTypeDescriptor());
/*     */     }
/* 263 */     if ((isMap()) && (typeDescriptor.isMap()))
/*     */     {
/* 265 */       return (isNestedAssignable(getMapKeyTypeDescriptor(), typeDescriptor.getMapKeyTypeDescriptor())) && 
/* 265 */         (isNestedAssignable(getMapValueTypeDescriptor(), typeDescriptor.getMapValueTypeDescriptor()));
/*     */     }
/*     */ 
/* 268 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean isNestedAssignable(TypeDescriptor nestedTypeDescriptor, TypeDescriptor otherNestedTypeDescriptor)
/*     */   {
/* 273 */     if ((nestedTypeDescriptor == null) || (otherNestedTypeDescriptor == null)) {
/* 274 */       return true;
/*     */     }
/* 276 */     return nestedTypeDescriptor.isAssignableTo(otherNestedTypeDescriptor);
/*     */   }
/*     */ 
/*     */   public boolean isCollection()
/*     */   {
/* 283 */     return Collection.class.isAssignableFrom(getType());
/*     */   }
/*     */ 
/*     */   public boolean isArray()
/*     */   {
/* 290 */     return getType().isArray();
/*     */   }
/*     */ 
/*     */   public TypeDescriptor getElementTypeDescriptor()
/*     */   {
/* 301 */     assertCollectionOrArray();
/* 302 */     if (this.resolvableType.isArray()) {
/* 303 */       return getRelatedIfResolvable(this, this.resolvableType.getComponentType());
/*     */     }
/* 305 */     return getRelatedIfResolvable(this, this.resolvableType.asCollection().getGeneric(new int[0]));
/*     */   }
/*     */ 
/*     */   public TypeDescriptor elementTypeDescriptor(Object element)
/*     */   {
/* 321 */     return narrow(element, getElementTypeDescriptor());
/*     */   }
/*     */ 
/*     */   public boolean isMap()
/*     */   {
/* 328 */     return Map.class.isAssignableFrom(getType());
/*     */   }
/*     */ 
/*     */   public TypeDescriptor getMapKeyTypeDescriptor()
/*     */   {
/* 338 */     assertMap();
/* 339 */     return getRelatedIfResolvable(this, this.resolvableType.asMap().getGeneric(new int[] { 0 }));
/*     */   }
/*     */ 
/*     */   public TypeDescriptor getMapKeyTypeDescriptor(Object mapKey)
/*     */   {
/* 354 */     return narrow(mapKey, getMapKeyTypeDescriptor());
/*     */   }
/*     */ 
/*     */   public TypeDescriptor getMapValueTypeDescriptor()
/*     */   {
/* 364 */     assertMap();
/* 365 */     return getRelatedIfResolvable(this, this.resolvableType.asMap().getGeneric(new int[] { 1 }));
/*     */   }
/*     */ 
/*     */   public TypeDescriptor getMapValueTypeDescriptor(Object mapValue)
/*     */   {
/* 379 */     return narrow(mapValue, getMapValueTypeDescriptor());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Class<?> getElementType()
/*     */   {
/* 389 */     return getType(getElementTypeDescriptor());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Class<?> getMapKeyType()
/*     */   {
/* 399 */     return getType(getMapKeyTypeDescriptor());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Class<?> getMapValueType()
/*     */   {
/* 409 */     return getType(getMapValueTypeDescriptor());
/*     */   }
/*     */ 
/*     */   private Class<?> getType(TypeDescriptor typeDescriptor) {
/* 413 */     return typeDescriptor == null ? null : typeDescriptor.getType();
/*     */   }
/*     */ 
/*     */   private void assertCollectionOrArray() {
/* 417 */     if ((!isCollection()) && (!isArray()))
/* 418 */       throw new IllegalStateException("Not a java.util.Collection or Array");
/*     */   }
/*     */ 
/*     */   private void assertMap()
/*     */   {
/* 423 */     if (!isMap())
/* 424 */       throw new IllegalStateException("Not a java.util.Map");
/*     */   }
/*     */ 
/*     */   private TypeDescriptor narrow(Object value, TypeDescriptor typeDescriptor)
/*     */   {
/* 429 */     if (typeDescriptor != null) {
/* 430 */       return typeDescriptor.narrow(value);
/*     */     }
/* 432 */     return value != null ? new TypeDescriptor(this.resolvableType, value.getClass(), this.annotations) : null;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 437 */     if (this == obj) {
/* 438 */       return true;
/*     */     }
/* 440 */     if (!(obj instanceof TypeDescriptor)) {
/* 441 */       return false;
/*     */     }
/* 443 */     TypeDescriptor other = (TypeDescriptor)obj;
/* 444 */     if (!ObjectUtils.nullSafeEquals(this.type, other.type)) {
/* 445 */       return false;
/*     */     }
/* 447 */     if (getAnnotations().length != other.getAnnotations().length) {
/* 448 */       return false;
/*     */     }
/* 450 */     for (Annotation ann : getAnnotations()) {
/* 451 */       if (other.getAnnotation(ann.annotationType()) == null) {
/* 452 */         return false;
/*     */       }
/*     */     }
/* 455 */     if ((isCollection()) || (isArray())) {
/* 456 */       return ObjectUtils.nullSafeEquals(getElementTypeDescriptor(), other.getElementTypeDescriptor());
/*     */     }
/* 458 */     if (isMap())
/*     */     {
/* 460 */       return (ObjectUtils.nullSafeEquals(getMapKeyTypeDescriptor(), other.getMapKeyTypeDescriptor())) && 
/* 460 */         (ObjectUtils.nullSafeEquals(getMapValueTypeDescriptor(), other.getMapValueTypeDescriptor()));
/*     */     }
/*     */ 
/* 463 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 469 */     return getType().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 474 */     StringBuilder builder = new StringBuilder();
/* 475 */     for (Annotation ann : getAnnotations()) {
/* 476 */       builder.append("@").append(ann.annotationType().getName()).append(' ');
/*     */     }
/* 478 */     builder.append(this.resolvableType.toString());
/* 479 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public static TypeDescriptor valueOf(Class<?> type)
/*     */   {
/* 493 */     Assert.notNull(type, "Type must not be null");
/* 494 */     TypeDescriptor desc = (TypeDescriptor)commonTypesCache.get(type);
/* 495 */     return desc != null ? desc : new TypeDescriptor(ResolvableType.forClass(type), null, null);
/*     */   }
/*     */ 
/*     */   public static TypeDescriptor collection(Class<?> collectionType, TypeDescriptor elementTypeDescriptor)
/*     */   {
/* 511 */     Assert.notNull(collectionType, "CollectionType must not be null");
/* 512 */     if (!Collection.class.isAssignableFrom(collectionType)) {
/* 513 */       throw new IllegalArgumentException("collectionType must be a java.util.Collection");
/*     */     }
/* 515 */     ResolvableType element = elementTypeDescriptor == null ? null : elementTypeDescriptor.resolvableType;
/*     */ 
/* 517 */     return new TypeDescriptor(ResolvableType.forClassWithGenerics(collectionType, new ResolvableType[] { element }), null, null);
/*     */   }
/*     */ 
/*     */   public static TypeDescriptor map(Class<?> mapType, TypeDescriptor keyTypeDescriptor, TypeDescriptor valueTypeDescriptor)
/*     */   {
/* 532 */     if (!Map.class.isAssignableFrom(mapType)) {
/* 533 */       throw new IllegalArgumentException("mapType must be a java.util.Map");
/*     */     }
/* 535 */     ResolvableType key = keyTypeDescriptor == null ? null : keyTypeDescriptor.resolvableType;
/* 536 */     ResolvableType value = valueTypeDescriptor == null ? null : valueTypeDescriptor.resolvableType;
/* 537 */     return new TypeDescriptor(ResolvableType.forClassWithGenerics(mapType, new ResolvableType[] { key, value }), null, null);
/*     */   }
/*     */ 
/*     */   public static TypeDescriptor array(TypeDescriptor elementTypeDescriptor)
/*     */   {
/* 549 */     if (elementTypeDescriptor == null) {
/* 550 */       return null;
/*     */     }
/*     */ 
/* 554 */     return new TypeDescriptor(
/* 553 */       ResolvableType.forArrayComponent(elementTypeDescriptor.resolvableType), 
/* 553 */       null, elementTypeDescriptor
/* 554 */       .getAnnotations());
/*     */   }
/*     */ 
/*     */   public static TypeDescriptor nested(MethodParameter methodParameter, int nestingLevel)
/*     */   {
/* 581 */     if (methodParameter.getNestingLevel() != 1) {
/* 582 */       throw new IllegalArgumentException("methodParameter nesting level must be 1: use the nestingLevel parameter to specify the desired nestingLevel for nested type traversal");
/*     */     }
/* 584 */     return nested(new TypeDescriptor(methodParameter), nestingLevel);
/*     */   }
/*     */ 
/*     */   public static TypeDescriptor nested(Field field, int nestingLevel)
/*     */   {
/* 608 */     return nested(new TypeDescriptor(field), nestingLevel);
/*     */   }
/*     */ 
/*     */   public static TypeDescriptor nested(Property property, int nestingLevel)
/*     */   {
/* 633 */     return nested(new TypeDescriptor(property), nestingLevel);
/*     */   }
/*     */ 
/*     */   public static TypeDescriptor forObject(Object source)
/*     */   {
/* 644 */     return source != null ? valueOf(source.getClass()) : null;
/*     */   }
/*     */ 
/*     */   private static TypeDescriptor nested(TypeDescriptor typeDescriptor, int nestingLevel) {
/* 648 */     ResolvableType nested = typeDescriptor.resolvableType;
/* 649 */     for (int i = 0; i < nestingLevel; i++) {
/* 650 */       if (!Object.class.equals(nested.getType()))
/*     */       {
/* 654 */         nested = nested.getNested(2);
/*     */       }
/*     */     }
/* 657 */     Assert.state(nested != ResolvableType.NONE, new StringBuilder().append("Unable to obtain nested generic from ").append(typeDescriptor).append(" at level ").append(nestingLevel).toString());
/*     */ 
/* 659 */     return getRelatedIfResolvable(typeDescriptor, nested);
/*     */   }
/*     */ 
/*     */   private static TypeDescriptor getRelatedIfResolvable(TypeDescriptor source, ResolvableType type) {
/* 663 */     if (type.resolve() == null) {
/* 664 */       return null;
/*     */     }
/* 666 */     return new TypeDescriptor(type, null, source.annotations);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  57 */     for (Class preCachedClass : CACHED_COMMON_TYPES)
/*  58 */       commonTypesCache.put(preCachedClass, valueOf(preCachedClass));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.TypeDescriptor
 * JD-Core Version:    0.6.2
 */