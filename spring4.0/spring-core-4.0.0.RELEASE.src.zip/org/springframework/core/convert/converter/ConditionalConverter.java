package org.springframework.core.convert.converter;

import org.springframework.core.convert.TypeDescriptor;

public abstract interface ConditionalConverter
{
  public abstract boolean matches(TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.converter.ConditionalConverter
 * JD-Core Version:    0.6.2
 */