package org.springframework.core.convert.converter;

public abstract interface ConditionalGenericConverter extends GenericConverter, ConditionalConverter
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.converter.ConditionalGenericConverter
 * JD-Core Version:    0.6.2
 */