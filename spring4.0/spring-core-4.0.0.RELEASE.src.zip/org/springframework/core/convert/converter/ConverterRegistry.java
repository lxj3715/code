package org.springframework.core.convert.converter;

public abstract interface ConverterRegistry
{
  public abstract void addConverter(Converter<?, ?> paramConverter);

  public abstract void addConverter(Class<?> paramClass1, Class<?> paramClass2, Converter<?, ?> paramConverter);

  public abstract void addConverter(GenericConverter paramGenericConverter);

  public abstract void addConverterFactory(ConverterFactory<?, ?> paramConverterFactory);

  public abstract void removeConvertible(Class<?> paramClass1, Class<?> paramClass2);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.converter.ConverterRegistry
 * JD-Core Version:    0.6.2
 */