/*     */ package org.springframework.core.convert.converter;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract interface GenericConverter
/*     */ {
/*     */   public abstract Set<ConvertiblePair> getConvertibleTypes();
/*     */ 
/*     */   public abstract Object convert(Object paramObject, TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);
/*     */ 
/*     */   public static final class ConvertiblePair
/*     */   {
/*     */     private final Class<?> sourceType;
/*     */     private final Class<?> targetType;
/*     */ 
/*     */     public ConvertiblePair(Class<?> sourceType, Class<?> targetType)
/*     */     {
/*  83 */       Assert.notNull(sourceType, "Source type must not be null");
/*  84 */       Assert.notNull(targetType, "Target type must not be null");
/*  85 */       this.sourceType = sourceType;
/*  86 */       this.targetType = targetType;
/*     */     }
/*     */ 
/*     */     public Class<?> getSourceType() {
/*  90 */       return this.sourceType;
/*     */     }
/*     */ 
/*     */     public Class<?> getTargetType() {
/*  94 */       return this.targetType;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/*  99 */       if (this == obj) {
/* 100 */         return true;
/*     */       }
/* 102 */       if ((obj == null) || (obj.getClass() != ConvertiblePair.class)) {
/* 103 */         return false;
/*     */       }
/* 105 */       ConvertiblePair other = (ConvertiblePair)obj;
/* 106 */       return (this.sourceType.equals(other.sourceType)) && (this.targetType.equals(other.targetType));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 112 */       return this.sourceType.hashCode() * 31 + this.targetType.hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.converter.GenericConverter
 * JD-Core Version:    0.6.2
 */