/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ final class ArrayToArrayConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final CollectionToArrayConverter helperConverter;
/*    */   private final ConversionService conversionService;
/*    */ 
/*    */   public ArrayToArrayConverter(ConversionService conversionService)
/*    */   {
/* 44 */     this.helperConverter = new CollectionToArrayConverter(conversionService);
/* 45 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 50 */     return Collections.singleton(new GenericConverter.ConvertiblePair([Ljava.lang.Object.class, [Ljava.lang.Object.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 55 */     return this.helperConverter.matches(sourceType, targetType);
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 61 */     if (((this.conversionService instanceof GenericConversionService)) && 
/* 62 */       (((GenericConversionService)this.conversionService)
/* 62 */       .canBypassConvert(sourceType
/* 63 */       .getElementTypeDescriptor(), targetType
/* 64 */       .getElementTypeDescriptor()))) {
/* 65 */       return source;
/*    */     }
/* 67 */     List sourceList = Arrays.asList(ObjectUtils.toObjectArray(source));
/* 68 */     return this.helperConverter.convert(sourceList, sourceType, targetType);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ArrayToArrayConverter
 * JD-Core Version:    0.6.2
 */