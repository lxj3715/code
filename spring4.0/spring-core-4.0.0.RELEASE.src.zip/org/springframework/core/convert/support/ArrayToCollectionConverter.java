/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.CollectionFactory;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ 
/*    */ final class ArrayToCollectionConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */ 
/*    */   public ArrayToCollectionConverter(ConversionService conversionService)
/*    */   {
/* 44 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 49 */     return Collections.singleton(new GenericConverter.ConvertiblePair([Ljava.lang.Object.class, Collection.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 54 */     return ConversionUtils.canConvertElements(sourceType
/* 55 */       .getElementTypeDescriptor(), targetType.getElementTypeDescriptor(), this.conversionService);
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 60 */     if (source == null) {
/* 61 */       return null;
/*    */     }
/* 63 */     int length = Array.getLength(source);
/* 64 */     Collection target = CollectionFactory.createCollection(targetType.getType(), length);
/* 65 */     if (targetType.getElementTypeDescriptor() == null) {
/* 66 */       for (int i = 0; i < length; i++) {
/* 67 */         Object sourceElement = Array.get(source, i);
/* 68 */         target.add(sourceElement);
/*    */       }
/*    */     }
/*    */     else {
/* 72 */       for (int i = 0; i < length; i++) {
/* 73 */         Object sourceElement = Array.get(source, i);
/* 74 */         Object targetElement = this.conversionService.convert(sourceElement, sourceType
/* 75 */           .elementTypeDescriptor(sourceElement), 
/* 75 */           targetType.getElementTypeDescriptor());
/* 76 */         target.add(targetElement);
/*    */       }
/*    */     }
/* 79 */     return target;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ArrayToCollectionConverter
 * JD-Core Version:    0.6.2
 */