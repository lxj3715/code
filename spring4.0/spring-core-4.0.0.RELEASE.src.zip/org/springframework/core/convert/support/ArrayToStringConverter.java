/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ final class ArrayToStringConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final CollectionToStringConverter helperConverter;
/*    */ 
/*    */   public ArrayToStringConverter(ConversionService conversionService)
/*    */   {
/* 40 */     this.helperConverter = new CollectionToStringConverter(conversionService);
/*    */   }
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 45 */     return Collections.singleton(new GenericConverter.ConvertiblePair([Ljava.lang.Object.class, String.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 50 */     return this.helperConverter.matches(sourceType, targetType);
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 55 */     return this.helperConverter.convert(Arrays.asList(ObjectUtils.toObjectArray(source)), sourceType, targetType);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ArrayToStringConverter
 * JD-Core Version:    0.6.2
 */