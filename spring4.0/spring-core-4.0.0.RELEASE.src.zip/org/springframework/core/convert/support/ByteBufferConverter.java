/*     */ package org.springframework.core.convert.support;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ 
/*     */ final class ByteBufferConverter
/*     */   implements ConditionalGenericConverter
/*     */ {
/*  37 */   private static final TypeDescriptor BYTE_BUFFER_TYPE = TypeDescriptor.valueOf(ByteBuffer.class);
/*     */ 
/*  39 */   private static final TypeDescriptor BYTE_ARRAY_TYPE = TypeDescriptor.valueOf([B.class);
/*     */ 
/*  46 */   private static final Set<GenericConverter.ConvertiblePair> CONVERTIBLE_PAIRS = Collections.unmodifiableSet(convertiblePairs);
/*     */   private ConversionService conversionService;
/*     */ 
/*     */   public ByteBufferConverter(ConversionService conversionService)
/*     */   {
/*  54 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */   {
/*  60 */     return CONVERTIBLE_PAIRS;
/*     */   }
/*     */ 
/*     */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  65 */     if (sourceType.isAssignableTo(BYTE_BUFFER_TYPE)) {
/*  66 */       return matchesFromByteBuffer(targetType);
/*     */     }
/*  68 */     if (targetType.isAssignableTo(BYTE_BUFFER_TYPE)) {
/*  69 */       return matchesToByteBuffer(sourceType);
/*     */     }
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean matchesFromByteBuffer(TypeDescriptor targetType) {
/*  75 */     return (targetType.isAssignableTo(BYTE_ARRAY_TYPE)) || (this.conversionService.canConvert(BYTE_ARRAY_TYPE, targetType));
/*     */   }
/*     */ 
/*     */   private boolean matchesToByteBuffer(TypeDescriptor sourceType)
/*     */   {
/*  80 */     return (sourceType.isAssignableTo(BYTE_ARRAY_TYPE)) || (this.conversionService.canConvert(sourceType, BYTE_ARRAY_TYPE));
/*     */   }
/*     */ 
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  87 */     if (sourceType.isAssignableTo(BYTE_BUFFER_TYPE)) {
/*  88 */       return convertFromByteBuffer((ByteBuffer)source, targetType);
/*     */     }
/*  90 */     if (targetType.isAssignableTo(BYTE_BUFFER_TYPE)) {
/*  91 */       return convertToByteBuffer(source, sourceType);
/*     */     }
/*     */ 
/*  94 */     throw new IllegalStateException("Unexpected source/target types");
/*     */   }
/*     */ 
/*     */   private Object convertFromByteBuffer(ByteBuffer source, TypeDescriptor targetType) {
/*  98 */     byte[] bytes = new byte[source.remaining()];
/*  99 */     source.get(bytes);
/* 100 */     if (targetType.isAssignableTo(BYTE_ARRAY_TYPE)) {
/* 101 */       return bytes;
/*     */     }
/* 103 */     return this.conversionService.convert(bytes, BYTE_ARRAY_TYPE, targetType);
/*     */   }
/*     */ 
/*     */   private Object convertToByteBuffer(Object source, TypeDescriptor sourceType)
/*     */   {
/* 108 */     byte[] bytes = (byte[])((source instanceof byte[]) ? source : this.conversionService
/* 108 */       .convert(source, sourceType, BYTE_ARRAY_TYPE));
/*     */ 
/* 109 */     ByteBuffer byteBuffer = ByteBuffer.allocate(bytes.length);
/* 110 */     byteBuffer.put(bytes);
/* 111 */     byteBuffer.rewind();
/* 112 */     return byteBuffer;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  43 */     Set convertiblePairs = new HashSet();
/*  44 */     convertiblePairs.add(new GenericConverter.ConvertiblePair(ByteBuffer.class, Object.class));
/*  45 */     convertiblePairs.add(new GenericConverter.ConvertiblePair(Object.class, ByteBuffer.class));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ByteBufferConverter
 * JD-Core Version:    0.6.2
 */