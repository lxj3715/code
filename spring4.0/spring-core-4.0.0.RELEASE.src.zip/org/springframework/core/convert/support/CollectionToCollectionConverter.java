/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.CollectionFactory;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ 
/*    */ final class CollectionToCollectionConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */ 
/*    */   public CollectionToCollectionConverter(ConversionService conversionService)
/*    */   {
/* 44 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 49 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Collection.class, Collection.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 54 */     return ConversionUtils.canConvertElements(sourceType
/* 55 */       .getElementTypeDescriptor(), targetType.getElementTypeDescriptor(), this.conversionService);
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 60 */     if (source == null) {
/* 61 */       return null;
/*    */     }
/* 63 */     boolean copyRequired = !targetType.getType().isInstance(source);
/* 64 */     Collection sourceCollection = (Collection)source;
/* 65 */     if ((!copyRequired) && (sourceCollection.isEmpty())) {
/* 66 */       return sourceCollection;
/*    */     }
/* 68 */     Collection target = CollectionFactory.createCollection(targetType.getType(), sourceCollection.size());
/*    */     Iterator localIterator;
/* 69 */     if (targetType.getElementTypeDescriptor() == null) {
/* 70 */       for (localIterator = sourceCollection.iterator(); localIterator.hasNext(); ) { Object element = localIterator.next();
/* 71 */         target.add(element);
/*    */       }
/*    */     }
/*    */     else {
/* 75 */       for (localIterator = sourceCollection.iterator(); localIterator.hasNext(); ) { Object sourceElement = localIterator.next();
/* 76 */         Object targetElement = this.conversionService.convert(sourceElement, sourceType
/* 77 */           .elementTypeDescriptor(sourceElement), 
/* 77 */           targetType.getElementTypeDescriptor());
/* 78 */         target.add(targetElement);
/* 79 */         if (sourceElement != targetElement) {
/* 80 */           copyRequired = true;
/*    */         }
/*    */       }
/*    */     }
/* 84 */     return copyRequired ? target : source;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.CollectionToCollectionConverter
 * JD-Core Version:    0.6.2
 */