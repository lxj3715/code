package org.springframework.core.convert.support;

import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.ConverterRegistry;

public abstract interface ConfigurableConversionService extends ConversionService, ConverterRegistry
{
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ConfigurableConversionService
 * JD-Core Version:    0.6.2
 */