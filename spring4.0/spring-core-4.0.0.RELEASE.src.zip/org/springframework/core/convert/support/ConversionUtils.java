/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.ConversionFailedException;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ 
/*    */ abstract class ConversionUtils
/*    */ {
/*    */   public static Object invokeConverter(GenericConverter converter, Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/*    */     try
/*    */     {
/* 35 */       return converter.convert(source, sourceType, targetType);
/*    */     }
/*    */     catch (ConversionFailedException ex) {
/* 38 */       throw ex;
/*    */     }
/*    */     catch (Exception ex) {
/* 41 */       throw new ConversionFailedException(sourceType, targetType, source, ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static boolean canConvertElements(TypeDescriptor sourceElementType, TypeDescriptor targetElementType, ConversionService conversionService) {
/* 46 */     if (targetElementType == null)
/*    */     {
/* 48 */       return true;
/*    */     }
/* 50 */     if (sourceElementType == null)
/*    */     {
/* 52 */       return true;
/*    */     }
/* 54 */     if (conversionService.canConvert(sourceElementType, targetElementType))
/*    */     {
/* 56 */       return true;
/*    */     }
/* 58 */     if (sourceElementType.getType().isAssignableFrom(targetElementType.getType()))
/*    */     {
/* 60 */       return true;
/*    */     }
/*    */ 
/* 64 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ConversionUtils
 * JD-Core Version:    0.6.2
 */