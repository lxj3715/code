/*     */ package org.springframework.core.convert.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class DefaultConversionService extends GenericConversionService
/*     */ {
/*  42 */   private static final boolean zoneIdAvailable = ClassUtils.isPresent("java.time.ZoneId", DefaultConversionService.class
/*  42 */     .getClassLoader());
/*     */ 
/*     */   public DefaultConversionService()
/*     */   {
/*  50 */     addDefaultConverters(this);
/*     */   }
/*     */ 
/*     */   public static void addDefaultConverters(ConverterRegistry converterRegistry)
/*     */   {
/*  63 */     addScalarConverters(converterRegistry);
/*  64 */     addCollectionConverters(converterRegistry);
/*     */ 
/*  66 */     converterRegistry.addConverter(new ByteBufferConverter((ConversionService)converterRegistry));
/*  67 */     if (zoneIdAvailable) {
/*  68 */       ZoneIdConverterRegistrar.registerZoneIdConverters(converterRegistry);
/*     */     }
/*     */ 
/*  71 */     converterRegistry.addConverter(new ObjectToObjectConverter());
/*  72 */     converterRegistry.addConverter(new IdToEntityConverter((ConversionService)converterRegistry));
/*  73 */     converterRegistry.addConverter(new FallbackObjectToStringConverter());
/*     */   }
/*     */ 
/*     */   private static void addScalarConverters(ConverterRegistry converterRegistry)
/*     */   {
/*  79 */     converterRegistry.addConverterFactory(new NumberToNumberConverterFactory());
/*     */ 
/*  81 */     converterRegistry.addConverterFactory(new StringToNumberConverterFactory());
/*  82 */     converterRegistry.addConverter(Number.class, String.class, new ObjectToStringConverter());
/*     */ 
/*  84 */     converterRegistry.addConverter(new StringToCharacterConverter());
/*  85 */     converterRegistry.addConverter(Character.class, String.class, new ObjectToStringConverter());
/*     */ 
/*  87 */     converterRegistry.addConverter(new NumberToCharacterConverter());
/*  88 */     converterRegistry.addConverterFactory(new CharacterToNumberFactory());
/*     */ 
/*  90 */     converterRegistry.addConverter(new StringToBooleanConverter());
/*  91 */     converterRegistry.addConverter(Boolean.class, String.class, new ObjectToStringConverter());
/*     */ 
/*  93 */     converterRegistry.addConverterFactory(new StringToEnumConverterFactory());
/*  94 */     converterRegistry.addConverter(Enum.class, String.class, new EnumToStringConverter((ConversionService)converterRegistry));
/*     */ 
/*  97 */     converterRegistry.addConverter(new StringToLocaleConverter());
/*  98 */     converterRegistry.addConverter(Locale.class, String.class, new ObjectToStringConverter());
/*     */ 
/* 100 */     converterRegistry.addConverter(new StringToPropertiesConverter());
/* 101 */     converterRegistry.addConverter(new PropertiesToStringConverter());
/*     */ 
/* 103 */     converterRegistry.addConverter(new StringToUUIDConverter());
/* 104 */     converterRegistry.addConverter(UUID.class, String.class, new ObjectToStringConverter());
/*     */   }
/*     */ 
/*     */   private static void addCollectionConverters(ConverterRegistry converterRegistry) {
/* 108 */     ConversionService conversionService = (ConversionService)converterRegistry;
/*     */ 
/* 110 */     converterRegistry.addConverter(new ArrayToCollectionConverter(conversionService));
/* 111 */     converterRegistry.addConverter(new CollectionToArrayConverter(conversionService));
/*     */ 
/* 113 */     converterRegistry.addConverter(new ArrayToArrayConverter(conversionService));
/* 114 */     converterRegistry.addConverter(new CollectionToCollectionConverter(conversionService));
/* 115 */     converterRegistry.addConverter(new MapToMapConverter(conversionService));
/*     */ 
/* 117 */     converterRegistry.addConverter(new ArrayToStringConverter(conversionService));
/* 118 */     converterRegistry.addConverter(new StringToArrayConverter(conversionService));
/*     */ 
/* 120 */     converterRegistry.addConverter(new ArrayToObjectConverter(conversionService));
/* 121 */     converterRegistry.addConverter(new ObjectToArrayConverter(conversionService));
/*     */ 
/* 123 */     converterRegistry.addConverter(new CollectionToStringConverter(conversionService));
/* 124 */     converterRegistry.addConverter(new StringToCollectionConverter(conversionService));
/*     */ 
/* 126 */     converterRegistry.addConverter(new CollectionToObjectConverter(conversionService));
/* 127 */     converterRegistry.addConverter(new ObjectToCollectionConverter(conversionService));
/*     */   }
/*     */ 
/*     */   private static final class ZoneIdConverterRegistrar
/*     */   {
/*     */     public static void registerZoneIdConverters(ConverterRegistry converterRegistry)
/*     */     {
/* 137 */       converterRegistry.addConverter(new TimeZoneToZoneIdConverter());
/* 138 */       converterRegistry.addConverter(new ZoneIdToTimeZoneConverter());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.DefaultConversionService
 * JD-Core Version:    0.6.2
 */