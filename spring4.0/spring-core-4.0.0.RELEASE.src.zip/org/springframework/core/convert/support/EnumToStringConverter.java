/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalConverter;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ final class EnumToStringConverter
/*    */   implements Converter<Enum<?>, String>, ConditionalConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */ 
/*    */   public EnumToStringConverter(ConversionService conversionService)
/*    */   {
/* 37 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 42 */     for (Class interfaceType : ClassUtils.getAllInterfacesForClass(sourceType.getType())) {
/* 43 */       if (this.conversionService.canConvert(TypeDescriptor.valueOf(interfaceType), targetType)) {
/* 44 */         return false;
/*    */       }
/*    */     }
/* 47 */     return true;
/*    */   }
/*    */ 
/*    */   public String convert(Enum<?> source)
/*    */   {
/* 52 */     return source.name();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.EnumToStringConverter
 * JD-Core Version:    0.6.2
 */