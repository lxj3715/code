/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.io.StringWriter;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ 
/*    */ final class FallbackObjectToStringConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 40 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object.class, String.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 45 */     Class sourceClass = sourceType.getObjectType();
/* 46 */     if (String.class.equals(sourceClass)) {
/* 47 */       return false;
/*    */     }
/*    */ 
/* 50 */     return (CharSequence.class.isAssignableFrom(sourceClass)) || (StringWriter.class.isAssignableFrom(sourceClass)) || 
/* 50 */       (ObjectToObjectConverter.hasValueOfMethodOrConstructor(sourceClass, String.class));
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 55 */     return source != null ? source.toString() : null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.FallbackObjectToStringConverter
 * JD-Core Version:    0.6.2
 */