/*     */ package org.springframework.core.convert.support;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.core.convert.ConverterNotFoundException;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalConverter;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterFactory;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class GenericConversionService
/*     */   implements ConfigurableConversionService
/*     */ {
/*  65 */   private static final GenericConverter NO_OP_CONVERTER = new NoOpConverter("NO_OP");
/*     */ 
/*  71 */   private static final GenericConverter NO_MATCH = new NoOpConverter("NO_MATCH");
/*     */   private final Converters converters;
/*     */   private final Map<ConverterCacheKey, GenericConverter> converterCache;
/*     */ 
/*     */   public GenericConversionService()
/*     */   {
/*  74 */     this.converters = new Converters(null);
/*     */ 
/*  76 */     this.converterCache = new ConcurrentHashMap(64);
/*     */   }
/*     */ 
/*     */   public void addConverter(Converter<?, ?> converter)
/*     */   {
/*  84 */     GenericConverter.ConvertiblePair typeInfo = getRequiredTypeInfo(converter, Converter.class);
/*  85 */     Assert.notNull(typeInfo, "Unable to the determine sourceType <S> and targetType <T> which your Converter<S, T> converts between; declare these generic types.");
/*     */ 
/*  87 */     addConverter(new ConverterAdapter(typeInfo, converter));
/*     */   }
/*     */ 
/*     */   public void addConverter(Class<?> sourceType, Class<?> targetType, Converter<?, ?> converter)
/*     */   {
/*  92 */     GenericConverter.ConvertiblePair typeInfo = new GenericConverter.ConvertiblePair(sourceType, targetType);
/*  93 */     addConverter(new ConverterAdapter(typeInfo, converter));
/*     */   }
/*     */ 
/*     */   public void addConverter(GenericConverter converter)
/*     */   {
/*  98 */     this.converters.add(converter);
/*  99 */     invalidateCache();
/*     */   }
/*     */ 
/*     */   public void addConverterFactory(ConverterFactory<?, ?> converterFactory)
/*     */   {
/* 104 */     GenericConverter.ConvertiblePair typeInfo = getRequiredTypeInfo(converterFactory, ConverterFactory.class);
/* 105 */     if (typeInfo == null) {
/* 106 */       throw new IllegalArgumentException("Unable to the determine sourceType <S> and targetRangeType R which your ConverterFactory<S, R> converts between; declare these generic types.");
/*     */     }
/*     */ 
/* 110 */     addConverter(new ConverterFactoryAdapter(typeInfo, converterFactory));
/*     */   }
/*     */ 
/*     */   public void removeConvertible(Class<?> sourceType, Class<?> targetType)
/*     */   {
/* 115 */     this.converters.remove(sourceType, targetType);
/* 116 */     invalidateCache();
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class<?> sourceType, Class<?> targetType)
/*     */   {
/* 123 */     Assert.notNull(targetType, "The targetType to convert to cannot be null");
/* 124 */     return canConvert(sourceType != null ? 
/* 125 */       TypeDescriptor.valueOf(sourceType) : 
/* 125 */       null, 
/* 126 */       TypeDescriptor.valueOf(targetType));
/*     */   }
/*     */ 
/*     */   public boolean canConvert(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 131 */     Assert.notNull(targetType, "The targetType to convert to cannot be null");
/* 132 */     if (sourceType == null) {
/* 133 */       return true;
/*     */     }
/* 135 */     GenericConverter converter = getConverter(sourceType, targetType);
/* 136 */     return converter != null;
/*     */   }
/*     */ 
/*     */   public boolean canBypassConvert(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 150 */     Assert.notNull(targetType, "The targetType to convert to cannot be null");
/* 151 */     if (sourceType == null) {
/* 152 */       return true;
/*     */     }
/* 154 */     GenericConverter converter = getConverter(sourceType, targetType);
/* 155 */     return converter == NO_OP_CONVERTER;
/*     */   }
/*     */ 
/*     */   public <T> T convert(Object source, Class<T> targetType)
/*     */   {
/* 161 */     Assert.notNull(targetType, "The targetType to convert to cannot be null");
/* 162 */     return convert(source, TypeDescriptor.forObject(source), TypeDescriptor.valueOf(targetType));
/*     */   }
/*     */ 
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 167 */     Assert.notNull(targetType, "The targetType to convert to cannot be null");
/* 168 */     if (sourceType == null) {
/* 169 */       Assert.isTrue(source == null, "The source must be [null] if sourceType == [null]");
/* 170 */       return handleResult(sourceType, targetType, convertNullSource(sourceType, targetType));
/*     */     }
/* 172 */     if ((source != null) && (!sourceType.getObjectType().isInstance(source)))
/*     */     {
/* 174 */       throw new IllegalArgumentException("The source to convert from must be an instance of " + sourceType + "; instead it was a " + source
/* 174 */         .getClass().getName());
/*     */     }
/* 176 */     GenericConverter converter = getConverter(sourceType, targetType);
/* 177 */     if (converter != null) {
/* 178 */       Object result = ConversionUtils.invokeConverter(converter, source, sourceType, targetType);
/* 179 */       return handleResult(sourceType, targetType, result);
/*     */     }
/* 181 */     return handleConverterNotFound(source, sourceType, targetType);
/*     */   }
/*     */ 
/*     */   public Object convert(Object source, TypeDescriptor targetType)
/*     */   {
/* 198 */     return convert(source, TypeDescriptor.forObject(source), targetType);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 203 */     return this.converters.toString();
/*     */   }
/*     */ 
/*     */   protected Object convertNullSource(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 218 */     return null;
/*     */   }
/*     */ 
/*     */   protected GenericConverter getConverter(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 234 */     ConverterCacheKey key = new ConverterCacheKey(sourceType, targetType);
/* 235 */     GenericConverter converter = (GenericConverter)this.converterCache.get(key);
/* 236 */     if (converter != null) {
/* 237 */       return converter != NO_MATCH ? converter : null;
/*     */     }
/*     */ 
/* 240 */     converter = this.converters.find(sourceType, targetType);
/* 241 */     if (converter == null) {
/* 242 */       converter = getDefaultConverter(sourceType, targetType);
/*     */     }
/*     */ 
/* 245 */     if (converter != null) {
/* 246 */       this.converterCache.put(key, converter);
/* 247 */       return converter;
/*     */     }
/*     */ 
/* 250 */     this.converterCache.put(key, NO_MATCH);
/* 251 */     return null;
/*     */   }
/*     */ 
/*     */   protected GenericConverter getDefaultConverter(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 264 */     return sourceType.isAssignableTo(targetType) ? NO_OP_CONVERTER : null;
/*     */   }
/*     */ 
/*     */   private GenericConverter.ConvertiblePair getRequiredTypeInfo(Object converter, Class<?> genericIfc)
/*     */   {
/* 270 */     ResolvableType resolvableType = ResolvableType.forClass(converter.getClass()).as(genericIfc);
/* 271 */     if (resolvableType.hasUnresolvableGenerics()) {
/* 272 */       return null;
/*     */     }
/* 274 */     return new GenericConverter.ConvertiblePair(resolvableType.resolveGeneric(new int[] { 0 }), resolvableType.resolveGeneric(new int[] { 1 }));
/*     */   }
/*     */ 
/*     */   private void invalidateCache() {
/* 278 */     this.converterCache.clear();
/*     */   }
/*     */ 
/*     */   private Object handleConverterNotFound(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 282 */     if (source == null) {
/* 283 */       assertNotPrimitiveTargetType(sourceType, targetType);
/* 284 */       return source;
/*     */     }
/* 286 */     if ((sourceType.isAssignableTo(targetType)) && (targetType.getObjectType().isInstance(source))) {
/* 287 */       return source;
/*     */     }
/* 289 */     throw new ConverterNotFoundException(sourceType, targetType);
/*     */   }
/*     */ 
/*     */   private Object handleResult(TypeDescriptor sourceType, TypeDescriptor targetType, Object result) {
/* 293 */     if (result == null) {
/* 294 */       assertNotPrimitiveTargetType(sourceType, targetType);
/*     */     }
/* 296 */     return result;
/*     */   }
/*     */ 
/*     */   private void assertNotPrimitiveTargetType(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 300 */     if (targetType.isPrimitive())
/* 301 */       throw new ConversionFailedException(sourceType, targetType, null, new IllegalArgumentException("A null value cannot be assigned to a primitive type"));
/*     */   }
/*     */ 
/*     */   private static class NoOpConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private String name;
/*     */ 
/*     */     public NoOpConverter(String name)
/*     */     {
/* 641 */       this.name = name;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 647 */       return null;
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 653 */       return source;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 658 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConvertersForPair
/*     */   {
/* 607 */     private final LinkedList<GenericConverter> converters = new LinkedList();
/*     */ 
/*     */     public void add(GenericConverter converter) {
/* 610 */       this.converters.addFirst(converter);
/*     */     }
/*     */ 
/*     */     public GenericConverter getConverter(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 615 */       for (GenericConverter converter : this.converters) {
/* 616 */         if ((!(converter instanceof ConditionalGenericConverter)) || 
/* 617 */           (((ConditionalGenericConverter)converter)
/* 617 */           .matches(sourceType, targetType)))
/*     */         {
/* 619 */           return converter;
/*     */         }
/*     */       }
/* 622 */       return null;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 627 */       return StringUtils.collectionToCommaDelimitedString(this.converters);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Converters
/*     */   {
/* 458 */     private final Set<GenericConverter> globalConverters = new LinkedHashSet();
/*     */ 
/* 461 */     private final Map<GenericConverter.ConvertiblePair, GenericConversionService.ConvertersForPair> converters = new LinkedHashMap(36);
/*     */ 
/*     */     public void add(GenericConverter converter)
/*     */     {
/* 465 */       Set convertibleTypes = converter.getConvertibleTypes();
/* 466 */       if (convertibleTypes == null) {
/* 467 */         Assert.state(converter instanceof ConditionalConverter, "Only conditional converters may return null convertible types");
/*     */ 
/* 469 */         this.globalConverters.add(converter);
/*     */       }
/*     */       else {
/* 472 */         for (GenericConverter.ConvertiblePair convertiblePair : convertibleTypes) {
/* 473 */           GenericConversionService.ConvertersForPair convertersForPair = getMatchableConverters(convertiblePair);
/* 474 */           convertersForPair.add(converter);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private GenericConversionService.ConvertersForPair getMatchableConverters(GenericConverter.ConvertiblePair convertiblePair) {
/* 480 */       GenericConversionService.ConvertersForPair convertersForPair = (GenericConversionService.ConvertersForPair)this.converters.get(convertiblePair);
/* 481 */       if (convertersForPair == null) {
/* 482 */         convertersForPair = new GenericConversionService.ConvertersForPair(null);
/* 483 */         this.converters.put(convertiblePair, convertersForPair);
/*     */       }
/* 485 */       return convertersForPair;
/*     */     }
/*     */ 
/*     */     public void remove(Class<?> sourceType, Class<?> targetType) {
/* 489 */       this.converters.remove(new GenericConverter.ConvertiblePair(sourceType, targetType));
/*     */     }
/*     */ 
/*     */     public GenericConverter find(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 502 */       List sourceCandidates = getClassHierarchy(sourceType.getType());
/* 503 */       List targetCandidates = getClassHierarchy(targetType.getType());
/* 504 */       for (Iterator localIterator1 = sourceCandidates.iterator(); localIterator1.hasNext(); ) { sourceCandidate = (Class)localIterator1.next();
/* 505 */         for (Class targetCandidate : targetCandidates) {
/* 506 */           GenericConverter.ConvertiblePair convertiblePair = new GenericConverter.ConvertiblePair(sourceCandidate, targetCandidate);
/* 507 */           GenericConverter converter = getRegisteredConverter(sourceType, targetType, convertiblePair);
/*     */ 
/* 509 */           if (converter != null)
/* 510 */             return converter;
/*     */         }
/*     */       }
/*     */       Class sourceCandidate;
/* 514 */       return null;
/*     */     }
/*     */ 
/*     */     private GenericConverter getRegisteredConverter(TypeDescriptor sourceType, TypeDescriptor targetType, GenericConverter.ConvertiblePair convertiblePair)
/*     */     {
/* 521 */       GenericConversionService.ConvertersForPair convertersForPair = (GenericConversionService.ConvertersForPair)this.converters.get(convertiblePair);
/*     */ 
/* 523 */       GenericConverter converter = convertersForPair == null ? null : convertersForPair
/* 523 */         .getConverter(sourceType, targetType);
/*     */ 
/* 524 */       if (converter != null) {
/* 525 */         return converter;
/*     */       }
/*     */ 
/* 529 */       for (GenericConverter globalConverter : this.globalConverters) {
/* 530 */         if (((ConditionalConverter)globalConverter).matches(sourceType, targetType))
/*     */         {
/* 532 */           return globalConverter;
/*     */         }
/*     */       }
/*     */ 
/* 536 */       return null;
/*     */     }
/*     */ 
/*     */     private List<Class<?>> getClassHierarchy(Class<?> type)
/*     */     {
/* 546 */       List hierarchy = new ArrayList(20);
/* 547 */       Set visited = new HashSet(20);
/* 548 */       addToClassHierarchy(0, ClassUtils.resolvePrimitiveIfNecessary(type), false, hierarchy, visited);
/* 549 */       boolean array = type.isArray();
/* 550 */       int i = 0;
/* 551 */       while (i < hierarchy.size()) {
/* 552 */         Class candidate = (Class)hierarchy.get(i);
/*     */ 
/* 554 */         candidate = array ? candidate.getComponentType() : 
/* 554 */           ClassUtils.resolvePrimitiveIfNecessary(candidate);
/*     */ 
/* 555 */         Class superclass = candidate.getSuperclass();
/* 556 */         if ((candidate.getSuperclass() != null) && (superclass != Object.class)) {
/* 557 */           addToClassHierarchy(i + 1, candidate.getSuperclass(), array, hierarchy, visited);
/*     */         }
/* 559 */         for (Class implementedInterface : candidate.getInterfaces()) {
/* 560 */           addToClassHierarchy(hierarchy.size(), implementedInterface, array, hierarchy, visited);
/*     */         }
/* 562 */         i++;
/*     */       }
/* 564 */       addToClassHierarchy(hierarchy.size(), Object.class, array, hierarchy, visited);
/* 565 */       addToClassHierarchy(hierarchy.size(), Object.class, false, hierarchy, visited);
/* 566 */       return hierarchy;
/*     */     }
/*     */ 
/*     */     private void addToClassHierarchy(int index, Class<?> type, boolean asArray, List<Class<?>> hierarchy, Set<Class<?>> visited)
/*     */     {
/* 571 */       if (asArray) {
/* 572 */         type = Array.newInstance(type, 0).getClass();
/*     */       }
/* 574 */       if (visited.add(type))
/* 575 */         hierarchy.add(index, type);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 581 */       StringBuilder builder = new StringBuilder();
/* 582 */       builder.append("ConversionService converters = ").append("\n");
/* 583 */       for (String converterString : getConverterStrings()) {
/* 584 */         builder.append("\t");
/* 585 */         builder.append(converterString);
/* 586 */         builder.append("\n");
/*     */       }
/* 588 */       return builder.toString();
/*     */     }
/*     */ 
/*     */     private List<String> getConverterStrings() {
/* 592 */       List converterStrings = new ArrayList();
/* 593 */       for (GenericConversionService.ConvertersForPair convertersForPair : this.converters.values()) {
/* 594 */         converterStrings.add(convertersForPair.toString());
/*     */       }
/* 596 */       Collections.sort(converterStrings);
/* 597 */       return converterStrings;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class ConverterCacheKey
/*     */   {
/*     */     private final TypeDescriptor sourceType;
/*     */     private final TypeDescriptor targetType;
/*     */ 
/*     */     public ConverterCacheKey(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 422 */       this.sourceType = sourceType;
/* 423 */       this.targetType = targetType;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 429 */       if (this == other) {
/* 430 */         return true;
/*     */       }
/* 432 */       if (!(other instanceof ConverterCacheKey)) {
/* 433 */         return false;
/*     */       }
/* 435 */       ConverterCacheKey otherKey = (ConverterCacheKey)other;
/*     */ 
/* 437 */       return (ObjectUtils.nullSafeEquals(this.sourceType, otherKey.sourceType)) && 
/* 437 */         (ObjectUtils.nullSafeEquals(this.targetType, otherKey.targetType));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 443 */       return ObjectUtils.nullSafeHashCode(this.sourceType) * 29 + 
/* 443 */         ObjectUtils.nullSafeHashCode(this.targetType);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 448 */       return "ConverterCacheKey [sourceType = " + this.sourceType + ", targetType = " + this.targetType + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class ConverterFactoryAdapter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final GenericConverter.ConvertiblePair typeInfo;
/*     */     private final ConverterFactory<Object, Object> converterFactory;
/*     */ 
/*     */     public ConverterFactoryAdapter(ConverterFactory<?, ?> typeInfo)
/*     */     {
/* 369 */       this.converterFactory = converterFactory;
/* 370 */       this.typeInfo = typeInfo;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 376 */       return Collections.singleton(this.typeInfo);
/*     */     }
/*     */ 
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 381 */       boolean matches = true;
/* 382 */       if ((this.converterFactory instanceof ConditionalConverter)) {
/* 383 */         matches = ((ConditionalConverter)this.converterFactory).matches(sourceType, targetType);
/*     */       }
/* 385 */       if (matches) {
/* 386 */         Converter converter = this.converterFactory.getConverter(targetType.getType());
/* 387 */         if ((converter instanceof ConditionalConverter)) {
/* 388 */           matches = ((ConditionalConverter)converter).matches(sourceType, targetType);
/*     */         }
/*     */       }
/* 391 */       return matches;
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 396 */       if (source == null) {
/* 397 */         return GenericConversionService.this.convertNullSource(sourceType, targetType);
/*     */       }
/* 399 */       return this.converterFactory.getConverter(targetType.getObjectType()).convert(source);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 406 */       return this.typeInfo.getSourceType().getName() + " -> " + this.typeInfo
/* 405 */         .getTargetType().getName() + " : " + this.converterFactory
/* 406 */         .toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class ConverterAdapter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private final GenericConverter.ConvertiblePair typeInfo;
/*     */     private final Converter<Object, Object> converter;
/*     */ 
/*     */     public ConverterAdapter(Converter<?, ?> typeInfo)
/*     */     {
/* 319 */       this.converter = converter;
/* 320 */       this.typeInfo = typeInfo;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 326 */       return Collections.singleton(this.typeInfo);
/*     */     }
/*     */ 
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 331 */       if (!this.typeInfo.getTargetType().equals(targetType.getObjectType())) {
/* 332 */         return false;
/*     */       }
/* 334 */       if ((this.converter instanceof ConditionalConverter)) {
/* 335 */         return ((ConditionalConverter)this.converter).matches(sourceType, targetType);
/*     */       }
/* 337 */       return true;
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 342 */       if (source == null) {
/* 343 */         return GenericConversionService.this.convertNullSource(sourceType, targetType);
/*     */       }
/* 345 */       return this.converter.convert(source);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 352 */       return this.typeInfo.getSourceType().getName() + " -> " + this.typeInfo
/* 351 */         .getTargetType().getName() + " : " + this.converter
/* 352 */         .toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.GenericConversionService
 * JD-Core Version:    0.6.2
 */