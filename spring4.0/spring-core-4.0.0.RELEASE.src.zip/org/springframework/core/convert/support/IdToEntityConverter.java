/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ final class IdToEntityConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */ 
/*    */   public IdToEntityConverter(ConversionService conversionService)
/*    */   {
/* 45 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 50 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object.class, Object.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 55 */     Method finder = getFinder(targetType.getType());
/* 56 */     return (finder != null) && (this.conversionService.canConvert(sourceType, TypeDescriptor.valueOf(finder.getParameterTypes()[0])));
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 61 */     if (source == null) {
/* 62 */       return null;
/*    */     }
/* 64 */     Method finder = getFinder(targetType.getType());
/* 65 */     Object id = this.conversionService.convert(source, sourceType, TypeDescriptor.valueOf(finder.getParameterTypes()[0]));
/* 66 */     return ReflectionUtils.invokeMethod(finder, source, new Object[] { id });
/*    */   }
/*    */ 
/*    */   private Method getFinder(Class<?> entityClass) {
/* 70 */     String finderMethod = "find" + getEntityName(entityClass);
/* 71 */     Method[] methods = entityClass.getDeclaredMethods();
/* 72 */     for (Method method : methods) {
/* 73 */       if ((Modifier.isStatic(method.getModifiers())) && (method.getParameterTypes().length == 1) && (method.getReturnType().equals(entityClass)) && 
/* 74 */         (method.getName().equals(finderMethod))) {
/* 75 */         return method;
/*    */       }
/*    */     }
/*    */ 
/* 79 */     return null;
/*    */   }
/*    */ 
/*    */   private String getEntityName(Class<?> entityClass) {
/* 83 */     String shortName = ClassUtils.getShortName(entityClass);
/* 84 */     int lastDot = shortName.lastIndexOf('.');
/* 85 */     if (lastDot != -1) {
/* 86 */       return shortName.substring(lastDot + 1);
/*    */     }
/*    */ 
/* 89 */     return shortName;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.IdToEntityConverter
 * JD-Core Version:    0.6.2
 */