/*     */ package org.springframework.core.convert.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ 
/*     */ final class MapToMapConverter
/*     */   implements ConditionalGenericConverter
/*     */ {
/*     */   private final ConversionService conversionService;
/*     */ 
/*     */   public MapToMapConverter(ConversionService conversionService)
/*     */   {
/*  46 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */   {
/*  51 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Map.class, Map.class));
/*     */   }
/*     */ 
/*     */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  56 */     return (canConvertKey(sourceType, targetType)) && (canConvertValue(sourceType, targetType));
/*     */   }
/*     */ 
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  62 */     if (source == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     boolean copyRequired = !targetType.getType().isInstance(source);
/*  66 */     Map sourceMap = (Map)source;
/*  67 */     if ((!copyRequired) && (sourceMap.isEmpty())) {
/*  68 */       return sourceMap;
/*     */     }
/*  70 */     List targetEntries = new ArrayList(sourceMap.size());
/*  71 */     for (Iterator localIterator = sourceMap.entrySet().iterator(); localIterator.hasNext(); ) { entry = (Map.Entry)localIterator.next();
/*  72 */       Object sourceKey = entry.getKey();
/*  73 */       Object sourceValue = entry.getValue();
/*  74 */       Object targetKey = convertKey(sourceKey, sourceType, targetType.getMapKeyTypeDescriptor());
/*  75 */       Object targetValue = convertValue(sourceValue, sourceType, targetType.getMapValueTypeDescriptor());
/*  76 */       targetEntries.add(new MapEntry(targetKey, targetValue));
/*  77 */       if ((sourceKey != targetKey) || (sourceValue != targetValue))
/*  78 */         copyRequired = true;
/*     */     }
/*     */     Map.Entry entry;
/*  81 */     if (!copyRequired) {
/*  82 */       return sourceMap;
/*     */     }
/*  84 */     Map targetMap = CollectionFactory.createMap(targetType.getType(), sourceMap.size());
/*  85 */     for (MapEntry entry : targetEntries) {
/*  86 */       entry.addToMap(targetMap);
/*     */     }
/*  88 */     return targetMap;
/*     */   }
/*     */ 
/*     */   private boolean canConvertKey(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  94 */     return ConversionUtils.canConvertElements(sourceType.getMapKeyTypeDescriptor(), targetType
/*  95 */       .getMapKeyTypeDescriptor(), this.conversionService);
/*     */   }
/*     */ 
/*     */   private boolean canConvertValue(TypeDescriptor sourceType, TypeDescriptor targetType) {
/*  99 */     return ConversionUtils.canConvertElements(sourceType.getMapValueTypeDescriptor(), targetType
/* 100 */       .getMapValueTypeDescriptor(), this.conversionService);
/*     */   }
/*     */ 
/*     */   private Object convertKey(Object sourceKey, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 104 */     if (targetType == null) {
/* 105 */       return sourceKey;
/*     */     }
/* 107 */     return this.conversionService.convert(sourceKey, sourceType.getMapKeyTypeDescriptor(sourceKey), targetType);
/*     */   }
/*     */ 
/*     */   private Object convertValue(Object sourceValue, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 111 */     if (targetType == null) {
/* 112 */       return sourceValue;
/*     */     }
/* 114 */     return this.conversionService.convert(sourceValue, sourceType.getMapValueTypeDescriptor(sourceValue), targetType);
/*     */   }
/*     */ 
/*     */   private static class MapEntry {
/*     */     private Object key;
/*     */     private Object value;
/*     */ 
/*     */     public MapEntry(Object key, Object value) {
/* 123 */       this.key = key;
/* 124 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public void addToMap(Map<Object, Object> map) {
/* 128 */       map.put(this.key, this.value);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.MapToMapConverter
 * JD-Core Version:    0.6.2
 */