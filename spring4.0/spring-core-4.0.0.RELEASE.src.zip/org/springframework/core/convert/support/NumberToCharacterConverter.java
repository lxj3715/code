/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ 
/*    */ final class NumberToCharacterConverter
/*    */   implements Converter<Number, Character>
/*    */ {
/*    */   public Character convert(Number source)
/*    */   {
/* 39 */     return Character.valueOf((char)source.shortValue());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.NumberToCharacterConverter
 * JD-Core Version:    0.6.2
 */