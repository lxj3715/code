/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalConverter;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.convert.converter.ConverterFactory;
/*    */ import org.springframework.util.NumberUtils;
/*    */ 
/*    */ final class NumberToNumberConverterFactory
/*    */   implements ConverterFactory<Number, Number>, ConditionalConverter
/*    */ {
/*    */   public <T extends Number> Converter<Number, T> getConverter(Class<T> targetType)
/*    */   {
/* 48 */     return new NumberToNumber(targetType);
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 53 */     return !sourceType.equals(targetType);
/*    */   }
/*    */ 
/*    */   private static final class NumberToNumber<T extends Number> implements Converter<Number, T>
/*    */   {
/*    */     private final Class<T> targetType;
/*    */ 
/*    */     public NumberToNumber(Class<T> targetType) {
/* 61 */       this.targetType = targetType;
/*    */     }
/*    */ 
/*    */     public T convert(Number source)
/*    */     {
/* 66 */       return NumberUtils.convertNumberToTargetClass(source, this.targetType);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.NumberToNumberConverterFactory
 * JD-Core Version:    0.6.2
 */