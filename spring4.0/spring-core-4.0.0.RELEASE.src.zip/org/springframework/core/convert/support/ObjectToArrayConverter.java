/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ 
/*    */ final class ObjectToArrayConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */ 
/*    */   public ObjectToArrayConverter(ConversionService conversionService)
/*    */   {
/* 39 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 44 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object.class, [Ljava.lang.Object.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 49 */     return ConversionUtils.canConvertElements(sourceType, targetType.getElementTypeDescriptor(), this.conversionService);
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 54 */     if (source == null) {
/* 55 */       return null;
/*    */     }
/* 57 */     Object target = Array.newInstance(targetType.getElementTypeDescriptor().getType(), 1);
/* 58 */     Object targetElement = this.conversionService.convert(source, sourceType, targetType.getElementTypeDescriptor());
/* 59 */     Array.set(target, 0, targetElement);
/* 60 */     return target;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ObjectToArrayConverter
 * JD-Core Version:    0.6.2
 */