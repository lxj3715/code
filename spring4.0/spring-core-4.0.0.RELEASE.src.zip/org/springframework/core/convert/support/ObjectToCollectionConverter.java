/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.CollectionFactory;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ 
/*    */ final class ObjectToCollectionConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */ 
/*    */   public ObjectToCollectionConverter(ConversionService conversionService)
/*    */   {
/* 41 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 46 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object.class, Collection.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 51 */     return ConversionUtils.canConvertElements(sourceType, targetType.getElementTypeDescriptor(), this.conversionService);
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 56 */     if (source == null) {
/* 57 */       return null;
/*    */     }
/* 59 */     Collection target = CollectionFactory.createCollection(targetType.getType(), 1);
/* 60 */     if ((targetType.getElementTypeDescriptor() == null) || (targetType.getElementTypeDescriptor().isCollection())) {
/* 61 */       target.add(source);
/*    */     }
/*    */     else {
/* 64 */       Object singleElement = this.conversionService.convert(source, sourceType, targetType.getElementTypeDescriptor());
/* 65 */       target.add(singleElement);
/*    */     }
/* 67 */     return target;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ObjectToCollectionConverter
 * JD-Core Version:    0.6.2
 */