/*     */ package org.springframework.core.convert.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ final class ObjectToObjectConverter
/*     */   implements ConditionalGenericConverter
/*     */ {
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */   {
/*  48 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object.class, Object.class));
/*     */   }
/*     */ 
/*     */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  53 */     if (sourceType.getType().equals(targetType.getType()))
/*     */     {
/*  55 */       return false;
/*     */     }
/*  57 */     return hasValueOfMethodOrConstructor(targetType.getType(), sourceType.getType());
/*     */   }
/*     */ 
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  62 */     if (source == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     Class sourceClass = sourceType.getType();
/*  66 */     Class targetClass = targetType.getType();
/*  67 */     Method method = getValueOfMethodOn(targetClass, sourceClass);
/*     */     try {
/*  69 */       if (method != null) {
/*  70 */         ReflectionUtils.makeAccessible(method);
/*  71 */         return method.invoke(null, new Object[] { source });
/*     */       }
/*     */ 
/*  74 */       Constructor constructor = getConstructor(targetClass, sourceClass);
/*  75 */       if (constructor != null) {
/*  76 */         return constructor.newInstance(new Object[] { source });
/*     */       }
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/*  81 */       throw new ConversionFailedException(sourceType, targetType, source, ex.getTargetException());
/*     */     }
/*     */     catch (Throwable ex) {
/*  84 */       throw new ConversionFailedException(sourceType, targetType, source, ex);
/*     */     }
/*     */ 
/*  87 */     throw new IllegalStateException("No static valueOf(" + sourceClass.getName() + ") method or Constructor(" + sourceClass
/*  87 */       .getName() + ") exists on " + targetClass.getName());
/*     */   }
/*     */ 
/*     */   static boolean hasValueOfMethodOrConstructor(Class<?> clazz, Class<?> sourceParameterType) {
/*  91 */     return (getValueOfMethodOn(clazz, sourceParameterType) != null) || (getConstructor(clazz, sourceParameterType) != null);
/*     */   }
/*     */ 
/*     */   private static Method getValueOfMethodOn(Class<?> clazz, Class<?> sourceParameterType) {
/*  95 */     Method method = ClassUtils.getStaticMethod(clazz, "valueOf", new Class[] { sourceParameterType });
/*  96 */     if (method == null) {
/*  97 */       method = ClassUtils.getStaticMethod(clazz, "of", new Class[] { sourceParameterType });
/*     */     }
/*  99 */     return method;
/*     */   }
/*     */ 
/*     */   private static Constructor<?> getConstructor(Class<?> clazz, Class<?> sourceParameterType) {
/* 103 */     return ClassUtils.getConstructorIfAvailable(clazz, new Class[] { sourceParameterType });
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ObjectToObjectConverter
 * JD-Core Version:    0.6.2
 */