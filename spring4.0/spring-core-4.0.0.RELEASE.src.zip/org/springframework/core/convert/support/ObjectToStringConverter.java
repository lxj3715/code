/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ 
/*    */ final class ObjectToStringConverter
/*    */   implements Converter<Object, String>
/*    */ {
/*    */   public String convert(Object source)
/*    */   {
/* 30 */     return source.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.ObjectToStringConverter
 * JD-Core Version:    0.6.2
 */