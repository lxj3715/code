/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ 
/*    */ final class StringToCharacterConverter
/*    */   implements Converter<String, Character>
/*    */ {
/*    */   public Character convert(String source)
/*    */   {
/* 31 */     if (source.length() == 0) {
/* 32 */       return null;
/*    */     }
/* 34 */     if (source.length() > 1)
/*    */     {
/* 36 */       throw new IllegalArgumentException("Can only convert a [String] with length of 1 to a [Character]; string value '" + source + "'  has length of " + source
/* 36 */         .length());
/*    */     }
/* 38 */     return Character.valueOf(source.charAt(0));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.StringToCharacterConverter
 * JD-Core Version:    0.6.2
 */