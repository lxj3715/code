/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.CollectionFactory;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ final class StringToCollectionConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */ 
/*    */   public StringToCollectionConverter(ConversionService conversionService)
/*    */   {
/* 41 */     this.conversionService = conversionService;
/*    */   }
/*    */ 
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 46 */     return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, Collection.class));
/*    */   }
/*    */ 
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 51 */     if (targetType.getElementTypeDescriptor() != null) {
/* 52 */       return this.conversionService.canConvert(sourceType, targetType.getElementTypeDescriptor());
/*    */     }
/* 54 */     return true;
/*    */   }
/*    */ 
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 60 */     if (source == null) {
/* 61 */       return null;
/*    */     }
/* 63 */     String string = (String)source;
/* 64 */     String[] fields = StringUtils.commaDelimitedListToStringArray(string);
/* 65 */     Collection target = CollectionFactory.createCollection(targetType.getType(), fields.length);
/* 66 */     if (targetType.getElementTypeDescriptor() == null) {
/* 67 */       for (String field : fields)
/* 68 */         target.add(field.trim());
/*    */     }
/*    */     else {
/* 71 */       for (String field : fields) {
/* 72 */         Object targetElement = this.conversionService.convert(field.trim(), sourceType, targetType.getElementTypeDescriptor());
/* 73 */         target.add(targetElement);
/*    */       }
/*    */     }
/* 76 */     return target;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.StringToCollectionConverter
 * JD-Core Version:    0.6.2
 */