/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.convert.converter.ConverterFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ final class StringToEnumConverterFactory
/*    */   implements ConverterFactory<String, Enum>
/*    */ {
/*    */   public <T extends Enum> Converter<String, T> getConverter(Class<T> targetType)
/*    */   {
/* 34 */     Class enumType = targetType;
/* 35 */     while ((enumType != null) && (!enumType.isEnum())) {
/* 36 */       enumType = enumType.getSuperclass();
/*    */     }
/* 38 */     Assert.notNull(enumType, "The target type " + targetType.getName() + " does not refer to an enum");
/*    */ 
/* 40 */     return new StringToEnum(enumType);
/*    */   }
/*    */ 
/*    */   private class StringToEnum<T extends Enum> implements Converter<String, T>
/*    */   {
/*    */     private final Class<T> enumType;
/*    */ 
/*    */     public StringToEnum() {
/* 48 */       this.enumType = enumType;
/*    */     }
/*    */ 
/*    */     public T convert(String source)
/*    */     {
/* 53 */       if (source.length() == 0)
/*    */       {
/* 55 */         return null;
/*    */       }
/* 57 */       return Enum.valueOf(this.enumType, source.trim());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.StringToEnumConverterFactory
 * JD-Core Version:    0.6.2
 */