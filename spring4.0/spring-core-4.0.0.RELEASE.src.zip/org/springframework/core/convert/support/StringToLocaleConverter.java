/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ final class StringToLocaleConverter
/*    */   implements Converter<String, Locale>
/*    */ {
/*    */   public Locale convert(String source)
/*    */   {
/* 34 */     return StringUtils.parseLocaleString(source);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.StringToLocaleConverter
 * JD-Core Version:    0.6.2
 */