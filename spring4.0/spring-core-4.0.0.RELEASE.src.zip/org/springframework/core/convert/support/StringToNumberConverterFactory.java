/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.convert.converter.ConverterFactory;
/*    */ import org.springframework.util.NumberUtils;
/*    */ 
/*    */ final class StringToNumberConverterFactory
/*    */   implements ConverterFactory<String, Number>
/*    */ {
/*    */   public <T extends Number> Converter<String, T> getConverter(Class<T> targetType)
/*    */   {
/* 45 */     return new StringToNumber(targetType);
/*    */   }
/*    */ 
/*    */   private static final class StringToNumber<T extends Number> implements Converter<String, T>
/*    */   {
/*    */     private final Class<T> targetType;
/*    */ 
/*    */     public StringToNumber(Class<T> targetType) {
/* 53 */       this.targetType = targetType;
/*    */     }
/*    */ 
/*    */     public T convert(String source)
/*    */     {
/* 58 */       if (source.length() == 0) {
/* 59 */         return null;
/*    */       }
/* 61 */       return NumberUtils.parseNumber(source, this.targetType);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.StringToNumberConverterFactory
 * JD-Core Version:    0.6.2
 */