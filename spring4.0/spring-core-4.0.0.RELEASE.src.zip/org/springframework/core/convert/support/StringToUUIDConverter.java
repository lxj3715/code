/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ final class StringToUUIDConverter
/*    */   implements Converter<String, UUID>
/*    */ {
/*    */   public UUID convert(String source)
/*    */   {
/* 34 */     if (StringUtils.hasLength(source)) {
/* 35 */       return UUID.fromString(source.trim());
/*    */     }
/* 37 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.StringToUUIDConverter
 * JD-Core Version:    0.6.2
 */