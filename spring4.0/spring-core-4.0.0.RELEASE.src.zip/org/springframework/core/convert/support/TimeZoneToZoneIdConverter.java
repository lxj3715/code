/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.time.ZoneId;
/*    */ import java.util.TimeZone;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ 
/*    */ class TimeZoneToZoneIdConverter
/*    */   implements Converter<TimeZone, ZoneId>
/*    */ {
/*    */   public ZoneId convert(TimeZone source)
/*    */   {
/* 39 */     return source.toZoneId();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.convert.support.TimeZoneToZoneIdConverter
 * JD-Core Version:    0.6.2
 */