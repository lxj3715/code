/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.security.AccessControlException;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractEnvironment
/*     */   implements ConfigurableEnvironment
/*     */ {
/*     */   public static final String ACTIVE_PROFILES_PROPERTY_NAME = "spring.profiles.active";
/*     */   public static final String DEFAULT_PROFILES_PROPERTY_NAME = "spring.profiles.default";
/*     */   protected static final String RESERVED_DEFAULT_PROFILE_NAME = "default";
/*  90 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  92 */   private Set<String> activeProfiles = new LinkedHashSet();
/*     */ 
/*  94 */   private Set<String> defaultProfiles = new LinkedHashSet(getReservedDefaultProfiles());
/*     */ 
/*  96 */   private final MutablePropertySources propertySources = new MutablePropertySources(this.logger);
/*     */ 
/*  98 */   private final ConfigurablePropertyResolver propertyResolver = new PropertySourcesPropertyResolver(this.propertySources);
/*     */ 
/*     */   public AbstractEnvironment()
/*     */   {
/* 110 */     String name = getClass().getSimpleName();
/* 111 */     if (this.logger.isDebugEnabled()) {
/* 112 */       this.logger.debug(String.format("Initializing new %s", new Object[] { name }));
/*     */     }
/* 114 */     customizePropertySources(this.propertySources);
/* 115 */     if (this.logger.isDebugEnabled())
/* 116 */       this.logger.debug(String.format("Initialized %s with PropertySources %s", new Object[] { name, this.propertySources }));
/*     */   }
/*     */ 
/*     */   protected void customizePropertySources(MutablePropertySources propertySources)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Set<String> getReservedDefaultProfiles()
/*     */   {
/* 209 */     return Collections.singleton("default");
/*     */   }
/*     */ 
/*     */   public String[] getActiveProfiles()
/*     */   {
/* 219 */     return StringUtils.toStringArray(doGetActiveProfiles());
/*     */   }
/*     */ 
/*     */   protected Set<String> doGetActiveProfiles()
/*     */   {
/* 231 */     if (this.activeProfiles.isEmpty()) {
/* 232 */       String profiles = getProperty("spring.profiles.active");
/* 233 */       if (StringUtils.hasText(profiles)) {
/* 234 */         setActiveProfiles(StringUtils.commaDelimitedListToStringArray(StringUtils.trimAllWhitespace(profiles)));
/*     */       }
/*     */     }
/* 237 */     return this.activeProfiles;
/*     */   }
/*     */ 
/*     */   public void setActiveProfiles(String[] profiles)
/*     */   {
/* 242 */     Assert.notNull(profiles, "Profile array must not be null");
/* 243 */     this.activeProfiles.clear();
/* 244 */     for (String profile : profiles) {
/* 245 */       validateProfile(profile);
/* 246 */       this.activeProfiles.add(profile);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addActiveProfile(String profile)
/*     */   {
/* 252 */     if (this.logger.isDebugEnabled()) {
/* 253 */       this.logger.debug(String.format("Activating profile '%s'", new Object[] { profile }));
/*     */     }
/* 255 */     validateProfile(profile);
/* 256 */     doGetActiveProfiles();
/* 257 */     this.activeProfiles.add(profile);
/*     */   }
/*     */ 
/*     */   public String[] getDefaultProfiles()
/*     */   {
/* 263 */     return StringUtils.toStringArray(doGetDefaultProfiles());
/*     */   }
/*     */ 
/*     */   protected Set<String> doGetDefaultProfiles()
/*     */   {
/* 279 */     if (this.defaultProfiles.equals(getReservedDefaultProfiles())) {
/* 280 */       String profiles = getProperty("spring.profiles.default");
/* 281 */       if (StringUtils.hasText(profiles)) {
/* 282 */         setDefaultProfiles(StringUtils.commaDelimitedListToStringArray(StringUtils.trimAllWhitespace(profiles)));
/*     */       }
/*     */     }
/* 285 */     return this.defaultProfiles;
/*     */   }
/*     */ 
/*     */   public void setDefaultProfiles(String[] profiles)
/*     */   {
/* 297 */     Assert.notNull(profiles, "Profile array must not be null");
/* 298 */     this.defaultProfiles.clear();
/* 299 */     for (String profile : profiles) {
/* 300 */       validateProfile(profile);
/* 301 */       this.defaultProfiles.add(profile);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean acceptsProfiles(String[] profiles)
/*     */   {
/* 307 */     Assert.notEmpty(profiles, "Must specify at least one profile");
/* 308 */     for (String profile : profiles) {
/* 309 */       if ((profile != null) && (profile.length() > 0) && (profile.charAt(0) == '!')) {
/* 310 */         if (!isProfileActive(profile.substring(1))) {
/* 311 */           return true;
/*     */         }
/*     */       }
/* 314 */       else if (isProfileActive(profile)) {
/* 315 */         return true;
/*     */       }
/*     */     }
/* 318 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean isProfileActive(String profile)
/*     */   {
/* 327 */     validateProfile(profile);
/*     */ 
/* 329 */     return (doGetActiveProfiles().contains(profile)) || (
/* 329 */       (doGetActiveProfiles().isEmpty()) && (doGetDefaultProfiles().contains(profile)));
/*     */   }
/*     */ 
/*     */   protected void validateProfile(String profile)
/*     */   {
/* 343 */     if (!StringUtils.hasText(profile)) {
/* 344 */       throw new IllegalArgumentException("Invalid profile [" + profile + "]: must contain text");
/*     */     }
/* 346 */     if (profile.charAt(0) == '!')
/* 347 */       throw new IllegalArgumentException("Invalid profile [" + profile + "]: must not begin with ! operator");
/*     */   }
/*     */ 
/*     */   public MutablePropertySources getPropertySources()
/*     */   {
/* 353 */     return this.propertySources;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getSystemEnvironment()
/*     */   {
/*     */     Map systemEnvironment;
/*     */     try
/*     */     {
/* 361 */       systemEnvironment = System.getenv();
/*     */     }
/*     */     catch (AccessControlException ex)
/*     */     {
/*     */       Map systemEnvironment;
/* 364 */       systemEnvironment = new ReadOnlySystemAttributesMap()
/*     */       {
/*     */         protected String getSystemAttribute(String variableName) {
/*     */           try {
/* 368 */             return System.getenv(variableName);
/*     */           }
/*     */           catch (AccessControlException ex) {
/* 371 */             if (AbstractEnvironment.this.logger.isInfoEnabled())
/* 372 */               AbstractEnvironment.this.logger.info(String.format("Caught AccessControlException when accessing system environment variable [%s]; its value will be returned [null]. Reason: %s", new Object[] { variableName, ex
/* 375 */                 .getMessage() }));
/*     */           }
/* 377 */           return null;
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/* 382 */     return systemEnvironment;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getSystemProperties()
/*     */   {
/*     */     Map systemProperties;
/*     */     try
/*     */     {
/* 390 */       systemProperties = System.getProperties();
/*     */     }
/*     */     catch (AccessControlException ex)
/*     */     {
/*     */       Map systemProperties;
/* 393 */       systemProperties = new ReadOnlySystemAttributesMap()
/*     */       {
/*     */         protected String getSystemAttribute(String propertyName) {
/*     */           try {
/* 397 */             return System.getProperty(propertyName);
/*     */           }
/*     */           catch (AccessControlException ex) {
/* 400 */             if (AbstractEnvironment.this.logger.isInfoEnabled())
/* 401 */               AbstractEnvironment.this.logger.info(String.format("Caught AccessControlException when accessing system property [%s]; its value will be returned [null]. Reason: %s", new Object[] { propertyName, ex
/* 404 */                 .getMessage() }));
/*     */           }
/* 406 */           return null;
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/* 411 */     return systemProperties;
/*     */   }
/*     */ 
/*     */   public void merge(ConfigurableEnvironment parent)
/*     */   {
/* 416 */     for (Object localObject = parent.getPropertySources().iterator(); ((Iterator)localObject).hasNext(); ) { ps = (PropertySource)((Iterator)localObject).next();
/* 417 */       if (!this.propertySources.contains(ps.getName())) {
/* 418 */         this.propertySources.addLast(ps);
/*     */       }
/*     */     }
/* 421 */     localObject = parent.getActiveProfiles(); PropertySource ps = localObject.length; for (PropertySource localPropertySource1 = 0; localPropertySource1 < ps; localPropertySource1++) { String profile = localObject[localPropertySource1];
/* 422 */       this.activeProfiles.add(profile);
/*     */     }
/* 424 */     if (parent.getDefaultProfiles().length > 0) {
/* 425 */       this.defaultProfiles.remove("default");
/* 426 */       localObject = parent.getDefaultProfiles(); ps = localObject.length; for (PropertySource localPropertySource2 = 0; localPropertySource2 < ps; localPropertySource2++) { String profile = localObject[localPropertySource2];
/* 427 */         this.defaultProfiles.add(profile);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsProperty(String key)
/*     */   {
/* 439 */     return this.propertyResolver.containsProperty(key);
/*     */   }
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/* 444 */     return this.propertyResolver.getProperty(key);
/*     */   }
/*     */ 
/*     */   public String getProperty(String key, String defaultValue)
/*     */   {
/* 449 */     return this.propertyResolver.getProperty(key, defaultValue);
/*     */   }
/*     */ 
/*     */   public <T> T getProperty(String key, Class<T> targetType)
/*     */   {
/* 454 */     return this.propertyResolver.getProperty(key, targetType);
/*     */   }
/*     */ 
/*     */   public <T> T getProperty(String key, Class<T> targetType, T defaultValue)
/*     */   {
/* 459 */     return this.propertyResolver.getProperty(key, targetType, defaultValue);
/*     */   }
/*     */ 
/*     */   public <T> Class<T> getPropertyAsClass(String key, Class<T> targetType)
/*     */   {
/* 464 */     return this.propertyResolver.getPropertyAsClass(key, targetType);
/*     */   }
/*     */ 
/*     */   public String getRequiredProperty(String key) throws IllegalStateException
/*     */   {
/* 469 */     return this.propertyResolver.getRequiredProperty(key);
/*     */   }
/*     */ 
/*     */   public <T> T getRequiredProperty(String key, Class<T> targetType) throws IllegalStateException
/*     */   {
/* 474 */     return this.propertyResolver.getRequiredProperty(key, targetType);
/*     */   }
/*     */ 
/*     */   public void setRequiredProperties(String[] requiredProperties)
/*     */   {
/* 479 */     this.propertyResolver.setRequiredProperties(requiredProperties);
/*     */   }
/*     */ 
/*     */   public void validateRequiredProperties() throws MissingRequiredPropertiesException
/*     */   {
/* 484 */     this.propertyResolver.validateRequiredProperties();
/*     */   }
/*     */ 
/*     */   public String resolvePlaceholders(String text)
/*     */   {
/* 489 */     return this.propertyResolver.resolvePlaceholders(text);
/*     */   }
/*     */ 
/*     */   public String resolveRequiredPlaceholders(String text) throws IllegalArgumentException
/*     */   {
/* 494 */     return this.propertyResolver.resolveRequiredPlaceholders(text);
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnresolvableNestedPlaceholders(boolean ignoreUnresolvableNestedPlaceholders)
/*     */   {
/* 499 */     this.propertyResolver.setIgnoreUnresolvableNestedPlaceholders(ignoreUnresolvableNestedPlaceholders);
/*     */   }
/*     */ 
/*     */   public void setConversionService(ConfigurableConversionService conversionService)
/*     */   {
/* 504 */     this.propertyResolver.setConversionService(conversionService);
/*     */   }
/*     */ 
/*     */   public ConfigurableConversionService getConversionService()
/*     */   {
/* 509 */     return this.propertyResolver.getConversionService();
/*     */   }
/*     */ 
/*     */   public void setPlaceholderPrefix(String placeholderPrefix)
/*     */   {
/* 514 */     this.propertyResolver.setPlaceholderPrefix(placeholderPrefix);
/*     */   }
/*     */ 
/*     */   public void setPlaceholderSuffix(String placeholderSuffix)
/*     */   {
/* 519 */     this.propertyResolver.setPlaceholderSuffix(placeholderSuffix);
/*     */   }
/*     */ 
/*     */   public void setValueSeparator(String valueSeparator)
/*     */   {
/* 524 */     this.propertyResolver.setValueSeparator(valueSeparator);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 530 */     return String.format("%s {activeProfiles=%s, defaultProfiles=%s, propertySources=%s}", new Object[] { 
/* 531 */       getClass().getSimpleName(), this.activeProfiles, this.defaultProfiles, this.propertySources });
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.AbstractEnvironment
 * JD-Core Version:    0.6.2
 */