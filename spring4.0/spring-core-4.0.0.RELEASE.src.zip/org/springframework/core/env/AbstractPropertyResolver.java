/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.util.PropertyPlaceholderHelper;
/*     */ import org.springframework.util.PropertyPlaceholderHelper.PlaceholderResolver;
/*     */ 
/*     */ public abstract class AbstractPropertyResolver
/*     */   implements ConfigurablePropertyResolver
/*     */ {
/*  39 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  41 */   protected ConfigurableConversionService conversionService = new DefaultConversionService();
/*     */   private PropertyPlaceholderHelper nonStrictHelper;
/*     */   private PropertyPlaceholderHelper strictHelper;
/*  47 */   private boolean ignoreUnresolvableNestedPlaceholders = false;
/*     */ 
/*  49 */   private String placeholderPrefix = "${";
/*     */ 
/*  51 */   private String placeholderSuffix = "}";
/*     */ 
/*  53 */   private String valueSeparator = ":";
/*     */ 
/*  55 */   private final Set<String> requiredProperties = new LinkedHashSet();
/*     */ 
/*     */   public ConfigurableConversionService getConversionService()
/*     */   {
/*  60 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */   public void setConversionService(ConfigurableConversionService conversionService)
/*     */   {
/*  65 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   public String getProperty(String key, String defaultValue)
/*     */   {
/*  70 */     String value = getProperty(key);
/*  71 */     return value != null ? value : defaultValue;
/*     */   }
/*     */ 
/*     */   public <T> T getProperty(String key, Class<T> targetType, T defaultValue)
/*     */   {
/*  76 */     Object value = getProperty(key, targetType);
/*  77 */     return value != null ? value : defaultValue;
/*     */   }
/*     */ 
/*     */   public void setRequiredProperties(String[] requiredProperties)
/*     */   {
/*  82 */     for (String key : requiredProperties)
/*  83 */       this.requiredProperties.add(key);
/*     */   }
/*     */ 
/*     */   public void validateRequiredProperties()
/*     */   {
/*  89 */     MissingRequiredPropertiesException ex = new MissingRequiredPropertiesException();
/*  90 */     for (String key : this.requiredProperties) {
/*  91 */       if (getProperty(key) == null) {
/*  92 */         ex.addMissingRequiredProperty(key);
/*     */       }
/*     */     }
/*  95 */     if (!ex.getMissingRequiredProperties().isEmpty())
/*  96 */       throw ex;
/*     */   }
/*     */ 
/*     */   public String getRequiredProperty(String key)
/*     */     throws IllegalStateException
/*     */   {
/* 102 */     String value = getProperty(key);
/* 103 */     if (value == null) {
/* 104 */       throw new IllegalStateException(String.format("required key [%s] not found", new Object[] { key }));
/*     */     }
/* 106 */     return value;
/*     */   }
/*     */ 
/*     */   public <T> T getRequiredProperty(String key, Class<T> valueType) throws IllegalStateException
/*     */   {
/* 111 */     Object value = getProperty(key, valueType);
/* 112 */     if (value == null) {
/* 113 */       throw new IllegalStateException(String.format("required key [%s] not found", new Object[] { key }));
/*     */     }
/* 115 */     return value;
/*     */   }
/*     */ 
/*     */   public void setPlaceholderPrefix(String placeholderPrefix)
/*     */   {
/* 124 */     this.placeholderPrefix = placeholderPrefix;
/*     */   }
/*     */ 
/*     */   public void setPlaceholderSuffix(String placeholderSuffix)
/*     */   {
/* 133 */     this.placeholderSuffix = placeholderSuffix;
/*     */   }
/*     */ 
/*     */   public void setValueSeparator(String valueSeparator)
/*     */   {
/* 142 */     this.valueSeparator = valueSeparator;
/*     */   }
/*     */ 
/*     */   public String resolvePlaceholders(String text)
/*     */   {
/* 147 */     if (this.nonStrictHelper == null) {
/* 148 */       this.nonStrictHelper = createPlaceholderHelper(true);
/*     */     }
/* 150 */     return doResolvePlaceholders(text, this.nonStrictHelper);
/*     */   }
/*     */ 
/*     */   public String resolveRequiredPlaceholders(String text) throws IllegalArgumentException
/*     */   {
/* 155 */     if (this.strictHelper == null) {
/* 156 */       this.strictHelper = createPlaceholderHelper(false);
/*     */     }
/* 158 */     return doResolvePlaceholders(text, this.strictHelper);
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnresolvableNestedPlaceholders(boolean ignoreUnresolvableNestedPlaceholders)
/*     */   {
/* 168 */     this.ignoreUnresolvableNestedPlaceholders = ignoreUnresolvableNestedPlaceholders;
/*     */   }
/*     */ 
/*     */   protected String resolveNestedPlaceholders(String value)
/*     */   {
/* 185 */     return this.ignoreUnresolvableNestedPlaceholders ? 
/* 185 */       resolvePlaceholders(value) : 
/* 185 */       resolveRequiredPlaceholders(value);
/*     */   }
/*     */ 
/*     */   private PropertyPlaceholderHelper createPlaceholderHelper(boolean ignoreUnresolvablePlaceholders) {
/* 189 */     return new PropertyPlaceholderHelper(this.placeholderPrefix, this.placeholderSuffix, this.valueSeparator, ignoreUnresolvablePlaceholders);
/*     */   }
/*     */ 
/*     */   private String doResolvePlaceholders(String text, PropertyPlaceholderHelper helper)
/*     */   {
/* 194 */     return helper.replacePlaceholders(text, new PropertyPlaceholderHelper.PlaceholderResolver()
/*     */     {
/*     */       public String resolvePlaceholder(String placeholderName) {
/* 197 */         return AbstractPropertyResolver.this.getPropertyAsRawString(placeholderName);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   protected abstract String getPropertyAsRawString(String paramString);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.AbstractPropertyResolver
 * JD-Core Version:    0.6.2
 */