/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class CommandLinePropertySource<T> extends EnumerablePropertySource<T>
/*     */ {
/*     */   public static final String COMMAND_LINE_PROPERTY_SOURCE_NAME = "commandLineArgs";
/*     */   public static final String DEFAULT_NON_OPTION_ARGS_PROPERTY_NAME = "nonOptionArgs";
/* 196 */   private String nonOptionArgsPropertyName = "nonOptionArgs";
/*     */ 
/*     */   public CommandLinePropertySource(T source)
/*     */   {
/* 203 */     super("commandLineArgs", source);
/*     */   }
/*     */ 
/*     */   public CommandLinePropertySource(String name, T source)
/*     */   {
/* 211 */     super(name, source);
/*     */   }
/*     */ 
/*     */   public void setNonOptionArgsPropertyName(String nonOptionArgsPropertyName)
/*     */   {
/* 219 */     this.nonOptionArgsPropertyName = nonOptionArgsPropertyName;
/*     */   }
/*     */ 
/*     */   public final boolean containsProperty(String name)
/*     */   {
/* 232 */     if (this.nonOptionArgsPropertyName.equals(name)) {
/* 233 */       return !getNonOptionArgs().isEmpty();
/*     */     }
/* 235 */     return containsOption(name);
/*     */   }
/*     */ 
/*     */   public final String getProperty(String name)
/*     */   {
/* 250 */     if (this.nonOptionArgsPropertyName.equals(name)) {
/* 251 */       Collection nonOptionArguments = getNonOptionArgs();
/* 252 */       if (nonOptionArguments.isEmpty()) {
/* 253 */         return null;
/*     */       }
/*     */ 
/* 256 */       return StringUtils.collectionToCommaDelimitedString(nonOptionArguments);
/*     */     }
/*     */ 
/* 259 */     Collection optionValues = getOptionValues(name);
/* 260 */     if (optionValues == null) {
/* 261 */       return null;
/*     */     }
/*     */ 
/* 264 */     return StringUtils.collectionToCommaDelimitedString(optionValues);
/*     */   }
/*     */ 
/*     */   protected abstract boolean containsOption(String paramString);
/*     */ 
/*     */   protected abstract List<String> getOptionValues(String paramString);
/*     */ 
/*     */   protected abstract List<String> getNonOptionArgs();
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.CommandLinePropertySource
 * JD-Core Version:    0.6.2
 */