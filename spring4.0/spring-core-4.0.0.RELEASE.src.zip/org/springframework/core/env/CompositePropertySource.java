/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class CompositePropertySource extends PropertySource<Object>
/*    */ {
/* 32 */   private Set<PropertySource<?>> propertySources = new LinkedHashSet();
/*    */ 
/*    */   public CompositePropertySource(String name)
/*    */   {
/* 41 */     super(name);
/*    */   }
/*    */ 
/*    */   public Object getProperty(String name)
/*    */   {
/* 47 */     for (PropertySource propertySource : this.propertySources) {
/* 48 */       Object candidate = propertySource.getProperty(name);
/* 49 */       if (candidate != null) {
/* 50 */         return candidate;
/*    */       }
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */   public void addPropertySource(PropertySource<?> propertySource) {
/* 57 */     this.propertySources.add(propertySource);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 62 */     return String.format("%s [name='%s', propertySources=%s]", new Object[] { 
/* 63 */       getClass().getSimpleName(), this.name, this.propertySources });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.CompositePropertySource
 * JD-Core Version:    0.6.2
 */