package org.springframework.core.env;

import java.util.Map;

public abstract interface ConfigurableEnvironment extends Environment, ConfigurablePropertyResolver
{
  public abstract void setActiveProfiles(String[] paramArrayOfString);

  public abstract void addActiveProfile(String paramString);

  public abstract void setDefaultProfiles(String[] paramArrayOfString);

  public abstract MutablePropertySources getPropertySources();

  public abstract Map<String, Object> getSystemEnvironment();

  public abstract Map<String, Object> getSystemProperties();

  public abstract void merge(ConfigurableEnvironment paramConfigurableEnvironment);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.ConfigurableEnvironment
 * JD-Core Version:    0.6.2
 */