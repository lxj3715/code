package org.springframework.core.env;

import org.springframework.core.convert.support.ConfigurableConversionService;

public abstract interface ConfigurablePropertyResolver extends PropertyResolver
{
  public abstract ConfigurableConversionService getConversionService();

  public abstract void setConversionService(ConfigurableConversionService paramConfigurableConversionService);

  public abstract void setPlaceholderPrefix(String paramString);

  public abstract void setPlaceholderSuffix(String paramString);

  public abstract void setValueSeparator(String paramString);

  public abstract void setRequiredProperties(String[] paramArrayOfString);

  public abstract void validateRequiredProperties()
    throws MissingRequiredPropertiesException;

  public abstract void setIgnoreUnresolvableNestedPlaceholders(boolean paramBoolean);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.ConfigurablePropertyResolver
 * JD-Core Version:    0.6.2
 */