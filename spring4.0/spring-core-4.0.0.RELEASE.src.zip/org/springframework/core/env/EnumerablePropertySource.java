/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class EnumerablePropertySource<T> extends PropertySource<T>
/*    */ {
/* 47 */   protected static final String[] EMPTY_NAMES_ARRAY = new String[0];
/*    */ 
/* 49 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public EnumerablePropertySource(String name, T source)
/*    */   {
/* 53 */     super(name, source);
/*    */   }
/*    */ 
/*    */   public abstract String[] getPropertyNames();
/*    */ 
/*    */   public boolean containsProperty(String name)
/*    */   {
/* 70 */     Assert.notNull(name, "property name must not be null");
/* 71 */     for (String candidate : getPropertyNames()) {
/* 72 */       if (candidate.equals(name)) {
/* 73 */         if (this.logger.isDebugEnabled()) {
/* 74 */           this.logger.debug(String.format("PropertySource [%s] contains '%s'", new Object[] { getName(), name }));
/*    */         }
/* 76 */         return true;
/*    */       }
/*    */     }
/* 79 */     if (this.logger.isTraceEnabled()) {
/* 80 */       this.logger.trace(String.format("PropertySource [%s] does not contain '%s'", new Object[] { getName(), name }));
/*    */     }
/* 82 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.EnumerablePropertySource
 * JD-Core Version:    0.6.2
 */