package org.springframework.core.env;

public abstract interface Environment extends PropertyResolver
{
  public abstract String[] getActiveProfiles();

  public abstract String[] getDefaultProfiles();

  public abstract boolean acceptsProfiles(String[] paramArrayOfString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.Environment
 * JD-Core Version:    0.6.2
 */