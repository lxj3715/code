package org.springframework.core.env;

public abstract interface EnvironmentCapable
{
  public abstract Environment getEnvironment();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.EnvironmentCapable
 * JD-Core Version:    0.6.2
 */