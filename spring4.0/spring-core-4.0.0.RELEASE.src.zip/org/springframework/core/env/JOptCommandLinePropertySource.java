/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import joptsimple.OptionSet;
/*     */ import joptsimple.OptionSpec;
/*     */ 
/*     */ public class JOptCommandLinePropertySource extends CommandLinePropertySource<OptionSet>
/*     */ {
/*     */   public JOptCommandLinePropertySource(OptionSet options)
/*     */   {
/*  65 */     super(options);
/*     */   }
/*     */ 
/*     */   public JOptCommandLinePropertySource(String name, OptionSet options)
/*     */   {
/*  73 */     super(name, options);
/*     */   }
/*     */ 
/*     */   protected boolean containsOption(String name)
/*     */   {
/*  78 */     return ((OptionSet)this.source).has(name);
/*     */   }
/*     */ 
/*     */   public String[] getPropertyNames()
/*     */   {
/*  83 */     List names = new ArrayList();
/*  84 */     for (OptionSpec spec : ((OptionSet)this.source).specs()) {
/*  85 */       List aliases = new ArrayList(spec.options());
/*  86 */       if (!aliases.isEmpty())
/*     */       {
/*  88 */         names.add(aliases.get(aliases.size() - 1));
/*     */       }
/*     */     }
/*  91 */     return (String[])names.toArray(new String[names.size()]);
/*     */   }
/*     */ 
/*     */   public List<String> getOptionValues(String name)
/*     */   {
/*  96 */     List argValues = ((OptionSet)this.source).valuesOf(name);
/*  97 */     List stringArgValues = new ArrayList();
/*  98 */     for (Iterator localIterator = argValues.iterator(); localIterator.hasNext(); ) { Object argValue = localIterator.next();
/*  99 */       if (!(argValue instanceof String)) {
/* 100 */         throw new IllegalArgumentException("argument values must be of type String");
/*     */       }
/* 102 */       stringArgValues.add((String)argValue);
/*     */     }
/* 104 */     if (stringArgValues.size() == 0) {
/* 105 */       if (((OptionSet)this.source).has(name)) {
/* 106 */         return Collections.emptyList();
/*     */       }
/*     */ 
/* 109 */       return null;
/*     */     }
/*     */ 
/* 112 */     return Collections.unmodifiableList(stringArgValues);
/*     */   }
/*     */ 
/*     */   protected List<String> getNonOptionArgs()
/*     */   {
/* 117 */     return ((OptionSet)this.source).nonOptionArguments();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.JOptCommandLinePropertySource
 * JD-Core Version:    0.6.2
 */