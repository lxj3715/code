/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class MapPropertySource extends EnumerablePropertySource<Map<String, Object>>
/*    */ {
/*    */   public MapPropertySource(String name, Map<String, Object> source)
/*    */   {
/* 31 */     super(name, source);
/*    */   }
/*    */ 
/*    */   public Object getProperty(String name)
/*    */   {
/* 36 */     return ((Map)this.source).get(name);
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames()
/*    */   {
/* 41 */     return (String[])((Map)this.source).keySet().toArray(EMPTY_NAMES_ARRAY);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.MapPropertySource
 * JD-Core Version:    0.6.2
 */