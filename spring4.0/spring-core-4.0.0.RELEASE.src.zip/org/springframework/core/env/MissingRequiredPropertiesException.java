/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class MissingRequiredPropertiesException extends IllegalStateException
/*    */ {
/* 34 */   private final Set<String> missingRequiredProperties = new LinkedHashSet();
/*    */ 
/*    */   public Set<String> getMissingRequiredProperties()
/*    */   {
/* 43 */     return this.missingRequiredProperties;
/*    */   }
/*    */ 
/*    */   void addMissingRequiredProperty(String key) {
/* 47 */     this.missingRequiredProperties.add(key);
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 52 */     return String.format("The following properties were declared as required but could not be resolved: %s", new Object[] { 
/* 54 */       getMissingRequiredProperties() });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.MissingRequiredPropertiesException
 * JD-Core Version:    0.6.2
 */