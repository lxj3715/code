/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class MutablePropertySources
/*     */   implements PropertySources
/*     */ {
/*     */   static final String NON_EXISTENT_PROPERTY_SOURCE_MESSAGE = "PropertySource named [%s] does not exist";
/*     */   static final String ILLEGAL_RELATIVE_ADDITION_MESSAGE = "PropertySource named [%s] cannot be added relative to itself";
/*     */   private final Log logger;
/*  47 */   private final LinkedList<PropertySource<?>> propertySourceList = new LinkedList();
/*     */ 
/*     */   public MutablePropertySources()
/*     */   {
/*  54 */     this.logger = LogFactory.getLog(getClass());
/*     */   }
/*     */ 
/*     */   public MutablePropertySources(PropertySources propertySources)
/*     */   {
/*  62 */     this();
/*  63 */     for (PropertySource propertySource : propertySources)
/*  64 */       addLast(propertySource);
/*     */   }
/*     */ 
/*     */   MutablePropertySources(Log logger)
/*     */   {
/*  73 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   public boolean contains(String name)
/*     */   {
/*  79 */     return this.propertySourceList.contains(PropertySource.named(name));
/*     */   }
/*     */ 
/*     */   public PropertySource<?> get(String name)
/*     */   {
/*  84 */     int index = this.propertySourceList.indexOf(PropertySource.named(name));
/*  85 */     return index == -1 ? null : (PropertySource)this.propertySourceList.get(index);
/*     */   }
/*     */ 
/*     */   public Iterator<PropertySource<?>> iterator()
/*     */   {
/*  90 */     return this.propertySourceList.iterator();
/*     */   }
/*     */ 
/*     */   public void addFirst(PropertySource<?> propertySource)
/*     */   {
/*  97 */     if (this.logger.isDebugEnabled()) {
/*  98 */       this.logger.debug(String.format("Adding [%s] PropertySource with highest search precedence", new Object[] { propertySource
/*  99 */         .getName() }));
/*     */     }
/* 101 */     removeIfPresent(propertySource);
/* 102 */     this.propertySourceList.addFirst(propertySource);
/*     */   }
/*     */ 
/*     */   public void addLast(PropertySource<?> propertySource)
/*     */   {
/* 109 */     if (this.logger.isDebugEnabled()) {
/* 110 */       this.logger.debug(String.format("Adding [%s] PropertySource with lowest search precedence", new Object[] { propertySource
/* 111 */         .getName() }));
/*     */     }
/* 113 */     removeIfPresent(propertySource);
/* 114 */     this.propertySourceList.addLast(propertySource);
/*     */   }
/*     */ 
/*     */   public void addBefore(String relativePropertySourceName, PropertySource<?> propertySource)
/*     */   {
/* 122 */     if (this.logger.isDebugEnabled()) {
/* 123 */       this.logger.debug(String.format("Adding [%s] PropertySource with search precedence immediately higher than [%s]", new Object[] { propertySource
/* 124 */         .getName(), relativePropertySourceName }));
/*     */     }
/* 126 */     assertLegalRelativeAddition(relativePropertySourceName, propertySource);
/* 127 */     removeIfPresent(propertySource);
/* 128 */     int index = assertPresentAndGetIndex(relativePropertySourceName);
/* 129 */     addAtIndex(index, propertySource);
/*     */   }
/*     */ 
/*     */   public void addAfter(String relativePropertySourceName, PropertySource<?> propertySource)
/*     */   {
/* 137 */     if (this.logger.isDebugEnabled()) {
/* 138 */       this.logger.debug(String.format("Adding [%s] PropertySource with search precedence immediately lower than [%s]", new Object[] { propertySource
/* 139 */         .getName(), relativePropertySourceName }));
/*     */     }
/* 141 */     assertLegalRelativeAddition(relativePropertySourceName, propertySource);
/* 142 */     removeIfPresent(propertySource);
/* 143 */     int index = assertPresentAndGetIndex(relativePropertySourceName);
/* 144 */     addAtIndex(index + 1, propertySource);
/*     */   }
/*     */ 
/*     */   public int precedenceOf(PropertySource<?> propertySource)
/*     */   {
/* 151 */     return this.propertySourceList.indexOf(propertySource);
/*     */   }
/*     */ 
/*     */   public PropertySource<?> remove(String name)
/*     */   {
/* 159 */     if (this.logger.isDebugEnabled()) {
/* 160 */       this.logger.debug(String.format("Removing [%s] PropertySource", new Object[] { name }));
/*     */     }
/* 162 */     int index = this.propertySourceList.indexOf(PropertySource.named(name));
/* 163 */     return index == -1 ? null : (PropertySource)this.propertySourceList.remove(index);
/*     */   }
/*     */ 
/*     */   public void replace(String name, PropertySource<?> propertySource)
/*     */   {
/* 174 */     if (this.logger.isDebugEnabled()) {
/* 175 */       this.logger.debug(String.format("Replacing [%s] PropertySource with [%s]", new Object[] { name, propertySource
/* 176 */         .getName() }));
/*     */     }
/* 178 */     int index = assertPresentAndGetIndex(name);
/* 179 */     this.propertySourceList.set(index, propertySource);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 186 */     return this.propertySourceList.size();
/*     */   }
/*     */ 
/*     */   public synchronized String toString()
/*     */   {
/* 191 */     String[] names = new String[size()];
/* 192 */     for (int i = 0; i < size(); i++) {
/* 193 */       names[i] = ((PropertySource)this.propertySourceList.get(i)).getName();
/*     */     }
/* 195 */     return String.format("[%s]", new Object[] { StringUtils.arrayToCommaDelimitedString(names) });
/*     */   }
/*     */ 
/*     */   protected void assertLegalRelativeAddition(String relativePropertySourceName, PropertySource<?> propertySource)
/*     */   {
/* 202 */     String newPropertySourceName = propertySource.getName();
/* 203 */     Assert.isTrue(!relativePropertySourceName.equals(newPropertySourceName), 
/* 204 */       String.format("PropertySource named [%s] cannot be added relative to itself", new Object[] { newPropertySourceName }));
/*     */   }
/*     */ 
/*     */   protected void removeIfPresent(PropertySource<?> propertySource)
/*     */   {
/* 211 */     if (this.propertySourceList.contains(propertySource))
/* 212 */       this.propertySourceList.remove(propertySource);
/*     */   }
/*     */ 
/*     */   private void addAtIndex(int index, PropertySource<?> propertySource)
/*     */   {
/* 220 */     removeIfPresent(propertySource);
/* 221 */     this.propertySourceList.add(index, propertySource);
/*     */   }
/*     */ 
/*     */   private int assertPresentAndGetIndex(String name)
/*     */   {
/* 231 */     int index = this.propertySourceList.indexOf(PropertySource.named(name));
/* 232 */     Assert.isTrue(index >= 0, String.format("PropertySource named [%s] does not exist", new Object[] { name }));
/* 233 */     return index;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.MutablePropertySources
 * JD-Core Version:    0.6.2
 */