/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class PropertiesPropertySource extends MapPropertySource
/*    */ {
/*    */   public PropertiesPropertySource(String name, Properties source)
/*    */   {
/* 39 */     super(name, source);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.PropertiesPropertySource
 * JD-Core Version:    0.6.2
 */