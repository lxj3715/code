/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class PropertySource<T>
/*     */ {
/*  58 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   protected final String name;
/*     */   protected final T source;
/*     */ 
/*     */   public PropertySource(String name, T source)
/*     */   {
/*  68 */     Assert.hasText(name, "Property source name must contain at least one character");
/*  69 */     Assert.notNull(source, "Property source must not be null");
/*  70 */     this.name = name;
/*  71 */     this.source = source;
/*     */   }
/*     */ 
/*     */   public PropertySource(String name)
/*     */   {
/*  83 */     this(name, new Object());
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  90 */     return this.name;
/*     */   }
/*     */ 
/*     */   public T getSource()
/*     */   {
/*  97 */     return this.source;
/*     */   }
/*     */ 
/*     */   public boolean containsProperty(String name)
/*     */   {
/* 108 */     return getProperty(name) != null;
/*     */   }
/*     */ 
/*     */   public abstract Object getProperty(String paramString);
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 124 */     int prime = 31;
/* 125 */     int result = 1;
/* 126 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/* 127 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 141 */     if (this == obj)
/* 142 */       return true;
/* 143 */     if (obj == null)
/* 144 */       return false;
/* 145 */     if (!(obj instanceof PropertySource))
/* 146 */       return false;
/* 147 */     PropertySource other = (PropertySource)obj;
/* 148 */     if (this.name == null) {
/* 149 */       if (other.name != null)
/* 150 */         return false;
/* 151 */     } else if (!this.name.equals(other.name))
/* 152 */       return false;
/* 153 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 169 */     if (this.logger.isDebugEnabled()) {
/* 170 */       return String.format("%s@%s [name='%s', properties=%s]", new Object[] { 
/* 171 */         getClass().getSimpleName(), Integer.valueOf(System.identityHashCode(this)), this.name, this.source });
/*     */     }
/*     */ 
/* 174 */     return String.format("%s [name='%s']", new Object[] { 
/* 175 */       getClass().getSimpleName(), this.name });
/*     */   }
/*     */ 
/*     */   public static PropertySource<?> named(String name)
/*     */   {
/* 200 */     return new ComparisonPropertySource(name);
/*     */   }
/*     */ 
/*     */   static class ComparisonPropertySource extends PropertySource.StubPropertySource
/*     */   {
/*     */     private static final String USAGE_ERROR = "ComparisonPropertySource instances are for collection comparison use only";
/*     */ 
/*     */     public ComparisonPropertySource(String name)
/*     */     {
/* 243 */       super();
/*     */     }
/*     */ 
/*     */     public Object getSource()
/*     */     {
/* 248 */       throw new UnsupportedOperationException("ComparisonPropertySource instances are for collection comparison use only");
/*     */     }
/*     */ 
/*     */     public boolean containsProperty(String name)
/*     */     {
/* 253 */       throw new UnsupportedOperationException("ComparisonPropertySource instances are for collection comparison use only");
/*     */     }
/*     */ 
/*     */     public String getProperty(String name)
/*     */     {
/* 258 */       throw new UnsupportedOperationException("ComparisonPropertySource instances are for collection comparison use only");
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 263 */       return String.format("%s [name='%s']", new Object[] { getClass().getSimpleName(), this.name });
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class StubPropertySource extends PropertySource<Object>
/*     */   {
/*     */     public StubPropertySource(String name)
/*     */     {
/* 220 */       super(new Object());
/*     */     }
/*     */ 
/*     */     public String getProperty(String name)
/*     */     {
/* 228 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.PropertySource
 * JD-Core Version:    0.6.2
 */