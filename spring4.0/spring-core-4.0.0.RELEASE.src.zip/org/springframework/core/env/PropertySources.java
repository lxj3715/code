package org.springframework.core.env;

public abstract interface PropertySources extends Iterable<PropertySource<?>>
{
  public abstract boolean contains(String paramString);

  public abstract PropertySource<?> get(String paramString);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.PropertySources
 * JD-Core Version:    0.6.2
 */