/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class PropertySourcesPropertyResolver extends AbstractPropertyResolver
/*     */ {
/*     */   private final PropertySources propertySources;
/*     */ 
/*     */   public PropertySourcesPropertyResolver(PropertySources propertySources)
/*     */   {
/*  42 */     this.propertySources = propertySources;
/*     */   }
/*     */ 
/*     */   public boolean containsProperty(String key)
/*     */   {
/*  48 */     if (this.propertySources != null) {
/*  49 */       for (PropertySource propertySource : this.propertySources) {
/*  50 */         if (propertySource.containsProperty(key)) {
/*  51 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/*  60 */     return (String)getProperty(key, String.class, true);
/*     */   }
/*     */ 
/*     */   public <T> T getProperty(String key, Class<T> targetValueType)
/*     */   {
/*  65 */     return getProperty(key, targetValueType, true);
/*     */   }
/*     */ 
/*     */   protected String getPropertyAsRawString(String key)
/*     */   {
/*  70 */     return (String)getProperty(key, String.class, false);
/*     */   }
/*     */ 
/*     */   protected <T> T getProperty(String key, Class<T> targetValueType, boolean resolveNestedPlaceholders) {
/*  74 */     boolean debugEnabled = this.logger.isDebugEnabled();
/*  75 */     if (this.logger.isTraceEnabled()) {
/*  76 */       this.logger.trace(String.format("getProperty(\"%s\", %s)", new Object[] { key, targetValueType.getSimpleName() }));
/*     */     }
/*  78 */     if (this.propertySources != null) {
/*  79 */       for (PropertySource propertySource : this.propertySources) {
/*  80 */         if (debugEnabled)
/*  81 */           this.logger.debug(String.format("Searching for key '%s' in [%s]", new Object[] { key, propertySource.getName() }));
/*     */         Object value;
/*  84 */         if ((value = propertySource.getProperty(key)) != null) {
/*  85 */           Class valueType = value.getClass();
/*  86 */           if ((resolveNestedPlaceholders) && ((value instanceof String))) {
/*  87 */             value = resolveNestedPlaceholders((String)value);
/*     */           }
/*  89 */           if (debugEnabled) {
/*  90 */             this.logger.debug(String.format("Found key '%s' in [%s] with type [%s] and value '%s'", new Object[] { key, propertySource
/*  91 */               .getName(), valueType.getSimpleName(), value }));
/*     */           }
/*  93 */           if (!this.conversionService.canConvert(valueType, targetValueType)) {
/*  94 */             throw new IllegalArgumentException(String.format("Cannot convert value [%s] from source type [%s] to target type [%s]", new Object[] { value, valueType
/*  96 */               .getSimpleName(), targetValueType.getSimpleName() }));
/*     */           }
/*  98 */           return this.conversionService.convert(value, targetValueType);
/*     */         }
/*     */       }
/*     */     }
/* 102 */     if (debugEnabled) {
/* 103 */       this.logger.debug(String.format("Could not find key '%s' in any property source. Returning [null]", new Object[] { key }));
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   public <T> Class<T> getPropertyAsClass(String key, Class<T> targetValueType)
/*     */   {
/* 110 */     boolean debugEnabled = this.logger.isDebugEnabled();
/* 111 */     if (this.logger.isTraceEnabled()) {
/* 112 */       this.logger.trace(String.format("getPropertyAsClass(\"%s\", %s)", new Object[] { key, targetValueType.getSimpleName() }));
/*     */     }
/* 114 */     if (this.propertySources != null) {
/* 115 */       for (PropertySource propertySource : this.propertySources) {
/* 116 */         if (debugEnabled) {
/* 117 */           this.logger.debug(String.format("Searching for key '%s' in [%s]", new Object[] { key, propertySource.getName() }));
/*     */         }
/* 119 */         Object value = propertySource.getProperty(key);
/* 120 */         if (value != null) {
/* 121 */           if (debugEnabled)
/* 122 */             this.logger.debug(String.format("Found key '%s' in [%s] with value '%s'", new Object[] { key, propertySource.getName(), value }));
/*     */           Class clazz;
/* 125 */           if ((value instanceof String)) {
/*     */             try {
/* 127 */               clazz = ClassUtils.forName((String)value, null);
/*     */             }
/*     */             catch (Exception ex)
/*     */             {
/*     */               Class clazz;
/* 130 */               throw new ClassConversionException((String)value, targetValueType, ex);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/*     */             Class clazz;
/* 133 */             if ((value instanceof Class)) {
/* 134 */               clazz = (Class)value;
/*     */             }
/*     */             else
/* 137 */               clazz = value.getClass();
/*     */           }
/* 139 */           if (!targetValueType.isAssignableFrom(clazz)) {
/* 140 */             throw new ClassConversionException(clazz, targetValueType);
/*     */           }
/*     */ 
/* 143 */           Class targetClass = clazz;
/* 144 */           return targetClass;
/*     */         }
/*     */       }
/*     */     }
/* 148 */     if (debugEnabled) {
/* 149 */       this.logger.debug(String.format("Could not find key '%s' in any property source. Returning [null]", new Object[] { key }));
/*     */     }
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */   private static class ClassConversionException extends ConversionException
/*     */   {
/*     */     public ClassConversionException(Class<?> actual, Class<?> expected)
/*     */     {
/* 159 */       super();
/*     */     }
/*     */ 
/*     */     public ClassConversionException(String actual, Class<?> expected, Exception ex) {
/* 163 */       super(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.PropertySourcesPropertyResolver
 * JD-Core Version:    0.6.2
 */