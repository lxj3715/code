/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ abstract class ReadOnlySystemAttributesMap
/*     */   implements Map<String, String>
/*     */ {
/*     */   public boolean containsKey(Object key)
/*     */   {
/*  44 */     return get(key) != null;
/*     */   }
/*     */ 
/*     */   public String get(Object key)
/*     */   {
/*  53 */     Assert.isInstanceOf(String.class, key, 
/*  54 */       String.format("expected key [%s] to be of type String, got %s", new Object[] { key, key
/*  55 */       .getClass().getName() }));
/*     */ 
/*  57 */     return getSystemAttribute((String)key);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */   protected abstract String getSystemAttribute(String paramString);
/*     */ 
/*     */   public int size()
/*     */   {
/*  76 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public String put(String key, String value)
/*     */   {
/*  81 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/*  86 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public String remove(Object key)
/*     */   {
/*  91 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  96 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Set<String> keySet()
/*     */   {
/* 101 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends String> m)
/*     */   {
/* 106 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Collection<String> values()
/*     */   {
/* 111 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<String, String>> entrySet()
/*     */   {
/* 116 */     return Collections.emptySet();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.ReadOnlySystemAttributesMap
 * JD-Core Version:    0.6.2
 */