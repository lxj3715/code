/*     */ package org.springframework.core.env;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SystemEnvironmentPropertySource extends MapPropertySource
/*     */ {
/*     */   public SystemEnvironmentPropertySource(String name, Map<String, Object> source)
/*     */   {
/*  70 */     super(name, source);
/*     */   }
/*     */ 
/*     */   public boolean containsProperty(String name)
/*     */   {
/*  79 */     return getProperty(name) != null;
/*     */   }
/*     */ 
/*     */   public Object getProperty(String name)
/*     */   {
/*  89 */     Assert.notNull(name, "property name must not be null");
/*  90 */     String actualName = resolvePropertyName(name);
/*  91 */     if ((this.logger.isDebugEnabled()) && (!name.equals(actualName))) {
/*  92 */       this.logger.debug(String.format("PropertySource [%s] does not contain '%s', but found equivalent '%s'", new Object[] { 
/*  94 */         getName(), name, actualName }));
/*     */     }
/*  96 */     return super.getProperty(actualName);
/*     */   }
/*     */ 
/*     */   private String resolvePropertyName(String name)
/*     */   {
/* 105 */     if (super.containsProperty(name)) {
/* 106 */       return name;
/*     */     }
/*     */ 
/* 109 */     String usName = name.replace('.', '_');
/* 110 */     if ((!name.equals(usName)) && (super.containsProperty(usName))) {
/* 111 */       return usName;
/*     */     }
/*     */ 
/* 114 */     String ucName = name.toUpperCase();
/* 115 */     if (!name.equals(ucName)) {
/* 116 */       if (super.containsProperty(ucName)) {
/* 117 */         return ucName;
/*     */       }
/* 119 */       String usUcName = ucName.replace('.', '_');
/* 120 */       if ((!ucName.equals(usUcName)) && (super.containsProperty(usUcName))) {
/* 121 */         return usUcName;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 126 */     return name;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.env.SystemEnvironmentPropertySource
 * JD-Core Version:    0.6.2
 */