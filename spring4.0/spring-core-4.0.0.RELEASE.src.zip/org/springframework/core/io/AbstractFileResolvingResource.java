/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ 
/*     */ public abstract class AbstractFileResolvingResource extends AbstractResource
/*     */ {
/*     */   public File getFile()
/*     */     throws IOException
/*     */   {
/*  48 */     URL url = getURL();
/*  49 */     if (url.getProtocol().startsWith("vfs")) {
/*  50 */       return VfsResourceDelegate.getResource(url).getFile();
/*     */     }
/*  52 */     return ResourceUtils.getFile(url, getDescription());
/*     */   }
/*     */ 
/*     */   protected File getFileForLastModifiedCheck()
/*     */     throws IOException
/*     */   {
/*  61 */     URL url = getURL();
/*  62 */     if (ResourceUtils.isJarURL(url)) {
/*  63 */       URL actualUrl = ResourceUtils.extractJarFileURL(url);
/*  64 */       if (actualUrl.getProtocol().startsWith("vfs")) {
/*  65 */         return VfsResourceDelegate.getResource(actualUrl).getFile();
/*     */       }
/*  67 */       return ResourceUtils.getFile(actualUrl, "Jar URL");
/*     */     }
/*     */ 
/*  70 */     return getFile();
/*     */   }
/*     */ 
/*     */   protected File getFile(URI uri)
/*     */     throws IOException
/*     */   {
/*  80 */     if (uri.getScheme().startsWith("vfs")) {
/*  81 */       return VfsResourceDelegate.getResource(uri).getFile();
/*     */     }
/*  83 */     return ResourceUtils.getFile(uri, getDescription());
/*     */   }
/*     */ 
/*     */   public boolean exists()
/*     */   {
/*     */     try
/*     */     {
/*  90 */       URL url = getURL();
/*  91 */       if (ResourceUtils.isFileURL(url))
/*     */       {
/*  93 */         return getFile().exists();
/*     */       }
/*     */ 
/*  97 */       URLConnection con = url.openConnection();
/*  98 */       ResourceUtils.useCachesIfNecessary(con);
/*  99 */       HttpURLConnection httpCon = (con instanceof HttpURLConnection) ? (HttpURLConnection)con : null;
/*     */ 
/* 101 */       if (httpCon != null) {
/* 102 */         httpCon.setRequestMethod("HEAD");
/* 103 */         int code = httpCon.getResponseCode();
/* 104 */         if (code == 200) {
/* 105 */           return true;
/*     */         }
/* 107 */         if (code == 404) {
/* 108 */           return false;
/*     */         }
/*     */       }
/* 111 */       if (con.getContentLength() >= 0) {
/* 112 */         return true;
/*     */       }
/* 114 */       if (httpCon != null)
/*     */       {
/* 116 */         httpCon.disconnect();
/* 117 */         return false;
/*     */       }
/*     */ 
/* 121 */       InputStream is = getInputStream();
/* 122 */       is.close();
/* 123 */       return true;
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/* 128 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isReadable()
/*     */   {
/*     */     try
/*     */     {
/* 135 */       URL url = getURL();
/* 136 */       if (ResourceUtils.isFileURL(url))
/*     */       {
/* 138 */         File file = getFile();
/* 139 */         return (file.canRead()) && (!file.isDirectory());
/*     */       }
/*     */ 
/* 142 */       return true;
/*     */     }
/*     */     catch (IOException ex) {
/*     */     }
/* 146 */     return false;
/*     */   }
/*     */ 
/*     */   public long contentLength()
/*     */     throws IOException
/*     */   {
/* 152 */     URL url = getURL();
/* 153 */     if (ResourceUtils.isFileURL(url))
/*     */     {
/* 155 */       return getFile().length();
/*     */     }
/*     */ 
/* 159 */     URLConnection con = url.openConnection();
/* 160 */     ResourceUtils.useCachesIfNecessary(con);
/* 161 */     if ((con instanceof HttpURLConnection)) {
/* 162 */       ((HttpURLConnection)con).setRequestMethod("HEAD");
/*     */     }
/* 164 */     return con.getContentLength();
/*     */   }
/*     */ 
/*     */   public long lastModified()
/*     */     throws IOException
/*     */   {
/* 170 */     URL url = getURL();
/* 171 */     if ((ResourceUtils.isFileURL(url)) || (ResourceUtils.isJarURL(url)))
/*     */     {
/* 173 */       return super.lastModified();
/*     */     }
/*     */ 
/* 177 */     URLConnection con = url.openConnection();
/* 178 */     ResourceUtils.useCachesIfNecessary(con);
/* 179 */     if ((con instanceof HttpURLConnection)) {
/* 180 */       ((HttpURLConnection)con).setRequestMethod("HEAD");
/*     */     }
/* 182 */     return con.getLastModified();
/*     */   }
/*     */ 
/*     */   private static class VfsResourceDelegate
/*     */   {
/*     */     public static Resource getResource(URL url)
/*     */       throws IOException
/*     */     {
/* 193 */       return new VfsResource(VfsUtils.getRoot(url));
/*     */     }
/*     */ 
/*     */     public static Resource getResource(URI uri) throws IOException {
/* 197 */       return new VfsResource(VfsUtils.getRoot(uri));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.AbstractFileResolvingResource
 * JD-Core Version:    0.6.2
 */