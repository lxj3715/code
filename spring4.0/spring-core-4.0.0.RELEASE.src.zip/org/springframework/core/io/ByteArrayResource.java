/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class ByteArrayResource extends AbstractResource
/*     */ {
/*     */   private final byte[] byteArray;
/*     */   private final String description;
/*     */ 
/*     */   public ByteArrayResource(byte[] byteArray)
/*     */   {
/*  51 */     this(byteArray, "resource loaded from byte array");
/*     */   }
/*     */ 
/*     */   public ByteArrayResource(byte[] byteArray, String description)
/*     */   {
/*  60 */     if (byteArray == null) {
/*  61 */       throw new IllegalArgumentException("Byte array must not be null");
/*     */     }
/*  63 */     this.byteArray = byteArray;
/*  64 */     this.description = (description != null ? description : "");
/*     */   }
/*     */ 
/*     */   public final byte[] getByteArray()
/*     */   {
/*  71 */     return this.byteArray;
/*     */   }
/*     */ 
/*     */   public boolean exists()
/*     */   {
/*  80 */     return true;
/*     */   }
/*     */ 
/*     */   public long contentLength()
/*     */   {
/*  88 */     return this.byteArray.length;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/*  98 */     return new ByteArrayInputStream(this.byteArray);
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 106 */     return this.description;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 117 */     return (obj == this) || (((obj instanceof ByteArrayResource)) && 
/* 117 */       (Arrays.equals(((ByteArrayResource)obj).byteArray, this.byteArray)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 126 */     return [B.class.hashCode() * 29 * this.byteArray.length;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.ByteArrayResource
 * JD-Core Version:    0.6.2
 */