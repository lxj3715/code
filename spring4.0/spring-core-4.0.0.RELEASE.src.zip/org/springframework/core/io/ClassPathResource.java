/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ClassPathResource extends AbstractFileResolvingResource
/*     */ {
/*     */   private final String path;
/*     */   private ClassLoader classLoader;
/*     */   private Class<?> clazz;
/*     */ 
/*     */   public ClassPathResource(String path)
/*     */   {
/*  63 */     this(path, (ClassLoader)null);
/*     */   }
/*     */ 
/*     */   public ClassPathResource(String path, ClassLoader classLoader)
/*     */   {
/*  76 */     Assert.notNull(path, "Path must not be null");
/*  77 */     String pathToUse = StringUtils.cleanPath(path);
/*  78 */     if (pathToUse.startsWith("/")) {
/*  79 */       pathToUse = pathToUse.substring(1);
/*     */     }
/*  81 */     this.path = pathToUse;
/*  82 */     this.classLoader = (classLoader != null ? classLoader : ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public ClassPathResource(String path, Class<?> clazz)
/*     */   {
/*  94 */     Assert.notNull(path, "Path must not be null");
/*  95 */     this.path = StringUtils.cleanPath(path);
/*  96 */     this.clazz = clazz;
/*     */   }
/*     */ 
/*     */   protected ClassPathResource(String path, ClassLoader classLoader, Class<?> clazz)
/*     */   {
/* 107 */     this.path = StringUtils.cleanPath(path);
/* 108 */     this.classLoader = classLoader;
/* 109 */     this.clazz = clazz;
/*     */   }
/*     */ 
/*     */   public final String getPath()
/*     */   {
/* 116 */     return this.path;
/*     */   }
/*     */ 
/*     */   public final ClassLoader getClassLoader()
/*     */   {
/* 123 */     return this.classLoader != null ? this.classLoader : this.clazz.getClassLoader();
/*     */   }
/*     */ 
/*     */   public boolean exists()
/*     */   {
/*     */     URL url;
/*     */     URL url;
/* 134 */     if (this.clazz != null) {
/* 135 */       url = this.clazz.getResource(this.path);
/*     */     }
/*     */     else {
/* 138 */       url = this.classLoader.getResource(this.path);
/*     */     }
/* 140 */     return url != null;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/*     */     InputStream is;
/*     */     InputStream is;
/* 151 */     if (this.clazz != null) {
/* 152 */       is = this.clazz.getResourceAsStream(this.path);
/*     */     }
/*     */     else {
/* 155 */       is = this.classLoader.getResourceAsStream(this.path);
/*     */     }
/* 157 */     if (is == null) {
/* 158 */       throw new FileNotFoundException(new StringBuilder().append(getDescription()).append(" cannot be opened because it does not exist").toString());
/*     */     }
/* 160 */     return is;
/*     */   }
/*     */ 
/*     */   public URL getURL()
/*     */     throws IOException
/*     */   {
/*     */     URL url;
/*     */     URL url;
/* 171 */     if (this.clazz != null) {
/* 172 */       url = this.clazz.getResource(this.path);
/*     */     }
/*     */     else {
/* 175 */       url = this.classLoader.getResource(this.path);
/*     */     }
/* 177 */     if (url == null) {
/* 178 */       throw new FileNotFoundException(new StringBuilder().append(getDescription()).append(" cannot be resolved to URL because it does not exist").toString());
/*     */     }
/* 180 */     return url;
/*     */   }
/*     */ 
/*     */   public Resource createRelative(String relativePath)
/*     */   {
/* 190 */     String pathToUse = StringUtils.applyRelativePath(this.path, relativePath);
/* 191 */     return new ClassPathResource(pathToUse, this.classLoader, this.clazz);
/*     */   }
/*     */ 
/*     */   public String getFilename()
/*     */   {
/* 201 */     return StringUtils.getFilename(this.path);
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 209 */     StringBuilder builder = new StringBuilder("class path resource [");
/* 210 */     String pathToUse = this.path;
/* 211 */     if ((this.clazz != null) && (!pathToUse.startsWith("/"))) {
/* 212 */       builder.append(ClassUtils.classPackageAsResourcePath(this.clazz));
/* 213 */       builder.append('/');
/*     */     }
/* 215 */     if (pathToUse.startsWith("/")) {
/* 216 */       pathToUse = pathToUse.substring(1);
/*     */     }
/* 218 */     builder.append(pathToUse);
/* 219 */     builder.append(']');
/* 220 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 228 */     if (obj == this) {
/* 229 */       return true;
/*     */     }
/* 231 */     if ((obj instanceof ClassPathResource)) {
/* 232 */       ClassPathResource otherRes = (ClassPathResource)obj;
/*     */ 
/* 235 */       return (this.path.equals(otherRes.path)) && 
/* 234 */         (ObjectUtils.nullSafeEquals(this.classLoader, otherRes.classLoader)) && 
/* 235 */         (ObjectUtils.nullSafeEquals(this.clazz, otherRes.clazz));
/*     */     }
/*     */ 
/* 237 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 246 */     return this.path.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.ClassPathResource
 * JD-Core Version:    0.6.2
 */