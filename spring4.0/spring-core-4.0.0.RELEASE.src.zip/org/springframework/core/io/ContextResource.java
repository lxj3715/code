package org.springframework.core.io;

public abstract interface ContextResource extends Resource
{
  public abstract String getPathWithinContext();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.ContextResource
 * JD-Core Version:    0.6.2
 */