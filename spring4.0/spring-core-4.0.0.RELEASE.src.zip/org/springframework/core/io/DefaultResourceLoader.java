/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class DefaultResourceLoader
/*     */   implements ResourceLoader
/*     */ {
/*     */   private ClassLoader classLoader;
/*     */ 
/*     */   public DefaultResourceLoader()
/*     */   {
/*  53 */     this.classLoader = ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   public DefaultResourceLoader(ClassLoader classLoader)
/*     */   {
/*  62 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void setClassLoader(ClassLoader classLoader)
/*     */   {
/*  73 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/*  84 */     return this.classLoader != null ? this.classLoader : ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   public Resource getResource(String location)
/*     */   {
/*  90 */     Assert.notNull(location, "Location must not be null");
/*  91 */     if (location.startsWith("classpath:")) {
/*  92 */       return new ClassPathResource(location.substring("classpath:".length()), getClassLoader());
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  97 */       URL url = new URL(location);
/*  98 */       return new UrlResource(url);
/*     */     }
/*     */     catch (MalformedURLException ex) {
/*     */     }
/* 102 */     return getResourceByPath(location);
/*     */   }
/*     */ 
/*     */   protected Resource getResourceByPath(String path)
/*     */   {
/* 119 */     return new ClassPathContextResource(path, getClassLoader());
/*     */   }
/*     */ 
/*     */   protected static class ClassPathContextResource extends ClassPathResource
/*     */     implements ContextResource
/*     */   {
/*     */     public ClassPathContextResource(String path, ClassLoader classLoader)
/*     */     {
/* 130 */       super(classLoader);
/*     */     }
/*     */ 
/*     */     public String getPathWithinContext()
/*     */     {
/* 135 */       return getPath();
/*     */     }
/*     */ 
/*     */     public Resource createRelative(String relativePath)
/*     */     {
/* 140 */       String pathToUse = StringUtils.applyRelativePath(getPath(), relativePath);
/* 141 */       return new ClassPathContextResource(pathToUse, getClassLoader());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.DefaultResourceLoader
 * JD-Core Version:    0.6.2
 */