/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class InputStreamResource extends AbstractResource
/*     */ {
/*     */   private final InputStream inputStream;
/*     */   private final String description;
/*  46 */   private boolean read = false;
/*     */ 
/*     */   public InputStreamResource(InputStream inputStream)
/*     */   {
/*  54 */     this(inputStream, "resource loaded through InputStream");
/*     */   }
/*     */ 
/*     */   public InputStreamResource(InputStream inputStream, String description)
/*     */   {
/*  63 */     if (inputStream == null) {
/*  64 */       throw new IllegalArgumentException("InputStream must not be null");
/*     */     }
/*  66 */     this.inputStream = inputStream;
/*  67 */     this.description = (description != null ? description : "");
/*     */   }
/*     */ 
/*     */   public boolean exists()
/*     */   {
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isOpen()
/*     */   {
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException, IllegalStateException
/*     */   {
/*  93 */     if (this.read) {
/*  94 */       throw new IllegalStateException("InputStream has already been read - do not use InputStreamResource if a stream needs to be read multiple times");
/*     */     }
/*     */ 
/*  97 */     this.read = true;
/*  98 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 106 */     return this.description;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 116 */     return (obj == this) || (((obj instanceof InputStreamResource)) && 
/* 116 */       (((InputStreamResource)obj).inputStream
/* 116 */       .equals(this.inputStream)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 124 */     return this.inputStream.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.InputStreamResource
 * JD-Core Version:    0.6.2
 */