package org.springframework.core.io;

import java.io.IOException;
import java.io.InputStream;

public abstract interface InputStreamSource
{
  public abstract InputStream getInputStream()
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.InputStreamSource
 * JD-Core Version:    0.6.2
 */