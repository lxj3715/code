/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.OpenOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileTime;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class PathResource extends AbstractResource
/*     */   implements WritableResource
/*     */ {
/*     */   private final Path path;
/*     */ 
/*     */   public PathResource(Path path)
/*     */   {
/*  56 */     Assert.notNull(path, "Path must not be null");
/*  57 */     this.path = path.normalize();
/*     */   }
/*     */ 
/*     */   public PathResource(String path)
/*     */   {
/*  70 */     Assert.notNull(path, "Path must not be null");
/*  71 */     this.path = Paths.get(path, new String[0]).normalize();
/*     */   }
/*     */ 
/*     */   public PathResource(URI uri)
/*     */   {
/*  84 */     Assert.notNull(uri, "URI must not be null");
/*  85 */     this.path = Paths.get(uri).normalize();
/*     */   }
/*     */ 
/*     */   public final String getPath()
/*     */   {
/*  93 */     return this.path.toString();
/*     */   }
/*     */ 
/*     */   public boolean exists()
/*     */   {
/* 102 */     return Files.exists(this.path, new LinkOption[0]);
/*     */   }
/*     */ 
/*     */   public boolean isReadable()
/*     */   {
/* 113 */     return (Files.isReadable(this.path)) && (!Files.isDirectory(this.path, new LinkOption[0]));
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/* 122 */     if (!exists()) {
/* 123 */       throw new FileNotFoundException(getPath() + " (No such file or directory)");
/*     */     }
/* 125 */     if (Files.isDirectory(this.path, new LinkOption[0])) {
/* 126 */       throw new FileNotFoundException(getPath() + " (Is a directory)");
/*     */     }
/* 128 */     return Files.newInputStream(this.path, new OpenOption[0]);
/*     */   }
/*     */ 
/*     */   public URL getURL()
/*     */     throws IOException
/*     */   {
/* 138 */     return this.path.toUri().toURL();
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */     throws IOException
/*     */   {
/* 147 */     return this.path.toUri();
/*     */   }
/*     */ 
/*     */   public File getFile()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 156 */       return this.path.toFile();
/*     */     }
/*     */     catch (UnsupportedOperationException ex)
/*     */     {
/*     */     }
/* 161 */     throw new FileNotFoundException(this.path + " cannot be resolved to " + "absolute file path");
/*     */   }
/*     */ 
/*     */   public long contentLength()
/*     */     throws IOException
/*     */   {
/* 171 */     return Files.size(this.path);
/*     */   }
/*     */ 
/*     */   public long lastModified()
/*     */     throws IOException
/*     */   {
/* 182 */     return Files.getLastModifiedTime(this.path, new LinkOption[0]).toMillis();
/*     */   }
/*     */ 
/*     */   public Resource createRelative(String relativePath)
/*     */     throws IOException
/*     */   {
/* 192 */     return new PathResource(this.path.resolve(relativePath));
/*     */   }
/*     */ 
/*     */   public String getFilename()
/*     */   {
/* 201 */     return this.path.getFileName().toString();
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 206 */     return "path [" + this.path.toAbsolutePath() + "]";
/*     */   }
/*     */ 
/*     */   public boolean isWritable()
/*     */   {
/* 219 */     return (Files.isWritable(this.path)) && (!Files.isDirectory(this.path, new LinkOption[0]));
/*     */   }
/*     */ 
/*     */   public OutputStream getOutputStream()
/*     */     throws IOException
/*     */   {
/* 228 */     if (Files.isDirectory(this.path, new LinkOption[0])) {
/* 229 */       throw new FileNotFoundException(getPath() + " (Is a directory)");
/*     */     }
/* 231 */     return Files.newOutputStream(this.path, new OpenOption[0]);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 241 */     return (obj == this) || (((obj instanceof PathResource)) && 
/* 241 */       (this.path
/* 241 */       .equals(((PathResource)obj).path)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 249 */     return this.path.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.PathResource
 * JD-Core Version:    0.6.2
 */