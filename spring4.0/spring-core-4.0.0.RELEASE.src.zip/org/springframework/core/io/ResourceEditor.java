/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceEditor extends PropertyEditorSupport
/*     */ {
/*     */   private final ResourceLoader resourceLoader;
/*     */   private PropertyResolver propertyResolver;
/*     */   private final boolean ignoreUnresolvablePlaceholders;
/*     */ 
/*     */   public ResourceEditor()
/*     */   {
/*  63 */     this(new DefaultResourceLoader(), null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ResourceEditor(ResourceLoader resourceLoader)
/*     */   {
/*  75 */     this(resourceLoader, null, true);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ResourceEditor(ResourceLoader resourceLoader, boolean ignoreUnresolvablePlaceholders)
/*     */   {
/*  89 */     this(resourceLoader, null, ignoreUnresolvablePlaceholders);
/*     */   }
/*     */ 
/*     */   public ResourceEditor(ResourceLoader resourceLoader, PropertyResolver propertyResolver)
/*     */   {
/*  99 */     this(resourceLoader, propertyResolver, true);
/*     */   }
/*     */ 
/*     */   public ResourceEditor(ResourceLoader resourceLoader, PropertyResolver propertyResolver, boolean ignoreUnresolvablePlaceholders)
/*     */   {
/* 111 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 112 */     this.resourceLoader = resourceLoader;
/* 113 */     this.propertyResolver = propertyResolver;
/* 114 */     this.ignoreUnresolvablePlaceholders = ignoreUnresolvablePlaceholders;
/*     */   }
/*     */ 
/*     */   public void setAsText(String text)
/*     */   {
/* 120 */     if (StringUtils.hasText(text)) {
/* 121 */       String locationToUse = resolvePath(text).trim();
/* 122 */       setValue(this.resourceLoader.getResource(locationToUse));
/*     */     }
/*     */     else {
/* 125 */       setValue(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String resolvePath(String path)
/*     */   {
/* 138 */     if (this.propertyResolver == null) {
/* 139 */       this.propertyResolver = new StandardEnvironment();
/*     */     }
/*     */ 
/* 142 */     return this.ignoreUnresolvablePlaceholders ? this.propertyResolver.resolvePlaceholders(path) : this.propertyResolver
/* 142 */       .resolveRequiredPlaceholders(path);
/*     */   }
/*     */ 
/*     */   public String getAsText()
/*     */   {
/* 148 */     Resource value = (Resource)getValue();
/*     */     try
/*     */     {
/* 151 */       return value != null ? value.getURL().toExternalForm() : "";
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/* 156 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.ResourceEditor
 * JD-Core Version:    0.6.2
 */