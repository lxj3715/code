package org.springframework.core.io;

public abstract interface ResourceLoader
{
  public static final String CLASSPATH_URL_PREFIX = "classpath:";

  public abstract Resource getResource(String paramString);

  public abstract ClassLoader getClassLoader();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.ResourceLoader
 * JD-Core Version:    0.6.2
 */