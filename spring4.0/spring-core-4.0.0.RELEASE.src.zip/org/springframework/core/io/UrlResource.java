/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class UrlResource extends AbstractFileResolvingResource
/*     */ {
/*     */   private final URI uri;
/*     */   private final URL url;
/*     */   private final URL cleanedUrl;
/*     */ 
/*     */   public UrlResource(URI uri)
/*     */     throws MalformedURLException
/*     */   {
/*  66 */     Assert.notNull(uri, "URI must not be null");
/*  67 */     this.uri = uri;
/*  68 */     this.url = uri.toURL();
/*  69 */     this.cleanedUrl = getCleanedUrl(this.url, uri.toString());
/*     */   }
/*     */ 
/*     */   public UrlResource(URL url)
/*     */   {
/*  77 */     Assert.notNull(url, "URL must not be null");
/*  78 */     this.url = url;
/*  79 */     this.cleanedUrl = getCleanedUrl(this.url, url.toString());
/*  80 */     this.uri = null;
/*     */   }
/*     */ 
/*     */   public UrlResource(String path)
/*     */     throws MalformedURLException
/*     */   {
/*  91 */     Assert.notNull(path, "Path must not be null");
/*  92 */     this.uri = null;
/*  93 */     this.url = new URL(path);
/*  94 */     this.cleanedUrl = getCleanedUrl(this.url, path);
/*     */   }
/*     */ 
/*     */   public UrlResource(String protocol, String location)
/*     */     throws MalformedURLException
/*     */   {
/* 108 */     this(protocol, location, null);
/*     */   }
/*     */ 
/*     */   public UrlResource(String protocol, String location, String fragment)
/*     */     throws MalformedURLException
/*     */   {
/*     */     try
/*     */     {
/* 125 */       this.uri = new URI(protocol, location, fragment);
/* 126 */       this.url = this.uri.toURL();
/* 127 */       this.cleanedUrl = getCleanedUrl(this.url, this.uri.toString());
/*     */     }
/*     */     catch (URISyntaxException ex) {
/* 130 */       MalformedURLException exToThrow = new MalformedURLException(ex.getMessage());
/* 131 */       exToThrow.initCause(ex);
/* 132 */       throw exToThrow;
/*     */     }
/*     */   }
/*     */ 
/*     */   private URL getCleanedUrl(URL originalUrl, String originalPath)
/*     */   {
/*     */     try
/*     */     {
/* 145 */       return new URL(StringUtils.cleanPath(originalPath));
/*     */     }
/*     */     catch (MalformedURLException ex)
/*     */     {
/*     */     }
/* 150 */     return originalUrl;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/* 165 */     URLConnection con = this.url.openConnection();
/* 166 */     ResourceUtils.useCachesIfNecessary(con);
/*     */     try {
/* 168 */       return con.getInputStream();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 172 */       if ((con instanceof HttpURLConnection)) {
/* 173 */         ((HttpURLConnection)con).disconnect();
/*     */       }
/* 175 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public URL getURL()
/*     */     throws IOException
/*     */   {
/* 184 */     return this.url;
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */     throws IOException
/*     */   {
/* 193 */     if (this.uri != null) {
/* 194 */       return this.uri;
/*     */     }
/*     */ 
/* 197 */     return super.getURI();
/*     */   }
/*     */ 
/*     */   public File getFile()
/*     */     throws IOException
/*     */   {
/* 208 */     if (this.uri != null) {
/* 209 */       return super.getFile(this.uri);
/*     */     }
/*     */ 
/* 212 */     return super.getFile();
/*     */   }
/*     */ 
/*     */   public Resource createRelative(String relativePath)
/*     */     throws MalformedURLException
/*     */   {
/* 223 */     if (relativePath.startsWith("/")) {
/* 224 */       relativePath = relativePath.substring(1);
/*     */     }
/* 226 */     return new UrlResource(new URL(this.url, relativePath));
/*     */   }
/*     */ 
/*     */   public String getFilename()
/*     */   {
/* 236 */     return new File(this.url.getFile()).getName();
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 244 */     return "URL [" + this.url + "]";
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 254 */     return (obj == this) || (((obj instanceof UrlResource)) && 
/* 254 */       (this.cleanedUrl
/* 254 */       .equals(((UrlResource)obj).cleanedUrl)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 262 */     return this.cleanedUrl.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.UrlResource
 * JD-Core Version:    0.6.2
 */