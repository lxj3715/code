/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import org.springframework.core.NestedIOException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class VfsResource extends AbstractResource
/*     */ {
/*     */   private final Object resource;
/*     */ 
/*     */   public VfsResource(Object resources)
/*     */   {
/*  44 */     Assert.notNull(resources, "VirtualFile must not be null");
/*  45 */     this.resource = resources;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/*  51 */     return VfsUtils.getInputStream(this.resource);
/*     */   }
/*     */ 
/*     */   public boolean exists()
/*     */   {
/*  56 */     return VfsUtils.exists(this.resource);
/*     */   }
/*     */ 
/*     */   public boolean isReadable()
/*     */   {
/*  61 */     return VfsUtils.isReadable(this.resource);
/*     */   }
/*     */ 
/*     */   public URL getURL() throws IOException
/*     */   {
/*     */     try {
/*  67 */       return VfsUtils.getURL(this.resource);
/*     */     }
/*     */     catch (Exception ex) {
/*  70 */       throw new NestedIOException("Failed to obtain URL for file " + this.resource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public URI getURI() throws IOException
/*     */   {
/*     */     try {
/*  77 */       return VfsUtils.getURI(this.resource);
/*     */     }
/*     */     catch (Exception ex) {
/*  80 */       throw new NestedIOException("Failed to obtain URI for " + this.resource, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public File getFile() throws IOException
/*     */   {
/*  86 */     return VfsUtils.getFile(this.resource);
/*     */   }
/*     */ 
/*     */   public long contentLength() throws IOException
/*     */   {
/*  91 */     return VfsUtils.getSize(this.resource);
/*     */   }
/*     */ 
/*     */   public long lastModified() throws IOException
/*     */   {
/*  96 */     return VfsUtils.getLastModified(this.resource);
/*     */   }
/*     */ 
/*     */   public Resource createRelative(String relativePath) throws IOException
/*     */   {
/* 101 */     if ((!relativePath.startsWith(".")) && (relativePath.contains("/"))) {
/*     */       try {
/* 103 */         return new VfsResource(VfsUtils.getChild(this.resource, relativePath));
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/* 110 */     return new VfsResource(VfsUtils.getRelative(new URL(getURL(), relativePath)));
/*     */   }
/*     */ 
/*     */   public String getFilename()
/*     */   {
/* 115 */     return VfsUtils.getName(this.resource);
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 120 */     return this.resource.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 125 */     return (obj == this) || (((obj instanceof VfsResource)) && (this.resource.equals(((VfsResource)obj).resource)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 130 */     return this.resource.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.VfsResource
 * JD-Core Version:    0.6.2
 */