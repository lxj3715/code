/*     */ package org.springframework.core.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class VfsUtils
/*     */ {
/*     */   private static final String VFS3_PKG = "org.jboss.vfs.";
/*     */   private static final String VFS_NAME = "VFS";
/*  47 */   private static Method VFS_METHOD_GET_ROOT_URL = null;
/*  48 */   private static Method VFS_METHOD_GET_ROOT_URI = null;
/*     */ 
/*  50 */   private static Method VIRTUAL_FILE_METHOD_EXISTS = null;
/*     */   private static Method VIRTUAL_FILE_METHOD_GET_INPUT_STREAM;
/*     */   private static Method VIRTUAL_FILE_METHOD_GET_SIZE;
/*     */   private static Method VIRTUAL_FILE_METHOD_GET_LAST_MODIFIED;
/*     */   private static Method VIRTUAL_FILE_METHOD_TO_URL;
/*     */   private static Method VIRTUAL_FILE_METHOD_TO_URI;
/*     */   private static Method VIRTUAL_FILE_METHOD_GET_NAME;
/*     */   private static Method VIRTUAL_FILE_METHOD_GET_PATH_NAME;
/*     */   private static Method VIRTUAL_FILE_METHOD_GET_CHILD;
/*     */   protected static Class<?> VIRTUAL_FILE_VISITOR_INTERFACE;
/*     */   protected static Method VIRTUAL_FILE_METHOD_VISIT;
/*  63 */   private static Field VISITOR_ATTRIBUTES_FIELD_RECURSE = null;
/*  64 */   private static Method GET_PHYSICAL_FILE = null;
/*     */ 
/*     */   protected static Object invokeVfsMethod(Method method, Object target, Object[] args)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  98 */       return method.invoke(target, args);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 101 */       Throwable targetEx = ex.getTargetException();
/* 102 */       if ((targetEx instanceof IOException)) {
/* 103 */         throw ((IOException)targetEx);
/*     */       }
/* 105 */       ReflectionUtils.handleInvocationTargetException(ex);
/*     */     }
/*     */     catch (Exception ex) {
/* 108 */       ReflectionUtils.handleReflectionException(ex);
/*     */     }
/*     */ 
/* 111 */     throw new IllegalStateException("Invalid code path reached");
/*     */   }
/*     */ 
/*     */   static boolean exists(Object vfsResource) {
/*     */     try {
/* 116 */       return ((Boolean)invokeVfsMethod(VIRTUAL_FILE_METHOD_EXISTS, vfsResource, new Object[0])).booleanValue();
/*     */     } catch (IOException ex) {
/*     */     }
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   static boolean isReadable(Object vfsResource)
/*     */   {
/*     */     try {
/* 125 */       return ((Long)invokeVfsMethod(VIRTUAL_FILE_METHOD_GET_SIZE, vfsResource, new Object[0])).longValue() > 0L;
/*     */     } catch (IOException ex) {
/*     */     }
/* 128 */     return false;
/*     */   }
/*     */ 
/*     */   static long getSize(Object vfsResource) throws IOException
/*     */   {
/* 133 */     return ((Long)invokeVfsMethod(VIRTUAL_FILE_METHOD_GET_SIZE, vfsResource, new Object[0])).longValue();
/*     */   }
/*     */ 
/*     */   static long getLastModified(Object vfsResource) throws IOException {
/* 137 */     return ((Long)invokeVfsMethod(VIRTUAL_FILE_METHOD_GET_LAST_MODIFIED, vfsResource, new Object[0])).longValue();
/*     */   }
/*     */ 
/*     */   static InputStream getInputStream(Object vfsResource) throws IOException {
/* 141 */     return (InputStream)invokeVfsMethod(VIRTUAL_FILE_METHOD_GET_INPUT_STREAM, vfsResource, new Object[0]);
/*     */   }
/*     */ 
/*     */   static URL getURL(Object vfsResource) throws IOException {
/* 145 */     return (URL)invokeVfsMethod(VIRTUAL_FILE_METHOD_TO_URL, vfsResource, new Object[0]);
/*     */   }
/*     */ 
/*     */   static URI getURI(Object vfsResource) throws IOException {
/* 149 */     return (URI)invokeVfsMethod(VIRTUAL_FILE_METHOD_TO_URI, vfsResource, new Object[0]);
/*     */   }
/*     */ 
/*     */   static String getName(Object vfsResource) {
/*     */     try {
/* 154 */       return (String)invokeVfsMethod(VIRTUAL_FILE_METHOD_GET_NAME, vfsResource, new Object[0]);
/*     */     }
/*     */     catch (IOException ex) {
/* 157 */       throw new IllegalStateException("Cannot get resource name", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   static Object getRelative(URL url) throws IOException {
/* 162 */     return invokeVfsMethod(VFS_METHOD_GET_ROOT_URL, null, new Object[] { url });
/*     */   }
/*     */ 
/*     */   static Object getChild(Object vfsResource, String path) throws IOException {
/* 166 */     return invokeVfsMethod(VIRTUAL_FILE_METHOD_GET_CHILD, vfsResource, new Object[] { path });
/*     */   }
/*     */ 
/*     */   static File getFile(Object vfsResource) throws IOException {
/* 170 */     return (File)invokeVfsMethod(GET_PHYSICAL_FILE, vfsResource, new Object[0]);
/*     */   }
/*     */ 
/*     */   static Object getRoot(URI url) throws IOException {
/* 174 */     return invokeVfsMethod(VFS_METHOD_GET_ROOT_URI, null, new Object[] { url });
/*     */   }
/*     */ 
/*     */   protected static Object getRoot(URL url)
/*     */     throws IOException
/*     */   {
/* 180 */     return invokeVfsMethod(VFS_METHOD_GET_ROOT_URL, null, new Object[] { url });
/*     */   }
/*     */ 
/*     */   protected static Object doGetVisitorAttribute() {
/* 184 */     return ReflectionUtils.getField(VISITOR_ATTRIBUTES_FIELD_RECURSE, null);
/*     */   }
/*     */ 
/*     */   protected static String doGetPath(Object resource) {
/* 188 */     return (String)ReflectionUtils.invokeMethod(VIRTUAL_FILE_METHOD_GET_PATH_NAME, resource);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  67 */     ClassLoader loader = VfsUtils.class.getClassLoader();
/*     */     try {
/*  69 */       Class vfsClass = loader.loadClass("org.jboss.vfs.VFS");
/*  70 */       VFS_METHOD_GET_ROOT_URL = ReflectionUtils.findMethod(vfsClass, "getChild", new Class[] { URL.class });
/*  71 */       VFS_METHOD_GET_ROOT_URI = ReflectionUtils.findMethod(vfsClass, "getChild", new Class[] { URI.class });
/*     */ 
/*  73 */       Class virtualFile = loader.loadClass("org.jboss.vfs.VirtualFile");
/*  74 */       VIRTUAL_FILE_METHOD_EXISTS = ReflectionUtils.findMethod(virtualFile, "exists");
/*  75 */       VIRTUAL_FILE_METHOD_GET_INPUT_STREAM = ReflectionUtils.findMethod(virtualFile, "openStream");
/*  76 */       VIRTUAL_FILE_METHOD_GET_SIZE = ReflectionUtils.findMethod(virtualFile, "getSize");
/*  77 */       VIRTUAL_FILE_METHOD_GET_LAST_MODIFIED = ReflectionUtils.findMethod(virtualFile, "getLastModified");
/*  78 */       VIRTUAL_FILE_METHOD_TO_URI = ReflectionUtils.findMethod(virtualFile, "toURI");
/*  79 */       VIRTUAL_FILE_METHOD_TO_URL = ReflectionUtils.findMethod(virtualFile, "toURL");
/*  80 */       VIRTUAL_FILE_METHOD_GET_NAME = ReflectionUtils.findMethod(virtualFile, "getName");
/*  81 */       VIRTUAL_FILE_METHOD_GET_PATH_NAME = ReflectionUtils.findMethod(virtualFile, "getPathName");
/*  82 */       GET_PHYSICAL_FILE = ReflectionUtils.findMethod(virtualFile, "getPhysicalFile");
/*  83 */       VIRTUAL_FILE_METHOD_GET_CHILD = ReflectionUtils.findMethod(virtualFile, "getChild", new Class[] { String.class });
/*     */ 
/*  85 */       VIRTUAL_FILE_VISITOR_INTERFACE = loader.loadClass("org.jboss.vfs.VirtualFileVisitor");
/*  86 */       VIRTUAL_FILE_METHOD_VISIT = ReflectionUtils.findMethod(virtualFile, "visit", new Class[] { VIRTUAL_FILE_VISITOR_INTERFACE });
/*     */ 
/*  88 */       Class visitorAttributesClass = loader.loadClass("org.jboss.vfs.VisitorAttributes");
/*  89 */       VISITOR_ATTRIBUTES_FIELD_RECURSE = ReflectionUtils.findField(visitorAttributesClass, "RECURSE");
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  92 */       throw new IllegalStateException("Could not detect JBoss VFS infrastructure", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.VfsUtils
 * JD-Core Version:    0.6.2
 */