/*     */ package org.springframework.core.io.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class EncodedResource
/*     */ {
/*     */   private final Resource resource;
/*     */   private String encoding;
/*     */   private Charset charset;
/*     */ 
/*     */   public EncodedResource(Resource resource)
/*     */   {
/*  55 */     Assert.notNull(resource, "Resource must not be null");
/*  56 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   public EncodedResource(Resource resource, String encoding)
/*     */   {
/*  66 */     Assert.notNull(resource, "Resource must not be null");
/*  67 */     this.resource = resource;
/*  68 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   public EncodedResource(Resource resource, Charset charset)
/*     */   {
/*  78 */     Assert.notNull(resource, "Resource must not be null");
/*  79 */     this.resource = resource;
/*  80 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   public final Resource getResource()
/*     */   {
/*  88 */     return this.resource;
/*     */   }
/*     */ 
/*     */   public final String getEncoding()
/*     */   {
/*  96 */     return this.encoding;
/*     */   }
/*     */ 
/*     */   public final Charset getCharset()
/*     */   {
/* 104 */     return this.charset;
/*     */   }
/*     */ 
/*     */   public boolean requiresReader()
/*     */   {
/* 115 */     return (this.encoding != null) || (this.charset != null);
/*     */   }
/*     */ 
/*     */   public Reader getReader()
/*     */     throws IOException
/*     */   {
/* 125 */     if (this.charset != null) {
/* 126 */       return new InputStreamReader(this.resource.getInputStream(), this.charset);
/*     */     }
/* 128 */     if (this.encoding != null) {
/* 129 */       return new InputStreamReader(this.resource.getInputStream(), this.encoding);
/*     */     }
/*     */ 
/* 132 */     return new InputStreamReader(this.resource.getInputStream());
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/* 143 */     return this.resource.getInputStream();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 149 */     if (obj == this) {
/* 150 */       return true;
/*     */     }
/* 152 */     if ((obj instanceof EncodedResource)) {
/* 153 */       EncodedResource otherRes = (EncodedResource)obj;
/*     */ 
/* 155 */       return (this.resource.equals(otherRes.resource)) && 
/* 155 */         (ObjectUtils.nullSafeEquals(this.encoding, otherRes.encoding));
/*     */     }
/*     */ 
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 162 */     return this.resource.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 167 */     return this.resource.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.support.EncodedResource
 * JD-Core Version:    0.6.2
 */