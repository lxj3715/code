/*     */ package org.springframework.core.io.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.UrlResource;
/*     */ import org.springframework.core.io.VfsResource;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class PathMatchingResourcePatternResolver
/*     */   implements ResourcePatternResolver
/*     */ {
/* 169 */   private static final Log logger = LogFactory.getLog(PathMatchingResourcePatternResolver.class);
/*     */   private static Method equinoxResolveMethod;
/*     */   private final ResourceLoader resourceLoader;
/* 189 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */ 
/*     */   public PathMatchingResourcePatternResolver()
/*     */   {
/* 198 */     this.resourceLoader = new DefaultResourceLoader();
/*     */   }
/*     */ 
/*     */   public PathMatchingResourcePatternResolver(ClassLoader classLoader)
/*     */   {
/* 209 */     this.resourceLoader = new DefaultResourceLoader(classLoader);
/*     */   }
/*     */ 
/*     */   public PathMatchingResourcePatternResolver(ResourceLoader resourceLoader)
/*     */   {
/* 219 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 220 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public ResourceLoader getResourceLoader()
/*     */   {
/* 227 */     return this.resourceLoader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 236 */     return getResourceLoader().getClassLoader();
/*     */   }
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 245 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 246 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */ 
/*     */   public PathMatcher getPathMatcher()
/*     */   {
/* 253 */     return this.pathMatcher;
/*     */   }
/*     */ 
/*     */   public Resource getResource(String location)
/*     */   {
/* 259 */     return getResourceLoader().getResource(location);
/*     */   }
/*     */ 
/*     */   public Resource[] getResources(String locationPattern) throws IOException
/*     */   {
/* 264 */     Assert.notNull(locationPattern, "Location pattern must not be null");
/* 265 */     if (locationPattern.startsWith("classpath*:"))
/*     */     {
/* 267 */       if (getPathMatcher().isPattern(locationPattern.substring("classpath*:".length())))
/*     */       {
/* 269 */         return findPathMatchingResources(locationPattern);
/*     */       }
/*     */ 
/* 273 */       return findAllClassPathResources(locationPattern.substring("classpath*:".length()));
/*     */     }
/*     */ 
/* 279 */     int prefixEnd = locationPattern.indexOf(":") + 1;
/* 280 */     if (getPathMatcher().isPattern(locationPattern.substring(prefixEnd)))
/*     */     {
/* 282 */       return findPathMatchingResources(locationPattern);
/*     */     }
/*     */ 
/* 286 */     return new Resource[] { getResourceLoader().getResource(locationPattern) };
/*     */   }
/*     */ 
/*     */   protected Resource[] findAllClassPathResources(String location)
/*     */     throws IOException
/*     */   {
/* 300 */     String path = location;
/* 301 */     if (path.startsWith("/")) {
/* 302 */       path = path.substring(1);
/*     */     }
/* 304 */     Enumeration resourceUrls = getClassLoader().getResources(path);
/* 305 */     Set result = new LinkedHashSet(16);
/* 306 */     while (resourceUrls.hasMoreElements()) {
/* 307 */       URL url = (URL)resourceUrls.nextElement();
/* 308 */       result.add(convertClassLoaderURL(url));
/*     */     }
/* 310 */     return (Resource[])result.toArray(new Resource[result.size()]);
/*     */   }
/*     */ 
/*     */   protected Resource convertClassLoaderURL(URL url)
/*     */   {
/* 322 */     return new UrlResource(url);
/*     */   }
/*     */ 
/*     */   protected Resource[] findPathMatchingResources(String locationPattern)
/*     */     throws IOException
/*     */   {
/* 337 */     String rootDirPath = determineRootDir(locationPattern);
/* 338 */     String subPattern = locationPattern.substring(rootDirPath.length());
/* 339 */     Resource[] rootDirResources = getResources(rootDirPath);
/* 340 */     Set result = new LinkedHashSet(16);
/* 341 */     for (Resource rootDirResource : rootDirResources) {
/* 342 */       rootDirResource = resolveRootDirResource(rootDirResource);
/* 343 */       if (isJarResource(rootDirResource)) {
/* 344 */         result.addAll(doFindPathMatchingJarResources(rootDirResource, subPattern));
/*     */       }
/* 346 */       else if (rootDirResource.getURL().getProtocol().startsWith("vfs")) {
/* 347 */         result.addAll(VfsResourceMatchingDelegate.findMatchingResources(rootDirResource, subPattern, getPathMatcher()));
/*     */       }
/*     */       else {
/* 350 */         result.addAll(doFindPathMatchingFileResources(rootDirResource, subPattern));
/*     */       }
/*     */     }
/* 353 */     if (logger.isDebugEnabled()) {
/* 354 */       logger.debug("Resolved location pattern [" + locationPattern + "] to resources " + result);
/*     */     }
/* 356 */     return (Resource[])result.toArray(new Resource[result.size()]);
/*     */   }
/*     */ 
/*     */   protected String determineRootDir(String location)
/*     */   {
/* 372 */     int prefixEnd = location.indexOf(":") + 1;
/* 373 */     int rootDirEnd = location.length();
/* 374 */     while ((rootDirEnd > prefixEnd) && (getPathMatcher().isPattern(location.substring(prefixEnd, rootDirEnd)))) {
/* 375 */       rootDirEnd = location.lastIndexOf('/', rootDirEnd - 2) + 1;
/*     */     }
/* 377 */     if (rootDirEnd == 0) {
/* 378 */       rootDirEnd = prefixEnd;
/*     */     }
/* 380 */     return location.substring(0, rootDirEnd);
/*     */   }
/*     */ 
/*     */   protected Resource resolveRootDirResource(Resource original)
/*     */     throws IOException
/*     */   {
/* 393 */     if (equinoxResolveMethod != null) {
/* 394 */       URL url = original.getURL();
/* 395 */       if (url.getProtocol().startsWith("bundle")) {
/* 396 */         return new UrlResource((URL)ReflectionUtils.invokeMethod(equinoxResolveMethod, null, new Object[] { url }));
/*     */       }
/*     */     }
/* 399 */     return original;
/*     */   }
/*     */ 
/*     */   protected boolean isJarResource(Resource resource)
/*     */     throws IOException
/*     */   {
/* 414 */     return ResourceUtils.isJarURL(resource.getURL());
/*     */   }
/*     */ 
/*     */   protected Set<Resource> doFindPathMatchingJarResources(Resource rootDirResource, String subPattern)
/*     */     throws IOException
/*     */   {
/* 430 */     URLConnection con = rootDirResource.getURL().openConnection();
/*     */ 
/* 434 */     boolean newJarFile = false;
/*     */     String rootEntryPath;
/*     */     JarFile jarFile;
/*     */     String jarFileUrl;
/*     */     String rootEntryPath;
/* 436 */     if ((con instanceof JarURLConnection))
/*     */     {
/* 438 */       JarURLConnection jarCon = (JarURLConnection)con;
/* 439 */       ResourceUtils.useCachesIfNecessary(jarCon);
/* 440 */       JarFile jarFile = jarCon.getJarFile();
/* 441 */       String jarFileUrl = jarCon.getJarFileURL().toExternalForm();
/* 442 */       JarEntry jarEntry = jarCon.getJarEntry();
/* 443 */       rootEntryPath = jarEntry != null ? jarEntry.getName() : "";
/*     */     }
/*     */     else
/*     */     {
/* 450 */       String urlFile = rootDirResource.getURL().getFile();
/* 451 */       int separatorIndex = urlFile.indexOf("!/");
/*     */       JarFile jarFile;
/* 452 */       if (separatorIndex != -1) {
/* 453 */         String jarFileUrl = urlFile.substring(0, separatorIndex);
/* 454 */         String rootEntryPath = urlFile.substring(separatorIndex + "!/".length());
/* 455 */         jarFile = getJarFile(jarFileUrl);
/*     */       }
/*     */       else {
/* 458 */         jarFile = new JarFile(urlFile);
/* 459 */         jarFileUrl = urlFile;
/* 460 */         rootEntryPath = "";
/*     */       }
/* 462 */       newJarFile = true;
/*     */     }
/*     */     try
/*     */     {
/* 466 */       if (logger.isDebugEnabled()) {
/* 467 */         logger.debug("Looking for matching resources in jar file [" + jarFileUrl + "]");
/*     */       }
/* 469 */       if ((!"".equals(rootEntryPath)) && (!rootEntryPath.endsWith("/")))
/*     */       {
/* 472 */         rootEntryPath = rootEntryPath + "/";
/*     */       }
/* 474 */       Set result = new LinkedHashSet(8);
/* 475 */       for (Enumeration entries = jarFile.entries(); entries.hasMoreElements(); ) {
/* 476 */         JarEntry entry = (JarEntry)entries.nextElement();
/* 477 */         String entryPath = entry.getName();
/* 478 */         if (entryPath.startsWith(rootEntryPath)) {
/* 479 */           String relativePath = entryPath.substring(rootEntryPath.length());
/* 480 */           if (getPathMatcher().match(subPattern, relativePath)) {
/* 481 */             result.add(rootDirResource.createRelative(relativePath));
/*     */           }
/*     */         }
/*     */       }
/* 485 */       return result;
/*     */     }
/*     */     finally
/*     */     {
/* 490 */       if (newJarFile)
/* 491 */         jarFile.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JarFile getJarFile(String jarFileUrl)
/*     */     throws IOException
/*     */   {
/* 500 */     if (jarFileUrl.startsWith("file:")) {
/*     */       try {
/* 502 */         return new JarFile(ResourceUtils.toURI(jarFileUrl).getSchemeSpecificPart());
/*     */       }
/*     */       catch (URISyntaxException ex)
/*     */       {
/* 506 */         return new JarFile(jarFileUrl.substring("file:".length()));
/*     */       }
/*     */     }
/*     */ 
/* 510 */     return new JarFile(jarFileUrl);
/*     */   }
/*     */ 
/*     */   protected Set<Resource> doFindPathMatchingFileResources(Resource rootDirResource, String subPattern)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 529 */       rootDir = rootDirResource.getFile().getAbsoluteFile();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */       File rootDir;
/* 532 */       if (logger.isWarnEnabled()) {
/* 533 */         logger.warn("Cannot search for matching files underneath " + rootDirResource + " because it does not correspond to a directory in the file system", ex);
/*     */       }
/*     */ 
/* 536 */       return Collections.emptySet();
/*     */     }
/*     */     File rootDir;
/* 538 */     return doFindMatchingFileSystemResources(rootDir, subPattern);
/*     */   }
/*     */ 
/*     */   protected Set<Resource> doFindMatchingFileSystemResources(File rootDir, String subPattern)
/*     */     throws IOException
/*     */   {
/* 552 */     if (logger.isDebugEnabled()) {
/* 553 */       logger.debug("Looking for matching resources in directory tree [" + rootDir.getPath() + "]");
/*     */     }
/* 555 */     Set matchingFiles = retrieveMatchingFiles(rootDir, subPattern);
/* 556 */     Set result = new LinkedHashSet(matchingFiles.size());
/* 557 */     for (File file : matchingFiles) {
/* 558 */       result.add(new FileSystemResource(file));
/*     */     }
/* 560 */     return result;
/*     */   }
/*     */ 
/*     */   protected Set<File> retrieveMatchingFiles(File rootDir, String pattern)
/*     */     throws IOException
/*     */   {
/* 573 */     if (!rootDir.exists())
/*     */     {
/* 575 */       if (logger.isDebugEnabled()) {
/* 576 */         logger.debug("Skipping [" + rootDir.getAbsolutePath() + "] because it does not exist");
/*     */       }
/* 578 */       return Collections.emptySet();
/*     */     }
/* 580 */     if (!rootDir.isDirectory())
/*     */     {
/* 582 */       if (logger.isWarnEnabled()) {
/* 583 */         logger.warn("Skipping [" + rootDir.getAbsolutePath() + "] because it does not denote a directory");
/*     */       }
/* 585 */       return Collections.emptySet();
/*     */     }
/* 587 */     if (!rootDir.canRead()) {
/* 588 */       if (logger.isWarnEnabled()) {
/* 589 */         logger.warn("Cannot search for matching files underneath directory [" + rootDir.getAbsolutePath() + "] because the application is not allowed to read the directory");
/*     */       }
/*     */ 
/* 592 */       return Collections.emptySet();
/*     */     }
/* 594 */     String fullPattern = StringUtils.replace(rootDir.getAbsolutePath(), File.separator, "/");
/* 595 */     if (!pattern.startsWith("/")) {
/* 596 */       fullPattern = fullPattern + "/";
/*     */     }
/* 598 */     fullPattern = fullPattern + StringUtils.replace(pattern, File.separator, "/");
/* 599 */     Set result = new LinkedHashSet(8);
/* 600 */     doRetrieveMatchingFiles(fullPattern, rootDir, result);
/* 601 */     return result;
/*     */   }
/*     */ 
/*     */   protected void doRetrieveMatchingFiles(String fullPattern, File dir, Set<File> result)
/*     */     throws IOException
/*     */   {
/* 614 */     if (logger.isDebugEnabled()) {
/* 615 */       logger.debug("Searching directory [" + dir.getAbsolutePath() + "] for files matching pattern [" + fullPattern + "]");
/*     */     }
/*     */ 
/* 618 */     File[] dirContents = dir.listFiles();
/* 619 */     if (dirContents == null) {
/* 620 */       if (logger.isWarnEnabled()) {
/* 621 */         logger.warn("Could not retrieve contents of directory [" + dir.getAbsolutePath() + "]");
/*     */       }
/* 623 */       return;
/*     */     }
/* 625 */     for (File content : dirContents) {
/* 626 */       String currPath = StringUtils.replace(content.getAbsolutePath(), File.separator, "/");
/* 627 */       if ((content.isDirectory()) && (getPathMatcher().matchStart(fullPattern, currPath + "/"))) {
/* 628 */         if (!content.canRead()) {
/* 629 */           if (logger.isDebugEnabled()) {
/* 630 */             logger.debug("Skipping subdirectory [" + dir.getAbsolutePath() + "] because the application is not allowed to read the directory");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 635 */           doRetrieveMatchingFiles(fullPattern, content, result);
/*     */         }
/*     */       }
/* 638 */       if (getPathMatcher().match(fullPattern, currPath))
/* 639 */         result.add(content);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 176 */       Class fileLocatorClass = PathMatchingResourcePatternResolver.class.getClassLoader().loadClass("org.eclipse.core.runtime.FileLocator");
/*     */ 
/* 178 */       equinoxResolveMethod = fileLocatorClass.getMethod("resolve", new Class[] { URL.class });
/* 179 */       logger.debug("Found Equinox FileLocator for OSGi bundle URL resolution");
/*     */     }
/*     */     catch (Throwable ex) {
/* 182 */       equinoxResolveMethod = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PatternVirtualFileVisitor
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final String subPattern;
/*     */     private final PathMatcher pathMatcher;
/*     */     private final String rootPath;
/* 673 */     private final Set<Resource> resources = new LinkedHashSet();
/*     */ 
/*     */     public PatternVirtualFileVisitor(String rootPath, String subPattern, PathMatcher pathMatcher) {
/* 676 */       this.subPattern = subPattern;
/* 677 */       this.pathMatcher = pathMatcher;
/* 678 */       this.rootPath = (rootPath + "/");
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */     {
/* 683 */       String methodName = method.getName();
/* 684 */       if (Object.class.equals(method.getDeclaringClass())) {
/* 685 */         if (methodName.equals("equals"))
/*     */         {
/* 687 */           return Boolean.valueOf(proxy == args[0]);
/*     */         }
/* 689 */         if (methodName.equals("hashCode"))
/* 690 */           return Integer.valueOf(System.identityHashCode(proxy));
/*     */       }
/*     */       else {
/* 693 */         if ("getAttributes".equals(methodName)) {
/* 694 */           return getAttributes();
/*     */         }
/* 696 */         if ("visit".equals(methodName)) {
/* 697 */           visit(args[0]);
/* 698 */           return null;
/*     */         }
/* 700 */         if ("toString".equals(methodName)) {
/* 701 */           return toString();
/*     */         }
/*     */       }
/* 704 */       throw new IllegalStateException("Unexpected method invocation: " + method);
/*     */     }
/*     */ 
/*     */     public void visit(Object vfsResource) {
/* 708 */       if (this.pathMatcher.match(this.subPattern, 
/* 709 */         VfsPatternUtils.getPath(vfsResource)
/* 709 */         .substring(this.rootPath.length())))
/* 710 */         this.resources.add(new VfsResource(vfsResource));
/*     */     }
/*     */ 
/*     */     public Object getAttributes()
/*     */     {
/* 715 */       return VfsPatternUtils.getVisitorAttribute();
/*     */     }
/*     */ 
/*     */     public Set<Resource> getResources() {
/* 719 */       return this.resources;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 723 */       return this.resources.size();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 728 */       StringBuilder sb = new StringBuilder();
/* 729 */       sb.append("sub-pattern: ").append(this.subPattern);
/* 730 */       sb.append(", resources: ").append(this.resources);
/* 731 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class VfsResourceMatchingDelegate
/*     */   {
/*     */     public static Set<Resource> findMatchingResources(Resource rootResource, String locationPattern, PathMatcher pathMatcher)
/*     */       throws IOException
/*     */     {
/* 652 */       Object root = VfsPatternUtils.findRoot(rootResource.getURL());
/*     */ 
/* 654 */       PathMatchingResourcePatternResolver.PatternVirtualFileVisitor visitor = new PathMatchingResourcePatternResolver.PatternVirtualFileVisitor(
/* 654 */         VfsPatternUtils.getPath(root), 
/* 654 */         locationPattern, pathMatcher);
/* 655 */       VfsPatternUtils.visit(root, visitor);
/* 656 */       return visitor.getResources();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.support.PathMatchingResourcePatternResolver
 * JD-Core Version:    0.6.2
 */