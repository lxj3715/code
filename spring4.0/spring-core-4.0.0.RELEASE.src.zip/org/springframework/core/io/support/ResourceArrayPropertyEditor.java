/*     */ package org.springframework.core.io.support;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ResourceArrayPropertyEditor extends PropertyEditorSupport
/*     */ {
/*  58 */   private static final Log logger = LogFactory.getLog(ResourceArrayPropertyEditor.class);
/*     */   private final ResourcePatternResolver resourcePatternResolver;
/*     */   private PropertyResolver propertyResolver;
/*     */   private final boolean ignoreUnresolvablePlaceholders;
/*     */ 
/*     */   public ResourceArrayPropertyEditor()
/*     */   {
/*  74 */     this(new PathMatchingResourcePatternResolver(), null, true);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ResourceArrayPropertyEditor(ResourcePatternResolver resourcePatternResolver)
/*     */   {
/*  85 */     this(resourcePatternResolver, null, true);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ResourceArrayPropertyEditor(ResourcePatternResolver resourcePatternResolver, boolean ignoreUnresolvablePlaceholders)
/*     */   {
/*  98 */     this(resourcePatternResolver, null, ignoreUnresolvablePlaceholders);
/*     */   }
/*     */ 
/*     */   public ResourceArrayPropertyEditor(ResourcePatternResolver resourcePatternResolver, PropertyResolver propertyResolver)
/*     */   {
/* 108 */     this(resourcePatternResolver, propertyResolver, true);
/*     */   }
/*     */ 
/*     */   public ResourceArrayPropertyEditor(ResourcePatternResolver resourcePatternResolver, PropertyResolver propertyResolver, boolean ignoreUnresolvablePlaceholders)
/*     */   {
/* 122 */     Assert.notNull(resourcePatternResolver, "ResourcePatternResolver must not be null");
/* 123 */     this.resourcePatternResolver = resourcePatternResolver;
/* 124 */     this.propertyResolver = propertyResolver;
/* 125 */     this.ignoreUnresolvablePlaceholders = ignoreUnresolvablePlaceholders;
/*     */   }
/*     */ 
/*     */   public void setAsText(String text)
/*     */   {
/* 134 */     String pattern = resolvePath(text).trim();
/*     */     try {
/* 136 */       setValue(this.resourcePatternResolver.getResources(pattern));
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 140 */       throw new IllegalArgumentException("Could not resolve resource location pattern [" + pattern + "]: " + ex
/* 140 */         .getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setValue(Object value)
/*     */     throws IllegalArgumentException
/*     */   {
/* 150 */     if (((value instanceof Collection)) || (((value instanceof Object[])) && (!(value instanceof Resource[])))) {
/* 151 */       Collection input = (value instanceof Collection) ? (Collection)value : Arrays.asList((Object[])value);
/* 152 */       List merged = new ArrayList();
/* 153 */       for (Iterator localIterator = input.iterator(); localIterator.hasNext(); ) { Object element = localIterator.next();
/* 154 */         if ((element instanceof String))
/*     */         {
/* 157 */           String pattern = resolvePath((String)element).trim();
/*     */           try {
/* 159 */             Resource[] resources = this.resourcePatternResolver.getResources(pattern);
/* 160 */             for (Resource resource : resources) {
/* 161 */               if (!merged.contains(resource)) {
/* 162 */                 merged.add(resource);
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (IOException ex)
/*     */           {
/* 168 */             if (logger.isDebugEnabled()) {
/* 169 */               logger.debug("Could not retrieve resources for pattern '" + pattern + "'", ex);
/*     */             }
/*     */           }
/*     */         }
/* 173 */         else if ((element instanceof Resource))
/*     */         {
/* 175 */           Resource resource = (Resource)element;
/* 176 */           if (!merged.contains(resource)) {
/* 177 */             merged.add(resource);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 182 */           throw new IllegalArgumentException("Cannot convert element [" + element + "] to [" + Resource.class
/* 182 */             .getName() + "]: only location String and Resource object supported");
/*     */         }
/*     */       }
/* 185 */       super.setValue(merged.toArray(new Resource[merged.size()]));
/*     */     }
/*     */     else
/*     */     {
/* 191 */       super.setValue(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String resolvePath(String path)
/*     */   {
/* 204 */     if (this.propertyResolver == null) {
/* 205 */       this.propertyResolver = new StandardEnvironment();
/*     */     }
/*     */ 
/* 208 */     return this.ignoreUnresolvablePlaceholders ? this.propertyResolver.resolvePlaceholders(path) : this.propertyResolver
/* 208 */       .resolveRequiredPlaceholders(path);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.support.ResourceArrayPropertyEditor
 * JD-Core Version:    0.6.2
 */