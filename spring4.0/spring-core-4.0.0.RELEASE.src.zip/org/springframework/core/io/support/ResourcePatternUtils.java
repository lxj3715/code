/*    */ package org.springframework.core.io.support;
/*    */ 
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ResourceUtils;
/*    */ 
/*    */ public abstract class ResourcePatternUtils
/*    */ {
/*    */   public static boolean isUrl(String resourceLocation)
/*    */   {
/* 48 */     return (resourceLocation != null) && (
/* 47 */       (resourceLocation
/* 47 */       .startsWith("classpath*:")) || 
/* 48 */       (ResourceUtils.isUrl(resourceLocation)));
/*    */   }
/*    */ 
/*    */   public static ResourcePatternResolver getResourcePatternResolver(ResourceLoader resourceLoader)
/*    */   {
/* 62 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 63 */     if ((resourceLoader instanceof ResourcePatternResolver)) {
/* 64 */       return (ResourcePatternResolver)resourceLoader;
/*    */     }
/* 66 */     if (resourceLoader != null) {
/* 67 */       return new PathMatchingResourcePatternResolver(resourceLoader);
/*    */     }
/*    */ 
/* 70 */     return new PathMatchingResourcePatternResolver();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.support.ResourcePatternUtils
 * JD-Core Version:    0.6.2
 */