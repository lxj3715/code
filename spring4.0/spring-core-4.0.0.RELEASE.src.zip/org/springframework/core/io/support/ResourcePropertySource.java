/*     */ package org.springframework.core.io.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.env.PropertiesPropertySource;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourcePropertySource extends PropertiesPropertySource
/*     */ {
/*     */   public ResourcePropertySource(String name, EncodedResource resource)
/*     */     throws IOException
/*     */   {
/*  47 */     super(name, PropertiesLoaderUtils.loadProperties(resource));
/*     */   }
/*     */ 
/*     */   public ResourcePropertySource(EncodedResource resource)
/*     */     throws IOException
/*     */   {
/*  56 */     this(getNameForResource(resource.getResource()), resource);
/*     */   }
/*     */ 
/*     */   public ResourcePropertySource(String name, Resource resource)
/*     */     throws IOException
/*     */   {
/*  64 */     super(name, PropertiesLoaderUtils.loadProperties(new EncodedResource(resource)));
/*     */   }
/*     */ 
/*     */   public ResourcePropertySource(Resource resource)
/*     */     throws IOException
/*     */   {
/*  73 */     this(getNameForResource(resource), resource);
/*     */   }
/*     */ 
/*     */   public ResourcePropertySource(String name, String location, ClassLoader classLoader)
/*     */     throws IOException
/*     */   {
/*  82 */     this(name, new DefaultResourceLoader(classLoader).getResource(location));
/*     */   }
/*     */ 
/*     */   public ResourcePropertySource(String location, ClassLoader classLoader)
/*     */     throws IOException
/*     */   {
/*  93 */     this(new DefaultResourceLoader(classLoader).getResource(location));
/*     */   }
/*     */ 
/*     */   public ResourcePropertySource(String name, String location)
/*     */     throws IOException
/*     */   {
/* 103 */     this(name, new DefaultResourceLoader().getResource(location));
/*     */   }
/*     */ 
/*     */   public ResourcePropertySource(String location)
/*     */     throws IOException
/*     */   {
/* 112 */     this(new DefaultResourceLoader().getResource(location));
/*     */   }
/*     */ 
/*     */   private static String getNameForResource(Resource resource)
/*     */   {
/* 121 */     String name = resource.getDescription();
/* 122 */     if (!StringUtils.hasText(name)) {
/* 123 */       name = resource.getClass().getSimpleName() + "@" + System.identityHashCode(resource);
/*     */     }
/* 125 */     return name;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.support.ResourcePropertySource
 * JD-Core Version:    0.6.2
 */