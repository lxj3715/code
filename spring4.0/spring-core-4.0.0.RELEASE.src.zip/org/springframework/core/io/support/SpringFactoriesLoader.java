/*     */ package org.springframework.core.io.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.core.io.UrlResource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class SpringFactoriesLoader
/*     */ {
/*     */   private static final String FACTORIES_RESOURCE_LOCATION = "META-INF/spring.factories";
/*  58 */   private static final Log logger = LogFactory.getLog(SpringFactoriesLoader.class);
/*     */ 
/*     */   public static <T> List<T> loadFactories(Class<T> factoryClass, ClassLoader classLoader)
/*     */   {
/*  69 */     Assert.notNull(factoryClass, "'factoryClass' must not be null");
/*  70 */     if (classLoader == null) {
/*  71 */       classLoader = SpringFactoriesLoader.class.getClassLoader();
/*     */     }
/*  73 */     List factoryNames = loadFactoryNames(factoryClass, classLoader);
/*  74 */     if (logger.isTraceEnabled()) {
/*  75 */       logger.trace("Loaded [" + factoryClass.getName() + "] names: " + factoryNames);
/*     */     }
/*  77 */     List result = new ArrayList(factoryNames.size());
/*  78 */     for (String factoryName : factoryNames) {
/*  79 */       result.add(instantiateFactory(factoryName, factoryClass, classLoader));
/*     */     }
/*  81 */     OrderComparator.sort(result);
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */   public static List<String> loadFactoryNames(Class<?> factoryClass, ClassLoader classLoader) {
/*  86 */     String factoryClassName = factoryClass.getName();
/*     */     try {
/*  88 */       List result = new ArrayList();
/*  89 */       Enumeration urls = classLoader.getResources("META-INF/spring.factories");
/*  90 */       while (urls.hasMoreElements()) {
/*  91 */         URL url = (URL)urls.nextElement();
/*  92 */         Properties properties = PropertiesLoaderUtils.loadProperties(new UrlResource(url));
/*  93 */         String factoryClassNames = properties.getProperty(factoryClassName);
/*  94 */         result.addAll(Arrays.asList(StringUtils.commaDelimitedListToStringArray(factoryClassNames)));
/*     */       }
/*  96 */       return result;
/*     */     }
/*     */     catch (IOException ex) {
/*  99 */       throw new IllegalArgumentException("Unable to load [" + factoryClass.getName() + "] factories from location [" + "META-INF/spring.factories" + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static <T> T instantiateFactory(String instanceClassName, Class<T> factoryClass, ClassLoader classLoader)
/*     */   {
/*     */     try
/*     */     {
/* 107 */       Class instanceClass = ClassUtils.forName(instanceClassName, classLoader);
/* 108 */       if (!factoryClass.isAssignableFrom(instanceClass))
/*     */       {
/* 110 */         throw new IllegalArgumentException("Class [" + instanceClassName + "] is not assignable to [" + factoryClass
/* 110 */           .getName() + "]");
/*     */       }
/* 112 */       return instanceClass.newInstance();
/*     */     }
/*     */     catch (Throwable ex) {
/* 115 */       throw new IllegalArgumentException("Cannot instantiate factory class: " + factoryClass.getName(), ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.io.support.SpringFactoriesLoader
 * JD-Core Version:    0.6.2
 */