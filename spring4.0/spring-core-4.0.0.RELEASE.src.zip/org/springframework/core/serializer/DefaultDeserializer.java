/*    */ package org.springframework.core.serializer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import org.springframework.core.NestedIOException;
/*    */ 
/*    */ public class DefaultDeserializer
/*    */   implements Deserializer<Object>
/*    */ {
/*    */   public Object deserialize(InputStream inputStream)
/*    */     throws IOException
/*    */   {
/* 39 */     ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
/*    */     try {
/* 41 */       return objectInputStream.readObject();
/*    */     }
/*    */     catch (ClassNotFoundException ex) {
/* 44 */       throw new NestedIOException("Failed to deserialize object type", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.serializer.DefaultDeserializer
 * JD-Core Version:    0.6.2
 */