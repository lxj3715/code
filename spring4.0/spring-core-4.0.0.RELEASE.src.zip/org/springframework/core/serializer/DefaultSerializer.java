/*    */ package org.springframework.core.serializer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DefaultSerializer
/*    */   implements Serializer<Object>
/*    */ {
/*    */   public void serialize(Object object, OutputStream outputStream)
/*    */     throws IOException
/*    */   {
/* 39 */     if (!(object instanceof Serializable))
/*    */     {
/* 41 */       throw new IllegalArgumentException(getClass().getSimpleName() + " requires a Serializable payload " + "but received an object of type [" + object
/* 41 */         .getClass().getName() + "]");
/*    */     }
/* 43 */     ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
/* 44 */     objectOutputStream.writeObject(object);
/* 45 */     objectOutputStream.flush();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.serializer.DefaultSerializer
 * JD-Core Version:    0.6.2
 */