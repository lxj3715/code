package org.springframework.core.serializer;

import java.io.IOException;
import java.io.InputStream;

public abstract interface Deserializer<T>
{
  public abstract T deserialize(InputStream paramInputStream)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.serializer.Deserializer
 * JD-Core Version:    0.6.2
 */