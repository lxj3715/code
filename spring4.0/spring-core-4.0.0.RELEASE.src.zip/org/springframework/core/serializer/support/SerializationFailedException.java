/*    */ package org.springframework.core.serializer.support;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class SerializationFailedException extends NestedRuntimeException
/*    */ {
/*    */   public SerializationFailedException(String message)
/*    */   {
/* 39 */     super(message);
/*    */   }
/*    */ 
/*    */   public SerializationFailedException(String message, Throwable cause)
/*    */   {
/* 49 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.serializer.support.SerializationFailedException
 * JD-Core Version:    0.6.2
 */