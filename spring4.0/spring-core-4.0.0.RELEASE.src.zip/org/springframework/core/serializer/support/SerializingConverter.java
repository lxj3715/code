/*    */ package org.springframework.core.serializer.support;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.serializer.DefaultSerializer;
/*    */ import org.springframework.core.serializer.Serializer;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SerializingConverter
/*    */   implements Converter<Object, byte[]>
/*    */ {
/*    */   private final Serializer<Object> serializer;
/*    */ 
/*    */   public SerializingConverter()
/*    */   {
/* 43 */     this.serializer = new DefaultSerializer();
/*    */   }
/*    */ 
/*    */   public SerializingConverter(Serializer<Object> serializer)
/*    */   {
/* 50 */     Assert.notNull(serializer, "Serializer must not be null");
/* 51 */     this.serializer = serializer;
/*    */   }
/*    */ 
/*    */   public byte[] convert(Object source)
/*    */   {
/* 60 */     ByteArrayOutputStream byteStream = new ByteArrayOutputStream(128);
/*    */     try {
/* 62 */       this.serializer.serialize(source, byteStream);
/* 63 */       return byteStream.toByteArray();
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 67 */       throw new SerializationFailedException("Failed to serialize object using " + this.serializer
/* 67 */         .getClass().getSimpleName(), ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.serializer.support.SerializingConverter
 * JD-Core Version:    0.6.2
 */