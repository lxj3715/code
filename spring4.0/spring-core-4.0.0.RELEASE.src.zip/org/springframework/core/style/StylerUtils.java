/*    */ package org.springframework.core.style;
/*    */ 
/*    */ public abstract class StylerUtils
/*    */ {
/* 38 */   static final ValueStyler DEFAULT_VALUE_STYLER = new DefaultValueStyler();
/*    */ 
/*    */   public static String style(Object value)
/*    */   {
/* 47 */     return DEFAULT_VALUE_STYLER.style(value);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.style.StylerUtils
 * JD-Core Version:    0.6.2
 */