package org.springframework.core.style;

public abstract interface ToStringStyler
{
  public abstract void styleStart(StringBuilder paramStringBuilder, Object paramObject);

  public abstract void styleEnd(StringBuilder paramStringBuilder, Object paramObject);

  public abstract void styleField(StringBuilder paramStringBuilder, String paramString, Object paramObject);

  public abstract void styleValue(StringBuilder paramStringBuilder, Object paramObject);

  public abstract void styleFieldSeparator(StringBuilder paramStringBuilder);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.style.ToStringStyler
 * JD-Core Version:    0.6.2
 */