package org.springframework.core.style;

public abstract interface ValueStyler
{
  public abstract String style(Object paramObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.style.ValueStyler
 * JD-Core Version:    0.6.2
 */