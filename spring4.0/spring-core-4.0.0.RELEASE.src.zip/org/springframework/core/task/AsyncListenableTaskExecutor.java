package org.springframework.core.task;

import java.util.concurrent.Callable;
import org.springframework.util.concurrent.ListenableFuture;

public abstract interface AsyncListenableTaskExecutor extends AsyncTaskExecutor
{
  public abstract ListenableFuture<?> submitListenable(Runnable paramRunnable);

  public abstract <T> ListenableFuture<T> submitListenable(Callable<T> paramCallable);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.task.AsyncListenableTaskExecutor
 * JD-Core Version:    0.6.2
 */