/*     */ package org.springframework.core.task;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrencyThrottleSupport;
/*     */ import org.springframework.util.CustomizableThreadCreator;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureTask;
/*     */ 
/*     */ public class SimpleAsyncTaskExecutor extends CustomizableThreadCreator
/*     */   implements AsyncListenableTaskExecutor, Serializable
/*     */ {
/*     */   public static final int UNBOUNDED_CONCURRENCY = -1;
/*     */   public static final int NO_CONCURRENCY = 0;
/*  64 */   private final ConcurrencyThrottleAdapter concurrencyThrottle = new ConcurrencyThrottleAdapter(null);
/*     */   private ThreadFactory threadFactory;
/*     */ 
/*     */   public SimpleAsyncTaskExecutor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SimpleAsyncTaskExecutor(String threadNamePrefix)
/*     */   {
/*  81 */     super(threadNamePrefix);
/*     */   }
/*     */ 
/*     */   public SimpleAsyncTaskExecutor(ThreadFactory threadFactory)
/*     */   {
/*  89 */     this.threadFactory = threadFactory;
/*     */   }
/*     */ 
/*     */   public void setThreadFactory(ThreadFactory threadFactory)
/*     */   {
/* 102 */     this.threadFactory = threadFactory;
/*     */   }
/*     */ 
/*     */   public final ThreadFactory getThreadFactory()
/*     */   {
/* 109 */     return this.threadFactory;
/*     */   }
/*     */ 
/*     */   public void setConcurrencyLimit(int concurrencyLimit)
/*     */   {
/* 123 */     this.concurrencyThrottle.setConcurrencyLimit(concurrencyLimit);
/*     */   }
/*     */ 
/*     */   public final int getConcurrencyLimit()
/*     */   {
/* 130 */     return this.concurrencyThrottle.getConcurrencyLimit();
/*     */   }
/*     */ 
/*     */   public final boolean isThrottleActive()
/*     */   {
/* 140 */     return this.concurrencyThrottle.isThrottleActive();
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 151 */     execute(task, 9223372036854775807L);
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout)
/*     */   {
/* 165 */     Assert.notNull(task, "Runnable must not be null");
/* 166 */     if ((isThrottleActive()) && (startTimeout > 0L)) {
/* 167 */       this.concurrencyThrottle.beforeAccess();
/* 168 */       doExecute(new ConcurrencyThrottlingRunnable(task));
/*     */     }
/*     */     else {
/* 171 */       doExecute(task);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task)
/*     */   {
/* 177 */     FutureTask future = new FutureTask(task, null);
/* 178 */     execute(future, 9223372036854775807L);
/* 179 */     return future;
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task)
/*     */   {
/* 184 */     FutureTask future = new FutureTask(task);
/* 185 */     execute(future, 9223372036854775807L);
/* 186 */     return future;
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> submitListenable(Runnable task)
/*     */   {
/* 191 */     ListenableFutureTask future = new ListenableFutureTask(task, null);
/* 192 */     execute(future, 9223372036854775807L);
/* 193 */     return future;
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<T> submitListenable(Callable<T> task)
/*     */   {
/* 198 */     ListenableFutureTask future = new ListenableFutureTask(task);
/* 199 */     execute(future, 9223372036854775807L);
/* 200 */     return future;
/*     */   }
/*     */ 
/*     */   protected void doExecute(Runnable task)
/*     */   {
/* 212 */     Thread thread = this.threadFactory != null ? this.threadFactory.newThread(task) : createThread(task);
/* 213 */     thread.start();
/*     */   }
/*     */ 
/*     */   private class ConcurrencyThrottlingRunnable
/*     */     implements Runnable
/*     */   {
/*     */     private final Runnable target;
/*     */ 
/*     */     public ConcurrencyThrottlingRunnable(Runnable target)
/*     */     {
/* 245 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try {
/* 251 */         this.target.run();
/*     */ 
/* 254 */         SimpleAsyncTaskExecutor.this.concurrencyThrottle.afterAccess(); } finally { SimpleAsyncTaskExecutor.this.concurrencyThrottle.afterAccess(); }
/*     */ 
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConcurrencyThrottleAdapter extends ConcurrencyThrottleSupport
/*     */   {
/*     */     protected void beforeAccess()
/*     */     {
/* 226 */       super.beforeAccess();
/*     */     }
/*     */ 
/*     */     protected void afterAccess()
/*     */     {
/* 231 */       super.afterAccess();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.task.SimpleAsyncTaskExecutor
 * JD-Core Version:    0.6.2
 */