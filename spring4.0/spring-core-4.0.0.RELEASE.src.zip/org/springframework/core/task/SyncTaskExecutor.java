/*    */ package org.springframework.core.task;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SyncTaskExecutor
/*    */   implements TaskExecutor, Serializable
/*    */ {
/*    */   public void execute(Runnable task)
/*    */   {
/* 49 */     Assert.notNull(task, "Runnable must not be null");
/* 50 */     task.run();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.task.SyncTaskExecutor
 * JD-Core Version:    0.6.2
 */