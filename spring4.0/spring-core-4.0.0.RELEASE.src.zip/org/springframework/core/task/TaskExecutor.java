package org.springframework.core.task;

import java.util.concurrent.Executor;

public abstract interface TaskExecutor extends Executor
{
  public abstract void execute(Runnable paramRunnable);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.task.TaskExecutor
 * JD-Core Version:    0.6.2
 */