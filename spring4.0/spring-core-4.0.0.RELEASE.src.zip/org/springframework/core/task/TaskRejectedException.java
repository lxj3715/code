/*    */ package org.springframework.core.task;
/*    */ 
/*    */ import java.util.concurrent.RejectedExecutionException;
/*    */ 
/*    */ public class TaskRejectedException extends RejectedExecutionException
/*    */ {
/*    */   public TaskRejectedException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ 
/*    */   public TaskRejectedException(String msg, Throwable cause)
/*    */   {
/* 51 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.task.TaskRejectedException
 * JD-Core Version:    0.6.2
 */