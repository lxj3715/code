/*    */ package org.springframework.core.task;
/*    */ 
/*    */ public class TaskTimeoutException extends TaskRejectedException
/*    */ {
/*    */   public TaskTimeoutException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public TaskTimeoutException(String msg, Throwable cause)
/*    */   {
/* 49 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.task.TaskTimeoutException
 * JD-Core Version:    0.6.2
 */