/*    */ package org.springframework.core.task.support;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.Executor;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.FutureTask;
/*    */ import java.util.concurrent.RejectedExecutionException;
/*    */ import org.springframework.core.task.AsyncTaskExecutor;
/*    */ import org.springframework.core.task.TaskRejectedException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class TaskExecutorAdapter
/*    */   implements AsyncTaskExecutor
/*    */ {
/*    */   private Executor concurrentExecutor;
/*    */ 
/*    */   public TaskExecutorAdapter(Executor concurrentExecutor)
/*    */   {
/* 53 */     Assert.notNull(concurrentExecutor, "Executor must not be null");
/* 54 */     this.concurrentExecutor = concurrentExecutor;
/*    */   }
/*    */ 
/*    */   public void execute(Runnable task)
/*    */   {
/*    */     try
/*    */     {
/* 65 */       this.concurrentExecutor.execute(task);
/*    */     }
/*    */     catch (RejectedExecutionException ex) {
/* 68 */       throw new TaskRejectedException("Executor [" + this.concurrentExecutor + "] did not accept task: " + task, ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void execute(Runnable task, long startTimeout)
/*    */   {
/* 75 */     execute(task);
/*    */   }
/*    */ 
/*    */   public Future<?> submit(Runnable task)
/*    */   {
/*    */     try {
/* 81 */       if ((this.concurrentExecutor instanceof ExecutorService)) {
/* 82 */         return ((ExecutorService)this.concurrentExecutor).submit(task);
/*    */       }
/*    */ 
/* 85 */       FutureTask future = new FutureTask(task, null);
/* 86 */       this.concurrentExecutor.execute(future);
/* 87 */       return future;
/*    */     }
/*    */     catch (RejectedExecutionException ex)
/*    */     {
/* 91 */       throw new TaskRejectedException("Executor [" + this.concurrentExecutor + "] did not accept task: " + task, ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public <T> Future<T> submit(Callable<T> task)
/*    */   {
/*    */     try
/*    */     {
/* 99 */       if ((this.concurrentExecutor instanceof ExecutorService)) {
/* 100 */         return ((ExecutorService)this.concurrentExecutor).submit(task);
/*    */       }
/*    */ 
/* 103 */       FutureTask future = new FutureTask(task);
/* 104 */       this.concurrentExecutor.execute(future);
/* 105 */       return future;
/*    */     }
/*    */     catch (RejectedExecutionException ex)
/*    */     {
/* 109 */       throw new TaskRejectedException("Executor [" + this.concurrentExecutor + "] did not accept task: " + task, ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.task.support.TaskExecutorAdapter
 * JD-Core Version:    0.6.2
 */