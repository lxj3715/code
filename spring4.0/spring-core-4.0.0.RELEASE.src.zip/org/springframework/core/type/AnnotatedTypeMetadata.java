package org.springframework.core.type;

import java.util.Map;
import org.springframework.util.MultiValueMap;

public abstract interface AnnotatedTypeMetadata
{
  public abstract boolean isAnnotated(String paramString);

  public abstract Map<String, Object> getAnnotationAttributes(String paramString);

  public abstract Map<String, Object> getAnnotationAttributes(String paramString, boolean paramBoolean);

  public abstract MultiValueMap<String, Object> getAllAnnotationAttributes(String paramString);

  public abstract MultiValueMap<String, Object> getAllAnnotationAttributes(String paramString, boolean paramBoolean);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.AnnotatedTypeMetadata
 * JD-Core Version:    0.6.2
 */