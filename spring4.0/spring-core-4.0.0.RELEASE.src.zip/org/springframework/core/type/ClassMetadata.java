package org.springframework.core.type;

public abstract interface ClassMetadata
{
  public abstract String getClassName();

  public abstract boolean isInterface();

  public abstract boolean isAbstract();

  public abstract boolean isConcrete();

  public abstract boolean isFinal();

  public abstract boolean isIndependent();

  public abstract boolean hasEnclosingClass();

  public abstract String getEnclosingClassName();

  public abstract boolean hasSuperClass();

  public abstract String getSuperClassName();

  public abstract String[] getInterfaceNames();

  public abstract String[] getMemberClassNames();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.ClassMetadata
 * JD-Core Version:    0.6.2
 */