package org.springframework.core.type;

public abstract interface MethodMetadata extends AnnotatedTypeMetadata
{
  public abstract String getMethodName();

  public abstract String getDeclaringClassName();

  public abstract boolean isStatic();

  public abstract boolean isFinal();

  public abstract boolean isOverridable();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.MethodMetadata
 * JD-Core Version:    0.6.2
 */