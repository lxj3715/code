/*     */ package org.springframework.core.type;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public class StandardAnnotationMetadata extends StandardClassMetadata
/*     */   implements AnnotationMetadata
/*     */ {
/*     */   private final boolean nestedAnnotationsAsMap;
/*     */ 
/*     */   public StandardAnnotationMetadata(Class<?> introspectedClass)
/*     */   {
/*  49 */     this(introspectedClass, false);
/*     */   }
/*     */ 
/*     */   public StandardAnnotationMetadata(Class<?> introspectedClass, boolean nestedAnnotationsAsMap)
/*     */   {
/*  64 */     super(introspectedClass);
/*  65 */     this.nestedAnnotationsAsMap = nestedAnnotationsAsMap;
/*     */   }
/*     */ 
/*     */   public Set<String> getAnnotationTypes()
/*     */   {
/*  71 */     Set types = new LinkedHashSet();
/*  72 */     Annotation[] anns = getIntrospectedClass().getAnnotations();
/*  73 */     for (Annotation ann : anns) {
/*  74 */       types.add(ann.annotationType().getName());
/*     */     }
/*  76 */     return types;
/*     */   }
/*     */ 
/*     */   public Set<String> getMetaAnnotationTypes(String annotationType)
/*     */   {
/*  81 */     return AnnotatedElementUtils.getMetaAnnotationTypes(getIntrospectedClass(), annotationType);
/*     */   }
/*     */ 
/*     */   public boolean hasAnnotation(String annotationType)
/*     */   {
/*  86 */     Annotation[] anns = getIntrospectedClass().getAnnotations();
/*  87 */     for (Annotation ann : anns) {
/*  88 */       if (ann.annotationType().getName().equals(annotationType)) {
/*  89 */         return true;
/*     */       }
/*     */     }
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean hasMetaAnnotation(String annotationType)
/*     */   {
/*  97 */     return AnnotatedElementUtils.hasMetaAnnotationTypes(getIntrospectedClass(), annotationType);
/*     */   }
/*     */ 
/*     */   public boolean isAnnotated(String annotationType)
/*     */   {
/* 102 */     return AnnotatedElementUtils.isAnnotated(getIntrospectedClass(), annotationType);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getAnnotationAttributes(String annotationType)
/*     */   {
/* 107 */     return getAnnotationAttributes(annotationType, false);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getAnnotationAttributes(String annotationType, boolean classValuesAsString)
/*     */   {
/* 112 */     return AnnotatedElementUtils.getAnnotationAttributes(getIntrospectedClass(), annotationType, classValuesAsString, this.nestedAnnotationsAsMap);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationType)
/*     */   {
/* 118 */     return getAllAnnotationAttributes(annotationType, false);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationType, boolean classValuesAsString)
/*     */   {
/* 123 */     return AnnotatedElementUtils.getAllAnnotationAttributes(getIntrospectedClass(), annotationType, classValuesAsString, this.nestedAnnotationsAsMap);
/*     */   }
/*     */ 
/*     */   public boolean hasAnnotatedMethods(String annotationType)
/*     */   {
/* 129 */     Method[] methods = getIntrospectedClass().getDeclaredMethods();
/* 130 */     for (Method method : methods) {
/* 131 */       if (AnnotatedElementUtils.isAnnotated(method, annotationType)) {
/* 132 */         return true;
/*     */       }
/*     */     }
/* 135 */     return false;
/*     */   }
/*     */ 
/*     */   public Set<MethodMetadata> getAnnotatedMethods(String annotationType)
/*     */   {
/* 140 */     Method[] methods = getIntrospectedClass().getDeclaredMethods();
/* 141 */     Set annotatedMethods = new LinkedHashSet();
/* 142 */     for (Method method : methods) {
/* 143 */       if (AnnotatedElementUtils.isAnnotated(method, annotationType)) {
/* 144 */         annotatedMethods.add(new StandardMethodMetadata(method, this.nestedAnnotationsAsMap));
/*     */       }
/*     */     }
/* 147 */     return annotatedMethods;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.StandardAnnotationMetadata
 * JD-Core Version:    0.6.2
 */