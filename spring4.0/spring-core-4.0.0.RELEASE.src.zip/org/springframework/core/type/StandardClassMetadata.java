/*     */ package org.springframework.core.type;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.LinkedHashSet;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class StandardClassMetadata
/*     */   implements ClassMetadata
/*     */ {
/*     */   private final Class<?> introspectedClass;
/*     */ 
/*     */   public StandardClassMetadata(Class<?> introspectedClass)
/*     */   {
/*  41 */     Assert.notNull(introspectedClass, "Class must not be null");
/*  42 */     this.introspectedClass = introspectedClass;
/*     */   }
/*     */ 
/*     */   public final Class<?> getIntrospectedClass()
/*     */   {
/*  49 */     return this.introspectedClass;
/*     */   }
/*     */ 
/*     */   public String getClassName()
/*     */   {
/*  55 */     return this.introspectedClass.getName();
/*     */   }
/*     */ 
/*     */   public boolean isInterface()
/*     */   {
/*  60 */     return this.introspectedClass.isInterface();
/*     */   }
/*     */ 
/*     */   public boolean isAbstract()
/*     */   {
/*  65 */     return Modifier.isAbstract(this.introspectedClass.getModifiers());
/*     */   }
/*     */ 
/*     */   public boolean isConcrete()
/*     */   {
/*  70 */     return (!isInterface()) && (!isAbstract());
/*     */   }
/*     */ 
/*     */   public boolean isFinal()
/*     */   {
/*  75 */     return Modifier.isFinal(this.introspectedClass.getModifiers());
/*     */   }
/*     */ 
/*     */   public boolean isIndependent()
/*     */   {
/*  82 */     return (!hasEnclosingClass()) || (
/*  81 */       (this.introspectedClass
/*  81 */       .getDeclaringClass() != null) && 
/*  82 */       (Modifier.isStatic(this.introspectedClass
/*  82 */       .getModifiers())));
/*     */   }
/*     */ 
/*     */   public boolean hasEnclosingClass()
/*     */   {
/*  87 */     return this.introspectedClass.getEnclosingClass() != null;
/*     */   }
/*     */ 
/*     */   public String getEnclosingClassName()
/*     */   {
/*  92 */     Class enclosingClass = this.introspectedClass.getEnclosingClass();
/*  93 */     return enclosingClass != null ? enclosingClass.getName() : null;
/*     */   }
/*     */ 
/*     */   public boolean hasSuperClass()
/*     */   {
/*  98 */     return this.introspectedClass.getSuperclass() != null;
/*     */   }
/*     */ 
/*     */   public String getSuperClassName()
/*     */   {
/* 103 */     Class superClass = this.introspectedClass.getSuperclass();
/* 104 */     return superClass != null ? superClass.getName() : null;
/*     */   }
/*     */ 
/*     */   public String[] getInterfaceNames()
/*     */   {
/* 109 */     Class[] ifcs = this.introspectedClass.getInterfaces();
/* 110 */     String[] ifcNames = new String[ifcs.length];
/* 111 */     for (int i = 0; i < ifcs.length; i++) {
/* 112 */       ifcNames[i] = ifcs[i].getName();
/*     */     }
/* 114 */     return ifcNames;
/*     */   }
/*     */ 
/*     */   public String[] getMemberClassNames()
/*     */   {
/* 119 */     LinkedHashSet memberClassNames = new LinkedHashSet();
/* 120 */     for (Class nestedClass : this.introspectedClass.getDeclaredClasses()) {
/* 121 */       memberClassNames.add(nestedClass.getName());
/*     */     }
/* 123 */     return (String[])memberClassNames.toArray(new String[memberClassNames.size()]);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.StandardClassMetadata
 * JD-Core Version:    0.6.2
 */