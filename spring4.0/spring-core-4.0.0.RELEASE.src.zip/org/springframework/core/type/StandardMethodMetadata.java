/*     */ package org.springframework.core.type;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public class StandardMethodMetadata
/*     */   implements MethodMetadata
/*     */ {
/*     */   private final Method introspectedMethod;
/*     */   private final boolean nestedAnnotationsAsMap;
/*     */ 
/*     */   public StandardMethodMetadata(Method introspectedMethod)
/*     */   {
/*  49 */     this(introspectedMethod, false);
/*     */   }
/*     */ 
/*     */   public StandardMethodMetadata(Method introspectedMethod, boolean nestedAnnotationsAsMap)
/*     */   {
/*  64 */     Assert.notNull(introspectedMethod, "Method must not be null");
/*  65 */     this.introspectedMethod = introspectedMethod;
/*  66 */     this.nestedAnnotationsAsMap = nestedAnnotationsAsMap;
/*     */   }
/*     */ 
/*     */   public final Method getIntrospectedMethod()
/*     */   {
/*  73 */     return this.introspectedMethod;
/*     */   }
/*     */ 
/*     */   public String getMethodName()
/*     */   {
/*  79 */     return this.introspectedMethod.getName();
/*     */   }
/*     */ 
/*     */   public String getDeclaringClassName()
/*     */   {
/*  84 */     return this.introspectedMethod.getDeclaringClass().getName();
/*     */   }
/*     */ 
/*     */   public boolean isStatic()
/*     */   {
/*  89 */     return Modifier.isStatic(this.introspectedMethod.getModifiers());
/*     */   }
/*     */ 
/*     */   public boolean isFinal()
/*     */   {
/*  94 */     return Modifier.isFinal(this.introspectedMethod.getModifiers());
/*     */   }
/*     */ 
/*     */   public boolean isOverridable()
/*     */   {
/*  99 */     return (!isStatic()) && (!isFinal()) && (!Modifier.isPrivate(this.introspectedMethod.getModifiers()));
/*     */   }
/*     */ 
/*     */   public boolean isAnnotated(String annotationType)
/*     */   {
/* 104 */     return AnnotatedElementUtils.isAnnotated(this.introspectedMethod, annotationType);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getAnnotationAttributes(String annotationType)
/*     */   {
/* 109 */     return getAnnotationAttributes(annotationType, false);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getAnnotationAttributes(String annotationType, boolean classValuesAsString)
/*     */   {
/* 114 */     return AnnotatedElementUtils.getAnnotationAttributes(this.introspectedMethod, annotationType, classValuesAsString, this.nestedAnnotationsAsMap);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationType)
/*     */   {
/* 120 */     return getAllAnnotationAttributes(annotationType, false);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationType, boolean classValuesAsString)
/*     */   {
/* 125 */     return AnnotatedElementUtils.getAllAnnotationAttributes(this.introspectedMethod, annotationType, classValuesAsString, this.nestedAnnotationsAsMap);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.StandardMethodMetadata
 * JD-Core Version:    0.6.2
 */