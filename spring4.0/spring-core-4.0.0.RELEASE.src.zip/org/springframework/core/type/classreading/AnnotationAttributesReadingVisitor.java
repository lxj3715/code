/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ final class AnnotationAttributesReadingVisitor extends RecursiveAnnotationAttributesVisitor
/*     */ {
/*     */   private final String annotationType;
/*     */   private final MultiValueMap<String, AnnotationAttributes> attributesMap;
/*     */   private final Map<String, Set<String>> metaAnnotationMap;
/*     */ 
/*     */   public AnnotationAttributesReadingVisitor(String annotationType, MultiValueMap<String, AnnotationAttributes> attributesMap, Map<String, Set<String>> metaAnnotationMap, ClassLoader classLoader)
/*     */   {
/* 250 */     super(annotationType, new AnnotationAttributes(), classLoader);
/* 251 */     this.annotationType = annotationType;
/* 252 */     this.attributesMap = attributesMap;
/* 253 */     this.metaAnnotationMap = metaAnnotationMap;
/*     */   }
/*     */ 
/*     */   public void doVisitEnd(Class<?> annotationClass)
/*     */   {
/* 259 */     super.doVisitEnd(annotationClass);
/* 260 */     List attributes = (List)this.attributesMap.get(this.annotationType);
/* 261 */     if (attributes == null) {
/* 262 */       this.attributesMap.add(this.annotationType, this.attributes);
/*     */     }
/*     */     else {
/* 265 */       attributes.add(0, this.attributes);
/*     */     }
/* 267 */     Set metaAnnotationTypeNames = new LinkedHashSet();
/* 268 */     for (Annotation metaAnnotation : annotationClass.getAnnotations()) {
/* 269 */       recursivelyCollectMetaAnnotations(metaAnnotationTypeNames, metaAnnotation);
/*     */     }
/* 271 */     if (this.metaAnnotationMap != null)
/* 272 */       this.metaAnnotationMap.put(annotationClass.getName(), metaAnnotationTypeNames);
/*     */   }
/*     */ 
/*     */   private void recursivelyCollectMetaAnnotations(Set<String> visited, Annotation annotation)
/*     */   {
/* 277 */     if (visited.add(annotation.annotationType().getName()))
/*     */     {
/* 280 */       if (Modifier.isPublic(annotation.annotationType().getModifiers())) {
/* 281 */         this.attributesMap.add(annotation.annotationType().getName(), 
/* 282 */           AnnotationUtils.getAnnotationAttributes(annotation, true, true));
/*     */ 
/* 283 */         for (Annotation metaMetaAnnotation : annotation.annotationType().getAnnotations())
/* 284 */           recursivelyCollectMetaAnnotations(visited, metaMetaAnnotation);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.AnnotationAttributesReadingVisitor
 * JD-Core Version:    0.6.2
 */