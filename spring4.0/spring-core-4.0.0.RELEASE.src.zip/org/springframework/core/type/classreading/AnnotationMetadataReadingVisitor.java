/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public class AnnotationMetadataReadingVisitor extends ClassMetadataReadingVisitor
/*     */   implements AnnotationMetadata
/*     */ {
/*     */   protected final ClassLoader classLoader;
/*  51 */   protected final Set<String> annotationSet = new LinkedHashSet();
/*     */ 
/*  53 */   protected final Map<String, Set<String>> metaAnnotationMap = new LinkedHashMap(4);
/*     */ 
/*  55 */   protected final MultiValueMap<String, AnnotationAttributes> attributeMap = new LinkedMultiValueMap(4);
/*     */ 
/*  57 */   protected final MultiValueMap<String, MethodMetadata> methodMetadataMap = new LinkedMultiValueMap();
/*     */ 
/*     */   public AnnotationMetadataReadingVisitor(ClassLoader classLoader)
/*     */   {
/*  61 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*     */   {
/*  67 */     return new MethodMetadataReadingVisitor(name, access, getClassName(), this.classLoader, this.methodMetadataMap);
/*     */   }
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*     */   {
/*  72 */     String className = Type.getType(desc).getClassName();
/*  73 */     this.annotationSet.add(className);
/*  74 */     return new AnnotationAttributesReadingVisitor(className, this.attributeMap, this.metaAnnotationMap, this.classLoader);
/*     */   }
/*     */ 
/*     */   public Set<String> getAnnotationTypes()
/*     */   {
/*  80 */     return this.annotationSet;
/*     */   }
/*     */ 
/*     */   public Set<String> getMetaAnnotationTypes(String annotationType)
/*     */   {
/*  85 */     return (Set)this.metaAnnotationMap.get(annotationType);
/*     */   }
/*     */ 
/*     */   public boolean hasAnnotation(String annotationType)
/*     */   {
/*  90 */     return this.annotationSet.contains(annotationType);
/*     */   }
/*     */ 
/*     */   public boolean hasMetaAnnotation(String metaAnnotationType)
/*     */   {
/*  95 */     Collection allMetaTypes = this.metaAnnotationMap.values();
/*  96 */     for (Set metaTypes : allMetaTypes) {
/*  97 */       if (metaTypes.contains(metaAnnotationType)) {
/*  98 */         return true;
/*     */       }
/*     */     }
/* 101 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isAnnotated(String annotationType)
/*     */   {
/* 106 */     return this.attributeMap.containsKey(annotationType);
/*     */   }
/*     */ 
/*     */   public AnnotationAttributes getAnnotationAttributes(String annotationType)
/*     */   {
/* 111 */     return getAnnotationAttributes(annotationType, false);
/*     */   }
/*     */ 
/*     */   public AnnotationAttributes getAnnotationAttributes(String annotationType, boolean classValuesAsString)
/*     */   {
/* 116 */     List attributes = (List)this.attributeMap.get(annotationType);
/* 117 */     AnnotationAttributes raw = attributes == null ? null : (AnnotationAttributes)attributes.get(0);
/* 118 */     return AnnotationReadingVisitorUtils.convertClassValues(this.classLoader, raw, classValuesAsString);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationType)
/*     */   {
/* 123 */     return getAllAnnotationAttributes(annotationType, false);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationType, boolean classValuesAsString)
/*     */   {
/* 128 */     MultiValueMap allAttributes = new LinkedMultiValueMap();
/* 129 */     List attributes = (List)this.attributeMap.get(annotationType);
/* 130 */     if (attributes == null) {
/* 131 */       return null;
/*     */     }
/* 133 */     for (AnnotationAttributes raw : attributes)
/*     */     {
/* 135 */       for (Map.Entry entry : AnnotationReadingVisitorUtils.convertClassValues(this.classLoader, raw, classValuesAsString).entrySet()) {
/* 136 */         allAttributes.add(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/* 139 */     return allAttributes;
/*     */   }
/*     */ 
/*     */   public boolean hasAnnotatedMethods(String annotationType)
/*     */   {
/* 144 */     return this.methodMetadataMap.containsKey(annotationType);
/*     */   }
/*     */ 
/*     */   public Set<MethodMetadata> getAnnotatedMethods(String annotationType)
/*     */   {
/* 149 */     List list = (List)this.methodMetadataMap.get(annotationType);
/* 150 */     if (CollectionUtils.isEmpty(list)) {
/* 151 */       return new LinkedHashSet(0);
/*     */     }
/* 153 */     Set annotatedMethods = new LinkedHashSet(list.size());
/* 154 */     annotatedMethods.addAll(list);
/* 155 */     return annotatedMethods;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.AnnotationMetadataReadingVisitor
 * JD-Core Version:    0.6.2
 */