/*    */ package org.springframework.core.type.classreading;
/*    */ 
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.asm.Type;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ 
/*    */ abstract class AnnotationReadingVisitorUtils
/*    */ {
/*    */   public static AnnotationAttributes convertClassValues(ClassLoader classLoader, AnnotationAttributes original, boolean classValuesAsString)
/*    */   {
/* 38 */     if (original == null) {
/* 39 */       return null;
/*    */     }
/*    */ 
/* 42 */     AnnotationAttributes result = new AnnotationAttributes(original.size());
/* 43 */     for (Map.Entry entry : original.entrySet()) {
/*    */       try {
/* 45 */         Object value = entry.getValue();
/* 46 */         if ((value instanceof AnnotationAttributes)) {
/* 47 */           value = convertClassValues(classLoader, (AnnotationAttributes)value, classValuesAsString);
/*    */         }
/* 50 */         else if ((value instanceof AnnotationAttributes[])) {
/* 51 */           AnnotationAttributes[] values = (AnnotationAttributes[])value;
/* 52 */           for (int i = 0; i < values.length; i++) {
/* 53 */             values[i] = convertClassValues(classLoader, values[i], classValuesAsString);
/*    */           }
/*    */ 
/*    */         }
/* 57 */         else if ((value instanceof Type))
/*    */         {
/* 59 */           value = classValuesAsString ? ((Type)value).getClassName() : classLoader
/* 59 */             .loadClass(((Type)value)
/* 59 */             .getClassName());
/*    */         }
/* 61 */         else if ((value instanceof Type[])) {
/* 62 */           Type[] array = (Type[])value;
/* 63 */           Object[] convArray = classValuesAsString ? new String[array.length] : new Class[array.length];
/* 64 */           for (int i = 0; i < array.length; i++) {
/* 65 */             convArray[i] = (classValuesAsString ? array[i].getClassName() : classLoader
/* 66 */               .loadClass(array[i]
/* 66 */               .getClassName()));
/*    */           }
/* 68 */           value = convArray;
/*    */         }
/* 70 */         else if (classValuesAsString) {
/* 71 */           if ((value instanceof Class)) {
/* 72 */             value = ((Class)value).getName();
/*    */           }
/* 74 */           else if ((value instanceof Class[])) {
/* 75 */             Class[] clazzArray = (Class[])value;
/* 76 */             String[] newValue = new String[clazzArray.length];
/* 77 */             for (int i = 0; i < clazzArray.length; i++) {
/* 78 */               newValue[i] = clazzArray[i].getName();
/*    */             }
/* 80 */             value = newValue;
/*    */           }
/*    */         }
/* 83 */         result.put(entry.getKey(), value);
/*    */       }
/*    */       catch (Exception ex)
/*    */       {
/*    */       }
/*    */     }
/* 89 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.AnnotationReadingVisitorUtils
 * JD-Core Version:    0.6.2
 */