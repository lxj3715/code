/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ import org.springframework.asm.Attribute;
/*     */ import org.springframework.asm.ClassVisitor;
/*     */ import org.springframework.asm.FieldVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.core.type.ClassMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ class ClassMetadataReadingVisitor extends ClassVisitor
/*     */   implements ClassMetadata
/*     */ {
/*     */   private String className;
/*     */   private boolean isInterface;
/*     */   private boolean isAbstract;
/*     */   private boolean isFinal;
/*     */   private String enclosingClassName;
/*     */   private boolean independentInnerClass;
/*     */   private String superClassName;
/*     */   private String[] interfaces;
/*  62 */   private Set<String> memberClassNames = new LinkedHashSet();
/*     */ 
/*     */   public ClassMetadataReadingVisitor()
/*     */   {
/*  66 */     super(262144);
/*     */   }
/*     */ 
/*     */   public void visit(int version, int access, String name, String signature, String supername, String[] interfaces)
/*     */   {
/*  72 */     this.className = ClassUtils.convertResourcePathToClassName(name);
/*  73 */     this.isInterface = ((access & 0x200) != 0);
/*  74 */     this.isAbstract = ((access & 0x400) != 0);
/*  75 */     this.isFinal = ((access & 0x10) != 0);
/*  76 */     if (supername != null) {
/*  77 */       this.superClassName = ClassUtils.convertResourcePathToClassName(supername);
/*     */     }
/*  79 */     this.interfaces = new String[interfaces.length];
/*  80 */     for (int i = 0; i < interfaces.length; i++)
/*  81 */       this.interfaces[i] = ClassUtils.convertResourcePathToClassName(interfaces[i]);
/*     */   }
/*     */ 
/*     */   public void visitOuterClass(String owner, String name, String desc)
/*     */   {
/*  87 */     this.enclosingClassName = ClassUtils.convertResourcePathToClassName(owner);
/*     */   }
/*     */ 
/*     */   public void visitInnerClass(String name, String outerName, String innerName, int access)
/*     */   {
/*  92 */     if (outerName != null) {
/*  93 */       String fqName = ClassUtils.convertResourcePathToClassName(name);
/*  94 */       String fqOuterName = ClassUtils.convertResourcePathToClassName(outerName);
/*  95 */       if (this.className.equals(fqName)) {
/*  96 */         this.enclosingClassName = fqOuterName;
/*  97 */         this.independentInnerClass = ((access & 0x8) != 0);
/*     */       }
/*  99 */       else if (this.className.equals(fqOuterName)) {
/* 100 */         this.memberClassNames.add(fqName);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void visitSource(String source, String debug)
/*     */   {
/*     */   }
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*     */   {
/* 113 */     return new EmptyAnnotationVisitor();
/*     */   }
/*     */ 
/*     */   public void visitAttribute(Attribute attr)
/*     */   {
/*     */   }
/*     */ 
/*     */   public FieldVisitor visitField(int access, String name, String desc, String signature, Object value)
/*     */   {
/* 124 */     return new EmptyFieldVisitor();
/*     */   }
/*     */ 
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*     */   {
/* 130 */     return new EmptyMethodVisitor();
/*     */   }
/*     */ 
/*     */   public void visitEnd()
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 141 */     return this.className;
/*     */   }
/*     */ 
/*     */   public boolean isInterface()
/*     */   {
/* 146 */     return this.isInterface;
/*     */   }
/*     */ 
/*     */   public boolean isAbstract()
/*     */   {
/* 151 */     return this.isAbstract;
/*     */   }
/*     */ 
/*     */   public boolean isConcrete()
/*     */   {
/* 156 */     return (!this.isInterface) && (!this.isAbstract);
/*     */   }
/*     */ 
/*     */   public boolean isFinal()
/*     */   {
/* 161 */     return this.isFinal;
/*     */   }
/*     */ 
/*     */   public boolean isIndependent()
/*     */   {
/* 166 */     return (this.enclosingClassName == null) || (this.independentInnerClass);
/*     */   }
/*     */ 
/*     */   public boolean hasEnclosingClass()
/*     */   {
/* 171 */     return this.enclosingClassName != null;
/*     */   }
/*     */ 
/*     */   public String getEnclosingClassName()
/*     */   {
/* 176 */     return this.enclosingClassName;
/*     */   }
/*     */ 
/*     */   public boolean hasSuperClass()
/*     */   {
/* 181 */     return this.superClassName != null;
/*     */   }
/*     */ 
/*     */   public String getSuperClassName()
/*     */   {
/* 186 */     return this.superClassName;
/*     */   }
/*     */ 
/*     */   public String[] getInterfaceNames()
/*     */   {
/* 191 */     return this.interfaces;
/*     */   }
/*     */ 
/*     */   public String[] getMemberClassNames()
/*     */   {
/* 196 */     return (String[])this.memberClassNames.toArray(new String[this.memberClassNames.size()]);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.ClassMetadataReadingVisitor
 * JD-Core Version:    0.6.2
 */