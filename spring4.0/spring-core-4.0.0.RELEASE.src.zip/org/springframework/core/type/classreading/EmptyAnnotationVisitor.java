/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ 
/*     */ class EmptyAnnotationVisitor extends AnnotationVisitor
/*     */ {
/*     */   public EmptyAnnotationVisitor()
/*     */   {
/* 205 */     super(262144);
/*     */   }
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String name, String desc)
/*     */   {
/* 210 */     return this;
/*     */   }
/*     */ 
/*     */   public AnnotationVisitor visitArray(String name)
/*     */   {
/* 215 */     return this;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.EmptyAnnotationVisitor
 * JD-Core Version:    0.6.2
 */