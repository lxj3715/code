/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import org.springframework.asm.FieldVisitor;
/*     */ 
/*     */ class EmptyFieldVisitor extends FieldVisitor
/*     */ {
/*     */   public EmptyFieldVisitor()
/*     */   {
/* 231 */     super(262144);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.EmptyFieldVisitor
 * JD-Core Version:    0.6.2
 */