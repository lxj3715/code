/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ 
/*     */ class EmptyMethodVisitor extends MethodVisitor
/*     */ {
/*     */   public EmptyMethodVisitor()
/*     */   {
/* 223 */     super(262144);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.EmptyMethodVisitor
 * JD-Core Version:    0.6.2
 */