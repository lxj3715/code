package org.springframework.core.type.classreading;

import org.springframework.core.io.Resource;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.ClassMetadata;

public abstract interface MetadataReader
{
  public abstract Resource getResource();

  public abstract ClassMetadata getClassMetadata();

  public abstract AnnotationMetadata getAnnotationMetadata();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.MetadataReader
 * JD-Core Version:    0.6.2
 */