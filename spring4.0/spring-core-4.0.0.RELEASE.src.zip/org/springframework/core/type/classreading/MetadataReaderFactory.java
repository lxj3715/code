package org.springframework.core.type.classreading;

import java.io.IOException;
import org.springframework.core.io.Resource;

public abstract interface MetadataReaderFactory
{
  public abstract MetadataReader getMetadataReader(String paramString)
    throws IOException;

  public abstract MetadataReader getMetadataReader(Resource paramResource)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.MetadataReaderFactory
 * JD-Core Version:    0.6.2
 */