/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public class MethodMetadataReadingVisitor extends MethodVisitor
/*     */   implements MethodMetadata
/*     */ {
/*     */   protected final String name;
/*     */   protected final int access;
/*     */   protected final String declaringClassName;
/*     */   protected final ClassLoader classLoader;
/*     */   protected final MultiValueMap<String, MethodMetadata> methodMetadataMap;
/*  56 */   protected final MultiValueMap<String, AnnotationAttributes> attributeMap = new LinkedMultiValueMap(2);
/*     */ 
/*     */   public MethodMetadataReadingVisitor(String name, int access, String declaringClassName, ClassLoader classLoader, MultiValueMap<String, MethodMetadata> methodMetadataMap)
/*     */   {
/*  62 */     super(262144);
/*  63 */     this.name = name;
/*  64 */     this.access = access;
/*  65 */     this.declaringClassName = declaringClassName;
/*  66 */     this.classLoader = classLoader;
/*  67 */     this.methodMetadataMap = methodMetadataMap;
/*     */   }
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*     */   {
/*  73 */     String className = Type.getType(desc).getClassName();
/*  74 */     this.methodMetadataMap.add(className, this);
/*  75 */     return new AnnotationAttributesReadingVisitor(className, this.attributeMap, null, this.classLoader);
/*     */   }
/*     */ 
/*     */   public String getMethodName()
/*     */   {
/*  80 */     return this.name;
/*     */   }
/*     */ 
/*     */   public boolean isStatic()
/*     */   {
/*  85 */     return (this.access & 0x8) != 0;
/*     */   }
/*     */ 
/*     */   public boolean isFinal()
/*     */   {
/*  90 */     return (this.access & 0x10) != 0;
/*     */   }
/*     */ 
/*     */   public boolean isOverridable()
/*     */   {
/*  95 */     return (!isStatic()) && (!isFinal()) && ((this.access & 0x2) == 0);
/*     */   }
/*     */ 
/*     */   public boolean isAnnotated(String annotationType)
/*     */   {
/* 100 */     return this.attributeMap.containsKey(annotationType);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getAnnotationAttributes(String annotationType)
/*     */   {
/* 105 */     return getAnnotationAttributes(annotationType, false);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getAnnotationAttributes(String annotationType, boolean classValuesAsString)
/*     */   {
/* 111 */     List attributes = (List)this.attributeMap.get(annotationType);
/* 112 */     return attributes == null ? null : AnnotationReadingVisitorUtils.convertClassValues(this.classLoader, 
/* 113 */       (AnnotationAttributes)attributes
/* 113 */       .get(0), 
/* 113 */       classValuesAsString);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationType)
/*     */   {
/* 118 */     return getAllAnnotationAttributes(annotationType, false);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, Object> getAllAnnotationAttributes(String annotationType, boolean classValuesAsString)
/*     */   {
/* 124 */     if (!this.attributeMap.containsKey(annotationType)) {
/* 125 */       return null;
/*     */     }
/* 127 */     MultiValueMap allAttributes = new LinkedMultiValueMap();
/* 128 */     for (AnnotationAttributes annotationAttributes : (List)this.attributeMap.get(annotationType)) {
/* 129 */       for (Map.Entry entry : AnnotationReadingVisitorUtils.convertClassValues(this.classLoader, annotationAttributes, classValuesAsString)
/* 130 */         .entrySet()) {
/* 131 */         allAttributes.add(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/* 134 */     return allAttributes;
/*     */   }
/*     */ 
/*     */   public String getDeclaringClassName()
/*     */   {
/* 139 */     return this.declaringClassName;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.MethodMetadataReadingVisitor
 * JD-Core Version:    0.6.2
 */