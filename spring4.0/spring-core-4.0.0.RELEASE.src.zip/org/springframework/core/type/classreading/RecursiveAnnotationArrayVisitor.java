/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.asm.AnnotationVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ final class RecursiveAnnotationArrayVisitor extends AbstractRecursiveAnnotationVisitor
/*     */ {
/*     */   private final String attributeName;
/* 115 */   private final List<AnnotationAttributes> allNestedAttributes = new ArrayList();
/*     */ 
/*     */   public RecursiveAnnotationArrayVisitor(String attributeName, AnnotationAttributes attributes, ClassLoader classLoader)
/*     */   {
/* 119 */     super(classLoader, attributes);
/* 120 */     this.attributeName = attributeName;
/*     */   }
/*     */ 
/*     */   public void visit(String attributeName, Object attributeValue)
/*     */   {
/* 125 */     Object newValue = attributeValue;
/* 126 */     Object existingValue = this.attributes.get(this.attributeName);
/* 127 */     if (existingValue != null) {
/* 128 */       newValue = ObjectUtils.addObjectToArray((Object[])existingValue, newValue);
/*     */     }
/*     */     else {
/* 131 */       Class arrayClass = newValue.getClass();
/* 132 */       if (Enum.class.isAssignableFrom(arrayClass)) {
/* 133 */         while ((arrayClass.getSuperclass() != null) && (!arrayClass.isEnum())) {
/* 134 */           arrayClass = arrayClass.getSuperclass();
/*     */         }
/*     */       }
/* 137 */       Object[] newArray = (Object[])Array.newInstance(arrayClass, 1);
/* 138 */       newArray[0] = newValue;
/* 139 */       newValue = newArray;
/*     */     }
/* 141 */     this.attributes.put(this.attributeName, newValue);
/*     */   }
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String attributeName, String asmTypeDescriptor)
/*     */   {
/* 146 */     String annotationType = Type.getType(asmTypeDescriptor).getClassName();
/* 147 */     AnnotationAttributes nestedAttributes = new AnnotationAttributes();
/* 148 */     this.allNestedAttributes.add(nestedAttributes);
/* 149 */     return new RecursiveAnnotationAttributesVisitor(annotationType, nestedAttributes, this.classLoader);
/*     */   }
/*     */ 
/*     */   public void visitEnd()
/*     */   {
/* 154 */     if (!this.allNestedAttributes.isEmpty())
/* 155 */       this.attributes.put(this.attributeName, this.allNestedAttributes.toArray(
/* 156 */         new AnnotationAttributes[this.allNestedAttributes
/* 156 */         .size()]));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.RecursiveAnnotationArrayVisitor
 * JD-Core Version:    0.6.2
 */