/*     */ package org.springframework.core.type.classreading;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ 
/*     */ class RecursiveAnnotationAttributesVisitor extends AbstractRecursiveAnnotationVisitor
/*     */ {
/*     */   private final String annotationType;
/*     */ 
/*     */   public RecursiveAnnotationAttributesVisitor(String annotationType, AnnotationAttributes attributes, ClassLoader classLoader)
/*     */   {
/* 173 */     super(classLoader, attributes);
/* 174 */     this.annotationType = annotationType;
/*     */   }
/*     */ 
/*     */   public final void visitEnd()
/*     */   {
/*     */     try {
/* 180 */       Class annotationClass = this.classLoader.loadClass(this.annotationType);
/* 181 */       doVisitEnd(annotationClass);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 184 */       this.logger.debug("Failed to class-load type while reading annotation metadata. This is a non-fatal error, but certain annotation metadata may be unavailable.", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doVisitEnd(Class<?> annotationClass)
/*     */   {
/* 190 */     registerDefaultValues(annotationClass);
/*     */   }
/*     */ 
/*     */   private void registerDefaultValues(Class<?> annotationClass)
/*     */   {
/* 196 */     if (Modifier.isPublic(annotationClass.getModifiers()))
/*     */     {
/* 198 */       Method[] annotationAttributes = annotationClass.getMethods();
/* 199 */       for (Method annotationAttribute : annotationAttributes) {
/* 200 */         String attributeName = annotationAttribute.getName();
/* 201 */         Object defaultValue = annotationAttribute.getDefaultValue();
/* 202 */         if ((defaultValue != null) && (!this.attributes.containsKey(attributeName))) {
/* 203 */           if ((defaultValue instanceof Annotation)) {
/* 204 */             defaultValue = AnnotationAttributes.fromMap(
/* 205 */               AnnotationUtils.getAnnotationAttributes((Annotation)defaultValue, false, true));
/*     */           }
/* 207 */           else if ((defaultValue instanceof Annotation[])) {
/* 208 */             Annotation[] realAnnotations = (Annotation[])defaultValue;
/* 209 */             AnnotationAttributes[] mappedAnnotations = new AnnotationAttributes[realAnnotations.length];
/* 210 */             for (int i = 0; i < realAnnotations.length; i++) {
/* 211 */               mappedAnnotations[i] = AnnotationAttributes.fromMap(
/* 212 */                 AnnotationUtils.getAnnotationAttributes(realAnnotations[i], false, true));
/*     */             }
/*     */ 
/* 214 */             defaultValue = mappedAnnotations;
/*     */           }
/* 216 */           this.attributes.put(attributeName, defaultValue);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.RecursiveAnnotationAttributesVisitor
 * JD-Core Version:    0.6.2
 */