/*    */ package org.springframework.core.type.classreading;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.springframework.core.io.DefaultResourceLoader;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class SimpleMetadataReaderFactory
/*    */   implements MetadataReaderFactory
/*    */ {
/*    */   private final ResourceLoader resourceLoader;
/*    */ 
/*    */   public SimpleMetadataReaderFactory()
/*    */   {
/* 42 */     this.resourceLoader = new DefaultResourceLoader();
/*    */   }
/*    */ 
/*    */   public SimpleMetadataReaderFactory(ResourceLoader resourceLoader)
/*    */   {
/* 51 */     this.resourceLoader = (resourceLoader != null ? resourceLoader : new DefaultResourceLoader());
/*    */   }
/*    */ 
/*    */   public SimpleMetadataReaderFactory(ClassLoader classLoader)
/*    */   {
/* 59 */     this.resourceLoader = (classLoader != null ? new DefaultResourceLoader(classLoader) : new DefaultResourceLoader());
/*    */   }
/*    */ 
/*    */   public final ResourceLoader getResourceLoader()
/*    */   {
/* 69 */     return this.resourceLoader;
/*    */   }
/*    */ 
/*    */   public MetadataReader getMetadataReader(String className)
/*    */     throws IOException
/*    */   {
/* 76 */     String resourcePath = "classpath:" + 
/* 76 */       ClassUtils.convertClassNameToResourcePath(className) + 
/* 76 */       ".class";
/* 77 */     return getMetadataReader(this.resourceLoader.getResource(resourcePath));
/*    */   }
/*    */ 
/*    */   public MetadataReader getMetadataReader(Resource resource) throws IOException
/*    */   {
/* 82 */     return new SimpleMetadataReader(resource, this.resourceLoader.getClassLoader());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.classreading.SimpleMetadataReaderFactory
 * JD-Core Version:    0.6.2
 */