/*     */ package org.springframework.core.type.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.type.ClassMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ 
/*     */ public abstract class AbstractTypeHierarchyTraversingFilter
/*     */   implements TypeFilter
/*     */ {
/*     */   private final boolean considerInherited;
/*     */   private final boolean considerInterfaces;
/*     */ 
/*     */   protected AbstractTypeHierarchyTraversingFilter(boolean considerInherited, boolean considerInterfaces)
/*     */   {
/*  45 */     this.considerInherited = considerInherited;
/*  46 */     this.considerInterfaces = considerInterfaces;
/*     */   }
/*     */ 
/*     */   public boolean match(MetadataReader metadataReader, MetadataReaderFactory metadataReaderFactory)
/*     */     throws IOException
/*     */   {
/*  56 */     if (matchSelf(metadataReader)) {
/*  57 */       return true;
/*     */     }
/*  59 */     ClassMetadata metadata = metadataReader.getClassMetadata();
/*  60 */     if (matchClassName(metadata.getClassName())) {
/*  61 */       return true;
/*     */     }
/*     */ 
/*  64 */     if (!this.considerInherited)
/*  65 */       return false;
/*     */     Boolean superClassMatch;
/*  67 */     if (metadata.hasSuperClass())
/*     */     {
/*  69 */       superClassMatch = matchSuperClass(metadata.getSuperClassName());
/*  70 */       if (superClassMatch != null) {
/*  71 */         if (superClassMatch.booleanValue()) {
/*  72 */           return true;
/*     */         }
/*     */ 
/*     */       }
/*  77 */       else if (match(metadata.getSuperClassName(), metadataReaderFactory)) {
/*  78 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  83 */     if (!this.considerInterfaces) {
/*  84 */       return false;
/*     */     }
/*  86 */     for (String ifc : metadata.getInterfaceNames())
/*     */     {
/*  88 */       Boolean interfaceMatch = matchInterface(ifc);
/*  89 */       if (interfaceMatch != null) {
/*  90 */         if (interfaceMatch.booleanValue()) {
/*  91 */           return true;
/*     */         }
/*     */ 
/*     */       }
/*  96 */       else if (match(ifc, metadataReaderFactory)) {
/*  97 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean match(String className, MetadataReaderFactory metadataReaderFactory) throws IOException {
/* 106 */     return match(metadataReaderFactory.getMetadataReader(className), metadataReaderFactory);
/*     */   }
/*     */ 
/*     */   protected boolean matchSelf(MetadataReader metadataReader)
/*     */   {
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean matchClassName(String className)
/*     */   {
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   protected Boolean matchSuperClass(String superClassName)
/*     */   {
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   protected Boolean matchInterface(String interfaceNames)
/*     */   {
/* 136 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.filter.AbstractTypeHierarchyTraversingFilter
 * JD-Core Version:    0.6.2
 */