/*    */ package org.springframework.core.type.filter;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.annotation.Inherited;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.classreading.MetadataReader;
/*    */ 
/*    */ public class AnnotationTypeFilter extends AbstractTypeHierarchyTraversingFilter
/*    */ {
/*    */   private final Class<? extends Annotation> annotationType;
/*    */   private final boolean considerMetaAnnotations;
/*    */ 
/*    */   public AnnotationTypeFilter(Class<? extends Annotation> annotationType)
/*    */   {
/* 52 */     this(annotationType, true);
/*    */   }
/*    */ 
/*    */   public AnnotationTypeFilter(Class<? extends Annotation> annotationType, boolean considerMetaAnnotations)
/*    */   {
/* 62 */     this(annotationType, considerMetaAnnotations, false);
/*    */   }
/*    */ 
/*    */   public AnnotationTypeFilter(Class<? extends Annotation> annotationType, boolean considerMetaAnnotations, boolean considerInterfaces)
/*    */   {
/* 72 */     super(annotationType.isAnnotationPresent(Inherited.class), considerInterfaces);
/* 73 */     this.annotationType = annotationType;
/* 74 */     this.considerMetaAnnotations = considerMetaAnnotations;
/*    */   }
/*    */ 
/*    */   protected boolean matchSelf(MetadataReader metadataReader)
/*    */   {
/* 80 */     AnnotationMetadata metadata = metadataReader.getAnnotationMetadata();
/*    */ 
/* 82 */     return (metadata.hasAnnotation(this.annotationType.getName())) || ((this.considerMetaAnnotations) && 
/* 82 */       (metadata
/* 82 */       .hasMetaAnnotation(this.annotationType
/* 82 */       .getName())));
/*    */   }
/*    */ 
/*    */   protected Boolean matchSuperClass(String superClassName)
/*    */   {
/* 87 */     if (Object.class.getName().equals(superClassName)) {
/* 88 */       return Boolean.FALSE;
/*    */     }
/* 90 */     if (superClassName.startsWith("java.")) {
/*    */       try {
/* 92 */         Class clazz = getClass().getClassLoader().loadClass(superClassName);
/* 93 */         return Boolean.valueOf(clazz.getAnnotation(this.annotationType) != null);
/*    */       }
/*    */       catch (ClassNotFoundException ex)
/*    */       {
/*    */       }
/*    */     }
/* 99 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.filter.AnnotationTypeFilter
 * JD-Core Version:    0.6.2
 */