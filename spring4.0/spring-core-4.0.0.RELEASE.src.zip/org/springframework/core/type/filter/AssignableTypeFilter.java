/*    */ package org.springframework.core.type.filter;
/*    */ 
/*    */ public class AssignableTypeFilter extends AbstractTypeHierarchyTraversingFilter
/*    */ {
/*    */   private final Class<?> targetType;
/*    */ 
/*    */   public AssignableTypeFilter(Class<?> targetType)
/*    */   {
/* 37 */     super(true, true);
/* 38 */     this.targetType = targetType;
/*    */   }
/*    */ 
/*    */   protected boolean matchClassName(String className)
/*    */   {
/* 44 */     return this.targetType.getName().equals(className);
/*    */   }
/*    */ 
/*    */   protected Boolean matchSuperClass(String superClassName)
/*    */   {
/* 49 */     return matchTargetType(superClassName);
/*    */   }
/*    */ 
/*    */   protected Boolean matchInterface(String interfaceName)
/*    */   {
/* 54 */     return matchTargetType(interfaceName);
/*    */   }
/*    */ 
/*    */   protected Boolean matchTargetType(String typeName) {
/* 58 */     if (this.targetType.getName().equals(typeName)) {
/* 59 */       return Boolean.valueOf(true);
/*    */     }
/* 61 */     if (Object.class.getName().equals(typeName)) {
/* 62 */       return Boolean.FALSE;
/*    */     }
/* 64 */     if (typeName.startsWith("java.")) {
/*    */       try {
/* 66 */         Class clazz = getClass().getClassLoader().loadClass(typeName);
/* 67 */         return Boolean.valueOf(this.targetType.isAssignableFrom(clazz));
/*    */       }
/*    */       catch (ClassNotFoundException ex)
/*    */       {
/*    */       }
/*    */     }
/* 73 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.filter.AssignableTypeFilter
 * JD-Core Version:    0.6.2
 */