package org.springframework.core.type.filter;

import java.io.IOException;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;

public abstract interface TypeFilter
{
  public abstract boolean match(MetadataReader paramMetadataReader, MetadataReaderFactory paramMetadataReaderFactory)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.core.type.filter.TypeFilter
 * JD-Core Version:    0.6.2
 */