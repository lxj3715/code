package org.springframework.objenesis;

import org.springframework.objenesis.instantiator.ObjectInstantiator;

public abstract interface Objenesis
{
  public abstract <T> T newInstance(Class<T> paramClass);

  public abstract <T> ObjectInstantiator<T> getInstantiatorOf(Class<T> paramClass);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.Objenesis
 * JD-Core Version:    0.6.2
 */