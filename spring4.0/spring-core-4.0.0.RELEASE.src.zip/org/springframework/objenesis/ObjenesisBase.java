/*    */ package org.springframework.objenesis;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ import org.springframework.objenesis.strategy.InstantiatorStrategy;
/*    */ 
/*    */ public class ObjenesisBase
/*    */   implements Objenesis
/*    */ {
/*    */   protected final InstantiatorStrategy strategy;
/*    */   protected ConcurrentHashMap<String, ObjectInstantiator<?>> cache;
/*    */ 
/*    */   public ObjenesisBase(InstantiatorStrategy strategy)
/*    */   {
/* 43 */     this(strategy, true);
/*    */   }
/*    */ 
/*    */   public ObjenesisBase(InstantiatorStrategy strategy, boolean useCache)
/*    */   {
/* 53 */     if (strategy == null) {
/* 54 */       throw new IllegalArgumentException("A strategy can't be null");
/*    */     }
/* 56 */     this.strategy = strategy;
/* 57 */     this.cache = (useCache ? new ConcurrentHashMap() : null);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 62 */     return getClass().getName() + " using " + this.strategy.getClass().getName() + (this.cache == null ? " without" : " with") + " caching";
/*    */   }
/*    */ 
/*    */   public <T> T newInstance(Class<T> clazz)
/*    */   {
/* 73 */     return getInstantiatorOf(clazz).newInstance();
/*    */   }
/*    */ 
/*    */   public <T> ObjectInstantiator<T> getInstantiatorOf(Class<T> clazz)
/*    */   {
/* 86 */     if (this.cache == null) {
/* 87 */       return this.strategy.newInstantiatorOf(clazz);
/*    */     }
/* 89 */     ObjectInstantiator instantiator = (ObjectInstantiator)this.cache.get(clazz.getName());
/* 90 */     if (instantiator == null) {
/* 91 */       ObjectInstantiator newInstantiator = this.strategy.newInstantiatorOf(clazz);
/* 92 */       instantiator = (ObjectInstantiator)this.cache.putIfAbsent(clazz.getName(), newInstantiator);
/* 93 */       if (instantiator == null) {
/* 94 */         instantiator = newInstantiator;
/*    */       }
/*    */     }
/* 97 */     return instantiator;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.ObjenesisBase
 * JD-Core Version:    0.6.2
 */