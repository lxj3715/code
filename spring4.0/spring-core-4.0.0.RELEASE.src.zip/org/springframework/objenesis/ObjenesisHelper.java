/*    */ package org.springframework.objenesis;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public final class ObjenesisHelper
/*    */ {
/* 29 */   private static final Objenesis OBJENESIS_STD = new ObjenesisStd();
/*    */ 
/* 31 */   private static final Objenesis OBJENESIS_SERIALIZER = new ObjenesisSerializer();
/*    */ 
/*    */   public static <T> T newInstance(Class<T> clazz)
/*    */   {
/* 43 */     return OBJENESIS_STD.newInstance(clazz);
/*    */   }
/*    */ 
/*    */   public static <T extends Serializable> T newSerializableInstance(Class<T> clazz)
/*    */   {
/* 54 */     return (Serializable)OBJENESIS_SERIALIZER.newInstance(clazz);
/*    */   }
/*    */ 
/*    */   public static <T> ObjectInstantiator<T> getInstantiatorOf(Class<T> clazz)
/*    */   {
/* 66 */     return OBJENESIS_STD.getInstantiatorOf(clazz);
/*    */   }
/*    */ 
/*    */   public static <T extends Serializable> ObjectInstantiator<T> getSerializableObjectInstantiatorOf(Class<T> clazz)
/*    */   {
/* 78 */     return OBJENESIS_SERIALIZER.getInstantiatorOf(clazz);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.ObjenesisHelper
 * JD-Core Version:    0.6.2
 */