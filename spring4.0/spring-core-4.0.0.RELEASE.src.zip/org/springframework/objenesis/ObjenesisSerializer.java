/*    */ package org.springframework.objenesis;
/*    */ 
/*    */ import org.springframework.objenesis.strategy.SerializingInstantiatorStrategy;
/*    */ 
/*    */ public class ObjenesisSerializer extends ObjenesisBase
/*    */ {
/*    */   public ObjenesisSerializer()
/*    */   {
/* 31 */     super(new SerializingInstantiatorStrategy());
/*    */   }
/*    */ 
/*    */   public ObjenesisSerializer(boolean useCache)
/*    */   {
/* 41 */     super(new SerializingInstantiatorStrategy(), useCache);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.ObjenesisSerializer
 * JD-Core Version:    0.6.2
 */