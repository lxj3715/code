/*    */ package org.springframework.objenesis;
/*    */ 
/*    */ import org.springframework.objenesis.strategy.StdInstantiatorStrategy;
/*    */ 
/*    */ public class ObjenesisStd extends ObjenesisBase
/*    */ {
/*    */   public ObjenesisStd()
/*    */   {
/* 31 */     super(new StdInstantiatorStrategy());
/*    */   }
/*    */ 
/*    */   public ObjenesisStd(boolean useCache)
/*    */   {
/* 41 */     super(new StdInstantiatorStrategy(), useCache);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.ObjenesisStd
 * JD-Core Version:    0.6.2
 */