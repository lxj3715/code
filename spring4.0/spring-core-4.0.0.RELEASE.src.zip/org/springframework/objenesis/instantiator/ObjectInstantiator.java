package org.springframework.objenesis.instantiator;

public abstract interface ObjectInstantiator<T>
{
  public abstract T newInstance();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.ObjectInstantiator
 * JD-Core Version:    0.6.2
 */