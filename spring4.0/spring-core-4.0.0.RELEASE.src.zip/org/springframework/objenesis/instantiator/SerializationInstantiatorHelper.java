/*    */ package org.springframework.objenesis.instantiator;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class SerializationInstantiatorHelper
/*    */ {
/*    */   public static <T> Class<? super T> getNonSerializableSuperClass(Class<T> type)
/*    */   {
/* 38 */     Class result = type;
/* 39 */     while (Serializable.class.isAssignableFrom(result)) {
/* 40 */       result = result.getSuperclass();
/* 41 */       if (result == null) {
/* 42 */         throw new Error("Bad class hierarchy: No non-serializable parents");
/*    */       }
/*    */     }
/* 45 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.SerializationInstantiatorHelper
 * JD-Core Version:    0.6.2
 */