/*    */ package org.springframework.objenesis.instantiator.android;
/*    */ 
/*    */ import java.io.ObjectInputStream;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class Android23Instantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Class<T> type;
/*    */   private final Method newStaticMethod;
/*    */ 
/*    */   public Android23Instantiator(Class<T> type)
/*    */   {
/* 35 */     this.type = type;
/* 36 */     this.newStaticMethod = getNewStaticMethod();
/*    */   }
/*    */ 
/*    */   public T newInstance() {
/*    */     try {
/* 41 */       return this.type.cast(this.newStaticMethod.invoke(null, new Object[] { this.type, Object.class }));
/*    */     }
/*    */     catch (Exception e) {
/* 44 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static Method getNewStaticMethod() {
/*    */     try {
/* 50 */       Method newStaticMethod = ObjectInputStream.class.getDeclaredMethod("newInstance", new Class[] { Class.class, Class.class });
/*    */ 
/* 52 */       newStaticMethod.setAccessible(true);
/* 53 */       return newStaticMethod;
/*    */     }
/*    */     catch (RuntimeException e) {
/* 56 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 59 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.android.Android23Instantiator
 * JD-Core Version:    0.6.2
 */