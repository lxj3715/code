/*    */ package org.springframework.objenesis.instantiator.android;
/*    */ 
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class Android30Instantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Class<T> type;
/*    */   private final Method newInstanceMethod;
/*    */   private final Integer objectConstructorId;
/*    */ 
/*    */   public Android30Instantiator(Class<T> type)
/*    */   {
/* 37 */     this.type = type;
/* 38 */     this.newInstanceMethod = getNewInstanceMethod();
/* 39 */     this.objectConstructorId = findConstructorIdForJavaLangObjectConstructor();
/*    */   }
/*    */ 
/*    */   public T newInstance() {
/*    */     try {
/* 44 */       return this.type.cast(this.newInstanceMethod.invoke(null, new Object[] { this.type, this.objectConstructorId }));
/*    */     }
/*    */     catch (Exception e) {
/* 47 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static Method getNewInstanceMethod() {
/*    */     try {
/* 53 */       Method newInstanceMethod = ObjectStreamClass.class.getDeclaredMethod("newInstance", new Class[] { Class.class, Integer.TYPE });
/*    */ 
/* 55 */       newInstanceMethod.setAccessible(true);
/* 56 */       return newInstanceMethod;
/*    */     }
/*    */     catch (RuntimeException e) {
/* 59 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 62 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static Integer findConstructorIdForJavaLangObjectConstructor() {
/*    */     try {
/* 68 */       Method newInstanceMethod = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", new Class[] { Class.class });
/*    */ 
/* 70 */       newInstanceMethod.setAccessible(true);
/*    */ 
/* 72 */       return (Integer)newInstanceMethod.invoke(null, new Object[] { Object.class });
/*    */     }
/*    */     catch (RuntimeException e) {
/* 75 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 78 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 81 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 84 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.android.Android30Instantiator
 * JD-Core Version:    0.6.2
 */