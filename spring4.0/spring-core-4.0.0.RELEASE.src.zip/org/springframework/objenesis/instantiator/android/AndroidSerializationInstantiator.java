/*    */ package org.springframework.objenesis.instantiator.android;
/*    */ 
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class AndroidSerializationInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Class<T> type;
/*    */   private final ObjectStreamClass objectStreamClass;
/*    */   private final Method newInstanceMethod;
/*    */ 
/*    */   public AndroidSerializationInstantiator(Class<T> type)
/*    */   {
/* 38 */     this.type = type;
/* 39 */     this.newInstanceMethod = getNewInstanceMethod();
/* 40 */     Method m = null;
/*    */     try {
/* 42 */       m = ObjectStreamClass.class.getMethod("lookupAny", new Class[] { Class.class });
/*    */     } catch (NoSuchMethodException e) {
/* 44 */       throw new ObjenesisException(e);
/*    */     }
/*    */     try {
/* 47 */       this.objectStreamClass = ((ObjectStreamClass)m.invoke(null, new Object[] { type }));
/*    */     } catch (IllegalAccessException e) {
/* 49 */       throw new ObjenesisException(e);
/*    */     } catch (InvocationTargetException e) {
/* 51 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public T newInstance() {
/*    */     try {
/* 57 */       return this.type.cast(this.newInstanceMethod.invoke(this.objectStreamClass, new Object[] { this.type }));
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 60 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (IllegalArgumentException e) {
/* 63 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 66 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static Method getNewInstanceMethod() {
/*    */     try {
/* 72 */       Method newInstanceMethod = ObjectStreamClass.class.getDeclaredMethod("newInstance", new Class[] { Class.class });
/*    */ 
/* 74 */       newInstanceMethod.setAccessible(true);
/* 75 */       return newInstanceMethod;
/*    */     }
/*    */     catch (RuntimeException e) {
/* 78 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 81 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.android.AndroidSerializationInstantiator
 * JD-Core Version:    0.6.2
 */