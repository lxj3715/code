/*    */ package org.springframework.objenesis.instantiator.basic;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ public class AccessibleInstantiator<T> extends ConstructorInstantiator<T>
/*    */ {
/*    */   public AccessibleInstantiator(Class<T> type)
/*    */   {
/* 29 */     super(type);
/* 30 */     if (this.constructor != null)
/* 31 */       this.constructor.setAccessible(true);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.basic.AccessibleInstantiator
 * JD-Core Version:    0.6.2
 */