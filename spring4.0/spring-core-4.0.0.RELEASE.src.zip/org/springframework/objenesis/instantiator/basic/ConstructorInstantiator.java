/*    */ package org.springframework.objenesis.instantiator.basic;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class ConstructorInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   protected Constructor<T> constructor;
/*    */ 
/*    */   public ConstructorInstantiator(Class<T> type)
/*    */   {
/*    */     try
/*    */     {
/* 37 */       this.constructor = type.getDeclaredConstructor((Class[])null);
/*    */     }
/*    */     catch (Exception e) {
/* 40 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public T newInstance() {
/*    */     try {
/* 46 */       return this.constructor.newInstance((Object[])null);
/*    */     }
/*    */     catch (Exception e) {
/* 49 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.basic.ConstructorInstantiator
 * JD-Core Version:    0.6.2
 */