/*    */ package org.springframework.objenesis.instantiator.basic;
/*    */ 
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class NewInstanceInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Class<T> type;
/*    */ 
/*    */   public NewInstanceInstantiator(Class<T> type)
/*    */   {
/* 33 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public T newInstance() {
/*    */     try {
/* 38 */       return this.type.newInstance();
/*    */     }
/*    */     catch (Exception e) {
/* 41 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.basic.NewInstanceInstantiator
 * JD-Core Version:    0.6.2
 */