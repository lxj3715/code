/*    */ package org.springframework.objenesis.instantiator.basic;
/*    */ 
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class NullInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   public T newInstance()
/*    */   {
/* 31 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.basic.NullInstantiator
 * JD-Core Version:    0.6.2
 */