/*     */ package org.springframework.objenesis.instantiator.basic;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.io.Serializable;
/*     */ import org.springframework.objenesis.ObjenesisException;
/*     */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*     */ 
/*     */ public class ObjectInputStreamInstantiator<T>
/*     */   implements ObjectInstantiator<T>
/*     */ {
/*     */   private ObjectInputStream inputStream;
/*     */ 
/*     */   public ObjectInputStreamInstantiator(Class<T> clazz)
/*     */   {
/* 158 */     if (Serializable.class.isAssignableFrom(clazz)) {
/*     */       try {
/* 160 */         this.inputStream = new ObjectInputStream(new MockStream(clazz));
/*     */       }
/*     */       catch (IOException e) {
/* 163 */         throw new Error("IOException: " + e.getMessage());
/*     */       }
/*     */     }
/*     */     else
/* 167 */       throw new ObjenesisException(new NotSerializableException(clazz + " not serializable"));
/*     */   }
/*     */ 
/*     */   public T newInstance()
/*     */   {
/*     */     try
/*     */     {
/* 174 */       return this.inputStream.readObject();
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 177 */       throw new Error("ClassNotFoundException: " + e.getMessage());
/*     */     }
/*     */     catch (Exception e) {
/* 180 */       throw new ObjenesisException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MockStream extends InputStream
/*     */   {
/*     */     private int pointer;
/*     */     private byte[] data;
/*     */     private int sequence;
/*  47 */     private static final int[] NEXT = { 1, 2, 2 };
/*     */     private byte[][] buffers;
/*     */     private final byte[] FIRST_DATA;
/*     */     private static byte[] HEADER;
/*     */     private static byte[] REPEATING_DATA;
/*     */ 
/*     */     private static void initialize()
/*     */     {
/*     */       try
/*     */       {
/*  60 */         ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
/*  61 */         DataOutputStream dout = new DataOutputStream(byteOut);
/*  62 */         dout.writeShort(-21267);
/*  63 */         dout.writeShort(5);
/*  64 */         HEADER = byteOut.toByteArray();
/*     */ 
/*  66 */         byteOut = new ByteArrayOutputStream();
/*  67 */         dout = new DataOutputStream(byteOut);
/*     */ 
/*  69 */         dout.writeByte(115);
/*  70 */         dout.writeByte(113);
/*  71 */         dout.writeInt(8257536);
/*  72 */         REPEATING_DATA = byteOut.toByteArray();
/*     */       }
/*     */       catch (IOException e) {
/*  75 */         throw new Error("IOException: " + e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/*     */     public MockStream(Class<?> clazz)
/*     */     {
/*  81 */       this.pointer = 0;
/*  82 */       this.sequence = 0;
/*  83 */       this.data = HEADER;
/*     */ 
/*  94 */       ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
/*  95 */       DataOutputStream dout = new DataOutputStream(byteOut);
/*     */       try {
/*  97 */         dout.writeByte(115);
/*  98 */         dout.writeByte(114);
/*  99 */         dout.writeUTF(clazz.getName());
/* 100 */         dout.writeLong(ObjectStreamClass.lookup(clazz).getSerialVersionUID());
/* 101 */         dout.writeByte(2);
/* 102 */         dout.writeShort(0);
/* 103 */         dout.writeByte(120);
/* 104 */         dout.writeByte(112);
/*     */       }
/*     */       catch (IOException e) {
/* 107 */         throw new Error("IOException: " + e.getMessage());
/*     */       }
/* 109 */       this.FIRST_DATA = byteOut.toByteArray();
/* 110 */       this.buffers = new byte[][] { HEADER, this.FIRST_DATA, REPEATING_DATA };
/*     */     }
/*     */ 
/*     */     private void advanceBuffer() {
/* 114 */       this.pointer = 0;
/* 115 */       this.sequence = NEXT[this.sequence];
/* 116 */       this.data = this.buffers[this.sequence];
/*     */     }
/*     */ 
/*     */     public int read() throws IOException
/*     */     {
/* 121 */       int result = this.data[(this.pointer++)];
/* 122 */       if (this.pointer >= this.data.length) {
/* 123 */         advanceBuffer();
/*     */       }
/*     */ 
/* 126 */       return result;
/*     */     }
/*     */ 
/*     */     public int available() throws IOException
/*     */     {
/* 131 */       return 2147483647;
/*     */     }
/*     */ 
/*     */     public int read(byte[] b, int off, int len) throws IOException
/*     */     {
/* 136 */       int left = len;
/* 137 */       int remaining = this.data.length - this.pointer;
/*     */ 
/* 139 */       while (remaining <= left) {
/* 140 */         System.arraycopy(this.data, this.pointer, b, off, remaining);
/* 141 */         off += remaining;
/* 142 */         left -= remaining;
/* 143 */         advanceBuffer();
/* 144 */         remaining = this.data.length - this.pointer;
/*     */       }
/* 146 */       if (left > 0) {
/* 147 */         System.arraycopy(this.data, this.pointer, b, off, left);
/* 148 */         this.pointer += left;
/*     */       }
/*     */ 
/* 151 */       return len;
/*     */     }
/*     */ 
/*     */     static
/*     */     {
/*  55 */       initialize();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.basic.ObjectInputStreamInstantiator
 * JD-Core Version:    0.6.2
 */