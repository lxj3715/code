/*    */ package org.springframework.objenesis.instantiator.basic;
/*    */ 
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class ObjectStreamClassInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private static Method newInstanceMethod;
/*    */   private final ObjectStreamClass objStreamClass;
/*    */ 
/*    */   private static void initialize()
/*    */   {
/* 39 */     if (newInstanceMethod == null)
/*    */       try {
/* 41 */         newInstanceMethod = ObjectStreamClass.class.getDeclaredMethod("newInstance", new Class[0]);
/* 42 */         newInstanceMethod.setAccessible(true);
/*    */       }
/*    */       catch (RuntimeException e) {
/* 45 */         throw new ObjenesisException(e);
/*    */       }
/*    */       catch (NoSuchMethodException e) {
/* 48 */         throw new ObjenesisException(e);
/*    */       }
/*    */   }
/*    */ 
/*    */   public ObjectStreamClassInstantiator(Class<T> type)
/*    */   {
/* 56 */     initialize();
/* 57 */     this.objStreamClass = ObjectStreamClass.lookup(type);
/*    */   }
/*    */ 
/*    */   public T newInstance()
/*    */   {
/*    */     try
/*    */     {
/* 64 */       return newInstanceMethod.invoke(this.objStreamClass, new Object[0]);
/*    */     }
/*    */     catch (Exception e) {
/* 67 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.basic.ObjectStreamClassInstantiator
 * JD-Core Version:    0.6.2
 */