/*    */ package org.springframework.objenesis.instantiator.gcj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.SerializationInstantiatorHelper;
/*    */ 
/*    */ public class GCJSerializationInstantiator<T> extends GCJInstantiatorBase<T>
/*    */ {
/*    */   private Class<? super T> superType;
/*    */ 
/*    */   public GCJSerializationInstantiator(Class<T> type)
/*    */   {
/* 33 */     super(type);
/* 34 */     this.superType = SerializationInstantiatorHelper.getNonSerializableSuperClass(type);
/*    */   }
/*    */ 
/*    */   public T newInstance()
/*    */   {
/*    */     try {
/* 40 */       return this.type.cast(newObjectMethod.invoke(dummyStream, new Object[] { this.type, this.superType }));
/*    */     }
/*    */     catch (Exception e) {
/* 43 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.gcj.GCJSerializationInstantiator
 * JD-Core Version:    0.6.2
 */