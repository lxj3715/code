/*    */ package org.springframework.objenesis.instantiator.jrockit;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class JRockitLegacyInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/* 32 */   private static Method safeAllocObjectMethod = null;
/*    */   private final Class<T> type;
/*    */ 
/*    */   private static void initialize()
/*    */   {
/* 35 */     if (safeAllocObjectMethod == null)
/*    */       try
/*    */       {
/* 38 */         Class memSystem = Class.forName("jrockit.vm.MemSystem");
/* 39 */         safeAllocObjectMethod = memSystem.getDeclaredMethod("safeAllocObject", new Class[] { Class.class });
/*    */ 
/* 41 */         safeAllocObjectMethod.setAccessible(true);
/*    */       }
/*    */       catch (RuntimeException e) {
/* 44 */         throw new ObjenesisException(e);
/*    */       }
/*    */       catch (ClassNotFoundException e) {
/* 47 */         throw new ObjenesisException(e);
/*    */       }
/*    */       catch (NoSuchMethodException e) {
/* 50 */         throw new ObjenesisException(e);
/*    */       }
/*    */   }
/*    */ 
/*    */   public JRockitLegacyInstantiator(Class<T> type)
/*    */   {
/* 58 */     initialize();
/* 59 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public T newInstance() {
/*    */     try {
/* 64 */       return this.type.cast(safeAllocObjectMethod.invoke(null, new Object[] { this.type }));
/*    */     }
/*    */     catch (Exception e) {
/* 67 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.jrockit.JRockitLegacyInstantiator
 * JD-Core Version:    0.6.2
 */