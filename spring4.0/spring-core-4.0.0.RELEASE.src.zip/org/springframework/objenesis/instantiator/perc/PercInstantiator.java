/*    */ package org.springframework.objenesis.instantiator.perc;
/*    */ 
/*    */ import java.io.ObjectInputStream;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class PercInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Method newInstanceMethod;
/* 36 */   private final Object[] typeArgs = { null, Boolean.FALSE };
/*    */ 
/*    */   public PercInstantiator(Class<T> type)
/*    */   {
/* 40 */     this.typeArgs[0] = type;
/*    */     try
/*    */     {
/* 43 */       this.newInstanceMethod = ObjectInputStream.class.getDeclaredMethod("newInstance", new Class[] { Class.class, Boolean.TYPE });
/*    */ 
/* 45 */       this.newInstanceMethod.setAccessible(true);
/*    */     }
/*    */     catch (RuntimeException e) {
/* 48 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 51 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public T newInstance()
/*    */   {
/*    */     try {
/* 58 */       return this.newInstanceMethod.invoke(null, this.typeArgs);
/*    */     } catch (Exception e) {
/* 60 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.perc.PercInstantiator
 * JD-Core Version:    0.6.2
 */