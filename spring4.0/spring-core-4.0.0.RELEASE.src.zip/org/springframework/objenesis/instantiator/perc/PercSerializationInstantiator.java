/*    */ package org.springframework.objenesis.instantiator.perc;
/*    */ 
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class PercSerializationInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private Object[] typeArgs;
/*    */   private final Method newInstanceMethod;
/*    */ 
/*    */   public PercSerializationInstantiator(Class<T> type)
/*    */   {
/* 44 */     Class unserializableType = type;
/*    */ 
/* 46 */     while (Serializable.class.isAssignableFrom(unserializableType)) {
/* 47 */       unserializableType = unserializableType.getSuperclass();
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 52 */       Class percMethodClass = Class.forName("COM.newmonics.PercClassLoader.Method");
/*    */ 
/* 54 */       this.newInstanceMethod = ObjectInputStream.class.getDeclaredMethod("noArgConstruct", new Class[] { Class.class, Object.class, percMethodClass });
/*    */ 
/* 56 */       this.newInstanceMethod.setAccessible(true);
/*    */ 
/* 59 */       Class percClassClass = Class.forName("COM.newmonics.PercClassLoader.PercClass");
/* 60 */       Method getPercClassMethod = percClassClass.getDeclaredMethod("getPercClass", new Class[] { Class.class });
/* 61 */       Object someObject = getPercClassMethod.invoke(null, new Object[] { unserializableType });
/* 62 */       Method findMethodMethod = someObject.getClass().getDeclaredMethod("findMethod", new Class[] { String.class });
/*    */ 
/* 64 */       Object percMethod = findMethodMethod.invoke(someObject, new Object[] { "<init>()V" });
/*    */ 
/* 66 */       this.typeArgs = new Object[] { unserializableType, type, percMethod };
/*    */     }
/*    */     catch (ClassNotFoundException e)
/*    */     {
/* 70 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 73 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 76 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 79 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public T newInstance()
/*    */   {
/*    */     try {
/* 86 */       return this.newInstanceMethod.invoke(null, this.typeArgs);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 89 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 92 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.perc.PercSerializationInstantiator
 * JD-Core Version:    0.6.2
 */