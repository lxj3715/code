/*    */ package org.springframework.objenesis.instantiator.sun;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ 
/*    */ class SunReflectionFactoryHelper
/*    */ {
/*    */   public static <T> Constructor<T> newConstructorForSerialization(Class<T> type, Constructor<?> constructor)
/*    */   {
/* 38 */     Class reflectionFactoryClass = getReflectionFactoryClass();
/* 39 */     Object reflectionFactory = createReflectionFactory(reflectionFactoryClass);
/*    */ 
/* 41 */     Method newConstructorForSerializationMethod = getNewConstructorForSerializationMethod(reflectionFactoryClass);
/*    */     try
/*    */     {
/* 45 */       return (Constructor)newConstructorForSerializationMethod.invoke(reflectionFactory, new Object[] { type, constructor });
/*    */     }
/*    */     catch (IllegalArgumentException e)
/*    */     {
/* 49 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 52 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 55 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static Class<?> getReflectionFactoryClass() {
/*    */     try {
/* 61 */       return Class.forName("sun.reflect.ReflectionFactory");
/*    */     }
/*    */     catch (ClassNotFoundException e) {
/* 64 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static Object createReflectionFactory(Class<?> reflectionFactoryClass) {
/*    */     try {
/* 70 */       Method method = reflectionFactoryClass.getDeclaredMethod("getReflectionFactory", new Class[0]);
/*    */ 
/* 72 */       return method.invoke(null, new Object[0]);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 75 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 78 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (IllegalArgumentException e) {
/* 81 */       throw new ObjenesisException(e);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 84 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static Method getNewConstructorForSerializationMethod(Class<?> reflectionFactoryClass) {
/*    */     try {
/* 90 */       return reflectionFactoryClass.getDeclaredMethod("newConstructorForSerialization", new Class[] { Class.class, Constructor.class });
/*    */     }
/*    */     catch (NoSuchMethodException e)
/*    */     {
/* 94 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.sun.SunReflectionFactoryHelper
 * JD-Core Version:    0.6.2
 */