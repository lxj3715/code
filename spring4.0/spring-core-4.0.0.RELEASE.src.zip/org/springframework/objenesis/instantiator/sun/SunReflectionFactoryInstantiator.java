/*    */ package org.springframework.objenesis.instantiator.sun;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class SunReflectionFactoryInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private final Constructor<T> mungedConstructor;
/*    */ 
/*    */   public SunReflectionFactoryInstantiator(Class<T> type)
/*    */   {
/* 37 */     Constructor javaLangObjectConstructor = getJavaLangObjectConstructor();
/* 38 */     this.mungedConstructor = SunReflectionFactoryHelper.newConstructorForSerialization(type, javaLangObjectConstructor);
/*    */ 
/* 40 */     this.mungedConstructor.setAccessible(true);
/*    */   }
/*    */ 
/*    */   public T newInstance() {
/*    */     try {
/* 45 */       return this.mungedConstructor.newInstance((Object[])null);
/*    */     }
/*    */     catch (Exception e) {
/* 48 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static Constructor<Object> getJavaLangObjectConstructor() {
/*    */     try {
/* 54 */       return Object.class.getConstructor((Class[])null);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/* 57 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.sun.SunReflectionFactoryInstantiator
 * JD-Core Version:    0.6.2
 */