/*    */ package org.springframework.objenesis.instantiator.sun;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ import sun.misc.Unsafe;
/*    */ 
/*    */ public class UnsafeFactoryInstantiator<T>
/*    */   implements ObjectInstantiator<T>
/*    */ {
/*    */   private static Unsafe unsafe;
/*    */   private final Class<T> type;
/*    */ 
/*    */   public UnsafeFactoryInstantiator(Class<T> type)
/*    */   {
/* 40 */     if (unsafe == null) {
/*    */       Field f;
/*    */       try {
/* 43 */         f = Unsafe.class.getDeclaredField("theUnsafe");
/*    */       } catch (NoSuchFieldException e) {
/* 45 */         throw new ObjenesisException(e);
/*    */       }
/* 47 */       f.setAccessible(true);
/*    */       try {
/* 49 */         unsafe = (Unsafe)f.get(null);
/*    */       } catch (IllegalAccessException e) {
/* 51 */         throw new ObjenesisException(e);
/*    */       }
/*    */     }
/* 54 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public T newInstance() {
/*    */     try {
/* 59 */       return this.type.cast(unsafe.allocateInstance(this.type));
/*    */     } catch (InstantiationException e) {
/* 61 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.instantiator.sun.UnsafeFactoryInstantiator
 * JD-Core Version:    0.6.2
 */