/*    */ package org.springframework.objenesis.strategy;
/*    */ 
/*    */ public abstract class BaseInstantiatorStrategy
/*    */   implements InstantiatorStrategy
/*    */ {
/*    */   protected static final String JROCKIT = "BEA";
/*    */   protected static final String GNU = "GNU libgcj";
/*    */   protected static final String SUN = "Java HotSpot";
/*    */   protected static final String PERC = "PERC";
/*    */   protected static final String DALVIK = "Dalvik";
/* 41 */   protected static final String VM_VERSION = PlatformDescription.VM_VERSION;
/*    */ 
/* 44 */   protected static final String VM_INFO = PlatformDescription.VM_INFO;
/*    */ 
/* 47 */   protected static final String VENDOR_VERSION = PlatformDescription.VENDOR_VERSION;
/*    */ 
/* 50 */   protected static final String VENDOR = PlatformDescription.VENDOR;
/*    */ 
/* 53 */   protected static final String JVM_NAME = PlatformDescription.JVM_NAME;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.strategy.BaseInstantiatorStrategy
 * JD-Core Version:    0.6.2
 */