package org.springframework.objenesis.strategy;

import org.springframework.objenesis.instantiator.ObjectInstantiator;

public abstract interface InstantiatorStrategy
{
  public abstract <T> ObjectInstantiator<T> newInstantiatorOf(Class<T> paramClass);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.strategy.InstantiatorStrategy
 * JD-Core Version:    0.6.2
 */