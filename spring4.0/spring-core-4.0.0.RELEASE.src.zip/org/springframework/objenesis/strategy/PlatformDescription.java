/*    */ package org.springframework.objenesis.strategy;
/*    */ 
/*    */ public final class PlatformDescription
/*    */ {
/*    */   public static final String JROCKIT = "BEA";
/*    */   public static final String GNU = "GNU libgcj";
/*    */   public static final String SUN = "Java HotSpot";
/*    */   public static final String PERC = "PERC";
/*    */   public static final String DALVIK = "Dalvik";
/* 41 */   public static final String SPECIFICATION_VERSION = System.getProperty("java.specification.version");
/*    */ 
/* 44 */   public static final String VM_VERSION = System.getProperty("java.runtime.version");
/*    */ 
/* 47 */   public static final String VM_INFO = System.getProperty("java.vm.info");
/*    */ 
/* 50 */   public static final String VENDOR_VERSION = System.getProperty("java.vm.version");
/*    */ 
/* 53 */   public static final String VENDOR = System.getProperty("java.vm.vendor");
/*    */ 
/* 56 */   public static final String JVM_NAME = System.getProperty("java.vm.name");
/*    */ 
/*    */   public static boolean isThisJVM(String name)
/*    */   {
/* 66 */     return JVM_NAME.startsWith(name);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.strategy.PlatformDescription
 * JD-Core Version:    0.6.2
 */