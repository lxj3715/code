/*    */ package org.springframework.objenesis.strategy;
/*    */ 
/*    */ import java.io.NotSerializableException;
/*    */ import java.io.Serializable;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ import org.springframework.objenesis.instantiator.android.AndroidSerializationInstantiator;
/*    */ import org.springframework.objenesis.instantiator.basic.ObjectStreamClassInstantiator;
/*    */ import org.springframework.objenesis.instantiator.gcj.GCJSerializationInstantiator;
/*    */ import org.springframework.objenesis.instantiator.perc.PercSerializationInstantiator;
/*    */ 
/*    */ public class SerializingInstantiatorStrategy extends BaseInstantiatorStrategy
/*    */ {
/*    */   public <T> ObjectInstantiator<T> newInstantiatorOf(Class<T> type)
/*    */   {
/* 53 */     if (!Serializable.class.isAssignableFrom(type)) {
/* 54 */       throw new ObjenesisException(new NotSerializableException(type + " not serializable"));
/*    */     }
/* 56 */     if (JVM_NAME.startsWith("Java HotSpot")) {
/* 57 */       return new ObjectStreamClassInstantiator(type);
/*    */     }
/* 59 */     if (JVM_NAME.startsWith("Dalvik")) {
/* 60 */       return new AndroidSerializationInstantiator(type);
/*    */     }
/* 62 */     if (JVM_NAME.startsWith("GNU libgcj")) {
/* 63 */       return new GCJSerializationInstantiator(type);
/*    */     }
/* 65 */     if (JVM_NAME.startsWith("PERC")) {
/* 66 */       return new PercSerializationInstantiator(type);
/*    */     }
/*    */ 
/* 69 */     return new ObjectStreamClassInstantiator(type);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.strategy.SerializingInstantiatorStrategy
 * JD-Core Version:    0.6.2
 */