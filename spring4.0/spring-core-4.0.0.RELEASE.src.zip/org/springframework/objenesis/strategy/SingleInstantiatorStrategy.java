/*    */ package org.springframework.objenesis.strategy;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import org.springframework.objenesis.ObjenesisException;
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ 
/*    */ public class SingleInstantiatorStrategy
/*    */   implements InstantiatorStrategy
/*    */ {
/*    */   private Constructor<?> constructor;
/*    */ 
/*    */   public SingleInstantiatorStrategy(Class<?> instantiator)
/*    */   {
/*    */     try
/*    */     {
/* 42 */       this.constructor = instantiator.getConstructor(new Class[] { Class.class });
/*    */     } catch (NoSuchMethodException e) {
/* 44 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public <T> ObjectInstantiator<T> newInstantiatorOf(Class<T> type)
/*    */   {
/*    */     try {
/* 51 */       return (ObjectInstantiator)this.constructor.newInstance(new Object[] { type });
/*    */     } catch (InstantiationException e) {
/* 53 */       throw new ObjenesisException(e);
/*    */     } catch (IllegalAccessException e) {
/* 55 */       throw new ObjenesisException(e);
/*    */     } catch (InvocationTargetException e) {
/* 57 */       throw new ObjenesisException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.strategy.SingleInstantiatorStrategy
 * JD-Core Version:    0.6.2
 */