/*    */ package org.springframework.objenesis.strategy;
/*    */ 
/*    */ import org.springframework.objenesis.instantiator.ObjectInstantiator;
/*    */ import org.springframework.objenesis.instantiator.android.Android23Instantiator;
/*    */ import org.springframework.objenesis.instantiator.android.Android30Instantiator;
/*    */ import org.springframework.objenesis.instantiator.gcj.GCJInstantiator;
/*    */ import org.springframework.objenesis.instantiator.jrockit.JRockitLegacyInstantiator;
/*    */ import org.springframework.objenesis.instantiator.perc.PercInstantiator;
/*    */ import org.springframework.objenesis.instantiator.sun.SunReflectionFactoryInstantiator;
/*    */ import org.springframework.objenesis.instantiator.sun.UnsafeFactoryInstantiator;
/*    */ 
/*    */ public class StdInstantiatorStrategy extends BaseInstantiatorStrategy
/*    */ {
/*    */   public <T> ObjectInstantiator<T> newInstantiatorOf(Class<T> type)
/*    */   {
/* 52 */     if (PlatformDescription.isThisJVM("Java HotSpot"))
/*    */     {
/* 55 */       return new SunReflectionFactoryInstantiator(type);
/*    */     }
/* 57 */     if (PlatformDescription.isThisJVM("BEA")) {
/* 58 */       if (VM_VERSION.startsWith("1.4"))
/*    */       {
/* 62 */         if (!VENDOR_VERSION.startsWith("R"))
/*    */         {
/* 65 */           if ((VM_INFO == null) || (!VM_INFO.startsWith("R25.1")) || (!VM_INFO.startsWith("R25.2"))) {
/* 66 */             return new JRockitLegacyInstantiator(type);
/*    */           }
/*    */         }
/*    */       }
/*    */ 
/* 71 */       return new SunReflectionFactoryInstantiator(type);
/*    */     }
/* 73 */     if (PlatformDescription.isThisJVM("Dalvik"))
/*    */     {
/* 76 */       if (VENDOR_VERSION.compareTo("1.5.0") < 0)
/*    */       {
/* 78 */         return new Android23Instantiator(type);
/*    */       }
/*    */ 
/* 81 */       return new Android30Instantiator(type);
/*    */     }
/*    */ 
/* 84 */     if (PlatformDescription.isThisJVM("GNU libgcj")) {
/* 85 */       return new GCJInstantiator(type);
/*    */     }
/* 87 */     if (PlatformDescription.isThisJVM("PERC")) {
/* 88 */       return new PercInstantiator(type);
/*    */     }
/*    */ 
/* 92 */     return new UnsafeFactoryInstantiator(type);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.objenesis.strategy.StdInstantiatorStrategy
 * JD-Core Version:    0.6.2
 */