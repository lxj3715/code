/*    */ package org.springframework.util;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ import java.security.SecureRandom;
/*    */ import java.util.Random;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class AlternativeJdkIdGenerator
/*    */   implements IdGenerator
/*    */ {
/*    */   private final Random random;
/*    */ 
/*    */   public AlternativeJdkIdGenerator()
/*    */   {
/* 39 */     byte[] seed = new SecureRandom().generateSeed(8);
/* 40 */     this.random = new Random(new BigInteger(seed).longValue());
/*    */   }
/*    */ 
/*    */   public UUID generateId()
/*    */   {
/* 46 */     byte[] randomBytes = new byte[16];
/* 47 */     this.random.nextBytes(randomBytes);
/*    */ 
/* 49 */     long mostSigBits = 0L;
/* 50 */     for (int i = 0; i < 8; i++) {
/* 51 */       mostSigBits = mostSigBits << 8 | randomBytes[i] & 0xFF;
/*    */     }
/*    */ 
/* 54 */     long leastSigBits = 0L;
/* 55 */     for (int i = 8; i < 16; i++) {
/* 56 */       leastSigBits = leastSigBits << 8 | randomBytes[i] & 0xFF;
/*    */     }
/*    */ 
/* 59 */     return new UUID(mostSigBits, leastSigBits);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.AlternativeJdkIdGenerator
 * JD-Core Version:    0.6.2
 */