/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class AntPathMatcher
/*     */   implements PathMatcher
/*     */ {
/*     */   private static final int CACHE_TURNOFF_THRESHOLD = 65536;
/*  55 */   private static final Pattern VARIABLE_PATTERN = Pattern.compile("\\{[^/]+?\\}");
/*     */   public static final String DEFAULT_PATH_SEPARATOR = "/";
/*     */   private String pathSeparator;
/*     */   private boolean trimTokens;
/*     */   private volatile Boolean cachePatterns;
/*     */   final Map<String, AntPathStringMatcher> stringMatcherCache;
/*     */ 
/*     */   public AntPathMatcher()
/*     */   {
/*  61 */     this.pathSeparator = "/";
/*     */ 
/*  63 */     this.trimTokens = true;
/*     */ 
/*  67 */     this.stringMatcherCache = new ConcurrentHashMap(256);
/*     */   }
/*     */ 
/*     */   public void setPathSeparator(String pathSeparator)
/*     */   {
/*  76 */     this.pathSeparator = (pathSeparator != null ? pathSeparator : "/");
/*     */   }
/*     */ 
/*     */   public void setTrimTokens(boolean trimTokens)
/*     */   {
/*  84 */     this.trimTokens = trimTokens;
/*     */   }
/*     */ 
/*     */   public void setCachePatterns(boolean cachePatterns)
/*     */   {
/*  99 */     this.cachePatterns = Boolean.valueOf(cachePatterns);
/*     */   }
/*     */ 
/*     */   public boolean isPattern(String path)
/*     */   {
/* 105 */     return (path.indexOf('*') != -1) || (path.indexOf('?') != -1);
/*     */   }
/*     */ 
/*     */   public boolean match(String pattern, String path)
/*     */   {
/* 110 */     return doMatch(pattern, path, true, null);
/*     */   }
/*     */ 
/*     */   public boolean matchStart(String pattern, String path)
/*     */   {
/* 115 */     return doMatch(pattern, path, false, null);
/*     */   }
/*     */ 
/*     */   protected boolean doMatch(String pattern, String path, boolean fullMatch, Map<String, String> uriTemplateVariables)
/*     */   {
/* 127 */     if (path.startsWith(this.pathSeparator) != pattern.startsWith(this.pathSeparator)) {
/* 128 */       return false;
/*     */     }
/*     */ 
/* 131 */     String[] pattDirs = StringUtils.tokenizeToStringArray(pattern, this.pathSeparator, this.trimTokens, true);
/* 132 */     String[] pathDirs = StringUtils.tokenizeToStringArray(path, this.pathSeparator, this.trimTokens, true);
/*     */ 
/* 134 */     int pattIdxStart = 0;
/* 135 */     int pattIdxEnd = pattDirs.length - 1;
/* 136 */     int pathIdxStart = 0;
/* 137 */     int pathIdxEnd = pathDirs.length - 1;
/*     */ 
/* 140 */     while ((pattIdxStart <= pattIdxEnd) && (pathIdxStart <= pathIdxEnd)) {
/* 141 */       String pattDir = pattDirs[pattIdxStart];
/* 142 */       if ("**".equals(pattDir)) {
/*     */         break;
/*     */       }
/* 145 */       if (!matchStrings(pattDir, pathDirs[pathIdxStart], uriTemplateVariables)) {
/* 146 */         return false;
/*     */       }
/* 148 */       pattIdxStart++;
/* 149 */       pathIdxStart++;
/*     */     }
/*     */ 
/* 152 */     if (pathIdxStart > pathIdxEnd)
/*     */     {
/* 154 */       if (pattIdxStart > pattIdxEnd)
/*     */       {
/* 156 */         return !path
/* 156 */           .endsWith(this.pathSeparator) ? 
/* 156 */           true : pattern.endsWith(this.pathSeparator) ? path.endsWith(this.pathSeparator) : 
/* 156 */           false;
/*     */       }
/* 158 */       if (!fullMatch) {
/* 159 */         return true;
/*     */       }
/* 161 */       if ((pattIdxStart == pattIdxEnd) && (pattDirs[pattIdxStart].equals("*")) && (path.endsWith(this.pathSeparator))) {
/* 162 */         return true;
/*     */       }
/* 164 */       for (int i = pattIdxStart; i <= pattIdxEnd; i++) {
/* 165 */         if (!pattDirs[i].equals("**")) {
/* 166 */           return false;
/*     */         }
/*     */       }
/* 169 */       return true;
/*     */     }
/* 171 */     if (pattIdxStart > pattIdxEnd)
/*     */     {
/* 173 */       return false;
/*     */     }
/* 175 */     if ((!fullMatch) && ("**".equals(pattDirs[pattIdxStart])))
/*     */     {
/* 177 */       return true;
/*     */     }
/*     */ 
/* 181 */     while ((pattIdxStart <= pattIdxEnd) && (pathIdxStart <= pathIdxEnd)) {
/* 182 */       String pattDir = pattDirs[pattIdxEnd];
/* 183 */       if (pattDir.equals("**")) {
/*     */         break;
/*     */       }
/* 186 */       if (!matchStrings(pattDir, pathDirs[pathIdxEnd], uriTemplateVariables)) {
/* 187 */         return false;
/*     */       }
/* 189 */       pattIdxEnd--;
/* 190 */       pathIdxEnd--;
/*     */     }
/* 192 */     if (pathIdxStart > pathIdxEnd)
/*     */     {
/* 194 */       for (int i = pattIdxStart; i <= pattIdxEnd; i++) {
/* 195 */         if (!pattDirs[i].equals("**")) {
/* 196 */           return false;
/*     */         }
/*     */       }
/* 199 */       return true;
/*     */     }
/*     */ 
/* 202 */     while ((pattIdxStart != pattIdxEnd) && (pathIdxStart <= pathIdxEnd)) {
/* 203 */       int patIdxTmp = -1;
/* 204 */       for (int i = pattIdxStart + 1; i <= pattIdxEnd; i++) {
/* 205 */         if (pattDirs[i].equals("**")) {
/* 206 */           patIdxTmp = i;
/* 207 */           break;
/*     */         }
/*     */       }
/* 210 */       if (patIdxTmp == pattIdxStart + 1)
/*     */       {
/* 212 */         pattIdxStart++;
/*     */       }
/*     */       else
/*     */       {
/* 217 */         int patLength = patIdxTmp - pattIdxStart - 1;
/* 218 */         int strLength = pathIdxEnd - pathIdxStart + 1;
/* 219 */         int foundIdx = -1;
/*     */ 
/* 222 */         label560: for (int i = 0; i <= strLength - patLength; i++) {
/* 223 */           for (int j = 0; j < patLength; j++) {
/* 224 */             String subPat = pattDirs[(pattIdxStart + j + 1)];
/* 225 */             String subStr = pathDirs[(pathIdxStart + i + j)];
/* 226 */             if (!matchStrings(subPat, subStr, uriTemplateVariables)) {
/*     */               break label560;
/*     */             }
/*     */           }
/* 230 */           foundIdx = pathIdxStart + i;
/* 231 */           break;
/*     */         }
/*     */ 
/* 234 */         if (foundIdx == -1) {
/* 235 */           return false;
/*     */         }
/*     */ 
/* 238 */         pattIdxStart = patIdxTmp;
/* 239 */         pathIdxStart = foundIdx + patLength;
/*     */       }
/*     */     }
/* 242 */     for (int i = pattIdxStart; i <= pattIdxEnd; i++) {
/* 243 */       if (!pattDirs[i].equals("**")) {
/* 244 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 248 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean matchStrings(String pattern, String str, Map<String, String> uriTemplateVariables)
/*     */   {
/* 258 */     return getStringMatcher(pattern).matchStrings(str, uriTemplateVariables);
/*     */   }
/*     */ 
/*     */   protected AntPathStringMatcher getStringMatcher(String pattern)
/*     */   {
/* 275 */     AntPathStringMatcher matcher = null;
/* 276 */     Boolean cachePatterns = this.cachePatterns;
/* 277 */     if ((cachePatterns == null) || (cachePatterns.booleanValue())) {
/* 278 */       matcher = (AntPathStringMatcher)this.stringMatcherCache.get(pattern);
/*     */     }
/* 280 */     if (matcher == null) {
/* 281 */       matcher = new AntPathStringMatcher(pattern);
/* 282 */       if ((cachePatterns == null) && (this.stringMatcherCache.size() >= 65536))
/*     */       {
/* 286 */         this.cachePatterns = Boolean.valueOf(false);
/* 287 */         this.stringMatcherCache.clear();
/* 288 */         return matcher;
/*     */       }
/* 290 */       if ((cachePatterns == null) || (cachePatterns.booleanValue())) {
/* 291 */         this.stringMatcherCache.put(pattern, matcher);
/*     */       }
/*     */     }
/* 294 */     return matcher;
/*     */   }
/*     */ 
/*     */   public String extractPathWithinPattern(String pattern, String path)
/*     */   {
/* 312 */     String[] patternParts = StringUtils.tokenizeToStringArray(pattern, this.pathSeparator, this.trimTokens, true);
/* 313 */     String[] pathParts = StringUtils.tokenizeToStringArray(path, this.pathSeparator, this.trimTokens, true);
/*     */ 
/* 315 */     StringBuilder builder = new StringBuilder();
/*     */ 
/* 318 */     int puts = 0;
/* 319 */     for (int i = 0; i < patternParts.length; i++) {
/* 320 */       String patternPart = patternParts[i];
/* 321 */       if (((patternPart.indexOf('*') > -1) || (patternPart.indexOf('?') > -1)) && (pathParts.length >= i + 1)) {
/* 322 */         if ((puts > 0) || ((i == 0) && (!pattern.startsWith(this.pathSeparator)))) {
/* 323 */           builder.append(this.pathSeparator);
/*     */         }
/* 325 */         builder.append(pathParts[i]);
/* 326 */         puts++;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 331 */     for (int i = patternParts.length; i < pathParts.length; i++) {
/* 332 */       if ((puts > 0) || (i > 0)) {
/* 333 */         builder.append(this.pathSeparator);
/*     */       }
/* 335 */       builder.append(pathParts[i]);
/*     */     }
/*     */ 
/* 338 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public Map<String, String> extractUriTemplateVariables(String pattern, String path)
/*     */   {
/* 343 */     Map variables = new LinkedHashMap();
/* 344 */     boolean result = doMatch(pattern, path, true, variables);
/* 345 */     Assert.state(result, new StringBuilder().append("Pattern \"").append(pattern).append("\" is not a match for \"").append(path).append("\"").toString());
/* 346 */     return variables;
/*     */   }
/*     */ 
/*     */   public String combine(String pattern1, String pattern2)
/*     */   {
/* 370 */     if ((!StringUtils.hasText(pattern1)) && (!StringUtils.hasText(pattern2))) {
/* 371 */       return "";
/*     */     }
/* 373 */     if (!StringUtils.hasText(pattern1)) {
/* 374 */       return pattern2;
/*     */     }
/* 376 */     if (!StringUtils.hasText(pattern2)) {
/* 377 */       return pattern1;
/*     */     }
/*     */ 
/* 380 */     boolean pattern1ContainsUriVar = pattern1.indexOf('{') != -1;
/* 381 */     if ((!pattern1.equals(pattern2)) && (!pattern1ContainsUriVar) && (match(pattern1, pattern2)))
/*     */     {
/* 384 */       return pattern2;
/*     */     }
/*     */ 
/* 389 */     if (pattern1.endsWith("/*")) {
/* 390 */       return slashConcat(pattern1.substring(0, pattern1.length() - 2), pattern2);
/*     */     }
/*     */ 
/* 395 */     if (pattern1.endsWith("/**")) {
/* 396 */       return slashConcat(pattern1, pattern2);
/*     */     }
/*     */ 
/* 399 */     int starDotPos1 = pattern1.indexOf("*.");
/* 400 */     if ((pattern1ContainsUriVar) || (starDotPos1 == -1))
/*     */     {
/* 402 */       return slashConcat(pattern1, pattern2);
/*     */     }
/* 404 */     String extension1 = pattern1.substring(starDotPos1 + 1);
/* 405 */     int dotPos2 = pattern2.indexOf('.');
/* 406 */     String fileName2 = dotPos2 == -1 ? pattern2 : pattern2.substring(0, dotPos2);
/* 407 */     String extension2 = dotPos2 == -1 ? "" : pattern2.substring(dotPos2);
/* 408 */     String extension = extension1.startsWith("*") ? extension2 : extension1;
/* 409 */     return new StringBuilder().append(fileName2).append(extension).toString();
/*     */   }
/*     */ 
/*     */   private String slashConcat(String path1, String path2) {
/* 413 */     if ((path1.endsWith("/")) || (path2.startsWith("/"))) {
/* 414 */       return new StringBuilder().append(path1).append(path2).toString();
/*     */     }
/* 416 */     return new StringBuilder().append(path1).append("/").append(path2).toString();
/*     */   }
/*     */ 
/*     */   public Comparator<String> getPatternComparator(String path)
/*     */   {
/* 433 */     return new AntPatternComparator(path);
/*     */   }
/*     */ 
/*     */   protected static class AntPatternComparator
/*     */     implements Comparator<String>
/*     */   {
/*     */     private final String path;
/*     */ 
/*     */     public AntPatternComparator(String path)
/*     */     {
/* 530 */       this.path = path;
/*     */     }
/*     */ 
/*     */     public int compare(String pattern1, String pattern2)
/*     */     {
/* 535 */       if ((isNullOrCaptureAllPattern(pattern1)) && (isNullOrCaptureAllPattern(pattern2))) {
/* 536 */         return 0;
/*     */       }
/* 538 */       if (isNullOrCaptureAllPattern(pattern1)) {
/* 539 */         return 1;
/*     */       }
/* 541 */       if (isNullOrCaptureAllPattern(pattern2)) {
/* 542 */         return -1;
/*     */       }
/*     */ 
/* 545 */       boolean pattern1EqualsPath = pattern1.equals(this.path);
/* 546 */       boolean pattern2EqualsPath = pattern2.equals(this.path);
/* 547 */       if ((pattern1EqualsPath) && (pattern2EqualsPath)) {
/* 548 */         return 0;
/*     */       }
/* 550 */       if (pattern1EqualsPath) {
/* 551 */         return -1;
/*     */       }
/* 553 */       if (pattern2EqualsPath) {
/* 554 */         return 1;
/*     */       }
/*     */ 
/* 557 */       int wildCardCount1 = getWildCardCount(pattern1);
/* 558 */       int wildCardCount2 = getWildCardCount(pattern2);
/*     */ 
/* 560 */       int bracketCount1 = StringUtils.countOccurrencesOf(pattern1, "{");
/* 561 */       int bracketCount2 = StringUtils.countOccurrencesOf(pattern2, "{");
/*     */ 
/* 563 */       int totalCount1 = wildCardCount1 + bracketCount1;
/* 564 */       int totalCount2 = wildCardCount2 + bracketCount2;
/*     */ 
/* 566 */       if (totalCount1 != totalCount2) {
/* 567 */         return totalCount1 - totalCount2;
/*     */       }
/*     */ 
/* 570 */       int pattern1Length = getPatternLength(pattern1);
/* 571 */       int pattern2Length = getPatternLength(pattern2);
/*     */ 
/* 573 */       if (pattern1Length != pattern2Length) {
/* 574 */         return pattern2Length - pattern1Length;
/*     */       }
/*     */ 
/* 577 */       if (wildCardCount1 < wildCardCount2) {
/* 578 */         return -1;
/*     */       }
/* 580 */       if (wildCardCount2 < wildCardCount1) {
/* 581 */         return 1;
/*     */       }
/*     */ 
/* 584 */       if (bracketCount1 < bracketCount2) {
/* 585 */         return -1;
/*     */       }
/* 587 */       if (bracketCount2 < bracketCount1) {
/* 588 */         return 1;
/*     */       }
/*     */ 
/* 591 */       return 0;
/*     */     }
/*     */ 
/*     */     private boolean isNullOrCaptureAllPattern(String pattern) {
/* 595 */       return (pattern == null) || ("/**".equals(pattern));
/*     */     }
/*     */ 
/*     */     private int getWildCardCount(String pattern) {
/* 599 */       if (pattern.endsWith(".*")) {
/* 600 */         pattern = pattern.substring(0, pattern.length() - 2);
/*     */       }
/* 602 */       return StringUtils.countOccurrencesOf(pattern, "*");
/*     */     }
/*     */ 
/*     */     private int getPatternLength(String pattern)
/*     */     {
/* 609 */       return AntPathMatcher.VARIABLE_PATTERN.matcher(pattern).replaceAll("#").length();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class AntPathStringMatcher
/*     */   {
/* 444 */     private static final Pattern GLOB_PATTERN = Pattern.compile("\\?|\\*|\\{((?:\\{[^/]+?\\}|[^/{}]|\\\\[{}])+?)\\}");
/*     */     private static final String DEFAULT_VARIABLE_PATTERN = "(.*)";
/*     */     private final Pattern pattern;
/* 450 */     private final List<String> variableNames = new LinkedList();
/*     */ 
/*     */     public AntPathStringMatcher(String pattern) {
/* 453 */       StringBuilder patternBuilder = new StringBuilder();
/* 454 */       Matcher m = GLOB_PATTERN.matcher(pattern);
/* 455 */       int end = 0;
/* 456 */       while (m.find()) {
/* 457 */         patternBuilder.append(quote(pattern, end, m.start()));
/* 458 */         String match = m.group();
/* 459 */         if ("?".equals(match)) {
/* 460 */           patternBuilder.append('.');
/*     */         }
/* 462 */         else if ("*".equals(match)) {
/* 463 */           patternBuilder.append(".*");
/*     */         }
/* 465 */         else if ((match.startsWith("{")) && (match.endsWith("}"))) {
/* 466 */           int colonIdx = match.indexOf(58);
/* 467 */           if (colonIdx == -1) {
/* 468 */             patternBuilder.append("(.*)");
/* 469 */             this.variableNames.add(m.group(1));
/*     */           }
/*     */           else {
/* 472 */             String variablePattern = match.substring(colonIdx + 1, match.length() - 1);
/* 473 */             patternBuilder.append('(');
/* 474 */             patternBuilder.append(variablePattern);
/* 475 */             patternBuilder.append(')');
/* 476 */             String variableName = match.substring(1, colonIdx);
/* 477 */             this.variableNames.add(variableName);
/*     */           }
/*     */         }
/* 480 */         end = m.end();
/*     */       }
/* 482 */       patternBuilder.append(quote(pattern, end, pattern.length()));
/* 483 */       this.pattern = Pattern.compile(patternBuilder.toString());
/*     */     }
/*     */ 
/*     */     private String quote(String s, int start, int end) {
/* 487 */       if (start == end) {
/* 488 */         return "";
/*     */       }
/* 490 */       return Pattern.quote(s.substring(start, end));
/*     */     }
/*     */ 
/*     */     public boolean matchStrings(String str, Map<String, String> uriTemplateVariables)
/*     */     {
/* 498 */       Matcher matcher = this.pattern.matcher(str);
/* 499 */       if (matcher.matches()) {
/* 500 */         if (uriTemplateVariables != null)
/*     */         {
/* 502 */           Assert.isTrue(this.variableNames.size() == matcher.groupCount(), new StringBuilder().append("The number of capturing groups in the pattern segment ").append(this.pattern).append(" does not match the number of URI template variables it defines, which can occur if ").append(" capturing groups are used in a URI template regex. Use non-capturing groups instead.").toString());
/*     */ 
/* 506 */           for (int i = 1; i <= matcher.groupCount(); i++) {
/* 507 */             String name = (String)this.variableNames.get(i - 1);
/* 508 */             String value = matcher.group(i);
/* 509 */             uriTemplateVariables.put(name, value);
/*     */           }
/*     */         }
/* 512 */         return true;
/*     */       }
/*     */ 
/* 515 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.AntPathMatcher
 * JD-Core Version:    0.6.2
 */