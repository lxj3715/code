/*      */ package org.springframework.util;
/*      */ 
/*      */ import java.beans.Introspector;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.security.AccessControlException;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ 
/*      */ public abstract class ClassUtils
/*      */ {
/*      */   public static final String ARRAY_SUFFIX = "[]";
/*      */   private static final String INTERNAL_ARRAY_PREFIX = "[";
/*      */   private static final String NON_PRIMITIVE_ARRAY_PREFIX = "[L";
/*      */   private static final char PACKAGE_SEPARATOR = '.';
/*      */   private static final char INNER_CLASS_SEPARATOR = '$';
/*      */   public static final String CGLIB_CLASS_SEPARATOR = "$$";
/*      */   public static final String CLASS_FILE_SUFFIX = ".class";
/*   78 */   private static final Map<Class<?>, Class<?>> primitiveWrapperTypeMap = new HashMap(8);
/*      */ 
/*   84 */   private static final Map<Class<?>, Class<?>> primitiveTypeToWrapperMap = new HashMap(8);
/*      */ 
/*   90 */   private static final Map<String, Class<?>> primitiveTypeNameMap = new HashMap(32);
/*      */ 
/*   96 */   private static final Map<String, Class<?>> commonClassCache = new HashMap(32);
/*      */ 
/*      */   private static void registerCommonClasses(Class<?>[] commonClasses)
/*      */   {
/*  137 */     for (Class clazz : commonClasses)
/*  138 */       commonClassCache.put(clazz.getName(), clazz);
/*      */   }
/*      */ 
/*      */   public static ClassLoader getDefaultClassLoader()
/*      */   {
/*  155 */     ClassLoader cl = null;
/*      */     try {
/*  157 */       cl = Thread.currentThread().getContextClassLoader();
/*      */     }
/*      */     catch (Throwable ex)
/*      */     {
/*      */     }
/*  162 */     if (cl == null)
/*      */     {
/*  164 */       cl = ClassUtils.class.getClassLoader();
/*      */     }
/*  166 */     return cl;
/*      */   }
/*      */ 
/*      */   public static ClassLoader overrideThreadContextClassLoader(ClassLoader classLoaderToUse)
/*      */   {
/*  177 */     Thread currentThread = Thread.currentThread();
/*  178 */     ClassLoader threadContextClassLoader = currentThread.getContextClassLoader();
/*  179 */     if ((classLoaderToUse != null) && (!classLoaderToUse.equals(threadContextClassLoader))) {
/*  180 */       currentThread.setContextClassLoader(classLoaderToUse);
/*  181 */       return threadContextClassLoader;
/*      */     }
/*      */ 
/*  184 */     return null;
/*      */   }
/*      */ 
/*      */   public static Class<?> forName(String name, ClassLoader classLoader)
/*      */     throws ClassNotFoundException, LinkageError
/*      */   {
/*  202 */     Assert.notNull(name, "Name must not be null");
/*      */ 
/*  204 */     Class clazz = resolvePrimitiveClassName(name);
/*  205 */     if (clazz == null) {
/*  206 */       clazz = (Class)commonClassCache.get(name);
/*      */     }
/*  208 */     if (clazz != null) {
/*  209 */       return clazz;
/*      */     }
/*      */ 
/*  213 */     if (name.endsWith("[]")) {
/*  214 */       String elementClassName = name.substring(0, name.length() - "[]".length());
/*  215 */       Class elementClass = forName(elementClassName, classLoader);
/*  216 */       return Array.newInstance(elementClass, 0).getClass();
/*      */     }
/*      */ 
/*  220 */     if ((name.startsWith("[L")) && (name.endsWith(";"))) {
/*  221 */       String elementName = name.substring("[L".length(), name.length() - 1);
/*  222 */       Class elementClass = forName(elementName, classLoader);
/*  223 */       return Array.newInstance(elementClass, 0).getClass();
/*      */     }
/*      */ 
/*  227 */     if (name.startsWith("[")) {
/*  228 */       String elementName = name.substring("[".length());
/*  229 */       Class elementClass = forName(elementName, classLoader);
/*  230 */       return Array.newInstance(elementClass, 0).getClass();
/*      */     }
/*      */ 
/*  233 */     ClassLoader classLoaderToUse = classLoader;
/*  234 */     if (classLoaderToUse == null)
/*  235 */       classLoaderToUse = getDefaultClassLoader();
/*      */     try
/*      */     {
/*  238 */       return classLoaderToUse.loadClass(name);
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/*  241 */       int lastDotIndex = name.lastIndexOf(46);
/*  242 */       if (lastDotIndex != -1) {
/*  243 */         String innerClassName = new StringBuilder().append(name.substring(0, lastDotIndex)).append('$').append(name.substring(lastDotIndex + 1)).toString();
/*      */         try {
/*  245 */           return classLoaderToUse.loadClass(innerClassName);
/*      */         }
/*      */         catch (ClassNotFoundException ex2)
/*      */         {
/*      */         }
/*      */       }
/*  251 */       throw ex;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static Class<?> resolveClassName(String className, ClassLoader classLoader)
/*      */     throws IllegalArgumentException
/*      */   {
/*      */     try
/*      */     {
/*  271 */       return forName(className, classLoader);
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/*  274 */       throw new IllegalArgumentException(new StringBuilder().append("Cannot find class [").append(className).append("]").toString(), ex);
/*      */     }
/*      */     catch (LinkageError ex) {
/*  277 */       throw new IllegalArgumentException(new StringBuilder().append("Error loading class [").append(className).append("]: problem with class file or dependent class.").toString(), ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static Class<?> resolvePrimitiveClassName(String name)
/*      */   {
/*  293 */     Class result = null;
/*      */ 
/*  296 */     if ((name != null) && (name.length() <= 8))
/*      */     {
/*  298 */       result = (Class)primitiveTypeNameMap.get(name);
/*      */     }
/*  300 */     return result;
/*      */   }
/*      */ 
/*      */   public static boolean isPresent(String className, ClassLoader classLoader)
/*      */   {
/*      */     try
/*      */     {
/*  314 */       forName(className, classLoader);
/*  315 */       return true;
/*      */     }
/*      */     catch (Throwable ex) {
/*      */     }
/*  319 */     return false;
/*      */   }
/*      */ 
/*      */   public static Class<?> getUserClass(Object instance)
/*      */   {
/*  331 */     Assert.notNull(instance, "Instance must not be null");
/*  332 */     return getUserClass(instance.getClass());
/*      */   }
/*      */ 
/*      */   public static Class<?> getUserClass(Class<?> clazz)
/*      */   {
/*  342 */     if ((clazz != null) && (clazz.getName().contains("$$"))) {
/*  343 */       Class superClass = clazz.getSuperclass();
/*  344 */       if ((superClass != null) && (!Object.class.equals(superClass))) {
/*  345 */         return superClass;
/*      */       }
/*      */     }
/*  348 */     return clazz;
/*      */   }
/*      */ 
/*      */   public static boolean isCacheSafe(Class<?> clazz, ClassLoader classLoader)
/*      */   {
/*  358 */     Assert.notNull(clazz, "Class must not be null");
/*  359 */     ClassLoader target = clazz.getClassLoader();
/*  360 */     if (target == null) {
/*  361 */       return false;
/*      */     }
/*  363 */     ClassLoader cur = classLoader;
/*  364 */     if (cur == target) {
/*  365 */       return true;
/*      */     }
/*  367 */     while (cur != null) {
/*  368 */       cur = cur.getParent();
/*  369 */       if (cur == target) {
/*  370 */         return true;
/*      */       }
/*      */     }
/*  373 */     return false;
/*      */   }
/*      */ 
/*      */   public static String getShortName(String className)
/*      */   {
/*  384 */     Assert.hasLength(className, "Class name must not be empty");
/*  385 */     int lastDotIndex = className.lastIndexOf(46);
/*  386 */     int nameEndIndex = className.indexOf("$$");
/*  387 */     if (nameEndIndex == -1) {
/*  388 */       nameEndIndex = className.length();
/*      */     }
/*  390 */     String shortName = className.substring(lastDotIndex + 1, nameEndIndex);
/*  391 */     shortName = shortName.replace('$', '.');
/*  392 */     return shortName;
/*      */   }
/*      */ 
/*      */   public static String getShortName(Class<?> clazz)
/*      */   {
/*  401 */     return getShortName(getQualifiedName(clazz));
/*      */   }
/*      */ 
/*      */   public static String getShortNameAsProperty(Class<?> clazz)
/*      */   {
/*  412 */     String shortName = getShortName(clazz);
/*  413 */     int dotIndex = shortName.lastIndexOf(46);
/*  414 */     shortName = dotIndex != -1 ? shortName.substring(dotIndex + 1) : shortName;
/*  415 */     return Introspector.decapitalize(shortName);
/*      */   }
/*      */ 
/*      */   public static String getClassFileName(Class<?> clazz)
/*      */   {
/*  425 */     Assert.notNull(clazz, "Class must not be null");
/*  426 */     String className = clazz.getName();
/*  427 */     int lastDotIndex = className.lastIndexOf(46);
/*  428 */     return new StringBuilder().append(className.substring(lastDotIndex + 1)).append(".class").toString();
/*      */   }
/*      */ 
/*      */   public static String getPackageName(Class<?> clazz)
/*      */   {
/*  439 */     Assert.notNull(clazz, "Class must not be null");
/*  440 */     return getPackageName(clazz.getName());
/*      */   }
/*      */ 
/*      */   public static String getPackageName(String fqClassName)
/*      */   {
/*  451 */     Assert.notNull(fqClassName, "Class name must not be null");
/*  452 */     int lastDotIndex = fqClassName.lastIndexOf(46);
/*  453 */     return lastDotIndex != -1 ? fqClassName.substring(0, lastDotIndex) : "";
/*      */   }
/*      */ 
/*      */   public static String getQualifiedName(Class<?> clazz)
/*      */   {
/*  463 */     Assert.notNull(clazz, "Class must not be null");
/*  464 */     if (clazz.isArray()) {
/*  465 */       return getQualifiedNameForArray(clazz);
/*      */     }
/*      */ 
/*  468 */     return clazz.getName();
/*      */   }
/*      */ 
/*      */   private static String getQualifiedNameForArray(Class<?> clazz)
/*      */   {
/*  479 */     StringBuilder result = new StringBuilder();
/*  480 */     while (clazz.isArray()) {
/*  481 */       clazz = clazz.getComponentType();
/*  482 */       result.append("[]");
/*      */     }
/*  484 */     result.insert(0, clazz.getName());
/*  485 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getQualifiedMethodName(Method method)
/*      */   {
/*  495 */     Assert.notNull(method, "Method must not be null");
/*  496 */     return new StringBuilder().append(method.getDeclaringClass().getName()).append(".").append(method.getName()).toString();
/*      */   }
/*      */ 
/*      */   public static String getDescriptiveType(Object value)
/*      */   {
/*  507 */     if (value == null) {
/*  508 */       return null;
/*      */     }
/*  510 */     Class clazz = value.getClass();
/*  511 */     if (Proxy.isProxyClass(clazz)) {
/*  512 */       StringBuilder result = new StringBuilder(clazz.getName());
/*  513 */       result.append(" implementing ");
/*  514 */       Class[] ifcs = clazz.getInterfaces();
/*  515 */       for (int i = 0; i < ifcs.length; i++) {
/*  516 */         result.append(ifcs[i].getName());
/*  517 */         if (i < ifcs.length - 1) {
/*  518 */           result.append(',');
/*      */         }
/*      */       }
/*  521 */       return result.toString();
/*      */     }
/*  523 */     if (clazz.isArray()) {
/*  524 */       return getQualifiedNameForArray(clazz);
/*      */     }
/*      */ 
/*  527 */     return clazz.getName();
/*      */   }
/*      */ 
/*      */   public static boolean matchesTypeName(Class<?> clazz, String typeName)
/*      */   {
/*  539 */     return (typeName != null) && (
/*  538 */       (typeName
/*  538 */       .equals(clazz
/*  538 */       .getName())) || (typeName.equals(clazz.getSimpleName())) || (
/*  539 */       (clazz
/*  539 */       .isArray()) && (typeName.equals(getQualifiedNameForArray(clazz)))));
/*      */   }
/*      */ 
/*      */   public static boolean hasConstructor(Class<?> clazz, Class<?>[] paramTypes)
/*      */   {
/*  552 */     return getConstructorIfAvailable(clazz, paramTypes) != null;
/*      */   }
/*      */ 
/*      */   public static <T> Constructor<T> getConstructorIfAvailable(Class<T> clazz, Class<?>[] paramTypes)
/*      */   {
/*  565 */     Assert.notNull(clazz, "Class must not be null");
/*      */     try {
/*  567 */       return clazz.getConstructor(paramTypes);
/*      */     } catch (NoSuchMethodException ex) {
/*      */     }
/*  570 */     return null;
/*      */   }
/*      */ 
/*      */   public static boolean hasMethod(Class<?> clazz, String methodName, Class<?>[] paramTypes)
/*      */   {
/*  584 */     return getMethodIfAvailable(clazz, methodName, paramTypes) != null;
/*      */   }
/*      */ 
/*      */   public static Method getMethod(Class<?> clazz, String methodName, Class<?>[] paramTypes)
/*      */   {
/*  602 */     Assert.notNull(clazz, "Class must not be null");
/*  603 */     Assert.notNull(methodName, "Method name must not be null");
/*  604 */     if (paramTypes != null) {
/*      */       try {
/*  606 */         return clazz.getMethod(methodName, paramTypes);
/*      */       }
/*      */       catch (NoSuchMethodException ex) {
/*  609 */         throw new IllegalStateException(new StringBuilder().append("Expected method not found: ").append(ex).toString());
/*      */       }
/*      */     }
/*      */ 
/*  613 */     Set candidates = new HashSet(1);
/*  614 */     Method[] methods = clazz.getMethods();
/*  615 */     for (Method method : methods) {
/*  616 */       if (methodName.equals(method.getName())) {
/*  617 */         candidates.add(method);
/*      */       }
/*      */     }
/*  620 */     if (candidates.size() == 1) {
/*  621 */       return (Method)candidates.iterator().next();
/*      */     }
/*  623 */     if (candidates.isEmpty()) {
/*  624 */       throw new IllegalStateException(new StringBuilder().append("Expected method not found: ").append(clazz).append(".").append(methodName).toString());
/*      */     }
/*      */ 
/*  627 */     throw new IllegalStateException(new StringBuilder().append("No unique method found: ").append(clazz).append(".").append(methodName).toString());
/*      */   }
/*      */ 
/*      */   public static Method getMethodIfAvailable(Class<?> clazz, String methodName, Class<?>[] paramTypes)
/*      */   {
/*  646 */     Assert.notNull(clazz, "Class must not be null");
/*  647 */     Assert.notNull(methodName, "Method name must not be null");
/*  648 */     if (paramTypes != null) {
/*      */       try {
/*  650 */         return clazz.getMethod(methodName, paramTypes);
/*      */       }
/*      */       catch (NoSuchMethodException ex) {
/*  653 */         return null;
/*      */       }
/*      */     }
/*      */ 
/*  657 */     Set candidates = new HashSet(1);
/*  658 */     Method[] methods = clazz.getMethods();
/*  659 */     for (Method method : methods) {
/*  660 */       if (methodName.equals(method.getName())) {
/*  661 */         candidates.add(method);
/*      */       }
/*      */     }
/*  664 */     if (candidates.size() == 1) {
/*  665 */       return (Method)candidates.iterator().next();
/*      */     }
/*  667 */     return null;
/*      */   }
/*      */ 
/*      */   public static int getMethodCountForName(Class<?> clazz, String methodName)
/*      */   {
/*  679 */     Assert.notNull(clazz, "Class must not be null");
/*  680 */     Assert.notNull(methodName, "Method name must not be null");
/*  681 */     int count = 0;
/*  682 */     Method[] declaredMethods = clazz.getDeclaredMethods();
/*  683 */     Method[] arrayOfMethod1 = declaredMethods; int i = arrayOfMethod1.length; for (Method localMethod1 = 0; localMethod1 < i; localMethod1++) { method = arrayOfMethod1[localMethod1];
/*  684 */       if (methodName.equals(method.getName())) {
/*  685 */         count++;
/*      */       }
/*      */     }
/*  688 */     Class[] ifcs = clazz.getInterfaces();
/*  689 */     Class[] arrayOfClass1 = ifcs; localMethod1 = arrayOfClass1.length; for (Method method = 0; method < localMethod1; method++) { Class ifc = arrayOfClass1[method];
/*  690 */       count += getMethodCountForName(ifc, methodName);
/*      */     }
/*  692 */     if (clazz.getSuperclass() != null) {
/*  693 */       count += getMethodCountForName(clazz.getSuperclass(), methodName);
/*      */     }
/*  695 */     return count;
/*      */   }
/*      */ 
/*      */   public static boolean hasAtLeastOneMethodWithName(Class<?> clazz, String methodName)
/*      */   {
/*  707 */     Assert.notNull(clazz, "Class must not be null");
/*  708 */     Assert.notNull(methodName, "Method name must not be null");
/*  709 */     Method[] declaredMethods = clazz.getDeclaredMethods();
/*  710 */     Method[] arrayOfMethod1 = declaredMethods; int i = arrayOfMethod1.length; for (Method localMethod1 = 0; localMethod1 < i; localMethod1++) { method = arrayOfMethod1[localMethod1];
/*  711 */       if (method.getName().equals(methodName)) {
/*  712 */         return true;
/*      */       }
/*      */     }
/*  715 */     Class[] ifcs = clazz.getInterfaces();
/*  716 */     Class[] arrayOfClass1 = ifcs; localMethod1 = arrayOfClass1.length; for (Method method = 0; method < localMethod1; method++) { Class ifc = arrayOfClass1[method];
/*  717 */       if (hasAtLeastOneMethodWithName(ifc, methodName)) {
/*  718 */         return true;
/*      */       }
/*      */     }
/*  721 */     return (clazz.getSuperclass() != null) && (hasAtLeastOneMethodWithName(clazz.getSuperclass(), methodName));
/*      */   }
/*      */ 
/*      */   public static Method getMostSpecificMethod(Method method, Class<?> targetClass)
/*      */   {
/*  745 */     if ((method != null) && (isOverridable(method, targetClass)) && (targetClass != null) && 
/*  746 */       (!targetClass
/*  746 */       .equals(method
/*  746 */       .getDeclaringClass()))) {
/*      */       try {
/*  748 */         if (Modifier.isPublic(method.getModifiers())) {
/*      */           try {
/*  750 */             return targetClass.getMethod(method.getName(), method.getParameterTypes());
/*      */           }
/*      */           catch (NoSuchMethodException ex) {
/*  753 */             return method;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  758 */         Method specificMethod = ReflectionUtils.findMethod(targetClass, method
/*  758 */           .getName(), method.getParameterTypes());
/*  759 */         return specificMethod != null ? specificMethod : method;
/*      */       }
/*      */       catch (AccessControlException ex)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*  766 */     return method;
/*      */   }
/*      */ 
/*      */   public static boolean isUserLevelMethod(Method method)
/*      */   {
/*  781 */     Assert.notNull(method, "Method must not be null");
/*  782 */     return (method.isBridge()) || ((!method.isSynthetic()) && (!isGroovyObjectMethod(method)));
/*      */   }
/*      */ 
/*      */   private static boolean isGroovyObjectMethod(Method method) {
/*  786 */     return method.getDeclaringClass().getName().equals("groovy.lang.GroovyObject");
/*      */   }
/*      */ 
/*      */   private static boolean isOverridable(Method method, Class<?> targetClass)
/*      */   {
/*  795 */     if (Modifier.isPrivate(method.getModifiers())) {
/*  796 */       return false;
/*      */     }
/*  798 */     if ((Modifier.isPublic(method.getModifiers())) || (Modifier.isProtected(method.getModifiers()))) {
/*  799 */       return true;
/*      */     }
/*  801 */     return getPackageName(method.getDeclaringClass()).equals(getPackageName(targetClass));
/*      */   }
/*      */ 
/*      */   public static Method getStaticMethod(Class<?> clazz, String methodName, Class<?>[] args)
/*      */   {
/*  813 */     Assert.notNull(clazz, "Class must not be null");
/*  814 */     Assert.notNull(methodName, "Method name must not be null");
/*      */     try {
/*  816 */       Method method = clazz.getMethod(methodName, args);
/*  817 */       return Modifier.isStatic(method.getModifiers()) ? method : null;
/*      */     } catch (NoSuchMethodException ex) {
/*      */     }
/*  820 */     return null;
/*      */   }
/*      */ 
/*      */   public static boolean isPrimitiveWrapper(Class<?> clazz)
/*      */   {
/*  832 */     Assert.notNull(clazz, "Class must not be null");
/*  833 */     return primitiveWrapperTypeMap.containsKey(clazz);
/*      */   }
/*      */ 
/*      */   public static boolean isPrimitiveOrWrapper(Class<?> clazz)
/*      */   {
/*  844 */     Assert.notNull(clazz, "Class must not be null");
/*  845 */     return (clazz.isPrimitive()) || (isPrimitiveWrapper(clazz));
/*      */   }
/*      */ 
/*      */   public static boolean isPrimitiveArray(Class<?> clazz)
/*      */   {
/*  855 */     Assert.notNull(clazz, "Class must not be null");
/*  856 */     return (clazz.isArray()) && (clazz.getComponentType().isPrimitive());
/*      */   }
/*      */ 
/*      */   public static boolean isPrimitiveWrapperArray(Class<?> clazz)
/*      */   {
/*  866 */     Assert.notNull(clazz, "Class must not be null");
/*  867 */     return (clazz.isArray()) && (isPrimitiveWrapper(clazz.getComponentType()));
/*      */   }
/*      */ 
/*      */   public static Class<?> resolvePrimitiveIfNecessary(Class<?> clazz)
/*      */   {
/*  877 */     Assert.notNull(clazz, "Class must not be null");
/*  878 */     return (clazz.isPrimitive()) && (clazz != Void.TYPE) ? (Class)primitiveTypeToWrapperMap.get(clazz) : clazz;
/*      */   }
/*      */ 
/*      */   public static boolean isAssignable(Class<?> lhsType, Class<?> rhsType)
/*      */   {
/*  891 */     Assert.notNull(lhsType, "Left-hand side type must not be null");
/*  892 */     Assert.notNull(rhsType, "Right-hand side type must not be null");
/*  893 */     if (lhsType.isAssignableFrom(rhsType)) {
/*  894 */       return true;
/*      */     }
/*  896 */     if (lhsType.isPrimitive()) {
/*  897 */       Class resolvedPrimitive = (Class)primitiveWrapperTypeMap.get(rhsType);
/*  898 */       if ((resolvedPrimitive != null) && (lhsType.equals(resolvedPrimitive)))
/*  899 */         return true;
/*      */     }
/*      */     else
/*      */     {
/*  903 */       Class resolvedWrapper = (Class)primitiveTypeToWrapperMap.get(rhsType);
/*  904 */       if ((resolvedWrapper != null) && (lhsType.isAssignableFrom(resolvedWrapper))) {
/*  905 */         return true;
/*      */       }
/*      */     }
/*  908 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isAssignableValue(Class<?> type, Object value)
/*      */   {
/*  920 */     Assert.notNull(type, "Type must not be null");
/*  921 */     return !type.isPrimitive() ? true : value != null ? isAssignable(type, value.getClass()) : false;
/*      */   }
/*      */ 
/*      */   public static String convertResourcePathToClassName(String resourcePath)
/*      */   {
/*  931 */     Assert.notNull(resourcePath, "Resource path must not be null");
/*  932 */     return resourcePath.replace('/', '.');
/*      */   }
/*      */ 
/*      */   public static String convertClassNameToResourcePath(String className)
/*      */   {
/*  941 */     Assert.notNull(className, "Class name must not be null");
/*  942 */     return className.replace('.', '/');
/*      */   }
/*      */ 
/*      */   public static String addResourcePathToPackagePath(Class<?> clazz, String resourceName)
/*      */   {
/*  962 */     Assert.notNull(resourceName, "Resource name must not be null");
/*  963 */     if (!resourceName.startsWith("/")) {
/*  964 */       return new StringBuilder().append(classPackageAsResourcePath(clazz)).append("/").append(resourceName).toString();
/*      */     }
/*  966 */     return new StringBuilder().append(classPackageAsResourcePath(clazz)).append(resourceName).toString();
/*      */   }
/*      */ 
/*      */   public static String classPackageAsResourcePath(Class<?> clazz)
/*      */   {
/*  984 */     if (clazz == null) {
/*  985 */       return "";
/*      */     }
/*  987 */     String className = clazz.getName();
/*  988 */     int packageEndIndex = className.lastIndexOf(46);
/*  989 */     if (packageEndIndex == -1) {
/*  990 */       return "";
/*      */     }
/*  992 */     String packageName = className.substring(0, packageEndIndex);
/*  993 */     return packageName.replace('.', '/');
/*      */   }
/*      */ 
/*      */   public static String classNamesToString(Class<?>[] classes)
/*      */   {
/* 1006 */     return classNamesToString(Arrays.asList(classes));
/*      */   }
/*      */ 
/*      */   public static String classNamesToString(Collection<Class<?>> classes)
/*      */   {
/* 1019 */     if (CollectionUtils.isEmpty(classes)) {
/* 1020 */       return "[]";
/*      */     }
/* 1022 */     StringBuilder sb = new StringBuilder("[");
/* 1023 */     for (Iterator it = classes.iterator(); it.hasNext(); ) {
/* 1024 */       Class clazz = (Class)it.next();
/* 1025 */       sb.append(clazz.getName());
/* 1026 */       if (it.hasNext()) {
/* 1027 */         sb.append(", ");
/*      */       }
/*      */     }
/* 1030 */     sb.append("]");
/* 1031 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static Class<?>[] toClassArray(Collection<Class<?>> collection)
/*      */   {
/* 1042 */     if (collection == null) {
/* 1043 */       return null;
/*      */     }
/* 1045 */     return (Class[])collection.toArray(new Class[collection.size()]);
/*      */   }
/*      */ 
/*      */   public static Class<?>[] getAllInterfaces(Object instance)
/*      */   {
/* 1055 */     Assert.notNull(instance, "Instance must not be null");
/* 1056 */     return getAllInterfacesForClass(instance.getClass());
/*      */   }
/*      */ 
/*      */   public static Class<?>[] getAllInterfacesForClass(Class<?> clazz)
/*      */   {
/* 1067 */     return getAllInterfacesForClass(clazz, null);
/*      */   }
/*      */ 
/*      */   public static Class<?>[] getAllInterfacesForClass(Class<?> clazz, ClassLoader classLoader)
/*      */   {
/* 1080 */     Set ifcs = getAllInterfacesForClassAsSet(clazz, classLoader);
/* 1081 */     return (Class[])ifcs.toArray(new Class[ifcs.size()]);
/*      */   }
/*      */ 
/*      */   public static Set<Class<?>> getAllInterfacesAsSet(Object instance)
/*      */   {
/* 1091 */     Assert.notNull(instance, "Instance must not be null");
/* 1092 */     return getAllInterfacesForClassAsSet(instance.getClass());
/*      */   }
/*      */ 
/*      */   public static Set<Class<?>> getAllInterfacesForClassAsSet(Class<?> clazz)
/*      */   {
/* 1103 */     return getAllInterfacesForClassAsSet(clazz, null);
/*      */   }
/*      */ 
/*      */   public static Set<Class<?>> getAllInterfacesForClassAsSet(Class<?> clazz, ClassLoader classLoader)
/*      */   {
/* 1116 */     Assert.notNull(clazz, "Class must not be null");
/* 1117 */     if ((clazz.isInterface()) && (isVisible(clazz, classLoader))) {
/* 1118 */       return Collections.singleton(clazz);
/*      */     }
/* 1120 */     Set interfaces = new LinkedHashSet();
/* 1121 */     while (clazz != null) {
/* 1122 */       Class[] ifcs = clazz.getInterfaces();
/* 1123 */       for (Class ifc : ifcs) {
/* 1124 */         interfaces.addAll(getAllInterfacesForClassAsSet(ifc, classLoader));
/*      */       }
/* 1126 */       clazz = clazz.getSuperclass();
/*      */     }
/* 1128 */     return interfaces;
/*      */   }
/*      */ 
/*      */   public static Class<?> createCompositeInterface(Class<?>[] interfaces, ClassLoader classLoader)
/*      */   {
/* 1141 */     Assert.notEmpty(interfaces, "Interfaces must not be empty");
/* 1142 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/* 1143 */     return Proxy.getProxyClass(classLoader, interfaces);
/*      */   }
/*      */ 
/*      */   public static Class<?> determineCommonAncestor(Class<?> clazz1, Class<?> clazz2)
/*      */   {
/* 1156 */     if (clazz1 == null) {
/* 1157 */       return clazz2;
/*      */     }
/* 1159 */     if (clazz2 == null) {
/* 1160 */       return clazz1;
/*      */     }
/* 1162 */     if (clazz1.isAssignableFrom(clazz2)) {
/* 1163 */       return clazz1;
/*      */     }
/* 1165 */     if (clazz2.isAssignableFrom(clazz1)) {
/* 1166 */       return clazz2;
/*      */     }
/* 1168 */     Class ancestor = clazz1;
/*      */     do {
/* 1170 */       ancestor = ancestor.getSuperclass();
/* 1171 */       if ((ancestor == null) || (Object.class.equals(ancestor))) {
/* 1172 */         return null;
/*      */       }
/*      */     }
/* 1175 */     while (!ancestor.isAssignableFrom(clazz2));
/* 1176 */     return ancestor;
/*      */   }
/*      */ 
/*      */   public static boolean isVisible(Class<?> clazz, ClassLoader classLoader)
/*      */   {
/* 1186 */     if (classLoader == null)
/* 1187 */       return true;
/*      */     try
/*      */     {
/* 1190 */       Class actualClass = classLoader.loadClass(clazz.getName());
/* 1191 */       return clazz == actualClass;
/*      */     }
/*      */     catch (ClassNotFoundException ex)
/*      */     {
/*      */     }
/* 1196 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isCglibProxy(Object object)
/*      */   {
/* 1206 */     return isCglibProxyClass(object.getClass());
/*      */   }
/*      */ 
/*      */   public static boolean isCglibProxyClass(Class<?> clazz)
/*      */   {
/* 1214 */     return (clazz != null) && (isCglibProxyClassName(clazz.getName()));
/*      */   }
/*      */ 
/*      */   public static boolean isCglibProxyClassName(String className)
/*      */   {
/* 1222 */     return (className != null) && (className.contains("$$"));
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  100 */     primitiveWrapperTypeMap.put(Boolean.class, Boolean.TYPE);
/*  101 */     primitiveWrapperTypeMap.put(Byte.class, Byte.TYPE);
/*  102 */     primitiveWrapperTypeMap.put(Character.class, Character.TYPE);
/*  103 */     primitiveWrapperTypeMap.put(Double.class, Double.TYPE);
/*  104 */     primitiveWrapperTypeMap.put(Float.class, Float.TYPE);
/*  105 */     primitiveWrapperTypeMap.put(Integer.class, Integer.TYPE);
/*  106 */     primitiveWrapperTypeMap.put(Long.class, Long.TYPE);
/*  107 */     primitiveWrapperTypeMap.put(Short.class, Short.TYPE);
/*      */ 
/*  109 */     for (Iterator localIterator = primitiveWrapperTypeMap.entrySet().iterator(); localIterator.hasNext(); ) { entry = (Map.Entry)localIterator.next();
/*  110 */       primitiveTypeToWrapperMap.put(entry.getValue(), entry.getKey());
/*  111 */       registerCommonClasses(new Class[] { (Class)entry.getKey() });
/*      */     }
/*      */     Map.Entry entry;
/*  114 */     Object primitiveTypes = new HashSet(32);
/*  115 */     ((Set)primitiveTypes).addAll(primitiveWrapperTypeMap.values());
/*  116 */     ((Set)primitiveTypes).addAll(Arrays.asList(new Class[] { [Z.class, [B.class, [C.class, [D.class, [F.class, [I.class, [J.class, [S.class }));
/*      */ 
/*  119 */     ((Set)primitiveTypes).add(Void.TYPE);
/*  120 */     for (Class primitiveType : (Set)primitiveTypes) {
/*  121 */       primitiveTypeNameMap.put(primitiveType.getName(), primitiveType);
/*      */     }
/*      */ 
/*  124 */     registerCommonClasses(new Class[] { [Ljava.lang.Boolean.class, [Ljava.lang.Byte.class, [Ljava.lang.Character.class, [Ljava.lang.Double.class, [Ljava.lang.Float.class, [Ljava.lang.Integer.class, [Ljava.lang.Long.class, [Ljava.lang.Short.class });
/*      */ 
/*  126 */     registerCommonClasses(new Class[] { Number.class, [Ljava.lang.Number.class, String.class, [Ljava.lang.String.class, Object.class, [Ljava.lang.Object.class, Class.class, [Ljava.lang.Class.class });
/*      */ 
/*  128 */     registerCommonClasses(new Class[] { Throwable.class, Exception.class, RuntimeException.class, Error.class, StackTraceElement.class, [Ljava.lang.StackTraceElement.class });
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.ClassUtils
 * JD-Core Version:    0.6.2
 */