/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class CollectionUtils
/*     */ {
/*     */   public static boolean isEmpty(Collection<?> collection)
/*     */   {
/*  51 */     return (collection == null) || (collection.isEmpty());
/*     */   }
/*     */ 
/*     */   public static boolean isEmpty(Map<?, ?> map)
/*     */   {
/*  61 */     return (map == null) || (map.isEmpty());
/*     */   }
/*     */ 
/*     */   public static List arrayToList(Object source)
/*     */   {
/*  78 */     return Arrays.asList(ObjectUtils.toObjectArray(source));
/*     */   }
/*     */ 
/*     */   public static <E> void mergeArrayIntoCollection(Object array, Collection<E> collection)
/*     */   {
/*  88 */     if (collection == null) {
/*  89 */       throw new IllegalArgumentException("Collection must not be null");
/*     */     }
/*  91 */     Object[] arr = ObjectUtils.toObjectArray(array);
/*  92 */     for (Object elem : arr)
/*  93 */       collection.add(elem);
/*     */   }
/*     */ 
/*     */   public static <K, V> void mergePropertiesIntoMap(Properties props, Map<K, V> map)
/*     */   {
/* 107 */     if (map == null)
/* 108 */       throw new IllegalArgumentException("Map must not be null");
/*     */     Enumeration en;
/* 110 */     if (props != null)
/* 111 */       for (en = props.propertyNames(); en.hasMoreElements(); ) {
/* 112 */         String key = (String)en.nextElement();
/* 113 */         Object value = props.getProperty(key);
/* 114 */         if (value == null)
/*     */         {
/* 116 */           value = props.get(key);
/*     */         }
/* 118 */         map.put(key, value);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static boolean contains(Iterator<?> iterator, Object element)
/*     */   {
/* 131 */     if (iterator != null) {
/* 132 */       while (iterator.hasNext()) {
/* 133 */         Object candidate = iterator.next();
/* 134 */         if (ObjectUtils.nullSafeEquals(candidate, element)) {
/* 135 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean contains(Enumeration<?> enumeration, Object element)
/*     */   {
/* 149 */     if (enumeration != null) {
/* 150 */       while (enumeration.hasMoreElements()) {
/* 151 */         Object candidate = enumeration.nextElement();
/* 152 */         if (ObjectUtils.nullSafeEquals(candidate, element)) {
/* 153 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean containsInstance(Collection<?> collection, Object element)
/*     */   {
/*     */     Iterator localIterator;
/* 169 */     if (collection != null) {
/* 170 */       for (localIterator = collection.iterator(); localIterator.hasNext(); ) { Object candidate = localIterator.next();
/* 171 */         if (candidate == element) {
/* 172 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 176 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean containsAny(Collection<?> source, Collection<?> candidates)
/*     */   {
/* 187 */     if ((isEmpty(source)) || (isEmpty(candidates))) {
/* 188 */       return false;
/*     */     }
/* 190 */     for (Iterator localIterator = candidates.iterator(); localIterator.hasNext(); ) { Object candidate = localIterator.next();
/* 191 */       if (source.contains(candidate)) {
/* 192 */         return true;
/*     */       }
/*     */     }
/* 195 */     return false;
/*     */   }
/*     */ 
/*     */   public static <E> E findFirstMatch(Collection<?> source, Collection<E> candidates)
/*     */   {
/* 209 */     if ((isEmpty(source)) || (isEmpty(candidates))) {
/* 210 */       return null;
/*     */     }
/* 212 */     for (Iterator localIterator = candidates.iterator(); localIterator.hasNext(); ) { Object candidate = localIterator.next();
/* 213 */       if (source.contains(candidate)) {
/* 214 */         return candidate;
/*     */       }
/*     */     }
/* 217 */     return null;
/*     */   }
/*     */ 
/*     */   public static <T> T findValueOfType(Collection<?> collection, Class<T> type)
/*     */   {
/* 229 */     if (isEmpty(collection)) {
/* 230 */       return null;
/*     */     }
/* 232 */     Object value = null;
/* 233 */     for (Iterator localIterator = collection.iterator(); localIterator.hasNext(); ) { Object element = localIterator.next();
/* 234 */       if ((type == null) || (type.isInstance(element))) {
/* 235 */         if (value != null)
/*     */         {
/* 237 */           return null;
/*     */         }
/* 239 */         value = element;
/*     */       }
/*     */     }
/* 242 */     return value;
/*     */   }
/*     */ 
/*     */   public static Object findValueOfType(Collection<?> collection, Class<?>[] types)
/*     */   {
/* 255 */     if ((isEmpty(collection)) || (ObjectUtils.isEmpty(types))) {
/* 256 */       return null;
/*     */     }
/* 258 */     for (Class type : types) {
/* 259 */       Object value = findValueOfType(collection, type);
/* 260 */       if (value != null) {
/* 261 */         return value;
/*     */       }
/*     */     }
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean hasUniqueObject(Collection<?> collection)
/*     */   {
/* 274 */     if (isEmpty(collection)) {
/* 275 */       return false;
/*     */     }
/* 277 */     boolean hasCandidate = false;
/* 278 */     Object candidate = null;
/* 279 */     for (Iterator localIterator = collection.iterator(); localIterator.hasNext(); ) { Object elem = localIterator.next();
/* 280 */       if (!hasCandidate) {
/* 281 */         hasCandidate = true;
/* 282 */         candidate = elem;
/*     */       }
/* 284 */       else if (candidate != elem) {
/* 285 */         return false;
/*     */       }
/*     */     }
/* 288 */     return true;
/*     */   }
/*     */ 
/*     */   public static Class<?> findCommonElementType(Collection<?> collection)
/*     */   {
/* 298 */     if (isEmpty(collection)) {
/* 299 */       return null;
/*     */     }
/* 301 */     Class candidate = null;
/* 302 */     for (Iterator localIterator = collection.iterator(); localIterator.hasNext(); ) { Object val = localIterator.next();
/* 303 */       if (val != null) {
/* 304 */         if (candidate == null) {
/* 305 */           candidate = val.getClass();
/*     */         }
/* 307 */         else if (candidate != val.getClass()) {
/* 308 */           return null;
/*     */         }
/*     */       }
/*     */     }
/* 312 */     return candidate;
/*     */   }
/*     */ 
/*     */   public static <A, E extends A> A[] toArray(Enumeration<E> enumeration, A[] array)
/*     */   {
/* 321 */     ArrayList elements = new ArrayList();
/* 322 */     while (enumeration.hasMoreElements()) {
/* 323 */       elements.add(enumeration.nextElement());
/*     */     }
/* 325 */     return elements.toArray(array);
/*     */   }
/*     */ 
/*     */   public static <E> Iterator<E> toIterator(Enumeration<E> enumeration)
/*     */   {
/* 334 */     return new EnumerationIterator(enumeration);
/*     */   }
/*     */ 
/*     */   public static <K, V> MultiValueMap<K, V> toMultiValueMap(Map<K, List<V>> map)
/*     */   {
/* 343 */     return new MultiValueMapAdapter(map);
/*     */   }
/*     */ 
/*     */   public static <K, V> MultiValueMap<K, V> unmodifiableMultiValueMap(MultiValueMap<? extends K, ? extends V> map)
/*     */   {
/* 353 */     Assert.notNull(map, "'map' must not be null");
/* 354 */     Map result = new LinkedHashMap(map.size());
/* 355 */     for (Map.Entry entry : map.entrySet()) {
/* 356 */       List values = Collections.unmodifiableList((List)entry.getValue());
/* 357 */       result.put(entry.getKey(), values);
/*     */     }
/* 359 */     Map unmodifiableMap = Collections.unmodifiableMap(result);
/* 360 */     return toMultiValueMap(unmodifiableMap);
/*     */   }
/*     */ 
/*     */   private static class MultiValueMapAdapter<K, V>
/*     */     implements MultiValueMap<K, V>, Serializable
/*     */   {
/*     */     private final Map<K, List<V>> map;
/*     */ 
/*     */     public MultiValueMapAdapter(Map<K, List<V>> map)
/*     */     {
/* 400 */       Assert.notNull(map, "'map' must not be null");
/* 401 */       this.map = map;
/*     */     }
/*     */ 
/*     */     public void add(K key, V value)
/*     */     {
/* 406 */       List values = (List)this.map.get(key);
/* 407 */       if (values == null) {
/* 408 */         values = new LinkedList();
/* 409 */         this.map.put(key, values);
/*     */       }
/* 411 */       values.add(value);
/*     */     }
/*     */ 
/*     */     public V getFirst(K key)
/*     */     {
/* 416 */       List values = (List)this.map.get(key);
/* 417 */       return values != null ? values.get(0) : null;
/*     */     }
/*     */ 
/*     */     public void set(K key, V value)
/*     */     {
/* 422 */       List values = new LinkedList();
/* 423 */       values.add(value);
/* 424 */       this.map.put(key, values);
/*     */     }
/*     */ 
/*     */     public void setAll(Map<K, V> values)
/*     */     {
/* 429 */       for (Map.Entry entry : values.entrySet())
/* 430 */         set(entry.getKey(), entry.getValue());
/*     */     }
/*     */ 
/*     */     public Map<K, V> toSingleValueMap()
/*     */     {
/* 436 */       LinkedHashMap singleValueMap = new LinkedHashMap(this.map.size());
/* 437 */       for (Map.Entry entry : this.map.entrySet()) {
/* 438 */         singleValueMap.put(entry.getKey(), ((List)entry.getValue()).get(0));
/*     */       }
/* 440 */       return singleValueMap;
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 445 */       return this.map.size();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty()
/*     */     {
/* 450 */       return this.map.isEmpty();
/*     */     }
/*     */ 
/*     */     public boolean containsKey(Object key)
/*     */     {
/* 455 */       return this.map.containsKey(key);
/*     */     }
/*     */ 
/*     */     public boolean containsValue(Object value)
/*     */     {
/* 460 */       return this.map.containsValue(value);
/*     */     }
/*     */ 
/*     */     public List<V> get(Object key)
/*     */     {
/* 465 */       return (List)this.map.get(key);
/*     */     }
/*     */ 
/*     */     public List<V> put(K key, List<V> value)
/*     */     {
/* 470 */       return (List)this.map.put(key, value);
/*     */     }
/*     */ 
/*     */     public List<V> remove(Object key)
/*     */     {
/* 475 */       return (List)this.map.remove(key);
/*     */     }
/*     */ 
/*     */     public void putAll(Map<? extends K, ? extends List<V>> m)
/*     */     {
/* 480 */       this.map.putAll(m);
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 485 */       this.map.clear();
/*     */     }
/*     */ 
/*     */     public Set<K> keySet()
/*     */     {
/* 490 */       return this.map.keySet();
/*     */     }
/*     */ 
/*     */     public Collection<List<V>> values()
/*     */     {
/* 495 */       return this.map.values();
/*     */     }
/*     */ 
/*     */     public Set<Map.Entry<K, List<V>>> entrySet()
/*     */     {
/* 500 */       return this.map.entrySet();
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 505 */       if (this == other) {
/* 506 */         return true;
/*     */       }
/* 508 */       return this.map.equals(other);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 513 */       return this.map.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 518 */       return this.map.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EnumerationIterator<E>
/*     */     implements Iterator<E>
/*     */   {
/*     */     private Enumeration<E> enumeration;
/*     */ 
/*     */     public EnumerationIterator(Enumeration<E> enumeration)
/*     */     {
/* 372 */       this.enumeration = enumeration;
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 377 */       return this.enumeration.hasMoreElements();
/*     */     }
/*     */ 
/*     */     public E next()
/*     */     {
/* 382 */       return this.enumeration.nextElement();
/*     */     }
/*     */ 
/*     */     public void remove() throws UnsupportedOperationException
/*     */     {
/* 387 */       throw new UnsupportedOperationException("Not supported");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.CollectionUtils
 * JD-Core Version:    0.6.2
 */