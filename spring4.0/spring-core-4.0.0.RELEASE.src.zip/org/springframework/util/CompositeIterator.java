/*    */ package org.springframework.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ public class CompositeIterator<E>
/*    */   implements Iterator<E>
/*    */ {
/* 30 */   private List<Iterator<E>> iterators = new LinkedList();
/*    */ 
/* 32 */   private boolean inUse = false;
/*    */ 
/*    */   public void add(Iterator<E> iterator)
/*    */   {
/* 44 */     Assert.state(!this.inUse, "You can no longer add iterator to a composite iterator that's already in use");
/* 45 */     if (this.iterators.contains(iterator)) {
/* 46 */       throw new IllegalArgumentException("You cannot add the same iterator twice");
/*    */     }
/* 48 */     this.iterators.add(iterator);
/*    */   }
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 53 */     this.inUse = true;
/* 54 */     for (Iterator it = this.iterators.iterator(); it.hasNext(); ) {
/* 55 */       if (((Iterator)it.next()).hasNext()) {
/* 56 */         return true;
/*    */       }
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */   public E next()
/*    */   {
/* 64 */     this.inUse = true;
/* 65 */     for (Iterator it = this.iterators.iterator(); it.hasNext(); ) {
/* 66 */       Iterator iterator = (Iterator)it.next();
/* 67 */       if (iterator.hasNext()) {
/* 68 */         return iterator.next();
/*    */       }
/*    */     }
/* 71 */     throw new NoSuchElementException("Exhausted all iterators");
/*    */   }
/*    */ 
/*    */   public void remove()
/*    */   {
/* 76 */     throw new UnsupportedOperationException("Remove is not supported");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.CompositeIterator
 * JD-Core Version:    0.6.2
 */