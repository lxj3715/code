/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public class ConcurrentReferenceHashMap<K, V> extends AbstractMap<K, V>
/*     */   implements ConcurrentMap<K, V>
/*     */ {
/*     */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   private static final int DEFAULT_CONCURRENCY_LEVEL = 16;
/*     */   private static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*  67 */   private static final ReferenceType DEFAULT_REFERENCE_TYPE = ReferenceType.SOFT;
/*     */   private static final int MAXIMUM_CONCURRENCY_LEVEL = 65536;
/*     */   private static final int MAXIMUM_SEGMENT_SIZE = 1073741824;
/*     */   private final ConcurrentReferenceHashMap<K, V>[].Segment segments;
/*     */   private final float loadFactor;
/*     */   private final ReferenceType referenceType;
/*     */   private final int shift;
/*     */   private Set<Map.Entry<K, V>> entrySet;
/*     */ 
/*     */   public ConcurrentReferenceHashMap()
/*     */   {
/* 104 */     this(16, 0.75F, 16, DEFAULT_REFERENCE_TYPE);
/*     */   }
/*     */ 
/*     */   public ConcurrentReferenceHashMap(int initialCapacity)
/*     */   {
/* 112 */     this(initialCapacity, 0.75F, 16, DEFAULT_REFERENCE_TYPE);
/*     */   }
/*     */ 
/*     */   public ConcurrentReferenceHashMap(int initialCapacity, float loadFactor)
/*     */   {
/* 122 */     this(initialCapacity, loadFactor, 16, DEFAULT_REFERENCE_TYPE);
/*     */   }
/*     */ 
/*     */   public ConcurrentReferenceHashMap(int initialCapacity, int concurrencyLevel)
/*     */   {
/* 132 */     this(initialCapacity, 0.75F, concurrencyLevel, DEFAULT_REFERENCE_TYPE);
/*     */   }
/*     */ 
/*     */   public ConcurrentReferenceHashMap(int initialCapacity, float loadFactor, int concurrencyLevel)
/*     */   {
/* 144 */     this(initialCapacity, loadFactor, concurrencyLevel, DEFAULT_REFERENCE_TYPE);
/*     */   }
/*     */ 
/*     */   public ConcurrentReferenceHashMap(int initialCapacity, float loadFactor, int concurrencyLevel, ReferenceType referenceType)
/*     */   {
/* 160 */     Assert.isTrue(concurrencyLevel > 0, "ConcurrencyLevel must be positive");
/* 161 */     Assert.isTrue(initialCapacity >= 0, "InitialCapacity must not be negative");
/* 162 */     Assert.isTrue(loadFactor > 0.0F, "LoadFactor must be positive");
/* 163 */     Assert.notNull(referenceType, "Reference type must not be null");
/* 164 */     this.loadFactor = loadFactor;
/* 165 */     this.shift = calculateShift(concurrencyLevel, 65536);
/* 166 */     int size = 1 << this.shift;
/* 167 */     this.referenceType = referenceType;
/* 168 */     int roundedUpSegmentCapactity = (int)((initialCapacity + size - 1L) / size);
/* 169 */     this.segments = ((Segment[])Array.newInstance(Segment.class, size));
/* 170 */     for (int i = 0; i < this.segments.length; i++)
/* 171 */       this.segments[i] = new Segment(roundedUpSegmentCapactity);
/*     */   }
/*     */ 
/*     */   protected final float getLoadFactor()
/*     */   {
/* 177 */     return this.loadFactor;
/*     */   }
/*     */ 
/*     */   protected final int getSegmentsSize() {
/* 181 */     return this.segments.length;
/*     */   }
/*     */ 
/*     */   protected final ConcurrentReferenceHashMap<K, V>.Segment getSegment(int index) {
/* 185 */     return this.segments[index];
/*     */   }
/*     */ 
/*     */   protected ConcurrentReferenceHashMap<K, V>.ReferenceManager createReferenceManager()
/*     */   {
/* 194 */     return new ReferenceManager();
/*     */   }
/*     */ 
/*     */   protected int getHash(Object o)
/*     */   {
/* 205 */     int hash = o == null ? 0 : o.hashCode();
/* 206 */     hash += (hash << 15 ^ 0xFFFFCD7D);
/* 207 */     hash ^= hash >>> 10;
/* 208 */     hash += (hash << 3);
/* 209 */     hash ^= hash >>> 6;
/* 210 */     hash += (hash << 2) + (hash << 14);
/* 211 */     hash ^= hash >>> 16;
/* 212 */     return hash;
/*     */   }
/*     */ 
/*     */   public V get(Object key)
/*     */   {
/* 217 */     Reference reference = getReference(key, Restructure.WHEN_NECESSARY);
/* 218 */     Entry entry = reference == null ? null : reference.get();
/* 219 */     return entry != null ? entry.getValue() : null;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 224 */     Reference reference = getReference(key, Restructure.WHEN_NECESSARY);
/* 225 */     Entry entry = reference == null ? null : reference.get();
/* 226 */     return (entry != null) && (ObjectUtils.nullSafeEquals(entry.getKey(), key));
/*     */   }
/*     */ 
/*     */   protected final Reference<K, V> getReference(Object key, Restructure restructure)
/*     */   {
/* 237 */     int hash = getHash(key);
/* 238 */     return getSegmentForHash(hash).getReference(key, hash, restructure);
/*     */   }
/*     */ 
/*     */   public V put(K key, V value)
/*     */   {
/* 243 */     return put(key, value, true);
/*     */   }
/*     */ 
/*     */   public V putIfAbsent(K key, V value)
/*     */   {
/* 248 */     return put(key, value, false);
/*     */   }
/*     */ 
/*     */   private V put(K key, final V value, final boolean overwriteExisting) {
/* 252 */     return doTask(key, new Task(new TaskOption[] { TaskOption.RESTRUCTURE_BEFORE, TaskOption.RESIZE }, overwriteExisting)
/*     */     {
/*     */       protected V execute(ConcurrentReferenceHashMap.Reference<K, V> reference, ConcurrentReferenceHashMap.Entry<K, V> entry, ConcurrentReferenceHashMap<K, V>.Entries entries) {
/* 255 */         if (entry != null) {
/* 256 */           Object previousValue = entry.getValue();
/* 257 */           if (overwriteExisting) {
/* 258 */             entry.setValue(value);
/*     */           }
/* 260 */           return previousValue;
/*     */         }
/* 262 */         entries.add(value);
/* 263 */         return null; }  } ); } 
/*     */   public V remove(Object key) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: new 41	org/springframework/util/ConcurrentReferenceHashMap$2
/*     */     //   5: dup
/*     */     //   6: aload_0
/*     */     //   7: iconst_2
/*     */     //   8: anewarray 36	org/springframework/util/ConcurrentReferenceHashMap$TaskOption
/*     */     //   11: dup
/*     */     //   12: iconst_0
/*     */     //   13: getstatic 42	org/springframework/util/ConcurrentReferenceHashMap$TaskOption:RESTRUCTURE_AFTER	Lorg/springframework/util/ConcurrentReferenceHashMap$TaskOption;
/*     */     //   16: aastore
/*     */     //   17: dup
/*     */     //   18: iconst_1
/*     */     //   19: getstatic 43	org/springframework/util/ConcurrentReferenceHashMap$TaskOption:SKIP_IF_EMPTY	Lorg/springframework/util/ConcurrentReferenceHashMap$TaskOption;
/*     */     //   22: aastore
/*     */     //   23: invokespecial 44	org/springframework/util/ConcurrentReferenceHashMap$2:<init>	(Lorg/springframework/util/ConcurrentReferenceHashMap;[Lorg/springframework/util/ConcurrentReferenceHashMap$TaskOption;)V
/*     */     //   26: invokespecial 40	org/springframework/util/ConcurrentReferenceHashMap:doTask	(Ljava/lang/Object;Lorg/springframework/util/ConcurrentReferenceHashMap$Task;)Ljava/lang/Object;
/*     */     //   29: areturn } 
/* 284 */   public boolean remove(Object key, final Object value) { return ((Boolean)doTask(key, new Task(new TaskOption[] { TaskOption.RESTRUCTURE_AFTER, TaskOption.SKIP_IF_EMPTY }, value)
/*     */     {
/*     */       protected Boolean execute(ConcurrentReferenceHashMap.Reference<K, V> reference, ConcurrentReferenceHashMap.Entry<K, V> entry) {
/* 287 */         if ((entry != null) && (ObjectUtils.nullSafeEquals(entry.getValue(), value))) {
/* 288 */           reference.release();
/* 289 */           return Boolean.valueOf(true);
/*     */         }
/* 291 */         return Boolean.valueOf(false);
/*     */       }
/*     */     })).booleanValue();
/*     */   }
/*     */ 
/*     */   public boolean replace(K key, final V oldValue, final V newValue)
/*     */   {
/* 298 */     return ((Boolean)doTask(key, new Task(new TaskOption[] { TaskOption.RESTRUCTURE_BEFORE, TaskOption.SKIP_IF_EMPTY }, oldValue)
/*     */     {
/*     */       protected Boolean execute(ConcurrentReferenceHashMap.Reference<K, V> reference, ConcurrentReferenceHashMap.Entry<K, V> entry) {
/* 301 */         if ((entry != null) && (ObjectUtils.nullSafeEquals(entry.getValue(), oldValue))) {
/* 302 */           entry.setValue(newValue);
/* 303 */           return Boolean.valueOf(true);
/*     */         }
/* 305 */         return Boolean.valueOf(false);
/*     */       }
/*     */     })).booleanValue();
/*     */   }
/*     */ 
/*     */   public V replace(K key, final V value)
/*     */   {
/* 312 */     return doTask(key, new Task(new TaskOption[] { TaskOption.RESTRUCTURE_BEFORE, TaskOption.SKIP_IF_EMPTY }, value)
/*     */     {
/*     */       protected V execute(ConcurrentReferenceHashMap.Reference<K, V> reference, ConcurrentReferenceHashMap.Entry<K, V> entry) {
/* 315 */         if (entry != null) {
/* 316 */           Object previousValue = entry.getValue();
/* 317 */           entry.setValue(value);
/* 318 */           return previousValue;
/*     */         }
/* 320 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 327 */     for (Segment segment : this.segments)
/* 328 */       segment.clear();
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 334 */     int size = 0;
/* 335 */     for (Segment segment : this.segments) {
/* 336 */       size += segment.getCount();
/*     */     }
/* 338 */     return size;
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<K, V>> entrySet()
/*     */   {
/* 343 */     if (this.entrySet == null) {
/* 344 */       this.entrySet = new EntrySet(null);
/*     */     }
/* 346 */     return this.entrySet;
/*     */   }
/*     */ 
/*     */   private <T> T doTask(Object key, ConcurrentReferenceHashMap<K, V>.Task<T> task) {
/* 350 */     int hash = getHash(key);
/* 351 */     return getSegmentForHash(hash).doTask(hash, key, task);
/*     */   }
/*     */ 
/*     */   private ConcurrentReferenceHashMap<K, V>.Segment getSegmentForHash(int hash) {
/* 355 */     return this.segments[(hash >>> 32 - this.shift & this.segments.length - 1)];
/*     */   }
/*     */ 
/*     */   protected static int calculateShift(int minimumValue, int maximumValue)
/*     */   {
/* 366 */     int shift = 0;
/* 367 */     int value = 1;
/* 368 */     while ((value < minimumValue) && (value < minimumValue)) {
/* 369 */       value <<= 1;
/* 370 */       shift++;
/*     */     }
/* 372 */     return shift;
/*     */   }
/*     */ 
/*     */   private static final class WeakEntryReference<K, V> extends WeakReference<ConcurrentReferenceHashMap.Entry<K, V>>
/*     */     implements ConcurrentReferenceHashMap.Reference<K, V>
/*     */   {
/*     */     private final int hash;
/*     */     private final ConcurrentReferenceHashMap.Reference<K, V> nextReference;
/*     */ 
/*     */     public WeakEntryReference(ConcurrentReferenceHashMap.Entry<K, V> entry, int hash, ConcurrentReferenceHashMap.Reference<K, V> next, ReferenceQueue<ConcurrentReferenceHashMap.Entry<K, V>> queue)
/*     */     {
/* 981 */       super(queue);
/* 982 */       this.hash = hash;
/* 983 */       this.nextReference = next;
/*     */     }
/*     */ 
/*     */     public int getHash()
/*     */     {
/* 988 */       return this.hash;
/*     */     }
/*     */ 
/*     */     public ConcurrentReferenceHashMap.Reference<K, V> getNext()
/*     */     {
/* 993 */       return this.nextReference;
/*     */     }
/*     */ 
/*     */     public void release()
/*     */     {
/* 998 */       enqueue();
/* 999 */       clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class SoftEntryReference<K, V> extends SoftReference<ConcurrentReferenceHashMap.Entry<K, V>>
/*     */     implements ConcurrentReferenceHashMap.Reference<K, V>
/*     */   {
/*     */     private final int hash;
/*     */     private final ConcurrentReferenceHashMap.Reference<K, V> nextReference;
/*     */ 
/*     */     public SoftEntryReference(ConcurrentReferenceHashMap.Entry<K, V> entry, int hash, ConcurrentReferenceHashMap.Reference<K, V> next, ReferenceQueue<ConcurrentReferenceHashMap.Entry<K, V>> queue)
/*     */     {
/* 948 */       super(queue);
/* 949 */       this.hash = hash;
/* 950 */       this.nextReference = next;
/*     */     }
/*     */ 
/*     */     public int getHash()
/*     */     {
/* 955 */       return this.hash;
/*     */     }
/*     */ 
/*     */     public ConcurrentReferenceHashMap.Reference<K, V> getNext()
/*     */     {
/* 960 */       return this.nextReference;
/*     */     }
/*     */ 
/*     */     public void release()
/*     */     {
/* 965 */       enqueue();
/* 966 */       clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class ReferenceManager
/*     */   {
/* 908 */     private final ReferenceQueue<ConcurrentReferenceHashMap.Entry<K, V>> queue = new ReferenceQueue();
/*     */ 
/*     */     protected ReferenceManager()
/*     */     {
/*     */     }
/*     */ 
/*     */     public ConcurrentReferenceHashMap.Reference<K, V> createReference(ConcurrentReferenceHashMap.Entry<K, V> entry, int hash, ConcurrentReferenceHashMap.Reference<K, V> next)
/*     */     {
/* 918 */       if (ConcurrentReferenceHashMap.this.referenceType == ConcurrentReferenceHashMap.ReferenceType.WEAK) {
/* 919 */         return new ConcurrentReferenceHashMap.WeakEntryReference(entry, hash, next, this.queue);
/*     */       }
/* 921 */       return new ConcurrentReferenceHashMap.SoftEntryReference(entry, hash, next, this.queue);
/*     */     }
/*     */ 
/*     */     public ConcurrentReferenceHashMap.Reference<K, V> pollForPurge()
/*     */     {
/* 933 */       return (ConcurrentReferenceHashMap.Reference)this.queue.poll();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static enum Restructure
/*     */   {
/* 898 */     WHEN_NECESSARY, NEVER;
/*     */   }
/*     */ 
/*     */   private class EntryIterator
/*     */     implements Iterator<Map.Entry<K, V>>
/*     */   {
/*     */     private int segmentIndex;
/*     */     private int referenceIndex;
/*     */     private ConcurrentReferenceHashMap.Reference<K, V>[] references;
/*     */     private ConcurrentReferenceHashMap.Reference<K, V> reference;
/*     */     private ConcurrentReferenceHashMap.Entry<K, V> next;
/*     */     private ConcurrentReferenceHashMap.Entry<K, V> last;
/*     */ 
/*     */     public EntryIterator()
/*     */     {
/* 830 */       moveToNextSegment();
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 835 */       getNextIfNecessary();
/* 836 */       return this.next != null;
/*     */     }
/*     */ 
/*     */     public ConcurrentReferenceHashMap.Entry<K, V> next()
/*     */     {
/* 841 */       getNextIfNecessary();
/* 842 */       if (this.next == null) {
/* 843 */         throw new NoSuchElementException();
/*     */       }
/* 845 */       this.last = this.next;
/* 846 */       this.next = null;
/* 847 */       return this.last;
/*     */     }
/*     */ 
/*     */     private void getNextIfNecessary() {
/* 851 */       while (this.next == null) {
/* 852 */         moveToNextReference();
/* 853 */         if (this.reference == null) {
/* 854 */           return;
/*     */         }
/* 856 */         this.next = this.reference.get();
/*     */       }
/*     */     }
/*     */ 
/*     */     private void moveToNextReference() {
/* 861 */       if (this.reference != null) {
/* 862 */         this.reference = this.reference.getNext();
/*     */       }
/* 864 */       while ((this.reference == null) && (this.references != null))
/* 865 */         if (this.referenceIndex >= this.references.length) {
/* 866 */           moveToNextSegment();
/* 867 */           this.referenceIndex = 0;
/*     */         }
/*     */         else {
/* 870 */           this.reference = this.references[this.referenceIndex];
/* 871 */           this.referenceIndex += 1;
/*     */         }
/*     */     }
/*     */ 
/*     */     private void moveToNextSegment()
/*     */     {
/* 877 */       this.reference = null;
/* 878 */       this.references = null;
/* 879 */       if (this.segmentIndex < ConcurrentReferenceHashMap.this.segments.length) {
/* 880 */         this.references = ConcurrentReferenceHashMap.Segment.access$400(ConcurrentReferenceHashMap.this.segments[this.segmentIndex]);
/* 881 */         this.segmentIndex += 1;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 887 */       Assert.state(this.last != null);
/* 888 */       ConcurrentReferenceHashMap.this.remove(this.last.getKey());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EntrySet extends AbstractSet<Map.Entry<K, V>>
/*     */   {
/*     */     private EntrySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<K, V>> iterator()
/*     */     {
/* 775 */       return new ConcurrentReferenceHashMap.EntryIterator(ConcurrentReferenceHashMap.this);
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o)
/*     */     {
/* 780 */       if ((o != null) && ((o instanceof Map.Entry))) {
/* 781 */         Map.Entry entry = (Map.Entry)o;
/* 782 */         ConcurrentReferenceHashMap.Reference reference = ConcurrentReferenceHashMap.this.getReference(entry.getKey(), ConcurrentReferenceHashMap.Restructure.NEVER);
/* 783 */         ConcurrentReferenceHashMap.Entry other = reference == null ? null : reference.get();
/* 784 */         if (other != null) {
/* 785 */           return ObjectUtils.nullSafeEquals(entry.getValue(), other.getValue());
/*     */         }
/*     */       }
/* 788 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o)
/*     */     {
/* 793 */       if ((o instanceof Map.Entry)) {
/* 794 */         Map.Entry entry = (Map.Entry)o;
/* 795 */         return ConcurrentReferenceHashMap.this.remove(entry.getKey(), entry.getValue());
/*     */       }
/* 797 */       return false;
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 802 */       return ConcurrentReferenceHashMap.this.size();
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 807 */       ConcurrentReferenceHashMap.this.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private abstract class Entries
/*     */   {
/*     */     private Entries()
/*     */     {
/*     */     }
/*     */ 
/*     */     public abstract void add(V paramV);
/*     */   }
/*     */ 
/*     */   private static enum TaskOption
/*     */   {
/* 751 */     RESTRUCTURE_BEFORE, RESTRUCTURE_AFTER, SKIP_IF_EMPTY, RESIZE;
/*     */   }
/*     */ 
/*     */   private abstract class Task<T>
/*     */   {
/*     */     private final EnumSet<ConcurrentReferenceHashMap.TaskOption> options;
/*     */ 
/*     */     public Task(ConcurrentReferenceHashMap.TaskOption[] options)
/*     */     {
/* 714 */       this.options = (options.length == 0 ? EnumSet.noneOf(ConcurrentReferenceHashMap.TaskOption.class) : EnumSet.of(options[0], options));
/*     */     }
/*     */ 
/*     */     public boolean hasOption(ConcurrentReferenceHashMap.TaskOption option) {
/* 718 */       return this.options.contains(option);
/*     */     }
/*     */ 
/*     */     protected T execute(ConcurrentReferenceHashMap.Reference<K, V> reference, ConcurrentReferenceHashMap.Entry<K, V> entry, ConcurrentReferenceHashMap<K, V>.Entries entries)
/*     */     {
/* 730 */       return execute(reference, entry);
/*     */     }
/*     */ 
/*     */     protected T execute(ConcurrentReferenceHashMap.Reference<K, V> reference, ConcurrentReferenceHashMap.Entry<K, V> entry)
/*     */     {
/* 741 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static final class Entry<K, V>
/*     */     implements Map.Entry<K, V>
/*     */   {
/*     */     private final K key;
/*     */     private volatile V value;
/*     */ 
/*     */     public Entry(K key, V value)
/*     */     {
/* 658 */       this.key = key;
/* 659 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public K getKey()
/*     */     {
/* 664 */       return this.key;
/*     */     }
/*     */ 
/*     */     public V getValue()
/*     */     {
/* 669 */       return this.value;
/*     */     }
/*     */ 
/*     */     public V setValue(V value)
/*     */     {
/* 674 */       Object previous = this.value;
/* 675 */       this.value = value;
/* 676 */       return previous;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 681 */       return this.key + "=" + this.value;
/*     */     }
/*     */ 
/*     */     public final boolean equals(Object o)
/*     */     {
/* 687 */       if (o == this) {
/* 688 */         return true;
/*     */       }
/* 690 */       if ((o != null) && ((o instanceof Map.Entry))) {
/* 691 */         Map.Entry other = (Map.Entry)o;
/*     */ 
/* 693 */         return (ObjectUtils.nullSafeEquals(getKey(), other.getKey())) && 
/* 693 */           (ObjectUtils.nullSafeEquals(getValue(), other.getValue()));
/*     */       }
/* 695 */       return false;
/*     */     }
/*     */ 
/*     */     public final int hashCode()
/*     */     {
/* 701 */       return ObjectUtils.nullSafeHashCode(this.key) ^ 
/* 701 */         ObjectUtils.nullSafeHashCode(this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static abstract interface Reference<K, V>
/*     */   {
/*     */     public abstract ConcurrentReferenceHashMap.Entry<K, V> get();
/*     */ 
/*     */     public abstract int getHash();
/*     */ 
/*     */     public abstract Reference<K, V> getNext();
/*     */ 
/*     */     public abstract void release();
/*     */   }
/*     */ 
/*     */   protected final class Segment extends ReentrantLock
/*     */   {
/*     */     private final ConcurrentReferenceHashMap<K, V>.ReferenceManager referenceManager;
/*     */     private final int initialSize;
/*     */     private volatile ConcurrentReferenceHashMap.Reference<K, V>[] references;
/* 414 */     private volatile int count = 0;
/*     */     private int resizeThreshold;
/*     */ 
/*     */     public Segment(int initialCapacity)
/*     */     {
/* 423 */       this.referenceManager = ConcurrentReferenceHashMap.this.createReferenceManager();
/* 424 */       this.initialSize = (1 << ConcurrentReferenceHashMap.calculateShift(initialCapacity, 1073741824));
/* 425 */       setReferences(createReferenceArray(this.initialSize));
/*     */     }
/*     */ 
/*     */     public ConcurrentReferenceHashMap.Reference<K, V> getReference(Object key, int hash, ConcurrentReferenceHashMap.Restructure restructure) {
/* 429 */       if (restructure == ConcurrentReferenceHashMap.Restructure.WHEN_NECESSARY) {
/* 430 */         restructureIfNecessary(false);
/*     */       }
/* 432 */       if (this.count == 0) {
/* 433 */         return null;
/*     */       }
/*     */ 
/* 436 */       ConcurrentReferenceHashMap.Reference[] references = this.references;
/* 437 */       int index = getIndex(hash, references);
/* 438 */       ConcurrentReferenceHashMap.Reference head = references[index];
/* 439 */       return findInChain(head, key, hash);
/*     */     }
/*     */ 
/*     */     public <T> T doTask(final int hash, final Object key, ConcurrentReferenceHashMap<K, V>.Task<T> task)
/*     */     {
/* 451 */       boolean resize = task.hasOption(ConcurrentReferenceHashMap.TaskOption.RESIZE);
/* 452 */       if (task.hasOption(ConcurrentReferenceHashMap.TaskOption.RESTRUCTURE_BEFORE)) {
/* 453 */         restructureIfNecessary(resize);
/*     */       }
/* 455 */       if ((task.hasOption(ConcurrentReferenceHashMap.TaskOption.SKIP_IF_EMPTY)) && (this.count == 0)) {
/* 456 */         return task.execute(null, null, null);
/*     */       }
/* 458 */       lock();
/*     */       try {
/* 460 */         final int index = getIndex(hash, this.references);
/* 461 */         final ConcurrentReferenceHashMap.Reference head = this.references[index];
/* 462 */         ConcurrentReferenceHashMap.Reference reference = findInChain(head, key, hash);
/* 463 */         ConcurrentReferenceHashMap.Entry entry = reference == null ? null : reference.get();
/* 464 */         ConcurrentReferenceHashMap.Entries entries = new ConcurrentReferenceHashMap.Entries(key, hash)
/*     */         {
/*     */           public void add(V value)
/*     */           {
/* 468 */             ConcurrentReferenceHashMap.Entry newEntry = new ConcurrentReferenceHashMap.Entry(key, value);
/* 469 */             ConcurrentReferenceHashMap.Reference newReference = ConcurrentReferenceHashMap.Segment.this.referenceManager.createReference(newEntry, hash, head);
/* 470 */             ConcurrentReferenceHashMap.Segment.this.references[index] = newReference;
/* 471 */             ConcurrentReferenceHashMap.Segment.access$508(ConcurrentReferenceHashMap.Segment.this);
/*     */           }
/*     */         };
/* 474 */         return task.execute(reference, entry, entries);
/*     */       }
/*     */       finally {
/* 477 */         unlock();
/* 478 */         if (task.hasOption(ConcurrentReferenceHashMap.TaskOption.RESTRUCTURE_AFTER))
/* 479 */           restructureIfNecessary(resize);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 488 */       if (this.count == 0) {
/* 489 */         return;
/*     */       }
/* 491 */       lock();
/*     */       try {
/* 493 */         setReferences(createReferenceArray(this.initialSize));
/* 494 */         this.count = 0;
/*     */ 
/* 496 */         unlock(); } finally { unlock(); }
/*     */ 
/*     */     }
/*     */ 
/*     */     private void restructureIfNecessary(boolean allowResize)
/*     */     {
/* 507 */       boolean needsResize = (this.count > 0) && (this.count >= this.resizeThreshold);
/* 508 */       ConcurrentReferenceHashMap.Reference reference = this.referenceManager.pollForPurge();
/* 509 */       if ((reference != null) || ((needsResize) && (allowResize))) {
/* 510 */         lock();
/*     */         try {
/* 512 */           int countAfterRestructure = this.count;
/*     */ 
/* 514 */           Set toPurge = Collections.emptySet();
/* 515 */           if (reference != null) {
/* 516 */             toPurge = new HashSet();
/* 517 */             while (reference != null) {
/* 518 */               toPurge.add(reference);
/* 519 */               reference = this.referenceManager.pollForPurge();
/*     */             }
/*     */           }
/* 522 */           countAfterRestructure -= toPurge.size();
/*     */ 
/* 526 */           needsResize = (countAfterRestructure > 0) && (countAfterRestructure >= this.resizeThreshold);
/* 527 */           boolean resizing = false;
/* 528 */           int restructureSize = this.references.length;
/* 529 */           if ((allowResize) && (needsResize) && (restructureSize < 1073741824)) {
/* 530 */             restructureSize <<= 1;
/* 531 */             resizing = true;
/*     */           }
/*     */ 
/* 535 */           ConcurrentReferenceHashMap.Reference[] restructured = resizing ? createReferenceArray(restructureSize) : this.references;
/*     */ 
/* 538 */           for (int i = 0; i < this.references.length; i++) {
/* 539 */             reference = this.references[i];
/* 540 */             if (!resizing) {
/* 541 */               restructured[i] = null;
/*     */             }
/* 543 */             while (reference != null) {
/* 544 */               if (!toPurge.contains(reference)) {
/* 545 */                 int index = getIndex(reference.getHash(), restructured);
/* 546 */                 restructured[index] = this.referenceManager.createReference(reference
/* 547 */                   .get(), reference.getHash(), restructured[index]);
/*     */               }
/*     */ 
/* 550 */               reference = reference.getNext();
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 555 */           if (resizing) {
/* 556 */             setReferences(restructured);
/*     */           }
/* 558 */           this.count = countAfterRestructure;
/*     */         } finally {
/* 560 */           unlock();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private ConcurrentReferenceHashMap.Reference<K, V> findInChain(ConcurrentReferenceHashMap.Reference<K, V> reference, Object key, int hash) {
/* 566 */       while (reference != null) {
/* 567 */         if (reference.getHash() == hash) {
/* 568 */           ConcurrentReferenceHashMap.Entry entry = reference.get();
/* 569 */           if (entry != null) {
/* 570 */             Object entryKey = entry.getKey();
/* 571 */             if ((entryKey == key) || (entryKey.equals(key))) {
/* 572 */               return reference;
/*     */             }
/*     */           }
/*     */         }
/* 576 */         reference = reference.getNext();
/*     */       }
/* 578 */       return null;
/*     */     }
/*     */ 
/*     */     private ConcurrentReferenceHashMap.Reference<K, V>[] createReferenceArray(int size)
/*     */     {
/* 583 */       return (ConcurrentReferenceHashMap.Reference[])Array.newInstance(ConcurrentReferenceHashMap.Reference.class, size);
/*     */     }
/*     */ 
/*     */     private int getIndex(int hash, ConcurrentReferenceHashMap.Reference<K, V>[] references) {
/* 587 */       return hash & references.length - 1;
/*     */     }
/*     */ 
/*     */     private void setReferences(ConcurrentReferenceHashMap.Reference<K, V>[] references)
/*     */     {
/* 595 */       this.references = references;
/* 596 */       this.resizeThreshold = ((int)(references.length * ConcurrentReferenceHashMap.this.getLoadFactor()));
/*     */     }
/*     */ 
/*     */     public final int getSize()
/*     */     {
/* 603 */       return this.references.length;
/*     */     }
/*     */ 
/*     */     public final int getCount()
/*     */     {
/* 610 */       return this.count;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum ReferenceType
/*     */   {
/* 384 */     SOFT, 
/*     */ 
/* 389 */     WEAK;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.ConcurrentReferenceHashMap
 * JD-Core Version:    0.6.2
 */