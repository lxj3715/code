/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class CustomizableThreadCreator
/*     */   implements Serializable
/*     */ {
/*     */   private String threadNamePrefix;
/*  37 */   private int threadPriority = 5;
/*     */ 
/*  39 */   private boolean daemon = false;
/*     */   private ThreadGroup threadGroup;
/*  43 */   private int threadCount = 0;
/*     */ 
/*  45 */   private final Object threadCountMonitor = new SerializableMonitor(null);
/*     */ 
/*     */   public CustomizableThreadCreator()
/*     */   {
/*  52 */     this.threadNamePrefix = getDefaultThreadNamePrefix();
/*     */   }
/*     */ 
/*     */   public CustomizableThreadCreator(String threadNamePrefix)
/*     */   {
/*  60 */     this.threadNamePrefix = (threadNamePrefix != null ? threadNamePrefix : getDefaultThreadNamePrefix());
/*     */   }
/*     */ 
/*     */   public void setThreadNamePrefix(String threadNamePrefix)
/*     */   {
/*  69 */     this.threadNamePrefix = (threadNamePrefix != null ? threadNamePrefix : getDefaultThreadNamePrefix());
/*     */   }
/*     */ 
/*     */   public String getThreadNamePrefix()
/*     */   {
/*  77 */     return this.threadNamePrefix;
/*     */   }
/*     */ 
/*     */   public void setThreadPriority(int threadPriority)
/*     */   {
/*  86 */     this.threadPriority = threadPriority;
/*     */   }
/*     */ 
/*     */   public int getThreadPriority()
/*     */   {
/*  93 */     return this.threadPriority;
/*     */   }
/*     */ 
/*     */   public void setDaemon(boolean daemon)
/*     */   {
/* 107 */     this.daemon = daemon;
/*     */   }
/*     */ 
/*     */   public boolean isDaemon()
/*     */   {
/* 114 */     return this.daemon;
/*     */   }
/*     */ 
/*     */   public void setThreadGroupName(String name)
/*     */   {
/* 122 */     this.threadGroup = new ThreadGroup(name);
/*     */   }
/*     */ 
/*     */   public void setThreadGroup(ThreadGroup threadGroup)
/*     */   {
/* 130 */     this.threadGroup = threadGroup;
/*     */   }
/*     */ 
/*     */   public ThreadGroup getThreadGroup()
/*     */   {
/* 138 */     return this.threadGroup;
/*     */   }
/*     */ 
/*     */   public Thread createThread(Runnable runnable)
/*     */   {
/* 150 */     Thread thread = new Thread(getThreadGroup(), runnable, nextThreadName());
/* 151 */     thread.setPriority(getThreadPriority());
/* 152 */     thread.setDaemon(isDaemon());
/* 153 */     return thread;
/*     */   }
/*     */ 
/*     */   protected String nextThreadName()
/*     */   {
/* 164 */     int threadNumber = 0;
/* 165 */     synchronized (this.threadCountMonitor) {
/* 166 */       this.threadCount += 1;
/* 167 */       threadNumber = this.threadCount;
/*     */     }
/* 169 */     return getThreadNamePrefix() + threadNumber;
/*     */   }
/*     */ 
/*     */   protected String getDefaultThreadNamePrefix()
/*     */   {
/* 177 */     return ClassUtils.getShortName(getClass()) + "-";
/*     */   }
/*     */ 
/*     */   private static class SerializableMonitor
/*     */     implements Serializable
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.CustomizableThreadCreator
 * JD-Core Version:    0.6.2
 */