/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ 
/*     */ public abstract class DigestUtils
/*     */ {
/*     */   private static final String MD5_ALGORITHM_NAME = "MD5";
/*  36 */   private static final char[] HEX_CHARS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */ 
/*     */   public static byte[] md5Digest(byte[] bytes)
/*     */   {
/*  45 */     return digest("MD5", bytes);
/*     */   }
/*     */ 
/*     */   public static String md5DigestAsHex(byte[] bytes)
/*     */   {
/*  55 */     return digestAsHexString("MD5", bytes);
/*     */   }
/*     */ 
/*     */   public static StringBuilder appendMd5DigestAsHex(byte[] bytes, StringBuilder builder)
/*     */   {
/*  66 */     return appendDigestAsHex("MD5", bytes, builder);
/*     */   }
/*     */ 
/*     */   private static MessageDigest getDigest(String algorithm)
/*     */   {
/*     */     try
/*     */     {
/*  75 */       return MessageDigest.getInstance(algorithm);
/*     */     }
/*     */     catch (NoSuchAlgorithmException ex) {
/*  78 */       throw new IllegalStateException("Could not find MessageDigest with algorithm \"" + algorithm + "\"", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static byte[] digest(String algorithm, byte[] bytes) {
/*  83 */     return getDigest(algorithm).digest(bytes);
/*     */   }
/*     */ 
/*     */   private static String digestAsHexString(String algorithm, byte[] bytes) {
/*  87 */     char[] hexDigest = digestAsHexChars(algorithm, bytes);
/*  88 */     return new String(hexDigest);
/*     */   }
/*     */ 
/*     */   private static StringBuilder appendDigestAsHex(String algorithm, byte[] bytes, StringBuilder builder) {
/*  92 */     char[] hexDigest = digestAsHexChars(algorithm, bytes);
/*  93 */     return builder.append(hexDigest);
/*     */   }
/*     */ 
/*     */   private static char[] digestAsHexChars(String algorithm, byte[] bytes) {
/*  97 */     byte[] digest = digest(algorithm, bytes);
/*  98 */     return encodeHex(digest);
/*     */   }
/*     */ 
/*     */   private static char[] encodeHex(byte[] bytes) {
/* 102 */     char[] chars = new char[32];
/* 103 */     for (int i = 0; i < chars.length; i += 2) {
/* 104 */       byte b = bytes[(i / 2)];
/* 105 */       chars[i] = HEX_CHARS[(b >>> 4 & 0xF)];
/* 106 */       chars[(i + 1)] = HEX_CHARS[(b & 0xF)];
/*     */     }
/* 108 */     return chars;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.DigestUtils
 * JD-Core Version:    0.6.2
 */