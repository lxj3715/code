package org.springframework.util;

public abstract interface ErrorHandler
{
  public abstract void handleError(Throwable paramThrowable);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.ErrorHandler
 * JD-Core Version:    0.6.2
 */