/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public abstract class FileCopyUtils
/*     */ {
/*     */   public static final int BUFFER_SIZE = 4096;
/*     */ 
/*     */   public static int copy(File in, File out)
/*     */     throws IOException
/*     */   {
/*  61 */     Assert.notNull(in, "No input File specified");
/*  62 */     Assert.notNull(out, "No output File specified");
/*  63 */     return copy(new BufferedInputStream(new FileInputStream(in)), new BufferedOutputStream(new FileOutputStream(out)));
/*     */   }
/*     */ 
/*     */   public static void copy(byte[] in, File out)
/*     */     throws IOException
/*     */   {
/*  74 */     Assert.notNull(in, "No input byte array specified");
/*  75 */     Assert.notNull(out, "No output File specified");
/*  76 */     ByteArrayInputStream inStream = new ByteArrayInputStream(in);
/*  77 */     OutputStream outStream = new BufferedOutputStream(new FileOutputStream(out));
/*  78 */     copy(inStream, outStream);
/*     */   }
/*     */ 
/*     */   public static byte[] copyToByteArray(File in)
/*     */     throws IOException
/*     */   {
/*  88 */     Assert.notNull(in, "No input File specified");
/*  89 */     return copyToByteArray(new BufferedInputStream(new FileInputStream(in)));
/*     */   }
/*     */ 
/*     */   public static int copy(InputStream in, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 106 */     Assert.notNull(in, "No InputStream specified");
/* 107 */     Assert.notNull(out, "No OutputStream specified");
/*     */     try {
/* 109 */       return StreamUtils.copy(in, out);
/*     */     }
/*     */     finally {
/*     */       try {
/* 113 */         in.close();
/*     */       }
/*     */       catch (IOException ex) {
/*     */       }
/*     */       try {
/* 118 */         out.close();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void copy(byte[] in, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 133 */     Assert.notNull(in, "No input byte array specified");
/* 134 */     Assert.notNull(out, "No OutputStream specified");
/*     */     try {
/* 136 */       out.write(in);
/*     */       try
/*     */       {
/* 140 */         out.close(); } catch (IOException ex) {  } } finally { try { out.close(); }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] copyToByteArray(InputStream in)
/*     */     throws IOException
/*     */   {
/* 155 */     ByteArrayOutputStream out = new ByteArrayOutputStream(4096);
/* 156 */     copy(in, out);
/* 157 */     return out.toByteArray();
/*     */   }
/*     */ 
/*     */   public static int copy(Reader in, Writer out)
/*     */     throws IOException
/*     */   {
/* 174 */     Assert.notNull(in, "No Reader specified");
/* 175 */     Assert.notNull(out, "No Writer specified");
/*     */     try {
/* 177 */       int byteCount = 0;
/* 178 */       char[] buffer = new char[4096];
/* 179 */       int bytesRead = -1;
/* 180 */       while ((bytesRead = in.read(buffer)) != -1) {
/* 181 */         out.write(buffer, 0, bytesRead);
/* 182 */         byteCount += bytesRead;
/*     */       }
/* 184 */       out.flush();
/* 185 */       return byteCount;
/*     */     }
/*     */     finally {
/*     */       try {
/* 189 */         in.close();
/*     */       }
/*     */       catch (IOException ex) {
/*     */       }
/*     */       try {
/* 194 */         out.close();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void copy(String in, Writer out)
/*     */     throws IOException
/*     */   {
/* 209 */     Assert.notNull(in, "No input String specified");
/* 210 */     Assert.notNull(out, "No Writer specified");
/*     */     try {
/* 212 */       out.write(in);
/*     */       try
/*     */       {
/* 216 */         out.close(); } catch (IOException ex) {  } } finally { try { out.close(); }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String copyToString(Reader in)
/*     */     throws IOException
/*     */   {
/* 231 */     StringWriter out = new StringWriter();
/* 232 */     copy(in, out);
/* 233 */     return out.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.FileCopyUtils
 * JD-Core Version:    0.6.2
 */