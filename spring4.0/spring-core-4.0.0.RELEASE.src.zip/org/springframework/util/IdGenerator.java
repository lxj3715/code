package org.springframework.util;

import java.util.UUID;

public abstract interface IdGenerator
{
  public abstract UUID generateId();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.IdGenerator
 * JD-Core Version:    0.6.2
 */