/*    */ package org.springframework.util;
/*    */ 
/*    */ public class InvalidMimeTypeException extends IllegalArgumentException
/*    */ {
/*    */   private String mimeType;
/*    */ 
/*    */   public InvalidMimeTypeException(String mimeType, String message)
/*    */   {
/* 39 */     super("Invalid mime type \"" + mimeType + "\": " + message);
/* 40 */     this.mimeType = mimeType;
/*    */   }
/*    */ 
/*    */   public String getMimeType()
/*    */   {
/* 49 */     return this.mimeType;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.InvalidMimeTypeException
 * JD-Core Version:    0.6.2
 */