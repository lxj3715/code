/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class LinkedCaseInsensitiveMap<V> extends LinkedHashMap<String, V>
/*     */ {
/*     */   private final Map<String, String> caseInsensitiveKeys;
/*     */   private final Locale locale;
/*     */ 
/*     */   public LinkedCaseInsensitiveMap()
/*     */   {
/*  49 */     this(null);
/*     */   }
/*     */ 
/*     */   public LinkedCaseInsensitiveMap(Locale locale)
/*     */   {
/*  60 */     this.caseInsensitiveKeys = new HashMap();
/*  61 */     this.locale = (locale != null ? locale : Locale.getDefault());
/*     */   }
/*     */ 
/*     */   public LinkedCaseInsensitiveMap(int initialCapacity)
/*     */   {
/*  72 */     this(initialCapacity, null);
/*     */   }
/*     */ 
/*     */   public LinkedCaseInsensitiveMap(int initialCapacity, Locale locale)
/*     */   {
/*  84 */     super(initialCapacity);
/*  85 */     this.caseInsensitiveKeys = new HashMap(initialCapacity);
/*  86 */     this.locale = (locale != null ? locale : Locale.getDefault());
/*     */   }
/*     */ 
/*     */   public V put(String key, V value)
/*     */   {
/*  92 */     String oldKey = (String)this.caseInsensitiveKeys.put(convertKey(key), key);
/*  93 */     if ((oldKey != null) && (!oldKey.equals(key))) {
/*  94 */       super.remove(oldKey);
/*     */     }
/*  96 */     return super.put(key, value);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends V> map)
/*     */   {
/* 101 */     if (map.isEmpty()) {
/* 102 */       return;
/*     */     }
/* 104 */     for (Map.Entry entry : map.entrySet())
/* 105 */       put((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 111 */     return ((key instanceof String)) && (this.caseInsensitiveKeys.containsKey(convertKey((String)key)));
/*     */   }
/*     */ 
/*     */   public V get(Object key)
/*     */   {
/* 116 */     if ((key instanceof String)) {
/* 117 */       return super.get(this.caseInsensitiveKeys.get(convertKey((String)key)));
/*     */     }
/*     */ 
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   public V remove(Object key)
/*     */   {
/* 126 */     if ((key instanceof String)) {
/* 127 */       return super.remove(this.caseInsensitiveKeys.remove(convertKey((String)key)));
/*     */     }
/*     */ 
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 136 */     this.caseInsensitiveKeys.clear();
/* 137 */     super.clear();
/*     */   }
/*     */ 
/*     */   protected String convertKey(String key)
/*     */   {
/* 150 */     return key.toLowerCase(this.locale);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.LinkedCaseInsensitiveMap
 * JD-Core Version:    0.6.2
 */