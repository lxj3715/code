/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class LinkedMultiValueMap<K, V>
/*     */   implements MultiValueMap<K, V>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3801124242820219131L;
/*     */   private final Map<K, List<V>> targetMap;
/*     */ 
/*     */   public LinkedMultiValueMap()
/*     */   {
/*  49 */     this.targetMap = new LinkedHashMap();
/*     */   }
/*     */ 
/*     */   public LinkedMultiValueMap(int initialCapacity)
/*     */   {
/*  58 */     this.targetMap = new LinkedHashMap(initialCapacity);
/*     */   }
/*     */ 
/*     */   public LinkedMultiValueMap(Map<K, List<V>> otherMap)
/*     */   {
/*  67 */     this.targetMap = new LinkedHashMap(otherMap);
/*     */   }
/*     */ 
/*     */   public void add(K key, V value)
/*     */   {
/*  75 */     List values = (List)this.targetMap.get(key);
/*  76 */     if (values == null) {
/*  77 */       values = new LinkedList();
/*  78 */       this.targetMap.put(key, values);
/*     */     }
/*  80 */     values.add(value);
/*     */   }
/*     */ 
/*     */   public V getFirst(K key)
/*     */   {
/*  85 */     List values = (List)this.targetMap.get(key);
/*  86 */     return values != null ? values.get(0) : null;
/*     */   }
/*     */ 
/*     */   public void set(K key, V value)
/*     */   {
/*  91 */     List values = new LinkedList();
/*  92 */     values.add(value);
/*  93 */     this.targetMap.put(key, values);
/*     */   }
/*     */ 
/*     */   public void setAll(Map<K, V> values)
/*     */   {
/*  98 */     for (Map.Entry entry : values.entrySet())
/*  99 */       set(entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public Map<K, V> toSingleValueMap()
/*     */   {
/* 105 */     LinkedHashMap singleValueMap = new LinkedHashMap(this.targetMap.size());
/* 106 */     for (Map.Entry entry : this.targetMap.entrySet()) {
/* 107 */       singleValueMap.put(entry.getKey(), ((List)entry.getValue()).get(0));
/*     */     }
/* 109 */     return singleValueMap;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 117 */     return this.targetMap.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 122 */     return this.targetMap.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 127 */     return this.targetMap.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 132 */     return this.targetMap.containsValue(value);
/*     */   }
/*     */ 
/*     */   public List<V> get(Object key)
/*     */   {
/* 137 */     return (List)this.targetMap.get(key);
/*     */   }
/*     */ 
/*     */   public List<V> put(K key, List<V> value)
/*     */   {
/* 142 */     return (List)this.targetMap.put(key, value);
/*     */   }
/*     */ 
/*     */   public List<V> remove(Object key)
/*     */   {
/* 147 */     return (List)this.targetMap.remove(key);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends K, ? extends List<V>> m)
/*     */   {
/* 152 */     this.targetMap.putAll(m);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 157 */     this.targetMap.clear();
/*     */   }
/*     */ 
/*     */   public Set<K> keySet()
/*     */   {
/* 162 */     return this.targetMap.keySet();
/*     */   }
/*     */ 
/*     */   public Collection<List<V>> values()
/*     */   {
/* 167 */     return this.targetMap.values();
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<K, List<V>>> entrySet()
/*     */   {
/* 172 */     return this.targetMap.entrySet();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 178 */     return this.targetMap.equals(obj);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 183 */     return this.targetMap.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 188 */     return this.targetMap.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.LinkedMultiValueMap
 * JD-Core Version:    0.6.2
 */