/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.net.URL;
/*     */ import org.apache.log4j.LogManager;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ import org.apache.log4j.xml.DOMConfigurator;
/*     */ 
/*     */ public abstract class Log4jConfigurer
/*     */ {
/*     */   public static final String CLASSPATH_URL_PREFIX = "classpath:";
/*     */   public static final String XML_FILE_EXTENSION = ".xml";
/*     */ 
/*     */   public static void initLogging(String location)
/*     */     throws FileNotFoundException
/*     */   {
/*  66 */     String resolvedLocation = SystemPropertyUtils.resolvePlaceholders(location);
/*  67 */     URL url = ResourceUtils.getURL(resolvedLocation);
/*  68 */     if (resolvedLocation.toLowerCase().endsWith(".xml")) {
/*  69 */       DOMConfigurator.configure(url);
/*     */     }
/*     */     else
/*  72 */       PropertyConfigurator.configure(url);
/*     */   }
/*     */ 
/*     */   public static void initLogging(String location, long refreshInterval)
/*     */     throws FileNotFoundException
/*     */   {
/*  96 */     String resolvedLocation = SystemPropertyUtils.resolvePlaceholders(location);
/*  97 */     File file = ResourceUtils.getFile(resolvedLocation);
/*  98 */     if (!file.exists()) {
/*  99 */       throw new FileNotFoundException("Log4j config file [" + resolvedLocation + "] not found");
/*     */     }
/* 101 */     if (resolvedLocation.toLowerCase().endsWith(".xml")) {
/* 102 */       DOMConfigurator.configureAndWatch(file.getAbsolutePath(), refreshInterval);
/*     */     }
/*     */     else
/* 105 */       PropertyConfigurator.configureAndWatch(file.getAbsolutePath(), refreshInterval);
/*     */   }
/*     */ 
/*     */   public static void shutdownLogging()
/*     */   {
/* 116 */     LogManager.shutdown();
/*     */   }
/*     */ 
/*     */   public static void setWorkingDirSystemProperty(String key)
/*     */   {
/* 128 */     System.setProperty(key, new File("").getAbsolutePath());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.Log4jConfigurer
 * JD-Core Version:    0.6.2
 */