/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ public class MethodInvoker
/*     */ {
/*     */   private Class<?> targetClass;
/*     */   private Object targetObject;
/*     */   private String targetMethod;
/*     */   private String staticMethod;
/*  51 */   private Object[] arguments = new Object[0];
/*     */   private Method methodObject;
/*     */ 
/*     */   public void setTargetClass(Class<?> targetClass)
/*     */   {
/*  65 */     this.targetClass = targetClass;
/*     */   }
/*     */ 
/*     */   public Class<?> getTargetClass()
/*     */   {
/*  72 */     return this.targetClass;
/*     */   }
/*     */ 
/*     */   public void setTargetObject(Object targetObject)
/*     */   {
/*  83 */     this.targetObject = targetObject;
/*  84 */     if (targetObject != null)
/*  85 */       this.targetClass = targetObject.getClass();
/*     */   }
/*     */ 
/*     */   public Object getTargetObject()
/*     */   {
/*  93 */     return this.targetObject;
/*     */   }
/*     */ 
/*     */   public void setTargetMethod(String targetMethod)
/*     */   {
/* 104 */     this.targetMethod = targetMethod;
/*     */   }
/*     */ 
/*     */   public String getTargetMethod()
/*     */   {
/* 111 */     return this.targetMethod;
/*     */   }
/*     */ 
/*     */   public void setStaticMethod(String staticMethod)
/*     */   {
/* 122 */     this.staticMethod = staticMethod;
/*     */   }
/*     */ 
/*     */   public void setArguments(Object[] arguments)
/*     */   {
/* 130 */     this.arguments = (arguments != null ? arguments : new Object[0]);
/*     */   }
/*     */ 
/*     */   public Object[] getArguments()
/*     */   {
/* 137 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws ClassNotFoundException, NoSuchMethodException
/*     */   {
/* 148 */     if (this.staticMethod != null) {
/* 149 */       int lastDotIndex = this.staticMethod.lastIndexOf('.');
/* 150 */       if ((lastDotIndex == -1) || (lastDotIndex == this.staticMethod.length())) {
/* 151 */         throw new IllegalArgumentException("staticMethod must be a fully qualified class plus method name: e.g. 'example.MyExampleClass.myExampleMethod'");
/*     */       }
/*     */ 
/* 155 */       String className = this.staticMethod.substring(0, lastDotIndex);
/* 156 */       String methodName = this.staticMethod.substring(lastDotIndex + 1);
/* 157 */       this.targetClass = resolveClassName(className);
/* 158 */       this.targetMethod = methodName;
/*     */     }
/*     */ 
/* 161 */     Class targetClass = getTargetClass();
/* 162 */     String targetMethod = getTargetMethod();
/* 163 */     if (targetClass == null) {
/* 164 */       throw new IllegalArgumentException("Either 'targetClass' or 'targetObject' is required");
/*     */     }
/* 166 */     if (targetMethod == null) {
/* 167 */       throw new IllegalArgumentException("Property 'targetMethod' is required");
/*     */     }
/*     */ 
/* 170 */     Object[] arguments = getArguments();
/* 171 */     Class[] argTypes = new Class[arguments.length];
/* 172 */     for (int i = 0; i < arguments.length; i++) {
/* 173 */       argTypes[i] = (arguments[i] != null ? arguments[i].getClass() : Object.class);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 178 */       this.methodObject = targetClass.getMethod(targetMethod, argTypes);
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/* 182 */       this.methodObject = findMatchingMethod();
/* 183 */       if (this.methodObject == null)
/* 184 */         throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Class<?> resolveClassName(String className)
/*     */     throws ClassNotFoundException
/*     */   {
/* 198 */     return ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   protected Method findMatchingMethod()
/*     */   {
/* 209 */     String targetMethod = getTargetMethod();
/* 210 */     Object[] arguments = getArguments();
/* 211 */     int argCount = arguments.length;
/*     */ 
/* 213 */     Method[] candidates = ReflectionUtils.getAllDeclaredMethods(getTargetClass());
/* 214 */     int minTypeDiffWeight = 2147483647;
/* 215 */     Method matchingMethod = null;
/*     */ 
/* 217 */     for (Method candidate : candidates) {
/* 218 */       if (candidate.getName().equals(targetMethod)) {
/* 219 */         Class[] paramTypes = candidate.getParameterTypes();
/* 220 */         if (paramTypes.length == argCount) {
/* 221 */           int typeDiffWeight = getTypeDifferenceWeight(paramTypes, arguments);
/* 222 */           if (typeDiffWeight < minTypeDiffWeight) {
/* 223 */             minTypeDiffWeight = typeDiffWeight;
/* 224 */             matchingMethod = candidate;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 230 */     return matchingMethod;
/*     */   }
/*     */ 
/*     */   public Method getPreparedMethod()
/*     */     throws IllegalStateException
/*     */   {
/* 242 */     if (this.methodObject == null) {
/* 243 */       throw new IllegalStateException("prepare() must be called prior to invoke() on MethodInvoker");
/*     */     }
/* 245 */     return this.methodObject;
/*     */   }
/*     */ 
/*     */   public boolean isPrepared()
/*     */   {
/* 253 */     return this.methodObject != null;
/*     */   }
/*     */ 
/*     */   public Object invoke()
/*     */     throws InvocationTargetException, IllegalAccessException
/*     */   {
/* 267 */     Object targetObject = getTargetObject();
/* 268 */     Method preparedMethod = getPreparedMethod();
/* 269 */     if ((targetObject == null) && (!Modifier.isStatic(preparedMethod.getModifiers()))) {
/* 270 */       throw new IllegalArgumentException("Target method must not be non-static without a target");
/*     */     }
/* 272 */     ReflectionUtils.makeAccessible(preparedMethod);
/* 273 */     return preparedMethod.invoke(targetObject, getArguments());
/*     */   }
/*     */ 
/*     */   public static int getTypeDifferenceWeight(Class<?>[] paramTypes, Object[] args)
/*     */   {
/* 298 */     int result = 0;
/* 299 */     for (int i = 0; i < paramTypes.length; i++) {
/* 300 */       if (!ClassUtils.isAssignableValue(paramTypes[i], args[i])) {
/* 301 */         return 2147483647;
/*     */       }
/* 303 */       if (args[i] != null) {
/* 304 */         Class paramType = paramTypes[i];
/* 305 */         Class superClass = args[i].getClass().getSuperclass();
/* 306 */         while (superClass != null) {
/* 307 */           if (paramType.equals(superClass)) {
/* 308 */             result += 2;
/* 309 */             superClass = null;
/*     */           }
/* 311 */           else if (ClassUtils.isAssignable(paramType, superClass)) {
/* 312 */             result += 2;
/* 313 */             superClass = superClass.getSuperclass();
/*     */           }
/*     */           else {
/* 316 */             superClass = null;
/*     */           }
/*     */         }
/* 319 */         if (paramType.isInterface()) {
/* 320 */           result += 1;
/*     */         }
/*     */       }
/*     */     }
/* 324 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.MethodInvoker
 * JD-Core Version:    0.6.2
 */