/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ public class MimeType
/*     */   implements Comparable<MimeType>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4085923477777865903L;
/*     */   protected static final String WILDCARD_TYPE = "*";
/*     */   private static final BitSet TOKEN;
/*     */   private static final String PARAM_CHARSET = "charset";
/*     */   private final String type;
/*     */   private final String subtype;
/*     */   private final Map<String, String> parameters;
/*     */ 
/*     */   public MimeType(String type)
/*     */   {
/* 107 */     this(type, "*");
/*     */   }
/*     */ 
/*     */   public MimeType(String type, String subtype)
/*     */   {
/* 118 */     this(type, subtype, Collections.emptyMap());
/*     */   }
/*     */ 
/*     */   public MimeType(String type, String subtype, Charset charSet)
/*     */   {
/* 129 */     this(type, subtype, Collections.singletonMap("charset", charSet.name()));
/*     */   }
/*     */ 
/*     */   public MimeType(MimeType other, Map<String, String> parameters)
/*     */   {
/* 140 */     this(other.getType(), other.getSubtype(), parameters);
/*     */   }
/*     */ 
/*     */   public MimeType(String type, String subtype, Map<String, String> parameters)
/*     */   {
/* 151 */     Assert.hasLength(type, "type must not be empty");
/* 152 */     Assert.hasLength(subtype, "subtype must not be empty");
/* 153 */     checkToken(type);
/* 154 */     checkToken(subtype);
/* 155 */     this.type = type.toLowerCase(Locale.ENGLISH);
/* 156 */     this.subtype = subtype.toLowerCase(Locale.ENGLISH);
/* 157 */     if (!CollectionUtils.isEmpty(parameters)) {
/* 158 */       Map m = new LinkedCaseInsensitiveMap(parameters.size(), Locale.ENGLISH);
/* 159 */       for (Map.Entry entry : parameters.entrySet()) {
/* 160 */         String attribute = (String)entry.getKey();
/* 161 */         String value = (String)entry.getValue();
/* 162 */         checkParameters(attribute, value);
/* 163 */         m.put(attribute, value);
/*     */       }
/* 165 */       this.parameters = Collections.unmodifiableMap(m);
/*     */     }
/*     */     else {
/* 168 */       this.parameters = Collections.emptyMap();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkToken(String token)
/*     */   {
/* 179 */     for (int i = 0; i < token.length(); i++) {
/* 180 */       char ch = token.charAt(i);
/* 181 */       if (!TOKEN.get(ch))
/* 182 */         throw new IllegalArgumentException("Invalid token character '" + ch + "' in token \"" + token + "\"");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void checkParameters(String attribute, String value)
/*     */   {
/* 188 */     Assert.hasLength(attribute, "parameter attribute must not be empty");
/* 189 */     Assert.hasLength(value, "parameter value must not be empty");
/* 190 */     checkToken(attribute);
/* 191 */     if ("charset".equals(attribute)) {
/* 192 */       value = unquote(value);
/* 193 */       Charset.forName(value);
/*     */     }
/* 195 */     else if (!isQuotedString(value)) {
/* 196 */       checkToken(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isQuotedString(String s) {
/* 201 */     if (s.length() < 2) {
/* 202 */       return false;
/*     */     }
/*     */ 
/* 205 */     return ((s.startsWith("\"")) && (s.endsWith("\""))) || ((s.startsWith("'")) && (s.endsWith("'")));
/*     */   }
/*     */ 
/*     */   protected String unquote(String s)
/*     */   {
/* 210 */     if (s == null) {
/* 211 */       return null;
/*     */     }
/* 213 */     return isQuotedString(s) ? s.substring(1, s.length() - 1) : s;
/*     */   }
/*     */ 
/*     */   public boolean isWildcardType()
/*     */   {
/* 221 */     return "*".equals(getType());
/*     */   }
/*     */ 
/*     */   public boolean isWildcardSubtype()
/*     */   {
/* 231 */     return ("*".equals(getSubtype())) || (getSubtype().startsWith("*+"));
/*     */   }
/*     */ 
/*     */   public boolean isConcrete()
/*     */   {
/* 240 */     return (!isWildcardType()) && (!isWildcardSubtype());
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/* 247 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getSubtype()
/*     */   {
/* 254 */     return this.subtype;
/*     */   }
/*     */ 
/*     */   public Charset getCharSet()
/*     */   {
/* 262 */     String charSet = getParameter("charset");
/* 263 */     return charSet != null ? Charset.forName(unquote(charSet)) : null;
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 272 */     return (String)this.parameters.get(name);
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParameters()
/*     */   {
/* 280 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public boolean includes(MimeType other)
/*     */   {
/* 293 */     if (other == null) {
/* 294 */       return false;
/*     */     }
/* 296 */     if (isWildcardType())
/*     */     {
/* 298 */       return true;
/*     */     }
/* 300 */     if (getType().equals(other.getType())) {
/* 301 */       if (getSubtype().equals(other.getSubtype())) {
/* 302 */         return true;
/*     */       }
/* 304 */       if (isWildcardSubtype())
/*     */       {
/* 306 */         int thisPlusIdx = getSubtype().indexOf(43);
/* 307 */         if (thisPlusIdx == -1) {
/* 308 */           return true;
/*     */         }
/*     */ 
/* 312 */         int otherPlusIdx = other.getSubtype().indexOf(43);
/* 313 */         if (otherPlusIdx != -1) {
/* 314 */           String thisSubtypeNoSuffix = getSubtype().substring(0, thisPlusIdx);
/* 315 */           String thisSubtypeSuffix = getSubtype().substring(thisPlusIdx + 1);
/* 316 */           String otherSubtypeSuffix = other.getSubtype().substring(otherPlusIdx + 1);
/* 317 */           if ((thisSubtypeSuffix.equals(otherSubtypeSuffix)) && ("*".equals(thisSubtypeNoSuffix))) {
/* 318 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 324 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isCompatibleWith(MimeType other)
/*     */   {
/* 337 */     if (other == null) {
/* 338 */       return false;
/*     */     }
/* 340 */     if ((isWildcardType()) || (other.isWildcardType())) {
/* 341 */       return true;
/*     */     }
/* 343 */     if (getType().equals(other.getType())) {
/* 344 */       if (getSubtype().equals(other.getSubtype())) {
/* 345 */         return true;
/*     */       }
/*     */ 
/* 348 */       if ((isWildcardSubtype()) || (other.isWildcardSubtype()))
/*     */       {
/* 350 */         int thisPlusIdx = getSubtype().indexOf(43);
/* 351 */         int otherPlusIdx = other.getSubtype().indexOf(43);
/*     */ 
/* 353 */         if ((thisPlusIdx == -1) && (otherPlusIdx == -1)) {
/* 354 */           return true;
/*     */         }
/* 356 */         if ((thisPlusIdx != -1) && (otherPlusIdx != -1)) {
/* 357 */           String thisSubtypeNoSuffix = getSubtype().substring(0, thisPlusIdx);
/* 358 */           String otherSubtypeNoSuffix = other.getSubtype().substring(0, otherPlusIdx);
/*     */ 
/* 360 */           String thisSubtypeSuffix = getSubtype().substring(thisPlusIdx + 1);
/* 361 */           String otherSubtypeSuffix = other.getSubtype().substring(otherPlusIdx + 1);
/*     */ 
/* 363 */           if ((thisSubtypeSuffix.equals(otherSubtypeSuffix)) && (
/* 364 */             ("*"
/* 364 */             .equals(thisSubtypeNoSuffix)) || 
/* 364 */             ("*".equals(otherSubtypeNoSuffix)))) {
/* 365 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 370 */     return false;
/*     */   }
/*     */ 
/*     */   public int compareTo(MimeType other)
/*     */   {
/* 380 */     int comp = getType().compareToIgnoreCase(other.getType());
/* 381 */     if (comp != 0) {
/* 382 */       return comp;
/*     */     }
/* 384 */     comp = getSubtype().compareToIgnoreCase(other.getSubtype());
/* 385 */     if (comp != 0) {
/* 386 */       return comp;
/*     */     }
/* 388 */     comp = getParameters().size() - other.getParameters().size();
/* 389 */     if (comp != 0) {
/* 390 */       return comp;
/*     */     }
/* 392 */     TreeSet thisAttributes = new TreeSet(String.CASE_INSENSITIVE_ORDER);
/* 393 */     thisAttributes.addAll(getParameters().keySet());
/* 394 */     TreeSet otherAttributes = new TreeSet(String.CASE_INSENSITIVE_ORDER);
/* 395 */     otherAttributes.addAll(other.getParameters().keySet());
/* 396 */     Iterator thisAttributesIterator = thisAttributes.iterator();
/* 397 */     Iterator otherAttributesIterator = otherAttributes.iterator();
/* 398 */     while (thisAttributesIterator.hasNext()) {
/* 399 */       String thisAttribute = (String)thisAttributesIterator.next();
/* 400 */       String otherAttribute = (String)otherAttributesIterator.next();
/* 401 */       comp = thisAttribute.compareToIgnoreCase(otherAttribute);
/* 402 */       if (comp != 0) {
/* 403 */         return comp;
/*     */       }
/* 405 */       String thisValue = (String)getParameters().get(thisAttribute);
/* 406 */       String otherValue = (String)other.getParameters().get(otherAttribute);
/* 407 */       if (otherValue == null) {
/* 408 */         otherValue = "";
/*     */       }
/* 410 */       comp = thisValue.compareTo(otherValue);
/* 411 */       if (comp != 0) {
/* 412 */         return comp;
/*     */       }
/*     */     }
/* 415 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 420 */     if (this == other) {
/* 421 */       return true;
/*     */     }
/* 423 */     if (!(other instanceof MimeType)) {
/* 424 */       return false;
/*     */     }
/* 426 */     MimeType otherType = (MimeType)other;
/*     */ 
/* 428 */     return (this.type.equalsIgnoreCase(otherType.type)) && (this.subtype.equalsIgnoreCase(otherType.subtype)) && 
/* 428 */       (this.parameters
/* 428 */       .equals(otherType.parameters));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 433 */     int result = this.type.hashCode();
/* 434 */     result = 31 * result + this.subtype.hashCode();
/* 435 */     result = 31 * result + this.parameters.hashCode();
/* 436 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 441 */     StringBuilder builder = new StringBuilder();
/* 442 */     appendTo(builder);
/* 443 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   protected void appendTo(StringBuilder builder) {
/* 447 */     builder.append(this.type);
/* 448 */     builder.append('/');
/* 449 */     builder.append(this.subtype);
/* 450 */     appendTo(this.parameters, builder);
/*     */   }
/*     */ 
/*     */   private void appendTo(Map<String, String> map, StringBuilder builder) {
/* 454 */     for (Map.Entry entry : map.entrySet()) {
/* 455 */       builder.append(';');
/* 456 */       builder.append((String)entry.getKey());
/* 457 */       builder.append('=');
/* 458 */       builder.append((String)entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static MimeType valueOf(String value)
/*     */   {
/* 469 */     return MimeTypeUtils.parseMimeType(value);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  66 */     BitSet ctl = new BitSet(128);
/*  67 */     for (int i = 0; i <= 31; i++) {
/*  68 */       ctl.set(i);
/*     */     }
/*  70 */     ctl.set(127);
/*     */ 
/*  72 */     BitSet separators = new BitSet(128);
/*  73 */     separators.set(40);
/*  74 */     separators.set(41);
/*  75 */     separators.set(60);
/*  76 */     separators.set(62);
/*  77 */     separators.set(64);
/*  78 */     separators.set(44);
/*  79 */     separators.set(59);
/*  80 */     separators.set(58);
/*  81 */     separators.set(92);
/*  82 */     separators.set(34);
/*  83 */     separators.set(47);
/*  84 */     separators.set(91);
/*  85 */     separators.set(93);
/*  86 */     separators.set(63);
/*  87 */     separators.set(61);
/*  88 */     separators.set(123);
/*  89 */     separators.set(125);
/*  90 */     separators.set(32);
/*  91 */     separators.set(9);
/*     */ 
/*  93 */     TOKEN = new BitSet(128);
/*  94 */     TOKEN.set(0, 128);
/*  95 */     TOKEN.andNot(ctl);
/*  96 */     TOKEN.andNot(separators);
/*     */   }
/*     */ 
/*     */   public static class SpecificityComparator<T extends MimeType>
/*     */     implements Comparator<T>
/*     */   {
/*     */     public int compare(T mimeType1, T mimeType2)
/*     */     {
/* 477 */       if ((mimeType1.isWildcardType()) && (!mimeType2.isWildcardType())) {
/* 478 */         return 1;
/*     */       }
/* 480 */       if ((mimeType2.isWildcardType()) && (!mimeType1.isWildcardType())) {
/* 481 */         return -1;
/*     */       }
/* 483 */       if (!mimeType1.getType().equals(mimeType2.getType())) {
/* 484 */         return 0;
/*     */       }
/*     */ 
/* 487 */       if ((mimeType1.isWildcardSubtype()) && (!mimeType2.isWildcardSubtype())) {
/* 488 */         return 1;
/*     */       }
/* 490 */       if ((mimeType2.isWildcardSubtype()) && (!mimeType1.isWildcardSubtype())) {
/* 491 */         return -1;
/*     */       }
/* 493 */       if (!mimeType1.getSubtype().equals(mimeType2.getSubtype())) {
/* 494 */         return 0;
/*     */       }
/*     */ 
/* 497 */       return compareParameters(mimeType1, mimeType2);
/*     */     }
/*     */ 
/*     */     protected int compareParameters(T mimeType1, T mimeType2)
/*     */     {
/* 503 */       int paramsSize1 = mimeType1.getParameters().size();
/* 504 */       int paramsSize2 = mimeType2.getParameters().size();
/* 505 */       return paramsSize2 == paramsSize1 ? 0 : paramsSize2 < paramsSize1 ? -1 : 1;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.MimeType
 * JD-Core Version:    0.6.2
 */