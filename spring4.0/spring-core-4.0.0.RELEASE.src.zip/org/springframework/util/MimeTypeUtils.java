/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class MimeTypeUtils
/*     */ {
/* 182 */   public static final MimeType ALL = MimeType.valueOf("*/*");
/*     */   public static final String ALL_VALUE = "*/*";
/* 183 */   public static final MimeType APPLICATION_ATOM_XML = MimeType.valueOf("application/atom+xml");
/*     */   public static final String APPLICATION_ATOM_XML_VALUE = "application/atom+xml";
/* 184 */   public static final MimeType APPLICATION_FORM_URLENCODED = MimeType.valueOf("application/x-www-form-urlencoded");
/*     */   public static final String APPLICATION_FORM_URLENCODED_VALUE = "application/x-www-form-urlencoded";
/* 185 */   public static final MimeType APPLICATION_JSON = MimeType.valueOf("application/json");
/*     */   public static final String APPLICATION_JSON_VALUE = "application/json";
/* 186 */   public static final MimeType APPLICATION_OCTET_STREAM = MimeType.valueOf("application/octet-stream");
/*     */   public static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream";
/* 187 */   public static final MimeType APPLICATION_XHTML_XML = MimeType.valueOf("application/xhtml+xml");
/*     */   public static final String APPLICATION_XHTML_XML_VALUE = "application/xhtml+xml";
/* 188 */   public static final MimeType APPLICATION_XML = MimeType.valueOf("application/xml");
/*     */   public static final String APPLICATION_XML_VALUE = "application/xml";
/* 189 */   public static final MimeType IMAGE_GIF = MimeType.valueOf("image/gif");
/*     */   public static final String IMAGE_GIF_VALUE = "image/gif";
/* 190 */   public static final MimeType IMAGE_JPEG = MimeType.valueOf("image/jpeg");
/*     */   public static final String IMAGE_JPEG_VALUE = "image/jpeg";
/* 191 */   public static final MimeType IMAGE_PNG = MimeType.valueOf("image/png");
/*     */   public static final String IMAGE_PNG_VALUE = "image/png";
/* 192 */   public static final MimeType MULTIPART_FORM_DATA = MimeType.valueOf("multipart/form-data");
/*     */   public static final String MULTIPART_FORM_DATA_VALUE = "multipart/form-data";
/* 193 */   public static final MimeType TEXT_HTML = MimeType.valueOf("text/html");
/*     */   public static final String TEXT_HTML_VALUE = "text/html";
/* 194 */   public static final MimeType TEXT_PLAIN = MimeType.valueOf("text/plain");
/*     */   public static final String TEXT_PLAIN_VALUE = "text/plain";
/* 195 */   public static final MimeType TEXT_XML = MimeType.valueOf("text/xml");
/*     */   public static final String TEXT_XML_VALUE = "text/xml";
/* 326 */   public static final Comparator<MimeType> SPECIFICITY_COMPARATOR = new MimeType.SpecificityComparator();
/*     */ 
/*     */   public static MimeType parseMimeType(String mimeType)
/*     */   {
/* 206 */     if (!StringUtils.hasLength(mimeType)) {
/* 207 */       throw new InvalidMimeTypeException(mimeType, "'mimeType' must not be empty");
/*     */     }
/* 209 */     String[] parts = StringUtils.tokenizeToStringArray(mimeType, ";");
/*     */ 
/* 211 */     String fullType = parts[0].trim();
/*     */ 
/* 213 */     if ("*".equals(fullType)) {
/* 214 */       fullType = "*/*";
/*     */     }
/* 216 */     int subIndex = fullType.indexOf('/');
/* 217 */     if (subIndex == -1) {
/* 218 */       throw new InvalidMimeTypeException(mimeType, "does not contain '/'");
/*     */     }
/* 220 */     if (subIndex == fullType.length() - 1) {
/* 221 */       throw new InvalidMimeTypeException(mimeType, "does not contain subtype after '/'");
/*     */     }
/* 223 */     String type = fullType.substring(0, subIndex);
/* 224 */     String subtype = fullType.substring(subIndex + 1, fullType.length());
/* 225 */     if (("*".equals(type)) && (!"*".equals(subtype))) {
/* 226 */       throw new InvalidMimeTypeException(mimeType, "wildcard type is legal only in '*/*' (all mime types)");
/*     */     }
/*     */ 
/* 229 */     Map parameters = null;
/* 230 */     if (parts.length > 1) {
/* 231 */       parameters = new LinkedHashMap(parts.length - 1);
/* 232 */       for (int i = 1; i < parts.length; i++) {
/* 233 */         String parameter = parts[i];
/* 234 */         int eqIndex = parameter.indexOf('=');
/* 235 */         if (eqIndex != -1) {
/* 236 */           String attribute = parameter.substring(0, eqIndex);
/* 237 */           String value = parameter.substring(eqIndex + 1, parameter.length());
/* 238 */           parameters.put(attribute, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 244 */       return new MimeType(type, subtype, parameters);
/*     */     }
/*     */     catch (UnsupportedCharsetException ex) {
/* 247 */       throw new InvalidMimeTypeException(mimeType, new StringBuilder().append("unsupported charset '").append(ex.getCharsetName()).append("'").toString());
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 250 */       throw new InvalidMimeTypeException(mimeType, ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static List<MimeType> parseMimeTypes(String mimeTypes)
/*     */   {
/* 261 */     if (!StringUtils.hasLength(mimeTypes)) {
/* 262 */       return Collections.emptyList();
/*     */     }
/* 264 */     String[] tokens = mimeTypes.split(",\\s*");
/* 265 */     List result = new ArrayList(tokens.length);
/* 266 */     for (String token : tokens) {
/* 267 */       result.add(parseMimeType(token));
/*     */     }
/* 269 */     return result;
/*     */   }
/*     */ 
/*     */   public static String toString(Collection<? extends MimeType> mimeTypes)
/*     */   {
/* 279 */     StringBuilder builder = new StringBuilder();
/* 280 */     for (Iterator iterator = mimeTypes.iterator(); iterator.hasNext(); ) {
/* 281 */       MimeType mimeType = (MimeType)iterator.next();
/* 282 */       mimeType.appendTo(builder);
/* 283 */       if (iterator.hasNext()) {
/* 284 */         builder.append(", ");
/*     */       }
/*     */     }
/* 287 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificity(List<MimeType> mimeTypes)
/*     */   {
/* 316 */     Assert.notNull(mimeTypes, "'mimeTypes' must not be null");
/* 317 */     if (mimeTypes.size() > 1)
/* 318 */       Collections.sort(mimeTypes, SPECIFICITY_COMPARATOR);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.MimeTypeUtils
 * JD-Core Version:    0.6.2
 */