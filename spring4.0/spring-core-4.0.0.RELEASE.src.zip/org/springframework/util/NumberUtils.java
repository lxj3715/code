/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ 
/*     */ public abstract class NumberUtils
/*     */ {
/*     */   public static <T extends Number> T convertNumberToTargetClass(Number number, Class<T> targetClass)
/*     */     throws IllegalArgumentException
/*     */   {
/*  56 */     Assert.notNull(number, "Number must not be null");
/*  57 */     Assert.notNull(targetClass, "Target class must not be null");
/*     */ 
/*  59 */     if (targetClass.isInstance(number)) {
/*  60 */       return number;
/*     */     }
/*  62 */     if (targetClass.equals(Byte.class)) {
/*  63 */       long value = number.longValue();
/*  64 */       if ((value < -128L) || (value > 127L)) {
/*  65 */         raiseOverflowException(number, targetClass);
/*     */       }
/*  67 */       return new Byte(number.byteValue());
/*     */     }
/*  69 */     if (targetClass.equals(Short.class)) {
/*  70 */       long value = number.longValue();
/*  71 */       if ((value < -32768L) || (value > 32767L)) {
/*  72 */         raiseOverflowException(number, targetClass);
/*     */       }
/*  74 */       return new Short(number.shortValue());
/*     */     }
/*  76 */     if (targetClass.equals(Integer.class)) {
/*  77 */       long value = number.longValue();
/*  78 */       if ((value < -2147483648L) || (value > 2147483647L)) {
/*  79 */         raiseOverflowException(number, targetClass);
/*     */       }
/*  81 */       return new Integer(number.intValue());
/*     */     }
/*  83 */     if (targetClass.equals(Long.class)) {
/*  84 */       return new Long(number.longValue());
/*     */     }
/*  86 */     if (targetClass.equals(BigInteger.class)) {
/*  87 */       if ((number instanceof BigDecimal))
/*     */       {
/*  89 */         return ((BigDecimal)number).toBigInteger();
/*     */       }
/*     */ 
/*  93 */       return BigInteger.valueOf(number.longValue());
/*     */     }
/*     */ 
/*  96 */     if (targetClass.equals(Float.class)) {
/*  97 */       return new Float(number.floatValue());
/*     */     }
/*  99 */     if (targetClass.equals(Double.class)) {
/* 100 */       return new Double(number.doubleValue());
/*     */     }
/* 102 */     if (targetClass.equals(BigDecimal.class))
/*     */     {
/* 105 */       return new BigDecimal(number.toString());
/*     */     }
/*     */ 
/* 109 */     throw new IllegalArgumentException("Could not convert number [" + number + "] of type [" + number
/* 109 */       .getClass().getName() + "] to unknown target class [" + targetClass.getName() + "]");
/*     */   }
/*     */ 
/*     */   private static void raiseOverflowException(Number number, Class<?> targetClass)
/*     */   {
/* 120 */     throw new IllegalArgumentException("Could not convert number [" + number + "] of type [" + number
/* 120 */       .getClass().getName() + "] to target class [" + targetClass.getName() + "]: overflow");
/*     */   }
/*     */ 
/*     */   public static <T extends Number> T parseNumber(String text, Class<T> targetClass)
/*     */   {
/* 144 */     Assert.notNull(text, "Text must not be null");
/* 145 */     Assert.notNull(targetClass, "Target class must not be null");
/* 146 */     String trimmed = StringUtils.trimAllWhitespace(text);
/*     */ 
/* 148 */     if (targetClass.equals(Byte.class)) {
/* 149 */       return isHexNumber(trimmed) ? Byte.decode(trimmed) : Byte.valueOf(trimmed);
/*     */     }
/* 151 */     if (targetClass.equals(Short.class)) {
/* 152 */       return isHexNumber(trimmed) ? Short.decode(trimmed) : Short.valueOf(trimmed);
/*     */     }
/* 154 */     if (targetClass.equals(Integer.class)) {
/* 155 */       return isHexNumber(trimmed) ? Integer.decode(trimmed) : Integer.valueOf(trimmed);
/*     */     }
/* 157 */     if (targetClass.equals(Long.class)) {
/* 158 */       return isHexNumber(trimmed) ? Long.decode(trimmed) : Long.valueOf(trimmed);
/*     */     }
/* 160 */     if (targetClass.equals(BigInteger.class)) {
/* 161 */       return isHexNumber(trimmed) ? decodeBigInteger(trimmed) : new BigInteger(trimmed);
/*     */     }
/* 163 */     if (targetClass.equals(Float.class)) {
/* 164 */       return Float.valueOf(trimmed);
/*     */     }
/* 166 */     if (targetClass.equals(Double.class)) {
/* 167 */       return Double.valueOf(trimmed);
/*     */     }
/* 169 */     if ((targetClass.equals(BigDecimal.class)) || (targetClass.equals(Number.class))) {
/* 170 */       return new BigDecimal(trimmed);
/*     */     }
/*     */ 
/* 174 */     throw new IllegalArgumentException("Cannot convert String [" + text + "] to target class [" + targetClass
/* 174 */       .getName() + "]");
/*     */   }
/*     */ 
/*     */   public static <T extends Number> T parseNumber(String text, Class<T> targetClass, NumberFormat numberFormat)
/*     */   {
/* 194 */     if (numberFormat != null) {
/* 195 */       Assert.notNull(text, "Text must not be null");
/* 196 */       Assert.notNull(targetClass, "Target class must not be null");
/* 197 */       DecimalFormat decimalFormat = null;
/* 198 */       boolean resetBigDecimal = false;
/* 199 */       if ((numberFormat instanceof DecimalFormat)) {
/* 200 */         decimalFormat = (DecimalFormat)numberFormat;
/* 201 */         if ((BigDecimal.class.equals(targetClass)) && (!decimalFormat.isParseBigDecimal())) {
/* 202 */           decimalFormat.setParseBigDecimal(true);
/* 203 */           resetBigDecimal = true;
/*     */         }
/*     */       }
/*     */       try {
/* 207 */         Number number = numberFormat.parse(StringUtils.trimAllWhitespace(text));
/* 208 */         return convertNumberToTargetClass(number, targetClass);
/*     */       }
/*     */       catch (ParseException ex) {
/* 211 */         throw new IllegalArgumentException("Could not parse number: " + ex.getMessage());
/*     */       }
/*     */       finally {
/* 214 */         if (resetBigDecimal) {
/* 215 */           decimalFormat.setParseBigDecimal(false);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 220 */     return parseNumber(text, targetClass);
/*     */   }
/*     */ 
/*     */   private static boolean isHexNumber(String value)
/*     */   {
/* 229 */     int index = value.startsWith("-") ? 1 : 0;
/* 230 */     return (value.startsWith("0x", index)) || (value.startsWith("0X", index)) || (value.startsWith("#", index));
/*     */   }
/*     */ 
/*     */   private static BigInteger decodeBigInteger(String value)
/*     */   {
/* 239 */     int radix = 10;
/* 240 */     int index = 0;
/* 241 */     boolean negative = false;
/*     */ 
/* 244 */     if (value.startsWith("-")) {
/* 245 */       negative = true;
/* 246 */       index++;
/*     */     }
/*     */ 
/* 250 */     if ((value.startsWith("0x", index)) || (value.startsWith("0X", index))) {
/* 251 */       index += 2;
/* 252 */       radix = 16;
/*     */     }
/* 254 */     else if (value.startsWith("#", index)) {
/* 255 */       index++;
/* 256 */       radix = 16;
/*     */     }
/* 258 */     else if ((value.startsWith("0", index)) && (value.length() > 1 + index)) {
/* 259 */       index++;
/* 260 */       radix = 8;
/*     */     }
/*     */ 
/* 263 */     BigInteger result = new BigInteger(value.substring(index), radix);
/* 264 */     return negative ? result.negate() : result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.NumberUtils
 * JD-Core Version:    0.6.2
 */