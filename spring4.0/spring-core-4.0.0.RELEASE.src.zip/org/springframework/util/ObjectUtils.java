/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public abstract class ObjectUtils
/*     */ {
/*     */   private static final int INITIAL_HASH = 7;
/*     */   private static final int MULTIPLIER = 31;
/*     */   private static final String EMPTY_STRING = "";
/*     */   private static final String NULL_STRING = "null";
/*     */   private static final String ARRAY_START = "{";
/*     */   private static final String ARRAY_END = "}";
/*     */   private static final String EMPTY_ARRAY = "{}";
/*     */   private static final String ARRAY_ELEMENT_SEPARATOR = ", ";
/*     */ 
/*     */   public static boolean isCheckedException(Throwable ex)
/*     */   {
/*  62 */     return (!(ex instanceof RuntimeException)) && (!(ex instanceof Error));
/*     */   }
/*     */ 
/*     */   public static boolean isCompatibleWithThrowsClause(Throwable ex, Class<?>[] declaredExceptions)
/*     */   {
/*  73 */     if (!isCheckedException(ex)) {
/*  74 */       return true;
/*     */     }
/*  76 */     if (declaredExceptions != null) {
/*  77 */       int i = 0;
/*  78 */       while (i < declaredExceptions.length) {
/*  79 */         if (declaredExceptions[i].isAssignableFrom(ex.getClass())) {
/*  80 */           return true;
/*     */         }
/*  82 */         i++;
/*     */       }
/*     */     }
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isArray(Object obj)
/*     */   {
/*  94 */     return (obj != null) && (obj.getClass().isArray());
/*     */   }
/*     */ 
/*     */   public static boolean isEmpty(Object[] array)
/*     */   {
/* 103 */     return (array == null) || (array.length == 0);
/*     */   }
/*     */ 
/*     */   public static boolean containsElement(Object[] array, Object element)
/*     */   {
/* 114 */     if (array == null) {
/* 115 */       return false;
/*     */     }
/* 117 */     for (Object arrayEle : array) {
/* 118 */       if (nullSafeEquals(arrayEle, element)) {
/* 119 */         return true;
/*     */       }
/*     */     }
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean containsConstant(Enum<?>[] enumValues, String constant)
/*     */   {
/* 133 */     return containsConstant(enumValues, constant, false);
/*     */   }
/*     */ 
/*     */   public static boolean containsConstant(Enum<?>[] enumValues, String constant, boolean caseSensitive)
/*     */   {
/* 144 */     for (Enum candidate : enumValues) {
/* 145 */       if (caseSensitive ? candidate
/* 146 */         .toString().equals(constant) : candidate
/* 147 */         .toString().equalsIgnoreCase(constant)) {
/* 148 */         return true;
/*     */       }
/*     */     }
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   public static <E extends Enum<?>> E caseInsensitiveValueOf(E[] enumValues, String constant)
/*     */   {
/* 163 */     for (Enum candidate : enumValues) {
/* 164 */       if (candidate.toString().equalsIgnoreCase(constant)) {
/* 165 */         return candidate;
/*     */       }
/*     */     }
/*     */ 
/* 169 */     throw new IllegalArgumentException(
/* 169 */       String.format("constant [%s] does not exist in enum type %s", new Object[] { constant, enumValues
/* 170 */       .getClass().getComponentType().getName() }));
/*     */   }
/*     */ 
/*     */   public static <A, O extends A> A[] addObjectToArray(A[] array, O obj)
/*     */   {
/* 181 */     Class compType = Object.class;
/* 182 */     if (array != null) {
/* 183 */       compType = array.getClass().getComponentType();
/*     */     }
/* 185 */     else if (obj != null) {
/* 186 */       compType = obj.getClass();
/*     */     }
/* 188 */     int newArrLength = array != null ? array.length + 1 : 1;
/*     */ 
/* 190 */     Object[] newArr = (Object[])Array.newInstance(compType, newArrLength);
/* 191 */     if (array != null) {
/* 192 */       System.arraycopy(array, 0, newArr, 0, array.length);
/*     */     }
/* 194 */     newArr[(newArr.length - 1)] = obj;
/* 195 */     return newArr;
/*     */   }
/*     */ 
/*     */   public static Object[] toObjectArray(Object source)
/*     */   {
/* 208 */     if ((source instanceof Object[])) {
/* 209 */       return (Object[])source;
/*     */     }
/* 211 */     if (source == null) {
/* 212 */       return new Object[0];
/*     */     }
/* 214 */     if (!source.getClass().isArray()) {
/* 215 */       throw new IllegalArgumentException(new StringBuilder().append("Source is not an array: ").append(source).toString());
/*     */     }
/* 217 */     int length = Array.getLength(source);
/* 218 */     if (length == 0) {
/* 219 */       return new Object[0];
/*     */     }
/* 221 */     Class wrapperType = Array.get(source, 0).getClass();
/* 222 */     Object[] newArray = (Object[])Array.newInstance(wrapperType, length);
/* 223 */     for (int i = 0; i < length; i++) {
/* 224 */       newArray[i] = Array.get(source, i);
/*     */     }
/* 226 */     return newArray;
/*     */   }
/*     */ 
/*     */   public static boolean nullSafeEquals(Object o1, Object o2)
/*     */   {
/* 246 */     if (o1 == o2) {
/* 247 */       return true;
/*     */     }
/* 249 */     if ((o1 == null) || (o2 == null)) {
/* 250 */       return false;
/*     */     }
/* 252 */     if (o1.equals(o2)) {
/* 253 */       return true;
/*     */     }
/* 255 */     if ((o1.getClass().isArray()) && (o2.getClass().isArray())) {
/* 256 */       if (((o1 instanceof Object[])) && ((o2 instanceof Object[]))) {
/* 257 */         return Arrays.equals((Object[])o1, (Object[])o2);
/*     */       }
/* 259 */       if (((o1 instanceof boolean[])) && ((o2 instanceof boolean[]))) {
/* 260 */         return Arrays.equals((boolean[])o1, (boolean[])o2);
/*     */       }
/* 262 */       if (((o1 instanceof byte[])) && ((o2 instanceof byte[]))) {
/* 263 */         return Arrays.equals((byte[])o1, (byte[])o2);
/*     */       }
/* 265 */       if (((o1 instanceof char[])) && ((o2 instanceof char[]))) {
/* 266 */         return Arrays.equals((char[])o1, (char[])o2);
/*     */       }
/* 268 */       if (((o1 instanceof double[])) && ((o2 instanceof double[]))) {
/* 269 */         return Arrays.equals((double[])o1, (double[])o2);
/*     */       }
/* 271 */       if (((o1 instanceof float[])) && ((o2 instanceof float[]))) {
/* 272 */         return Arrays.equals((float[])o1, (float[])o2);
/*     */       }
/* 274 */       if (((o1 instanceof int[])) && ((o2 instanceof int[]))) {
/* 275 */         return Arrays.equals((int[])o1, (int[])o2);
/*     */       }
/* 277 */       if (((o1 instanceof long[])) && ((o2 instanceof long[]))) {
/* 278 */         return Arrays.equals((long[])o1, (long[])o2);
/*     */       }
/* 280 */       if (((o1 instanceof short[])) && ((o2 instanceof short[]))) {
/* 281 */         return Arrays.equals((short[])o1, (short[])o2);
/*     */       }
/*     */     }
/* 284 */     return false;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(Object obj)
/*     */   {
/* 304 */     if (obj == null) {
/* 305 */       return 0;
/*     */     }
/* 307 */     if (obj.getClass().isArray()) {
/* 308 */       if ((obj instanceof Object[])) {
/* 309 */         return nullSafeHashCode((Object[])obj);
/*     */       }
/* 311 */       if ((obj instanceof boolean[])) {
/* 312 */         return nullSafeHashCode((boolean[])obj);
/*     */       }
/* 314 */       if ((obj instanceof byte[])) {
/* 315 */         return nullSafeHashCode((byte[])obj);
/*     */       }
/* 317 */       if ((obj instanceof char[])) {
/* 318 */         return nullSafeHashCode((char[])obj);
/*     */       }
/* 320 */       if ((obj instanceof double[])) {
/* 321 */         return nullSafeHashCode((double[])obj);
/*     */       }
/* 323 */       if ((obj instanceof float[])) {
/* 324 */         return nullSafeHashCode((float[])obj);
/*     */       }
/* 326 */       if ((obj instanceof int[])) {
/* 327 */         return nullSafeHashCode((int[])obj);
/*     */       }
/* 329 */       if ((obj instanceof long[])) {
/* 330 */         return nullSafeHashCode((long[])obj);
/*     */       }
/* 332 */       if ((obj instanceof short[])) {
/* 333 */         return nullSafeHashCode((short[])obj);
/*     */       }
/*     */     }
/* 336 */     return obj.hashCode();
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(Object[] array)
/*     */   {
/* 344 */     if (array == null) {
/* 345 */       return 0;
/*     */     }
/* 347 */     int hash = 7;
/* 348 */     int arraySize = array.length;
/* 349 */     for (int i = 0; i < arraySize; i++) {
/* 350 */       hash = 31 * hash + nullSafeHashCode(array[i]);
/*     */     }
/* 352 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(boolean[] array)
/*     */   {
/* 360 */     if (array == null) {
/* 361 */       return 0;
/*     */     }
/* 363 */     int hash = 7;
/* 364 */     int arraySize = array.length;
/* 365 */     for (int i = 0; i < arraySize; i++) {
/* 366 */       hash = 31 * hash + hashCode(array[i]);
/*     */     }
/* 368 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(byte[] array)
/*     */   {
/* 376 */     if (array == null) {
/* 377 */       return 0;
/*     */     }
/* 379 */     int hash = 7;
/* 380 */     int arraySize = array.length;
/* 381 */     for (int i = 0; i < arraySize; i++) {
/* 382 */       hash = 31 * hash + array[i];
/*     */     }
/* 384 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(char[] array)
/*     */   {
/* 392 */     if (array == null) {
/* 393 */       return 0;
/*     */     }
/* 395 */     int hash = 7;
/* 396 */     int arraySize = array.length;
/* 397 */     for (int i = 0; i < arraySize; i++) {
/* 398 */       hash = 31 * hash + array[i];
/*     */     }
/* 400 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(double[] array)
/*     */   {
/* 408 */     if (array == null) {
/* 409 */       return 0;
/*     */     }
/* 411 */     int hash = 7;
/* 412 */     int arraySize = array.length;
/* 413 */     for (int i = 0; i < arraySize; i++) {
/* 414 */       hash = 31 * hash + hashCode(array[i]);
/*     */     }
/* 416 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(float[] array)
/*     */   {
/* 424 */     if (array == null) {
/* 425 */       return 0;
/*     */     }
/* 427 */     int hash = 7;
/* 428 */     int arraySize = array.length;
/* 429 */     for (int i = 0; i < arraySize; i++) {
/* 430 */       hash = 31 * hash + hashCode(array[i]);
/*     */     }
/* 432 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(int[] array)
/*     */   {
/* 440 */     if (array == null) {
/* 441 */       return 0;
/*     */     }
/* 443 */     int hash = 7;
/* 444 */     int arraySize = array.length;
/* 445 */     for (int i = 0; i < arraySize; i++) {
/* 446 */       hash = 31 * hash + array[i];
/*     */     }
/* 448 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(long[] array)
/*     */   {
/* 456 */     if (array == null) {
/* 457 */       return 0;
/*     */     }
/* 459 */     int hash = 7;
/* 460 */     int arraySize = array.length;
/* 461 */     for (int i = 0; i < arraySize; i++) {
/* 462 */       hash = 31 * hash + hashCode(array[i]);
/*     */     }
/* 464 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int nullSafeHashCode(short[] array)
/*     */   {
/* 472 */     if (array == null) {
/* 473 */       return 0;
/*     */     }
/* 475 */     int hash = 7;
/* 476 */     int arraySize = array.length;
/* 477 */     for (int i = 0; i < arraySize; i++) {
/* 478 */       hash = 31 * hash + array[i];
/*     */     }
/* 480 */     return hash;
/*     */   }
/*     */ 
/*     */   public static int hashCode(boolean bool)
/*     */   {
/* 488 */     return bool ? 1231 : 1237;
/*     */   }
/*     */ 
/*     */   public static int hashCode(double dbl)
/*     */   {
/* 496 */     long bits = Double.doubleToLongBits(dbl);
/* 497 */     return hashCode(bits);
/*     */   }
/*     */ 
/*     */   public static int hashCode(float flt)
/*     */   {
/* 505 */     return Float.floatToIntBits(flt);
/*     */   }
/*     */ 
/*     */   public static int hashCode(long lng)
/*     */   {
/* 513 */     return (int)(lng ^ lng >>> 32);
/*     */   }
/*     */ 
/*     */   public static String identityToString(Object obj)
/*     */   {
/* 528 */     if (obj == null) {
/* 529 */       return "";
/*     */     }
/* 531 */     return new StringBuilder().append(obj.getClass().getName()).append("@").append(getIdentityHexString(obj)).toString();
/*     */   }
/*     */ 
/*     */   public static String getIdentityHexString(Object obj)
/*     */   {
/* 540 */     return Integer.toHexString(System.identityHashCode(obj));
/*     */   }
/*     */ 
/*     */   public static String getDisplayString(Object obj)
/*     */   {
/* 553 */     if (obj == null) {
/* 554 */       return "";
/*     */     }
/* 556 */     return nullSafeToString(obj);
/*     */   }
/*     */ 
/*     */   public static String nullSafeClassName(Object obj)
/*     */   {
/* 566 */     return obj != null ? obj.getClass().getName() : "null";
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(Object obj)
/*     */   {
/* 577 */     if (obj == null) {
/* 578 */       return "null";
/*     */     }
/* 580 */     if ((obj instanceof String)) {
/* 581 */       return (String)obj;
/*     */     }
/* 583 */     if ((obj instanceof Object[])) {
/* 584 */       return nullSafeToString((Object[])obj);
/*     */     }
/* 586 */     if ((obj instanceof boolean[])) {
/* 587 */       return nullSafeToString((boolean[])obj);
/*     */     }
/* 589 */     if ((obj instanceof byte[])) {
/* 590 */       return nullSafeToString((byte[])obj);
/*     */     }
/* 592 */     if ((obj instanceof char[])) {
/* 593 */       return nullSafeToString((char[])obj);
/*     */     }
/* 595 */     if ((obj instanceof double[])) {
/* 596 */       return nullSafeToString((double[])obj);
/*     */     }
/* 598 */     if ((obj instanceof float[])) {
/* 599 */       return nullSafeToString((float[])obj);
/*     */     }
/* 601 */     if ((obj instanceof int[])) {
/* 602 */       return nullSafeToString((int[])obj);
/*     */     }
/* 604 */     if ((obj instanceof long[])) {
/* 605 */       return nullSafeToString((long[])obj);
/*     */     }
/* 607 */     if ((obj instanceof short[])) {
/* 608 */       return nullSafeToString((short[])obj);
/*     */     }
/* 610 */     String str = obj.toString();
/* 611 */     return str != null ? str : "";
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(Object[] array)
/*     */   {
/* 624 */     if (array == null) {
/* 625 */       return "null";
/*     */     }
/* 627 */     int length = array.length;
/* 628 */     if (length == 0) {
/* 629 */       return "{}";
/*     */     }
/* 631 */     StringBuilder sb = new StringBuilder();
/* 632 */     for (int i = 0; i < length; i++) {
/* 633 */       if (i == 0) {
/* 634 */         sb.append("{");
/*     */       }
/*     */       else {
/* 637 */         sb.append(", ");
/*     */       }
/* 639 */       sb.append(String.valueOf(array[i]));
/*     */     }
/* 641 */     sb.append("}");
/* 642 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(boolean[] array)
/*     */   {
/* 655 */     if (array == null) {
/* 656 */       return "null";
/*     */     }
/* 658 */     int length = array.length;
/* 659 */     if (length == 0) {
/* 660 */       return "{}";
/*     */     }
/* 662 */     StringBuilder sb = new StringBuilder();
/* 663 */     for (int i = 0; i < length; i++) {
/* 664 */       if (i == 0) {
/* 665 */         sb.append("{");
/*     */       }
/*     */       else {
/* 668 */         sb.append(", ");
/*     */       }
/*     */ 
/* 671 */       sb.append(array[i]);
/*     */     }
/* 673 */     sb.append("}");
/* 674 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(byte[] array)
/*     */   {
/* 687 */     if (array == null) {
/* 688 */       return "null";
/*     */     }
/* 690 */     int length = array.length;
/* 691 */     if (length == 0) {
/* 692 */       return "{}";
/*     */     }
/* 694 */     StringBuilder sb = new StringBuilder();
/* 695 */     for (int i = 0; i < length; i++) {
/* 696 */       if (i == 0) {
/* 697 */         sb.append("{");
/*     */       }
/*     */       else {
/* 700 */         sb.append(", ");
/*     */       }
/* 702 */       sb.append(array[i]);
/*     */     }
/* 704 */     sb.append("}");
/* 705 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(char[] array)
/*     */   {
/* 718 */     if (array == null) {
/* 719 */       return "null";
/*     */     }
/* 721 */     int length = array.length;
/* 722 */     if (length == 0) {
/* 723 */       return "{}";
/*     */     }
/* 725 */     StringBuilder sb = new StringBuilder();
/* 726 */     for (int i = 0; i < length; i++) {
/* 727 */       if (i == 0) {
/* 728 */         sb.append("{");
/*     */       }
/*     */       else {
/* 731 */         sb.append(", ");
/*     */       }
/* 733 */       sb.append("'").append(array[i]).append("'");
/*     */     }
/* 735 */     sb.append("}");
/* 736 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(double[] array)
/*     */   {
/* 749 */     if (array == null) {
/* 750 */       return "null";
/*     */     }
/* 752 */     int length = array.length;
/* 753 */     if (length == 0) {
/* 754 */       return "{}";
/*     */     }
/* 756 */     StringBuilder sb = new StringBuilder();
/* 757 */     for (int i = 0; i < length; i++) {
/* 758 */       if (i == 0) {
/* 759 */         sb.append("{");
/*     */       }
/*     */       else {
/* 762 */         sb.append(", ");
/*     */       }
/*     */ 
/* 765 */       sb.append(array[i]);
/*     */     }
/* 767 */     sb.append("}");
/* 768 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(float[] array)
/*     */   {
/* 781 */     if (array == null) {
/* 782 */       return "null";
/*     */     }
/* 784 */     int length = array.length;
/* 785 */     if (length == 0) {
/* 786 */       return "{}";
/*     */     }
/* 788 */     StringBuilder sb = new StringBuilder();
/* 789 */     for (int i = 0; i < length; i++) {
/* 790 */       if (i == 0) {
/* 791 */         sb.append("{");
/*     */       }
/*     */       else {
/* 794 */         sb.append(", ");
/*     */       }
/*     */ 
/* 797 */       sb.append(array[i]);
/*     */     }
/* 799 */     sb.append("}");
/* 800 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(int[] array)
/*     */   {
/* 813 */     if (array == null) {
/* 814 */       return "null";
/*     */     }
/* 816 */     int length = array.length;
/* 817 */     if (length == 0) {
/* 818 */       return "{}";
/*     */     }
/* 820 */     StringBuilder sb = new StringBuilder();
/* 821 */     for (int i = 0; i < length; i++) {
/* 822 */       if (i == 0) {
/* 823 */         sb.append("{");
/*     */       }
/*     */       else {
/* 826 */         sb.append(", ");
/*     */       }
/* 828 */       sb.append(array[i]);
/*     */     }
/* 830 */     sb.append("}");
/* 831 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(long[] array)
/*     */   {
/* 844 */     if (array == null) {
/* 845 */       return "null";
/*     */     }
/* 847 */     int length = array.length;
/* 848 */     if (length == 0) {
/* 849 */       return "{}";
/*     */     }
/* 851 */     StringBuilder sb = new StringBuilder();
/* 852 */     for (int i = 0; i < length; i++) {
/* 853 */       if (i == 0) {
/* 854 */         sb.append("{");
/*     */       }
/*     */       else {
/* 857 */         sb.append(", ");
/*     */       }
/* 859 */       sb.append(array[i]);
/*     */     }
/* 861 */     sb.append("}");
/* 862 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String nullSafeToString(short[] array)
/*     */   {
/* 875 */     if (array == null) {
/* 876 */       return "null";
/*     */     }
/* 878 */     int length = array.length;
/* 879 */     if (length == 0) {
/* 880 */       return "{}";
/*     */     }
/* 882 */     StringBuilder sb = new StringBuilder();
/* 883 */     for (int i = 0; i < length; i++) {
/* 884 */       if (i == 0) {
/* 885 */         sb.append("{");
/*     */       }
/*     */       else {
/* 888 */         sb.append(", ");
/*     */       }
/* 890 */       sb.append(array[i]);
/*     */     }
/* 892 */     sb.append("}");
/* 893 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.ObjectUtils
 * JD-Core Version:    0.6.2
 */