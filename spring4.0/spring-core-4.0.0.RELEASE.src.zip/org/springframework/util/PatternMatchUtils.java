/*    */ package org.springframework.util;
/*    */ 
/*    */ public abstract class PatternMatchUtils
/*    */ {
/*    */   public static boolean simpleMatch(String pattern, String str)
/*    */   {
/* 37 */     if ((pattern == null) || (str == null)) {
/* 38 */       return false;
/*    */     }
/* 40 */     int firstIndex = pattern.indexOf('*');
/* 41 */     if (firstIndex == -1) {
/* 42 */       return pattern.equals(str);
/*    */     }
/* 44 */     if (firstIndex == 0) {
/* 45 */       if (pattern.length() == 1) {
/* 46 */         return true;
/*    */       }
/* 48 */       int nextIndex = pattern.indexOf('*', firstIndex + 1);
/* 49 */       if (nextIndex == -1) {
/* 50 */         return str.endsWith(pattern.substring(1));
/*    */       }
/* 52 */       String part = pattern.substring(1, nextIndex);
/* 53 */       int partIndex = str.indexOf(part);
/* 54 */       while (partIndex != -1) {
/* 55 */         if (simpleMatch(pattern.substring(nextIndex), str.substring(partIndex + part.length()))) {
/* 56 */           return true;
/*    */         }
/* 58 */         partIndex = str.indexOf(part, partIndex + 1);
/*    */       }
/* 60 */       return false;
/*    */     }
/*    */ 
/* 64 */     return (str.length() >= firstIndex) && 
/* 63 */       (pattern
/* 63 */       .substring(0, firstIndex)
/* 63 */       .equals(str.substring(0, firstIndex))) && 
/* 64 */       (simpleMatch(pattern
/* 64 */       .substring(firstIndex), 
/* 64 */       str.substring(firstIndex)));
/*    */   }
/*    */ 
/*    */   public static boolean simpleMatch(String[] patterns, String str)
/*    */   {
/* 76 */     if (patterns != null) {
/* 77 */       for (int i = 0; i < patterns.length; i++) {
/* 78 */         if (simpleMatch(patterns[i], str)) {
/* 79 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 83 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.PatternMatchUtils
 * JD-Core Version:    0.6.2
 */