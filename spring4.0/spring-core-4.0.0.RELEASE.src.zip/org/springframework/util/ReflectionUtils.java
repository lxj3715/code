/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public abstract class ReflectionUtils
/*     */ {
/*  47 */   private static final Pattern CGLIB_RENAMED_METHOD_PATTERN = Pattern.compile("CGLIB\\$(.+)\\$\\d+");
/*     */ 
/* 667 */   public static FieldFilter COPYABLE_FIELDS = new FieldFilter()
/*     */   {
/*     */     public boolean matches(Field field)
/*     */     {
/* 671 */       return (!Modifier.isStatic(field.getModifiers())) && (!Modifier.isFinal(field.getModifiers()));
/*     */     }
/* 667 */   };
/*     */ 
/* 679 */   public static MethodFilter NON_BRIDGED_METHODS = new MethodFilter()
/*     */   {
/*     */     public boolean matches(Method method)
/*     */     {
/* 683 */       return !method.isBridge();
/*     */     }
/* 679 */   };
/*     */ 
/* 692 */   public static MethodFilter USER_DECLARED_METHODS = new MethodFilter()
/*     */   {
/*     */     public boolean matches(Method method)
/*     */     {
/* 696 */       return (!method.isBridge()) && (method.getDeclaringClass() != Object.class);
/*     */     }
/* 692 */   };
/*     */ 
/*     */   public static Field findField(Class<?> clazz, String name)
/*     */   {
/*  57 */     return findField(clazz, name, null);
/*     */   }
/*     */ 
/*     */   public static Field findField(Class<?> clazz, String name, Class<?> type)
/*     */   {
/*  70 */     Assert.notNull(clazz, "Class must not be null");
/*  71 */     Assert.isTrue((name != null) || (type != null), "Either name or type of the field must be specified");
/*  72 */     Class searchType = clazz;
/*  73 */     while ((!Object.class.equals(searchType)) && (searchType != null)) {
/*  74 */       Field[] fields = searchType.getDeclaredFields();
/*  75 */       for (Field field : fields) {
/*  76 */         if (((name == null) || (name.equals(field.getName()))) && ((type == null) || (type.equals(field.getType())))) {
/*  77 */           return field;
/*     */         }
/*     */       }
/*  80 */       searchType = searchType.getSuperclass();
/*     */     }
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setField(Field field, Object target, Object value)
/*     */   {
/*     */     try
/*     */     {
/*  97 */       field.set(target, value);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 100 */       handleReflectionException(ex);
/*     */ 
/* 102 */       throw new IllegalStateException("Unexpected reflection exception - " + ex
/* 102 */         .getClass().getName() + ": " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object getField(Field field, Object target)
/*     */   {
/*     */     try
/*     */     {
/* 118 */       return field.get(target);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 121 */       handleReflectionException(ex);
/*     */ 
/* 123 */       throw new IllegalStateException("Unexpected reflection exception - " + ex
/* 123 */         .getClass().getName() + ": " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Method findMethod(Class<?> clazz, String name)
/*     */   {
/* 136 */     return findMethod(clazz, name, new Class[0]);
/*     */   }
/*     */ 
/*     */   public static Method findMethod(Class<?> clazz, String name, Class<?>[] paramTypes)
/*     */   {
/* 150 */     Assert.notNull(clazz, "Class must not be null");
/* 151 */     Assert.notNull(name, "Method name must not be null");
/* 152 */     Class searchType = clazz;
/* 153 */     while (searchType != null) {
/* 154 */       Method[] methods = searchType.isInterface() ? searchType.getMethods() : searchType.getDeclaredMethods();
/* 155 */       for (Method method : methods) {
/* 156 */         if ((name.equals(method.getName())) && ((paramTypes == null) || 
/* 157 */           (Arrays.equals(paramTypes, method
/* 157 */           .getParameterTypes())))) {
/* 158 */           return method;
/*     */         }
/*     */       }
/* 161 */       searchType = searchType.getSuperclass();
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   public static Object invokeMethod(Method method, Object target)
/*     */   {
/* 176 */     return invokeMethod(method, target, new Object[0]);
/*     */   }
/*     */ 
/*     */   public static Object invokeMethod(Method method, Object target, Object[] args)
/*     */   {
/*     */     try
/*     */     {
/* 191 */       return method.invoke(target, args);
/*     */     }
/*     */     catch (Exception ex) {
/* 194 */       handleReflectionException(ex);
/*     */     }
/* 196 */     throw new IllegalStateException("Should never get here");
/*     */   }
/*     */ 
/*     */   public static Object invokeJdbcMethod(Method method, Object target)
/*     */     throws SQLException
/*     */   {
/* 209 */     return invokeJdbcMethod(method, target, new Object[0]);
/*     */   }
/*     */ 
/*     */   public static Object invokeJdbcMethod(Method method, Object target, Object[] args)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 224 */       return method.invoke(target, args);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 227 */       handleReflectionException(ex);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 230 */       if ((ex.getTargetException() instanceof SQLException)) {
/* 231 */         throw ((SQLException)ex.getTargetException());
/*     */       }
/* 233 */       handleInvocationTargetException(ex);
/*     */     }
/* 235 */     throw new IllegalStateException("Should never get here");
/*     */   }
/*     */ 
/*     */   public static void handleReflectionException(Exception ex)
/*     */   {
/* 247 */     if ((ex instanceof NoSuchMethodException)) {
/* 248 */       throw new IllegalStateException("Method not found: " + ex.getMessage());
/*     */     }
/* 250 */     if ((ex instanceof IllegalAccessException)) {
/* 251 */       throw new IllegalStateException("Could not access method: " + ex.getMessage());
/*     */     }
/* 253 */     if ((ex instanceof InvocationTargetException)) {
/* 254 */       handleInvocationTargetException((InvocationTargetException)ex);
/*     */     }
/* 256 */     if ((ex instanceof RuntimeException)) {
/* 257 */       throw ((RuntimeException)ex);
/*     */     }
/* 259 */     throw new UndeclaredThrowableException(ex);
/*     */   }
/*     */ 
/*     */   public static void handleInvocationTargetException(InvocationTargetException ex)
/*     */   {
/* 270 */     rethrowRuntimeException(ex.getTargetException());
/*     */   }
/*     */ 
/*     */   public static void rethrowRuntimeException(Throwable ex)
/*     */   {
/* 285 */     if ((ex instanceof RuntimeException)) {
/* 286 */       throw ((RuntimeException)ex);
/*     */     }
/* 288 */     if ((ex instanceof Error)) {
/* 289 */       throw ((Error)ex);
/*     */     }
/* 291 */     throw new UndeclaredThrowableException(ex);
/*     */   }
/*     */ 
/*     */   public static void rethrowException(Throwable ex)
/*     */     throws Exception
/*     */   {
/* 306 */     if ((ex instanceof Exception)) {
/* 307 */       throw ((Exception)ex);
/*     */     }
/* 309 */     if ((ex instanceof Error)) {
/* 310 */       throw ((Error)ex);
/*     */     }
/* 312 */     throw new UndeclaredThrowableException(ex);
/*     */   }
/*     */ 
/*     */   public static boolean declaresException(Method method, Class<?> exceptionType)
/*     */   {
/* 325 */     Assert.notNull(method, "Method must not be null");
/* 326 */     Class[] declaredExceptions = method.getExceptionTypes();
/* 327 */     for (Class declaredException : declaredExceptions) {
/* 328 */       if (declaredException.isAssignableFrom(exceptionType)) {
/* 329 */         return true;
/*     */       }
/*     */     }
/* 332 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isPublicStaticFinal(Field field)
/*     */   {
/* 340 */     int modifiers = field.getModifiers();
/* 341 */     return (Modifier.isPublic(modifiers)) && (Modifier.isStatic(modifiers)) && (Modifier.isFinal(modifiers));
/*     */   }
/*     */ 
/*     */   public static boolean isEqualsMethod(Method method)
/*     */   {
/* 349 */     if ((method == null) || (!method.getName().equals("equals"))) {
/* 350 */       return false;
/*     */     }
/* 352 */     Class[] paramTypes = method.getParameterTypes();
/* 353 */     return (paramTypes.length == 1) && (paramTypes[0] == Object.class);
/*     */   }
/*     */ 
/*     */   public static boolean isHashCodeMethod(Method method)
/*     */   {
/* 361 */     return (method != null) && (method.getName().equals("hashCode")) && (method.getParameterTypes().length == 0);
/*     */   }
/*     */ 
/*     */   public static boolean isToStringMethod(Method method)
/*     */   {
/* 369 */     return (method != null) && (method.getName().equals("toString")) && (method.getParameterTypes().length == 0);
/*     */   }
/*     */ 
/*     */   public static boolean isObjectMethod(Method method)
/*     */   {
/*     */     try
/*     */     {
/* 377 */       Object.class.getDeclaredMethod(method.getName(), method.getParameterTypes());
/* 378 */       return true;
/*     */     } catch (SecurityException ex) {
/* 380 */       return false; } catch (NoSuchMethodException ex) {
/*     */     }
/* 382 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isCglibRenamedMethod(Method renamedMethod)
/*     */   {
/* 393 */     return CGLIB_RENAMED_METHOD_PATTERN.matcher(renamedMethod.getName()).matches();
/*     */   }
/*     */ 
/*     */   public static void makeAccessible(Field field)
/*     */   {
/* 405 */     if (((!Modifier.isPublic(field.getModifiers())) || (!Modifier.isPublic(field.getDeclaringClass().getModifiers())) || 
/* 406 */       (Modifier.isFinal(field
/* 406 */       .getModifiers()))) && (!field.isAccessible()))
/* 407 */       field.setAccessible(true);
/*     */   }
/*     */ 
/*     */   public static void makeAccessible(Method method)
/*     */   {
/* 420 */     if (((!Modifier.isPublic(method.getModifiers())) || (!Modifier.isPublic(method.getDeclaringClass().getModifiers()))) && 
/* 421 */       (!method
/* 421 */       .isAccessible()))
/* 422 */       method.setAccessible(true);
/*     */   }
/*     */ 
/*     */   public static void makeAccessible(Constructor<?> ctor)
/*     */   {
/* 435 */     if (((!Modifier.isPublic(ctor.getModifiers())) || (!Modifier.isPublic(ctor.getDeclaringClass().getModifiers()))) && 
/* 436 */       (!ctor
/* 436 */       .isAccessible()))
/* 437 */       ctor.setAccessible(true);
/*     */   }
/*     */ 
/*     */   public static void doWithMethods(Class<?> clazz, MethodCallback mc)
/*     */     throws IllegalArgumentException
/*     */   {
/* 451 */     doWithMethods(clazz, mc, null);
/*     */   }
/*     */ 
/*     */   public static void doWithMethods(Class<?> clazz, MethodCallback mc, MethodFilter mf)
/*     */     throws IllegalArgumentException
/*     */   {
/* 467 */     Method[] methods = clazz.getDeclaredMethods();
/* 468 */     for (Method method : methods) {
/* 469 */       if ((mf == null) || (mf.matches(method)))
/*     */       {
/*     */         try
/*     */         {
/* 473 */           mc.doWith(method);
/*     */         }
/*     */         catch (IllegalAccessException ex) {
/* 476 */           throw new IllegalStateException("Shouldn't be illegal to access method '" + method.getName() + "': " + ex);
/*     */         }
/*     */       }
/*     */     }
/* 480 */     if (clazz.getSuperclass() != null) {
/* 481 */       doWithMethods(clazz.getSuperclass(), mc, mf);
/*     */     }
/* 483 */     else if (clazz.isInterface())
/* 484 */       for (Class superIfc : clazz.getInterfaces())
/* 485 */         doWithMethods(superIfc, mc, mf);
/*     */   }
/*     */ 
/*     */   public static Method[] getAllDeclaredMethods(Class<?> leafClass)
/*     */     throws IllegalArgumentException
/*     */   {
/* 495 */     List methods = new ArrayList(32);
/* 496 */     doWithMethods(leafClass, new MethodCallback()
/*     */     {
/*     */       public void doWith(Method method) {
/* 499 */         this.val$methods.add(method);
/*     */       }
/*     */     });
/* 502 */     return (Method[])methods.toArray(new Method[methods.size()]);
/*     */   }
/*     */ 
/*     */   public static Method[] getUniqueDeclaredMethods(Class<?> leafClass)
/*     */     throws IllegalArgumentException
/*     */   {
/* 511 */     List methods = new ArrayList(32);
/* 512 */     doWithMethods(leafClass, new MethodCallback()
/*     */     {
/*     */       public void doWith(Method method) {
/* 515 */         boolean knownSignature = false;
/* 516 */         Method methodBeingOverriddenWithCovariantReturnType = null;
/*     */ 
/* 518 */         for (Method existingMethod : this.val$methods) {
/* 519 */           if ((method.getName().equals(existingMethod.getName())) && 
/* 520 */             (Arrays.equals(method
/* 520 */             .getParameterTypes(), existingMethod.getParameterTypes())))
/*     */           {
/* 522 */             if ((existingMethod.getReturnType() != method.getReturnType()) && 
/* 523 */               (existingMethod
/* 523 */               .getReturnType().isAssignableFrom(method.getReturnType()))) {
/* 524 */               methodBeingOverriddenWithCovariantReturnType = existingMethod; break;
/*     */             }
/* 526 */             knownSignature = true;
/*     */ 
/* 528 */             break;
/*     */           }
/*     */         }
/* 531 */         if (methodBeingOverriddenWithCovariantReturnType != null) {
/* 532 */           this.val$methods.remove(methodBeingOverriddenWithCovariantReturnType);
/*     */         }
/* 534 */         if ((!knownSignature) && (!ReflectionUtils.isCglibRenamedMethod(method)))
/* 535 */           this.val$methods.add(method);
/*     */       }
/*     */     });
/* 539 */     return (Method[])methods.toArray(new Method[methods.size()]);
/*     */   }
/*     */ 
/*     */   public static void doWithFields(Class<?> clazz, FieldCallback fc)
/*     */     throws IllegalArgumentException
/*     */   {
/* 549 */     doWithFields(clazz, fc, null);
/*     */   }
/*     */ 
/*     */   public static void doWithFields(Class<?> clazz, FieldCallback fc, FieldFilter ff)
/*     */     throws IllegalArgumentException
/*     */   {
/* 563 */     Class targetClass = clazz;
/*     */     do {
/* 565 */       Field[] fields = targetClass.getDeclaredFields();
/* 566 */       for (Field field : fields)
/*     */       {
/* 568 */         if ((ff == null) || (ff.matches(field)))
/*     */         {
/*     */           try
/*     */           {
/* 572 */             fc.doWith(field);
/*     */           }
/*     */           catch (IllegalAccessException ex)
/*     */           {
/* 576 */             throw new IllegalStateException("Shouldn't be illegal to access field '" + field
/* 576 */               .getName() + "': " + ex);
/*     */           }
/*     */         }
/*     */       }
/* 579 */       targetClass = targetClass.getSuperclass();
/*     */     }
/* 581 */     while ((targetClass != null) && (targetClass != Object.class));
/*     */   }
/*     */ 
/*     */   public static void shallowCopyFieldState(Object src, final Object dest)
/*     */     throws IllegalArgumentException
/*     */   {
/* 591 */     if (src == null) {
/* 592 */       throw new IllegalArgumentException("Source for field copy cannot be null");
/*     */     }
/* 594 */     if (dest == null) {
/* 595 */       throw new IllegalArgumentException("Destination for field copy cannot be null");
/*     */     }
/* 597 */     if (!src.getClass().isAssignableFrom(dest.getClass()))
/*     */     {
/* 599 */       throw new IllegalArgumentException("Destination class [" + dest.getClass().getName() + "] must be same or subclass as source class [" + src
/* 599 */         .getClass().getName() + "]");
/*     */     }
/* 601 */     doWithFields(src.getClass(), new FieldCallback()
/*     */     {
/*     */       public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {
/* 604 */         ReflectionUtils.makeAccessible(field);
/* 605 */         Object srcValue = field.get(this.val$src);
/* 606 */         field.set(dest, srcValue);
/*     */       }
/*     */     }
/*     */     , COPYABLE_FIELDS);
/*     */   }
/*     */ 
/*     */   public static abstract interface FieldFilter
/*     */   {
/*     */     public abstract boolean matches(Field paramField);
/*     */   }
/*     */ 
/*     */   public static abstract interface FieldCallback
/*     */   {
/*     */     public abstract void doWith(Field paramField)
/*     */       throws IllegalArgumentException, IllegalAccessException;
/*     */   }
/*     */ 
/*     */   public static abstract interface MethodFilter
/*     */   {
/*     */     public abstract boolean matches(Method paramMethod);
/*     */   }
/*     */ 
/*     */   public static abstract interface MethodCallback
/*     */   {
/*     */     public abstract void doWith(Method paramMethod)
/*     */       throws IllegalArgumentException, IllegalAccessException;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.ReflectionUtils
 * JD-Core Version:    0.6.2
 */