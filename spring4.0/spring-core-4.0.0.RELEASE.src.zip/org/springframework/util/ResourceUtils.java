/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ 
/*     */ public abstract class ResourceUtils
/*     */ {
/*     */   public static final String CLASSPATH_URL_PREFIX = "classpath:";
/*     */   public static final String FILE_URL_PREFIX = "file:";
/*     */   public static final String URL_PROTOCOL_FILE = "file";
/*     */   public static final String URL_PROTOCOL_JAR = "jar";
/*     */   public static final String URL_PROTOCOL_ZIP = "zip";
/*     */   public static final String URL_PROTOCOL_VFSZIP = "vfszip";
/*     */   public static final String URL_PROTOCOL_VFS = "vfs";
/*     */   public static final String URL_PROTOCOL_WSJAR = "wsjar";
/*     */   public static final String JAR_URL_SEPARATOR = "!/";
/*     */ 
/*     */   public static boolean isUrl(String resourceLocation)
/*     */   {
/*  91 */     if (resourceLocation == null) {
/*  92 */       return false;
/*     */     }
/*  94 */     if (resourceLocation.startsWith("classpath:"))
/*  95 */       return true;
/*     */     try
/*     */     {
/*  98 */       new URL(resourceLocation);
/*  99 */       return true;
/*     */     } catch (MalformedURLException ex) {
/*     */     }
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   public static URL getURL(String resourceLocation)
/*     */     throws FileNotFoundException
/*     */   {
/* 116 */     Assert.notNull(resourceLocation, "Resource location must not be null");
/* 117 */     if (resourceLocation.startsWith("classpath:")) {
/* 118 */       String path = resourceLocation.substring("classpath:".length());
/* 119 */       URL url = ClassUtils.getDefaultClassLoader().getResource(path);
/* 120 */       if (url == null) {
/* 121 */         String description = "class path resource [" + path + "]";
/* 122 */         throw new FileNotFoundException(description + " cannot be resolved to URL because it does not exist");
/*     */       }
/*     */ 
/* 125 */       return url;
/*     */     }
/*     */     try
/*     */     {
/* 129 */       return new URL(resourceLocation);
/*     */     }
/*     */     catch (MalformedURLException ex)
/*     */     {
/*     */       try {
/* 134 */         return new File(resourceLocation).toURI().toURL(); } catch (MalformedURLException ex2) {
/*     */       }
/*     */     }
/* 137 */     throw new FileNotFoundException("Resource location [" + resourceLocation + "] is neither a URL not a well-formed file path");
/*     */   }
/*     */ 
/*     */   public static File getFile(String resourceLocation)
/*     */     throws FileNotFoundException
/*     */   {
/* 155 */     Assert.notNull(resourceLocation, "Resource location must not be null");
/* 156 */     if (resourceLocation.startsWith("classpath:")) {
/* 157 */       String path = resourceLocation.substring("classpath:".length());
/* 158 */       String description = "class path resource [" + path + "]";
/* 159 */       URL url = ClassUtils.getDefaultClassLoader().getResource(path);
/* 160 */       if (url == null) {
/* 161 */         throw new FileNotFoundException(description + " cannot be resolved to absolute file path " + "because it does not reside in the file system");
/*     */       }
/*     */ 
/* 165 */       return getFile(url, description);
/*     */     }
/*     */     try
/*     */     {
/* 169 */       return getFile(new URL(resourceLocation));
/*     */     }
/*     */     catch (MalformedURLException ex) {
/*     */     }
/* 173 */     return new File(resourceLocation);
/*     */   }
/*     */ 
/*     */   public static File getFile(URL resourceUrl)
/*     */     throws FileNotFoundException
/*     */   {
/* 186 */     return getFile(resourceUrl, "URL");
/*     */   }
/*     */ 
/*     */   public static File getFile(URL resourceUrl, String description)
/*     */     throws FileNotFoundException
/*     */   {
/* 200 */     Assert.notNull(resourceUrl, "Resource URL must not be null");
/* 201 */     if (!"file".equals(resourceUrl.getProtocol())) {
/* 202 */       throw new FileNotFoundException(description + " cannot be resolved to absolute file path " + "because it does not reside in the file system: " + resourceUrl);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 207 */       return new File(toURI(resourceUrl).getSchemeSpecificPart());
/*     */     }
/*     */     catch (URISyntaxException ex) {
/*     */     }
/* 211 */     return new File(resourceUrl.getFile());
/*     */   }
/*     */ 
/*     */   public static File getFile(URI resourceUri)
/*     */     throws FileNotFoundException
/*     */   {
/* 224 */     return getFile(resourceUri, "URI");
/*     */   }
/*     */ 
/*     */   public static File getFile(URI resourceUri, String description)
/*     */     throws FileNotFoundException
/*     */   {
/* 238 */     Assert.notNull(resourceUri, "Resource URI must not be null");
/* 239 */     if (!"file".equals(resourceUri.getScheme())) {
/* 240 */       throw new FileNotFoundException(description + " cannot be resolved to absolute file path " + "because it does not reside in the file system: " + resourceUri);
/*     */     }
/*     */ 
/* 244 */     return new File(resourceUri.getSchemeSpecificPart());
/*     */   }
/*     */ 
/*     */   public static boolean isFileURL(URL url)
/*     */   {
/* 254 */     String protocol = url.getProtocol();
/* 255 */     return ("file".equals(protocol)) || (protocol.startsWith("vfs"));
/*     */   }
/*     */ 
/*     */   public static boolean isJarURL(URL url)
/*     */   {
/* 267 */     String up = url.getProtocol();
/* 268 */     return ("jar".equals(up)) || ("zip".equals(up)) || ("wsjar".equals(up));
/*     */   }
/*     */ 
/*     */   public static URL extractJarFileURL(URL jarUrl)
/*     */     throws MalformedURLException
/*     */   {
/* 279 */     String urlFile = jarUrl.getFile();
/* 280 */     int separatorIndex = urlFile.indexOf("!/");
/* 281 */     if (separatorIndex != -1) {
/* 282 */       String jarFile = urlFile.substring(0, separatorIndex);
/*     */       try {
/* 284 */         return new URL(jarFile);
/*     */       }
/*     */       catch (MalformedURLException ex)
/*     */       {
/* 289 */         if (!jarFile.startsWith("/")) {
/* 290 */           jarFile = "/" + jarFile;
/*     */         }
/* 292 */         return new URL("file:" + jarFile);
/*     */       }
/*     */     }
/*     */ 
/* 296 */     return jarUrl;
/*     */   }
/*     */ 
/*     */   public static URI toURI(URL url)
/*     */     throws URISyntaxException
/*     */   {
/* 311 */     return toURI(url.toString());
/*     */   }
/*     */ 
/*     */   public static URI toURI(String location)
/*     */     throws URISyntaxException
/*     */   {
/* 322 */     return new URI(StringUtils.replace(location, " ", "%20"));
/*     */   }
/*     */ 
/*     */   public static void useCachesIfNecessary(URLConnection con)
/*     */   {
/* 332 */     con.setUseCaches(con.getClass().getSimpleName().startsWith("JNLP"));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.ResourceUtils
 * JD-Core Version:    0.6.2
 */