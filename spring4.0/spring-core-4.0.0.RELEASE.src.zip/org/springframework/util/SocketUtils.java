/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.ServerSocket;
/*     */ import java.util.Random;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.net.ServerSocketFactory;
/*     */ 
/*     */ public abstract class SocketUtils
/*     */ {
/*     */   public static final int PORT_RANGE_MIN = 1024;
/*     */   public static final int PORT_RANGE_MAX = 65535;
/*  55 */   private static final Random random = new Random(System.currentTimeMillis());
/*     */ 
/*     */   public static int findAvailableTcpPort()
/*     */   {
/*  93 */     return findAvailableTcpPort(1024);
/*     */   }
/*     */ 
/*     */   public static int findAvailableTcpPort(int minPort)
/*     */   {
/* 104 */     return findAvailableTcpPort(minPort, 65535);
/*     */   }
/*     */ 
/*     */   public static int findAvailableTcpPort(int minPort, int maxPort)
/*     */   {
/* 116 */     return SocketType.TCP.findAvailablePort(minPort, maxPort);
/*     */   }
/*     */ 
/*     */   public static SortedSet<Integer> findAvailableTcpPorts(int numRequested)
/*     */   {
/* 127 */     return findAvailableTcpPorts(numRequested, 1024, 65535);
/*     */   }
/*     */ 
/*     */   public static SortedSet<Integer> findAvailableTcpPorts(int numRequested, int minPort, int maxPort)
/*     */   {
/* 140 */     return SocketType.TCP.findAvailablePorts(numRequested, minPort, maxPort);
/*     */   }
/*     */ 
/*     */   public static int findAvailableUdpPort()
/*     */   {
/* 150 */     return findAvailableUdpPort(1024);
/*     */   }
/*     */ 
/*     */   public static int findAvailableUdpPort(int minPort)
/*     */   {
/* 161 */     return findAvailableUdpPort(minPort, 65535);
/*     */   }
/*     */ 
/*     */   public static int findAvailableUdpPort(int minPort, int maxPort)
/*     */   {
/* 173 */     return SocketType.UDP.findAvailablePort(minPort, maxPort);
/*     */   }
/*     */ 
/*     */   public static SortedSet<Integer> findAvailableUdpPorts(int numRequested)
/*     */   {
/* 184 */     return findAvailableUdpPorts(numRequested, 1024, 65535);
/*     */   }
/*     */ 
/*     */   public static SortedSet<Integer> findAvailableUdpPorts(int numRequested, int minPort, int maxPort)
/*     */   {
/* 197 */     return SocketType.UDP.findAvailablePorts(numRequested, minPort, maxPort);
/*     */   }
/*     */ 
/*     */   private static abstract enum SocketType
/*     */   {
/* 203 */     TCP, 
/*     */ 
/* 218 */     UDP;
/*     */ 
/*     */     protected abstract boolean isPortAvailable(int paramInt);
/*     */ 
/*     */     private int findRandomPort(int minPort, int maxPort)
/*     */     {
/* 247 */       int portRange = maxPort - minPort;
/* 248 */       return minPort + SocketUtils.random.nextInt(portRange);
/*     */     }
/*     */ 
/*     */     int findAvailablePort(int minPort, int maxPort)
/*     */     {
/* 260 */       Assert.isTrue(minPort > 0, "'minPort' must be greater than 0");
/* 261 */       Assert.isTrue(maxPort > minPort, "'maxPort' must be greater than 'minPort'");
/* 262 */       Assert.isTrue(maxPort <= 65535, "'maxPort' must be less than or equal to 65535");
/*     */ 
/* 264 */       int portRange = maxPort - minPort;
/*     */ 
/* 266 */       int searchCounter = 0;
/*     */       int candidatePort;
/*     */       do
/*     */       {
/* 268 */         searchCounter++; if (searchCounter > portRange) {
/* 269 */           throw new IllegalStateException(String.format("Could not find an available %s port in the range [%d, %d] after %d attempts", new Object[] { 
/* 270 */             name(), Integer.valueOf(minPort), 
/* 271 */             Integer.valueOf(maxPort), 
/* 271 */             Integer.valueOf(searchCounter) }));
/*     */         }
/* 273 */         candidatePort = findRandomPort(minPort, maxPort);
/* 274 */       }while (!isPortAvailable(candidatePort));
/*     */ 
/* 276 */       return candidatePort;
/*     */     }
/*     */ 
/*     */     SortedSet<Integer> findAvailablePorts(int numRequested, int minPort, int maxPort)
/*     */     {
/* 289 */       Assert.isTrue(minPort > 0, "'minPort' must be greater than 0");
/* 290 */       Assert.isTrue(maxPort > minPort, "'maxPort' must be greater than 'minPort'");
/* 291 */       Assert.isTrue(maxPort <= 65535, "'maxPort' must be less than or equal to 65535");
/* 292 */       Assert.isTrue(numRequested > 0, "'numRequested' must be greater than 0");
/* 293 */       Assert.isTrue(maxPort - minPort >= numRequested, "'numRequested' must not be greater than 'maxPort' - 'minPort'");
/*     */ 
/* 296 */       SortedSet availablePorts = new TreeSet();
/* 297 */       int attemptCount = 0;
/*     */       while (true) { attemptCount++; if ((attemptCount > numRequested + 100) || (availablePorts.size() >= numRequested)) break;
/* 299 */         availablePorts.add(Integer.valueOf(findAvailablePort(minPort, maxPort)));
/*     */       }
/*     */ 
/* 302 */       if (availablePorts.size() != numRequested) {
/* 303 */         throw new IllegalStateException(String.format("Could not find %d available %s ports in the range [%d, %d]", new Object[] { 
/* 304 */           Integer.valueOf(numRequested), 
/* 304 */           name(), Integer.valueOf(minPort), 
/* 305 */           Integer.valueOf(maxPort) }));
/*     */       }
/*     */ 
/* 308 */       return availablePorts;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.SocketUtils
 * JD-Core Version:    0.6.2
 */