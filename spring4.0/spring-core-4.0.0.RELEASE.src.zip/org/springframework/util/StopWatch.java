/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.text.NumberFormat;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class StopWatch
/*     */ {
/*     */   private final String id;
/*  50 */   private boolean keepTaskList = true;
/*     */ 
/*  52 */   private final List<TaskInfo> taskList = new LinkedList();
/*     */   private long startTimeMillis;
/*     */   private boolean running;
/*     */   private String currentTaskName;
/*     */   private TaskInfo lastTaskInfo;
/*     */   private int taskCount;
/*     */   private long totalTimeMillis;
/*     */ 
/*     */   public StopWatch()
/*     */   {
/*  75 */     this.id = "";
/*     */   }
/*     */ 
/*     */   public StopWatch(String id)
/*     */   {
/*  86 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public void setKeepTaskList(boolean keepTaskList)
/*     */   {
/*  96 */     this.keepTaskList = keepTaskList;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */     throws IllegalStateException
/*     */   {
/* 106 */     start("");
/*     */   }
/*     */ 
/*     */   public void start(String taskName)
/*     */     throws IllegalStateException
/*     */   {
/* 116 */     if (this.running) {
/* 117 */       throw new IllegalStateException("Can't start StopWatch: it's already running");
/*     */     }
/* 119 */     this.startTimeMillis = System.currentTimeMillis();
/* 120 */     this.running = true;
/* 121 */     this.currentTaskName = taskName;
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */     throws IllegalStateException
/*     */   {
/* 131 */     if (!this.running) {
/* 132 */       throw new IllegalStateException("Can't stop StopWatch: it's not running");
/*     */     }
/* 134 */     long lastTime = System.currentTimeMillis() - this.startTimeMillis;
/* 135 */     this.totalTimeMillis += lastTime;
/* 136 */     this.lastTaskInfo = new TaskInfo(this.currentTaskName, lastTime);
/* 137 */     if (this.keepTaskList) {
/* 138 */       this.taskList.add(this.lastTaskInfo);
/*     */     }
/* 140 */     this.taskCount += 1;
/* 141 */     this.running = false;
/* 142 */     this.currentTaskName = null;
/*     */   }
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/* 149 */     return this.running;
/*     */   }
/*     */ 
/*     */   public long getLastTaskTimeMillis()
/*     */     throws IllegalStateException
/*     */   {
/* 157 */     if (this.lastTaskInfo == null) {
/* 158 */       throw new IllegalStateException("No tasks run: can't get last task interval");
/*     */     }
/* 160 */     return this.lastTaskInfo.getTimeMillis();
/*     */   }
/*     */ 
/*     */   public String getLastTaskName()
/*     */     throws IllegalStateException
/*     */   {
/* 167 */     if (this.lastTaskInfo == null) {
/* 168 */       throw new IllegalStateException("No tasks run: can't get last task name");
/*     */     }
/* 170 */     return this.lastTaskInfo.getTaskName();
/*     */   }
/*     */ 
/*     */   public TaskInfo getLastTaskInfo()
/*     */     throws IllegalStateException
/*     */   {
/* 177 */     if (this.lastTaskInfo == null) {
/* 178 */       throw new IllegalStateException("No tasks run: can't get last task info");
/*     */     }
/* 180 */     return this.lastTaskInfo;
/*     */   }
/*     */ 
/*     */   public long getTotalTimeMillis()
/*     */   {
/* 188 */     return this.totalTimeMillis;
/*     */   }
/*     */ 
/*     */   public double getTotalTimeSeconds()
/*     */   {
/* 195 */     return this.totalTimeMillis / 1000.0D;
/*     */   }
/*     */ 
/*     */   public int getTaskCount()
/*     */   {
/* 202 */     return this.taskCount;
/*     */   }
/*     */ 
/*     */   public TaskInfo[] getTaskInfo()
/*     */   {
/* 209 */     if (!this.keepTaskList) {
/* 210 */       throw new UnsupportedOperationException("Task info is not being kept!");
/*     */     }
/* 212 */     return (TaskInfo[])this.taskList.toArray(new TaskInfo[this.taskList.size()]);
/*     */   }
/*     */ 
/*     */   public String shortSummary()
/*     */   {
/* 220 */     return new StringBuilder().append("StopWatch '").append(this.id).append("': running time (millis) = ").append(getTotalTimeMillis()).toString();
/*     */   }
/*     */ 
/*     */   public String prettyPrint()
/*     */   {
/* 228 */     StringBuilder sb = new StringBuilder(shortSummary());
/* 229 */     sb.append('\n');
/* 230 */     if (!this.keepTaskList) {
/* 231 */       sb.append("No task info kept");
/*     */     } else {
/* 233 */       sb.append("-----------------------------------------\n");
/* 234 */       sb.append("ms     %     Task name\n");
/* 235 */       sb.append("-----------------------------------------\n");
/* 236 */       NumberFormat nf = NumberFormat.getNumberInstance();
/* 237 */       nf.setMinimumIntegerDigits(5);
/* 238 */       nf.setGroupingUsed(false);
/* 239 */       NumberFormat pf = NumberFormat.getPercentInstance();
/* 240 */       pf.setMinimumIntegerDigits(3);
/* 241 */       pf.setGroupingUsed(false);
/* 242 */       for (TaskInfo task : getTaskInfo()) {
/* 243 */         sb.append(nf.format(task.getTimeMillis())).append("  ");
/* 244 */         sb.append(pf.format(task.getTimeSeconds() / getTotalTimeSeconds())).append("  ");
/* 245 */         sb.append(task.getTaskName()).append("\n");
/*     */       }
/*     */     }
/* 248 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 257 */     StringBuilder sb = new StringBuilder(shortSummary());
/* 258 */     if (this.keepTaskList)
/* 259 */       for (TaskInfo task : getTaskInfo()) {
/* 260 */         sb.append("; [").append(task.getTaskName()).append("] took ").append(task.getTimeMillis());
/* 261 */         long percent = Math.round(100.0D * task.getTimeSeconds() / getTotalTimeSeconds());
/* 262 */         sb.append(" = ").append(percent).append("%");
/*     */       }
/*     */     else {
/* 265 */       sb.append("; no task info kept");
/*     */     }
/* 267 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static final class TaskInfo
/*     */   {
/*     */     private final String taskName;
/*     */     private final long timeMillis;
/*     */ 
/*     */     TaskInfo(String taskName, long timeMillis)
/*     */     {
/* 281 */       this.taskName = taskName;
/* 282 */       this.timeMillis = timeMillis;
/*     */     }
/*     */ 
/*     */     public String getTaskName()
/*     */     {
/* 289 */       return this.taskName;
/*     */     }
/*     */ 
/*     */     public long getTimeMillis()
/*     */     {
/* 296 */       return this.timeMillis;
/*     */     }
/*     */ 
/*     */     public double getTimeSeconds()
/*     */     {
/* 303 */       return this.timeMillis / 1000.0D;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.StopWatch
 * JD-Core Version:    0.6.2
 */