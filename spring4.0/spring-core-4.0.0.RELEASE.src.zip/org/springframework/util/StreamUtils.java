/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ public abstract class StreamUtils
/*     */ {
/*     */   public static final int BUFFER_SIZE = 4096;
/*     */ 
/*     */   public static byte[] copyToByteArray(InputStream in)
/*     */     throws IOException
/*     */   {
/*  55 */     ByteArrayOutputStream out = new ByteArrayOutputStream(4096);
/*  56 */     copy(in, out);
/*  57 */     return out.toByteArray();
/*     */   }
/*     */ 
/*     */   public static String copyToString(InputStream in, Charset charset)
/*     */     throws IOException
/*     */   {
/*  68 */     Assert.notNull(in, "No InputStream specified");
/*  69 */     StringBuilder out = new StringBuilder();
/*  70 */     InputStreamReader reader = new InputStreamReader(in, charset);
/*  71 */     char[] buffer = new char[4096];
/*  72 */     int bytesRead = -1;
/*  73 */     while ((bytesRead = reader.read(buffer)) != -1) {
/*  74 */       out.append(buffer, 0, bytesRead);
/*     */     }
/*  76 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public static void copy(byte[] in, OutputStream out)
/*     */     throws IOException
/*     */   {
/*  87 */     Assert.notNull(in, "No input byte array specified");
/*  88 */     Assert.notNull(out, "No OutputStream specified");
/*  89 */     out.write(in);
/*     */   }
/*     */ 
/*     */   public static void copy(String in, Charset charset, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 101 */     Assert.notNull(in, "No input String specified");
/* 102 */     Assert.notNull(charset, "No charset specified");
/* 103 */     Assert.notNull(out, "No OutputStream specified");
/* 104 */     Writer writer = new OutputStreamWriter(out, charset);
/* 105 */     writer.write(in);
/* 106 */     writer.flush();
/*     */   }
/*     */ 
/*     */   public static int copy(InputStream in, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 118 */     Assert.notNull(in, "No InputStream specified");
/* 119 */     Assert.notNull(out, "No OutputStream specified");
/* 120 */     int byteCount = 0;
/* 121 */     byte[] buffer = new byte[4096];
/* 122 */     int bytesRead = -1;
/* 123 */     while ((bytesRead = in.read(buffer)) != -1) {
/* 124 */       out.write(buffer, 0, bytesRead);
/* 125 */       byteCount += bytesRead;
/*     */     }
/* 127 */     out.flush();
/* 128 */     return byteCount;
/*     */   }
/*     */ 
/*     */   public static InputStream nonClosing(InputStream in)
/*     */   {
/* 138 */     Assert.notNull(in, "No InputStream specified");
/* 139 */     return new NonClosingInputStream(in);
/*     */   }
/*     */ 
/*     */   public static OutputStream nonClosing(OutputStream out)
/*     */   {
/* 149 */     Assert.notNull(out, "No OutputStream specified");
/* 150 */     return new NonClosingOutputStream(out);
/*     */   }
/*     */ 
/*     */   private static class NonClosingOutputStream extends FilterOutputStream
/*     */   {
/*     */     public NonClosingOutputStream(OutputStream out)
/*     */     {
/* 169 */       super();
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int let)
/*     */       throws IOException
/*     */     {
/* 175 */       this.out.write(b, off, let);
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class NonClosingInputStream extends FilterInputStream
/*     */   {
/*     */     public NonClosingInputStream(InputStream in)
/*     */     {
/* 157 */       super();
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.StreamUtils
 * JD-Core Version:    0.6.2
 */