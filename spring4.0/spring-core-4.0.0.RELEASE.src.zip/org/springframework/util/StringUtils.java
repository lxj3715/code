/*      */ package org.springframework.util;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ public abstract class StringUtils
/*      */ {
/*      */   private static final String FOLDER_SEPARATOR = "/";
/*      */   private static final String WINDOWS_FOLDER_SEPARATOR = "\\";
/*      */   private static final String TOP_PATH = "..";
/*      */   private static final String CURRENT_PATH = ".";
/*      */   private static final char EXTENSION_SEPARATOR = '.';
/*      */ 
/*      */   public static boolean isEmpty(Object str)
/*      */   {
/*   85 */     return (str == null) || ("".equals(str));
/*      */   }
/*      */ 
/*      */   public static boolean hasLength(CharSequence str)
/*      */   {
/*  102 */     return (str != null) && (str.length() > 0);
/*      */   }
/*      */ 
/*      */   public static boolean hasLength(String str)
/*      */   {
/*  113 */     return hasLength(str);
/*      */   }
/*      */ 
/*      */   public static boolean hasText(CharSequence str)
/*      */   {
/*  133 */     if (!hasLength(str)) {
/*  134 */       return false;
/*      */     }
/*  136 */     int strLen = str.length();
/*  137 */     for (int i = 0; i < strLen; i++) {
/*  138 */       if (!Character.isWhitespace(str.charAt(i))) {
/*  139 */         return true;
/*      */       }
/*      */     }
/*  142 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean hasText(String str)
/*      */   {
/*  155 */     return hasText(str);
/*      */   }
/*      */ 
/*      */   public static boolean containsWhitespace(CharSequence str)
/*      */   {
/*  166 */     if (!hasLength(str)) {
/*  167 */       return false;
/*      */     }
/*  169 */     int strLen = str.length();
/*  170 */     for (int i = 0; i < strLen; i++) {
/*  171 */       if (Character.isWhitespace(str.charAt(i))) {
/*  172 */         return true;
/*      */       }
/*      */     }
/*  175 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean containsWhitespace(String str)
/*      */   {
/*  186 */     return containsWhitespace(str);
/*      */   }
/*      */ 
/*      */   public static String trimWhitespace(String str)
/*      */   {
/*  196 */     if (!hasLength(str)) {
/*  197 */       return str;
/*      */     }
/*  199 */     StringBuilder sb = new StringBuilder(str);
/*  200 */     while ((sb.length() > 0) && (Character.isWhitespace(sb.charAt(0)))) {
/*  201 */       sb.deleteCharAt(0);
/*      */     }
/*  203 */     while ((sb.length() > 0) && (Character.isWhitespace(sb.charAt(sb.length() - 1)))) {
/*  204 */       sb.deleteCharAt(sb.length() - 1);
/*      */     }
/*  206 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String trimAllWhitespace(String str)
/*      */   {
/*  217 */     if (!hasLength(str)) {
/*  218 */       return str;
/*      */     }
/*  220 */     StringBuilder sb = new StringBuilder(str);
/*  221 */     int index = 0;
/*  222 */     while (sb.length() > index) {
/*  223 */       if (Character.isWhitespace(sb.charAt(index))) {
/*  224 */         sb.deleteCharAt(index);
/*      */       }
/*      */       else {
/*  227 */         index++;
/*      */       }
/*      */     }
/*  230 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String trimLeadingWhitespace(String str)
/*      */   {
/*  240 */     if (!hasLength(str)) {
/*  241 */       return str;
/*      */     }
/*  243 */     StringBuilder sb = new StringBuilder(str);
/*  244 */     while ((sb.length() > 0) && (Character.isWhitespace(sb.charAt(0)))) {
/*  245 */       sb.deleteCharAt(0);
/*      */     }
/*  247 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String trimTrailingWhitespace(String str)
/*      */   {
/*  257 */     if (!hasLength(str)) {
/*  258 */       return str;
/*      */     }
/*  260 */     StringBuilder sb = new StringBuilder(str);
/*  261 */     while ((sb.length() > 0) && (Character.isWhitespace(sb.charAt(sb.length() - 1)))) {
/*  262 */       sb.deleteCharAt(sb.length() - 1);
/*      */     }
/*  264 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String trimLeadingCharacter(String str, char leadingCharacter)
/*      */   {
/*  274 */     if (!hasLength(str)) {
/*  275 */       return str;
/*      */     }
/*  277 */     StringBuilder sb = new StringBuilder(str);
/*  278 */     while ((sb.length() > 0) && (sb.charAt(0) == leadingCharacter)) {
/*  279 */       sb.deleteCharAt(0);
/*      */     }
/*  281 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String trimTrailingCharacter(String str, char trailingCharacter)
/*      */   {
/*  291 */     if (!hasLength(str)) {
/*  292 */       return str;
/*      */     }
/*  294 */     StringBuilder sb = new StringBuilder(str);
/*  295 */     while ((sb.length() > 0) && (sb.charAt(sb.length() - 1) == trailingCharacter)) {
/*  296 */       sb.deleteCharAt(sb.length() - 1);
/*      */     }
/*  298 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String str, String prefix)
/*      */   {
/*  310 */     if ((str == null) || (prefix == null)) {
/*  311 */       return false;
/*      */     }
/*  313 */     if (str.startsWith(prefix)) {
/*  314 */       return true;
/*      */     }
/*  316 */     if (str.length() < prefix.length()) {
/*  317 */       return false;
/*      */     }
/*  319 */     String lcStr = str.substring(0, prefix.length()).toLowerCase();
/*  320 */     String lcPrefix = prefix.toLowerCase();
/*  321 */     return lcStr.equals(lcPrefix);
/*      */   }
/*      */ 
/*      */   public static boolean endsWithIgnoreCase(String str, String suffix)
/*      */   {
/*  332 */     if ((str == null) || (suffix == null)) {
/*  333 */       return false;
/*      */     }
/*  335 */     if (str.endsWith(suffix)) {
/*  336 */       return true;
/*      */     }
/*  338 */     if (str.length() < suffix.length()) {
/*  339 */       return false;
/*      */     }
/*      */ 
/*  342 */     String lcStr = str.substring(str.length() - suffix.length()).toLowerCase();
/*  343 */     String lcSuffix = suffix.toLowerCase();
/*  344 */     return lcStr.equals(lcSuffix);
/*      */   }
/*      */ 
/*      */   public static boolean substringMatch(CharSequence str, int index, CharSequence substring)
/*      */   {
/*  355 */     for (int j = 0; j < substring.length(); j++) {
/*  356 */       int i = index + j;
/*  357 */       if ((i >= str.length()) || (str.charAt(i) != substring.charAt(j))) {
/*  358 */         return false;
/*      */       }
/*      */     }
/*  361 */     return true;
/*      */   }
/*      */ 
/*      */   public static int countOccurrencesOf(String str, String sub)
/*      */   {
/*  370 */     if ((str == null) || (sub == null) || (str.length() == 0) || (sub.length() == 0)) {
/*  371 */       return 0;
/*      */     }
/*  373 */     int count = 0;
/*  374 */     int pos = 0;
/*      */     int idx;
/*  376 */     while ((idx = str.indexOf(sub, pos)) != -1) {
/*  377 */       count++;
/*  378 */       pos = idx + sub.length();
/*      */     }
/*  380 */     return count;
/*      */   }
/*      */ 
/*      */   public static String replace(String inString, String oldPattern, String newPattern)
/*      */   {
/*  392 */     if ((!hasLength(inString)) || (!hasLength(oldPattern)) || (newPattern == null)) {
/*  393 */       return inString;
/*      */     }
/*  395 */     StringBuilder sb = new StringBuilder();
/*  396 */     int pos = 0;
/*  397 */     int index = inString.indexOf(oldPattern);
/*      */ 
/*  399 */     int patLen = oldPattern.length();
/*  400 */     while (index >= 0) {
/*  401 */       sb.append(inString.substring(pos, index));
/*  402 */       sb.append(newPattern);
/*  403 */       pos = index + patLen;
/*  404 */       index = inString.indexOf(oldPattern, pos);
/*      */     }
/*  406 */     sb.append(inString.substring(pos));
/*      */ 
/*  408 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String delete(String inString, String pattern)
/*      */   {
/*  418 */     return replace(inString, pattern, "");
/*      */   }
/*      */ 
/*      */   public static String deleteAny(String inString, String charsToDelete)
/*      */   {
/*  429 */     if ((!hasLength(inString)) || (!hasLength(charsToDelete))) {
/*  430 */       return inString;
/*      */     }
/*  432 */     StringBuilder sb = new StringBuilder();
/*  433 */     for (int i = 0; i < inString.length(); i++) {
/*  434 */       char c = inString.charAt(i);
/*  435 */       if (charsToDelete.indexOf(c) == -1) {
/*  436 */         sb.append(c);
/*      */       }
/*      */     }
/*  439 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String quote(String str)
/*      */   {
/*  454 */     return str != null ? new StringBuilder().append("'").append(str).append("'").toString() : null;
/*      */   }
/*      */ 
/*      */   public static Object quoteIfString(Object obj)
/*      */   {
/*  465 */     return (obj instanceof String) ? quote((String)obj) : obj;
/*      */   }
/*      */ 
/*      */   public static String unqualify(String qualifiedName)
/*      */   {
/*  474 */     return unqualify(qualifiedName, '.');
/*      */   }
/*      */ 
/*      */   public static String unqualify(String qualifiedName, char separator)
/*      */   {
/*  484 */     return qualifiedName.substring(qualifiedName.lastIndexOf(separator) + 1);
/*      */   }
/*      */ 
/*      */   public static String capitalize(String str)
/*      */   {
/*  495 */     return changeFirstCharacterCase(str, true);
/*      */   }
/*      */ 
/*      */   public static String uncapitalize(String str)
/*      */   {
/*  506 */     return changeFirstCharacterCase(str, false);
/*      */   }
/*      */ 
/*      */   private static String changeFirstCharacterCase(String str, boolean capitalize) {
/*  510 */     if ((str == null) || (str.length() == 0)) {
/*  511 */       return str;
/*      */     }
/*  513 */     StringBuilder sb = new StringBuilder(str.length());
/*  514 */     if (capitalize) {
/*  515 */       sb.append(Character.toUpperCase(str.charAt(0)));
/*      */     }
/*      */     else {
/*  518 */       sb.append(Character.toLowerCase(str.charAt(0)));
/*      */     }
/*  520 */     sb.append(str.substring(1));
/*  521 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String getFilename(String path)
/*      */   {
/*  531 */     if (path == null) {
/*  532 */       return null;
/*      */     }
/*  534 */     int separatorIndex = path.lastIndexOf("/");
/*  535 */     return separatorIndex != -1 ? path.substring(separatorIndex + 1) : path;
/*      */   }
/*      */ 
/*      */   public static String getFilenameExtension(String path)
/*      */   {
/*  545 */     if (path == null) {
/*  546 */       return null;
/*      */     }
/*  548 */     int extIndex = path.lastIndexOf(46);
/*  549 */     if (extIndex == -1) {
/*  550 */       return null;
/*      */     }
/*  552 */     int folderIndex = path.lastIndexOf("/");
/*  553 */     if (folderIndex > extIndex) {
/*  554 */       return null;
/*      */     }
/*  556 */     return path.substring(extIndex + 1);
/*      */   }
/*      */ 
/*      */   public static String stripFilenameExtension(String path)
/*      */   {
/*  567 */     if (path == null) {
/*  568 */       return null;
/*      */     }
/*  570 */     int extIndex = path.lastIndexOf(46);
/*  571 */     if (extIndex == -1) {
/*  572 */       return path;
/*      */     }
/*  574 */     int folderIndex = path.lastIndexOf("/");
/*  575 */     if (folderIndex > extIndex) {
/*  576 */       return path;
/*      */     }
/*  578 */     return path.substring(0, extIndex);
/*      */   }
/*      */ 
/*      */   public static String applyRelativePath(String path, String relativePath)
/*      */   {
/*  590 */     int separatorIndex = path.lastIndexOf("/");
/*  591 */     if (separatorIndex != -1) {
/*  592 */       String newPath = path.substring(0, separatorIndex);
/*  593 */       if (!relativePath.startsWith("/")) {
/*  594 */         newPath = new StringBuilder().append(newPath).append("/").toString();
/*      */       }
/*  596 */       return new StringBuilder().append(newPath).append(relativePath).toString();
/*      */     }
/*      */ 
/*  599 */     return relativePath;
/*      */   }
/*      */ 
/*      */   public static String cleanPath(String path)
/*      */   {
/*  612 */     if (path == null) {
/*  613 */       return null;
/*      */     }
/*  615 */     String pathToUse = replace(path, "\\", "/");
/*      */ 
/*  621 */     int prefixIndex = pathToUse.indexOf(":");
/*  622 */     String prefix = "";
/*  623 */     if (prefixIndex != -1) {
/*  624 */       prefix = pathToUse.substring(0, prefixIndex + 1);
/*  625 */       pathToUse = pathToUse.substring(prefixIndex + 1);
/*      */     }
/*  627 */     if (pathToUse.startsWith("/")) {
/*  628 */       prefix = new StringBuilder().append(prefix).append("/").toString();
/*  629 */       pathToUse = pathToUse.substring(1);
/*      */     }
/*      */ 
/*  632 */     String[] pathArray = delimitedListToStringArray(pathToUse, "/");
/*  633 */     List pathElements = new LinkedList();
/*  634 */     int tops = 0;
/*      */ 
/*  636 */     for (int i = pathArray.length - 1; i >= 0; i--) {
/*  637 */       String element = pathArray[i];
/*  638 */       if (!".".equals(element))
/*      */       {
/*  641 */         if ("..".equals(element))
/*      */         {
/*  643 */           tops++;
/*      */         }
/*  646 */         else if (tops > 0)
/*      */         {
/*  648 */           tops--;
/*      */         }
/*      */         else
/*      */         {
/*  652 */           pathElements.add(0, element);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  658 */     for (int i = 0; i < tops; i++) {
/*  659 */       pathElements.add(0, "..");
/*      */     }
/*      */ 
/*  662 */     return new StringBuilder().append(prefix).append(collectionToDelimitedString(pathElements, "/")).toString();
/*      */   }
/*      */ 
/*      */   public static boolean pathEquals(String path1, String path2)
/*      */   {
/*  672 */     return cleanPath(path1).equals(cleanPath(path2));
/*      */   }
/*      */ 
/*      */   public static Locale parseLocaleString(String localeString)
/*      */   {
/*  685 */     String[] parts = tokenizeToStringArray(localeString, "_ ", false, false);
/*  686 */     String language = parts.length > 0 ? parts[0] : "";
/*  687 */     String country = parts.length > 1 ? parts[1] : "";
/*  688 */     validateLocalePart(language);
/*  689 */     validateLocalePart(country);
/*  690 */     String variant = "";
/*  691 */     if (parts.length > 2)
/*      */     {
/*  694 */       int endIndexOfCountryCode = localeString.lastIndexOf(country) + country.length();
/*      */ 
/*  696 */       variant = trimLeadingWhitespace(localeString.substring(endIndexOfCountryCode));
/*  697 */       if (variant.startsWith("_")) {
/*  698 */         variant = trimLeadingCharacter(variant, '_');
/*      */       }
/*      */     }
/*  701 */     return language.length() > 0 ? new Locale(language, country, variant) : null;
/*      */   }
/*      */ 
/*      */   private static void validateLocalePart(String localePart) {
/*  705 */     for (int i = 0; i < localePart.length(); i++) {
/*  706 */       char ch = localePart.charAt(i);
/*  707 */       if ((ch != '_') && (ch != ' ') && (!Character.isLetterOrDigit(ch)))
/*  708 */         throw new IllegalArgumentException(new StringBuilder().append("Locale part \"").append(localePart).append("\" contains invalid characters").toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String toLanguageTag(Locale locale)
/*      */   {
/*  721 */     return new StringBuilder().append(locale.getLanguage()).append(hasText(locale.getCountry()) ? new StringBuilder().append("-").append(locale.getCountry()).toString() : "").toString();
/*      */   }
/*      */ 
/*      */   public static TimeZone parseTimeZoneString(String timeZoneString)
/*      */   {
/*  732 */     TimeZone timeZone = TimeZone.getTimeZone(timeZoneString);
/*  733 */     if (("GMT".equals(timeZone.getID())) && (!timeZoneString.startsWith("GMT")))
/*      */     {
/*  735 */       throw new IllegalArgumentException(new StringBuilder().append("Invalid time zone specification '").append(timeZoneString).append("'").toString());
/*      */     }
/*  737 */     return timeZone;
/*      */   }
/*      */ 
/*      */   public static String[] addStringToArray(String[] array, String str)
/*      */   {
/*  753 */     if (ObjectUtils.isEmpty(array)) {
/*  754 */       return new String[] { str };
/*      */     }
/*  756 */     String[] newArr = new String[array.length + 1];
/*  757 */     System.arraycopy(array, 0, newArr, 0, array.length);
/*  758 */     newArr[array.length] = str;
/*  759 */     return newArr;
/*      */   }
/*      */ 
/*      */   public static String[] concatenateStringArrays(String[] array1, String[] array2)
/*      */   {
/*  771 */     if (ObjectUtils.isEmpty(array1)) {
/*  772 */       return array2;
/*      */     }
/*  774 */     if (ObjectUtils.isEmpty(array2)) {
/*  775 */       return array1;
/*      */     }
/*  777 */     String[] newArr = new String[array1.length + array2.length];
/*  778 */     System.arraycopy(array1, 0, newArr, 0, array1.length);
/*  779 */     System.arraycopy(array2, 0, newArr, array1.length, array2.length);
/*  780 */     return newArr;
/*      */   }
/*      */ 
/*      */   public static String[] mergeStringArrays(String[] array1, String[] array2)
/*      */   {
/*  794 */     if (ObjectUtils.isEmpty(array1)) {
/*  795 */       return array2;
/*      */     }
/*  797 */     if (ObjectUtils.isEmpty(array2)) {
/*  798 */       return array1;
/*      */     }
/*  800 */     List result = new ArrayList();
/*  801 */     result.addAll(Arrays.asList(array1));
/*  802 */     for (String str : array2) {
/*  803 */       if (!result.contains(str)) {
/*  804 */         result.add(str);
/*      */       }
/*      */     }
/*  807 */     return toStringArray(result);
/*      */   }
/*      */ 
/*      */   public static String[] sortStringArray(String[] array)
/*      */   {
/*  816 */     if (ObjectUtils.isEmpty(array)) {
/*  817 */       return new String[0];
/*      */     }
/*  819 */     Arrays.sort(array);
/*  820 */     return array;
/*      */   }
/*      */ 
/*      */   public static String[] toStringArray(Collection<String> collection)
/*      */   {
/*  831 */     if (collection == null) {
/*  832 */       return null;
/*      */     }
/*  834 */     return (String[])collection.toArray(new String[collection.size()]);
/*      */   }
/*      */ 
/*      */   public static String[] toStringArray(Enumeration<String> enumeration)
/*      */   {
/*  845 */     if (enumeration == null) {
/*  846 */       return null;
/*      */     }
/*  848 */     List list = Collections.list(enumeration);
/*  849 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */   public static String[] trimArrayElements(String[] array)
/*      */   {
/*  859 */     if (ObjectUtils.isEmpty(array)) {
/*  860 */       return new String[0];
/*      */     }
/*  862 */     String[] result = new String[array.length];
/*  863 */     for (int i = 0; i < array.length; i++) {
/*  864 */       String element = array[i];
/*  865 */       result[i] = (element != null ? element.trim() : null);
/*      */     }
/*  867 */     return result;
/*      */   }
/*      */ 
/*      */   public static String[] removeDuplicateStrings(String[] array)
/*      */   {
/*  877 */     if (ObjectUtils.isEmpty(array)) {
/*  878 */       return array;
/*      */     }
/*  880 */     Set set = new TreeSet();
/*  881 */     for (String element : array) {
/*  882 */       set.add(element);
/*      */     }
/*  884 */     return toStringArray(set);
/*      */   }
/*      */ 
/*      */   public static String[] split(String toSplit, String delimiter)
/*      */   {
/*  897 */     if ((!hasLength(toSplit)) || (!hasLength(delimiter))) {
/*  898 */       return null;
/*      */     }
/*  900 */     int offset = toSplit.indexOf(delimiter);
/*  901 */     if (offset < 0) {
/*  902 */       return null;
/*      */     }
/*  904 */     String beforeDelimiter = toSplit.substring(0, offset);
/*  905 */     String afterDelimiter = toSplit.substring(offset + delimiter.length());
/*  906 */     return new String[] { beforeDelimiter, afterDelimiter };
/*      */   }
/*      */ 
/*      */   public static Properties splitArrayElementsIntoProperties(String[] array, String delimiter)
/*      */   {
/*  921 */     return splitArrayElementsIntoProperties(array, delimiter, null);
/*      */   }
/*      */ 
/*      */   public static Properties splitArrayElementsIntoProperties(String[] array, String delimiter, String charsToDelete)
/*      */   {
/*  941 */     if (ObjectUtils.isEmpty(array)) {
/*  942 */       return null;
/*      */     }
/*  944 */     Properties result = new Properties();
/*  945 */     for (String element : array) {
/*  946 */       if (charsToDelete != null) {
/*  947 */         element = deleteAny(element, charsToDelete);
/*      */       }
/*  949 */       String[] splittedElement = split(element, delimiter);
/*  950 */       if (splittedElement != null)
/*      */       {
/*  953 */         result.setProperty(splittedElement[0].trim(), splittedElement[1].trim());
/*      */       }
/*      */     }
/*  955 */     return result;
/*      */   }
/*      */ 
/*      */   public static String[] tokenizeToStringArray(String str, String delimiters)
/*      */   {
/*  974 */     return tokenizeToStringArray(str, delimiters, true, true);
/*      */   }
/*      */ 
/*      */   public static String[] tokenizeToStringArray(String str, String delimiters, boolean trimTokens, boolean ignoreEmptyTokens)
/*      */   {
/*  999 */     if (str == null) {
/* 1000 */       return null;
/*      */     }
/* 1002 */     StringTokenizer st = new StringTokenizer(str, delimiters);
/* 1003 */     List tokens = new ArrayList();
/* 1004 */     while (st.hasMoreTokens()) {
/* 1005 */       String token = st.nextToken();
/* 1006 */       if (trimTokens) {
/* 1007 */         token = token.trim();
/*      */       }
/* 1009 */       if ((!ignoreEmptyTokens) || (token.length() > 0)) {
/* 1010 */         tokens.add(token);
/*      */       }
/*      */     }
/* 1013 */     return toStringArray(tokens);
/*      */   }
/*      */ 
/*      */   public static String[] delimitedListToStringArray(String str, String delimiter)
/*      */   {
/* 1028 */     return delimitedListToStringArray(str, delimiter, null);
/*      */   }
/*      */ 
/*      */   public static String[] delimitedListToStringArray(String str, String delimiter, String charsToDelete)
/*      */   {
/* 1045 */     if (str == null) {
/* 1046 */       return new String[0];
/*      */     }
/* 1048 */     if (delimiter == null) {
/* 1049 */       return new String[] { str };
/*      */     }
/* 1051 */     List result = new ArrayList();
/* 1052 */     if ("".equals(delimiter)) {
/* 1053 */       for (int i = 0; i < str.length(); i++)
/* 1054 */         result.add(deleteAny(str.substring(i, i + 1), charsToDelete));
/*      */     }
/*      */     else
/*      */     {
/* 1058 */       int pos = 0;
/*      */       int delPos;
/* 1060 */       while ((delPos = str.indexOf(delimiter, pos)) != -1) {
/* 1061 */         result.add(deleteAny(str.substring(pos, delPos), charsToDelete));
/* 1062 */         pos = delPos + delimiter.length();
/*      */       }
/* 1064 */       if ((str.length() > 0) && (pos <= str.length()))
/*      */       {
/* 1066 */         result.add(deleteAny(str.substring(pos), charsToDelete));
/*      */       }
/*      */     }
/* 1069 */     return toStringArray(result);
/*      */   }
/*      */ 
/*      */   public static String[] commaDelimitedListToStringArray(String str)
/*      */   {
/* 1078 */     return delimitedListToStringArray(str, ",");
/*      */   }
/*      */ 
/*      */   public static Set<String> commaDelimitedListToSet(String str)
/*      */   {
/* 1088 */     Set set = new TreeSet();
/* 1089 */     String[] tokens = commaDelimitedListToStringArray(str);
/* 1090 */     for (String token : tokens) {
/* 1091 */       set.add(token);
/*      */     }
/* 1093 */     return set;
/*      */   }
/*      */ 
/*      */   public static String collectionToDelimitedString(Collection<?> coll, String delim, String prefix, String suffix)
/*      */   {
/* 1106 */     if (CollectionUtils.isEmpty(coll)) {
/* 1107 */       return "";
/*      */     }
/* 1109 */     StringBuilder sb = new StringBuilder();
/* 1110 */     Iterator it = coll.iterator();
/* 1111 */     while (it.hasNext()) {
/* 1112 */       sb.append(prefix).append(it.next()).append(suffix);
/* 1113 */       if (it.hasNext()) {
/* 1114 */         sb.append(delim);
/*      */       }
/*      */     }
/* 1117 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String collectionToDelimitedString(Collection<?> coll, String delim)
/*      */   {
/* 1128 */     return collectionToDelimitedString(coll, delim, "", "");
/*      */   }
/*      */ 
/*      */   public static String collectionToCommaDelimitedString(Collection<?> coll)
/*      */   {
/* 1138 */     return collectionToDelimitedString(coll, ",");
/*      */   }
/*      */ 
/*      */   public static String arrayToDelimitedString(Object[] arr, String delim)
/*      */   {
/* 1149 */     if (ObjectUtils.isEmpty(arr)) {
/* 1150 */       return "";
/*      */     }
/* 1152 */     if (arr.length == 1) {
/* 1153 */       return ObjectUtils.nullSafeToString(arr[0]);
/*      */     }
/* 1155 */     StringBuilder sb = new StringBuilder();
/* 1156 */     for (int i = 0; i < arr.length; i++) {
/* 1157 */       if (i > 0) {
/* 1158 */         sb.append(delim);
/*      */       }
/* 1160 */       sb.append(arr[i]);
/*      */     }
/* 1162 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String arrayToCommaDelimitedString(Object[] arr)
/*      */   {
/* 1172 */     return arrayToDelimitedString(arr, ",");
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.StringUtils
 * JD-Core Version:    0.6.2
 */