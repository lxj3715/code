/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public abstract class SystemPropertyUtils
/*     */ {
/*     */   public static final String PLACEHOLDER_PREFIX = "${";
/*     */   public static final String PLACEHOLDER_SUFFIX = "}";
/*     */   public static final String VALUE_SEPARATOR = ":";
/*  48 */   private static final PropertyPlaceholderHelper strictHelper = new PropertyPlaceholderHelper("${", "}", ":", false);
/*     */ 
/*  51 */   private static final PropertyPlaceholderHelper nonStrictHelper = new PropertyPlaceholderHelper("${", "}", ":", true);
/*     */ 
/*     */   public static String resolvePlaceholders(String text)
/*     */   {
/*  64 */     return resolvePlaceholders(text, false);
/*     */   }
/*     */ 
/*     */   public static String resolvePlaceholders(String text, boolean ignoreUnresolvablePlaceholders)
/*     */   {
/*  79 */     PropertyPlaceholderHelper helper = ignoreUnresolvablePlaceholders ? nonStrictHelper : strictHelper;
/*  80 */     return helper.replacePlaceholders(text, new SystemPropertyPlaceholderResolver(text));
/*     */   }
/*     */ 
/*     */   private static class SystemPropertyPlaceholderResolver implements PropertyPlaceholderHelper.PlaceholderResolver
/*     */   {
/*     */     private final String text;
/*     */ 
/*     */     public SystemPropertyPlaceholderResolver(String text)
/*     */     {
/*  89 */       this.text = text;
/*     */     }
/*     */ 
/*     */     public String resolvePlaceholder(String placeholderName)
/*     */     {
/*     */       try {
/*  95 */         String propVal = System.getProperty(placeholderName);
/*  96 */         if (propVal == null);
/*  98 */         return System.getenv(placeholderName);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 103 */         System.err.println("Could not resolve placeholder '" + placeholderName + "' in [" + this.text + "] as system property: " + ex);
/*     */       }
/* 105 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.SystemPropertyUtils
 * JD-Core Version:    0.6.2
 */