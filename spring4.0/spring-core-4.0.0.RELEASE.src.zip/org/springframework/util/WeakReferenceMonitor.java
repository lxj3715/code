/*     */ package org.springframework.util;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class WeakReferenceMonitor
/*     */ {
/*  50 */   private static final Log logger = LogFactory.getLog(WeakReferenceMonitor.class);
/*     */ 
/*  53 */   private static final ReferenceQueue<Object> handleQueue = new ReferenceQueue();
/*     */ 
/*  56 */   private static final Map<Reference<?>, ReleaseListener> trackedEntries = new HashMap();
/*     */ 
/*  59 */   private static Thread monitoringThread = null;
/*     */ 
/*     */   public static void monitor(Object handle, ReleaseListener listener)
/*     */   {
/*  69 */     if (logger.isDebugEnabled()) {
/*  70 */       logger.debug("Monitoring handle [" + handle + "] with release listener [" + listener + "]");
/*     */     }
/*     */ 
/*  75 */     WeakReference weakRef = new WeakReference(handle, handleQueue);
/*     */ 
/*  78 */     addEntry(weakRef, listener);
/*     */   }
/*     */ 
/*     */   private static void addEntry(Reference<?> ref, ReleaseListener entry)
/*     */   {
/*  88 */     synchronized (WeakReferenceMonitor.class)
/*     */     {
/*  90 */       trackedEntries.put(ref, entry);
/*     */ 
/*  93 */       if (monitoringThread == null) {
/*  94 */         monitoringThread = new Thread(new MonitoringProcess(null), WeakReferenceMonitor.class.getName());
/*  95 */         monitoringThread.setDaemon(true);
/*  96 */         monitoringThread.start();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static ReleaseListener removeEntry(Reference<?> reference)
/*     */   {
/* 107 */     synchronized (WeakReferenceMonitor.class) {
/* 108 */       return (ReleaseListener)trackedEntries.remove(reference);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static boolean keepMonitoringThreadAlive()
/*     */   {
/* 117 */     synchronized (WeakReferenceMonitor.class) {
/* 118 */       if (!trackedEntries.isEmpty()) {
/* 119 */         return true;
/*     */       }
/*     */ 
/* 122 */       logger.debug("No entries left to track - stopping reference monitor thread");
/* 123 */       monitoringThread = null;
/* 124 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface ReleaseListener
/*     */   {
/*     */     public abstract void released();
/*     */   }
/*     */ 
/*     */   private static class MonitoringProcess implements Runnable
/*     */   {
/*     */     public void run()
/*     */     {
/* 137 */       WeakReferenceMonitor.logger.debug("Starting reference monitor thread");
/*     */       while (true)
/* 139 */         if (WeakReferenceMonitor.access$200())
/*     */           try {
/* 141 */             Reference reference = WeakReferenceMonitor.handleQueue.remove();
/*     */ 
/* 143 */             WeakReferenceMonitor.ReleaseListener entry = WeakReferenceMonitor.removeEntry(reference);
/* 144 */             if (entry != null)
/*     */               try
/*     */               {
/* 147 */                 entry.released();
/*     */               }
/*     */               catch (Throwable ex) {
/* 150 */                 WeakReferenceMonitor.logger.warn("Reference release listener threw exception", ex);
/*     */               }
/*     */           }
/*     */           catch (InterruptedException ex)
/*     */           {
/* 155 */             synchronized (WeakReferenceMonitor.class) {
/* 156 */               WeakReferenceMonitor.access$502(null);
/*     */             }
/* 158 */             WeakReferenceMonitor.logger.debug("Reference monitor thread interrupted", ex);
/*     */           }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.WeakReferenceMonitor
 * JD-Core Version:    0.6.2
 */