/*    */ package org.springframework.util.comparator;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class ComparableComparator<T extends Comparable<T>>
/*    */   implements Comparator<T>
/*    */ {
/* 33 */   public static final ComparableComparator INSTANCE = new ComparableComparator();
/*    */ 
/*    */   public int compare(T o1, T o2)
/*    */   {
/* 37 */     return o1.compareTo(o2);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.comparator.ComparableComparator
 * JD-Core Version:    0.6.2
 */