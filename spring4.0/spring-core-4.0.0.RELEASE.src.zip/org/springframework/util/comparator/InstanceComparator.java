/*    */ package org.springframework.util.comparator;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class InstanceComparator<T>
/*    */   implements Comparator<T>
/*    */ {
/*    */   private Class<?>[] instanceOrder;
/*    */ 
/*    */   public InstanceComparator(Class<?>[] instanceOrder)
/*    */   {
/* 50 */     Assert.notNull(instanceOrder, "InstanceOrder must not be null");
/* 51 */     this.instanceOrder = instanceOrder;
/*    */   }
/*    */ 
/*    */   public int compare(T o1, T o2)
/*    */   {
/* 57 */     int i1 = getOrder(o1);
/* 58 */     int i2 = getOrder(o2);
/* 59 */     return i1 == i2 ? 0 : i1 < i2 ? -1 : 1;
/*    */   }
/*    */ 
/*    */   private int getOrder(T object) {
/* 63 */     if (object != null) {
/* 64 */       for (int i = 0; i < this.instanceOrder.length; i++) {
/* 65 */         if (this.instanceOrder[i].isInstance(object)) {
/* 66 */           return i;
/*    */         }
/*    */       }
/*    */     }
/* 70 */     return this.instanceOrder.length;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.comparator.InstanceComparator
 * JD-Core Version:    0.6.2
 */