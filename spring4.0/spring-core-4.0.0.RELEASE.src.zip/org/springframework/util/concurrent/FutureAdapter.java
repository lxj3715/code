/*     */ package org.springframework.util.concurrent;
/*     */ 
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class FutureAdapter<T, S>
/*     */   implements Future<T>
/*     */ {
/*     */   private final Future<S> adaptee;
/*  41 */   private Object result = null;
/*     */ 
/*  43 */   private State state = State.NEW;
/*     */ 
/*  45 */   private final Object mutex = new Object();
/*     */ 
/*     */   protected FutureAdapter(Future<S> adaptee)
/*     */   {
/*  52 */     Assert.notNull(adaptee, "'delegate' must not be null");
/*  53 */     this.adaptee = adaptee;
/*     */   }
/*     */ 
/*     */   protected Future<S> getAdaptee()
/*     */   {
/*  60 */     return this.adaptee;
/*     */   }
/*     */ 
/*     */   public boolean cancel(boolean mayInterruptIfRunning)
/*     */   {
/*  65 */     return this.adaptee.cancel(mayInterruptIfRunning);
/*     */   }
/*     */ 
/*     */   public boolean isCancelled()
/*     */   {
/*  70 */     return this.adaptee.isCancelled();
/*     */   }
/*     */ 
/*     */   public boolean isDone()
/*     */   {
/*  75 */     return this.adaptee.isDone();
/*     */   }
/*     */ 
/*     */   public T get() throws InterruptedException, ExecutionException
/*     */   {
/*  80 */     return adaptInternal(this.adaptee.get());
/*     */   }
/*     */ 
/*     */   public T get(long timeout, TimeUnit unit)
/*     */     throws InterruptedException, ExecutionException, TimeoutException
/*     */   {
/*  86 */     return adaptInternal(this.adaptee.get(timeout, unit));
/*     */   }
/*     */ 
/*     */   final T adaptInternal(S adapteeResult) throws ExecutionException
/*     */   {
/*  91 */     synchronized (this.mutex) {
/*  92 */       switch (1.$SwitchMap$org$springframework$util$concurrent$FutureAdapter$State[this.state.ordinal()]) {
/*     */       case 1:
/*  94 */         return this.result;
/*     */       case 2:
/*  96 */         throw ((ExecutionException)this.result);
/*     */       case 3:
/*     */         try {
/*  99 */           Object adapted = adapt(adapteeResult);
/* 100 */           this.result = adapted;
/* 101 */           this.state = State.SUCCESS;
/* 102 */           return adapted;
/*     */         } catch (ExecutionException ex) {
/* 104 */           this.result = ex;
/* 105 */           this.state = State.FAILURE;
/* 106 */           throw ex;
/*     */         }
/*     */       }
/* 109 */       throw new IllegalStateException();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract T adapt(S paramS)
/*     */     throws ExecutionException;
/*     */ 
/*     */   private static enum State
/*     */   {
/* 120 */     NEW, SUCCESS, FAILURE;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.concurrent.FutureAdapter
 * JD-Core Version:    0.6.2
 */