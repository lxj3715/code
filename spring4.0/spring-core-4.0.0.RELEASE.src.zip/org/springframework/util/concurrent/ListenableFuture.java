package org.springframework.util.concurrent;

import java.util.concurrent.Future;

public abstract interface ListenableFuture<T> extends Future<T>
{
  public abstract void addCallback(ListenableFutureCallback<? super T> paramListenableFutureCallback);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.concurrent.ListenableFuture
 * JD-Core Version:    0.6.2
 */