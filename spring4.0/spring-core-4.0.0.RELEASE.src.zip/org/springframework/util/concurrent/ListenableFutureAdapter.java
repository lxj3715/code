/*    */ package org.springframework.util.concurrent;
/*    */ 
/*    */ import java.util.concurrent.ExecutionException;
/*    */ 
/*    */ public abstract class ListenableFutureAdapter<T, S> extends FutureAdapter<T, S>
/*    */   implements ListenableFuture<T>
/*    */ {
/*    */   protected ListenableFutureAdapter(ListenableFuture<S> adaptee)
/*    */   {
/* 41 */     super(adaptee);
/*    */   }
/*    */ 
/*    */   public void addCallback(final ListenableFutureCallback<? super T> callback)
/*    */   {
/* 47 */     ListenableFuture listenableAdaptee = (ListenableFuture)getAdaptee();
/* 48 */     listenableAdaptee.addCallback(new Object()
/*    */     {
/*    */       public void onSuccess(S result) {
/*    */         try {
/* 52 */           callback.onSuccess(ListenableFutureAdapter.this.adaptInternal(result));
/*    */         }
/*    */         catch (ExecutionException ex) {
/* 55 */           Throwable cause = ex.getCause();
/* 56 */           onFailure(cause != null ? cause : ex);
/*    */         }
/*    */         catch (Throwable t) {
/* 59 */           onFailure(t);
/*    */         }
/*    */       }
/*    */ 
/*    */       public void onFailure(Throwable t)
/*    */       {
/* 65 */         callback.onFailure(t);
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.concurrent.ListenableFutureAdapter
 * JD-Core Version:    0.6.2
 */