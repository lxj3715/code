package org.springframework.util.concurrent;

public abstract interface ListenableFutureCallback<T>
{
  public abstract void onSuccess(T paramT);

  public abstract void onFailure(Throwable paramThrowable);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.concurrent.ListenableFutureCallback
 * JD-Core Version:    0.6.2
 */