/*    */ package org.springframework.util.concurrent;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.Queue;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ListenableFutureCallbackRegistry<T>
/*    */ {
/*    */   private final Queue<ListenableFutureCallback<? super T>> callbacks;
/*    */   private State state;
/*    */   private Object result;
/*    */   private final Object mutex;
/*    */ 
/*    */   public ListenableFutureCallbackRegistry()
/*    */   {
/* 34 */     this.callbacks = new LinkedList();
/*    */ 
/* 37 */     this.state = State.NEW;
/*    */ 
/* 39 */     this.result = null;
/*    */ 
/* 41 */     this.mutex = new Object();
/*    */   }
/*    */ 
/*    */   public void addCallback(ListenableFutureCallback<? super T> callback)
/*    */   {
/* 50 */     Assert.notNull(callback, "'callback' must not be null");
/*    */ 
/* 52 */     synchronized (this.mutex) {
/* 53 */       switch (1.$SwitchMap$org$springframework$util$concurrent$ListenableFutureCallbackRegistry$State[this.state.ordinal()]) {
/*    */       case 1:
/* 55 */         this.callbacks.add(callback);
/* 56 */         break;
/*    */       case 2:
/* 58 */         callback.onSuccess(this.result);
/* 59 */         break;
/*    */       case 3:
/* 61 */         callback.onFailure((Throwable)this.result);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public void success(T result)
/*    */   {
/* 73 */     synchronized (this.mutex) {
/* 74 */       this.state = State.SUCCESS;
/* 75 */       this.result = result;
/*    */ 
/* 77 */       while (!this.callbacks.isEmpty())
/* 78 */         ((ListenableFutureCallback)this.callbacks.poll()).onSuccess(result);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void failure(Throwable t)
/*    */   {
/* 89 */     synchronized (this.mutex) {
/* 90 */       this.state = State.FAILURE;
/* 91 */       this.result = t;
/*    */ 
/* 93 */       while (!this.callbacks.isEmpty())
/* 94 */         ((ListenableFutureCallback)this.callbacks.poll()).onFailure(t);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static enum State {
/* 99 */     NEW, SUCCESS, FAILURE;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.concurrent.ListenableFutureCallbackRegistry
 * JD-Core Version:    0.6.2
 */