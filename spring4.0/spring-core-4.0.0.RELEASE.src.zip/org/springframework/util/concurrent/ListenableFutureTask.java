/*    */ package org.springframework.util.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import java.util.concurrent.FutureTask;
/*    */ 
/*    */ public class ListenableFutureTask<T> extends FutureTask<T>
/*    */   implements ListenableFuture<T>
/*    */ {
/* 32 */   private final ListenableFutureCallbackRegistry<T> callbacks = new ListenableFutureCallbackRegistry();
/*    */ 
/*    */   public ListenableFutureTask(Callable<T> callable)
/*    */   {
/* 41 */     super(callable);
/*    */   }
/*    */ 
/*    */   public ListenableFutureTask(Runnable runnable, T result)
/*    */   {
/* 52 */     super(runnable, result);
/*    */   }
/*    */ 
/*    */   public void addCallback(ListenableFutureCallback<? super T> callback)
/*    */   {
/* 57 */     this.callbacks.addCallback(callback);
/*    */   }
/*    */ 
/*    */   protected final void done()
/*    */   {
/*    */     Throwable cause;
/*    */     try {
/* 64 */       Object result = get();
/* 65 */       this.callbacks.success(result);
/* 66 */       return;
/*    */     }
/*    */     catch (InterruptedException ex) {
/* 69 */       Thread.currentThread().interrupt();
/* 70 */       return;
/*    */     }
/*    */     catch (ExecutionException ex) {
/* 73 */       cause = ex.getCause();
/* 74 */       if (cause == null)
/* 75 */         cause = ex;
/*    */     }
/*    */     catch (Throwable t)
/*    */     {
/* 79 */       cause = t;
/*    */     }
/* 81 */     this.callbacks.failure(cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.concurrent.ListenableFutureTask
 * JD-Core Version:    0.6.2
 */