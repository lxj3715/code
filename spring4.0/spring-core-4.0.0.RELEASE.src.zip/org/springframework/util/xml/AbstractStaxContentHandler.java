/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ abstract class AbstractStaxContentHandler
/*     */   implements ContentHandler
/*     */ {
/*  36 */   private SimpleNamespaceContext namespaceContext = new SimpleNamespaceContext();
/*     */ 
/*  38 */   private boolean namespaceContextChanged = false;
/*     */ 
/*     */   public final void startDocument() throws SAXException
/*     */   {
/*  42 */     this.namespaceContext.clear();
/*  43 */     this.namespaceContextChanged = false;
/*     */     try {
/*  45 */       startDocumentInternal();
/*     */     }
/*     */     catch (XMLStreamException ex) {
/*  48 */       throw new SAXException("Could not handle startDocument: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void startDocumentInternal() throws XMLStreamException;
/*     */ 
/*     */   public final void endDocument() throws SAXException
/*     */   {
/*  56 */     this.namespaceContext.clear();
/*  57 */     this.namespaceContextChanged = false;
/*     */     try {
/*  59 */       endDocumentInternal();
/*     */     }
/*     */     catch (XMLStreamException ex) {
/*  62 */       throw new SAXException("Could not handle startDocument: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void endDocumentInternal()
/*     */     throws XMLStreamException;
/*     */ 
/*     */   public final void startPrefixMapping(String prefix, String uri)
/*     */   {
/*  75 */     this.namespaceContext.bindNamespaceUri(prefix, uri);
/*  76 */     this.namespaceContextChanged = true;
/*     */   }
/*     */ 
/*     */   public final void endPrefixMapping(String prefix)
/*     */   {
/*  86 */     this.namespaceContext.removeBinding(prefix);
/*  87 */     this.namespaceContextChanged = true;
/*     */   }
/*     */ 
/*     */   public final void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
/*     */   {
/*     */     try {
/*  93 */       startElementInternal(toQName(uri, qName), atts, this.namespaceContextChanged ? this.namespaceContext : null);
/*  94 */       this.namespaceContextChanged = false;
/*     */     }
/*     */     catch (XMLStreamException ex) {
/*  97 */       throw new SAXException("Could not handle startElement: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void startElementInternal(QName paramQName, Attributes paramAttributes, SimpleNamespaceContext paramSimpleNamespaceContext) throws XMLStreamException;
/*     */ 
/*     */   public final void endElement(String uri, String localName, String qName) throws SAXException
/*     */   {
/*     */     try
/*     */     {
/* 107 */       endElementInternal(toQName(uri, qName), this.namespaceContextChanged ? this.namespaceContext : null);
/* 108 */       this.namespaceContextChanged = false;
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 111 */       throw new SAXException("Could not handle endElement: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void endElementInternal(QName paramQName, SimpleNamespaceContext paramSimpleNamespaceContext) throws XMLStreamException;
/*     */ 
/*     */   public final void characters(char[] ch, int start, int length) throws SAXException
/*     */   {
/*     */     try
/*     */     {
/* 121 */       charactersInternal(ch, start, length);
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 124 */       throw new SAXException("Could not handle characters: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void charactersInternal(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws XMLStreamException;
/*     */ 
/*     */   public final void ignorableWhitespace(char[] ch, int start, int length) throws SAXException
/*     */   {
/*     */     try {
/* 133 */       ignorableWhitespaceInternal(ch, start, length);
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 136 */       throw new SAXException("Could not handle ignorableWhitespace:" + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void ignorableWhitespaceInternal(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws XMLStreamException;
/*     */ 
/*     */   public final void processingInstruction(String target, String data) throws SAXException
/*     */   {
/*     */     try {
/* 145 */       processingInstructionInternal(target, data);
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 148 */       throw new SAXException("Could not handle processingInstruction: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void processingInstructionInternal(String paramString1, String paramString2) throws XMLStreamException;
/*     */ 
/*     */   public final void skippedEntity(String name) throws SAXException
/*     */   {
/*     */     try {
/* 157 */       skippedEntityInternal(name);
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 160 */       throw new SAXException("Could not handle skippedEntity: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected QName toQName(String namespaceUri, String qualifiedName)
/*     */   {
/* 173 */     int idx = qualifiedName.indexOf(':');
/* 174 */     if (idx == -1) {
/* 175 */       return new QName(namespaceUri, qualifiedName);
/*     */     }
/*     */ 
/* 178 */     String prefix = qualifiedName.substring(0, idx);
/* 179 */     String localPart = qualifiedName.substring(idx + 1);
/* 180 */     return new QName(namespaceUri, localPart, prefix);
/*     */   }
/*     */ 
/*     */   protected abstract void skippedEntityInternal(String paramString)
/*     */     throws XMLStreamException;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.AbstractStaxContentHandler
 * JD-Core Version:    0.6.2
 */