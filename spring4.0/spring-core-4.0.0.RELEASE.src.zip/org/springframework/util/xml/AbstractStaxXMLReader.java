/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ abstract class AbstractStaxXMLReader extends AbstractXMLReader
/*     */ {
/*     */   private static final String NAMESPACES_FEATURE_NAME = "http://xml.org/sax/features/namespaces";
/*     */   private static final String NAMESPACE_PREFIXES_FEATURE_NAME = "http://xml.org/sax/features/namespace-prefixes";
/*     */   private static final String IS_STANDALONE_FEATURE_NAME = "http://xml.org/sax/features/is-standalone";
/*     */   private boolean namespacesFeature;
/*     */   private boolean namespacePrefixesFeature;
/*     */   private Boolean isStandalone;
/*     */   private final Map<String, String> namespaces;
/*     */ 
/*     */   AbstractStaxXMLReader()
/*     */   {
/*  53 */     this.namespacesFeature = true;
/*     */ 
/*  55 */     this.namespacePrefixesFeature = false;
/*     */ 
/*  59 */     this.namespaces = new LinkedHashMap();
/*     */   }
/*     */ 
/*     */   public boolean getFeature(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
/*  63 */     if ("http://xml.org/sax/features/namespaces".equals(name)) {
/*  64 */       return this.namespacesFeature;
/*     */     }
/*  66 */     if ("http://xml.org/sax/features/namespace-prefixes".equals(name)) {
/*  67 */       return this.namespacePrefixesFeature;
/*     */     }
/*  69 */     if ("http://xml.org/sax/features/is-standalone".equals(name)) {
/*  70 */       if (this.isStandalone != null) {
/*  71 */         return this.isStandalone.booleanValue();
/*     */       }
/*     */ 
/*  74 */       throw new SAXNotSupportedException("startDocument() callback not completed yet");
/*     */     }
/*     */ 
/*  78 */     return super.getFeature(name);
/*     */   }
/*     */ 
/*     */   public void setFeature(String name, boolean value)
/*     */     throws SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/*  84 */     if ("http://xml.org/sax/features/namespaces".equals(name)) {
/*  85 */       this.namespacesFeature = value;
/*     */     }
/*  87 */     else if ("http://xml.org/sax/features/namespace-prefixes".equals(name)) {
/*  88 */       this.namespacePrefixesFeature = value;
/*     */     }
/*     */     else
/*  91 */       super.setFeature(name, value);
/*     */   }
/*     */ 
/*     */   protected void setStandalone(boolean standalone)
/*     */   {
/*  96 */     this.isStandalone = Boolean.valueOf(standalone);
/*     */   }
/*     */ 
/*     */   protected boolean hasNamespacesFeature()
/*     */   {
/* 103 */     return this.namespacesFeature;
/*     */   }
/*     */ 
/*     */   protected boolean hasNamespacePrefixesFeature()
/*     */   {
/* 110 */     return this.namespacePrefixesFeature;
/*     */   }
/*     */ 
/*     */   protected String toQualifiedName(QName qName)
/*     */   {
/* 121 */     String prefix = qName.getPrefix();
/* 122 */     if (!StringUtils.hasLength(prefix)) {
/* 123 */       return qName.getLocalPart();
/*     */     }
/*     */ 
/* 126 */     return prefix + ":" + qName.getLocalPart();
/*     */   }
/*     */ 
/*     */   public final void parse(InputSource ignored)
/*     */     throws SAXException
/*     */   {
/* 139 */     parse();
/*     */   }
/*     */ 
/*     */   public final void parse(String ignored)
/*     */     throws SAXException
/*     */   {
/* 150 */     parse();
/*     */   }
/*     */ 
/*     */   private void parse() throws SAXException {
/*     */     try {
/* 155 */       parseInternal();
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 158 */       Locator locator = null;
/* 159 */       if (ex.getLocation() != null) {
/* 160 */         locator = new StaxLocator(ex.getLocation());
/*     */       }
/* 162 */       SAXParseException saxException = new SAXParseException(ex.getMessage(), locator, ex);
/* 163 */       if (getErrorHandler() != null) {
/* 164 */         getErrorHandler().fatalError(saxException);
/*     */       }
/*     */       else
/* 167 */         throw saxException;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void parseInternal()
/*     */     throws SAXException, XMLStreamException;
/*     */ 
/*     */   protected void startPrefixMapping(String prefix, String namespace)
/*     */     throws SAXException
/*     */   {
/* 182 */     if (getContentHandler() != null) {
/* 183 */       if (prefix == null) {
/* 184 */         prefix = "";
/*     */       }
/* 186 */       if (!StringUtils.hasLength(namespace)) {
/* 187 */         return;
/*     */       }
/* 189 */       if (!namespace.equals(this.namespaces.get(prefix))) {
/* 190 */         getContentHandler().startPrefixMapping(prefix, namespace);
/* 191 */         this.namespaces.put(prefix, namespace);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void endPrefixMapping(String prefix)
/*     */     throws SAXException
/*     */   {
/* 201 */     if ((getContentHandler() != null) && 
/* 202 */       (this.namespaces.containsKey(prefix))) {
/* 203 */       getContentHandler().endPrefixMapping(prefix);
/* 204 */       this.namespaces.remove(prefix);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class StaxLocator
/*     */     implements Locator
/*     */   {
/*     */     private Location location;
/*     */ 
/*     */     protected StaxLocator(Location location)
/*     */     {
/* 219 */       this.location = location;
/*     */     }
/*     */ 
/*     */     public String getPublicId()
/*     */     {
/* 224 */       return this.location.getPublicId();
/*     */     }
/*     */ 
/*     */     public String getSystemId()
/*     */     {
/* 229 */       return this.location.getSystemId();
/*     */     }
/*     */ 
/*     */     public int getLineNumber()
/*     */     {
/* 234 */       return this.location.getLineNumber();
/*     */     }
/*     */ 
/*     */     public int getColumnNumber()
/*     */     {
/* 239 */       return this.location.getColumnNumber();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.AbstractStaxXMLReader
 * JD-Core Version:    0.6.2
 */