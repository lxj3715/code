/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.DTDHandler;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ 
/*     */ abstract class AbstractXMLReader
/*     */   implements XMLReader
/*     */ {
/*     */   private DTDHandler dtdHandler;
/*     */   private ContentHandler contentHandler;
/*     */   private EntityResolver entityResolver;
/*     */   private ErrorHandler errorHandler;
/*     */   private LexicalHandler lexicalHandler;
/*     */ 
/*     */   public ContentHandler getContentHandler()
/*     */   {
/*  53 */     return this.contentHandler;
/*     */   }
/*     */ 
/*     */   public void setContentHandler(ContentHandler contentHandler)
/*     */   {
/*  58 */     this.contentHandler = contentHandler;
/*     */   }
/*     */ 
/*     */   public void setDTDHandler(DTDHandler dtdHandler)
/*     */   {
/*  63 */     this.dtdHandler = dtdHandler;
/*     */   }
/*     */ 
/*     */   public DTDHandler getDTDHandler()
/*     */   {
/*  68 */     return this.dtdHandler;
/*     */   }
/*     */ 
/*     */   public EntityResolver getEntityResolver()
/*     */   {
/*  73 */     return this.entityResolver;
/*     */   }
/*     */ 
/*     */   public void setEntityResolver(EntityResolver entityResolver)
/*     */   {
/*  78 */     this.entityResolver = entityResolver;
/*     */   }
/*     */ 
/*     */   public ErrorHandler getErrorHandler()
/*     */   {
/*  83 */     return this.errorHandler;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/*  88 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   protected LexicalHandler getLexicalHandler() {
/*  92 */     return this.lexicalHandler;
/*     */   }
/*     */ 
/*     */   public boolean getFeature(String name)
/*     */     throws SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/* 103 */     throw new SAXNotRecognizedException(name);
/*     */   }
/*     */ 
/*     */   public void setFeature(String name, boolean value)
/*     */     throws SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/* 113 */     throw new SAXNotRecognizedException(name);
/*     */   }
/*     */ 
/*     */   public Object getProperty(String name)
/*     */     throws SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/* 122 */     if ("http://xml.org/sax/properties/lexical-handler".equals(name)) {
/* 123 */       return this.lexicalHandler;
/*     */     }
/*     */ 
/* 126 */     throw new SAXNotRecognizedException(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, Object value)
/*     */     throws SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/* 136 */     if ("http://xml.org/sax/properties/lexical-handler".equals(name)) {
/* 137 */       this.lexicalHandler = ((LexicalHandler)value);
/*     */     }
/*     */     else
/* 140 */       throw new SAXNotRecognizedException(name);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.AbstractXMLReader
 * JD-Core Version:    0.6.2
 */