/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.util.Assert;
/*     */ import org.w3c.dom.CharacterData;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.EntityReference;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.ContentHandler;
/*     */ 
/*     */ public abstract class DomUtils
/*     */ {
/*     */   public static List<Element> getChildElementsByTagName(Element ele, String[] childEleNames)
/*     */   {
/*  59 */     Assert.notNull(ele, "Element must not be null");
/*  60 */     Assert.notNull(childEleNames, "Element names collection must not be null");
/*  61 */     List childEleNameList = Arrays.asList(childEleNames);
/*  62 */     NodeList nl = ele.getChildNodes();
/*  63 */     List childEles = new ArrayList();
/*  64 */     for (int i = 0; i < nl.getLength(); i++) {
/*  65 */       Node node = nl.item(i);
/*  66 */       if (((node instanceof Element)) && (nodeNameMatch(node, childEleNameList))) {
/*  67 */         childEles.add((Element)node);
/*     */       }
/*     */     }
/*  70 */     return childEles;
/*     */   }
/*     */ 
/*     */   public static List<Element> getChildElementsByTagName(Element ele, String childEleName)
/*     */   {
/*  84 */     return getChildElementsByTagName(ele, new String[] { childEleName });
/*     */   }
/*     */ 
/*     */   public static Element getChildElementByTagName(Element ele, String childEleName)
/*     */   {
/*  94 */     Assert.notNull(ele, "Element must not be null");
/*  95 */     Assert.notNull(childEleName, "Element name must not be null");
/*  96 */     NodeList nl = ele.getChildNodes();
/*  97 */     for (int i = 0; i < nl.getLength(); i++) {
/*  98 */       Node node = nl.item(i);
/*  99 */       if (((node instanceof Element)) && (nodeNameMatch(node, childEleName))) {
/* 100 */         return (Element)node;
/*     */       }
/*     */     }
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getChildElementValueByTagName(Element ele, String childEleName)
/*     */   {
/* 113 */     Element child = getChildElementByTagName(ele, childEleName);
/* 114 */     return child != null ? getTextValue(child) : null;
/*     */   }
/*     */ 
/*     */   public static List<Element> getChildElements(Element ele)
/*     */   {
/* 123 */     Assert.notNull(ele, "Element must not be null");
/* 124 */     NodeList nl = ele.getChildNodes();
/* 125 */     List childEles = new ArrayList();
/* 126 */     for (int i = 0; i < nl.getLength(); i++) {
/* 127 */       Node node = nl.item(i);
/* 128 */       if ((node instanceof Element)) {
/* 129 */         childEles.add((Element)node);
/*     */       }
/*     */     }
/* 132 */     return childEles;
/*     */   }
/*     */ 
/*     */   public static String getTextValue(Element valueEle)
/*     */   {
/* 145 */     Assert.notNull(valueEle, "Element must not be null");
/* 146 */     StringBuilder sb = new StringBuilder();
/* 147 */     NodeList nl = valueEle.getChildNodes();
/* 148 */     for (int i = 0; i < nl.getLength(); i++) {
/* 149 */       Node item = nl.item(i);
/* 150 */       if ((((item instanceof CharacterData)) && (!(item instanceof Comment))) || ((item instanceof EntityReference))) {
/* 151 */         sb.append(item.getNodeValue());
/*     */       }
/*     */     }
/* 154 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static boolean nodeNameEquals(Node node, String desiredName)
/*     */   {
/* 163 */     Assert.notNull(node, "Node must not be null");
/* 164 */     Assert.notNull(desiredName, "Desired name must not be null");
/* 165 */     return nodeNameMatch(node, desiredName);
/*     */   }
/*     */ 
/*     */   public static ContentHandler createContentHandler(Node node)
/*     */   {
/* 174 */     return new DomContentHandler(node);
/*     */   }
/*     */ 
/*     */   private static boolean nodeNameMatch(Node node, String desiredName)
/*     */   {
/* 181 */     return (desiredName.equals(node.getNodeName())) || (desiredName.equals(node.getLocalName()));
/*     */   }
/*     */ 
/*     */   private static boolean nodeNameMatch(Node node, Collection<?> desiredNames)
/*     */   {
/* 188 */     return (desiredNames.contains(node.getNodeName())) || (desiredNames.contains(node.getLocalName()));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.DomUtils
 * JD-Core Version:    0.6.2
 */