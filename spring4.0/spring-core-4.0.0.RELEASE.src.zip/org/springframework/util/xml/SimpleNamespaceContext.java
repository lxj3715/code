/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SimpleNamespaceContext
/*     */   implements NamespaceContext
/*     */ {
/*  40 */   private Map<String, String> prefixToNamespaceUri = new HashMap();
/*     */ 
/*  42 */   private Map<String, List<String>> namespaceUriToPrefixes = new HashMap();
/*     */ 
/*  44 */   private String defaultNamespaceUri = "";
/*     */ 
/*     */   public String getNamespaceURI(String prefix)
/*     */   {
/*  48 */     Assert.notNull(prefix, "prefix is null");
/*  49 */     if ("xml".equals(prefix)) {
/*  50 */       return "http://www.w3.org/XML/1998/namespace";
/*     */     }
/*  52 */     if ("xmlns".equals(prefix)) {
/*  53 */       return "http://www.w3.org/2000/xmlns/";
/*     */     }
/*  55 */     if ("".equals(prefix)) {
/*  56 */       return this.defaultNamespaceUri;
/*     */     }
/*  58 */     if (this.prefixToNamespaceUri.containsKey(prefix)) {
/*  59 */       return (String)this.prefixToNamespaceUri.get(prefix);
/*     */     }
/*  61 */     return "";
/*     */   }
/*     */ 
/*     */   public String getPrefix(String namespaceUri)
/*     */   {
/*  66 */     List prefixes = getPrefixesInternal(namespaceUri);
/*  67 */     return prefixes.isEmpty() ? null : (String)prefixes.get(0);
/*     */   }
/*     */ 
/*     */   public Iterator<String> getPrefixes(String namespaceUri)
/*     */   {
/*  72 */     return getPrefixesInternal(namespaceUri).iterator();
/*     */   }
/*     */ 
/*     */   public void setBindings(Map<String, String> bindings)
/*     */   {
/*  81 */     for (Map.Entry entry : bindings.entrySet())
/*  82 */       bindNamespaceUri((String)entry.getKey(), (String)entry.getValue());
/*     */   }
/*     */ 
/*     */   public void bindDefaultNamespaceUri(String namespaceUri)
/*     */   {
/*  92 */     bindNamespaceUri("", namespaceUri);
/*     */   }
/*     */ 
/*     */   public void bindNamespaceUri(String prefix, String namespaceUri)
/*     */   {
/* 102 */     Assert.notNull(prefix, "No prefix given");
/* 103 */     Assert.notNull(namespaceUri, "No namespaceUri given");
/* 104 */     if ("".equals(prefix)) {
/* 105 */       this.defaultNamespaceUri = namespaceUri;
/*     */     }
/*     */     else {
/* 108 */       this.prefixToNamespaceUri.put(prefix, namespaceUri);
/* 109 */       getPrefixesInternal(namespaceUri).add(prefix);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 115 */     this.prefixToNamespaceUri.clear();
/*     */   }
/*     */ 
/*     */   public Iterator<String> getBoundPrefixes()
/*     */   {
/* 124 */     return this.prefixToNamespaceUri.keySet().iterator();
/*     */   }
/*     */ 
/*     */   private List<String> getPrefixesInternal(String namespaceUri) {
/* 128 */     if (this.defaultNamespaceUri.equals(namespaceUri)) {
/* 129 */       return Collections.singletonList("");
/*     */     }
/* 131 */     if ("http://www.w3.org/XML/1998/namespace".equals(namespaceUri)) {
/* 132 */       return Collections.singletonList("xml");
/*     */     }
/* 134 */     if ("http://www.w3.org/2000/xmlns/".equals(namespaceUri)) {
/* 135 */       return Collections.singletonList("xmlns");
/*     */     }
/*     */ 
/* 138 */     List list = (List)this.namespaceUriToPrefixes.get(namespaceUri);
/* 139 */     if (list == null) {
/* 140 */       list = new ArrayList();
/* 141 */       this.namespaceUriToPrefixes.put(namespaceUri, list);
/*     */     }
/* 143 */     return list;
/*     */   }
/*     */ 
/*     */   public void removeBinding(String prefix)
/*     */   {
/* 153 */     if ("".equals(prefix)) {
/* 154 */       this.defaultNamespaceUri = "";
/*     */     }
/*     */     else {
/* 157 */       String namespaceUri = (String)this.prefixToNamespaceUri.remove(prefix);
/* 158 */       List prefixes = getPrefixesInternal(namespaceUri);
/* 159 */       prefixes.remove(prefix);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.SimpleNamespaceContext
 * JD-Core Version:    0.6.2
 */