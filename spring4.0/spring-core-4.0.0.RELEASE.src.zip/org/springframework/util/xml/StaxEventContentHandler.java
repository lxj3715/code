/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.XMLEventConsumer;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ 
/*     */ class StaxEventContentHandler extends AbstractStaxContentHandler
/*     */ {
/*     */   private final XMLEventFactory eventFactory;
/*     */   private final XMLEventConsumer eventConsumer;
/*     */ 
/*     */   StaxEventContentHandler(XMLEventConsumer consumer)
/*     */   {
/*  59 */     this.eventFactory = XMLEventFactory.newInstance();
/*  60 */     this.eventConsumer = consumer;
/*     */   }
/*     */ 
/*     */   StaxEventContentHandler(XMLEventConsumer consumer, XMLEventFactory factory)
/*     */   {
/*  70 */     this.eventFactory = factory;
/*  71 */     this.eventConsumer = consumer;
/*     */   }
/*     */ 
/*     */   public void setDocumentLocator(Locator locator)
/*     */   {
/*  76 */     if (locator != null)
/*  77 */       this.eventFactory.setLocation(new LocatorLocationAdapter(locator));
/*     */   }
/*     */ 
/*     */   protected void startDocumentInternal()
/*     */     throws XMLStreamException
/*     */   {
/*  83 */     consumeEvent(this.eventFactory.createStartDocument());
/*     */   }
/*     */ 
/*     */   protected void endDocumentInternal() throws XMLStreamException
/*     */   {
/*  88 */     consumeEvent(this.eventFactory.createEndDocument());
/*     */   }
/*     */ 
/*     */   protected void startElementInternal(QName name, Attributes atts, SimpleNamespaceContext namespaceContext)
/*     */     throws XMLStreamException
/*     */   {
/*  95 */     List attributes = getAttributes(atts);
/*  96 */     List namespaces = createNamespaces(namespaceContext);
/*  97 */     consumeEvent(this.eventFactory.createStartElement(name, attributes.iterator(), namespaces != null ? namespaces
/*  98 */       .iterator() : null));
/*     */   }
/*     */ 
/*     */   protected void endElementInternal(QName name, SimpleNamespaceContext namespaceContext) throws XMLStreamException
/*     */   {
/* 103 */     List namespaces = createNamespaces(namespaceContext);
/* 104 */     consumeEvent(this.eventFactory.createEndElement(name, namespaces != null ? namespaces.iterator() : null));
/*     */   }
/*     */ 
/*     */   protected void charactersInternal(char[] ch, int start, int length) throws XMLStreamException
/*     */   {
/* 109 */     consumeEvent(this.eventFactory.createCharacters(new String(ch, start, length)));
/*     */   }
/*     */ 
/*     */   protected void ignorableWhitespaceInternal(char[] ch, int start, int length) throws XMLStreamException
/*     */   {
/* 114 */     consumeEvent(this.eventFactory.createIgnorableSpace(new String(ch, start, length)));
/*     */   }
/*     */ 
/*     */   protected void processingInstructionInternal(String target, String data) throws XMLStreamException
/*     */   {
/* 119 */     consumeEvent(this.eventFactory.createProcessingInstruction(target, data));
/*     */   }
/*     */ 
/*     */   private void consumeEvent(XMLEvent event) throws XMLStreamException {
/* 123 */     this.eventConsumer.add(event);
/*     */   }
/*     */ 
/*     */   private List<Namespace> createNamespaces(SimpleNamespaceContext namespaceContext)
/*     */   {
/* 130 */     if (namespaceContext == null) {
/* 131 */       return null;
/*     */     }
/*     */ 
/* 134 */     List namespaces = new ArrayList();
/* 135 */     String defaultNamespaceUri = namespaceContext.getNamespaceURI("");
/* 136 */     if (StringUtils.hasLength(defaultNamespaceUri)) {
/* 137 */       namespaces.add(this.eventFactory.createNamespace(defaultNamespaceUri));
/*     */     }
/* 139 */     for (Iterator iterator = namespaceContext.getBoundPrefixes(); iterator.hasNext(); ) {
/* 140 */       String prefix = (String)iterator.next();
/* 141 */       String namespaceUri = namespaceContext.getNamespaceURI(prefix);
/* 142 */       namespaces.add(this.eventFactory.createNamespace(prefix, namespaceUri));
/*     */     }
/* 144 */     return namespaces;
/*     */   }
/*     */ 
/*     */   private List<Attribute> getAttributes(Attributes attributes) {
/* 148 */     List list = new ArrayList();
/* 149 */     for (int i = 0; i < attributes.getLength(); i++) {
/* 150 */       QName name = toQName(attributes.getURI(i), attributes.getQName(i));
/* 151 */       if ((!"xmlns".equals(name.getLocalPart())) && (!"xmlns".equals(name.getPrefix()))) {
/* 152 */         list.add(this.eventFactory.createAttribute(name, attributes.getValue(i)));
/*     */       }
/*     */     }
/* 155 */     return list;
/*     */   }
/*     */ 
/*     */   protected void skippedEntityInternal(String name)
/*     */     throws XMLStreamException
/*     */   {
/*     */   }
/*     */ 
/*     */   private static final class LocatorLocationAdapter implements Location
/*     */   {
/*     */     private final Locator locator;
/*     */ 
/*     */     public LocatorLocationAdapter(Locator locator)
/*     */     {
/* 169 */       this.locator = locator;
/*     */     }
/*     */ 
/*     */     public int getLineNumber()
/*     */     {
/* 174 */       return this.locator.getLineNumber();
/*     */     }
/*     */ 
/*     */     public int getColumnNumber()
/*     */     {
/* 179 */       return this.locator.getColumnNumber();
/*     */     }
/*     */ 
/*     */     public int getCharacterOffset()
/*     */     {
/* 184 */       return -1;
/*     */     }
/*     */ 
/*     */     public String getPublicId()
/*     */     {
/* 189 */       return this.locator.getPublicId();
/*     */     }
/*     */ 
/*     */     public String getSystemId()
/*     */     {
/* 194 */       return this.locator.getSystemId();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.StaxEventContentHandler
 * JD-Core Version:    0.6.2
 */