/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import org.xml.sax.ContentHandler;
/*     */ 
/*     */ class StaxResult extends SAXResult
/*     */ {
/*     */   private XMLEventWriter eventWriter;
/*     */   private XMLStreamWriter streamWriter;
/*     */ 
/*     */   StaxResult(XMLStreamWriter streamWriter)
/*     */   {
/*  58 */     super.setHandler(new StaxStreamContentHandler(streamWriter));
/*  59 */     this.streamWriter = streamWriter;
/*     */   }
/*     */ 
/*     */   StaxResult(XMLEventWriter eventWriter)
/*     */   {
/*  67 */     super.setHandler(new StaxEventContentHandler(eventWriter));
/*  68 */     this.eventWriter = eventWriter;
/*     */   }
/*     */ 
/*     */   StaxResult(XMLEventWriter eventWriter, XMLEventFactory eventFactory)
/*     */   {
/*  78 */     super.setHandler(new StaxEventContentHandler(eventWriter, eventFactory));
/*  79 */     this.eventWriter = eventWriter;
/*     */   }
/*     */ 
/*     */   XMLEventWriter getXMLEventWriter()
/*     */   {
/*  90 */     return this.eventWriter;
/*     */   }
/*     */ 
/*     */   XMLStreamWriter getXMLStreamWriter()
/*     */   {
/* 100 */     return this.streamWriter;
/*     */   }
/*     */ 
/*     */   public void setHandler(ContentHandler handler)
/*     */   {
/* 110 */     throw new UnsupportedOperationException("setHandler is not supported");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.StaxResult
 * JD-Core Version:    0.6.2
 */