/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ 
/*     */ class StaxStreamContentHandler extends AbstractStaxContentHandler
/*     */ {
/*     */   private final XMLStreamWriter streamWriter;
/*     */ 
/*     */   StaxStreamContentHandler(XMLStreamWriter streamWriter)
/*     */   {
/*  48 */     Assert.notNull(streamWriter, "'streamWriter' must not be null");
/*  49 */     this.streamWriter = streamWriter;
/*     */   }
/*     */ 
/*     */   public void setDocumentLocator(Locator locator)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void charactersInternal(char[] ch, int start, int length) throws XMLStreamException
/*     */   {
/*  58 */     this.streamWriter.writeCharacters(ch, start, length);
/*     */   }
/*     */ 
/*     */   protected void endDocumentInternal() throws XMLStreamException
/*     */   {
/*  63 */     this.streamWriter.writeEndDocument();
/*     */   }
/*     */ 
/*     */   protected void endElementInternal(QName name, SimpleNamespaceContext namespaceContext) throws XMLStreamException
/*     */   {
/*  68 */     this.streamWriter.writeEndElement();
/*     */   }
/*     */ 
/*     */   protected void ignorableWhitespaceInternal(char[] ch, int start, int length) throws XMLStreamException
/*     */   {
/*  73 */     this.streamWriter.writeCharacters(ch, start, length);
/*     */   }
/*     */ 
/*     */   protected void processingInstructionInternal(String target, String data) throws XMLStreamException
/*     */   {
/*  78 */     this.streamWriter.writeProcessingInstruction(target, data);
/*     */   }
/*     */ 
/*     */   protected void skippedEntityInternal(String name)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void startDocumentInternal() throws XMLStreamException
/*     */   {
/*  87 */     this.streamWriter.writeStartDocument();
/*     */   }
/*     */ 
/*     */   protected void startElementInternal(QName name, Attributes attributes, SimpleNamespaceContext namespaceContext)
/*     */     throws XMLStreamException
/*     */   {
/*  93 */     this.streamWriter.writeStartElement(name.getPrefix(), name.getLocalPart(), name.getNamespaceURI());
/*     */     Iterator iterator;
/*  94 */     if (namespaceContext != null) {
/*  95 */       String defaultNamespaceUri = namespaceContext.getNamespaceURI("");
/*  96 */       if (StringUtils.hasLength(defaultNamespaceUri)) {
/*  97 */         this.streamWriter.writeNamespace("", defaultNamespaceUri);
/*  98 */         this.streamWriter.setDefaultNamespace(defaultNamespaceUri);
/*     */       }
/* 100 */       for (iterator = namespaceContext.getBoundPrefixes(); iterator.hasNext(); ) {
/* 101 */         String prefix = (String)iterator.next();
/* 102 */         this.streamWriter.writeNamespace(prefix, namespaceContext.getNamespaceURI(prefix));
/* 103 */         this.streamWriter.setPrefix(prefix, namespaceContext.getNamespaceURI(prefix));
/*     */       }
/*     */     }
/* 106 */     for (int i = 0; i < attributes.getLength(); i++) {
/* 107 */       QName attrName = toQName(attributes.getURI(i), attributes.getQName(i));
/* 108 */       if ((!"xmlns".equals(attrName.getLocalPart())) && (!"xmlns".equals(attrName.getPrefix())))
/* 109 */         this.streamWriter.writeAttribute(attrName.getPrefix(), attrName.getNamespaceURI(), attrName.getLocalPart(), attributes
/* 110 */           .getValue(i));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.StaxStreamContentHandler
 * JD-Core Version:    0.6.2
 */