/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.Comment;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.ProcessingInstruction;
/*     */ import javax.xml.stream.events.StartDocument;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ class XMLEventStreamReader extends AbstractXMLStreamReader
/*     */ {
/*     */   private XMLEvent event;
/*     */   private final XMLEventReader eventReader;
/*     */ 
/*     */   XMLEventStreamReader(XMLEventReader eventReader)
/*     */     throws XMLStreamException
/*     */   {
/*  50 */     this.eventReader = eventReader;
/*  51 */     this.event = eventReader.nextEvent();
/*     */   }
/*     */ 
/*     */   public boolean isStandalone()
/*     */   {
/*  56 */     if (this.event.isStartDocument()) {
/*  57 */       return ((StartDocument)this.event).isStandalone();
/*     */     }
/*     */ 
/*  60 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public String getVersion()
/*     */   {
/*  66 */     if (this.event.isStartDocument()) {
/*  67 */       return ((StartDocument)this.event).getVersion();
/*     */     }
/*     */ 
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */   public int getTextStart()
/*     */   {
/*  76 */     return 0;
/*     */   }
/*     */ 
/*     */   public String getText()
/*     */   {
/*  81 */     if (this.event.isCharacters()) {
/*  82 */       return this.event.asCharacters().getData();
/*     */     }
/*  84 */     if (this.event.getEventType() == 5) {
/*  85 */       return ((Comment)this.event).getText();
/*     */     }
/*     */ 
/*  88 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public String getPITarget()
/*     */   {
/*  94 */     if (this.event.isProcessingInstruction()) {
/*  95 */       return ((ProcessingInstruction)this.event).getTarget();
/*     */     }
/*     */ 
/*  98 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public String getPIData()
/*     */   {
/* 104 */     if (this.event.isProcessingInstruction()) {
/* 105 */       return ((ProcessingInstruction)this.event).getData();
/*     */     }
/*     */ 
/* 108 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public int getNamespaceCount()
/*     */   {
/*     */     Iterator namespaces;
/* 115 */     if (this.event.isStartElement()) {
/* 116 */       namespaces = this.event.asStartElement().getNamespaces();
/*     */     }
/*     */     else
/*     */     {
/*     */       Iterator namespaces;
/* 118 */       if (this.event.isEndElement()) {
/* 119 */         namespaces = this.event.asEndElement().getNamespaces();
/*     */       }
/*     */       else
/* 122 */         throw new IllegalStateException();
/*     */     }
/*     */     Iterator namespaces;
/* 124 */     return countIterator(namespaces);
/*     */   }
/*     */ 
/*     */   public NamespaceContext getNamespaceContext()
/*     */   {
/* 129 */     if (this.event.isStartElement()) {
/* 130 */       return this.event.asStartElement().getNamespaceContext();
/*     */     }
/*     */ 
/* 133 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public QName getName()
/*     */   {
/* 139 */     if (this.event.isStartElement()) {
/* 140 */       return this.event.asStartElement().getName();
/*     */     }
/* 142 */     if (this.event.isEndElement()) {
/* 143 */       return this.event.asEndElement().getName();
/*     */     }
/*     */ 
/* 146 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public Location getLocation()
/*     */   {
/* 152 */     return this.event.getLocation();
/*     */   }
/*     */ 
/*     */   public int getEventType()
/*     */   {
/* 157 */     return this.event.getEventType();
/*     */   }
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   public String getCharacterEncodingScheme()
/*     */   {
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   public int getAttributeCount()
/*     */   {
/* 172 */     if (!this.event.isStartElement()) {
/* 173 */       throw new IllegalStateException();
/*     */     }
/* 175 */     Iterator attributes = this.event.asStartElement().getAttributes();
/* 176 */     return countIterator(attributes);
/*     */   }
/*     */ 
/*     */   public void close() throws XMLStreamException
/*     */   {
/* 181 */     this.eventReader.close();
/*     */   }
/*     */ 
/*     */   public QName getAttributeName(int index)
/*     */   {
/* 186 */     return getAttribute(index).getName();
/*     */   }
/*     */ 
/*     */   public String getAttributeType(int index)
/*     */   {
/* 191 */     return getAttribute(index).getDTDType();
/*     */   }
/*     */ 
/*     */   public String getAttributeValue(int index)
/*     */   {
/* 196 */     return getAttribute(index).getValue();
/*     */   }
/*     */ 
/*     */   public String getNamespacePrefix(int index)
/*     */   {
/* 201 */     return getNamespace(index).getPrefix();
/*     */   }
/*     */ 
/*     */   public String getNamespaceURI(int index)
/*     */   {
/* 206 */     return getNamespace(index).getNamespaceURI();
/*     */   }
/*     */ 
/*     */   public Object getProperty(String name) throws IllegalArgumentException
/*     */   {
/* 211 */     return this.eventReader.getProperty(name);
/*     */   }
/*     */ 
/*     */   public boolean isAttributeSpecified(int index)
/*     */   {
/* 216 */     return getAttribute(index).isSpecified();
/*     */   }
/*     */ 
/*     */   public int next() throws XMLStreamException
/*     */   {
/* 221 */     this.event = this.eventReader.nextEvent();
/* 222 */     return this.event.getEventType();
/*     */   }
/*     */ 
/*     */   public boolean standaloneSet()
/*     */   {
/* 227 */     if (this.event.isStartDocument()) {
/* 228 */       return ((StartDocument)this.event).standaloneSet();
/*     */     }
/*     */ 
/* 231 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   private int countIterator(Iterator iterator)
/*     */   {
/* 236 */     int count = 0;
/* 237 */     while (iterator.hasNext()) {
/* 238 */       iterator.next();
/* 239 */       count++;
/*     */     }
/* 241 */     return count;
/*     */   }
/*     */ 
/*     */   private Attribute getAttribute(int index) {
/* 245 */     if (!this.event.isStartElement()) {
/* 246 */       throw new IllegalStateException();
/*     */     }
/* 248 */     int count = 0;
/* 249 */     Iterator attributes = this.event.asStartElement().getAttributes();
/* 250 */     while (attributes.hasNext()) {
/* 251 */       Attribute attribute = (Attribute)attributes.next();
/* 252 */       if (count == index) {
/* 253 */         return attribute;
/*     */       }
/*     */ 
/* 256 */       count++;
/*     */     }
/*     */ 
/* 259 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   private Namespace getNamespace(int index)
/*     */   {
/*     */     Iterator namespaces;
/* 264 */     if (this.event.isStartElement()) {
/* 265 */       namespaces = this.event.asStartElement().getNamespaces();
/*     */     }
/*     */     else
/*     */     {
/*     */       Iterator namespaces;
/* 267 */       if (this.event.isEndElement()) {
/* 268 */         namespaces = this.event.asEndElement().getNamespaces();
/*     */       }
/*     */       else
/* 271 */         throw new IllegalStateException();
/*     */     }
/*     */     Iterator namespaces;
/* 273 */     int count = 0;
/* 274 */     while (namespaces.hasNext()) {
/* 275 */       Namespace namespace = (Namespace)namespaces.next();
/* 276 */       if (count == index) {
/* 277 */         return namespace;
/*     */       }
/*     */ 
/* 280 */       count++;
/*     */     }
/*     */ 
/* 283 */     throw new IllegalArgumentException();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.XMLEventStreamReader
 * JD-Core Version:    0.6.2
 */