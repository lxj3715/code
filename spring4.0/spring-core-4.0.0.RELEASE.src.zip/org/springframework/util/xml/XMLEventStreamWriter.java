/*     */ package org.springframework.util.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ class XMLEventStreamWriter
/*     */   implements XMLStreamWriter
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*     */   private final XMLEventWriter eventWriter;
/*     */   private final XMLEventFactory eventFactory;
/*  51 */   private List<EndElement> endElements = new ArrayList();
/*     */ 
/*     */   public XMLEventStreamWriter(XMLEventWriter eventWriter, XMLEventFactory eventFactory) {
/*  54 */     Assert.notNull(eventWriter, "'eventWriter' must not be null");
/*  55 */     Assert.notNull(eventFactory, "'eventFactory' must not be null");
/*     */ 
/*  57 */     this.eventWriter = eventWriter;
/*  58 */     this.eventFactory = eventFactory;
/*     */   }
/*     */ 
/*     */   public NamespaceContext getNamespaceContext()
/*     */   {
/*  63 */     return this.eventWriter.getNamespaceContext();
/*     */   }
/*     */ 
/*     */   public String getPrefix(String uri) throws XMLStreamException
/*     */   {
/*  68 */     return this.eventWriter.getPrefix(uri);
/*     */   }
/*     */ 
/*     */   public void setPrefix(String prefix, String uri) throws XMLStreamException
/*     */   {
/*  73 */     this.eventWriter.setPrefix(prefix, uri);
/*     */   }
/*     */ 
/*     */   public void setDefaultNamespace(String uri) throws XMLStreamException
/*     */   {
/*  78 */     this.eventWriter.setDefaultNamespace(uri);
/*     */   }
/*     */ 
/*     */   public void setNamespaceContext(NamespaceContext context) throws XMLStreamException
/*     */   {
/*  83 */     this.eventWriter.setNamespaceContext(context);
/*     */   }
/*     */ 
/*     */   public void writeStartDocument() throws XMLStreamException
/*     */   {
/*  88 */     this.eventWriter.add(this.eventFactory.createStartDocument());
/*     */   }
/*     */ 
/*     */   public void writeStartDocument(String version) throws XMLStreamException
/*     */   {
/*  93 */     this.eventWriter.add(this.eventFactory.createStartDocument("UTF-8", version));
/*     */   }
/*     */ 
/*     */   public void writeStartDocument(String encoding, String version) throws XMLStreamException
/*     */   {
/*  98 */     this.eventWriter.add(this.eventFactory.createStartDocument(encoding, version));
/*     */   }
/*     */ 
/*     */   public void writeStartElement(String localName) throws XMLStreamException
/*     */   {
/* 103 */     writeStartElement(this.eventFactory.createStartElement(new QName(localName), null, null));
/*     */   }
/*     */ 
/*     */   public void writeStartElement(String namespaceURI, String localName) throws XMLStreamException
/*     */   {
/* 108 */     writeStartElement(this.eventFactory.createStartElement(new QName(namespaceURI, localName), null, null));
/*     */   }
/*     */ 
/*     */   public void writeStartElement(String prefix, String localName, String namespaceURI) throws XMLStreamException
/*     */   {
/* 113 */     writeStartElement(this.eventFactory.createStartElement(new QName(namespaceURI, localName, prefix), null, null));
/*     */   }
/*     */ 
/*     */   public void writeEmptyElement(String localName) throws XMLStreamException
/*     */   {
/* 118 */     writeStartElement(localName);
/* 119 */     writeEndElement();
/*     */   }
/*     */ 
/*     */   public void writeEmptyElement(String namespaceURI, String localName) throws XMLStreamException
/*     */   {
/* 124 */     writeStartElement(namespaceURI, localName);
/* 125 */     writeEndElement();
/*     */   }
/*     */ 
/*     */   public void writeEmptyElement(String prefix, String localName, String namespaceURI) throws XMLStreamException
/*     */   {
/* 130 */     writeStartElement(prefix, localName, namespaceURI);
/* 131 */     writeEndElement();
/*     */   }
/*     */ 
/*     */   public void writeEndElement() throws XMLStreamException
/*     */   {
/* 136 */     int last = this.endElements.size() - 1;
/* 137 */     EndElement lastEndElement = (EndElement)this.endElements.get(last);
/* 138 */     this.eventWriter.add(lastEndElement);
/* 139 */     this.endElements.remove(last);
/*     */   }
/*     */ 
/*     */   public void writeAttribute(String localName, String value) throws XMLStreamException
/*     */   {
/* 144 */     this.eventWriter.add(this.eventFactory.createAttribute(localName, value));
/*     */   }
/*     */ 
/*     */   public void writeAttribute(String namespaceURI, String localName, String value) throws XMLStreamException
/*     */   {
/* 149 */     this.eventWriter.add(this.eventFactory.createAttribute(new QName(namespaceURI, localName), value));
/*     */   }
/*     */ 
/*     */   public void writeAttribute(String prefix, String namespaceURI, String localName, String value)
/*     */     throws XMLStreamException
/*     */   {
/* 155 */     this.eventWriter.add(this.eventFactory.createAttribute(prefix, namespaceURI, localName, value));
/*     */   }
/*     */ 
/*     */   public void writeNamespace(String prefix, String namespaceURI) throws XMLStreamException
/*     */   {
/* 160 */     writeNamespace(this.eventFactory.createNamespace(prefix, namespaceURI));
/*     */   }
/*     */ 
/*     */   public void writeDefaultNamespace(String namespaceURI) throws XMLStreamException
/*     */   {
/* 165 */     writeNamespace(this.eventFactory.createNamespace(namespaceURI));
/*     */   }
/*     */ 
/*     */   public void writeCharacters(String text) throws XMLStreamException
/*     */   {
/* 170 */     this.eventWriter.add(this.eventFactory.createCharacters(text));
/*     */   }
/*     */ 
/*     */   public void writeCharacters(char[] text, int start, int len) throws XMLStreamException
/*     */   {
/* 175 */     this.eventWriter.add(this.eventFactory.createCharacters(new String(text, start, len)));
/*     */   }
/*     */ 
/*     */   public void writeCData(String data) throws XMLStreamException
/*     */   {
/* 180 */     this.eventWriter.add(this.eventFactory.createCData(data));
/*     */   }
/*     */ 
/*     */   public void writeComment(String data) throws XMLStreamException
/*     */   {
/* 185 */     this.eventWriter.add(this.eventFactory.createComment(data));
/*     */   }
/*     */ 
/*     */   public void writeProcessingInstruction(String target) throws XMLStreamException
/*     */   {
/* 190 */     this.eventWriter.add(this.eventFactory.createProcessingInstruction(target, ""));
/*     */   }
/*     */ 
/*     */   public void writeProcessingInstruction(String target, String data) throws XMLStreamException
/*     */   {
/* 195 */     this.eventWriter.add(this.eventFactory.createProcessingInstruction(target, data));
/*     */   }
/*     */ 
/*     */   public void writeDTD(String dtd) throws XMLStreamException
/*     */   {
/* 200 */     this.eventWriter.add(this.eventFactory.createDTD(dtd));
/*     */   }
/*     */ 
/*     */   public void writeEntityRef(String name) throws XMLStreamException
/*     */   {
/* 205 */     this.eventWriter.add(this.eventFactory.createEntityReference(name, null));
/*     */   }
/*     */ 
/*     */   public void writeEndDocument() throws XMLStreamException
/*     */   {
/* 210 */     this.eventWriter.add(this.eventFactory.createEndDocument());
/*     */   }
/*     */ 
/*     */   public Object getProperty(String name) throws IllegalArgumentException
/*     */   {
/* 215 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   public void flush() throws XMLStreamException
/*     */   {
/* 220 */     this.eventWriter.flush();
/*     */   }
/*     */ 
/*     */   public void close() throws XMLStreamException
/*     */   {
/* 225 */     this.eventWriter.close();
/*     */   }
/*     */ 
/*     */   private void writeStartElement(StartElement startElement) throws XMLStreamException {
/* 229 */     this.eventWriter.add(startElement);
/* 230 */     this.endElements.add(this.eventFactory.createEndElement(startElement.getName(), startElement.getNamespaces()));
/*     */   }
/*     */ 
/*     */   private void writeNamespace(Namespace namespace) throws XMLStreamException {
/* 234 */     int last = this.endElements.size() - 1;
/* 235 */     EndElement oldEndElement = (EndElement)this.endElements.get(last);
/* 236 */     Iterator oldNamespaces = oldEndElement.getNamespaces();
/* 237 */     List newNamespaces = new ArrayList();
/* 238 */     while (oldNamespaces.hasNext()) {
/* 239 */       Namespace oldNamespace = (Namespace)oldNamespaces.next();
/* 240 */       newNamespaces.add(oldNamespace);
/*     */     }
/* 242 */     newNamespaces.add(namespace);
/* 243 */     EndElement newEndElement = this.eventFactory.createEndElement(oldEndElement.getName(), newNamespaces.iterator());
/* 244 */     this.eventWriter.add(namespace);
/* 245 */     this.endElements.set(last, newEndElement);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-core-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.util.xml.XMLEventStreamWriter
 * JD-Core Version:    0.6.2
 */