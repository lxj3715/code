/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class CannotAcquireLockException extends PessimisticLockingFailureException
/*    */ {
/*    */   public CannotAcquireLockException(String msg)
/*    */   {
/* 33 */     super(msg);
/*    */   }
/*    */ 
/*    */   public CannotAcquireLockException(String msg, Throwable cause)
/*    */   {
/* 42 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.CannotAcquireLockException
 * JD-Core Version:    0.6.2
 */