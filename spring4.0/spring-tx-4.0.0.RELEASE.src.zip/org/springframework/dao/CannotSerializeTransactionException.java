/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class CannotSerializeTransactionException extends PessimisticLockingFailureException
/*    */ {
/*    */   public CannotSerializeTransactionException(String msg)
/*    */   {
/* 33 */     super(msg);
/*    */   }
/*    */ 
/*    */   public CannotSerializeTransactionException(String msg, Throwable cause)
/*    */   {
/* 42 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.CannotSerializeTransactionException
 * JD-Core Version:    0.6.2
 */