/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class DuplicateKeyException extends DataIntegrityViolationException
/*    */ {
/*    */   public DuplicateKeyException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ 
/*    */   public DuplicateKeyException(String msg, Throwable cause)
/*    */   {
/* 44 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.DuplicateKeyException
 * JD-Core Version:    0.6.2
 */