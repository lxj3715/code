/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class EmptyResultDataAccessException extends IncorrectResultSizeDataAccessException
/*    */ {
/*    */   public EmptyResultDataAccessException(int expectedSize)
/*    */   {
/* 35 */     super(expectedSize, 0);
/*    */   }
/*    */ 
/*    */   public EmptyResultDataAccessException(String msg, int expectedSize)
/*    */   {
/* 44 */     super(msg, expectedSize, 0);
/*    */   }
/*    */ 
/*    */   public EmptyResultDataAccessException(String msg, int expectedSize, Throwable ex)
/*    */   {
/* 54 */     super(msg, expectedSize, 0, ex);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.EmptyResultDataAccessException
 * JD-Core Version:    0.6.2
 */