/*     */ package org.springframework.dao;
/*     */ 
/*     */ public class IncorrectResultSizeDataAccessException extends DataRetrievalFailureException
/*     */ {
/*     */   private int expectedSize;
/*     */   private int actualSize;
/*     */ 
/*     */   public IncorrectResultSizeDataAccessException(int expectedSize)
/*     */   {
/*  41 */     super("Incorrect result size: expected " + expectedSize);
/*  42 */     this.expectedSize = expectedSize;
/*  43 */     this.actualSize = -1;
/*     */   }
/*     */ 
/*     */   public IncorrectResultSizeDataAccessException(int expectedSize, int actualSize)
/*     */   {
/*  52 */     super("Incorrect result size: expected " + expectedSize + ", actual " + actualSize);
/*  53 */     this.expectedSize = expectedSize;
/*  54 */     this.actualSize = actualSize;
/*     */   }
/*     */ 
/*     */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize)
/*     */   {
/*  63 */     super(msg);
/*  64 */     this.expectedSize = expectedSize;
/*  65 */     this.actualSize = -1;
/*     */   }
/*     */ 
/*     */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize, Throwable ex)
/*     */   {
/*  75 */     super(msg, ex);
/*  76 */     this.expectedSize = expectedSize;
/*  77 */     this.actualSize = -1;
/*     */   }
/*     */ 
/*     */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize, int actualSize)
/*     */   {
/*  87 */     super(msg);
/*  88 */     this.expectedSize = expectedSize;
/*  89 */     this.actualSize = actualSize;
/*     */   }
/*     */ 
/*     */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize, int actualSize, Throwable ex)
/*     */   {
/* 100 */     super(msg, ex);
/* 101 */     this.expectedSize = expectedSize;
/* 102 */     this.actualSize = actualSize;
/*     */   }
/*     */ 
/*     */   public int getExpectedSize()
/*     */   {
/* 110 */     return this.expectedSize;
/*     */   }
/*     */ 
/*     */   public int getActualSize()
/*     */   {
/* 117 */     return this.actualSize;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.IncorrectResultSizeDataAccessException
 * JD-Core Version:    0.6.2
 */