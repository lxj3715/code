/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class IncorrectUpdateSemanticsDataAccessException extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   public IncorrectUpdateSemanticsDataAccessException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ 
/*    */   public IncorrectUpdateSemanticsDataAccessException(String msg, Throwable cause)
/*    */   {
/* 44 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public boolean wasDataUpdated()
/*    */   {
/* 54 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.IncorrectUpdateSemanticsDataAccessException
 * JD-Core Version:    0.6.2
 */