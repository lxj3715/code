/*    */ package org.springframework.dao;
/*    */ 
/*    */ public abstract class NonTransientDataAccessException extends DataAccessException
/*    */ {
/*    */   public NonTransientDataAccessException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   public NonTransientDataAccessException(String msg, Throwable cause)
/*    */   {
/* 46 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.NonTransientDataAccessException
 * JD-Core Version:    0.6.2
 */