/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class NonTransientDataAccessResourceException extends NonTransientDataAccessException
/*    */ {
/*    */   public NonTransientDataAccessResourceException(String msg)
/*    */   {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */   public NonTransientDataAccessResourceException(String msg, Throwable cause)
/*    */   {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.NonTransientDataAccessResourceException
 * JD-Core Version:    0.6.2
 */