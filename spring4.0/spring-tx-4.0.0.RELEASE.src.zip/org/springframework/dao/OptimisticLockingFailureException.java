/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class OptimisticLockingFailureException extends ConcurrencyFailureException
/*    */ {
/*    */   public OptimisticLockingFailureException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public OptimisticLockingFailureException(String msg, Throwable cause)
/*    */   {
/* 46 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.OptimisticLockingFailureException
 * JD-Core Version:    0.6.2
 */