/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class PermissionDeniedDataAccessException extends NonTransientDataAccessException
/*    */ {
/*    */   public PermissionDeniedDataAccessException(String msg, Throwable cause)
/*    */   {
/* 36 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.PermissionDeniedDataAccessException
 * JD-Core Version:    0.6.2
 */