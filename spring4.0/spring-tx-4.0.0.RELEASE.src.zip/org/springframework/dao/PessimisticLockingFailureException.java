/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class PessimisticLockingFailureException extends ConcurrencyFailureException
/*    */ {
/*    */   public PessimisticLockingFailureException(String msg)
/*    */   {
/* 41 */     super(msg);
/*    */   }
/*    */ 
/*    */   public PessimisticLockingFailureException(String msg, Throwable cause)
/*    */   {
/* 50 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.PessimisticLockingFailureException
 * JD-Core Version:    0.6.2
 */