/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class QueryTimeoutException extends TransientDataAccessException
/*    */ {
/*    */   public QueryTimeoutException(String msg)
/*    */   {
/* 38 */     super(msg);
/*    */   }
/*    */ 
/*    */   public QueryTimeoutException(String msg, Throwable cause)
/*    */   {
/* 47 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.QueryTimeoutException
 * JD-Core Version:    0.6.2
 */