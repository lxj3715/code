/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class RecoverableDataAccessException extends DataAccessException
/*    */ {
/*    */   public RecoverableDataAccessException(String msg)
/*    */   {
/* 38 */     super(msg);
/*    */   }
/*    */ 
/*    */   public RecoverableDataAccessException(String msg, Throwable cause)
/*    */   {
/* 48 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.RecoverableDataAccessException
 * JD-Core Version:    0.6.2
 */