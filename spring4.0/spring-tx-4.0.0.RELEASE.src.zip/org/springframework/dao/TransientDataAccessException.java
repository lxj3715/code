/*    */ package org.springframework.dao;
/*    */ 
/*    */ public abstract class TransientDataAccessException extends DataAccessException
/*    */ {
/*    */   public TransientDataAccessException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   public TransientDataAccessException(String msg, Throwable cause)
/*    */   {
/* 46 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.TransientDataAccessException
 * JD-Core Version:    0.6.2
 */