/*    */ package org.springframework.dao;
/*    */ 
/*    */ public class TransientDataAccessResourceException extends TransientDataAccessException
/*    */ {
/*    */   public TransientDataAccessResourceException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ 
/*    */   public TransientDataAccessResourceException(String msg, Throwable cause)
/*    */   {
/* 44 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.TransientDataAccessResourceException
 * JD-Core Version:    0.6.2
 */