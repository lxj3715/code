/*    */ package org.springframework.dao;
/*    */ 
/*    */ public abstract class UncategorizedDataAccessException extends NonTransientDataAccessException
/*    */ {
/*    */   public UncategorizedDataAccessException(String msg, Throwable cause)
/*    */   {
/* 35 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.UncategorizedDataAccessException
 * JD-Core Version:    0.6.2
 */