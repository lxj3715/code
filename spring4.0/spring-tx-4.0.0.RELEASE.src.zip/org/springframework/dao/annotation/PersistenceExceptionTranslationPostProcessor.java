/*    */ package org.springframework.dao.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.stereotype.Repository;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class PersistenceExceptionTranslationPostProcessor extends AbstractAdvisingBeanPostProcessor
/*    */   implements BeanFactoryAware
/*    */ {
/* 64 */   private Class<? extends Annotation> repositoryAnnotationType = Repository.class;
/*    */ 
/*    */   public void setRepositoryAnnotationType(Class<? extends Annotation> repositoryAnnotationType)
/*    */   {
/* 76 */     Assert.notNull(repositoryAnnotationType, "'repositoryAnnotationType' must not be null");
/* 77 */     this.repositoryAnnotationType = repositoryAnnotationType;
/*    */   }
/*    */ 
/*    */   public void setBeanFactory(BeanFactory beanFactory)
/*    */   {
/* 82 */     if (!(beanFactory instanceof ListableBeanFactory)) {
/* 83 */       throw new IllegalArgumentException("Cannot use PersistenceExceptionTranslator autodetection without ListableBeanFactory");
/*    */     }
/*    */ 
/* 86 */     this.advisor = new PersistenceExceptionTranslationAdvisor((ListableBeanFactory)beanFactory, this.repositoryAnnotationType);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor
 * JD-Core Version:    0.6.2
 */