/*    */ package org.springframework.dao.support;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ChainedPersistenceExceptionTranslator
/*    */   implements PersistenceExceptionTranslator
/*    */ {
/* 37 */   private final List<PersistenceExceptionTranslator> delegates = new ArrayList(4);
/*    */ 
/*    */   public final void addDelegate(PersistenceExceptionTranslator pet)
/*    */   {
/* 44 */     Assert.notNull(pet, "PersistenceExceptionTranslator must not be null");
/* 45 */     this.delegates.add(pet);
/*    */   }
/*    */ 
/*    */   public final PersistenceExceptionTranslator[] getDelegates()
/*    */   {
/* 52 */     return (PersistenceExceptionTranslator[])this.delegates.toArray(new PersistenceExceptionTranslator[this.delegates.size()]);
/*    */   }
/*    */ 
/*    */   public DataAccessException translateExceptionIfPossible(RuntimeException ex)
/*    */   {
/* 58 */     for (PersistenceExceptionTranslator pet : this.delegates) {
/* 59 */       DataAccessException translatedDex = pet.translateExceptionIfPossible(ex);
/* 60 */       if (translatedDex != null) {
/* 61 */         return translatedDex;
/*    */       }
/*    */     }
/* 64 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.support.ChainedPersistenceExceptionTranslator
 * JD-Core Version:    0.6.2
 */