/*    */ package org.springframework.dao.support;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.BeanInitializationException;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public abstract class DaoSupport
/*    */   implements InitializingBean
/*    */ {
/* 38 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public final void afterPropertiesSet()
/*    */     throws IllegalArgumentException, BeanInitializationException
/*    */   {
/* 44 */     checkDaoConfig();
/*    */     try
/*    */     {
/* 48 */       initDao();
/*    */     }
/*    */     catch (Exception ex) {
/* 51 */       throw new BeanInitializationException("Initialization of DAO failed", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract void checkDaoConfig()
/*    */     throws IllegalArgumentException;
/*    */ 
/*    */   protected void initDao()
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.support.DaoSupport
 * JD-Core Version:    0.6.2
 */