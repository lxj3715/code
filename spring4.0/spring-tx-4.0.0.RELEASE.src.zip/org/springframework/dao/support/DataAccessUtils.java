/*     */ package org.springframework.dao.support;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.EmptyResultDataAccessException;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.dao.TypeMismatchDataAccessException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ public abstract class DataAccessUtils
/*     */ {
/*     */   public static <T> T singleResult(Collection<T> results)
/*     */     throws IncorrectResultSizeDataAccessException
/*     */   {
/*  48 */     int size = results != null ? results.size() : 0;
/*  49 */     if (size == 0) {
/*  50 */       return null;
/*     */     }
/*  52 */     if (results.size() > 1) {
/*  53 */       throw new IncorrectResultSizeDataAccessException(1, size);
/*     */     }
/*  55 */     return results.iterator().next();
/*     */   }
/*     */ 
/*     */   public static <T> T requiredSingleResult(Collection<T> results)
/*     */     throws IncorrectResultSizeDataAccessException
/*     */   {
/*  69 */     int size = results != null ? results.size() : 0;
/*  70 */     if (size == 0) {
/*  71 */       throw new EmptyResultDataAccessException(1);
/*     */     }
/*  73 */     if (results.size() > 1) {
/*  74 */       throw new IncorrectResultSizeDataAccessException(1, size);
/*     */     }
/*  76 */     return results.iterator().next();
/*     */   }
/*     */ 
/*     */   public static <T> T uniqueResult(Collection<T> results)
/*     */     throws IncorrectResultSizeDataAccessException
/*     */   {
/*  90 */     int size = results != null ? results.size() : 0;
/*  91 */     if (size == 0) {
/*  92 */       return null;
/*     */     }
/*  94 */     if (!CollectionUtils.hasUniqueObject(results)) {
/*  95 */       throw new IncorrectResultSizeDataAccessException(1, size);
/*     */     }
/*  97 */     return results.iterator().next();
/*     */   }
/*     */ 
/*     */   public static <T> T requiredUniqueResult(Collection<T> results)
/*     */     throws IncorrectResultSizeDataAccessException
/*     */   {
/* 112 */     int size = results != null ? results.size() : 0;
/* 113 */     if (size == 0) {
/* 114 */       throw new EmptyResultDataAccessException(1);
/*     */     }
/* 116 */     if (!CollectionUtils.hasUniqueObject(results)) {
/* 117 */       throw new IncorrectResultSizeDataAccessException(1, size);
/*     */     }
/* 119 */     return results.iterator().next();
/*     */   }
/*     */ 
/*     */   public static <T> T objectResult(Collection<?> results, Class<T> requiredType)
/*     */     throws IncorrectResultSizeDataAccessException, TypeMismatchDataAccessException
/*     */   {
/* 140 */     Object result = requiredUniqueResult(results);
/* 141 */     if ((requiredType != null) && (!requiredType.isInstance(result))) {
/* 142 */       if (String.class.equals(requiredType)) {
/* 143 */         result = result.toString();
/*     */       }
/* 145 */       else if ((Number.class.isAssignableFrom(requiredType)) && (Number.class.isInstance(result))) {
/*     */         try {
/* 147 */           result = NumberUtils.convertNumberToTargetClass((Number)result, requiredType);
/*     */         }
/*     */         catch (IllegalArgumentException ex) {
/* 150 */           throw new TypeMismatchDataAccessException(ex.getMessage());
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 156 */         throw new TypeMismatchDataAccessException("Result object is of type [" + result
/* 155 */           .getClass().getName() + "] and could not be converted to required type [" + requiredType
/* 156 */           .getName() + "]");
/*     */       }
/*     */     }
/* 159 */     return result;
/*     */   }
/*     */ 
/*     */   public static int intResult(Collection<?> results)
/*     */     throws IncorrectResultSizeDataAccessException, TypeMismatchDataAccessException
/*     */   {
/* 178 */     return ((Number)objectResult(results, Number.class)).intValue();
/*     */   }
/*     */ 
/*     */   public static long longResult(Collection<?> results)
/*     */     throws IncorrectResultSizeDataAccessException, TypeMismatchDataAccessException
/*     */   {
/* 197 */     return ((Number)objectResult(results, Number.class)).longValue();
/*     */   }
/*     */ 
/*     */   public static RuntimeException translateIfNecessary(RuntimeException rawException, PersistenceExceptionTranslator pet)
/*     */   {
/* 212 */     Assert.notNull(pet, "PersistenceExceptionTranslator must not be null");
/* 213 */     DataAccessException dex = pet.translateExceptionIfPossible(rawException);
/* 214 */     return dex != null ? dex : rawException;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.support.DataAccessUtils
 * JD-Core Version:    0.6.2
 */