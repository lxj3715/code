/*     */ package org.springframework.dao.support;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class PersistenceExceptionTranslationInterceptor
/*     */   implements MethodInterceptor, BeanFactoryAware, InitializingBean
/*     */ {
/*     */   private volatile PersistenceExceptionTranslator persistenceExceptionTranslator;
/*  52 */   private boolean alwaysTranslate = false;
/*     */   private ListableBeanFactory beanFactory;
/*     */ 
/*     */   public PersistenceExceptionTranslationInterceptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PersistenceExceptionTranslationInterceptor(PersistenceExceptionTranslator pet)
/*     */   {
/*  71 */     Assert.notNull(pet, "PersistenceExceptionTranslator must not be null");
/*  72 */     this.persistenceExceptionTranslator = pet;
/*     */   }
/*     */ 
/*     */   public PersistenceExceptionTranslationInterceptor(ListableBeanFactory beanFactory)
/*     */   {
/*  82 */     Assert.notNull(beanFactory, "ListableBeanFactory must not be null");
/*  83 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public void setPersistenceExceptionTranslator(PersistenceExceptionTranslator pet)
/*     */   {
/*  94 */     this.persistenceExceptionTranslator = pet;
/*     */   }
/*     */ 
/*     */   public void setAlwaysTranslate(boolean alwaysTranslate)
/*     */   {
/* 110 */     this.alwaysTranslate = alwaysTranslate;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/* 115 */     if (this.persistenceExceptionTranslator == null)
/*     */     {
/* 117 */       if (!(beanFactory instanceof ListableBeanFactory)) {
/* 118 */         throw new IllegalArgumentException("Cannot use PersistenceExceptionTranslator autodetection without ListableBeanFactory");
/*     */       }
/*     */ 
/* 121 */       this.beanFactory = ((ListableBeanFactory)beanFactory);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 127 */     if ((this.persistenceExceptionTranslator == null) && (this.beanFactory == null))
/* 128 */       throw new IllegalArgumentException("Property 'persistenceExceptionTranslator' is required");
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation mi)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 136 */       return mi.proceed();
/*     */     }
/*     */     catch (RuntimeException ex)
/*     */     {
/* 140 */       if ((!this.alwaysTranslate) && (ReflectionUtils.declaresException(mi.getMethod(), ex.getClass()))) {
/* 141 */         throw ex;
/*     */       }
/*     */ 
/* 144 */       if (this.persistenceExceptionTranslator == null) {
/* 145 */         this.persistenceExceptionTranslator = detectPersistenceExceptionTranslators(this.beanFactory);
/*     */       }
/* 147 */       throw DataAccessUtils.translateIfNecessary(ex, this.persistenceExceptionTranslator);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected PersistenceExceptionTranslator detectPersistenceExceptionTranslators(ListableBeanFactory beanFactory)
/*     */   {
/* 162 */     Map pets = BeanFactoryUtils.beansOfTypeIncludingAncestors(beanFactory, PersistenceExceptionTranslator.class, false, false);
/*     */ 
/* 164 */     ChainedPersistenceExceptionTranslator cpet = new ChainedPersistenceExceptionTranslator();
/* 165 */     for (PersistenceExceptionTranslator pet : pets.values()) {
/* 166 */       cpet.addDelegate(pet);
/*     */     }
/* 168 */     return cpet;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.support.PersistenceExceptionTranslationInterceptor
 * JD-Core Version:    0.6.2
 */