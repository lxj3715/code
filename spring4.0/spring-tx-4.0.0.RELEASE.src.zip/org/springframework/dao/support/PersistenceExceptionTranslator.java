package org.springframework.dao.support;

import org.springframework.dao.DataAccessException;

public abstract interface PersistenceExceptionTranslator
{
  public abstract DataAccessException translateExceptionIfPossible(RuntimeException paramRuntimeException);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.dao.support.PersistenceExceptionTranslator
 * JD-Core Version:    0.6.2
 */