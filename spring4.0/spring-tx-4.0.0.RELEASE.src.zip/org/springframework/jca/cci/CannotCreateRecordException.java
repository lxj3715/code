/*    */ package org.springframework.jca.cci;
/*    */ 
/*    */ import javax.resource.ResourceException;
/*    */ import org.springframework.dao.DataAccessResourceFailureException;
/*    */ 
/*    */ public class CannotCreateRecordException extends DataAccessResourceFailureException
/*    */ {
/*    */   public CannotCreateRecordException(String msg, ResourceException ex)
/*    */   {
/* 39 */     super(msg, ex);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.CannotCreateRecordException
 * JD-Core Version:    0.6.2
 */