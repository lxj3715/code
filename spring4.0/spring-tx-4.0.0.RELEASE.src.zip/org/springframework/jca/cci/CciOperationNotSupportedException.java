/*    */ package org.springframework.jca.cci;
/*    */ 
/*    */ import javax.resource.ResourceException;
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ 
/*    */ public class CciOperationNotSupportedException extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   public CciOperationNotSupportedException(String msg, ResourceException ex)
/*    */   {
/* 38 */     super(msg, ex);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.CciOperationNotSupportedException
 * JD-Core Version:    0.6.2
 */