/*    */ package org.springframework.jca.cci;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ 
/*    */ public class InvalidResultSetAccessException extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   public InvalidResultSetAccessException(String msg, SQLException ex)
/*    */   {
/* 43 */     super(ex.getMessage(), ex);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.InvalidResultSetAccessException
 * JD-Core Version:    0.6.2
 */