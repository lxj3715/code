/*     */ package org.springframework.jca.cci.connection;
/*     */ 
/*     */ import javax.resource.NotSupportedException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.cci.Connection;
/*     */ import javax.resource.cci.ConnectionFactory;
/*     */ import javax.resource.cci.LocalTransaction;
/*     */ import javax.resource.spi.LocalTransactionException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.transaction.CannotCreateTransactionException;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*     */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*     */ import org.springframework.transaction.support.ResourceTransactionManager;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ 
/*     */ public class CciLocalTransactionManager extends AbstractPlatformTransactionManager
/*     */   implements ResourceTransactionManager, InitializingBean
/*     */ {
/*     */   private ConnectionFactory connectionFactory;
/*     */ 
/*     */   public CciLocalTransactionManager()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CciLocalTransactionManager(ConnectionFactory connectionFactory)
/*     */   {
/*  83 */     setConnectionFactory(connectionFactory);
/*  84 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   public void setConnectionFactory(ConnectionFactory cf)
/*     */   {
/*  93 */     if ((cf instanceof TransactionAwareConnectionFactoryProxy))
/*     */     {
/*  97 */       this.connectionFactory = ((TransactionAwareConnectionFactoryProxy)cf).getTargetConnectionFactory();
/*     */     }
/*     */     else
/* 100 */       this.connectionFactory = cf;
/*     */   }
/*     */ 
/*     */   public ConnectionFactory getConnectionFactory()
/*     */   {
/* 109 */     return this.connectionFactory;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 114 */     if (getConnectionFactory() == null)
/* 115 */       throw new IllegalArgumentException("Property 'connectionFactory' is required");
/*     */   }
/*     */ 
/*     */   public Object getResourceFactory()
/*     */   {
/* 122 */     return getConnectionFactory();
/*     */   }
/*     */ 
/*     */   protected Object doGetTransaction()
/*     */   {
/* 127 */     CciLocalTransactionObject txObject = new CciLocalTransactionObject(null);
/*     */ 
/* 129 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(getConnectionFactory());
/* 130 */     txObject.setConnectionHolder(conHolder);
/* 131 */     return txObject;
/*     */   }
/*     */ 
/*     */   protected boolean isExistingTransaction(Object transaction)
/*     */   {
/* 136 */     CciLocalTransactionObject txObject = (CciLocalTransactionObject)transaction;
/*     */ 
/* 138 */     return txObject.getConnectionHolder() != null;
/*     */   }
/*     */ 
/*     */   protected void doBegin(Object transaction, TransactionDefinition definition)
/*     */   {
/* 143 */     CciLocalTransactionObject txObject = (CciLocalTransactionObject)transaction;
/* 144 */     Connection con = null;
/*     */     try
/*     */     {
/* 147 */       con = getConnectionFactory().getConnection();
/* 148 */       if (this.logger.isDebugEnabled()) {
/* 149 */         this.logger.debug("Acquired Connection [" + con + "] for local CCI transaction");
/*     */       }
/*     */ 
/* 152 */       txObject.setConnectionHolder(new ConnectionHolder(con));
/* 153 */       txObject.getConnectionHolder().setSynchronizedWithTransaction(true);
/*     */ 
/* 155 */       con.getLocalTransaction().begin();
/* 156 */       int timeout = determineTimeout(definition);
/* 157 */       if (timeout != -1) {
/* 158 */         txObject.getConnectionHolder().setTimeoutInSeconds(timeout);
/*     */       }
/* 160 */       TransactionSynchronizationManager.bindResource(getConnectionFactory(), txObject.getConnectionHolder());
/*     */     }
/*     */     catch (NotSupportedException ex)
/*     */     {
/* 164 */       ConnectionFactoryUtils.releaseConnection(con, getConnectionFactory());
/* 165 */       throw new CannotCreateTransactionException("CCI Connection does not support local transactions", ex);
/*     */     }
/*     */     catch (LocalTransactionException ex) {
/* 168 */       ConnectionFactoryUtils.releaseConnection(con, getConnectionFactory());
/* 169 */       throw new CannotCreateTransactionException("Could not begin local CCI transaction", ex);
/*     */     }
/*     */     catch (Throwable ex) {
/* 172 */       ConnectionFactoryUtils.releaseConnection(con, getConnectionFactory());
/* 173 */       throw new TransactionSystemException("Unexpected failure on begin of CCI local transaction", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object doSuspend(Object transaction)
/*     */   {
/* 179 */     CciLocalTransactionObject txObject = (CciLocalTransactionObject)transaction;
/* 180 */     txObject.setConnectionHolder(null);
/* 181 */     return TransactionSynchronizationManager.unbindResource(getConnectionFactory());
/*     */   }
/*     */ 
/*     */   protected void doResume(Object transaction, Object suspendedResources)
/*     */   {
/* 186 */     ConnectionHolder conHolder = (ConnectionHolder)suspendedResources;
/* 187 */     TransactionSynchronizationManager.bindResource(getConnectionFactory(), conHolder);
/*     */   }
/*     */ 
/*     */   protected boolean isRollbackOnly(Object transaction) throws TransactionException {
/* 191 */     CciLocalTransactionObject txObject = (CciLocalTransactionObject)transaction;
/* 192 */     return txObject.getConnectionHolder().isRollbackOnly();
/*     */   }
/*     */ 
/*     */   protected void doCommit(DefaultTransactionStatus status)
/*     */   {
/* 197 */     CciLocalTransactionObject txObject = (CciLocalTransactionObject)status.getTransaction();
/* 198 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 199 */     if (status.isDebug())
/* 200 */       this.logger.debug("Committing CCI local transaction on Connection [" + con + "]");
/*     */     try
/*     */     {
/* 203 */       con.getLocalTransaction().commit();
/*     */     }
/*     */     catch (LocalTransactionException ex) {
/* 206 */       throw new TransactionSystemException("Could not commit CCI local transaction", ex);
/*     */     }
/*     */     catch (ResourceException ex) {
/* 209 */       throw new TransactionSystemException("Unexpected failure on commit of CCI local transaction", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doRollback(DefaultTransactionStatus status)
/*     */   {
/* 215 */     CciLocalTransactionObject txObject = (CciLocalTransactionObject)status.getTransaction();
/* 216 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 217 */     if (status.isDebug())
/* 218 */       this.logger.debug("Rolling back CCI local transaction on Connection [" + con + "]");
/*     */     try
/*     */     {
/* 221 */       con.getLocalTransaction().rollback();
/*     */     }
/*     */     catch (LocalTransactionException ex) {
/* 224 */       throw new TransactionSystemException("Could not roll back CCI local transaction", ex);
/*     */     }
/*     */     catch (ResourceException ex) {
/* 227 */       throw new TransactionSystemException("Unexpected failure on rollback of CCI local transaction", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doSetRollbackOnly(DefaultTransactionStatus status)
/*     */   {
/* 233 */     CciLocalTransactionObject txObject = (CciLocalTransactionObject)status.getTransaction();
/* 234 */     if (status.isDebug()) {
/* 235 */       this.logger.debug("Setting CCI local transaction [" + txObject.getConnectionHolder().getConnection() + "] rollback-only");
/*     */     }
/*     */ 
/* 238 */     txObject.getConnectionHolder().setRollbackOnly();
/*     */   }
/*     */ 
/*     */   protected void doCleanupAfterCompletion(Object transaction)
/*     */   {
/* 243 */     CciLocalTransactionObject txObject = (CciLocalTransactionObject)transaction;
/*     */ 
/* 246 */     TransactionSynchronizationManager.unbindResource(getConnectionFactory());
/* 247 */     txObject.getConnectionHolder().clear();
/*     */ 
/* 249 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 250 */     if (this.logger.isDebugEnabled()) {
/* 251 */       this.logger.debug("Releasing CCI Connection [" + con + "] after transaction");
/*     */     }
/* 253 */     ConnectionFactoryUtils.releaseConnection(con, getConnectionFactory());
/*     */   }
/*     */ 
/*     */   private static class CciLocalTransactionObject
/*     */   {
/*     */     private ConnectionHolder connectionHolder;
/*     */ 
/*     */     public void setConnectionHolder(ConnectionHolder connectionHolder)
/*     */     {
/* 267 */       this.connectionHolder = connectionHolder;
/*     */     }
/*     */ 
/*     */     public ConnectionHolder getConnectionHolder() {
/* 271 */       return this.connectionHolder;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.connection.CciLocalTransactionManager
 * JD-Core Version:    0.6.2
 */