/*     */ package org.springframework.jca.cci.connection;
/*     */ 
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.cci.Connection;
/*     */ import javax.resource.cci.ConnectionFactory;
/*     */ import javax.resource.cci.ConnectionSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jca.cci.CannotGetCciConnectionException;
/*     */ import org.springframework.transaction.support.ResourceHolderSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class ConnectionFactoryUtils
/*     */ {
/*  54 */   private static final Log logger = LogFactory.getLog(ConnectionFactoryUtils.class);
/*     */ 
/*     */   public static Connection getConnection(ConnectionFactory cf)
/*     */     throws CannotGetCciConnectionException
/*     */   {
/*  71 */     return getConnection(cf, null);
/*     */   }
/*     */ 
/*     */   public static Connection getConnection(ConnectionFactory cf, ConnectionSpec spec)
/*     */     throws CannotGetCciConnectionException
/*     */   {
/*     */     try
/*     */     {
/*  93 */       if (spec != null) {
/*  94 */         Assert.notNull(cf, "No ConnectionFactory specified");
/*  95 */         return cf.getConnection(spec);
/*     */       }
/*     */ 
/*  98 */       return doGetConnection(cf);
/*     */     }
/*     */     catch (ResourceException ex)
/*     */     {
/* 102 */       throw new CannotGetCciConnectionException("Could not get CCI Connection", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Connection doGetConnection(ConnectionFactory cf)
/*     */     throws ResourceException
/*     */   {
/* 119 */     Assert.notNull(cf, "No ConnectionFactory specified");
/*     */ 
/* 121 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(cf);
/* 122 */     if (conHolder != null) {
/* 123 */       return conHolder.getConnection();
/*     */     }
/*     */ 
/* 126 */     logger.debug("Opening CCI Connection");
/* 127 */     Connection con = cf.getConnection();
/*     */ 
/* 129 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 130 */       logger.debug("Registering transaction synchronization for CCI Connection");
/* 131 */       conHolder = new ConnectionHolder(con);
/* 132 */       conHolder.setSynchronizedWithTransaction(true);
/* 133 */       TransactionSynchronizationManager.registerSynchronization(new ConnectionSynchronization(conHolder, cf));
/* 134 */       TransactionSynchronizationManager.bindResource(cf, conHolder);
/*     */     }
/*     */ 
/* 137 */     return con;
/*     */   }
/*     */ 
/*     */   public static boolean isConnectionTransactional(Connection con, ConnectionFactory cf)
/*     */   {
/* 149 */     if (cf == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(cf);
/* 153 */     return (conHolder != null) && (conHolder.getConnection() == con);
/*     */   }
/*     */ 
/*     */   public static void releaseConnection(Connection con, ConnectionFactory cf)
/*     */   {
/*     */     try
/*     */     {
/* 167 */       doReleaseConnection(con, cf);
/*     */     }
/*     */     catch (ResourceException ex) {
/* 170 */       logger.debug("Could not close CCI Connection", ex);
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 174 */       logger.debug("Unexpected exception on closing CCI Connection", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void doReleaseConnection(Connection con, ConnectionFactory cf)
/*     */     throws ResourceException
/*     */   {
/* 190 */     if ((con == null) || (isConnectionTransactional(con, cf))) {
/* 191 */       return;
/*     */     }
/* 193 */     con.close();
/*     */   }
/*     */ 
/*     */   private static class ConnectionSynchronization extends ResourceHolderSynchronization<ConnectionHolder, ConnectionFactory>
/*     */   {
/*     */     public ConnectionSynchronization(ConnectionHolder connectionHolder, ConnectionFactory connectionFactory)
/*     */     {
/* 205 */       super(connectionFactory);
/*     */     }
/*     */ 
/*     */     protected void releaseResource(ConnectionHolder resourceHolder, ConnectionFactory resourceKey)
/*     */     {
/* 210 */       ConnectionFactoryUtils.releaseConnection(resourceHolder.getConnection(), resourceKey);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.connection.ConnectionFactoryUtils
 * JD-Core Version:    0.6.2
 */