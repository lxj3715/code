/*    */ package org.springframework.jca.cci.connection;
/*    */ 
/*    */ import javax.resource.cci.Connection;
/*    */ import org.springframework.transaction.support.ResourceHolderSupport;
/*    */ 
/*    */ public class ConnectionHolder extends ResourceHolderSupport
/*    */ {
/*    */   private final Connection connection;
/*    */ 
/*    */   public ConnectionHolder(Connection connection)
/*    */   {
/* 42 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */   public Connection getConnection() {
/* 46 */     return this.connection;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.connection.ConnectionHolder
 * JD-Core Version:    0.6.2
 */