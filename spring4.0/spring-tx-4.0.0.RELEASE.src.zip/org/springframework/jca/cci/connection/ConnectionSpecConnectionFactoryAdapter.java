/*     */ package org.springframework.jca.cci.connection;
/*     */ 
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.cci.Connection;
/*     */ import javax.resource.cci.ConnectionFactory;
/*     */ import javax.resource.cci.ConnectionSpec;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ 
/*     */ public class ConnectionSpecConnectionFactoryAdapter extends DelegatingConnectionFactory
/*     */ {
/*     */   private ConnectionSpec connectionSpec;
/*  70 */   private final ThreadLocal<ConnectionSpec> threadBoundSpec = new NamedThreadLocal("Current CCI ConnectionSpec");
/*     */ 
/*     */   public void setConnectionSpec(ConnectionSpec connectionSpec)
/*     */   {
/*  79 */     this.connectionSpec = connectionSpec;
/*     */   }
/*     */ 
/*     */   public void setConnectionSpecForCurrentThread(ConnectionSpec spec)
/*     */   {
/*  91 */     this.threadBoundSpec.set(spec);
/*     */   }
/*     */ 
/*     */   public void removeConnectionSpecFromCurrentThread()
/*     */   {
/* 100 */     this.threadBoundSpec.remove();
/*     */   }
/*     */ 
/*     */   public final Connection getConnection()
/*     */     throws ResourceException
/*     */   {
/* 112 */     ConnectionSpec threadSpec = (ConnectionSpec)this.threadBoundSpec.get();
/* 113 */     if (threadSpec != null) {
/* 114 */       return doGetConnection(threadSpec);
/*     */     }
/*     */ 
/* 117 */     return doGetConnection(this.connectionSpec);
/*     */   }
/*     */ 
/*     */   protected Connection doGetConnection(ConnectionSpec spec)
/*     */     throws ResourceException
/*     */   {
/* 132 */     if (getTargetConnectionFactory() == null) {
/* 133 */       throw new IllegalStateException("targetConnectionFactory is required");
/*     */     }
/* 135 */     if (spec != null) {
/* 136 */       return getTargetConnectionFactory().getConnection(spec);
/*     */     }
/*     */ 
/* 139 */     return getTargetConnectionFactory().getConnection();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.connection.ConnectionSpecConnectionFactoryAdapter
 * JD-Core Version:    0.6.2
 */