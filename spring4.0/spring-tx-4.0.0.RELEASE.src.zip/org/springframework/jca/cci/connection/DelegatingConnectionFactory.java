/*    */ package org.springframework.jca.cci.connection;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import javax.naming.Reference;
/*    */ import javax.resource.ResourceException;
/*    */ import javax.resource.cci.Connection;
/*    */ import javax.resource.cci.ConnectionFactory;
/*    */ import javax.resource.cci.ConnectionSpec;
/*    */ import javax.resource.cci.RecordFactory;
/*    */ import javax.resource.cci.ResourceAdapterMetaData;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public class DelegatingConnectionFactory
/*    */   implements ConnectionFactory, InitializingBean
/*    */ {
/*    */   private ConnectionFactory targetConnectionFactory;
/*    */ 
/*    */   public void setTargetConnectionFactory(ConnectionFactory targetConnectionFactory)
/*    */   {
/* 52 */     this.targetConnectionFactory = targetConnectionFactory;
/*    */   }
/*    */ 
/*    */   public ConnectionFactory getTargetConnectionFactory()
/*    */   {
/* 59 */     return this.targetConnectionFactory;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 65 */     if (getTargetConnectionFactory() == null)
/* 66 */       throw new IllegalArgumentException("Property 'targetConnectionFactory' is required");
/*    */   }
/*    */ 
/*    */   public Connection getConnection()
/*    */     throws ResourceException
/*    */   {
/* 73 */     return getTargetConnectionFactory().getConnection();
/*    */   }
/*    */ 
/*    */   public Connection getConnection(ConnectionSpec connectionSpec) throws ResourceException
/*    */   {
/* 78 */     return getTargetConnectionFactory().getConnection(connectionSpec);
/*    */   }
/*    */ 
/*    */   public RecordFactory getRecordFactory() throws ResourceException
/*    */   {
/* 83 */     return getTargetConnectionFactory().getRecordFactory();
/*    */   }
/*    */ 
/*    */   public ResourceAdapterMetaData getMetaData() throws ResourceException
/*    */   {
/* 88 */     return getTargetConnectionFactory().getMetaData();
/*    */   }
/*    */ 
/*    */   public Reference getReference() throws NamingException
/*    */   {
/* 93 */     return getTargetConnectionFactory().getReference();
/*    */   }
/*    */ 
/*    */   public void setReference(Reference reference)
/*    */   {
/* 98 */     getTargetConnectionFactory().setReference(reference);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.connection.DelegatingConnectionFactory
 * JD-Core Version:    0.6.2
 */