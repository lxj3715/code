/*    */ package org.springframework.jca.cci.connection;
/*    */ 
/*    */ import javax.resource.NotSupportedException;
/*    */ import javax.resource.ResourceException;
/*    */ import javax.resource.cci.IndexedRecord;
/*    */ import javax.resource.cci.MappedRecord;
/*    */ import javax.resource.cci.RecordFactory;
/*    */ 
/*    */ public class NotSupportedRecordFactory
/*    */   implements RecordFactory
/*    */ {
/*    */   public MappedRecord createMappedRecord(String name)
/*    */     throws ResourceException
/*    */   {
/* 46 */     throw new NotSupportedException("The RecordFactory facility is not supported by the connector");
/*    */   }
/*    */ 
/*    */   public IndexedRecord createIndexedRecord(String name) throws ResourceException
/*    */   {
/* 51 */     throw new NotSupportedException("The RecordFactory facility is not supported by the connector");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.connection.NotSupportedRecordFactory
 * JD-Core Version:    0.6.2
 */