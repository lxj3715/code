/*     */ package org.springframework.jca.cci.connection;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import javax.resource.NotSupportedException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.cci.Connection;
/*     */ import javax.resource.cci.ConnectionFactory;
/*     */ import javax.resource.cci.ConnectionSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SingleConnectionFactory extends DelegatingConnectionFactory
/*     */   implements DisposableBean
/*     */ {
/*  57 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Connection target;
/*     */   private Connection connection;
/*  66 */   private final Object connectionMonitor = new Object();
/*     */ 
/*     */   public SingleConnectionFactory()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SingleConnectionFactory(Connection target)
/*     */   {
/*  82 */     Assert.notNull(target, "Target Connection must not be null");
/*  83 */     this.target = target;
/*  84 */     this.connection = getCloseSuppressingConnectionProxy(target);
/*     */   }
/*     */ 
/*     */   public SingleConnectionFactory(ConnectionFactory targetConnectionFactory)
/*     */   {
/*  94 */     Assert.notNull(targetConnectionFactory, "Target ConnectionFactory must not be null");
/*  95 */     setTargetConnectionFactory(targetConnectionFactory);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 104 */     if ((this.connection == null) && (getTargetConnectionFactory() == null))
/* 105 */       throw new IllegalArgumentException("Connection or 'targetConnectionFactory' is required");
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws ResourceException
/*     */   {
/* 112 */     synchronized (this.connectionMonitor) {
/* 113 */       if (this.connection == null) {
/* 114 */         initConnection();
/*     */       }
/* 116 */       return this.connection;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Connection getConnection(ConnectionSpec connectionSpec) throws ResourceException
/*     */   {
/* 122 */     throw new NotSupportedException("SingleConnectionFactory does not support custom ConnectionSpec");
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 134 */     resetConnection();
/*     */   }
/*     */ 
/*     */   public void initConnection()
/*     */     throws ResourceException
/*     */   {
/* 145 */     if (getTargetConnectionFactory() == null) {
/* 146 */       throw new IllegalStateException("'targetConnectionFactory' is required for lazily initializing a Connection");
/*     */     }
/*     */ 
/* 149 */     synchronized (this.connectionMonitor) {
/* 150 */       if (this.target != null) {
/* 151 */         closeConnection(this.target);
/*     */       }
/* 153 */       this.target = doCreateConnection();
/* 154 */       prepareConnection(this.target);
/* 155 */       if (this.logger.isInfoEnabled()) {
/* 156 */         this.logger.info("Established shared CCI Connection: " + this.target);
/*     */       }
/* 158 */       this.connection = getCloseSuppressingConnectionProxy(this.target);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resetConnection()
/*     */   {
/* 166 */     synchronized (this.connectionMonitor) {
/* 167 */       if (this.target != null) {
/* 168 */         closeConnection(this.target);
/*     */       }
/* 170 */       this.target = null;
/* 171 */       this.connection = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Connection doCreateConnection()
/*     */     throws ResourceException
/*     */   {
/* 181 */     return getTargetConnectionFactory().getConnection();
/*     */   }
/*     */ 
/*     */   protected void prepareConnection(Connection con)
/*     */     throws ResourceException
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void closeConnection(Connection con)
/*     */   {
/*     */     try
/*     */     {
/* 198 */       con.close();
/*     */     }
/*     */     catch (Throwable ex) {
/* 201 */       this.logger.warn("Could not close shared CCI Connection", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Connection getCloseSuppressingConnectionProxy(Connection target)
/*     */   {
/* 214 */     return (Connection)Proxy.newProxyInstance(Connection.class
/* 215 */       .getClassLoader(), new Class[] { Connection.class }, new CloseSuppressingInvocationHandler(target, null));
/*     */   }
/*     */ 
/*     */   private static class CloseSuppressingInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Connection target;
/*     */ 
/*     */     private CloseSuppressingInvocationHandler(Connection target)
/*     */     {
/* 229 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */     {
/* 234 */       if (method.getName().equals("equals"))
/*     */       {
/* 236 */         return Boolean.valueOf(proxy == args[0]);
/*     */       }
/* 238 */       if (method.getName().equals("hashCode"))
/*     */       {
/* 240 */         return Integer.valueOf(System.identityHashCode(proxy));
/*     */       }
/* 242 */       if (method.getName().equals("close"))
/*     */       {
/* 244 */         return null;
/*     */       }
/*     */       try {
/* 247 */         return method.invoke(this.target, args);
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 250 */         throw ex.getTargetException();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.connection.SingleConnectionFactory
 * JD-Core Version:    0.6.2
 */