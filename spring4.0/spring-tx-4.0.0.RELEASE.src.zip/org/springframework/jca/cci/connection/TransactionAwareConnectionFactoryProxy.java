/*     */ package org.springframework.jca.cci.connection;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.cci.Connection;
/*     */ import javax.resource.cci.ConnectionFactory;
/*     */ import javax.resource.spi.IllegalStateException;
/*     */ 
/*     */ public class TransactionAwareConnectionFactoryProxy extends DelegatingConnectionFactory
/*     */ {
/*     */   public TransactionAwareConnectionFactoryProxy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TransactionAwareConnectionFactoryProxy(ConnectionFactory targetConnectionFactory)
/*     */   {
/*  82 */     setTargetConnectionFactory(targetConnectionFactory);
/*  83 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws ResourceException
/*     */   {
/*  95 */     Connection con = ConnectionFactoryUtils.doGetConnection(getTargetConnectionFactory());
/*  96 */     return getTransactionAwareConnectionProxy(con, getTargetConnectionFactory());
/*     */   }
/*     */ 
/*     */   protected Connection getTransactionAwareConnectionProxy(Connection target, ConnectionFactory cf)
/*     */   {
/* 109 */     return (Connection)Proxy.newProxyInstance(Connection.class
/* 110 */       .getClassLoader(), new Class[] { Connection.class }, new TransactionAwareInvocationHandler(target, cf));
/*     */   }
/*     */ 
/*     */   private static class TransactionAwareInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Connection target;
/*     */     private final ConnectionFactory connectionFactory;
/*     */ 
/*     */     public TransactionAwareInvocationHandler(Connection target, ConnectionFactory cf)
/*     */     {
/* 127 */       this.target = target;
/* 128 */       this.connectionFactory = cf;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args)
/*     */       throws Throwable
/*     */     {
/* 135 */       if (method.getName().equals("equals"))
/*     */       {
/* 137 */         return Boolean.valueOf(proxy == args[0]);
/*     */       }
/* 139 */       if (method.getName().equals("hashCode"))
/*     */       {
/* 141 */         return Integer.valueOf(System.identityHashCode(proxy));
/*     */       }
/* 143 */       if (method.getName().equals("getLocalTransaction")) {
/* 144 */         if (ConnectionFactoryUtils.isConnectionTransactional(this.target, this.connectionFactory)) {
/* 145 */           throw new IllegalStateException("Local transaction handling not allowed within a managed transaction");
/*     */         }
/*     */ 
/*     */       }
/* 149 */       else if (method.getName().equals("close"))
/*     */       {
/* 151 */         ConnectionFactoryUtils.doReleaseConnection(this.target, this.connectionFactory);
/* 152 */         return null;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 157 */         return method.invoke(this.target, args);
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 160 */         throw ex.getTargetException();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.connection.TransactionAwareConnectionFactoryProxy
 * JD-Core Version:    0.6.2
 */