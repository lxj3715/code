/*     */ package org.springframework.jca.cci.core;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import javax.resource.NotSupportedException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.cci.Connection;
/*     */ import javax.resource.cci.ConnectionFactory;
/*     */ import javax.resource.cci.ConnectionSpec;
/*     */ import javax.resource.cci.IndexedRecord;
/*     */ import javax.resource.cci.Interaction;
/*     */ import javax.resource.cci.InteractionSpec;
/*     */ import javax.resource.cci.MappedRecord;
/*     */ import javax.resource.cci.Record;
/*     */ import javax.resource.cci.RecordFactory;
/*     */ import javax.resource.cci.ResultSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jca.cci.CannotCreateRecordException;
/*     */ import org.springframework.jca.cci.CciOperationNotSupportedException;
/*     */ import org.springframework.jca.cci.InvalidResultSetAccessException;
/*     */ import org.springframework.jca.cci.RecordTypeNotSupportedException;
/*     */ import org.springframework.jca.cci.connection.ConnectionFactoryUtils;
/*     */ import org.springframework.jca.cci.connection.NotSupportedRecordFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class CciTemplate
/*     */   implements CciOperations
/*     */ {
/*  72 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   private ConnectionFactory connectionFactory;
/*     */   private ConnectionSpec connectionSpec;
/*     */   private RecordCreator outputRecordCreator;
/*     */ 
/*     */   public CciTemplate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CciTemplate(ConnectionFactory connectionFactory)
/*     */   {
/*  95 */     setConnectionFactory(connectionFactory);
/*  96 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   public CciTemplate(ConnectionFactory connectionFactory, ConnectionSpec connectionSpec)
/*     */   {
/* 107 */     setConnectionFactory(connectionFactory);
/* 108 */     setConnectionSpec(connectionSpec);
/* 109 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   public void setConnectionFactory(ConnectionFactory connectionFactory)
/*     */   {
/* 117 */     this.connectionFactory = connectionFactory;
/*     */   }
/*     */ 
/*     */   public ConnectionFactory getConnectionFactory()
/*     */   {
/* 124 */     return this.connectionFactory;
/*     */   }
/*     */ 
/*     */   public void setConnectionSpec(ConnectionSpec connectionSpec)
/*     */   {
/* 132 */     this.connectionSpec = connectionSpec;
/*     */   }
/*     */ 
/*     */   public ConnectionSpec getConnectionSpec()
/*     */   {
/* 139 */     return this.connectionSpec;
/*     */   }
/*     */ 
/*     */   public void setOutputRecordCreator(RecordCreator creator)
/*     */   {
/* 155 */     this.outputRecordCreator = creator;
/*     */   }
/*     */ 
/*     */   public RecordCreator getOutputRecordCreator()
/*     */   {
/* 162 */     return this.outputRecordCreator;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/* 166 */     if (getConnectionFactory() == null)
/* 167 */       throw new IllegalArgumentException("Property 'connectionFactory' is required");
/*     */   }
/*     */ 
/*     */   public CciTemplate getDerivedTemplate(ConnectionSpec connectionSpec)
/*     */   {
/* 182 */     CciTemplate derived = new CciTemplate();
/* 183 */     derived.setConnectionFactory(getConnectionFactory());
/* 184 */     derived.setConnectionSpec(connectionSpec);
/* 185 */     derived.setOutputRecordCreator(getOutputRecordCreator());
/* 186 */     return derived;
/*     */   }
/*     */ 
/*     */   public <T> T execute(ConnectionCallback<T> action)
/*     */     throws DataAccessException
/*     */   {
/* 192 */     Assert.notNull(action, "Callback object must not be null");
/* 193 */     Connection con = ConnectionFactoryUtils.getConnection(getConnectionFactory(), getConnectionSpec());
/*     */     try {
/* 195 */       return action.doInConnection(con, getConnectionFactory());
/*     */     }
/*     */     catch (NotSupportedException ex) {
/* 198 */       throw new CciOperationNotSupportedException("CCI operation not supported by connector", ex);
/*     */     }
/*     */     catch (ResourceException ex) {
/* 201 */       throw new DataAccessResourceFailureException("CCI operation failed", ex);
/*     */     }
/*     */     catch (SQLException ex) {
/* 204 */       throw new InvalidResultSetAccessException("Parsing of CCI ResultSet failed", ex);
/*     */     }
/*     */     finally {
/* 207 */       ConnectionFactoryUtils.releaseConnection(con, getConnectionFactory());
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T execute(final InteractionCallback<T> action) throws DataAccessException
/*     */   {
/* 213 */     Assert.notNull(action, "Callback object must not be null");
/* 214 */     return execute(new ConnectionCallback()
/*     */     {
/*     */       public T doInConnection(Connection connection, ConnectionFactory connectionFactory) throws ResourceException, SQLException, DataAccessException
/*     */       {
/* 218 */         Interaction interaction = connection.createInteraction();
/*     */         try {
/* 220 */           return action.doInInteraction(interaction, connectionFactory);
/*     */         }
/*     */         finally {
/* 223 */           CciTemplate.this.closeInteraction(interaction);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Record execute(InteractionSpec spec, Record inputRecord) throws DataAccessException
/*     */   {
/* 231 */     return (Record)doExecute(spec, inputRecord, null, new SimpleRecordExtractor(null));
/*     */   }
/*     */ 
/*     */   public void execute(InteractionSpec spec, Record inputRecord, Record outputRecord) throws DataAccessException
/*     */   {
/* 236 */     doExecute(spec, inputRecord, outputRecord, null);
/*     */   }
/*     */ 
/*     */   public Record execute(InteractionSpec spec, RecordCreator inputCreator) throws DataAccessException
/*     */   {
/* 241 */     return (Record)doExecute(spec, createRecord(inputCreator), null, new SimpleRecordExtractor(null));
/*     */   }
/*     */ 
/*     */   public <T> T execute(InteractionSpec spec, Record inputRecord, RecordExtractor<T> outputExtractor)
/*     */     throws DataAccessException
/*     */   {
/* 248 */     return doExecute(spec, inputRecord, null, outputExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(InteractionSpec spec, RecordCreator inputCreator, RecordExtractor<T> outputExtractor)
/*     */     throws DataAccessException
/*     */   {
/* 255 */     return doExecute(spec, createRecord(inputCreator), null, outputExtractor);
/*     */   }
/*     */ 
/*     */   protected <T> T doExecute(final InteractionSpec spec, final Record inputRecord, final Record outputRecord, final RecordExtractor<T> outputExtractor)
/*     */     throws DataAccessException
/*     */   {
/* 273 */     return execute(new Object()
/*     */     {
/*     */       public T doInInteraction(Interaction interaction, ConnectionFactory connectionFactory) throws ResourceException, SQLException, DataAccessException
/*     */       {
/* 277 */         Record outputRecordToUse = outputRecord;
/*     */         try
/*     */         {
/*     */           RecordFactory recordFactory;
/* 279 */           if ((outputRecord != null) || (CciTemplate.this.getOutputRecordCreator() != null))
/*     */           {
/* 281 */             if (outputRecord == null) {
/* 282 */               recordFactory = CciTemplate.this.getRecordFactory(connectionFactory);
/* 283 */               outputRecordToUse = CciTemplate.this.getOutputRecordCreator().createRecord(recordFactory);
/*     */             }
/* 285 */             interaction.execute(spec, inputRecord, outputRecordToUse);
/*     */           }
/*     */           else {
/* 288 */             outputRecordToUse = interaction.execute(spec, inputRecord);
/*     */           }
/* 290 */           return outputExtractor != null ? outputExtractor.extractData(outputRecordToUse) : null;
/*     */         }
/*     */         finally {
/* 293 */           if ((outputRecordToUse instanceof ResultSet))
/* 294 */             CciTemplate.this.closeResultSet((ResultSet)outputRecordToUse);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public IndexedRecord createIndexedRecord(String name)
/*     */     throws DataAccessException
/*     */   {
/*     */     try
/*     */     {
/* 312 */       RecordFactory recordFactory = getRecordFactory(getConnectionFactory());
/* 313 */       return recordFactory.createIndexedRecord(name);
/*     */     }
/*     */     catch (NotSupportedException ex) {
/* 316 */       throw new RecordTypeNotSupportedException("Creation of indexed Record not supported by connector", ex);
/*     */     }
/*     */     catch (ResourceException ex) {
/* 319 */       throw new CannotCreateRecordException("Creation of indexed Record failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public MappedRecord createMappedRecord(String name)
/*     */     throws DataAccessException
/*     */   {
/*     */     try
/*     */     {
/* 333 */       RecordFactory recordFactory = getRecordFactory(getConnectionFactory());
/* 334 */       return recordFactory.createMappedRecord(name);
/*     */     }
/*     */     catch (NotSupportedException ex) {
/* 337 */       throw new RecordTypeNotSupportedException("Creation of mapped Record not supported by connector", ex);
/*     */     }
/*     */     catch (ResourceException ex) {
/* 340 */       throw new CannotCreateRecordException("Creation of mapped Record failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Record createRecord(RecordCreator recordCreator)
/*     */     throws DataAccessException
/*     */   {
/*     */     try
/*     */     {
/* 355 */       RecordFactory recordFactory = getRecordFactory(getConnectionFactory());
/* 356 */       return recordCreator.createRecord(recordFactory);
/*     */     }
/*     */     catch (NotSupportedException ex) {
/* 359 */       throw new RecordTypeNotSupportedException("Creation of the desired Record type not supported by connector", ex);
/*     */     }
/*     */     catch (ResourceException ex)
/*     */     {
/* 363 */       throw new CannotCreateRecordException("Creation of the desired Record failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected RecordFactory getRecordFactory(ConnectionFactory connectionFactory)
/*     */     throws ResourceException
/*     */   {
/*     */     try
/*     */     {
/* 380 */       return connectionFactory.getRecordFactory();
/*     */     } catch (NotSupportedException ex) {
/*     */     }
/* 383 */     return new NotSupportedRecordFactory();
/*     */   }
/*     */ 
/*     */   private void closeInteraction(Interaction interaction)
/*     */   {
/* 395 */     if (interaction != null)
/*     */       try {
/* 397 */         interaction.close();
/*     */       }
/*     */       catch (ResourceException ex) {
/* 400 */         this.logger.trace("Could not close CCI Interaction", ex);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 404 */         this.logger.trace("Unexpected exception on closing CCI Interaction", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void closeResultSet(ResultSet resultSet)
/*     */   {
/* 416 */     if (resultSet != null)
/*     */       try {
/* 418 */         resultSet.close();
/*     */       }
/*     */       catch (SQLException ex) {
/* 421 */         this.logger.trace("Could not close CCI ResultSet", ex);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 425 */         this.logger.trace("Unexpected exception on closing CCI ResultSet", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   private static class SimpleRecordExtractor
/*     */     implements RecordExtractor<Record>
/*     */   {
/*     */     public Record extractData(Record record)
/*     */     {
/* 435 */       return record;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.core.CciTemplate
 * JD-Core Version:    0.6.2
 */