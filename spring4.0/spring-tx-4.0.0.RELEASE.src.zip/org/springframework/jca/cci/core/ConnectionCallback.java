package org.springframework.jca.cci.core;

import java.sql.SQLException;
import javax.resource.ResourceException;
import javax.resource.cci.Connection;
import javax.resource.cci.ConnectionFactory;
import org.springframework.dao.DataAccessException;

public abstract interface ConnectionCallback<T>
{
  public abstract T doInConnection(Connection paramConnection, ConnectionFactory paramConnectionFactory)
    throws ResourceException, SQLException, DataAccessException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.core.ConnectionCallback
 * JD-Core Version:    0.6.2
 */