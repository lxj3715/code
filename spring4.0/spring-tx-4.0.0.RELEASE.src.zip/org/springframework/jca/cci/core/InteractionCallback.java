package org.springframework.jca.cci.core;

import java.sql.SQLException;
import javax.resource.ResourceException;
import javax.resource.cci.ConnectionFactory;
import javax.resource.cci.Interaction;
import org.springframework.dao.DataAccessException;

public abstract interface InteractionCallback<T>
{
  public abstract T doInInteraction(Interaction paramInteraction, ConnectionFactory paramConnectionFactory)
    throws ResourceException, SQLException, DataAccessException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.core.InteractionCallback
 * JD-Core Version:    0.6.2
 */