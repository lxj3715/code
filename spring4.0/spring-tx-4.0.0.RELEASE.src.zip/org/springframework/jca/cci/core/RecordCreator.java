package org.springframework.jca.cci.core;

import javax.resource.ResourceException;
import javax.resource.cci.Record;
import javax.resource.cci.RecordFactory;
import org.springframework.dao.DataAccessException;

public abstract interface RecordCreator
{
  public abstract Record createRecord(RecordFactory paramRecordFactory)
    throws ResourceException, DataAccessException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.core.RecordCreator
 * JD-Core Version:    0.6.2
 */