package org.springframework.jca.cci.core;

import java.sql.SQLException;
import javax.resource.ResourceException;
import javax.resource.cci.Record;
import org.springframework.dao.DataAccessException;

public abstract interface RecordExtractor<T>
{
  public abstract T extractData(Record paramRecord)
    throws ResourceException, SQLException, DataAccessException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.core.RecordExtractor
 * JD-Core Version:    0.6.2
 */