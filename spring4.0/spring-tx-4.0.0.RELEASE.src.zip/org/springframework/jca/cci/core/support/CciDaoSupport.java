/*     */ package org.springframework.jca.cci.core.support;
/*     */ 
/*     */ import javax.resource.cci.Connection;
/*     */ import javax.resource.cci.ConnectionFactory;
/*     */ import javax.resource.cci.ConnectionSpec;
/*     */ import org.springframework.dao.support.DaoSupport;
/*     */ import org.springframework.jca.cci.CannotGetCciConnectionException;
/*     */ import org.springframework.jca.cci.connection.ConnectionFactoryUtils;
/*     */ import org.springframework.jca.cci.core.CciTemplate;
/*     */ 
/*     */ public abstract class CciDaoSupport extends DaoSupport
/*     */ {
/*     */   private CciTemplate cciTemplate;
/*     */ 
/*     */   public final void setConnectionFactory(ConnectionFactory connectionFactory)
/*     */   {
/*  55 */     if ((this.cciTemplate == null) || (connectionFactory != this.cciTemplate.getConnectionFactory()))
/*  56 */       this.cciTemplate = createCciTemplate(connectionFactory);
/*     */   }
/*     */ 
/*     */   protected CciTemplate createCciTemplate(ConnectionFactory connectionFactory)
/*     */   {
/*  70 */     return new CciTemplate(connectionFactory);
/*     */   }
/*     */ 
/*     */   public final ConnectionFactory getConnectionFactory()
/*     */   {
/*  77 */     return this.cciTemplate.getConnectionFactory();
/*     */   }
/*     */ 
/*     */   public final void setCciTemplate(CciTemplate cciTemplate)
/*     */   {
/*  85 */     this.cciTemplate = cciTemplate;
/*     */   }
/*     */ 
/*     */   public final CciTemplate getCciTemplate()
/*     */   {
/*  93 */     return this.cciTemplate;
/*     */   }
/*     */ 
/*     */   protected final void checkDaoConfig()
/*     */   {
/*  98 */     if (this.cciTemplate == null)
/*  99 */       throw new IllegalArgumentException("'connectionFactory' or 'cciTemplate' is required");
/*     */   }
/*     */ 
/*     */   protected final CciTemplate getCciTemplate(ConnectionSpec connectionSpec)
/*     */   {
/* 114 */     return getCciTemplate().getDerivedTemplate(connectionSpec);
/*     */   }
/*     */ 
/*     */   protected final Connection getConnection()
/*     */     throws CannotGetCciConnectionException
/*     */   {
/* 125 */     return ConnectionFactoryUtils.getConnection(getConnectionFactory());
/*     */   }
/*     */ 
/*     */   protected final void releaseConnection(Connection con)
/*     */   {
/* 135 */     ConnectionFactoryUtils.releaseConnection(con, getConnectionFactory());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.core.support.CciDaoSupport
 * JD-Core Version:    0.6.2
 */