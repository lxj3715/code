/*     */ package org.springframework.jca.cci.core.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.resource.cci.Record;
/*     */ import javax.resource.cci.Streamable;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ public class CommAreaRecord
/*     */   implements Record, Streamable
/*     */ {
/*     */   private byte[] bytes;
/*     */   private String recordName;
/*     */   private String recordShortDescription;
/*     */ 
/*     */   public CommAreaRecord()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CommAreaRecord(byte[] bytes)
/*     */   {
/*  58 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */   public void setRecordName(String recordName)
/*     */   {
/*  64 */     this.recordName = recordName;
/*     */   }
/*     */ 
/*     */   public String getRecordName()
/*     */   {
/*  69 */     return this.recordName;
/*     */   }
/*     */ 
/*     */   public void setRecordShortDescription(String recordShortDescription)
/*     */   {
/*  74 */     this.recordShortDescription = recordShortDescription;
/*     */   }
/*     */ 
/*     */   public String getRecordShortDescription()
/*     */   {
/*  79 */     return this.recordShortDescription;
/*     */   }
/*     */ 
/*     */   public void read(InputStream in)
/*     */     throws IOException
/*     */   {
/*  85 */     this.bytes = FileCopyUtils.copyToByteArray(in);
/*     */   }
/*     */ 
/*     */   public void write(OutputStream out) throws IOException
/*     */   {
/*  90 */     out.write(this.bytes);
/*  91 */     out.flush();
/*     */   }
/*     */ 
/*     */   public byte[] toByteArray() {
/*  95 */     return this.bytes;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 101 */     return new CommAreaRecord(this.bytes);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.core.support.CommAreaRecord
 * JD-Core Version:    0.6.2
 */