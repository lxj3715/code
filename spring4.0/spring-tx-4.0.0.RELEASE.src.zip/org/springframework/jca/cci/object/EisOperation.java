/*    */ package org.springframework.jca.cci.object;
/*    */ 
/*    */ import javax.resource.cci.ConnectionFactory;
/*    */ import javax.resource.cci.InteractionSpec;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.jca.cci.core.CciTemplate;
/*    */ 
/*    */ public abstract class EisOperation
/*    */   implements InitializingBean
/*    */ {
/* 39 */   private CciTemplate cciTemplate = new CciTemplate();
/*    */   private InteractionSpec interactionSpec;
/*    */ 
/*    */   public void setCciTemplate(CciTemplate cciTemplate)
/*    */   {
/* 50 */     if (cciTemplate == null) {
/* 51 */       throw new IllegalArgumentException("cciTemplate must not be null");
/*    */     }
/* 53 */     this.cciTemplate = cciTemplate;
/*    */   }
/*    */ 
/*    */   public CciTemplate getCciTemplate()
/*    */   {
/* 60 */     return this.cciTemplate;
/*    */   }
/*    */ 
/*    */   public void setConnectionFactory(ConnectionFactory connectionFactory)
/*    */   {
/* 67 */     this.cciTemplate.setConnectionFactory(connectionFactory);
/*    */   }
/*    */ 
/*    */   public void setInteractionSpec(InteractionSpec interactionSpec)
/*    */   {
/* 74 */     this.interactionSpec = interactionSpec;
/*    */   }
/*    */ 
/*    */   public InteractionSpec getInteractionSpec()
/*    */   {
/* 81 */     return this.interactionSpec;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 87 */     this.cciTemplate.afterPropertiesSet();
/*    */ 
/* 89 */     if (this.interactionSpec == null)
/* 90 */       throw new IllegalArgumentException("interactionSpec is required");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.object.EisOperation
 * JD-Core Version:    0.6.2
 */