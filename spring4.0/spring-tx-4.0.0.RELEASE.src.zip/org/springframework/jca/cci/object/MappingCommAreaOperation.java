/*    */ package org.springframework.jca.cci.object;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.resource.cci.ConnectionFactory;
/*    */ import javax.resource.cci.InteractionSpec;
/*    */ import javax.resource.cci.Record;
/*    */ import javax.resource.cci.RecordFactory;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.dao.DataRetrievalFailureException;
/*    */ import org.springframework.jca.cci.core.support.CommAreaRecord;
/*    */ 
/*    */ public abstract class MappingCommAreaOperation extends MappingRecordOperation
/*    */ {
/*    */   public MappingCommAreaOperation()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MappingCommAreaOperation(ConnectionFactory connectionFactory, InteractionSpec interactionSpec)
/*    */   {
/* 53 */     super(connectionFactory, interactionSpec);
/*    */   }
/*    */ 
/*    */   protected final Record createInputRecord(RecordFactory recordFactory, Object inObject)
/*    */   {
/*    */     try
/*    */     {
/* 60 */       return new CommAreaRecord(objectToBytes(inObject));
/*    */     }
/*    */     catch (IOException ex) {
/* 63 */       throw new DataRetrievalFailureException("I/O exception during bytes conversion", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected final Object extractOutputData(Record record) throws DataAccessException
/*    */   {
/* 69 */     CommAreaRecord commAreaRecord = (CommAreaRecord)record;
/*    */     try {
/* 71 */       return bytesToObject(commAreaRecord.toByteArray());
/*    */     }
/*    */     catch (IOException ex) {
/* 74 */       throw new DataRetrievalFailureException("I/O exception during bytes conversion", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract byte[] objectToBytes(Object paramObject)
/*    */     throws IOException, DataAccessException;
/*    */ 
/*    */   protected abstract Object bytesToObject(byte[] paramArrayOfByte)
/*    */     throws IOException, DataAccessException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.object.MappingCommAreaOperation
 * JD-Core Version:    0.6.2
 */