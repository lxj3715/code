/*     */ package org.springframework.jca.cci.object;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.cci.ConnectionFactory;
/*     */ import javax.resource.cci.InteractionSpec;
/*     */ import javax.resource.cci.Record;
/*     */ import javax.resource.cci.RecordFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jca.cci.core.CciTemplate;
/*     */ import org.springframework.jca.cci.core.RecordCreator;
/*     */ import org.springframework.jca.cci.core.RecordExtractor;
/*     */ 
/*     */ public abstract class MappingRecordOperation extends EisOperation
/*     */ {
/*     */   public MappingRecordOperation()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MappingRecordOperation(ConnectionFactory connectionFactory, InteractionSpec interactionSpec)
/*     */   {
/*  61 */     getCciTemplate().setConnectionFactory(connectionFactory);
/*  62 */     setInteractionSpec(interactionSpec);
/*     */   }
/*     */ 
/*     */   public void setOutputRecordCreator(RecordCreator creator)
/*     */   {
/*  77 */     getCciTemplate().setOutputRecordCreator(creator);
/*     */   }
/*     */ 
/*     */   public Object execute(Object inputObject)
/*     */     throws DataAccessException
/*     */   {
/*  90 */     return getCciTemplate().execute(
/*  91 */       getInteractionSpec(), new RecordCreatorImpl(inputObject), new RecordExtractorImpl());
/*     */   }
/*     */ 
/*     */   protected abstract Record createInputRecord(RecordFactory paramRecordFactory, Object paramObject)
/*     */     throws ResourceException, DataAccessException;
/*     */ 
/*     */   protected abstract Object extractOutputData(Record paramRecord)
/*     */     throws ResourceException, SQLException, DataAccessException;
/*     */ 
/*     */   protected class RecordExtractorImpl
/*     */     implements RecordExtractor<Object>
/*     */   {
/*     */     protected RecordExtractorImpl()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Object extractData(Record record)
/*     */       throws ResourceException, SQLException, DataAccessException
/*     */     {
/* 147 */       return MappingRecordOperation.this.extractOutputData(record);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class RecordCreatorImpl
/*     */     implements RecordCreator
/*     */   {
/*     */     private final Object inputObject;
/*     */ 
/*     */     public RecordCreatorImpl(Object inObject)
/*     */     {
/* 129 */       this.inputObject = inObject;
/*     */     }
/*     */ 
/*     */     public Record createRecord(RecordFactory recordFactory) throws ResourceException, DataAccessException
/*     */     {
/* 134 */       return MappingRecordOperation.this.createInputRecord(recordFactory, this.inputObject);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.object.MappingRecordOperation
 * JD-Core Version:    0.6.2
 */