/*    */ package org.springframework.jca.cci.object;
/*    */ 
/*    */ import javax.resource.cci.ConnectionFactory;
/*    */ import javax.resource.cci.InteractionSpec;
/*    */ import javax.resource.cci.Record;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.jca.cci.core.CciTemplate;
/*    */ 
/*    */ public class SimpleRecordOperation extends EisOperation
/*    */ {
/*    */   public SimpleRecordOperation()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SimpleRecordOperation(ConnectionFactory connectionFactory, InteractionSpec interactionSpec)
/*    */   {
/* 46 */     getCciTemplate().setConnectionFactory(connectionFactory);
/* 47 */     setInteractionSpec(interactionSpec);
/*    */   }
/*    */ 
/*    */   public Record execute(Record inputRecord)
/*    */     throws DataAccessException
/*    */   {
/* 60 */     return getCciTemplate().execute(getInteractionSpec(), inputRecord);
/*    */   }
/*    */ 
/*    */   public void execute(Record inputRecord, Record outputRecord)
/*    */     throws DataAccessException
/*    */   {
/* 73 */     getCciTemplate().execute(getInteractionSpec(), inputRecord, outputRecord);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.cci.object.SimpleRecordOperation
 * JD-Core Version:    0.6.2
 */