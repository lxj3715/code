package org.springframework.jca.context;

import javax.resource.spi.BootstrapContext;
import org.springframework.beans.factory.Aware;

public abstract interface BootstrapContextAware extends Aware
{
  public abstract void setBootstrapContext(BootstrapContext paramBootstrapContext);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.context.BootstrapContextAware
 * JD-Core Version:    0.6.2
 */