/*    */ package org.springframework.jca.context;
/*    */ 
/*    */ import javax.resource.spi.BootstrapContext;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ 
/*    */ class BootstrapContextAwareProcessor
/*    */   implements BeanPostProcessor
/*    */ {
/*    */   private final BootstrapContext bootstrapContext;
/*    */ 
/*    */   public BootstrapContextAwareProcessor(BootstrapContext bootstrapContext)
/*    */   {
/* 45 */     this.bootstrapContext = bootstrapContext;
/*    */   }
/*    */ 
/*    */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*    */     throws BeansException
/*    */   {
/* 51 */     if ((this.bootstrapContext != null) && ((bean instanceof BootstrapContextAware))) {
/* 52 */       ((BootstrapContextAware)bean).setBootstrapContext(this.bootstrapContext);
/*    */     }
/* 54 */     return bean;
/*    */   }
/*    */ 
/*    */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException
/*    */   {
/* 59 */     return bean;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.context.BootstrapContextAwareProcessor
 * JD-Core Version:    0.6.2
 */