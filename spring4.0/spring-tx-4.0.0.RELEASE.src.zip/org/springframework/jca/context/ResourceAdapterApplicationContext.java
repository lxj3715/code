/*    */ package org.springframework.jca.context;
/*    */ 
/*    */ import javax.resource.spi.BootstrapContext;
/*    */ import javax.resource.spi.work.WorkManager;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.ObjectFactory;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.context.support.GenericApplicationContext;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ResourceAdapterApplicationContext extends GenericApplicationContext
/*    */ {
/*    */   private final BootstrapContext bootstrapContext;
/*    */ 
/*    */   public ResourceAdapterApplicationContext(BootstrapContext bootstrapContext)
/*    */   {
/* 50 */     Assert.notNull(bootstrapContext, "BootstrapContext must not be null");
/* 51 */     this.bootstrapContext = bootstrapContext;
/*    */   }
/*    */ 
/*    */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*    */     throws BeansException
/*    */   {
/* 57 */     beanFactory.addBeanPostProcessor(new BootstrapContextAwareProcessor(this.bootstrapContext));
/* 58 */     beanFactory.ignoreDependencyInterface(BootstrapContextAware.class);
/* 59 */     beanFactory.registerResolvableDependency(BootstrapContext.class, this.bootstrapContext);
/*    */ 
/* 62 */     beanFactory.registerResolvableDependency(WorkManager.class, new ObjectFactory()
/*    */     {
/*    */       public WorkManager getObject() {
/* 65 */         return ResourceAdapterApplicationContext.this.bootstrapContext.getWorkManager();
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.context.ResourceAdapterApplicationContext
 * JD-Core Version:    0.6.2
 */