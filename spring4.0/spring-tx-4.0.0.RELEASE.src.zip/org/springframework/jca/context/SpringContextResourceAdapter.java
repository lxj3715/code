/*     */ package org.springframework.jca.context;
/*     */ 
/*     */ import javax.resource.NotSupportedException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ActivationSpec;
/*     */ import javax.resource.spi.BootstrapContext;
/*     */ import javax.resource.spi.ResourceAdapter;
/*     */ import javax.resource.spi.ResourceAdapterInternalException;
/*     */ import javax.resource.spi.endpoint.MessageEndpointFactory;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class SpringContextResourceAdapter
/*     */   implements ResourceAdapter
/*     */ {
/*     */   public static final String CONFIG_LOCATION_DELIMITERS = ",; \t\n";
/*     */   public static final String DEFAULT_CONTEXT_CONFIG_LOCATION = "META-INF/applicationContext.xml";
/* 120 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/* 122 */   private String contextConfigLocation = "META-INF/applicationContext.xml";
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */ 
/*     */   public void setContextConfigLocation(String contextConfigLocation)
/*     */   {
/* 137 */     this.contextConfigLocation = contextConfigLocation;
/*     */   }
/*     */ 
/*     */   protected String getContextConfigLocation()
/*     */   {
/* 144 */     return this.contextConfigLocation;
/*     */   }
/*     */ 
/*     */   protected ConfigurableEnvironment createEnvironment()
/*     */   {
/* 153 */     return new StandardEnvironment();
/*     */   }
/*     */ 
/*     */   public void start(BootstrapContext bootstrapContext)
/*     */     throws ResourceAdapterInternalException
/*     */   {
/* 162 */     if (this.logger.isInfoEnabled()) {
/* 163 */       this.logger.info("Starting SpringContextResourceAdapter with BootstrapContext: " + bootstrapContext);
/*     */     }
/* 165 */     this.applicationContext = createApplicationContext(bootstrapContext);
/*     */   }
/*     */ 
/*     */   protected ConfigurableApplicationContext createApplicationContext(BootstrapContext bootstrapContext)
/*     */   {
/* 177 */     ResourceAdapterApplicationContext applicationContext = new ResourceAdapterApplicationContext(bootstrapContext);
/*     */ 
/* 180 */     applicationContext.setClassLoader(getClass().getClassLoader());
/*     */ 
/* 183 */     String[] configLocations = StringUtils.tokenizeToStringArray(getContextConfigLocation(), ",; \t\n");
/* 184 */     if (configLocations != null) {
/* 185 */       loadBeanDefinitions(applicationContext, configLocations);
/*     */     }
/* 187 */     applicationContext.refresh();
/* 188 */     return applicationContext;
/*     */   }
/*     */ 
/*     */   protected void loadBeanDefinitions(BeanDefinitionRegistry registry, String[] configLocations)
/*     */   {
/* 199 */     new XmlBeanDefinitionReader(registry).loadBeanDefinitions(configLocations);
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 207 */     this.logger.info("Stopping SpringContextResourceAdapter");
/* 208 */     this.applicationContext.close();
/*     */   }
/*     */ 
/*     */   public void endpointActivation(MessageEndpointFactory messageEndpointFactory, ActivationSpec activationSpec)
/*     */     throws ResourceException
/*     */   {
/* 219 */     throw new NotSupportedException("SpringContextResourceAdapter does not support message endpoints");
/*     */   }
/*     */ 
/*     */   public void endpointDeactivation(MessageEndpointFactory messageEndpointFactory, ActivationSpec activationSpec)
/*     */   {
/*     */   }
/*     */ 
/*     */   public XAResource[] getXAResources(ActivationSpec[] activationSpecs)
/*     */     throws ResourceException
/*     */   {
/* 234 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 241 */     return ((obj instanceof SpringContextResourceAdapter)) && 
/* 241 */       (ObjectUtils.nullSafeEquals(getContextConfigLocation(), ((SpringContextResourceAdapter)obj)
/* 242 */       .getContextConfigLocation()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 247 */     return ObjectUtils.nullSafeHashCode(getContextConfigLocation());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.context.SpringContextResourceAdapter
 * JD-Core Version:    0.6.2
 */