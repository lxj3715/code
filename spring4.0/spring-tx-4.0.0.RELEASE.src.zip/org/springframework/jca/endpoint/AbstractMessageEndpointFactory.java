/*     */ package org.springframework.jca.endpoint;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ApplicationServerInternalException;
/*     */ import javax.resource.spi.UnavailableException;
/*     */ import javax.resource.spi.endpoint.MessageEndpoint;
/*     */ import javax.resource.spi.endpoint.MessageEndpointFactory;
/*     */ import javax.transaction.Transaction;
/*     */ import javax.transaction.TransactionManager;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.transaction.jta.SimpleTransactionFactory;
/*     */ import org.springframework.transaction.jta.TransactionFactory;
/*     */ 
/*     */ public abstract class AbstractMessageEndpointFactory
/*     */   implements MessageEndpointFactory, BeanNameAware
/*     */ {
/*     */   protected final Log logger;
/*     */   private TransactionFactory transactionFactory;
/*     */   private String transactionName;
/*     */   private int transactionTimeout;
/*     */   private String beanName;
/*     */ 
/*     */   public AbstractMessageEndpointFactory()
/*     */   {
/*  49 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  55 */     this.transactionTimeout = -1;
/*     */   }
/*     */ 
/*     */   public void setTransactionManager(Object transactionManager)
/*     */   {
/*  74 */     if ((transactionManager instanceof TransactionFactory)) {
/*  75 */       this.transactionFactory = ((TransactionFactory)transactionManager);
/*     */     }
/*  77 */     else if ((transactionManager instanceof TransactionManager)) {
/*  78 */       this.transactionFactory = new SimpleTransactionFactory((TransactionManager)transactionManager);
/*     */     }
/*     */     else
/*  81 */       throw new IllegalArgumentException("Transaction manager [" + transactionManager + "] is neither a [org.springframework.transaction.jta.TransactionFactory} nor a " + "[javax.transaction.TransactionManager]");
/*     */   }
/*     */ 
/*     */   public void setTransactionFactory(TransactionFactory transactionFactory)
/*     */   {
/* 100 */     this.transactionFactory = transactionFactory;
/*     */   }
/*     */ 
/*     */   public void setTransactionName(String transactionName)
/*     */   {
/* 109 */     this.transactionName = transactionName;
/*     */   }
/*     */ 
/*     */   public void setTransactionTimeout(int transactionTimeout)
/*     */   {
/* 119 */     this.transactionTimeout = transactionTimeout;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName)
/*     */   {
/* 128 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public String getActivationName()
/*     */   {
/* 138 */     return this.beanName;
/*     */   }
/*     */ 
/*     */   public boolean isDeliveryTransacted(Method method)
/*     */     throws NoSuchMethodException
/*     */   {
/* 149 */     return this.transactionFactory != null;
/*     */   }
/*     */ 
/*     */   public MessageEndpoint createEndpoint(XAResource xaResource)
/*     */     throws UnavailableException
/*     */   {
/* 159 */     AbstractMessageEndpoint endpoint = createEndpointInternal();
/* 160 */     endpoint.initXAResource(xaResource);
/* 161 */     return endpoint;
/*     */   }
/*     */ 
/*     */   public MessageEndpoint createEndpoint(XAResource xaResource, long timeout)
/*     */     throws UnavailableException
/*     */   {
/* 170 */     AbstractMessageEndpoint endpoint = createEndpointInternal();
/* 171 */     endpoint.initXAResource(xaResource);
/* 172 */     return endpoint;
/*     */   }
/*     */ 
/*     */   protected abstract AbstractMessageEndpoint createEndpointInternal()
/*     */     throws UnavailableException;
/*     */ 
/*     */   private class TransactionDelegate
/*     */   {
/*     */     private final XAResource xaResource;
/*     */     private Transaction transaction;
/*     */     private boolean rollbackOnly;
/*     */ 
/*     */     public TransactionDelegate(XAResource xaResource)
/*     */     {
/* 301 */       if ((xaResource == null) && 
/* 302 */         (AbstractMessageEndpointFactory.this.transactionFactory != null) && (!AbstractMessageEndpointFactory.this.transactionFactory.supportsResourceAdapterManagedTransactions())) {
/* 303 */         throw new IllegalStateException("ResourceAdapter-provided XAResource is required for transaction management. Check your ResourceAdapter's configuration.");
/*     */       }
/*     */ 
/* 307 */       this.xaResource = xaResource;
/*     */     }
/*     */ 
/*     */     public void beginTransaction() throws Exception {
/* 311 */       if ((AbstractMessageEndpointFactory.this.transactionFactory != null) && (this.xaResource != null)) {
/* 312 */         this.transaction = AbstractMessageEndpointFactory.this.transactionFactory.createTransaction(AbstractMessageEndpointFactory.this.transactionName, AbstractMessageEndpointFactory.this.transactionTimeout);
/* 313 */         this.transaction.enlistResource(this.xaResource);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setRollbackOnly() {
/* 318 */       if (this.transaction != null)
/* 319 */         this.rollbackOnly = true;
/*     */     }
/*     */ 
/*     */     public void endTransaction() throws Exception
/*     */     {
/* 324 */       if (this.transaction != null)
/*     */         try {
/* 326 */           if (this.rollbackOnly) {
/* 327 */             this.transaction.rollback();
/*     */           }
/*     */           else {
/* 330 */             this.transaction.commit();
/*     */           }
/*     */ 
/* 334 */           this.transaction = null;
/* 335 */           this.rollbackOnly = false;
/*     */         }
/*     */         finally
/*     */         {
/* 334 */           this.transaction = null;
/* 335 */           this.rollbackOnly = false;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract class AbstractMessageEndpoint
/*     */     implements MessageEndpoint
/*     */   {
/*     */     private AbstractMessageEndpointFactory.TransactionDelegate transactionDelegate;
/* 192 */     private boolean beforeDeliveryCalled = false;
/*     */     private ClassLoader previousContextClassLoader;
/*     */ 
/*     */     protected AbstractMessageEndpoint()
/*     */     {
/*     */     }
/*     */ 
/*     */     void initXAResource(XAResource xaResource)
/*     */     {
/* 201 */       this.transactionDelegate = new AbstractMessageEndpointFactory.TransactionDelegate(AbstractMessageEndpointFactory.this, xaResource);
/*     */     }
/*     */ 
/*     */     public void beforeDelivery(Method method)
/*     */       throws ResourceException
/*     */     {
/* 216 */       this.beforeDeliveryCalled = true;
/*     */       try {
/* 218 */         this.transactionDelegate.beginTransaction();
/*     */       }
/*     */       catch (Throwable ex) {
/* 221 */         throw new ApplicationServerInternalException("Failed to begin transaction", ex);
/*     */       }
/* 223 */       Thread currentThread = Thread.currentThread();
/* 224 */       this.previousContextClassLoader = currentThread.getContextClassLoader();
/* 225 */       currentThread.setContextClassLoader(getEndpointClassLoader());
/*     */     }
/*     */ 
/*     */     protected abstract ClassLoader getEndpointClassLoader();
/*     */ 
/*     */     protected final boolean hasBeforeDeliveryBeenCalled()
/*     */     {
/* 241 */       return this.beforeDeliveryCalled;
/*     */     }
/*     */ 
/*     */     protected final void onEndpointException(Throwable ex)
/*     */     {
/* 252 */       this.transactionDelegate.setRollbackOnly();
/*     */     }
/*     */ 
/*     */     public void afterDelivery()
/*     */       throws ResourceException
/*     */     {
/* 264 */       this.beforeDeliveryCalled = false;
/* 265 */       Thread.currentThread().setContextClassLoader(this.previousContextClassLoader);
/* 266 */       this.previousContextClassLoader = null;
/*     */       try {
/* 268 */         this.transactionDelegate.endTransaction();
/*     */       }
/*     */       catch (Throwable ex) {
/* 271 */         throw new ApplicationServerInternalException("Failed to complete transaction", ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void release()
/*     */     {
/*     */       try {
/* 278 */         this.transactionDelegate.setRollbackOnly();
/* 279 */         this.transactionDelegate.endTransaction();
/*     */       }
/*     */       catch (Throwable ex) {
/* 282 */         AbstractMessageEndpointFactory.this.logger.error("Could not complete unfinished transaction on endpoint release", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.endpoint.AbstractMessageEndpointFactory
 * JD-Core Version:    0.6.2
 */