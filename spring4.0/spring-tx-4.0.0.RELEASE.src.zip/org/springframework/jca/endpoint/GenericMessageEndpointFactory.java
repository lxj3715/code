/*     */ package org.springframework.jca.endpoint;
/*     */ 
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.UnavailableException;
/*     */ import javax.resource.spi.endpoint.MessageEndpoint;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.support.DelegatingIntroductionInterceptor;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class GenericMessageEndpointFactory extends AbstractMessageEndpointFactory
/*     */ {
/*     */   private Object messageListener;
/*     */ 
/*     */   public void setMessageListener(Object messageListener)
/*     */   {
/*  64 */     this.messageListener = messageListener;
/*     */   }
/*     */ 
/*     */   public MessageEndpoint createEndpoint(XAResource xaResource)
/*     */     throws UnavailableException
/*     */   {
/*  74 */     GenericMessageEndpoint endpoint = (GenericMessageEndpoint)super.createEndpoint(xaResource);
/*  75 */     ProxyFactory proxyFactory = new ProxyFactory(this.messageListener);
/*  76 */     DelegatingIntroductionInterceptor introduction = new DelegatingIntroductionInterceptor(endpoint);
/*  77 */     introduction.suppressInterface(MethodInterceptor.class);
/*  78 */     proxyFactory.addAdvice(introduction);
/*  79 */     return (MessageEndpoint)proxyFactory.getProxy();
/*     */   }
/*     */ 
/*     */   protected AbstractMessageEndpointFactory.AbstractMessageEndpoint createEndpointInternal()
/*     */     throws UnavailableException
/*     */   {
/*  87 */     return new GenericMessageEndpoint(null);
/*     */   }
/*     */ 
/*     */   public static class InternalResourceException extends RuntimeException
/*     */   {
/*     */     protected InternalResourceException(ResourceException cause)
/*     */     {
/* 156 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class GenericMessageEndpoint extends AbstractMessageEndpointFactory.AbstractMessageEndpoint
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private GenericMessageEndpoint()
/*     */     {
/*  95 */       super();
/*     */     }
/*     */ 
/*     */     public Object invoke(MethodInvocation methodInvocation) throws Throwable {
/*  99 */       boolean applyDeliveryCalls = !hasBeforeDeliveryBeenCalled();
/* 100 */       if (applyDeliveryCalls) {
/*     */         try {
/* 102 */           beforeDelivery(null);
/*     */         }
/*     */         catch (ResourceException ex) {
/* 105 */           if (ReflectionUtils.declaresException(methodInvocation.getMethod(), ex.getClass())) {
/* 106 */             throw ex;
/*     */           }
/*     */ 
/* 109 */           throw new GenericMessageEndpointFactory.InternalResourceException(ex);
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 114 */         return methodInvocation.proceed();
/*     */       }
/*     */       catch (Throwable ex) {
/* 117 */         onEndpointException(ex);
/* 118 */         throw ex;
/*     */       }
/*     */       finally {
/* 121 */         if (applyDeliveryCalls)
/*     */           try {
/* 123 */             afterDelivery();
/*     */           }
/*     */           catch (ResourceException ex) {
/* 126 */             if (ReflectionUtils.declaresException(methodInvocation.getMethod(), ex.getClass())) {
/* 127 */               throw ex;
/*     */             }
/*     */ 
/* 130 */             throw new GenericMessageEndpointFactory.InternalResourceException(ex);
/*     */           }
/*     */       }
/*     */     }
/*     */ 
/*     */     protected ClassLoader getEndpointClassLoader()
/*     */     {
/* 139 */       return GenericMessageEndpointFactory.this.messageListener.getClass().getClassLoader();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.endpoint.GenericMessageEndpointFactory
 * JD-Core Version:    0.6.2
 */