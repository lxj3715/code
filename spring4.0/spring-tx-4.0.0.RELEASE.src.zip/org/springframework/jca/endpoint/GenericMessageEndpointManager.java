/*     */ package org.springframework.jca.endpoint;
/*     */ 
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ActivationSpec;
/*     */ import javax.resource.spi.ResourceAdapter;
/*     */ import javax.resource.spi.endpoint.MessageEndpointFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ 
/*     */ public class GenericMessageEndpointManager
/*     */   implements SmartLifecycle, InitializingBean, DisposableBean
/*     */ {
/*     */   private ResourceAdapter resourceAdapter;
/*     */   private MessageEndpointFactory messageEndpointFactory;
/*     */   private ActivationSpec activationSpec;
/* 155 */   private boolean autoStartup = true;
/*     */ 
/* 157 */   private int phase = 2147483647;
/*     */ 
/* 159 */   private boolean running = false;
/*     */ 
/* 161 */   private final Object lifecycleMonitor = new Object();
/*     */ 
/*     */   public void setResourceAdapter(ResourceAdapter resourceAdapter)
/*     */   {
/* 168 */     this.resourceAdapter = resourceAdapter;
/*     */   }
/*     */ 
/*     */   public ResourceAdapter getResourceAdapter()
/*     */   {
/* 175 */     return this.resourceAdapter;
/*     */   }
/*     */ 
/*     */   public void setMessageEndpointFactory(MessageEndpointFactory messageEndpointFactory)
/*     */   {
/* 187 */     this.messageEndpointFactory = messageEndpointFactory;
/*     */   }
/*     */ 
/*     */   public MessageEndpointFactory getMessageEndpointFactory()
/*     */   {
/* 194 */     return this.messageEndpointFactory;
/*     */   }
/*     */ 
/*     */   public void setActivationSpec(ActivationSpec activationSpec)
/*     */   {
/* 203 */     this.activationSpec = activationSpec;
/*     */   }
/*     */ 
/*     */   public ActivationSpec getActivationSpec()
/*     */   {
/* 210 */     return this.activationSpec;
/*     */   }
/*     */ 
/*     */   public void setAutoStartup(boolean autoStartup)
/*     */   {
/* 220 */     this.autoStartup = autoStartup;
/*     */   }
/*     */ 
/*     */   public boolean isAutoStartup()
/*     */   {
/* 229 */     return this.autoStartup;
/*     */   }
/*     */ 
/*     */   public void setPhase(int phase)
/*     */   {
/* 240 */     this.phase = phase;
/*     */   }
/*     */ 
/*     */   public int getPhase()
/*     */   {
/* 248 */     return this.phase;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws ResourceException
/*     */   {
/* 257 */     if (getResourceAdapter() == null) {
/* 258 */       throw new IllegalArgumentException("Property 'resourceAdapter' is required");
/*     */     }
/* 260 */     if (getMessageEndpointFactory() == null) {
/* 261 */       throw new IllegalArgumentException("Property 'messageEndpointFactory' is required");
/*     */     }
/* 263 */     ActivationSpec activationSpec = getActivationSpec();
/* 264 */     if (activationSpec == null) {
/* 265 */       throw new IllegalArgumentException("Property 'activationSpec' is required");
/*     */     }
/*     */ 
/* 268 */     if (activationSpec.getResourceAdapter() == null) {
/* 269 */       activationSpec.setResourceAdapter(getResourceAdapter());
/*     */     }
/* 271 */     else if (activationSpec.getResourceAdapter() != getResourceAdapter())
/*     */     {
/* 273 */       throw new IllegalArgumentException("ActivationSpec [" + activationSpec + "] is associated with a different ResourceAdapter: " + activationSpec
/* 273 */         .getResourceAdapter());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/* 282 */     synchronized (this.lifecycleMonitor) {
/* 283 */       if (!this.running) {
/*     */         try {
/* 285 */           getResourceAdapter().endpointActivation(getMessageEndpointFactory(), getActivationSpec());
/*     */         }
/*     */         catch (ResourceException ex) {
/* 288 */           throw new IllegalStateException("Could not activate message endpoint", ex);
/*     */         }
/* 290 */         this.running = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 300 */     synchronized (this.lifecycleMonitor) {
/* 301 */       if (this.running) {
/* 302 */         getResourceAdapter().endpointDeactivation(getMessageEndpointFactory(), getActivationSpec());
/* 303 */         this.running = false;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop(Runnable callback)
/*     */   {
/* 310 */     synchronized (this.lifecycleMonitor) {
/* 311 */       stop();
/* 312 */       callback.run();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/* 321 */     synchronized (this.lifecycleMonitor) {
/* 322 */       return this.running;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 331 */     stop();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.endpoint.GenericMessageEndpointManager
 * JD-Core Version:    0.6.2
 */