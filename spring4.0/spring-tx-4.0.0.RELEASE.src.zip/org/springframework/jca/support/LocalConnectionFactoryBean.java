/*     */ package org.springframework.jca.support;
/*     */ 
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionManager;
/*     */ import javax.resource.spi.ManagedConnectionFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class LocalConnectionFactoryBean
/*     */   implements FactoryBean<Object>, InitializingBean
/*     */ {
/*     */   private ManagedConnectionFactory managedConnectionFactory;
/*     */   private ConnectionManager connectionManager;
/*     */   private Object connectionFactory;
/*     */ 
/*     */   public void setManagedConnectionFactory(ManagedConnectionFactory managedConnectionFactory)
/*     */   {
/*  97 */     this.managedConnectionFactory = managedConnectionFactory;
/*     */   }
/*     */ 
/*     */   public void setConnectionManager(ConnectionManager connectionManager)
/*     */   {
/* 109 */     this.connectionManager = connectionManager;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws ResourceException
/*     */   {
/* 114 */     if (this.managedConnectionFactory == null) {
/* 115 */       throw new IllegalArgumentException("Property 'managedConnectionFactory' is required");
/*     */     }
/* 117 */     if (this.connectionManager != null) {
/* 118 */       this.connectionFactory = this.managedConnectionFactory.createConnectionFactory(this.connectionManager);
/*     */     }
/*     */     else
/* 121 */       this.connectionFactory = this.managedConnectionFactory.createConnectionFactory();
/*     */   }
/*     */ 
/*     */   public Object getObject()
/*     */   {
/* 128 */     return this.connectionFactory;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 133 */     return this.connectionFactory != null ? this.connectionFactory.getClass() : null;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 138 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.support.LocalConnectionFactoryBean
 * JD-Core Version:    0.6.2
 */