/*     */ package org.springframework.jca.support;
/*     */ 
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.BootstrapContext;
/*     */ import javax.resource.spi.ResourceAdapter;
/*     */ import javax.resource.spi.XATerminator;
/*     */ import javax.resource.spi.work.WorkManager;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ResourceAdapterFactoryBean
/*     */   implements FactoryBean<ResourceAdapter>, InitializingBean, DisposableBean
/*     */ {
/*     */   private ResourceAdapter resourceAdapter;
/*     */   private BootstrapContext bootstrapContext;
/*     */   private WorkManager workManager;
/*     */   private XATerminator xaTerminator;
/*     */ 
/*     */   public void setResourceAdapterClass(Class<?> resourceAdapterClass)
/*     */   {
/*  70 */     Assert.isAssignable(ResourceAdapter.class, resourceAdapterClass);
/*  71 */     this.resourceAdapter = ((ResourceAdapter)BeanUtils.instantiateClass(resourceAdapterClass));
/*     */   }
/*     */ 
/*     */   public void setResourceAdapter(ResourceAdapter resourceAdapter)
/*     */   {
/*  81 */     this.resourceAdapter = resourceAdapter;
/*     */   }
/*     */ 
/*     */   public void setBootstrapContext(BootstrapContext bootstrapContext)
/*     */   {
/*  92 */     this.bootstrapContext = bootstrapContext;
/*     */   }
/*     */ 
/*     */   public void setWorkManager(WorkManager workManager)
/*     */   {
/* 100 */     this.workManager = workManager;
/*     */   }
/*     */ 
/*     */   public void setXaTerminator(XATerminator xaTerminator)
/*     */   {
/* 108 */     this.xaTerminator = xaTerminator;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws ResourceException
/*     */   {
/* 118 */     if (this.resourceAdapter == null) {
/* 119 */       throw new IllegalArgumentException("'resourceAdapter' or 'resourceAdapterClass' is required");
/*     */     }
/* 121 */     if (this.bootstrapContext == null) {
/* 122 */       this.bootstrapContext = new SimpleBootstrapContext(this.workManager, this.xaTerminator);
/*     */     }
/* 124 */     this.resourceAdapter.start(this.bootstrapContext);
/*     */   }
/*     */ 
/*     */   public ResourceAdapter getObject()
/*     */   {
/* 130 */     return this.resourceAdapter;
/*     */   }
/*     */ 
/*     */   public Class<? extends ResourceAdapter> getObjectType()
/*     */   {
/* 135 */     return this.resourceAdapter != null ? this.resourceAdapter.getClass() : ResourceAdapter.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 140 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 150 */     this.resourceAdapter.stop();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.support.ResourceAdapterFactoryBean
 * JD-Core Version:    0.6.2
 */