/*    */ package org.springframework.jca.support;
/*    */ 
/*    */ import java.util.Timer;
/*    */ import javax.resource.spi.BootstrapContext;
/*    */ import javax.resource.spi.UnavailableException;
/*    */ import javax.resource.spi.XATerminator;
/*    */ import javax.resource.spi.work.WorkManager;
/*    */ 
/*    */ public class SimpleBootstrapContext
/*    */   implements BootstrapContext
/*    */ {
/*    */   private WorkManager workManager;
/*    */   private XATerminator xaTerminator;
/*    */ 
/*    */   public SimpleBootstrapContext(WorkManager workManager)
/*    */   {
/* 51 */     this.workManager = workManager;
/*    */   }
/*    */ 
/*    */   public SimpleBootstrapContext(WorkManager workManager, XATerminator xaTerminator)
/*    */   {
/* 60 */     this.workManager = workManager;
/* 61 */     this.xaTerminator = xaTerminator;
/*    */   }
/*    */ 
/*    */   public WorkManager getWorkManager()
/*    */   {
/* 67 */     if (this.workManager == null) {
/* 68 */       throw new IllegalStateException("No WorkManager available");
/*    */     }
/* 70 */     return this.workManager;
/*    */   }
/*    */ 
/*    */   public XATerminator getXATerminator()
/*    */   {
/* 75 */     return this.xaTerminator;
/*    */   }
/*    */ 
/*    */   public Timer createTimer() throws UnavailableException
/*    */   {
/* 80 */     return new Timer();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.support.SimpleBootstrapContext
 * JD-Core Version:    0.6.2
 */