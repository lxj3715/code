/*    */ package org.springframework.jca.work;
/*    */ 
/*    */ import javax.resource.spi.work.Work;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class DelegatingWork
/*    */   implements Work
/*    */ {
/*    */   private final Runnable delegate;
/*    */ 
/*    */   public DelegatingWork(Runnable delegate)
/*    */   {
/* 41 */     Assert.notNull(delegate, "Delegate must not be null");
/* 42 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   public final Runnable getDelegate()
/*    */   {
/* 49 */     return this.delegate;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 58 */     this.delegate.run();
/*    */   }
/*    */ 
/*    */   public void release()
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.work.DelegatingWork
 * JD-Core Version:    0.6.2
 */