/*     */ package org.springframework.jca.work;
/*     */ 
/*     */ import javax.resource.spi.work.ExecutionContext;
/*     */ import javax.resource.spi.work.Work;
/*     */ import javax.resource.spi.work.WorkAdapter;
/*     */ import javax.resource.spi.work.WorkCompletedException;
/*     */ import javax.resource.spi.work.WorkEvent;
/*     */ import javax.resource.spi.work.WorkException;
/*     */ import javax.resource.spi.work.WorkListener;
/*     */ import javax.resource.spi.work.WorkManager;
/*     */ import javax.resource.spi.work.WorkRejectedException;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.core.task.SyncTaskExecutor;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.core.task.TaskTimeoutException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SimpleTaskWorkManager
/*     */   implements WorkManager
/*     */ {
/*     */   private TaskExecutor syncTaskExecutor;
/*     */   private AsyncTaskExecutor asyncTaskExecutor;
/*     */ 
/*     */   public SimpleTaskWorkManager()
/*     */   {
/*  65 */     this.syncTaskExecutor = new SyncTaskExecutor();
/*     */ 
/*  67 */     this.asyncTaskExecutor = new SimpleAsyncTaskExecutor();
/*     */   }
/*     */ 
/*     */   public void setSyncTaskExecutor(TaskExecutor syncTaskExecutor)
/*     */   {
/*  76 */     this.syncTaskExecutor = syncTaskExecutor;
/*     */   }
/*     */ 
/*     */   public void setAsyncTaskExecutor(AsyncTaskExecutor asyncTaskExecutor)
/*     */   {
/*  87 */     this.asyncTaskExecutor = asyncTaskExecutor;
/*     */   }
/*     */ 
/*     */   public void doWork(Work work)
/*     */     throws WorkException
/*     */   {
/*  93 */     doWork(work, 9223372036854775807L, null, null);
/*     */   }
/*     */ 
/*     */   public void doWork(Work work, long startTimeout, ExecutionContext executionContext, WorkListener workListener)
/*     */     throws WorkException
/*     */   {
/* 100 */     Assert.state(this.syncTaskExecutor != null, "No 'syncTaskExecutor' set");
/* 101 */     executeWork(this.syncTaskExecutor, work, startTimeout, false, executionContext, workListener);
/*     */   }
/*     */ 
/*     */   public long startWork(Work work) throws WorkException
/*     */   {
/* 106 */     return startWork(work, 9223372036854775807L, null, null);
/*     */   }
/*     */ 
/*     */   public long startWork(Work work, long startTimeout, ExecutionContext executionContext, WorkListener workListener)
/*     */     throws WorkException
/*     */   {
/* 113 */     Assert.state(this.asyncTaskExecutor != null, "No 'asyncTaskExecutor' set");
/* 114 */     return executeWork(this.asyncTaskExecutor, work, startTimeout, true, executionContext, workListener);
/*     */   }
/*     */ 
/*     */   public void scheduleWork(Work work) throws WorkException
/*     */   {
/* 119 */     scheduleWork(work, 9223372036854775807L, null, null);
/*     */   }
/*     */ 
/*     */   public void scheduleWork(Work work, long startTimeout, ExecutionContext executionContext, WorkListener workListener)
/*     */     throws WorkException
/*     */   {
/* 126 */     Assert.state(this.asyncTaskExecutor != null, "No 'asyncTaskExecutor' set");
/* 127 */     executeWork(this.asyncTaskExecutor, work, startTimeout, false, executionContext, workListener);
/*     */   }
/*     */ 
/*     */   protected long executeWork(TaskExecutor taskExecutor, Work work, long startTimeout, boolean blockUntilStarted, ExecutionContext executionContext, WorkListener workListener)
/*     */     throws WorkException
/*     */   {
/* 147 */     if ((executionContext != null) && (executionContext.getXid() != null)) {
/* 148 */       throw new WorkException("SimpleTaskWorkManager does not supported imported XIDs: " + executionContext.getXid());
/*     */     }
/* 150 */     WorkListener workListenerToUse = workListener;
/* 151 */     if (workListenerToUse == null) {
/* 152 */       workListenerToUse = new WorkAdapter();
/*     */     }
/*     */ 
/* 155 */     boolean isAsync = taskExecutor instanceof AsyncTaskExecutor;
/* 156 */     DelegatingWorkAdapter workHandle = new DelegatingWorkAdapter(work, workListenerToUse, !isAsync);
/*     */     try {
/* 158 */       if (isAsync) {
/* 159 */         ((AsyncTaskExecutor)taskExecutor).execute(workHandle, startTimeout);
/*     */       }
/*     */       else
/* 162 */         taskExecutor.execute(workHandle);
/*     */     }
/*     */     catch (TaskTimeoutException ex)
/*     */     {
/* 166 */       WorkException wex = new WorkRejectedException("TaskExecutor rejected Work because of timeout: " + work, ex);
/* 167 */       wex.setErrorCode("1");
/* 168 */       workListenerToUse.workRejected(new WorkEvent(this, 2, work, wex));
/* 169 */       throw wex;
/*     */     }
/*     */     catch (TaskRejectedException ex) {
/* 172 */       WorkException wex = new WorkRejectedException("TaskExecutor rejected Work: " + work, ex);
/* 173 */       wex.setErrorCode("-1");
/* 174 */       workListenerToUse.workRejected(new WorkEvent(this, 2, work, wex));
/* 175 */       throw wex;
/*     */     }
/*     */     catch (Throwable ex) {
/* 178 */       WorkException wex = new WorkException("TaskExecutor failed to execute Work: " + work, ex);
/* 179 */       wex.setErrorCode("-1");
/* 180 */       throw wex;
/*     */     }
/* 182 */     if (isAsync) {
/* 183 */       workListenerToUse.workAccepted(new WorkEvent(this, 1, work, null));
/*     */     }
/*     */ 
/* 186 */     if (blockUntilStarted) {
/* 187 */       long acceptanceTime = System.currentTimeMillis();
/* 188 */       synchronized (workHandle.monitor) {
/*     */         try {
/* 190 */           while (!workHandle.started)
/* 191 */             workHandle.monitor.wait();
/*     */         }
/*     */         catch (InterruptedException ex)
/*     */         {
/* 195 */           Thread.currentThread().interrupt();
/*     */         }
/*     */       }
/* 198 */       return System.currentTimeMillis() - acceptanceTime;
/*     */     }
/*     */ 
/* 201 */     return -1L;
/*     */   }
/*     */ 
/*     */   private static class DelegatingWorkAdapter
/*     */     implements Work
/*     */   {
/*     */     private final Work work;
/*     */     private final WorkListener workListener;
/*     */     private final boolean acceptOnExecution;
/* 218 */     public final Object monitor = new Object();
/*     */ 
/* 220 */     public boolean started = false;
/*     */ 
/*     */     public DelegatingWorkAdapter(Work work, WorkListener workListener, boolean acceptOnExecution) {
/* 223 */       this.work = work;
/* 224 */       this.workListener = workListener;
/* 225 */       this.acceptOnExecution = acceptOnExecution;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 230 */       if (this.acceptOnExecution) {
/* 231 */         this.workListener.workAccepted(new WorkEvent(this, 1, this.work, null));
/*     */       }
/* 233 */       synchronized (this.monitor) {
/* 234 */         this.started = true;
/* 235 */         this.monitor.notify();
/*     */       }
/* 237 */       this.workListener.workStarted(new WorkEvent(this, 3, this.work, null));
/*     */       try {
/* 239 */         this.work.run();
/*     */       }
/*     */       catch (RuntimeException ex) {
/* 242 */         this.workListener.workCompleted(new WorkEvent(this, 4, this.work, new WorkCompletedException(ex)));
/*     */ 
/* 244 */         throw ex;
/*     */       }
/*     */       catch (Error err) {
/* 247 */         this.workListener.workCompleted(new WorkEvent(this, 4, this.work, new WorkCompletedException(err)));
/*     */ 
/* 249 */         throw err;
/*     */       }
/* 251 */       this.workListener.workCompleted(new WorkEvent(this, 4, this.work, null));
/*     */     }
/*     */ 
/*     */     public void release()
/*     */     {
/* 256 */       this.work.release();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.work.SimpleTaskWorkManager
 * JD-Core Version:    0.6.2
 */