/*     */ package org.springframework.jca.work;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import javax.naming.NamingException;
/*     */ import javax.resource.spi.BootstrapContext;
/*     */ import javax.resource.spi.work.ExecutionContext;
/*     */ import javax.resource.spi.work.Work;
/*     */ import javax.resource.spi.work.WorkException;
/*     */ import javax.resource.spi.work.WorkListener;
/*     */ import javax.resource.spi.work.WorkManager;
/*     */ import javax.resource.spi.work.WorkRejectedException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.core.task.TaskTimeoutException;
/*     */ import org.springframework.jca.context.BootstrapContextAware;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ import org.springframework.scheduling.SchedulingException;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class WorkManagerTaskExecutor extends JndiLocatorSupport
/*     */   implements SchedulingTaskExecutor, WorkManager, BootstrapContextAware, InitializingBean
/*     */ {
/*     */   private WorkManager workManager;
/*     */   private String workManagerName;
/*  78 */   private boolean blockUntilStarted = false;
/*     */ 
/*  80 */   private boolean blockUntilCompleted = false;
/*     */   private WorkListener workListener;
/*     */ 
/*     */   public WorkManagerTaskExecutor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public WorkManagerTaskExecutor(WorkManager workManager)
/*     */   {
/*  97 */     setWorkManager(workManager);
/*     */   }
/*     */ 
/*     */   public void setWorkManager(WorkManager workManager)
/*     */   {
/* 105 */     Assert.notNull(workManager, "WorkManager must not be null");
/* 106 */     this.workManager = workManager;
/*     */   }
/*     */ 
/*     */   public void setWorkManagerName(String workManagerName)
/*     */   {
/* 118 */     this.workManagerName = workManagerName;
/*     */   }
/*     */ 
/*     */   public void setBootstrapContext(BootstrapContext bootstrapContext)
/*     */   {
/* 127 */     Assert.notNull(bootstrapContext, "BootstrapContext must not be null");
/* 128 */     this.workManager = bootstrapContext.getWorkManager();
/*     */   }
/*     */ 
/*     */   public void setBlockUntilStarted(boolean blockUntilStarted)
/*     */   {
/* 140 */     this.blockUntilStarted = blockUntilStarted;
/*     */   }
/*     */ 
/*     */   public void setBlockUntilCompleted(boolean blockUntilCompleted)
/*     */   {
/* 152 */     this.blockUntilCompleted = blockUntilCompleted;
/*     */   }
/*     */ 
/*     */   public void setWorkListener(WorkListener workListener)
/*     */   {
/* 161 */     this.workListener = workListener;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws NamingException
/*     */   {
/* 166 */     if (this.workManager == null)
/* 167 */       if (this.workManagerName != null) {
/* 168 */         this.workManager = ((WorkManager)lookup(this.workManagerName, WorkManager.class));
/*     */       }
/*     */       else
/* 171 */         this.workManager = getDefaultWorkManager();
/*     */   }
/*     */ 
/*     */   protected WorkManager getDefaultWorkManager()
/*     */   {
/* 183 */     return new SimpleTaskWorkManager();
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 193 */     execute(task, 9223372036854775807L);
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout)
/*     */   {
/* 198 */     Assert.state(this.workManager != null, "No WorkManager specified");
/* 199 */     Work work = new DelegatingWork(task);
/*     */     try {
/* 201 */       if (this.blockUntilCompleted) {
/* 202 */         if ((startTimeout != 9223372036854775807L) || (this.workListener != null)) {
/* 203 */           this.workManager.doWork(work, startTimeout, null, this.workListener);
/*     */         }
/*     */         else {
/* 206 */           this.workManager.doWork(work);
/*     */         }
/*     */       }
/* 209 */       else if (this.blockUntilStarted) {
/* 210 */         if ((startTimeout != 9223372036854775807L) || (this.workListener != null)) {
/* 211 */           this.workManager.startWork(work, startTimeout, null, this.workListener);
/*     */         }
/*     */         else {
/* 214 */           this.workManager.startWork(work);
/*     */         }
/*     */ 
/*     */       }
/* 218 */       else if ((startTimeout != 9223372036854775807L) || (this.workListener != null)) {
/* 219 */         this.workManager.scheduleWork(work, startTimeout, null, this.workListener);
/*     */       }
/*     */       else {
/* 222 */         this.workManager.scheduleWork(work);
/*     */       }
/*     */     }
/*     */     catch (WorkRejectedException ex)
/*     */     {
/* 227 */       if ("1".equals(ex.getErrorCode())) {
/* 228 */         throw new TaskTimeoutException("JCA WorkManager rejected task because of timeout: " + task, ex);
/*     */       }
/*     */ 
/* 231 */       throw new TaskRejectedException("JCA WorkManager rejected task: " + task, ex);
/*     */     }
/*     */     catch (WorkException ex)
/*     */     {
/* 235 */       throw new SchedulingException("Could not schedule task on JCA WorkManager", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task)
/*     */   {
/* 241 */     FutureTask future = new FutureTask(task, null);
/* 242 */     execute(future, 9223372036854775807L);
/* 243 */     return future;
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task)
/*     */   {
/* 248 */     FutureTask future = new FutureTask(task);
/* 249 */     execute(future, 9223372036854775807L);
/* 250 */     return future;
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 258 */     return true;
/*     */   }
/*     */ 
/*     */   public void doWork(Work work)
/*     */     throws WorkException
/*     */   {
/* 268 */     this.workManager.doWork(work);
/*     */   }
/*     */ 
/*     */   public void doWork(Work work, long delay, ExecutionContext executionContext, WorkListener workListener)
/*     */     throws WorkException
/*     */   {
/* 275 */     this.workManager.doWork(work, delay, executionContext, workListener);
/*     */   }
/*     */ 
/*     */   public long startWork(Work work) throws WorkException
/*     */   {
/* 280 */     return this.workManager.startWork(work);
/*     */   }
/*     */ 
/*     */   public long startWork(Work work, long delay, ExecutionContext executionContext, WorkListener workListener)
/*     */     throws WorkException
/*     */   {
/* 287 */     return this.workManager.startWork(work, delay, executionContext, workListener);
/*     */   }
/*     */ 
/*     */   public void scheduleWork(Work work) throws WorkException
/*     */   {
/* 292 */     this.workManager.scheduleWork(work);
/*     */   }
/*     */ 
/*     */   public void scheduleWork(Work work, long delay, ExecutionContext executionContext, WorkListener workListener)
/*     */     throws WorkException
/*     */   {
/* 299 */     this.workManager.scheduleWork(work, delay, executionContext, workListener);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.work.WorkManagerTaskExecutor
 * JD-Core Version:    0.6.2
 */