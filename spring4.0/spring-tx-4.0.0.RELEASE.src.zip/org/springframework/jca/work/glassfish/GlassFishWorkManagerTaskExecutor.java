/*    */ package org.springframework.jca.work.glassfish;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import javax.resource.spi.work.WorkManager;
/*    */ import org.springframework.jca.work.WorkManagerTaskExecutor;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ public class GlassFishWorkManagerTaskExecutor extends WorkManagerTaskExecutor
/*    */ {
/*    */   private static final String WORK_MANAGER_FACTORY_CLASS = "com.sun.enterprise.connectors.work.WorkManagerFactory";
/*    */   private final Method getWorkManagerMethod;
/*    */ 
/*    */   public GlassFishWorkManagerTaskExecutor()
/*    */   {
/*    */     try
/*    */     {
/* 50 */       Class wmf = getClass().getClassLoader().loadClass("com.sun.enterprise.connectors.work.WorkManagerFactory");
/* 51 */       this.getWorkManagerMethod = wmf.getMethod("getWorkManager", new Class[] { String.class });
/*    */     }
/*    */     catch (Exception ex) {
/* 54 */       throw new IllegalStateException("Could not initialize GlassFishWorkManagerTaskExecutor because GlassFish API is not available", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setThreadPoolName(String threadPoolName)
/*    */   {
/* 65 */     WorkManager wm = (WorkManager)ReflectionUtils.invokeMethod(this.getWorkManagerMethod, null, new Object[] { threadPoolName });
/* 66 */     if (wm == null) {
/* 67 */       throw new IllegalArgumentException("Specified thread pool name '" + threadPoolName + "' does not correspond to an actual pool definition in GlassFish. Check your configuration!");
/*    */     }
/*    */ 
/* 70 */     setWorkManager(wm);
/*    */   }
/*    */ 
/*    */   protected WorkManager getDefaultWorkManager()
/*    */   {
/* 78 */     return (WorkManager)ReflectionUtils.invokeMethod(this.getWorkManagerMethod, null, new Object[] { null });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.work.glassfish.GlassFishWorkManagerTaskExecutor
 * JD-Core Version:    0.6.2
 */