/*    */ package org.springframework.jca.work.jboss;
/*    */ 
/*    */ import javax.resource.spi.work.WorkManager;
/*    */ import org.springframework.jca.work.WorkManagerTaskExecutor;
/*    */ 
/*    */ @Deprecated
/*    */ public class JBossWorkManagerTaskExecutor extends WorkManagerTaskExecutor
/*    */ {
/*    */   public void setWorkManagerMBeanName(String mbeanName)
/*    */   {
/* 54 */     setWorkManager(JBossWorkManagerUtils.getWorkManager(mbeanName));
/*    */   }
/*    */ 
/*    */   protected WorkManager getDefaultWorkManager()
/*    */   {
/* 64 */     return JBossWorkManagerUtils.getWorkManager();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.work.jboss.JBossWorkManagerTaskExecutor
 * JD-Core Version:    0.6.2
 */