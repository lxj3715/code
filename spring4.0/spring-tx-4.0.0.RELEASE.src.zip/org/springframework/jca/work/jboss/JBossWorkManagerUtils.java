/*    */ package org.springframework.jca.work.jboss;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.management.MBeanServerInvocationHandler;
/*    */ import javax.management.ObjectName;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.resource.spi.work.WorkManager;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class JBossWorkManagerUtils
/*    */ {
/*    */   private static final String JBOSS_WORK_MANAGER_MBEAN_CLASS_NAME = "org.jboss.resource.work.JBossWorkManagerMBean";
/*    */   private static final String MBEAN_SERVER_CONNECTION_JNDI_NAME = "jmx/invoker/RMIAdaptor";
/*    */   private static final String DEFAULT_WORK_MANAGER_MBEAN_NAME = "jboss.jca:service=WorkManager";
/*    */ 
/*    */   public static WorkManager getWorkManager()
/*    */   {
/* 53 */     return getWorkManager("jboss.jca:service=WorkManager");
/*    */   }
/*    */ 
/*    */   public static WorkManager getWorkManager(String mbeanName)
/*    */   {
/* 63 */     Assert.hasLength(mbeanName, "JBossWorkManagerMBean name must not be empty");
/*    */     try {
/* 65 */       Class mbeanClass = JBossWorkManagerUtils.class.getClassLoader().loadClass("org.jboss.resource.work.JBossWorkManagerMBean");
/* 66 */       InitialContext jndiContext = new InitialContext();
/* 67 */       MBeanServerConnection mconn = (MBeanServerConnection)jndiContext.lookup("jmx/invoker/RMIAdaptor");
/* 68 */       ObjectName objectName = ObjectName.getInstance(mbeanName);
/* 69 */       Object workManagerMBean = MBeanServerInvocationHandler.newProxyInstance(mconn, objectName, mbeanClass, false);
/* 70 */       Method getInstanceMethod = workManagerMBean.getClass().getMethod("getInstance", new Class[0]);
/* 71 */       return (WorkManager)getInstanceMethod.invoke(workManagerMBean, new Object[0]);
/*    */     }
/*    */     catch (Exception ex) {
/* 74 */       throw new IllegalStateException("Could not initialize JBossWorkManagerTaskExecutor because JBoss API is not available", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.jca.work.jboss.JBossWorkManagerUtils
 * JD-Core Version:    0.6.2
 */