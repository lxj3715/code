/*    */ package org.springframework.transaction;
/*    */ 
/*    */ public class HeuristicCompletionException extends TransactionException
/*    */ {
/*    */   public static final int STATE_UNKNOWN = 0;
/*    */   public static final int STATE_COMMITTED = 1;
/*    */   public static final int STATE_ROLLED_BACK = 2;
/*    */   public static final int STATE_MIXED = 3;
/* 56 */   private int outcomeState = 0;
/*    */ 
/*    */   public static String getStateString(int state)
/*    */   {
/* 40 */     switch (state) {
/*    */     case 1:
/* 42 */       return "committed";
/*    */     case 2:
/* 44 */       return "rolled back";
/*    */     case 3:
/* 46 */       return "mixed";
/*    */     }
/* 48 */     return "unknown";
/*    */   }
/*    */ 
/*    */   public HeuristicCompletionException(int outcomeState, Throwable cause)
/*    */   {
/* 65 */     super("Heuristic completion: outcome state is " + getStateString(outcomeState), cause);
/* 66 */     this.outcomeState = outcomeState;
/*    */   }
/*    */ 
/*    */   public int getOutcomeState()
/*    */   {
/* 78 */     return this.outcomeState;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.HeuristicCompletionException
 * JD-Core Version:    0.6.2
 */