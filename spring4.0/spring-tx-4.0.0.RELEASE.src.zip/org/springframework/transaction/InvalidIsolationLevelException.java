/*    */ package org.springframework.transaction;
/*    */ 
/*    */ public class InvalidIsolationLevelException extends TransactionUsageException
/*    */ {
/*    */   public InvalidIsolationLevelException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.InvalidIsolationLevelException
 * JD-Core Version:    0.6.2
 */