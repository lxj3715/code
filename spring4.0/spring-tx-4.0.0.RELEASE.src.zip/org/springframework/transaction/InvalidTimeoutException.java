/*    */ package org.springframework.transaction;
/*    */ 
/*    */ public class InvalidTimeoutException extends TransactionUsageException
/*    */ {
/*    */   private int timeout;
/*    */ 
/*    */   public InvalidTimeoutException(String msg, int timeout)
/*    */   {
/* 39 */     super(msg);
/* 40 */     this.timeout = timeout;
/*    */   }
/*    */ 
/*    */   public int getTimeout()
/*    */   {
/* 47 */     return this.timeout;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.InvalidTimeoutException
 * JD-Core Version:    0.6.2
 */