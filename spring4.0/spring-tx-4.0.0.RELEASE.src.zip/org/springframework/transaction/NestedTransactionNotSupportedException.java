/*    */ package org.springframework.transaction;
/*    */ 
/*    */ public class NestedTransactionNotSupportedException extends CannotCreateTransactionException
/*    */ {
/*    */   public NestedTransactionNotSupportedException(String msg)
/*    */   {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */   public NestedTransactionNotSupportedException(String msg, Throwable cause)
/*    */   {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.NestedTransactionNotSupportedException
 * JD-Core Version:    0.6.2
 */