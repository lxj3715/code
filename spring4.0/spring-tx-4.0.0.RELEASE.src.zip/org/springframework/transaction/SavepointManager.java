package org.springframework.transaction;

public abstract interface SavepointManager
{
  public abstract Object createSavepoint()
    throws TransactionException;

  public abstract void rollbackToSavepoint(Object paramObject)
    throws TransactionException;

  public abstract void releaseSavepoint(Object paramObject)
    throws TransactionException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.SavepointManager
 * JD-Core Version:    0.6.2
 */