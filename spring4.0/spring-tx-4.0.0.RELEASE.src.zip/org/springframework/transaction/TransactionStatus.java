package org.springframework.transaction;

import java.io.Flushable;

public abstract interface TransactionStatus extends SavepointManager, Flushable
{
  public abstract boolean isNewTransaction();

  public abstract boolean hasSavepoint();

  public abstract void setRollbackOnly();

  public abstract boolean isRollbackOnly();

  public abstract void flush();

  public abstract boolean isCompleted();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.TransactionStatus
 * JD-Core Version:    0.6.2
 */