/*    */ package org.springframework.transaction;
/*    */ 
/*    */ public class TransactionSuspensionNotSupportedException extends CannotCreateTransactionException
/*    */ {
/*    */   public TransactionSuspensionNotSupportedException(String msg)
/*    */   {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */   public TransactionSuspensionNotSupportedException(String msg, Throwable cause)
/*    */   {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.TransactionSuspensionNotSupportedException
 * JD-Core Version:    0.6.2
 */