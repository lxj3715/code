/*    */ package org.springframework.transaction;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class TransactionSystemException extends TransactionException
/*    */ {
/*    */   private Throwable applicationException;
/*    */ 
/*    */   public TransactionSystemException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ 
/*    */   public TransactionSystemException(String msg, Throwable cause)
/*    */   {
/* 48 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public void initApplicationException(Throwable ex)
/*    */   {
/* 60 */     Assert.notNull(ex, "Application exception must not be null");
/* 61 */     if (this.applicationException != null) {
/* 62 */       throw new IllegalStateException("Already holding an application exception: " + this.applicationException);
/*    */     }
/* 64 */     this.applicationException = ex;
/*    */   }
/*    */ 
/*    */   public final Throwable getApplicationException()
/*    */   {
/* 73 */     return this.applicationException;
/*    */   }
/*    */ 
/*    */   public Throwable getOriginalException()
/*    */   {
/* 82 */     return this.applicationException != null ? this.applicationException : getCause();
/*    */   }
/*    */ 
/*    */   public boolean contains(Class<?> exType)
/*    */   {
/* 87 */     return (super.contains(exType)) || ((exType != null) && (exType.isInstance(this.applicationException)));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.TransactionSystemException
 * JD-Core Version:    0.6.2
 */