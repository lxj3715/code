/*    */ package org.springframework.transaction;
/*    */ 
/*    */ public class TransactionTimedOutException extends TransactionException
/*    */ {
/*    */   public TransactionTimedOutException(String msg)
/*    */   {
/* 53 */     super(msg);
/*    */   }
/*    */ 
/*    */   public TransactionTimedOutException(String msg, Throwable cause)
/*    */   {
/* 62 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.TransactionTimedOutException
 * JD-Core Version:    0.6.2
 */