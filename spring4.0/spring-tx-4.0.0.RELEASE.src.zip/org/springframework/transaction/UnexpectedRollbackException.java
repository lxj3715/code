/*    */ package org.springframework.transaction;
/*    */ 
/*    */ public class UnexpectedRollbackException extends TransactionException
/*    */ {
/*    */   public UnexpectedRollbackException(String msg)
/*    */   {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */   public UnexpectedRollbackException(String msg, Throwable cause)
/*    */   {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.UnexpectedRollbackException
 * JD-Core Version:    0.6.2
 */