/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ImportAware;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ @Configuration
/*    */ public abstract class AbstractTransactionManagementConfiguration
/*    */   implements ImportAware
/*    */ {
/*    */   protected AnnotationAttributes enableTx;
/*    */   protected PlatformTransactionManager txManager;
/*    */ 
/*    */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*    */   {
/* 48 */     this.enableTx = AnnotationAttributes.fromMap(importMetadata
/* 49 */       .getAnnotationAttributes(EnableTransactionManagement.class
/* 49 */       .getName(), false));
/* 50 */     Assert.notNull(this.enableTx, "@EnableTransactionManagement is not present on importing class " + importMetadata
/* 51 */       .getClassName());
/*    */   }
/*    */ 
/*    */   @Autowired(required=false)
/*    */   void setConfigurers(Collection<TransactionManagementConfigurer> configurers) {
/* 56 */     if (CollectionUtils.isEmpty(configurers)) {
/* 57 */       return;
/*    */     }
/* 59 */     if (configurers.size() > 1) {
/* 60 */       throw new IllegalStateException("Only one TransactionManagementConfigurer may exist");
/*    */     }
/* 62 */     TransactionManagementConfigurer configurer = (TransactionManagementConfigurer)configurers.iterator().next();
/* 63 */     this.txManager = configurer.annotationDrivenTransactionManager();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.AbstractTransactionManagementConfiguration
 * JD-Core Version:    0.6.2
 */