/*     */ package org.springframework.transaction.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.transaction.interceptor.AbstractFallbackTransactionAttributeSource;
/*     */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class AnnotationTransactionAttributeSource extends AbstractFallbackTransactionAttributeSource
/*     */   implements Serializable
/*     */ {
/*  57 */   private static final boolean jta12Present = ClassUtils.isPresent("javax.transaction.Transactional", AnnotationTransactionAttributeSource.class
/*  58 */     .getClassLoader());
/*     */ 
/*  60 */   private static final boolean ejb3Present = ClassUtils.isPresent("javax.ejb.TransactionAttribute", AnnotationTransactionAttributeSource.class
/*  61 */     .getClassLoader());
/*     */   private final boolean publicMethodsOnly;
/*     */   private final Set<TransactionAnnotationParser> annotationParsers;
/*     */ 
/*     */   public AnnotationTransactionAttributeSource()
/*     */   {
/*  74 */     this(true);
/*     */   }
/*     */ 
/*     */   public AnnotationTransactionAttributeSource(boolean publicMethodsOnly)
/*     */   {
/*  87 */     this.publicMethodsOnly = publicMethodsOnly;
/*  88 */     this.annotationParsers = new LinkedHashSet(2);
/*  89 */     this.annotationParsers.add(new SpringTransactionAnnotationParser());
/*  90 */     if (jta12Present) {
/*  91 */       this.annotationParsers.add(new JtaTransactionAnnotationParser());
/*     */     }
/*  93 */     if (ejb3Present)
/*  94 */       this.annotationParsers.add(new Ejb3TransactionAnnotationParser());
/*     */   }
/*     */ 
/*     */   public AnnotationTransactionAttributeSource(TransactionAnnotationParser annotationParser)
/*     */   {
/* 103 */     this.publicMethodsOnly = true;
/* 104 */     Assert.notNull(annotationParser, "TransactionAnnotationParser must not be null");
/* 105 */     this.annotationParsers = Collections.singleton(annotationParser);
/*     */   }
/*     */ 
/*     */   public AnnotationTransactionAttributeSource(TransactionAnnotationParser[] annotationParsers)
/*     */   {
/* 113 */     this.publicMethodsOnly = true;
/* 114 */     Assert.notEmpty(annotationParsers, "At least one TransactionAnnotationParser needs to be specified");
/* 115 */     Set parsers = new LinkedHashSet(annotationParsers.length);
/* 116 */     Collections.addAll(parsers, annotationParsers);
/* 117 */     this.annotationParsers = parsers;
/*     */   }
/*     */ 
/*     */   public AnnotationTransactionAttributeSource(Set<TransactionAnnotationParser> annotationParsers)
/*     */   {
/* 125 */     this.publicMethodsOnly = true;
/* 126 */     Assert.notEmpty(annotationParsers, "At least one TransactionAnnotationParser needs to be specified");
/* 127 */     this.annotationParsers = annotationParsers;
/*     */   }
/*     */ 
/*     */   protected TransactionAttribute findTransactionAttribute(Method method)
/*     */   {
/* 133 */     return determineTransactionAttribute(method);
/*     */   }
/*     */ 
/*     */   protected TransactionAttribute findTransactionAttribute(Class<?> clazz)
/*     */   {
/* 138 */     return determineTransactionAttribute(clazz);
/*     */   }
/*     */ 
/*     */   protected TransactionAttribute determineTransactionAttribute(AnnotatedElement ae)
/*     */   {
/* 153 */     for (TransactionAnnotationParser annotationParser : this.annotationParsers) {
/* 154 */       TransactionAttribute attr = annotationParser.parseTransactionAnnotation(ae);
/* 155 */       if (attr != null) {
/* 156 */         return attr;
/*     */       }
/*     */     }
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean allowPublicMethodsOnly()
/*     */   {
/* 167 */     return this.publicMethodsOnly;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 173 */     if (this == other) {
/* 174 */       return true;
/*     */     }
/* 176 */     if (!(other instanceof AnnotationTransactionAttributeSource)) {
/* 177 */       return false;
/*     */     }
/* 179 */     AnnotationTransactionAttributeSource otherTas = (AnnotationTransactionAttributeSource)other;
/* 180 */     return (this.annotationParsers.equals(otherTas.annotationParsers)) && (this.publicMethodsOnly == otherTas.publicMethodsOnly);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 186 */     return this.annotationParsers.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.AnnotationTransactionAttributeSource
 * JD-Core Version:    0.6.2
 */