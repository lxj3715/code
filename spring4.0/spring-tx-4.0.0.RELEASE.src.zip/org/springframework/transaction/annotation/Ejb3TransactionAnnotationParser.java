/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import javax.ejb.ApplicationException;
/*    */ import javax.ejb.TransactionAttributeType;
/*    */ import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
/*    */ 
/*    */ public class Ejb3TransactionAnnotationParser
/*    */   implements TransactionAnnotationParser, Serializable
/*    */ {
/*    */   public org.springframework.transaction.interceptor.TransactionAttribute parseTransactionAnnotation(AnnotatedElement ae)
/*    */   {
/* 39 */     javax.ejb.TransactionAttribute ann = (javax.ejb.TransactionAttribute)ae.getAnnotation(javax.ejb.TransactionAttribute.class);
/* 40 */     if (ann != null) {
/* 41 */       return parseTransactionAnnotation(ann);
/*    */     }
/*    */ 
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */   public org.springframework.transaction.interceptor.TransactionAttribute parseTransactionAnnotation(javax.ejb.TransactionAttribute ann)
/*    */   {
/* 49 */     return new Ejb3TransactionAttribute(ann.value());
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 54 */     return (this == other) || ((other instanceof Ejb3TransactionAnnotationParser));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 59 */     return Ejb3TransactionAnnotationParser.class.hashCode();
/*    */   }
/*    */ 
/*    */   private static class Ejb3TransactionAttribute extends DefaultTransactionAttribute
/*    */   {
/*    */     public Ejb3TransactionAttribute(TransactionAttributeType type)
/*    */     {
/* 70 */       setPropagationBehaviorName("PROPAGATION_" + type.name());
/*    */     }
/*    */ 
/*    */     public boolean rollbackOn(Throwable ex)
/*    */     {
/* 75 */       ApplicationException ann = (ApplicationException)ex.getClass().getAnnotation(ApplicationException.class);
/* 76 */       return ann != null ? ann.rollback() : super.rollbackOn(ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.Ejb3TransactionAnnotationParser
 * JD-Core Version:    0.6.2
 */