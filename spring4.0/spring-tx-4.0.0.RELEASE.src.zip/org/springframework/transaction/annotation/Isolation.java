/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ public enum Isolation
/*    */ {
/* 37 */   DEFAULT(-1), 
/*    */ 
/* 47 */   READ_UNCOMMITTED(1), 
/*    */ 
/* 55 */   READ_COMMITTED(2), 
/*    */ 
/* 66 */   REPEATABLE_READ(4), 
/*    */ 
/* 78 */   SERIALIZABLE(8);
/*    */ 
/*    */   private final int value;
/*    */ 
/*    */   private Isolation(int value)
/*    */   {
/* 84 */     this.value = value;
/*    */   }
/* 86 */   public int value() { return this.value; }
/*    */ 
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.Isolation
 * JD-Core Version:    0.6.2
 */