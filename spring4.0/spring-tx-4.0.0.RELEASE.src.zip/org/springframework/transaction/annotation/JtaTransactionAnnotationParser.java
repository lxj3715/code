/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.transaction.Transactional;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.transaction.interceptor.NoRollbackRuleAttribute;
/*    */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/*    */ import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
/*    */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*    */ 
/*    */ public class JtaTransactionAnnotationParser
/*    */   implements TransactionAnnotationParser, Serializable
/*    */ {
/*    */   public TransactionAttribute parseTransactionAnnotation(AnnotatedElement ae)
/*    */   {
/* 42 */     AnnotationAttributes ann = AnnotatedElementUtils.getAnnotationAttributes(ae, Transactional.class.getName());
/* 43 */     if (ann != null) {
/* 44 */       return parseTransactionAnnotation(ann);
/*    */     }
/*    */ 
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   public TransactionAttribute parseTransactionAnnotation(Transactional ann)
/*    */   {
/* 52 */     return parseTransactionAnnotation(AnnotationUtils.getAnnotationAttributes(ann, false, false));
/*    */   }
/*    */ 
/*    */   protected TransactionAttribute parseTransactionAnnotation(AnnotationAttributes attributes) {
/* 56 */     RuleBasedTransactionAttribute rbta = new RuleBasedTransactionAttribute();
/* 57 */     rbta.setPropagationBehaviorName("PROPAGATION_" + attributes
/* 58 */       .getEnum("value")
/* 58 */       .toString());
/* 59 */     ArrayList rollBackRules = new ArrayList();
/* 60 */     Class[] rbf = attributes.getClassArray("rollbackOn");
/* 61 */     Class[] arrayOfClass1 = rbf; int i = arrayOfClass1.length; for (Class localClass1 = 0; localClass1 < i; localClass1++) { rbRule = arrayOfClass1[localClass1];
/* 62 */       RollbackRuleAttribute rule = new RollbackRuleAttribute(rbRule);
/* 63 */       rollBackRules.add(rule);
/*    */     }
/* 65 */     Class[] nrbf = attributes.getClassArray("dontRollbackOn");
/* 66 */     Class[] arrayOfClass2 = nrbf; localClass1 = arrayOfClass2.length; for (Class rbRule = 0; rbRule < localClass1; rbRule++) { Class rbRule = arrayOfClass2[rbRule];
/* 67 */       NoRollbackRuleAttribute rule = new NoRollbackRuleAttribute(rbRule);
/* 68 */       rollBackRules.add(rule);
/*    */     }
/* 70 */     rbta.getRollbackRules().addAll(rollBackRules);
/* 71 */     return rbta;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 76 */     return (this == other) || ((other instanceof JtaTransactionAnnotationParser));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 81 */     return JtaTransactionAnnotationParser.class.hashCode();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.JtaTransactionAnnotationParser
 * JD-Core Version:    0.6.2
 */