/*     */ package org.springframework.transaction.annotation;
/*     */ 
/*     */ public enum Propagation
/*     */ {
/*  37 */   REQUIRED(0), 
/*     */ 
/*  50 */   SUPPORTS(1), 
/*     */ 
/*  56 */   MANDATORY(2), 
/*     */ 
/*  67 */   REQUIRES_NEW(3), 
/*     */ 
/*  78 */   NOT_SUPPORTED(4), 
/*     */ 
/*  84 */   NEVER(5), 
/*     */ 
/*  95 */   NESTED(6);
/*     */ 
/*     */   private final int value;
/*     */ 
/*     */   private Propagation(int value)
/*     */   {
/* 101 */     this.value = value;
/*     */   }
/* 103 */   public int value() { return this.value; }
/*     */ 
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.Propagation
 * JD-Core Version:    0.6.2
 */