/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.transaction.interceptor.BeanFactoryTransactionAttributeSourceAdvisor;
/*    */ import org.springframework.transaction.interceptor.TransactionAttributeSource;
/*    */ import org.springframework.transaction.interceptor.TransactionInterceptor;
/*    */ 
/*    */ @Configuration
/*    */ public class ProxyTransactionManagementConfiguration extends AbstractTransactionManagementConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.transaction.config.internalTransactionAdvisor"})
/*    */   @Role(2)
/*    */   public BeanFactoryTransactionAttributeSourceAdvisor transactionAdvisor()
/*    */   {
/* 43 */     BeanFactoryTransactionAttributeSourceAdvisor advisor = new BeanFactoryTransactionAttributeSourceAdvisor();
/* 44 */     advisor.setTransactionAttributeSource(transactionAttributeSource());
/* 45 */     advisor.setAdvice(transactionInterceptor());
/* 46 */     advisor.setOrder(((Integer)this.enableTx.getNumber("order")).intValue());
/* 47 */     return advisor;
/*    */   }
/*    */   @Bean
/*    */   @Role(2)
/*    */   public TransactionAttributeSource transactionAttributeSource() {
/* 53 */     return new AnnotationTransactionAttributeSource();
/*    */   }
/*    */   @Bean
/*    */   @Role(2)
/*    */   public TransactionInterceptor transactionInterceptor() {
/* 59 */     TransactionInterceptor interceptor = new TransactionInterceptor();
/* 60 */     interceptor.setTransactionAttributeSource(transactionAttributeSource());
/* 61 */     if (this.txManager != null) {
/* 62 */       interceptor.setTransactionManager(this.txManager);
/*    */     }
/* 64 */     return interceptor;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.ProxyTransactionManagementConfiguration
 * JD-Core Version:    0.6.2
 */