/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.transaction.interceptor.NoRollbackRuleAttribute;
/*    */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/*    */ import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
/*    */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*    */ 
/*    */ public class SpringTransactionAnnotationParser
/*    */   implements TransactionAnnotationParser, Serializable
/*    */ {
/*    */   public TransactionAttribute parseTransactionAnnotation(AnnotatedElement ae)
/*    */   {
/* 42 */     AnnotationAttributes ann = AnnotatedElementUtils.getAnnotationAttributes(ae, Transactional.class.getName());
/* 43 */     if (ann != null) {
/* 44 */       return parseTransactionAnnotation(ann);
/*    */     }
/*    */ 
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   public TransactionAttribute parseTransactionAnnotation(Transactional ann)
/*    */   {
/* 52 */     return parseTransactionAnnotation(AnnotationUtils.getAnnotationAttributes(ann, false, false));
/*    */   }
/*    */ 
/*    */   protected TransactionAttribute parseTransactionAnnotation(AnnotationAttributes attributes) {
/* 56 */     RuleBasedTransactionAttribute rbta = new RuleBasedTransactionAttribute();
/* 57 */     Propagation propagation = (Propagation)attributes.getEnum("propagation");
/* 58 */     rbta.setPropagationBehavior(propagation.value());
/* 59 */     Isolation isolation = (Isolation)attributes.getEnum("isolation");
/* 60 */     rbta.setIsolationLevel(isolation.value());
/* 61 */     rbta.setTimeout(attributes.getNumber("timeout").intValue());
/* 62 */     rbta.setReadOnly(attributes.getBoolean("readOnly"));
/* 63 */     rbta.setQualifier(attributes.getString("value"));
/* 64 */     ArrayList rollBackRules = new ArrayList();
/* 65 */     Class[] rbf = attributes.getClassArray("rollbackFor");
/* 66 */     Class[] arrayOfClass1 = rbf; int i = arrayOfClass1.length; for (Object localObject = 0; localObject < i; localObject++) { rbRule = arrayOfClass1[localObject];
/* 67 */       RollbackRuleAttribute rule = new RollbackRuleAttribute(rbRule);
/* 68 */       rollBackRules.add(rule);
/*    */     }
/* 70 */     String[] rbfc = attributes.getStringArray("rollbackForClassName");
/* 71 */     String[] arrayOfString1 = rbfc; localObject = arrayOfString1.length; for (Class rbRule = 0; rbRule < localObject; rbRule++) { rbRule = arrayOfString1[rbRule];
/* 72 */       RollbackRuleAttribute rule = new RollbackRuleAttribute(rbRule);
/* 73 */       rollBackRules.add(rule);
/*    */     }
/* 75 */     Class[] nrbf = attributes.getClassArray("noRollbackFor");
/* 76 */     localObject = nrbf; rbRule = localObject.length; for (String rbRule = 0; rbRule < rbRule; rbRule++) { rbRule = localObject[rbRule];
/* 77 */       NoRollbackRuleAttribute rule = new NoRollbackRuleAttribute(rbRule);
/* 78 */       rollBackRules.add(rule);
/*    */     }
/* 80 */     String[] nrbfc = attributes.getStringArray("noRollbackForClassName");
/* 81 */     rbRule = nrbfc; rbRule = rbRule.length; for (Class rbRule = 0; rbRule < rbRule; rbRule++) { String rbRule = rbRule[rbRule];
/* 82 */       NoRollbackRuleAttribute rule = new NoRollbackRuleAttribute(rbRule);
/* 83 */       rollBackRules.add(rule);
/*    */     }
/* 85 */     rbta.getRollbackRules().addAll(rollBackRules);
/* 86 */     return rbta;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 91 */     return (this == other) || ((other instanceof SpringTransactionAnnotationParser));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 96 */     return SpringTransactionAnnotationParser.class.hashCode();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.SpringTransactionAnnotationParser
 * JD-Core Version:    0.6.2
 */