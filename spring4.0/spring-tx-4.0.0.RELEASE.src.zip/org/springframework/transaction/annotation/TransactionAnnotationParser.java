package org.springframework.transaction.annotation;

import java.lang.reflect.AnnotatedElement;
import org.springframework.transaction.interceptor.TransactionAttribute;

public abstract interface TransactionAnnotationParser
{
  public abstract TransactionAttribute parseTransactionAnnotation(AnnotatedElement paramAnnotatedElement);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.TransactionAnnotationParser
 * JD-Core Version:    0.6.2
 */