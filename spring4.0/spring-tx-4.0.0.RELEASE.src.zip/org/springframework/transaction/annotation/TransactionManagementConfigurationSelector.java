/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ 
/*    */ public class TransactionManagementConfigurationSelector extends AdviceModeImportSelector<EnableTransactionManagement>
/*    */ {
/*    */   protected String[] selectImports(AdviceMode adviceMode)
/*    */   {
/* 45 */     switch (1.$SwitchMap$org$springframework$context$annotation$AdviceMode[adviceMode.ordinal()]) {
/*    */     case 1:
/* 47 */       return new String[] { AutoProxyRegistrar.class.getName(), ProxyTransactionManagementConfiguration.class.getName() };
/*    */     case 2:
/* 49 */       return new String[] { "org.springframework.transaction.aspectj.AspectJTransactionManagementConfiguration" };
/*    */     }
/* 51 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.TransactionManagementConfigurationSelector
 * JD-Core Version:    0.6.2
 */