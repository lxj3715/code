package org.springframework.transaction.annotation;

import org.springframework.transaction.PlatformTransactionManager;

public abstract interface TransactionManagementConfigurer
{
  public abstract PlatformTransactionManager annotationDrivenTransactionManager();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.TransactionManagementConfigurer
 * JD-Core Version:    0.6.2
 */