package org.springframework.transaction.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface Transactional
{
  public abstract String value();

  public abstract Propagation propagation();

  public abstract Isolation isolation();

  public abstract int timeout();

  public abstract boolean readOnly();

  public abstract Class<? extends Throwable>[] rollbackFor();

  public abstract String[] rollbackForClassName();

  public abstract Class<? extends Throwable>[] noRollbackFor();

  public abstract String[] noRollbackForClassName();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.annotation.Transactional
 * JD-Core Version:    0.6.2
 */