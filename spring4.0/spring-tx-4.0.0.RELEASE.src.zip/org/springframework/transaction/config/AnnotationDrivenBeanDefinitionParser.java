/*     */ package org.springframework.transaction.config;
/*     */ 
/*     */ import org.springframework.aop.config.AopNamespaceUtils;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.transaction.interceptor.BeanFactoryTransactionAttributeSourceAdvisor;
/*     */ import org.springframework.transaction.interceptor.TransactionInterceptor;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class AnnotationDrivenBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */ 
/*     */   @Deprecated
/*     */   public static final String TRANSACTION_ADVISOR_BEAN_NAME = "org.springframework.transaction.config.internalTransactionAdvisor";
/*     */ 
/*     */   @Deprecated
/*     */   public static final String TRANSACTION_ASPECT_BEAN_NAME = "org.springframework.transaction.config.internalTransactionAspect";
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  77 */     String mode = element.getAttribute("mode");
/*  78 */     if ("aspectj".equals(mode))
/*     */     {
/*  80 */       registerTransactionAspect(element, parserContext);
/*     */     }
/*     */     else
/*     */     {
/*  84 */       AopAutoProxyConfigurer.configureAutoProxyCreator(element, parserContext);
/*     */     }
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */   private void registerTransactionAspect(Element element, ParserContext parserContext) {
/*  90 */     String txAspectBeanName = "org.springframework.transaction.config.internalTransactionAspect";
/*  91 */     String txAspectClassName = "org.springframework.transaction.aspectj.AnnotationTransactionAspect";
/*  92 */     if (!parserContext.getRegistry().containsBeanDefinition(txAspectBeanName)) {
/*  93 */       RootBeanDefinition def = new RootBeanDefinition();
/*  94 */       def.setBeanClassName(txAspectClassName);
/*  95 */       def.setFactoryMethodName("aspectOf");
/*  96 */       registerTransactionManager(element, def);
/*  97 */       parserContext.registerBeanComponent(new BeanComponentDefinition(def, txAspectBeanName));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void registerTransactionManager(Element element, BeanDefinition def) {
/* 102 */     def.getPropertyValues().add("transactionManagerBeanName", 
/* 103 */       TxNamespaceHandler.getTransactionManagerName(element));
/*     */   }
/*     */ 
/*     */   private static class AopAutoProxyConfigurer
/*     */   {
/*     */     public static void configureAutoProxyCreator(Element element, ParserContext parserContext)
/*     */     {
/* 113 */       AopNamespaceUtils.registerAutoProxyCreatorIfNecessary(parserContext, element);
/*     */ 
/* 115 */       String txAdvisorBeanName = "org.springframework.transaction.config.internalTransactionAdvisor";
/* 116 */       if (!parserContext.getRegistry().containsBeanDefinition(txAdvisorBeanName)) {
/* 117 */         Object eleSource = parserContext.extractSource(element);
/*     */ 
/* 120 */         RootBeanDefinition sourceDef = new RootBeanDefinition("org.springframework.transaction.annotation.AnnotationTransactionAttributeSource");
/*     */ 
/* 122 */         sourceDef.setSource(eleSource);
/* 123 */         sourceDef.setRole(2);
/* 124 */         String sourceName = parserContext.getReaderContext().registerWithGeneratedName(sourceDef);
/*     */ 
/* 127 */         RootBeanDefinition interceptorDef = new RootBeanDefinition(TransactionInterceptor.class);
/* 128 */         interceptorDef.setSource(eleSource);
/* 129 */         interceptorDef.setRole(2);
/* 130 */         AnnotationDrivenBeanDefinitionParser.registerTransactionManager(element, interceptorDef);
/* 131 */         interceptorDef.getPropertyValues().add("transactionAttributeSource", new RuntimeBeanReference(sourceName));
/* 132 */         String interceptorName = parserContext.getReaderContext().registerWithGeneratedName(interceptorDef);
/*     */ 
/* 135 */         RootBeanDefinition advisorDef = new RootBeanDefinition(BeanFactoryTransactionAttributeSourceAdvisor.class);
/* 136 */         advisorDef.setSource(eleSource);
/* 137 */         advisorDef.setRole(2);
/* 138 */         advisorDef.getPropertyValues().add("transactionAttributeSource", new RuntimeBeanReference(sourceName));
/* 139 */         advisorDef.getPropertyValues().add("adviceBeanName", interceptorName);
/* 140 */         if (element.hasAttribute("order")) {
/* 141 */           advisorDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */         }
/* 143 */         parserContext.getRegistry().registerBeanDefinition(txAdvisorBeanName, advisorDef);
/*     */ 
/* 145 */         CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), eleSource);
/* 146 */         compositeDef.addNestedComponent(new BeanComponentDefinition(sourceDef, sourceName));
/* 147 */         compositeDef.addNestedComponent(new BeanComponentDefinition(interceptorDef, interceptorName));
/* 148 */         compositeDef.addNestedComponent(new BeanComponentDefinition(advisorDef, txAdvisorBeanName));
/* 149 */         parserContext.registerComponent(compositeDef);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.config.AnnotationDrivenBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */