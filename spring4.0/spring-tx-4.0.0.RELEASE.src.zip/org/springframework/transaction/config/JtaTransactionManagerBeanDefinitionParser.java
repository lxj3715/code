/*    */ package org.springframework.transaction.config;
/*    */ 
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class JtaTransactionManagerBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*    */ {
/*    */   private static final String WEBLOGIC_JTA_TRANSACTION_MANAGER_CLASS_NAME = "org.springframework.transaction.jta.WebLogicJtaTransactionManager";
/*    */   private static final String WEBSPHERE_TRANSACTION_MANAGER_CLASS_NAME = "org.springframework.transaction.jta.WebSphereUowTransactionManager";
/*    */   private static final String JTA_TRANSACTION_MANAGER_CLASS_NAME = "org.springframework.transaction.jta.JtaTransactionManager";
/* 46 */   private static final boolean weblogicPresent = ClassUtils.isPresent("weblogic.transaction.UserTransaction", JtaTransactionManagerBeanDefinitionParser.class
/* 47 */     .getClassLoader());
/*    */ 
/* 49 */   private static final boolean webspherePresent = ClassUtils.isPresent("com.ibm.wsspi.uow.UOWManager", JtaTransactionManagerBeanDefinitionParser.class
/* 50 */     .getClassLoader());
/*    */ 
/*    */   protected String getBeanClassName(Element element)
/*    */   {
/* 55 */     if (weblogicPresent) {
/* 56 */       return "org.springframework.transaction.jta.WebLogicJtaTransactionManager";
/*    */     }
/* 58 */     if (webspherePresent) {
/* 59 */       return "org.springframework.transaction.jta.WebSphereUowTransactionManager";
/*    */     }
/*    */ 
/* 62 */     return "org.springframework.transaction.jta.JtaTransactionManager";
/*    */   }
/*    */ 
/*    */   protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext)
/*    */   {
/* 68 */     return "transactionManager";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.config.JtaTransactionManagerBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */