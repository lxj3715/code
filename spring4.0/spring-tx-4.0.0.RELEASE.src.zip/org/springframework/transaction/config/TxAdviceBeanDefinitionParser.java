/*     */ package org.springframework.transaction.config;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.transaction.interceptor.NameMatchTransactionAttributeSource;
/*     */ import org.springframework.transaction.interceptor.NoRollbackRuleAttribute;
/*     */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/*     */ import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
/*     */ import org.springframework.transaction.interceptor.TransactionInterceptor;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class TxAdviceBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*     */ {
/*     */   private static final String METHOD_ELEMENT = "method";
/*     */   private static final String METHOD_NAME_ATTRIBUTE = "name";
/*     */   private static final String ATTRIBUTES_ELEMENT = "attributes";
/*     */   private static final String TIMEOUT_ATTRIBUTE = "timeout";
/*     */   private static final String READ_ONLY_ATTRIBUTE = "read-only";
/*     */   private static final String PROPAGATION_ATTRIBUTE = "propagation";
/*     */   private static final String ISOLATION_ATTRIBUTE = "isolation";
/*     */   private static final String ROLLBACK_FOR_ATTRIBUTE = "rollback-for";
/*     */   private static final String NO_ROLLBACK_FOR_ATTRIBUTE = "no-rollback-for";
/*     */ 
/*     */   protected Class<?> getBeanClass(Element element)
/*     */   {
/*  71 */     return TransactionInterceptor.class;
/*     */   }
/*     */ 
/*     */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */   {
/*  76 */     builder.addPropertyReference("transactionManager", TxNamespaceHandler.getTransactionManagerName(element));
/*     */ 
/*  78 */     List txAttributes = DomUtils.getChildElementsByTagName(element, "attributes");
/*  79 */     if (txAttributes.size() > 1) {
/*  80 */       parserContext.getReaderContext().error("Element <attributes> is allowed at most once inside element <advice>", element);
/*     */     }
/*  83 */     else if (txAttributes.size() == 1)
/*     */     {
/*  85 */       Element attributeSourceElement = (Element)txAttributes.get(0);
/*  86 */       RootBeanDefinition attributeSourceDefinition = parseAttributeSource(attributeSourceElement, parserContext);
/*  87 */       builder.addPropertyValue("transactionAttributeSource", attributeSourceDefinition);
/*     */     }
/*     */     else
/*     */     {
/*  91 */       builder.addPropertyValue("transactionAttributeSource", new RootBeanDefinition("org.springframework.transaction.annotation.AnnotationTransactionAttributeSource"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private RootBeanDefinition parseAttributeSource(Element attrEle, ParserContext parserContext)
/*     */   {
/*  97 */     List methods = DomUtils.getChildElementsByTagName(attrEle, "method");
/*     */ 
/*  99 */     ManagedMap transactionAttributeMap = new ManagedMap(methods
/*  99 */       .size());
/* 100 */     transactionAttributeMap.setSource(parserContext.extractSource(attrEle));
/*     */ 
/* 102 */     for (Element methodEle : methods) {
/* 103 */       String name = methodEle.getAttribute("name");
/* 104 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 105 */       nameHolder.setSource(parserContext.extractSource(methodEle));
/*     */ 
/* 107 */       RuleBasedTransactionAttribute attribute = new RuleBasedTransactionAttribute();
/* 108 */       String propagation = methodEle.getAttribute("propagation");
/* 109 */       String isolation = methodEle.getAttribute("isolation");
/* 110 */       String timeout = methodEle.getAttribute("timeout");
/* 111 */       String readOnly = methodEle.getAttribute("read-only");
/* 112 */       if (StringUtils.hasText(propagation)) {
/* 113 */         attribute.setPropagationBehaviorName("PROPAGATION_" + propagation);
/*     */       }
/* 115 */       if (StringUtils.hasText(isolation)) {
/* 116 */         attribute.setIsolationLevelName("ISOLATION_" + isolation);
/*     */       }
/* 118 */       if (StringUtils.hasText(timeout)) {
/*     */         try {
/* 120 */           attribute.setTimeout(Integer.parseInt(timeout));
/*     */         }
/*     */         catch (NumberFormatException ex) {
/* 123 */           parserContext.getReaderContext().error("Timeout must be an integer value: [" + timeout + "]", methodEle);
/*     */         }
/*     */       }
/* 126 */       if (StringUtils.hasText(readOnly)) {
/* 127 */         attribute.setReadOnly(Boolean.valueOf(methodEle.getAttribute("read-only")).booleanValue());
/*     */       }
/*     */ 
/* 130 */       List rollbackRules = new LinkedList();
/* 131 */       if (methodEle.hasAttribute("rollback-for")) {
/* 132 */         String rollbackForValue = methodEle.getAttribute("rollback-for");
/* 133 */         addRollbackRuleAttributesTo(rollbackRules, rollbackForValue);
/*     */       }
/* 135 */       if (methodEle.hasAttribute("no-rollback-for")) {
/* 136 */         String noRollbackForValue = methodEle.getAttribute("no-rollback-for");
/* 137 */         addNoRollbackRuleAttributesTo(rollbackRules, noRollbackForValue);
/*     */       }
/* 139 */       attribute.setRollbackRules(rollbackRules);
/*     */ 
/* 141 */       transactionAttributeMap.put(nameHolder, attribute);
/*     */     }
/*     */ 
/* 144 */     RootBeanDefinition attributeSourceDefinition = new RootBeanDefinition(NameMatchTransactionAttributeSource.class);
/* 145 */     attributeSourceDefinition.setSource(parserContext.extractSource(attrEle));
/* 146 */     attributeSourceDefinition.getPropertyValues().add("nameMap", transactionAttributeMap);
/* 147 */     return attributeSourceDefinition;
/*     */   }
/*     */ 
/*     */   private void addRollbackRuleAttributesTo(List<RollbackRuleAttribute> rollbackRules, String rollbackForValue) {
/* 151 */     String[] exceptionTypeNames = StringUtils.commaDelimitedListToStringArray(rollbackForValue);
/* 152 */     for (String typeName : exceptionTypeNames)
/* 153 */       rollbackRules.add(new RollbackRuleAttribute(StringUtils.trimWhitespace(typeName)));
/*     */   }
/*     */ 
/*     */   private void addNoRollbackRuleAttributesTo(List<RollbackRuleAttribute> rollbackRules, String noRollbackForValue)
/*     */   {
/* 158 */     String[] exceptionTypeNames = StringUtils.commaDelimitedListToStringArray(noRollbackForValue);
/* 159 */     for (String typeName : exceptionTypeNames)
/* 160 */       rollbackRules.add(new NoRollbackRuleAttribute(StringUtils.trimWhitespace(typeName)));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.config.TxAdviceBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */