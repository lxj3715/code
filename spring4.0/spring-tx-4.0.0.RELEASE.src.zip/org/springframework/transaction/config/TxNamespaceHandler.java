/*    */ package org.springframework.transaction.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class TxNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   static final String TRANSACTION_MANAGER_ATTRIBUTE = "transaction-manager";
/*    */   static final String DEFAULT_TRANSACTION_MANAGER_BEAN_NAME = "transactionManager";
/*    */ 
/*    */   static String getTransactionManagerName(Element element)
/*    */   {
/* 49 */     return element.hasAttribute("transaction-manager") ? element
/* 49 */       .getAttribute("transaction-manager") : 
/* 49 */       "transactionManager";
/*    */   }
/*    */ 
/*    */   public void init()
/*    */   {
/* 55 */     registerBeanDefinitionParser("advice", new TxAdviceBeanDefinitionParser());
/* 56 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
/* 57 */     registerBeanDefinitionParser("jta-transaction-manager", new JtaTransactionManagerBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.config.TxNamespaceHandler
 * JD-Core Version:    0.6.2
 */