/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class AbstractFallbackTransactionAttributeSource
/*     */   implements TransactionAttributeSource
/*     */ {
/*  57 */   private static final TransactionAttribute NULL_TRANSACTION_ATTRIBUTE = new DefaultTransactionAttribute();
/*     */   protected final Log logger;
/*     */   final Map<Object, TransactionAttribute> attributeCache;
/*     */ 
/*     */   public AbstractFallbackTransactionAttributeSource()
/*     */   {
/*  65 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  72 */     this.attributeCache = new ConcurrentHashMap(1024);
/*     */   }
/*     */ 
/*     */   public TransactionAttribute getTransactionAttribute(Method method, Class<?> targetClass)
/*     */   {
/*  86 */     Object cacheKey = getCacheKey(method, targetClass);
/*  87 */     Object cached = this.attributeCache.get(cacheKey);
/*  88 */     if (cached != null)
/*     */     {
/*  91 */       if (cached == NULL_TRANSACTION_ATTRIBUTE) {
/*  92 */         return null;
/*     */       }
/*     */ 
/*  95 */       return (TransactionAttribute)cached;
/*     */     }
/*     */ 
/* 100 */     TransactionAttribute txAtt = computeTransactionAttribute(method, targetClass);
/*     */ 
/* 102 */     if (txAtt == null) {
/* 103 */       this.attributeCache.put(cacheKey, NULL_TRANSACTION_ATTRIBUTE);
/*     */     }
/*     */     else {
/* 106 */       if (this.logger.isDebugEnabled()) {
/* 107 */         this.logger.debug("Adding transactional method '" + method.getName() + "' with attribute: " + txAtt);
/*     */       }
/* 109 */       this.attributeCache.put(cacheKey, txAtt);
/*     */     }
/* 111 */     return txAtt;
/*     */   }
/*     */ 
/*     */   protected Object getCacheKey(Method method, Class<?> targetClass)
/*     */   {
/* 124 */     return new DefaultCacheKey(method, targetClass);
/*     */   }
/*     */ 
/*     */   private TransactionAttribute computeTransactionAttribute(Method method, Class<?> targetClass)
/*     */   {
/* 134 */     if ((allowPublicMethodsOnly()) && (!Modifier.isPublic(method.getModifiers()))) {
/* 135 */       return null;
/*     */     }
/*     */ 
/* 139 */     Class userClass = ClassUtils.getUserClass(targetClass);
/*     */ 
/* 142 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, userClass);
/*     */ 
/* 144 */     specificMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/*     */ 
/* 147 */     TransactionAttribute txAtt = findTransactionAttribute(specificMethod);
/* 148 */     if (txAtt != null) {
/* 149 */       return txAtt;
/*     */     }
/*     */ 
/* 153 */     txAtt = findTransactionAttribute(specificMethod.getDeclaringClass());
/* 154 */     if (txAtt != null) {
/* 155 */       return txAtt;
/*     */     }
/*     */ 
/* 158 */     if (specificMethod != method)
/*     */     {
/* 160 */       txAtt = findTransactionAttribute(method);
/* 161 */       if (txAtt != null) {
/* 162 */         return txAtt;
/*     */       }
/*     */ 
/* 165 */       return findTransactionAttribute(method.getDeclaringClass());
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   protected abstract TransactionAttribute findTransactionAttribute(Method paramMethod);
/*     */ 
/*     */   protected abstract TransactionAttribute findTransactionAttribute(Class<?> paramClass);
/*     */ 
/*     */   protected boolean allowPublicMethodsOnly()
/*     */   {
/* 195 */     return false;
/*     */   }
/*     */ 
/*     */   private static class DefaultCacheKey
/*     */   {
/*     */     private final Method method;
/*     */     private final Class<?> targetClass;
/*     */ 
/*     */     public DefaultCacheKey(Method method, Class<?> targetClass)
/*     */     {
/* 209 */       this.method = method;
/* 210 */       this.targetClass = targetClass;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 215 */       if (this == other) {
/* 216 */         return true;
/*     */       }
/* 218 */       if (!(other instanceof DefaultCacheKey)) {
/* 219 */         return false;
/*     */       }
/* 221 */       DefaultCacheKey otherKey = (DefaultCacheKey)other;
/*     */ 
/* 223 */       return (this.method.equals(otherKey.method)) && 
/* 223 */         (ObjectUtils.nullSafeEquals(this.targetClass, otherKey.targetClass));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 228 */       return this.method.hashCode() * 29 + (this.targetClass != null ? this.targetClass.hashCode() : 0);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.AbstractFallbackTransactionAttributeSource
 * JD-Core Version:    0.6.2
 */