/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractBeanFactoryPointcutAdvisor;
/*    */ 
/*    */ public class BeanFactoryTransactionAttributeSourceAdvisor extends AbstractBeanFactoryPointcutAdvisor
/*    */ {
/*    */   private TransactionAttributeSource transactionAttributeSource;
/* 38 */   private final TransactionAttributeSourcePointcut pointcut = new TransactionAttributeSourcePointcut()
/*    */   {
/*    */     protected TransactionAttributeSource getTransactionAttributeSource() {
/* 41 */       return BeanFactoryTransactionAttributeSourceAdvisor.this.transactionAttributeSource;
/*    */     }
/* 38 */   };
/*    */ 
/*    */   public void setTransactionAttributeSource(TransactionAttributeSource transactionAttributeSource)
/*    */   {
/* 53 */     this.transactionAttributeSource = transactionAttributeSource;
/*    */   }
/*    */ 
/*    */   public void setClassFilter(ClassFilter classFilter)
/*    */   {
/* 61 */     this.pointcut.setClassFilter(classFilter);
/*    */   }
/*    */ 
/*    */   public Pointcut getPointcut()
/*    */   {
/* 66 */     return this.pointcut;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.BeanFactoryTransactionAttributeSourceAdvisor
 * JD-Core Version:    0.6.2
 */