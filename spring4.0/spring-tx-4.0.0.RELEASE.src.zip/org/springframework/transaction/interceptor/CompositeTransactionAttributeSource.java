/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class CompositeTransactionAttributeSource
/*    */   implements TransactionAttributeSource, Serializable
/*    */ {
/*    */   private final TransactionAttributeSource[] transactionAttributeSources;
/*    */ 
/*    */   public CompositeTransactionAttributeSource(TransactionAttributeSource[] transactionAttributeSources)
/*    */   {
/* 42 */     Assert.notNull(transactionAttributeSources, "TransactionAttributeSource array must not be null");
/* 43 */     this.transactionAttributeSources = transactionAttributeSources;
/*    */   }
/*    */ 
/*    */   public final TransactionAttributeSource[] getTransactionAttributeSources()
/*    */   {
/* 51 */     return this.transactionAttributeSources;
/*    */   }
/*    */ 
/*    */   public TransactionAttribute getTransactionAttribute(Method method, Class<?> targetClass)
/*    */   {
/* 57 */     for (TransactionAttributeSource tas : this.transactionAttributeSources) {
/* 58 */       TransactionAttribute ta = tas.getTransactionAttribute(method, targetClass);
/* 59 */       if (ta != null) {
/* 60 */         return ta;
/*    */       }
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.CompositeTransactionAttributeSource
 * JD-Core Version:    0.6.2
 */