/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import org.springframework.transaction.support.DefaultTransactionDefinition;
/*     */ 
/*     */ public class DefaultTransactionAttribute extends DefaultTransactionDefinition
/*     */   implements TransactionAttribute
/*     */ {
/*     */   private String qualifier;
/*     */ 
/*     */   public DefaultTransactionAttribute()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DefaultTransactionAttribute(TransactionAttribute other)
/*     */   {
/*  56 */     super(other);
/*     */   }
/*     */ 
/*     */   public DefaultTransactionAttribute(int propagationBehavior)
/*     */   {
/*  69 */     super(propagationBehavior);
/*     */   }
/*     */ 
/*     */   public void setQualifier(String qualifier)
/*     */   {
/*  79 */     this.qualifier = qualifier;
/*     */   }
/*     */ 
/*     */   public String getQualifier()
/*     */   {
/*  87 */     return this.qualifier;
/*     */   }
/*     */ 
/*     */   public boolean rollbackOn(Throwable ex)
/*     */   {
/*  97 */     return ((ex instanceof RuntimeException)) || ((ex instanceof Error));
/*     */   }
/*     */ 
/*     */   protected final StringBuilder getAttributeDescription()
/*     */   {
/* 106 */     StringBuilder result = getDefinitionDescription();
/* 107 */     if (this.qualifier != null) {
/* 108 */       result.append("; '").append(this.qualifier).append("'");
/*     */     }
/* 110 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.DefaultTransactionAttribute
 * JD-Core Version:    0.6.2
 */