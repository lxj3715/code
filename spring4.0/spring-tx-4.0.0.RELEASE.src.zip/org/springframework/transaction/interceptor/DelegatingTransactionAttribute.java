/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.transaction.support.DelegatingTransactionDefinition;
/*    */ 
/*    */ public abstract class DelegatingTransactionAttribute extends DelegatingTransactionDefinition
/*    */   implements TransactionAttribute, Serializable
/*    */ {
/*    */   private final TransactionAttribute targetAttribute;
/*    */ 
/*    */   public DelegatingTransactionAttribute(TransactionAttribute targetAttribute)
/*    */   {
/* 44 */     super(targetAttribute);
/* 45 */     this.targetAttribute = targetAttribute;
/*    */   }
/*    */ 
/*    */   public String getQualifier()
/*    */   {
/* 51 */     return this.targetAttribute.getQualifier();
/*    */   }
/*    */ 
/*    */   public boolean rollbackOn(Throwable ex)
/*    */   {
/* 56 */     return this.targetAttribute.rollbackOn(ex);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.DelegatingTransactionAttribute
 * JD-Core Version:    0.6.2
 */