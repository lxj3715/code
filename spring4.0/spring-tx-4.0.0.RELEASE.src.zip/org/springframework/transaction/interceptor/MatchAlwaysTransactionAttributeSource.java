/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ public class MatchAlwaysTransactionAttributeSource
/*    */   implements TransactionAttributeSource, Serializable
/*    */ {
/* 40 */   private TransactionAttribute transactionAttribute = new DefaultTransactionAttribute();
/*    */ 
/*    */   public void setTransactionAttribute(TransactionAttribute transactionAttribute)
/*    */   {
/* 50 */     this.transactionAttribute = transactionAttribute;
/*    */   }
/*    */ 
/*    */   public TransactionAttribute getTransactionAttribute(Method method, Class<?> targetClass)
/*    */   {
/* 56 */     return (method == null) || (ClassUtils.isUserLevelMethod(method)) ? this.transactionAttribute : null;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 62 */     if (this == other) {
/* 63 */       return true;
/*    */     }
/* 65 */     if (!(other instanceof MatchAlwaysTransactionAttributeSource)) {
/* 66 */       return false;
/*    */     }
/* 68 */     MatchAlwaysTransactionAttributeSource otherTas = (MatchAlwaysTransactionAttributeSource)other;
/* 69 */     return ObjectUtils.nullSafeEquals(this.transactionAttribute, otherTas.transactionAttribute);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 74 */     return MatchAlwaysTransactionAttributeSource.class.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 79 */     return getClass().getName() + ": " + this.transactionAttribute;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.MatchAlwaysTransactionAttributeSource
 * JD-Core Version:    0.6.2
 */