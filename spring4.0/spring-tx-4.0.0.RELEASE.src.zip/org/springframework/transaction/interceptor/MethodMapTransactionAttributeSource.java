/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ public class MethodMapTransactionAttributeSource
/*     */   implements TransactionAttributeSource, BeanClassLoaderAware, InitializingBean
/*     */ {
/*  49 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Map<String, TransactionAttribute> methodMap;
/*  54 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*  56 */   private boolean eagerlyInitialized = false;
/*     */ 
/*  58 */   private boolean initialized = false;
/*     */ 
/*  61 */   private final Map<Method, TransactionAttribute> transactionAttributeMap = new HashMap();
/*     */ 
/*  65 */   private final Map<Method, String> methodNameMap = new HashMap();
/*     */ 
/*     */   public void setMethodMap(Map<String, TransactionAttribute> methodMap)
/*     */   {
/*  81 */     this.methodMap = methodMap;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/*  86 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/*  97 */     initMethodMap(this.methodMap);
/*  98 */     this.eagerlyInitialized = true;
/*  99 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */   protected void initMethodMap(Map<String, TransactionAttribute> methodMap)
/*     */   {
/* 108 */     if (methodMap != null)
/* 109 */       for (Map.Entry entry : methodMap.entrySet())
/* 110 */         addTransactionalMethod((String)entry.getKey(), (TransactionAttribute)entry.getValue());
/*     */   }
/*     */ 
/*     */   public void addTransactionalMethod(String name, TransactionAttribute attr)
/*     */   {
/* 124 */     Assert.notNull(name, "Name must not be null");
/* 125 */     int lastDotIndex = name.lastIndexOf(".");
/* 126 */     if (lastDotIndex == -1) {
/* 127 */       throw new IllegalArgumentException("'" + name + "' is not a valid method name: format is FQN.methodName");
/*     */     }
/* 129 */     String className = name.substring(0, lastDotIndex);
/* 130 */     String methodName = name.substring(lastDotIndex + 1);
/* 131 */     Class clazz = ClassUtils.resolveClassName(className, this.beanClassLoader);
/* 132 */     addTransactionalMethod(clazz, methodName, attr);
/*     */   }
/*     */ 
/*     */   public void addTransactionalMethod(Class<?> clazz, String mappedName, TransactionAttribute attr)
/*     */   {
/* 143 */     Assert.notNull(clazz, "Class must not be null");
/* 144 */     Assert.notNull(mappedName, "Mapped name must not be null");
/* 145 */     String name = clazz.getName() + '.' + mappedName;
/*     */ 
/* 147 */     Method[] methods = clazz.getDeclaredMethods();
/* 148 */     List matchingMethods = new ArrayList();
/* 149 */     for (Method method : methods) {
/* 150 */       if (isMatch(method.getName(), mappedName)) {
/* 151 */         matchingMethods.add(method);
/*     */       }
/*     */     }
/* 154 */     if (matchingMethods.isEmpty())
/*     */     {
/* 156 */       throw new IllegalArgumentException("Couldn't find method '" + mappedName + "' on class [" + clazz
/* 156 */         .getName() + "]");
/*     */     }
/*     */ 
/* 160 */     for (??? = matchingMethods.iterator(); ((Iterator)???).hasNext(); ) { Method method = (Method)((Iterator)???).next();
/* 161 */       String regMethodName = (String)this.methodNameMap.get(method);
/* 162 */       if ((regMethodName == null) || ((!regMethodName.equals(name)) && (regMethodName.length() <= name.length())))
/*     */       {
/* 165 */         if ((this.logger.isDebugEnabled()) && (regMethodName != null)) {
/* 166 */           this.logger.debug("Replacing attribute for transactional method [" + method + "]: current name '" + name + "' is more specific than '" + regMethodName + "'");
/*     */         }
/*     */ 
/* 169 */         this.methodNameMap.put(method, name);
/* 170 */         addTransactionalMethod(method, attr);
/*     */       }
/* 173 */       else if (this.logger.isDebugEnabled()) {
/* 174 */         this.logger.debug("Keeping attribute for transactional method [" + method + "]: current name '" + name + "' is not more specific than '" + regMethodName + "'");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTransactionalMethod(Method method, TransactionAttribute attr)
/*     */   {
/* 187 */     Assert.notNull(method, "Method must not be null");
/* 188 */     Assert.notNull(attr, "TransactionAttribute must not be null");
/* 189 */     if (this.logger.isDebugEnabled()) {
/* 190 */       this.logger.debug("Adding transactional method [" + method + "] with attribute [" + attr + "]");
/*     */     }
/* 192 */     this.transactionAttributeMap.put(method, attr);
/*     */   }
/*     */ 
/*     */   protected boolean isMatch(String methodName, String mappedName)
/*     */   {
/* 205 */     return PatternMatchUtils.simpleMatch(mappedName, methodName);
/*     */   }
/*     */ 
/*     */   public TransactionAttribute getTransactionAttribute(Method method, Class<?> targetClass)
/*     */   {
/* 211 */     if (this.eagerlyInitialized) {
/* 212 */       return (TransactionAttribute)this.transactionAttributeMap.get(method);
/*     */     }
/*     */ 
/* 215 */     synchronized (this.transactionAttributeMap) {
/* 216 */       if (!this.initialized) {
/* 217 */         initMethodMap(this.methodMap);
/* 218 */         this.initialized = true;
/*     */       }
/* 220 */       return (TransactionAttribute)this.transactionAttributeMap.get(method);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 228 */     if (this == other) {
/* 229 */       return true;
/*     */     }
/* 231 */     if (!(other instanceof MethodMapTransactionAttributeSource)) {
/* 232 */       return false;
/*     */     }
/* 234 */     MethodMapTransactionAttributeSource otherTas = (MethodMapTransactionAttributeSource)other;
/* 235 */     return ObjectUtils.nullSafeEquals(this.methodMap, otherTas.methodMap);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 240 */     return MethodMapTransactionAttributeSource.class.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 245 */     return getClass().getName() + ": " + this.methodMap;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.MethodMapTransactionAttributeSource
 * JD-Core Version:    0.6.2
 */