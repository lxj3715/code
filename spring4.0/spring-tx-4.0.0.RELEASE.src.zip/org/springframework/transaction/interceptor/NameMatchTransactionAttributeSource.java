/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ public class NameMatchTransactionAttributeSource
/*     */   implements TransactionAttributeSource, Serializable
/*     */ {
/*  49 */   protected static final Log logger = LogFactory.getLog(NameMatchTransactionAttributeSource.class);
/*     */ 
/*  52 */   private Map<String, TransactionAttribute> nameMap = new HashMap();
/*     */ 
/*     */   public void setNameMap(Map<String, TransactionAttribute> nameMap)
/*     */   {
/*  63 */     for (Map.Entry entry : nameMap.entrySet())
/*  64 */       addTransactionalMethod((String)entry.getKey(), (TransactionAttribute)entry.getValue());
/*     */   }
/*     */ 
/*     */   public void setProperties(Properties transactionAttributes)
/*     */   {
/*  76 */     TransactionAttributeEditor tae = new TransactionAttributeEditor();
/*  77 */     Enumeration propNames = transactionAttributes.propertyNames();
/*  78 */     while (propNames.hasMoreElements()) {
/*  79 */       String methodName = (String)propNames.nextElement();
/*  80 */       String value = transactionAttributes.getProperty(methodName);
/*  81 */       tae.setAsText(value);
/*  82 */       TransactionAttribute attr = (TransactionAttribute)tae.getValue();
/*  83 */       addTransactionalMethod(methodName, attr);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTransactionalMethod(String methodName, TransactionAttribute attr)
/*     */   {
/*  95 */     if (logger.isDebugEnabled()) {
/*  96 */       logger.debug("Adding transactional method [" + methodName + "] with attribute [" + attr + "]");
/*     */     }
/*  98 */     this.nameMap.put(methodName, attr);
/*     */   }
/*     */ 
/*     */   public TransactionAttribute getTransactionAttribute(Method method, Class<?> targetClass)
/*     */   {
/* 104 */     if (!ClassUtils.isUserLevelMethod(method)) {
/* 105 */       return null;
/*     */     }
/*     */ 
/* 109 */     String methodName = method.getName();
/* 110 */     TransactionAttribute attr = (TransactionAttribute)this.nameMap.get(methodName);
/*     */     String bestNameMatch;
/* 112 */     if (attr == null)
/*     */     {
/* 114 */       bestNameMatch = null;
/* 115 */       for (String mappedName : this.nameMap.keySet()) {
/* 116 */         if ((isMatch(methodName, mappedName)) && ((bestNameMatch == null) || 
/* 117 */           (bestNameMatch
/* 117 */           .length() <= mappedName.length()))) {
/* 118 */           attr = (TransactionAttribute)this.nameMap.get(mappedName);
/* 119 */           bestNameMatch = mappedName;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 124 */     return attr;
/*     */   }
/*     */ 
/*     */   protected boolean isMatch(String methodName, String mappedName)
/*     */   {
/* 137 */     return PatternMatchUtils.simpleMatch(mappedName, methodName);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 143 */     if (this == other) {
/* 144 */       return true;
/*     */     }
/* 146 */     if (!(other instanceof NameMatchTransactionAttributeSource)) {
/* 147 */       return false;
/*     */     }
/* 149 */     NameMatchTransactionAttributeSource otherTas = (NameMatchTransactionAttributeSource)other;
/* 150 */     return ObjectUtils.nullSafeEquals(this.nameMap, otherTas.nameMap);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 155 */     return NameMatchTransactionAttributeSource.class.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 160 */     return getClass().getName() + ": " + this.nameMap;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.NameMatchTransactionAttributeSource
 * JD-Core Version:    0.6.2
 */