/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ public class NoRollbackRuleAttribute extends RollbackRuleAttribute
/*    */ {
/*    */   public NoRollbackRuleAttribute(Class<?> clazz)
/*    */   {
/* 36 */     super(clazz);
/*    */   }
/*    */ 
/*    */   public NoRollbackRuleAttribute(String exceptionName)
/*    */   {
/* 46 */     super(exceptionName);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return "No" + super.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.NoRollbackRuleAttribute
 * JD-Core Version:    0.6.2
 */