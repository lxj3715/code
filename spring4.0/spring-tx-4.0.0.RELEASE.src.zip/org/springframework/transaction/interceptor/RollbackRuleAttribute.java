/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class RollbackRuleAttribute
/*     */   implements Serializable
/*     */ {
/*  41 */   public static final RollbackRuleAttribute ROLLBACK_ON_RUNTIME_EXCEPTIONS = new RollbackRuleAttribute(RuntimeException.class);
/*     */   private final String exceptionName;
/*     */ 
/*     */   public RollbackRuleAttribute(Class<?> clazz)
/*     */   {
/*  63 */     Assert.notNull(clazz, "'clazz' cannot be null.");
/*  64 */     if (!Throwable.class.isAssignableFrom(clazz))
/*     */     {
/*  66 */       throw new IllegalArgumentException("Cannot construct rollback rule from [" + clazz
/*  66 */         .getName() + "]: it's not a Throwable");
/*     */     }
/*  68 */     this.exceptionName = clazz.getName();
/*     */   }
/*     */ 
/*     */   public RollbackRuleAttribute(String exceptionName)
/*     */   {
/*  90 */     Assert.hasText(exceptionName, "'exceptionName' cannot be null or empty.");
/*  91 */     this.exceptionName = exceptionName;
/*     */   }
/*     */ 
/*     */   public String getExceptionName()
/*     */   {
/*  99 */     return this.exceptionName;
/*     */   }
/*     */ 
/*     */   public int getDepth(Throwable ex)
/*     */   {
/* 109 */     return getDepth(ex.getClass(), 0);
/*     */   }
/*     */ 
/*     */   private int getDepth(Class<?> exceptionClass, int depth)
/*     */   {
/* 114 */     if (exceptionClass.getName().indexOf(this.exceptionName) != -1)
/*     */     {
/* 116 */       return depth;
/*     */     }
/*     */ 
/* 119 */     if (exceptionClass.equals(Throwable.class)) {
/* 120 */       return -1;
/*     */     }
/* 122 */     return getDepth(exceptionClass.getSuperclass(), depth + 1);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 128 */     if (this == other) {
/* 129 */       return true;
/*     */     }
/* 131 */     if (!(other instanceof RollbackRuleAttribute)) {
/* 132 */       return false;
/*     */     }
/* 134 */     RollbackRuleAttribute rhs = (RollbackRuleAttribute)other;
/* 135 */     return this.exceptionName.equals(rhs.exceptionName);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 140 */     return this.exceptionName.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 145 */     return "RollbackRuleAttribute with pattern [" + this.exceptionName + "]";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.RollbackRuleAttribute
 * JD-Core Version:    0.6.2
 */