/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class RuleBasedTransactionAttribute extends DefaultTransactionAttribute
/*     */   implements Serializable
/*     */ {
/*     */   public static final String PREFIX_ROLLBACK_RULE = "-";
/*     */   public static final String PREFIX_COMMIT_RULE = "+";
/*  51 */   private static final Log logger = LogFactory.getLog(RuleBasedTransactionAttribute.class);
/*     */   private List<RollbackRuleAttribute> rollbackRules;
/*     */ 
/*     */   public RuleBasedTransactionAttribute()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RuleBasedTransactionAttribute(RuleBasedTransactionAttribute other)
/*     */   {
/*  80 */     super(other);
/*  81 */     this.rollbackRules = new ArrayList(other.rollbackRules);
/*     */   }
/*     */ 
/*     */   public RuleBasedTransactionAttribute(int propagationBehavior, List<RollbackRuleAttribute> rollbackRules)
/*     */   {
/*  95 */     super(propagationBehavior);
/*  96 */     this.rollbackRules = rollbackRules;
/*     */   }
/*     */ 
/*     */   public void setRollbackRules(List<RollbackRuleAttribute> rollbackRules)
/*     */   {
/* 107 */     this.rollbackRules = rollbackRules;
/*     */   }
/*     */ 
/*     */   public List<RollbackRuleAttribute> getRollbackRules()
/*     */   {
/* 115 */     if (this.rollbackRules == null) {
/* 116 */       this.rollbackRules = new LinkedList();
/*     */     }
/* 118 */     return this.rollbackRules;
/*     */   }
/*     */ 
/*     */   public boolean rollbackOn(Throwable ex)
/*     */   {
/* 130 */     if (logger.isTraceEnabled()) {
/* 131 */       logger.trace(new StringBuilder().append("Applying rules to determine whether transaction should rollback on ").append(ex).toString());
/*     */     }
/*     */ 
/* 134 */     RollbackRuleAttribute winner = null;
/* 135 */     int deepest = 2147483647;
/*     */ 
/* 137 */     if (this.rollbackRules != null) {
/* 138 */       for (RollbackRuleAttribute rule : this.rollbackRules) {
/* 139 */         int depth = rule.getDepth(ex);
/* 140 */         if ((depth >= 0) && (depth < deepest)) {
/* 141 */           deepest = depth;
/* 142 */           winner = rule;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 147 */     if (logger.isTraceEnabled()) {
/* 148 */       logger.trace(new StringBuilder().append("Winning rollback rule is: ").append(winner).toString());
/*     */     }
/*     */ 
/* 152 */     if (winner == null) {
/* 153 */       logger.trace("No relevant rollback rule found: applying default rules");
/* 154 */       return super.rollbackOn(ex);
/*     */     }
/*     */ 
/* 157 */     return !(winner instanceof NoRollbackRuleAttribute);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 163 */     StringBuilder result = getAttributeDescription();
/* 164 */     if (this.rollbackRules != null) {
/* 165 */       for (RollbackRuleAttribute rule : this.rollbackRules) {
/* 166 */         String sign = (rule instanceof NoRollbackRuleAttribute) ? "+" : "-";
/* 167 */         result.append(',').append(sign).append(rule.getExceptionName());
/*     */       }
/*     */     }
/* 170 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.RuleBasedTransactionAttribute
 * JD-Core Version:    0.6.2
 */