/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.transaction.NoTransactionException;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.TransactionStatus;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.support.CallbackPreferringPlatformTransactionManager;
/*     */ import org.springframework.transaction.support.TransactionCallback;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class TransactionAspectSupport
/*     */   implements BeanFactoryAware, InitializingBean
/*     */ {
/*  75 */   private static final ThreadLocal<TransactionInfo> transactionInfoHolder = new NamedThreadLocal("Current aspect-driven transaction");
/*     */   protected final Log logger;
/*     */   private String transactionManagerBeanName;
/*     */   private PlatformTransactionManager transactionManager;
/*     */   private TransactionAttributeSource transactionAttributeSource;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public TransactionAspectSupport()
/*     */   {
/* 116 */     this.logger = LogFactory.getLog(getClass());
/*     */   }
/*     */ 
/*     */   protected static TransactionInfo currentTransactionInfo()
/*     */     throws NoTransactionException
/*     */   {
/*  97 */     return (TransactionInfo)transactionInfoHolder.get();
/*     */   }
/*     */ 
/*     */   public static TransactionStatus currentTransactionStatus()
/*     */     throws NoTransactionException
/*     */   {
/* 108 */     TransactionInfo info = currentTransactionInfo();
/* 109 */     if (info == null) {
/* 110 */       throw new NoTransactionException("No transaction aspect-managed TransactionStatus in scope");
/*     */     }
/* 112 */     return currentTransactionInfo().transactionStatus;
/*     */   }
/*     */ 
/*     */   public void setTransactionManagerBeanName(String transactionManagerBeanName)
/*     */   {
/* 131 */     this.transactionManagerBeanName = transactionManagerBeanName;
/*     */   }
/*     */ 
/*     */   protected final String getTransactionManagerBeanName()
/*     */   {
/* 138 */     return this.transactionManagerBeanName;
/*     */   }
/*     */ 
/*     */   public void setTransactionManager(PlatformTransactionManager transactionManager)
/*     */   {
/* 145 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */   public PlatformTransactionManager getTransactionManager()
/*     */   {
/* 152 */     return this.transactionManager;
/*     */   }
/*     */ 
/*     */   public void setTransactionAttributes(Properties transactionAttributes)
/*     */   {
/* 168 */     NameMatchTransactionAttributeSource tas = new NameMatchTransactionAttributeSource();
/* 169 */     tas.setProperties(transactionAttributes);
/* 170 */     this.transactionAttributeSource = tas;
/*     */   }
/*     */ 
/*     */   public void setTransactionAttributeSources(TransactionAttributeSource[] transactionAttributeSources)
/*     */   {
/* 182 */     this.transactionAttributeSource = new CompositeTransactionAttributeSource(transactionAttributeSources);
/*     */   }
/*     */ 
/*     */   public void setTransactionAttributeSource(TransactionAttributeSource transactionAttributeSource)
/*     */   {
/* 195 */     this.transactionAttributeSource = transactionAttributeSource;
/*     */   }
/*     */ 
/*     */   public TransactionAttributeSource getTransactionAttributeSource()
/*     */   {
/* 202 */     return this.transactionAttributeSource;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 210 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   protected final BeanFactory getBeanFactory()
/*     */   {
/* 217 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 225 */     if ((this.transactionManager == null) && (this.beanFactory == null)) {
/* 226 */       throw new IllegalStateException("Setting the property 'transactionManager' or running in a ListableBeanFactory is required");
/*     */     }
/*     */ 
/* 229 */     if (this.transactionAttributeSource == null)
/* 230 */       throw new IllegalStateException("Either 'transactionAttributeSource' or 'transactionAttributes' is required: If there are no transactional methods, then don't use a transaction aspect.");
/*     */   }
/*     */ 
/*     */   protected Object invokeWithinTransaction(Method method, Class<?> targetClass, final InvocationCallback invocation)
/*     */     throws Throwable
/*     */   {
/* 251 */     final TransactionAttribute txAttr = getTransactionAttributeSource().getTransactionAttribute(method, targetClass);
/* 252 */     final PlatformTransactionManager tm = determineTransactionManager(txAttr);
/* 253 */     final String joinpointIdentification = methodIdentification(method, targetClass);
/*     */ 
/* 255 */     if ((txAttr == null) || (!(tm instanceof CallbackPreferringPlatformTransactionManager)))
/*     */     {
/* 257 */       TransactionInfo txInfo = createTransactionIfNecessary(tm, txAttr, joinpointIdentification);
/* 258 */       Object retVal = null;
/*     */       try
/*     */       {
/* 262 */         retVal = invocation.proceedWithInvocation();
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 266 */         completeTransactionAfterThrowing(txInfo, ex);
/* 267 */         throw ex;
/*     */       }
/*     */       finally {
/* 270 */         cleanupTransactionInfo(txInfo);
/*     */       }
/* 272 */       commitTransactionAfterReturning(txInfo);
/* 273 */       return retVal;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 279 */       Object result = ((CallbackPreferringPlatformTransactionManager)tm).execute(txAttr, new TransactionCallback()
/*     */       {
/*     */         public Object doInTransaction(TransactionStatus status)
/*     */         {
/* 283 */           TransactionAspectSupport.TransactionInfo txInfo = TransactionAspectSupport.this.prepareTransactionInfo(tm, txAttr, joinpointIdentification, status);
/*     */           try {
/* 285 */             return invocation.proceedWithInvocation();
/*     */           }
/*     */           catch (Throwable ex) {
/* 288 */             if (txAttr.rollbackOn(ex))
/*     */             {
/* 290 */               if ((ex instanceof RuntimeException)) {
/* 291 */                 throw ((RuntimeException)ex);
/*     */               }
/*     */ 
/* 294 */               throw new TransactionAspectSupport.ThrowableHolderException(ex);
/*     */             }
/*     */ 
/* 299 */             return new TransactionAspectSupport.ThrowableHolder(ex);
/*     */           }
/*     */           finally
/*     */           {
/* 303 */             TransactionAspectSupport.this.cleanupTransactionInfo(txInfo);
/*     */           }
/*     */         }
/*     */       });
/* 309 */       if ((result instanceof ThrowableHolder)) {
/* 310 */         throw ((ThrowableHolder)result).getThrowable();
/*     */       }
/*     */ 
/* 313 */       return result;
/*     */     }
/*     */     catch (ThrowableHolderException ex)
/*     */     {
/* 317 */       throw ex.getCause();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected PlatformTransactionManager determineTransactionManager(TransactionAttribute txAttr)
/*     */   {
/* 326 */     if ((this.transactionManager != null) || (this.beanFactory == null) || (txAttr == null)) {
/* 327 */       return this.transactionManager;
/*     */     }
/* 329 */     String qualifier = txAttr.getQualifier();
/* 330 */     if (StringUtils.hasLength(qualifier)) {
/* 331 */       return (PlatformTransactionManager)BeanFactoryAnnotationUtils.qualifiedBeanOfType(this.beanFactory, PlatformTransactionManager.class, qualifier);
/*     */     }
/* 333 */     if (this.transactionManagerBeanName != null) {
/* 334 */       return (PlatformTransactionManager)this.beanFactory.getBean(this.transactionManagerBeanName, PlatformTransactionManager.class);
/*     */     }
/*     */ 
/* 337 */     return (PlatformTransactionManager)this.beanFactory.getBean(PlatformTransactionManager.class);
/*     */   }
/*     */ 
/*     */   protected String methodIdentification(Method method, Class<?> targetClass)
/*     */   {
/* 351 */     String simpleMethodId = methodIdentification(method);
/* 352 */     if (simpleMethodId != null) {
/* 353 */       return simpleMethodId;
/*     */     }
/* 355 */     return new StringBuilder().append((targetClass != null ? targetClass : method.getDeclaringClass()).getName()).append(".").append(method.getName()).toString();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected String methodIdentification(Method method)
/*     */   {
/* 368 */     return null;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected TransactionInfo createTransactionIfNecessary(Method method, Class<?> targetClass)
/*     */   {
/* 386 */     TransactionAttribute txAttr = getTransactionAttributeSource().getTransactionAttribute(method, targetClass);
/* 387 */     PlatformTransactionManager tm = determineTransactionManager(txAttr);
/* 388 */     return createTransactionIfNecessary(tm, txAttr, methodIdentification(method, targetClass));
/*     */   }
/*     */ 
/*     */   protected TransactionInfo createTransactionIfNecessary(PlatformTransactionManager tm, TransactionAttribute txAttr, final String joinpointIdentification)
/*     */   {
/* 408 */     if ((txAttr != null) && (txAttr.getName() == null)) {
/* 409 */       txAttr = new DelegatingTransactionAttribute(txAttr)
/*     */       {
/*     */         public String getName() {
/* 412 */           return joinpointIdentification;
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/* 417 */     TransactionStatus status = null;
/* 418 */     if (txAttr != null) {
/* 419 */       if (tm != null) {
/* 420 */         status = tm.getTransaction(txAttr);
/*     */       }
/* 423 */       else if (this.logger.isDebugEnabled()) {
/* 424 */         this.logger.debug(new StringBuilder().append("Skipping transactional joinpoint [").append(joinpointIdentification).append("] because no transaction manager has been configured").toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 429 */     return prepareTransactionInfo(tm, txAttr, joinpointIdentification, status);
/*     */   }
/*     */ 
/*     */   protected TransactionInfo prepareTransactionInfo(PlatformTransactionManager tm, TransactionAttribute txAttr, String joinpointIdentification, TransactionStatus status)
/*     */   {
/* 443 */     TransactionInfo txInfo = new TransactionInfo(tm, txAttr, joinpointIdentification);
/* 444 */     if (txAttr != null)
/*     */     {
/* 446 */       if (this.logger.isTraceEnabled()) {
/* 447 */         this.logger.trace(new StringBuilder().append("Getting transaction for [").append(txInfo.getJoinpointIdentification()).append("]").toString());
/*     */       }
/*     */ 
/* 450 */       txInfo.newTransactionStatus(status);
/*     */     }
/* 456 */     else if (this.logger.isTraceEnabled()) {
/* 457 */       this.logger.trace(new StringBuilder().append("Don't need to create transaction for [").append(joinpointIdentification).append("]: This method isn't transactional.").toString());
/*     */     }
/*     */ 
/* 464 */     txInfo.bindToThread();
/* 465 */     return txInfo;
/*     */   }
/*     */ 
/*     */   protected void commitTransactionAfterReturning(TransactionInfo txInfo)
/*     */   {
/* 474 */     if ((txInfo != null) && (txInfo.hasTransaction())) {
/* 475 */       if (this.logger.isTraceEnabled()) {
/* 476 */         this.logger.trace(new StringBuilder().append("Completing transaction for [").append(txInfo.getJoinpointIdentification()).append("]").toString());
/*     */       }
/* 478 */       txInfo.getTransactionManager().commit(txInfo.getTransactionStatus());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void completeTransactionAfterThrowing(TransactionInfo txInfo, Throwable ex)
/*     */   {
/* 489 */     if ((txInfo != null) && (txInfo.hasTransaction())) {
/* 490 */       if (this.logger.isTraceEnabled()) {
/* 491 */         this.logger.trace(new StringBuilder().append("Completing transaction for [").append(txInfo.getJoinpointIdentification()).append("] after exception: ").append(ex).toString());
/*     */       }
/*     */ 
/* 494 */       if (txInfo.transactionAttribute.rollbackOn(ex)) {
/*     */         try {
/* 496 */           txInfo.getTransactionManager().rollback(txInfo.getTransactionStatus());
/*     */         }
/*     */         catch (TransactionSystemException ex2) {
/* 499 */           this.logger.error("Application exception overridden by rollback exception", ex);
/* 500 */           ex2.initApplicationException(ex);
/* 501 */           throw ex2;
/*     */         }
/*     */         catch (RuntimeException ex2) {
/* 504 */           this.logger.error("Application exception overridden by rollback exception", ex);
/* 505 */           throw ex2;
/*     */         }
/*     */         catch (Error err) {
/* 508 */           this.logger.error("Application exception overridden by rollback error", ex);
/* 509 */           throw err;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*     */         try
/*     */         {
/* 516 */           txInfo.getTransactionManager().commit(txInfo.getTransactionStatus());
/*     */         }
/*     */         catch (TransactionSystemException ex2) {
/* 519 */           this.logger.error("Application exception overridden by commit exception", ex);
/* 520 */           ex2.initApplicationException(ex);
/* 521 */           throw ex2;
/*     */         }
/*     */         catch (RuntimeException ex2) {
/* 524 */           this.logger.error("Application exception overridden by commit exception", ex);
/* 525 */           throw ex2;
/*     */         }
/*     */         catch (Error err) {
/* 528 */           this.logger.error("Application exception overridden by commit error", ex);
/* 529 */           throw err;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void cleanupTransactionInfo(TransactionInfo txInfo)
/*     */   {
/* 541 */     if (txInfo != null)
/* 542 */       txInfo.restoreThreadLocalStatus();
/*     */   }
/*     */ 
/*     */   private static class ThrowableHolderException extends RuntimeException
/*     */   {
/*     */     public ThrowableHolderException(Throwable throwable)
/*     */     {
/* 658 */       super();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 663 */       return getCause().toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ThrowableHolder
/*     */   {
/*     */     private final Throwable throwable;
/*     */ 
/*     */     public ThrowableHolder(Throwable throwable)
/*     */     {
/* 641 */       this.throwable = throwable;
/*     */     }
/*     */ 
/*     */     public final Throwable getThrowable() {
/* 645 */       return this.throwable;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static abstract interface InvocationCallback
/*     */   {
/*     */     public abstract Object proceedWithInvocation()
/*     */       throws Throwable;
/*     */   }
/*     */ 
/*     */   protected final class TransactionInfo
/*     */   {
/*     */     private final PlatformTransactionManager transactionManager;
/*     */     private final TransactionAttribute transactionAttribute;
/*     */     private final String joinpointIdentification;
/*     */     private TransactionStatus transactionStatus;
/*     */     private TransactionInfo oldTransactionInfo;
/*     */ 
/*     */     public TransactionInfo(PlatformTransactionManager transactionManager, TransactionAttribute transactionAttribute, String joinpointIdentification)
/*     */     {
/* 565 */       this.transactionManager = transactionManager;
/* 566 */       this.transactionAttribute = transactionAttribute;
/* 567 */       this.joinpointIdentification = joinpointIdentification;
/*     */     }
/*     */ 
/*     */     public PlatformTransactionManager getTransactionManager() {
/* 571 */       return this.transactionManager;
/*     */     }
/*     */ 
/*     */     public TransactionAttribute getTransactionAttribute() {
/* 575 */       return this.transactionAttribute;
/*     */     }
/*     */ 
/*     */     public String getJoinpointIdentification()
/*     */     {
/* 583 */       return this.joinpointIdentification;
/*     */     }
/*     */ 
/*     */     public void newTransactionStatus(TransactionStatus status) {
/* 587 */       this.transactionStatus = status;
/*     */     }
/*     */ 
/*     */     public TransactionStatus getTransactionStatus() {
/* 591 */       return this.transactionStatus;
/*     */     }
/*     */ 
/*     */     public boolean hasTransaction()
/*     */     {
/* 599 */       return this.transactionStatus != null;
/*     */     }
/*     */ 
/*     */     private void bindToThread()
/*     */     {
/* 605 */       this.oldTransactionInfo = ((TransactionInfo)TransactionAspectSupport.transactionInfoHolder.get());
/* 606 */       TransactionAspectSupport.transactionInfoHolder.set(this);
/*     */     }
/*     */ 
/*     */     private void restoreThreadLocalStatus()
/*     */     {
/* 612 */       TransactionAspectSupport.transactionInfoHolder.set(this.oldTransactionInfo);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 617 */       return this.transactionAttribute.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionAspectSupport
 * JD-Core Version:    0.6.2
 */