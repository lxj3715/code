package org.springframework.transaction.interceptor;

import org.springframework.transaction.TransactionDefinition;

public abstract interface TransactionAttribute extends TransactionDefinition
{
  public abstract String getQualifier();

  public abstract boolean rollbackOn(Throwable paramThrowable);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionAttribute
 * JD-Core Version:    0.6.2
 */