/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.List;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class TransactionAttributeEditor extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text)
/*    */     throws IllegalArgumentException
/*    */   {
/* 52 */     if (StringUtils.hasLength(text))
/*    */     {
/* 54 */       String[] tokens = StringUtils.commaDelimitedListToStringArray(text);
/* 55 */       RuleBasedTransactionAttribute attr = new RuleBasedTransactionAttribute();
/* 56 */       for (int i = 0; i < tokens.length; i++)
/*    */       {
/* 58 */         String token = StringUtils.trimWhitespace(tokens[i].trim());
/*    */ 
/* 60 */         if (StringUtils.containsWhitespace(token)) {
/* 61 */           throw new IllegalArgumentException("Transaction attribute token contains illegal whitespace: [" + token + "]");
/*    */         }
/*    */ 
/* 65 */         if (token.startsWith("PROPAGATION_")) {
/* 66 */           attr.setPropagationBehaviorName(token);
/*    */         }
/* 68 */         else if (token.startsWith("ISOLATION_")) {
/* 69 */           attr.setIsolationLevelName(token);
/*    */         }
/* 71 */         else if (token.startsWith("timeout_")) {
/* 72 */           String value = token.substring("timeout_".length());
/* 73 */           attr.setTimeout(Integer.parseInt(value));
/*    */         }
/* 75 */         else if (token.equals("readOnly")) {
/* 76 */           attr.setReadOnly(true);
/*    */         }
/* 78 */         else if (token.startsWith("+")) {
/* 79 */           attr.getRollbackRules().add(new NoRollbackRuleAttribute(token.substring(1)));
/*    */         }
/* 81 */         else if (token.startsWith("-")) {
/* 82 */           attr.getRollbackRules().add(new RollbackRuleAttribute(token.substring(1)));
/*    */         }
/*    */         else {
/* 85 */           throw new IllegalArgumentException("Invalid transaction attribute token: [" + token + "]");
/*    */         }
/*    */       }
/* 88 */       setValue(attr);
/*    */     }
/*    */     else {
/* 91 */       setValue(null);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionAttributeEditor
 * JD-Core Version:    0.6.2
 */