package org.springframework.transaction.interceptor;

import java.lang.reflect.Method;

public abstract interface TransactionAttributeSource
{
  public abstract TransactionAttribute getTransactionAttribute(Method paramMethod, Class<?> paramClass);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionAttributeSource
 * JD-Core Version:    0.6.2
 */