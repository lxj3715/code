/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractPointcutAdvisor;
/*    */ 
/*    */ public class TransactionAttributeSourceAdvisor extends AbstractPointcutAdvisor
/*    */ {
/*    */   private TransactionInterceptor transactionInterceptor;
/* 43 */   private final TransactionAttributeSourcePointcut pointcut = new TransactionAttributeSourcePointcut()
/*    */   {
/*    */     protected TransactionAttributeSource getTransactionAttributeSource() {
/* 46 */       return TransactionAttributeSourceAdvisor.this.transactionInterceptor != null ? TransactionAttributeSourceAdvisor.this.transactionInterceptor.getTransactionAttributeSource() : null;
/*    */     }
/* 43 */   };
/*    */ 
/*    */   public TransactionAttributeSourceAdvisor()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TransactionAttributeSourceAdvisor(TransactionInterceptor interceptor)
/*    */   {
/* 62 */     setTransactionInterceptor(interceptor);
/*    */   }
/*    */ 
/*    */   public void setTransactionInterceptor(TransactionInterceptor interceptor)
/*    */   {
/* 70 */     this.transactionInterceptor = interceptor;
/*    */   }
/*    */ 
/*    */   public void setClassFilter(ClassFilter classFilter)
/*    */   {
/* 78 */     this.pointcut.setClassFilter(classFilter);
/*    */   }
/*    */ 
/*    */   public Advice getAdvice()
/*    */   {
/* 84 */     return this.transactionInterceptor;
/*    */   }
/*    */ 
/*    */   public Pointcut getPointcut()
/*    */   {
/* 89 */     return this.pointcut;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionAttributeSourceAdvisor
 * JD-Core Version:    0.6.2
 */