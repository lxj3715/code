/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.propertyeditors.PropertiesEditor;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class TransactionAttributeSourceEditor extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text)
/*    */     throws IllegalArgumentException
/*    */   {
/* 53 */     MethodMapTransactionAttributeSource source = new MethodMapTransactionAttributeSource();
/* 54 */     if (StringUtils.hasLength(text))
/*    */     {
/* 56 */       PropertiesEditor propertiesEditor = new PropertiesEditor();
/* 57 */       propertiesEditor.setAsText(text);
/* 58 */       Properties props = (Properties)propertiesEditor.getValue();
/*    */ 
/* 61 */       TransactionAttributeEditor tae = new TransactionAttributeEditor();
/* 62 */       Enumeration propNames = props.propertyNames();
/* 63 */       while (propNames.hasMoreElements()) {
/* 64 */         String name = (String)propNames.nextElement();
/* 65 */         String value = props.getProperty(name);
/*    */ 
/* 67 */         tae.setAsText(value);
/* 68 */         TransactionAttribute attr = (TransactionAttribute)tae.getValue();
/*    */ 
/* 70 */         source.addTransactionalMethod(name, attr);
/*    */       }
/*    */     }
/* 73 */     setValue(source);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionAttributeSourceEditor
 * JD-Core Version:    0.6.2
 */