/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.support.StaticMethodMatcherPointcut;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ abstract class TransactionAttributeSourcePointcut extends StaticMethodMatcherPointcut
/*    */   implements Serializable
/*    */ {
/*    */   public boolean matches(Method method, Class<?> targetClass)
/*    */   {
/* 37 */     TransactionAttributeSource tas = getTransactionAttributeSource();
/* 38 */     return (tas == null) || (tas.getTransactionAttribute(method, targetClass) != null);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 43 */     if (this == other) {
/* 44 */       return true;
/*    */     }
/* 46 */     if (!(other instanceof TransactionAttributeSourcePointcut)) {
/* 47 */       return false;
/*    */     }
/* 49 */     TransactionAttributeSourcePointcut otherPc = (TransactionAttributeSourcePointcut)other;
/* 50 */     return ObjectUtils.nullSafeEquals(getTransactionAttributeSource(), otherPc.getTransactionAttributeSource());
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 55 */     return TransactionAttributeSourcePointcut.class.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 60 */     return getClass().getName() + ": " + getTransactionAttributeSource();
/*    */   }
/*    */ 
/*    */   protected abstract TransactionAttributeSource getTransactionAttributeSource();
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionAttributeSourcePointcut
 * JD-Core Version:    0.6.2
 */