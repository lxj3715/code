/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Properties;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ 
/*     */ public class TransactionInterceptor extends TransactionAspectSupport
/*     */   implements MethodInterceptor, Serializable
/*     */ {
/*     */   public TransactionInterceptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TransactionInterceptor(PlatformTransactionManager ptm, Properties attributes)
/*     */   {
/*  70 */     setTransactionManager(ptm);
/*  71 */     setTransactionAttributes(attributes);
/*     */   }
/*     */ 
/*     */   public TransactionInterceptor(PlatformTransactionManager ptm, TransactionAttributeSource tas)
/*     */   {
/*  82 */     setTransactionManager(ptm);
/*  83 */     setTransactionAttributeSource(tas);
/*     */   }
/*     */ 
/*     */   public Object invoke(final MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  92 */     Class targetClass = invocation.getThis() != null ? AopUtils.getTargetClass(invocation.getThis()) : null;
/*     */ 
/*  95 */     return invokeWithinTransaction(invocation.getMethod(), targetClass, new TransactionAspectSupport.InvocationCallback()
/*     */     {
/*     */       public Object proceedWithInvocation() throws Throwable {
/*  98 */         return invocation.proceed();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream oos)
/*     */     throws IOException
/*     */   {
/* 110 */     oos.defaultWriteObject();
/*     */ 
/* 113 */     oos.writeObject(getTransactionManagerBeanName());
/* 114 */     oos.writeObject(getTransactionManager());
/* 115 */     oos.writeObject(getTransactionAttributeSource());
/* 116 */     oos.writeObject(getBeanFactory());
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException
/*     */   {
/* 121 */     ois.defaultReadObject();
/*     */ 
/* 126 */     setTransactionManagerBeanName((String)ois.readObject());
/* 127 */     setTransactionManager((PlatformTransactionManager)ois.readObject());
/* 128 */     setTransactionAttributeSource((TransactionAttributeSource)ois.readObject());
/* 129 */     setBeanFactory((BeanFactory)ois.readObject());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionInterceptor
 * JD-Core Version:    0.6.2
 */