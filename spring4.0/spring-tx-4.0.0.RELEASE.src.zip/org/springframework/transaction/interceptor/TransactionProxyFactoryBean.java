/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.framework.AbstractSingletonProxyFactoryBean;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ 
/*     */ public class TransactionProxyFactoryBean extends AbstractSingletonProxyFactoryBean
/*     */   implements BeanFactoryAware
/*     */ {
/* 118 */   private final TransactionInterceptor transactionInterceptor = new TransactionInterceptor();
/*     */   private Pointcut pointcut;
/*     */ 
/*     */   public void setTransactionManager(PlatformTransactionManager transactionManager)
/*     */   {
/* 129 */     this.transactionInterceptor.setTransactionManager(transactionManager);
/*     */   }
/*     */ 
/*     */   public void setTransactionAttributes(Properties transactionAttributes)
/*     */   {
/* 146 */     this.transactionInterceptor.setTransactionAttributes(transactionAttributes);
/*     */   }
/*     */ 
/*     */   public void setTransactionAttributeSource(TransactionAttributeSource transactionAttributeSource)
/*     */   {
/* 161 */     this.transactionInterceptor.setTransactionAttributeSource(transactionAttributeSource);
/*     */   }
/*     */ 
/*     */   public void setPointcut(Pointcut pointcut)
/*     */   {
/* 172 */     this.pointcut = pointcut;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 184 */     this.transactionInterceptor.setBeanFactory(beanFactory);
/*     */   }
/*     */ 
/*     */   protected Object createMainInterceptor()
/*     */   {
/* 193 */     this.transactionInterceptor.afterPropertiesSet();
/* 194 */     if (this.pointcut != null) {
/* 195 */       return new DefaultPointcutAdvisor(this.pointcut, this.transactionInterceptor);
/*     */     }
/*     */ 
/* 199 */     return new TransactionAttributeSourceAdvisor(this.transactionInterceptor);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionProxyFactoryBean
 * JD-Core Version:    0.6.2
 */