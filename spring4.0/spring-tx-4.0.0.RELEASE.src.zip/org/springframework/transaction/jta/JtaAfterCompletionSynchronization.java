/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.transaction.Synchronization;
/*    */ import org.springframework.transaction.support.TransactionSynchronization;
/*    */ import org.springframework.transaction.support.TransactionSynchronizationUtils;
/*    */ 
/*    */ public class JtaAfterCompletionSynchronization
/*    */   implements Synchronization
/*    */ {
/*    */   private final List<TransactionSynchronization> synchronizations;
/*    */ 
/*    */   public JtaAfterCompletionSynchronization(List<TransactionSynchronization> synchronizations)
/*    */   {
/* 48 */     this.synchronizations = synchronizations;
/*    */   }
/*    */ 
/*    */   public void beforeCompletion()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void afterCompletion(int status)
/*    */   {
/* 58 */     switch (status) {
/*    */     case 3:
/*    */       try {
/* 61 */         TransactionSynchronizationUtils.invokeAfterCommit(this.synchronizations);
/*    */ 
/* 64 */         TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 0); } finally { TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 0); }
/*    */ 
/*    */ 
/*    */     case 4:
/* 69 */       TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 1);
/*    */ 
/* 71 */       break;
/*    */     }
/* 73 */     TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 2);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.JtaAfterCompletionSynchronization
 * JD-Core Version:    0.6.2
 */