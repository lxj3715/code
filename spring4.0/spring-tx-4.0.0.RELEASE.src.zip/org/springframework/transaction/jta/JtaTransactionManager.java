/*      */ package org.springframework.transaction.jta;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import javax.naming.NamingException;
/*      */ import javax.transaction.HeuristicMixedException;
/*      */ import javax.transaction.HeuristicRollbackException;
/*      */ import javax.transaction.InvalidTransactionException;
/*      */ import javax.transaction.NotSupportedException;
/*      */ import javax.transaction.RollbackException;
/*      */ import javax.transaction.SystemException;
/*      */ import javax.transaction.Transaction;
/*      */ import javax.transaction.TransactionManager;
/*      */ import javax.transaction.TransactionSynchronizationRegistry;
/*      */ import javax.transaction.UserTransaction;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.jndi.JndiTemplate;
/*      */ import org.springframework.transaction.CannotCreateTransactionException;
/*      */ import org.springframework.transaction.HeuristicCompletionException;
/*      */ import org.springframework.transaction.IllegalTransactionStateException;
/*      */ import org.springframework.transaction.InvalidIsolationLevelException;
/*      */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*      */ import org.springframework.transaction.TransactionDefinition;
/*      */ import org.springframework.transaction.TransactionSuspensionNotSupportedException;
/*      */ import org.springframework.transaction.TransactionSystemException;
/*      */ import org.springframework.transaction.UnexpectedRollbackException;
/*      */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*      */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*      */ import org.springframework.transaction.support.TransactionSynchronization;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ public class JtaTransactionManager extends AbstractPlatformTransactionManager
/*      */   implements TransactionFactory, InitializingBean, Serializable
/*      */ {
/*      */   public static final String DEFAULT_USER_TRANSACTION_NAME = "java:comp/UserTransaction";
/*  137 */   public static final String[] FALLBACK_TRANSACTION_MANAGER_NAMES = { "java:comp/TransactionManager", "java:appserver/TransactionManager", "java:pm/TransactionManager", "java:/TransactionManager" };
/*      */   public static final String DEFAULT_TRANSACTION_SYNCHRONIZATION_REGISTRY_NAME = "java:comp/TransactionSynchronizationRegistry";
/*  149 */   private transient JndiTemplate jndiTemplate = new JndiTemplate();
/*      */   private transient UserTransaction userTransaction;
/*      */   private String userTransactionName;
/*  155 */   private boolean autodetectUserTransaction = true;
/*      */ 
/*  157 */   private boolean cacheUserTransaction = true;
/*      */ 
/*  159 */   private boolean userTransactionObtainedFromJndi = false;
/*      */   private transient TransactionManager transactionManager;
/*      */   private String transactionManagerName;
/*  165 */   private boolean autodetectTransactionManager = true;
/*      */   private transient TransactionSynchronizationRegistry transactionSynchronizationRegistry;
/*      */   private String transactionSynchronizationRegistryName;
/*  171 */   private boolean autodetectTransactionSynchronizationRegistry = true;
/*      */ 
/*  173 */   private boolean allowCustomIsolationLevels = false;
/*      */ 
/*      */   public JtaTransactionManager()
/*      */   {
/*  186 */     setNestedTransactionAllowed(true);
/*      */   }
/*      */ 
/*      */   public JtaTransactionManager(UserTransaction userTransaction)
/*      */   {
/*  194 */     this();
/*  195 */     Assert.notNull(userTransaction, "UserTransaction must not be null");
/*  196 */     this.userTransaction = userTransaction;
/*      */   }
/*      */ 
/*      */   public JtaTransactionManager(UserTransaction userTransaction, TransactionManager transactionManager)
/*      */   {
/*  205 */     this();
/*  206 */     Assert.notNull(userTransaction, "UserTransaction must not be null");
/*  207 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/*  208 */     this.userTransaction = userTransaction;
/*  209 */     this.transactionManager = transactionManager;
/*      */   }
/*      */ 
/*      */   public JtaTransactionManager(TransactionManager transactionManager)
/*      */   {
/*  217 */     this();
/*  218 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/*  219 */     this.transactionManager = transactionManager;
/*  220 */     this.userTransaction = buildUserTransaction(transactionManager);
/*      */   }
/*      */ 
/*      */   public void setJndiTemplate(JndiTemplate jndiTemplate)
/*      */   {
/*  229 */     Assert.notNull(jndiTemplate, "JndiTemplate must not be null");
/*  230 */     this.jndiTemplate = jndiTemplate;
/*      */   }
/*      */ 
/*      */   public JndiTemplate getJndiTemplate()
/*      */   {
/*  237 */     return this.jndiTemplate;
/*      */   }
/*      */ 
/*      */   public void setJndiEnvironment(Properties jndiEnvironment)
/*      */   {
/*  246 */     this.jndiTemplate = new JndiTemplate(jndiEnvironment);
/*      */   }
/*      */ 
/*      */   public Properties getJndiEnvironment()
/*      */   {
/*  253 */     return this.jndiTemplate.getEnvironment();
/*      */   }
/*      */ 
/*      */   public void setUserTransaction(UserTransaction userTransaction)
/*      */   {
/*  265 */     this.userTransaction = userTransaction;
/*      */   }
/*      */ 
/*      */   public UserTransaction getUserTransaction()
/*      */   {
/*  272 */     return this.userTransaction;
/*      */   }
/*      */ 
/*      */   public void setUserTransactionName(String userTransactionName)
/*      */   {
/*  284 */     this.userTransactionName = userTransactionName;
/*      */   }
/*      */ 
/*      */   public void setAutodetectUserTransaction(boolean autodetectUserTransaction)
/*      */   {
/*  298 */     this.autodetectUserTransaction = autodetectUserTransaction;
/*      */   }
/*      */ 
/*      */   public void setCacheUserTransaction(boolean cacheUserTransaction)
/*      */   {
/*  314 */     this.cacheUserTransaction = cacheUserTransaction;
/*      */   }
/*      */ 
/*      */   public void setTransactionManager(TransactionManager transactionManager)
/*      */   {
/*  328 */     this.transactionManager = transactionManager;
/*      */   }
/*      */ 
/*      */   public TransactionManager getTransactionManager()
/*      */   {
/*  335 */     return this.transactionManager;
/*      */   }
/*      */ 
/*      */   public void setTransactionManagerName(String transactionManagerName)
/*      */   {
/*  349 */     this.transactionManagerName = transactionManagerName;
/*      */   }
/*      */ 
/*      */   public void setAutodetectTransactionManager(boolean autodetectTransactionManager)
/*      */   {
/*  365 */     this.autodetectTransactionManager = autodetectTransactionManager;
/*      */   }
/*      */ 
/*      */   public void setTransactionSynchronizationRegistry(TransactionSynchronizationRegistry transactionSynchronizationRegistry)
/*      */   {
/*  380 */     this.transactionSynchronizationRegistry = transactionSynchronizationRegistry;
/*      */   }
/*      */ 
/*      */   public TransactionSynchronizationRegistry getTransactionSynchronizationRegistry()
/*      */   {
/*  387 */     return this.transactionSynchronizationRegistry;
/*      */   }
/*      */ 
/*      */   public void setTransactionSynchronizationRegistryName(String transactionSynchronizationRegistryName)
/*      */   {
/*  398 */     this.transactionSynchronizationRegistryName = transactionSynchronizationRegistryName;
/*      */   }
/*      */ 
/*      */   public void setAutodetectTransactionSynchronizationRegistry(boolean autodetectTransactionSynchronizationRegistry)
/*      */   {
/*  412 */     this.autodetectTransactionSynchronizationRegistry = autodetectTransactionSynchronizationRegistry;
/*      */   }
/*      */ 
/*      */   public void setAllowCustomIsolationLevels(boolean allowCustomIsolationLevels)
/*      */   {
/*  425 */     this.allowCustomIsolationLevels = allowCustomIsolationLevels;
/*      */   }
/*      */ 
/*      */   public void afterPropertiesSet()
/*      */     throws TransactionSystemException
/*      */   {
/*  435 */     initUserTransactionAndTransactionManager();
/*  436 */     checkUserTransactionAndTransactionManager();
/*  437 */     initTransactionSynchronizationRegistry();
/*      */   }
/*      */ 
/*      */   protected void initUserTransactionAndTransactionManager()
/*      */     throws TransactionSystemException
/*      */   {
/*  445 */     if (this.userTransaction == null)
/*      */     {
/*  447 */       if (StringUtils.hasLength(this.userTransactionName)) {
/*  448 */         this.userTransaction = lookupUserTransaction(this.userTransactionName);
/*  449 */         this.userTransactionObtainedFromJndi = true;
/*      */       }
/*      */       else {
/*  452 */         this.userTransaction = retrieveUserTransaction();
/*  453 */         if ((this.userTransaction == null) && (this.autodetectUserTransaction))
/*      */         {
/*  455 */           this.userTransaction = findUserTransaction();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  460 */     if (this.transactionManager == null)
/*      */     {
/*  462 */       if (StringUtils.hasLength(this.transactionManagerName)) {
/*  463 */         this.transactionManager = lookupTransactionManager(this.transactionManagerName);
/*      */       }
/*      */       else {
/*  466 */         this.transactionManager = retrieveTransactionManager();
/*  467 */         if ((this.transactionManager == null) && (this.autodetectTransactionManager))
/*      */         {
/*  470 */           this.transactionManager = findTransactionManager(this.userTransaction);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  476 */     if ((this.userTransaction == null) && (this.transactionManager != null))
/*  477 */       this.userTransaction = buildUserTransaction(this.transactionManager);
/*      */   }
/*      */ 
/*      */   protected void checkUserTransactionAndTransactionManager()
/*      */     throws IllegalStateException
/*      */   {
/*  488 */     if (this.userTransaction != null) {
/*  489 */       if (this.logger.isInfoEnabled()) {
/*  490 */         this.logger.info("Using JTA UserTransaction: " + this.userTransaction);
/*      */       }
/*      */     }
/*      */     else {
/*  494 */       throw new IllegalStateException("No JTA UserTransaction available - specify either 'userTransaction' or 'userTransactionName' or 'transactionManager' or 'transactionManagerName'");
/*      */     }
/*      */ 
/*  499 */     if (this.transactionManager != null) {
/*  500 */       if (this.logger.isInfoEnabled()) {
/*  501 */         this.logger.info("Using JTA TransactionManager: " + this.transactionManager);
/*      */       }
/*      */     }
/*      */     else
/*  505 */       this.logger.warn("No JTA TransactionManager found: transaction suspension not available");
/*      */   }
/*      */ 
/*      */   protected void initTransactionSynchronizationRegistry()
/*      */   {
/*  516 */     if (this.transactionSynchronizationRegistry == null)
/*      */     {
/*  518 */       if (StringUtils.hasLength(this.transactionSynchronizationRegistryName)) {
/*  519 */         this.transactionSynchronizationRegistry = 
/*  520 */           lookupTransactionSynchronizationRegistry(this.transactionSynchronizationRegistryName);
/*      */       }
/*      */       else
/*      */       {
/*  523 */         this.transactionSynchronizationRegistry = retrieveTransactionSynchronizationRegistry();
/*  524 */         if ((this.transactionSynchronizationRegistry == null) && (this.autodetectTransactionSynchronizationRegistry))
/*      */         {
/*  527 */           this.transactionSynchronizationRegistry = 
/*  528 */             findTransactionSynchronizationRegistry(this.userTransaction, this.transactionManager);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  533 */     if ((this.transactionSynchronizationRegistry != null) && 
/*  534 */       (this.logger.isInfoEnabled()))
/*  535 */       this.logger.info("Using JTA TransactionSynchronizationRegistry: " + this.transactionSynchronizationRegistry);
/*      */   }
/*      */ 
/*      */   protected UserTransaction buildUserTransaction(TransactionManager transactionManager)
/*      */   {
/*  547 */     if ((transactionManager instanceof UserTransaction)) {
/*  548 */       return (UserTransaction)transactionManager;
/*      */     }
/*      */ 
/*  551 */     return new UserTransactionAdapter(transactionManager);
/*      */   }
/*      */ 
/*      */   protected UserTransaction lookupUserTransaction(String userTransactionName)
/*      */     throws TransactionSystemException
/*      */   {
/*      */     try
/*      */     {
/*  568 */       if (this.logger.isDebugEnabled()) {
/*  569 */         this.logger.debug("Retrieving JTA UserTransaction from JNDI location [" + userTransactionName + "]");
/*      */       }
/*  571 */       return (UserTransaction)getJndiTemplate().lookup(userTransactionName, UserTransaction.class);
/*      */     }
/*      */     catch (NamingException ex) {
/*  574 */       throw new TransactionSystemException("JTA UserTransaction is not available at JNDI location [" + userTransactionName + "]", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected TransactionManager lookupTransactionManager(String transactionManagerName)
/*      */     throws TransactionSystemException
/*      */   {
/*      */     try
/*      */     {
/*  592 */       if (this.logger.isDebugEnabled()) {
/*  593 */         this.logger.debug("Retrieving JTA TransactionManager from JNDI location [" + transactionManagerName + "]");
/*      */       }
/*  595 */       return (TransactionManager)getJndiTemplate().lookup(transactionManagerName, TransactionManager.class);
/*      */     }
/*      */     catch (NamingException ex) {
/*  598 */       throw new TransactionSystemException("JTA TransactionManager is not available at JNDI location [" + transactionManagerName + "]", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected TransactionSynchronizationRegistry lookupTransactionSynchronizationRegistry(String registryName)
/*      */     throws TransactionSystemException
/*      */   {
/*      */     try
/*      */     {
/*  615 */       if (this.logger.isDebugEnabled()) {
/*  616 */         this.logger.debug("Retrieving JTA TransactionSynchronizationRegistry from JNDI location [" + registryName + "]");
/*      */       }
/*  618 */       return (TransactionSynchronizationRegistry)getJndiTemplate().lookup(registryName, TransactionSynchronizationRegistry.class);
/*      */     }
/*      */     catch (NamingException ex) {
/*  621 */       throw new TransactionSystemException("JTA TransactionSynchronizationRegistry is not available at JNDI location [" + registryName + "]", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected UserTransaction retrieveUserTransaction()
/*      */     throws TransactionSystemException
/*      */   {
/*  636 */     return null;
/*      */   }
/*      */ 
/*      */   protected TransactionManager retrieveTransactionManager()
/*      */     throws TransactionSystemException
/*      */   {
/*  649 */     return null;
/*      */   }
/*      */ 
/*      */   protected TransactionSynchronizationRegistry retrieveTransactionSynchronizationRegistry()
/*      */     throws TransactionSystemException
/*      */   {
/*  661 */     return null;
/*      */   }
/*      */ 
/*      */   protected UserTransaction findUserTransaction()
/*      */   {
/*  671 */     String jndiName = "java:comp/UserTransaction";
/*      */     try {
/*  673 */       UserTransaction ut = (UserTransaction)getJndiTemplate().lookup(jndiName, UserTransaction.class);
/*  674 */       if (this.logger.isDebugEnabled()) {
/*  675 */         this.logger.debug("JTA UserTransaction found at default JNDI location [" + jndiName + "]");
/*      */       }
/*  677 */       this.userTransactionObtainedFromJndi = true;
/*  678 */       return ut;
/*      */     }
/*      */     catch (NamingException ex) {
/*  681 */       if (this.logger.isDebugEnabled())
/*  682 */         this.logger.debug("No JTA UserTransaction found at default JNDI location [" + jndiName + "]", ex);
/*      */     }
/*  684 */     return null;
/*      */   }
/*      */ 
/*      */   protected TransactionManager findTransactionManager(UserTransaction ut)
/*      */   {
/*  697 */     if ((ut instanceof TransactionManager)) {
/*  698 */       if (this.logger.isDebugEnabled()) {
/*  699 */         this.logger.debug("JTA UserTransaction object [" + ut + "] implements TransactionManager");
/*      */       }
/*  701 */       return (TransactionManager)ut;
/*      */     }
/*      */ 
/*  705 */     for (String jndiName : FALLBACK_TRANSACTION_MANAGER_NAMES) {
/*      */       try {
/*  707 */         TransactionManager tm = (TransactionManager)getJndiTemplate().lookup(jndiName, TransactionManager.class);
/*  708 */         if (this.logger.isDebugEnabled()) {
/*  709 */           this.logger.debug("JTA TransactionManager found at fallback JNDI location [" + jndiName + "]");
/*      */         }
/*  711 */         return tm;
/*      */       }
/*      */       catch (NamingException ex) {
/*  714 */         if (this.logger.isDebugEnabled()) {
/*  715 */           this.logger.debug("No JTA TransactionManager found at fallback JNDI location [" + jndiName + "]", ex);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  721 */     return null;
/*      */   }
/*      */ 
/*      */   protected TransactionSynchronizationRegistry findTransactionSynchronizationRegistry(UserTransaction ut, TransactionManager tm)
/*      */     throws TransactionSystemException
/*      */   {
/*  738 */     if (this.userTransactionObtainedFromJndi)
/*      */     {
/*  741 */       String jndiName = "java:comp/TransactionSynchronizationRegistry";
/*      */       try {
/*  743 */         TransactionSynchronizationRegistry tsr = (TransactionSynchronizationRegistry)getJndiTemplate().lookup(jndiName, TransactionSynchronizationRegistry.class);
/*  744 */         if (this.logger.isDebugEnabled()) {
/*  745 */           this.logger.debug("JTA TransactionSynchronizationRegistry found at default JNDI location [" + jndiName + "]");
/*      */         }
/*  747 */         return tsr;
/*      */       }
/*      */       catch (NamingException ex) {
/*  750 */         if (this.logger.isDebugEnabled()) {
/*  751 */           this.logger.debug("No JTA TransactionSynchronizationRegistry found at default JNDI location [" + jndiName + "]", ex);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  757 */     if ((ut instanceof TransactionSynchronizationRegistry)) {
/*  758 */       return (TransactionSynchronizationRegistry)ut;
/*      */     }
/*  760 */     if ((tm instanceof TransactionSynchronizationRegistry)) {
/*  761 */       return (TransactionSynchronizationRegistry)tm;
/*      */     }
/*      */ 
/*  764 */     return null;
/*      */   }
/*      */ 
/*      */   protected Object doGetTransaction()
/*      */   {
/*  780 */     UserTransaction ut = getUserTransaction();
/*  781 */     if (ut == null) {
/*  782 */       throw new CannotCreateTransactionException("No JTA UserTransaction available - programmatic PlatformTransactionManager.getTransaction usage not supported");
/*      */     }
/*      */ 
/*  785 */     if (!this.cacheUserTransaction) {
/*  786 */       ut = lookupUserTransaction(this.userTransactionName != null ? this.userTransactionName : "java:comp/UserTransaction");
/*      */     }
/*      */ 
/*  789 */     return doGetJtaTransaction(ut);
/*      */   }
/*      */ 
/*      */   protected JtaTransactionObject doGetJtaTransaction(UserTransaction ut)
/*      */   {
/*  800 */     return new JtaTransactionObject(ut);
/*      */   }
/*      */ 
/*      */   protected boolean isExistingTransaction(Object transaction)
/*      */   {
/*  805 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*      */     try {
/*  807 */       return txObject.getUserTransaction().getStatus() != 6;
/*      */     }
/*      */     catch (SystemException ex) {
/*  810 */       throw new TransactionSystemException("JTA failure on getStatus", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected boolean useSavepointForNestedTransaction()
/*      */   {
/*  824 */     return false;
/*      */   }
/*      */ 
/*      */   protected void doBegin(Object transaction, TransactionDefinition definition)
/*      */   {
/*  830 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*      */     try {
/*  832 */       doJtaBegin(txObject, definition);
/*      */     }
/*      */     catch (NotSupportedException ex)
/*      */     {
/*  836 */       throw new NestedTransactionNotSupportedException("JTA implementation does not support nested transactions", ex);
/*      */     }
/*      */     catch (UnsupportedOperationException ex)
/*      */     {
/*  841 */       throw new NestedTransactionNotSupportedException("JTA implementation does not support nested transactions", ex);
/*      */     }
/*      */     catch (SystemException ex)
/*      */     {
/*  845 */       throw new CannotCreateTransactionException("JTA failure on begin", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void doJtaBegin(JtaTransactionObject txObject, TransactionDefinition definition)
/*      */     throws NotSupportedException, SystemException
/*      */   {
/*  872 */     applyIsolationLevel(txObject, definition.getIsolationLevel());
/*  873 */     int timeout = determineTimeout(definition);
/*  874 */     applyTimeout(txObject, timeout);
/*  875 */     txObject.getUserTransaction().begin();
/*      */   }
/*      */ 
/*      */   protected void applyIsolationLevel(JtaTransactionObject txObject, int isolationLevel)
/*      */     throws InvalidIsolationLevelException, SystemException
/*      */   {
/*  895 */     if ((!this.allowCustomIsolationLevels) && (isolationLevel != -1))
/*  896 */       throw new InvalidIsolationLevelException("JtaTransactionManager does not support custom isolation levels by default - switch 'allowCustomIsolationLevels' to 'true'");
/*      */   }
/*      */ 
/*      */   protected void applyTimeout(JtaTransactionObject txObject, int timeout)
/*      */     throws SystemException
/*      */   {
/*  913 */     if (timeout > -1)
/*  914 */       txObject.getUserTransaction().setTransactionTimeout(timeout);
/*      */   }
/*      */ 
/*      */   protected Object doSuspend(Object transaction)
/*      */   {
/*  921 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*      */     try {
/*  923 */       return doJtaSuspend(txObject);
/*      */     }
/*      */     catch (SystemException ex) {
/*  926 */       throw new TransactionSystemException("JTA failure on suspend", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Object doJtaSuspend(JtaTransactionObject txObject)
/*      */     throws SystemException
/*      */   {
/*  940 */     if (getTransactionManager() == null) {
/*  941 */       throw new TransactionSuspensionNotSupportedException("JtaTransactionManager needs a JTA TransactionManager for suspending a transaction: specify the 'transactionManager' or 'transactionManagerName' property");
/*      */     }
/*      */ 
/*  945 */     return getTransactionManager().suspend();
/*      */   }
/*      */ 
/*      */   protected void doResume(Object transaction, Object suspendedResources)
/*      */   {
/*  950 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*      */     try {
/*  952 */       doJtaResume(txObject, suspendedResources);
/*      */     }
/*      */     catch (InvalidTransactionException ex) {
/*  955 */       throw new IllegalTransactionStateException("Tried to resume invalid JTA transaction", ex);
/*      */     }
/*      */     catch (IllegalStateException ex) {
/*  958 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*      */     }
/*      */     catch (SystemException ex) {
/*  961 */       throw new TransactionSystemException("JTA failure on resume", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void doJtaResume(JtaTransactionObject txObject, Object suspendedTransaction)
/*      */     throws InvalidTransactionException, SystemException
/*      */   {
/*  978 */     if (getTransactionManager() == null) {
/*  979 */       throw new TransactionSuspensionNotSupportedException("JtaTransactionManager needs a JTA TransactionManager for suspending a transaction: specify the 'transactionManager' or 'transactionManagerName' property");
/*      */     }
/*      */ 
/*  983 */     getTransactionManager().resume((Transaction)suspendedTransaction);
/*      */   }
/*      */ 
/*      */   protected boolean shouldCommitOnGlobalRollbackOnly()
/*      */   {
/*  993 */     return true;
/*      */   }
/*      */ 
/*      */   protected void doCommit(DefaultTransactionStatus status)
/*      */   {
/*  998 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/*      */     try {
/* 1000 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/* 1001 */       if (jtaStatus == 6)
/*      */       {
/* 1005 */         throw new UnexpectedRollbackException("JTA transaction already completed - probably rolled back");
/*      */       }
/* 1007 */       if (jtaStatus == 4)
/*      */       {
/*      */         try
/*      */         {
/* 1012 */           txObject.getUserTransaction().rollback();
/*      */         }
/*      */         catch (IllegalStateException ex) {
/* 1015 */           if (this.logger.isDebugEnabled()) {
/* 1016 */             this.logger.debug("Rollback failure with transaction already marked as rolled back: " + ex);
/*      */           }
/*      */         }
/* 1019 */         throw new UnexpectedRollbackException("JTA transaction already rolled back (probably due to a timeout)");
/*      */       }
/* 1021 */       txObject.getUserTransaction().commit();
/*      */     }
/*      */     catch (RollbackException ex) {
/* 1024 */       throw new UnexpectedRollbackException("JTA transaction unexpectedly rolled back (maybe due to a timeout)", ex);
/*      */     }
/*      */     catch (HeuristicMixedException ex)
/*      */     {
/* 1028 */       throw new HeuristicCompletionException(3, ex);
/*      */     }
/*      */     catch (HeuristicRollbackException ex) {
/* 1031 */       throw new HeuristicCompletionException(2, ex);
/*      */     }
/*      */     catch (IllegalStateException ex) {
/* 1034 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*      */     }
/*      */     catch (SystemException ex) {
/* 1037 */       throw new TransactionSystemException("JTA failure on commit", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void doRollback(DefaultTransactionStatus status)
/*      */   {
/* 1043 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/*      */     try {
/* 1045 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/* 1046 */       if (jtaStatus != 6) {
/*      */         try {
/* 1048 */           txObject.getUserTransaction().rollback();
/*      */         }
/*      */         catch (IllegalStateException ex) {
/* 1051 */           if (jtaStatus == 4)
/*      */           {
/* 1053 */             if (this.logger.isDebugEnabled()) {
/* 1054 */               this.logger.debug("Rollback failure with transaction already marked as rolled back: " + ex);
/*      */             }
/*      */           }
/*      */           else
/* 1058 */             throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (SystemException ex)
/*      */     {
/* 1064 */       throw new TransactionSystemException("JTA failure on rollback", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void doSetRollbackOnly(DefaultTransactionStatus status)
/*      */   {
/* 1070 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/* 1071 */     if (status.isDebug())
/* 1072 */       this.logger.debug("Setting JTA transaction rollback-only");
/*      */     try
/*      */     {
/* 1075 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/* 1076 */       if ((jtaStatus != 6) && (jtaStatus != 4))
/* 1077 */         txObject.getUserTransaction().setRollbackOnly();
/*      */     }
/*      */     catch (IllegalStateException ex)
/*      */     {
/* 1081 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*      */     }
/*      */     catch (SystemException ex) {
/* 1084 */       throw new TransactionSystemException("JTA failure on setRollbackOnly", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void registerAfterCompletionWithExistingTransaction(Object transaction, List<TransactionSynchronization> synchronizations)
/*      */   {
/* 1093 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/* 1094 */     this.logger.debug("Registering after-completion synchronization with existing JTA transaction");
/*      */     try {
/* 1096 */       doRegisterAfterCompletionWithJtaTransaction(txObject, synchronizations);
/*      */     }
/*      */     catch (SystemException ex) {
/* 1099 */       throw new TransactionSystemException("JTA failure on registerSynchronization", ex);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 1103 */       if (((ex instanceof RollbackException)) || ((ex.getCause() instanceof RollbackException))) {
/* 1104 */         this.logger.debug("Participating in existing JTA transaction that has been marked for rollback: cannot register Spring after-completion callbacks with outer JTA transaction - immediately performing Spring after-completion callbacks with outcome status 'rollback'. Original exception: " + ex);
/*      */ 
/* 1108 */         invokeAfterCompletion(synchronizations, 1);
/*      */       }
/*      */       else {
/* 1111 */         this.logger.debug("Participating in existing JTA transaction, but unexpected internal transaction state encountered: cannot register Spring after-completion callbacks with outer JTA transaction - processing Spring after-completion callbacks with outcome status 'unknown'Original exception: " + ex);
/*      */ 
/* 1115 */         invokeAfterCompletion(synchronizations, 2);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void doRegisterAfterCompletionWithJtaTransaction(JtaTransactionObject txObject, List<TransactionSynchronization> synchronizations)
/*      */     throws RollbackException, SystemException
/*      */   {
/* 1140 */     int jtaStatus = txObject.getUserTransaction().getStatus();
/* 1141 */     if (jtaStatus == 6) {
/* 1142 */       throw new RollbackException("JTA transaction already completed - probably rolled back");
/*      */     }
/* 1144 */     if (jtaStatus == 4) {
/* 1145 */       throw new RollbackException("JTA transaction already rolled back (probably due to a timeout)");
/*      */     }
/*      */ 
/* 1148 */     if (this.transactionSynchronizationRegistry != null)
/*      */     {
/* 1150 */       this.transactionSynchronizationRegistry.registerInterposedSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/*      */     }
/* 1154 */     else if (getTransactionManager() != null)
/*      */     {
/* 1156 */       Transaction transaction = getTransactionManager().getTransaction();
/* 1157 */       if (transaction == null) {
/* 1158 */         throw new IllegalStateException("No JTA Transaction available");
/*      */       }
/* 1160 */       transaction.registerSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/*      */     }
/*      */     else
/*      */     {
/* 1165 */       this.logger.warn("Participating in existing JTA transaction, but no JTA TransactionManager available: cannot register Spring after-completion callbacks with outer JTA transaction - processing Spring after-completion callbacks with outcome status 'unknown'");
/*      */ 
/* 1168 */       invokeAfterCompletion(synchronizations, 2);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Transaction createTransaction(String name, int timeout)
/*      */     throws NotSupportedException, SystemException
/*      */   {
/* 1179 */     TransactionManager tm = getTransactionManager();
/* 1180 */     Assert.state(tm != null, "No JTA TransactionManager available");
/* 1181 */     if (timeout >= 0) {
/* 1182 */       tm.setTransactionTimeout(timeout);
/*      */     }
/* 1184 */     tm.begin();
/* 1185 */     return new ManagedTransactionAdapter(tm);
/*      */   }
/*      */ 
/*      */   public boolean supportsResourceAdapterManagedTransactions()
/*      */   {
/* 1190 */     return false;
/*      */   }
/*      */ 
/*      */   private void readObject(ObjectInputStream ois)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1200 */     ois.defaultReadObject();
/*      */ 
/* 1203 */     this.jndiTemplate = new JndiTemplate();
/*      */ 
/* 1206 */     initUserTransactionAndTransactionManager();
/* 1207 */     initTransactionSynchronizationRegistry();
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.JtaTransactionManager
 * JD-Core Version:    0.6.2
 */