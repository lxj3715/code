/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import javax.transaction.SystemException;
/*    */ import javax.transaction.UserTransaction;
/*    */ import org.springframework.transaction.TransactionSystemException;
/*    */ import org.springframework.transaction.support.SmartTransactionObject;
/*    */ import org.springframework.transaction.support.TransactionSynchronizationUtils;
/*    */ 
/*    */ public class JtaTransactionObject
/*    */   implements SmartTransactionObject
/*    */ {
/*    */   private final UserTransaction userTransaction;
/*    */ 
/*    */   public JtaTransactionObject(UserTransaction userTransaction)
/*    */   {
/* 49 */     this.userTransaction = userTransaction;
/*    */   }
/*    */ 
/*    */   public final UserTransaction getUserTransaction()
/*    */   {
/* 56 */     return this.userTransaction;
/*    */   }
/*    */ 
/*    */   public boolean isRollbackOnly()
/*    */   {
/* 65 */     if (this.userTransaction == null)
/* 66 */       return false;
/*    */     try
/*    */     {
/* 69 */       int jtaStatus = this.userTransaction.getStatus();
/* 70 */       return (jtaStatus == 1) || (jtaStatus == 4);
/*    */     }
/*    */     catch (SystemException ex) {
/* 73 */       throw new TransactionSystemException("JTA failure on getStatus", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void flush()
/*    */   {
/* 84 */     TransactionSynchronizationUtils.triggerFlush();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.JtaTransactionObject
 * JD-Core Version:    0.6.2
 */