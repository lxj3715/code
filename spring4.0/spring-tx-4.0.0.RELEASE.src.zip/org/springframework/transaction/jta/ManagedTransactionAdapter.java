/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import javax.transaction.HeuristicMixedException;
/*    */ import javax.transaction.HeuristicRollbackException;
/*    */ import javax.transaction.RollbackException;
/*    */ import javax.transaction.Synchronization;
/*    */ import javax.transaction.SystemException;
/*    */ import javax.transaction.Transaction;
/*    */ import javax.transaction.TransactionManager;
/*    */ import javax.transaction.xa.XAResource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ManagedTransactionAdapter
/*    */   implements Transaction
/*    */ {
/*    */   private final TransactionManager transactionManager;
/*    */ 
/*    */   public ManagedTransactionAdapter(TransactionManager transactionManager)
/*    */     throws SystemException
/*    */   {
/* 48 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/* 49 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ 
/*    */   public final TransactionManager getTransactionManager()
/*    */   {
/* 56 */     return this.transactionManager;
/*    */   }
/*    */ 
/*    */   public void commit()
/*    */     throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, SystemException
/*    */   {
/* 63 */     this.transactionManager.commit();
/*    */   }
/*    */ 
/*    */   public void rollback() throws SystemException
/*    */   {
/* 68 */     this.transactionManager.rollback();
/*    */   }
/*    */ 
/*    */   public void setRollbackOnly() throws SystemException
/*    */   {
/* 73 */     this.transactionManager.setRollbackOnly();
/*    */   }
/*    */ 
/*    */   public int getStatus() throws SystemException
/*    */   {
/* 78 */     return this.transactionManager.getStatus();
/*    */   }
/*    */ 
/*    */   public boolean enlistResource(XAResource xaRes) throws RollbackException, SystemException
/*    */   {
/* 83 */     return this.transactionManager.getTransaction().enlistResource(xaRes);
/*    */   }
/*    */ 
/*    */   public boolean delistResource(XAResource xaRes, int flag) throws SystemException
/*    */   {
/* 88 */     return this.transactionManager.getTransaction().delistResource(xaRes, flag);
/*    */   }
/*    */ 
/*    */   public void registerSynchronization(Synchronization sync) throws RollbackException, SystemException
/*    */   {
/* 93 */     this.transactionManager.getTransaction().registerSynchronization(sync);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.ManagedTransactionAdapter
 * JD-Core Version:    0.6.2
 */