/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import javax.transaction.NotSupportedException;
/*    */ import javax.transaction.SystemException;
/*    */ import javax.transaction.Transaction;
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SimpleTransactionFactory
/*    */   implements TransactionFactory
/*    */ {
/*    */   private final TransactionManager transactionManager;
/*    */ 
/*    */   public SimpleTransactionFactory(TransactionManager transactionManager)
/*    */   {
/* 48 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/* 49 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ 
/*    */   public Transaction createTransaction(String name, int timeout)
/*    */     throws NotSupportedException, SystemException
/*    */   {
/* 55 */     if (timeout >= 0) {
/* 56 */       this.transactionManager.setTransactionTimeout(timeout);
/*    */     }
/* 58 */     this.transactionManager.begin();
/* 59 */     return new ManagedTransactionAdapter(this.transactionManager);
/*    */   }
/*    */ 
/*    */   public boolean supportsResourceAdapterManagedTransactions()
/*    */   {
/* 64 */     return false;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.SimpleTransactionFactory
 * JD-Core Version:    0.6.2
 */