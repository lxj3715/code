/*     */ package org.springframework.transaction.jta;
/*     */ 
/*     */ import javax.transaction.Synchronization;
/*     */ import javax.transaction.TransactionManager;
/*     */ import javax.transaction.UserTransaction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SpringJtaSynchronizationAdapter
/*     */   implements Synchronization
/*     */ {
/*  47 */   protected static final Log logger = LogFactory.getLog(SpringJtaSynchronizationAdapter.class);
/*     */   private final TransactionSynchronization springSynchronization;
/*     */   private UserTransaction jtaTransaction;
/*  53 */   private boolean beforeCompletionCalled = false;
/*     */ 
/*     */   public SpringJtaSynchronizationAdapter(TransactionSynchronization springSynchronization)
/*     */   {
/*  62 */     Assert.notNull(springSynchronization, "TransactionSynchronization must not be null");
/*  63 */     this.springSynchronization = springSynchronization;
/*     */   }
/*     */ 
/*     */   public SpringJtaSynchronizationAdapter(TransactionSynchronization springSynchronization, UserTransaction jtaUserTransaction)
/*     */   {
/*  82 */     this(springSynchronization);
/*  83 */     if ((jtaUserTransaction != null) && (!jtaUserTransaction.getClass().getName().startsWith("weblogic.")))
/*  84 */       this.jtaTransaction = jtaUserTransaction;
/*     */   }
/*     */ 
/*     */   public SpringJtaSynchronizationAdapter(TransactionSynchronization springSynchronization, TransactionManager jtaTransactionManager)
/*     */   {
/* 104 */     this(springSynchronization);
/* 105 */     if ((jtaTransactionManager != null) && (!jtaTransactionManager.getClass().getName().startsWith("weblogic.")))
/* 106 */       this.jtaTransaction = new UserTransactionAdapter(jtaTransactionManager);
/*     */   }
/*     */ 
/*     */   public void beforeCompletion()
/*     */   {
/*     */     try
/*     */     {
/* 119 */       boolean readOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
/* 120 */       this.springSynchronization.beforeCommit(readOnly);
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 123 */       setRollbackOnlyIfPossible();
/* 124 */       throw ex;
/*     */     }
/*     */     catch (Error err) {
/* 127 */       setRollbackOnlyIfPossible();
/* 128 */       throw err;
/*     */     }
/*     */     finally
/*     */     {
/* 134 */       this.beforeCompletionCalled = true;
/* 135 */       this.springSynchronization.beforeCompletion();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setRollbackOnlyIfPossible()
/*     */   {
/* 143 */     if (this.jtaTransaction != null) {
/*     */       try {
/* 145 */         this.jtaTransaction.setRollbackOnly();
/*     */       }
/*     */       catch (UnsupportedOperationException ex)
/*     */       {
/* 149 */         logger.debug("JTA transaction handle does not support setRollbackOnly method - relying on JTA provider to mark the transaction as rollback-only based on the exception thrown from beforeCompletion", ex);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 154 */         logger.error("Could not set JTA transaction rollback-only", ex);
/*     */       }
/*     */     }
/*     */     else
/* 158 */       logger.debug("No JTA transaction handle available and/or running on WebLogic - relying on JTA provider to mark the transaction as rollback-only based on the exception thrown from beforeCompletion");
/*     */   }
/*     */ 
/*     */   public void afterCompletion(int status)
/*     */   {
/* 174 */     if (!this.beforeCompletionCalled)
/*     */     {
/* 177 */       this.springSynchronization.beforeCompletion();
/*     */     }
/*     */ 
/* 180 */     switch (status) {
/*     */     case 3:
/* 182 */       this.springSynchronization.afterCompletion(0);
/* 183 */       break;
/*     */     case 4:
/* 185 */       this.springSynchronization.afterCompletion(1);
/* 186 */       break;
/*     */     default:
/* 188 */       this.springSynchronization.afterCompletion(2);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.SpringJtaSynchronizationAdapter
 * JD-Core Version:    0.6.2
 */