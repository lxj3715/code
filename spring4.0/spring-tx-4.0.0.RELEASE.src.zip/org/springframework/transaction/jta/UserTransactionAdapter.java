/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import javax.transaction.HeuristicMixedException;
/*    */ import javax.transaction.HeuristicRollbackException;
/*    */ import javax.transaction.NotSupportedException;
/*    */ import javax.transaction.RollbackException;
/*    */ import javax.transaction.SystemException;
/*    */ import javax.transaction.TransactionManager;
/*    */ import javax.transaction.UserTransaction;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class UserTransactionAdapter
/*    */   implements UserTransaction
/*    */ {
/*    */   private final TransactionManager transactionManager;
/*    */ 
/*    */   public UserTransactionAdapter(TransactionManager transactionManager)
/*    */   {
/* 56 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/* 57 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ 
/*    */   public final TransactionManager getTransactionManager()
/*    */   {
/* 64 */     return this.transactionManager;
/*    */   }
/*    */ 
/*    */   public void setTransactionTimeout(int timeout)
/*    */     throws SystemException
/*    */   {
/* 70 */     this.transactionManager.setTransactionTimeout(timeout);
/*    */   }
/*    */ 
/*    */   public void begin() throws NotSupportedException, SystemException
/*    */   {
/* 75 */     this.transactionManager.begin();
/*    */   }
/*    */ 
/*    */   public void commit()
/*    */     throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, SystemException
/*    */   {
/* 82 */     this.transactionManager.commit();
/*    */   }
/*    */ 
/*    */   public void rollback() throws SecurityException, SystemException
/*    */   {
/* 87 */     this.transactionManager.rollback();
/*    */   }
/*    */ 
/*    */   public void setRollbackOnly() throws SystemException
/*    */   {
/* 92 */     this.transactionManager.setRollbackOnly();
/*    */   }
/*    */ 
/*    */   public int getStatus() throws SystemException
/*    */   {
/* 97 */     return this.transactionManager.getStatus();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.UserTransactionAdapter
 * JD-Core Version:    0.6.2
 */