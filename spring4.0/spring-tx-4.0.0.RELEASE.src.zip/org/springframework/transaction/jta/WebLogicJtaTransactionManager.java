/*     */ package org.springframework.transaction.jta;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.transaction.InvalidTransactionException;
/*     */ import javax.transaction.NotSupportedException;
/*     */ import javax.transaction.SystemException;
/*     */ import javax.transaction.Transaction;
/*     */ import javax.transaction.TransactionManager;
/*     */ import javax.transaction.UserTransaction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ 
/*     */ public class WebLogicJtaTransactionManager extends JtaTransactionManager
/*     */ {
/*     */   private static final String USER_TRANSACTION_CLASS_NAME = "weblogic.transaction.UserTransaction";
/*     */   private static final String CLIENT_TRANSACTION_MANAGER_CLASS_NAME = "weblogic.transaction.ClientTransactionManager";
/*     */   private static final String TRANSACTION_CLASS_NAME = "weblogic.transaction.Transaction";
/*     */   private static final String TRANSACTION_HELPER_CLASS_NAME = "weblogic.transaction.TransactionHelper";
/*     */   private static final String ISOLATION_LEVEL_KEY = "ISOLATION LEVEL";
/*     */   private boolean weblogicUserTransactionAvailable;
/*     */   private Method beginWithNameMethod;
/*     */   private Method beginWithNameAndTimeoutMethod;
/*     */   private boolean weblogicTransactionManagerAvailable;
/*     */   private Method forceResumeMethod;
/*     */   private Method setPropertyMethod;
/*     */   private Object transactionHelper;
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws TransactionSystemException
/*     */   {
/* 104 */     super.afterPropertiesSet();
/* 105 */     loadWebLogicTransactionClasses();
/*     */   }
/*     */ 
/*     */   protected UserTransaction retrieveUserTransaction() throws TransactionSystemException
/*     */   {
/* 110 */     loadWebLogicTransactionHelper();
/*     */     try {
/* 112 */       this.logger.debug("Retrieving JTA UserTransaction from WebLogic TransactionHelper");
/* 113 */       Method getUserTransactionMethod = this.transactionHelper.getClass().getMethod("getUserTransaction", new Class[0]);
/* 114 */       return (UserTransaction)getUserTransactionMethod.invoke(this.transactionHelper, new Object[0]);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 118 */       throw new TransactionSystemException("WebLogic's TransactionHelper.getUserTransaction() method failed", ex
/* 118 */         .getTargetException());
/*     */     }
/*     */     catch (Exception ex) {
/* 121 */       throw new TransactionSystemException("Could not invoke WebLogic's TransactionHelper.getUserTransaction() method", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected TransactionManager retrieveTransactionManager()
/*     */     throws TransactionSystemException
/*     */   {
/* 128 */     loadWebLogicTransactionHelper();
/*     */     try {
/* 130 */       this.logger.debug("Retrieving JTA TransactionManager from WebLogic TransactionHelper");
/* 131 */       Method getTransactionManagerMethod = this.transactionHelper.getClass().getMethod("getTransactionManager", new Class[0]);
/* 132 */       return (TransactionManager)getTransactionManagerMethod.invoke(this.transactionHelper, new Object[0]);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 136 */       throw new TransactionSystemException("WebLogic's TransactionHelper.getTransactionManager() method failed", ex
/* 136 */         .getTargetException());
/*     */     }
/*     */     catch (Exception ex) {
/* 139 */       throw new TransactionSystemException("Could not invoke WebLogic's TransactionHelper.getTransactionManager() method", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadWebLogicTransactionHelper() throws TransactionSystemException
/*     */   {
/* 145 */     if (this.transactionHelper == null)
/*     */       try {
/* 147 */         Class transactionHelperClass = getClass().getClassLoader().loadClass("weblogic.transaction.TransactionHelper");
/* 148 */         Method getTransactionHelperMethod = transactionHelperClass.getMethod("getTransactionHelper", new Class[0]);
/* 149 */         this.transactionHelper = getTransactionHelperMethod.invoke(null, new Object[0]);
/* 150 */         this.logger.debug("WebLogic TransactionHelper found");
/*     */       }
/*     */       catch (InvocationTargetException ex)
/*     */       {
/* 154 */         throw new TransactionSystemException("WebLogic's TransactionHelper.getTransactionHelper() method failed", ex
/* 154 */           .getTargetException());
/*     */       }
/*     */       catch (Exception ex) {
/* 157 */         throw new TransactionSystemException("Could not initialize WebLogicJtaTransactionManager because WebLogic API classes are not available", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void loadWebLogicTransactionClasses()
/*     */     throws TransactionSystemException
/*     */   {
/*     */     try
/*     */     {
/* 166 */       Class userTransactionClass = getClass().getClassLoader().loadClass("weblogic.transaction.UserTransaction");
/* 167 */       this.weblogicUserTransactionAvailable = userTransactionClass.isInstance(getUserTransaction());
/* 168 */       if (this.weblogicUserTransactionAvailable) {
/* 169 */         this.beginWithNameMethod = userTransactionClass.getMethod("begin", new Class[] { String.class });
/* 170 */         this.beginWithNameAndTimeoutMethod = userTransactionClass.getMethod("begin", new Class[] { String.class, Integer.TYPE });
/* 171 */         this.logger.info("Support for WebLogic transaction names available");
/*     */       }
/*     */       else {
/* 174 */         this.logger.info("Support for WebLogic transaction names not available");
/*     */       }
/*     */ 
/* 179 */       Class transactionManagerClass = getClass().getClassLoader().loadClass("weblogic.transaction.ClientTransactionManager");
/* 180 */       this.logger.debug("WebLogic ClientTransactionManager found");
/*     */ 
/* 182 */       this.weblogicTransactionManagerAvailable = transactionManagerClass.isInstance(getTransactionManager());
/* 183 */       if (this.weblogicTransactionManagerAvailable) {
/* 184 */         Class transactionClass = getClass().getClassLoader().loadClass("weblogic.transaction.Transaction");
/* 185 */         this.forceResumeMethod = transactionManagerClass.getMethod("forceResume", new Class[] { Transaction.class });
/* 186 */         this.setPropertyMethod = transactionClass.getMethod("setProperty", new Class[] { String.class, Serializable.class });
/* 187 */         this.logger.debug("Support for WebLogic forceResume available");
/*     */       }
/*     */       else {
/* 190 */         this.logger.warn("Support for WebLogic forceResume not available");
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 194 */       throw new TransactionSystemException("Could not initialize WebLogicJtaTransactionManager because WebLogic API classes are not available", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doJtaBegin(JtaTransactionObject txObject, TransactionDefinition definition)
/*     */     throws NotSupportedException, SystemException
/*     */   {
/* 205 */     int timeout = determineTimeout(definition);
/*     */ 
/* 208 */     if ((this.weblogicUserTransactionAvailable) && (definition.getName() != null)) {
/*     */       try {
/* 210 */         if (timeout > -1)
/*     */         {
/* 215 */           this.beginWithNameAndTimeoutMethod.invoke(txObject.getUserTransaction(), new Object[] { definition.getName(), Integer.valueOf(timeout) });
/*     */         }
/*     */         else
/*     */         {
/* 222 */           this.beginWithNameMethod.invoke(txObject.getUserTransaction(), new Object[] { definition.getName() });
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException ex)
/*     */       {
/* 227 */         throw new TransactionSystemException("WebLogic's UserTransaction.begin() method failed", ex
/* 227 */           .getTargetException());
/*     */       }
/*     */       catch (Exception ex) {
/* 230 */         throw new TransactionSystemException("Could not invoke WebLogic's UserTransaction.begin() method", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 237 */       applyTimeout(txObject, timeout);
/* 238 */       txObject.getUserTransaction().begin();
/*     */     }
/*     */ 
/* 242 */     if (this.weblogicTransactionManagerAvailable) {
/* 243 */       if (definition.getIsolationLevel() != -1) {
/*     */         try {
/* 245 */           Transaction tx = getTransactionManager().getTransaction();
/* 246 */           Integer isolationLevel = Integer.valueOf(definition.getIsolationLevel());
/*     */ 
/* 251 */           this.setPropertyMethod.invoke(tx, new Object[] { "ISOLATION LEVEL", isolationLevel });
/*     */         }
/*     */         catch (InvocationTargetException ex)
/*     */         {
/* 255 */           throw new TransactionSystemException("WebLogic's Transaction.setProperty(String, Serializable) method failed", ex
/* 255 */             .getTargetException());
/*     */         }
/*     */         catch (Exception ex) {
/* 258 */           throw new TransactionSystemException("Could not invoke WebLogic's Transaction.setProperty(String, Serializable) method", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 264 */       applyIsolationLevel(txObject, definition.getIsolationLevel());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doJtaResume(JtaTransactionObject txObject, Object suspendedTransaction)
/*     */     throws InvalidTransactionException, SystemException
/*     */   {
/*     */     try
/*     */     {
/* 273 */       getTransactionManager().resume((Transaction)suspendedTransaction);
/*     */     }
/*     */     catch (InvalidTransactionException ex) {
/* 276 */       if (!this.weblogicTransactionManagerAvailable) {
/* 277 */         throw ex;
/*     */       }
/*     */ 
/* 280 */       if (this.logger.isDebugEnabled()) {
/* 281 */         this.logger.debug("Standard JTA resume threw InvalidTransactionException: " + ex.getMessage() + " - trying WebLogic JTA forceResume");
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 290 */         this.forceResumeMethod.invoke(getTransactionManager(), new Object[] { suspendedTransaction });
/*     */       }
/*     */       catch (InvocationTargetException ex2)
/*     */       {
/* 294 */         throw new TransactionSystemException("WebLogic's TransactionManager.forceResume(Transaction) method failed", ex2
/* 294 */           .getTargetException());
/*     */       }
/*     */       catch (Exception ex2) {
/* 297 */         throw new TransactionSystemException("Could not access WebLogic's TransactionManager.forceResume(Transaction) method", ex2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Transaction createTransaction(String name, int timeout)
/*     */     throws NotSupportedException, SystemException
/*     */   {
/* 305 */     if ((this.weblogicUserTransactionAvailable) && (name != null)) {
/*     */       try {
/* 307 */         if (timeout >= 0) {
/* 308 */           this.beginWithNameAndTimeoutMethod.invoke(getUserTransaction(), new Object[] { name, Integer.valueOf(timeout) });
/*     */         }
/*     */         else
/* 311 */           this.beginWithNameMethod.invoke(getUserTransaction(), new Object[] { name });
/*     */       }
/*     */       catch (InvocationTargetException ex)
/*     */       {
/* 315 */         if ((ex.getTargetException() instanceof NotSupportedException)) {
/* 316 */           throw ((NotSupportedException)ex.getTargetException());
/*     */         }
/* 318 */         if ((ex.getTargetException() instanceof SystemException)) {
/* 319 */           throw ((SystemException)ex.getTargetException());
/*     */         }
/* 321 */         if ((ex.getTargetException() instanceof RuntimeException)) {
/* 322 */           throw ((RuntimeException)ex.getTargetException());
/*     */         }
/*     */ 
/* 326 */         throw new SystemException("WebLogic's begin() method failed with an unexpected error: " + ex
/* 326 */           .getTargetException());
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 330 */         throw new SystemException("Could not invoke WebLogic's UserTransaction.begin() method: " + ex);
/*     */       }
/* 332 */       return new ManagedTransactionAdapter(getTransactionManager());
/*     */     }
/*     */ 
/* 337 */     return super.createTransaction(name, timeout);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.WebLogicJtaTransactionManager
 * JD-Core Version:    0.6.2
 */