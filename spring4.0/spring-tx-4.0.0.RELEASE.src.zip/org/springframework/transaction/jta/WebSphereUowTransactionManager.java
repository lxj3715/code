/*     */ package org.springframework.transaction.jta;
/*     */ 
/*     */ import com.ibm.wsspi.uow.UOWAction;
/*     */ import com.ibm.wsspi.uow.UOWActionException;
/*     */ import com.ibm.wsspi.uow.UOWException;
/*     */ import com.ibm.wsspi.uow.UOWManager;
/*     */ import com.ibm.wsspi.uow.UOWManagerFactory;
/*     */ import java.util.List;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ import org.springframework.transaction.IllegalTransactionStateException;
/*     */ import org.springframework.transaction.InvalidTimeoutException;
/*     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.support.AbstractPlatformTransactionManager.SuspendedResourcesHolder;
/*     */ import org.springframework.transaction.support.CallbackPreferringPlatformTransactionManager;
/*     */ import org.springframework.transaction.support.DefaultTransactionDefinition;
/*     */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*     */ import org.springframework.transaction.support.TransactionCallback;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class WebSphereUowTransactionManager extends JtaTransactionManager
/*     */   implements CallbackPreferringPlatformTransactionManager
/*     */ {
/*     */   public static final String DEFAULT_UOW_MANAGER_NAME = "java:comp/websphere/UOWManager";
/*     */   private UOWManager uowManager;
/*     */   private String uowManagerName;
/*     */ 
/*     */   public WebSphereUowTransactionManager()
/*     */   {
/* 105 */     setAutodetectTransactionManager(false);
/*     */   }
/*     */ 
/*     */   public WebSphereUowTransactionManager(UOWManager uowManager)
/*     */   {
/* 113 */     this();
/* 114 */     this.uowManager = uowManager;
/*     */   }
/*     */ 
/*     */   public void setUowManager(UOWManager uowManager)
/*     */   {
/* 125 */     this.uowManager = uowManager;
/*     */   }
/*     */ 
/*     */   public void setUowManagerName(String uowManagerName)
/*     */   {
/* 135 */     this.uowManagerName = uowManagerName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws TransactionSystemException
/*     */   {
/* 141 */     initUserTransactionAndTransactionManager();
/*     */ 
/* 144 */     if (this.uowManager == null)
/* 145 */       if (this.uowManagerName != null) {
/* 146 */         this.uowManager = lookupUowManager(this.uowManagerName);
/*     */       }
/*     */       else
/* 149 */         this.uowManager = lookupDefaultUowManager();
/*     */   }
/*     */ 
/*     */   protected UOWManager lookupUowManager(String uowManagerName)
/*     */     throws TransactionSystemException
/*     */   {
/*     */     try
/*     */     {
/* 164 */       if (this.logger.isDebugEnabled()) {
/* 165 */         this.logger.debug("Retrieving WebSphere UOWManager from JNDI location [" + uowManagerName + "]");
/*     */       }
/* 167 */       return (UOWManager)getJndiTemplate().lookup(uowManagerName, UOWManager.class);
/*     */     }
/*     */     catch (NamingException ex) {
/* 170 */       throw new TransactionSystemException("WebSphere UOWManager is not available at JNDI location [" + uowManagerName + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected UOWManager lookupDefaultUowManager()
/*     */     throws TransactionSystemException
/*     */   {
/*     */     try
/*     */     {
/* 184 */       this.logger.debug("Retrieving WebSphere UOWManager from default JNDI location [java:comp/websphere/UOWManager]");
/* 185 */       return (UOWManager)getJndiTemplate().lookup("java:comp/websphere/UOWManager", UOWManager.class);
/*     */     }
/*     */     catch (NamingException ex) {
/* 188 */       this.logger.debug("WebSphere UOWManager is not available at default JNDI location [java:comp/websphere/UOWManager] - falling back to UOWManagerFactory lookup");
/*     */     }
/* 190 */     return UOWManagerFactory.getUOWManager();
/*     */   }
/*     */ 
/*     */   protected void doRegisterAfterCompletionWithJtaTransaction(JtaTransactionObject txObject, List<TransactionSynchronization> synchronizations)
/*     */   {
/* 201 */     this.uowManager.registerInterposedSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/*     */   }
/*     */ 
/*     */   public boolean supportsResourceAdapterManagedTransactions()
/*     */   {
/* 215 */     return true;
/*     */   }
/*     */ 
/*     */   public <T> T execute(TransactionDefinition definition, TransactionCallback<T> callback)
/*     */     throws TransactionException
/*     */   {
/* 221 */     if (definition == null)
/*     */     {
/* 223 */       definition = new DefaultTransactionDefinition();
/*     */     }
/*     */ 
/* 226 */     if (definition.getTimeout() < -1) {
/* 227 */       throw new InvalidTimeoutException("Invalid transaction timeout", definition.getTimeout());
/*     */     }
/* 229 */     int pb = definition.getPropagationBehavior();
/*     */ 
/* 231 */     boolean existingTx = (this.uowManager.getUOWStatus() != 5) && 
/* 231 */       (this.uowManager
/* 231 */       .getUOWType() != 0);
/*     */ 
/* 233 */     int uowType = 1;
/* 234 */     boolean joinTx = false;
/* 235 */     boolean newSynch = false;
/*     */ 
/* 237 */     if (existingTx) {
/* 238 */       if (pb == 5) {
/* 239 */         throw new IllegalTransactionStateException("Transaction propagation 'never' but existing transaction found");
/*     */       }
/*     */ 
/* 242 */       if (pb == 6) {
/* 243 */         throw new NestedTransactionNotSupportedException("Transaction propagation 'nested' not supported for WebSphere UOW transactions");
/*     */       }
/*     */ 
/* 246 */       if ((pb == 1) || (pb == 0) || (pb == 2))
/*     */       {
/* 248 */         joinTx = true;
/* 249 */         newSynch = getTransactionSynchronization() != 2;
/*     */       }
/* 251 */       else if (pb == 4) {
/* 252 */         uowType = 0;
/* 253 */         newSynch = getTransactionSynchronization() == 0;
/*     */       }
/*     */       else {
/* 256 */         newSynch = getTransactionSynchronization() != 2;
/*     */       }
/*     */     }
/*     */     else {
/* 260 */       if (pb == 2) {
/* 261 */         throw new IllegalTransactionStateException("Transaction propagation 'mandatory' but no existing transaction found");
/*     */       }
/*     */ 
/* 264 */       if ((pb == 1) || (pb == 4) || (pb == 5))
/*     */       {
/* 266 */         uowType = 0;
/* 267 */         newSynch = getTransactionSynchronization() == 0;
/*     */       }
/*     */       else {
/* 270 */         newSynch = getTransactionSynchronization() != 2;
/*     */       }
/*     */     }
/*     */ 
/* 274 */     boolean debug = this.logger.isDebugEnabled();
/* 275 */     if (debug) {
/* 276 */       this.logger.debug("Creating new transaction with name [" + definition.getName() + "]: " + definition);
/*     */     }
/* 278 */     AbstractPlatformTransactionManager.SuspendedResourcesHolder suspendedResources = !joinTx ? suspend(null) : null;
/*     */     try {
/* 280 */       if (definition.getTimeout() > -1) {
/* 281 */         this.uowManager.setUOWTimeout(uowType, definition.getTimeout());
/*     */       }
/* 283 */       if (debug) {
/* 284 */         this.logger.debug("Invoking WebSphere UOW action: type=" + uowType + ", join=" + joinTx);
/*     */       }
/* 286 */       UOWActionAdapter action = new UOWActionAdapter(definition, callback, uowType == 1, !joinTx, newSynch, debug);
/*     */ 
/* 288 */       this.uowManager.runUnderUOW(uowType, joinTx, action);
/* 289 */       if (debug) {
/* 290 */         this.logger.debug("Returned from WebSphere UOW action: type=" + uowType + ", join=" + joinTx);
/*     */       }
/* 292 */       return action.getResult();
/*     */     }
/*     */     catch (UOWException ex) {
/* 295 */       throw new TransactionSystemException("UOWManager transaction processing failed", ex);
/*     */     }
/*     */     catch (UOWActionException ex) {
/* 298 */       throw new TransactionSystemException("UOWManager threw unexpected UOWActionException", ex);
/*     */     }
/*     */     finally {
/* 301 */       if (suspendedResources != null)
/* 302 */         resume(null, suspendedResources);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class UOWActionAdapter<T>
/*     */     implements UOWAction
/*     */   {
/*     */     private final TransactionDefinition definition;
/*     */     private final TransactionCallback<T> callback;
/*     */     private final boolean actualTransaction;
/*     */     private final boolean newTransaction;
/*     */     private final boolean newSynchronization;
/*     */     private boolean debug;
/*     */     private T result;
/*     */     private Throwable exception;
/*     */ 
/*     */     public UOWActionAdapter(TransactionCallback<T> definition, boolean callback, boolean actualTransaction, boolean newTransaction, boolean newSynchronization)
/*     */     {
/* 331 */       this.definition = definition;
/* 332 */       this.callback = callback;
/* 333 */       this.actualTransaction = actualTransaction;
/* 334 */       this.newTransaction = newTransaction;
/* 335 */       this.newSynchronization = newSynchronization;
/* 336 */       this.debug = debug;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 341 */       DefaultTransactionStatus status = WebSphereUowTransactionManager.this.prepareTransactionStatus(this.definition, this.actualTransaction ? this : null, this.newTransaction, this.newSynchronization, this.debug, null);
/*     */       try
/*     */       {
/* 345 */         this.result = this.callback.doInTransaction(status);
/* 346 */         WebSphereUowTransactionManager.this.triggerBeforeCommit(status);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/*     */         List synchronizations;
/* 349 */         this.exception = ex;
/* 350 */         WebSphereUowTransactionManager.this.uowManager.setRollbackOnly();
/*     */       }
/*     */       finally
/*     */       {
/*     */         List synchronizations;
/* 353 */         if (status.isLocalRollbackOnly()) {
/* 354 */           if (status.isDebug()) {
/* 355 */             WebSphereUowTransactionManager.this.logger.debug("Transactional code has requested rollback");
/*     */           }
/* 357 */           WebSphereUowTransactionManager.this.uowManager.setRollbackOnly();
/*     */         }
/* 359 */         WebSphereUowTransactionManager.this.triggerBeforeCompletion(status);
/* 360 */         if (status.isNewSynchronization()) {
/* 361 */           List synchronizations = TransactionSynchronizationManager.getSynchronizations();
/* 362 */           TransactionSynchronizationManager.clear();
/* 363 */           if (!synchronizations.isEmpty())
/* 364 */             WebSphereUowTransactionManager.this.uowManager.registerInterposedSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public T getResult()
/*     */     {
/* 371 */       if (this.exception != null) {
/* 372 */         ReflectionUtils.rethrowRuntimeException(this.exception);
/*     */       }
/* 374 */       return this.result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.jta.WebSphereUowTransactionManager
 * JD-Core Version:    0.6.2
 */