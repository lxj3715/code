/*      */ package org.springframework.transaction.support;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.List;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.core.Constants;
/*      */ import org.springframework.transaction.IllegalTransactionStateException;
/*      */ import org.springframework.transaction.InvalidTimeoutException;
/*      */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*      */ import org.springframework.transaction.PlatformTransactionManager;
/*      */ import org.springframework.transaction.TransactionDefinition;
/*      */ import org.springframework.transaction.TransactionException;
/*      */ import org.springframework.transaction.TransactionStatus;
/*      */ import org.springframework.transaction.TransactionSuspensionNotSupportedException;
/*      */ import org.springframework.transaction.UnexpectedRollbackException;
/*      */ 
/*      */ public abstract class AbstractPlatformTransactionManager
/*      */   implements PlatformTransactionManager, Serializable
/*      */ {
/*      */   public static final int SYNCHRONIZATION_ALWAYS = 0;
/*      */   public static final int SYNCHRONIZATION_ON_ACTUAL_TRANSACTION = 1;
/*      */   public static final int SYNCHRONIZATION_NEVER = 2;
/*  110 */   private static final Constants constants = new Constants(AbstractPlatformTransactionManager.class);
/*      */   protected transient Log logger;
/*      */   private int transactionSynchronization;
/*      */   private int defaultTimeout;
/*      */   private boolean nestedTransactionAllowed;
/*      */   private boolean validateExistingTransaction;
/*      */   private boolean globalRollbackOnParticipationFailure;
/*      */   private boolean failEarlyOnGlobalRollbackOnly;
/*      */   private boolean rollbackOnCommitFailure;
/*      */ 
/*      */   public AbstractPlatformTransactionManager()
/*      */   {
/*  113 */     this.logger = LogFactory.getLog(getClass());
/*      */ 
/*  115 */     this.transactionSynchronization = 0;
/*      */ 
/*  117 */     this.defaultTimeout = -1;
/*      */ 
/*  119 */     this.nestedTransactionAllowed = false;
/*      */ 
/*  121 */     this.validateExistingTransaction = false;
/*      */ 
/*  123 */     this.globalRollbackOnParticipationFailure = true;
/*      */ 
/*  125 */     this.failEarlyOnGlobalRollbackOnly = false;
/*      */ 
/*  127 */     this.rollbackOnCommitFailure = false;
/*      */   }
/*      */ 
/*      */   public final void setTransactionSynchronizationName(String constantName)
/*      */   {
/*  137 */     setTransactionSynchronization(constants.asNumber(constantName).intValue());
/*      */   }
/*      */ 
/*      */   public final void setTransactionSynchronization(int transactionSynchronization)
/*      */   {
/*  153 */     this.transactionSynchronization = transactionSynchronization;
/*      */   }
/*      */ 
/*      */   public final int getTransactionSynchronization()
/*      */   {
/*  161 */     return this.transactionSynchronization;
/*      */   }
/*      */ 
/*      */   public final void setDefaultTimeout(int defaultTimeout)
/*      */   {
/*  173 */     if (defaultTimeout < -1) {
/*  174 */       throw new InvalidTimeoutException("Invalid default timeout", defaultTimeout);
/*      */     }
/*  176 */     this.defaultTimeout = defaultTimeout;
/*      */   }
/*      */ 
/*      */   public final int getDefaultTimeout()
/*      */   {
/*  186 */     return this.defaultTimeout;
/*      */   }
/*      */ 
/*      */   public final void setNestedTransactionAllowed(boolean nestedTransactionAllowed)
/*      */   {
/*  195 */     this.nestedTransactionAllowed = nestedTransactionAllowed;
/*      */   }
/*      */ 
/*      */   public final boolean isNestedTransactionAllowed()
/*      */   {
/*  202 */     return this.nestedTransactionAllowed;
/*      */   }
/*      */ 
/*      */   public final void setValidateExistingTransaction(boolean validateExistingTransaction)
/*      */   {
/*  219 */     this.validateExistingTransaction = validateExistingTransaction;
/*      */   }
/*      */ 
/*      */   public final boolean isValidateExistingTransaction()
/*      */   {
/*  227 */     return this.validateExistingTransaction;
/*      */   }
/*      */ 
/*      */   public final void setGlobalRollbackOnParticipationFailure(boolean globalRollbackOnParticipationFailure)
/*      */   {
/*  263 */     this.globalRollbackOnParticipationFailure = globalRollbackOnParticipationFailure;
/*      */   }
/*      */ 
/*      */   public final boolean isGlobalRollbackOnParticipationFailure()
/*      */   {
/*  271 */     return this.globalRollbackOnParticipationFailure;
/*      */   }
/*      */ 
/*      */   public final void setFailEarlyOnGlobalRollbackOnly(boolean failEarlyOnGlobalRollbackOnly)
/*      */   {
/*  290 */     this.failEarlyOnGlobalRollbackOnly = failEarlyOnGlobalRollbackOnly;
/*      */   }
/*      */ 
/*      */   public final boolean isFailEarlyOnGlobalRollbackOnly()
/*      */   {
/*  298 */     return this.failEarlyOnGlobalRollbackOnly;
/*      */   }
/*      */ 
/*      */   public final void setRollbackOnCommitFailure(boolean rollbackOnCommitFailure)
/*      */   {
/*  311 */     this.rollbackOnCommitFailure = rollbackOnCommitFailure;
/*      */   }
/*      */ 
/*      */   public final boolean isRollbackOnCommitFailure()
/*      */   {
/*  319 */     return this.rollbackOnCommitFailure;
/*      */   }
/*      */ 
/*      */   public final TransactionStatus getTransaction(TransactionDefinition definition)
/*      */     throws TransactionException
/*      */   {
/*  337 */     Object transaction = doGetTransaction();
/*      */ 
/*  340 */     boolean debugEnabled = this.logger.isDebugEnabled();
/*      */ 
/*  342 */     if (definition == null)
/*      */     {
/*  344 */       definition = new DefaultTransactionDefinition();
/*      */     }
/*      */ 
/*  347 */     if (isExistingTransaction(transaction))
/*      */     {
/*  349 */       return handleExistingTransaction(definition, transaction, debugEnabled);
/*      */     }
/*      */ 
/*  353 */     if (definition.getTimeout() < -1) {
/*  354 */       throw new InvalidTimeoutException("Invalid transaction timeout", definition.getTimeout());
/*      */     }
/*      */ 
/*  358 */     if (definition.getPropagationBehavior() == 2) {
/*  359 */       throw new IllegalTransactionStateException("No existing transaction found for transaction marked with propagation 'mandatory'");
/*      */     }
/*      */ 
/*  362 */     if ((definition.getPropagationBehavior() == 0) || 
/*  363 */       (definition
/*  363 */       .getPropagationBehavior() == 3) || 
/*  364 */       (definition
/*  364 */       .getPropagationBehavior() == 6)) {
/*  365 */       SuspendedResourcesHolder suspendedResources = suspend(null);
/*  366 */       if (debugEnabled)
/*  367 */         this.logger.debug(new StringBuilder().append("Creating new transaction with name [").append(definition.getName()).append("]: ").append(definition).toString());
/*      */       try
/*      */       {
/*  370 */         boolean newSynchronization = getTransactionSynchronization() != 2;
/*  371 */         DefaultTransactionStatus status = newTransactionStatus(definition, transaction, true, newSynchronization, debugEnabled, suspendedResources);
/*      */ 
/*  373 */         doBegin(transaction, definition);
/*  374 */         prepareSynchronization(status, definition);
/*  375 */         return status;
/*      */       }
/*      */       catch (RuntimeException ex) {
/*  378 */         resume(null, suspendedResources);
/*  379 */         throw ex;
/*      */       }
/*      */       catch (Error err) {
/*  382 */         resume(null, suspendedResources);
/*  383 */         throw err;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  388 */     boolean newSynchronization = getTransactionSynchronization() == 0;
/*  389 */     return prepareTransactionStatus(definition, null, true, newSynchronization, debugEnabled, null);
/*      */   }
/*      */ 
/*      */   private TransactionStatus handleExistingTransaction(TransactionDefinition definition, Object transaction, boolean debugEnabled)
/*      */     throws TransactionException
/*      */   {
/*  400 */     if (definition.getPropagationBehavior() == 5) {
/*  401 */       throw new IllegalTransactionStateException("Existing transaction found for transaction marked with propagation 'never'");
/*      */     }
/*      */ 
/*  405 */     if (definition.getPropagationBehavior() == 4) {
/*  406 */       if (debugEnabled) {
/*  407 */         this.logger.debug("Suspending current transaction");
/*      */       }
/*  409 */       Object suspendedResources = suspend(transaction);
/*  410 */       boolean newSynchronization = getTransactionSynchronization() == 0;
/*  411 */       return prepareTransactionStatus(definition, null, false, newSynchronization, debugEnabled, suspendedResources);
/*      */     }
/*      */ 
/*  415 */     if (definition.getPropagationBehavior() == 3) {
/*  416 */       if (debugEnabled) {
/*  417 */         this.logger.debug(new StringBuilder().append("Suspending current transaction, creating new transaction with name [")
/*  418 */           .append(definition
/*  418 */           .getName()).append("]").toString());
/*      */       }
/*  420 */       SuspendedResourcesHolder suspendedResources = suspend(transaction);
/*      */       try {
/*  422 */         boolean newSynchronization = getTransactionSynchronization() != 2;
/*  423 */         DefaultTransactionStatus status = newTransactionStatus(definition, transaction, true, newSynchronization, debugEnabled, suspendedResources);
/*      */ 
/*  425 */         doBegin(transaction, definition);
/*  426 */         prepareSynchronization(status, definition);
/*  427 */         return status;
/*      */       }
/*      */       catch (RuntimeException beginEx) {
/*  430 */         resumeAfterBeginException(transaction, suspendedResources, beginEx);
/*  431 */         throw beginEx;
/*      */       }
/*      */       catch (Error beginErr) {
/*  434 */         resumeAfterBeginException(transaction, suspendedResources, beginErr);
/*  435 */         throw beginErr;
/*      */       }
/*      */     }
/*      */ 
/*  439 */     if (definition.getPropagationBehavior() == 6) {
/*  440 */       if (!isNestedTransactionAllowed()) {
/*  441 */         throw new NestedTransactionNotSupportedException("Transaction manager does not allow nested transactions by default - specify 'nestedTransactionAllowed' property with value 'true'");
/*      */       }
/*      */ 
/*  445 */       if (debugEnabled) {
/*  446 */         this.logger.debug(new StringBuilder().append("Creating nested transaction with name [").append(definition.getName()).append("]").toString());
/*      */       }
/*  448 */       if (useSavepointForNestedTransaction())
/*      */       {
/*  453 */         DefaultTransactionStatus status = prepareTransactionStatus(definition, transaction, false, false, debugEnabled, null);
/*      */ 
/*  454 */         status.createAndHoldSavepoint();
/*  455 */         return status;
/*      */       }
/*      */ 
/*  461 */       boolean newSynchronization = getTransactionSynchronization() != 2;
/*  462 */       DefaultTransactionStatus status = newTransactionStatus(definition, transaction, true, newSynchronization, debugEnabled, null);
/*      */ 
/*  464 */       doBegin(transaction, definition);
/*  465 */       prepareSynchronization(status, definition);
/*  466 */       return status;
/*      */     }
/*      */ 
/*  471 */     if (debugEnabled) {
/*  472 */       this.logger.debug("Participating in existing transaction");
/*      */     }
/*  474 */     if (isValidateExistingTransaction()) {
/*  475 */       if (definition.getIsolationLevel() != -1) {
/*  476 */         Integer currentIsolationLevel = TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/*  477 */         if ((currentIsolationLevel == null) || (currentIsolationLevel.intValue() != definition.getIsolationLevel())) {
/*  478 */           Constants isoConstants = DefaultTransactionDefinition.constants;
/*      */ 
/*  482 */           throw new IllegalTransactionStateException(new StringBuilder().append("Participating transaction with definition [").append(definition).append("] specifies isolation level which is incompatible with existing transaction: ")
/*  482 */             .append(currentIsolationLevel != null ? isoConstants
/*  482 */             .toCode(currentIsolationLevel, "ISOLATION_") : 
/*  482 */             "(unknown)").toString());
/*      */         }
/*      */       }
/*      */ 
/*  486 */       if ((!definition.isReadOnly()) && 
/*  487 */         (TransactionSynchronizationManager.isCurrentTransactionReadOnly())) {
/*  488 */         throw new IllegalTransactionStateException(new StringBuilder().append("Participating transaction with definition [").append(definition).append("] is not marked as read-only but existing transaction is").toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  493 */     boolean newSynchronization = getTransactionSynchronization() != 2;
/*  494 */     return prepareTransactionStatus(definition, transaction, false, newSynchronization, debugEnabled, null);
/*      */   }
/*      */ 
/*      */   protected final DefaultTransactionStatus prepareTransactionStatus(TransactionDefinition definition, Object transaction, boolean newTransaction, boolean newSynchronization, boolean debug, Object suspendedResources)
/*      */   {
/*  507 */     DefaultTransactionStatus status = newTransactionStatus(definition, transaction, newTransaction, newSynchronization, debug, suspendedResources);
/*      */ 
/*  509 */     prepareSynchronization(status, definition);
/*  510 */     return status;
/*      */   }
/*      */ 
/*      */   protected DefaultTransactionStatus newTransactionStatus(TransactionDefinition definition, Object transaction, boolean newTransaction, boolean newSynchronization, boolean debug, Object suspendedResources)
/*      */   {
/*  521 */     boolean actualNewSynchronization = (newSynchronization) && 
/*  521 */       (!TransactionSynchronizationManager.isSynchronizationActive());
/*      */ 
/*  524 */     return new DefaultTransactionStatus(transaction, newTransaction, actualNewSynchronization, definition
/*  524 */       .isReadOnly(), debug, suspendedResources);
/*      */   }
/*      */ 
/*      */   protected void prepareSynchronization(DefaultTransactionStatus status, TransactionDefinition definition)
/*      */   {
/*  531 */     if (status.isNewSynchronization()) {
/*  532 */       TransactionSynchronizationManager.setActualTransactionActive(status.hasTransaction());
/*  533 */       TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(definition
/*  534 */         .getIsolationLevel() != -1 ? 
/*  535 */         Integer.valueOf(definition
/*  535 */         .getIsolationLevel()) : null);
/*  536 */       TransactionSynchronizationManager.setCurrentTransactionReadOnly(definition.isReadOnly());
/*  537 */       TransactionSynchronizationManager.setCurrentTransactionName(definition.getName());
/*  538 */       TransactionSynchronizationManager.initSynchronization();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected int determineTimeout(TransactionDefinition definition)
/*      */   {
/*  552 */     if (definition.getTimeout() != -1) {
/*  553 */       return definition.getTimeout();
/*      */     }
/*  555 */     return this.defaultTimeout;
/*      */   }
/*      */ 
/*      */   protected final SuspendedResourcesHolder suspend(Object transaction)
/*      */     throws TransactionException
/*      */   {
/*  570 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/*  571 */       List suspendedSynchronizations = doSuspendSynchronization();
/*      */       try {
/*  573 */         Object suspendedResources = null;
/*  574 */         if (transaction != null) {
/*  575 */           suspendedResources = doSuspend(transaction);
/*      */         }
/*  577 */         String name = TransactionSynchronizationManager.getCurrentTransactionName();
/*  578 */         TransactionSynchronizationManager.setCurrentTransactionName(null);
/*  579 */         boolean readOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
/*  580 */         TransactionSynchronizationManager.setCurrentTransactionReadOnly(false);
/*  581 */         Integer isolationLevel = TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/*  582 */         TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(null);
/*  583 */         boolean wasActive = TransactionSynchronizationManager.isActualTransactionActive();
/*  584 */         TransactionSynchronizationManager.setActualTransactionActive(false);
/*  585 */         return new SuspendedResourcesHolder(suspendedResources, suspendedSynchronizations, name, readOnly, isolationLevel, wasActive, null);
/*      */       }
/*      */       catch (RuntimeException ex)
/*      */       {
/*  590 */         doResumeSynchronization(suspendedSynchronizations);
/*  591 */         throw ex;
/*      */       }
/*      */       catch (Error err)
/*      */       {
/*  595 */         doResumeSynchronization(suspendedSynchronizations);
/*  596 */         throw err;
/*      */       }
/*      */     }
/*  599 */     if (transaction != null)
/*      */     {
/*  601 */       Object suspendedResources = doSuspend(transaction);
/*  602 */       return new SuspendedResourcesHolder(suspendedResources, null);
/*      */     }
/*      */ 
/*  606 */     return null;
/*      */   }
/*      */ 
/*      */   protected final void resume(Object transaction, SuspendedResourcesHolder resourcesHolder)
/*      */     throws TransactionException
/*      */   {
/*  623 */     if (resourcesHolder != null) {
/*  624 */       Object suspendedResources = resourcesHolder.suspendedResources;
/*  625 */       if (suspendedResources != null) {
/*  626 */         doResume(transaction, suspendedResources);
/*      */       }
/*  628 */       List suspendedSynchronizations = resourcesHolder.suspendedSynchronizations;
/*  629 */       if (suspendedSynchronizations != null) {
/*  630 */         TransactionSynchronizationManager.setActualTransactionActive(resourcesHolder.wasActive);
/*  631 */         TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(resourcesHolder.isolationLevel);
/*  632 */         TransactionSynchronizationManager.setCurrentTransactionReadOnly(resourcesHolder.readOnly);
/*  633 */         TransactionSynchronizationManager.setCurrentTransactionName(resourcesHolder.name);
/*  634 */         doResumeSynchronization(suspendedSynchronizations);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void resumeAfterBeginException(Object transaction, SuspendedResourcesHolder suspendedResources, Throwable beginEx)
/*      */   {
/*  645 */     String exMessage = "Inner transaction begin exception overridden by outer transaction resume exception";
/*      */     try {
/*  647 */       resume(transaction, suspendedResources);
/*      */     }
/*      */     catch (RuntimeException resumeEx) {
/*  650 */       this.logger.error(exMessage, beginEx);
/*  651 */       throw resumeEx;
/*      */     }
/*      */     catch (Error resumeErr) {
/*  654 */       this.logger.error(exMessage, beginEx);
/*  655 */       throw resumeErr;
/*      */     }
/*      */   }
/*      */ 
/*      */   private List<TransactionSynchronization> doSuspendSynchronization()
/*      */   {
/*  666 */     List suspendedSynchronizations = TransactionSynchronizationManager.getSynchronizations();
/*  667 */     for (TransactionSynchronization synchronization : suspendedSynchronizations) {
/*  668 */       synchronization.suspend();
/*      */     }
/*  670 */     TransactionSynchronizationManager.clearSynchronization();
/*  671 */     return suspendedSynchronizations;
/*      */   }
/*      */ 
/*      */   private void doResumeSynchronization(List<TransactionSynchronization> suspendedSynchronizations)
/*      */   {
/*  680 */     TransactionSynchronizationManager.initSynchronization();
/*  681 */     for (TransactionSynchronization synchronization : suspendedSynchronizations) {
/*  682 */       synchronization.resume();
/*  683 */       TransactionSynchronizationManager.registerSynchronization(synchronization);
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void commit(TransactionStatus status)
/*      */     throws TransactionException
/*      */   {
/*  699 */     if (status.isCompleted()) {
/*  700 */       throw new IllegalTransactionStateException("Transaction is already completed - do not call commit or rollback more than once per transaction");
/*      */     }
/*      */ 
/*  704 */     DefaultTransactionStatus defStatus = (DefaultTransactionStatus)status;
/*  705 */     if (defStatus.isLocalRollbackOnly()) {
/*  706 */       if (defStatus.isDebug()) {
/*  707 */         this.logger.debug("Transactional code has requested rollback");
/*      */       }
/*  709 */       processRollback(defStatus);
/*  710 */       return;
/*      */     }
/*  712 */     if ((!shouldCommitOnGlobalRollbackOnly()) && (defStatus.isGlobalRollbackOnly())) {
/*  713 */       if (defStatus.isDebug()) {
/*  714 */         this.logger.debug("Global transaction is marked as rollback-only but transactional code requested commit");
/*      */       }
/*  716 */       processRollback(defStatus);
/*      */ 
/*  719 */       if ((status.isNewTransaction()) || (isFailEarlyOnGlobalRollbackOnly())) {
/*  720 */         throw new UnexpectedRollbackException("Transaction rolled back because it has been marked as rollback-only");
/*      */       }
/*      */ 
/*  723 */       return;
/*      */     }
/*      */ 
/*  726 */     processCommit(defStatus);
/*      */   }
/*      */ 
/*      */   private void processCommit(DefaultTransactionStatus status)
/*      */     throws TransactionException
/*      */   {
/*      */     try
/*      */     {
/*  737 */       boolean beforeCompletionInvoked = false;
/*      */       try {
/*  739 */         prepareForCommit(status);
/*  740 */         triggerBeforeCommit(status);
/*  741 */         triggerBeforeCompletion(status);
/*  742 */         beforeCompletionInvoked = true;
/*  743 */         boolean globalRollbackOnly = false;
/*  744 */         if ((status.isNewTransaction()) || (isFailEarlyOnGlobalRollbackOnly())) {
/*  745 */           globalRollbackOnly = status.isGlobalRollbackOnly();
/*      */         }
/*  747 */         if (status.hasSavepoint()) {
/*  748 */           if (status.isDebug()) {
/*  749 */             this.logger.debug("Releasing transaction savepoint");
/*      */           }
/*  751 */           status.releaseHeldSavepoint();
/*      */         }
/*  753 */         else if (status.isNewTransaction()) {
/*  754 */           if (status.isDebug()) {
/*  755 */             this.logger.debug("Initiating transaction commit");
/*      */           }
/*  757 */           doCommit(status);
/*      */         }
/*      */ 
/*  761 */         if (globalRollbackOnly) {
/*  762 */           throw new UnexpectedRollbackException("Transaction silently rolled back because it has been marked as rollback-only");
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (UnexpectedRollbackException ex)
/*      */       {
/*  768 */         triggerAfterCompletion(status, 1);
/*  769 */         throw ex;
/*      */       }
/*      */       catch (TransactionException ex)
/*      */       {
/*  773 */         if (isRollbackOnCommitFailure()) {
/*  774 */           doRollbackOnCommitException(status, ex);
/*      */         }
/*      */         else {
/*  777 */           triggerAfterCompletion(status, 2);
/*      */         }
/*  779 */         throw ex;
/*      */       }
/*      */       catch (RuntimeException ex) {
/*  782 */         if (!beforeCompletionInvoked) {
/*  783 */           triggerBeforeCompletion(status);
/*      */         }
/*  785 */         doRollbackOnCommitException(status, ex);
/*  786 */         throw ex;
/*      */       }
/*      */       catch (Error err) {
/*  789 */         if (!beforeCompletionInvoked) {
/*  790 */           triggerBeforeCompletion(status);
/*      */         }
/*  792 */         doRollbackOnCommitException(status, err);
/*  793 */         throw err;
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*      */       }
/*      */       finally
/*      */       {
/*  802 */         triggerAfterCompletion(status, 0);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  807 */       cleanupAfterCompletion(status);
/*      */     }
/*      */   }
/*      */ 
/*      */   public final void rollback(TransactionStatus status)
/*      */     throws TransactionException
/*      */   {
/*  820 */     if (status.isCompleted()) {
/*  821 */       throw new IllegalTransactionStateException("Transaction is already completed - do not call commit or rollback more than once per transaction");
/*      */     }
/*      */ 
/*  825 */     DefaultTransactionStatus defStatus = (DefaultTransactionStatus)status;
/*  826 */     processRollback(defStatus); } 
/*      */   // ERROR //
/*      */   private void processRollback(DefaultTransactionStatus status) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_1
/*      */     //   2: invokevirtual 131	org/springframework/transaction/support/AbstractPlatformTransactionManager:triggerBeforeCompletion	(Lorg/springframework/transaction/support/DefaultTransactionStatus;)V
/*      */     //   5: aload_1
/*      */     //   6: invokevirtual 133	org/springframework/transaction/support/DefaultTransactionStatus:hasSavepoint	()Z
/*      */     //   9: ifeq +28 -> 37
/*      */     //   12: aload_1
/*      */     //   13: invokevirtual 117	org/springframework/transaction/support/DefaultTransactionStatus:isDebug	()Z
/*      */     //   16: ifeq +14 -> 30
/*      */     //   19: aload_0
/*      */     //   20: getfield 4	org/springframework/transaction/support/AbstractPlatformTransactionManager:logger	Lorg/apache/commons/logging/Log;
/*      */     //   23: ldc 145
/*      */     //   25: invokeinterface 42 2 0
/*      */     //   30: aload_1
/*      */     //   31: invokevirtual 146	org/springframework/transaction/support/DefaultTransactionStatus:rollbackToHeldSavepoint	()V
/*      */     //   34: goto +115 -> 149
/*      */     //   37: aload_1
/*      */     //   38: invokevirtual 132	org/springframework/transaction/support/DefaultTransactionStatus:isNewTransaction	()Z
/*      */     //   41: ifeq +29 -> 70
/*      */     //   44: aload_1
/*      */     //   45: invokevirtual 117	org/springframework/transaction/support/DefaultTransactionStatus:isDebug	()Z
/*      */     //   48: ifeq +14 -> 62
/*      */     //   51: aload_0
/*      */     //   52: getfield 4	org/springframework/transaction/support/AbstractPlatformTransactionManager:logger	Lorg/apache/commons/logging/Log;
/*      */     //   55: ldc 147
/*      */     //   57: invokeinterface 42 2 0
/*      */     //   62: aload_0
/*      */     //   63: aload_1
/*      */     //   64: invokevirtual 148	org/springframework/transaction/support/AbstractPlatformTransactionManager:doRollback	(Lorg/springframework/transaction/support/DefaultTransactionStatus;)V
/*      */     //   67: goto +82 -> 149
/*      */     //   70: aload_1
/*      */     //   71: invokevirtual 81	org/springframework/transaction/support/DefaultTransactionStatus:hasTransaction	()Z
/*      */     //   74: ifeq +64 -> 138
/*      */     //   77: aload_1
/*      */     //   78: invokevirtual 116	org/springframework/transaction/support/DefaultTransactionStatus:isLocalRollbackOnly	()Z
/*      */     //   81: ifne +10 -> 91
/*      */     //   84: aload_0
/*      */     //   85: invokevirtual 149	org/springframework/transaction/support/AbstractPlatformTransactionManager:isGlobalRollbackOnParticipationFailure	()Z
/*      */     //   88: ifeq +29 -> 117
/*      */     //   91: aload_1
/*      */     //   92: invokevirtual 117	org/springframework/transaction/support/DefaultTransactionStatus:isDebug	()Z
/*      */     //   95: ifeq +14 -> 109
/*      */     //   98: aload_0
/*      */     //   99: getfield 4	org/springframework/transaction/support/AbstractPlatformTransactionManager:logger	Lorg/apache/commons/logging/Log;
/*      */     //   102: ldc 150
/*      */     //   104: invokeinterface 42 2 0
/*      */     //   109: aload_0
/*      */     //   110: aload_1
/*      */     //   111: invokevirtual 151	org/springframework/transaction/support/AbstractPlatformTransactionManager:doSetRollbackOnly	(Lorg/springframework/transaction/support/DefaultTransactionStatus;)V
/*      */     //   114: goto +35 -> 149
/*      */     //   117: aload_1
/*      */     //   118: invokevirtual 117	org/springframework/transaction/support/DefaultTransactionStatus:isDebug	()Z
/*      */     //   121: ifeq +28 -> 149
/*      */     //   124: aload_0
/*      */     //   125: getfield 4	org/springframework/transaction/support/AbstractPlatformTransactionManager:logger	Lorg/apache/commons/logging/Log;
/*      */     //   128: ldc 152
/*      */     //   130: invokeinterface 42 2 0
/*      */     //   135: goto +14 -> 149
/*      */     //   138: aload_0
/*      */     //   139: getfield 4	org/springframework/transaction/support/AbstractPlatformTransactionManager:logger	Lorg/apache/commons/logging/Log;
/*      */     //   142: ldc 153
/*      */     //   144: invokeinterface 42 2 0
/*      */     //   149: goto +21 -> 170
/*      */     //   152: astore_2
/*      */     //   153: aload_0
/*      */     //   154: aload_1
/*      */     //   155: iconst_2
/*      */     //   156: invokespecial 139	org/springframework/transaction/support/AbstractPlatformTransactionManager:triggerAfterCompletion	(Lorg/springframework/transaction/support/DefaultTransactionStatus;I)V
/*      */     //   159: aload_2
/*      */     //   160: athrow
/*      */     //   161: astore_2
/*      */     //   162: aload_0
/*      */     //   163: aload_1
/*      */     //   164: iconst_2
/*      */     //   165: invokespecial 139	org/springframework/transaction/support/AbstractPlatformTransactionManager:triggerAfterCompletion	(Lorg/springframework/transaction/support/DefaultTransactionStatus;I)V
/*      */     //   168: aload_2
/*      */     //   169: athrow
/*      */     //   170: aload_0
/*      */     //   171: aload_1
/*      */     //   172: iconst_1
/*      */     //   173: invokespecial 139	org/springframework/transaction/support/AbstractPlatformTransactionManager:triggerAfterCompletion	(Lorg/springframework/transaction/support/DefaultTransactionStatus;I)V
/*      */     //   176: aload_0
/*      */     //   177: aload_1
/*      */     //   178: invokespecial 144	org/springframework/transaction/support/AbstractPlatformTransactionManager:cleanupAfterCompletion	(Lorg/springframework/transaction/support/DefaultTransactionStatus;)V
/*      */     //   181: goto +11 -> 192
/*      */     //   184: astore_3
/*      */     //   185: aload_0
/*      */     //   186: aload_1
/*      */     //   187: invokespecial 144	org/springframework/transaction/support/AbstractPlatformTransactionManager:cleanupAfterCompletion	(Lorg/springframework/transaction/support/DefaultTransactionStatus;)V
/*      */     //   190: aload_3
/*      */     //   191: athrow
/*      */     //   192: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	149	152	java/lang/RuntimeException
/*      */     //   0	149	161	java/lang/Error
/*      */     //   0	176	184	finally } 
/*      */   private void doRollbackOnCommitException(DefaultTransactionStatus status, Throwable ex) throws TransactionException { try { if (status.isNewTransaction()) {
/*  893 */         if (status.isDebug()) {
/*  894 */           this.logger.debug("Initiating transaction rollback after commit exception", ex);
/*      */         }
/*  896 */         doRollback(status);
/*      */       }
/*  898 */       else if ((status.hasTransaction()) && (isGlobalRollbackOnParticipationFailure())) {
/*  899 */         if (status.isDebug()) {
/*  900 */           this.logger.debug("Marking existing transaction as rollback-only after commit exception", ex);
/*      */         }
/*  902 */         doSetRollbackOnly(status);
/*      */       }
/*      */     } catch (RuntimeException rbex)
/*      */     {
/*  906 */       this.logger.error("Commit exception overridden by rollback exception", ex);
/*  907 */       triggerAfterCompletion(status, 2);
/*  908 */       throw rbex;
/*      */     }
/*      */     catch (Error rberr) {
/*  911 */       this.logger.error("Commit exception overridden by rollback exception", ex);
/*  912 */       triggerAfterCompletion(status, 2);
/*  913 */       throw rberr;
/*      */     }
/*  915 */     triggerAfterCompletion(status, 1);
/*      */   }
/*      */ 
/*      */   protected final void triggerBeforeCommit(DefaultTransactionStatus status)
/*      */   {
/*  924 */     if (status.isNewSynchronization()) {
/*  925 */       if (status.isDebug()) {
/*  926 */         this.logger.trace("Triggering beforeCommit synchronization");
/*      */       }
/*  928 */       TransactionSynchronizationUtils.triggerBeforeCommit(status.isReadOnly());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void triggerBeforeCompletion(DefaultTransactionStatus status)
/*      */   {
/*  937 */     if (status.isNewSynchronization()) {
/*  938 */       if (status.isDebug()) {
/*  939 */         this.logger.trace("Triggering beforeCompletion synchronization");
/*      */       }
/*  941 */       TransactionSynchronizationUtils.triggerBeforeCompletion();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void triggerAfterCommit(DefaultTransactionStatus status)
/*      */   {
/*  950 */     if (status.isNewSynchronization()) {
/*  951 */       if (status.isDebug()) {
/*  952 */         this.logger.trace("Triggering afterCommit synchronization");
/*      */       }
/*  954 */       TransactionSynchronizationUtils.triggerAfterCommit();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void triggerAfterCompletion(DefaultTransactionStatus status, int completionStatus)
/*      */   {
/*  964 */     if (status.isNewSynchronization()) {
/*  965 */       List synchronizations = TransactionSynchronizationManager.getSynchronizations();
/*  966 */       if ((!status.hasTransaction()) || (status.isNewTransaction())) {
/*  967 */         if (status.isDebug()) {
/*  968 */           this.logger.trace("Triggering afterCompletion synchronization");
/*      */         }
/*      */ 
/*  972 */         invokeAfterCompletion(synchronizations, completionStatus);
/*      */       }
/*  974 */       else if (!synchronizations.isEmpty())
/*      */       {
/*  978 */         registerAfterCompletionWithExistingTransaction(status.getTransaction(), synchronizations);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void invokeAfterCompletion(List<TransactionSynchronization> synchronizations, int completionStatus)
/*      */   {
/*  997 */     TransactionSynchronizationUtils.invokeAfterCompletion(synchronizations, completionStatus);
/*      */   }
/*      */ 
/*      */   private void cleanupAfterCompletion(DefaultTransactionStatus status)
/*      */   {
/* 1007 */     status.setCompleted();
/* 1008 */     if (status.isNewSynchronization()) {
/* 1009 */       TransactionSynchronizationManager.clear();
/*      */     }
/* 1011 */     if (status.isNewTransaction()) {
/* 1012 */       doCleanupAfterCompletion(status.getTransaction());
/*      */     }
/* 1014 */     if (status.getSuspendedResources() != null) {
/* 1015 */       if (status.isDebug()) {
/* 1016 */         this.logger.debug("Resuming suspended transaction after completion of inner transaction");
/*      */       }
/* 1018 */       resume(status.getTransaction(), (SuspendedResourcesHolder)status.getSuspendedResources());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected abstract Object doGetTransaction()
/*      */     throws TransactionException;
/*      */ 
/*      */   protected boolean isExistingTransaction(Object transaction)
/*      */     throws TransactionException
/*      */   {
/* 1067 */     return false;
/*      */   }
/*      */ 
/*      */   protected boolean useSavepointForNestedTransaction()
/*      */   {
/* 1087 */     return true;
/*      */   }
/*      */ 
/*      */   protected abstract void doBegin(Object paramObject, TransactionDefinition paramTransactionDefinition)
/*      */     throws TransactionException;
/*      */ 
/*      */   protected Object doSuspend(Object transaction)
/*      */     throws TransactionException
/*      */   {
/* 1125 */     throw new TransactionSuspensionNotSupportedException(new StringBuilder().append("Transaction manager [")
/* 1125 */       .append(getClass().getName()).append("] does not support transaction suspension").toString());
/*      */   }
/*      */ 
/*      */   protected void doResume(Object transaction, Object suspendedResources)
/*      */     throws TransactionException
/*      */   {
/* 1143 */     throw new TransactionSuspensionNotSupportedException(new StringBuilder().append("Transaction manager [")
/* 1143 */       .append(getClass().getName()).append("] does not support transaction suspension").toString());
/*      */   }
/*      */ 
/*      */   protected boolean shouldCommitOnGlobalRollbackOnly()
/*      */   {
/* 1176 */     return false;
/*      */   }
/*      */ 
/*      */   protected void prepareForCommit(DefaultTransactionStatus status)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected abstract void doCommit(DefaultTransactionStatus paramDefaultTransactionStatus)
/*      */     throws TransactionException;
/*      */ 
/*      */   protected abstract void doRollback(DefaultTransactionStatus paramDefaultTransactionStatus)
/*      */     throws TransactionException;
/*      */ 
/*      */   protected void doSetRollbackOnly(DefaultTransactionStatus status)
/*      */     throws TransactionException
/*      */   {
/* 1224 */     throw new IllegalTransactionStateException("Participating in existing transactions is not supported - when 'isExistingTransaction' returns true, appropriate 'doSetRollbackOnly' behavior must be provided");
/*      */   }
/*      */ 
/*      */   protected void registerAfterCompletionWithExistingTransaction(Object transaction, List<TransactionSynchronization> synchronizations)
/*      */     throws TransactionException
/*      */   {
/* 1247 */     this.logger.debug("Cannot register Spring after-completion synchronization with existing transaction - processing Spring after-completion callbacks immediately, with outcome status 'unknown'");
/*      */ 
/* 1249 */     invokeAfterCompletion(synchronizations, 2);
/*      */   }
/*      */ 
/*      */   protected void doCleanupAfterCompletion(Object transaction)
/*      */   {
/*      */   }
/*      */ 
/*      */   private void readObject(ObjectInputStream ois)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1269 */     ois.defaultReadObject();
/*      */ 
/* 1272 */     this.logger = LogFactory.getLog(getClass());
/*      */   }
/*      */ 
/*      */   protected static class SuspendedResourcesHolder {
/*      */     private final Object suspendedResources;
/*      */     private List<TransactionSynchronization> suspendedSynchronizations;
/*      */     private String name;
/*      */     private boolean readOnly;
/*      */     private Integer isolationLevel;
/*      */     private boolean wasActive;
/*      */ 
/*      */     private SuspendedResourcesHolder(Object suspendedResources) {
/* 1289 */       this.suspendedResources = suspendedResources;
/*      */     }
/*      */ 
/*      */     private SuspendedResourcesHolder(Object suspendedResources, List<TransactionSynchronization> suspendedSynchronizations, String name, boolean readOnly, Integer isolationLevel, boolean wasActive)
/*      */     {
/* 1295 */       this.suspendedResources = suspendedResources;
/* 1296 */       this.suspendedSynchronizations = suspendedSynchronizations;
/* 1297 */       this.name = name;
/* 1298 */       this.readOnly = readOnly;
/* 1299 */       this.isolationLevel = isolationLevel;
/* 1300 */       this.wasActive = wasActive;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.AbstractPlatformTransactionManager
 * JD-Core Version:    0.6.2
 */