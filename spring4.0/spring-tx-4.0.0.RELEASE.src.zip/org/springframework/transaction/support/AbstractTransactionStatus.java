/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*     */ import org.springframework.transaction.SavepointManager;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionStatus;
/*     */ import org.springframework.transaction.TransactionUsageException;
/*     */ 
/*     */ public abstract class AbstractTransactionStatus
/*     */   implements TransactionStatus
/*     */ {
/*  48 */   private boolean rollbackOnly = false;
/*     */ 
/*  50 */   private boolean completed = false;
/*     */   private Object savepoint;
/*     */ 
/*     */   public void setRollbackOnly()
/*     */   {
/*  61 */     this.rollbackOnly = true;
/*     */   }
/*     */ 
/*     */   public boolean isRollbackOnly()
/*     */   {
/*  73 */     return (isLocalRollbackOnly()) || (isGlobalRollbackOnly());
/*     */   }
/*     */ 
/*     */   public boolean isLocalRollbackOnly()
/*     */   {
/*  82 */     return this.rollbackOnly;
/*     */   }
/*     */ 
/*     */   public boolean isGlobalRollbackOnly()
/*     */   {
/*  91 */     return false;
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setCompleted()
/*     */   {
/* 105 */     this.completed = true;
/*     */   }
/*     */ 
/*     */   public boolean isCompleted()
/*     */   {
/* 110 */     return this.completed;
/*     */   }
/*     */ 
/*     */   protected void setSavepoint(Object savepoint)
/*     */   {
/* 123 */     this.savepoint = savepoint;
/*     */   }
/*     */ 
/*     */   protected Object getSavepoint()
/*     */   {
/* 130 */     return this.savepoint;
/*     */   }
/*     */ 
/*     */   public boolean hasSavepoint()
/*     */   {
/* 135 */     return this.savepoint != null;
/*     */   }
/*     */ 
/*     */   public void createAndHoldSavepoint()
/*     */     throws TransactionException
/*     */   {
/* 144 */     setSavepoint(getSavepointManager().createSavepoint());
/*     */   }
/*     */ 
/*     */   public void rollbackToHeldSavepoint()
/*     */     throws TransactionException
/*     */   {
/* 151 */     if (!hasSavepoint()) {
/* 152 */       throw new TransactionUsageException("No savepoint associated with current transaction");
/*     */     }
/* 154 */     getSavepointManager().rollbackToSavepoint(getSavepoint());
/* 155 */     setSavepoint(null);
/*     */   }
/*     */ 
/*     */   public void releaseHeldSavepoint()
/*     */     throws TransactionException
/*     */   {
/* 162 */     if (!hasSavepoint()) {
/* 163 */       throw new TransactionUsageException("No savepoint associated with current transaction");
/*     */     }
/* 165 */     getSavepointManager().releaseSavepoint(getSavepoint());
/* 166 */     setSavepoint(null);
/*     */   }
/*     */ 
/*     */   public Object createSavepoint()
/*     */     throws TransactionException
/*     */   {
/* 182 */     return getSavepointManager().createSavepoint();
/*     */   }
/*     */ 
/*     */   public void rollbackToSavepoint(Object savepoint)
/*     */     throws TransactionException
/*     */   {
/* 194 */     getSavepointManager().rollbackToSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */   public void releaseSavepoint(Object savepoint)
/*     */     throws TransactionException
/*     */   {
/* 205 */     getSavepointManager().releaseSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */   protected SavepointManager getSavepointManager()
/*     */   {
/* 215 */     throw new NestedTransactionNotSupportedException("This transaction does not support savepoints");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.AbstractTransactionStatus
 * JD-Core Version:    0.6.2
 */