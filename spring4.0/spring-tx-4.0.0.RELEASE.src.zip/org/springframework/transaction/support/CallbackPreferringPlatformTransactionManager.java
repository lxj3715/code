package org.springframework.transaction.support;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;

public abstract interface CallbackPreferringPlatformTransactionManager extends PlatformTransactionManager
{
  public abstract <T> T execute(TransactionDefinition paramTransactionDefinition, TransactionCallback<T> paramTransactionCallback)
    throws TransactionException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.CallbackPreferringPlatformTransactionManager
 * JD-Core Version:    0.6.2
 */