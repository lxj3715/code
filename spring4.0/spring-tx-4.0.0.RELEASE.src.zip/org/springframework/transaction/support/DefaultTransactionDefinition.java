/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ 
/*     */ public class DefaultTransactionDefinition
/*     */   implements TransactionDefinition, Serializable
/*     */ {
/*     */   public static final String PREFIX_PROPAGATION = "PROPAGATION_";
/*     */   public static final String PREFIX_ISOLATION = "ISOLATION_";
/*     */   public static final String PREFIX_TIMEOUT = "timeout_";
/*     */   public static final String READ_ONLY_MARKER = "readOnly";
/*  52 */   static final Constants constants = new Constants(Serializable.class);
/*     */ 
/*  54 */   private int propagationBehavior = 0;
/*     */ 
/*  56 */   private int isolationLevel = -1;
/*     */ 
/*  58 */   private int timeout = -1;
/*     */ 
/*  60 */   private boolean readOnly = false;
/*     */   private String name;
/*     */ 
/*     */   public DefaultTransactionDefinition()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DefaultTransactionDefinition(TransactionDefinition other)
/*     */   {
/*  86 */     this.propagationBehavior = other.getPropagationBehavior();
/*  87 */     this.isolationLevel = other.getIsolationLevel();
/*  88 */     this.timeout = other.getTimeout();
/*  89 */     this.readOnly = other.isReadOnly();
/*  90 */     this.name = other.getName();
/*     */   }
/*     */ 
/*     */   public DefaultTransactionDefinition(int propagationBehavior)
/*     */   {
/* 103 */     this.propagationBehavior = propagationBehavior;
/*     */   }
/*     */ 
/*     */   public final void setPropagationBehaviorName(String constantName)
/*     */     throws IllegalArgumentException
/*     */   {
/* 117 */     if ((constantName == null) || (!constantName.startsWith("PROPAGATION_"))) {
/* 118 */       throw new IllegalArgumentException("Only propagation constants allowed");
/*     */     }
/* 120 */     setPropagationBehavior(constants.asNumber(constantName).intValue());
/*     */   }
/*     */ 
/*     */   public final void setPropagationBehavior(int propagationBehavior)
/*     */   {
/* 131 */     if (!constants.getValues("PROPAGATION_").contains(Integer.valueOf(propagationBehavior))) {
/* 132 */       throw new IllegalArgumentException("Only values of propagation constants allowed");
/*     */     }
/* 134 */     this.propagationBehavior = propagationBehavior;
/*     */   }
/*     */ 
/*     */   public final int getPropagationBehavior()
/*     */   {
/* 139 */     return this.propagationBehavior;
/*     */   }
/*     */ 
/*     */   public final void setIsolationLevelName(String constantName)
/*     */     throws IllegalArgumentException
/*     */   {
/* 152 */     if ((constantName == null) || (!constantName.startsWith("ISOLATION_"))) {
/* 153 */       throw new IllegalArgumentException("Only isolation constants allowed");
/*     */     }
/* 155 */     setIsolationLevel(constants.asNumber(constantName).intValue());
/*     */   }
/*     */ 
/*     */   public final void setIsolationLevel(int isolationLevel)
/*     */   {
/* 166 */     if (!constants.getValues("ISOLATION_").contains(Integer.valueOf(isolationLevel))) {
/* 167 */       throw new IllegalArgumentException("Only values of isolation constants allowed");
/*     */     }
/* 169 */     this.isolationLevel = isolationLevel;
/*     */   }
/*     */ 
/*     */   public final int getIsolationLevel()
/*     */   {
/* 174 */     return this.isolationLevel;
/*     */   }
/*     */ 
/*     */   public final void setTimeout(int timeout)
/*     */   {
/* 183 */     if (timeout < -1) {
/* 184 */       throw new IllegalArgumentException("Timeout must be a positive integer or TIMEOUT_DEFAULT");
/*     */     }
/* 186 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public final int getTimeout()
/*     */   {
/* 191 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public final void setReadOnly(boolean readOnly)
/*     */   {
/* 199 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */   public final boolean isReadOnly()
/*     */   {
/* 204 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */   public final void setName(String name)
/*     */   {
/* 213 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public final String getName()
/*     */   {
/* 218 */     return this.name;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 228 */     return ((other instanceof Serializable)) && (toString().equals(other.toString()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 237 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 254 */     return getDefinitionDescription().toString();
/*     */   }
/*     */ 
/*     */   protected final StringBuilder getDefinitionDescription()
/*     */   {
/* 262 */     StringBuilder result = new StringBuilder();
/* 263 */     result.append(constants.toCode(Integer.valueOf(this.propagationBehavior), "PROPAGATION_"));
/* 264 */     result.append(',');
/* 265 */     result.append(constants.toCode(Integer.valueOf(this.isolationLevel), "ISOLATION_"));
/* 266 */     if (this.timeout != -1) {
/* 267 */       result.append(',');
/* 268 */       result.append("timeout_").append(this.timeout);
/*     */     }
/* 270 */     if (this.readOnly) {
/* 271 */       result.append(',');
/* 272 */       result.append("readOnly");
/*     */     }
/* 274 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.DefaultTransactionDefinition
 * JD-Core Version:    0.6.2
 */