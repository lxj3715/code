/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*     */ import org.springframework.transaction.SavepointManager;
/*     */ 
/*     */ public class DefaultTransactionStatus extends AbstractTransactionStatus
/*     */ {
/*     */   private final Object transaction;
/*     */   private final boolean newTransaction;
/*     */   private final boolean newSynchronization;
/*     */   private final boolean readOnly;
/*     */   private final boolean debug;
/*     */   private final Object suspendedResources;
/*     */ 
/*     */   public DefaultTransactionStatus(Object transaction, boolean newTransaction, boolean newSynchronization, boolean readOnly, boolean debug, Object suspendedResources)
/*     */   {
/*  83 */     this.transaction = transaction;
/*  84 */     this.newTransaction = newTransaction;
/*  85 */     this.newSynchronization = newSynchronization;
/*  86 */     this.readOnly = readOnly;
/*  87 */     this.debug = debug;
/*  88 */     this.suspendedResources = suspendedResources;
/*     */   }
/*     */ 
/*     */   public Object getTransaction()
/*     */   {
/*  96 */     return this.transaction;
/*     */   }
/*     */ 
/*     */   public boolean hasTransaction()
/*     */   {
/* 103 */     return this.transaction != null;
/*     */   }
/*     */ 
/*     */   public boolean isNewTransaction()
/*     */   {
/* 108 */     return (hasTransaction()) && (this.newTransaction);
/*     */   }
/*     */ 
/*     */   public boolean isNewSynchronization()
/*     */   {
/* 116 */     return this.newSynchronization;
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly()
/*     */   {
/* 123 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */   public boolean isDebug()
/*     */   {
/* 132 */     return this.debug;
/*     */   }
/*     */ 
/*     */   public Object getSuspendedResources()
/*     */   {
/* 140 */     return this.suspendedResources;
/*     */   }
/*     */ 
/*     */   public boolean isGlobalRollbackOnly()
/*     */   {
/* 158 */     return ((this.transaction instanceof SmartTransactionObject)) && 
/* 158 */       (((SmartTransactionObject)this.transaction)
/* 158 */       .isRollbackOnly());
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/* 167 */     if ((this.transaction instanceof SmartTransactionObject))
/* 168 */       ((SmartTransactionObject)this.transaction).flush();
/*     */   }
/*     */ 
/*     */   protected SavepointManager getSavepointManager()
/*     */   {
/* 178 */     if (!isTransactionSavepointManager())
/*     */     {
/* 180 */       throw new NestedTransactionNotSupportedException("Transaction object [" + 
/* 180 */         getTransaction() + "] does not support savepoints");
/*     */     }
/* 182 */     return (SavepointManager)getTransaction();
/*     */   }
/*     */ 
/*     */   public boolean isTransactionSavepointManager()
/*     */   {
/* 192 */     return getTransaction() instanceof SavepointManager;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.DefaultTransactionStatus
 * JD-Core Version:    0.6.2
 */