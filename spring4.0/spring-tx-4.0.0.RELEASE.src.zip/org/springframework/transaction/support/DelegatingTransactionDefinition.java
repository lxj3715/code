/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.transaction.TransactionDefinition;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class DelegatingTransactionDefinition
/*    */   implements TransactionDefinition, Serializable
/*    */ {
/*    */   private final TransactionDefinition targetDefinition;
/*    */ 
/*    */   public DelegatingTransactionDefinition(TransactionDefinition targetDefinition)
/*    */   {
/* 44 */     Assert.notNull(targetDefinition, "Target definition must not be null");
/* 45 */     this.targetDefinition = targetDefinition;
/*    */   }
/*    */ 
/*    */   public int getPropagationBehavior()
/*    */   {
/* 51 */     return this.targetDefinition.getPropagationBehavior();
/*    */   }
/*    */ 
/*    */   public int getIsolationLevel()
/*    */   {
/* 56 */     return this.targetDefinition.getIsolationLevel();
/*    */   }
/*    */ 
/*    */   public int getTimeout()
/*    */   {
/* 61 */     return this.targetDefinition.getTimeout();
/*    */   }
/*    */ 
/*    */   public boolean isReadOnly()
/*    */   {
/* 66 */     return this.targetDefinition.isReadOnly();
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 71 */     return this.targetDefinition.getName();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 77 */     return this.targetDefinition.equals(obj);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 82 */     return this.targetDefinition.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 87 */     return this.targetDefinition.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.DelegatingTransactionDefinition
 * JD-Core Version:    0.6.2
 */