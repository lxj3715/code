package org.springframework.transaction.support;

public abstract interface ResourceHolder
{
  public abstract void reset();

  public abstract void unbound();

  public abstract boolean isVoid();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.ResourceHolder
 * JD-Core Version:    0.6.2
 */