/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.util.Date;
/*     */ import org.springframework.transaction.TransactionTimedOutException;
/*     */ 
/*     */ public abstract class ResourceHolderSupport
/*     */   implements ResourceHolder
/*     */ {
/*  37 */   private boolean synchronizedWithTransaction = false;
/*     */ 
/*  39 */   private boolean rollbackOnly = false;
/*     */   private Date deadline;
/*  43 */   private int referenceCount = 0;
/*     */ 
/*  45 */   private boolean isVoid = false;
/*     */ 
/*     */   public void setSynchronizedWithTransaction(boolean synchronizedWithTransaction)
/*     */   {
/*  52 */     this.synchronizedWithTransaction = synchronizedWithTransaction;
/*     */   }
/*     */ 
/*     */   public boolean isSynchronizedWithTransaction()
/*     */   {
/*  59 */     return this.synchronizedWithTransaction;
/*     */   }
/*     */ 
/*     */   public void setRollbackOnly()
/*     */   {
/*  66 */     this.rollbackOnly = true;
/*     */   }
/*     */ 
/*     */   public boolean isRollbackOnly()
/*     */   {
/*  73 */     return this.rollbackOnly;
/*     */   }
/*     */ 
/*     */   public void setTimeoutInSeconds(int seconds)
/*     */   {
/*  81 */     setTimeoutInMillis(seconds * 1000);
/*     */   }
/*     */ 
/*     */   public void setTimeoutInMillis(long millis)
/*     */   {
/*  89 */     this.deadline = new Date(System.currentTimeMillis() + millis);
/*     */   }
/*     */ 
/*     */   public boolean hasTimeout()
/*     */   {
/*  96 */     return this.deadline != null;
/*     */   }
/*     */ 
/*     */   public Date getDeadline()
/*     */   {
/* 104 */     return this.deadline;
/*     */   }
/*     */ 
/*     */   public int getTimeToLiveInSeconds()
/*     */   {
/* 114 */     double diff = getTimeToLiveInMillis() / 1000.0D;
/* 115 */     int secs = (int)Math.ceil(diff);
/* 116 */     checkTransactionTimeout(secs <= 0);
/* 117 */     return secs;
/*     */   }
/*     */ 
/*     */   public long getTimeToLiveInMillis()
/*     */     throws TransactionTimedOutException
/*     */   {
/* 126 */     if (this.deadline == null) {
/* 127 */       throw new IllegalStateException("No timeout specified for this resource holder");
/*     */     }
/* 129 */     long timeToLive = this.deadline.getTime() - System.currentTimeMillis();
/* 130 */     checkTransactionTimeout(timeToLive <= 0L);
/* 131 */     return timeToLive;
/*     */   }
/*     */ 
/*     */   private void checkTransactionTimeout(boolean deadlineReached)
/*     */     throws TransactionTimedOutException
/*     */   {
/* 139 */     if (deadlineReached) {
/* 140 */       setRollbackOnly();
/* 141 */       throw new TransactionTimedOutException("Transaction timed out: deadline was " + this.deadline);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void requested()
/*     */   {
/* 150 */     this.referenceCount += 1;
/*     */   }
/*     */ 
/*     */   public void released()
/*     */   {
/* 158 */     this.referenceCount -= 1;
/*     */   }
/*     */ 
/*     */   public boolean isOpen()
/*     */   {
/* 165 */     return this.referenceCount > 0;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 172 */     this.synchronizedWithTransaction = false;
/* 173 */     this.rollbackOnly = false;
/* 174 */     this.deadline = null;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/* 182 */     clear();
/* 183 */     this.referenceCount = 0;
/*     */   }
/*     */ 
/*     */   public void unbound()
/*     */   {
/* 188 */     this.isVoid = true;
/*     */   }
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 193 */     return this.isVoid;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.ResourceHolderSupport
 * JD-Core Version:    0.6.2
 */