/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ public abstract class ResourceHolderSynchronization<H extends ResourceHolder, K>
/*     */   implements TransactionSynchronization
/*     */ {
/*     */   private final H resourceHolder;
/*     */   private final K resourceKey;
/*  33 */   private volatile boolean holderActive = true;
/*     */ 
/*     */   public ResourceHolderSynchronization(H resourceHolder, K resourceKey)
/*     */   {
/*  43 */     this.resourceHolder = resourceHolder;
/*  44 */     this.resourceKey = resourceKey;
/*     */   }
/*     */ 
/*     */   public void suspend()
/*     */   {
/*  50 */     if (this.holderActive)
/*  51 */       TransactionSynchronizationManager.unbindResource(this.resourceKey);
/*     */   }
/*     */ 
/*     */   public void resume()
/*     */   {
/*  57 */     if (this.holderActive)
/*  58 */       TransactionSynchronizationManager.bindResource(this.resourceKey, this.resourceHolder);
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*  64 */     flushResource(this.resourceHolder);
/*     */   }
/*     */ 
/*     */   public void beforeCommit(boolean readOnly)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void beforeCompletion()
/*     */   {
/*  73 */     if (shouldUnbindAtCompletion()) {
/*  74 */       TransactionSynchronizationManager.unbindResource(this.resourceKey);
/*  75 */       this.holderActive = false;
/*  76 */       if (shouldReleaseBeforeCompletion())
/*  77 */         releaseResource(this.resourceHolder, this.resourceKey);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void afterCommit()
/*     */   {
/*  84 */     if (!shouldReleaseBeforeCompletion())
/*  85 */       processResourceAfterCommit(this.resourceHolder);
/*     */   }
/*     */ 
/*     */   public void afterCompletion(int status)
/*     */   {
/*  91 */     if (shouldUnbindAtCompletion()) {
/*  92 */       boolean releaseNecessary = false;
/*  93 */       if (this.holderActive)
/*     */       {
/*  96 */         this.holderActive = false;
/*  97 */         TransactionSynchronizationManager.unbindResourceIfPossible(this.resourceKey);
/*  98 */         this.resourceHolder.unbound();
/*  99 */         releaseNecessary = true;
/*     */       }
/*     */       else {
/* 102 */         releaseNecessary = shouldReleaseAfterCompletion(this.resourceHolder);
/*     */       }
/* 104 */       if (releaseNecessary) {
/* 105 */         releaseResource(this.resourceHolder, this.resourceKey);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 110 */       cleanupResource(this.resourceHolder, this.resourceKey, status == 0);
/*     */     }
/* 112 */     this.resourceHolder.reset();
/*     */   }
/*     */ 
/*     */   protected boolean shouldUnbindAtCompletion()
/*     */   {
/* 122 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean shouldReleaseBeforeCompletion()
/*     */   {
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean shouldReleaseAfterCompletion(H resourceHolder)
/*     */   {
/* 146 */     return !shouldReleaseBeforeCompletion();
/*     */   }
/*     */ 
/*     */   protected void flushResource(H resourceHolder)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void processResourceAfterCommit(H resourceHolder)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void releaseResource(H resourceHolder, K resourceKey)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void cleanupResource(H resourceHolder, K resourceKey, boolean committed)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.ResourceHolderSynchronization
 * JD-Core Version:    0.6.2
 */