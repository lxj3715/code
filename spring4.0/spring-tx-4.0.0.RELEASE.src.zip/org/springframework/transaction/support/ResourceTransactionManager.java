package org.springframework.transaction.support;

import org.springframework.transaction.PlatformTransactionManager;

public abstract interface ResourceTransactionManager extends PlatformTransactionManager
{
  public abstract Object getResourceFactory();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.ResourceTransactionManager
 * JD-Core Version:    0.6.2
 */