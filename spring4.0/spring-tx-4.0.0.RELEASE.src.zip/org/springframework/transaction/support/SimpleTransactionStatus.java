/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ public class SimpleTransactionStatus extends AbstractTransactionStatus
/*    */ {
/*    */   private final boolean newTransaction;
/*    */ 
/*    */   public SimpleTransactionStatus()
/*    */   {
/* 48 */     this(true);
/*    */   }
/*    */ 
/*    */   public SimpleTransactionStatus(boolean newTransaction)
/*    */   {
/* 56 */     this.newTransaction = newTransaction;
/*    */   }
/*    */ 
/*    */   public boolean isNewTransaction()
/*    */   {
/* 62 */     return this.newTransaction;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.SimpleTransactionStatus
 * JD-Core Version:    0.6.2
 */