package org.springframework.transaction.support;

import java.io.Flushable;

public abstract interface SmartTransactionObject extends Flushable
{
  public abstract boolean isRollbackOnly();

  public abstract void flush();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.SmartTransactionObject
 * JD-Core Version:    0.6.2
 */