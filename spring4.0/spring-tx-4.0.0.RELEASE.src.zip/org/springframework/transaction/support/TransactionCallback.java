package org.springframework.transaction.support;

import org.springframework.transaction.TransactionStatus;

public abstract interface TransactionCallback<T>
{
  public abstract T doInTransaction(TransactionStatus paramTransactionStatus);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionCallback
 * JD-Core Version:    0.6.2
 */