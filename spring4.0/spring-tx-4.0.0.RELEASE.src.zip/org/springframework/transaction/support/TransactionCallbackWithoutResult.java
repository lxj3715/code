/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import org.springframework.transaction.TransactionStatus;
/*    */ 
/*    */ public abstract class TransactionCallbackWithoutResult
/*    */   implements TransactionCallback<Object>
/*    */ {
/*    */   public final Object doInTransaction(TransactionStatus status)
/*    */   {
/* 34 */     doInTransactionWithoutResult(status);
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   protected abstract void doInTransactionWithoutResult(TransactionStatus paramTransactionStatus);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionCallbackWithoutResult
 * JD-Core Version:    0.6.2
 */