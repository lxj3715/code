package org.springframework.transaction.support;

import org.springframework.transaction.TransactionException;

public abstract interface TransactionOperations
{
  public abstract <T> T execute(TransactionCallback<T> paramTransactionCallback)
    throws TransactionException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionOperations
 * JD-Core Version:    0.6.2
 */