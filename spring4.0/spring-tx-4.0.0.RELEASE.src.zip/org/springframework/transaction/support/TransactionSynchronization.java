package org.springframework.transaction.support;

import java.io.Flushable;

public abstract interface TransactionSynchronization extends Flushable
{
  public static final int STATUS_COMMITTED = 0;
  public static final int STATUS_ROLLED_BACK = 1;
  public static final int STATUS_UNKNOWN = 2;

  public abstract void suspend();

  public abstract void resume();

  public abstract void flush();

  public abstract void beforeCommit(boolean paramBoolean);

  public abstract void beforeCompletion();

  public abstract void afterCommit();

  public abstract void afterCompletion(int paramInt);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionSynchronization
 * JD-Core Version:    0.6.2
 */