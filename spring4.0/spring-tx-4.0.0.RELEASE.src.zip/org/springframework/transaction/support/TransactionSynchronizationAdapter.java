/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ public abstract class TransactionSynchronizationAdapter
/*    */   implements TransactionSynchronization, Ordered
/*    */ {
/*    */   public int getOrder()
/*    */   {
/* 37 */     return 2147483647;
/*    */   }
/*    */ 
/*    */   public void suspend()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void resume()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void flush()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void beforeCommit(boolean readOnly)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void beforeCompletion()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void afterCommit()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void afterCompletion(int status)
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionSynchronizationAdapter
 * JD-Core Version:    0.6.2
 */