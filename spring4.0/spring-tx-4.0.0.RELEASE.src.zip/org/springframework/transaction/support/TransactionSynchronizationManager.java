/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class TransactionSynchronizationManager
/*     */ {
/*  78 */   private static final Log logger = LogFactory.getLog(TransactionSynchronizationManager.class);
/*     */ 
/*  80 */   private static final ThreadLocal<Map<Object, Object>> resources = new NamedThreadLocal("Transactional resources");
/*     */ 
/*  83 */   private static final ThreadLocal<Set<TransactionSynchronization>> synchronizations = new NamedThreadLocal("Transaction synchronizations");
/*     */ 
/*  86 */   private static final ThreadLocal<String> currentTransactionName = new NamedThreadLocal("Current transaction name");
/*     */ 
/*  89 */   private static final ThreadLocal<Boolean> currentTransactionReadOnly = new NamedThreadLocal("Current transaction read-only status");
/*     */ 
/*  92 */   private static final ThreadLocal<Integer> currentTransactionIsolationLevel = new NamedThreadLocal("Current transaction isolation level");
/*     */ 
/*  95 */   private static final ThreadLocal<Boolean> actualTransactionActive = new NamedThreadLocal("Actual transaction active");
/*     */ 
/*     */   public static Map<Object, Object> getResourceMap()
/*     */   {
/* 113 */     Map map = (Map)resources.get();
/* 114 */     return map != null ? Collections.unmodifiableMap(map) : Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   public static boolean hasResource(Object key)
/*     */   {
/* 124 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 125 */     Object value = doGetResource(actualKey);
/* 126 */     return value != null;
/*     */   }
/*     */ 
/*     */   public static Object getResource(Object key)
/*     */   {
/* 137 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 138 */     Object value = doGetResource(actualKey);
/* 139 */     if ((value != null) && (logger.isTraceEnabled())) {
/* 140 */       logger.trace("Retrieved value [" + value + "] for key [" + actualKey + "] bound to thread [" + 
/* 141 */         Thread.currentThread().getName() + "]");
/*     */     }
/* 143 */     return value;
/*     */   }
/*     */ 
/*     */   private static Object doGetResource(Object actualKey)
/*     */   {
/* 150 */     Map map = (Map)resources.get();
/* 151 */     if (map == null) {
/* 152 */       return null;
/*     */     }
/* 154 */     Object value = map.get(actualKey);
/*     */ 
/* 156 */     if (((value instanceof ResourceHolder)) && (((ResourceHolder)value).isVoid())) {
/* 157 */       map.remove(actualKey);
/*     */ 
/* 159 */       if (map.isEmpty()) {
/* 160 */         resources.remove();
/*     */       }
/* 162 */       value = null;
/*     */     }
/* 164 */     return value;
/*     */   }
/*     */ 
/*     */   public static void bindResource(Object key, Object value)
/*     */     throws IllegalStateException
/*     */   {
/* 175 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 176 */     Assert.notNull(value, "Value must not be null");
/* 177 */     Map map = (Map)resources.get();
/*     */ 
/* 179 */     if (map == null) {
/* 180 */       map = new HashMap();
/* 181 */       resources.set(map);
/*     */     }
/* 183 */     Object oldValue = map.put(actualKey, value);
/*     */ 
/* 185 */     if (((oldValue instanceof ResourceHolder)) && (((ResourceHolder)oldValue).isVoid())) {
/* 186 */       oldValue = null;
/*     */     }
/* 188 */     if (oldValue != null)
/*     */     {
/* 190 */       throw new IllegalStateException("Already value [" + oldValue + "] for key [" + actualKey + "] bound to thread [" + 
/* 190 */         Thread.currentThread().getName() + "]");
/*     */     }
/* 192 */     if (logger.isTraceEnabled())
/* 193 */       logger.trace("Bound value [" + value + "] for key [" + actualKey + "] to thread [" + 
/* 194 */         Thread.currentThread().getName() + "]");
/*     */   }
/*     */ 
/*     */   public static Object unbindResource(Object key)
/*     */     throws IllegalStateException
/*     */   {
/* 206 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 207 */     Object value = doUnbindResource(actualKey);
/* 208 */     if (value == null)
/*     */     {
/* 210 */       throw new IllegalStateException("No value for key [" + actualKey + "] bound to thread [" + 
/* 210 */         Thread.currentThread().getName() + "]");
/*     */     }
/* 212 */     return value;
/*     */   }
/*     */ 
/*     */   public static Object unbindResourceIfPossible(Object key)
/*     */   {
/* 221 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 222 */     return doUnbindResource(actualKey);
/*     */   }
/*     */ 
/*     */   private static Object doUnbindResource(Object actualKey)
/*     */   {
/* 229 */     Map map = (Map)resources.get();
/* 230 */     if (map == null) {
/* 231 */       return null;
/*     */     }
/* 233 */     Object value = map.remove(actualKey);
/*     */ 
/* 235 */     if (map.isEmpty()) {
/* 236 */       resources.remove();
/*     */     }
/*     */ 
/* 239 */     if (((value instanceof ResourceHolder)) && (((ResourceHolder)value).isVoid())) {
/* 240 */       value = null;
/*     */     }
/* 242 */     if ((value != null) && (logger.isTraceEnabled())) {
/* 243 */       logger.trace("Removed value [" + value + "] for key [" + actualKey + "] from thread [" + 
/* 244 */         Thread.currentThread().getName() + "]");
/*     */     }
/* 246 */     return value;
/*     */   }
/*     */ 
/*     */   public static boolean isSynchronizationActive()
/*     */   {
/* 260 */     return synchronizations.get() != null;
/*     */   }
/*     */ 
/*     */   public static void initSynchronization()
/*     */     throws IllegalStateException
/*     */   {
/* 269 */     if (isSynchronizationActive()) {
/* 270 */       throw new IllegalStateException("Cannot activate transaction synchronization - already active");
/*     */     }
/* 272 */     logger.trace("Initializing transaction synchronization");
/* 273 */     synchronizations.set(new LinkedHashSet());
/*     */   }
/*     */ 
/*     */   public static void registerSynchronization(TransactionSynchronization synchronization)
/*     */     throws IllegalStateException
/*     */   {
/* 289 */     Assert.notNull(synchronization, "TransactionSynchronization must not be null");
/* 290 */     if (!isSynchronizationActive()) {
/* 291 */       throw new IllegalStateException("Transaction synchronization is not active");
/*     */     }
/* 293 */     ((Set)synchronizations.get()).add(synchronization);
/*     */   }
/*     */ 
/*     */   public static List<TransactionSynchronization> getSynchronizations()
/*     */     throws IllegalStateException
/*     */   {
/* 304 */     Set synchs = (Set)synchronizations.get();
/* 305 */     if (synchs == null) {
/* 306 */       throw new IllegalStateException("Transaction synchronization is not active");
/*     */     }
/*     */ 
/* 311 */     if (synchs.isEmpty()) {
/* 312 */       return Collections.emptyList();
/*     */     }
/*     */ 
/* 316 */     List sortedSynchs = new ArrayList(synchs);
/* 317 */     OrderComparator.sort(sortedSynchs);
/* 318 */     return Collections.unmodifiableList(sortedSynchs);
/*     */   }
/*     */ 
/*     */   public static void clearSynchronization()
/*     */     throws IllegalStateException
/*     */   {
/* 328 */     if (!isSynchronizationActive()) {
/* 329 */       throw new IllegalStateException("Cannot deactivate transaction synchronization - not active");
/*     */     }
/* 331 */     logger.trace("Clearing transaction synchronization");
/* 332 */     synchronizations.remove();
/*     */   }
/*     */ 
/*     */   public static void setCurrentTransactionName(String name)
/*     */   {
/* 347 */     currentTransactionName.set(name);
/*     */   }
/*     */ 
/*     */   public static String getCurrentTransactionName()
/*     */   {
/* 357 */     return (String)currentTransactionName.get();
/*     */   }
/*     */ 
/*     */   public static void setCurrentTransactionReadOnly(boolean readOnly)
/*     */   {
/* 368 */     currentTransactionReadOnly.set(readOnly ? Boolean.TRUE : null);
/*     */   }
/*     */ 
/*     */   public static boolean isCurrentTransactionReadOnly()
/*     */   {
/* 384 */     return currentTransactionReadOnly.get() != null;
/*     */   }
/*     */ 
/*     */   public static void setCurrentTransactionIsolationLevel(Integer isolationLevel)
/*     */   {
/* 404 */     currentTransactionIsolationLevel.set(isolationLevel);
/*     */   }
/*     */ 
/*     */   public static Integer getCurrentTransactionIsolationLevel()
/*     */   {
/* 425 */     return (Integer)currentTransactionIsolationLevel.get();
/*     */   }
/*     */ 
/*     */   public static void setActualTransactionActive(boolean active)
/*     */   {
/* 435 */     actualTransactionActive.set(active ? Boolean.TRUE : null);
/*     */   }
/*     */ 
/*     */   public static boolean isActualTransactionActive()
/*     */   {
/* 450 */     return actualTransactionActive.get() != null;
/*     */   }
/*     */ 
/*     */   public static void clear()
/*     */   {
/* 464 */     clearSynchronization();
/* 465 */     setCurrentTransactionName(null);
/* 466 */     setCurrentTransactionReadOnly(false);
/* 467 */     setCurrentTransactionIsolationLevel(null);
/* 468 */     setActualTransactionActive(false);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionSynchronizationManager
 * JD-Core Version:    0.6.2
 */