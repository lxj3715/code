/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.scope.ScopedObject;
/*     */ import org.springframework.core.InfrastructureProxy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public abstract class TransactionSynchronizationUtils
/*     */ {
/*  40 */   private static final Log logger = LogFactory.getLog(TransactionSynchronizationUtils.class);
/*     */ 
/*  42 */   private static final boolean aopAvailable = ClassUtils.isPresent("org.springframework.aop.scope.ScopedObject", TransactionSynchronizationUtils.class
/*  43 */     .getClassLoader());
/*     */ 
/*     */   public static boolean sameResourceFactory(ResourceTransactionManager tm, Object resourceFactory)
/*     */   {
/*  53 */     return unwrapResourceIfNecessary(tm.getResourceFactory()).equals(unwrapResourceIfNecessary(resourceFactory));
/*     */   }
/*     */ 
/*     */   static Object unwrapResourceIfNecessary(Object resource)
/*     */   {
/*  62 */     Assert.notNull(resource, "Resource must not be null");
/*  63 */     Object resourceRef = resource;
/*     */ 
/*  65 */     if ((resourceRef instanceof InfrastructureProxy)) {
/*  66 */       resourceRef = ((InfrastructureProxy)resourceRef).getWrappedObject();
/*     */     }
/*  68 */     if (aopAvailable)
/*     */     {
/*  70 */       resourceRef = ScopedProxyUnwrapper.unwrapIfNecessary(resourceRef);
/*     */     }
/*  72 */     return resourceRef;
/*     */   }
/*     */ 
/*     */   public static void triggerFlush()
/*     */   {
/*  82 */     for (TransactionSynchronization synchronization : TransactionSynchronizationManager.getSynchronizations())
/*  83 */       synchronization.flush();
/*     */   }
/*     */ 
/*     */   public static void triggerBeforeCommit(boolean readOnly)
/*     */   {
/*  94 */     for (TransactionSynchronization synchronization : TransactionSynchronizationManager.getSynchronizations())
/*  95 */       synchronization.beforeCommit(readOnly);
/*     */   }
/*     */ 
/*     */   public static void triggerBeforeCompletion()
/*     */   {
/* 104 */     for (TransactionSynchronization synchronization : TransactionSynchronizationManager.getSynchronizations())
/*     */       try {
/* 106 */         synchronization.beforeCompletion();
/*     */       }
/*     */       catch (Throwable tsex) {
/* 109 */         logger.error("TransactionSynchronization.beforeCompletion threw exception", tsex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void triggerAfterCommit()
/*     */   {
/* 121 */     invokeAfterCommit(TransactionSynchronizationManager.getSynchronizations());
/*     */   }
/*     */ 
/*     */   public static void invokeAfterCommit(List<TransactionSynchronization> synchronizations)
/*     */   {
/* 131 */     if (synchronizations != null)
/* 132 */       for (TransactionSynchronization synchronization : synchronizations)
/* 133 */         synchronization.afterCommit();
/*     */   }
/*     */ 
/*     */   public static void triggerAfterCompletion(int completionStatus)
/*     */   {
/* 149 */     List synchronizations = TransactionSynchronizationManager.getSynchronizations();
/* 150 */     invokeAfterCompletion(synchronizations, completionStatus);
/*     */   }
/*     */ 
/*     */   public static void invokeAfterCompletion(List<TransactionSynchronization> synchronizations, int completionStatus)
/*     */   {
/* 165 */     if (synchronizations != null)
/* 166 */       for (TransactionSynchronization synchronization : synchronizations)
/*     */         try {
/* 168 */           synchronization.afterCompletion(completionStatus);
/*     */         }
/*     */         catch (Throwable tsex) {
/* 171 */           logger.error("TransactionSynchronization.afterCompletion threw exception", tsex);
/*     */         }
/*     */   }
/*     */ 
/*     */   private static class ScopedProxyUnwrapper
/*     */   {
/*     */     public static Object unwrapIfNecessary(Object resource)
/*     */     {
/* 184 */       if ((resource instanceof ScopedObject)) {
/* 185 */         return ((ScopedObject)resource).getTargetObject();
/*     */       }
/*     */ 
/* 188 */       return resource;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionSynchronizationUtils
 * JD-Core Version:    0.6.2
 */