/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionStatus;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ 
/*     */ public class TransactionTemplate extends DefaultTransactionDefinition
/*     */   implements TransactionOperations, InitializingBean
/*     */ {
/*  67 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private PlatformTransactionManager transactionManager;
/*     */ 
/*     */   public TransactionTemplate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TransactionTemplate(PlatformTransactionManager transactionManager)
/*     */   {
/*  86 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */   public TransactionTemplate(PlatformTransactionManager transactionManager, TransactionDefinition transactionDefinition)
/*     */   {
/*  97 */     super(transactionDefinition);
/*  98 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */   public void setTransactionManager(PlatformTransactionManager transactionManager)
/*     */   {
/* 106 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */   public PlatformTransactionManager getTransactionManager()
/*     */   {
/* 113 */     return this.transactionManager;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 118 */     if (this.transactionManager == null)
/* 119 */       throw new IllegalArgumentException("Property 'transactionManager' is required");
/*     */   }
/*     */ 
/*     */   public <T> T execute(TransactionCallback<T> action)
/*     */     throws TransactionException
/*     */   {
/* 126 */     if ((this.transactionManager instanceof CallbackPreferringPlatformTransactionManager)) {
/* 127 */       return ((CallbackPreferringPlatformTransactionManager)this.transactionManager).execute(this, action);
/*     */     }
/*     */ 
/* 130 */     TransactionStatus status = this.transactionManager.getTransaction(this);
/*     */     try
/*     */     {
/* 133 */       result = action.doInTransaction(status);
/*     */     }
/*     */     catch (RuntimeException ex)
/*     */     {
/*     */       Object result;
/* 137 */       rollbackOnException(status, ex);
/* 138 */       throw ex;
/*     */     }
/*     */     catch (Error err)
/*     */     {
/* 142 */       rollbackOnException(status, err);
/* 143 */       throw err;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 147 */       rollbackOnException(status, ex);
/* 148 */       throw new UndeclaredThrowableException(ex, "TransactionCallback threw undeclared checked exception");
/*     */     }
/*     */     Object result;
/* 150 */     this.transactionManager.commit(status);
/* 151 */     return result;
/*     */   }
/*     */ 
/*     */   private void rollbackOnException(TransactionStatus status, Throwable ex)
/*     */     throws TransactionException
/*     */   {
/* 162 */     this.logger.debug("Initiating transaction rollback on application exception", ex);
/*     */     try {
/* 164 */       this.transactionManager.rollback(status);
/*     */     }
/*     */     catch (TransactionSystemException ex2) {
/* 167 */       this.logger.error("Application exception overridden by rollback exception", ex);
/* 168 */       ex2.initApplicationException(ex);
/* 169 */       throw ex2;
/*     */     }
/*     */     catch (RuntimeException ex2) {
/* 172 */       this.logger.error("Application exception overridden by rollback exception", ex);
/* 173 */       throw ex2;
/*     */     }
/*     */     catch (Error err) {
/* 176 */       this.logger.error("Application exception overridden by rollback error", ex);
/* 177 */       throw err;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-tx-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionTemplate
 * JD-Core Version:    0.6.2
 */