/*     */ package org.springframework.http;
/*     */ 
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class HttpEntity<T>
/*     */ {
/*  59 */   public static final HttpEntity<?> EMPTY = new HttpEntity();
/*     */   private final HttpHeaders headers;
/*     */   private final T body;
/*     */ 
/*     */   protected HttpEntity()
/*     */   {
/*  71 */     this(null, null);
/*     */   }
/*     */ 
/*     */   public HttpEntity(T body)
/*     */   {
/*  79 */     this(body, null);
/*     */   }
/*     */ 
/*     */   public HttpEntity(MultiValueMap<String, String> headers)
/*     */   {
/*  87 */     this(null, headers);
/*     */   }
/*     */ 
/*     */   public HttpEntity(T body, MultiValueMap<String, String> headers)
/*     */   {
/*  96 */     this.body = body;
/*  97 */     HttpHeaders tempHeaders = new HttpHeaders();
/*  98 */     if (headers != null) {
/*  99 */       tempHeaders.putAll(headers);
/*     */     }
/* 101 */     this.headers = HttpHeaders.readOnlyHttpHeaders(tempHeaders);
/*     */   }
/*     */ 
/*     */   public HttpHeaders getHeaders()
/*     */   {
/* 109 */     return this.headers;
/*     */   }
/*     */ 
/*     */   public T getBody()
/*     */   {
/* 116 */     return this.body;
/*     */   }
/*     */ 
/*     */   public boolean hasBody()
/*     */   {
/* 123 */     return this.body != null;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 128 */     if (this == other) {
/* 129 */       return true;
/*     */     }
/* 131 */     if (!(other instanceof HttpEntity)) {
/* 132 */       return false;
/*     */     }
/* 134 */     HttpEntity otherEntity = (HttpEntity)other;
/*     */ 
/* 136 */     return (ObjectUtils.nullSafeEquals(this.headers, otherEntity.headers)) && 
/* 136 */       (ObjectUtils.nullSafeEquals(this.body, otherEntity.body));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 141 */     return ObjectUtils.nullSafeHashCode(this.headers) * 29 + ObjectUtils.nullSafeHashCode(this.body);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 146 */     StringBuilder builder = new StringBuilder("<");
/* 147 */     if (this.body != null) {
/* 148 */       builder.append(this.body);
/* 149 */       if (this.headers != null) {
/* 150 */         builder.append(',');
/*     */       }
/*     */     }
/* 153 */     if (this.headers != null) {
/* 154 */       builder.append(this.headers);
/*     */     }
/* 156 */     builder.append('>');
/* 157 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpEntity
 * JD-Core Version:    0.6.2
 */