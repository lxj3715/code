/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class HttpHeaders
/*     */   implements MultiValueMap<String, String>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8578554704772377436L;
/*     */   private static final String ACCEPT = "Accept";
/*     */   private static final String ACCEPT_CHARSET = "Accept-Charset";
/*     */   private static final String ALLOW = "Allow";
/*     */   private static final String CACHE_CONTROL = "Cache-Control";
/*     */   private static final String CONNECTION = "Connection";
/*     */   private static final String CONTENT_DISPOSITION = "Content-Disposition";
/*     */   private static final String CONTENT_LENGTH = "Content-Length";
/*     */   private static final String CONTENT_TYPE = "Content-Type";
/*     */   private static final String DATE = "Date";
/*     */   private static final String ETAG = "ETag";
/*     */   private static final String EXPIRES = "Expires";
/*     */   private static final String IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   private static final String IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String LAST_MODIFIED = "Last-Modified";
/*     */   private static final String LOCATION = "Location";
/*     */   private static final String ORIGIN = "Origin";
/*     */   private static final String PRAGMA = "Pragma";
/*     */   private static final String UPGARDE = "Upgrade";
/*  99 */   private static final String[] DATE_FORMATS = { "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM dd HH:mm:ss yyyy" };
/*     */ 
/* 105 */   private static TimeZone GMT = TimeZone.getTimeZone("GMT");
/*     */   private final Map<String, List<String>> headers;
/*     */ 
/*     */   private HttpHeaders(Map<String, List<String>> headers, boolean readOnly)
/*     */   {
/* 114 */     Assert.notNull(headers, "'headers' must not be null");
/* 115 */     if (readOnly)
/*     */     {
/* 117 */       Map map = new LinkedCaseInsensitiveMap(headers
/* 117 */         .size(), Locale.ENGLISH);
/* 118 */       for (Map.Entry entry : headers.entrySet()) {
/* 119 */         List values = Collections.unmodifiableList((List)entry.getValue());
/* 120 */         map.put(entry.getKey(), values);
/*     */       }
/* 122 */       this.headers = Collections.unmodifiableMap(map);
/*     */     }
/*     */     else {
/* 125 */       this.headers = headers;
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders()
/*     */   {
/* 133 */     this(new LinkedCaseInsensitiveMap(8, Locale.ENGLISH), false);
/*     */   }
/*     */ 
/*     */   public static HttpHeaders readOnlyHttpHeaders(HttpHeaders headers)
/*     */   {
/* 140 */     return new HttpHeaders(headers, true);
/*     */   }
/*     */ 
/*     */   public void setAccept(List<MediaType> acceptableMediaTypes)
/*     */   {
/* 148 */     set("Accept", MediaType.toString(acceptableMediaTypes));
/*     */   }
/*     */ 
/*     */   public List<MediaType> getAccept()
/*     */   {
/* 157 */     String value = getFirst("Accept");
/* 158 */     List result = value != null ? MediaType.parseMediaTypes(value) : Collections.emptyList();
/*     */ 
/* 161 */     if ((result.size() == 1) && (((List)this.headers.get("Accept")).size() > 1)) {
/* 162 */       value = StringUtils.collectionToCommaDelimitedString((Collection)this.headers.get("Accept"));
/* 163 */       result = MediaType.parseMediaTypes(value);
/*     */     }
/*     */ 
/* 166 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAcceptCharset(List<Charset> acceptableCharsets)
/*     */   {
/* 174 */     StringBuilder builder = new StringBuilder();
/* 175 */     for (Iterator iterator = acceptableCharsets.iterator(); iterator.hasNext(); ) {
/* 176 */       Charset charset = (Charset)iterator.next();
/* 177 */       builder.append(charset.name().toLowerCase(Locale.ENGLISH));
/* 178 */       if (iterator.hasNext()) {
/* 179 */         builder.append(", ");
/*     */       }
/*     */     }
/* 182 */     set("Accept-Charset", builder.toString());
/*     */   }
/*     */ 
/*     */   public List<Charset> getAcceptCharset()
/*     */   {
/* 191 */     List result = new ArrayList();
/* 192 */     String value = getFirst("Accept-Charset");
/* 193 */     if (value != null) {
/* 194 */       String[] tokens = value.split(",\\s*");
/* 195 */       for (String token : tokens) {
/* 196 */         int paramIdx = token.indexOf(59);
/*     */         String charsetName;
/*     */         String charsetName;
/* 198 */         if (paramIdx == -1) {
/* 199 */           charsetName = token;
/*     */         }
/*     */         else {
/* 202 */           charsetName = token.substring(0, paramIdx);
/*     */         }
/* 204 */         if (!charsetName.equals("*")) {
/* 205 */           result.add(Charset.forName(charsetName));
/*     */         }
/*     */       }
/*     */     }
/* 209 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAllow(Set<HttpMethod> allowedMethods)
/*     */   {
/* 217 */     set("Allow", StringUtils.collectionToCommaDelimitedString(allowedMethods));
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> getAllow()
/*     */   {
/* 226 */     String value = getFirst("Allow");
/* 227 */     if (value != null) {
/* 228 */       List allowedMethod = new ArrayList(5);
/* 229 */       String[] tokens = value.split(",\\s*");
/* 230 */       for (String token : tokens) {
/* 231 */         allowedMethod.add(HttpMethod.valueOf(token));
/*     */       }
/* 233 */       return EnumSet.copyOf(allowedMethod);
/*     */     }
/*     */ 
/* 236 */     return EnumSet.noneOf(HttpMethod.class);
/*     */   }
/*     */ 
/*     */   public void setCacheControl(String cacheControl)
/*     */   {
/* 245 */     set("Cache-Control", cacheControl);
/*     */   }
/*     */ 
/*     */   public String getCacheControl()
/*     */   {
/* 253 */     return getFirst("Cache-Control");
/*     */   }
/*     */ 
/*     */   public void setConnection(String connection)
/*     */   {
/* 261 */     set("Connection", connection);
/*     */   }
/*     */ 
/*     */   public void setConnection(List<String> connection)
/*     */   {
/* 269 */     set("Connection", toCommaDelimitedString(connection));
/*     */   }
/*     */ 
/*     */   public List<String> getConnection()
/*     */   {
/* 277 */     return getFirstValueAsList("Connection");
/*     */   }
/*     */ 
/*     */   public void setContentDispositionFormData(String name, String filename)
/*     */   {
/* 286 */     Assert.notNull(name, "'name' must not be null");
/* 287 */     StringBuilder builder = new StringBuilder("form-data; name=\"");
/* 288 */     builder.append(name).append('"');
/* 289 */     if (filename != null) {
/* 290 */       builder.append("; filename=\"");
/* 291 */       builder.append(filename).append('"');
/*     */     }
/* 293 */     set("Content-Disposition", builder.toString());
/*     */   }
/*     */ 
/*     */   public void setContentLength(long contentLength)
/*     */   {
/* 301 */     set("Content-Length", Long.toString(contentLength));
/*     */   }
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/* 310 */     String value = getFirst("Content-Length");
/* 311 */     return value != null ? Long.parseLong(value) : -1L;
/*     */   }
/*     */ 
/*     */   public void setContentType(MediaType mediaType)
/*     */   {
/* 319 */     Assert.isTrue(!mediaType.isWildcardType(), "'Content-Type' cannot contain wildcard type '*'");
/* 320 */     Assert.isTrue(!mediaType.isWildcardSubtype(), "'Content-Type' cannot contain wildcard subtype '*'");
/* 321 */     set("Content-Type", mediaType.toString());
/*     */   }
/*     */ 
/*     */   public MediaType getContentType()
/*     */   {
/* 330 */     String value = getFirst("Content-Type");
/* 331 */     return value != null ? MediaType.parseMediaType(value) : null;
/*     */   }
/*     */ 
/*     */   public void setDate(long date)
/*     */   {
/* 340 */     setDate("Date", date);
/*     */   }
/*     */ 
/*     */   public long getDate()
/*     */   {
/* 350 */     return getFirstDate("Date");
/*     */   }
/*     */ 
/*     */   public void setETag(String eTag)
/*     */   {
/* 358 */     if (eTag != null) {
/* 359 */       Assert.isTrue((eTag.startsWith("\"")) || (eTag.startsWith("W/")), "Invalid eTag, does not start with W/ or \"");
/* 360 */       Assert.isTrue(eTag.endsWith("\""), "Invalid eTag, does not end with \"");
/*     */     }
/* 362 */     set("ETag", eTag);
/*     */   }
/*     */ 
/*     */   public String getETag()
/*     */   {
/* 370 */     return getFirst("ETag");
/*     */   }
/*     */ 
/*     */   public void setExpires(long expires)
/*     */   {
/* 379 */     setDate("Expires", expires);
/*     */   }
/*     */ 
/*     */   public long getExpires()
/*     */   {
/*     */     try
/*     */     {
/* 392 */       return getFirstDate("Expires");
/*     */     } catch (IllegalArgumentException ex) {
/*     */     }
/* 395 */     return -1L;
/*     */   }
/*     */ 
/*     */   public void setIfModifiedSince(long ifModifiedSince)
/*     */   {
/* 405 */     setDate("If-Modified-Since", ifModifiedSince);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long getIfNotModifiedSince()
/*     */   {
/* 416 */     return getIfModifiedSince();
/*     */   }
/*     */ 
/*     */   public long getIfModifiedSince()
/*     */   {
/* 425 */     return getFirstDate("If-Modified-Since");
/*     */   }
/*     */ 
/*     */   public void setIfNoneMatch(String ifNoneMatch)
/*     */   {
/* 433 */     set("If-None-Match", ifNoneMatch);
/*     */   }
/*     */ 
/*     */   public void setIfNoneMatch(List<String> ifNoneMatchList)
/*     */   {
/* 441 */     set("If-None-Match", toCommaDelimitedString(ifNoneMatchList));
/*     */   }
/*     */ 
/*     */   protected String toCommaDelimitedString(List<String> list) {
/* 445 */     StringBuilder builder = new StringBuilder();
/* 446 */     for (Iterator iterator = list.iterator(); iterator.hasNext(); ) {
/* 447 */       String ifNoneMatch = (String)iterator.next();
/* 448 */       builder.append(ifNoneMatch);
/* 449 */       if (iterator.hasNext()) {
/* 450 */         builder.append(", ");
/*     */       }
/*     */     }
/* 453 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public List<String> getIfNoneMatch()
/*     */   {
/* 461 */     return getFirstValueAsList("If-None-Match");
/*     */   }
/*     */ 
/*     */   protected List<String> getFirstValueAsList(String header) {
/* 465 */     List result = new ArrayList();
/*     */ 
/* 467 */     String value = getFirst(header);
/* 468 */     if (value != null) {
/* 469 */       String[] tokens = value.split(",\\s*");
/* 470 */       for (String token : tokens) {
/* 471 */         result.add(token);
/*     */       }
/*     */     }
/* 474 */     return result;
/*     */   }
/*     */ 
/*     */   public void setLastModified(long lastModified)
/*     */   {
/* 483 */     setDate("Last-Modified", lastModified);
/*     */   }
/*     */ 
/*     */   public long getLastModified()
/*     */   {
/* 492 */     return getFirstDate("Last-Modified");
/*     */   }
/*     */ 
/*     */   public void setLocation(URI location)
/*     */   {
/* 500 */     set("Location", location.toASCIIString());
/*     */   }
/*     */ 
/*     */   public URI getLocation()
/*     */   {
/* 509 */     String value = getFirst("Location");
/* 510 */     return value != null ? URI.create(value) : null;
/*     */   }
/*     */ 
/*     */   public void setOrigin(String origin)
/*     */   {
/* 518 */     set("Origin", origin);
/*     */   }
/*     */ 
/*     */   public String getOrigin()
/*     */   {
/* 526 */     return getFirst("Origin");
/*     */   }
/*     */ 
/*     */   public void setPragma(String pragma)
/*     */   {
/* 534 */     set("Pragma", pragma);
/*     */   }
/*     */ 
/*     */   public String getPragma()
/*     */   {
/* 542 */     return getFirst("Pragma");
/*     */   }
/*     */ 
/*     */   public void setUpgrade(String upgrade)
/*     */   {
/* 550 */     set("Upgrade", upgrade);
/*     */   }
/*     */ 
/*     */   public String getUpgrade()
/*     */   {
/* 558 */     return getFirst("Upgrade");
/*     */   }
/*     */ 
/*     */   public long getFirstDate(String headerName)
/*     */   {
/* 569 */     String headerValue = getFirst(headerName);
/* 570 */     if (headerValue == null) {
/* 571 */       return -1L;
/*     */     }
/* 573 */     for (String dateFormat : DATE_FORMATS) {
/* 574 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat, Locale.US);
/* 575 */       simpleDateFormat.setTimeZone(GMT);
/*     */       try {
/* 577 */         return simpleDateFormat.parse(headerValue).getTime();
/*     */       }
/*     */       catch (ParseException e)
/*     */       {
/*     */       }
/*     */     }
/* 583 */     throw new IllegalArgumentException(new StringBuilder().append("Cannot parse date value \"").append(headerValue).append("\" for \"").append(headerName).append("\" header").toString());
/*     */   }
/*     */ 
/*     */   public void setDate(String headerName, long date)
/*     */   {
/* 593 */     SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMATS[0], Locale.US);
/* 594 */     dateFormat.setTimeZone(GMT);
/* 595 */     set(headerName, dateFormat.format(new Date(date)));
/*     */   }
/*     */ 
/*     */   public String getFirst(String headerName)
/*     */   {
/* 607 */     List headerValues = (List)this.headers.get(headerName);
/* 608 */     return headerValues != null ? (String)headerValues.get(0) : null;
/*     */   }
/*     */ 
/*     */   public void add(String headerName, String headerValue)
/*     */   {
/* 621 */     List headerValues = (List)this.headers.get(headerName);
/* 622 */     if (headerValues == null) {
/* 623 */       headerValues = new LinkedList();
/* 624 */       this.headers.put(headerName, headerValues);
/*     */     }
/* 626 */     headerValues.add(headerValue);
/*     */   }
/*     */ 
/*     */   public void set(String headerName, String headerValue)
/*     */   {
/* 639 */     List headerValues = new LinkedList();
/* 640 */     headerValues.add(headerValue);
/* 641 */     this.headers.put(headerName, headerValues);
/*     */   }
/*     */ 
/*     */   public void setAll(Map<String, String> values)
/*     */   {
/* 646 */     for (Map.Entry entry : values.entrySet())
/* 647 */       set((String)entry.getKey(), (String)entry.getValue());
/*     */   }
/*     */ 
/*     */   public Map<String, String> toSingleValueMap()
/*     */   {
/* 653 */     LinkedHashMap singleValueMap = new LinkedHashMap(this.headers.size());
/* 654 */     for (Map.Entry entry : this.headers.entrySet()) {
/* 655 */       singleValueMap.put(entry.getKey(), ((List)entry.getValue()).get(0));
/*     */     }
/* 657 */     return singleValueMap;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 664 */     return this.headers.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 669 */     return this.headers.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 674 */     return this.headers.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 679 */     return this.headers.containsValue(value);
/*     */   }
/*     */ 
/*     */   public List<String> get(Object key)
/*     */   {
/* 684 */     return (List)this.headers.get(key);
/*     */   }
/*     */ 
/*     */   public List<String> put(String key, List<String> value)
/*     */   {
/* 689 */     return (List)this.headers.put(key, value);
/*     */   }
/*     */ 
/*     */   public List<String> remove(Object key)
/*     */   {
/* 694 */     return (List)this.headers.remove(key);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends List<String>> m)
/*     */   {
/* 699 */     this.headers.putAll(m);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 704 */     this.headers.clear();
/*     */   }
/*     */ 
/*     */   public Set<String> keySet()
/*     */   {
/* 709 */     return this.headers.keySet();
/*     */   }
/*     */ 
/*     */   public Collection<List<String>> values()
/*     */   {
/* 714 */     return this.headers.values();
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<String, List<String>>> entrySet()
/*     */   {
/* 719 */     return this.headers.entrySet();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 725 */     if (this == other) {
/* 726 */       return true;
/*     */     }
/* 728 */     if (!(other instanceof HttpHeaders)) {
/* 729 */       return false;
/*     */     }
/* 731 */     HttpHeaders otherHeaders = (HttpHeaders)other;
/* 732 */     return this.headers.equals(otherHeaders.headers);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 737 */     return this.headers.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 742 */     return this.headers.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpHeaders
 * JD-Core Version:    0.6.2
 */