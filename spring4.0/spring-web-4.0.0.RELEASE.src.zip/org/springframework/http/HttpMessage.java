package org.springframework.http;

public abstract interface HttpMessage
{
  public abstract HttpHeaders getHeaders();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpMessage
 * JD-Core Version:    0.6.2
 */