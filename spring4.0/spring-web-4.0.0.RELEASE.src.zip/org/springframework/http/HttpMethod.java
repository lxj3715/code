/*    */ package org.springframework.http;
/*    */ 
/*    */ public enum HttpMethod
/*    */ {
/* 29 */   GET, POST, HEAD, OPTIONS, PUT, PATCH, DELETE, TRACE;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpMethod
 * JD-Core Version:    0.6.2
 */