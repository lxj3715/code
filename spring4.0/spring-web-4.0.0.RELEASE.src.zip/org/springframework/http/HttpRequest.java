package org.springframework.http;

import java.net.URI;

public abstract interface HttpRequest extends HttpMessage
{
  public abstract HttpMethod getMethod();

  public abstract URI getURI();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpRequest
 * JD-Core Version:    0.6.2
 */