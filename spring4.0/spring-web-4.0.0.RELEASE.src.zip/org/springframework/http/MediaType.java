/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.InvalidMimeTypeException;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeType.SpecificityComparator;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.comparator.CompoundComparator;
/*     */ 
/*     */ public class MediaType extends MimeType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2069937152339670231L;
/* 195 */   public static final MediaType ALL = valueOf("*/*");
/*     */   public static final String ALL_VALUE = "*/*";
/* 196 */   public static final MediaType APPLICATION_ATOM_XML = valueOf("application/atom+xml");
/*     */   public static final String APPLICATION_ATOM_XML_VALUE = "application/atom+xml";
/* 197 */   public static final MediaType APPLICATION_FORM_URLENCODED = valueOf("application/x-www-form-urlencoded");
/*     */   public static final String APPLICATION_FORM_URLENCODED_VALUE = "application/x-www-form-urlencoded";
/* 198 */   public static final MediaType APPLICATION_JSON = valueOf("application/json");
/*     */   public static final String APPLICATION_JSON_VALUE = "application/json";
/* 199 */   public static final MediaType APPLICATION_OCTET_STREAM = valueOf("application/octet-stream");
/*     */   public static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream";
/* 200 */   public static final MediaType APPLICATION_XHTML_XML = valueOf("application/xhtml+xml");
/*     */   public static final String APPLICATION_XHTML_XML_VALUE = "application/xhtml+xml";
/* 201 */   public static final MediaType APPLICATION_XML = valueOf("application/xml");
/*     */   public static final String APPLICATION_XML_VALUE = "application/xml";
/* 202 */   public static final MediaType IMAGE_GIF = valueOf("image/gif");
/*     */   public static final String IMAGE_GIF_VALUE = "image/gif";
/* 203 */   public static final MediaType IMAGE_JPEG = valueOf("image/jpeg");
/*     */   public static final String IMAGE_JPEG_VALUE = "image/jpeg";
/* 204 */   public static final MediaType IMAGE_PNG = valueOf("image/png");
/*     */   public static final String IMAGE_PNG_VALUE = "image/png";
/* 205 */   public static final MediaType MULTIPART_FORM_DATA = valueOf("multipart/form-data");
/*     */   public static final String MULTIPART_FORM_DATA_VALUE = "multipart/form-data";
/* 206 */   public static final MediaType TEXT_HTML = valueOf("text/html");
/*     */   public static final String TEXT_HTML_VALUE = "text/html";
/* 207 */   public static final MediaType TEXT_PLAIN = valueOf("text/plain");
/*     */   public static final String TEXT_PLAIN_VALUE = "text/plain";
/* 208 */   public static final MediaType TEXT_XML = valueOf("text/xml");
/*     */   public static final String TEXT_XML_VALUE = "text/xml";
/*     */   private static final String PARAM_QUALITY_FACTOR = "q";
/* 488 */   public static final Comparator<MediaType> QUALITY_VALUE_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(MediaType mediaType1, MediaType mediaType2)
/*     */     {
/* 492 */       double quality1 = mediaType1.getQualityValue();
/* 493 */       double quality2 = mediaType2.getQualityValue();
/* 494 */       int qualityComparison = Double.compare(quality2, quality1);
/* 495 */       if (qualityComparison != 0) {
/* 496 */         return qualityComparison;
/*     */       }
/* 498 */       if ((mediaType1.isWildcardType()) && (!mediaType2.isWildcardType())) {
/* 499 */         return 1;
/*     */       }
/* 501 */       if ((mediaType2.isWildcardType()) && (!mediaType1.isWildcardType())) {
/* 502 */         return -1;
/*     */       }
/* 504 */       if (!mediaType1.getType().equals(mediaType2.getType())) {
/* 505 */         return 0;
/*     */       }
/*     */ 
/* 508 */       if ((mediaType1.isWildcardSubtype()) && (!mediaType2.isWildcardSubtype())) {
/* 509 */         return 1;
/*     */       }
/* 511 */       if ((mediaType2.isWildcardSubtype()) && (!mediaType1.isWildcardSubtype())) {
/* 512 */         return -1;
/*     */       }
/* 514 */       if (!mediaType1.getSubtype().equals(mediaType2.getSubtype())) {
/* 515 */         return 0;
/*     */       }
/*     */ 
/* 518 */       int paramsSize1 = mediaType1.getParameters().size();
/* 519 */       int paramsSize2 = mediaType2.getParameters().size();
/* 520 */       return paramsSize2 == paramsSize1 ? 0 : paramsSize2 < paramsSize1 ? -1 : 1;
/*     */     }
/* 488 */   };
/*     */ 
/* 530 */   public static final Comparator<MediaType> SPECIFICITY_COMPARATOR = new MimeType.SpecificityComparator()
/*     */   {
/*     */     protected int compareParameters(MediaType mediaType1, MediaType mediaType2)
/*     */     {
/* 534 */       double quality1 = mediaType1.getQualityValue();
/* 535 */       double quality2 = mediaType2.getQualityValue();
/* 536 */       int qualityComparison = Double.compare(quality2, quality1);
/* 537 */       if (qualityComparison != 0) {
/* 538 */         return qualityComparison;
/*     */       }
/* 540 */       return super.compareParameters(mediaType1, mediaType2);
/*     */     }
/* 530 */   };
/*     */ 
/*     */   public MediaType(String type)
/*     */   {
/* 219 */     super(type);
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype)
/*     */   {
/* 230 */     super(type, subtype, Collections.emptyMap());
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, Charset charset)
/*     */   {
/* 241 */     super(type, subtype, charset);
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, double qualityValue)
/*     */   {
/* 252 */     this(type, subtype, Collections.singletonMap("q", Double.toString(qualityValue)));
/*     */   }
/*     */ 
/*     */   public MediaType(MediaType other, Map<String, String> parameters)
/*     */   {
/* 263 */     super(other.getType(), other.getSubtype(), parameters);
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, Map<String, String> parameters)
/*     */   {
/* 274 */     super(type, subtype, parameters);
/*     */   }
/*     */ 
/*     */   protected void checkParameters(String attribute, String value)
/*     */   {
/* 279 */     super.checkParameters(attribute, value);
/* 280 */     if ("q".equals(attribute)) {
/* 281 */       value = unquote(value);
/* 282 */       double d = Double.parseDouble(value);
/* 283 */       Assert.isTrue((d >= 0.0D) && (d <= 1.0D), "Invalid quality value \"" + value + "\": should be between 0.0 and 1.0");
/*     */     }
/*     */   }
/*     */ 
/*     */   public double getQualityValue()
/*     */   {
/* 294 */     String qualityFactory = getParameter("q");
/* 295 */     return qualityFactory != null ? Double.parseDouble(unquote(qualityFactory)) : 1.0D;
/*     */   }
/*     */ 
/*     */   public boolean includes(MediaType other)
/*     */   {
/* 306 */     return super.includes(other);
/*     */   }
/*     */ 
/*     */   public boolean isCompatibleWith(MediaType other)
/*     */   {
/* 317 */     return super.isCompatibleWith(other);
/*     */   }
/*     */ 
/*     */   public MediaType copyQualityValue(MediaType mediaType)
/*     */   {
/* 325 */     if (!mediaType.getParameters().containsKey("q")) {
/* 326 */       return this;
/*     */     }
/* 328 */     Map params = new LinkedHashMap(getParameters());
/* 329 */     params.put("q", mediaType.getParameters().get("q"));
/* 330 */     return new MediaType(this, params);
/*     */   }
/*     */ 
/*     */   public MediaType removeQualityValue()
/*     */   {
/* 338 */     if (!getParameters().containsKey("q")) {
/* 339 */       return this;
/*     */     }
/* 341 */     Map params = new LinkedHashMap(getParameters());
/* 342 */     params.remove("q");
/* 343 */     return new MediaType(this, params);
/*     */   }
/*     */ 
/*     */   public static MediaType valueOf(String value)
/*     */   {
/* 354 */     return parseMediaType(value);
/*     */   }
/*     */ 
/*     */   public static MediaType parseMediaType(String mediaType)
/*     */   {
/*     */     try
/*     */     {
/* 366 */       type = MimeTypeUtils.parseMimeType(mediaType);
/*     */     }
/*     */     catch (InvalidMimeTypeException ex)
/*     */     {
/*     */       MimeType type;
/* 369 */       throw new InvalidMediaTypeException(ex);
/*     */     }
/*     */     try
/*     */     {
/*     */       MimeType type;
/* 372 */       return new MediaType(type.getType(), type.getSubtype(), type.getParameters());
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 375 */       throw new InvalidMediaTypeException(mediaType, ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static List<MediaType> parseMediaTypes(String mediaTypes)
/*     */   {
/* 388 */     if (!StringUtils.hasLength(mediaTypes)) {
/* 389 */       return Collections.emptyList();
/*     */     }
/* 391 */     String[] tokens = mediaTypes.split(",\\s*");
/* 392 */     List result = new ArrayList(tokens.length);
/* 393 */     for (String token : tokens) {
/* 394 */       result.add(parseMediaType(token));
/*     */     }
/* 396 */     return result;
/*     */   }
/*     */ 
/*     */   public static String toString(Collection<MediaType> mediaTypes)
/*     */   {
/* 407 */     return MimeTypeUtils.toString(mediaTypes);
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificity(List<MediaType> mediaTypes)
/*     */   {
/* 437 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 438 */     if (mediaTypes.size() > 1)
/* 439 */       Collections.sort(mediaTypes, SPECIFICITY_COMPARATOR);
/*     */   }
/*     */ 
/*     */   public static void sortByQualityValue(List<MediaType> mediaTypes)
/*     */   {
/* 464 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 465 */     if (mediaTypes.size() > 1)
/* 466 */       Collections.sort(mediaTypes, QUALITY_VALUE_COMPARATOR);
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificityAndQuality(List<MediaType> mediaTypes)
/*     */   {
/* 477 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 478 */     if (mediaTypes.size() > 1)
/* 479 */       Collections.sort(mediaTypes, new CompoundComparator(new Comparator[] { SPECIFICITY_COMPARATOR, QUALITY_VALUE_COMPARATOR }));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.MediaType
 * JD-Core Version:    0.6.2
 */