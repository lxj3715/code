/*    */ package org.springframework.http;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class MediaTypeEditor extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text)
/*    */   {
/* 36 */     if (StringUtils.hasText(text)) {
/* 37 */       setValue(MediaType.parseMediaType(text));
/*    */     }
/*    */     else
/* 40 */       setValue(null);
/*    */   }
/*    */ 
/*    */   public String getAsText()
/*    */   {
/* 46 */     MediaType mediaType = (MediaType)getValue();
/* 47 */     return mediaType != null ? mediaType.toString() : "";
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.MediaTypeEditor
 * JD-Core Version:    0.6.2
 */