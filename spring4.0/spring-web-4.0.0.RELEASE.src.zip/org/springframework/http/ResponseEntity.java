/*     */ package org.springframework.http;
/*     */ 
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class ResponseEntity<T> extends HttpEntity<T>
/*     */ {
/*     */   private final HttpStatus statusCode;
/*     */ 
/*     */   public ResponseEntity(HttpStatus statusCode)
/*     */   {
/*  57 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(T body, HttpStatus statusCode)
/*     */   {
/*  66 */     super(body);
/*  67 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(MultiValueMap<String, String> headers, HttpStatus statusCode)
/*     */   {
/*  76 */     super(headers);
/*  77 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(T body, MultiValueMap<String, String> headers, HttpStatus statusCode)
/*     */   {
/*  87 */     super(body, headers);
/*  88 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public HttpStatus getStatusCode()
/*     */   {
/*  97 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 102 */     if (this == other) {
/* 103 */       return true;
/*     */     }
/* 105 */     if (!(other instanceof ResponseEntity)) {
/* 106 */       return false;
/*     */     }
/* 108 */     ResponseEntity otherEntity = (ResponseEntity)other;
/* 109 */     return (ObjectUtils.nullSafeEquals(this.statusCode, otherEntity.statusCode)) && (super.equals(other));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 114 */     return super.hashCode() * 29 + ObjectUtils.nullSafeHashCode(this.statusCode);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 119 */     StringBuilder builder = new StringBuilder("<");
/* 120 */     builder.append(this.statusCode.toString());
/* 121 */     builder.append(' ');
/* 122 */     builder.append(this.statusCode.getReasonPhrase());
/* 123 */     builder.append(',');
/* 124 */     Object body = getBody();
/* 125 */     HttpHeaders headers = getHeaders();
/* 126 */     if (body != null) {
/* 127 */       builder.append(body);
/* 128 */       if (headers != null) {
/* 129 */         builder.append(',');
/*     */       }
/*     */     }
/* 132 */     if (headers != null) {
/* 133 */       builder.append(headers);
/*     */     }
/* 135 */     builder.append('>');
/* 136 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.ResponseEntity
 * JD-Core Version:    0.6.2
 */