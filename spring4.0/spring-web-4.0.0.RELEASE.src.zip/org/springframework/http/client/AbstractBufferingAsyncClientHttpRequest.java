/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.concurrent.ListenableFuture;
/*    */ 
/*    */ abstract class AbstractBufferingAsyncClientHttpRequest extends AbstractAsyncClientHttpRequest
/*    */ {
/* 35 */   private ByteArrayOutputStream bufferedOutput = new ByteArrayOutputStream();
/*    */ 
/*    */   protected OutputStream getBodyInternal(HttpHeaders headers) throws IOException
/*    */   {
/* 39 */     return this.bufferedOutput;
/*    */   }
/*    */ 
/*    */   protected ListenableFuture<ClientHttpResponse> executeInternal(HttpHeaders headers)
/*    */     throws IOException
/*    */   {
/* 45 */     byte[] bytes = this.bufferedOutput.toByteArray();
/* 46 */     if (headers.getContentLength() == -1L) {
/* 47 */       headers.setContentLength(bytes.length);
/*    */     }
/* 49 */     ListenableFuture result = executeInternal(headers, bytes);
/* 50 */     this.bufferedOutput = null;
/* 51 */     return result;
/*    */   }
/*    */ 
/*    */   protected abstract ListenableFuture<ClientHttpResponse> executeInternal(HttpHeaders paramHttpHeaders, byte[] paramArrayOfByte)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AbstractBufferingAsyncClientHttpRequest
 * JD-Core Version:    0.6.2
 */