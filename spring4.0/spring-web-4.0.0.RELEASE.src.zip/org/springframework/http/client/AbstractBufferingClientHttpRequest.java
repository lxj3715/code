/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ abstract class AbstractBufferingClientHttpRequest extends AbstractClientHttpRequest
/*    */ {
/* 33 */   private ByteArrayOutputStream bufferedOutput = new ByteArrayOutputStream();
/*    */ 
/*    */   protected OutputStream getBodyInternal(HttpHeaders headers) throws IOException
/*    */   {
/* 37 */     return this.bufferedOutput;
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers) throws IOException
/*    */   {
/* 42 */     byte[] bytes = this.bufferedOutput.toByteArray();
/* 43 */     if (headers.getContentLength() == -1L) {
/* 44 */       headers.setContentLength(bytes.length);
/*    */     }
/* 46 */     ClientHttpResponse result = executeInternal(headers, bytes);
/* 47 */     this.bufferedOutput = null;
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */   protected abstract ClientHttpResponse executeInternal(HttpHeaders paramHttpHeaders, byte[] paramArrayOfByte)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AbstractBufferingClientHttpRequest
 * JD-Core Version:    0.6.2
 */