/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class AbstractClientHttpRequest
/*    */   implements ClientHttpRequest
/*    */ {
/* 33 */   private final HttpHeaders headers = new HttpHeaders();
/*    */ 
/* 35 */   private boolean executed = false;
/*    */ 
/*    */   public final HttpHeaders getHeaders()
/*    */   {
/* 40 */     return this.executed ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*    */   }
/*    */ 
/*    */   public final OutputStream getBody() throws IOException
/*    */   {
/* 45 */     assertNotExecuted();
/* 46 */     return getBodyInternal(this.headers);
/*    */   }
/*    */ 
/*    */   public final ClientHttpResponse execute() throws IOException
/*    */   {
/* 51 */     assertNotExecuted();
/* 52 */     ClientHttpResponse result = executeInternal(this.headers);
/* 53 */     this.executed = true;
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   protected void assertNotExecuted()
/*    */   {
/* 63 */     Assert.state(!this.executed, "ClientHttpRequest already executed");
/*    */   }
/*    */ 
/*    */   protected abstract OutputStream getBodyInternal(HttpHeaders paramHttpHeaders)
/*    */     throws IOException;
/*    */ 
/*    */   protected abstract ClientHttpResponse executeInternal(HttpHeaders paramHttpHeaders)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AbstractClientHttpRequest
 * JD-Core Version:    0.6.2
 */