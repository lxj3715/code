/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class AbstractClientHttpRequestFactoryWrapper
/*    */   implements ClientHttpRequestFactory
/*    */ {
/*    */   private final ClientHttpRequestFactory requestFactory;
/*    */ 
/*    */   protected AbstractClientHttpRequestFactoryWrapper(ClientHttpRequestFactory requestFactory)
/*    */   {
/* 41 */     Assert.notNull(requestFactory, "'requestFactory' must not be null");
/* 42 */     this.requestFactory = requestFactory;
/*    */   }
/*    */ 
/*    */   public final ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*    */     throws IOException
/*    */   {
/* 53 */     return createRequest(uri, httpMethod, this.requestFactory);
/*    */   }
/*    */ 
/*    */   protected abstract ClientHttpRequest createRequest(URI paramURI, HttpMethod paramHttpMethod, ClientHttpRequestFactory paramClientHttpRequestFactory)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AbstractClientHttpRequestFactoryWrapper
 * JD-Core Version:    0.6.2
 */