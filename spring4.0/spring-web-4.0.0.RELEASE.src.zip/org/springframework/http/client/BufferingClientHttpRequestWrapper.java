/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ final class BufferingClientHttpRequestWrapper extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final ClientHttpRequest request;
/*    */ 
/*    */   BufferingClientHttpRequestWrapper(ClientHttpRequest request)
/*    */   {
/* 39 */     Assert.notNull(request, "'request' must not be null");
/* 40 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 46 */     return this.request.getMethod();
/*    */   }
/*    */ 
/*    */   public URI getURI()
/*    */   {
/* 51 */     return this.request.getURI();
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput) throws IOException
/*    */   {
/* 56 */     this.request.getHeaders().putAll(headers);
/* 57 */     StreamUtils.copy(bufferedOutput, this.request.getBody());
/* 58 */     ClientHttpResponse response = this.request.execute();
/* 59 */     return new BufferingClientHttpResponseWrapper(response);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.BufferingClientHttpRequestWrapper
 * JD-Core Version:    0.6.2
 */