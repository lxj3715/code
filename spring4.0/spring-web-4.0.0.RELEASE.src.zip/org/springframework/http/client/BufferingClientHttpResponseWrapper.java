/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ final class BufferingClientHttpResponseWrapper
/*    */   implements ClientHttpResponse
/*    */ {
/*    */   private final ClientHttpResponse response;
/*    */   private byte[] body;
/*    */ 
/*    */   BufferingClientHttpResponseWrapper(ClientHttpResponse response)
/*    */   {
/* 42 */     this.response = response;
/*    */   }
/*    */ 
/*    */   public HttpStatus getStatusCode()
/*    */     throws IOException
/*    */   {
/* 48 */     return this.response.getStatusCode();
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode() throws IOException
/*    */   {
/* 53 */     return this.response.getRawStatusCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException
/*    */   {
/* 58 */     return this.response.getStatusText();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 63 */     return this.response.getHeaders();
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 68 */     if (this.body == null) {
/* 69 */       this.body = StreamUtils.copyToByteArray(this.response.getBody());
/*    */     }
/* 71 */     return new ByteArrayInputStream(this.body);
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/* 76 */     this.response.close();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.BufferingClientHttpResponseWrapper
 * JD-Core Version:    0.6.2
 */