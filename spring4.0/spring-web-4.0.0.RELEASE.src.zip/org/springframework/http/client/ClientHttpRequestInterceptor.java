package org.springframework.http.client;

import java.io.IOException;
import org.springframework.http.HttpRequest;

public abstract interface ClientHttpRequestInterceptor
{
  public abstract ClientHttpResponse intercept(HttpRequest paramHttpRequest, byte[] paramArrayOfByte, ClientHttpRequestExecution paramClientHttpRequestExecution)
    throws IOException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.ClientHttpRequestInterceptor
 * JD-Core Version:    0.6.2
 */