/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpEntityEnclosingRequest;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.concurrent.FutureCallback;
/*     */ import org.apache.http.nio.client.HttpAsyncClient;
/*     */ import org.apache.http.nio.entity.NByteArrayEntity;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.concurrent.FutureAdapter;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallback;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallbackRegistry;
/*     */ 
/*     */ final class HttpComponentsAsyncClientHttpRequest extends AbstractBufferingAsyncClientHttpRequest
/*     */ {
/*     */   private final HttpAsyncClient httpClient;
/*     */   private final HttpUriRequest httpRequest;
/*     */   private final HttpContext httpContext;
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequest(HttpAsyncClient httpClient, HttpUriRequest httpRequest, HttpContext httpContext)
/*     */   {
/*  61 */     this.httpClient = httpClient;
/*  62 */     this.httpRequest = httpRequest;
/*  63 */     this.httpContext = httpContext;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  68 */     return HttpMethod.valueOf(this.httpRequest.getMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*  73 */     return this.httpRequest.getURI();
/*     */   }
/*     */ 
/*     */   protected ListenableFuture<ClientHttpResponse> executeInternal(HttpHeaders headers, byte[] bufferedOutput)
/*     */     throws IOException
/*     */   {
/*  79 */     HttpComponentsClientHttpRequest.addHeaders(this.httpRequest, headers);
/*     */ 
/*  81 */     if ((this.httpRequest instanceof HttpEntityEnclosingRequest)) {
/*  82 */       HttpEntityEnclosingRequest entityEnclosingRequest = (HttpEntityEnclosingRequest)this.httpRequest;
/*     */ 
/*  84 */       HttpEntity requestEntity = new NByteArrayEntity(bufferedOutput);
/*  85 */       entityEnclosingRequest.setEntity(requestEntity);
/*     */     }
/*     */ 
/*  88 */     HttpResponseFutureCallback callback = new HttpResponseFutureCallback(null);
/*     */ 
/*  91 */     Future futureResponse = this.httpClient
/*  91 */       .execute(this.httpRequest, this.httpContext, callback);
/*     */ 
/*  92 */     return new ClientHttpResponseFuture(futureResponse, callback, null);
/*     */   }
/*     */ 
/*     */   private static class ClientHttpResponseFuture extends FutureAdapter<ClientHttpResponse, HttpResponse>
/*     */     implements ListenableFuture<ClientHttpResponse>
/*     */   {
/*     */     private final HttpComponentsAsyncClientHttpRequest.HttpResponseFutureCallback callback;
/*     */ 
/*     */     private ClientHttpResponseFuture(Future<HttpResponse> futureResponse, HttpComponentsAsyncClientHttpRequest.HttpResponseFutureCallback callback)
/*     */     {
/* 129 */       super();
/* 130 */       this.callback = callback;
/*     */     }
/*     */ 
/*     */     protected ClientHttpResponse adapt(HttpResponse response)
/*     */     {
/* 135 */       return new HttpComponentsAsyncClientHttpResponse(response);
/*     */     }
/*     */ 
/*     */     public void addCallback(ListenableFutureCallback<? super ClientHttpResponse> callback)
/*     */     {
/* 141 */       this.callback.addCallback(callback);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class HttpResponseFutureCallback
/*     */     implements FutureCallback<HttpResponse>
/*     */   {
/*  97 */     private final ListenableFutureCallbackRegistry<ClientHttpResponse> callbacks = new ListenableFutureCallbackRegistry();
/*     */ 
/*     */     public void addCallback(ListenableFutureCallback<? super ClientHttpResponse> callback)
/*     */     {
/* 102 */       this.callbacks.addCallback(callback);
/*     */     }
/*     */ 
/*     */     public void completed(HttpResponse result)
/*     */     {
/* 107 */       this.callbacks.success(new HttpComponentsAsyncClientHttpResponse(result));
/*     */     }
/*     */ 
/*     */     public void failed(Exception ex)
/*     */     {
/* 112 */       this.callbacks.failure(ex);
/*     */     }
/*     */ 
/*     */     public void cancelled()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsAsyncClientHttpRequest
 * JD-Core Version:    0.6.2
 */