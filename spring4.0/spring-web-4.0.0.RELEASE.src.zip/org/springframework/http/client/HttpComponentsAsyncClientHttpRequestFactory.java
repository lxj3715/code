/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.client.methods.Configurable;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.client.protocol.HttpClientContext;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
/*     */ import org.apache.http.impl.nio.client.HttpAsyncClients;
/*     */ import org.apache.http.nio.client.HttpAsyncClient;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class HttpComponentsAsyncClientHttpRequestFactory extends HttpComponentsClientHttpRequestFactory
/*     */   implements AsyncClientHttpRequestFactory, InitializingBean
/*     */ {
/*     */   private CloseableHttpAsyncClient httpAsyncClient;
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequestFactory()
/*     */   {
/*  58 */     this(HttpAsyncClients.createSystem());
/*     */   }
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequestFactory(CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  68 */     Assert.notNull(httpAsyncClient, "'httpAsyncClient' must not be null");
/*  69 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequestFactory(CloseableHttpClient httpClient, CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  81 */     super(httpClient);
/*  82 */     Assert.notNull(httpAsyncClient, "'httpAsyncClient' must not be null");
/*  83 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */ 
/*     */   public void setHttpAsyncClient(CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  92 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */ 
/*     */   public CloseableHttpAsyncClient getHttpAsyncClient()
/*     */   {
/* 100 */     return this.httpAsyncClient;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 105 */     startAsyncClient();
/*     */   }
/*     */ 
/*     */   private void startAsyncClient() {
/* 109 */     CloseableHttpAsyncClient asyncClient = getHttpAsyncClient();
/* 110 */     if (!asyncClient.isRunning())
/* 111 */       asyncClient.start();
/*     */   }
/*     */ 
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 118 */     HttpAsyncClient asyncClient = getHttpAsyncClient();
/* 119 */     startAsyncClient();
/* 120 */     HttpUriRequest httpRequest = createHttpUriRequest(httpMethod, uri);
/* 121 */     postProcessHttpRequest(httpRequest);
/* 122 */     HttpContext context = createHttpContext(httpMethod, uri);
/* 123 */     if (context == null) {
/* 124 */       context = HttpClientContext.create();
/*     */     }
/*     */ 
/* 127 */     if (context.getAttribute("http.request-config") == null)
/*     */     {
/* 129 */       RequestConfig config = null;
/* 130 */       if ((httpRequest instanceof Configurable)) {
/* 131 */         config = ((Configurable)httpRequest).getConfig();
/*     */       }
/* 133 */       if (config == null) {
/* 134 */         config = RequestConfig.DEFAULT;
/*     */       }
/* 136 */       context.setAttribute("http.request-config", config);
/*     */     }
/* 138 */     return new HttpComponentsAsyncClientHttpRequest(asyncClient, httpRequest, context);
/*     */   }
/*     */ 
/*     */   public void destroy() throws Exception
/*     */   {
/*     */     try {
/* 144 */       super.destroy();
/*     */ 
/* 147 */       getHttpAsyncClient().close(); } finally { getHttpAsyncClient().close(); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsAsyncClientHttpRequestFactory
 * JD-Core Version:    0.6.2
 */