/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.http.Header;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.HttpResponse;
/*    */ import org.apache.http.StatusLine;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ final class HttpComponentsAsyncClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final HttpResponse httpResponse;
/*    */   private HttpHeaders headers;
/*    */ 
/*    */   HttpComponentsAsyncClientHttpResponse(HttpResponse httpResponse)
/*    */   {
/* 46 */     this.httpResponse = httpResponse;
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode()
/*    */     throws IOException
/*    */   {
/* 52 */     return this.httpResponse.getStatusLine().getStatusCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException
/*    */   {
/* 57 */     return this.httpResponse.getStatusLine().getReasonPhrase();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 62 */     if (this.headers == null) {
/* 63 */       this.headers = new HttpHeaders();
/* 64 */       for (Header header : this.httpResponse.getAllHeaders()) {
/* 65 */         this.headers.add(header.getName(), header.getValue());
/*    */       }
/*    */     }
/* 68 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 73 */     HttpEntity entity = this.httpResponse.getEntity();
/* 74 */     return entity != null ? entity.getContent() : null;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsAsyncClientHttpResponse
 * JD-Core Version:    0.6.2
 */