/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.HttpEntityEnclosingRequest;
/*    */ import org.apache.http.client.methods.CloseableHttpResponse;
/*    */ import org.apache.http.client.methods.HttpUriRequest;
/*    */ import org.apache.http.entity.ByteArrayEntity;
/*    */ import org.apache.http.impl.client.CloseableHttpClient;
/*    */ import org.apache.http.protocol.HttpContext;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ 
/*    */ final class HttpComponentsClientHttpRequest extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final CloseableHttpClient httpClient;
/*    */   private final HttpUriRequest httpRequest;
/*    */   private final HttpContext httpContext;
/*    */ 
/*    */   public HttpComponentsClientHttpRequest(CloseableHttpClient httpClient, HttpUriRequest httpRequest, HttpContext httpContext)
/*    */   {
/* 56 */     this.httpClient = httpClient;
/* 57 */     this.httpRequest = httpRequest;
/* 58 */     this.httpContext = httpContext;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 64 */     return HttpMethod.valueOf(this.httpRequest.getMethod());
/*    */   }
/*    */ 
/*    */   public URI getURI()
/*    */   {
/* 69 */     return this.httpRequest.getURI();
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput)
/*    */     throws IOException
/*    */   {
/* 75 */     addHeaders(this.httpRequest, headers);
/*    */ 
/* 77 */     if ((this.httpRequest instanceof HttpEntityEnclosingRequest)) {
/* 78 */       HttpEntityEnclosingRequest entityEnclosingRequest = (HttpEntityEnclosingRequest)this.httpRequest;
/*    */ 
/* 80 */       HttpEntity requestEntity = new ByteArrayEntity(bufferedOutput);
/* 81 */       entityEnclosingRequest.setEntity(requestEntity);
/*    */     }
/*    */ 
/* 84 */     CloseableHttpResponse httpResponse = this.httpClient
/* 84 */       .execute(this.httpRequest, this.httpContext);
/*    */ 
/* 85 */     return new HttpComponentsClientHttpResponse(httpResponse);
/*    */   }
/*    */ 
/*    */   static void addHeaders(HttpUriRequest httpRequest, HttpHeaders headers)
/*    */   {
/* 95 */     for (Map.Entry entry : headers.entrySet()) {
/* 96 */       headerName = (String)entry.getKey();
/* 97 */       if ((!headerName.equalsIgnoreCase("Content-Length")) && 
/* 98 */         (!headerName
/* 98 */         .equalsIgnoreCase("Transfer-Encoding")))
/*    */       {
/* 99 */         for (String headerValue : (List)entry.getValue())
/* 100 */           httpRequest.addHeader(headerName, headerValue);
/*    */       }
/*    */     }
/*    */     String headerName;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsClientHttpRequest
 * JD-Core Version:    0.6.2
 */