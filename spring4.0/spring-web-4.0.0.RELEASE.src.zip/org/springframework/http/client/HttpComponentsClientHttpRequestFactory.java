/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.client.config.RequestConfig.Builder;
/*     */ import org.apache.http.client.methods.Configurable;
/*     */ import org.apache.http.client.methods.HttpDelete;
/*     */ import org.apache.http.client.methods.HttpGet;
/*     */ import org.apache.http.client.methods.HttpHead;
/*     */ import org.apache.http.client.methods.HttpOptions;
/*     */ import org.apache.http.client.methods.HttpPatch;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpPut;
/*     */ import org.apache.http.client.methods.HttpTrace;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.client.protocol.HttpClientContext;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.HttpClients;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class HttpComponentsClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, DisposableBean
/*     */ {
/*     */   private CloseableHttpClient httpClient;
/*     */   private int connectTimeout;
/*     */   private int socketTimeout;
/*  63 */   private boolean bufferRequestBody = true;
/*     */ 
/*     */   public HttpComponentsClientHttpRequestFactory()
/*     */   {
/*  71 */     this(HttpClients.createSystem());
/*     */   }
/*     */ 
/*     */   public HttpComponentsClientHttpRequestFactory(HttpClient httpClient)
/*     */   {
/*  84 */     Assert.notNull(httpClient, "'httpClient' must not be null");
/*  85 */     Assert.isInstanceOf(CloseableHttpClient.class, httpClient, "'httpClient' is not of type CloseableHttpClient");
/*  86 */     this.httpClient = ((CloseableHttpClient)httpClient);
/*     */   }
/*     */ 
/*     */   public void setHttpClient(HttpClient httpClient)
/*     */   {
/*  99 */     Assert.isInstanceOf(CloseableHttpClient.class, httpClient, "'httpClient' is not of type CloseableHttpClient");
/* 100 */     this.httpClient = ((CloseableHttpClient)httpClient);
/*     */   }
/*     */ 
/*     */   public HttpClient getHttpClient()
/*     */   {
/* 108 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int timeout)
/*     */   {
/* 117 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 118 */     this.connectTimeout = timeout;
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int timeout)
/*     */   {
/* 127 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 128 */     this.socketTimeout = timeout;
/*     */   }
/*     */ 
/*     */   public void setBufferRequestBody(boolean bufferRequestBody)
/*     */   {
/* 137 */     this.bufferRequestBody = bufferRequestBody;
/*     */   }
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 143 */     CloseableHttpClient client = (CloseableHttpClient)getHttpClient();
/* 144 */     Assert.state(client != null, "Synchronous execution requires an HttpClient to be set");
/* 145 */     HttpUriRequest httpRequest = createHttpUriRequest(httpMethod, uri);
/* 146 */     postProcessHttpRequest(httpRequest);
/* 147 */     HttpContext context = createHttpContext(httpMethod, uri);
/* 148 */     if (context == null) {
/* 149 */       context = HttpClientContext.create();
/*     */     }
/*     */ 
/* 152 */     if (context.getAttribute("http.request-config") == null)
/*     */     {
/* 154 */       RequestConfig config = null;
/* 155 */       if ((httpRequest instanceof Configurable)) {
/* 156 */         config = ((Configurable)httpRequest).getConfig();
/*     */       }
/* 158 */       if (config == null) {
/* 159 */         if ((this.socketTimeout > 0) || (this.connectTimeout > 0))
/*     */         {
/* 163 */           config = RequestConfig.custom()
/* 161 */             .setConnectTimeout(this.connectTimeout)
/* 162 */             .setSocketTimeout(this.socketTimeout)
/* 163 */             .build();
/*     */         }
/*     */         else {
/* 166 */           config = RequestConfig.DEFAULT;
/*     */         }
/*     */       }
/* 169 */       context.setAttribute("http.request-config", config);
/*     */     }
/* 171 */     if (this.bufferRequestBody) {
/* 172 */       return new HttpComponentsClientHttpRequest(client, httpRequest, context);
/*     */     }
/*     */ 
/* 175 */     return new HttpComponentsStreamingClientHttpRequest(client, httpRequest, context);
/*     */   }
/*     */ 
/*     */   protected HttpUriRequest createHttpUriRequest(HttpMethod httpMethod, URI uri)
/*     */   {
/* 186 */     switch (1.$SwitchMap$org$springframework$http$HttpMethod[httpMethod.ordinal()]) {
/*     */     case 1:
/* 188 */       return new HttpGet(uri);
/*     */     case 2:
/* 190 */       return new HttpDelete(uri);
/*     */     case 3:
/* 192 */       return new HttpHead(uri);
/*     */     case 4:
/* 194 */       return new HttpOptions(uri);
/*     */     case 5:
/* 196 */       return new HttpPost(uri);
/*     */     case 6:
/* 198 */       return new HttpPut(uri);
/*     */     case 7:
/* 200 */       return new HttpTrace(uri);
/*     */     case 8:
/* 202 */       return new HttpPatch(uri);
/*     */     }
/* 204 */     throw new IllegalArgumentException("Invalid HTTP method: " + httpMethod);
/*     */   }
/*     */ 
/*     */   protected void postProcessHttpRequest(HttpUriRequest request)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected HttpContext createHttpContext(HttpMethod httpMethod, URI uri)
/*     */   {
/* 225 */     return null;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws Exception
/*     */   {
/* 235 */     this.httpClient.close();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsClientHttpRequestFactory
 * JD-Core Version:    0.6.2
 */