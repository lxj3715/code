/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.http.Header;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.StatusLine;
/*    */ import org.apache.http.client.methods.CloseableHttpResponse;
/*    */ import org.apache.http.util.EntityUtils;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ final class HttpComponentsClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final CloseableHttpResponse httpResponse;
/*    */   private HttpHeaders headers;
/*    */ 
/*    */   HttpComponentsClientHttpResponse(CloseableHttpResponse httpResponse)
/*    */   {
/* 48 */     this.httpResponse = httpResponse;
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode()
/*    */     throws IOException
/*    */   {
/* 54 */     return this.httpResponse.getStatusLine().getStatusCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException
/*    */   {
/* 59 */     return this.httpResponse.getStatusLine().getReasonPhrase();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 64 */     if (this.headers == null) {
/* 65 */       this.headers = new HttpHeaders();
/* 66 */       for (Header header : this.httpResponse.getAllHeaders()) {
/* 67 */         this.headers.add(header.getName(), header.getValue());
/*    */       }
/*    */     }
/* 70 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 75 */     HttpEntity entity = this.httpResponse.getEntity();
/* 76 */     return entity != null ? entity.getContent() : null;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/*    */     try
/*    */     {
/*    */       try
/*    */       {
/* 85 */         EntityUtils.consume(this.httpResponse.getEntity());
/*    */ 
/* 88 */         this.httpResponse.close(); } finally { this.httpResponse.close(); }
/*    */ 
/*    */     }
/*    */     catch (IOException ignore)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsClientHttpResponse
 * JD-Core Version:    0.6.2
 */