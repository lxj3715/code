/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpEntityEnclosingRequest;
/*     */ import org.apache.http.client.methods.CloseableHttpResponse;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.message.BasicHeader;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.http.StreamingHttpOutputMessage.Body;
/*     */ 
/*     */ final class HttpComponentsStreamingClientHttpRequest extends AbstractClientHttpRequest
/*     */   implements StreamingHttpOutputMessage
/*     */ {
/*     */   private final CloseableHttpClient httpClient;
/*     */   private final HttpUriRequest httpRequest;
/*     */   private final HttpContext httpContext;
/*     */   private StreamingHttpOutputMessage.Body body;
/*     */ 
/*     */   public HttpComponentsStreamingClientHttpRequest(CloseableHttpClient httpClient, HttpUriRequest httpRequest, HttpContext httpContext)
/*     */   {
/*  62 */     this.httpClient = httpClient;
/*  63 */     this.httpRequest = httpRequest;
/*  64 */     this.httpContext = httpContext;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  69 */     return HttpMethod.valueOf(this.httpRequest.getMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*  74 */     return this.httpRequest.getURI();
/*     */   }
/*     */ 
/*     */   public void setBody(StreamingHttpOutputMessage.Body body)
/*     */   {
/*  79 */     assertNotExecuted();
/*  80 */     this.body = body;
/*     */   }
/*     */ 
/*     */   protected OutputStream getBodyInternal(HttpHeaders headers) throws IOException
/*     */   {
/*  85 */     throw new UnsupportedOperationException("getBody not supported when bufferRequestBody is false");
/*     */   }
/*     */ 
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers)
/*     */     throws IOException
/*     */   {
/*  91 */     HttpComponentsClientHttpRequest.addHeaders(this.httpRequest, headers);
/*     */ 
/*  93 */     if (((this.httpRequest instanceof HttpEntityEnclosingRequest)) && (this.body != null)) {
/*  94 */       HttpEntityEnclosingRequest entityEnclosingRequest = (HttpEntityEnclosingRequest)this.httpRequest;
/*     */ 
/*  97 */       HttpEntity requestEntity = new StreamingHttpEntity(getHeaders(), this.body, null);
/*  98 */       entityEnclosingRequest.setEntity(requestEntity);
/*     */     }
/*     */ 
/* 101 */     CloseableHttpResponse httpResponse = this.httpClient
/* 101 */       .execute(this.httpRequest, this.httpContext);
/*     */ 
/* 102 */     return new HttpComponentsClientHttpResponse(httpResponse);
/*     */   }
/*     */ 
/*     */   private static class StreamingHttpEntity
/*     */     implements HttpEntity
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */     private final StreamingHttpOutputMessage.Body body;
/*     */ 
/*     */     private StreamingHttpEntity(HttpHeaders headers, StreamingHttpOutputMessage.Body body)
/*     */     {
/* 114 */       this.headers = headers;
/* 115 */       this.body = body;
/*     */     }
/*     */ 
/*     */     public boolean isRepeatable()
/*     */     {
/* 120 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean isChunked()
/*     */     {
/* 125 */       return false;
/*     */     }
/*     */ 
/*     */     public long getContentLength()
/*     */     {
/* 130 */       return this.headers.getContentLength();
/*     */     }
/*     */ 
/*     */     public Header getContentType()
/*     */     {
/* 135 */       MediaType contentType = this.headers.getContentType();
/*     */ 
/* 137 */       return contentType != null ? new BasicHeader("Content-Type", contentType
/* 137 */         .toString()) : null;
/*     */     }
/*     */ 
/*     */     public Header getContentEncoding()
/*     */     {
/* 142 */       String contentEncoding = this.headers.getFirst("Content-Encoding");
/* 143 */       return contentEncoding != null ? new BasicHeader("Content-Encoding", contentEncoding) : null;
/*     */     }
/*     */ 
/*     */     public InputStream getContent()
/*     */       throws IOException, IllegalStateException
/*     */     {
/* 150 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     public void writeTo(OutputStream outputStream) throws IOException
/*     */     {
/* 155 */       this.body.writeTo(outputStream);
/*     */     }
/*     */ 
/*     */     public boolean isStreaming()
/*     */     {
/* 160 */       return true;
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public void consumeContent() throws IOException
/*     */     {
/* 166 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsStreamingClientHttpRequest
 * JD-Core Version:    0.6.2
 */