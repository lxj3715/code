/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.http.HttpMethod;
/*    */ 
/*    */ public class InterceptingClientHttpRequestFactory extends AbstractClientHttpRequestFactoryWrapper
/*    */ {
/*    */   private final List<ClientHttpRequestInterceptor> interceptors;
/*    */ 
/*    */   public InterceptingClientHttpRequestFactory(ClientHttpRequestFactory requestFactory, List<ClientHttpRequestInterceptor> interceptors)
/*    */   {
/* 43 */     super(requestFactory);
/* 44 */     this.interceptors = (interceptors != null ? interceptors : Collections.emptyList());
/*    */   }
/*    */ 
/*    */   protected ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod, ClientHttpRequestFactory requestFactory)
/*    */   {
/* 49 */     return new InterceptingClientHttpRequest(requestFactory, this.interceptors, uri, httpMethod);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.InterceptingClientHttpRequestFactory
 * JD-Core Version:    0.6.2
 */