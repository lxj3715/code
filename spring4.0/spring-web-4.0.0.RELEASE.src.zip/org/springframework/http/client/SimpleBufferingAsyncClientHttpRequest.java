/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.springframework.core.task.AsyncListenableTaskExecutor;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ import org.springframework.util.concurrent.ListenableFuture;
/*    */ 
/*    */ final class SimpleBufferingAsyncClientHttpRequest extends AbstractBufferingAsyncClientHttpRequest
/*    */ {
/*    */   private final HttpURLConnection connection;
/*    */   private final boolean outputStreaming;
/*    */   private final AsyncListenableTaskExecutor taskExecutor;
/*    */ 
/*    */   SimpleBufferingAsyncClientHttpRequest(HttpURLConnection connection, boolean outputStreaming, AsyncListenableTaskExecutor taskExecutor)
/*    */   {
/* 52 */     this.connection = connection;
/* 53 */     this.outputStreaming = outputStreaming;
/* 54 */     this.taskExecutor = taskExecutor;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 59 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*    */   }
/*    */ 
/*    */   public URI getURI()
/*    */   {
/*    */     try {
/* 65 */       return this.connection.getURL().toURI();
/*    */     }
/*    */     catch (URISyntaxException ex) {
/* 68 */       throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex.getMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected ListenableFuture<ClientHttpResponse> executeInternal(final HttpHeaders headers, final byte[] bufferedOutput)
/*    */     throws IOException
/*    */   {
/* 75 */     return this.taskExecutor.submitListenable(new Callable()
/*    */     {
/*    */       public ClientHttpResponse call() throws Exception {
/* 78 */         for (Map.Entry entry : headers.entrySet()) {
/* 79 */           headerName = (String)entry.getKey();
/* 80 */           for (String headerValue : (List)entry.getValue())
/* 81 */             SimpleBufferingAsyncClientHttpRequest.this.connection.addRequestProperty(headerName, headerValue);
/*    */         }
/*    */         String headerName;
/* 85 */         if ((SimpleBufferingAsyncClientHttpRequest.this.connection.getDoOutput()) && (SimpleBufferingAsyncClientHttpRequest.this.outputStreaming)) {
/* 86 */           SimpleBufferingAsyncClientHttpRequest.this.connection.setFixedLengthStreamingMode(bufferedOutput.length);
/*    */         }
/*    */ 
/* 89 */         SimpleBufferingAsyncClientHttpRequest.this.connection.connect();
/* 90 */         if (SimpleBufferingAsyncClientHttpRequest.this.connection.getDoOutput()) {
/* 91 */           FileCopyUtils.copy(bufferedOutput, SimpleBufferingAsyncClientHttpRequest.this.connection.getOutputStream());
/*    */         }
/* 93 */         return new SimpleClientHttpResponse(SimpleBufferingAsyncClientHttpRequest.this.connection);
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleBufferingAsyncClientHttpRequest
 * JD-Core Version:    0.6.2
 */