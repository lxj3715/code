/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ final class SimpleBufferingClientHttpRequest extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final HttpURLConnection connection;
/*    */   private final boolean outputStreaming;
/*    */ 
/*    */   SimpleBufferingClientHttpRequest(HttpURLConnection connection, boolean outputStreaming)
/*    */   {
/* 46 */     this.connection = connection;
/* 47 */     this.outputStreaming = outputStreaming;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 53 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*    */   }
/*    */ 
/*    */   public URI getURI()
/*    */   {
/*    */     try {
/* 59 */       return this.connection.getURL().toURI();
/*    */     }
/*    */     catch (URISyntaxException ex) {
/* 62 */       throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex.getMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput) throws IOException
/*    */   {
/* 68 */     for (Map.Entry entry : headers.entrySet()) {
/* 69 */       headerName = (String)entry.getKey();
/* 70 */       for (String headerValue : (List)entry.getValue())
/* 71 */         this.connection.addRequestProperty(headerName, headerValue);
/*    */     }
/*    */     String headerName;
/* 75 */     if ((this.connection.getDoOutput()) && (this.outputStreaming)) {
/* 76 */       this.connection.setFixedLengthStreamingMode(bufferedOutput.length);
/*    */     }
/* 78 */     this.connection.connect();
/* 79 */     if (this.connection.getDoOutput()) {
/* 80 */       FileCopyUtils.copy(bufferedOutput, this.connection.getOutputStream());
/*    */     }
/*    */ 
/* 83 */     return new SimpleClientHttpResponse(this.connection);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleBufferingClientHttpRequest
 * JD-Core Version:    0.6.2
 */