/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.springframework.core.task.AsyncListenableTaskExecutor;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ 
/*     */ final class SimpleStreamingAsyncClientHttpRequest extends AbstractAsyncClientHttpRequest
/*     */ {
/*     */   private final HttpURLConnection connection;
/*     */   private final int chunkSize;
/*     */   private OutputStream body;
/*     */   private final boolean outputStreaming;
/*     */   private final AsyncListenableTaskExecutor taskExecutor;
/*     */ 
/*     */   SimpleStreamingAsyncClientHttpRequest(HttpURLConnection connection, int chunkSize, boolean outputStreaming, AsyncListenableTaskExecutor taskExecutor)
/*     */   {
/*  58 */     this.connection = connection;
/*  59 */     this.chunkSize = chunkSize;
/*  60 */     this.outputStreaming = outputStreaming;
/*  61 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  66 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*     */     try {
/*  72 */       return this.connection.getURL().toURI();
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/*  76 */       throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex
/*  76 */         .getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected OutputStream getBodyInternal(HttpHeaders headers) throws IOException
/*     */   {
/*  82 */     if (this.body == null) {
/*  83 */       if (this.outputStreaming) {
/*  84 */         int contentLength = (int)headers.getContentLength();
/*  85 */         if (contentLength >= 0) {
/*  86 */           this.connection.setFixedLengthStreamingMode(contentLength);
/*     */         }
/*     */         else {
/*  89 */           this.connection.setChunkedStreamingMode(this.chunkSize);
/*     */         }
/*     */       }
/*  92 */       writeHeaders(headers);
/*  93 */       this.connection.connect();
/*  94 */       this.body = this.connection.getOutputStream();
/*     */     }
/*  96 */     return StreamUtils.nonClosing(this.body);
/*     */   }
/*     */ 
/*     */   private void writeHeaders(HttpHeaders headers) {
/* 100 */     for (Map.Entry entry : headers.entrySet()) {
/* 101 */       headerName = (String)entry.getKey();
/* 102 */       for (String headerValue : (List)entry.getValue())
/* 103 */         this.connection.addRequestProperty(headerName, headerValue);
/*     */     }
/*     */     String headerName;
/*     */   }
/*     */ 
/*     */   protected ListenableFuture<ClientHttpResponse> executeInternal(final HttpHeaders headers)
/*     */     throws IOException
/*     */   {
/* 111 */     return this.taskExecutor.submitListenable(new Callable()
/*     */     {
/*     */       public ClientHttpResponse call() throws Exception {
/*     */         try {
/* 115 */           if (SimpleStreamingAsyncClientHttpRequest.this.body != null) {
/* 116 */             SimpleStreamingAsyncClientHttpRequest.this.body.close();
/*     */           }
/*     */           else {
/* 119 */             SimpleStreamingAsyncClientHttpRequest.this.writeHeaders(headers);
/* 120 */             SimpleStreamingAsyncClientHttpRequest.this.connection.connect();
/*     */           }
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/* 126 */         return new SimpleClientHttpResponse(SimpleStreamingAsyncClientHttpRequest.this.connection);
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleStreamingAsyncClientHttpRequest
 * JD-Core Version:    0.6.2
 */