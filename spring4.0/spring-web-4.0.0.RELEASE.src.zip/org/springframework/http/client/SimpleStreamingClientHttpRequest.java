/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ final class SimpleStreamingClientHttpRequest extends AbstractClientHttpRequest
/*     */ {
/*     */   private final HttpURLConnection connection;
/*     */   private final int chunkSize;
/*     */   private OutputStream body;
/*     */   private final boolean outputStreaming;
/*     */ 
/*     */   SimpleStreamingClientHttpRequest(HttpURLConnection connection, int chunkSize, boolean outputStreaming)
/*     */   {
/*  52 */     this.connection = connection;
/*  53 */     this.chunkSize = chunkSize;
/*  54 */     this.outputStreaming = outputStreaming;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  59 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*     */     try {
/*  65 */       return this.connection.getURL().toURI();
/*     */     }
/*     */     catch (URISyntaxException ex) {
/*  68 */       throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected OutputStream getBodyInternal(HttpHeaders headers) throws IOException
/*     */   {
/*  74 */     if (this.body == null) {
/*  75 */       if (this.outputStreaming) {
/*  76 */         int contentLength = (int)headers.getContentLength();
/*  77 */         if (contentLength >= 0) {
/*  78 */           this.connection.setFixedLengthStreamingMode(contentLength);
/*     */         }
/*     */         else {
/*  81 */           this.connection.setChunkedStreamingMode(this.chunkSize);
/*     */         }
/*     */       }
/*  84 */       writeHeaders(headers);
/*  85 */       this.connection.connect();
/*  86 */       this.body = this.connection.getOutputStream();
/*     */     }
/*  88 */     return StreamUtils.nonClosing(this.body);
/*     */   }
/*     */ 
/*     */   private void writeHeaders(HttpHeaders headers) {
/*  92 */     for (Map.Entry entry : headers.entrySet()) {
/*  93 */       headerName = (String)entry.getKey();
/*  94 */       for (String headerValue : (List)entry.getValue())
/*  95 */         this.connection.addRequestProperty(headerName, headerValue);
/*     */     }
/*     */     String headerName;
/*     */   }
/*     */ 
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers) throws IOException
/*     */   {
/*     */     try {
/* 103 */       if (this.body != null) {
/* 104 */         this.body.close();
/*     */       }
/*     */       else {
/* 107 */         writeHeaders(headers);
/* 108 */         this.connection.connect();
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/* 114 */     return new SimpleClientHttpResponse(this.connection);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleStreamingClientHttpRequest
 * JD-Core Version:    0.6.2
 */