/*    */ package org.springframework.http.client.support;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.client.AsyncClientHttpRequest;
/*    */ import org.springframework.http.client.AsyncClientHttpRequestFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AsyncHttpAccessor
/*    */ {
/* 44 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   private AsyncClientHttpRequestFactory asyncRequestFactory;
/*    */ 
/*    */   public void setAsyncRequestFactory(AsyncClientHttpRequestFactory asyncRequestFactory)
/*    */   {
/* 53 */     Assert.notNull(asyncRequestFactory, "'asyncRequestFactory' must not be null");
/* 54 */     this.asyncRequestFactory = asyncRequestFactory;
/*    */   }
/*    */ 
/*    */   public AsyncClientHttpRequestFactory getAsyncRequestFactory()
/*    */   {
/* 62 */     return this.asyncRequestFactory;
/*    */   }
/*    */ 
/*    */   protected AsyncClientHttpRequest createAsyncRequest(URI url, HttpMethod method)
/*    */     throws IOException
/*    */   {
/* 75 */     AsyncClientHttpRequest request = getAsyncRequestFactory().createAsyncRequest(url, method);
/* 76 */     if (this.logger.isDebugEnabled()) {
/* 77 */       this.logger.debug("Created asynchronous " + method.name() + " request for \"" + url + "\"");
/*    */     }
/* 79 */     return request;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.support.AsyncHttpAccessor
 * JD-Core Version:    0.6.2
 */