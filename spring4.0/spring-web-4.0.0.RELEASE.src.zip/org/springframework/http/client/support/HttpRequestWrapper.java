/*    */ package org.springframework.http.client.support;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpRequest;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class HttpRequestWrapper
/*    */   implements HttpRequest
/*    */ {
/*    */   private final HttpRequest request;
/*    */ 
/*    */   public HttpRequestWrapper(HttpRequest request)
/*    */   {
/* 44 */     Assert.notNull(request, "'request' must not be null");
/* 45 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public HttpRequest getRequest()
/*    */   {
/* 52 */     return this.request;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 60 */     return this.request.getMethod();
/*    */   }
/*    */ 
/*    */   public URI getURI()
/*    */   {
/* 68 */     return this.request.getURI();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 76 */     return this.request.getHeaders();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.support.HttpRequestWrapper
 * JD-Core Version:    0.6.2
 */