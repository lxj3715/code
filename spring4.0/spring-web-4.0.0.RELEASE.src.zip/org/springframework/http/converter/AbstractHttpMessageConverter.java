/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.http.StreamingHttpOutputMessage.Body;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractHttpMessageConverter<T>
/*     */   implements HttpMessageConverter<T>
/*     */ {
/*  49 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  51 */   private List<MediaType> supportedMediaTypes = Collections.emptyList();
/*     */ 
/*     */   protected AbstractHttpMessageConverter()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected AbstractHttpMessageConverter(MediaType supportedMediaType)
/*     */   {
/*  66 */     setSupportedMediaTypes(Collections.singletonList(supportedMediaType));
/*     */   }
/*     */ 
/*     */   protected AbstractHttpMessageConverter(MediaType[] supportedMediaTypes)
/*     */   {
/*  74 */     setSupportedMediaTypes(Arrays.asList(supportedMediaTypes));
/*     */   }
/*     */ 
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes)
/*     */   {
/*  82 */     Assert.notEmpty(supportedMediaTypes, "'supportedMediaTypes' must not be empty");
/*  83 */     this.supportedMediaTypes = new ArrayList(supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes()
/*     */   {
/*  88 */     return Collections.unmodifiableList(this.supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  99 */     return (supports(clazz)) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean canRead(MediaType mediaType)
/*     */   {
/* 111 */     if (mediaType == null) {
/* 112 */       return true;
/*     */     }
/* 114 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 115 */       if (supportedMediaType.includes(mediaType)) {
/* 116 */         return true;
/*     */       }
/*     */     }
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 129 */     return (supports(clazz)) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean canWrite(MediaType mediaType)
/*     */   {
/* 141 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 142 */       return true;
/*     */     }
/* 144 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 145 */       if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 146 */         return true;
/*     */       }
/*     */     }
/* 149 */     return false;
/*     */   }
/*     */ 
/*     */   public final T read(Class<? extends T> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException
/*     */   {
/* 158 */     return readInternal(clazz, inputMessage);
/*     */   }
/*     */ 
/*     */   public final void write(final T t, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 170 */     final HttpHeaders headers = outputMessage.getHeaders();
/* 171 */     if (headers.getContentType() == null) {
/* 172 */       if ((contentType == null) || (contentType.isWildcardType()) || (contentType.isWildcardSubtype())) {
/* 173 */         contentType = getDefaultContentType(t);
/*     */       }
/* 175 */       if (contentType != null) {
/* 176 */         headers.setContentType(contentType);
/*     */       }
/*     */     }
/* 179 */     if (headers.getContentLength() == -1L) {
/* 180 */       Long contentLength = getContentLength(t, headers.getContentType());
/* 181 */       if (contentLength != null) {
/* 182 */         headers.setContentLength(contentLength.longValue());
/*     */       }
/*     */     }
/* 185 */     if ((outputMessage instanceof StreamingHttpOutputMessage)) {
/* 186 */       StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)outputMessage;
/*     */ 
/* 189 */       streamingOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*     */       {
/*     */         public void writeTo(final OutputStream outputStream) throws IOException {
/* 192 */           AbstractHttpMessageConverter.this.writeInternal(t, new HttpOutputMessage()
/*     */           {
/*     */             public OutputStream getBody() throws IOException {
/* 195 */               return outputStream;
/*     */             }
/*     */ 
/*     */             public HttpHeaders getHeaders()
/*     */             {
/* 200 */               return AbstractHttpMessageConverter.1.this.val$headers;
/*     */             }
/*     */           });
/*     */         }
/*     */       });
/*     */     }
/*     */     else {
/* 207 */       writeInternal(t, outputMessage);
/* 208 */       outputMessage.getBody().flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected MediaType getDefaultContentType(T t)
/*     */     throws IOException
/*     */   {
/* 222 */     List mediaTypes = getSupportedMediaTypes();
/* 223 */     return !mediaTypes.isEmpty() ? (MediaType)mediaTypes.get(0) : null;
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(T t, MediaType contentType)
/*     */     throws IOException
/*     */   {
/* 234 */     return null;
/*     */   }
/*     */ 
/*     */   protected abstract boolean supports(Class<?> paramClass);
/*     */ 
/*     */   protected abstract T readInternal(Class<? extends T> paramClass, HttpInputMessage paramHttpInputMessage)
/*     */     throws IOException, HttpMessageNotReadableException;
/*     */ 
/*     */   protected abstract void writeInternal(T paramT, HttpOutputMessage paramHttpOutputMessage)
/*     */     throws IOException, HttpMessageNotWritableException;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.AbstractHttpMessageConverter
 * JD-Core Version:    0.6.2
 */