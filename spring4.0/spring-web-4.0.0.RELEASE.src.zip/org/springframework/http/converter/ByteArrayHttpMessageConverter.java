/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpInputMessage;
/*    */ import org.springframework.http.HttpOutputMessage;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ public class ByteArrayHttpMessageConverter extends AbstractHttpMessageConverter<byte[]>
/*    */ {
/*    */   public ByteArrayHttpMessageConverter()
/*    */   {
/* 41 */     super(new MediaType[] { new MediaType("application", "octet-stream"), MediaType.ALL });
/*    */   }
/*    */ 
/*    */   public boolean supports(Class<?> clazz)
/*    */   {
/* 46 */     return [B.class.equals(clazz);
/*    */   }
/*    */ 
/*    */   public byte[] readInternal(Class<? extends byte[]> clazz, HttpInputMessage inputMessage) throws IOException
/*    */   {
/* 51 */     long contentLength = inputMessage.getHeaders().getContentLength();
/* 52 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(contentLength >= 0L ? (int)contentLength : 4096);
/* 53 */     StreamUtils.copy(inputMessage.getBody(), bos);
/* 54 */     return bos.toByteArray();
/*    */   }
/*    */ 
/*    */   protected Long getContentLength(byte[] bytes, MediaType contentType)
/*    */   {
/* 59 */     return Long.valueOf(bytes.length);
/*    */   }
/*    */ 
/*    */   protected void writeInternal(byte[] bytes, HttpOutputMessage outputMessage) throws IOException
/*    */   {
/* 64 */     StreamUtils.copy(bytes, outputMessage.getBody());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.ByteArrayHttpMessageConverter
 * JD-Core Version:    0.6.2
 */