/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class FormHttpMessageConverter
/*     */   implements HttpMessageConverter<MultiValueMap<String, ?>>
/*     */ {
/*  74 */   private static final byte[] BOUNDARY_CHARS = { 45, 95, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90 };
/*     */ 
/*  80 */   private final Random rnd = new Random();
/*     */ 
/*  82 */   private Charset charset = Charset.forName("UTF-8");
/*     */ 
/*  84 */   private List<MediaType> supportedMediaTypes = new ArrayList();
/*     */ 
/*  86 */   private List<HttpMessageConverter<?>> partConverters = new ArrayList();
/*     */ 
/*     */   public FormHttpMessageConverter()
/*     */   {
/*  90 */     this.supportedMediaTypes.add(MediaType.APPLICATION_FORM_URLENCODED);
/*  91 */     this.supportedMediaTypes.add(MediaType.MULTIPART_FORM_DATA);
/*     */ 
/*  93 */     this.partConverters.add(new ByteArrayHttpMessageConverter());
/*  94 */     StringHttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter();
/*  95 */     stringHttpMessageConverter.setWriteAcceptCharset(false);
/*  96 */     this.partConverters.add(stringHttpMessageConverter);
/*  97 */     this.partConverters.add(new ResourceHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public final void setPartConverters(List<HttpMessageConverter<?>> partConverters)
/*     */   {
/* 105 */     Assert.notEmpty(partConverters, "'partConverters' must not be empty");
/* 106 */     this.partConverters = partConverters;
/*     */   }
/*     */ 
/*     */   public final void addPartConverter(HttpMessageConverter<?> partConverter)
/*     */   {
/* 113 */     Assert.notNull(partConverter, "'partConverter' must not be NULL");
/* 114 */     this.partConverters.add(partConverter);
/*     */   }
/*     */ 
/*     */   public void setCharset(Charset charset)
/*     */   {
/* 121 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 126 */     if (!MultiValueMap.class.isAssignableFrom(clazz)) {
/* 127 */       return false;
/*     */     }
/* 129 */     if (mediaType == null) {
/* 130 */       return true;
/*     */     }
/* 132 */     for (MediaType supportedMediaType : getSupportedMediaTypes())
/*     */     {
/* 134 */       if ((!supportedMediaType.equals(MediaType.MULTIPART_FORM_DATA)) && 
/* 135 */         (supportedMediaType
/* 135 */         .includes(mediaType)))
/*     */       {
/* 136 */         return true;
/*     */       }
/*     */     }
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 144 */     if (!MultiValueMap.class.isAssignableFrom(clazz)) {
/* 145 */       return false;
/*     */     }
/* 147 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 148 */       return true;
/*     */     }
/* 150 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 151 */       if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 152 */         return true;
/*     */       }
/*     */     }
/* 155 */     return false;
/*     */   }
/*     */ 
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes)
/*     */   {
/* 162 */     this.supportedMediaTypes = supportedMediaTypes;
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes()
/*     */   {
/* 167 */     return Collections.unmodifiableList(this.supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, String> read(Class<? extends MultiValueMap<String, ?>> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 174 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/* 175 */     Charset charset = contentType.getCharSet() != null ? contentType.getCharSet() : this.charset;
/* 176 */     String body = StreamUtils.copyToString(inputMessage.getBody(), charset);
/*     */ 
/* 178 */     String[] pairs = StringUtils.tokenizeToStringArray(body, "&");
/*     */ 
/* 180 */     MultiValueMap result = new LinkedMultiValueMap(pairs.length);
/*     */ 
/* 182 */     for (String pair : pairs) {
/* 183 */       int idx = pair.indexOf(61);
/* 184 */       if (idx == -1) {
/* 185 */         result.add(URLDecoder.decode(pair, charset.name()), null);
/*     */       }
/*     */       else {
/* 188 */         String name = URLDecoder.decode(pair.substring(0, idx), charset.name());
/* 189 */         String value = URLDecoder.decode(pair.substring(idx + 1), charset.name());
/* 190 */         result.add(name, value);
/*     */       }
/*     */     }
/* 193 */     return result;
/*     */   }
/*     */ 
/*     */   public void write(MultiValueMap<String, ?> map, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 200 */     if (!isMultipart(map, contentType)) {
/* 201 */       writeForm(map, contentType, outputMessage);
/*     */     }
/*     */     else
/* 204 */       writeMultipart(map, outputMessage);
/*     */   }
/*     */ 
/*     */   private boolean isMultipart(MultiValueMap<String, ?> map, MediaType contentType)
/*     */   {
/* 209 */     if (contentType != null) {
/* 210 */       return MediaType.MULTIPART_FORM_DATA.equals(contentType);
/*     */     }
/* 212 */     for (String name : map.keySet())
/* 213 */       for (localIterator2 = ((List)map.get(name)).iterator(); localIterator2.hasNext(); ) { Object value = localIterator2.next();
/* 214 */         if ((value != null) && (!(value instanceof String)))
/* 215 */           return true;
/*     */       }
/*     */     Iterator localIterator2;
/* 219 */     return false;
/*     */   }
/*     */ 
/*     */   private void writeForm(MultiValueMap<String, String> form, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException
/*     */   {
/*     */     Charset charset;
/*     */     Charset charset;
/* 225 */     if (contentType != null) {
/* 226 */       outputMessage.getHeaders().setContentType(contentType);
/* 227 */       charset = contentType.getCharSet() != null ? contentType.getCharSet() : this.charset;
/*     */     }
/*     */     else {
/* 230 */       outputMessage.getHeaders().setContentType(MediaType.APPLICATION_FORM_URLENCODED);
/* 231 */       charset = this.charset;
/*     */     }
/* 233 */     StringBuilder builder = new StringBuilder();
/* 234 */     for (Iterator nameIterator = form.keySet().iterator(); nameIterator.hasNext(); ) {
/* 235 */       String name = (String)nameIterator.next();
/* 236 */       for (Iterator valueIterator = ((List)form.get(name)).iterator(); valueIterator.hasNext(); ) {
/* 237 */         String value = (String)valueIterator.next();
/* 238 */         builder.append(URLEncoder.encode(name, charset.name()));
/* 239 */         if (value != null) {
/* 240 */           builder.append('=');
/* 241 */           builder.append(URLEncoder.encode(value, charset.name()));
/* 242 */           if (valueIterator.hasNext()) {
/* 243 */             builder.append('&');
/*     */           }
/*     */         }
/*     */       }
/* 247 */       if (nameIterator.hasNext()) {
/* 248 */         builder.append('&');
/*     */       }
/*     */     }
/* 251 */     byte[] bytes = builder.toString().getBytes(charset.name());
/* 252 */     outputMessage.getHeaders().setContentLength(bytes.length);
/* 253 */     StreamUtils.copy(bytes, outputMessage.getBody());
/*     */   }
/*     */ 
/*     */   private void writeMultipart(MultiValueMap<String, Object> parts, HttpOutputMessage outputMessage) throws IOException
/*     */   {
/* 258 */     byte[] boundary = generateMultipartBoundary();
/*     */ 
/* 260 */     Map parameters = Collections.singletonMap("boundary", new String(boundary, "US-ASCII"));
/* 261 */     MediaType contentType = new MediaType(MediaType.MULTIPART_FORM_DATA, parameters);
/* 262 */     outputMessage.getHeaders().setContentType(contentType);
/*     */ 
/* 264 */     writeParts(outputMessage.getBody(), parts, boundary);
/* 265 */     writeEnd(boundary, outputMessage.getBody());
/*     */   }
/*     */ 
/*     */   private void writeParts(OutputStream os, MultiValueMap<String, Object> parts, byte[] boundary) throws IOException {
/* 269 */     for (Map.Entry entry : parts.entrySet()) {
/* 270 */       name = (String)entry.getKey();
/* 271 */       for (localIterator2 = ((List)entry.getValue()).iterator(); localIterator2.hasNext(); ) { Object part = localIterator2.next();
/* 272 */         if (part != null) {
/* 273 */           writeBoundary(boundary, os);
/* 274 */           HttpEntity entity = getEntity(part);
/* 275 */           writePart(name, entity, os);
/* 276 */           writeNewLine(os); }  } 
/*     */     }
/*     */     String name;
/*     */     Iterator localIterator2;
/*     */   }
/*     */ 
/* 283 */   private void writeBoundary(byte[] boundary, OutputStream os) throws IOException { os.write(45);
/* 284 */     os.write(45);
/* 285 */     os.write(boundary);
/* 286 */     writeNewLine(os); }
/*     */ 
/*     */   private HttpEntity<?> getEntity(Object part)
/*     */   {
/* 290 */     if ((part instanceof HttpEntity)) {
/* 291 */       return (HttpEntity)part;
/*     */     }
/*     */ 
/* 294 */     return new HttpEntity(part);
/*     */   }
/*     */ 
/*     */   private void writePart(String name, HttpEntity<?> partEntity, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 300 */     Object partBody = partEntity.getBody();
/* 301 */     Class partType = partBody.getClass();
/* 302 */     HttpHeaders partHeaders = partEntity.getHeaders();
/* 303 */     MediaType partContentType = partHeaders.getContentType();
/* 304 */     for (HttpMessageConverter messageConverter : this.partConverters) {
/* 305 */       if (messageConverter.canWrite(partType, partContentType)) {
/* 306 */         HttpOutputMessage multipartOutputMessage = new MultipartHttpOutputMessage(os);
/* 307 */         multipartOutputMessage.getHeaders().setContentDispositionFormData(name, getFilename(partBody));
/* 308 */         if (!partHeaders.isEmpty()) {
/* 309 */           multipartOutputMessage.getHeaders().putAll(partHeaders);
/*     */         }
/* 311 */         messageConverter.write(partBody, partContentType, multipartOutputMessage);
/* 312 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 317 */     throw new HttpMessageNotWritableException(new StringBuilder().append("Could not write request: no suitable HttpMessageConverter found for request type [")
/* 317 */       .append(partType
/* 317 */       .getName()).append("]").toString());
/*     */   }
/*     */ 
/*     */   private void writeEnd(byte[] boundary, OutputStream os) throws IOException {
/* 321 */     os.write(45);
/* 322 */     os.write(45);
/* 323 */     os.write(boundary);
/* 324 */     os.write(45);
/* 325 */     os.write(45);
/* 326 */     writeNewLine(os);
/*     */   }
/*     */ 
/*     */   private void writeNewLine(OutputStream os) throws IOException {
/* 330 */     os.write(13);
/* 331 */     os.write(10);
/*     */   }
/*     */ 
/*     */   protected byte[] generateMultipartBoundary()
/*     */   {
/* 340 */     byte[] boundary = new byte[this.rnd.nextInt(11) + 30];
/* 341 */     for (int i = 0; i < boundary.length; i++) {
/* 342 */       boundary[i] = BOUNDARY_CHARS[this.rnd.nextInt(BOUNDARY_CHARS.length)];
/*     */     }
/* 344 */     return boundary;
/*     */   }
/*     */ 
/*     */   protected String getFilename(Object part)
/*     */   {
/* 356 */     if ((part instanceof Resource)) {
/* 357 */       Resource resource = (Resource)part;
/* 358 */       return resource.getFilename();
/*     */     }
/*     */ 
/* 361 */     return null;
/*     */   }
/*     */ 
/*     */   private class MultipartHttpOutputMessage
/*     */     implements HttpOutputMessage
/*     */   {
/* 371 */     private final HttpHeaders headers = new HttpHeaders();
/*     */     private final OutputStream os;
/* 375 */     private boolean headersWritten = false;
/*     */ 
/*     */     public MultipartHttpOutputMessage(OutputStream os) {
/* 378 */       this.os = os;
/*     */     }
/*     */ 
/*     */     public HttpHeaders getHeaders()
/*     */     {
/* 383 */       return this.headersWritten ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*     */     }
/*     */ 
/*     */     public OutputStream getBody() throws IOException
/*     */     {
/* 388 */       writeHeaders();
/* 389 */       return this.os;
/*     */     }
/*     */ 
/*     */     private void writeHeaders() throws IOException {
/* 393 */       if (!this.headersWritten) {
/* 394 */         for (Map.Entry entry : this.headers.entrySet()) {
/* 395 */           headerName = getAsciiBytes((String)entry.getKey());
/* 396 */           for (String headerValueString : (List)entry.getValue()) {
/* 397 */             byte[] headerValue = getAsciiBytes(headerValueString);
/* 398 */             this.os.write(headerName);
/* 399 */             this.os.write(58);
/* 400 */             this.os.write(32);
/* 401 */             this.os.write(headerValue);
/* 402 */             FormHttpMessageConverter.this.writeNewLine(this.os);
/*     */           }
/*     */         }
/*     */         byte[] headerName;
/* 405 */         FormHttpMessageConverter.this.writeNewLine(this.os);
/* 406 */         this.headersWritten = true;
/*     */       }
/*     */     }
/*     */ 
/*     */     protected byte[] getAsciiBytes(String name) {
/*     */       try {
/* 412 */         return name.getBytes("US-ASCII");
/*     */       }
/*     */       catch (UnsupportedEncodingException ex)
/*     */       {
/* 416 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.FormHttpMessageConverter
 * JD-Core Version:    0.6.2
 */