/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class HttpMessageConversionException extends NestedRuntimeException
/*    */ {
/*    */   public HttpMessageConversionException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   public HttpMessageConversionException(String msg, Throwable cause)
/*    */   {
/* 46 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.HttpMessageConversionException
 * JD-Core Version:    0.6.2
 */