/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ public class HttpMessageNotReadableException extends HttpMessageConversionException
/*    */ {
/*    */   public HttpMessageNotReadableException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ 
/*    */   public HttpMessageNotReadableException(String msg, Throwable cause)
/*    */   {
/* 45 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.HttpMessageNotReadableException
 * JD-Core Version:    0.6.2
 */