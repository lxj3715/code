/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ public class HttpMessageNotWritableException extends HttpMessageConversionException
/*    */ {
/*    */   public HttpMessageNotWritableException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   public HttpMessageNotWritableException(String msg, Throwable cause)
/*    */   {
/* 46 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.HttpMessageNotWritableException
 * JD-Core Version:    0.6.2
 */