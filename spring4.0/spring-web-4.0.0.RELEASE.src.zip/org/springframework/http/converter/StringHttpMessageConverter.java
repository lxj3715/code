/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.SortedMap;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ public class StringHttpMessageConverter extends AbstractHttpMessageConverter<String>
/*     */ {
/*  42 */   public static final Charset DEFAULT_CHARSET = Charset.forName("ISO-8859-1");
/*     */   private final Charset defaultCharset;
/*     */   private final List<Charset> availableCharsets;
/*  48 */   private boolean writeAcceptCharset = true;
/*     */ 
/*     */   public StringHttpMessageConverter()
/*     */   {
/*  56 */     this(DEFAULT_CHARSET);
/*     */   }
/*     */ 
/*     */   public StringHttpMessageConverter(Charset defaultCharset)
/*     */   {
/*  64 */     super(new MediaType[] { new MediaType("text", "plain", defaultCharset), MediaType.ALL });
/*  65 */     this.defaultCharset = defaultCharset;
/*  66 */     this.availableCharsets = new ArrayList(Charset.availableCharsets().values());
/*     */   }
/*     */ 
/*     */   public void setWriteAcceptCharset(boolean writeAcceptCharset)
/*     */   {
/*  74 */     this.writeAcceptCharset = writeAcceptCharset;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/*  79 */     return String.class.equals(clazz);
/*     */   }
/*     */ 
/*     */   protected String readInternal(Class<? extends String> clazz, HttpInputMessage inputMessage) throws IOException
/*     */   {
/*  84 */     Charset charset = getContentTypeCharset(inputMessage.getHeaders().getContentType());
/*  85 */     return StreamUtils.copyToString(inputMessage.getBody(), charset);
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(String s, MediaType contentType)
/*     */   {
/*  90 */     Charset charset = getContentTypeCharset(contentType);
/*     */     try {
/*  92 */       return Long.valueOf(s.getBytes(charset.name()).length);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/*  96 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeInternal(String s, HttpOutputMessage outputMessage) throws IOException
/*     */   {
/* 102 */     if (this.writeAcceptCharset) {
/* 103 */       outputMessage.getHeaders().setAcceptCharset(getAcceptedCharsets());
/*     */     }
/* 105 */     Charset charset = getContentTypeCharset(outputMessage.getHeaders().getContentType());
/* 106 */     StreamUtils.copy(s, charset, outputMessage.getBody());
/*     */   }
/*     */ 
/*     */   protected List<Charset> getAcceptedCharsets()
/*     */   {
/* 115 */     return this.availableCharsets;
/*     */   }
/*     */ 
/*     */   private Charset getContentTypeCharset(MediaType contentType) {
/* 119 */     if ((contentType != null) && (contentType.getCharSet() != null)) {
/* 120 */       return contentType.getCharSet();
/*     */     }
/*     */ 
/* 123 */     return this.defaultCharset;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.StringHttpMessageConverter
 * JD-Core Version:    0.6.2
 */