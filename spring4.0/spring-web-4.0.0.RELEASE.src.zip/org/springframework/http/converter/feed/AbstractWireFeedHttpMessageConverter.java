/*    */ package org.springframework.http.converter.feed;
/*    */ 
/*    */ import com.sun.syndication.feed.WireFeed;
/*    */ import com.sun.syndication.io.FeedException;
/*    */ import com.sun.syndication.io.WireFeedInput;
/*    */ import com.sun.syndication.io.WireFeedOutput;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.Writer;
/*    */ import java.nio.charset.Charset;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpInputMessage;
/*    */ import org.springframework.http.HttpOutputMessage;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*    */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*    */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public abstract class AbstractWireFeedHttpMessageConverter<T extends WireFeed> extends AbstractHttpMessageConverter<T>
/*    */ {
/* 50 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*    */ 
/*    */   protected AbstractWireFeedHttpMessageConverter(MediaType supportedMediaType) {
/* 53 */     super(supportedMediaType);
/*    */   }
/*    */ 
/*    */   protected T readInternal(Class<? extends T> clazz, HttpInputMessage inputMessage)
/*    */     throws IOException, HttpMessageNotReadableException
/*    */   {
/* 60 */     WireFeedInput feedInput = new WireFeedInput();
/* 61 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/*    */     Charset charset;
/*    */     Charset charset;
/* 63 */     if ((contentType != null) && (contentType.getCharSet() != null))
/* 64 */       charset = contentType.getCharSet();
/*    */     else
/* 66 */       charset = DEFAULT_CHARSET;
/*    */     try
/*    */     {
/* 69 */       Reader reader = new InputStreamReader(inputMessage.getBody(), charset);
/* 70 */       return feedInput.build(reader);
/*    */     }
/*    */     catch (FeedException ex) {
/* 73 */       throw new HttpMessageNotReadableException("Could not read WireFeed: " + ex.getMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void writeInternal(T wireFeed, HttpOutputMessage outputMessage)
/*    */     throws IOException, HttpMessageNotWritableException
/*    */   {
/* 80 */     String wireFeedEncoding = wireFeed.getEncoding();
/* 81 */     if (!StringUtils.hasLength(wireFeedEncoding)) {
/* 82 */       wireFeedEncoding = DEFAULT_CHARSET.name();
/*    */     }
/* 84 */     MediaType contentType = outputMessage.getHeaders().getContentType();
/* 85 */     if (contentType != null) {
/* 86 */       Charset wireFeedCharset = Charset.forName(wireFeedEncoding);
/* 87 */       contentType = new MediaType(contentType.getType(), contentType.getSubtype(), wireFeedCharset);
/* 88 */       outputMessage.getHeaders().setContentType(contentType);
/*    */     }
/*    */ 
/* 91 */     WireFeedOutput feedOutput = new WireFeedOutput();
/*    */     try
/*    */     {
/* 94 */       Writer writer = new OutputStreamWriter(outputMessage.getBody(), wireFeedEncoding);
/* 95 */       feedOutput.output(wireFeed, writer);
/*    */     }
/*    */     catch (FeedException ex) {
/* 98 */       throw new HttpMessageNotWritableException("Could not write WiredFeed: " + ex.getMessage(), ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.feed.AbstractWireFeedHttpMessageConverter
 * JD-Core Version:    0.6.2
 */