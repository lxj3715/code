/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude.Include;
/*     */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*     */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class Jackson2ObjectMapperFactoryBean
/*     */   implements FactoryBean<ObjectMapper>, InitializingBean
/*     */ {
/*     */   private ObjectMapper objectMapper;
/* 123 */   private Map<Object, Boolean> features = new HashMap();
/*     */ 
/* 125 */   private final List<Module> modules = new ArrayList();
/*     */   private DateFormat dateFormat;
/*     */   private AnnotationIntrospector annotationIntrospector;
/* 131 */   private final Map<Class<?>, JsonSerializer<?>> serializers = new LinkedHashMap();
/*     */ 
/* 133 */   private final Map<Class<?>, JsonDeserializer<?>> deserializers = new LinkedHashMap();
/*     */   private JsonInclude.Include serializationInclusion;
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/* 143 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   public void setDateFormat(DateFormat dateFormat)
/*     */   {
/* 153 */     this.dateFormat = dateFormat;
/*     */   }
/*     */ 
/*     */   public void setSimpleDateFormat(String format)
/*     */   {
/* 163 */     this.dateFormat = new SimpleDateFormat(format);
/*     */   }
/*     */ 
/*     */   public void setAnnotationIntrospector(AnnotationIntrospector annotationIntrospector)
/*     */   {
/* 171 */     this.annotationIntrospector = annotationIntrospector;
/*     */   }
/*     */ 
/*     */   public void setSerializers(JsonSerializer<?>[] serializers)
/*     */   {
/* 181 */     if (serializers != null)
/* 182 */       for (JsonSerializer serializer : serializers) {
/* 183 */         Class handledType = serializer.handledType();
/* 184 */         Assert.isTrue((handledType != null) && (handledType != Object.class), "Unknown handled type in " + serializer
/* 185 */           .getClass().getName());
/* 186 */         this.serializers.put(serializer.handledType(), serializer);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void setSerializersByType(Map<Class<?>, JsonSerializer<?>> serializers)
/*     */   {
/* 196 */     if (serializers != null)
/* 197 */       this.serializers.putAll(serializers);
/*     */   }
/*     */ 
/*     */   public void setDeserializersByType(Map<Class<?>, JsonDeserializer<?>> deserializers)
/*     */   {
/* 205 */     if (deserializers != null)
/* 206 */       this.deserializers.putAll(deserializers);
/*     */   }
/*     */ 
/*     */   public void setAutoDetectFields(boolean autoDetectFields)
/*     */   {
/* 214 */     this.features.put(MapperFeature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/*     */   }
/*     */ 
/*     */   public void setAutoDetectGettersSetters(boolean autoDetectGettersSetters)
/*     */   {
/* 222 */     this.features.put(MapperFeature.AUTO_DETECT_GETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 223 */     this.features.put(MapperFeature.AUTO_DETECT_SETTERS, Boolean.valueOf(autoDetectGettersSetters));
/*     */   }
/*     */ 
/*     */   public void setFailOnEmptyBeans(boolean failOnEmptyBeans)
/*     */   {
/* 230 */     this.features.put(SerializationFeature.FAIL_ON_EMPTY_BEANS, Boolean.valueOf(failOnEmptyBeans));
/*     */   }
/*     */ 
/*     */   public void setIndentOutput(boolean indentOutput)
/*     */   {
/* 237 */     this.features.put(SerializationFeature.INDENT_OUTPUT, Boolean.valueOf(indentOutput));
/*     */   }
/*     */ 
/*     */   public void setFeaturesToEnable(Object[] featuresToEnable)
/*     */   {
/* 249 */     if (featuresToEnable != null)
/* 250 */       for (Object feature : featuresToEnable)
/* 251 */         this.features.put(feature, Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   public void setFeaturesToDisable(Object[] featuresToDisable)
/*     */   {
/* 265 */     if (featuresToDisable != null)
/* 266 */       for (Object feature : featuresToDisable)
/* 267 */         this.features.put(feature, Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   public void setSerializationInclusion(JsonInclude.Include serializationInclusion)
/*     */   {
/* 277 */     this.serializationInclusion = serializationInclusion;
/*     */   }
/*     */ 
/*     */   public void setModules(List<Module> modules)
/*     */   {
/* 287 */     if (modules != null)
/* 288 */       this.modules.addAll(modules);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 294 */     if (this.objectMapper == null) {
/* 295 */       this.objectMapper = new ObjectMapper();
/*     */     }
/*     */ 
/* 298 */     if (this.dateFormat != null) {
/* 299 */       this.objectMapper.setDateFormat(this.dateFormat);
/*     */     }
/*     */ 
/* 302 */     if ((!this.serializers.isEmpty()) || (!this.deserializers.isEmpty())) {
/* 303 */       module = new SimpleModule();
/* 304 */       addSerializers(module);
/* 305 */       addDeserializers(module);
/* 306 */       this.objectMapper.registerModule(module);
/*     */     }
/*     */ 
/* 309 */     if (this.annotationIntrospector != null) {
/* 310 */       this.objectMapper.setAnnotationIntrospector(this.annotationIntrospector);
/*     */     }
/*     */ 
/* 313 */     for (SimpleModule module = this.features.keySet().iterator(); module.hasNext(); ) { Object feature = module.next();
/* 314 */       configureFeature(feature, ((Boolean)this.features.get(feature)).booleanValue());
/*     */     }
/*     */ 
/* 317 */     if (this.serializationInclusion != null) {
/* 318 */       this.objectMapper.setSerializationInclusion(this.serializationInclusion);
/*     */     }
/*     */ 
/* 321 */     if (!this.modules.isEmpty())
/* 322 */       this.objectMapper.registerModules(this.modules);
/*     */   }
/*     */ 
/*     */   private <T> void addSerializers(SimpleModule module)
/*     */   {
/* 328 */     for (Class type : this.serializers.keySet())
/* 329 */       module.addSerializer(type, (JsonSerializer)this.serializers.get(type));
/*     */   }
/*     */ 
/*     */   private <T> void addDeserializers(SimpleModule module)
/*     */   {
/* 335 */     for (Class type : this.deserializers.keySet())
/* 336 */       module.addDeserializer(type, (JsonDeserializer)this.deserializers.get(type));
/*     */   }
/*     */ 
/*     */   private void configureFeature(Object feature, boolean enabled)
/*     */   {
/* 341 */     if ((feature instanceof JsonParser.Feature)) {
/* 342 */       this.objectMapper.configure((JsonParser.Feature)feature, enabled);
/*     */     }
/* 344 */     else if ((feature instanceof JsonGenerator.Feature)) {
/* 345 */       this.objectMapper.configure((JsonGenerator.Feature)feature, enabled);
/*     */     }
/* 347 */     else if ((feature instanceof SerializationFeature)) {
/* 348 */       this.objectMapper.configure((SerializationFeature)feature, enabled);
/*     */     }
/* 350 */     else if ((feature instanceof DeserializationFeature)) {
/* 351 */       this.objectMapper.configure((DeserializationFeature)feature, enabled);
/*     */     }
/* 353 */     else if ((feature instanceof MapperFeature)) {
/* 354 */       this.objectMapper.configure((MapperFeature)feature, enabled);
/*     */     }
/*     */     else
/* 357 */       throw new FatalBeanException("Unknown feature class " + feature.getClass().getName());
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObject()
/*     */   {
/* 367 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 372 */     return ObjectMapper.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 377 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean
 * JD-Core Version:    0.6.2
 */