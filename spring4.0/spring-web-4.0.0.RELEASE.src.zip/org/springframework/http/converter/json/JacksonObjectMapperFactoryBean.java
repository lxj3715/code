/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.codehaus.jackson.JsonGenerator.Feature;
/*     */ import org.codehaus.jackson.JsonParser.Feature;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ @Deprecated
/*     */ public class JacksonObjectMapperFactoryBean
/*     */   implements FactoryBean<ObjectMapper>, InitializingBean
/*     */ {
/*     */   private ObjectMapper objectMapper;
/*  95 */   private Map<Object, Boolean> features = new HashMap();
/*     */   private DateFormat dateFormat;
/*     */   private AnnotationIntrospector annotationIntrospector;
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/* 107 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   public void setDateFormat(DateFormat dateFormat)
/*     */   {
/* 117 */     this.dateFormat = dateFormat;
/*     */   }
/*     */ 
/*     */   public void setSimpleDateFormat(String format)
/*     */   {
/* 127 */     this.dateFormat = new SimpleDateFormat(format);
/*     */   }
/*     */ 
/*     */   public void setAnnotationIntrospector(AnnotationIntrospector annotationIntrospector)
/*     */   {
/* 136 */     this.annotationIntrospector = annotationIntrospector;
/*     */   }
/*     */ 
/*     */   public void setAutoDetectFields(boolean autoDetectFields)
/*     */   {
/* 144 */     this.features.put(SerializationConfig.Feature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/* 145 */     this.features.put(DeserializationConfig.Feature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/*     */   }
/*     */ 
/*     */   public void setAutoDetectGettersSetters(boolean autoDetectGettersSetters)
/*     */   {
/* 153 */     this.features.put(SerializationConfig.Feature.AUTO_DETECT_GETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 154 */     this.features.put(DeserializationConfig.Feature.AUTO_DETECT_SETTERS, Boolean.valueOf(autoDetectGettersSetters));
/*     */   }
/*     */ 
/*     */   public void setFailOnEmptyBeans(boolean failOnEmptyBeans)
/*     */   {
/* 161 */     this.features.put(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, Boolean.valueOf(failOnEmptyBeans));
/*     */   }
/*     */ 
/*     */   public void setIndentOutput(boolean indentOutput)
/*     */   {
/* 168 */     this.features.put(SerializationConfig.Feature.INDENT_OUTPUT, Boolean.valueOf(indentOutput));
/*     */   }
/*     */ 
/*     */   public void setFeaturesToEnable(Object[] featuresToEnable)
/*     */   {
/* 179 */     if (featuresToEnable != null)
/* 180 */       for (Object feature : featuresToEnable)
/* 181 */         this.features.put(feature, Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   public void setFeaturesToDisable(Object[] featuresToDisable)
/*     */   {
/* 194 */     if (featuresToDisable != null)
/* 195 */       for (Object feature : featuresToDisable)
/* 196 */         this.features.put(feature, Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 204 */     if (this.objectMapper == null) {
/* 205 */       this.objectMapper = new ObjectMapper();
/*     */     }
/* 207 */     if (this.annotationIntrospector != null) {
/* 208 */       this.objectMapper.setSerializationConfig(this.objectMapper
/* 209 */         .getSerializationConfig().withAnnotationIntrospector(this.annotationIntrospector));
/* 210 */       this.objectMapper.setDeserializationConfig(this.objectMapper
/* 211 */         .getDeserializationConfig().withAnnotationIntrospector(this.annotationIntrospector));
/*     */     }
/* 213 */     if (this.dateFormat != null) {
/* 214 */       this.objectMapper.setDateFormat(this.dateFormat);
/*     */     }
/* 216 */     for (Map.Entry entry : this.features.entrySet())
/* 217 */       configureFeature(entry.getKey(), ((Boolean)entry.getValue()).booleanValue());
/*     */   }
/*     */ 
/*     */   private void configureFeature(Object feature, boolean enabled)
/*     */   {
/* 222 */     if ((feature instanceof JsonParser.Feature)) {
/* 223 */       this.objectMapper.configure((JsonParser.Feature)feature, enabled);
/*     */     }
/* 225 */     else if ((feature instanceof JsonGenerator.Feature)) {
/* 226 */       this.objectMapper.configure((JsonGenerator.Feature)feature, enabled);
/*     */     }
/* 228 */     else if ((feature instanceof SerializationConfig.Feature)) {
/* 229 */       this.objectMapper.configure((SerializationConfig.Feature)feature, enabled);
/*     */     }
/* 231 */     else if ((feature instanceof DeserializationConfig.Feature)) {
/* 232 */       this.objectMapper.configure((DeserializationConfig.Feature)feature, enabled);
/*     */     }
/*     */     else
/* 235 */       throw new IllegalArgumentException("Unknown feature class: " + feature.getClass().getName());
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObject()
/*     */   {
/* 245 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 250 */     return ObjectMapper.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 255 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.JacksonObjectMapperFactoryBean
 * JD-Core Version:    0.6.2
 */