/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MappingJackson2HttpMessageConverter extends AbstractHttpMessageConverter<Object>
/*     */   implements GenericHttpMessageConverter<Object>
/*     */ {
/*  59 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */ 
/*  62 */   private ObjectMapper objectMapper = new ObjectMapper();
/*     */   private String jsonPrefix;
/*     */   private Boolean prettyPrint;
/*     */ 
/*     */   public MappingJackson2HttpMessageConverter()
/*     */   {
/*  73 */     super(new MediaType[] { new MediaType("application", "json", DEFAULT_CHARSET), new MediaType("application", "*+json", DEFAULT_CHARSET) });
/*     */   }
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/*  88 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/*  89 */     this.objectMapper = objectMapper;
/*  90 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObjectMapper()
/*     */   {
/*  97 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/* 106 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/* 118 */     this.jsonPrefix = (prefixJson ? "{} && " : null);
/*     */   }
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 131 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 132 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   private void configurePrettyPrint() {
/* 136 */     if (this.prettyPrint != null)
/* 137 */       this.objectMapper.configure(SerializationFeature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 144 */     return canRead(clazz, null, mediaType);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/* 149 */     JavaType javaType = getJavaType(type, contextClass);
/* 150 */     return (this.objectMapper.canDeserialize(javaType)) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 155 */     return (this.objectMapper.canSerialize(clazz)) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 161 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 168 */     JavaType javaType = getJavaType(clazz, null);
/* 169 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 176 */     JavaType javaType = getJavaType(type, contextClass);
/* 177 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   private Object readJavaType(JavaType javaType, HttpInputMessage inputMessage) {
/*     */     try {
/* 182 */       return this.objectMapper.readValue(inputMessage.getBody(), javaType);
/*     */     }
/*     */     catch (IOException ex) {
/* 185 */       throw new HttpMessageNotReadableException("Could not read JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Object object, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 193 */     JsonEncoding encoding = getJsonEncoding(outputMessage.getHeaders().getContentType());
/*     */ 
/* 198 */     JsonGenerator jsonGenerator = this.objectMapper
/* 198 */       .getJsonFactory().createJsonGenerator(outputMessage.getBody(), encoding);
/*     */ 
/* 202 */     if (this.objectMapper.isEnabled(SerializationFeature.INDENT_OUTPUT)) {
/* 203 */       jsonGenerator.useDefaultPrettyPrinter();
/*     */     }
/*     */     try
/*     */     {
/* 207 */       if (this.jsonPrefix != null) {
/* 208 */         jsonGenerator.writeRaw(this.jsonPrefix);
/*     */       }
/* 210 */       this.objectMapper.writeValue(jsonGenerator, object);
/*     */     }
/*     */     catch (JsonProcessingException ex) {
/* 213 */       throw new HttpMessageNotWritableException("Could not write JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JavaType getJavaType(Type type, Class<?> contextClass)
/*     */   {
/* 238 */     return this.objectMapper.getTypeFactory().constructType(type, contextClass);
/*     */   }
/*     */ 
/*     */   protected JsonEncoding getJsonEncoding(MediaType contentType)
/*     */   {
/* 247 */     if ((contentType != null) && (contentType.getCharSet() != null)) {
/* 248 */       Charset charset = contentType.getCharSet();
/* 249 */       for (JsonEncoding encoding : JsonEncoding.values()) {
/* 250 */         if (charset.name().equals(encoding.getJavaName())) {
/* 251 */           return encoding;
/*     */         }
/*     */       }
/*     */     }
/* 255 */     return JsonEncoding.UTF8;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
 * JD-Core Version:    0.6.2
 */