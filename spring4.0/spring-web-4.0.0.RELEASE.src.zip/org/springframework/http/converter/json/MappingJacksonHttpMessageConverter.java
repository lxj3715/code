/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ @Deprecated
/*     */ public class MappingJacksonHttpMessageConverter extends AbstractHttpMessageConverter<Object>
/*     */   implements GenericHttpMessageConverter<Object>
/*     */ {
/*  60 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */ 
/*  63 */   private ObjectMapper objectMapper = new ObjectMapper();
/*     */   private String jsonPrefix;
/*     */   private Boolean prettyPrint;
/*     */ 
/*     */   public MappingJacksonHttpMessageConverter()
/*     */   {
/*  74 */     super(new MediaType[] { new MediaType("application", "json", DEFAULT_CHARSET), new MediaType("application", "*+json", DEFAULT_CHARSET) });
/*     */   }
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/*  89 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/*  90 */     this.objectMapper = objectMapper;
/*  91 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObjectMapper()
/*     */   {
/*  98 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/* 107 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/* 119 */     this.jsonPrefix = (prefixJson ? "{} && " : null);
/*     */   }
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 133 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 134 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   private void configurePrettyPrint() {
/* 138 */     if (this.prettyPrint != null)
/* 139 */       this.objectMapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 146 */     return canRead(clazz, null, mediaType);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/* 151 */     JavaType javaType = getJavaType(type, contextClass);
/* 152 */     return (this.objectMapper.canDeserialize(javaType)) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 157 */     return (this.objectMapper.canSerialize(clazz)) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 163 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 170 */     JavaType javaType = getJavaType(clazz, null);
/* 171 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 178 */     JavaType javaType = getJavaType(type, contextClass);
/* 179 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   private Object readJavaType(JavaType javaType, HttpInputMessage inputMessage) {
/*     */     try {
/* 184 */       return this.objectMapper.readValue(inputMessage.getBody(), javaType);
/*     */     }
/*     */     catch (IOException ex) {
/* 187 */       throw new HttpMessageNotReadableException("Could not read JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Object object, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 195 */     JsonEncoding encoding = getJsonEncoding(outputMessage.getHeaders().getContentType());
/*     */ 
/* 197 */     JsonGenerator jsonGenerator = this.objectMapper
/* 197 */       .getJsonFactory().createJsonGenerator(outputMessage.getBody(), encoding);
/*     */ 
/* 201 */     if (this.objectMapper.getSerializationConfig().isEnabled(SerializationConfig.Feature.INDENT_OUTPUT)) {
/* 202 */       jsonGenerator.useDefaultPrettyPrinter();
/*     */     }
/*     */     try
/*     */     {
/* 206 */       if (this.jsonPrefix != null) {
/* 207 */         jsonGenerator.writeRaw(this.jsonPrefix);
/*     */       }
/* 209 */       this.objectMapper.writeValue(jsonGenerator, object);
/*     */     }
/*     */     catch (JsonProcessingException ex) {
/* 212 */       throw new HttpMessageNotWritableException("Could not write JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JavaType getJavaType(Type type, Class<?> contextClass)
/*     */   {
/* 236 */     return this.objectMapper.getTypeFactory().constructType(type, contextClass);
/*     */   }
/*     */ 
/*     */   protected JsonEncoding getJsonEncoding(MediaType contentType)
/*     */   {
/* 245 */     if ((contentType != null) && (contentType.getCharSet() != null)) {
/* 246 */       Charset charset = contentType.getCharSet();
/* 247 */       for (JsonEncoding encoding : JsonEncoding.values()) {
/* 248 */         if (charset.name().equals(encoding.getJavaName())) {
/* 249 */           return encoding;
/*     */         }
/*     */       }
/*     */     }
/* 253 */     return JsonEncoding.UTF8;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.MappingJacksonHttpMessageConverter
 * JD-Core Version:    0.6.2
 */