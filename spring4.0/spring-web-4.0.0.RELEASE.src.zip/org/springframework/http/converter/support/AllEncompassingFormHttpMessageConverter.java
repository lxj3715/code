/*    */ package org.springframework.http.converter.support;
/*    */ 
/*    */ import org.springframework.http.converter.FormHttpMessageConverter;
/*    */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*    */ import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class AllEncompassingFormHttpMessageConverter extends FormHttpMessageConverter
/*    */ {
/* 36 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", AllEncompassingFormHttpMessageConverter.class
/* 36 */     .getClassLoader());
/*    */ 
/* 39 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", AllEncompassingFormHttpMessageConverter.class
/* 39 */     .getClassLoader())) && 
/* 40 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", AllEncompassingFormHttpMessageConverter.class
/* 40 */     .getClassLoader()));
/*    */ 
/* 43 */   private static final boolean jacksonPresent = (ClassUtils.isPresent("org.codehaus.jackson.map.ObjectMapper", AllEncompassingFormHttpMessageConverter.class
/* 43 */     .getClassLoader())) && 
/* 44 */     (ClassUtils.isPresent("org.codehaus.jackson.JsonGenerator", AllEncompassingFormHttpMessageConverter.class
/* 44 */     .getClassLoader()));
/*    */ 
/*    */   public AllEncompassingFormHttpMessageConverter()
/*    */   {
/* 49 */     addPartConverter(new SourceHttpMessageConverter());
/* 50 */     if (jaxb2Present) {
/* 51 */       addPartConverter(new Jaxb2RootElementHttpMessageConverter());
/*    */     }
/* 53 */     if (jackson2Present) {
/* 54 */       addPartConverter(new MappingJackson2HttpMessageConverter());
/*    */     }
/* 56 */     else if (jacksonPresent)
/* 57 */       addPartConverter(new MappingJacksonHttpMessageConverter());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter
 * JD-Core Version:    0.6.2
 */