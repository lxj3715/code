/*    */ package org.springframework.http.converter.xml;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import javax.xml.bind.JAXBContext;
/*    */ import javax.xml.bind.JAXBException;
/*    */ import javax.xml.bind.Marshaller;
/*    */ import javax.xml.bind.Unmarshaller;
/*    */ import org.springframework.http.converter.HttpMessageConversionException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class AbstractJaxb2HttpMessageConverter<T> extends AbstractXmlHttpMessageConverter<T>
/*    */ {
/* 38 */   private final ConcurrentMap<Class<?>, JAXBContext> jaxbContexts = new ConcurrentHashMap(64);
/*    */ 
/*    */   protected final Marshaller createMarshaller(Class<?> clazz)
/*    */   {
/*    */     try
/*    */     {
/* 49 */       JAXBContext jaxbContext = getJaxbContext(clazz);
/* 50 */       return jaxbContext.createMarshaller();
/*    */     }
/*    */     catch (JAXBException ex)
/*    */     {
/* 54 */       throw new HttpMessageConversionException("Could not create Marshaller for class [" + clazz + "]: " + ex
/* 54 */         .getMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected final Unmarshaller createUnmarshaller(Class<?> clazz)
/*    */     throws JAXBException
/*    */   {
/*    */     try
/*    */     {
/* 66 */       JAXBContext jaxbContext = getJaxbContext(clazz);
/* 67 */       return jaxbContext.createUnmarshaller();
/*    */     }
/*    */     catch (JAXBException ex)
/*    */     {
/* 71 */       throw new HttpMessageConversionException("Could not create Unmarshaller for class [" + clazz + "]: " + ex
/* 71 */         .getMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected final JAXBContext getJaxbContext(Class<?> clazz)
/*    */   {
/* 82 */     Assert.notNull(clazz, "'clazz' must not be null");
/* 83 */     JAXBContext jaxbContext = (JAXBContext)this.jaxbContexts.get(clazz);
/* 84 */     if (jaxbContext == null) {
/*    */       try {
/* 86 */         jaxbContext = JAXBContext.newInstance(new Class[] { clazz });
/* 87 */         this.jaxbContexts.putIfAbsent(clazz, jaxbContext);
/*    */       }
/*    */       catch (JAXBException ex)
/*    */       {
/* 91 */         throw new HttpMessageConversionException("Could not instantiate JAXBContext for class [" + clazz + "]: " + ex
/* 91 */           .getMessage(), ex);
/*    */       }
/*    */     }
/* 94 */     return jaxbContext;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.AbstractJaxb2HttpMessageConverter
 * JD-Core Version:    0.6.2
 */