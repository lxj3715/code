/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ 
/*     */ public class Jaxb2CollectionHttpMessageConverter<T extends Collection> extends AbstractJaxb2HttpMessageConverter<T>
/*     */   implements GenericHttpMessageConverter<T>
/*     */ {
/*  61 */   private final XMLInputFactory inputFactory = createXmlInputFactory();
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/*  80 */     if (!(type instanceof ParameterizedType)) {
/*  81 */       return false;
/*     */     }
/*  83 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/*  84 */     if (!(parameterizedType.getRawType() instanceof Class)) {
/*  85 */       return false;
/*     */     }
/*  87 */     Class rawType = (Class)parameterizedType.getRawType();
/*  88 */     if (!Collection.class.isAssignableFrom(rawType)) {
/*  89 */       return false;
/*     */     }
/*  91 */     if (parameterizedType.getActualTypeArguments().length != 1) {
/*  92 */       return false;
/*     */     }
/*  94 */     Type typeArgument = parameterizedType.getActualTypeArguments()[0];
/*  95 */     if (!(typeArgument instanceof Class)) {
/*  96 */       return false;
/*     */     }
/*  98 */     Class typeArgumentClass = (Class)typeArgument;
/*     */ 
/* 100 */     return ((typeArgumentClass.isAnnotationPresent(XmlRootElement.class)) || 
/* 100 */       (typeArgumentClass
/* 100 */       .isAnnotationPresent(XmlType.class))) && 
/* 100 */       (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 115 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected T readFromSource(Class<? extends T> clazz, HttpHeaders headers, Source source)
/*     */     throws IOException
/*     */   {
/* 121 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public T read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 129 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/* 130 */     Collection result = createCollection((Class)parameterizedType.getRawType());
/* 131 */     Class elementClass = (Class)parameterizedType.getActualTypeArguments()[0];
/*     */     try
/*     */     {
/* 134 */       Unmarshaller unmarshaller = createUnmarshaller(elementClass);
/* 135 */       XMLStreamReader streamReader = this.inputFactory.createXMLStreamReader(inputMessage.getBody());
/* 136 */       int event = moveToFirstChildOfRootElement(streamReader);
/*     */ 
/* 138 */       while (event != 8) {
/* 139 */         if (elementClass.isAnnotationPresent(XmlRootElement.class)) {
/* 140 */           result.add(unmarshaller.unmarshal(streamReader));
/*     */         }
/* 142 */         else if (elementClass.isAnnotationPresent(XmlType.class)) {
/* 143 */           result.add(unmarshaller.unmarshal(streamReader, elementClass).getValue());
/*     */         }
/*     */         else
/*     */         {
/* 147 */           throw new HttpMessageConversionException("Could not unmarshal to [" + elementClass + "]");
/*     */         }
/* 149 */         event = moveToNextElement(streamReader);
/*     */       }
/* 151 */       return result;
/*     */     }
/*     */     catch (UnmarshalException ex) {
/* 154 */       throw new HttpMessageNotReadableException("Could not unmarshal to [" + elementClass + "]: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (JAXBException ex) {
/* 157 */       throw new HttpMessageConversionException("Could not instantiate JAXBContext: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 160 */       throw new HttpMessageConversionException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected T createCollection(Class<?> collectionClass)
/*     */   {
/* 173 */     if (!collectionClass.isInterface()) {
/*     */       try {
/* 175 */         return (Collection)collectionClass.newInstance();
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 180 */         throw new IllegalArgumentException("Could not instantiate collection class [" + collectionClass
/* 180 */           .getName() + "]: " + ex.getMessage());
/*     */       }
/*     */     }
/* 183 */     if (List.class.equals(collectionClass)) {
/* 184 */       return new ArrayList();
/*     */     }
/* 186 */     if (SortedSet.class.equals(collectionClass)) {
/* 187 */       return new TreeSet();
/*     */     }
/*     */ 
/* 190 */     return new LinkedHashSet();
/*     */   }
/*     */ 
/*     */   private int moveToFirstChildOfRootElement(XMLStreamReader streamReader)
/*     */     throws XMLStreamException
/*     */   {
/* 196 */     int event = streamReader.next();
/* 197 */     while (event != 1) {
/* 198 */       event = streamReader.next();
/*     */     }
/*     */ 
/* 202 */     event = streamReader.next();
/* 203 */     while ((event != 1) && (event != 8)) {
/* 204 */       event = streamReader.next();
/*     */     }
/* 206 */     return event;
/*     */   }
/*     */ 
/*     */   private int moveToNextElement(XMLStreamReader streamReader) throws XMLStreamException {
/* 210 */     int event = streamReader.getEventType();
/* 211 */     while ((event != 1) && (event != 8)) {
/* 212 */       event = streamReader.next();
/*     */     }
/* 214 */     return event;
/*     */   }
/*     */ 
/*     */   protected void writeToResult(T t, HttpHeaders headers, Result result) throws IOException
/*     */   {
/* 219 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected XMLInputFactory createXmlInputFactory()
/*     */   {
/* 231 */     XMLInputFactory inputFactory = XMLInputFactory.newInstance();
/* 232 */     inputFactory.setProperty("javax.xml.stream.isReplacingEntityReferences", Boolean.valueOf(false));
/* 233 */     return inputFactory;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.Jaxb2CollectionHttpMessageConverter
 * JD-Core Version:    0.6.2
 */