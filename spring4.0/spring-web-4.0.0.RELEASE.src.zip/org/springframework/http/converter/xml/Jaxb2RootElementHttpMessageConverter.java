/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.MarshalException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.PropertyException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class Jaxb2RootElementHttpMessageConverter extends AbstractJaxb2HttpMessageConverter<Object>
/*     */ {
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  55 */     return ((clazz.isAnnotationPresent(XmlRootElement.class)) || (clazz.isAnnotationPresent(XmlType.class))) && 
/*  55 */       (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  60 */     return (AnnotationUtils.findAnnotation(clazz, XmlRootElement.class) != null) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/*  66 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readFromSource(Class<?> clazz, HttpHeaders headers, Source source) throws IOException
/*     */   {
/*     */     try {
/*  72 */       Unmarshaller unmarshaller = createUnmarshaller(clazz);
/*  73 */       if (clazz.isAnnotationPresent(XmlRootElement.class)) {
/*  74 */         return unmarshaller.unmarshal(source);
/*     */       }
/*     */ 
/*  77 */       JAXBElement jaxbElement = unmarshaller.unmarshal(source, clazz);
/*  78 */       return jaxbElement.getValue();
/*     */     }
/*     */     catch (UnmarshalException ex)
/*     */     {
/*  82 */       throw new HttpMessageNotReadableException("Could not unmarshal to [" + clazz + "]: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (JAXBException ex)
/*     */     {
/*  86 */       throw new HttpMessageConversionException("Could not instantiate JAXBContext: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeToResult(Object o, HttpHeaders headers, Result result) throws IOException
/*     */   {
/*     */     try {
/*  93 */       Class clazz = ClassUtils.getUserClass(o);
/*  94 */       Marshaller marshaller = createMarshaller(clazz);
/*  95 */       setCharset(headers.getContentType(), marshaller);
/*  96 */       marshaller.marshal(o, result);
/*     */     }
/*     */     catch (MarshalException ex) {
/*  99 */       throw new HttpMessageNotWritableException("Could not marshal [" + o + "]: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (JAXBException ex) {
/* 102 */       throw new HttpMessageConversionException("Could not instantiate JAXBContext: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setCharset(MediaType contentType, Marshaller marshaller) throws PropertyException {
/* 107 */     if ((contentType != null) && (contentType.getCharSet() != null))
/* 108 */       marshaller.setProperty("jaxb.encoding", contentType.getCharSet().name());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter
 * JD-Core Version:    0.6.2
 */