/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ public class SourceHttpMessageConverter<T extends Source> extends AbstractHttpMessageConverter<T>
/*     */ {
/*  63 */   private final TransformerFactory transformerFactory = TransformerFactory.newInstance();
/*     */ 
/*  65 */   private boolean processExternalEntities = false;
/*     */ 
/*     */   public SourceHttpMessageConverter()
/*     */   {
/*  72 */     super(new MediaType[] { MediaType.APPLICATION_XML, MediaType.TEXT_XML, new MediaType("application", "*+xml") });
/*     */   }
/*     */ 
/*     */   public void setProcessExternalEntities(boolean processExternalEntities)
/*     */   {
/*  82 */     this.processExternalEntities = processExternalEntities;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/*  88 */     return (DOMSource.class.equals(clazz)) || (SAXSource.class.equals(clazz)) || 
/*  88 */       (StreamSource.class
/*  88 */       .equals(clazz)) || 
/*  88 */       (Source.class.equals(clazz));
/*     */   }
/*     */ 
/*     */   protected T readInternal(Class<? extends T> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/*  96 */     InputStream body = inputMessage.getBody();
/*  97 */     if (DOMSource.class.equals(clazz)) {
/*  98 */       return readDOMSource(body);
/*     */     }
/* 100 */     if (SAXSource.class.equals(clazz)) {
/* 101 */       return readSAXSource(body);
/*     */     }
/* 103 */     if (StAXSource.class.equals(clazz)) {
/* 104 */       return readStAXSource(body);
/*     */     }
/* 106 */     if ((StreamSource.class.equals(clazz)) || (Source.class.equals(clazz))) {
/* 107 */       return readStreamSource(body);
/*     */     }
/*     */ 
/* 110 */     throw new HttpMessageConversionException("Could not read class [" + clazz + "]. Only DOMSource, SAXSource, and StreamSource are supported.");
/*     */   }
/*     */ 
/*     */   private DOMSource readDOMSource(InputStream body) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
/* 118 */       documentBuilderFactory.setNamespaceAware(true);
/* 119 */       documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", this.processExternalEntities);
/* 120 */       DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
/* 121 */       Document document = documentBuilder.parse(body);
/* 122 */       return new DOMSource(document);
/*     */     }
/*     */     catch (ParserConfigurationException ex) {
/* 125 */       throw new HttpMessageNotReadableException("Could not set feature: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (SAXException ex) {
/* 128 */       throw new HttpMessageNotReadableException("Could not parse document: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private SAXSource readSAXSource(InputStream body) throws IOException {
/*     */     try {
/* 134 */       XMLReader reader = XMLReaderFactory.createXMLReader();
/* 135 */       reader.setFeature("http://xml.org/sax/features/external-general-entities", this.processExternalEntities);
/* 136 */       byte[] bytes = StreamUtils.copyToByteArray(body);
/* 137 */       return new SAXSource(reader, new InputSource(new ByteArrayInputStream(bytes)));
/*     */     }
/*     */     catch (SAXException ex) {
/* 140 */       throw new HttpMessageNotReadableException("Could not parse document: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Source readStAXSource(InputStream body) {
/*     */     try {
/* 146 */       XMLInputFactory inputFactory = XMLInputFactory.newFactory();
/* 147 */       inputFactory.setProperty("javax.xml.stream.isSupportingExternalEntities", Boolean.valueOf(this.processExternalEntities));
/* 148 */       XMLStreamReader streamReader = inputFactory.createXMLStreamReader(body);
/* 149 */       return new StAXSource(streamReader);
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 152 */       throw new HttpMessageNotReadableException("Could not parse document: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private StreamSource readStreamSource(InputStream body) throws IOException {
/* 157 */     byte[] bytes = StreamUtils.copyToByteArray(body);
/* 158 */     return new StreamSource(new ByteArrayInputStream(bytes));
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(T t, MediaType contentType)
/*     */   {
/* 163 */     if ((t instanceof DOMSource)) {
/*     */       try {
/* 165 */         CountingOutputStream os = new CountingOutputStream(null);
/* 166 */         transform(t, new StreamResult(os));
/* 167 */         return Long.valueOf(os.count);
/*     */       }
/*     */       catch (TransformerException ex)
/*     */       {
/*     */       }
/*     */     }
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */   protected void writeInternal(T t, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException
/*     */   {
/*     */     try
/*     */     {
/* 180 */       Result result = new StreamResult(outputMessage.getBody());
/* 181 */       transform(t, result);
/*     */     }
/*     */     catch (TransformerException ex) {
/* 184 */       throw new HttpMessageNotWritableException("Could not transform [" + t + "] to output message", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void transform(Source source, Result result) throws TransformerException {
/* 189 */     this.transformerFactory.newTransformer().transform(source, result);
/*     */   }
/*     */ 
/*     */   private static class CountingOutputStream extends OutputStream
/*     */   {
/* 195 */     private long count = 0L;
/*     */ 
/*     */     public void write(int b) throws IOException
/*     */     {
/* 199 */       this.count += 1L;
/*     */     }
/*     */ 
/*     */     public void write(byte[] b) throws IOException
/*     */     {
/* 204 */       this.count += b.length;
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 209 */       this.count += len;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.SourceHttpMessageConverter
 * JD-Core Version:    0.6.2
 */