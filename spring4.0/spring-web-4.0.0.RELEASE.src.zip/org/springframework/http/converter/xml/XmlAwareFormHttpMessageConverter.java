/*    */ package org.springframework.http.converter.xml;
/*    */ 
/*    */ import org.springframework.http.converter.FormHttpMessageConverter;
/*    */ 
/*    */ @Deprecated
/*    */ public class XmlAwareFormHttpMessageConverter extends FormHttpMessageConverter
/*    */ {
/*    */   public XmlAwareFormHttpMessageConverter()
/*    */   {
/* 37 */     addPartConverter(new SourceHttpMessageConverter());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.XmlAwareFormHttpMessageConverter
 * JD-Core Version:    0.6.2
 */