package org.springframework.http.server;

public abstract interface ServerHttpAsyncRequestControl
{
  public abstract void start();

  public abstract void start(long paramLong);

  public abstract boolean isStarted();

  public abstract void complete();

  public abstract boolean isCompleted();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServerHttpAsyncRequestControl
 * JD-Core Version:    0.6.2
 */