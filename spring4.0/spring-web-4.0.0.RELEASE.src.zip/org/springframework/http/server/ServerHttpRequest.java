package org.springframework.http.server;

import java.net.InetSocketAddress;
import java.security.Principal;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpRequest;

public abstract interface ServerHttpRequest extends HttpRequest, HttpInputMessage
{
  public abstract Principal getPrincipal();

  public abstract InetSocketAddress getLocalAddress();

  public abstract InetSocketAddress getRemoteAddress();

  public abstract ServerHttpAsyncRequestControl getAsyncRequestControl(ServerHttpResponse paramServerHttpResponse);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServerHttpRequest
 * JD-Core Version:    0.6.2
 */