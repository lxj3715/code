/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ServletServerHttpRequest
/*     */   implements ServerHttpRequest
/*     */ {
/*     */   protected static final String FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
/*     */   protected static final String FORM_CHARSET = "UTF-8";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private final HttpServletRequest servletRequest;
/*     */   private HttpHeaders headers;
/*     */   private ServerHttpAsyncRequestControl asyncRequestControl;
/*     */ 
/*     */   public ServletServerHttpRequest(HttpServletRequest servletRequest)
/*     */   {
/*  71 */     Assert.notNull(servletRequest, "'servletRequest' must not be null");
/*  72 */     this.servletRequest = servletRequest;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getServletRequest()
/*     */   {
/*  80 */     return this.servletRequest;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  85 */     return HttpMethod.valueOf(this.servletRequest.getMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*     */     try
/*     */     {
/*  93 */       return new URI(this.servletRequest.getScheme(), null, this.servletRequest.getServerName(), this.servletRequest
/*  92 */         .getServerPort(), this.servletRequest.getRequestURI(), this.servletRequest
/*  93 */         .getQueryString(), null);
/*     */     }
/*     */     catch (URISyntaxException ex) {
/*  96 */       throw new IllegalStateException("Could not get HttpServletRequest URI: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders getHeaders()
/*     */   {
/* 102 */     if (this.headers == null) {
/* 103 */       this.headers = new HttpHeaders();
/* 104 */       for (Enumeration headerNames = this.servletRequest.getHeaderNames(); headerNames.hasMoreElements(); ) {
/* 105 */         String headerName = (String)headerNames.nextElement();
/* 106 */         Enumeration headerValues = this.servletRequest.getHeaders(headerName);
/* 107 */         while (headerValues.hasMoreElements()) {
/* 108 */           String headerValue = (String)headerValues.nextElement();
/* 109 */           this.headers.add(headerName, headerValue);
/*     */         }
/*     */       }
/*     */ 
/* 113 */       if ((this.headers.getContentType() == null) && (this.servletRequest.getContentType() != null)) {
/* 114 */         MediaType contentType = MediaType.parseMediaType(this.servletRequest.getContentType());
/* 115 */         this.headers.setContentType(contentType);
/*     */       }
/* 117 */       if ((this.headers.getContentType() != null) && (this.headers.getContentType().getCharSet() == null) && 
/* 118 */         (this.servletRequest
/* 118 */         .getCharacterEncoding() != null)) {
/* 119 */         MediaType oldContentType = this.headers.getContentType();
/* 120 */         Charset charSet = Charset.forName(this.servletRequest.getCharacterEncoding());
/* 121 */         Map params = new HashMap(oldContentType.getParameters());
/* 122 */         params.put("charset", charSet.toString());
/* 123 */         MediaType newContentType = new MediaType(oldContentType.getType(), oldContentType.getSubtype(), params);
/* 124 */         this.headers.setContentType(newContentType);
/*     */       }
/* 126 */       if ((this.headers.getContentLength() == -1L) && (this.servletRequest.getContentLength() != -1)) {
/* 127 */         this.headers.setContentLength(this.servletRequest.getContentLength());
/*     */       }
/*     */     }
/* 130 */     return this.headers;
/*     */   }
/*     */ 
/*     */   public Principal getPrincipal()
/*     */   {
/* 135 */     return this.servletRequest.getUserPrincipal();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress()
/*     */   {
/* 140 */     return new InetSocketAddress(this.servletRequest.getLocalName(), this.servletRequest.getLocalPort());
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getRemoteAddress()
/*     */   {
/* 145 */     return new InetSocketAddress(this.servletRequest.getRemoteHost(), this.servletRequest.getRemotePort());
/*     */   }
/*     */ 
/*     */   public InputStream getBody() throws IOException
/*     */   {
/* 150 */     if (isFormPost(this.servletRequest)) {
/* 151 */       return getBodyFromServletRequestParameters(this.servletRequest);
/*     */     }
/*     */ 
/* 154 */     return this.servletRequest.getInputStream();
/*     */   }
/*     */ 
/*     */   private boolean isFormPost(HttpServletRequest request)
/*     */   {
/* 160 */     return (request.getContentType() != null) && (request.getContentType().contains("application/x-www-form-urlencoded")) && 
/* 160 */       ("POST"
/* 160 */       .equalsIgnoreCase(request
/* 160 */       .getMethod()));
/*     */   }
/*     */ 
/*     */   private InputStream getBodyFromServletRequestParameters(HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/* 170 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 171 */     Writer writer = new OutputStreamWriter(bos, "UTF-8");
/*     */ 
/* 173 */     Map form = request.getParameterMap();
/* 174 */     for (Iterator nameIterator = form.keySet().iterator(); nameIterator.hasNext(); ) {
/* 175 */       String name = (String)nameIterator.next();
/* 176 */       List values = Arrays.asList((Object[])form.get(name));
/* 177 */       for (Iterator valueIterator = values.iterator(); valueIterator.hasNext(); ) {
/* 178 */         String value = (String)valueIterator.next();
/* 179 */         writer.write(URLEncoder.encode(name, "UTF-8"));
/* 180 */         if (value != null) {
/* 181 */           writer.write(61);
/* 182 */           writer.write(URLEncoder.encode(value, "UTF-8"));
/* 183 */           if (valueIterator.hasNext()) {
/* 184 */             writer.write(38);
/*     */           }
/*     */         }
/*     */       }
/* 188 */       if (nameIterator.hasNext()) {
/* 189 */         writer.append('&');
/*     */       }
/*     */     }
/* 192 */     writer.flush();
/*     */ 
/* 194 */     return new ByteArrayInputStream(bos.toByteArray());
/*     */   }
/*     */ 
/*     */   public ServerHttpAsyncRequestControl getAsyncRequestControl(ServerHttpResponse response)
/*     */   {
/* 199 */     if (this.asyncRequestControl == null) {
/* 200 */       Assert.isInstanceOf(ServletServerHttpResponse.class, response);
/* 201 */       ServletServerHttpResponse servletServerResponse = (ServletServerHttpResponse)response;
/* 202 */       this.asyncRequestControl = new ServletServerHttpAsyncRequestControl(this, servletServerResponse);
/*     */     }
/* 204 */     return this.asyncRequestControl;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServletServerHttpRequest
 * JD-Core Version:    0.6.2
 */