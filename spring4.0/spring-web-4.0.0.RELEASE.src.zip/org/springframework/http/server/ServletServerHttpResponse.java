/*    */ package org.springframework.http.server;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ServletServerHttpResponse
/*    */   implements ServerHttpResponse
/*    */ {
/*    */   private final HttpServletResponse servletResponse;
/* 40 */   private final HttpHeaders headers = new HttpHeaders();
/*    */ 
/* 42 */   private boolean headersWritten = false;
/*    */ 
/*    */   public ServletServerHttpResponse(HttpServletResponse servletResponse)
/*    */   {
/* 50 */     Assert.notNull(servletResponse, "'servletResponse' must not be null");
/* 51 */     this.servletResponse = servletResponse;
/*    */   }
/*    */ 
/*    */   public HttpServletResponse getServletResponse()
/*    */   {
/* 59 */     return this.servletResponse;
/*    */   }
/*    */ 
/*    */   public void setStatusCode(HttpStatus status)
/*    */   {
/* 64 */     this.servletResponse.setStatus(status.value());
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 69 */     return this.headersWritten ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*    */   }
/*    */ 
/*    */   public OutputStream getBody() throws IOException
/*    */   {
/* 74 */     writeHeaders();
/* 75 */     return this.servletResponse.getOutputStream();
/*    */   }
/*    */ 
/*    */   public void flush() throws IOException
/*    */   {
/* 80 */     writeHeaders();
/* 81 */     this.servletResponse.flushBuffer();
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/* 86 */     writeHeaders();
/*    */   }
/*    */ 
/*    */   private void writeHeaders() {
/* 90 */     if (!this.headersWritten) {
/* 91 */       for (Map.Entry entry : this.headers.entrySet()) {
/* 92 */         headerName = (String)entry.getKey();
/* 93 */         for (String headerValue : (List)entry.getValue())
/* 94 */           this.servletResponse.addHeader(headerName, headerValue);
/*    */       }
/*    */       String headerName;
/* 98 */       if ((this.servletResponse.getContentType() == null) && (this.headers.getContentType() != null)) {
/* 99 */         this.servletResponse.setContentType(this.headers.getContentType().toString());
/*    */       }
/* 101 */       if ((this.servletResponse.getCharacterEncoding() == null) && (this.headers.getContentType() != null) && 
/* 102 */         (this.headers
/* 102 */         .getContentType().getCharSet() != null)) {
/* 103 */         this.servletResponse.setCharacterEncoding(this.headers.getContentType().getCharSet().name());
/*    */       }
/* 105 */       this.headersWritten = true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServletServerHttpResponse
 * JD-Core Version:    0.6.2
 */