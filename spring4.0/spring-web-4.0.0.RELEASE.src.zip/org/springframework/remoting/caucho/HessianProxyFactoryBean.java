/*    */ package org.springframework.remoting.caucho;
/*    */ 
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ 
/*    */ public class HessianProxyFactoryBean extends HessianClientInterceptor
/*    */   implements FactoryBean<Object>
/*    */ {
/*    */   private Object serviceProxy;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 50 */     super.afterPropertiesSet();
/* 51 */     this.serviceProxy = new ProxyFactory(getServiceInterface(), this).getProxy(getBeanClassLoader());
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 57 */     return this.serviceProxy;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType()
/*    */   {
/* 62 */     return getServiceInterface();
/*    */   }
/*    */ 
/*    */   public boolean isSingleton()
/*    */   {
/* 67 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.HessianProxyFactoryBean
 * JD-Core Version:    0.6.2
 */