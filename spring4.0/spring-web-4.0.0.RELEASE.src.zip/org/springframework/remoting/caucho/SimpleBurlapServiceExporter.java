/*    */ package org.springframework.remoting.caucho;
/*    */ 
/*    */ import com.sun.net.httpserver.Headers;
/*    */ import com.sun.net.httpserver.HttpExchange;
/*    */ import com.sun.net.httpserver.HttpHandler;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ @Deprecated
/*    */ public class SimpleBurlapServiceExporter extends BurlapExporter
/*    */   implements HttpHandler
/*    */ {
/*    */   public void handle(HttpExchange exchange)
/*    */     throws IOException
/*    */   {
/* 58 */     if (!"POST".equals(exchange.getRequestMethod())) {
/* 59 */       exchange.getResponseHeaders().set("Allow", "POST");
/* 60 */       exchange.sendResponseHeaders(405, -1L);
/* 61 */       return;
/*    */     }
/*    */ 
/* 64 */     ByteArrayOutputStream output = new ByteArrayOutputStream(1024);
/*    */     try {
/* 66 */       invoke(exchange.getRequestBody(), output);
/*    */     }
/*    */     catch (Throwable ex) {
/* 69 */       exchange.sendResponseHeaders(500, -1L);
/* 70 */       this.logger.error("Burlap skeleton invocation failed", ex);
/*    */     }
/*    */ 
/* 73 */     exchange.sendResponseHeaders(200, output.size());
/* 74 */     FileCopyUtils.copy(output.toByteArray(), exchange.getResponseBody());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.SimpleBurlapServiceExporter
 * JD-Core Version:    0.6.2
 */