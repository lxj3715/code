/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Locale;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.NoHttpResponseException;
/*     */ import org.apache.http.StatusLine;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.conn.scheme.PlainSocketFactory;
/*     */ import org.apache.http.conn.scheme.Scheme;
/*     */ import org.apache.http.conn.scheme.SchemeRegistry;
/*     */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*     */ import org.apache.http.entity.ByteArrayEntity;
/*     */ import org.apache.http.impl.client.DefaultHttpClient;
/*     */ import org.apache.http.impl.conn.PoolingClientConnectionManager;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class HttpComponentsHttpInvokerRequestExecutor extends AbstractHttpInvokerRequestExecutor
/*     */ {
/*     */   private static final int DEFAULT_MAX_TOTAL_CONNECTIONS = 100;
/*     */   private static final int DEFAULT_MAX_CONNECTIONS_PER_ROUTE = 5;
/*     */   private static final int DEFAULT_READ_TIMEOUT_MILLISECONDS = 60000;
/*     */   private HttpClient httpClient;
/*     */ 
/*     */   public HttpComponentsHttpInvokerRequestExecutor()
/*     */   {
/*  70 */     SchemeRegistry schemeRegistry = new SchemeRegistry();
/*  71 */     schemeRegistry.register(new Scheme("http", 80, PlainSocketFactory.getSocketFactory()));
/*  72 */     schemeRegistry.register(new Scheme("https", 443, SSLSocketFactory.getSocketFactory()));
/*     */ 
/*  74 */     PoolingClientConnectionManager connectionManager = new PoolingClientConnectionManager(schemeRegistry);
/*     */ 
/*  76 */     connectionManager.setMaxTotal(100);
/*  77 */     connectionManager.setDefaultMaxPerRoute(5);
/*     */ 
/*  79 */     this.httpClient = new DefaultHttpClient(connectionManager);
/*  80 */     setReadTimeout(60000);
/*     */   }
/*     */ 
/*     */   public HttpComponentsHttpInvokerRequestExecutor(HttpClient httpClient)
/*     */   {
/*  89 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public void setHttpClient(HttpClient httpClient)
/*     */   {
/*  97 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public HttpClient getHttpClient()
/*     */   {
/* 104 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int timeout)
/*     */   {
/* 113 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 114 */     getHttpClient().getParams().setIntParameter("http.connection.timeout", timeout);
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int timeout)
/*     */   {
/* 124 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 125 */     getHttpClient().getParams().setIntParameter("http.socket.timeout", timeout);
/*     */   }
/*     */ 
/*     */   protected RemoteInvocationResult doExecuteRequest(HttpInvokerClientConfiguration config, ByteArrayOutputStream baos)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 144 */     HttpPost postMethod = createHttpPost(config);
/* 145 */     setRequestBody(config, postMethod, baos);
/*     */     try {
/* 147 */       HttpResponse response = executeHttpPost(config, getHttpClient(), postMethod);
/* 148 */       validateResponse(config, response);
/* 149 */       InputStream responseBody = getResponseBody(config, response);
/* 150 */       return readRemoteInvocationResult(responseBody, config.getCodebaseUrl());
/*     */     }
/*     */     finally {
/* 153 */       postMethod.releaseConnection();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected HttpPost createHttpPost(HttpInvokerClientConfiguration config)
/*     */     throws IOException
/*     */   {
/* 167 */     HttpPost httpPost = new HttpPost(config.getServiceUrl());
/* 168 */     LocaleContext localeContext = LocaleContextHolder.getLocaleContext();
/* 169 */     if (localeContext != null) {
/* 170 */       Locale locale = localeContext.getLocale();
/* 171 */       if (locale != null) {
/* 172 */         httpPost.addHeader("Accept-Language", StringUtils.toLanguageTag(locale));
/*     */       }
/*     */     }
/* 175 */     if (isAcceptGzipEncoding()) {
/* 176 */       httpPost.addHeader("Accept-Encoding", "gzip");
/*     */     }
/* 178 */     return httpPost;
/*     */   }
/*     */ 
/*     */   protected void setRequestBody(HttpInvokerClientConfiguration config, HttpPost httpPost, ByteArrayOutputStream baos)
/*     */     throws IOException
/*     */   {
/* 196 */     ByteArrayEntity entity = new ByteArrayEntity(baos.toByteArray());
/* 197 */     entity.setContentType(getContentType());
/* 198 */     httpPost.setEntity(entity);
/*     */   }
/*     */ 
/*     */   protected HttpResponse executeHttpPost(HttpInvokerClientConfiguration config, HttpClient httpClient, HttpPost httpPost)
/*     */     throws IOException
/*     */   {
/* 213 */     return httpClient.execute(httpPost);
/*     */   }
/*     */ 
/*     */   protected void validateResponse(HttpInvokerClientConfiguration config, HttpResponse response)
/*     */     throws IOException
/*     */   {
/* 228 */     StatusLine status = response.getStatusLine();
/* 229 */     if (status.getStatusCode() >= 300)
/*     */     {
/* 232 */       throw new NoHttpResponseException("Did not receive successful HTTP response: status code = " + status
/* 231 */         .getStatusCode() + ", status message = [" + status
/* 232 */         .getReasonPhrase() + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected InputStream getResponseBody(HttpInvokerClientConfiguration config, HttpResponse httpResponse)
/*     */     throws IOException
/*     */   {
/* 251 */     if (isGzipResponse(httpResponse)) {
/* 252 */       return new GZIPInputStream(httpResponse.getEntity().getContent());
/*     */     }
/*     */ 
/* 255 */     return httpResponse.getEntity().getContent();
/*     */   }
/*     */ 
/*     */   protected boolean isGzipResponse(HttpResponse httpResponse)
/*     */   {
/* 267 */     Header encodingHeader = httpResponse.getFirstHeader("Content-Encoding");
/*     */ 
/* 269 */     return (encodingHeader != null) && (encodingHeader.getValue() != null) && 
/* 269 */       (encodingHeader
/* 269 */       .getValue().toLowerCase().contains("gzip"));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpComponentsHttpInvokerRequestExecutor
 * JD-Core Version:    0.6.2
 */