package org.springframework.remoting.httpinvoker;

public abstract interface HttpInvokerClientConfiguration
{
  public abstract String getServiceUrl();

  public abstract String getCodebaseUrl();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpInvokerClientConfiguration
 * JD-Core Version:    0.6.2
 */