/*    */ package org.springframework.remoting.httpinvoker;
/*    */ 
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ 
/*    */ public class HttpInvokerProxyFactoryBean extends HttpInvokerClientInterceptor
/*    */   implements FactoryBean<Object>
/*    */ {
/*    */   private Object serviceProxy;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 58 */     super.afterPropertiesSet();
/* 59 */     if (getServiceInterface() == null) {
/* 60 */       throw new IllegalArgumentException("Property 'serviceInterface' is required");
/*    */     }
/* 62 */     this.serviceProxy = new ProxyFactory(getServiceInterface(), this).getProxy(getBeanClassLoader());
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 68 */     return this.serviceProxy;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType()
/*    */   {
/* 73 */     return getServiceInterface();
/*    */   }
/*    */ 
/*    */   public boolean isSingleton()
/*    */   {
/* 78 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean
 * JD-Core Version:    0.6.2
 */