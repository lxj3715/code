/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.remoting.rmi.RemoteInvocationSerializingExporter;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ public class HttpInvokerServiceExporter extends RemoteInvocationSerializingExporter
/*     */   implements HttpRequestHandler
/*     */ {
/*     */   public void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*     */     try
/*     */     {
/*  73 */       RemoteInvocation invocation = readRemoteInvocation(request);
/*  74 */       RemoteInvocationResult result = invokeAndCreateResult(invocation, getProxy());
/*  75 */       writeRemoteInvocationResult(request, response, result);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  78 */       throw new NestedServletException("Class not found during deserialization", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpServletRequest request)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  96 */     return readRemoteInvocation(request, request.getInputStream());
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpServletRequest request, InputStream is)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 115 */     ObjectInputStream ois = createObjectInputStream(decorateInputStream(request, is));
/*     */     try {
/* 117 */       return doReadRemoteInvocation(ois);
/*     */     }
/*     */     finally {
/* 120 */       ois.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected InputStream decorateInputStream(HttpServletRequest request, InputStream is)
/*     */     throws IOException
/*     */   {
/* 135 */     return is;
/*     */   }
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpServletRequest request, HttpServletResponse response, RemoteInvocationResult result)
/*     */     throws IOException
/*     */   {
/* 149 */     response.setContentType(getContentType());
/* 150 */     writeRemoteInvocationResult(request, response, result, response.getOutputStream());
/*     */   }
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpServletRequest request, HttpServletResponse response, RemoteInvocationResult result, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 172 */     ObjectOutputStream oos = createObjectOutputStream(decorateOutputStream(request, response, os));
/*     */     try {
/* 174 */       doWriteRemoteInvocationResult(result, oos);
/*     */     }
/*     */     finally {
/* 177 */       oos.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected OutputStream decorateOutputStream(HttpServletRequest request, HttpServletResponse response, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 195 */     return os;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter
 * JD-Core Version:    0.6.2
 */