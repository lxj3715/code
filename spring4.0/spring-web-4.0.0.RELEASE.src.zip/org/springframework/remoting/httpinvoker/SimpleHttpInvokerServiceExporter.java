/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import com.sun.net.httpserver.Headers;
/*     */ import com.sun.net.httpserver.HttpExchange;
/*     */ import com.sun.net.httpserver.HttpHandler;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.remoting.rmi.RemoteInvocationSerializingExporter;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ 
/*     */ public class SimpleHttpInvokerServiceExporter extends RemoteInvocationSerializingExporter
/*     */   implements HttpHandler
/*     */ {
/*     */   public void handle(HttpExchange exchange)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  67 */       RemoteInvocation invocation = readRemoteInvocation(exchange);
/*  68 */       RemoteInvocationResult result = invokeAndCreateResult(invocation, getProxy());
/*  69 */       writeRemoteInvocationResult(exchange, result);
/*  70 */       exchange.close();
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  73 */       exchange.sendResponseHeaders(500, -1L);
/*  74 */       this.logger.error("Class not found during deserialization", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpExchange exchange)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  92 */     return readRemoteInvocation(exchange, exchange.getRequestBody());
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpExchange exchange, InputStream is)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 111 */     ObjectInputStream ois = createObjectInputStream(decorateInputStream(exchange, is));
/* 112 */     return doReadRemoteInvocation(ois);
/*     */   }
/*     */ 
/*     */   protected InputStream decorateInputStream(HttpExchange exchange, InputStream is)
/*     */     throws IOException
/*     */   {
/* 126 */     return is;
/*     */   }
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpExchange exchange, RemoteInvocationResult result)
/*     */     throws IOException
/*     */   {
/* 138 */     exchange.getResponseHeaders().set("Content-Type", getContentType());
/* 139 */     exchange.sendResponseHeaders(200, 0L);
/* 140 */     writeRemoteInvocationResult(exchange, result, exchange.getResponseBody());
/*     */   }
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpExchange exchange, RemoteInvocationResult result, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 160 */     ObjectOutputStream oos = createObjectOutputStream(decorateOutputStream(exchange, os));
/* 161 */     doWriteRemoteInvocationResult(result, oos);
/* 162 */     oos.flush();
/*     */   }
/*     */ 
/*     */   protected OutputStream decorateOutputStream(HttpExchange exchange, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 176 */     return os;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.SimpleHttpInvokerServiceExporter
 * JD-Core Version:    0.6.2
 */