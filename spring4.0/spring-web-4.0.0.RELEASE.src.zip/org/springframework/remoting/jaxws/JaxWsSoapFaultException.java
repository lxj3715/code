/*    */ package org.springframework.remoting.jaxws;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.soap.SOAPFault;
/*    */ import javax.xml.ws.soap.SOAPFaultException;
/*    */ import org.springframework.remoting.soap.SoapFaultException;
/*    */ 
/*    */ public class JaxWsSoapFaultException extends SoapFaultException
/*    */ {
/*    */   public JaxWsSoapFaultException(SOAPFaultException original)
/*    */   {
/* 40 */     super(original.getMessage(), original);
/*    */   }
/*    */ 
/*    */   public final SOAPFault getFault()
/*    */   {
/* 47 */     return ((SOAPFaultException)getCause()).getFault();
/*    */   }
/*    */ 
/*    */   public String getFaultCode()
/*    */   {
/* 53 */     return getFault().getFaultCode();
/*    */   }
/*    */ 
/*    */   public QName getFaultCodeAsQName()
/*    */   {
/* 58 */     return getFault().getFaultCodeAsQName();
/*    */   }
/*    */ 
/*    */   public String getFaultString()
/*    */   {
/* 63 */     return getFault().getFaultString();
/*    */   }
/*    */ 
/*    */   public String getFaultActor()
/*    */   {
/* 68 */     return getFault().getFaultActor();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.JaxWsSoapFaultException
 * JD-Core Version:    0.6.2
 */