/*     */ package org.springframework.remoting.jaxws;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.concurrent.Executor;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ import javax.xml.ws.handler.HandlerResolver;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class LocalJaxWsServiceFactory
/*     */ {
/*     */   private URL wsdlDocumentUrl;
/*     */   private String namespaceUri;
/*     */   private String serviceName;
/*     */   private WebServiceFeature[] serviceFeatures;
/*     */   private Executor executor;
/*     */   private HandlerResolver handlerResolver;
/*     */ 
/*     */   public void setWsdlDocumentUrl(URL wsdlDocumentUrl)
/*     */   {
/*  64 */     this.wsdlDocumentUrl = wsdlDocumentUrl;
/*     */   }
/*     */ 
/*     */   public void setWsdlDocumentResource(Resource wsdlDocumentResource)
/*     */     throws IOException
/*     */   {
/*  73 */     Assert.notNull(wsdlDocumentResource, "WSDL Resource must not be null.");
/*  74 */     this.wsdlDocumentUrl = wsdlDocumentResource.getURL();
/*     */   }
/*     */ 
/*     */   public URL getWsdlDocumentUrl()
/*     */   {
/*  81 */     return this.wsdlDocumentUrl;
/*     */   }
/*     */ 
/*     */   public void setNamespaceUri(String namespaceUri)
/*     */   {
/*  89 */     this.namespaceUri = (namespaceUri != null ? namespaceUri.trim() : null);
/*     */   }
/*     */ 
/*     */   public String getNamespaceUri()
/*     */   {
/*  96 */     return this.namespaceUri;
/*     */   }
/*     */ 
/*     */   public void setServiceName(String serviceName)
/*     */   {
/* 104 */     this.serviceName = serviceName;
/*     */   }
/*     */ 
/*     */   public String getServiceName()
/*     */   {
/* 111 */     return this.serviceName;
/*     */   }
/*     */ 
/*     */   public void setServiceFeatures(WebServiceFeature[] serviceFeatures)
/*     */   {
/* 122 */     this.serviceFeatures = serviceFeatures;
/*     */   }
/*     */ 
/*     */   public void setExecutor(Executor executor)
/*     */   {
/* 131 */     this.executor = executor;
/*     */   }
/*     */ 
/*     */   public void setHandlerResolver(HandlerResolver handlerResolver)
/*     */   {
/* 140 */     this.handlerResolver = handlerResolver;
/*     */   }
/*     */ 
/*     */   public Service createJaxWsService()
/*     */   {
/* 150 */     Assert.notNull(this.serviceName, "No service name specified");
/*     */     Service service;
/*     */     Service service;
/* 153 */     if (this.serviceFeatures != null)
/*     */     {
/* 156 */       service = this.wsdlDocumentUrl != null ? 
/* 155 */         Service.create(this.wsdlDocumentUrl, 
/* 155 */         getQName(this.serviceName), 
/* 155 */         this.serviceFeatures) : 
/* 156 */         Service.create(getQName(this.serviceName), 
/* 156 */         this.serviceFeatures);
/*     */     }
/*     */     else
/*     */     {
/* 161 */       service = this.wsdlDocumentUrl != null ? 
/* 160 */         Service.create(this.wsdlDocumentUrl, 
/* 160 */         getQName(this.serviceName)) : 
/* 161 */         Service.create(getQName(this.serviceName));
/*     */     }
/*     */ 
/* 164 */     if (this.executor != null) {
/* 165 */       service.setExecutor(this.executor);
/*     */     }
/* 167 */     if (this.handlerResolver != null) {
/* 168 */       service.setHandlerResolver(this.handlerResolver);
/*     */     }
/*     */ 
/* 171 */     return service;
/*     */   }
/*     */ 
/*     */   protected QName getQName(String name)
/*     */   {
/* 180 */     return getNamespaceUri() != null ? new QName(getNamespaceUri(), name) : new QName(name);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.LocalJaxWsServiceFactory
 * JD-Core Version:    0.6.2
 */