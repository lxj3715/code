/*    */ package org.springframework.web;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ public class HttpMediaTypeNotAcceptableException extends HttpMediaTypeException
/*    */ {
/*    */   public HttpMediaTypeNotAcceptableException(String message)
/*    */   {
/* 37 */     super(message);
/*    */   }
/*    */ 
/*    */   public HttpMediaTypeNotAcceptableException(List<MediaType> supportedMediaTypes)
/*    */   {
/* 45 */     super("Could not find acceptable representation", supportedMediaTypes);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.HttpMediaTypeNotAcceptableException
 * JD-Core Version:    0.6.2
 */