/*     */ package org.springframework.web;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.annotation.HandlesTypes;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ 
/*     */ @HandlesTypes({WebApplicationInitializer.class})
/*     */ public class SpringServletContainerInitializer
/*     */   implements ServletContainerInitializer
/*     */ {
/*     */   public void onStartup(Set<Class<?>> webAppInitializerClasses, ServletContext servletContext)
/*     */     throws ServletException
/*     */   {
/* 154 */     List initializers = new LinkedList();
/*     */ 
/* 156 */     if (webAppInitializerClasses != null) {
/* 157 */       for (Class waiClass : webAppInitializerClasses)
/*     */       {
/* 160 */         if ((!waiClass.isInterface()) && (!Modifier.isAbstract(waiClass.getModifiers())) && 
/* 161 */           (WebApplicationInitializer.class
/* 161 */           .isAssignableFrom(waiClass))) {
/*     */           try
/*     */           {
/* 163 */             initializers.add((WebApplicationInitializer)waiClass.newInstance());
/*     */           }
/*     */           catch (Throwable ex) {
/* 166 */             throw new ServletException("Failed to instantiate WebApplicationInitializer class", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 172 */     if (initializers.isEmpty()) {
/* 173 */       servletContext.log("No Spring WebApplicationInitializer types detected on classpath");
/* 174 */       return;
/*     */     }
/*     */ 
/* 177 */     Collections.sort(initializers, new AnnotationAwareOrderComparator());
/* 178 */     servletContext.log("Spring WebApplicationInitializers detected on classpath: " + initializers);
/*     */ 
/* 180 */     for (WebApplicationInitializer initializer : initializers)
/* 181 */       initializer.onStartup(servletContext);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.SpringServletContainerInitializer
 * JD-Core Version:    0.6.2
 */