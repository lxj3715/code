package org.springframework.web;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

public abstract interface WebApplicationInitializer
{
  public abstract void onStartup(ServletContext paramServletContext)
    throws ServletException;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.WebApplicationInitializer
 * JD-Core Version:    0.6.2
 */