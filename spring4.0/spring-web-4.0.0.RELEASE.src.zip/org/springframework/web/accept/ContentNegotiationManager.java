/*     */ package org.springframework.web.accept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class ContentNegotiationManager
/*     */   implements ContentNegotiationStrategy, MediaTypeFileExtensionResolver
/*     */ {
/*  53 */   private static final List<MediaType> MEDIA_TYPE_ALL = Arrays.asList(new MediaType[] { MediaType.ALL });
/*     */ 
/*  55 */   private final List<ContentNegotiationStrategy> contentNegotiationStrategies = new ArrayList();
/*     */ 
/*  58 */   private final Set<MediaTypeFileExtensionResolver> fileExtensionResolvers = new LinkedHashSet();
/*     */ 
/*     */   public ContentNegotiationManager(ContentNegotiationStrategy[] strategies)
/*     */   {
/*  69 */     Assert.notEmpty(strategies, "At least one ContentNegotiationStrategy is expected");
/*  70 */     this.contentNegotiationStrategies.addAll(Arrays.asList(strategies));
/*  71 */     for (ContentNegotiationStrategy strategy : this.contentNegotiationStrategies)
/*  72 */       if ((strategy instanceof MediaTypeFileExtensionResolver))
/*  73 */         this.fileExtensionResolvers.add((MediaTypeFileExtensionResolver)strategy);
/*     */   }
/*     */ 
/*     */   public ContentNegotiationManager(Collection<ContentNegotiationStrategy> strategies)
/*     */   {
/*  85 */     Assert.notEmpty(strategies, "At least one ContentNegotiationStrategy is expected");
/*  86 */     this.contentNegotiationStrategies.addAll(strategies);
/*  87 */     for (ContentNegotiationStrategy strategy : this.contentNegotiationStrategies)
/*  88 */       if ((strategy instanceof MediaTypeFileExtensionResolver))
/*  89 */         this.fileExtensionResolvers.add((MediaTypeFileExtensionResolver)strategy);
/*     */   }
/*     */ 
/*     */   public ContentNegotiationManager()
/*     */   {
/*  98 */     this(new MediaTypeFileExtensionResolver[] { new HeaderContentNegotiationStrategy() });
/*     */   }
/*     */ 
/*     */   public void addFileExtensionResolvers(MediaTypeFileExtensionResolver[] resolvers)
/*     */   {
/* 111 */     this.fileExtensionResolvers.addAll(Arrays.asList(resolvers));
/*     */   }
/*     */ 
/*     */   public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest)
/*     */     throws HttpMediaTypeNotAcceptableException
/*     */   {
/* 123 */     for (ContentNegotiationStrategy strategy : this.contentNegotiationStrategies) {
/* 124 */       List mediaTypes = strategy.resolveMediaTypes(webRequest);
/* 125 */       if ((!mediaTypes.isEmpty()) && (!mediaTypes.equals(MEDIA_TYPE_ALL)))
/*     */       {
/* 128 */         return mediaTypes;
/*     */       }
/*     */     }
/* 130 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   public List<String> resolveFileExtensions(MediaType mediaType)
/*     */   {
/* 139 */     Set result = new LinkedHashSet();
/* 140 */     for (MediaTypeFileExtensionResolver resolver : this.fileExtensionResolvers) {
/* 141 */       result.addAll(resolver.resolveFileExtensions(mediaType));
/*     */     }
/* 143 */     return new ArrayList(result);
/*     */   }
/*     */ 
/*     */   public List<String> getAllFileExtensions()
/*     */   {
/* 152 */     Set result = new LinkedHashSet();
/* 153 */     for (MediaTypeFileExtensionResolver resolver : this.fileExtensionResolvers) {
/* 154 */       result.addAll(resolver.getAllFileExtensions());
/*     */     }
/* 156 */     return new ArrayList(result);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ContentNegotiationManager
 * JD-Core Version:    0.6.2
 */