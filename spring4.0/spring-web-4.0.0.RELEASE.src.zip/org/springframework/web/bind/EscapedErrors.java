/*     */ package org.springframework.web.bind;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.FieldError;
/*     */ import org.springframework.validation.ObjectError;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ 
/*     */ public class EscapedErrors
/*     */   implements Errors
/*     */ {
/*     */   private final Errors source;
/*     */ 
/*     */   public EscapedErrors(Errors source)
/*     */   {
/*  50 */     if (source == null) {
/*  51 */       throw new IllegalArgumentException("Cannot wrap a null instance");
/*     */     }
/*  53 */     this.source = source;
/*     */   }
/*     */ 
/*     */   public Errors getSource() {
/*  57 */     return this.source;
/*     */   }
/*     */ 
/*     */   public String getObjectName()
/*     */   {
/*  63 */     return this.source.getObjectName();
/*     */   }
/*     */ 
/*     */   public void setNestedPath(String nestedPath)
/*     */   {
/*  68 */     this.source.setNestedPath(nestedPath);
/*     */   }
/*     */ 
/*     */   public String getNestedPath()
/*     */   {
/*  73 */     return this.source.getNestedPath();
/*     */   }
/*     */ 
/*     */   public void pushNestedPath(String subPath)
/*     */   {
/*  78 */     this.source.pushNestedPath(subPath);
/*     */   }
/*     */ 
/*     */   public void popNestedPath() throws IllegalStateException
/*     */   {
/*  83 */     this.source.popNestedPath();
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode)
/*     */   {
/*  89 */     this.source.reject(errorCode);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, String defaultMessage)
/*     */   {
/*  94 */     this.source.reject(errorCode, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, Object[] errorArgs, String defaultMessage)
/*     */   {
/*  99 */     this.source.reject(errorCode, errorArgs, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode)
/*     */   {
/* 104 */     this.source.rejectValue(field, errorCode);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, String defaultMessage)
/*     */   {
/* 109 */     this.source.rejectValue(field, errorCode, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, Object[] errorArgs, String defaultMessage)
/*     */   {
/* 114 */     this.source.rejectValue(field, errorCode, errorArgs, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void addAllErrors(Errors errors)
/*     */   {
/* 119 */     this.source.addAllErrors(errors);
/*     */   }
/*     */ 
/*     */   public boolean hasErrors()
/*     */   {
/* 125 */     return this.source.hasErrors();
/*     */   }
/*     */ 
/*     */   public int getErrorCount()
/*     */   {
/* 130 */     return this.source.getErrorCount();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getAllErrors()
/*     */   {
/* 135 */     return escapeObjectErrors(this.source.getAllErrors());
/*     */   }
/*     */ 
/*     */   public boolean hasGlobalErrors()
/*     */   {
/* 140 */     return this.source.hasGlobalErrors();
/*     */   }
/*     */ 
/*     */   public int getGlobalErrorCount()
/*     */   {
/* 145 */     return this.source.getGlobalErrorCount();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getGlobalErrors()
/*     */   {
/* 150 */     return escapeObjectErrors(this.source.getGlobalErrors());
/*     */   }
/*     */ 
/*     */   public ObjectError getGlobalError()
/*     */   {
/* 155 */     return escapeObjectError(this.source.getGlobalError());
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors()
/*     */   {
/* 160 */     return this.source.hasFieldErrors();
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount()
/*     */   {
/* 165 */     return this.source.getFieldErrorCount();
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors()
/*     */   {
/* 170 */     return this.source.getFieldErrors();
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError()
/*     */   {
/* 175 */     return this.source.getFieldError();
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors(String field)
/*     */   {
/* 180 */     return this.source.hasFieldErrors(field);
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount(String field)
/*     */   {
/* 185 */     return this.source.getFieldErrorCount(field);
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors(String field)
/*     */   {
/* 190 */     return escapeObjectErrors(this.source.getFieldErrors(field));
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError(String field)
/*     */   {
/* 195 */     return (FieldError)escapeObjectError(this.source.getFieldError(field));
/*     */   }
/*     */ 
/*     */   public Object getFieldValue(String field)
/*     */   {
/* 200 */     Object value = this.source.getFieldValue(field);
/* 201 */     return (value instanceof String) ? HtmlUtils.htmlEscape((String)value) : value;
/*     */   }
/*     */ 
/*     */   public Class<?> getFieldType(String field)
/*     */   {
/* 206 */     return this.source.getFieldType(field);
/*     */   }
/*     */ 
/*     */   private <T extends ObjectError> T escapeObjectError(T source)
/*     */   {
/* 211 */     if (source == null) {
/* 212 */       return null;
/*     */     }
/* 214 */     if ((source instanceof FieldError)) {
/* 215 */       FieldError fieldError = (FieldError)source;
/* 216 */       Object value = fieldError.getRejectedValue();
/* 217 */       if ((value instanceof String)) {
/* 218 */         value = HtmlUtils.htmlEscape((String)value);
/*     */       }
/*     */ 
/* 223 */       return new FieldError(fieldError
/* 221 */         .getObjectName(), fieldError.getField(), value, fieldError
/* 222 */         .isBindingFailure(), fieldError.getCodes(), fieldError
/* 223 */         .getArguments(), HtmlUtils.htmlEscape(fieldError.getDefaultMessage()));
/*     */     }
/*     */ 
/* 228 */     return new ObjectError(source
/* 227 */       .getObjectName(), source.getCodes(), source.getArguments(), 
/* 228 */       HtmlUtils.htmlEscape(source
/* 228 */       .getDefaultMessage()));
/*     */   }
/*     */ 
/*     */   private <T extends ObjectError> List<T> escapeObjectErrors(List<T> source)
/*     */   {
/* 233 */     List escaped = new ArrayList(source.size());
/* 234 */     for (ObjectError objectError : source) {
/* 235 */       escaped.add(escapeObjectError(objectError));
/*     */     }
/* 237 */     return escaped;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.EscapedErrors
 * JD-Core Version:    0.6.2
 */