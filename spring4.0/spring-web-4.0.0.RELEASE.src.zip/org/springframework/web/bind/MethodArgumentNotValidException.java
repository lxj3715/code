/*    */ package org.springframework.web.bind;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.validation.BindingResult;
/*    */ import org.springframework.validation.ObjectError;
/*    */ 
/*    */ public class MethodArgumentNotValidException extends Exception
/*    */ {
/*    */   private final MethodParameter parameter;
/*    */   private final BindingResult bindingResult;
/*    */ 
/*    */   public MethodArgumentNotValidException(MethodParameter parameter, BindingResult bindingResult)
/*    */   {
/* 43 */     this.parameter = parameter;
/* 44 */     this.bindingResult = bindingResult;
/*    */   }
/*    */ 
/*    */   public MethodParameter getParameter()
/*    */   {
/* 51 */     return this.parameter;
/*    */   }
/*    */ 
/*    */   public BindingResult getBindingResult()
/*    */   {
/* 58 */     return this.bindingResult;
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 67 */     StringBuilder sb = new StringBuilder("Validation failed for argument at index ")
/* 65 */       .append(this.parameter
/* 65 */       .getParameterIndex()).append(" in method: ")
/* 66 */       .append(this.parameter
/* 66 */       .getMethod().toGenericString())
/* 67 */       .append(", with ")
/* 67 */       .append(this.bindingResult.getErrorCount()).append(" error(s): ");
/* 68 */     for (ObjectError error : this.bindingResult.getAllErrors()) {
/* 69 */       sb.append("[").append(error).append("] ");
/*    */     }
/* 71 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.MethodArgumentNotValidException
 * JD-Core Version:    0.6.2
 */