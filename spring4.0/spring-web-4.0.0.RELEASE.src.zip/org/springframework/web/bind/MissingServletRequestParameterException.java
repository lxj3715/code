/*    */ package org.springframework.web.bind;
/*    */ 
/*    */ public class MissingServletRequestParameterException extends ServletRequestBindingException
/*    */ {
/*    */   private final String parameterName;
/*    */   private final String parameterType;
/*    */ 
/*    */   public MissingServletRequestParameterException(String parameterName, String parameterType)
/*    */   {
/* 39 */     super("");
/* 40 */     this.parameterName = parameterName;
/* 41 */     this.parameterType = parameterType;
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 47 */     return "Required " + this.parameterType + " parameter '" + this.parameterName + "' is not present";
/*    */   }
/*    */ 
/*    */   public final String getParameterName()
/*    */   {
/* 54 */     return this.parameterName;
/*    */   }
/*    */ 
/*    */   public final String getParameterType()
/*    */   {
/* 61 */     return this.parameterType;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.MissingServletRequestParameterException
 * JD-Core Version:    0.6.2
 */