/*    */ package org.springframework.web.bind;
/*    */ 
/*    */ import org.springframework.web.util.NestedServletException;
/*    */ 
/*    */ public class ServletRequestBindingException extends NestedServletException
/*    */ {
/*    */   public ServletRequestBindingException(String msg)
/*    */   {
/* 40 */     super(msg);
/*    */   }
/*    */ 
/*    */   public ServletRequestBindingException(String msg, Throwable cause)
/*    */   {
/* 49 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.ServletRequestBindingException
 * JD-Core Version:    0.6.2
 */