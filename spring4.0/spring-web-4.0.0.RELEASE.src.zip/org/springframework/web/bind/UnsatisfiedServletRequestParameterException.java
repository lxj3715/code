/*    */ package org.springframework.web.bind;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class UnsatisfiedServletRequestParameterException extends ServletRequestBindingException
/*    */ {
/*    */   private final String[] paramConditions;
/*    */   private final Map<String, String[]> actualParams;
/*    */ 
/*    */   public UnsatisfiedServletRequestParameterException(String[] paramConditions, Map<String, String[]> actualParams)
/*    */   {
/* 48 */     super("");
/* 49 */     this.paramConditions = paramConditions;
/* 50 */     this.actualParams = actualParams;
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 57 */     return new StringBuilder().append("Parameter conditions \"").append(StringUtils.arrayToDelimitedString(this.paramConditions, ", ")).append("\" not met for actual request parameters: ")
/* 57 */       .append(requestParameterMapToString(this.actualParams))
/* 57 */       .toString();
/*    */   }
/*    */ 
/*    */   private static String requestParameterMapToString(Map<String, String[]> actualParams) {
/* 61 */     StringBuilder result = new StringBuilder();
/* 62 */     for (Iterator it = actualParams.entrySet().iterator(); it.hasNext(); ) {
/* 63 */       Map.Entry entry = (Map.Entry)it.next();
/* 64 */       result.append((String)entry.getKey()).append('=').append(ObjectUtils.nullSafeToString((Object[])entry.getValue()));
/* 65 */       if (it.hasNext()) {
/* 66 */         result.append(", ");
/*    */       }
/*    */     }
/* 69 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public final String[] getParamConditions()
/*    */   {
/* 77 */     return this.paramConditions;
/*    */   }
/*    */ 
/*    */   public final Map<String, String[]> getActualParams()
/*    */   {
/* 85 */     return this.actualParams;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.UnsatisfiedServletRequestParameterException
 * JD-Core Version:    0.6.2
 */