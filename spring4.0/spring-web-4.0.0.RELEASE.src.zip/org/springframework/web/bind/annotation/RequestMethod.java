/*    */ package org.springframework.web.bind.annotation;
/*    */ 
/*    */ public enum RequestMethod
/*    */ {
/* 39 */   GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.RequestMethod
 * JD-Core Version:    0.6.2
 */