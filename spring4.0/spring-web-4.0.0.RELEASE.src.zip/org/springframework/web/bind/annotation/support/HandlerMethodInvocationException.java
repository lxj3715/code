/*    */ package org.springframework.web.bind.annotation.support;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class HandlerMethodInvocationException extends NestedRuntimeException
/*    */ {
/*    */   public HandlerMethodInvocationException(Method handlerMethod, Throwable cause)
/*    */   {
/* 39 */     super("Failed to invoke handler method [" + handlerMethod + "]", cause);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.support.HandlerMethodInvocationException
 * JD-Core Version:    0.6.2
 */