/*     */ package org.springframework.web.bind.annotation.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.ui.ExtendedModelMap;
/*     */ import org.springframework.ui.Model;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.CookieValue;
/*     */ import org.springframework.web.bind.annotation.InitBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestHeader;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.support.DefaultSessionAttributeStore;
/*     */ import org.springframework.web.bind.support.SessionAttributeStore;
/*     */ import org.springframework.web.bind.support.SessionStatus;
/*     */ import org.springframework.web.bind.support.SimpleSessionStatus;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.bind.support.WebBindingInitializer;
/*     */ import org.springframework.web.bind.support.WebRequestDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ 
/*     */ public class HandlerMethodInvoker
/*     */ {
/*  97 */   private static final String MODEL_KEY_PREFIX_STALE = new StringBuilder().append(SessionAttributeStore.class.getName()).append(".STALE.").toString();
/*     */ 
/* 100 */   private static final Log logger = LogFactory.getLog(HandlerMethodInvoker.class);
/*     */   private final HandlerMethodResolver methodResolver;
/*     */   private final WebBindingInitializer bindingInitializer;
/*     */   private final SessionAttributeStore sessionAttributeStore;
/*     */   private final ParameterNameDiscoverer parameterNameDiscoverer;
/*     */   private final WebArgumentResolver[] customArgumentResolvers;
/*     */   private final HttpMessageConverter<?>[] messageConverters;
/* 114 */   private final SimpleSessionStatus sessionStatus = new SimpleSessionStatus();
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver)
/*     */   {
/* 118 */     this(methodResolver, null);
/*     */   }
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver, WebBindingInitializer bindingInitializer) {
/* 122 */     this(methodResolver, bindingInitializer, new DefaultSessionAttributeStore(), null, null, null);
/*     */   }
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver, WebBindingInitializer bindingInitializer, SessionAttributeStore sessionAttributeStore, ParameterNameDiscoverer parameterNameDiscoverer, WebArgumentResolver[] customArgumentResolvers, HttpMessageConverter<?>[] messageConverters)
/*     */   {
/* 129 */     this.methodResolver = methodResolver;
/* 130 */     this.bindingInitializer = bindingInitializer;
/* 131 */     this.sessionAttributeStore = sessionAttributeStore;
/* 132 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/* 133 */     this.customArgumentResolvers = customArgumentResolvers;
/* 134 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   public final Object invokeHandlerMethod(Method handlerMethod, Object handler, NativeWebRequest webRequest, ExtendedModelMap implicitModel)
/*     */     throws Exception
/*     */   {
/* 141 */     Method handlerMethodToInvoke = BridgeMethodResolver.findBridgedMethod(handlerMethod);
/*     */     try {
/* 143 */       boolean debug = logger.isDebugEnabled();
/* 144 */       for (String attrName : this.methodResolver.getActualSessionAttributeNames()) {
/* 145 */         Object attrValue = this.sessionAttributeStore.retrieveAttribute(webRequest, attrName);
/* 146 */         if (attrValue != null) {
/* 147 */           implicitModel.addAttribute(attrName, attrValue);
/*     */         }
/*     */       }
/* 150 */       for (Method attributeMethod : this.methodResolver.getModelAttributeMethods()) {
/* 151 */         Method attributeMethodToInvoke = BridgeMethodResolver.findBridgedMethod(attributeMethod);
/* 152 */         Object[] args = resolveHandlerArguments(attributeMethodToInvoke, handler, webRequest, implicitModel);
/* 153 */         if (debug) {
/* 154 */           logger.debug(new StringBuilder().append("Invoking model attribute method: ").append(attributeMethodToInvoke).toString());
/*     */         }
/* 156 */         String attrName = ((ModelAttribute)AnnotationUtils.findAnnotation(attributeMethod, ModelAttribute.class)).value();
/* 157 */         if (("".equals(attrName)) || (!implicitModel.containsAttribute(attrName)))
/*     */         {
/* 160 */           ReflectionUtils.makeAccessible(attributeMethodToInvoke);
/* 161 */           Object attrValue = attributeMethodToInvoke.invoke(handler, args);
/* 162 */           if ("".equals(attrName)) {
/* 163 */             Class resolvedType = GenericTypeResolver.resolveReturnType(attributeMethodToInvoke, handler.getClass());
/* 164 */             attrName = Conventions.getVariableNameForReturnType(attributeMethodToInvoke, resolvedType, attrValue);
/*     */           }
/* 166 */           if (!implicitModel.containsAttribute(attrName))
/* 167 */             implicitModel.addAttribute(attrName, attrValue);
/*     */         }
/*     */       }
/* 170 */       Object[] args = resolveHandlerArguments(handlerMethodToInvoke, handler, webRequest, implicitModel);
/* 171 */       if (debug) {
/* 172 */         logger.debug(new StringBuilder().append("Invoking request handler method: ").append(handlerMethodToInvoke).toString());
/*     */       }
/* 174 */       ReflectionUtils.makeAccessible(handlerMethodToInvoke);
/* 175 */       return handlerMethodToInvoke.invoke(handler, args);
/*     */     }
/*     */     catch (IllegalStateException ex)
/*     */     {
/* 180 */       throw new HandlerMethodInvocationException(handlerMethodToInvoke, ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 184 */       ReflectionUtils.rethrowException(ex.getTargetException());
/* 185 */     }return null;
/*     */   }
/*     */ 
/*     */   public final void updateModelAttributes(Object handler, Map<String, Object> mavModel, ExtendedModelMap implicitModel, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 192 */     if ((this.methodResolver.hasSessionAttributes()) && (this.sessionStatus.isComplete())) {
/* 193 */       for (String attrName : this.methodResolver.getActualSessionAttributeNames()) {
/* 194 */         this.sessionAttributeStore.cleanupAttribute(webRequest, attrName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 200 */     Object model = mavModel != null ? mavModel : implicitModel;
/* 201 */     if (model != null)
/*     */       try {
/* 203 */         String[] originalAttrNames = (String[])((Map)model).keySet().toArray(new String[((Map)model).size()]);
/* 204 */         for (String attrName : originalAttrNames) {
/* 205 */           Object attrValue = ((Map)model).get(attrName);
/* 206 */           boolean isSessionAttr = this.methodResolver.isSessionAttribute(attrName, attrValue != null ? attrValue
/* 207 */             .getClass() : null);
/* 208 */           if (isSessionAttr) {
/* 209 */             if (this.sessionStatus.isComplete()) {
/* 210 */               implicitModel.put(new StringBuilder().append(MODEL_KEY_PREFIX_STALE).append(attrName).toString(), Boolean.TRUE);
/*     */             }
/* 212 */             else if (!implicitModel.containsKey(new StringBuilder().append(MODEL_KEY_PREFIX_STALE).append(attrName).toString())) {
/* 213 */               this.sessionAttributeStore.storeAttribute(webRequest, attrName, attrValue);
/*     */             }
/*     */           }
/* 216 */           if ((!attrName.startsWith(BindingResult.MODEL_KEY_PREFIX)) && ((isSessionAttr) || 
/* 217 */             (isBindingCandidate(attrValue))))
/*     */           {
/* 218 */             String bindingResultKey = new StringBuilder().append(BindingResult.MODEL_KEY_PREFIX).append(attrName).toString();
/* 219 */             if ((mavModel != null) && (!((Map)model).containsKey(bindingResultKey))) {
/* 220 */               WebDataBinder binder = createBinder(webRequest, attrValue, attrName);
/* 221 */               initBinder(handler, attrName, binder, webRequest);
/* 222 */               mavModel.put(bindingResultKey, binder.getBindingResult());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException ex)
/*     */       {
/* 229 */         ReflectionUtils.rethrowException(ex.getTargetException());
/*     */       }
/*     */   }
/*     */ 
/*     */   private Object[] resolveHandlerArguments(Method handlerMethod, Object handler, NativeWebRequest webRequest, ExtendedModelMap implicitModel)
/*     */     throws Exception
/*     */   {
/* 238 */     Class[] paramTypes = handlerMethod.getParameterTypes();
/* 239 */     Object[] args = new Object[paramTypes.length];
/*     */ 
/* 241 */     for (int i = 0; i < args.length; i++) {
/* 242 */       MethodParameter methodParam = new MethodParameter(handlerMethod, i);
/* 243 */       methodParam.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 244 */       GenericTypeResolver.resolveParameterType(methodParam, handler.getClass());
/* 245 */       String paramName = null;
/* 246 */       String headerName = null;
/* 247 */       boolean requestBodyFound = false;
/* 248 */       String cookieName = null;
/* 249 */       String pathVarName = null;
/* 250 */       String attrName = null;
/* 251 */       boolean required = false;
/* 252 */       String defaultValue = null;
/* 253 */       boolean validate = false;
/* 254 */       Object[] validationHints = null;
/* 255 */       int annotationsFound = 0;
/* 256 */       Annotation[] paramAnns = methodParam.getParameterAnnotations();
/*     */ 
/* 258 */       for (Annotation paramAnn : paramAnns) {
/* 259 */         if (RequestParam.class.isInstance(paramAnn)) {
/* 260 */           RequestParam requestParam = (RequestParam)paramAnn;
/* 261 */           paramName = requestParam.value();
/* 262 */           required = requestParam.required();
/* 263 */           defaultValue = parseDefaultValueAttribute(requestParam.defaultValue());
/* 264 */           annotationsFound++;
/*     */         }
/* 266 */         else if (RequestHeader.class.isInstance(paramAnn)) {
/* 267 */           RequestHeader requestHeader = (RequestHeader)paramAnn;
/* 268 */           headerName = requestHeader.value();
/* 269 */           required = requestHeader.required();
/* 270 */           defaultValue = parseDefaultValueAttribute(requestHeader.defaultValue());
/* 271 */           annotationsFound++;
/*     */         }
/* 273 */         else if (RequestBody.class.isInstance(paramAnn)) {
/* 274 */           requestBodyFound = true;
/* 275 */           annotationsFound++;
/*     */         }
/* 277 */         else if (CookieValue.class.isInstance(paramAnn)) {
/* 278 */           CookieValue cookieValue = (CookieValue)paramAnn;
/* 279 */           cookieName = cookieValue.value();
/* 280 */           required = cookieValue.required();
/* 281 */           defaultValue = parseDefaultValueAttribute(cookieValue.defaultValue());
/* 282 */           annotationsFound++;
/*     */         }
/* 284 */         else if (PathVariable.class.isInstance(paramAnn)) {
/* 285 */           PathVariable pathVar = (PathVariable)paramAnn;
/* 286 */           pathVarName = pathVar.value();
/* 287 */           annotationsFound++;
/*     */         }
/* 289 */         else if (ModelAttribute.class.isInstance(paramAnn)) {
/* 290 */           ModelAttribute attr = (ModelAttribute)paramAnn;
/* 291 */           attrName = attr.value();
/* 292 */           annotationsFound++;
/*     */         }
/* 294 */         else if (Value.class.isInstance(paramAnn)) {
/* 295 */           defaultValue = ((Value)paramAnn).value();
/*     */         }
/* 297 */         else if (paramAnn.annotationType().getSimpleName().startsWith("Valid")) {
/* 298 */           validate = true;
/* 299 */           Object value = AnnotationUtils.getValue(paramAnn);
/* 300 */           validationHints = new Object[] { (value instanceof Object[]) ? (Object[])value : value };
/*     */         }
/*     */       }
/*     */ 
/* 304 */       if (annotationsFound > 1) {
/* 305 */         throw new IllegalStateException(new StringBuilder().append("Handler parameter annotations are exclusive choices - do not specify more than one such annotation on the same parameter: ").append(handlerMethod).toString());
/*     */       }
/*     */ 
/* 309 */       if (annotationsFound == 0) {
/* 310 */         Object argValue = resolveCommonArgument(methodParam, webRequest);
/* 311 */         if (argValue != WebArgumentResolver.UNRESOLVED) {
/* 312 */           args[i] = argValue;
/*     */         }
/* 314 */         else if (defaultValue != null) {
/* 315 */           args[i] = resolveDefaultValue(defaultValue);
/*     */         }
/*     */         else {
/* 318 */           Class paramType = methodParam.getParameterType();
/* 319 */           if ((Model.class.isAssignableFrom(paramType)) || (Map.class.isAssignableFrom(paramType))) {
/* 320 */             if (!paramType.isAssignableFrom(implicitModel.getClass())) {
/* 321 */               throw new IllegalStateException(new StringBuilder().append("Argument [").append(paramType.getSimpleName()).append("] is of type ").append("Model or Map but is not assignable from the actual model. You may need to switch ").append("newer MVC infrastructure classes to use this argument.").toString());
/*     */             }
/*     */ 
/* 325 */             args[i] = implicitModel;
/*     */           }
/* 327 */           else if (SessionStatus.class.isAssignableFrom(paramType)) {
/* 328 */             args[i] = this.sessionStatus;
/*     */           }
/* 330 */           else if (HttpEntity.class.isAssignableFrom(paramType)) {
/* 331 */             args[i] = resolveHttpEntityRequest(methodParam, webRequest);
/*     */           } else {
/* 333 */             if (Errors.class.isAssignableFrom(paramType)) {
/* 334 */               throw new IllegalStateException("Errors/BindingResult argument declared without preceding model attribute. Check your handler method signature!");
/*     */             }
/*     */ 
/* 337 */             if (BeanUtils.isSimpleProperty(paramType)) {
/* 338 */               paramName = "";
/*     */             }
/*     */             else {
/* 341 */               attrName = "";
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 346 */       if (paramName != null) {
/* 347 */         args[i] = resolveRequestParam(paramName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 349 */       else if (headerName != null) {
/* 350 */         args[i] = resolveRequestHeader(headerName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 352 */       else if (requestBodyFound) {
/* 353 */         args[i] = resolveRequestBody(methodParam, webRequest, handler);
/*     */       }
/* 355 */       else if (cookieName != null) {
/* 356 */         args[i] = resolveCookieValue(cookieName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 358 */       else if (pathVarName != null) {
/* 359 */         args[i] = resolvePathVariable(pathVarName, methodParam, webRequest, handler);
/*     */       }
/* 361 */       else if (attrName != null)
/*     */       {
/* 363 */         WebDataBinder binder = resolveModelAttribute(attrName, methodParam, implicitModel, webRequest, handler);
/*     */ 
/* 364 */         boolean assignBindingResult = (args.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/* 365 */         if (binder.getTarget() != null) {
/* 366 */           doBind(binder, webRequest, validate, validationHints, !assignBindingResult);
/*     */         }
/* 368 */         args[i] = binder.getTarget();
/* 369 */         if (assignBindingResult) {
/* 370 */           args[(i + 1)] = binder.getBindingResult();
/* 371 */           i++;
/*     */         }
/* 373 */         implicitModel.putAll(binder.getBindingResult().getModel());
/*     */       }
/*     */     }
/*     */ 
/* 377 */     return args;
/*     */   }
/*     */ 
/*     */   protected void initBinder(Object handler, String attrName, WebDataBinder binder, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 383 */     if (this.bindingInitializer != null)
/* 384 */       this.bindingInitializer.initBinder(binder, webRequest);
/*     */     boolean debug;
/* 386 */     if (handler != null) {
/* 387 */       Set initBinderMethods = this.methodResolver.getInitBinderMethods();
/* 388 */       if (!initBinderMethods.isEmpty()) {
/* 389 */         debug = logger.isDebugEnabled();
/* 390 */         for (Method initBinderMethod : initBinderMethods) {
/* 391 */           Method methodToInvoke = BridgeMethodResolver.findBridgedMethod(initBinderMethod);
/* 392 */           String[] targetNames = ((InitBinder)AnnotationUtils.findAnnotation(initBinderMethod, InitBinder.class)).value();
/* 393 */           if ((targetNames.length == 0) || (Arrays.asList(targetNames).contains(attrName)))
/*     */           {
/* 395 */             Object[] initBinderArgs = resolveInitBinderArguments(handler, methodToInvoke, binder, webRequest);
/*     */ 
/* 396 */             if (debug) {
/* 397 */               logger.debug(new StringBuilder().append("Invoking init-binder method: ").append(methodToInvoke).toString());
/*     */             }
/* 399 */             ReflectionUtils.makeAccessible(methodToInvoke);
/* 400 */             Object returnValue = methodToInvoke.invoke(handler, initBinderArgs);
/* 401 */             if (returnValue != null)
/* 402 */               throw new IllegalStateException(new StringBuilder().append("InitBinder methods must not have a return value: ").append(methodToInvoke).toString());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object[] resolveInitBinderArguments(Object handler, Method initBinderMethod, WebDataBinder binder, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 414 */     Class[] initBinderParams = initBinderMethod.getParameterTypes();
/* 415 */     Object[] initBinderArgs = new Object[initBinderParams.length];
/*     */ 
/* 417 */     for (int i = 0; i < initBinderArgs.length; i++) {
/* 418 */       MethodParameter methodParam = new MethodParameter(initBinderMethod, i);
/* 419 */       methodParam.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 420 */       GenericTypeResolver.resolveParameterType(methodParam, handler.getClass());
/* 421 */       String paramName = null;
/* 422 */       boolean paramRequired = false;
/* 423 */       String paramDefaultValue = null;
/* 424 */       String pathVarName = null;
/* 425 */       Annotation[] paramAnns = methodParam.getParameterAnnotations();
/*     */ 
/* 427 */       for (Annotation paramAnn : paramAnns) {
/* 428 */         if (RequestParam.class.isInstance(paramAnn)) {
/* 429 */           RequestParam requestParam = (RequestParam)paramAnn;
/* 430 */           paramName = requestParam.value();
/* 431 */           paramRequired = requestParam.required();
/* 432 */           paramDefaultValue = parseDefaultValueAttribute(requestParam.defaultValue());
/* 433 */           break;
/*     */         }
/* 435 */         if (ModelAttribute.class.isInstance(paramAnn)) {
/* 436 */           throw new IllegalStateException(new StringBuilder().append("@ModelAttribute is not supported on @InitBinder methods: ").append(initBinderMethod).toString());
/*     */         }
/*     */ 
/* 439 */         if (PathVariable.class.isInstance(paramAnn)) {
/* 440 */           PathVariable pathVar = (PathVariable)paramAnn;
/* 441 */           pathVarName = pathVar.value();
/*     */         }
/*     */       }
/*     */ 
/* 445 */       if ((paramName == null) && (pathVarName == null)) {
/* 446 */         Object argValue = resolveCommonArgument(methodParam, webRequest);
/* 447 */         if (argValue != WebArgumentResolver.UNRESOLVED) {
/* 448 */           initBinderArgs[i] = argValue;
/*     */         }
/*     */         else {
/* 451 */           Class paramType = initBinderParams[i];
/* 452 */           if (paramType.isInstance(binder)) {
/* 453 */             initBinderArgs[i] = binder;
/*     */           }
/* 455 */           else if (BeanUtils.isSimpleProperty(paramType)) {
/* 456 */             paramName = "";
/*     */           }
/*     */           else {
/* 459 */             throw new IllegalStateException(new StringBuilder().append("Unsupported argument [").append(paramType.getName()).append("] for @InitBinder method: ").append(initBinderMethod).toString());
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 465 */       if (paramName != null) {
/* 466 */         initBinderArgs[i] = 
/* 467 */           resolveRequestParam(paramName, paramRequired, paramDefaultValue, methodParam, webRequest, null);
/*     */       }
/* 469 */       else if (pathVarName != null) {
/* 470 */         initBinderArgs[i] = resolvePathVariable(pathVarName, methodParam, webRequest, null);
/*     */       }
/*     */     }
/*     */ 
/* 474 */     return initBinderArgs;
/*     */   }
/*     */ 
/*     */   private Object resolveRequestParam(String paramName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 482 */     Class paramType = methodParam.getParameterType();
/* 483 */     if ((Map.class.isAssignableFrom(paramType)) && (paramName.length() == 0)) {
/* 484 */       return resolveRequestParamMap(paramType, webRequest);
/*     */     }
/* 486 */     if (paramName.length() == 0) {
/* 487 */       paramName = getRequiredParameterName(methodParam);
/*     */     }
/* 489 */     Object paramValue = null;
/* 490 */     MultipartRequest multipartRequest = (MultipartRequest)webRequest.getNativeRequest(MultipartRequest.class);
/* 491 */     if (multipartRequest != null) {
/* 492 */       List files = multipartRequest.getFiles(paramName);
/* 493 */       if (!files.isEmpty()) {
/* 494 */         paramValue = files.size() == 1 ? files.get(0) : files;
/*     */       }
/*     */     }
/* 497 */     if (paramValue == null) {
/* 498 */       String[] paramValues = webRequest.getParameterValues(paramName);
/* 499 */       if (paramValues != null) {
/* 500 */         paramValue = paramValues.length == 1 ? paramValues[0] : paramValues;
/*     */       }
/*     */     }
/* 503 */     if (paramValue == null) {
/* 504 */       if (defaultValue != null) {
/* 505 */         paramValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 507 */       else if (required) {
/* 508 */         raiseMissingParameterException(paramName, paramType);
/*     */       }
/* 510 */       paramValue = checkValue(paramName, paramValue, paramType);
/*     */     }
/* 512 */     WebDataBinder binder = createBinder(webRequest, null, paramName);
/* 513 */     initBinder(handlerForInitBinderCall, paramName, binder, webRequest);
/* 514 */     return binder.convertIfNecessary(paramValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   private Map<String, ?> resolveRequestParamMap(Class<? extends Map<?, ?>> mapType, NativeWebRequest webRequest) {
/* 518 */     Map parameterMap = webRequest.getParameterMap();
/* 519 */     if (MultiValueMap.class.isAssignableFrom(mapType)) {
/* 520 */       MultiValueMap result = new LinkedMultiValueMap(parameterMap.size());
/* 521 */       for (Map.Entry entry : parameterMap.entrySet()) {
/* 522 */         for (String value : (String[])entry.getValue()) {
/* 523 */           result.add(entry.getKey(), value);
/*     */         }
/*     */       }
/* 526 */       return result;
/*     */     }
/*     */ 
/* 529 */     Map result = new LinkedHashMap(parameterMap.size());
/* 530 */     for (Map.Entry entry : parameterMap.entrySet()) {
/* 531 */       if (((String[])entry.getValue()).length > 0) {
/* 532 */         result.put(entry.getKey(), ((String[])entry.getValue())[0]);
/*     */       }
/*     */     }
/* 535 */     return result;
/*     */   }
/*     */ 
/*     */   private Object resolveRequestHeader(String headerName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 544 */     Class paramType = methodParam.getParameterType();
/* 545 */     if (Map.class.isAssignableFrom(paramType)) {
/* 546 */       return resolveRequestHeaderMap(paramType, webRequest);
/*     */     }
/* 548 */     if (headerName.length() == 0) {
/* 549 */       headerName = getRequiredParameterName(methodParam);
/*     */     }
/* 551 */     Object headerValue = null;
/* 552 */     String[] headerValues = webRequest.getHeaderValues(headerName);
/* 553 */     if (headerValues != null) {
/* 554 */       headerValue = headerValues.length == 1 ? headerValues[0] : headerValues;
/*     */     }
/* 556 */     if (headerValue == null) {
/* 557 */       if (defaultValue != null) {
/* 558 */         headerValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 560 */       else if (required) {
/* 561 */         raiseMissingHeaderException(headerName, paramType);
/*     */       }
/* 563 */       headerValue = checkValue(headerName, headerValue, paramType);
/*     */     }
/* 565 */     WebDataBinder binder = createBinder(webRequest, null, headerName);
/* 566 */     initBinder(handlerForInitBinderCall, headerName, binder, webRequest);
/* 567 */     return binder.convertIfNecessary(headerValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   private Map<String, ?> resolveRequestHeaderMap(Class<? extends Map<?, ?>> mapType, NativeWebRequest webRequest) {
/* 571 */     if (MultiValueMap.class.isAssignableFrom(mapType))
/*     */     {
/*     */       MultiValueMap result;
/*     */       MultiValueMap result;
/* 573 */       if (HttpHeaders.class.isAssignableFrom(mapType)) {
/* 574 */         result = new HttpHeaders();
/*     */       }
/*     */       else {
/* 577 */         result = new LinkedMultiValueMap();
/*     */       }
/* 579 */       for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 580 */         String headerName = (String)iterator.next();
/* 581 */         for (String headerValue : webRequest.getHeaderValues(headerName)) {
/* 582 */           result.add(headerName, headerValue);
/*     */         }
/*     */       }
/* 585 */       return result;
/*     */     }
/*     */ 
/* 588 */     Map result = new LinkedHashMap();
/* 589 */     for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 590 */       String headerName = (String)iterator.next();
/* 591 */       String headerValue = webRequest.getHeader(headerName);
/* 592 */       result.put(headerName, headerValue);
/*     */     }
/* 594 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object resolveRequestBody(MethodParameter methodParam, NativeWebRequest webRequest, Object handler)
/*     */     throws Exception
/*     */   {
/* 604 */     return readWithMessageConverters(methodParam, createHttpInputMessage(webRequest), methodParam.getParameterType());
/*     */   }
/*     */ 
/*     */   private HttpEntity<?> resolveHttpEntityRequest(MethodParameter methodParam, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 610 */     HttpInputMessage inputMessage = createHttpInputMessage(webRequest);
/* 611 */     Class paramType = getHttpEntityType(methodParam);
/* 612 */     Object body = readWithMessageConverters(methodParam, inputMessage, paramType);
/* 613 */     return new HttpEntity(body, inputMessage.getHeaders());
/*     */   }
/*     */ 
/*     */   private Object readWithMessageConverters(MethodParameter methodParam, HttpInputMessage inputMessage, Class<?> paramType)
/*     */     throws Exception
/*     */   {
/* 620 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/*     */     String paramName;
/* 621 */     if (contentType == null) {
/* 622 */       StringBuilder builder = new StringBuilder(ClassUtils.getShortName(methodParam.getParameterType()));
/* 623 */       paramName = methodParam.getParameterName();
/* 624 */       if (paramName != null) {
/* 625 */         builder.append(' ');
/* 626 */         builder.append(paramName);
/*     */       }
/*     */ 
/* 629 */       throw new HttpMediaTypeNotSupportedException(new StringBuilder().append("Cannot extract parameter (")
/* 629 */         .append(builder
/* 629 */         .toString()).append("): no Content-Type found").toString());
/*     */     }
/*     */ 
/* 632 */     List allSupportedMediaTypes = new ArrayList();
/* 633 */     if (this.messageConverters != null) {
/* 634 */       for (HttpMessageConverter messageConverter : this.messageConverters) {
/* 635 */         allSupportedMediaTypes.addAll(messageConverter.getSupportedMediaTypes());
/* 636 */         if (messageConverter.canRead(paramType, contentType)) {
/* 637 */           if (logger.isDebugEnabled()) {
/* 638 */             logger.debug(new StringBuilder().append("Reading [").append(paramType.getName()).append("] as \"").append(contentType).append("\" using [").append(messageConverter).append("]").toString());
/*     */           }
/*     */ 
/* 641 */           return messageConverter.read(paramType, inputMessage);
/*     */         }
/*     */       }
/*     */     }
/* 645 */     throw new HttpMediaTypeNotSupportedException(contentType, allSupportedMediaTypes);
/*     */   }
/*     */ 
/*     */   private Class<?> getHttpEntityType(MethodParameter methodParam) {
/* 649 */     Assert.isAssignable(HttpEntity.class, methodParam.getParameterType());
/* 650 */     ParameterizedType type = (ParameterizedType)methodParam.getGenericParameterType();
/* 651 */     if (type.getActualTypeArguments().length == 1) {
/* 652 */       Type typeArgument = type.getActualTypeArguments()[0];
/* 653 */       if ((typeArgument instanceof Class)) {
/* 654 */         return (Class)typeArgument;
/*     */       }
/* 656 */       if ((typeArgument instanceof GenericArrayType)) {
/* 657 */         Type componentType = ((GenericArrayType)typeArgument).getGenericComponentType();
/* 658 */         if ((componentType instanceof Class))
/*     */         {
/* 660 */           Object array = Array.newInstance((Class)componentType, 0);
/* 661 */           return array.getClass();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 666 */     throw new IllegalArgumentException(new StringBuilder().append("HttpEntity parameter (")
/* 666 */       .append(methodParam
/* 666 */       .getParameterName()).append(") is not parameterized").toString());
/*     */   }
/*     */ 
/*     */   private Object resolveCookieValue(String cookieName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 674 */     Class paramType = methodParam.getParameterType();
/* 675 */     if (cookieName.length() == 0) {
/* 676 */       cookieName = getRequiredParameterName(methodParam);
/*     */     }
/* 678 */     Object cookieValue = resolveCookieValue(cookieName, paramType, webRequest);
/* 679 */     if (cookieValue == null) {
/* 680 */       if (defaultValue != null) {
/* 681 */         cookieValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 683 */       else if (required) {
/* 684 */         raiseMissingCookieException(cookieName, paramType);
/*     */       }
/* 686 */       cookieValue = checkValue(cookieName, cookieValue, paramType);
/*     */     }
/* 688 */     WebDataBinder binder = createBinder(webRequest, null, cookieName);
/* 689 */     initBinder(handlerForInitBinderCall, cookieName, binder, webRequest);
/* 690 */     return binder.convertIfNecessary(cookieValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   protected Object resolveCookieValue(String cookieName, Class<?> paramType, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 700 */     throw new UnsupportedOperationException("@CookieValue not supported");
/*     */   }
/*     */ 
/*     */   private Object resolvePathVariable(String pathVarName, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 706 */     Class paramType = methodParam.getParameterType();
/* 707 */     if (pathVarName.length() == 0) {
/* 708 */       pathVarName = getRequiredParameterName(methodParam);
/*     */     }
/* 710 */     String pathVarValue = resolvePathVariable(pathVarName, paramType, webRequest);
/* 711 */     WebDataBinder binder = createBinder(webRequest, null, pathVarName);
/* 712 */     initBinder(handlerForInitBinderCall, pathVarName, binder, webRequest);
/* 713 */     return binder.convertIfNecessary(pathVarValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   protected String resolvePathVariable(String pathVarName, Class<?> paramType, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 723 */     throw new UnsupportedOperationException("@PathVariable not supported");
/*     */   }
/*     */ 
/*     */   private String getRequiredParameterName(MethodParameter methodParam) {
/* 727 */     String name = methodParam.getParameterName();
/* 728 */     if (name == null)
/*     */     {
/* 730 */       throw new IllegalStateException(new StringBuilder().append("No parameter name specified for argument of type [")
/* 730 */         .append(methodParam
/* 730 */         .getParameterType().getName()).append("], and no parameter name information found in class file either.").toString());
/*     */     }
/*     */ 
/* 733 */     return name;
/*     */   }
/*     */ 
/*     */   private Object checkValue(String name, Object value, Class<?> paramType) {
/* 737 */     if (value == null) {
/* 738 */       if (Boolean.TYPE.equals(paramType)) {
/* 739 */         return Boolean.FALSE;
/*     */       }
/* 741 */       if (paramType.isPrimitive()) {
/* 742 */         throw new IllegalStateException(new StringBuilder().append("Optional ").append(paramType).append(" parameter '").append(name).append("' is not present but cannot be translated into a null value due to being declared as a ").append("primitive type. Consider declaring it as object wrapper for the corresponding primitive type.").toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 747 */     return value;
/*     */   }
/*     */ 
/*     */   private WebDataBinder resolveModelAttribute(String attrName, MethodParameter methodParam, ExtendedModelMap implicitModel, NativeWebRequest webRequest, Object handler)
/*     */     throws Exception
/*     */   {
/* 754 */     String name = attrName;
/* 755 */     if ("".equals(name)) {
/* 756 */       name = Conventions.getVariableNameForParameter(methodParam);
/*     */     }
/* 758 */     Class paramType = methodParam.getParameterType();
/*     */     Object bindObject;
/*     */     Object bindObject;
/* 760 */     if (implicitModel.containsKey(name)) {
/* 761 */       bindObject = implicitModel.get(name);
/*     */     }
/* 763 */     else if (this.methodResolver.isSessionAttribute(name, paramType)) {
/* 764 */       Object bindObject = this.sessionAttributeStore.retrieveAttribute(webRequest, name);
/* 765 */       if (bindObject == null)
/* 766 */         raiseSessionRequiredException(new StringBuilder().append("Session attribute '").append(name).append("' required - not found in session").toString());
/*     */     }
/*     */     else
/*     */     {
/* 770 */       bindObject = BeanUtils.instantiateClass(paramType);
/*     */     }
/* 772 */     WebDataBinder binder = createBinder(webRequest, bindObject, name);
/* 773 */     initBinder(handler, name, binder, webRequest);
/* 774 */     return binder;
/*     */   }
/*     */ 
/*     */   protected boolean isBindingCandidate(Object value)
/*     */   {
/* 784 */     return (value != null) && (!value.getClass().isArray()) && (!(value instanceof Collection)) && (!(value instanceof Map)) && 
/* 784 */       (!BeanUtils.isSimpleValueType(value
/* 784 */       .getClass()));
/*     */   }
/*     */ 
/*     */   protected void raiseMissingParameterException(String paramName, Class<?> paramType) throws Exception {
/* 788 */     throw new IllegalStateException(new StringBuilder().append("Missing parameter '").append(paramName).append("' of type [").append(paramType.getName()).append("]").toString());
/*     */   }
/*     */ 
/*     */   protected void raiseMissingHeaderException(String headerName, Class<?> paramType) throws Exception {
/* 792 */     throw new IllegalStateException(new StringBuilder().append("Missing header '").append(headerName).append("' of type [").append(paramType.getName()).append("]").toString());
/*     */   }
/*     */ 
/*     */   protected void raiseMissingCookieException(String cookieName, Class<?> paramType) throws Exception
/*     */   {
/* 797 */     throw new IllegalStateException(new StringBuilder().append("Missing cookie value '").append(cookieName).append("' of type [")
/* 797 */       .append(paramType
/* 797 */       .getName()).append("]").toString());
/*     */   }
/*     */ 
/*     */   protected void raiseSessionRequiredException(String message) throws Exception {
/* 801 */     throw new IllegalStateException(message);
/*     */   }
/*     */ 
/*     */   protected WebDataBinder createBinder(NativeWebRequest webRequest, Object target, String objectName)
/*     */     throws Exception
/*     */   {
/* 807 */     return new WebRequestDataBinder(target, objectName);
/*     */   }
/*     */ 
/*     */   private void doBind(WebDataBinder binder, NativeWebRequest webRequest, boolean validate, Object[] validationHints, boolean failOnErrors)
/*     */     throws Exception
/*     */   {
/* 813 */     doBind(binder, webRequest);
/* 814 */     if (validate) {
/* 815 */       binder.validate(validationHints);
/*     */     }
/* 817 */     if ((failOnErrors) && (binder.getBindingResult().hasErrors()))
/* 818 */       throw new BindException(binder.getBindingResult());
/*     */   }
/*     */ 
/*     */   protected void doBind(WebDataBinder binder, NativeWebRequest webRequest) throws Exception
/*     */   {
/* 823 */     ((WebRequestDataBinder)binder).bind(webRequest);
/*     */   }
/*     */ 
/*     */   protected HttpInputMessage createHttpInputMessage(NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 831 */     throw new UnsupportedOperationException("@RequestBody not supported");
/*     */   }
/*     */ 
/*     */   protected HttpOutputMessage createHttpOutputMessage(NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 839 */     throw new UnsupportedOperationException("@Body not supported");
/*     */   }
/*     */ 
/*     */   protected String parseDefaultValueAttribute(String value) {
/* 843 */     return "\n\t\t\n\t\t\n\n\t\t\t\t\n".equals(value) ? null : value;
/*     */   }
/*     */ 
/*     */   protected Object resolveDefaultValue(String value) {
/* 847 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object resolveCommonArgument(MethodParameter methodParameter, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 854 */     if (this.customArgumentResolvers != null) {
/* 855 */       for (WebArgumentResolver argumentResolver : this.customArgumentResolvers) {
/* 856 */         Object value = argumentResolver.resolveArgument(methodParameter, webRequest);
/* 857 */         if (value != WebArgumentResolver.UNRESOLVED) {
/* 858 */           return value;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 864 */     Class paramType = methodParameter.getParameterType();
/* 865 */     Object value = resolveStandardArgument(paramType, webRequest);
/* 866 */     if ((value != WebArgumentResolver.UNRESOLVED) && (!ClassUtils.isAssignableValue(paramType, value)))
/*     */     {
/* 868 */       throw new IllegalStateException(new StringBuilder().append("Standard argument type [").append(paramType.getName()).append("] resolved to incompatible value of type [")
/* 868 */         .append(value != null ? value
/* 868 */         .getClass() : null).append("]. Consider declaring the argument type in a less specific fashion.").toString());
/*     */     }
/*     */ 
/* 871 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object resolveStandardArgument(Class<?> parameterType, NativeWebRequest webRequest) throws Exception {
/* 875 */     if (WebRequest.class.isAssignableFrom(parameterType)) {
/* 876 */       return webRequest;
/*     */     }
/* 878 */     return WebArgumentResolver.UNRESOLVED;
/*     */   }
/*     */ 
/*     */   protected final void addReturnValueAsModelAttribute(Method handlerMethod, Class<?> handlerType, Object returnValue, ExtendedModelMap implicitModel)
/*     */   {
/* 884 */     ModelAttribute attr = (ModelAttribute)AnnotationUtils.findAnnotation(handlerMethod, ModelAttribute.class);
/* 885 */     String attrName = attr != null ? attr.value() : "";
/* 886 */     if ("".equals(attrName)) {
/* 887 */       Class resolvedType = GenericTypeResolver.resolveReturnType(handlerMethod, handlerType);
/* 888 */       attrName = Conventions.getVariableNameForReturnType(handlerMethod, resolvedType, returnValue);
/*     */     }
/* 890 */     implicitModel.addAttribute(attrName, returnValue);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.support.HandlerMethodInvoker
 * JD-Core Version:    0.6.2
 */