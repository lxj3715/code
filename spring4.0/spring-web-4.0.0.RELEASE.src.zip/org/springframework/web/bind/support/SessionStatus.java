package org.springframework.web.bind.support;

public abstract interface SessionStatus
{
  public abstract void setComplete();

  public abstract boolean isComplete();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.SessionStatus
 * JD-Core Version:    0.6.2
 */