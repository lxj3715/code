/*    */ package org.springframework.web.bind.support;
/*    */ 
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public abstract interface WebArgumentResolver
/*    */ {
/* 51 */   public static final Object UNRESOLVED = new Object();
/*    */ 
/*    */   public abstract Object resolveArgument(MethodParameter paramMethodParameter, NativeWebRequest paramNativeWebRequest)
/*    */     throws Exception;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebArgumentResolver
 * JD-Core Version:    0.6.2
 */