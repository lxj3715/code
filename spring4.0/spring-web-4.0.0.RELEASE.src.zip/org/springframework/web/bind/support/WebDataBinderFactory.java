package org.springframework.web.bind.support;

import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.context.request.NativeWebRequest;

public abstract interface WebDataBinderFactory
{
  public abstract WebDataBinder createBinder(NativeWebRequest paramNativeWebRequest, Object paramObject, String paramString)
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebDataBinderFactory
 * JD-Core Version:    0.6.2
 */