/*     */ package org.springframework.web.bind.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ 
/*     */ public class WebRequestDataBinder extends WebDataBinder
/*     */ {
/*     */   public WebRequestDataBinder(Object target)
/*     */   {
/*  84 */     super(target);
/*     */   }
/*     */ 
/*     */   public WebRequestDataBinder(Object target, String objectName)
/*     */   {
/*  94 */     super(target, objectName);
/*     */   }
/*     */ 
/*     */   public void bind(WebRequest request)
/*     */   {
/* 117 */     MutablePropertyValues mpvs = new MutablePropertyValues(request.getParameterMap());
/*     */ 
/* 119 */     if ((isMultipartRequest(request)) && ((request instanceof NativeWebRequest))) {
/* 120 */       MultipartRequest multipartRequest = (MultipartRequest)((NativeWebRequest)request).getNativeRequest(MultipartRequest.class);
/* 121 */       if (multipartRequest != null) {
/* 122 */         bindMultipart(multipartRequest.getMultiFileMap(), mpvs);
/*     */       }
/* 124 */       else if (ClassUtils.hasMethod(HttpServletRequest.class, "getParts", new Class[0])) {
/* 125 */         HttpServletRequest serlvetRequest = (HttpServletRequest)((NativeWebRequest)request).getNativeRequest(HttpServletRequest.class);
/* 126 */         new Servlet3MultipartHelper(isBindEmptyMultipartFiles()).bindParts(serlvetRequest, mpvs);
/*     */       }
/*     */     }
/* 129 */     doBind(mpvs);
/*     */   }
/*     */ 
/*     */   public void closeNoCatch()
/*     */     throws BindException
/*     */   {
/* 139 */     if (getBindingResult().hasErrors())
/* 140 */       throw new BindException(getBindingResult());
/*     */   }
/*     */ 
/*     */   private boolean isMultipartRequest(WebRequest request)
/*     */   {
/* 150 */     String contentType = request.getHeader("Content-Type");
/* 151 */     return (contentType != null) && (StringUtils.startsWithIgnoreCase(contentType, "multipart"));
/*     */   }
/*     */ 
/*     */   private static class Servlet3MultipartHelper
/*     */   {
/*     */     private final boolean bindEmptyMultipartFiles;
/*     */ 
/*     */     public Servlet3MultipartHelper(boolean bindEmptyMultipartFiles)
/*     */     {
/* 165 */       this.bindEmptyMultipartFiles = bindEmptyMultipartFiles;
/*     */     }
/*     */ 
/*     */     public void bindParts(HttpServletRequest request, MutablePropertyValues mpvs)
/*     */     {
/*     */       try {
/* 171 */         MultiValueMap map = new LinkedMultiValueMap();
/* 172 */         for (Part part : request.getParts()) {
/* 173 */           map.add(part.getName(), part);
/*     */         }
/* 175 */         for (Map.Entry entry : map.entrySet())
/* 176 */           if (((List)entry.getValue()).size() == 1) {
/* 177 */             Part part = (Part)((List)entry.getValue()).get(0);
/* 178 */             if ((this.bindEmptyMultipartFiles) || (part.getSize() > 0L))
/* 179 */               mpvs.add((String)entry.getKey(), part);
/*     */           }
/*     */           else
/*     */           {
/* 183 */             mpvs.add((String)entry.getKey(), entry.getValue());
/*     */           }
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 188 */         throw new MultipartException("Failed to get request parts", ex);
/*     */       }
/*     */       catch (ServletException ex) {
/* 191 */         throw new MultipartException("Failed to get request parts", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebRequestDataBinder
 * JD-Core Version:    0.6.2
 */