/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.core.task.AsyncListenableTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.AsyncClientHttpRequest;
/*     */ import org.springframework.http.client.AsyncClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*     */ import org.springframework.http.client.support.AsyncHttpAccessor;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureAdapter;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallback;
/*     */ import org.springframework.web.util.UriTemplate;
/*     */ 
/*     */ public class AsyncRestTemplate extends AsyncHttpAccessor
/*     */   implements AsyncRestOperations
/*     */ {
/*     */   private final RestTemplate syncTemplate;
/*     */ 
/*     */   public AsyncRestTemplate()
/*     */   {
/*  80 */     this(new SimpleAsyncTaskExecutor());
/*     */   }
/*     */ 
/*     */   public AsyncRestTemplate(AsyncListenableTaskExecutor taskExecutor)
/*     */   {
/*  90 */     Assert.notNull(taskExecutor, "AsyncTaskExecutor must not be null");
/*  91 */     SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
/*     */ 
/*  93 */     requestFactory.setTaskExecutor(taskExecutor);
/*  94 */     this.syncTemplate = new RestTemplate(requestFactory);
/*  95 */     setAsyncRequestFactory(requestFactory);
/*     */   }
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory asyncRequestFactory)
/*     */   {
/* 108 */     this(asyncRequestFactory, (ClientHttpRequestFactory)asyncRequestFactory);
/*     */   }
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory asyncRequestFactory, ClientHttpRequestFactory syncRequestFactory)
/*     */   {
/* 119 */     this(asyncRequestFactory, new RestTemplate(syncRequestFactory));
/*     */   }
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory requestFactory, RestTemplate restTemplate)
/*     */   {
/* 130 */     Assert.notNull(restTemplate, "'restTemplate' must not be null");
/* 131 */     this.syncTemplate = restTemplate;
/* 132 */     setAsyncRequestFactory(requestFactory);
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 142 */     this.syncTemplate.setErrorHandler(errorHandler);
/*     */   }
/*     */ 
/*     */   public ResponseErrorHandler getErrorHandler()
/*     */   {
/* 147 */     return this.syncTemplate.getErrorHandler();
/*     */   }
/*     */ 
/*     */   public RestOperations getRestOperations()
/*     */   {
/* 152 */     return this.syncTemplate;
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 160 */     this.syncTemplate.setMessageConverters(messageConverters);
/*     */   }
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 167 */     return this.syncTemplate.getMessageConverters();
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(String url, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 177 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 178 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 179 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(String url, Class<T> responseType, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 186 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 187 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 188 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 193 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 194 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 195 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(String url, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 202 */     ResponseExtractor headersExtractor = headersExtractor();
/* 203 */     return execute(url, HttpMethod.HEAD, null, headersExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(String url, Map<String, ?> uriVariables) throws RestClientException
/*     */   {
/* 208 */     ResponseExtractor headersExtractor = headersExtractor();
/* 209 */     return execute(url, HttpMethod.HEAD, null, headersExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(URI url) throws RestClientException
/*     */   {
/* 214 */     ResponseExtractor headersExtractor = headersExtractor();
/* 215 */     return execute(url, HttpMethod.HEAD, null, headersExtractor);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<URI> postForLocation(String url, HttpEntity<?> request, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 223 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 224 */     ResponseExtractor headersExtractor = headersExtractor();
/*     */ 
/* 226 */     ListenableFuture headersFuture = execute(url, HttpMethod.POST, requestCallback, headersExtractor, uriVariables);
/*     */ 
/* 228 */     return extractLocationHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<URI> postForLocation(String url, HttpEntity<?> request, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 234 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 235 */     ResponseExtractor headersExtractor = headersExtractor();
/*     */ 
/* 237 */     ListenableFuture headersFuture = execute(url, HttpMethod.POST, requestCallback, headersExtractor, uriVariables);
/*     */ 
/* 239 */     return extractLocationHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<URI> postForLocation(URI url, HttpEntity<?> request)
/*     */     throws RestClientException
/*     */   {
/* 245 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 246 */     ResponseExtractor headersExtractor = headersExtractor();
/*     */ 
/* 248 */     ListenableFuture headersFuture = execute(url, HttpMethod.POST, requestCallback, headersExtractor);
/*     */ 
/* 249 */     return extractLocationHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   private static ListenableFuture<URI> extractLocationHeader(ListenableFuture<HttpHeaders> headersFuture) {
/* 253 */     return new ListenableFuture()
/*     */     {
/*     */       public void addCallback(final ListenableFutureCallback<? super URI> callback)
/*     */       {
/* 257 */         this.val$headersFuture.addCallback(new ListenableFutureCallback()
/*     */         {
/*     */           public void onSuccess(HttpHeaders result) {
/* 260 */             callback.onSuccess(result.getLocation());
/*     */           }
/*     */ 
/*     */           public void onFailure(Throwable t)
/*     */           {
/* 265 */             callback.onFailure(t);
/*     */           }
/*     */         });
/*     */       }
/*     */ 
/*     */       public boolean cancel(boolean mayInterruptIfRunning)
/*     */       {
/* 272 */         return this.val$headersFuture.cancel(mayInterruptIfRunning);
/*     */       }
/*     */ 
/*     */       public boolean isCancelled() {
/* 276 */         return this.val$headersFuture.isCancelled();
/*     */       }
/*     */ 
/*     */       public boolean isDone() {
/* 280 */         return this.val$headersFuture.isDone();
/*     */       }
/*     */ 
/*     */       public URI get() throws InterruptedException, ExecutionException {
/* 284 */         HttpHeaders headers = (HttpHeaders)this.val$headersFuture.get();
/* 285 */         return headers.getLocation();
/*     */       }
/*     */ 
/*     */       public URI get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException
/*     */       {
/* 290 */         HttpHeaders headers = (HttpHeaders)this.val$headersFuture.get(timeout, unit);
/* 291 */         return headers.getLocation();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(String url, HttpEntity<?> request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 299 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 301 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/*     */ 
/* 302 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(String url, HttpEntity<?> request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 310 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 312 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/*     */ 
/* 313 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(URI url, HttpEntity<?> request, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 320 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 322 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/*     */ 
/* 323 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> put(String url, HttpEntity<?> request, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 331 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 332 */     return execute(url, HttpMethod.PUT, requestCallback, null, uriVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> put(String url, HttpEntity<?> request, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 338 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 339 */     return execute(url, HttpMethod.PUT, requestCallback, null, uriVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> put(URI url, HttpEntity<?> request) throws RestClientException
/*     */   {
/* 344 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 345 */     return execute(url, HttpMethod.PUT, requestCallback, null);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> delete(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 353 */     return execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> delete(String url, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 359 */     return execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> delete(URI url) throws RestClientException
/*     */   {
/* 364 */     return execute(url, HttpMethod.DELETE, null, null);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(String url, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 371 */     ResponseExtractor headersExtractor = headersExtractor();
/* 372 */     ListenableFuture headersFuture = execute(url, HttpMethod.OPTIONS, null, headersExtractor, uriVariables);
/* 373 */     return extractAllowHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(String url, Map<String, ?> uriVariables) throws RestClientException
/*     */   {
/* 378 */     ResponseExtractor headersExtractor = headersExtractor();
/* 379 */     ListenableFuture headersFuture = execute(url, HttpMethod.OPTIONS, null, headersExtractor, uriVariables);
/* 380 */     return extractAllowHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(URI url) throws RestClientException
/*     */   {
/* 385 */     ResponseExtractor headersExtractor = headersExtractor();
/* 386 */     ListenableFuture headersFuture = execute(url, HttpMethod.OPTIONS, null, headersExtractor);
/* 387 */     return extractAllowHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   private static ListenableFuture<Set<HttpMethod>> extractAllowHeader(ListenableFuture<HttpHeaders> headersFuture) {
/* 391 */     return new ListenableFuture()
/*     */     {
/*     */       public void addCallback(final ListenableFutureCallback<? super Set<HttpMethod>> callback)
/*     */       {
/* 396 */         this.val$headersFuture.addCallback(new ListenableFutureCallback()
/*     */         {
/*     */           public void onSuccess(HttpHeaders result) {
/* 399 */             callback.onSuccess(result.getAllow());
/*     */           }
/*     */ 
/*     */           public void onFailure(Throwable t)
/*     */           {
/* 404 */             callback.onFailure(t);
/*     */           }
/*     */         });
/*     */       }
/*     */ 
/*     */       public boolean cancel(boolean mayInterruptIfRunning)
/*     */       {
/* 411 */         return this.val$headersFuture.cancel(mayInterruptIfRunning);
/*     */       }
/*     */ 
/*     */       public boolean isCancelled() {
/* 415 */         return this.val$headersFuture.isCancelled();
/*     */       }
/*     */ 
/*     */       public boolean isDone() {
/* 419 */         return this.val$headersFuture.isDone();
/*     */       }
/*     */ 
/*     */       public Set<HttpMethod> get() throws InterruptedException, ExecutionException {
/* 423 */         HttpHeaders headers = (HttpHeaders)this.val$headersFuture.get();
/* 424 */         return headers.getAllow();
/*     */       }
/*     */ 
/*     */       public Set<HttpMethod> get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException
/*     */       {
/* 429 */         HttpHeaders headers = (HttpHeaders)this.val$headersFuture.get(timeout, unit);
/* 430 */         return headers.getAllow();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 443 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/*     */ 
/* 445 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/*     */ 
/* 446 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 454 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/*     */ 
/* 456 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/*     */ 
/* 457 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 465 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/*     */ 
/* 467 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/*     */ 
/* 468 */     return execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 475 */     Type type = responseType.getType();
/* 476 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/*     */ 
/* 478 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/*     */ 
/* 479 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 486 */     Type type = responseType.getType();
/* 487 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/*     */ 
/* 489 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/*     */ 
/* 490 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 497 */     Type type = responseType.getType();
/* 498 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/*     */ 
/* 500 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/*     */ 
/* 501 */     return execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(String url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 512 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 513 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(String url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 521 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 522 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(URI url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 530 */     return doExecute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   protected <T> ListenableFuture<T> doExecute(URI url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 548 */     Assert.notNull(url, "'url' must not be null");
/* 549 */     Assert.notNull(method, "'method' must not be null");
/*     */     try {
/* 551 */       AsyncClientHttpRequest request = createAsyncRequest(url, method);
/* 552 */       if (requestCallback != null) {
/* 553 */         requestCallback.doWithRequest(request);
/*     */       }
/* 555 */       ListenableFuture responseFuture = request.executeAsync();
/* 556 */       return new ResponseExtractorFuture(method, url, responseFuture, responseExtractor);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 561 */       throw new ResourceAccessException("I/O error on " + method.name() + " request for \"" + url + "\":" + ex
/* 561 */         .getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void logResponseStatus(HttpMethod method, URI url, ClientHttpResponse response) {
/* 566 */     if (this.logger.isDebugEnabled())
/*     */       try {
/* 568 */         this.logger.debug("Async " + method.name() + " request for \"" + url + "\" resulted in " + response
/* 569 */           .getStatusCode() + " (" + response
/* 570 */           .getStatusText() + ")");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   private void handleResponseError(HttpMethod method, URI url, ClientHttpResponse response) throws IOException
/*     */   {
/* 579 */     if (this.logger.isWarnEnabled()) {
/*     */       try {
/* 581 */         this.logger.warn("Async " + method.name() + " request for \"" + url + "\" resulted in " + response
/* 582 */           .getStatusCode() + " (" + response
/* 583 */           .getStatusText() + "); invoking error handler");
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/* 589 */     getErrorHandler().handleError(response);
/*     */   }
/*     */ 
/*     */   protected <T> AsyncRequestCallback acceptHeaderRequestCallback(Class<T> responseType)
/*     */   {
/* 598 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.acceptHeaderRequestCallback(responseType));
/*     */   }
/*     */ 
/*     */   protected <T> AsyncRequestCallback httpEntityCallback(HttpEntity<T> requestBody)
/*     */   {
/* 606 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.httpEntityCallback(requestBody));
/*     */   }
/*     */ 
/*     */   protected <T> AsyncRequestCallback httpEntityCallback(HttpEntity<T> request, Type responseType)
/*     */   {
/* 614 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.httpEntityCallback(request, responseType));
/*     */   }
/*     */ 
/*     */   protected <T> ResponseExtractor<ResponseEntity<T>> responseEntityExtractor(Type responseType)
/*     */   {
/* 621 */     return this.syncTemplate.responseEntityExtractor(responseType);
/*     */   }
/*     */ 
/*     */   protected ResponseExtractor<HttpHeaders> headersExtractor()
/*     */   {
/* 628 */     return this.syncTemplate.headersExtractor();
/*     */   }
/*     */ 
/*     */   private static class AsyncRequestCallbackAdapter
/*     */     implements AsyncRequestCallback
/*     */   {
/*     */     private final RequestCallback adaptee;
/*     */ 
/*     */     public AsyncRequestCallbackAdapter(RequestCallback requestCallback)
/*     */     {
/* 694 */       this.adaptee = requestCallback;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(final AsyncClientHttpRequest request) throws IOException
/*     */     {
/* 699 */       if (this.adaptee != null)
/* 700 */         this.adaptee.doWithRequest(new ClientHttpRequest()
/*     */         {
/*     */           public ClientHttpResponse execute() throws IOException {
/* 703 */             throw new UnsupportedOperationException("execute not supported");
/*     */           }
/*     */ 
/*     */           public OutputStream getBody() throws IOException {
/* 707 */             return request.getBody();
/*     */           }
/*     */ 
/*     */           public HttpMethod getMethod() {
/* 711 */             return request.getMethod();
/*     */           }
/*     */ 
/*     */           public URI getURI() {
/* 715 */             return request.getURI();
/*     */           }
/*     */ 
/*     */           public HttpHeaders getHeaders() {
/* 719 */             return request.getHeaders();
/*     */           }
/*     */         });
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResponseExtractorFuture<T> extends ListenableFutureAdapter<T, ClientHttpResponse>
/*     */   {
/*     */     private final HttpMethod method;
/*     */     private final URI url;
/*     */     private final ResponseExtractor<T> responseExtractor;
/*     */ 
/*     */     public ResponseExtractorFuture(URI method, ListenableFuture<ClientHttpResponse> url, ResponseExtractor<T> clientHttpResponseFuture)
/*     */     {
/* 647 */       super();
/* 648 */       this.method = method;
/* 649 */       this.url = url;
/* 650 */       this.responseExtractor = responseExtractor;
/*     */     }
/*     */ 
/*     */     protected final T adapt(ClientHttpResponse response) throws ExecutionException
/*     */     {
/*     */       try {
/* 656 */         if (!AsyncRestTemplate.this.getErrorHandler().hasError(response)) {
/* 657 */           AsyncRestTemplate.this.logResponseStatus(this.method, this.url, response);
/*     */         }
/*     */         else {
/* 660 */           AsyncRestTemplate.this.handleResponseError(this.method, this.url, response);
/*     */         }
/* 662 */         return convertResponse(response);
/*     */       }
/*     */       catch (IOException ex) {
/* 665 */         throw new ExecutionException(ex);
/*     */       }
/*     */       finally {
/* 668 */         if (response != null)
/* 669 */           response.close();
/*     */       }
/*     */     }
/*     */ 
/*     */     protected T convertResponse(ClientHttpResponse response) throws IOException
/*     */     {
/* 675 */       return this.responseExtractor != null ? this.responseExtractor.extractData(response) : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.AsyncRestTemplate
 * JD-Core Version:    0.6.2
 */