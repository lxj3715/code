/*    */ package org.springframework.web.client;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatus;
/*    */ 
/*    */ public class HttpServerErrorException extends HttpStatusCodeException
/*    */ {
/*    */   private static final long serialVersionUID = -2915754006618138282L;
/*    */ 
/*    */   public HttpServerErrorException(HttpStatus statusCode)
/*    */   {
/* 42 */     super(statusCode);
/*    */   }
/*    */ 
/*    */   public HttpServerErrorException(HttpStatus statusCode, String statusText)
/*    */   {
/* 52 */     super(statusCode, statusText);
/*    */   }
/*    */ 
/*    */   public HttpServerErrorException(HttpStatus statusCode, String statusText, byte[] responseBody, Charset responseCharset)
/*    */   {
/* 66 */     super(statusCode, statusText, responseBody, responseCharset);
/*    */   }
/*    */ 
/*    */   public HttpServerErrorException(HttpStatus statusCode, String statusText, HttpHeaders responseHeaders, byte[] responseBody, Charset responseCharset)
/*    */   {
/* 81 */     super(statusCode, statusText, responseHeaders, responseBody, responseCharset);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.HttpServerErrorException
 * JD-Core Version:    0.6.2
 */