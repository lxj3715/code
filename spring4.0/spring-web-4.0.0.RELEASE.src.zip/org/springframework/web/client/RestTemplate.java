/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.client.support.InterceptingHttpAccessor;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.util.UriTemplate;
/*     */ 
/*     */ public class RestTemplate extends InterceptingHttpAccessor
/*     */   implements RestOperations
/*     */ {
/* 128 */   private static boolean romePresent = ClassUtils.isPresent("com.sun.syndication.feed.WireFeed", RestTemplate.class
/* 128 */     .getClassLoader());
/*     */ 
/* 131 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", RestTemplate.class
/* 131 */     .getClassLoader());
/*     */ 
/* 134 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", RestTemplate.class
/* 134 */     .getClassLoader())) && 
/* 135 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", RestTemplate.class
/* 135 */     .getClassLoader()));
/*     */ 
/* 138 */   private static final boolean jacksonPresent = (ClassUtils.isPresent("org.codehaus.jackson.map.ObjectMapper", RestTemplate.class
/* 138 */     .getClassLoader())) && 
/* 139 */     (ClassUtils.isPresent("org.codehaus.jackson.JsonGenerator", RestTemplate.class
/* 139 */     .getClassLoader()));
/*     */ 
/* 142 */   private final ResponseExtractor<HttpHeaders> headersExtractor = new HeadersExtractor(null);
/*     */ 
/* 144 */   private List<HttpMessageConverter<?>> messageConverters = new ArrayList();
/*     */ 
/* 146 */   private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();
/*     */ 
/*     */   public RestTemplate()
/*     */   {
/* 154 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 155 */     this.messageConverters.add(new StringHttpMessageConverter());
/* 156 */     this.messageConverters.add(new ResourceHttpMessageConverter());
/* 157 */     this.messageConverters.add(new SourceHttpMessageConverter());
/* 158 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/* 159 */     if (romePresent) {
/* 160 */       this.messageConverters.add(new AtomFeedHttpMessageConverter());
/* 161 */       this.messageConverters.add(new RssChannelHttpMessageConverter());
/*     */     }
/* 163 */     if (jaxb2Present) {
/* 164 */       this.messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*     */     }
/* 166 */     if (jackson2Present) {
/* 167 */       this.messageConverters.add(new MappingJackson2HttpMessageConverter());
/*     */     }
/* 169 */     else if (jacksonPresent)
/* 170 */       this.messageConverters.add(new MappingJacksonHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public RestTemplate(ClientHttpRequestFactory requestFactory)
/*     */   {
/* 181 */     this();
/* 182 */     setRequestFactory(requestFactory);
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 191 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/* 192 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 199 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 207 */     Assert.notNull(errorHandler, "'errorHandler' must not be null");
/* 208 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   public ResponseErrorHandler getErrorHandler()
/*     */   {
/* 215 */     return this.errorHandler;
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 223 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */ 
/* 225 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 225 */       getMessageConverters(), this.logger);
/* 226 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 231 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */ 
/* 233 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 233 */       getMessageConverters(), this.logger);
/* 234 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 239 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */ 
/* 241 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 241 */       getMessageConverters(), this.logger);
/* 242 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 248 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 249 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 250 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 256 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 257 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 258 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 263 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 264 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 265 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 272 */     ResponseExtractor headersExtractor = headersExtractor();
/* 273 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 278 */     ResponseExtractor headersExtractor = headersExtractor();
/* 279 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(URI url) throws RestClientException
/*     */   {
/* 284 */     ResponseExtractor headersExtractor = headersExtractor();
/* 285 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor);
/*     */   }
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 292 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 293 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor, urlVariables);
/* 294 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 300 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 301 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor, urlVariables);
/* 302 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public URI postForLocation(URI url, Object request) throws RestClientException
/*     */   {
/* 307 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 308 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor);
/* 309 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 315 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 317 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 317 */       getMessageConverters(), this.logger);
/* 318 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 324 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 326 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 326 */       getMessageConverters(), this.logger);
/* 327 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(URI url, Object request, Class<T> responseType) throws RestClientException
/*     */   {
/* 332 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 334 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 334 */       getMessageConverters());
/* 335 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 342 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 343 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 344 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 351 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 352 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 353 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(URI url, Object request, Class<T> responseType) throws RestClientException
/*     */   {
/* 358 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 359 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 360 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public void put(String url, Object request, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 367 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 368 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void put(String url, Object request, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 373 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 374 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void put(URI url, Object request) throws RestClientException
/*     */   {
/* 379 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 380 */     execute(url, HttpMethod.PUT, requestCallback, null);
/*     */   }
/*     */ 
/*     */   public void delete(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 387 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void delete(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 392 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void delete(URI url) throws RestClientException
/*     */   {
/* 397 */     execute(url, HttpMethod.DELETE, null, null);
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 404 */     ResponseExtractor headersExtractor = headersExtractor();
/* 405 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor, urlVariables);
/* 406 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 411 */     ResponseExtractor headersExtractor = headersExtractor();
/* 412 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor, urlVariables);
/* 413 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(URI url) throws RestClientException
/*     */   {
/* 418 */     ResponseExtractor headersExtractor = headersExtractor();
/* 419 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor);
/* 420 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 429 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 430 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 431 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 438 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 439 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 440 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 447 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 448 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 449 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 456 */     Type type = responseType.getType();
/* 457 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 458 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 459 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 466 */     Type type = responseType.getType();
/* 467 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 468 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 469 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 476 */     Type type = responseType.getType();
/* 477 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 478 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 479 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 488 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 489 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 496 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 497 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 504 */     return doExecute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 519 */     Assert.notNull(url, "'url' must not be null");
/* 520 */     Assert.notNull(method, "'method' must not be null");
/* 521 */     ClientHttpResponse response = null;
/*     */     try {
/* 523 */       ClientHttpRequest request = createRequest(url, method);
/* 524 */       if (requestCallback != null) {
/* 525 */         requestCallback.doWithRequest(request);
/*     */       }
/* 527 */       response = request.execute();
/* 528 */       if (!getErrorHandler().hasError(response)) {
/* 529 */         logResponseStatus(method, url, response);
/*     */       }
/*     */       else
/* 532 */         handleResponseError(method, url, response);
/*     */       Object localObject1;
/* 534 */       if (responseExtractor != null) {
/* 535 */         return responseExtractor.extractData(response);
/*     */       }
/*     */ 
/* 538 */       return null;
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 543 */       throw new ResourceAccessException("I/O error on " + method.name() + " request for \"" + url + "\":" + ex
/* 543 */         .getMessage(), ex);
/*     */     }
/*     */     finally {
/* 546 */       if (response != null)
/* 547 */         response.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void logResponseStatus(HttpMethod method, URI url, ClientHttpResponse response)
/*     */   {
/* 553 */     if (this.logger.isDebugEnabled())
/*     */       try {
/* 555 */         this.logger.debug(method.name() + " request for \"" + url + "\" resulted in " + response
/* 556 */           .getStatusCode() + " (" + response
/* 557 */           .getStatusText() + ")");
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   private void handleResponseError(HttpMethod method, URI url, ClientHttpResponse response) throws IOException
/*     */   {
/* 566 */     if (this.logger.isWarnEnabled()) {
/*     */       try {
/* 568 */         this.logger.warn(method
/* 569 */           .name() + " request for \"" + url + "\" resulted in " + response.getStatusCode() + " (" + response
/* 570 */           .getStatusText() + "); invoking error handler");
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*     */     }
/* 576 */     getErrorHandler().handleError(response);
/*     */   }
/*     */ 
/*     */   protected <T> RequestCallback acceptHeaderRequestCallback(Class<T> responseType)
/*     */   {
/* 585 */     return new AcceptHeaderRequestCallback(responseType, null);
/*     */   }
/*     */ 
/*     */   protected <T> RequestCallback httpEntityCallback(Object requestBody)
/*     */   {
/* 593 */     return new HttpEntityRequestCallback(requestBody, null);
/*     */   }
/*     */ 
/*     */   protected <T> RequestCallback httpEntityCallback(Object requestBody, Type responseType)
/*     */   {
/* 602 */     return new HttpEntityRequestCallback(requestBody, responseType, null);
/*     */   }
/*     */ 
/*     */   protected <T> ResponseExtractor<ResponseEntity<T>> responseEntityExtractor(Type responseType)
/*     */   {
/* 609 */     return new ResponseEntityResponseExtractor(responseType);
/*     */   }
/*     */ 
/*     */   protected ResponseExtractor<HttpHeaders> headersExtractor()
/*     */   {
/* 616 */     return this.headersExtractor;
/*     */   }
/*     */ 
/*     */   private static class HeadersExtractor
/*     */     implements ResponseExtractor<HttpHeaders>
/*     */   {
/*     */     public HttpHeaders extractData(ClientHttpResponse response)
/*     */       throws IOException
/*     */     {
/* 790 */       return response.getHeaders();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResponseEntityResponseExtractor<T>
/*     */     implements ResponseExtractor<ResponseEntity<T>>
/*     */   {
/*     */     private final HttpMessageConverterExtractor<T> delegate;
/*     */ 
/*     */     public ResponseEntityResponseExtractor(Type responseType)
/*     */     {
/* 763 */       if ((responseType != null) && (!Void.class.equals(responseType)))
/* 764 */         this.delegate = new HttpMessageConverterExtractor(responseType, RestTemplate.this.getMessageConverters(), RestTemplate.this.logger);
/*     */       else
/* 766 */         this.delegate = null;
/*     */     }
/*     */ 
/*     */     public ResponseEntity<T> extractData(ClientHttpResponse response)
/*     */       throws IOException
/*     */     {
/* 772 */       if (this.delegate != null) {
/* 773 */         Object body = this.delegate.extractData(response);
/* 774 */         return new ResponseEntity(body, response.getHeaders(), response.getStatusCode());
/*     */       }
/*     */ 
/* 777 */       return new ResponseEntity(response.getHeaders(), response.getStatusCode());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class HttpEntityRequestCallback extends RestTemplate.AcceptHeaderRequestCallback
/*     */   {
/*     */     private final HttpEntity<?> requestEntity;
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody)
/*     */     {
/* 689 */       this(requestBody, null);
/*     */     }
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody, Type responseType) {
/* 693 */       super(responseType, null);
/* 694 */       if ((requestBody instanceof HttpEntity)) {
/* 695 */         this.requestEntity = ((HttpEntity)requestBody);
/*     */       }
/* 697 */       else if (requestBody != null) {
/* 698 */         this.requestEntity = new HttpEntity(requestBody);
/*     */       }
/*     */       else
/* 701 */         this.requestEntity = HttpEntity.EMPTY;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(ClientHttpRequest httpRequest)
/*     */       throws IOException
/*     */     {
/* 708 */       super.doWithRequest(httpRequest);
/* 709 */       if (!this.requestEntity.hasBody()) {
/* 710 */         HttpHeaders httpHeaders = httpRequest.getHeaders();
/* 711 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 712 */         if (!requestHeaders.isEmpty()) {
/* 713 */           httpHeaders.putAll(requestHeaders);
/*     */         }
/* 715 */         if (httpHeaders.getContentLength() == -1L)
/* 716 */           httpHeaders.setContentLength(0L);
/*     */       }
/*     */       else
/*     */       {
/* 720 */         Object requestBody = this.requestEntity.getBody();
/* 721 */         Class requestType = requestBody.getClass();
/* 722 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 723 */         MediaType requestContentType = requestHeaders.getContentType();
/* 724 */         for (HttpMessageConverter messageConverter : RestTemplate.this.getMessageConverters()) {
/* 725 */           if (messageConverter.canWrite(requestType, requestContentType)) {
/* 726 */             if (!requestHeaders.isEmpty()) {
/* 727 */               httpRequest.getHeaders().putAll(requestHeaders);
/*     */             }
/* 729 */             if (RestTemplate.this.logger.isDebugEnabled()) {
/* 730 */               if (requestContentType != null) {
/* 731 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] as \"" + requestContentType + "\" using [" + messageConverter + "]");
/*     */               }
/*     */               else
/*     */               {
/* 735 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] using [" + messageConverter + "]");
/*     */               }
/*     */             }
/*     */ 
/* 739 */             messageConverter.write(requestBody, requestContentType, httpRequest);
/*     */ 
/* 741 */             return;
/*     */           }
/*     */         }
/*     */ 
/* 745 */         String message = "Could not write request: no suitable HttpMessageConverter found for request type [" + requestType
/* 745 */           .getName() + "]";
/* 746 */         if (requestContentType != null) {
/* 747 */           message = message + " and content type [" + requestContentType + "]";
/*     */         }
/* 749 */         throw new RestClientException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AcceptHeaderRequestCallback
/*     */     implements RequestCallback
/*     */   {
/*     */     private final Type responseType;
/*     */ 
/*     */     private AcceptHeaderRequestCallback(Type responseType)
/*     */     {
/* 628 */       this.responseType = responseType;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(ClientHttpRequest request) throws IOException
/*     */     {
/* 633 */       if (this.responseType != null) {
/* 634 */         Class responseClass = null;
/* 635 */         if ((this.responseType instanceof Class)) {
/* 636 */           responseClass = (Class)this.responseType;
/*     */         }
/*     */ 
/* 639 */         List allSupportedMediaTypes = new ArrayList();
/* 640 */         for (HttpMessageConverter converter : RestTemplate.this.getMessageConverters()) {
/* 641 */           if (responseClass != null) {
/* 642 */             if (converter.canRead(responseClass, null)) {
/* 643 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/* 646 */           else if ((converter instanceof GenericHttpMessageConverter))
/*     */           {
/* 648 */             GenericHttpMessageConverter genericConverter = (GenericHttpMessageConverter)converter;
/* 649 */             if (genericConverter.canRead(this.responseType, null, null)) {
/* 650 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 655 */         if (!allSupportedMediaTypes.isEmpty()) {
/* 656 */           MediaType.sortBySpecificity(allSupportedMediaTypes);
/* 657 */           if (RestTemplate.this.logger.isDebugEnabled()) {
/* 658 */             RestTemplate.this.logger.debug("Setting request Accept header to " + allSupportedMediaTypes);
/*     */           }
/*     */ 
/* 661 */           request.getHeaders().setAccept(allSupportedMediaTypes);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private List<MediaType> getSupportedMediaTypes(HttpMessageConverter<?> messageConverter) {
/* 667 */       List supportedMediaTypes = messageConverter.getSupportedMediaTypes();
/* 668 */       List result = new ArrayList(supportedMediaTypes.size());
/* 669 */       for (MediaType supportedMediaType : supportedMediaTypes) {
/* 670 */         if (supportedMediaType.getCharSet() != null)
/*     */         {
/* 672 */           supportedMediaType = new MediaType(supportedMediaType
/* 672 */             .getType(), supportedMediaType.getSubtype());
/*     */         }
/* 674 */         result.add(supportedMediaType);
/*     */       }
/* 676 */       return result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.RestTemplate
 * JD-Core Version:    0.6.2
 */