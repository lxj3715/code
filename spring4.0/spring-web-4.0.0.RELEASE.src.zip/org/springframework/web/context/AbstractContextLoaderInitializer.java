/*    */ package org.springframework.web.context;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.WebApplicationInitializer;
/*    */ 
/*    */ public abstract class AbstractContextLoaderInitializer
/*    */   implements WebApplicationInitializer
/*    */ {
/* 42 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public void onStartup(ServletContext servletContext) throws ServletException
/*    */   {
/* 46 */     registerContextLoaderListener(servletContext);
/*    */   }
/*    */ 
/*    */   protected void registerContextLoaderListener(ServletContext servletContext)
/*    */   {
/* 56 */     WebApplicationContext rootAppContext = createRootApplicationContext();
/* 57 */     if (rootAppContext != null) {
/* 58 */       servletContext.addListener(new ContextLoaderListener(rootAppContext));
/*    */     }
/*    */     else
/* 61 */       this.logger.debug("No ContextLoaderListener registered, as createRootApplicationContext() did not return an application context");
/*    */   }
/*    */ 
/*    */   protected abstract WebApplicationContext createRootApplicationContext();
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.AbstractContextLoaderInitializer
 * JD-Core Version:    0.6.2
 */