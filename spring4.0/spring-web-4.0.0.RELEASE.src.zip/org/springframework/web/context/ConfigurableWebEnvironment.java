package org.springframework.web.context;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import org.springframework.core.env.ConfigurableEnvironment;

public abstract interface ConfigurableWebEnvironment extends ConfigurableEnvironment
{
  public abstract void initPropertySources(ServletContext paramServletContext, ServletConfig paramServletConfig);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ConfigurableWebEnvironment
 * JD-Core Version:    0.6.2
 */