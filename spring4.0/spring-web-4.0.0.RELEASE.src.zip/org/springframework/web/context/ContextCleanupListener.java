/*    */ package org.springframework.web.context;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ 
/*    */ public class ContextCleanupListener
/*    */   implements ServletContextListener
/*    */ {
/* 43 */   private static final Log logger = LogFactory.getLog(ContextCleanupListener.class);
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent event)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent event)
/*    */   {
/* 52 */     cleanupAttributes(event.getServletContext());
/*    */   }
/*    */ 
/*    */   static void cleanupAttributes(ServletContext sc)
/*    */   {
/* 62 */     Enumeration attrNames = sc.getAttributeNames();
/* 63 */     while (attrNames.hasMoreElements()) {
/* 64 */       String attrName = (String)attrNames.nextElement();
/* 65 */       if (attrName.startsWith("org.springframework.")) {
/* 66 */         Object attrValue = sc.getAttribute(attrName);
/* 67 */         if ((attrValue instanceof DisposableBean))
/*    */           try {
/* 69 */             ((DisposableBean)attrValue).destroy();
/*    */           }
/*    */           catch (Throwable ex) {
/* 72 */             logger.error("Couldn't invoke destroy method of attribute with name '" + attrName + "'", ex);
/*    */           }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ContextCleanupListener
 * JD-Core Version:    0.6.2
 */