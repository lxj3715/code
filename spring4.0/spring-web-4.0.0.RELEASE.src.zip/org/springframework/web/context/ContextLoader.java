/*     */ package org.springframework.web.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*     */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.access.ContextSingletonBeanFactoryLocator;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ContextLoader
/*     */ {
/*     */   public static final String CONTEXT_CLASS_PARAM = "contextClass";
/*     */   public static final String CONTEXT_ID_PARAM = "contextId";
/*     */   public static final String CONTEXT_INITIALIZER_CLASSES_PARAM = "contextInitializerClasses";
/*     */   public static final String CONFIG_LOCATION_PARAM = "contextConfigLocation";
/*     */   public static final String LOCATOR_FACTORY_SELECTOR_PARAM = "locatorFactorySelector";
/*     */   public static final String LOCATOR_FACTORY_KEY_PARAM = "parentContextKey";
/*     */   private static final String DEFAULT_STRATEGIES_PATH = "ContextLoader.properties";
/*     */   private static final Properties defaultStrategies;
/* 175 */   private static final Map<ClassLoader, WebApplicationContext> currentContextPerThread = new ConcurrentHashMap(1);
/*     */   private static volatile WebApplicationContext currentContext;
/*     */   private WebApplicationContext context;
/*     */   private BeanFactoryReference parentContextRef;
/*     */ 
/*     */   public ContextLoader()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContextLoader(WebApplicationContext context)
/*     */   {
/* 248 */     this.context = context;
/*     */   }
/*     */ 
/*     */   public WebApplicationContext initWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 263 */     if (servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE) != null) {
/* 264 */       throw new IllegalStateException("Cannot initialize context because there is already a root application context present - check whether you have multiple ContextLoader* definitions in your web.xml!");
/*     */     }
/*     */ 
/* 269 */     Log logger = LogFactory.getLog(ContextLoader.class);
/* 270 */     servletContext.log("Initializing Spring root WebApplicationContext");
/* 271 */     if (logger.isInfoEnabled()) {
/* 272 */       logger.info("Root WebApplicationContext: initialization started");
/*     */     }
/* 274 */     long startTime = System.currentTimeMillis();
/*     */     try
/*     */     {
/* 279 */       if (this.context == null) {
/* 280 */         this.context = createWebApplicationContext(servletContext);
/*     */       }
/* 282 */       if ((this.context instanceof ConfigurableWebApplicationContext)) {
/* 283 */         ConfigurableWebApplicationContext cwac = (ConfigurableWebApplicationContext)this.context;
/* 284 */         if (!cwac.isActive())
/*     */         {
/* 287 */           if (cwac.getParent() == null)
/*     */           {
/* 290 */             ApplicationContext parent = loadParentContext(servletContext);
/* 291 */             cwac.setParent(parent);
/*     */           }
/* 293 */           configureAndRefreshWebApplicationContext(cwac, servletContext);
/*     */         }
/*     */       }
/* 296 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, this.context);
/*     */ 
/* 298 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 299 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 300 */         currentContext = this.context;
/*     */       }
/* 302 */       else if (ccl != null) {
/* 303 */         currentContextPerThread.put(ccl, this.context);
/*     */       }
/*     */ 
/* 306 */       if (logger.isDebugEnabled()) {
/* 307 */         logger.debug("Published root WebApplicationContext as ServletContext attribute with name [" + WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE + "]");
/*     */       }
/*     */ 
/* 310 */       if (logger.isInfoEnabled()) {
/* 311 */         long elapsedTime = System.currentTimeMillis() - startTime;
/* 312 */         logger.info("Root WebApplicationContext: initialization completed in " + elapsedTime + " ms");
/*     */       }
/*     */ 
/* 315 */       return this.context;
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 318 */       logger.error("Context initialization failed", ex);
/* 319 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, ex);
/* 320 */       throw ex;
/*     */     }
/*     */     catch (Error err) {
/* 323 */       logger.error("Context initialization failed", err);
/* 324 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, err);
/* 325 */       throw err;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc)
/*     */   {
/* 342 */     Class contextClass = determineContextClass(sc);
/* 343 */     if (!ConfigurableWebApplicationContext.class.isAssignableFrom(contextClass))
/*     */     {
/* 345 */       throw new ApplicationContextException("Custom context class [" + contextClass.getName() + "] is not of type [" + ConfigurableWebApplicationContext.class
/* 345 */         .getName() + "]");
/*     */     }
/* 347 */     return (ConfigurableWebApplicationContext)BeanUtils.instantiateClass(contextClass);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc, ApplicationContext parent)
/*     */   {
/* 357 */     return createWebApplicationContext(sc);
/*     */   }
/*     */ 
/*     */   protected void configureAndRefreshWebApplicationContext(ConfigurableWebApplicationContext wac, ServletContext sc) {
/* 361 */     if (ObjectUtils.identityToString(wac).equals(wac.getId()))
/*     */     {
/* 364 */       String idParam = sc.getInitParameter("contextId");
/* 365 */       if (idParam != null) {
/* 366 */         wac.setId(idParam);
/*     */       }
/*     */       else
/*     */       {
/* 370 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + 
/* 371 */           ObjectUtils.getDisplayString(sc
/* 371 */           .getContextPath()));
/*     */       }
/*     */     }
/*     */ 
/* 375 */     wac.setServletContext(sc);
/* 376 */     String initParameter = sc.getInitParameter("contextConfigLocation");
/* 377 */     if (initParameter != null) {
/* 378 */       wac.setConfigLocation(initParameter);
/*     */     }
/* 380 */     customizeContext(sc, wac);
/* 381 */     wac.refresh();
/*     */   }
/*     */ 
/*     */   protected Class<?> determineContextClass(ServletContext servletContext)
/*     */   {
/* 393 */     String contextClassName = servletContext.getInitParameter("contextClass");
/* 394 */     if (contextClassName != null) {
/*     */       try {
/* 396 */         return ClassUtils.forName(contextClassName, ClassUtils.getDefaultClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 399 */         throw new ApplicationContextException("Failed to load custom context class [" + contextClassName + "]", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 404 */     contextClassName = defaultStrategies.getProperty(WebApplicationContext.class.getName());
/*     */     try {
/* 406 */       return ClassUtils.forName(contextClassName, ContextLoader.class.getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 409 */       throw new ApplicationContextException("Failed to load default context class [" + contextClassName + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> determineContextInitializerClasses(ServletContext servletContext)
/*     */   {
/* 424 */     String classNames = servletContext.getInitParameter("contextInitializerClasses");
/* 425 */     List classes = new ArrayList();
/*     */ 
/* 427 */     if (classNames != null) {
/* 428 */       for (String className : StringUtils.tokenizeToStringArray(classNames, ",")) {
/*     */         try {
/* 430 */           Class clazz = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/* 431 */           Assert.isAssignable(ApplicationContextInitializer.class, clazz, "class [" + className + "] must implement ApplicationContextInitializer");
/*     */ 
/* 433 */           classes.add(clazz);
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 436 */           throw new ApplicationContextException("Failed to load context initializer class [" + className + "]", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 441 */     return classes;
/*     */   }
/*     */ 
/*     */   protected void customizeContext(ServletContext servletContext, ConfigurableWebApplicationContext applicationContext)
/*     */   {
/* 464 */     List initializerClasses = determineContextInitializerClasses(servletContext);
/*     */ 
/* 465 */     if (initializerClasses.isEmpty())
/*     */     {
/* 467 */       return;
/*     */     }
/*     */ 
/* 470 */     Class contextClass = applicationContext.getClass();
/* 471 */     ArrayList initializerInstances = new ArrayList();
/*     */ 
/* 474 */     for (Iterator localIterator = initializerClasses.iterator(); localIterator.hasNext(); ) { initializerClass = (Class)localIterator.next();
/*     */ 
/* 476 */       Class initializerContextClass = GenericTypeResolver.resolveTypeArgument(initializerClass, ApplicationContextInitializer.class);
/*     */ 
/* 477 */       if (initializerContextClass != null) {
/* 478 */         Assert.isAssignable(initializerContextClass, contextClass, String.format("Could not add context initializer [%s] as its generic parameter [%s] is not assignable from the type of application context used by this context loader [%s]: ", new Object[] { initializerClass
/* 481 */           .getName(), initializerContextClass.getName(), contextClass
/* 482 */           .getName() }));
/*     */       }
/* 484 */       initializerInstances.add(BeanUtils.instantiateClass(initializerClass));
/*     */     }
/*     */     Class initializerClass;
/* 487 */     ConfigurableEnvironment env = applicationContext.getEnvironment();
/* 488 */     if ((env instanceof ConfigurableWebEnvironment)) {
/* 489 */       ((ConfigurableWebEnvironment)env).initPropertySources(servletContext, null);
/*     */     }
/*     */ 
/* 492 */     AnnotationAwareOrderComparator.sort(initializerInstances);
/* 493 */     for (ApplicationContextInitializer initializer : initializerInstances)
/* 494 */       initializer.initialize(applicationContext);
/*     */   }
/*     */ 
/*     */   protected ApplicationContext loadParentContext(ServletContext servletContext)
/*     */   {
/* 519 */     ApplicationContext parentContext = null;
/* 520 */     String locatorFactorySelector = servletContext.getInitParameter("locatorFactorySelector");
/* 521 */     String parentContextKey = servletContext.getInitParameter("parentContextKey");
/*     */ 
/* 523 */     if (parentContextKey != null)
/*     */     {
/* 525 */       BeanFactoryLocator locator = ContextSingletonBeanFactoryLocator.getInstance(locatorFactorySelector);
/* 526 */       Log logger = LogFactory.getLog(ContextLoader.class);
/* 527 */       if (logger.isDebugEnabled()) {
/* 528 */         logger.debug("Getting parent context definition: using parent context key of '" + parentContextKey + "' with BeanFactoryLocator");
/*     */       }
/*     */ 
/* 531 */       this.parentContextRef = locator.useBeanFactory(parentContextKey);
/* 532 */       parentContext = (ApplicationContext)this.parentContextRef.getFactory();
/*     */     }
/*     */ 
/* 535 */     return parentContext;
/*     */   }
/*     */ 
/*     */   public void closeWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 548 */     servletContext.log("Closing Spring root WebApplicationContext");
/*     */     try {
/* 550 */       if ((this.context instanceof ConfigurableWebApplicationContext)) {
/* 551 */         ((ConfigurableWebApplicationContext)this.context).close();
/*     */       }
/*     */ 
/* 555 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 556 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 557 */         currentContext = null;
/*     */       }
/* 559 */       else if (ccl != null) {
/* 560 */         currentContextPerThread.remove(ccl);
/*     */       }
/* 562 */       servletContext.removeAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 563 */       if (this.parentContextRef != null)
/* 564 */         this.parentContextRef.release();
/*     */     }
/*     */     finally
/*     */     {
/* 555 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 556 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 557 */         currentContext = null;
/*     */       }
/* 559 */       else if (ccl != null) {
/* 560 */         currentContextPerThread.remove(ccl);
/*     */       }
/* 562 */       servletContext.removeAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 563 */       if (this.parentContextRef != null)
/* 564 */         this.parentContextRef.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getCurrentWebApplicationContext()
/*     */   {
/* 579 */     ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 580 */     if (ccl != null) {
/* 581 */       WebApplicationContext ccpt = (WebApplicationContext)currentContextPerThread.get(ccl);
/* 582 */       if (ccpt != null) {
/* 583 */         return ccpt;
/*     */       }
/*     */     }
/* 586 */     return currentContext;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 163 */       ClassPathResource resource = new ClassPathResource("ContextLoader.properties", ContextLoader.class);
/* 164 */       defaultStrategies = PropertiesLoaderUtils.loadProperties(resource);
/*     */     }
/*     */     catch (IOException ex) {
/* 167 */       throw new IllegalStateException("Could not load 'ContextLoader.properties': " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ContextLoader
 * JD-Core Version:    0.6.2
 */