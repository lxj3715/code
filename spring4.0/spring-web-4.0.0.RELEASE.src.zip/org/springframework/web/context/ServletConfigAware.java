package org.springframework.web.context;

import javax.servlet.ServletConfig;
import org.springframework.beans.factory.Aware;

public abstract interface ServletConfigAware extends Aware
{
  public abstract void setServletConfig(ServletConfig paramServletConfig);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ServletConfigAware
 * JD-Core Version:    0.6.2
 */