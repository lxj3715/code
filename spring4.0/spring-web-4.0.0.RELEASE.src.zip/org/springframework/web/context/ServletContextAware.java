package org.springframework.web.context;

import javax.servlet.ServletContext;
import org.springframework.beans.factory.Aware;

public abstract interface ServletContextAware extends Aware
{
  public abstract void setServletContext(ServletContext paramServletContext);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ServletContextAware
 * JD-Core Version:    0.6.2
 */