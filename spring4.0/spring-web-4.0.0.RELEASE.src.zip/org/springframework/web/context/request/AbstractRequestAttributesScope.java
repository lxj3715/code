/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ import org.springframework.beans.factory.ObjectFactory;
/*    */ import org.springframework.beans.factory.config.Scope;
/*    */ 
/*    */ public abstract class AbstractRequestAttributesScope
/*    */   implements Scope
/*    */ {
/*    */   public Object get(String name, ObjectFactory<?> objectFactory)
/*    */   {
/* 41 */     RequestAttributes attributes = RequestContextHolder.currentRequestAttributes();
/* 42 */     Object scopedObject = attributes.getAttribute(name, getScope());
/* 43 */     if (scopedObject == null) {
/* 44 */       scopedObject = objectFactory.getObject();
/* 45 */       attributes.setAttribute(name, scopedObject, getScope());
/*    */     }
/* 47 */     return scopedObject;
/*    */   }
/*    */ 
/*    */   public Object remove(String name)
/*    */   {
/* 52 */     RequestAttributes attributes = RequestContextHolder.currentRequestAttributes();
/* 53 */     Object scopedObject = attributes.getAttribute(name, getScope());
/* 54 */     if (scopedObject != null) {
/* 55 */       attributes.removeAttribute(name, getScope());
/* 56 */       return scopedObject;
/*    */     }
/*    */ 
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */   public void registerDestructionCallback(String name, Runnable callback)
/*    */   {
/* 65 */     RequestAttributes attributes = RequestContextHolder.currentRequestAttributes();
/* 66 */     attributes.registerDestructionCallback(name, callback, getScope());
/*    */   }
/*    */ 
/*    */   public Object resolveContextualObject(String key)
/*    */   {
/* 71 */     RequestAttributes attributes = RequestContextHolder.currentRequestAttributes();
/* 72 */     return attributes.resolveReference(key);
/*    */   }
/*    */ 
/*    */   protected abstract int getScope();
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.AbstractRequestAttributesScope
 * JD-Core Version:    0.6.2
 */