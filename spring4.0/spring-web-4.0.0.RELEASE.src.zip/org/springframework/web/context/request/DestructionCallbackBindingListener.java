/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.servlet.http.HttpSessionBindingEvent;
/*    */ import javax.servlet.http.HttpSessionBindingListener;
/*    */ 
/*    */ public class DestructionCallbackBindingListener
/*    */   implements HttpSessionBindingListener, Serializable
/*    */ {
/*    */   private final Runnable destructionCallback;
/*    */ 
/*    */   public DestructionCallbackBindingListener(Runnable destructionCallback)
/*    */   {
/* 44 */     this.destructionCallback = destructionCallback;
/*    */   }
/*    */ 
/*    */   public void valueBound(HttpSessionBindingEvent event)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void valueUnbound(HttpSessionBindingEvent event)
/*    */   {
/* 54 */     this.destructionCallback.run();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.DestructionCallbackBindingListener
 * JD-Core Version:    0.6.2
 */