/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.NDC;
/*     */ import org.springframework.ui.ModelMap;
/*     */ 
/*     */ public class Log4jNestedDiagnosticContextInterceptor
/*     */   implements AsyncWebRequestInterceptor
/*     */ {
/*  36 */   protected final Logger log4jLogger = Logger.getLogger(getClass());
/*     */ 
/*  38 */   private boolean includeClientInfo = false;
/*     */ 
/*     */   public void setIncludeClientInfo(boolean includeClientInfo)
/*     */   {
/*  46 */     this.includeClientInfo = includeClientInfo;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeClientInfo()
/*     */   {
/*  54 */     return this.includeClientInfo;
/*     */   }
/*     */ 
/*     */   public void preHandle(WebRequest request)
/*     */     throws Exception
/*     */   {
/*  63 */     NDC.push(getNestedDiagnosticContextMessage(request));
/*     */   }
/*     */ 
/*     */   protected String getNestedDiagnosticContextMessage(WebRequest request)
/*     */   {
/*  75 */     return request.getDescription(isIncludeClientInfo());
/*     */   }
/*     */ 
/*     */   public void postHandle(WebRequest request, ModelMap model)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void afterCompletion(WebRequest request, Exception ex)
/*     */     throws Exception
/*     */   {
/*  87 */     NDC.pop();
/*  88 */     if (NDC.getDepth() == 0)
/*  89 */       NDC.remove();
/*     */   }
/*     */ 
/*     */   public void afterConcurrentHandlingStarted(WebRequest request)
/*     */   {
/*  99 */     NDC.pop();
/* 100 */     if (NDC.getDepth() == 0)
/* 101 */       NDC.remove();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.Log4jNestedDiagnosticContextInterceptor
 * JD-Core Version:    0.6.2
 */