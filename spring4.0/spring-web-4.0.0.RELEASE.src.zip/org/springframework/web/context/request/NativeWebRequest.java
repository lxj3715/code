package org.springframework.web.context.request;

public abstract interface NativeWebRequest extends WebRequest
{
  public abstract Object getNativeRequest();

  public abstract Object getNativeResponse();

  public abstract <T> T getNativeRequest(Class<T> paramClass);

  public abstract <T> T getNativeResponse(Class<T> paramClass);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.NativeWebRequest
 * JD-Core Version:    0.6.2
 */