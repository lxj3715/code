/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletRequestEvent;
/*    */ import javax.servlet.ServletRequestListener;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.context.i18n.LocaleContextHolder;
/*    */ 
/*    */ public class RequestContextListener
/*    */   implements ServletRequestListener
/*    */ {
/* 49 */   private static final String REQUEST_ATTRIBUTES_ATTRIBUTE = RequestContextListener.class
/* 49 */     .getName() + ".REQUEST_ATTRIBUTES";
/*    */ 
/*    */   public void requestInitialized(ServletRequestEvent requestEvent)
/*    */   {
/* 54 */     if (!(requestEvent.getServletRequest() instanceof HttpServletRequest))
/*    */     {
/* 56 */       throw new IllegalArgumentException("Request is not an HttpServletRequest: " + requestEvent
/* 56 */         .getServletRequest());
/*    */     }
/* 58 */     HttpServletRequest request = (HttpServletRequest)requestEvent.getServletRequest();
/* 59 */     ServletRequestAttributes attributes = new ServletRequestAttributes(request);
/* 60 */     request.setAttribute(REQUEST_ATTRIBUTES_ATTRIBUTE, attributes);
/* 61 */     LocaleContextHolder.setLocale(request.getLocale());
/* 62 */     RequestContextHolder.setRequestAttributes(attributes);
/*    */   }
/*    */ 
/*    */   public void requestDestroyed(ServletRequestEvent requestEvent)
/*    */   {
/* 68 */     ServletRequestAttributes attributes = (ServletRequestAttributes)requestEvent
/* 68 */       .getServletRequest().getAttribute(REQUEST_ATTRIBUTES_ATTRIBUTE);
/*    */ 
/* 70 */     ServletRequestAttributes threadAttributes = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
/* 71 */     if (threadAttributes != null)
/*    */     {
/* 73 */       if (attributes == null) {
/* 74 */         attributes = threadAttributes;
/*    */       }
/* 76 */       LocaleContextHolder.resetLocaleContext();
/* 77 */       RequestContextHolder.resetRequestAttributes();
/*    */     }
/* 79 */     if (attributes != null)
/* 80 */       attributes.requestCompleted();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.RequestContextListener
 * JD-Core Version:    0.6.2
 */