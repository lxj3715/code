/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletRequestAttributes extends AbstractRequestAttributes
/*     */ {
/*  46 */   public static final String DESTRUCTION_CALLBACK_NAME_PREFIX = ServletRequestAttributes.class
/*  46 */     .getName() + ".DESTRUCTION_CALLBACK.";
/*     */   private final HttpServletRequest request;
/*     */   private volatile HttpSession session;
/*  53 */   private final Map<String, Object> sessionAttributesToUpdate = new ConcurrentHashMap(1);
/*     */ 
/*     */   public ServletRequestAttributes(HttpServletRequest request)
/*     */   {
/*  61 */     Assert.notNull(request, "Request must not be null");
/*  62 */     this.request = request;
/*     */   }
/*     */ 
/*     */   public final HttpServletRequest getRequest()
/*     */   {
/*  70 */     return this.request;
/*     */   }
/*     */ 
/*     */   protected final HttpSession getSession(boolean allowCreate)
/*     */   {
/*  78 */     if (isRequestActive()) {
/*  79 */       return this.request.getSession(allowCreate);
/*     */     }
/*     */ 
/*  83 */     if ((this.session == null) && (allowCreate)) {
/*  84 */       throw new IllegalStateException("No session found and request already completed - cannot create new session!");
/*     */     }
/*     */ 
/*  87 */     return this.session;
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String name, int scope)
/*     */   {
/*  94 */     if (scope == 0) {
/*  95 */       if (!isRequestActive()) {
/*  96 */         throw new IllegalStateException("Cannot ask for request attribute - request is not active anymore!");
/*     */       }
/*     */ 
/*  99 */       return this.request.getAttribute(name);
/*     */     }
/*     */ 
/* 102 */     HttpSession session = getSession(false);
/* 103 */     if (session != null) {
/*     */       try {
/* 105 */         Object value = session.getAttribute(name);
/* 106 */         if (value != null) {
/* 107 */           this.sessionAttributesToUpdate.put(name, value);
/*     */         }
/* 109 */         return value;
/*     */       }
/*     */       catch (IllegalStateException ex)
/*     */       {
/*     */       }
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   public void setAttribute(String name, Object value, int scope)
/*     */   {
/* 121 */     if (scope == 0) {
/* 122 */       if (!isRequestActive()) {
/* 123 */         throw new IllegalStateException("Cannot set request attribute - request is not active anymore!");
/*     */       }
/*     */ 
/* 126 */       this.request.setAttribute(name, value);
/*     */     }
/*     */     else {
/* 129 */       HttpSession session = getSession(true);
/* 130 */       this.sessionAttributesToUpdate.remove(name);
/* 131 */       session.setAttribute(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String name, int scope)
/*     */   {
/* 137 */     if (scope == 0) {
/* 138 */       if (isRequestActive()) {
/* 139 */         this.request.removeAttribute(name);
/* 140 */         removeRequestDestructionCallback(name);
/*     */       }
/*     */     }
/*     */     else {
/* 144 */       HttpSession session = getSession(false);
/* 145 */       if (session != null) {
/* 146 */         this.sessionAttributesToUpdate.remove(name);
/*     */         try {
/* 148 */           session.removeAttribute(name);
/*     */ 
/* 150 */           session.removeAttribute(DESTRUCTION_CALLBACK_NAME_PREFIX + name);
/*     */         }
/*     */         catch (IllegalStateException ex)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getAttributeNames(int scope)
/*     */   {
/* 161 */     if (scope == 0) {
/* 162 */       if (!isRequestActive()) {
/* 163 */         throw new IllegalStateException("Cannot ask for request attributes - request is not active anymore!");
/*     */       }
/*     */ 
/* 166 */       return StringUtils.toStringArray(this.request.getAttributeNames());
/*     */     }
/*     */ 
/* 169 */     HttpSession session = getSession(false);
/* 170 */     if (session != null) {
/*     */       try {
/* 172 */         return StringUtils.toStringArray(session.getAttributeNames());
/*     */       }
/*     */       catch (IllegalStateException ex)
/*     */       {
/*     */       }
/*     */     }
/* 178 */     return new String[0];
/*     */   }
/*     */ 
/*     */   public void registerDestructionCallback(String name, Runnable callback, int scope)
/*     */   {
/* 184 */     if (scope == 0) {
/* 185 */       registerRequestDestructionCallback(name, callback);
/*     */     }
/*     */     else
/* 188 */       registerSessionDestructionCallback(name, callback);
/*     */   }
/*     */ 
/*     */   public Object resolveReference(String key)
/*     */   {
/* 194 */     if ("request".equals(key)) {
/* 195 */       return this.request;
/*     */     }
/* 197 */     if ("session".equals(key)) {
/* 198 */       return getSession(true);
/*     */     }
/*     */ 
/* 201 */     return null;
/*     */   }
/*     */ 
/*     */   public String getSessionId()
/*     */   {
/* 207 */     return getSession(true).getId();
/*     */   }
/*     */ 
/*     */   public Object getSessionMutex()
/*     */   {
/* 212 */     return WebUtils.getSessionMutex(getSession(true));
/*     */   }
/*     */ 
/*     */   protected void updateAccessedSessionAttributes()
/*     */   {
/* 223 */     this.session = this.request.getSession(false);
/*     */ 
/* 225 */     if (this.session != null) {
/*     */       try {
/* 227 */         for (Map.Entry entry : this.sessionAttributesToUpdate.entrySet()) {
/* 228 */           String name = (String)entry.getKey();
/* 229 */           Object newValue = entry.getValue();
/* 230 */           Object oldValue = this.session.getAttribute(name);
/* 231 */           if (oldValue == newValue) {
/* 232 */             this.session.setAttribute(name, newValue);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IllegalStateException ex)
/*     */       {
/*     */       }
/*     */     }
/* 240 */     this.sessionAttributesToUpdate.clear();
/*     */   }
/*     */ 
/*     */   protected void registerSessionDestructionCallback(String name, Runnable callback)
/*     */   {
/* 251 */     HttpSession session = getSession(true);
/* 252 */     session.setAttribute(DESTRUCTION_CALLBACK_NAME_PREFIX + name, new DestructionCallbackBindingListener(callback));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 259 */     return this.request.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.ServletRequestAttributes
 * JD-Core Version:    0.6.2
 */