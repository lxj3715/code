/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletWebRequest extends ServletRequestAttributes
/*     */   implements NativeWebRequest
/*     */ {
/*     */   private static final String HEADER_ETAG = "ETag";
/*     */   private static final String HEADER_IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*     */   private static final String METHOD_GET = "GET";
/*     */   private HttpServletResponse response;
/*  53 */   private boolean notModified = false;
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request)
/*     */   {
/*  61 */     super(request);
/*     */   }
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  70 */     this(request);
/*  71 */     this.response = response;
/*     */   }
/*     */ 
/*     */   public final HttpServletResponse getResponse()
/*     */   {
/*  79 */     return this.response;
/*     */   }
/*     */ 
/*     */   public Object getNativeRequest()
/*     */   {
/*  84 */     return getRequest();
/*     */   }
/*     */ 
/*     */   public Object getNativeResponse()
/*     */   {
/*  89 */     return getResponse();
/*     */   }
/*     */ 
/*     */   public <T> T getNativeRequest(Class<T> requiredType)
/*     */   {
/*  94 */     return WebUtils.getNativeRequest(getRequest(), requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T getNativeResponse(Class<T> requiredType)
/*     */   {
/*  99 */     return WebUtils.getNativeResponse(getResponse(), requiredType);
/*     */   }
/*     */ 
/*     */   public String getHeader(String headerName)
/*     */   {
/* 105 */     return getRequest().getHeader(headerName);
/*     */   }
/*     */ 
/*     */   public String[] getHeaderValues(String headerName)
/*     */   {
/* 110 */     String[] headerValues = StringUtils.toStringArray(getRequest().getHeaders(headerName));
/* 111 */     return !ObjectUtils.isEmpty(headerValues) ? headerValues : null;
/*     */   }
/*     */ 
/*     */   public Iterator<String> getHeaderNames()
/*     */   {
/* 116 */     return CollectionUtils.toIterator(getRequest().getHeaderNames());
/*     */   }
/*     */ 
/*     */   public String getParameter(String paramName)
/*     */   {
/* 121 */     return getRequest().getParameter(paramName);
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String paramName)
/*     */   {
/* 126 */     return getRequest().getParameterValues(paramName);
/*     */   }
/*     */ 
/*     */   public Iterator<String> getParameterNames()
/*     */   {
/* 131 */     return CollectionUtils.toIterator(getRequest().getParameterNames());
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 136 */     return getRequest().getParameterMap();
/*     */   }
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/* 141 */     return getRequest().getLocale();
/*     */   }
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 146 */     return getRequest().getContextPath();
/*     */   }
/*     */ 
/*     */   public String getRemoteUser()
/*     */   {
/* 151 */     return getRequest().getRemoteUser();
/*     */   }
/*     */ 
/*     */   public Principal getUserPrincipal()
/*     */   {
/* 156 */     return getRequest().getUserPrincipal();
/*     */   }
/*     */ 
/*     */   public boolean isUserInRole(String role)
/*     */   {
/* 161 */     return getRequest().isUserInRole(role);
/*     */   }
/*     */ 
/*     */   public boolean isSecure()
/*     */   {
/* 166 */     return getRequest().isSecure();
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(long lastModifiedTimestamp)
/*     */   {
/* 171 */     if ((lastModifiedTimestamp >= 0L) && (!this.notModified) && ((this.response == null) || 
/* 172 */       (!this.response
/* 172 */       .containsHeader("Last-Modified"))))
/*     */     {
/* 173 */       long ifModifiedSince = getRequest().getDateHeader("If-Modified-Since");
/* 174 */       this.notModified = (ifModifiedSince >= lastModifiedTimestamp / 1000L * 1000L);
/* 175 */       if (this.response != null) {
/* 176 */         if ((this.notModified) && ("GET".equals(getRequest().getMethod()))) {
/* 177 */           this.response.setStatus(304);
/*     */         }
/*     */         else {
/* 180 */           this.response.setDateHeader("Last-Modified", lastModifiedTimestamp);
/*     */         }
/*     */       }
/*     */     }
/* 184 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(String eTag)
/*     */   {
/* 189 */     if ((StringUtils.hasLength(eTag)) && (!this.notModified) && ((this.response == null) || 
/* 190 */       (!this.response
/* 190 */       .containsHeader("ETag"))))
/*     */     {
/* 191 */       String ifNoneMatch = getRequest().getHeader("If-None-Match");
/* 192 */       this.notModified = eTag.equals(ifNoneMatch);
/* 193 */       if (this.response != null) {
/* 194 */         if ((this.notModified) && ("GET".equals(getRequest().getMethod()))) {
/* 195 */           this.response.setStatus(304);
/*     */         }
/*     */         else {
/* 198 */           this.response.setHeader("ETag", eTag);
/*     */         }
/*     */       }
/*     */     }
/* 202 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public boolean isNotModified()
/*     */   {
/* 207 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public String getDescription(boolean includeClientInfo)
/*     */   {
/* 212 */     HttpServletRequest request = getRequest();
/* 213 */     StringBuilder sb = new StringBuilder();
/* 214 */     sb.append("uri=").append(request.getRequestURI());
/* 215 */     if (includeClientInfo) {
/* 216 */       String client = request.getRemoteAddr();
/* 217 */       if (StringUtils.hasLength(client)) {
/* 218 */         sb.append(";client=").append(client);
/*     */       }
/* 220 */       HttpSession session = request.getSession(false);
/* 221 */       if (session != null) {
/* 222 */         sb.append(";session=").append(session.getId());
/*     */       }
/* 224 */       String user = request.getRemoteUser();
/* 225 */       if (StringUtils.hasLength(user)) {
/* 226 */         sb.append(";user=").append(user);
/*     */       }
/*     */     }
/* 229 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 235 */     return new StringBuilder().append("ServletWebRequest: ").append(getDescription(true)).toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.ServletWebRequest
 * JD-Core Version:    0.6.2
 */