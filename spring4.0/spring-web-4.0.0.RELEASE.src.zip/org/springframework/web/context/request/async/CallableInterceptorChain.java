/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ class CallableInterceptorChain
/*    */ {
/* 34 */   private static Log logger = LogFactory.getLog(CallableInterceptorChain.class);
/*    */   private final List<CallableProcessingInterceptor> interceptors;
/* 38 */   private int preProcessIndex = -1;
/*    */ 
/*    */   public CallableInterceptorChain(List<CallableProcessingInterceptor> interceptors)
/*    */   {
/* 42 */     this.interceptors = interceptors;
/*    */   }
/*    */ 
/*    */   public void applyBeforeConcurrentHandling(NativeWebRequest request, Callable<?> task) throws Exception {
/* 46 */     for (CallableProcessingInterceptor interceptor : this.interceptors)
/* 47 */       interceptor.beforeConcurrentHandling(request, task);
/*    */   }
/*    */ 
/*    */   public void applyPreProcess(NativeWebRequest request, Callable<?> task) throws Exception
/*    */   {
/* 52 */     for (CallableProcessingInterceptor interceptor : this.interceptors) {
/* 53 */       interceptor.preProcess(request, task);
/* 54 */       this.preProcessIndex += 1;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object applyPostProcess(NativeWebRequest request, Callable<?> task, Object concurrentResult) {
/* 59 */     Throwable exceptionResult = null;
/* 60 */     for (int i = this.preProcessIndex; i >= 0; i--) {
/*    */       try {
/* 62 */         ((CallableProcessingInterceptor)this.interceptors.get(i)).postProcess(request, task, concurrentResult);
/*    */       }
/*    */       catch (Throwable t)
/*    */       {
/* 66 */         if (exceptionResult != null) {
/* 67 */           logger.error("postProcess error", t);
/*    */         }
/*    */         else {
/* 70 */           exceptionResult = t;
/*    */         }
/*    */       }
/*    */     }
/* 74 */     return exceptionResult != null ? exceptionResult : concurrentResult;
/*    */   }
/*    */ 
/*    */   public Object triggerAfterTimeout(NativeWebRequest request, Callable<?> task) {
/* 78 */     for (CallableProcessingInterceptor interceptor : this.interceptors) {
/*    */       try {
/* 80 */         Object result = interceptor.handleTimeout(request, task);
/* 81 */         if (result == CallableProcessingInterceptor.RESPONSE_HANDLED) {
/*    */           break;
/*    */         }
/* 84 */         if (result != CallableProcessingInterceptor.RESULT_NONE)
/* 85 */           return result;
/*    */       }
/*    */       catch (Throwable t)
/*    */       {
/* 89 */         return t;
/*    */       }
/*    */     }
/* 92 */     return CallableProcessingInterceptor.RESULT_NONE;
/*    */   }
/*    */ 
/*    */   public void triggerAfterCompletion(NativeWebRequest request, Callable<?> task) {
/* 96 */     for (int i = this.interceptors.size() - 1; i >= 0; i--)
/*    */       try {
/* 98 */         ((CallableProcessingInterceptor)this.interceptors.get(i)).afterCompletion(request, task);
/*    */       }
/*    */       catch (Throwable t) {
/* 101 */         logger.error("afterCompletion error", t);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.CallableInterceptorChain
 * JD-Core Version:    0.6.2
 */