/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public abstract interface CallableProcessingInterceptor
/*    */ {
/* 47 */   public static final Object RESULT_NONE = new Object();
/*    */ 
/* 49 */   public static final Object RESPONSE_HANDLED = new Object();
/*    */ 
/*    */   public abstract <T> void beforeConcurrentHandling(NativeWebRequest paramNativeWebRequest, Callable<T> paramCallable)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract <T> void preProcess(NativeWebRequest paramNativeWebRequest, Callable<T> paramCallable)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract <T> void postProcess(NativeWebRequest paramNativeWebRequest, Callable<T> paramCallable, Object paramObject)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract <T> Object handleTimeout(NativeWebRequest paramNativeWebRequest, Callable<T> paramCallable)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract <T> void afterCompletion(NativeWebRequest paramNativeWebRequest, Callable<T> paramCallable)
/*    */     throws Exception;
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.CallableProcessingInterceptor
 * JD-Core Version:    0.6.2
 */