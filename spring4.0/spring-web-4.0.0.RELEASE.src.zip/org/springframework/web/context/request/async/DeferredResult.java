/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class DeferredResult<T>
/*     */ {
/*  51 */   private static final Log logger = LogFactory.getLog(DeferredResult.class);
/*     */ 
/*  53 */   private static final Object RESULT_NONE = new Object();
/*     */   private final Long timeout;
/*     */   private final Object timeoutResult;
/*     */   private Runnable timeoutCallback;
/*     */   private Runnable completionCallback;
/*     */   private DeferredResultHandler resultHandler;
/*  66 */   private Object result = RESULT_NONE;
/*     */   private boolean expired;
/*     */ 
/*     */   public DeferredResult()
/*     */   {
/*  75 */     this(null, RESULT_NONE);
/*     */   }
/*     */ 
/*     */   public DeferredResult(long timeout)
/*     */   {
/*  83 */     this(Long.valueOf(timeout), RESULT_NONE);
/*     */   }
/*     */ 
/*     */   public DeferredResult(Long timeout, Object timeoutResult)
/*     */   {
/*  93 */     this.timeoutResult = timeoutResult;
/*  94 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public final boolean isSetOrExpired()
/*     */   {
/* 107 */     return (this.result != RESULT_NONE) || (this.expired);
/*     */   }
/*     */ 
/*     */   public boolean hasResult()
/*     */   {
/* 114 */     return this.result != RESULT_NONE;
/*     */   }
/*     */ 
/*     */   public Object getResult()
/*     */   {
/* 123 */     return hasResult() ? this.result : null;
/*     */   }
/*     */ 
/*     */   final Long getTimeoutValue()
/*     */   {
/* 130 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void onTimeout(Runnable callback)
/*     */   {
/* 142 */     this.timeoutCallback = callback;
/*     */   }
/*     */ 
/*     */   public void onCompletion(Runnable callback)
/*     */   {
/* 152 */     this.completionCallback = callback;
/*     */   }
/*     */ 
/*     */   public final void setResultHandler(DeferredResultHandler resultHandler)
/*     */   {
/* 161 */     Assert.notNull(resultHandler, "DeferredResultHandler is required");
/* 162 */     synchronized (this) {
/* 163 */       this.resultHandler = resultHandler;
/* 164 */       if ((this.result != RESULT_NONE) && (!this.expired))
/*     */         try {
/* 166 */           this.resultHandler.handleResult(this.result);
/*     */         }
/*     */         catch (Throwable t) {
/* 169 */           logger.trace("DeferredResult not handled", t);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean setResult(T result)
/*     */   {
/* 183 */     return setResultInternal(result);
/*     */   }
/*     */ 
/*     */   private boolean setResultInternal(Object result) {
/* 187 */     synchronized (this) {
/* 188 */       if (isSetOrExpired()) {
/* 189 */         return false;
/*     */       }
/* 191 */       this.result = result;
/*     */     }
/* 193 */     if (this.resultHandler != null) {
/* 194 */       this.resultHandler.handleResult(this.result);
/*     */     }
/* 196 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean setErrorResult(Object result)
/*     */   {
/* 210 */     return setResultInternal(result);
/*     */   }
/*     */ 
/*     */   final DeferredResultProcessingInterceptor getInterceptor() {
/* 214 */     return new DeferredResultProcessingInterceptorAdapter()
/*     */     {
/*     */       public <S> boolean handleTimeout(NativeWebRequest request, DeferredResult<S> deferredResult)
/*     */       {
/* 218 */         if (DeferredResult.this.timeoutCallback != null) {
/* 219 */           DeferredResult.this.timeoutCallback.run();
/*     */         }
/* 221 */         if (DeferredResult.this.timeoutResult != DeferredResult.RESULT_NONE) {
/* 222 */           DeferredResult.this.setResultInternal(DeferredResult.this.timeoutResult);
/*     */         }
/* 224 */         return true;
/*     */       }
/*     */ 
/*     */       public <S> void afterCompletion(NativeWebRequest request, DeferredResult<S> deferredResult)
/*     */       {
/* 229 */         synchronized (DeferredResult.this) {
/* 230 */           DeferredResult.this.expired = true;
/*     */         }
/* 232 */         if (DeferredResult.this.completionCallback != null)
/* 233 */           DeferredResult.this.completionCallback.run();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static abstract interface DeferredResultHandler
/*     */   {
/*     */     public abstract void handleResult(Object paramObject);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.DeferredResult
 * JD-Core Version:    0.6.2
 */