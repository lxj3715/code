/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public final class WebAsyncManager
/*     */ {
/*  59 */   private static final Object RESULT_NONE = new Object();
/*     */ 
/*  61 */   private static final Log logger = LogFactory.getLog(WebAsyncManager.class);
/*     */ 
/*  63 */   private static final UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  65 */   private static final CallableProcessingInterceptor timeoutCallableInterceptor = new TimeoutCallableProcessingInterceptor();
/*     */ 
/*  68 */   private static final DeferredResultProcessingInterceptor timeoutDeferredResultInterceptor = new TimeoutDeferredResultProcessingInterceptor();
/*     */   private AsyncWebRequest asyncWebRequest;
/*  74 */   private AsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor(getClass().getSimpleName());
/*     */ 
/*  76 */   private Object concurrentResult = RESULT_NONE;
/*     */   private Object[] concurrentResultContext;
/*  80 */   private final Map<Object, CallableProcessingInterceptor> callableInterceptors = new LinkedHashMap();
/*     */ 
/*  83 */   private final Map<Object, DeferredResultProcessingInterceptor> deferredResultInterceptors = new LinkedHashMap();
/*     */ 
/*     */   public void setAsyncWebRequest(final AsyncWebRequest asyncWebRequest)
/*     */   {
/* 106 */     Assert.notNull(asyncWebRequest, "AsyncWebRequest must not be null");
/* 107 */     Assert.state(!isConcurrentHandlingStarted(), "Can't set AsyncWebRequest with concurrent handling in progress");
/* 108 */     this.asyncWebRequest = asyncWebRequest;
/* 109 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 112 */         asyncWebRequest.removeAttribute(WebAsyncUtils.WEB_ASYNC_MANAGER_ATTRIBUTE, 0);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void setTaskExecutor(AsyncTaskExecutor taskExecutor)
/*     */   {
/* 123 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */   public boolean isConcurrentHandlingStarted()
/*     */   {
/* 135 */     return (this.asyncWebRequest != null) && (this.asyncWebRequest.isAsyncStarted());
/*     */   }
/*     */ 
/*     */   public boolean hasConcurrentResult()
/*     */   {
/* 142 */     return this.concurrentResult != RESULT_NONE;
/*     */   }
/*     */ 
/*     */   public Object getConcurrentResult()
/*     */   {
/* 153 */     return this.concurrentResult;
/*     */   }
/*     */ 
/*     */   public Object[] getConcurrentResultContext()
/*     */   {
/* 163 */     return this.concurrentResultContext;
/*     */   }
/*     */ 
/*     */   public CallableProcessingInterceptor getCallableInterceptor(Object key)
/*     */   {
/* 172 */     return (CallableProcessingInterceptor)this.callableInterceptors.get(key);
/*     */   }
/*     */ 
/*     */   public DeferredResultProcessingInterceptor getDeferredResultInterceptor(Object key)
/*     */   {
/* 181 */     return (DeferredResultProcessingInterceptor)this.deferredResultInterceptors.get(key);
/*     */   }
/*     */ 
/*     */   public void registerCallableInterceptor(Object key, CallableProcessingInterceptor interceptor)
/*     */   {
/* 190 */     Assert.notNull(key, "Key is required");
/* 191 */     Assert.notNull(interceptor, "CallableProcessingInterceptor  is required");
/* 192 */     this.callableInterceptors.put(key, interceptor);
/*     */   }
/*     */ 
/*     */   public void registerCallableInterceptors(CallableProcessingInterceptor[] interceptors)
/*     */   {
/* 201 */     Assert.notNull(interceptors, "A CallableProcessingInterceptor is required");
/* 202 */     for (CallableProcessingInterceptor interceptor : interceptors) {
/* 203 */       String key = interceptor.getClass().getName() + ":" + interceptor.hashCode();
/* 204 */       this.callableInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerDeferredResultInterceptor(Object key, DeferredResultProcessingInterceptor interceptor)
/*     */   {
/* 214 */     Assert.notNull(key, "Key is required");
/* 215 */     Assert.notNull(interceptor, "DeferredResultProcessingInterceptor is required");
/* 216 */     this.deferredResultInterceptors.put(key, interceptor);
/*     */   }
/*     */ 
/*     */   public void registerDeferredResultInterceptors(DeferredResultProcessingInterceptor[] interceptors)
/*     */   {
/* 225 */     Assert.notNull(interceptors, "A DeferredResultProcessingInterceptor is required");
/* 226 */     for (DeferredResultProcessingInterceptor interceptor : interceptors) {
/* 227 */       String key = interceptors.getClass().getName() + ":" + interceptors.hashCode();
/* 228 */       this.deferredResultInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearConcurrentResult()
/*     */   {
/* 237 */     this.concurrentResult = RESULT_NONE;
/* 238 */     this.concurrentResultContext = null;
/*     */   }
/*     */ 
/*     */   public void startCallableProcessing(Callable<?> callable, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 258 */     Assert.notNull(callable, "Callable must not be null");
/* 259 */     startCallableProcessing(new WebAsyncTask(callable), processingContext);
/*     */   }
/*     */ 
/*     */   public void startCallableProcessing(WebAsyncTask<?> webAsyncTask, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 273 */     Assert.notNull(webAsyncTask, "WebAsyncTask must not be null");
/* 274 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */ 
/* 276 */     Long timeout = webAsyncTask.getTimeout();
/* 277 */     if (timeout != null) {
/* 278 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */ 
/* 281 */     AsyncTaskExecutor executor = webAsyncTask.getExecutor();
/* 282 */     if (executor != null) {
/* 283 */       this.taskExecutor = executor;
/*     */     }
/*     */ 
/* 286 */     List interceptors = new ArrayList();
/* 287 */     interceptors.add(webAsyncTask.getInterceptor());
/* 288 */     interceptors.addAll(this.callableInterceptors.values());
/* 289 */     interceptors.add(timeoutCallableInterceptor);
/*     */ 
/* 291 */     final Callable callable = webAsyncTask.getCallable();
/* 292 */     final CallableInterceptorChain interceptorChain = new CallableInterceptorChain(interceptors);
/*     */ 
/* 294 */     this.asyncWebRequest.addTimeoutHandler(new Object()
/*     */     {
/*     */       public void run() {
/* 297 */         WebAsyncManager.logger.debug("Processing timeout");
/* 298 */         Object result = interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, callable);
/* 299 */         if (result != CallableProcessingInterceptor.RESULT_NONE)
/* 300 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */       }
/*     */     });
/* 305 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 308 */         interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, callable);
/*     */       }
/*     */     });
/* 312 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, callable);
/*     */ 
/* 314 */     startAsyncProcessing(processingContext);
/*     */ 
/* 316 */     this.taskExecutor.submit(new Object()
/*     */     {
/*     */       public void run() {
/* 319 */         Object result = null;
/*     */         try {
/* 321 */           interceptorChain.applyPreProcess(WebAsyncManager.this.asyncWebRequest, callable);
/* 322 */           result = callable.call();
/*     */         }
/*     */         catch (Throwable t) {
/* 325 */           result = t;
/*     */         }
/*     */         finally {
/* 328 */           result = interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, callable, result);
/*     */         }
/* 330 */         WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private void setConcurrentResultAndDispatch(Object result) {
/* 336 */     synchronized (this) {
/* 337 */       if (hasConcurrentResult()) {
/* 338 */         return;
/*     */       }
/* 340 */       this.concurrentResult = result;
/*     */     }
/*     */ 
/* 343 */     if (this.asyncWebRequest.isAsyncComplete()) {
/* 344 */       logger.error("Could not complete async processing due to timeout or network error");
/* 345 */       return;
/*     */     }
/*     */ 
/* 348 */     logger.debug("Concurrent result value [" + this.concurrentResult + "]");
/* 349 */     logger.debug("Dispatching request to resume processing");
/*     */ 
/* 351 */     this.asyncWebRequest.dispatch();
/*     */   }
/*     */ 
/*     */   public void startDeferredResultProcessing(final DeferredResult<?> deferredResult, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 373 */     Assert.notNull(deferredResult, "DeferredResult must not be null");
/* 374 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */ 
/* 376 */     Long timeout = deferredResult.getTimeoutValue();
/* 377 */     if (timeout != null) {
/* 378 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */ 
/* 381 */     List interceptors = new ArrayList();
/* 382 */     interceptors.add(deferredResult.getInterceptor());
/* 383 */     interceptors.addAll(this.deferredResultInterceptors.values());
/* 384 */     interceptors.add(timeoutDeferredResultInterceptor);
/*     */ 
/* 386 */     final DeferredResultInterceptorChain interceptorChain = new DeferredResultInterceptorChain(interceptors);
/*     */ 
/* 388 */     this.asyncWebRequest.addTimeoutHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/* 392 */           interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, deferredResult);
/*     */         }
/*     */         catch (Throwable t) {
/* 395 */           WebAsyncManager.this.setConcurrentResultAndDispatch(t);
/*     */         }
/*     */       }
/*     */     });
/* 400 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 403 */         interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, deferredResult);
/*     */       }
/*     */     });
/* 407 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, deferredResult);
/*     */ 
/* 409 */     startAsyncProcessing(processingContext);
/*     */     try
/*     */     {
/* 412 */       interceptorChain.applyPreProcess(this.asyncWebRequest, deferredResult);
/* 413 */       deferredResult.setResultHandler(new DeferredResult.DeferredResultHandler()
/*     */       {
/*     */         public void handleResult(Object result) {
/* 416 */           result = interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, deferredResult, result);
/* 417 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (Throwable t) {
/* 422 */       setConcurrentResultAndDispatch(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void startAsyncProcessing(Object[] processingContext)
/*     */   {
/* 428 */     clearConcurrentResult();
/* 429 */     this.concurrentResultContext = processingContext;
/*     */ 
/* 431 */     this.asyncWebRequest.startAsync();
/*     */ 
/* 433 */     if (logger.isDebugEnabled()) {
/* 434 */       HttpServletRequest request = (HttpServletRequest)this.asyncWebRequest.getNativeRequest(HttpServletRequest.class);
/* 435 */       String requestUri = urlPathHelper.getRequestUri(request);
/* 436 */       logger.debug("Concurrent handling starting for " + request.getMethod() + " [" + requestUri + "]");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.WebAsyncManager
 * JD-Core Version:    0.6.2
 */