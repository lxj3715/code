/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AnnotationConfigWebApplicationContext extends AbstractRefreshableWebApplicationContext
/*     */ {
/*     */   private BeanNameGenerator beanNameGenerator;
/*     */   private ScopeMetadataResolver scopeMetadataResolver;
/*  87 */   private final Set<Class<?>> annotatedClasses = new LinkedHashSet();
/*     */ 
/*  89 */   private final Set<String> basePackages = new LinkedHashSet();
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 100 */     this.beanNameGenerator = beanNameGenerator;
/*     */   }
/*     */ 
/*     */   protected BeanNameGenerator getBeanNameGenerator()
/*     */   {
/* 108 */     return this.beanNameGenerator;
/*     */   }
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 119 */     this.scopeMetadataResolver = scopeMetadataResolver;
/*     */   }
/*     */ 
/*     */   protected ScopeMetadataResolver getScopeMetadataResolver()
/*     */   {
/* 127 */     return this.scopeMetadataResolver;
/*     */   }
/*     */ 
/*     */   public void register(Class<?>[] annotatedClasses)
/*     */   {
/* 145 */     Assert.notEmpty(annotatedClasses, "At least one annotated class must be specified");
/* 146 */     this.annotatedClasses.addAll(Arrays.asList(annotatedClasses));
/*     */   }
/*     */ 
/*     */   public void scan(String[] basePackages)
/*     */   {
/* 160 */     Assert.notEmpty(basePackages, "At least one base package must be specified");
/* 161 */     this.basePackages.addAll(Arrays.asList(basePackages));
/*     */   }
/*     */ 
/*     */   protected void loadBeanDefinitions(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 188 */     AnnotatedBeanDefinitionReader reader = new AnnotatedBeanDefinitionReader(beanFactory);
/* 189 */     reader.setEnvironment(getEnvironment());
/*     */ 
/* 191 */     ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(beanFactory);
/* 192 */     scanner.setEnvironment(getEnvironment());
/*     */ 
/* 194 */     BeanNameGenerator beanNameGenerator = getBeanNameGenerator();
/* 195 */     ScopeMetadataResolver scopeMetadataResolver = getScopeMetadataResolver();
/* 196 */     if (beanNameGenerator != null) {
/* 197 */       reader.setBeanNameGenerator(beanNameGenerator);
/* 198 */       scanner.setBeanNameGenerator(beanNameGenerator);
/* 199 */       beanFactory.registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */     }
/*     */ 
/* 202 */     if (scopeMetadataResolver != null) {
/* 203 */       reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 204 */       scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */     }
/*     */ 
/* 207 */     if (!this.annotatedClasses.isEmpty()) {
/* 208 */       if (this.logger.isInfoEnabled()) {
/* 209 */         this.logger.info("Registering annotated classes: [" + 
/* 210 */           StringUtils.collectionToCommaDelimitedString(this.annotatedClasses) + 
/* 210 */           "]");
/*     */       }
/* 212 */       reader.register((Class[])this.annotatedClasses.toArray(new Class[this.annotatedClasses.size()]));
/*     */     }
/*     */ 
/* 215 */     if (!this.basePackages.isEmpty()) {
/* 216 */       if (this.logger.isInfoEnabled()) {
/* 217 */         this.logger.info("Scanning base packages: [" + 
/* 218 */           StringUtils.collectionToCommaDelimitedString(this.basePackages) + 
/* 218 */           "]");
/*     */       }
/* 220 */       scanner.scan((String[])this.basePackages.toArray(new String[this.basePackages.size()]));
/*     */     }
/*     */ 
/* 223 */     String[] configLocations = getConfigLocations();
/* 224 */     if (configLocations != null)
/* 225 */       for (String configLocation : configLocations)
/*     */         try {
/* 227 */           Class clazz = getClassLoader().loadClass(configLocation);
/* 228 */           if (this.logger.isInfoEnabled()) {
/* 229 */             this.logger.info("Successfully resolved class for [" + configLocation + "]");
/*     */           }
/* 231 */           reader.register(new Class[] { clazz });
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 234 */           if (this.logger.isDebugEnabled()) {
/* 235 */             this.logger.debug("Could not load class for config location [" + configLocation + "] - trying package scan. " + ex);
/*     */           }
/*     */ 
/* 238 */           int count = scanner.scan(new String[] { configLocation });
/* 239 */           if (this.logger.isInfoEnabled())
/* 240 */             if (count == 0) {
/* 241 */               this.logger.info("No annotated classes found for specified class/package [" + configLocation + "]");
/*     */             }
/*     */             else
/* 244 */               this.logger.info("Found " + count + " annotated classes in package [" + configLocation + "]");
/*     */         }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.AnnotationConfigWebApplicationContext
 * JD-Core Version:    0.6.2
 */