/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.ui.context.support.UiApplicationContextUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*     */ import org.springframework.web.context.ConfigurableWebEnvironment;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public class GenericWebApplicationContext extends GenericApplicationContext
/*     */   implements ConfigurableWebApplicationContext, ThemeSource
/*     */ {
/*     */   private ServletContext servletContext;
/*     */   private ThemeSource themeSource;
/*     */ 
/*     */   public GenericWebApplicationContext()
/*     */   {
/*     */   }
/*     */ 
/*     */   public GenericWebApplicationContext(ServletContext servletContext)
/*     */   {
/*  88 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public GenericWebApplicationContext(DefaultListableBeanFactory beanFactory)
/*     */   {
/*  99 */     super(beanFactory);
/*     */   }
/*     */ 
/*     */   public GenericWebApplicationContext(DefaultListableBeanFactory beanFactory, ServletContext servletContext)
/*     */   {
/* 110 */     super(beanFactory);
/* 111 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 120 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public ServletContext getServletContext()
/*     */   {
/* 125 */     return this.servletContext;
/*     */   }
/*     */ 
/*     */   public String getApplicationName()
/*     */   {
/* 130 */     return this.servletContext != null ? this.servletContext.getContextPath() : "";
/*     */   }
/*     */ 
/*     */   protected ConfigurableEnvironment createEnvironment()
/*     */   {
/* 138 */     return new StandardServletEnvironment();
/*     */   }
/*     */ 
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 147 */     beanFactory.addBeanPostProcessor(new ServletContextAwareProcessor(this.servletContext));
/* 148 */     beanFactory.ignoreDependencyInterface(ServletContextAware.class);
/*     */ 
/* 150 */     WebApplicationContextUtils.registerWebApplicationScopes(beanFactory, this.servletContext);
/* 151 */     WebApplicationContextUtils.registerEnvironmentBeans(beanFactory, this.servletContext);
/*     */   }
/*     */ 
/*     */   protected Resource getResourceByPath(String path)
/*     */   {
/* 160 */     return new ServletContextResource(this.servletContext, path);
/*     */   }
/*     */ 
/*     */   protected ResourcePatternResolver getResourcePatternResolver()
/*     */   {
/* 169 */     return new ServletContextResourcePatternResolver(this);
/*     */   }
/*     */ 
/*     */   protected void onRefresh()
/*     */   {
/* 177 */     this.themeSource = UiApplicationContextUtils.initThemeSource(this);
/*     */   }
/*     */ 
/*     */   protected void initPropertySources()
/*     */   {
/* 186 */     super.initPropertySources();
/* 187 */     ConfigurableEnvironment env = getEnvironment();
/* 188 */     if ((env instanceof ConfigurableWebEnvironment))
/* 189 */       ((ConfigurableWebEnvironment)env).initPropertySources(this.servletContext, null);
/*     */   }
/*     */ 
/*     */   public Theme getTheme(String themeName)
/*     */   {
/* 196 */     return this.themeSource.getTheme(themeName);
/*     */   }
/*     */ 
/*     */   public void setServletConfig(ServletConfig servletConfig)
/*     */   {
/*     */   }
/*     */ 
/*     */   public ServletConfig getServletConfig()
/*     */   {
/* 211 */     throw new UnsupportedOperationException("GenericWebApplicationContext does not support getServletConfig()");
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getNamespace()
/*     */   {
/* 222 */     throw new UnsupportedOperationException("GenericWebApplicationContext does not support getNamespace()");
/*     */   }
/*     */ 
/*     */   public void setConfigLocation(String configLocation)
/*     */   {
/* 228 */     if (StringUtils.hasText(configLocation))
/* 229 */       throw new UnsupportedOperationException("GenericWebApplicationContext does not support setConfigLocation(). Do you still have an 'contextConfigLocations' init-param set?");
/*     */   }
/*     */ 
/*     */   public void setConfigLocations(String[] configLocations)
/*     */   {
/* 237 */     if (!ObjectUtils.isEmpty(configLocations))
/* 238 */       throw new UnsupportedOperationException("GenericWebApplicationContext does not support setConfigLocations(). Do you still have an 'contextConfigLocations' init-param set?");
/*     */   }
/*     */ 
/*     */   public String[] getConfigLocations()
/*     */   {
/* 246 */     throw new UnsupportedOperationException("GenericWebApplicationContext does not support getConfigLocations()");
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.GenericWebApplicationContext
 * JD-Core Version:    0.6.2
 */