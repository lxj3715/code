/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.web.context.ServletContextAware;
/*    */ 
/*    */ public class ServletContextAttributeFactoryBean
/*    */   implements FactoryBean<Object>, ServletContextAware
/*    */ {
/*    */   private String attributeName;
/*    */   private Object attribute;
/*    */ 
/*    */   public void setAttributeName(String attributeName)
/*    */   {
/* 55 */     this.attributeName = attributeName;
/*    */   }
/*    */ 
/*    */   public void setServletContext(ServletContext servletContext)
/*    */   {
/* 60 */     if (this.attributeName == null) {
/* 61 */       throw new IllegalArgumentException("Property 'attributeName' is required");
/*    */     }
/* 63 */     this.attribute = servletContext.getAttribute(this.attributeName);
/* 64 */     if (this.attribute == null)
/* 65 */       throw new IllegalStateException("No ServletContext attribute '" + this.attributeName + "' found");
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */     throws Exception
/*    */   {
/* 72 */     return this.attribute;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType()
/*    */   {
/* 77 */     return this.attribute != null ? this.attribute.getClass() : null;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton()
/*    */   {
/* 82 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextAttributeFactoryBean
 * JD-Core Version:    0.6.2
 */