/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.core.io.DefaultResourceLoader;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ public class ServletContextResourceLoader extends DefaultResourceLoader
/*    */ {
/*    */   private final ServletContext servletContext;
/*    */ 
/*    */   public ServletContextResourceLoader(ServletContext servletContext)
/*    */   {
/* 50 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */   protected Resource getResourceByPath(String path)
/*    */   {
/* 59 */     return new ServletContextResource(this.servletContext, path);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextResourceLoader
 * JD-Core Version:    0.6.2
 */