/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.core.env.MutablePropertySources;
/*    */ import org.springframework.core.env.PropertySource.StubPropertySource;
/*    */ import org.springframework.core.env.StandardEnvironment;
/*    */ import org.springframework.jndi.JndiLocatorDelegate;
/*    */ import org.springframework.jndi.JndiPropertySource;
/*    */ import org.springframework.web.context.ConfigurableWebEnvironment;
/*    */ 
/*    */ public class StandardServletEnvironment extends StandardEnvironment
/*    */   implements ConfigurableWebEnvironment
/*    */ {
/*    */   public static final String SERVLET_CONTEXT_PROPERTY_SOURCE_NAME = "servletContextInitParams";
/*    */   public static final String SERVLET_CONFIG_PROPERTY_SOURCE_NAME = "servletConfigInitParams";
/*    */   public static final String JNDI_PROPERTY_SOURCE_NAME = "jndiProperties";
/*    */ 
/*    */   protected void customizePropertySources(MutablePropertySources propertySources)
/*    */   {
/* 85 */     propertySources.addLast(new PropertySource.StubPropertySource("servletConfigInitParams"));
/* 86 */     propertySources.addLast(new PropertySource.StubPropertySource("servletContextInitParams"));
/* 87 */     if (JndiLocatorDelegate.isDefaultJndiEnvironmentAvailable()) {
/* 88 */       propertySources.addLast(new JndiPropertySource("jndiProperties"));
/*    */     }
/* 90 */     super.customizePropertySources(propertySources);
/*    */   }
/*    */ 
/*    */   public void initPropertySources(ServletContext servletContext, ServletConfig servletConfig)
/*    */   {
/* 95 */     WebApplicationContextUtils.initServletPropertySources(
/* 96 */       getPropertySources(), servletContext, servletConfig);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.StandardServletEnvironment
 * JD-Core Version:    0.6.2
 */