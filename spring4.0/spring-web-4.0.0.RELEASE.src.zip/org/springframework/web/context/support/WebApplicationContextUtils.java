/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource.StubPropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.RequestScope;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.SessionScope;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ 
/*     */ public abstract class WebApplicationContextUtils
/*     */ {
/*  71 */   private static final boolean jsfPresent = ClassUtils.isPresent("javax.faces.context.FacesContext", RequestContextHolder.class
/*  71 */     .getClassLoader());
/*     */ 
/*     */   public static WebApplicationContext getRequiredWebApplicationContext(ServletContext sc)
/*     */     throws IllegalStateException
/*     */   {
/*  87 */     WebApplicationContext wac = getWebApplicationContext(sc);
/*  88 */     if (wac == null) {
/*  89 */       throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*     */     }
/*  91 */     return wac;
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletContext sc)
/*     */   {
/* 104 */     return getWebApplicationContext(sc, WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletContext sc, String attrName)
/*     */   {
/* 114 */     Assert.notNull(sc, "ServletContext must not be null");
/* 115 */     Object attr = sc.getAttribute(attrName);
/* 116 */     if (attr == null) {
/* 117 */       return null;
/*     */     }
/* 119 */     if ((attr instanceof RuntimeException)) {
/* 120 */       throw ((RuntimeException)attr);
/*     */     }
/* 122 */     if ((attr instanceof Error)) {
/* 123 */       throw ((Error)attr);
/*     */     }
/* 125 */     if ((attr instanceof Exception)) {
/* 126 */       throw new IllegalStateException((Exception)attr);
/*     */     }
/* 128 */     if (!(attr instanceof WebApplicationContext)) {
/* 129 */       throw new IllegalStateException("Context attribute is not of type WebApplicationContext: " + attr);
/*     */     }
/* 131 */     return (WebApplicationContext)attr;
/*     */   }
/*     */ 
/*     */   public static void registerWebApplicationScopes(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 141 */     registerWebApplicationScopes(beanFactory, null);
/*     */   }
/*     */ 
/*     */   public static void registerWebApplicationScopes(ConfigurableListableBeanFactory beanFactory, ServletContext sc)
/*     */   {
/* 151 */     beanFactory.registerScope("request", new RequestScope());
/* 152 */     beanFactory.registerScope("session", new SessionScope(false));
/* 153 */     beanFactory.registerScope("globalSession", new SessionScope(true));
/* 154 */     if (sc != null) {
/* 155 */       ServletContextScope appScope = new ServletContextScope(sc);
/* 156 */       beanFactory.registerScope("application", appScope);
/*     */ 
/* 158 */       sc.setAttribute(ServletContextScope.class.getName(), appScope);
/*     */     }
/*     */ 
/* 161 */     beanFactory.registerResolvableDependency(ServletRequest.class, new RequestObjectFactory(null));
/* 162 */     beanFactory.registerResolvableDependency(HttpSession.class, new SessionObjectFactory(null));
/* 163 */     beanFactory.registerResolvableDependency(WebRequest.class, new WebRequestObjectFactory(null));
/* 164 */     if (jsfPresent)
/* 165 */       FacesDependencyRegistrar.registerFacesDependencies(beanFactory);
/*     */   }
/*     */ 
/*     */   public static void registerEnvironmentBeans(ConfigurableListableBeanFactory bf, ServletContext sc)
/*     */   {
/* 176 */     registerEnvironmentBeans(bf, sc, null);
/*     */   }
/*     */ 
/*     */   public static void registerEnvironmentBeans(ConfigurableListableBeanFactory bf, ServletContext sc, ServletConfig config)
/*     */   {
/* 189 */     if ((sc != null) && (!bf.containsBean("servletContext"))) {
/* 190 */       bf.registerSingleton("servletContext", sc);
/*     */     }
/*     */ 
/* 193 */     if ((config != null) && (!bf.containsBean("servletConfig"))) {
/* 194 */       bf.registerSingleton("servletConfig", config);
/*     */     }
/*     */ 
/* 197 */     if (!bf.containsBean("contextParameters")) {
/* 198 */       Map parameterMap = new HashMap();
/* 199 */       if (sc != null) {
/* 200 */         Enumeration paramNameEnum = sc.getInitParameterNames();
/* 201 */         while (paramNameEnum.hasMoreElements()) {
/* 202 */           String paramName = (String)paramNameEnum.nextElement();
/* 203 */           parameterMap.put(paramName, sc.getInitParameter(paramName));
/*     */         }
/*     */       }
/* 206 */       if (config != null) {
/* 207 */         Enumeration paramNameEnum = config.getInitParameterNames();
/* 208 */         while (paramNameEnum.hasMoreElements()) {
/* 209 */           String paramName = (String)paramNameEnum.nextElement();
/* 210 */           parameterMap.put(paramName, config.getInitParameter(paramName));
/*     */         }
/*     */       }
/* 213 */       bf.registerSingleton("contextParameters", 
/* 214 */         Collections.unmodifiableMap(parameterMap));
/*     */     }
/*     */ 
/* 217 */     if (!bf.containsBean("contextAttributes")) {
/* 218 */       Map attributeMap = new HashMap();
/* 219 */       if (sc != null) {
/* 220 */         Enumeration attrNameEnum = sc.getAttributeNames();
/* 221 */         while (attrNameEnum.hasMoreElements()) {
/* 222 */           String attrName = (String)attrNameEnum.nextElement();
/* 223 */           attributeMap.put(attrName, sc.getAttribute(attrName));
/*     */         }
/*     */       }
/* 226 */       bf.registerSingleton("contextAttributes", 
/* 227 */         Collections.unmodifiableMap(attributeMap));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initServletPropertySources(MutablePropertySources propertySources, ServletContext servletContext)
/*     */   {
/* 239 */     initServletPropertySources(propertySources, servletContext, null);
/*     */   }
/*     */ 
/*     */   public static void initServletPropertySources(MutablePropertySources propertySources, ServletContext servletContext, ServletConfig servletConfig)
/*     */   {
/* 262 */     Assert.notNull(propertySources, "propertySources must not be null");
/* 263 */     if ((servletContext != null) && 
/* 264 */       (propertySources
/* 264 */       .contains("servletContextInitParams")) && 
/* 265 */       ((propertySources
/* 265 */       .get("servletContextInitParams") instanceof PropertySource.StubPropertySource)))
/*     */     {
/* 266 */       propertySources.replace("servletContextInitParams", new ServletContextPropertySource("servletContextInitParams", servletContext));
/*     */     }
/* 268 */     if ((servletConfig != null) && 
/* 269 */       (propertySources
/* 269 */       .contains("servletConfigInitParams")) && 
/* 270 */       ((propertySources
/* 270 */       .get("servletConfigInitParams") instanceof PropertySource.StubPropertySource)))
/*     */     {
/* 271 */       propertySources.replace("servletConfigInitParams", new ServletConfigPropertySource("servletConfigInitParams", servletConfig));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static ServletRequestAttributes currentRequestAttributes()
/*     */   {
/* 280 */     RequestAttributes requestAttr = RequestContextHolder.currentRequestAttributes();
/* 281 */     if (!(requestAttr instanceof ServletRequestAttributes)) {
/* 282 */       throw new IllegalStateException("Current request is not a servlet request");
/*     */     }
/* 284 */     return (ServletRequestAttributes)requestAttr;
/*     */   }
/*     */ 
/*     */   private static class FacesDependencyRegistrar
/*     */   {
/*     */     public static void registerFacesDependencies(ConfigurableListableBeanFactory beanFactory)
/*     */     {
/* 348 */       beanFactory.registerResolvableDependency(FacesContext.class, new ObjectFactory()
/*     */       {
/*     */         public FacesContext getObject() {
/* 351 */           return FacesContext.getCurrentInstance();
/*     */         }
/*     */ 
/*     */         public String toString() {
/* 355 */           return "Current JSF FacesContext";
/*     */         }
/*     */       });
/* 358 */       beanFactory.registerResolvableDependency(ExternalContext.class, new ObjectFactory()
/*     */       {
/*     */         public ExternalContext getObject() {
/* 361 */           return FacesContext.getCurrentInstance().getExternalContext();
/*     */         }
/*     */ 
/*     */         public String toString() {
/* 365 */           return "Current JSF ExternalContext";
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class WebRequestObjectFactory
/*     */     implements ObjectFactory<WebRequest>, Serializable
/*     */   {
/*     */     public WebRequest getObject()
/*     */     {
/* 332 */       return new ServletWebRequest(WebApplicationContextUtils.access$300().getRequest());
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 337 */       return "Current ServletWebRequest";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SessionObjectFactory
/*     */     implements ObjectFactory<HttpSession>, Serializable
/*     */   {
/*     */     public HttpSession getObject()
/*     */     {
/* 314 */       return WebApplicationContextUtils.access$300().getRequest().getSession();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 319 */       return "Current HttpSession";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RequestObjectFactory
/*     */     implements ObjectFactory<ServletRequest>, Serializable
/*     */   {
/*     */     public ServletRequest getObject()
/*     */     {
/* 296 */       return WebApplicationContextUtils.access$300().getRequest();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 301 */       return "Current HttpServletRequest";
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.WebApplicationContextUtils
 * JD-Core Version:    0.6.2
 */