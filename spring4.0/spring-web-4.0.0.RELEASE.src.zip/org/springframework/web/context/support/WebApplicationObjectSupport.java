/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.support.ApplicationObjectSupport;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public abstract class WebApplicationObjectSupport extends ApplicationObjectSupport
/*     */   implements ServletContextAware
/*     */ {
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public final void setServletContext(ServletContext servletContext)
/*     */   {
/*  45 */     if (servletContext != this.servletContext) {
/*  46 */       this.servletContext = servletContext;
/*  47 */       if (servletContext != null)
/*  48 */         initServletContext(servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isContextRequired()
/*     */   {
/*  64 */     return true;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext(ApplicationContext context)
/*     */   {
/*  73 */     super.initApplicationContext(context);
/*  74 */     if ((this.servletContext == null) && ((context instanceof WebApplicationContext))) {
/*  75 */       this.servletContext = ((WebApplicationContext)context).getServletContext();
/*  76 */       if (this.servletContext != null)
/*  77 */         initServletContext(this.servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final WebApplicationContext getWebApplicationContext()
/*     */     throws IllegalStateException
/*     */   {
/* 104 */     ApplicationContext ctx = getApplicationContext();
/* 105 */     if ((ctx instanceof WebApplicationContext)) {
/* 106 */       return (WebApplicationContext)getApplicationContext();
/*     */     }
/* 108 */     if (isContextRequired()) {
/* 109 */       throw new IllegalStateException("WebApplicationObjectSupport instance [" + this + "] does not run in a WebApplicationContext but in: " + ctx);
/*     */     }
/*     */ 
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */     throws IllegalStateException
/*     */   {
/* 122 */     if (this.servletContext != null) {
/* 123 */       return this.servletContext;
/*     */     }
/* 125 */     ServletContext servletContext = getWebApplicationContext().getServletContext();
/* 126 */     if ((servletContext == null) && (isContextRequired())) {
/* 127 */       throw new IllegalStateException("WebApplicationObjectSupport instance [" + this + "] does not run within a ServletContext. Make sure the object is fully configured!");
/*     */     }
/*     */ 
/* 130 */     return servletContext;
/*     */   }
/*     */ 
/*     */   protected final File getTempDir()
/*     */     throws IllegalStateException
/*     */   {
/* 141 */     return WebUtils.getTempDir(getServletContext());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.WebApplicationObjectSupport
 * JD-Core Version:    0.6.2
 */