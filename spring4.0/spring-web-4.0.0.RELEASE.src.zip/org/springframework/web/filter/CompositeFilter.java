/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ 
/*     */ public class CompositeFilter
/*     */   implements Filter
/*     */ {
/*     */   private List<? extends Filter> filters;
/*     */ 
/*     */   public CompositeFilter()
/*     */   {
/*  44 */     this.filters = new ArrayList();
/*     */   }
/*     */   public void setFilters(List<? extends Filter> filters) {
/*  47 */     this.filters = new ArrayList(filters);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  57 */     for (int i = this.filters.size(); i-- > 0; ) {
/*  58 */       Filter filter = (Filter)this.filters.get(i);
/*  59 */       filter.destroy();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig config)
/*     */     throws ServletException
/*     */   {
/*  70 */     for (Filter filter : this.filters)
/*  71 */       filter.init(config);
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  85 */     new VirtualFilterChain(chain, this.filters, null).doFilter(request, response);
/*     */   }
/*     */ 
/*     */   private static class VirtualFilterChain
/*     */     implements FilterChain
/*     */   {
/*     */     private final FilterChain originalChain;
/*     */     private final List<? extends Filter> additionalFilters;
/*  91 */     private int currentPosition = 0;
/*     */ 
/*     */     private VirtualFilterChain(FilterChain chain, List<? extends Filter> additionalFilters) {
/*  94 */       this.originalChain = chain;
/*  95 */       this.additionalFilters = additionalFilters;
/*     */     }
/*     */ 
/*     */     public void doFilter(ServletRequest request, ServletResponse response)
/*     */       throws IOException, ServletException
/*     */     {
/* 101 */       if (this.currentPosition == this.additionalFilters.size()) {
/* 102 */         this.originalChain.doFilter(request, response);
/*     */       } else {
/* 104 */         this.currentPosition += 1;
/* 105 */         Filter nextFilter = (Filter)this.additionalFilters.get(this.currentPosition - 1);
/* 106 */         nextFilter.doFilter(request, response, this);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.CompositeFilter
 * JD-Core Version:    0.6.2
 */