/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ public class DelegatingFilterProxy extends GenericFilterBean
/*     */ {
/*     */   private String contextAttribute;
/*     */   private WebApplicationContext webApplicationContext;
/*     */   private String targetBeanName;
/*  89 */   private boolean targetFilterLifecycle = false;
/*     */   private volatile Filter delegate;
/*  93 */   private final Object delegateMonitor = new Object();
/*     */ 
/*     */   public DelegatingFilterProxy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DelegatingFilterProxy(Filter delegate)
/*     */   {
/* 118 */     Assert.notNull(delegate, "delegate Filter object must not be null");
/* 119 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   public DelegatingFilterProxy(String targetBeanName)
/*     */   {
/* 136 */     this(targetBeanName, null);
/*     */   }
/*     */ 
/*     */   public DelegatingFilterProxy(String targetBeanName, WebApplicationContext wac)
/*     */   {
/* 160 */     Assert.hasText(targetBeanName, "target Filter bean name must not be null or empty");
/* 161 */     setTargetBeanName(targetBeanName);
/* 162 */     this.webApplicationContext = wac;
/* 163 */     if (wac != null)
/* 164 */       setEnvironment(wac.getEnvironment());
/*     */   }
/*     */ 
/*     */   public void setContextAttribute(String contextAttribute)
/*     */   {
/* 173 */     this.contextAttribute = contextAttribute;
/*     */   }
/*     */ 
/*     */   public String getContextAttribute()
/*     */   {
/* 181 */     return this.contextAttribute;
/*     */   }
/*     */ 
/*     */   public void setTargetBeanName(String targetBeanName)
/*     */   {
/* 191 */     this.targetBeanName = targetBeanName;
/*     */   }
/*     */ 
/*     */   protected String getTargetBeanName()
/*     */   {
/* 198 */     return this.targetBeanName;
/*     */   }
/*     */ 
/*     */   public void setTargetFilterLifecycle(boolean targetFilterLifecycle)
/*     */   {
/* 210 */     this.targetFilterLifecycle = targetFilterLifecycle;
/*     */   }
/*     */ 
/*     */   protected boolean isTargetFilterLifecycle()
/*     */   {
/* 218 */     return this.targetFilterLifecycle;
/*     */   }
/*     */ 
/*     */   protected void initFilterBean()
/*     */     throws ServletException
/*     */   {
/* 224 */     synchronized (this.delegateMonitor) {
/* 225 */       if (this.delegate == null)
/*     */       {
/* 227 */         if (this.targetBeanName == null) {
/* 228 */           this.targetBeanName = getFilterName();
/*     */         }
/*     */ 
/* 233 */         WebApplicationContext wac = findWebApplicationContext();
/* 234 */         if (wac != null)
/* 235 */           this.delegate = initDelegate(wac);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 246 */     Filter delegateToUse = this.delegate;
/* 247 */     if (delegateToUse == null) {
/* 248 */       synchronized (this.delegateMonitor) {
/* 249 */         if (this.delegate == null) {
/* 250 */           WebApplicationContext wac = findWebApplicationContext();
/* 251 */           if (wac == null) {
/* 252 */             throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*     */           }
/* 254 */           this.delegate = initDelegate(wac);
/*     */         }
/* 256 */         delegateToUse = this.delegate;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 261 */     invokeDelegate(delegateToUse, request, response, filterChain);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 266 */     Filter delegateToUse = this.delegate;
/* 267 */     if (delegateToUse != null)
/* 268 */       destroyDelegate(delegateToUse);
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext findWebApplicationContext()
/*     */   {
/* 290 */     if (this.webApplicationContext != null)
/*     */     {
/* 292 */       if (((this.webApplicationContext instanceof ConfigurableApplicationContext)) && 
/* 293 */         (!((ConfigurableApplicationContext)this.webApplicationContext).isActive()))
/*     */       {
/* 295 */         ((ConfigurableApplicationContext)this.webApplicationContext).refresh();
/*     */       }
/*     */ 
/* 298 */       return this.webApplicationContext;
/*     */     }
/* 300 */     String attrName = getContextAttribute();
/* 301 */     if (attrName != null) {
/* 302 */       return WebApplicationContextUtils.getWebApplicationContext(getServletContext(), attrName);
/*     */     }
/*     */ 
/* 305 */     return WebApplicationContextUtils.getWebApplicationContext(getServletContext());
/*     */   }
/*     */ 
/*     */   protected Filter initDelegate(WebApplicationContext wac)
/*     */     throws ServletException
/*     */   {
/* 324 */     Filter delegate = (Filter)wac.getBean(getTargetBeanName(), Filter.class);
/* 325 */     if (isTargetFilterLifecycle()) {
/* 326 */       delegate.init(getFilterConfig());
/*     */     }
/* 328 */     return delegate;
/*     */   }
/*     */ 
/*     */   protected void invokeDelegate(Filter delegate, ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 344 */     delegate.doFilter(request, response, filterChain);
/*     */   }
/*     */ 
/*     */   protected void destroyDelegate(Filter delegate)
/*     */   {
/* 355 */     if (isTargetFilterLifecycle())
/* 356 */       delegate.destroy();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.DelegatingFilterProxy
 * JD-Core Version:    0.6.2
 */