/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceEditor;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.context.support.ServletContextResourceLoader;
/*     */ import org.springframework.web.context.support.StandardServletEnvironment;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ public abstract class GenericFilterBean
/*     */   implements Filter, BeanNameAware, EnvironmentAware, ServletContextAware, InitializingBean, DisposableBean
/*     */ {
/*     */   protected final Log logger;
/*     */   private final Set<String> requiredProperties;
/*     */   private FilterConfig filterConfig;
/*     */   private String beanName;
/*     */   private Environment environment;
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public GenericFilterBean()
/*     */   {
/*  82 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  88 */     this.requiredProperties = new HashSet();
/*     */ 
/*  94 */     this.environment = new StandardServletEnvironment();
/*     */   }
/*     */ 
/*     */   public final void setBeanName(String beanName)
/*     */   {
/* 108 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 122 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public final void setServletContext(ServletContext servletContext)
/*     */   {
/* 134 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws ServletException
/*     */   {
/* 147 */     initFilterBean();
/*     */   }
/*     */ 
/*     */   protected final void addRequiredProperty(String property)
/*     */   {
/* 161 */     this.requiredProperties.add(property);
/*     */   }
/*     */ 
/*     */   public final void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/* 175 */     Assert.notNull(filterConfig, "FilterConfig must not be null");
/* 176 */     if (this.logger.isDebugEnabled()) {
/* 177 */       this.logger.debug("Initializing filter '" + filterConfig.getFilterName() + "'");
/*     */     }
/*     */ 
/* 180 */     this.filterConfig = filterConfig;
/*     */     try
/*     */     {
/* 184 */       PropertyValues pvs = new FilterConfigPropertyValues(filterConfig, this.requiredProperties);
/* 185 */       BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(this);
/* 186 */       ResourceLoader resourceLoader = new ServletContextResourceLoader(filterConfig.getServletContext());
/* 187 */       bw.registerCustomEditor(Resource.class, new ResourceEditor(resourceLoader, this.environment));
/* 188 */       initBeanWrapper(bw);
/* 189 */       bw.setPropertyValues(pvs, true);
/*     */     }
/*     */     catch (BeansException ex)
/*     */     {
/* 193 */       String msg = "Failed to set bean properties on filter '" + filterConfig
/* 193 */         .getFilterName() + "': " + ex.getMessage();
/* 194 */       this.logger.error(msg, ex);
/* 195 */       throw new NestedServletException(msg, ex);
/*     */     }
/*     */ 
/* 199 */     initFilterBean();
/*     */ 
/* 201 */     if (this.logger.isDebugEnabled())
/* 202 */       this.logger.debug("Filter '" + filterConfig.getFilterName() + "' configured successfully");
/*     */   }
/*     */ 
/*     */   protected void initBeanWrapper(BeanWrapper bw)
/*     */     throws BeansException
/*     */   {
/*     */   }
/*     */ 
/*     */   public final FilterConfig getFilterConfig()
/*     */   {
/* 227 */     return this.filterConfig;
/*     */   }
/*     */ 
/*     */   protected final String getFilterName()
/*     */   {
/* 242 */     return this.filterConfig != null ? this.filterConfig.getFilterName() : this.beanName;
/*     */   }
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */   {
/* 257 */     return this.filterConfig != null ? this.filterConfig.getServletContext() : this.servletContext;
/*     */   }
/*     */ 
/*     */   protected void initFilterBean()
/*     */     throws ServletException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   private static class FilterConfigPropertyValues extends MutablePropertyValues
/*     */   {
/*     */     public FilterConfigPropertyValues(FilterConfig config, Set<String> requiredProperties)
/*     */       throws ServletException
/*     */     {
/* 303 */       Set missingProps = (requiredProperties != null) && (!requiredProperties.isEmpty()) ? new HashSet(requiredProperties) : null;
/*     */ 
/* 306 */       Enumeration en = config.getInitParameterNames();
/* 307 */       while (en.hasMoreElements()) {
/* 308 */         String property = (String)en.nextElement();
/* 309 */         Object value = config.getInitParameter(property);
/* 310 */         addPropertyValue(new PropertyValue(property, value));
/* 311 */         if (missingProps != null) {
/* 312 */           missingProps.remove(property);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 317 */       if ((missingProps != null) && (missingProps.size() > 0))
/*     */       {
/* 321 */         throw new ServletException("Initialization from FilterConfig for filter '" + config
/* 319 */           .getFilterName() + "' failed; the following required properties were missing: " + 
/* 321 */           StringUtils.collectionToDelimitedString(missingProps, ", "));
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.GenericFilterBean
 * JD-Core Version:    0.6.2
 */