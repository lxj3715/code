/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.FormHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public class HttpPutFormContentFilter extends OncePerRequestFilter
/*     */ {
/*     */   private final FormHttpMessageConverter formConverter;
/*     */ 
/*     */   public HttpPutFormContentFilter()
/*     */   {
/*  63 */     this.formConverter = new AllEncompassingFormHttpMessageConverter();
/*     */   }
/*     */ 
/*     */   public void setCharset(Charset charset)
/*     */   {
/*  69 */     this.formConverter.setCharset(charset);
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(final HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  76 */     if ((("PUT".equals(request.getMethod())) || ("PATCH".equals(request.getMethod()))) && (isFormContentType(request))) {
/*  77 */       HttpInputMessage inputMessage = new ServletServerHttpRequest(request)
/*     */       {
/*     */         public InputStream getBody() throws IOException {
/*  80 */           return request.getInputStream();
/*     */         }
/*     */       };
/*  83 */       MultiValueMap formParameters = this.formConverter.read(null, inputMessage);
/*  84 */       HttpServletRequest wrapper = new HttpPutFormContentRequestWrapper(request, formParameters);
/*  85 */       filterChain.doFilter(wrapper, response);
/*     */     }
/*     */     else {
/*  88 */       filterChain.doFilter(request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isFormContentType(HttpServletRequest request) {
/*  93 */     String contentType = request.getContentType();
/*  94 */     if (contentType != null) {
/*     */       try {
/*  96 */         MediaType mediaType = MediaType.parseMediaType(contentType);
/*  97 */         return MediaType.APPLICATION_FORM_URLENCODED.includes(mediaType);
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 100 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   private static class HttpPutFormContentRequestWrapper extends HttpServletRequestWrapper
/*     */   {
/*     */     private MultiValueMap<String, String> formParameters;
/*     */ 
/*     */     public HttpPutFormContentRequestWrapper(HttpServletRequest request, MultiValueMap<String, String> parameters)
/*     */     {
/* 113 */       super();
/* 114 */       this.formParameters = (parameters != null ? parameters : new LinkedMultiValueMap());
/*     */     }
/*     */ 
/*     */     public String getParameter(String name)
/*     */     {
/* 119 */       String queryStringValue = super.getParameter(name);
/* 120 */       String formValue = (String)this.formParameters.getFirst(name);
/* 121 */       return queryStringValue != null ? queryStringValue : formValue;
/*     */     }
/*     */ 
/*     */     public Map<String, String[]> getParameterMap()
/*     */     {
/* 126 */       Map result = new LinkedHashMap();
/* 127 */       Enumeration names = getParameterNames();
/* 128 */       while (names.hasMoreElements()) {
/* 129 */         String name = (String)names.nextElement();
/* 130 */         result.put(name, getParameterValues(name));
/*     */       }
/* 132 */       return result;
/*     */     }
/*     */ 
/*     */     public Enumeration<String> getParameterNames()
/*     */     {
/* 137 */       Set names = new LinkedHashSet();
/* 138 */       names.addAll(Collections.list(super.getParameterNames()));
/* 139 */       names.addAll(this.formParameters.keySet());
/* 140 */       return Collections.enumeration(names);
/*     */     }
/*     */ 
/*     */     public String[] getParameterValues(String name)
/*     */     {
/* 145 */       String[] queryStringValues = super.getParameterValues(name);
/* 146 */       List formValues = (List)this.formParameters.get(name);
/* 147 */       if (formValues == null) {
/* 148 */         return queryStringValues;
/*     */       }
/* 150 */       if (queryStringValues == null) {
/* 151 */         return (String[])formValues.toArray(new String[formValues.size()]);
/*     */       }
/*     */ 
/* 154 */       List result = new ArrayList();
/* 155 */       result.addAll(Arrays.asList(queryStringValues));
/* 156 */       result.addAll(formValues);
/* 157 */       return (String[])result.toArray(new String[result.size()]);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.HttpPutFormContentFilter
 * JD-Core Version:    0.6.2
 */