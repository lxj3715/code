/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ 
/*     */ public abstract class OncePerRequestFilter extends GenericFilterBean
/*     */ {
/*     */   public static final String ALREADY_FILTERED_SUFFIX = ".FILTERED";
/*     */ 
/*     */   public final void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  90 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse))) {
/*  91 */       throw new ServletException("OncePerRequestFilter just supports HTTP requests");
/*     */     }
/*  93 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/*  94 */     HttpServletResponse httpResponse = (HttpServletResponse)response;
/*     */ 
/*  96 */     String alreadyFilteredAttributeName = getAlreadyFilteredAttributeName();
/*  97 */     boolean hasAlreadyFilteredAttribute = request.getAttribute(alreadyFilteredAttributeName) != null;
/*     */ 
/*  99 */     if ((hasAlreadyFilteredAttribute) || (skipDispatch(httpRequest)) || (shouldNotFilter(httpRequest)))
/*     */     {
/* 102 */       filterChain.doFilter(request, response);
/*     */     }
/*     */     else
/*     */     {
/* 106 */       request.setAttribute(alreadyFilteredAttributeName, Boolean.TRUE);
/*     */       try {
/* 108 */         doFilterInternal(httpRequest, httpResponse, filterChain);
/*     */       }
/*     */       finally
/*     */       {
/* 112 */         request.removeAttribute(alreadyFilteredAttributeName);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean skipDispatch(HttpServletRequest request) {
/* 118 */     if ((isAsyncDispatch(request)) && (shouldNotFilterAsyncDispatch())) {
/* 119 */       return true;
/*     */     }
/* 121 */     if ((request.getAttribute("javax.servlet.error.request_uri") != null) && (shouldNotFilterErrorDispatch())) {
/* 122 */       return true;
/*     */     }
/* 124 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean isAsyncDispatch(HttpServletRequest request)
/*     */   {
/* 137 */     return WebAsyncUtils.getAsyncManager(request).hasConcurrentResult();
/*     */   }
/*     */ 
/*     */   protected boolean isAsyncStarted(HttpServletRequest request)
/*     */   {
/* 148 */     return WebAsyncUtils.getAsyncManager(request).isConcurrentHandlingStarted();
/*     */   }
/*     */ 
/*     */   protected String getAlreadyFilteredAttributeName()
/*     */   {
/* 161 */     String name = getFilterName();
/* 162 */     if (name == null) {
/* 163 */       name = getClass().getName();
/*     */     }
/* 165 */     return name + ".FILTERED";
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilter(HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/* 177 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/* 198 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterErrorDispatch()
/*     */   {
/* 208 */     return true;
/*     */   }
/*     */ 
/*     */   protected abstract void doFilterInternal(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, FilterChain paramFilterChain)
/*     */     throws ServletException, IOException;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.OncePerRequestFilter
 * JD-Core Version:    0.6.2
 */