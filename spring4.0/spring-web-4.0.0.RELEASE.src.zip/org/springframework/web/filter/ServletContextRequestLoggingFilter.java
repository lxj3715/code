/*    */ package org.springframework.web.filter;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class ServletContextRequestLoggingFilter extends AbstractRequestLoggingFilter
/*    */ {
/*    */   protected void beforeRequest(HttpServletRequest request, String message)
/*    */   {
/* 41 */     getServletContext().log(message);
/*    */   }
/*    */ 
/*    */   protected void afterRequest(HttpServletRequest request, String message)
/*    */   {
/* 49 */     getServletContext().log(message);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.ServletContextRequestLoggingFilter
 * JD-Core Version:    0.6.2
 */