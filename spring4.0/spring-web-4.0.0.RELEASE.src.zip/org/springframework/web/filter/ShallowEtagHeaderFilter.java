/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.DigestUtils;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ShallowEtagHeaderFilter extends OncePerRequestFilter
/*     */ {
/*  51 */   private static String HEADER_ETAG = "ETag";
/*     */ 
/*  53 */   private static String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  69 */     if (!isAsyncDispatch(request)) {
/*  70 */       response = new ShallowEtagResponseWrapper(response, null);
/*     */     }
/*     */ 
/*  73 */     filterChain.doFilter(request, response);
/*     */ 
/*  75 */     if (!isAsyncStarted(request))
/*  76 */       updateResponse(request, response);
/*     */   }
/*     */ 
/*     */   private void updateResponse(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/*  82 */     ShallowEtagResponseWrapper responseWrapper = (ShallowEtagResponseWrapper)WebUtils.getNativeResponse(response, ShallowEtagResponseWrapper.class);
/*  83 */     Assert.notNull(responseWrapper, "ShallowEtagResponseWrapper not found");
/*     */ 
/*  85 */     response = (HttpServletResponse)responseWrapper.getResponse();
/*     */ 
/*  87 */     byte[] body = responseWrapper.toByteArray();
/*  88 */     int statusCode = responseWrapper.getStatusCode();
/*     */ 
/*  90 */     if (isEligibleForEtag(request, responseWrapper, statusCode, body)) {
/*  91 */       String responseETag = generateETagHeaderValue(body);
/*  92 */       response.setHeader(HEADER_ETAG, responseETag);
/*     */ 
/*  94 */       String requestETag = request.getHeader(HEADER_IF_NONE_MATCH);
/*  95 */       if (responseETag.equals(requestETag)) {
/*  96 */         if (this.logger.isTraceEnabled()) {
/*  97 */           this.logger.trace("ETag [" + responseETag + "] equal to If-None-Match, sending 304");
/*     */         }
/*  99 */         response.setStatus(304);
/*     */       }
/*     */       else {
/* 102 */         if (this.logger.isTraceEnabled()) {
/* 103 */           this.logger.trace("ETag [" + responseETag + "] not equal to If-None-Match [" + requestETag + "], sending normal response");
/*     */         }
/*     */ 
/* 106 */         copyBodyToResponse(body, response);
/*     */       }
/*     */     }
/*     */     else {
/* 110 */       if (this.logger.isTraceEnabled()) {
/* 111 */         this.logger.trace("Response with status code [" + statusCode + "] not eligible for ETag");
/*     */       }
/* 113 */       copyBodyToResponse(body, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void copyBodyToResponse(byte[] body, HttpServletResponse response) throws IOException {
/* 118 */     if (body.length > 0) {
/* 119 */       response.setContentLength(body.length);
/* 120 */       FileCopyUtils.copy(body, response.getOutputStream());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleForEtag(HttpServletRequest request, HttpServletResponse response, int responseStatusCode, byte[] responseBody)
/*     */   {
/* 136 */     return (responseStatusCode >= 200) && (responseStatusCode < 300);
/*     */   }
/*     */ 
/*     */   protected String generateETagHeaderValue(byte[] bytes)
/*     */   {
/* 147 */     StringBuilder builder = new StringBuilder("\"0");
/* 148 */     DigestUtils.appendMd5DigestAsHex(bytes, builder);
/* 149 */     builder.append('"');
/* 150 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   private static class ShallowEtagResponseWrapper extends HttpServletResponseWrapper
/*     */   {
/* 161 */     private final ByteArrayOutputStream content = new ByteArrayOutputStream();
/*     */ 
/* 163 */     private final ServletOutputStream outputStream = new ResponseServletOutputStream(null);
/*     */     private PrintWriter writer;
/* 167 */     private int statusCode = 200;
/*     */ 
/*     */     private ShallowEtagResponseWrapper(HttpServletResponse response) {
/* 170 */       super();
/*     */     }
/*     */ 
/*     */     public void setStatus(int sc)
/*     */     {
/* 175 */       super.setStatus(sc);
/* 176 */       this.statusCode = sc;
/*     */     }
/*     */ 
/*     */     public void setStatus(int sc, String sm)
/*     */     {
/* 182 */       super.setStatus(sc, sm);
/* 183 */       this.statusCode = sc;
/*     */     }
/*     */ 
/*     */     public void sendError(int sc) throws IOException
/*     */     {
/* 188 */       super.sendError(sc);
/* 189 */       this.statusCode = sc;
/*     */     }
/*     */ 
/*     */     public void sendError(int sc, String msg) throws IOException
/*     */     {
/* 194 */       super.sendError(sc, msg);
/* 195 */       this.statusCode = sc;
/*     */     }
/*     */ 
/*     */     public void setContentLength(int len)
/*     */     {
/*     */     }
/*     */ 
/*     */     public ServletOutputStream getOutputStream()
/*     */     {
/* 204 */       return this.outputStream;
/*     */     }
/*     */ 
/*     */     public PrintWriter getWriter() throws IOException
/*     */     {
/* 209 */       if (this.writer == null) {
/* 210 */         String characterEncoding = getCharacterEncoding();
/* 211 */         this.writer = (characterEncoding != null ? new ResponsePrintWriter(characterEncoding, null) : new ResponsePrintWriter("ISO-8859-1", null));
/*     */       }
/*     */ 
/* 214 */       return this.writer;
/*     */     }
/*     */ 
/*     */     public void resetBuffer()
/*     */     {
/* 219 */       this.content.reset();
/*     */     }
/*     */ 
/*     */     public void reset()
/*     */     {
/* 224 */       super.reset();
/* 225 */       resetBuffer();
/*     */     }
/*     */ 
/*     */     private int getStatusCode() {
/* 229 */       return this.statusCode;
/*     */     }
/*     */ 
/*     */     private byte[] toByteArray() {
/* 233 */       return this.content.toByteArray();
/*     */     }
/*     */ 
/*     */     private class ResponsePrintWriter extends PrintWriter
/*     */     {
/*     */       private ResponsePrintWriter(String characterEncoding)
/*     */         throws UnsupportedEncodingException
/*     */       {
/* 252 */         super();
/*     */       }
/*     */ 
/*     */       public void write(char[] buf, int off, int len)
/*     */       {
/* 257 */         super.write(buf, off, len);
/* 258 */         super.flush();
/*     */       }
/*     */ 
/*     */       public void write(String s, int off, int len)
/*     */       {
/* 263 */         super.write(s, off, len);
/* 264 */         super.flush();
/*     */       }
/*     */ 
/*     */       public void write(int c)
/*     */       {
/* 269 */         super.write(c);
/* 270 */         super.flush();
/*     */       }
/*     */     }
/*     */ 
/*     */     private class ResponseServletOutputStream extends ServletOutputStream
/*     */     {
/*     */       private ResponseServletOutputStream()
/*     */       {
/*     */       }
/*     */ 
/*     */       public void write(int b)
/*     */         throws IOException
/*     */       {
/* 240 */         ShallowEtagHeaderFilter.ShallowEtagResponseWrapper.this.content.write(b);
/*     */       }
/*     */ 
/*     */       public void write(byte[] b, int off, int len) throws IOException
/*     */       {
/* 245 */         ShallowEtagHeaderFilter.ShallowEtagResponseWrapper.this.content.write(b, off, len);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.ShallowEtagHeaderFilter
 * JD-Core Version:    0.6.2
 */