/*     */ package org.springframework.web.jsf;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public abstract class FacesContextUtils
/*     */ {
/*     */   public static WebApplicationContext getWebApplicationContext(FacesContext fc)
/*     */   {
/*  50 */     Assert.notNull(fc, "FacesContext must not be null");
/*  51 */     Object attr = fc.getExternalContext().getApplicationMap().get(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */ 
/*  53 */     if (attr == null) {
/*  54 */       return null;
/*     */     }
/*  56 */     if ((attr instanceof RuntimeException)) {
/*  57 */       throw ((RuntimeException)attr);
/*     */     }
/*  59 */     if ((attr instanceof Error)) {
/*  60 */       throw ((Error)attr);
/*     */     }
/*  62 */     if (!(attr instanceof WebApplicationContext)) {
/*  63 */       throw new IllegalStateException("Root context attribute is not of type WebApplicationContext: " + attr);
/*     */     }
/*  65 */     return (WebApplicationContext)attr;
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getRequiredWebApplicationContext(FacesContext fc)
/*     */     throws IllegalStateException
/*     */   {
/*  81 */     WebApplicationContext wac = getWebApplicationContext(fc);
/*  82 */     if (wac == null) {
/*  83 */       throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*     */     }
/*  85 */     return wac;
/*     */   }
/*     */ 
/*     */   public static Object getSessionMutex(FacesContext fc)
/*     */   {
/* 109 */     Assert.notNull(fc, "FacesContext must not be null");
/* 110 */     ExternalContext ec = fc.getExternalContext();
/* 111 */     Object mutex = ec.getSessionMap().get(WebUtils.SESSION_MUTEX_ATTRIBUTE);
/* 112 */     if (mutex == null) {
/* 113 */       mutex = ec.getSession(true);
/*     */     }
/* 115 */     return mutex;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.FacesContextUtils
 * JD-Core Version:    0.6.2
 */