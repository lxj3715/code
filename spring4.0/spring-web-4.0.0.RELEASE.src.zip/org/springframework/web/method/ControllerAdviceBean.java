/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.ControllerAdvice;
/*     */ 
/*     */ public class ControllerAdviceBean
/*     */   implements Ordered
/*     */ {
/*  49 */   private static final Log logger = LogFactory.getLog(ControllerAdviceBean.class);
/*     */   private final Object bean;
/*     */   private final int order;
/*     */   private final BeanFactory beanFactory;
/*  57 */   private final List<Package> basePackages = new ArrayList();
/*     */ 
/*  59 */   private final List<Class<? extends Annotation>> annotations = new ArrayList();
/*     */ 
/*  61 */   private final List<Class<?>> assignableTypes = new ArrayList();
/*     */ 
/*     */   public ControllerAdviceBean(String beanName, BeanFactory beanFactory)
/*     */   {
/*  70 */     Assert.hasText(beanName, "'beanName' must not be null");
/*  71 */     Assert.notNull(beanFactory, "'beanFactory' must not be null");
/*  72 */     Assert.isTrue(beanFactory.containsBean(beanName), "Bean factory [" + beanFactory + "] does not contain bean " + "with name [" + beanName + "]");
/*     */ 
/*  75 */     this.bean = beanName;
/*  76 */     this.beanFactory = beanFactory;
/*     */ 
/*  78 */     Class beanType = this.beanFactory.getType(beanName);
/*  79 */     this.order = initOrderFromBeanType(beanType);
/*     */ 
/*  81 */     ControllerAdvice annotation = (ControllerAdvice)AnnotationUtils.findAnnotation(beanType, ControllerAdvice.class);
/*  82 */     Assert.notNull(annotation, "BeanType [" + beanType.getName() + "] is not annotated @ControllerAdvice");
/*     */ 
/*  84 */     this.basePackages.addAll(initBasePackagesFromBeanType(beanType, annotation));
/*  85 */     this.annotations.addAll(Arrays.asList(annotation.annotations()));
/*  86 */     this.assignableTypes.addAll(Arrays.asList(annotation.assignableTypes()));
/*     */   }
/*     */ 
/*     */   private static int initOrderFromBeanType(Class<?> beanType) {
/*  90 */     Order annot = (Order)AnnotationUtils.findAnnotation(beanType, Order.class);
/*  91 */     return annot != null ? annot.value() : 2147483647;
/*     */   }
/*     */ 
/*     */   private static List<Package> initBasePackagesFromBeanType(Class<?> beanType, ControllerAdvice annotation) {
/*  95 */     List basePackages = new ArrayList();
/*  96 */     List basePackageNames = new ArrayList();
/*  97 */     basePackageNames.addAll(Arrays.asList(annotation.value()));
/*  98 */     basePackageNames.addAll(Arrays.asList(annotation.basePackages()));
/*  99 */     for (Object localObject = basePackageNames.iterator(); ((Iterator)localObject).hasNext(); ) { pkgName = (String)((Iterator)localObject).next();
/* 100 */       if (StringUtils.hasText(pkgName)) {
/* 101 */         pkg = Package.getPackage(pkgName);
/* 102 */         if (pkg != null) {
/* 103 */           basePackages.add(pkg);
/*     */         }
/*     */         else {
/* 106 */           logger.warn("Package [" + pkgName + "] was not found, see [" + beanType.getName() + "]");
/*     */         }
/*     */       }
/*     */     }
/* 110 */     localObject = annotation.basePackageClasses(); String pkgName = localObject.length; for (Package pkg = 0; pkg < pkgName; pkg++) { Class markerClass = localObject[pkg];
/* 111 */       Package pack = markerClass.getPackage();
/* 112 */       if (pack != null) {
/* 113 */         basePackages.add(pack);
/*     */       }
/*     */       else {
/* 116 */         logger.warn("Package was not found for class [" + markerClass.getName() + "], see [" + beanType
/* 117 */           .getName() + "]");
/*     */       }
/*     */     }
/* 120 */     return basePackages;
/*     */   }
/*     */ 
/*     */   public ControllerAdviceBean(Object bean)
/*     */   {
/* 128 */     Assert.notNull(bean, "'bean' must not be null");
/* 129 */     this.bean = bean;
/* 130 */     this.order = initOrderFromBean(bean);
/*     */ 
/* 132 */     Class beanType = bean.getClass();
/* 133 */     ControllerAdvice annotation = (ControllerAdvice)AnnotationUtils.findAnnotation(beanType, ControllerAdvice.class);
/* 134 */     Assert.notNull(annotation, "BeanType [" + beanType.getName() + "] is not annotated @ControllerAdvice");
/*     */ 
/* 136 */     this.basePackages.addAll(initBasePackagesFromBeanType(beanType, annotation));
/* 137 */     this.annotations.addAll(Arrays.asList(annotation.annotations()));
/* 138 */     this.assignableTypes.addAll(Arrays.asList(annotation.assignableTypes()));
/* 139 */     this.beanFactory = null;
/*     */   }
/*     */ 
/*     */   private static int initOrderFromBean(Object bean) {
/* 143 */     return (bean instanceof Ordered) ? ((Ordered)bean).getOrder() : initOrderFromBeanType(bean.getClass());
/*     */   }
/*     */ 
/*     */   public static List<ControllerAdviceBean> findAnnotatedBeans(ApplicationContext applicationContext)
/*     */   {
/* 152 */     List beans = new ArrayList();
/* 153 */     for (String name : applicationContext.getBeanDefinitionNames()) {
/* 154 */       if (applicationContext.findAnnotationOnBean(name, ControllerAdvice.class) != null) {
/* 155 */         beans.add(new ControllerAdviceBean(name, applicationContext));
/*     */       }
/*     */     }
/* 158 */     return beans;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 167 */     return this.order;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 176 */     Class clazz = (this.bean instanceof String) ? this.beanFactory
/* 176 */       .getType((String)this.bean) : 
/* 176 */       this.bean.getClass();
/*     */ 
/* 178 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */ 
/*     */   public Object resolveBean()
/*     */   {
/* 185 */     return (this.bean instanceof String) ? this.beanFactory.getBean((String)this.bean) : this.bean;
/*     */   }
/*     */ 
/*     */   public boolean isApplicableToBeanType(Class<?> beanType)
/*     */   {
/* 196 */     if (!hasSelectors())
/* 197 */       return true;
/*     */     Class annotationClass;
/*     */     String packageName;
/* 199 */     if (beanType != null) {
/* 200 */       for (Class clazz : this.assignableTypes) {
/* 201 */         if (ClassUtils.isAssignable(clazz, beanType)) {
/* 202 */           return true;
/*     */         }
/*     */       }
/* 205 */       for (??? = this.annotations.iterator(); ???.hasNext(); ) { annotationClass = (Class)???.next();
/* 206 */         if (AnnotationUtils.findAnnotation(beanType, annotationClass) != null) {
/* 207 */           return true;
/*     */         }
/*     */       }
/* 210 */       packageName = beanType.getPackage().getName();
/* 211 */       for (Package basePackage : this.basePackages) {
/* 212 */         if (packageName.startsWith(basePackage.getName())) {
/* 213 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 217 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean hasSelectors() {
/* 221 */     return (!this.basePackages.isEmpty()) || (!this.annotations.isEmpty()) || (!this.assignableTypes.isEmpty());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 227 */     if (this == o) {
/* 228 */       return true;
/*     */     }
/* 230 */     if ((o != null) && ((o instanceof ControllerAdviceBean))) {
/* 231 */       ControllerAdviceBean other = (ControllerAdviceBean)o;
/* 232 */       return this.bean.equals(other.bean);
/*     */     }
/* 234 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 239 */     return 31 * this.bean.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 244 */     return this.bean.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.ControllerAdviceBean
 * JD-Core Version:    0.6.2
 */