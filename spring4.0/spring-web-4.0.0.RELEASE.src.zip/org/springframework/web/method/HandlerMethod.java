/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class HandlerMethod
/*     */ {
/*  50 */   protected final Log logger = LogFactory.getLog(HandlerMethod.class);
/*     */   private final Object bean;
/*     */   private final Method method;
/*     */   private final BeanFactory beanFactory;
/*     */   private final MethodParameter[] parameters;
/*     */   private final Method bridgedMethod;
/*     */ 
/*     */   public HandlerMethod(Object bean, Method method)
/*     */   {
/*  67 */     Assert.notNull(bean, "bean is required");
/*  68 */     Assert.notNull(method, "method is required");
/*  69 */     this.bean = bean;
/*  70 */     this.beanFactory = null;
/*  71 */     this.method = method;
/*  72 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  73 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   private MethodParameter[] initMethodParameters() {
/*  77 */     int count = this.bridgedMethod.getParameterTypes().length;
/*  78 */     MethodParameter[] result = new MethodParameter[count];
/*  79 */     for (int i = 0; i < count; i++) {
/*  80 */       result[i] = new HandlerMethodParameter(i);
/*     */     }
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */   public HandlerMethod(Object bean, String methodName, Class<?>[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  90 */     Assert.notNull(bean, "bean is required");
/*  91 */     Assert.notNull(methodName, "method is required");
/*  92 */     this.bean = bean;
/*  93 */     this.beanFactory = null;
/*  94 */     this.method = bean.getClass().getMethod(methodName, parameterTypes);
/*  95 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(this.method);
/*  96 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   public HandlerMethod(String beanName, BeanFactory beanFactory, Method method)
/*     */   {
/* 105 */     Assert.hasText(beanName, "beanName is required");
/* 106 */     Assert.notNull(beanFactory, "beanFactory is required");
/* 107 */     Assert.notNull(method, "method is required");
/* 108 */     Assert.isTrue(beanFactory.containsBean(beanName), "Bean factory [" + beanFactory + "] does not contain bean [" + beanName + "]");
/*     */ 
/* 110 */     this.bean = beanName;
/* 111 */     this.beanFactory = beanFactory;
/* 112 */     this.method = method;
/* 113 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 114 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   protected HandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/* 121 */     Assert.notNull(handlerMethod, "HandlerMethod is required");
/* 122 */     this.bean = handlerMethod.bean;
/* 123 */     this.beanFactory = handlerMethod.beanFactory;
/* 124 */     this.method = handlerMethod.method;
/* 125 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 126 */     this.parameters = handlerMethod.parameters;
/*     */   }
/*     */ 
/*     */   private HandlerMethod(HandlerMethod handlerMethod, Object handler)
/*     */   {
/* 133 */     Assert.notNull(handlerMethod, "handlerMethod is required");
/* 134 */     Assert.notNull(handler, "handler is required");
/* 135 */     this.bean = handler;
/* 136 */     this.beanFactory = handlerMethod.beanFactory;
/* 137 */     this.method = handlerMethod.method;
/* 138 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 139 */     this.parameters = handlerMethod.parameters;
/*     */   }
/*     */ 
/*     */   public Object getBean()
/*     */   {
/* 146 */     return this.bean;
/*     */   }
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/* 153 */     return this.method;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 162 */     Class clazz = (this.bean instanceof String) ? this.beanFactory
/* 162 */       .getType((String)this.bean) : 
/* 162 */       this.bean.getClass();
/* 163 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */ 
/*     */   protected Method getBridgedMethod()
/*     */   {
/* 171 */     return this.bridgedMethod;
/*     */   }
/*     */ 
/*     */   public MethodParameter[] getMethodParameters()
/*     */   {
/* 178 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public MethodParameter getReturnType()
/*     */   {
/* 185 */     return new HandlerMethodParameter(-1);
/*     */   }
/*     */ 
/*     */   public MethodParameter getReturnValueType(Object returnValue)
/*     */   {
/* 192 */     return new ReturnValueMethodParameter(returnValue);
/*     */   }
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 199 */     return Void.TYPE.equals(getReturnType().getParameterType());
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType)
/*     */   {
/* 209 */     return AnnotationUtils.findAnnotation(this.method, annotationType);
/*     */   }
/*     */ 
/*     */   public HandlerMethod createWithResolvedBean()
/*     */   {
/* 217 */     Object handler = this.bean;
/* 218 */     if ((this.bean instanceof String)) {
/* 219 */       String beanName = (String)this.bean;
/* 220 */       handler = this.beanFactory.getBean(beanName);
/*     */     }
/* 222 */     return new HandlerMethod(this, handler);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 227 */     if (this == obj) {
/* 228 */       return true;
/*     */     }
/* 230 */     if ((obj != null) && ((obj instanceof HandlerMethod))) {
/* 231 */       HandlerMethod other = (HandlerMethod)obj;
/* 232 */       return (this.bean.equals(other.bean)) && (this.method.equals(other.method));
/*     */     }
/* 234 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 239 */     return this.bean.hashCode() * 31 + this.method.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 244 */     return this.method.toGenericString();
/*     */   }
/*     */ 
/*     */   private class ReturnValueMethodParameter extends HandlerMethod.HandlerMethodParameter
/*     */   {
/*     */     private final Object returnValue;
/*     */ 
/*     */     public ReturnValueMethodParameter(Object returnValue)
/*     */     {
/* 277 */       super(-1);
/* 278 */       this.returnValue = returnValue;
/*     */     }
/*     */ 
/*     */     public Class<?> getParameterType()
/*     */     {
/* 283 */       return this.returnValue != null ? this.returnValue.getClass() : super.getParameterType();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class HandlerMethodParameter extends MethodParameter
/*     */   {
/*     */     public HandlerMethodParameter(int index)
/*     */     {
/* 254 */       super(index);
/*     */     }
/*     */ 
/*     */     public Class<?> getContainingClass()
/*     */     {
/* 259 */       return HandlerMethod.this.getBeanType();
/*     */     }
/*     */ 
/*     */     public <T extends Annotation> T getMethodAnnotation(Class<T> annotationType)
/*     */     {
/* 264 */       return HandlerMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.HandlerMethod
 * JD-Core Version:    0.6.2
 */