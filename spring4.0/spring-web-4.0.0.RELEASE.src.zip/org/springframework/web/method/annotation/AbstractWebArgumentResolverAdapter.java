/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public abstract class AbstractWebArgumentResolverAdapter
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  50 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   private final WebArgumentResolver adaptee;
/*     */ 
/*     */   public AbstractWebArgumentResolverAdapter(WebArgumentResolver adaptee)
/*     */   {
/*  58 */     Assert.notNull(adaptee, "'adaptee' must not be null");
/*  59 */     this.adaptee = adaptee;
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*     */     try
/*     */     {
/*  69 */       NativeWebRequest webRequest = getWebRequest();
/*  70 */       Object result = this.adaptee.resolveArgument(parameter, webRequest);
/*  71 */       if (result == WebArgumentResolver.UNRESOLVED) {
/*  72 */         return false;
/*     */       }
/*     */ 
/*  75 */       return ClassUtils.isAssignableValue(parameter.getParameterType(), result);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  80 */       this.logger.debug(new StringBuilder().append("Error in checking support for parameter [").append(parameter).append("], message: ").append(ex.getMessage()).toString());
/*  81 */     }return false;
/*     */   }
/*     */ 
/*     */   protected abstract NativeWebRequest getWebRequest();
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 101 */     Class paramType = parameter.getParameterType();
/* 102 */     Object result = this.adaptee.resolveArgument(parameter, webRequest);
/* 103 */     if ((result == WebArgumentResolver.UNRESOLVED) || (!ClassUtils.isAssignableValue(paramType, result)))
/*     */     {
/* 106 */       throw new IllegalStateException(new StringBuilder().append("Standard argument type [")
/* 105 */         .append(paramType
/* 105 */         .getName()).append("] in method ").append(parameter.getMethod()).append("resolved to incompatible value of type [")
/* 106 */         .append(result != null ? result
/* 106 */         .getClass() : null).append("]. Consider declaring the argument type in a less specific fashion.").toString());
/*     */     }
/*     */ 
/* 109 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.AbstractWebArgumentResolverAdapter
 * JD-Core Version:    0.6.2
 */