/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.ui.ModelMap;
/*    */ import org.springframework.validation.BindingResult;
/*    */ import org.springframework.validation.Errors;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class ErrorsMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 45 */     Class paramType = parameter.getParameterType();
/* 46 */     return Errors.class.isAssignableFrom(paramType);
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 55 */     ModelMap model = mavContainer.getModel();
/* 56 */     if (model.size() > 0) {
/* 57 */       int lastIndex = model.size() - 1;
/* 58 */       String lastKey = (String)new ArrayList(model.keySet()).get(lastIndex);
/* 59 */       if (lastKey.startsWith(BindingResult.MODEL_KEY_PREFIX)) {
/* 60 */         return model.get(lastKey);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 66 */     throw new IllegalStateException("An Errors/BindingResult argument is expected to be declared immediately after the model attribute, the @RequestBody or the @RequestPart arguments to which they apply: " + parameter
/* 66 */       .getMethod());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ErrorsMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */