/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.ExceptionDepthComparator;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ import org.springframework.web.method.HandlerMethodSelector;
/*     */ 
/*     */ public class ExceptionHandlerMethodResolver
/*     */ {
/*  46 */   private static final Method NO_METHOD_FOUND = ClassUtils.getMethodIfAvailable(System.class, "currentTimeMillis", new Class[0]);
/*     */ 
/*  48 */   private final Map<Class<? extends Throwable>, Method> mappedMethods = new ConcurrentHashMap(16);
/*     */ 
/*  51 */   private final Map<Class<? extends Throwable>, Method> exceptionLookupCache = new ConcurrentHashMap(16);
/*     */ 
/* 156 */   public static final ReflectionUtils.MethodFilter EXCEPTION_HANDLER_METHODS = new ReflectionUtils.MethodFilter()
/*     */   {
/*     */     public boolean matches(Method method)
/*     */     {
/* 160 */       return AnnotationUtils.findAnnotation(method, ExceptionHandler.class) != null;
/*     */     }
/* 156 */   };
/*     */ 
/*     */   public ExceptionHandlerMethodResolver(Class<?> handlerType)
/*     */   {
/*  59 */     for (Iterator localIterator1 = HandlerMethodSelector.selectMethods(handlerType, EXCEPTION_HANDLER_METHODS).iterator(); localIterator1.hasNext(); ) { method = (Method)localIterator1.next();
/*  60 */       for (Class exceptionType : detectExceptionMappings(method))
/*  61 */         addExceptionMapping(exceptionType, method);
/*     */     }
/*     */     Method method;
/*     */   }
/*     */ 
/*     */   private List<Class<? extends Throwable>> detectExceptionMappings(Method method)
/*     */   {
/*  72 */     List result = new ArrayList();
/*     */ 
/*  74 */     detectAnnotationExceptionMappings(method, result);
/*     */ 
/*  76 */     if (result.isEmpty()) {
/*  77 */       for (Class paramType : method.getParameterTypes()) {
/*  78 */         if (Throwable.class.isAssignableFrom(paramType)) {
/*  79 */           result.add(paramType);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  84 */     Assert.notEmpty(result, "No exception types mapped to {" + method + "}");
/*     */ 
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */   protected void detectAnnotationExceptionMappings(Method method, List<Class<? extends Throwable>> result) {
/*  90 */     ExceptionHandler annot = (ExceptionHandler)AnnotationUtils.findAnnotation(method, ExceptionHandler.class);
/*  91 */     result.addAll(Arrays.asList(annot.value()));
/*     */   }
/*     */ 
/*     */   private void addExceptionMapping(Class<? extends Throwable> exceptionType, Method method) {
/*  95 */     Method oldMethod = (Method)this.mappedMethods.put(exceptionType, method);
/*  96 */     if ((oldMethod != null) && (!oldMethod.equals(method)))
/*  97 */       throw new IllegalStateException("Ambiguous @ExceptionHandler method mapped for [" + exceptionType + "]: {" + oldMethod + ", " + method + "}.");
/*     */   }
/*     */ 
/*     */   public boolean hasExceptionMappings()
/*     */   {
/* 107 */     return this.mappedMethods.size() > 0;
/*     */   }
/*     */ 
/*     */   public Method resolveMethod(Exception exception)
/*     */   {
/* 117 */     return resolveMethodByExceptionType(exception.getClass());
/*     */   }
/*     */ 
/*     */   public Method resolveMethodByExceptionType(Class<? extends Exception> exceptionType)
/*     */   {
/* 127 */     Method method = (Method)this.exceptionLookupCache.get(exceptionType);
/* 128 */     if (method == null) {
/* 129 */       method = getMappedMethod(exceptionType);
/* 130 */       this.exceptionLookupCache.put(exceptionType, method != null ? method : NO_METHOD_FOUND);
/*     */     }
/* 132 */     return method != NO_METHOD_FOUND ? method : null;
/*     */   }
/*     */ 
/*     */   private Method getMappedMethod(Class<? extends Exception> exceptionType)
/*     */   {
/* 139 */     List matches = new ArrayList();
/* 140 */     for (Class mappedException : this.mappedMethods.keySet()) {
/* 141 */       if (mappedException.isAssignableFrom(exceptionType)) {
/* 142 */         matches.add(mappedException);
/*     */       }
/*     */     }
/* 145 */     if (!matches.isEmpty()) {
/* 146 */       Collections.sort(matches, new ExceptionDepthComparator(exceptionType));
/* 147 */       return (Method)this.mappedMethods.get(matches.get(0));
/*     */     }
/*     */ 
/* 150 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ExceptionHandlerMethodResolver
 * JD-Core Version:    0.6.2
 */