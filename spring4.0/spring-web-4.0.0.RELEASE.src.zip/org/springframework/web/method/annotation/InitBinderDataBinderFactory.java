/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.web.bind.WebDataBinder;
/*    */ import org.springframework.web.bind.annotation.InitBinder;
/*    */ import org.springframework.web.bind.support.DefaultDataBinderFactory;
/*    */ import org.springframework.web.bind.support.WebBindingInitializer;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.HandlerMethod;
/*    */ import org.springframework.web.method.support.InvocableHandlerMethod;
/*    */ 
/*    */ public class InitBinderDataBinderFactory extends DefaultDataBinderFactory
/*    */ {
/*    */   private final List<InvocableHandlerMethod> binderMethods;
/*    */ 
/*    */   public InitBinderDataBinderFactory(List<InvocableHandlerMethod> binderMethods, WebBindingInitializer initializer)
/*    */   {
/* 48 */     super(initializer);
/* 49 */     this.binderMethods = (binderMethods != null ? binderMethods : new ArrayList());
/*    */   }
/*    */ 
/*    */   public void initBinder(WebDataBinder binder, NativeWebRequest request)
/*    */     throws Exception
/*    */   {
/* 60 */     for (InvocableHandlerMethod binderMethod : this.binderMethods)
/* 61 */       if (isBinderMethodApplicable(binderMethod, binder)) {
/* 62 */         Object returnValue = binderMethod.invokeForRequest(request, null, new Object[] { binder });
/* 63 */         if (returnValue != null)
/* 64 */           throw new IllegalStateException("@InitBinder methods should return void: " + binderMethod);
/*    */       }
/*    */   }
/*    */ 
/*    */   protected boolean isBinderMethodApplicable(HandlerMethod initBinderMethod, WebDataBinder binder)
/*    */   {
/* 77 */     InitBinder annot = (InitBinder)initBinderMethod.getMethodAnnotation(InitBinder.class);
/* 78 */     Collection names = Arrays.asList(annot.value());
/* 79 */     return (names.size() == 0) || (names.contains(binder.getObjectName()));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.InitBinderDataBinderFactory
 * JD-Core Version:    0.6.2
 */