/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class MapMethodProcessor
/*    */   implements HandlerMethodArgumentResolver, HandlerMethodReturnValueHandler
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 43 */     return Map.class.isAssignableFrom(parameter.getParameterType());
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 52 */     return mavContainer.getModel();
/*    */   }
/*    */ 
/*    */   public boolean supportsReturnType(MethodParameter returnType)
/*    */   {
/* 57 */     return Map.class.isAssignableFrom(returnType.getParameterType());
/*    */   }
/*    */ 
/*    */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 67 */     if (returnValue == null) {
/* 68 */       return;
/*    */     }
/* 70 */     if ((returnValue instanceof Map)) {
/* 71 */       mavContainer.addAllAttributes((Map)returnValue);
/*    */     }
/*    */     else
/*    */     {
/* 76 */       throw new UnsupportedOperationException("Unexpected return type: " + returnType
/* 76 */         .getParameterType().getName() + " in method: " + returnType.getMethod());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.MapMethodProcessor
 * JD-Core Version:    0.6.2
 */