/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.bind.support.WebRequestDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public class ModelAttributeMethodProcessor
/*     */   implements HandlerMethodArgumentResolver, HandlerMethodReturnValueHandler
/*     */ {
/*  57 */   protected Log logger = LogFactory.getLog(getClass());
/*     */   private final boolean annotationNotRequired;
/*     */ 
/*     */   public ModelAttributeMethodProcessor(boolean annotationNotRequired)
/*     */   {
/*  67 */     this.annotationNotRequired = annotationNotRequired;
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  76 */     if (parameter.hasParameterAnnotation(ModelAttribute.class)) {
/*  77 */       return true;
/*     */     }
/*  79 */     if (this.annotationNotRequired) {
/*  80 */       return !BeanUtils.isSimpleProperty(parameter.getParameterType());
/*     */     }
/*     */ 
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   public final Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest request, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 102 */     String name = ModelFactory.getNameForParameter(parameter);
/*     */ 
/* 104 */     Object attribute = mavContainer.containsAttribute(name) ? mavContainer
/* 104 */       .getModel().get(name) : createAttribute(name, parameter, binderFactory, request);
/*     */ 
/* 106 */     WebDataBinder binder = binderFactory.createBinder(request, attribute, name);
/* 107 */     if (binder.getTarget() != null) {
/* 108 */       bindRequestParameters(binder, request);
/* 109 */       validateIfApplicable(binder, parameter);
/* 110 */       if ((binder.getBindingResult().hasErrors()) && 
/* 111 */         (isBindExceptionRequired(binder, parameter))) {
/* 112 */         throw new BindException(binder.getBindingResult());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 119 */     Map bindingResultModel = binder.getBindingResult().getModel();
/* 120 */     mavContainer.removeAttributes(bindingResultModel);
/* 121 */     mavContainer.addAllAttributes(bindingResultModel);
/*     */ 
/* 123 */     return binder.getTarget();
/*     */   }
/*     */ 
/*     */   protected Object createAttribute(String attributeName, MethodParameter parameter, WebDataBinderFactory binderFactory, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/* 138 */     return BeanUtils.instantiateClass(parameter.getParameterType());
/*     */   }
/*     */ 
/*     */   protected void bindRequestParameters(WebDataBinder binder, NativeWebRequest request)
/*     */   {
/* 147 */     ((WebRequestDataBinder)binder).bind(request);
/*     */   }
/*     */ 
/*     */   protected void validateIfApplicable(WebDataBinder binder, MethodParameter parameter)
/*     */   {
/* 157 */     Annotation[] annotations = parameter.getParameterAnnotations();
/* 158 */     for (Annotation annot : annotations)
/* 159 */       if (annot.annotationType().getSimpleName().startsWith("Valid")) {
/* 160 */         Object hints = AnnotationUtils.getValue(annot);
/* 161 */         binder.validate(new Object[] { (hints instanceof Object[]) ? (Object[])hints : hints });
/* 162 */         break;
/*     */       }
/*     */   }
/*     */ 
/*     */   protected boolean isBindExceptionRequired(WebDataBinder binder, MethodParameter parameter)
/*     */   {
/* 174 */     int i = parameter.getParameterIndex();
/* 175 */     Class[] paramTypes = parameter.getMethod().getParameterTypes();
/* 176 */     boolean hasBindingResult = (paramTypes.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/*     */ 
/* 178 */     return !hasBindingResult;
/*     */   }
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/* 187 */     if (returnType.getMethodAnnotation(ModelAttribute.class) != null) {
/* 188 */       return true;
/*     */     }
/* 190 */     if (this.annotationNotRequired) {
/* 191 */       return !BeanUtils.isSimpleProperty(returnType.getParameterType());
/*     */     }
/*     */ 
/* 194 */     return false;
/*     */   }
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 207 */     if (returnValue != null) {
/* 208 */       String name = ModelFactory.getNameForReturnValue(returnValue, returnType);
/* 209 */       mavContainer.addAttribute(name, returnValue);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ModelAttributeMethodProcessor
 * JD-Core Version:    0.6.2
 */