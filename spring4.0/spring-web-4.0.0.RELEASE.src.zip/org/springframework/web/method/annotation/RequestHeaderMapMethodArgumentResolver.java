/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.bind.annotation.RequestHeader;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class RequestHeaderMapMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 51 */     return (parameter.hasParameterAnnotation(RequestHeader.class)) && 
/* 51 */       (Map.class
/* 51 */       .isAssignableFrom(parameter
/* 51 */       .getParameterType()));
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 60 */     Class paramType = parameter.getParameterType();
/*    */ 
/* 62 */     if (MultiValueMap.class.isAssignableFrom(paramType))
/*    */     {
/*    */       MultiValueMap result;
/*    */       MultiValueMap result;
/* 64 */       if (HttpHeaders.class.isAssignableFrom(paramType)) {
/* 65 */         result = new HttpHeaders();
/*    */       }
/*    */       else {
/* 68 */         result = new LinkedMultiValueMap();
/*    */       }
/* 70 */       for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 71 */         String headerName = (String)iterator.next();
/* 72 */         for (String headerValue : webRequest.getHeaderValues(headerName)) {
/* 73 */           result.add(headerName, headerValue);
/*    */         }
/*    */       }
/* 76 */       return result;
/*    */     }
/*    */ 
/* 79 */     Map result = new LinkedHashMap();
/* 80 */     for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 81 */       String headerName = (String)iterator.next();
/* 82 */       String headerValue = webRequest.getHeader(headerName);
/* 83 */       result.put(headerName, headerValue);
/*    */     }
/* 85 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestHeaderMapMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */