/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.bind.ServletRequestBindingException;
/*    */ import org.springframework.web.bind.annotation.RequestHeader;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class RequestHeaderMethodArgumentResolver extends AbstractNamedValueMethodArgumentResolver
/*    */ {
/*    */   public RequestHeaderMethodArgumentResolver(ConfigurableBeanFactory beanFactory)
/*    */   {
/* 52 */     super(beanFactory);
/*    */   }
/*    */ 
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 58 */     return (parameter.hasParameterAnnotation(RequestHeader.class)) && 
/* 58 */       (!Map.class
/* 58 */       .isAssignableFrom(parameter
/* 58 */       .getParameterType()));
/*    */   }
/*    */ 
/*    */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*    */   {
/* 63 */     RequestHeader annotation = (RequestHeader)parameter.getParameterAnnotation(RequestHeader.class);
/* 64 */     return new RequestHeaderNamedValueInfo(annotation, null);
/*    */   }
/*    */ 
/*    */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest request) throws Exception
/*    */   {
/* 69 */     String[] headerValues = request.getHeaderValues(name);
/* 70 */     if (headerValues != null) {
/* 71 */       return headerValues.length == 1 ? headerValues[0] : headerValues;
/*    */     }
/*    */ 
/* 74 */     return null;
/*    */   }
/*    */ 
/*    */   protected void handleMissingValue(String headerName, MethodParameter param)
/*    */     throws ServletRequestBindingException
/*    */   {
/* 80 */     String paramType = param.getParameterType().getName();
/* 81 */     throw new ServletRequestBindingException("Missing header '" + headerName + "' for method parameter type [" + paramType + "]");
/*    */   }
/*    */ 
/*    */   private static class RequestHeaderNamedValueInfo extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*    */   {
/*    */     private RequestHeaderNamedValueInfo(RequestHeader annotation)
/*    */     {
/* 88 */       super(annotation.required(), annotation.defaultValue());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestHeaderMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */