/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.GenericCollectionTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.annotation.RequestPart;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.UriComponentsContributor;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class RequestParamMethodArgumentResolver extends AbstractNamedValueMethodArgumentResolver
/*     */   implements UriComponentsContributor
/*     */ {
/*  79 */   private static final TypeDescriptor STRING_TYPE_DESCRIPTOR = TypeDescriptor.valueOf(String.class);
/*     */   private final boolean useDefaultResolution;
/*     */ 
/*     */   public RequestParamMethodArgumentResolver(ConfigurableBeanFactory beanFactory, boolean useDefaultResolution)
/*     */   {
/*  95 */     super(beanFactory);
/*  96 */     this.useDefaultResolution = useDefaultResolution;
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/* 116 */     Class paramType = parameter.getParameterType();
/* 117 */     if (parameter.hasParameterAnnotation(RequestParam.class)) {
/* 118 */       if (Map.class.isAssignableFrom(paramType)) {
/* 119 */         String paramName = ((RequestParam)parameter.getParameterAnnotation(RequestParam.class)).value();
/* 120 */         return StringUtils.hasText(paramName);
/*     */       }
/*     */ 
/* 123 */       return true;
/*     */     }
/*     */ 
/* 127 */     if (parameter.hasParameterAnnotation(RequestPart.class)) {
/* 128 */       return false;
/*     */     }
/* 130 */     if ((MultipartFile.class.equals(paramType)) || ("javax.servlet.http.Part".equals(paramType.getName()))) {
/* 131 */       return true;
/*     */     }
/* 133 */     if (this.useDefaultResolution) {
/* 134 */       return BeanUtils.isSimpleProperty(paramType);
/*     */     }
/*     */ 
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*     */   {
/* 144 */     RequestParam annotation = (RequestParam)parameter.getParameterAnnotation(RequestParam.class);
/* 145 */     return annotation != null ? new RequestParamNamedValueInfo(annotation, null) : new RequestParamNamedValueInfo(null);
/*     */   }
/*     */ 
/*     */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 155 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*     */ 
/* 157 */     MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)WebUtils.getNativeRequest(servletRequest, MultipartHttpServletRequest.class);
/*     */     Object arg;
/*     */     Object arg;
/* 159 */     if (MultipartFile.class.equals(parameter.getParameterType())) {
/* 160 */       assertIsMultipartRequest(servletRequest);
/* 161 */       Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 162 */       arg = multipartRequest.getFile(name);
/*     */     }
/*     */     else
/*     */     {
/*     */       Object arg;
/* 164 */       if (isMultipartFileCollection(parameter)) {
/* 165 */         assertIsMultipartRequest(servletRequest);
/* 166 */         Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 167 */         arg = multipartRequest.getFiles(name);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object arg;
/* 169 */         if ("javax.servlet.http.Part".equals(parameter.getParameterType().getName())) {
/* 170 */           assertIsMultipartRequest(servletRequest);
/* 171 */           arg = servletRequest.getPart(name);
/*     */         }
/*     */         else
/*     */         {
/*     */           Object arg;
/* 173 */           if (isPartCollection(parameter)) {
/* 174 */             assertIsMultipartRequest(servletRequest);
/* 175 */             arg = new ArrayList(servletRequest.getParts());
/*     */           }
/*     */           else {
/* 178 */             arg = null;
/* 179 */             if (multipartRequest != null) {
/* 180 */               List files = multipartRequest.getFiles(name);
/* 181 */               if (!files.isEmpty()) {
/* 182 */                 arg = files.size() == 1 ? files.get(0) : files;
/*     */               }
/*     */             }
/* 185 */             if (arg == null) {
/* 186 */               String[] paramValues = webRequest.getParameterValues(name);
/* 187 */               if (paramValues != null)
/* 188 */                 arg = paramValues.length == 1 ? paramValues[0] : paramValues; 
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 193 */     return arg;
/*     */   }
/*     */ 
/*     */   private void assertIsMultipartRequest(HttpServletRequest request) {
/* 197 */     String contentType = request.getContentType();
/* 198 */     if ((contentType == null) || (!contentType.toLowerCase().startsWith("multipart/")))
/* 199 */       throw new MultipartException("The current request is not a multipart request");
/*     */   }
/*     */ 
/*     */   private boolean isMultipartFileCollection(MethodParameter parameter)
/*     */   {
/* 204 */     Class collectionType = getCollectionParameterType(parameter);
/* 205 */     return (collectionType != null) && (collectionType.equals(MultipartFile.class));
/*     */   }
/*     */ 
/*     */   private boolean isPartCollection(MethodParameter parameter) {
/* 209 */     Class collectionType = getCollectionParameterType(parameter);
/* 210 */     return (collectionType != null) && ("javax.servlet.http.Part".equals(collectionType.getName()));
/*     */   }
/*     */ 
/*     */   private Class<?> getCollectionParameterType(MethodParameter parameter) {
/* 214 */     Class paramType = parameter.getParameterType();
/* 215 */     if ((Collection.class.equals(paramType)) || (List.class.isAssignableFrom(paramType))) {
/* 216 */       Class valueType = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 217 */       if (valueType != null) {
/* 218 */         return valueType;
/*     */       }
/*     */     }
/* 221 */     return null;
/*     */   }
/*     */ 
/*     */   protected void handleMissingValue(String paramName, MethodParameter parameter) throws ServletException
/*     */   {
/* 226 */     throw new MissingServletRequestParameterException(paramName, parameter.getParameterType().getSimpleName());
/*     */   }
/*     */ 
/*     */   public void contributeMethodArgument(MethodParameter parameter, Object value, UriComponentsBuilder builder, Map<String, Object> uriVariables, ConversionService conversionService)
/*     */   {
/* 233 */     Class paramType = parameter.getParameterType();
/* 234 */     if ((Map.class.isAssignableFrom(paramType)) || (MultipartFile.class.equals(paramType)) || 
/* 235 */       ("javax.servlet.http.Part"
/* 235 */       .equals(paramType
/* 235 */       .getName()))) {
/* 236 */       return;
/*     */     }
/*     */ 
/* 239 */     RequestParam annot = (RequestParam)parameter.getParameterAnnotation(RequestParam.class);
/* 240 */     String name = StringUtils.isEmpty(annot.value()) ? parameter.getParameterName() : annot.value();
/*     */ 
/* 242 */     if (value == null) {
/* 243 */       builder.queryParam(name, new Object[0]);
/*     */     }
/*     */     else
/*     */     {
/*     */       Iterator localIterator;
/* 245 */       if ((value instanceof Collection)) {
/* 246 */         for (localIterator = ((Collection)value).iterator(); localIterator.hasNext(); ) { Object v = localIterator.next();
/* 247 */           v = formatUriValue(conversionService, TypeDescriptor.nested(parameter, 1), v);
/* 248 */           builder.queryParam(name, new Object[] { v });
/*     */         }
/*     */       }
/*     */       else
/* 252 */         builder.queryParam(name, new Object[] { formatUriValue(conversionService, new TypeDescriptor(parameter), value) });
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String formatUriValue(ConversionService cs, TypeDescriptor sourceType, Object value)
/*     */   {
/* 258 */     return cs != null ? 
/* 258 */       (String)cs
/* 258 */       .convert(value, sourceType, STRING_TYPE_DESCRIPTOR) : 
/* 258 */       null;
/*     */   }
/*     */ 
/*     */   private class RequestParamNamedValueInfo extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*     */   {
/*     */     private RequestParamNamedValueInfo()
/*     */     {
/* 265 */       super(false, "\n\t\t\n\t\t\n\n\t\t\t\t\n");
/*     */     }
/*     */ 
/*     */     private RequestParamNamedValueInfo(RequestParam annotation) {
/* 269 */       super(annotation.required(), annotation.defaultValue());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestParamMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */