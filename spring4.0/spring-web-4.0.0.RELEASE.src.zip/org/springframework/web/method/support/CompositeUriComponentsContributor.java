/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ public class CompositeUriComponentsContributor
/*     */   implements UriComponentsContributor
/*     */ {
/*  40 */   private final List<UriComponentsContributor> contributors = new ArrayList();
/*     */   private final ConversionService conversionService;
/*     */ 
/*     */   public CompositeUriComponentsContributor(Collection<?> contributors)
/*     */   {
/*  55 */     this(contributors, null);
/*     */   }
/*     */ 
/*     */   public CompositeUriComponentsContributor(Collection<?> contributors, ConversionService conversionService)
/*     */   {
/*  74 */     Assert.notNull(contributors, "'uriComponentsContributors' must not be null");
/*     */ 
/*  76 */     for (Iterator localIterator = contributors.iterator(); localIterator.hasNext(); ) { Object contributor = localIterator.next();
/*  77 */       if ((contributor instanceof UriComponentsContributor)) {
/*  78 */         this.contributors.add((UriComponentsContributor)contributor);
/*     */       }
/*     */     }
/*     */ 
/*  82 */     this.conversionService = (conversionService != null ? conversionService : new DefaultFormattingConversionService());
/*     */   }
/*     */ 
/*     */   public boolean hasContributors()
/*     */   {
/*  88 */     return this.contributors.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  93 */     for (UriComponentsContributor c : this.contributors) {
/*  94 */       if (c.supportsParameter(parameter)) {
/*  95 */         return true;
/*     */       }
/*     */     }
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   public void contributeMethodArgument(MethodParameter parameter, Object value, UriComponentsBuilder builder, Map<String, Object> uriVariables, ConversionService conversionService)
/*     */   {
/* 105 */     for (UriComponentsContributor c : this.contributors)
/* 106 */       if (c.supportsParameter(parameter)) {
/* 107 */         c.contributeMethodArgument(parameter, value, builder, uriVariables, conversionService);
/* 108 */         break;
/*     */       }
/*     */   }
/*     */ 
/*     */   public void contributeMethodArgument(MethodParameter parameter, Object value, UriComponentsBuilder builder, Map<String, Object> uriVariables)
/*     */   {
/* 119 */     contributeMethodArgument(parameter, value, builder, uriVariables, this.conversionService);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.CompositeUriComponentsContributor
 * JD-Core Version:    0.6.2
 */