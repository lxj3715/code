/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class HandlerMethodArgumentResolverComposite
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  42 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  44 */   private final List<HandlerMethodArgumentResolver> argumentResolvers = new LinkedList();
/*     */ 
/*  47 */   private final Map<MethodParameter, HandlerMethodArgumentResolver> argumentResolverCache = new ConcurrentHashMap(256);
/*     */ 
/*     */   public List<HandlerMethodArgumentResolver> getResolvers()
/*     */   {
/*  55 */     return Collections.unmodifiableList(this.argumentResolvers);
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  64 */     return getArgumentResolver(parameter) != null;
/*     */   }
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/*  77 */     HandlerMethodArgumentResolver resolver = getArgumentResolver(parameter);
/*  78 */     Assert.notNull(resolver, "Unknown parameter type [" + parameter.getParameterType().getName() + "]");
/*  79 */     return resolver.resolveArgument(parameter, mavContainer, webRequest, binderFactory);
/*     */   }
/*     */ 
/*     */   private HandlerMethodArgumentResolver getArgumentResolver(MethodParameter parameter)
/*     */   {
/*  86 */     HandlerMethodArgumentResolver result = (HandlerMethodArgumentResolver)this.argumentResolverCache.get(parameter);
/*  87 */     if (result == null) {
/*  88 */       for (HandlerMethodArgumentResolver methodArgumentResolver : this.argumentResolvers) {
/*  89 */         if (this.logger.isTraceEnabled()) {
/*  90 */           this.logger.trace("Testing if argument resolver [" + methodArgumentResolver + "] supports [" + parameter
/*  91 */             .getGenericParameterType() + "]");
/*     */         }
/*  93 */         if (methodArgumentResolver.supportsParameter(parameter)) {
/*  94 */           result = methodArgumentResolver;
/*  95 */           this.argumentResolverCache.put(parameter, result);
/*  96 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 100 */     return result;
/*     */   }
/*     */ 
/*     */   public HandlerMethodArgumentResolverComposite addResolver(HandlerMethodArgumentResolver argumentResolver)
/*     */   {
/* 107 */     this.argumentResolvers.add(argumentResolver);
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   public HandlerMethodArgumentResolverComposite addResolvers(List<? extends HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 116 */     if (argumentResolvers != null) {
/* 117 */       for (HandlerMethodArgumentResolver resolver : argumentResolvers) {
/* 118 */         this.argumentResolvers.add(resolver);
/*     */       }
/*     */     }
/* 121 */     return this;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.HandlerMethodArgumentResolverComposite
 * JD-Core Version:    0.6.2
 */