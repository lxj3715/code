/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class HandlerMethodReturnValueHandlerComposite
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*  38 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  40 */   private final List<HandlerMethodReturnValueHandler> returnValueHandlers = new ArrayList();
/*     */ 
/*     */   public List<HandlerMethodReturnValueHandler> getHandlers()
/*     */   {
/*  47 */     return Collections.unmodifiableList(this.returnValueHandlers);
/*     */   }
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*  56 */     return getReturnValueHandler(returnType) != null;
/*     */   }
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/*  69 */     HandlerMethodReturnValueHandler handler = getReturnValueHandler(returnType);
/*  70 */     Assert.notNull(handler, "Unknown return value type [" + returnType.getParameterType().getName() + "]");
/*  71 */     handler.handleReturnValue(returnValue, returnType, mavContainer, webRequest);
/*     */   }
/*     */ 
/*     */   private HandlerMethodReturnValueHandler getReturnValueHandler(MethodParameter returnType)
/*     */   {
/*  78 */     for (HandlerMethodReturnValueHandler returnValueHandler : this.returnValueHandlers) {
/*  79 */       if (this.logger.isTraceEnabled()) {
/*  80 */         this.logger.trace("Testing if return value handler [" + returnValueHandler + "] supports [" + returnType
/*  81 */           .getGenericParameterType() + "]");
/*     */       }
/*  83 */       if (returnValueHandler.supportsReturnType(returnType)) {
/*  84 */         return returnValueHandler;
/*     */       }
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   public HandlerMethodReturnValueHandlerComposite addHandler(HandlerMethodReturnValueHandler returnValuehandler)
/*     */   {
/*  94 */     this.returnValueHandlers.add(returnValuehandler);
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */   public HandlerMethodReturnValueHandlerComposite addHandlers(List<? extends HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 103 */     if (returnValueHandlers != null) {
/* 104 */       for (HandlerMethodReturnValueHandler handler : returnValueHandlers) {
/* 105 */         this.returnValueHandlers.add(handler);
/*     */       }
/*     */     }
/* 108 */     return this;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite
 * JD-Core Version:    0.6.2
 */