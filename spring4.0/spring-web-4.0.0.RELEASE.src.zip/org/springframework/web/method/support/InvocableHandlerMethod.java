/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ 
/*     */ public class InvocableHandlerMethod extends HandlerMethod
/*     */ {
/*  50 */   private HandlerMethodArgumentResolverComposite argumentResolvers = new HandlerMethodArgumentResolverComposite();
/*     */   private WebDataBinderFactory dataBinderFactory;
/*  54 */   private ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, Method method)
/*     */   {
/*  61 */     super(bean, method);
/*     */   }
/*     */ 
/*     */   public InvocableHandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/*  68 */     super(handlerMethod);
/*     */   }
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, String methodName, Class<?>[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  79 */     super(bean, methodName, parameterTypes);
/*     */   }
/*     */ 
/*     */   public void setDataBinderFactory(WebDataBinderFactory dataBinderFactory)
/*     */   {
/*  89 */     this.dataBinderFactory = dataBinderFactory;
/*     */   }
/*     */ 
/*     */   public void setHandlerMethodArgumentResolvers(HandlerMethodArgumentResolverComposite argumentResolvers)
/*     */   {
/*  96 */     this.argumentResolvers = argumentResolvers;
/*     */   }
/*     */ 
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 105 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */   public final Object invokeForRequest(NativeWebRequest request, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 124 */     Object[] args = getMethodArgumentValues(request, mavContainer, providedArgs);
/* 125 */     if (this.logger.isTraceEnabled()) {
/* 126 */       StringBuilder sb = new StringBuilder("Invoking [");
/* 127 */       sb.append(getBeanType().getSimpleName()).append(".");
/* 128 */       sb.append(getMethod().getName()).append("] method with arguments ");
/* 129 */       sb.append(Arrays.asList(args));
/* 130 */       this.logger.trace(sb.toString());
/*     */     }
/* 132 */     Object returnValue = invoke(args);
/* 133 */     if (this.logger.isTraceEnabled()) {
/* 134 */       this.logger.trace(new StringBuilder().append("Method [").append(getMethod().getName()).append("] returned [").append(returnValue).append("]").toString());
/*     */     }
/* 136 */     return returnValue;
/*     */   }
/*     */ 
/*     */   private Object[] getMethodArgumentValues(NativeWebRequest request, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 145 */     MethodParameter[] parameters = getMethodParameters();
/* 146 */     Object[] args = new Object[parameters.length];
/* 147 */     for (int i = 0; i < parameters.length; i++) {
/* 148 */       MethodParameter parameter = parameters[i];
/* 149 */       parameter.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 150 */       GenericTypeResolver.resolveParameterType(parameter, getBean().getClass());
/* 151 */       args[i] = resolveProvidedArgument(parameter, providedArgs);
/* 152 */       if (args[i] == null)
/*     */       {
/* 155 */         if (this.argumentResolvers.supportsParameter(parameter)) {
/*     */           try {
/* 157 */             args[i] = this.argumentResolvers.resolveArgument(parameter, mavContainer, request, this.dataBinderFactory);
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/* 161 */             if (this.logger.isTraceEnabled()) {
/* 162 */               this.logger.trace(getArgumentResolutionErrorMessage("Error resolving argument", i), ex);
/*     */             }
/* 164 */             throw ex;
/*     */           }
/*     */         }
/* 167 */         else if (args[i] == null) {
/* 168 */           String msg = getArgumentResolutionErrorMessage("No suitable resolver for argument", i);
/* 169 */           throw new IllegalStateException(msg);
/*     */         }
/*     */       }
/*     */     }
/* 172 */     return args;
/*     */   }
/*     */ 
/*     */   private String getArgumentResolutionErrorMessage(String message, int index) {
/* 176 */     MethodParameter param = getMethodParameters()[index];
/* 177 */     message = new StringBuilder().append(message).append(" [").append(index).append("] [type=").append(param.getParameterType().getName()).append("]").toString();
/* 178 */     return getDetailedErrorMessage(message);
/*     */   }
/*     */ 
/*     */   protected String getDetailedErrorMessage(String message)
/*     */   {
/* 186 */     StringBuilder sb = new StringBuilder(message).append("\n");
/* 187 */     sb.append("HandlerMethod details: \n");
/* 188 */     sb.append("Controller [").append(getBeanType().getName()).append("]\n");
/* 189 */     sb.append("Method [").append(getBridgedMethod().toGenericString()).append("]\n");
/* 190 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private Object resolveProvidedArgument(MethodParameter parameter, Object[] providedArgs)
/*     */   {
/* 197 */     if (providedArgs == null) {
/* 198 */       return null;
/*     */     }
/* 200 */     for (Object providedArg : providedArgs) {
/* 201 */       if (parameter.getParameterType().isInstance(providedArg)) {
/* 202 */         return providedArg;
/*     */       }
/*     */     }
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   private Object invoke(Object[] args)
/*     */     throws Exception
/*     */   {
/* 212 */     ReflectionUtils.makeAccessible(getBridgedMethod());
/*     */     try {
/* 214 */       return getBridgedMethod().invoke(getBean(), args);
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 217 */       String msg = getInvocationErrorMessage(e.getMessage(), args);
/* 218 */       throw new IllegalArgumentException(msg, e);
/*     */     }
/*     */     catch (InvocationTargetException e)
/*     */     {
/* 222 */       Throwable targetException = e.getTargetException();
/* 223 */       if ((targetException instanceof RuntimeException)) {
/* 224 */         throw ((RuntimeException)targetException);
/*     */       }
/* 226 */       if ((targetException instanceof Error)) {
/* 227 */         throw ((Error)targetException);
/*     */       }
/* 229 */       if ((targetException instanceof Exception)) {
/* 230 */         throw ((Exception)targetException);
/*     */       }
/*     */ 
/* 233 */       String msg = getInvocationErrorMessage("Failed to invoke controller method", args);
/* 234 */       throw new IllegalStateException(msg, targetException);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getInvocationErrorMessage(String message, Object[] resolvedArgs)
/*     */   {
/* 240 */     StringBuilder sb = new StringBuilder(getDetailedErrorMessage(message));
/* 241 */     sb.append("Resolved arguments: \n");
/* 242 */     for (int i = 0; i < resolvedArgs.length; i++) {
/* 243 */       sb.append("[").append(i).append("] ");
/* 244 */       if (resolvedArgs[i] == null) {
/* 245 */         sb.append("[null] \n");
/*     */       }
/*     */       else {
/* 248 */         sb.append("[type=").append(resolvedArgs[i].getClass().getName()).append("] ");
/* 249 */         sb.append("[value=").append(resolvedArgs[i]).append("]\n");
/*     */       }
/*     */     }
/* 252 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.InvocableHandlerMethod
 * JD-Core Version:    0.6.2
 */