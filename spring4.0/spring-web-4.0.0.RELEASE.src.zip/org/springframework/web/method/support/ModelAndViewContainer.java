/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.support.BindingAwareModelMap;
/*     */ import org.springframework.web.bind.support.SessionStatus;
/*     */ import org.springframework.web.bind.support.SimpleSessionStatus;
/*     */ 
/*     */ public class ModelAndViewContainer
/*     */ {
/*     */   private Object view;
/*  49 */   private boolean requestHandled = false;
/*     */ 
/*  51 */   private final ModelMap defaultModel = new BindingAwareModelMap();
/*     */   private ModelMap redirectModel;
/*  55 */   private boolean redirectModelScenario = false;
/*     */ 
/*  57 */   private boolean ignoreDefaultModelOnRedirect = false;
/*     */ 
/*  59 */   private final SessionStatus sessionStatus = new SimpleSessionStatus();
/*     */ 
/*     */   public void setViewName(String viewName)
/*     */   {
/*  72 */     this.view = viewName;
/*     */   }
/*     */ 
/*     */   public String getViewName()
/*     */   {
/*  80 */     return (this.view instanceof String) ? (String)this.view : null;
/*     */   }
/*     */ 
/*     */   public void setView(Object view)
/*     */   {
/*  88 */     this.view = view;
/*     */   }
/*     */ 
/*     */   public Object getView()
/*     */   {
/*  96 */     return this.view;
/*     */   }
/*     */ 
/*     */   public boolean isViewReference()
/*     */   {
/* 104 */     return this.view instanceof String;
/*     */   }
/*     */ 
/*     */   public void setRequestHandled(boolean requestHandled)
/*     */   {
/* 119 */     this.requestHandled = requestHandled;
/*     */   }
/*     */ 
/*     */   public boolean isRequestHandled()
/*     */   {
/* 126 */     return this.requestHandled;
/*     */   }
/*     */ 
/*     */   public ModelMap getModel()
/*     */   {
/* 136 */     if (useDefaultModel()) {
/* 137 */       return this.defaultModel;
/*     */     }
/*     */ 
/* 140 */     return this.redirectModel != null ? this.redirectModel : new ModelMap();
/*     */   }
/*     */ 
/*     */   private boolean useDefaultModel()
/*     */   {
/* 148 */     return (!this.redirectModelScenario) || ((this.redirectModel == null) && (!this.ignoreDefaultModelOnRedirect));
/*     */   }
/*     */ 
/*     */   public void setRedirectModel(ModelMap redirectModel)
/*     */   {
/* 158 */     this.redirectModel = redirectModel;
/*     */   }
/*     */ 
/*     */   public void setRedirectModelScenario(boolean redirectModelScenario)
/*     */   {
/* 166 */     this.redirectModelScenario = redirectModelScenario;
/*     */   }
/*     */ 
/*     */   public void setIgnoreDefaultModelOnRedirect(boolean ignoreDefaultModelOnRedirect)
/*     */   {
/* 178 */     this.ignoreDefaultModelOnRedirect = ignoreDefaultModelOnRedirect;
/*     */   }
/*     */ 
/*     */   public SessionStatus getSessionStatus()
/*     */   {
/* 186 */     return this.sessionStatus;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer addAttribute(String name, Object value)
/*     */   {
/* 194 */     getModel().addAttribute(name, value);
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer addAttribute(Object value)
/*     */   {
/* 203 */     getModel().addAttribute(value);
/* 204 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer addAllAttributes(Map<String, ?> attributes)
/*     */   {
/* 212 */     getModel().addAllAttributes(attributes);
/* 213 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer mergeAttributes(Map<String, ?> attributes)
/*     */   {
/* 222 */     getModel().mergeAttributes(attributes);
/* 223 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer removeAttributes(Map<String, ?> attributes)
/*     */   {
/* 230 */     if (attributes != null) {
/* 231 */       for (String key : attributes.keySet()) {
/* 232 */         getModel().remove(key);
/*     */       }
/*     */     }
/* 235 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean containsAttribute(String name)
/*     */   {
/* 243 */     return getModel().containsAttribute(name);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 251 */     StringBuilder sb = new StringBuilder("ModelAndViewContainer: ");
/* 252 */     if (!isRequestHandled()) {
/* 253 */       if (isViewReference()) {
/* 254 */         sb.append("reference to view with name '").append(this.view).append("'");
/*     */       }
/*     */       else {
/* 257 */         sb.append("View is [").append(this.view).append(']');
/*     */       }
/* 259 */       if (useDefaultModel()) {
/* 260 */         sb.append("; default model ");
/*     */       }
/*     */       else {
/* 263 */         sb.append("; redirect model ");
/*     */       }
/* 265 */       sb.append(getModel());
/*     */     }
/*     */     else {
/* 268 */       sb.append("Request handled directly");
/*     */     }
/* 270 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.ModelAndViewContainer
 * JD-Core Version:    0.6.2
 */