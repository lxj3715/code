/*     */ package org.springframework.web.multipart.commons;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItem;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class CommonsMultipartFile
/*     */   implements MultipartFile, Serializable
/*     */ {
/*  43 */   protected static final Log logger = LogFactory.getLog(CommonsMultipartFile.class);
/*     */   private final FileItem fileItem;
/*     */   private final long size;
/*     */ 
/*     */   public CommonsMultipartFile(FileItem fileItem)
/*     */   {
/*  55 */     this.fileItem = fileItem;
/*  56 */     this.size = this.fileItem.getSize();
/*     */   }
/*     */ 
/*     */   public final FileItem getFileItem()
/*     */   {
/*  64 */     return this.fileItem;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  70 */     return this.fileItem.getFieldName();
/*     */   }
/*     */ 
/*     */   public String getOriginalFilename()
/*     */   {
/*  75 */     String filename = this.fileItem.getName();
/*  76 */     if (filename == null)
/*     */     {
/*  78 */       return "";
/*     */     }
/*     */ 
/*  81 */     int pos = filename.lastIndexOf("/");
/*  82 */     if (pos == -1)
/*     */     {
/*  84 */       pos = filename.lastIndexOf("\\");
/*     */     }
/*  86 */     if (pos != -1)
/*     */     {
/*  88 */       return filename.substring(pos + 1);
/*     */     }
/*     */ 
/*  92 */     return filename;
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  98 */     return this.fileItem.getContentType();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 103 */     return this.size == 0L;
/*     */   }
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 108 */     return this.size;
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 113 */     if (!isAvailable()) {
/* 114 */       throw new IllegalStateException("File has been moved - cannot be read again");
/*     */     }
/* 116 */     byte[] bytes = this.fileItem.get();
/* 117 */     return bytes != null ? bytes : new byte[0];
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream() throws IOException
/*     */   {
/* 122 */     if (!isAvailable()) {
/* 123 */       throw new IllegalStateException("File has been moved - cannot be read again");
/*     */     }
/* 125 */     InputStream inputStream = this.fileItem.getInputStream();
/* 126 */     return inputStream != null ? inputStream : new ByteArrayInputStream(new byte[0]);
/*     */   }
/*     */ 
/*     */   public void transferTo(File dest) throws IOException, IllegalStateException
/*     */   {
/* 131 */     if (!isAvailable()) {
/* 132 */       throw new IllegalStateException("File has already been moved - cannot be transferred again");
/*     */     }
/*     */ 
/* 135 */     if ((dest.exists()) && (!dest.delete()))
/*     */     {
/* 137 */       throw new IOException("Destination file [" + dest
/* 137 */         .getAbsolutePath() + "] already exists and could not be deleted");
/*     */     }
/*     */     try
/*     */     {
/* 141 */       this.fileItem.write(dest);
/* 142 */       if (logger.isDebugEnabled()) {
/* 143 */         String action = "transferred";
/* 144 */         if (!this.fileItem.isInMemory()) {
/* 145 */           action = isAvailable() ? "copied" : "moved";
/*     */         }
/* 147 */         logger.debug("Multipart file '" + getName() + "' with original filename [" + 
/* 148 */           getOriginalFilename() + "], stored " + getStorageDescription() + ": " + action + " to [" + dest
/* 149 */           .getAbsolutePath() + "]");
/*     */       }
/*     */     }
/*     */     catch (FileUploadException ex) {
/* 153 */       throw new IllegalStateException(ex.getMessage());
/*     */     }
/*     */     catch (IOException ex) {
/* 156 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/* 159 */       logger.error("Could not transfer to file", ex);
/* 160 */       throw new IOException("Could not transfer to file: " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isAvailable()
/*     */   {
/* 170 */     if (this.fileItem.isInMemory()) {
/* 171 */       return true;
/*     */     }
/*     */ 
/* 174 */     if ((this.fileItem instanceof DiskFileItem)) {
/* 175 */       return ((DiskFileItem)this.fileItem).getStoreLocation().exists();
/*     */     }
/*     */ 
/* 178 */     return this.fileItem.getSize() == this.size;
/*     */   }
/*     */ 
/*     */   public String getStorageDescription()
/*     */   {
/* 187 */     if (this.fileItem.isInMemory()) {
/* 188 */       return "in memory";
/*     */     }
/* 190 */     if ((this.fileItem instanceof DiskFileItem)) {
/* 191 */       return "at [" + ((DiskFileItem)this.fileItem).getStoreLocation().getAbsolutePath() + "]";
/*     */     }
/*     */ 
/* 194 */     return "on disk";
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.commons.CommonsMultipartFile
 * JD-Core Version:    0.6.2
 */