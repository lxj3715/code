/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class DefaultMultipartHttpServletRequest extends AbstractMultipartHttpServletRequest
/*     */ {
/*     */   private static final String CONTENT_TYPE = "Content-Type";
/*     */   private Map<String, String[]> multipartParameters;
/*     */   private Map<String, String> multipartParameterContentTypes;
/*     */ 
/*     */   public DefaultMultipartHttpServletRequest(HttpServletRequest request, MultiValueMap<String, MultipartFile> mpFiles, Map<String, String[]> mpParams, Map<String, String> mpParamContentTypes)
/*     */   {
/*  61 */     super(request);
/*  62 */     setMultipartFiles(mpFiles);
/*  63 */     setMultipartParameters(mpParams);
/*  64 */     setMultipartParameterContentTypes(mpParamContentTypes);
/*     */   }
/*     */ 
/*     */   public DefaultMultipartHttpServletRequest(HttpServletRequest request)
/*     */   {
/*  72 */     super(request);
/*     */   }
/*     */ 
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/*  78 */     Set paramNames = new HashSet();
/*  79 */     Enumeration paramEnum = super.getParameterNames();
/*  80 */     while (paramEnum.hasMoreElements()) {
/*  81 */       paramNames.add(paramEnum.nextElement());
/*     */     }
/*  83 */     paramNames.addAll(getMultipartParameters().keySet());
/*  84 */     return Collections.enumeration(paramNames);
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/*  89 */     String[] values = (String[])getMultipartParameters().get(name);
/*  90 */     if (values != null) {
/*  91 */       return values.length > 0 ? values[0] : null;
/*     */     }
/*  93 */     return super.getParameter(name);
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String name)
/*     */   {
/*  98 */     String[] values = (String[])getMultipartParameters().get(name);
/*  99 */     if (values != null) {
/* 100 */       return values;
/*     */     }
/* 102 */     return super.getParameterValues(name);
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 107 */     Map paramMap = new HashMap();
/* 108 */     paramMap.putAll(super.getParameterMap());
/* 109 */     paramMap.putAll(getMultipartParameters());
/* 110 */     return paramMap;
/*     */   }
/*     */ 
/*     */   public String getMultipartContentType(String paramOrFileName)
/*     */   {
/* 115 */     MultipartFile file = getFile(paramOrFileName);
/* 116 */     if (file != null) {
/* 117 */       return file.getContentType();
/*     */     }
/*     */ 
/* 120 */     return (String)getMultipartParameterContentTypes().get(paramOrFileName);
/*     */   }
/*     */ 
/*     */   public HttpHeaders getMultipartHeaders(String paramOrFileName)
/*     */   {
/* 126 */     String contentType = getMultipartContentType(paramOrFileName);
/* 127 */     if (contentType != null) {
/* 128 */       HttpHeaders headers = new HttpHeaders();
/* 129 */       headers.add("Content-Type", contentType);
/* 130 */       return headers;
/*     */     }
/*     */ 
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   protected final void setMultipartParameters(Map<String, String[]> multipartParameters)
/*     */   {
/* 143 */     this.multipartParameters = multipartParameters;
/*     */   }
/*     */ 
/*     */   protected Map<String, String[]> getMultipartParameters()
/*     */   {
/* 152 */     if (this.multipartParameters == null) {
/* 153 */       initializeMultipart();
/*     */     }
/* 155 */     return this.multipartParameters;
/*     */   }
/*     */ 
/*     */   protected final void setMultipartParameterContentTypes(Map<String, String> multipartParameterContentTypes)
/*     */   {
/* 163 */     this.multipartParameterContentTypes = multipartParameterContentTypes;
/*     */   }
/*     */ 
/*     */   protected Map<String, String> getMultipartParameterContentTypes()
/*     */   {
/* 172 */     if (this.multipartParameterContentTypes == null) {
/* 173 */       initializeMultipart();
/*     */     }
/* 175 */     return this.multipartParameterContentTypes;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.DefaultMultipartHttpServletRequest
 * JD-Core Version:    0.6.2
 */