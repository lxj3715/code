/*    */ package org.springframework.web.multipart.support;
/*    */ 
/*    */ import javax.servlet.ServletException;
/*    */ 
/*    */ public class MissingServletRequestPartException extends ServletException
/*    */ {
/*    */   private static final long serialVersionUID = -1255077391966870705L;
/*    */   private final String partName;
/*    */ 
/*    */   public MissingServletRequestPartException(String partName)
/*    */   {
/* 43 */     super("Required request part '" + partName + "' is not present.");
/* 44 */     this.partName = partName;
/*    */   }
/*    */ 
/*    */   public String getRequestPartName() {
/* 48 */     return this.partName;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.MissingServletRequestPartException
 * JD-Core Version:    0.6.2
 */