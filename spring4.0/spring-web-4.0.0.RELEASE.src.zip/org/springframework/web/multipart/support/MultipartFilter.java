/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.multipart.MultipartResolver;
/*     */ 
/*     */ public class MultipartFilter extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_MULTIPART_RESOLVER_BEAN_NAME = "filterMultipartResolver";
/*  68 */   private final MultipartResolver defaultMultipartResolver = new StandardServletMultipartResolver();
/*     */ 
/*  70 */   private String multipartResolverBeanName = "filterMultipartResolver";
/*     */ 
/*     */   public void setMultipartResolverBeanName(String multipartResolverBeanName)
/*     */   {
/*  78 */     this.multipartResolverBeanName = multipartResolverBeanName;
/*     */   }
/*     */ 
/*     */   protected String getMultipartResolverBeanName()
/*     */   {
/*  86 */     return this.multipartResolverBeanName;
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 102 */     MultipartResolver multipartResolver = lookupMultipartResolver(request);
/*     */ 
/* 104 */     HttpServletRequest processedRequest = request;
/* 105 */     if (multipartResolver.isMultipart(processedRequest)) {
/* 106 */       if (this.logger.isDebugEnabled()) {
/* 107 */         this.logger.debug("Resolving multipart request [" + processedRequest.getRequestURI() + "] with MultipartFilter");
/*     */       }
/*     */ 
/* 110 */       processedRequest = multipartResolver.resolveMultipart(processedRequest);
/*     */     }
/* 113 */     else if (this.logger.isDebugEnabled()) {
/* 114 */       this.logger.debug("Request [" + processedRequest.getRequestURI() + "] is not a multipart request");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 119 */       filterChain.doFilter(processedRequest, response);
/*     */     }
/*     */     finally {
/* 122 */       if ((processedRequest instanceof MultipartHttpServletRequest))
/* 123 */         multipartResolver.cleanupMultipart((MultipartHttpServletRequest)processedRequest);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected MultipartResolver lookupMultipartResolver(HttpServletRequest request)
/*     */   {
/* 137 */     return lookupMultipartResolver();
/*     */   }
/*     */ 
/*     */   protected MultipartResolver lookupMultipartResolver()
/*     */   {
/* 149 */     WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
/* 150 */     String beanName = getMultipartResolverBeanName();
/* 151 */     if ((wac != null) && (wac.containsBean(beanName))) {
/* 152 */       if (this.logger.isDebugEnabled()) {
/* 153 */         this.logger.debug("Using MultipartResolver '" + beanName + "' for MultipartFilter");
/*     */       }
/* 155 */       return (MultipartResolver)wac.getBean(beanName, MultipartResolver.class);
/*     */     }
/*     */ 
/* 158 */     return this.defaultMultipartResolver;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.MultipartFilter
 * JD-Core Version:    0.6.2
 */