/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ 
/*     */ public class RequestPartServletServerHttpRequest extends ServletServerHttpRequest
/*     */ {
/*     */   private final MultipartHttpServletRequest multipartRequest;
/*     */   private final String partName;
/*     */   private final HttpHeaders headers;
/*     */ 
/*     */   public RequestPartServletServerHttpRequest(HttpServletRequest request, String partName)
/*     */     throws MissingServletRequestPartException
/*     */   {
/*  63 */     super(request);
/*     */ 
/*  65 */     this.multipartRequest = asMultipartRequest(request);
/*  66 */     this.partName = partName;
/*     */ 
/*  68 */     this.headers = this.multipartRequest.getMultipartHeaders(this.partName);
/*  69 */     if (this.headers == null) {
/*  70 */       if ((request instanceof MultipartHttpServletRequest)) {
/*  71 */         throw new MissingServletRequestPartException(partName);
/*     */       }
/*     */ 
/*  74 */       throw new IllegalArgumentException("Failed to obtain request part: " + partName + ". " + "The part is missing or multipart processing is not configured. " + "Check for a MultipartResolver bean or if Servlet 3.0 multipart processing is enabled.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static MultipartHttpServletRequest asMultipartRequest(HttpServletRequest request)
/*     */   {
/*  83 */     if ((request instanceof MultipartHttpServletRequest)) {
/*  84 */       return (MultipartHttpServletRequest)request;
/*     */     }
/*  86 */     if (ClassUtils.hasMethod(HttpServletRequest.class, "getParts", new Class[0]))
/*     */     {
/*  88 */       return new StandardMultipartHttpServletRequest(request);
/*     */     }
/*  90 */     throw new IllegalArgumentException("Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/*     */   }
/*     */ 
/*     */   public HttpHeaders getHeaders()
/*     */   {
/*  95 */     return this.headers;
/*     */   }
/*     */ 
/*     */   public InputStream getBody() throws IOException
/*     */   {
/* 100 */     if ((this.multipartRequest instanceof StandardMultipartHttpServletRequest)) {
/*     */       try {
/* 102 */         return this.multipartRequest.getPart(this.partName).getInputStream();
/*     */       }
/*     */       catch (Exception ex) {
/* 105 */         throw new MultipartException("Could not parse multipart servlet request", ex);
/*     */       }
/*     */     }
/*     */ 
/* 109 */     MultipartFile file = this.multipartRequest.getFile(this.partName);
/* 110 */     if (file != null) {
/* 111 */       return file.getInputStream();
/*     */     }
/*     */ 
/* 114 */     String paramValue = this.multipartRequest.getParameter(this.partName);
/* 115 */     return new ByteArrayInputStream(paramValue.getBytes("UTF-8"));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.RequestPartServletServerHttpRequest
 * JD-Core Version:    0.6.2
 */