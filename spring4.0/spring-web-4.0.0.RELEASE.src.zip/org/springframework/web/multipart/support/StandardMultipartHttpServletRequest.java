/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class StandardMultipartHttpServletRequest extends AbstractMultipartHttpServletRequest
/*     */ {
/*     */   private static final String CONTENT_DISPOSITION = "content-disposition";
/*     */   private static final String FILENAME_KEY = "filename=";
/*     */ 
/*     */   public StandardMultipartHttpServletRequest(HttpServletRequest request)
/*     */     throws MultipartException
/*     */   {
/*  55 */     super(request);
/*     */     try {
/*  57 */       Collection parts = request.getParts();
/*  58 */       MultiValueMap files = new LinkedMultiValueMap(parts.size());
/*  59 */       for (Part part : parts) {
/*  60 */         String filename = extractFilename(part.getHeader("content-disposition"));
/*  61 */         if (filename != null) {
/*  62 */           files.add(part.getName(), new StandardMultipartFile(part, filename));
/*     */         }
/*     */       }
/*  65 */       setMultipartFiles(files);
/*     */     }
/*     */     catch (Exception ex) {
/*  68 */       throw new MultipartException("Could not parse multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String extractFilename(String contentDisposition) {
/*  73 */     if (contentDisposition == null) {
/*  74 */       return null;
/*     */     }
/*     */ 
/*  77 */     int startIndex = contentDisposition.indexOf("filename=");
/*  78 */     if (startIndex == -1) {
/*  79 */       return null;
/*     */     }
/*  81 */     String filename = contentDisposition.substring(startIndex + "filename=".length());
/*  82 */     if (filename.startsWith("\"")) {
/*  83 */       int endIndex = filename.indexOf("\"", 1);
/*  84 */       if (endIndex != -1)
/*  85 */         return filename.substring(1, endIndex);
/*     */     }
/*     */     else
/*     */     {
/*  89 */       int endIndex = filename.indexOf(";");
/*  90 */       if (endIndex != -1) {
/*  91 */         return filename.substring(0, endIndex);
/*     */       }
/*     */     }
/*  94 */     return filename;
/*     */   }
/*     */ 
/*     */   public String getMultipartContentType(String paramOrFileName)
/*     */   {
/*     */     try
/*     */     {
/* 101 */       Part part = getPart(paramOrFileName);
/* 102 */       return part != null ? part.getContentType() : null;
/*     */     }
/*     */     catch (Exception ex) {
/* 105 */       throw new MultipartException("Could not access multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders getMultipartHeaders(String paramOrFileName)
/*     */   {
/*     */     try {
/* 112 */       Part part = getPart(paramOrFileName);
/* 113 */       if (part != null) {
/* 114 */         HttpHeaders headers = new HttpHeaders();
/* 115 */         for (String headerName : part.getHeaderNames()) {
/* 116 */           headers.put(headerName, new ArrayList(part.getHeaders(headerName)));
/*     */         }
/* 118 */         return headers;
/*     */       }
/*     */ 
/* 121 */       return null;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 125 */       throw new MultipartException("Could not access multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class StandardMultipartFile
/*     */     implements MultipartFile
/*     */   {
/*     */     private final Part part;
/*     */     private final String filename;
/*     */ 
/*     */     public StandardMultipartFile(Part part, String filename)
/*     */     {
/* 140 */       this.part = part;
/* 141 */       this.filename = filename;
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/* 146 */       return this.part.getName();
/*     */     }
/*     */ 
/*     */     public String getOriginalFilename()
/*     */     {
/* 151 */       return this.filename;
/*     */     }
/*     */ 
/*     */     public String getContentType()
/*     */     {
/* 156 */       return this.part.getContentType();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty()
/*     */     {
/* 161 */       return this.part.getSize() == 0L;
/*     */     }
/*     */ 
/*     */     public long getSize()
/*     */     {
/* 166 */       return this.part.getSize();
/*     */     }
/*     */ 
/*     */     public byte[] getBytes() throws IOException
/*     */     {
/* 171 */       return FileCopyUtils.copyToByteArray(this.part.getInputStream());
/*     */     }
/*     */ 
/*     */     public InputStream getInputStream() throws IOException
/*     */     {
/* 176 */       return this.part.getInputStream();
/*     */     }
/*     */ 
/*     */     public void transferTo(File dest) throws IOException, IllegalStateException
/*     */     {
/* 181 */       this.part.write(dest.getPath());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.StandardMultipartHttpServletRequest
 * JD-Core Version:    0.6.2
 */