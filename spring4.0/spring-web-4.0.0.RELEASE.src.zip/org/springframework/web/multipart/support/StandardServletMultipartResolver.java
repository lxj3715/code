/*    */ package org.springframework.web.multipart.support;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.Part;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.multipart.MultipartException;
/*    */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*    */ import org.springframework.web.multipart.MultipartResolver;
/*    */ 
/*    */ public class StandardServletMultipartResolver
/*    */   implements MultipartResolver
/*    */ {
/*    */   public boolean isMultipart(HttpServletRequest request)
/*    */   {
/* 51 */     if (!"post".equals(request.getMethod().toLowerCase())) {
/* 52 */       return false;
/*    */     }
/* 54 */     String contentType = request.getContentType();
/* 55 */     return (contentType != null) && (contentType.toLowerCase().startsWith("multipart/"));
/*    */   }
/*    */ 
/*    */   public MultipartHttpServletRequest resolveMultipart(HttpServletRequest request) throws MultipartException
/*    */   {
/* 60 */     return new StandardMultipartHttpServletRequest(request);
/*    */   }
/*    */ 
/*    */   public void cleanupMultipart(MultipartHttpServletRequest request)
/*    */   {
/*    */     try
/*    */     {
/* 68 */       for (Part part : request.getParts()) {
/* 69 */         if (request.getFile(part.getName()) != null)
/* 70 */           part.delete();
/*    */       }
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 75 */       LogFactory.getLog(getClass()).warn("Failed to perform cleanup of multipart items", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.StandardServletMultipartResolver
 * JD-Core Version:    0.6.2
 */