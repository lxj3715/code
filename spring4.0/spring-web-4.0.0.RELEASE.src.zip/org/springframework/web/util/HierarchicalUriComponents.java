/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ final class HierarchicalUriComponents extends UriComponents
/*     */ {
/*     */   private static final char PATH_DELIMITER = '/';
/*     */   private final String userInfo;
/*     */   private final String host;
/*     */   private final int port;
/*     */   private final PathComponent path;
/*     */   private final MultiValueMap<String, String> queryParams;
/*     */   private final boolean encoded;
/* 789 */   static final PathComponent NULL_PATH_COMPONENT = new PathComponent()
/*     */   {
/*     */     public String getPath() {
/* 792 */       return null;
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments() {
/* 796 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException {
/* 800 */       return this;
/*     */     }
/*     */ 
/*     */     public void verify() {
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables) {
/* 807 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 811 */       return this == obj;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 815 */       return 42;
/*     */     }
/* 789 */   };
/*     */ 
/*     */   HierarchicalUriComponents(String scheme, String userInfo, String host, int port, PathComponent path, MultiValueMap<String, String> queryParams, String fragment, boolean encoded, boolean verify)
/*     */   {
/*  79 */     super(scheme, fragment);
/*  80 */     this.userInfo = userInfo;
/*  81 */     this.host = host;
/*  82 */     this.port = port;
/*  83 */     this.path = (path != null ? path : NULL_PATH_COMPONENT);
/*  84 */     this.queryParams = CollectionUtils.unmodifiableMultiValueMap(queryParams != null ? queryParams : new LinkedMultiValueMap(0));
/*     */ 
/*  86 */     this.encoded = encoded;
/*  87 */     if (verify)
/*  88 */       verify();
/*     */   }
/*     */ 
/*     */   public String getSchemeSpecificPart()
/*     */   {
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUserInfo()
/*     */   {
/* 102 */     return this.userInfo;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 107 */     return this.host;
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 112 */     return this.port;
/*     */   }
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 117 */     return this.path.getPath();
/*     */   }
/*     */ 
/*     */   public List<String> getPathSegments()
/*     */   {
/* 122 */     return this.path.getPathSegments();
/*     */   }
/*     */ 
/*     */   public String getQuery()
/*     */   {
/* 127 */     if (!this.queryParams.isEmpty()) {
/* 128 */       StringBuilder queryBuilder = new StringBuilder();
/* 129 */       for (Map.Entry entry : this.queryParams.entrySet()) {
/* 130 */         name = (String)entry.getKey();
/* 131 */         List values = (List)entry.getValue();
/* 132 */         if (CollectionUtils.isEmpty(values)) {
/* 133 */           if (queryBuilder.length() != 0) {
/* 134 */             queryBuilder.append('&');
/*     */           }
/* 136 */           queryBuilder.append(name);
/*     */         }
/*     */         else {
/* 139 */           for (localIterator2 = values.iterator(); localIterator2.hasNext(); ) { Object value = localIterator2.next();
/* 140 */             if (queryBuilder.length() != 0) {
/* 141 */               queryBuilder.append('&');
/*     */             }
/* 143 */             queryBuilder.append(name);
/*     */ 
/* 145 */             if (value != null) {
/* 146 */               queryBuilder.append('=');
/* 147 */               queryBuilder.append(value.toString());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       String name;
/*     */       Iterator localIterator2;
/* 152 */       return queryBuilder.toString();
/*     */     }
/*     */ 
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, String> getQueryParams()
/*     */   {
/* 164 */     return this.queryParams;
/*     */   }
/*     */ 
/*     */   public HierarchicalUriComponents encode(String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 179 */     Assert.hasLength(encoding, "'encoding' must not be empty");
/* 180 */     if (this.encoded) {
/* 181 */       return this;
/*     */     }
/* 183 */     String encodedScheme = encodeUriComponent(getScheme(), encoding, Type.SCHEME);
/* 184 */     String encodedUserInfo = encodeUriComponent(this.userInfo, encoding, Type.USER_INFO);
/* 185 */     String encodedHost = encodeUriComponent(this.host, encoding, getHostType());
/*     */ 
/* 187 */     PathComponent encodedPath = this.path.encode(encoding);
/*     */ 
/* 189 */     MultiValueMap encodedQueryParams = new LinkedMultiValueMap(this.queryParams
/* 189 */       .size());
/* 190 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 191 */       String encodedName = encodeUriComponent((String)entry.getKey(), encoding, Type.QUERY_PARAM);
/* 192 */       List encodedValues = new ArrayList(((List)entry.getValue()).size());
/* 193 */       for (String value : (List)entry.getValue()) {
/* 194 */         String encodedValue = encodeUriComponent(value, encoding, Type.QUERY_PARAM);
/* 195 */         encodedValues.add(encodedValue);
/*     */       }
/* 197 */       encodedQueryParams.put(encodedName, encodedValues);
/*     */     }
/* 199 */     String encodedFragment = encodeUriComponent(getFragment(), encoding, Type.FRAGMENT);
/* 200 */     return new HierarchicalUriComponents(encodedScheme, encodedUserInfo, encodedHost, this.port, encodedPath, encodedQueryParams, encodedFragment, true, false);
/*     */   }
/*     */ 
/*     */   static String encodeUriComponent(String source, String encoding, Type type)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 214 */     if (source == null) {
/* 215 */       return null;
/*     */     }
/* 217 */     Assert.hasLength(encoding, "'encoding' must not be empty");
/* 218 */     byte[] bytes = encodeBytes(source.getBytes(encoding), type);
/* 219 */     return new String(bytes, "US-ASCII");
/*     */   }
/*     */ 
/*     */   private static byte[] encodeBytes(byte[] source, Type type) {
/* 223 */     Assert.notNull(source, "'source' must not be null");
/* 224 */     Assert.notNull(type, "'type' must not be null");
/* 225 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(source.length);
/* 226 */     for (byte b : source) {
/* 227 */       if (b < 0) {
/* 228 */         b = (byte)(b + 256);
/*     */       }
/* 230 */       if (type.isAllowed(b)) {
/* 231 */         bos.write(b);
/*     */       }
/*     */       else {
/* 234 */         bos.write(37);
/* 235 */         char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 0xF, 16));
/* 236 */         char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, 16));
/* 237 */         bos.write(hex1);
/* 238 */         bos.write(hex2);
/*     */       }
/*     */     }
/* 241 */     return bos.toByteArray();
/*     */   }
/*     */ 
/*     */   private Type getHostType() {
/* 245 */     return (this.host != null) && (this.host.startsWith("[")) ? Type.HOST_IPV6 : Type.HOST_IPV4;
/*     */   }
/*     */ 
/*     */   private void verify()
/*     */   {
/* 256 */     if (!this.encoded) {
/* 257 */       return;
/*     */     }
/* 259 */     verifyUriComponent(getScheme(), Type.SCHEME);
/* 260 */     verifyUriComponent(this.userInfo, Type.USER_INFO);
/* 261 */     verifyUriComponent(this.host, getHostType());
/* 262 */     this.path.verify();
/* 263 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 264 */       verifyUriComponent((String)entry.getKey(), Type.QUERY_PARAM);
/* 265 */       for (String value : (List)entry.getValue()) {
/* 266 */         verifyUriComponent(value, Type.QUERY_PARAM);
/*     */       }
/*     */     }
/* 269 */     verifyUriComponent(getFragment(), Type.FRAGMENT);
/*     */   }
/*     */ 
/*     */   private static void verifyUriComponent(String source, Type type) {
/* 273 */     if (source == null) {
/* 274 */       return;
/*     */     }
/* 276 */     int length = source.length();
/* 277 */     for (int i = 0; i < length; i++) {
/* 278 */       char ch = source.charAt(i);
/* 279 */       if (ch == '%') {
/* 280 */         if (i + 2 < length) {
/* 281 */           char hex1 = source.charAt(i + 1);
/* 282 */           char hex2 = source.charAt(i + 2);
/* 283 */           int u = Character.digit(hex1, 16);
/* 284 */           int l = Character.digit(hex2, 16);
/* 285 */           if ((u == -1) || (l == -1)) {
/* 286 */             throw new IllegalArgumentException(new StringBuilder().append("Invalid encoded sequence \"").append(source.substring(i)).append("\"").toString());
/*     */           }
/* 288 */           i += 2;
/*     */         }
/*     */         else {
/* 291 */           throw new IllegalArgumentException(new StringBuilder().append("Invalid encoded sequence \"").append(source.substring(i)).append("\"").toString());
/*     */         }
/*     */       }
/* 294 */       else if (!type.isAllowed(ch))
/*     */       {
/* 296 */         throw new IllegalArgumentException(new StringBuilder().append("Invalid character '").append(ch).append("' for ")
/* 296 */           .append(type
/* 296 */           .name()).append(" in \"").append(source).append("\"").toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected HierarchicalUriComponents expandInternal(UriComponents.UriTemplateVariables uriVariables)
/*     */   {
/* 306 */     Assert.state(!this.encoded, "Cannot expand an already encoded UriComponents object");
/* 307 */     String expandedScheme = expandUriComponent(getScheme(), uriVariables);
/* 308 */     String expandedUserInfo = expandUriComponent(this.userInfo, uriVariables);
/* 309 */     String expandedHost = expandUriComponent(this.host, uriVariables);
/* 310 */     PathComponent expandedPath = this.path.expand(uriVariables);
/*     */ 
/* 312 */     MultiValueMap expandedQueryParams = new LinkedMultiValueMap(this.queryParams
/* 312 */       .size());
/* 313 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 314 */       String expandedName = expandUriComponent((String)entry.getKey(), uriVariables);
/* 315 */       List expandedValues = new ArrayList(((List)entry.getValue()).size());
/* 316 */       for (String value : (List)entry.getValue()) {
/* 317 */         String expandedValue = expandUriComponent(value, uriVariables);
/* 318 */         expandedValues.add(expandedValue);
/*     */       }
/* 320 */       expandedQueryParams.put(expandedName, expandedValues);
/*     */     }
/* 322 */     String expandedFragment = expandUriComponent(getFragment(), uriVariables);
/* 323 */     return new HierarchicalUriComponents(expandedScheme, expandedUserInfo, expandedHost, this.port, expandedPath, expandedQueryParams, expandedFragment, false, false);
/*     */   }
/*     */ 
/*     */   public UriComponents normalize()
/*     */   {
/* 333 */     String normalizedPath = StringUtils.cleanPath(getPath());
/*     */ 
/* 336 */     return new HierarchicalUriComponents(getScheme(), this.userInfo, this.host, this.port, new FullPathComponent(normalizedPath), this.queryParams, 
/* 336 */       getFragment(), this.encoded, false);
/*     */   }
/*     */ 
/*     */   public String toUriString()
/*     */   {
/* 347 */     StringBuilder uriBuilder = new StringBuilder();
/* 348 */     if (getScheme() != null) {
/* 349 */       uriBuilder.append(getScheme());
/* 350 */       uriBuilder.append(':');
/*     */     }
/* 352 */     if ((this.userInfo != null) || (this.host != null)) {
/* 353 */       uriBuilder.append("//");
/* 354 */       if (this.userInfo != null) {
/* 355 */         uriBuilder.append(this.userInfo);
/* 356 */         uriBuilder.append('@');
/*     */       }
/* 358 */       if (this.host != null) {
/* 359 */         uriBuilder.append(this.host);
/*     */       }
/* 361 */       if (this.port != -1) {
/* 362 */         uriBuilder.append(':');
/* 363 */         uriBuilder.append(this.port);
/*     */       }
/*     */     }
/* 366 */     String path = getPath();
/* 367 */     if (StringUtils.hasLength(path)) {
/* 368 */       if ((uriBuilder.length() != 0) && (path.charAt(0) != '/')) {
/* 369 */         uriBuilder.append('/');
/*     */       }
/* 371 */       uriBuilder.append(path);
/*     */     }
/* 373 */     String query = getQuery();
/* 374 */     if (query != null) {
/* 375 */       uriBuilder.append('?');
/* 376 */       uriBuilder.append(query);
/*     */     }
/* 378 */     if (getFragment() != null) {
/* 379 */       uriBuilder.append('#');
/* 380 */       uriBuilder.append(getFragment());
/*     */     }
/* 382 */     return uriBuilder.toString();
/*     */   }
/*     */ 
/*     */   public URI toUri()
/*     */   {
/*     */     try
/*     */     {
/* 391 */       if (this.encoded) {
/* 392 */         return new URI(toString());
/*     */       }
/*     */ 
/* 395 */       String path = getPath();
/* 396 */       if ((StringUtils.hasLength(path)) && (path.charAt(0) != '/'))
/*     */       {
/* 398 */         if ((getScheme() != null) || (getUserInfo() != null) || (getHost() != null) || (getPort() != -1)) {
/* 399 */           path = new StringBuilder().append('/').append(path).toString();
/*     */         }
/*     */       }
/*     */ 
/* 403 */       return new URI(getScheme(), getUserInfo(), getHost(), getPort(), path, getQuery(), 
/* 403 */         getFragment());
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/* 407 */       throw new IllegalStateException(new StringBuilder().append("Could not create URI object: ").append(ex.getMessage()).toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 413 */     if (this == obj) {
/* 414 */       return true;
/*     */     }
/* 416 */     if (!(obj instanceof HierarchicalUriComponents)) {
/* 417 */       return false;
/*     */     }
/* 419 */     HierarchicalUriComponents other = (HierarchicalUriComponents)obj;
/*     */ 
/* 426 */     return (ObjectUtils.nullSafeEquals(getScheme(), other.getScheme())) && 
/* 421 */       (ObjectUtils.nullSafeEquals(getUserInfo(), other.getUserInfo())) && 
/* 422 */       (ObjectUtils.nullSafeEquals(getHost(), other.getHost())) && 
/* 423 */       (getPort() == other.getPort()) && 
/* 424 */       (this.path
/* 424 */       .equals(other.path)) && 
/* 425 */       (this.queryParams
/* 425 */       .equals(other.queryParams)) && 
/* 426 */       (ObjectUtils.nullSafeEquals(getFragment(), other.getFragment()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 431 */     int result = ObjectUtils.nullSafeHashCode(getScheme());
/* 432 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.userInfo);
/* 433 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.host);
/* 434 */     result = 31 * result + this.port;
/* 435 */     result = 31 * result + this.path.hashCode();
/* 436 */     result = 31 * result + this.queryParams.hashCode();
/* 437 */     result = 31 * result + ObjectUtils.nullSafeHashCode(getFragment());
/* 438 */     return result;
/*     */   }
/*     */ 
/*     */   static final class PathComponentComposite
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final List<HierarchicalUriComponents.PathComponent> pathComponents;
/*     */ 
/*     */     public PathComponentComposite(List<HierarchicalUriComponents.PathComponent> pathComponents)
/*     */     {
/* 738 */       this.pathComponents = pathComponents;
/*     */     }
/*     */ 
/*     */     public String getPath()
/*     */     {
/* 743 */       StringBuilder pathBuilder = new StringBuilder();
/* 744 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 745 */         pathBuilder.append(pathComponent.getPath());
/*     */       }
/* 747 */       return pathBuilder.toString();
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments()
/*     */     {
/* 752 */       List result = new ArrayList();
/* 753 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 754 */         result.addAll(pathComponent.getPathSegments());
/*     */       }
/* 756 */       return result;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 761 */       List encodedComponents = new ArrayList(this.pathComponents.size());
/* 762 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 763 */         encodedComponents.add(pathComponent.encode(encoding));
/*     */       }
/* 765 */       return new PathComponentComposite(encodedComponents);
/*     */     }
/*     */ 
/*     */     public void verify()
/*     */     {
/* 770 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents)
/* 771 */         pathComponent.verify();
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 777 */       List expandedComponents = new ArrayList(this.pathComponents.size());
/* 778 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 779 */         expandedComponents.add(pathComponent.expand(uriVariables));
/*     */       }
/* 781 */       return new PathComponentComposite(expandedComponents);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class PathSegmentComponent
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final List<String> pathSegments;
/*     */ 
/*     */     public PathSegmentComponent(List<String> pathSegments)
/*     */     {
/* 666 */       this.pathSegments = Collections.unmodifiableList(pathSegments);
/*     */     }
/*     */ 
/*     */     public String getPath()
/*     */     {
/* 671 */       StringBuilder pathBuilder = new StringBuilder();
/* 672 */       pathBuilder.append('/');
/* 673 */       for (Iterator iterator = this.pathSegments.iterator(); iterator.hasNext(); ) {
/* 674 */         String pathSegment = (String)iterator.next();
/* 675 */         pathBuilder.append(pathSegment);
/* 676 */         if (iterator.hasNext()) {
/* 677 */           pathBuilder.append('/');
/*     */         }
/*     */       }
/* 680 */       return pathBuilder.toString();
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments()
/*     */     {
/* 685 */       return this.pathSegments;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 690 */       List pathSegments = getPathSegments();
/* 691 */       List encodedPathSegments = new ArrayList(pathSegments.size());
/* 692 */       for (String pathSegment : pathSegments) {
/* 693 */         String encodedPathSegment = HierarchicalUriComponents.encodeUriComponent(pathSegment, encoding, HierarchicalUriComponents.Type.PATH_SEGMENT);
/* 694 */         encodedPathSegments.add(encodedPathSegment);
/*     */       }
/* 696 */       return new PathSegmentComponent(encodedPathSegments);
/*     */     }
/*     */ 
/*     */     public void verify()
/*     */     {
/* 701 */       for (String pathSegment : getPathSegments())
/* 702 */         HierarchicalUriComponents.verifyUriComponent(pathSegment, HierarchicalUriComponents.Type.PATH_SEGMENT);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 708 */       List pathSegments = getPathSegments();
/* 709 */       List expandedPathSegments = new ArrayList(pathSegments.size());
/* 710 */       for (String pathSegment : pathSegments) {
/* 711 */         String expandedPathSegment = UriComponents.expandUriComponent(pathSegment, uriVariables);
/* 712 */         expandedPathSegments.add(expandedPathSegment);
/*     */       }
/* 714 */       return new PathSegmentComponent(expandedPathSegments);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 720 */       return (this == obj) || (((obj instanceof PathSegmentComponent)) && 
/* 720 */         (getPathSegments().equals(((PathSegmentComponent)obj).getPathSegments())));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 725 */       return getPathSegments().hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class FullPathComponent
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final String path;
/*     */ 
/*     */     public FullPathComponent(String path)
/*     */     {
/* 613 */       this.path = path;
/*     */     }
/*     */ 
/*     */     public String getPath()
/*     */     {
/* 618 */       return this.path;
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments()
/*     */     {
/* 623 */       String delimiter = new String(new char[] { '/' });
/* 624 */       String[] pathSegments = StringUtils.tokenizeToStringArray(this.path, delimiter);
/* 625 */       return Collections.unmodifiableList(Arrays.asList(pathSegments));
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 630 */       String encodedPath = HierarchicalUriComponents.encodeUriComponent(getPath(), encoding, HierarchicalUriComponents.Type.PATH);
/* 631 */       return new FullPathComponent(encodedPath);
/*     */     }
/*     */ 
/*     */     public void verify()
/*     */     {
/* 636 */       HierarchicalUriComponents.verifyUriComponent(this.path, HierarchicalUriComponents.Type.PATH);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 641 */       String expandedPath = UriComponents.expandUriComponent(getPath(), uriVariables);
/* 642 */       return new FullPathComponent(expandedPath);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 648 */       return (this == obj) || (((obj instanceof FullPathComponent)) && 
/* 648 */         (getPath().equals(((FullPathComponent)obj).getPath())));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 653 */       return getPath().hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface PathComponent extends Serializable
/*     */   {
/*     */     public abstract String getPath();
/*     */ 
/*     */     public abstract List<String> getPathSegments();
/*     */ 
/*     */     public abstract PathComponent encode(String paramString)
/*     */       throws UnsupportedEncodingException;
/*     */ 
/*     */     public abstract void verify();
/*     */ 
/*     */     public abstract PathComponent expand(UriComponents.UriTemplateVariables paramUriTemplateVariables);
/*     */   }
/*     */ 
/*     */   static abstract enum Type
/*     */   {
/* 451 */     SCHEME, 
/*     */ 
/* 457 */     AUTHORITY, 
/*     */ 
/* 463 */     USER_INFO, 
/*     */ 
/* 469 */     HOST_IPV4, 
/*     */ 
/* 475 */     HOST_IPV6, 
/*     */ 
/* 481 */     PORT, 
/*     */ 
/* 487 */     PATH, 
/*     */ 
/* 493 */     PATH_SEGMENT, 
/*     */ 
/* 499 */     QUERY, 
/*     */ 
/* 505 */     QUERY_PARAM, 
/*     */ 
/* 516 */     FRAGMENT;
/*     */ 
/*     */     public abstract boolean isAllowed(int paramInt);
/*     */ 
/*     */     protected boolean isAlpha(int c)
/*     */     {
/* 534 */       return ((c >= 97) && (c <= 122)) || ((c >= 65) && (c <= 90));
/*     */     }
/*     */ 
/*     */     protected boolean isDigit(int c)
/*     */     {
/* 542 */       return (c >= 48) && (c <= 57);
/*     */     }
/*     */ 
/*     */     protected boolean isGenericDelimiter(int c)
/*     */     {
/* 550 */       return (58 == c) || (47 == c) || (63 == c) || (35 == c) || (91 == c) || (93 == c) || (64 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isSubDelimiter(int c)
/*     */     {
/* 558 */       return (33 == c) || (36 == c) || (38 == c) || (39 == c) || (40 == c) || (41 == c) || (42 == c) || (43 == c) || (44 == c) || (59 == c) || (61 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isReserved(char c)
/*     */     {
/* 567 */       return (isGenericDelimiter(c)) || (isReserved(c));
/*     */     }
/*     */ 
/*     */     protected boolean isUnreserved(int c)
/*     */     {
/* 575 */       return (isAlpha(c)) || (isDigit(c)) || (45 == c) || (46 == c) || (95 == c) || (126 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isPchar(int c)
/*     */     {
/* 583 */       return (isUnreserved(c)) || (isSubDelimiter(c)) || (58 == c) || (64 == c);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.HierarchicalUriComponents
 * JD-Core Version:    0.6.2
 */