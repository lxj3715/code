/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ class HtmlCharacterEntityReferences
/*     */ {
/*     */   private static final String PROPERTIES_FILE = "HtmlCharacterEntityReferences.properties";
/*     */   static final char REFERENCE_START = '&';
/*     */   static final String DECIMAL_REFERENCE_START = "&#";
/*     */   static final String HEX_REFERENCE_START = "&#x";
/*     */   static final char REFERENCE_END = ';';
/*     */   static final char CHAR_NULL = '����';
/*  54 */   private final String[] characterToEntityReferenceMap = new String[3000];
/*     */ 
/*  56 */   private final Map<String, Character> entityReferenceToCharacterMap = new HashMap(252);
/*     */ 
/*     */   public HtmlCharacterEntityReferences()
/*     */   {
/*  63 */     Properties entityReferences = new Properties();
/*     */ 
/*  66 */     InputStream is = HtmlCharacterEntityReferences.class.getResourceAsStream("HtmlCharacterEntityReferences.properties");
/*  67 */     if (is == null)
/*  68 */       throw new IllegalStateException("Cannot find reference definition file [HtmlCharacterEntityReferences.properties] as class path resource");
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  73 */         entityReferences.load(is);
/*     */ 
/*  76 */         is.close(); } finally { is.close(); }
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*  81 */       throw new IllegalStateException("Failed to parse reference definition file [HtmlCharacterEntityReferences.properties]: " + ex
/*  81 */         .getMessage());
/*     */     }
/*     */ 
/*  85 */     Enumeration keys = entityReferences.propertyNames();
/*  86 */     while (keys.hasMoreElements()) {
/*  87 */       String key = (String)keys.nextElement();
/*  88 */       int referredChar = Integer.parseInt(key);
/*  89 */       Assert.isTrue((referredChar < 1000) || ((referredChar >= 8000) && (referredChar < 10000)), "Invalid reference to special HTML entity: " + referredChar);
/*     */ 
/*  91 */       int index = referredChar < 1000 ? referredChar : referredChar - 7000;
/*  92 */       String reference = entityReferences.getProperty(key);
/*  93 */       this.characterToEntityReferenceMap[index] = ('&' + reference + ';');
/*  94 */       this.entityReferenceToCharacterMap.put(reference, new Character((char)referredChar));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getSupportedReferenceCount()
/*     */   {
/* 103 */     return this.entityReferenceToCharacterMap.size();
/*     */   }
/*     */ 
/*     */   public boolean isMappedToReference(char character)
/*     */   {
/* 110 */     return convertToReference(character) != null;
/*     */   }
/*     */ 
/*     */   public String convertToReference(char character)
/*     */   {
/* 117 */     if ((character < 'Ϩ') || ((character >= 'ὀ') && (character < '✐'))) {
/* 118 */       int index = character < 'Ϩ' ? character : character - '᭘';
/* 119 */       String entityReference = this.characterToEntityReferenceMap[index];
/* 120 */       if (entityReference != null) {
/* 121 */         return entityReference;
/*     */       }
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */ 
/*     */   public char convertToCharacter(String entityReference)
/*     */   {
/* 131 */     Character referredCharacter = (Character)this.entityReferenceToCharacterMap.get(entityReference);
/* 132 */     if (referredCharacter != null) {
/* 133 */       return referredCharacter.charValue();
/*     */     }
/* 135 */     return 65535;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.HtmlCharacterEntityReferences
 * JD-Core Version:    0.6.2
 */