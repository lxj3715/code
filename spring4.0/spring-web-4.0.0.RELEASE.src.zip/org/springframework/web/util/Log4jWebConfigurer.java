/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.util.Log4jConfigurer;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ 
/*     */ public abstract class Log4jWebConfigurer
/*     */ {
/*     */   public static final String CONFIG_LOCATION_PARAM = "log4jConfigLocation";
/*     */   public static final String REFRESH_INTERVAL_PARAM = "log4jRefreshInterval";
/*     */   public static final String EXPOSE_WEB_APP_ROOT_PARAM = "log4jExposeWebAppRoot";
/*     */ 
/*     */   public static void initLogging(ServletContext servletContext)
/*     */   {
/* 115 */     if (exposeWebAppRoot(servletContext)) {
/* 116 */       WebUtils.setWebAppRootSystemProperty(servletContext);
/*     */     }
/*     */ 
/* 120 */     String location = servletContext.getInitParameter("log4jConfigLocation");
/* 121 */     if (location != null)
/*     */     {
/*     */       try
/*     */       {
/* 125 */         location = ServletContextPropertyUtils.resolvePlaceholders(location, servletContext);
/*     */ 
/* 128 */         if (!ResourceUtils.isUrl(location))
/*     */         {
/* 131 */           location = WebUtils.getRealPath(servletContext, location);
/*     */         }
/*     */ 
/* 135 */         servletContext.log("Initializing log4j from [" + location + "]");
/*     */ 
/* 138 */         String intervalString = servletContext.getInitParameter("log4jRefreshInterval");
/* 139 */         if (intervalString != null)
/*     */         {
/*     */           try
/*     */           {
/* 143 */             long refreshInterval = Long.parseLong(intervalString);
/* 144 */             Log4jConfigurer.initLogging(location, refreshInterval);
/*     */           }
/*     */           catch (NumberFormatException ex) {
/* 147 */             throw new IllegalArgumentException("Invalid 'log4jRefreshInterval' parameter: " + ex.getMessage());
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 152 */           Log4jConfigurer.initLogging(location);
/*     */         }
/*     */       }
/*     */       catch (FileNotFoundException ex) {
/* 156 */         throw new IllegalArgumentException("Invalid 'log4jConfigLocation' parameter: " + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void shutdownLogging(ServletContext servletContext)
/*     */   {
/* 168 */     servletContext.log("Shutting down log4j");
/*     */     try {
/* 170 */       Log4jConfigurer.shutdownLogging();
/*     */ 
/* 174 */       if (exposeWebAppRoot(servletContext))
/* 175 */         WebUtils.removeWebAppRootSystemProperty(servletContext);
/*     */     }
/*     */     finally
/*     */     {
/* 174 */       if (exposeWebAppRoot(servletContext))
/* 175 */         WebUtils.removeWebAppRootSystemProperty(servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static boolean exposeWebAppRoot(ServletContext servletContext)
/*     */   {
/* 186 */     String exposeWebAppRootParam = servletContext.getInitParameter("log4jExposeWebAppRoot");
/* 187 */     return (exposeWebAppRootParam == null) || (Boolean.valueOf(exposeWebAppRootParam).booleanValue());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.Log4jWebConfigurer
 * JD-Core Version:    0.6.2
 */