/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public abstract class UriComponents
/*     */   implements Serializable
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*  48 */   private static final Pattern NAMES_PATTERN = Pattern.compile("\\{([^/]+?)\\}");
/*     */   private final String scheme;
/*     */   private final String fragment;
/*     */ 
/*     */   protected UriComponents(String scheme, String fragment)
/*     */   {
/*  57 */     this.scheme = scheme;
/*  58 */     this.fragment = fragment;
/*     */   }
/*     */ 
/*     */   public final String getScheme()
/*     */   {
/*  68 */     return this.scheme;
/*     */   }
/*     */ 
/*     */   public abstract String getSchemeSpecificPart();
/*     */ 
/*     */   public abstract String getUserInfo();
/*     */ 
/*     */   public abstract String getHost();
/*     */ 
/*     */   public abstract int getPort();
/*     */ 
/*     */   public abstract String getPath();
/*     */ 
/*     */   public abstract List<String> getPathSegments();
/*     */ 
/*     */   public abstract String getQuery();
/*     */ 
/*     */   public abstract MultiValueMap<String, String> getQueryParams();
/*     */ 
/*     */   public final String getFragment()
/*     */   {
/* 115 */     return this.fragment;
/*     */   }
/*     */ 
/*     */   public final UriComponents encode()
/*     */   {
/*     */     try
/*     */     {
/* 126 */       return encode("UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/* 129 */     throw new InternalError("\"UTF-8\" not supported");
/*     */   }
/*     */ 
/*     */   public abstract UriComponents encode(String paramString)
/*     */     throws UnsupportedEncodingException;
/*     */ 
/*     */   public final UriComponents expand(Map<String, ?> uriVariables)
/*     */   {
/* 150 */     Assert.notNull(uriVariables, "'uriVariables' must not be null");
/* 151 */     return expandInternal(new MapTemplateVariables(uriVariables));
/*     */   }
/*     */ 
/*     */   public final UriComponents expand(Object[] uriVariableValues)
/*     */   {
/* 161 */     Assert.notNull(uriVariableValues, "'uriVariableValues' must not be null");
/* 162 */     return expandInternal(new VarArgsTemplateVariables(uriVariableValues));
/*     */   }
/*     */ 
/*     */   public final UriComponents expand(UriTemplateVariables uriTemplateVars)
/*     */   {
/* 172 */     Assert.notNull(uriTemplateVars, "'uriTemplateVars' must not be null");
/* 173 */     return expandInternal(uriTemplateVars);
/*     */   }
/*     */ 
/*     */   abstract UriComponents expandInternal(UriTemplateVariables paramUriTemplateVariables);
/*     */ 
/*     */   public abstract UriComponents normalize();
/*     */ 
/*     */   public abstract String toUriString();
/*     */ 
/*     */   public abstract URI toUri();
/*     */ 
/*     */   public final String toString()
/*     */   {
/* 202 */     return toUriString();
/*     */   }
/*     */ 
/*     */   static String expandUriComponent(String source, UriTemplateVariables uriVariables)
/*     */   {
/* 209 */     if (source == null) {
/* 210 */       return null;
/*     */     }
/* 212 */     if (source.indexOf('{') == -1) {
/* 213 */       return source;
/*     */     }
/* 215 */     Matcher matcher = NAMES_PATTERN.matcher(source);
/* 216 */     StringBuffer sb = new StringBuffer();
/* 217 */     while (matcher.find()) {
/* 218 */       String match = matcher.group(1);
/* 219 */       String variableName = getVariableName(match);
/* 220 */       Object variableValue = uriVariables.getValue(variableName);
/* 221 */       String variableValueString = getVariableValueAsString(variableValue);
/* 222 */       String replacement = Matcher.quoteReplacement(variableValueString);
/* 223 */       matcher.appendReplacement(sb, replacement);
/*     */     }
/* 225 */     matcher.appendTail(sb);
/* 226 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static String getVariableName(String match) {
/* 230 */     int colonIdx = match.indexOf(':');
/* 231 */     return colonIdx != -1 ? match.substring(0, colonIdx) : match;
/*     */   }
/*     */ 
/*     */   private static String getVariableValueAsString(Object variableValue) {
/* 235 */     return variableValue != null ? variableValue.toString() : "";
/*     */   }
/*     */ 
/*     */   private static class VarArgsTemplateVariables
/*     */     implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final Iterator<Object> valueIterator;
/*     */ 
/*     */     public VarArgsTemplateVariables(Object[] uriVariableValues)
/*     */     {
/* 278 */       this.valueIterator = Arrays.asList(uriVariableValues).iterator();
/*     */     }
/*     */ 
/*     */     public Object getValue(String name)
/*     */     {
/* 283 */       if (!this.valueIterator.hasNext()) {
/* 284 */         throw new IllegalArgumentException("Not enough variable values available to expand '" + name + "'");
/*     */       }
/*     */ 
/* 287 */       return this.valueIterator.next();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MapTemplateVariables
/*     */     implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final Map<String, ?> uriVariables;
/*     */ 
/*     */     public MapTemplateVariables(Map<String, ?> uriVariables)
/*     */     {
/* 257 */       this.uriVariables = uriVariables;
/*     */     }
/*     */ 
/*     */     public Object getValue(String name)
/*     */     {
/* 262 */       if (!this.uriVariables.containsKey(name)) {
/* 263 */         throw new IllegalArgumentException("Map has no value for '" + name + "'");
/*     */       }
/* 265 */       return this.uriVariables.get(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface UriTemplateVariables
/*     */   {
/*     */     public abstract Object getValue(String paramString);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriComponents
 * JD-Core Version:    0.6.2
 */