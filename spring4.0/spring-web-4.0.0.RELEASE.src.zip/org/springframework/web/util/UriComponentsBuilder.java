/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class UriComponentsBuilder
/*     */ {
/*  59 */   private static final Pattern QUERY_PARAM_PATTERN = Pattern.compile("([^&=]+)(=?)([^&]+)?");
/*     */   private static final String SCHEME_PATTERN = "([^:/?#]+):";
/*     */   private static final String HTTP_PATTERN = "(?i)(http|https):";
/*     */   private static final String USERINFO_PATTERN = "([^@/]*)";
/*     */   private static final String HOST_IPV4_PATTERN = "[^\\[/?#:]*";
/*     */   private static final String HOST_IPV6_PATTERN = "\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]";
/*     */   private static final String HOST_PATTERN = "(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)";
/*     */   private static final String PORT_PATTERN = "(\\d*)";
/*     */   private static final String PATH_PATTERN = "([^?#]*)";
/*     */   private static final String QUERY_PATTERN = "([^#]*)";
/*     */   private static final String LAST_PATTERN = "(.*)";
/*  82 */   private static final Pattern URI_PATTERN = Pattern.compile("^(([^:/?#]+):)?(//(([^@/]*)@)?(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)(:(\\d*))?)?([^?#]*)(\\?([^#]*))?(#(.*))?");
/*     */ 
/*  86 */   private static final Pattern HTTP_URL_PATTERN = Pattern.compile("^(?i)(http|https):(//(([^@/]*)@)?(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)(:(\\d*))?)?([^?#]*)(\\?(.*))?");
/*     */   private String scheme;
/*     */   private String ssp;
/*     */   private String userInfo;
/*     */   private String host;
/*  99 */   private int port = -1;
/*     */ 
/* 101 */   private CompositePathComponentBuilder pathBuilder = new CompositePathComponentBuilder();
/*     */ 
/* 103 */   private final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap();
/*     */   private String fragment;
/*     */ 
/*     */   public static UriComponentsBuilder newInstance()
/*     */   {
/* 125 */     return new UriComponentsBuilder();
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromPath(String path)
/*     */   {
/* 134 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 135 */     builder.path(path);
/* 136 */     return builder;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromUri(URI uri)
/*     */   {
/* 145 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 146 */     builder.uri(uri);
/* 147 */     return builder;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromUriString(String uri)
/*     */   {
/* 165 */     Assert.hasLength(uri, "'uri' must not be empty");
/* 166 */     Matcher m = URI_PATTERN.matcher(uri);
/* 167 */     if (m.matches()) {
/* 168 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 169 */       String scheme = m.group(2);
/* 170 */       String userInfo = m.group(5);
/* 171 */       String host = m.group(6);
/* 172 */       String port = m.group(8);
/* 173 */       String path = m.group(9);
/* 174 */       String query = m.group(11);
/* 175 */       String fragment = m.group(13);
/* 176 */       boolean opaque = false;
/* 177 */       if (StringUtils.hasLength(scheme)) {
/* 178 */         String s = uri.substring(scheme.length());
/* 179 */         if (!s.startsWith(":/")) {
/* 180 */           opaque = true;
/*     */         }
/*     */       }
/* 183 */       builder.scheme(scheme);
/* 184 */       if (opaque) {
/* 185 */         String ssp = uri.substring(scheme.length()).substring(1);
/* 186 */         if (StringUtils.hasLength(fragment)) {
/* 187 */           ssp = ssp.substring(0, ssp.length() - (fragment.length() + 1));
/*     */         }
/* 189 */         builder.schemeSpecificPart(ssp);
/*     */       }
/*     */       else {
/* 192 */         builder.userInfo(userInfo);
/* 193 */         builder.host(host);
/* 194 */         if (StringUtils.hasLength(port)) {
/* 195 */           builder.port(Integer.parseInt(port));
/*     */         }
/* 197 */         builder.path(path);
/* 198 */         builder.query(query);
/*     */       }
/* 200 */       if (StringUtils.hasText(fragment)) {
/* 201 */         builder.fragment(fragment);
/*     */       }
/* 203 */       return builder;
/*     */     }
/*     */ 
/* 206 */     throw new IllegalArgumentException("[" + uri + "] is not a valid URI");
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromHttpUrl(String httpUrl)
/*     */   {
/* 225 */     Assert.notNull(httpUrl, "'httpUrl' must not be null");
/* 226 */     Matcher m = HTTP_URL_PATTERN.matcher(httpUrl);
/* 227 */     if (m.matches()) {
/* 228 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/*     */ 
/* 230 */       String scheme = m.group(1);
/* 231 */       builder.scheme(scheme != null ? scheme.toLowerCase() : scheme);
/* 232 */       builder.userInfo(m.group(4));
/* 233 */       String host = m.group(5);
/* 234 */       if ((StringUtils.hasLength(scheme)) && (!StringUtils.hasLength(host))) {
/* 235 */         throw new IllegalArgumentException("[" + httpUrl + "] is not a valid HTTP URL");
/*     */       }
/* 237 */       builder.host(host);
/* 238 */       String port = m.group(7);
/* 239 */       if (StringUtils.hasLength(port)) {
/* 240 */         builder.port(Integer.parseInt(port));
/*     */       }
/* 242 */       builder.path(m.group(8));
/* 243 */       builder.query(m.group(10));
/*     */ 
/* 245 */       return builder;
/*     */     }
/*     */ 
/* 248 */     throw new IllegalArgumentException("[" + httpUrl + "] is not a valid HTTP URL");
/*     */   }
/*     */ 
/*     */   public UriComponents build()
/*     */   {
/* 260 */     return build(false);
/*     */   }
/*     */ 
/*     */   public UriComponents build(boolean encoded)
/*     */   {
/* 271 */     if (this.ssp != null) {
/* 272 */       return new OpaqueUriComponents(this.scheme, this.ssp, this.fragment);
/*     */     }
/*     */ 
/* 276 */     return new HierarchicalUriComponents(this.scheme, this.userInfo, this.host, this.port, this.pathBuilder
/* 276 */       .build(), this.queryParams, this.fragment, encoded, true);
/*     */   }
/*     */ 
/*     */   public UriComponents buildAndExpand(Map<String, ?> uriVariables)
/*     */   {
/* 288 */     return build(false).expand(uriVariables);
/*     */   }
/*     */ 
/*     */   public UriComponents buildAndExpand(Object[] uriVariableValues)
/*     */   {
/* 299 */     return build(false).expand(uriVariableValues);
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder uri(URI uri)
/*     */   {
/* 311 */     Assert.notNull(uri, "'uri' must not be null");
/* 312 */     this.scheme = uri.getScheme();
/* 313 */     if (uri.isOpaque()) {
/* 314 */       this.ssp = uri.getRawSchemeSpecificPart();
/* 315 */       resetHierarchicalComponents();
/*     */     }
/*     */     else {
/* 318 */       if (uri.getRawUserInfo() != null) {
/* 319 */         this.userInfo = uri.getRawUserInfo();
/*     */       }
/* 321 */       if (uri.getHost() != null) {
/* 322 */         this.host = uri.getHost();
/*     */       }
/* 324 */       if (uri.getPort() != -1) {
/* 325 */         this.port = uri.getPort();
/*     */       }
/* 327 */       if (StringUtils.hasLength(uri.getRawPath())) {
/* 328 */         this.pathBuilder = new CompositePathComponentBuilder(uri.getRawPath());
/*     */       }
/* 330 */       if (StringUtils.hasLength(uri.getRawQuery())) {
/* 331 */         this.queryParams.clear();
/* 332 */         query(uri.getRawQuery());
/*     */       }
/* 334 */       resetSchemeSpecificPart();
/*     */     }
/* 336 */     if (uri.getRawFragment() != null) {
/* 337 */       this.fragment = uri.getRawFragment();
/*     */     }
/* 339 */     return this;
/*     */   }
/*     */ 
/*     */   private void resetHierarchicalComponents() {
/* 343 */     this.userInfo = null;
/* 344 */     this.host = null;
/* 345 */     this.port = -1;
/* 346 */     this.pathBuilder = new CompositePathComponentBuilder();
/* 347 */     this.queryParams.clear();
/*     */   }
/*     */ 
/*     */   private void resetSchemeSpecificPart() {
/* 351 */     this.ssp = null;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder scheme(String scheme)
/*     */   {
/* 361 */     this.scheme = scheme;
/* 362 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder uriComponents(UriComponents uriComponents)
/*     */   {
/* 371 */     Assert.notNull(uriComponents, "'uriComponents' must not be null");
/* 372 */     this.scheme = uriComponents.getScheme();
/* 373 */     if ((uriComponents instanceof OpaqueUriComponents)) {
/* 374 */       this.ssp = uriComponents.getSchemeSpecificPart();
/* 375 */       resetHierarchicalComponents();
/*     */     }
/*     */     else {
/* 378 */       if (uriComponents.getUserInfo() != null) {
/* 379 */         this.userInfo = uriComponents.getUserInfo();
/*     */       }
/* 381 */       if (uriComponents.getHost() != null) {
/* 382 */         this.host = uriComponents.getHost();
/*     */       }
/* 384 */       if (uriComponents.getPort() != -1) {
/* 385 */         this.port = uriComponents.getPort();
/*     */       }
/* 387 */       if (StringUtils.hasLength(uriComponents.getPath())) {
/* 388 */         this.pathBuilder = new CompositePathComponentBuilder(uriComponents.getPath());
/*     */       }
/* 390 */       if (!uriComponents.getQueryParams().isEmpty()) {
/* 391 */         this.queryParams.clear();
/* 392 */         this.queryParams.putAll(uriComponents.getQueryParams());
/*     */       }
/* 394 */       resetSchemeSpecificPart();
/*     */     }
/* 396 */     if (uriComponents.getFragment() != null) {
/* 397 */       this.fragment = uriComponents.getFragment();
/*     */     }
/* 399 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder schemeSpecificPart(String ssp)
/*     */   {
/* 411 */     this.ssp = ssp;
/* 412 */     resetHierarchicalComponents();
/* 413 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder userInfo(String userInfo)
/*     */   {
/* 424 */     this.userInfo = userInfo;
/* 425 */     resetSchemeSpecificPart();
/* 426 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder host(String host)
/*     */   {
/* 436 */     this.host = host;
/* 437 */     resetSchemeSpecificPart();
/* 438 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder port(int port)
/*     */   {
/* 447 */     Assert.isTrue(port >= -1, "'port' must not be < -1");
/* 448 */     this.port = port;
/* 449 */     resetSchemeSpecificPart();
/* 450 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder path(String path)
/*     */   {
/* 460 */     this.pathBuilder.addPath(path);
/* 461 */     resetSchemeSpecificPart();
/* 462 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replacePath(String path)
/*     */   {
/* 471 */     this.pathBuilder = new CompositePathComponentBuilder(path);
/* 472 */     resetSchemeSpecificPart();
/* 473 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder pathSegment(String[] pathSegments)
/*     */     throws IllegalArgumentException
/*     */   {
/* 483 */     Assert.notNull(pathSegments, "'segments' must not be null");
/* 484 */     this.pathBuilder.addPathSegments(pathSegments);
/* 485 */     resetSchemeSpecificPart();
/* 486 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder query(String query)
/*     */   {
/* 505 */     if (query != null) {
/* 506 */       Matcher m = QUERY_PARAM_PATTERN.matcher(query);
/* 507 */       while (m.find()) {
/* 508 */         String name = m.group(1);
/* 509 */         String eq = m.group(2);
/* 510 */         String value = m.group(3);
/* 511 */         queryParam(name, new Object[] { 
/* 512 */           StringUtils.hasLength(eq) ? 
/* 512 */           "" : value != null ? value : 
/* 512 */           null });
/*     */       }
/*     */     }
/*     */     else {
/* 516 */       this.queryParams.clear();
/*     */     }
/* 518 */     resetSchemeSpecificPart();
/* 519 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replaceQuery(String query)
/*     */   {
/* 528 */     this.queryParams.clear();
/* 529 */     query(query);
/* 530 */     resetSchemeSpecificPart();
/* 531 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder queryParam(String name, Object[] values)
/*     */   {
/* 544 */     Assert.notNull(name, "'name' must not be null");
/* 545 */     if (!ObjectUtils.isEmpty(values)) {
/* 546 */       for (Object value : values) {
/* 547 */         String valueAsString = value != null ? value.toString() : null;
/* 548 */         this.queryParams.add(name, valueAsString);
/*     */       }
/*     */     }
/*     */     else {
/* 552 */       this.queryParams.add(name, null);
/*     */     }
/* 554 */     resetSchemeSpecificPart();
/* 555 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder queryParams(MultiValueMap<String, String> params)
/*     */   {
/* 564 */     Assert.notNull(params, "'params' must not be null");
/* 565 */     this.queryParams.putAll(params);
/* 566 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replaceQueryParam(String name, Object[] values)
/*     */   {
/* 578 */     Assert.notNull(name, "'name' must not be null");
/* 579 */     this.queryParams.remove(name);
/* 580 */     if (!ObjectUtils.isEmpty(values)) {
/* 581 */       queryParam(name, values);
/*     */     }
/* 583 */     resetSchemeSpecificPart();
/* 584 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder fragment(String fragment)
/*     */   {
/* 595 */     if (fragment != null) {
/* 596 */       Assert.hasLength(fragment, "'fragment' must not be empty");
/* 597 */       this.fragment = fragment;
/*     */     }
/*     */     else {
/* 600 */       this.fragment = null;
/*     */     }
/* 602 */     return this;
/*     */   }
/*     */ 
/*     */   private static class PathSegmentComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 712 */     private final List<String> pathSegments = new LinkedList();
/*     */ 
/*     */     public void append(String[] pathSegments) {
/* 715 */       for (String pathSegment : pathSegments)
/* 716 */         if (StringUtils.hasText(pathSegment))
/* 717 */           this.pathSegments.add(pathSegment);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 724 */       return this.pathSegments.isEmpty() ? null : new HierarchicalUriComponents.PathSegmentComponent(this.pathSegments);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class FullPathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 686 */     private final StringBuilder path = new StringBuilder();
/*     */ 
/*     */     public void append(String path) {
/* 689 */       this.path.append(path);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 694 */       if (this.path.length() == 0) {
/* 695 */         return null;
/*     */       }
/* 697 */       String path = this.path.toString().replace("//", "/");
/* 698 */       return new HierarchicalUriComponents.FullPathComponent(path);
/*     */     }
/*     */ 
/*     */     public void removeTrailingSlash() {
/* 702 */       int index = this.path.length() - 1;
/* 703 */       if (this.path.charAt(index) == '/')
/* 704 */         this.path.deleteCharAt(index);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CompositePathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 613 */     private final LinkedList<UriComponentsBuilder.PathComponentBuilder> componentBuilders = new LinkedList();
/*     */ 
/*     */     public CompositePathComponentBuilder() {
/*     */     }
/*     */ 
/*     */     public CompositePathComponentBuilder(String path) {
/* 619 */       addPath(path);
/*     */     }
/*     */ 
/*     */     public void addPathSegments(String[] pathSegments) {
/* 623 */       if (!ObjectUtils.isEmpty(pathSegments)) {
/* 624 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 625 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 626 */         if (psBuilder == null) {
/* 627 */           psBuilder = new UriComponentsBuilder.PathSegmentComponentBuilder(null);
/* 628 */           this.componentBuilders.add(psBuilder);
/* 629 */           if (fpBuilder != null) {
/* 630 */             fpBuilder.removeTrailingSlash();
/*     */           }
/*     */         }
/* 633 */         psBuilder.append(pathSegments);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void addPath(String path) {
/* 638 */       if (StringUtils.hasText(path)) {
/* 639 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 640 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 641 */         if (psBuilder != null) {
/* 642 */           path = "/" + path;
/*     */         }
/* 644 */         if (fpBuilder == null) {
/* 645 */           fpBuilder = new UriComponentsBuilder.FullPathComponentBuilder(null);
/* 646 */           this.componentBuilders.add(fpBuilder);
/*     */         }
/* 648 */         fpBuilder.append(path);
/*     */       }
/*     */     }
/*     */ 
/*     */     private <T> T getLastBuilder(Class<T> builderClass)
/*     */     {
/* 654 */       if (!this.componentBuilders.isEmpty()) {
/* 655 */         UriComponentsBuilder.PathComponentBuilder last = (UriComponentsBuilder.PathComponentBuilder)this.componentBuilders.getLast();
/* 656 */         if (builderClass.isInstance(last)) {
/* 657 */           return last;
/*     */         }
/*     */       }
/* 660 */       return null;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 665 */       int size = this.componentBuilders.size();
/* 666 */       List components = new ArrayList(size);
/* 667 */       for (UriComponentsBuilder.PathComponentBuilder componentBuilder : this.componentBuilders) {
/* 668 */         HierarchicalUriComponents.PathComponent pathComponent = componentBuilder.build();
/* 669 */         if (pathComponent != null) {
/* 670 */           components.add(pathComponent);
/*     */         }
/*     */       }
/* 673 */       if (components.isEmpty()) {
/* 674 */         return HierarchicalUriComponents.NULL_PATH_COMPONENT;
/*     */       }
/* 676 */       if (components.size() == 1) {
/* 677 */         return (HierarchicalUriComponents.PathComponent)components.get(0);
/*     */       }
/* 679 */       return new HierarchicalUriComponents.PathComponentComposite(components);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract interface PathComponentBuilder
/*     */   {
/*     */     public abstract HierarchicalUriComponents.PathComponent build();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriComponentsBuilder
 * JD-Core Version:    0.6.2
 */