/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class UriUtils
/*     */ {
/*     */   private static final String SCHEME_PATTERN = "([^:/?#]+):";
/*     */   private static final String HTTP_PATTERN = "(http|https):";
/*     */   private static final String USERINFO_PATTERN = "([^@/]*)";
/*     */   private static final String HOST_PATTERN = "([^/?#:]*)";
/*     */   private static final String PORT_PATTERN = "(\\d*)";
/*     */   private static final String PATH_PATTERN = "([^?#]*)";
/*     */   private static final String QUERY_PATTERN = "([^#]*)";
/*     */   private static final String LAST_PATTERN = "(.*)";
/*  60 */   private static final Pattern URI_PATTERN = Pattern.compile("^(([^:/?#]+):)?(//(([^@/]*)@)?([^/?#:]*)(:(\\d*))?)?([^?#]*)(\\?([^#]*))?(#(.*))?");
/*     */ 
/*  64 */   private static final Pattern HTTP_URL_PATTERN = Pattern.compile("^(http|https):(//(([^@/]*)@)?([^/?#:]*)(:(\\d*))?)?([^?#]*)(\\?(.*))?");
/*     */ 
/*     */   @Deprecated
/*     */   public static String encodeUri(String uri, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  89 */     Assert.notNull(uri, "'uri' must not be null");
/*  90 */     Assert.hasLength(encoding, "'encoding' must not be empty");
/*  91 */     Matcher m = URI_PATTERN.matcher(uri);
/*  92 */     if (m.matches()) {
/*  93 */       String scheme = m.group(2);
/*  94 */       String authority = m.group(3);
/*  95 */       String userinfo = m.group(5);
/*  96 */       String host = m.group(6);
/*  97 */       String port = m.group(8);
/*  98 */       String path = m.group(9);
/*  99 */       String query = m.group(11);
/* 100 */       String fragment = m.group(13);
/*     */ 
/* 102 */       return encodeUriComponents(scheme, authority, userinfo, host, port, path, query, fragment, encoding);
/*     */     }
/*     */ 
/* 105 */     throw new IllegalArgumentException(new StringBuilder().append("[").append(uri).append("] is not a valid URI").toString());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static String encodeHttpUrl(String httpUrl, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 130 */     Assert.notNull(httpUrl, "'httpUrl' must not be null");
/* 131 */     Assert.hasLength(encoding, "'encoding' must not be empty");
/* 132 */     Matcher m = HTTP_URL_PATTERN.matcher(httpUrl);
/* 133 */     if (m.matches()) {
/* 134 */       String scheme = m.group(1);
/* 135 */       String authority = m.group(2);
/* 136 */       String userinfo = m.group(4);
/* 137 */       String host = m.group(5);
/* 138 */       String portString = m.group(7);
/* 139 */       String path = m.group(8);
/* 140 */       String query = m.group(10);
/*     */ 
/* 142 */       return encodeUriComponents(scheme, authority, userinfo, host, portString, path, query, null, encoding);
/*     */     }
/*     */ 
/* 145 */     throw new IllegalArgumentException(new StringBuilder().append("[").append(httpUrl).append("] is not a valid HTTP URL").toString());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static String encodeUriComponents(String scheme, String authority, String userInfo, String host, String port, String path, String query, String fragment, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 171 */     Assert.hasLength(encoding, "'encoding' must not be empty");
/* 172 */     StringBuilder sb = new StringBuilder();
/*     */ 
/* 174 */     if (scheme != null) {
/* 175 */       sb.append(encodeScheme(scheme, encoding));
/* 176 */       sb.append(':');
/*     */     }
/*     */ 
/* 179 */     if (authority != null) {
/* 180 */       sb.append("//");
/* 181 */       if (userInfo != null) {
/* 182 */         sb.append(encodeUserInfo(userInfo, encoding));
/* 183 */         sb.append('@');
/*     */       }
/* 185 */       if (host != null) {
/* 186 */         sb.append(encodeHost(host, encoding));
/*     */       }
/* 188 */       if (port != null) {
/* 189 */         sb.append(':');
/* 190 */         sb.append(encodePort(port, encoding));
/*     */       }
/*     */     }
/*     */ 
/* 194 */     sb.append(encodePath(path, encoding));
/*     */ 
/* 196 */     if (query != null) {
/* 197 */       sb.append('?');
/* 198 */       sb.append(encodeQuery(query, encoding));
/*     */     }
/*     */ 
/* 201 */     if (fragment != null) {
/* 202 */       sb.append('#');
/* 203 */       sb.append(encodeFragment(fragment, encoding));
/*     */     }
/*     */ 
/* 206 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String encodeScheme(String scheme, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 220 */     return HierarchicalUriComponents.encodeUriComponent(scheme, encoding, HierarchicalUriComponents.Type.SCHEME);
/*     */   }
/*     */ 
/*     */   public static String encodeAuthority(String authority, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 232 */     return HierarchicalUriComponents.encodeUriComponent(authority, encoding, HierarchicalUriComponents.Type.AUTHORITY);
/*     */   }
/*     */ 
/*     */   public static String encodeUserInfo(String userInfo, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 244 */     return HierarchicalUriComponents.encodeUriComponent(userInfo, encoding, HierarchicalUriComponents.Type.USER_INFO);
/*     */   }
/*     */ 
/*     */   public static String encodeHost(String host, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 257 */     return HierarchicalUriComponents.encodeUriComponent(host, encoding, HierarchicalUriComponents.Type.HOST_IPV4);
/*     */   }
/*     */ 
/*     */   public static String encodePort(String port, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 269 */     return HierarchicalUriComponents.encodeUriComponent(port, encoding, HierarchicalUriComponents.Type.PORT);
/*     */   }
/*     */ 
/*     */   public static String encodePath(String path, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 281 */     return HierarchicalUriComponents.encodeUriComponent(path, encoding, HierarchicalUriComponents.Type.PATH);
/*     */   }
/*     */ 
/*     */   public static String encodePathSegment(String segment, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 292 */     return HierarchicalUriComponents.encodeUriComponent(segment, encoding, HierarchicalUriComponents.Type.PATH_SEGMENT);
/*     */   }
/*     */ 
/*     */   public static String encodeQuery(String query, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 305 */     return HierarchicalUriComponents.encodeUriComponent(query, encoding, HierarchicalUriComponents.Type.QUERY);
/*     */   }
/*     */ 
/*     */   public static String encodeQueryParam(String queryParam, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 316 */     return HierarchicalUriComponents.encodeUriComponent(queryParam, encoding, HierarchicalUriComponents.Type.QUERY_PARAM);
/*     */   }
/*     */ 
/*     */   public static String encodeFragment(String fragment, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 328 */     return HierarchicalUriComponents.encodeUriComponent(fragment, encoding, HierarchicalUriComponents.Type.FRAGMENT);
/*     */   }
/*     */ 
/*     */   public static String decode(String source, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 351 */     Assert.notNull(source, "'source' must not be null");
/* 352 */     Assert.hasLength(encoding, "'encoding' must not be empty");
/* 353 */     int length = source.length();
/* 354 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(length);
/* 355 */     boolean changed = false;
/* 356 */     for (int i = 0; i < length; i++) {
/* 357 */       int ch = source.charAt(i);
/* 358 */       if (ch == 37) {
/* 359 */         if (i + 2 < length) {
/* 360 */           char hex1 = source.charAt(i + 1);
/* 361 */           char hex2 = source.charAt(i + 2);
/* 362 */           int u = Character.digit(hex1, 16);
/* 363 */           int l = Character.digit(hex2, 16);
/* 364 */           if ((u == -1) || (l == -1)) {
/* 365 */             throw new IllegalArgumentException(new StringBuilder().append("Invalid encoded sequence \"").append(source.substring(i)).append("\"").toString());
/*     */           }
/* 367 */           bos.write((char)((u << 4) + l));
/* 368 */           i += 2;
/* 369 */           changed = true;
/*     */         }
/*     */         else {
/* 372 */           throw new IllegalArgumentException(new StringBuilder().append("Invalid encoded sequence \"").append(source.substring(i)).append("\"").toString());
/*     */         }
/*     */       }
/*     */       else {
/* 376 */         bos.write(ch);
/*     */       }
/*     */     }
/* 379 */     return changed ? new String(bos.toByteArray(), encoding) : source;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriUtils
 * JD-Core Version:    0.6.2
 */