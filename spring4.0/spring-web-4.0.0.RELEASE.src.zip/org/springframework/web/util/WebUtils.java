/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletRequestWrapper;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.ServletResponseWrapper;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class WebUtils
/*     */ {
/*     */   public static final String INCLUDE_REQUEST_URI_ATTRIBUTE = "javax.servlet.include.request_uri";
/*     */   public static final String INCLUDE_CONTEXT_PATH_ATTRIBUTE = "javax.servlet.include.context_path";
/*     */   public static final String INCLUDE_SERVLET_PATH_ATTRIBUTE = "javax.servlet.include.servlet_path";
/*     */   public static final String INCLUDE_PATH_INFO_ATTRIBUTE = "javax.servlet.include.path_info";
/*     */   public static final String INCLUDE_QUERY_STRING_ATTRIBUTE = "javax.servlet.include.query_string";
/*     */   public static final String FORWARD_REQUEST_URI_ATTRIBUTE = "javax.servlet.forward.request_uri";
/*     */   public static final String FORWARD_CONTEXT_PATH_ATTRIBUTE = "javax.servlet.forward.context_path";
/*     */   public static final String FORWARD_SERVLET_PATH_ATTRIBUTE = "javax.servlet.forward.servlet_path";
/*     */   public static final String FORWARD_PATH_INFO_ATTRIBUTE = "javax.servlet.forward.path_info";
/*     */   public static final String FORWARD_QUERY_STRING_ATTRIBUTE = "javax.servlet.forward.query_string";
/*     */   public static final String ERROR_STATUS_CODE_ATTRIBUTE = "javax.servlet.error.status_code";
/*     */   public static final String ERROR_EXCEPTION_TYPE_ATTRIBUTE = "javax.servlet.error.exception_type";
/*     */   public static final String ERROR_MESSAGE_ATTRIBUTE = "javax.servlet.error.message";
/*     */   public static final String ERROR_EXCEPTION_ATTRIBUTE = "javax.servlet.error.exception";
/*     */   public static final String ERROR_REQUEST_URI_ATTRIBUTE = "javax.servlet.error.request_uri";
/*     */   public static final String ERROR_SERVLET_NAME_ATTRIBUTE = "javax.servlet.error.servlet_name";
/*     */   public static final String CONTENT_TYPE_CHARSET_PREFIX = ";charset=";
/*     */   public static final String DEFAULT_CHARACTER_ENCODING = "ISO-8859-1";
/*     */   public static final String TEMP_DIR_CONTEXT_ATTRIBUTE = "javax.servlet.context.tempdir";
/*     */   public static final String HTML_ESCAPE_CONTEXT_PARAM = "defaultHtmlEscape";
/*     */   public static final String WEB_APP_ROOT_KEY_PARAM = "webAppRootKey";
/*     */   public static final String DEFAULT_WEB_APP_ROOT_KEY = "webapp.root";
/* 119 */   public static final String[] SUBMIT_IMAGE_SUFFIXES = { ".x", ".y" };
/*     */ 
/* 122 */   public static final String SESSION_MUTEX_ATTRIBUTE = WebUtils.class.getName() + ".MUTEX";
/*     */ 
/*     */   public static void setWebAppRootSystemProperty(ServletContext servletContext)
/*     */     throws IllegalStateException
/*     */   {
/* 140 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 141 */     String root = servletContext.getRealPath("/");
/* 142 */     if (root == null) {
/* 143 */       throw new IllegalStateException("Cannot set web app root system property when WAR file is not expanded");
/*     */     }
/*     */ 
/* 146 */     String param = servletContext.getInitParameter("webAppRootKey");
/* 147 */     String key = param != null ? param : "webapp.root";
/* 148 */     String oldValue = System.getProperty(key);
/* 149 */     if ((oldValue != null) && (!StringUtils.pathEquals(oldValue, root))) {
/* 150 */       throw new IllegalStateException("Web app root system property already set to different value: '" + key + "' = [" + oldValue + "] instead of [" + root + "] - " + "Choose unique values for the 'webAppRootKey' context-param in your web.xml files!");
/*     */     }
/*     */ 
/* 155 */     System.setProperty(key, root);
/* 156 */     servletContext.log("Set web app root system property: '" + key + "' = [" + root + "]");
/*     */   }
/*     */ 
/*     */   public static void removeWebAppRootSystemProperty(ServletContext servletContext)
/*     */   {
/* 166 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 167 */     String param = servletContext.getInitParameter("webAppRootKey");
/* 168 */     String key = param != null ? param : "webapp.root";
/* 169 */     System.getProperties().remove(key);
/*     */   }
/*     */ 
/*     */   public static boolean isDefaultHtmlEscape(ServletContext servletContext)
/*     */   {
/* 180 */     if (servletContext == null) {
/* 181 */       return false;
/*     */     }
/* 183 */     String param = servletContext.getInitParameter("defaultHtmlEscape");
/* 184 */     return Boolean.valueOf(param).booleanValue();
/*     */   }
/*     */ 
/*     */   public static Boolean getDefaultHtmlEscape(ServletContext servletContext)
/*     */   {
/* 198 */     if (servletContext == null) {
/* 199 */       return null;
/*     */     }
/* 201 */     String param = servletContext.getInitParameter("defaultHtmlEscape");
/* 202 */     return StringUtils.hasText(param) ? Boolean.valueOf(param) : null;
/*     */   }
/*     */ 
/*     */   public static File getTempDir(ServletContext servletContext)
/*     */   {
/* 212 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 213 */     return (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/*     */   }
/*     */ 
/*     */   public static String getRealPath(ServletContext servletContext, String path)
/*     */     throws FileNotFoundException
/*     */   {
/* 230 */     Assert.notNull(servletContext, "ServletContext must not be null");
/*     */ 
/* 232 */     if (!path.startsWith("/")) {
/* 233 */       path = "/" + path;
/*     */     }
/* 235 */     String realPath = servletContext.getRealPath(path);
/* 236 */     if (realPath == null) {
/* 237 */       throw new FileNotFoundException("ServletContext resource [" + path + "] cannot be resolved to absolute file path - " + "web application archive not expanded?");
/*     */     }
/*     */ 
/* 241 */     return realPath;
/*     */   }
/*     */ 
/*     */   public static String getSessionId(HttpServletRequest request)
/*     */   {
/* 251 */     Assert.notNull(request, "Request must not be null");
/* 252 */     HttpSession session = request.getSession(false);
/* 253 */     return session != null ? session.getId() : null;
/*     */   }
/*     */ 
/*     */   public static Object getSessionAttribute(HttpServletRequest request, String name)
/*     */   {
/* 265 */     Assert.notNull(request, "Request must not be null");
/* 266 */     HttpSession session = request.getSession(false);
/* 267 */     return session != null ? session.getAttribute(name) : null;
/*     */   }
/*     */ 
/*     */   public static Object getRequiredSessionAttribute(HttpServletRequest request, String name)
/*     */     throws IllegalStateException
/*     */   {
/* 282 */     Object attr = getSessionAttribute(request, name);
/* 283 */     if (attr == null) {
/* 284 */       throw new IllegalStateException("No session attribute '" + name + "' found");
/*     */     }
/* 286 */     return attr;
/*     */   }
/*     */ 
/*     */   public static void setSessionAttribute(HttpServletRequest request, String name, Object value)
/*     */   {
/* 298 */     Assert.notNull(request, "Request must not be null");
/* 299 */     if (value != null) {
/* 300 */       request.getSession().setAttribute(name, value);
/*     */     }
/*     */     else {
/* 303 */       HttpSession session = request.getSession(false);
/* 304 */       if (session != null)
/* 305 */         session.removeAttribute(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object getOrCreateSessionAttribute(HttpSession session, String name, Class<?> clazz)
/*     */     throws IllegalArgumentException
/*     */   {
/* 323 */     Assert.notNull(session, "Session must not be null");
/* 324 */     Object sessionObject = session.getAttribute(name);
/* 325 */     if (sessionObject == null) {
/*     */       try {
/* 327 */         sessionObject = clazz.newInstance();
/*     */       }
/*     */       catch (InstantiationException ex)
/*     */       {
/* 332 */         throw new IllegalArgumentException("Could not instantiate class [" + clazz
/* 331 */           .getName() + "] for session attribute '" + name + "': " + ex
/* 332 */           .getMessage());
/*     */       }
/*     */       catch (IllegalAccessException ex)
/*     */       {
/* 337 */         throw new IllegalArgumentException("Could not access default constructor of class [" + clazz
/* 336 */           .getName() + "] for session attribute '" + name + "': " + ex
/* 337 */           .getMessage());
/*     */       }
/* 339 */       session.setAttribute(name, sessionObject);
/*     */     }
/* 341 */     return sessionObject;
/*     */   }
/*     */ 
/*     */   public static Object getSessionMutex(HttpSession session)
/*     */   {
/* 365 */     Assert.notNull(session, "Session must not be null");
/* 366 */     Object mutex = session.getAttribute(SESSION_MUTEX_ATTRIBUTE);
/* 367 */     if (mutex == null) {
/* 368 */       mutex = session;
/*     */     }
/* 370 */     return mutex;
/*     */   }
/*     */ 
/*     */   public static <T> T getNativeRequest(ServletRequest request, Class<T> requiredType)
/*     */   {
/* 384 */     if (requiredType != null) {
/* 385 */       if (requiredType.isInstance(request)) {
/* 386 */         return request;
/*     */       }
/* 388 */       if ((request instanceof ServletRequestWrapper)) {
/* 389 */         return getNativeRequest(((ServletRequestWrapper)request).getRequest(), requiredType);
/*     */       }
/*     */     }
/* 392 */     return null;
/*     */   }
/*     */ 
/*     */   public static <T> T getNativeResponse(ServletResponse response, Class<T> requiredType)
/*     */   {
/* 405 */     if (requiredType != null) {
/* 406 */       if (requiredType.isInstance(response)) {
/* 407 */         return response;
/*     */       }
/* 409 */       if ((response instanceof ServletResponseWrapper)) {
/* 410 */         return getNativeResponse(((ServletResponseWrapper)response).getResponse(), requiredType);
/*     */       }
/*     */     }
/* 413 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean isIncludeRequest(ServletRequest request)
/*     */   {
/* 426 */     return request.getAttribute("javax.servlet.include.request_uri") != null;
/*     */   }
/*     */ 
/*     */   public static void exposeErrorRequestAttributes(HttpServletRequest request, Throwable ex, String servletName)
/*     */   {
/* 448 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.status_code", Integer.valueOf(200));
/* 449 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.exception_type", ex.getClass());
/* 450 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.message", ex.getMessage());
/* 451 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.exception", ex);
/* 452 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.request_uri", request.getRequestURI());
/* 453 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.servlet_name", servletName);
/*     */   }
/*     */ 
/*     */   private static void exposeRequestAttributeIfNotPresent(ServletRequest request, String name, Object value)
/*     */   {
/* 463 */     if (request.getAttribute(name) == null)
/* 464 */       request.setAttribute(name, value);
/*     */   }
/*     */ 
/*     */   public static void clearErrorRequestAttributes(HttpServletRequest request)
/*     */   {
/* 480 */     request.removeAttribute("javax.servlet.error.status_code");
/* 481 */     request.removeAttribute("javax.servlet.error.exception_type");
/* 482 */     request.removeAttribute("javax.servlet.error.message");
/* 483 */     request.removeAttribute("javax.servlet.error.exception");
/* 484 */     request.removeAttribute("javax.servlet.error.request_uri");
/* 485 */     request.removeAttribute("javax.servlet.error.servlet_name");
/*     */   }
/*     */ 
/*     */   public static void exposeRequestAttributes(ServletRequest request, Map<String, ?> attributes)
/*     */   {
/* 495 */     Assert.notNull(request, "Request must not be null");
/* 496 */     Assert.notNull(attributes, "Attributes Map must not be null");
/* 497 */     for (Map.Entry entry : attributes.entrySet())
/* 498 */       request.setAttribute((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public static Cookie getCookie(HttpServletRequest request, String name)
/*     */   {
/* 510 */     Assert.notNull(request, "Request must not be null");
/* 511 */     Cookie[] cookies = request.getCookies();
/* 512 */     if (cookies != null) {
/* 513 */       for (Cookie cookie : cookies) {
/* 514 */         if (name.equals(cookie.getName())) {
/* 515 */           return cookie;
/*     */         }
/*     */       }
/*     */     }
/* 519 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean hasSubmitParameter(ServletRequest request, String name)
/*     */   {
/* 532 */     Assert.notNull(request, "Request must not be null");
/* 533 */     if (request.getParameter(name) != null) {
/* 534 */       return true;
/*     */     }
/* 536 */     for (String suffix : SUBMIT_IMAGE_SUFFIXES) {
/* 537 */       if (request.getParameter(name + suffix) != null) {
/* 538 */         return true;
/*     */       }
/*     */     }
/* 541 */     return false;
/*     */   }
/*     */ 
/*     */   public static String findParameterValue(ServletRequest request, String name)
/*     */   {
/* 554 */     return findParameterValue(request.getParameterMap(), name);
/*     */   }
/*     */ 
/*     */   public static String findParameterValue(Map<String, ?> parameters, String name)
/*     */   {
/* 582 */     Object value = parameters.get(name);
/* 583 */     if ((value instanceof String[])) {
/* 584 */       String[] values = (String[])value;
/* 585 */       return values.length > 0 ? values[0] : null;
/*     */     }
/* 587 */     if (value != null) {
/* 588 */       return value.toString();
/*     */     }
/*     */ 
/* 591 */     String prefix = name + "_";
/* 592 */     for (String paramName : parameters.keySet()) {
/* 593 */       if (paramName.startsWith(prefix))
/*     */       {
/* 595 */         for (String suffix : SUBMIT_IMAGE_SUFFIXES) {
/* 596 */           if (paramName.endsWith(suffix)) {
/* 597 */             return paramName.substring(prefix.length(), paramName.length() - suffix.length());
/*     */           }
/*     */         }
/* 600 */         return paramName.substring(prefix.length());
/*     */       }
/*     */     }
/*     */ 
/* 604 */     return null;
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> getParametersStartingWith(ServletRequest request, String prefix)
/*     */   {
/* 622 */     Assert.notNull(request, "Request must not be null");
/* 623 */     Enumeration paramNames = request.getParameterNames();
/* 624 */     Map params = new TreeMap();
/* 625 */     if (prefix == null) {
/* 626 */       prefix = "";
/*     */     }
/* 628 */     while ((paramNames != null) && (paramNames.hasMoreElements())) {
/* 629 */       String paramName = (String)paramNames.nextElement();
/* 630 */       if (("".equals(prefix)) || (paramName.startsWith(prefix))) {
/* 631 */         String unprefixed = paramName.substring(prefix.length());
/* 632 */         String[] values = request.getParameterValues(paramName);
/* 633 */         if ((values != null) && (values.length != 0))
/*     */         {
/* 636 */           if (values.length > 1) {
/* 637 */             params.put(unprefixed, values);
/*     */           }
/*     */           else
/* 640 */             params.put(unprefixed, values[0]);
/*     */         }
/*     */       }
/*     */     }
/* 644 */     return params;
/*     */   }
/*     */ 
/*     */   public static int getTargetPage(ServletRequest request, String paramPrefix, int currentPage)
/*     */   {
/* 657 */     Enumeration paramNames = request.getParameterNames();
/* 658 */     while (paramNames.hasMoreElements()) {
/* 659 */       String paramName = (String)paramNames.nextElement();
/* 660 */       if (paramName.startsWith(paramPrefix)) {
/* 661 */         for (int i = 0; i < SUBMIT_IMAGE_SUFFIXES.length; i++) {
/* 662 */           String suffix = SUBMIT_IMAGE_SUFFIXES[i];
/* 663 */           if (paramName.endsWith(suffix)) {
/* 664 */             paramName = paramName.substring(0, paramName.length() - suffix.length());
/*     */           }
/*     */         }
/* 667 */         return Integer.parseInt(paramName.substring(paramPrefix.length()));
/*     */       }
/*     */     }
/* 670 */     return currentPage;
/*     */   }
/*     */ 
/*     */   public static String extractFilenameFromUrlPath(String urlPath)
/*     */   {
/* 681 */     String filename = extractFullFilenameFromUrlPath(urlPath);
/* 682 */     int dotIndex = filename.lastIndexOf(46);
/* 683 */     if (dotIndex != -1) {
/* 684 */       filename = filename.substring(0, dotIndex);
/*     */     }
/* 686 */     return filename;
/*     */   }
/*     */ 
/*     */   public static String extractFullFilenameFromUrlPath(String urlPath)
/*     */   {
/* 696 */     int end = urlPath.indexOf(59);
/* 697 */     if (end == -1) {
/* 698 */       end = urlPath.indexOf(63);
/* 699 */       if (end == -1) {
/* 700 */         end = urlPath.length();
/*     */       }
/*     */     }
/* 703 */     int begin = urlPath.lastIndexOf(47, end) + 1;
/* 704 */     return urlPath.substring(begin, end);
/*     */   }
/*     */ 
/*     */   public static MultiValueMap<String, String> parseMatrixVariables(String matrixVariables)
/*     */   {
/* 717 */     MultiValueMap result = new LinkedMultiValueMap();
/* 718 */     if (!StringUtils.hasText(matrixVariables)) {
/* 719 */       return result;
/*     */     }
/* 721 */     StringTokenizer pairs = new StringTokenizer(matrixVariables, ";");
/* 722 */     while (pairs.hasMoreTokens()) {
/* 723 */       String pair = pairs.nextToken();
/* 724 */       int index = pair.indexOf(61);
/* 725 */       if (index != -1) {
/* 726 */         String name = pair.substring(0, index);
/* 727 */         String rawValue = pair.substring(index + 1);
/* 728 */         for (String value : StringUtils.commaDelimitedListToStringArray(rawValue))
/* 729 */           result.add(name, value);
/*     */       }
/*     */       else
/*     */       {
/* 733 */         result.add(pair, "");
/*     */       }
/*     */     }
/* 736 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-web-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.WebUtils
 * JD-Core Version:    0.6.2
 */