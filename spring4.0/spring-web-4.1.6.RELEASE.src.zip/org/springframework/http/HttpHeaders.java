/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class HttpHeaders
/*     */   implements MultiValueMap<String, String>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8578554704772377436L;
/*     */   public static final String ACCEPT = "Accept";
/*     */   public static final String ACCEPT_CHARSET = "Accept-Charset";
/*     */   public static final String ACCEPT_ENCODING = "Accept-Encoding";
/*     */   public static final String ACCEPT_LANGUAGE = "Accept-Language";
/*     */   public static final String ACCEPT_RANGES = "Accept-Ranges";
/*     */   public static final String AGE = "Age";
/*     */   public static final String ALLOW = "Allow";
/*     */   public static final String AUTHORIZATION = "Authorization";
/*     */   public static final String CACHE_CONTROL = "Cache-Control";
/*     */   public static final String CONNECTION = "Connection";
/*     */   public static final String CONTENT_ENCODING = "Content-Encoding";
/*     */   public static final String CONTENT_DISPOSITION = "Content-Disposition";
/*     */   public static final String CONTENT_LANGUAGE = "Content-Language";
/*     */   public static final String CONTENT_LENGTH = "Content-Length";
/*     */   public static final String CONTENT_LOCATION = "Content-Location";
/*     */   public static final String CONTENT_RANGE = "Content-Range";
/*     */   public static final String CONTENT_TYPE = "Content-Type";
/*     */   public static final String COOKIE = "Cookie";
/*     */   public static final String DATE = "Date";
/*     */   public static final String ETAG = "ETag";
/*     */   public static final String EXPECT = "Expect";
/*     */   public static final String EXPIRES = "Expires";
/*     */   public static final String FROM = "From";
/*     */   public static final String HOST = "Host";
/*     */   public static final String IF_MATCH = "If-Match";
/*     */   public static final String IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   public static final String IF_NONE_MATCH = "If-None-Match";
/*     */   public static final String IF_RANGE = "If-Range";
/*     */   public static final String IF_UNMODIFIED_SINCE = "If-Unmodified-Since";
/*     */   public static final String LAST_MODIFIED = "Last-Modified";
/*     */   public static final String LINK = "Link";
/*     */   public static final String LOCATION = "Location";
/*     */   public static final String MAX_FORWARDS = "Max-Forwards";
/*     */   public static final String ORIGIN = "Origin";
/*     */   public static final String PRAGMA = "Pragma";
/*     */   public static final String PROXY_AUTHENTICATE = "Proxy-Authenticate";
/*     */   public static final String PROXY_AUTHORIZATION = "Proxy-Authorization";
/*     */   public static final String RANGE = "Range";
/*     */   public static final String REFERER = "Referer";
/*     */   public static final String RETRY_AFTER = "Retry-After";
/*     */   public static final String SERVER = "Server";
/*     */   public static final String SET_COOKIE = "Set-Cookie";
/*     */   public static final String SET_COOKIE2 = "Set-Cookie2";
/*     */   public static final String TE = "TE";
/*     */   public static final String TRAILER = "Trailer";
/*     */   public static final String TRANSFER_ENCODING = "Transfer-Encoding";
/*     */   public static final String UPGRADE = "Upgrade";
/*     */   public static final String USER_AGENT = "User-Agent";
/*     */   public static final String VARY = "Vary";
/*     */   public static final String VIA = "Via";
/*     */   public static final String WARNING = "Warning";
/*     */   public static final String WWW_AUTHENTICATE = "WWW-Authenticate";
/* 325 */   private static final String[] DATE_FORMATS = { "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM dd HH:mm:ss yyyy" };
/*     */ 
/* 331 */   private static TimeZone GMT = TimeZone.getTimeZone("GMT");
/*     */   private final Map<String, List<String>> headers;
/*     */ 
/*     */   public HttpHeaders()
/*     */   {
/* 341 */     this(new LinkedCaseInsensitiveMap(8, Locale.ENGLISH), false);
/*     */   }
/*     */ 
/*     */   private HttpHeaders(Map<String, List<String>> headers, boolean readOnly)
/*     */   {
/* 348 */     Assert.notNull(headers, "'headers' must not be null");
/* 349 */     if (readOnly)
/*     */     {
/* 351 */       Map map = new LinkedCaseInsensitiveMap(headers
/* 351 */         .size(), Locale.ENGLISH);
/* 352 */       for (Map.Entry entry : headers.entrySet()) {
/* 353 */         List values = Collections.unmodifiableList((List)entry.getValue());
/* 354 */         map.put(entry.getKey(), values);
/*     */       }
/* 356 */       this.headers = Collections.unmodifiableMap(map);
/*     */     }
/*     */     else {
/* 359 */       this.headers = headers;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAccept(List<MediaType> acceptableMediaTypes)
/*     */   {
/* 369 */     set("Accept", MediaType.toString(acceptableMediaTypes));
/*     */   }
/*     */ 
/*     */   public List<MediaType> getAccept()
/*     */   {
/* 378 */     String value = getFirst("Accept");
/* 379 */     List result = value != null ? MediaType.parseMediaTypes(value) : Collections.emptyList();
/*     */ 
/* 382 */     if (result.size() == 1) {
/* 383 */       List acceptHeader = get("Accept");
/* 384 */       if (acceptHeader.size() > 1) {
/* 385 */         value = StringUtils.collectionToCommaDelimitedString(acceptHeader);
/* 386 */         result = MediaType.parseMediaTypes(value);
/*     */       }
/*     */     }
/*     */ 
/* 390 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAcceptCharset(List<Charset> acceptableCharsets)
/*     */   {
/* 398 */     StringBuilder builder = new StringBuilder();
/* 399 */     for (Iterator iterator = acceptableCharsets.iterator(); iterator.hasNext(); ) {
/* 400 */       Charset charset = (Charset)iterator.next();
/* 401 */       builder.append(charset.name().toLowerCase(Locale.ENGLISH));
/* 402 */       if (iterator.hasNext()) {
/* 403 */         builder.append(", ");
/*     */       }
/*     */     }
/* 406 */     set("Accept-Charset", builder.toString());
/*     */   }
/*     */ 
/*     */   public List<Charset> getAcceptCharset()
/*     */   {
/* 414 */     List result = new ArrayList();
/* 415 */     String value = getFirst("Accept-Charset");
/* 416 */     if (value != null) {
/* 417 */       String[] tokens = value.split(",\\s*");
/* 418 */       for (String token : tokens) {
/* 419 */         int paramIdx = token.indexOf(59);
/*     */         String charsetName;
/*     */         String charsetName;
/* 421 */         if (paramIdx == -1) {
/* 422 */           charsetName = token;
/*     */         }
/*     */         else {
/* 425 */           charsetName = token.substring(0, paramIdx);
/*     */         }
/* 427 */         if (!charsetName.equals("*")) {
/* 428 */           result.add(Charset.forName(charsetName));
/*     */         }
/*     */       }
/*     */     }
/* 432 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAllow(Set<HttpMethod> allowedMethods)
/*     */   {
/* 440 */     set("Allow", StringUtils.collectionToCommaDelimitedString(allowedMethods));
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> getAllow()
/*     */   {
/* 449 */     String value = getFirst("Allow");
/* 450 */     if (!StringUtils.isEmpty(value)) {
/* 451 */       List allowedMethod = new ArrayList(5);
/* 452 */       String[] tokens = value.split(",\\s*");
/* 453 */       for (String token : tokens) {
/* 454 */         allowedMethod.add(HttpMethod.valueOf(token));
/*     */       }
/* 456 */       return EnumSet.copyOf(allowedMethod);
/*     */     }
/*     */ 
/* 459 */     return EnumSet.noneOf(HttpMethod.class);
/*     */   }
/*     */ 
/*     */   public void setCacheControl(String cacheControl)
/*     */   {
/* 467 */     set("Cache-Control", cacheControl);
/*     */   }
/*     */ 
/*     */   public String getCacheControl()
/*     */   {
/* 474 */     return getFirst("Cache-Control");
/*     */   }
/*     */ 
/*     */   public void setConnection(String connection)
/*     */   {
/* 481 */     set("Connection", connection);
/*     */   }
/*     */ 
/*     */   public void setConnection(List<String> connection)
/*     */   {
/* 488 */     set("Connection", toCommaDelimitedString(connection));
/*     */   }
/*     */ 
/*     */   public List<String> getConnection()
/*     */   {
/* 495 */     return getFirstValueAsList("Connection");
/*     */   }
/*     */ 
/*     */   public void setContentDispositionFormData(String name, String filename)
/*     */   {
/* 505 */     Assert.notNull(name, "'name' must not be null");
/* 506 */     StringBuilder builder = new StringBuilder("form-data; name=\"");
/* 507 */     builder.append(name).append('"');
/* 508 */     if (filename != null) {
/* 509 */       builder.append("; filename=\"");
/* 510 */       builder.append(filename).append('"');
/*     */     }
/* 512 */     set("Content-Disposition", builder.toString());
/*     */   }
/*     */ 
/*     */   public void setContentLength(long contentLength)
/*     */   {
/* 520 */     set("Content-Length", Long.toString(contentLength));
/*     */   }
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/* 529 */     String value = getFirst("Content-Length");
/* 530 */     return value != null ? Long.parseLong(value) : -1L;
/*     */   }
/*     */ 
/*     */   public void setContentType(MediaType mediaType)
/*     */   {
/* 538 */     Assert.isTrue(!mediaType.isWildcardType(), "'Content-Type' cannot contain wildcard type '*'");
/* 539 */     Assert.isTrue(!mediaType.isWildcardSubtype(), "'Content-Type' cannot contain wildcard subtype '*'");
/* 540 */     set("Content-Type", mediaType.toString());
/*     */   }
/*     */ 
/*     */   public MediaType getContentType()
/*     */   {
/* 549 */     String value = getFirst("Content-Type");
/* 550 */     return StringUtils.hasLength(value) ? MediaType.parseMediaType(value) : null;
/*     */   }
/*     */ 
/*     */   public void setDate(long date)
/*     */   {
/* 560 */     setDate("Date", date);
/*     */   }
/*     */ 
/*     */   public long getDate()
/*     */   {
/* 571 */     return getFirstDate("Date");
/*     */   }
/*     */ 
/*     */   public void setETag(String eTag)
/*     */   {
/* 578 */     if (eTag != null) {
/* 579 */       Assert.isTrue((eTag.startsWith("\"")) || (eTag.startsWith("W/")), "Invalid eTag, does not start with W/ or \"");
/*     */ 
/* 581 */       Assert.isTrue(eTag.endsWith("\""), "Invalid eTag, does not end with \"");
/*     */     }
/* 583 */     set("ETag", eTag);
/*     */   }
/*     */ 
/*     */   public String getETag()
/*     */   {
/* 590 */     return getFirst("ETag");
/*     */   }
/*     */ 
/*     */   public void setExpires(long expires)
/*     */   {
/* 600 */     setDate("Expires", expires);
/*     */   }
/*     */ 
/*     */   public long getExpires()
/*     */   {
/*     */     try
/*     */     {
/* 611 */       return getFirstDate("Expires");
/*     */     } catch (IllegalArgumentException ex) {
/*     */     }
/* 614 */     return -1L;
/*     */   }
/*     */ 
/*     */   public void setIfModifiedSince(long ifModifiedSince)
/*     */   {
/* 624 */     setDate("If-Modified-Since", ifModifiedSince);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long getIfNotModifiedSince()
/*     */   {
/* 635 */     return getIfModifiedSince();
/*     */   }
/*     */ 
/*     */   public long getIfModifiedSince()
/*     */   {
/* 644 */     return getFirstDate("If-Modified-Since");
/*     */   }
/*     */ 
/*     */   public void setIfNoneMatch(String ifNoneMatch)
/*     */   {
/* 651 */     set("If-None-Match", ifNoneMatch);
/*     */   }
/*     */ 
/*     */   public void setIfNoneMatch(List<String> ifNoneMatchList)
/*     */   {
/* 658 */     set("If-None-Match", toCommaDelimitedString(ifNoneMatchList));
/*     */   }
/*     */ 
/*     */   protected String toCommaDelimitedString(List<String> list) {
/* 662 */     StringBuilder builder = new StringBuilder();
/* 663 */     for (Iterator iterator = list.iterator(); iterator.hasNext(); ) {
/* 664 */       String ifNoneMatch = (String)iterator.next();
/* 665 */       builder.append(ifNoneMatch);
/* 666 */       if (iterator.hasNext()) {
/* 667 */         builder.append(", ");
/*     */       }
/*     */     }
/* 670 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public List<String> getIfNoneMatch()
/*     */   {
/* 677 */     return getFirstValueAsList("If-None-Match");
/*     */   }
/*     */ 
/*     */   protected List<String> getFirstValueAsList(String header) {
/* 681 */     List result = new ArrayList();
/* 682 */     String value = getFirst(header);
/* 683 */     if (value != null) {
/* 684 */       String[] tokens = value.split(",\\s*");
/* 685 */       for (String token : tokens) {
/* 686 */         result.add(token);
/*     */       }
/*     */     }
/* 689 */     return result;
/*     */   }
/*     */ 
/*     */   public void setLastModified(long lastModified)
/*     */   {
/* 699 */     setDate("Last-Modified", lastModified);
/*     */   }
/*     */ 
/*     */   public long getLastModified()
/*     */   {
/* 709 */     return getFirstDate("Last-Modified");
/*     */   }
/*     */ 
/*     */   public void setLocation(URI location)
/*     */   {
/* 717 */     set("Location", location.toASCIIString());
/*     */   }
/*     */ 
/*     */   public URI getLocation()
/*     */   {
/* 726 */     String value = getFirst("Location");
/* 727 */     return value != null ? URI.create(value) : null;
/*     */   }
/*     */ 
/*     */   public void setOrigin(String origin)
/*     */   {
/* 734 */     set("Origin", origin);
/*     */   }
/*     */ 
/*     */   public String getOrigin()
/*     */   {
/* 741 */     return getFirst("Origin");
/*     */   }
/*     */ 
/*     */   public void setPragma(String pragma)
/*     */   {
/* 748 */     set("Pragma", pragma);
/*     */   }
/*     */ 
/*     */   public String getPragma()
/*     */   {
/* 755 */     return getFirst("Pragma");
/*     */   }
/*     */ 
/*     */   public void setUpgrade(String upgrade)
/*     */   {
/* 762 */     set("Upgrade", upgrade);
/*     */   }
/*     */ 
/*     */   public String getUpgrade()
/*     */   {
/* 769 */     return getFirst("Upgrade");
/*     */   }
/*     */ 
/*     */   public long getFirstDate(String headerName)
/*     */   {
/* 778 */     String headerValue = getFirst(headerName);
/* 779 */     if (headerValue == null) {
/* 780 */       return -1L;
/*     */     }
/* 782 */     for (String dateFormat : DATE_FORMATS) {
/* 783 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat, Locale.US);
/* 784 */       simpleDateFormat.setTimeZone(GMT);
/*     */       try {
/* 786 */         return simpleDateFormat.parse(headerValue).getTime();
/*     */       }
/*     */       catch (ParseException localParseException)
/*     */       {
/*     */       }
/*     */     }
/* 792 */     throw new IllegalArgumentException(new StringBuilder().append("Cannot parse date value \"").append(headerValue).append("\" for \"").append(headerName).append("\" header").toString());
/*     */   }
/*     */ 
/*     */   public void setDate(String headerName, long date)
/*     */   {
/* 802 */     SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMATS[0], Locale.US);
/* 803 */     dateFormat.setTimeZone(GMT);
/* 804 */     set(headerName, dateFormat.format(new Date(date)));
/*     */   }
/*     */ 
/*     */   public String getFirst(String headerName)
/*     */   {
/* 814 */     List headerValues = (List)this.headers.get(headerName);
/* 815 */     return headerValues != null ? (String)headerValues.get(0) : null;
/*     */   }
/*     */ 
/*     */   public void add(String headerName, String headerValue)
/*     */   {
/* 828 */     List headerValues = (List)this.headers.get(headerName);
/* 829 */     if (headerValues == null) {
/* 830 */       headerValues = new LinkedList();
/* 831 */       this.headers.put(headerName, headerValues);
/*     */     }
/* 833 */     headerValues.add(headerValue);
/*     */   }
/*     */ 
/*     */   public void set(String headerName, String headerValue)
/*     */   {
/* 846 */     List headerValues = new LinkedList();
/* 847 */     headerValues.add(headerValue);
/* 848 */     this.headers.put(headerName, headerValues);
/*     */   }
/*     */ 
/*     */   public void setAll(Map<String, String> values)
/*     */   {
/* 853 */     for (Map.Entry entry : values.entrySet())
/* 854 */       set((String)entry.getKey(), (String)entry.getValue());
/*     */   }
/*     */ 
/*     */   public Map<String, String> toSingleValueMap()
/*     */   {
/* 860 */     LinkedHashMap singleValueMap = new LinkedHashMap(this.headers.size());
/* 861 */     for (Map.Entry entry : this.headers.entrySet()) {
/* 862 */       singleValueMap.put(entry.getKey(), ((List)entry.getValue()).get(0));
/*     */     }
/* 864 */     return singleValueMap;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 872 */     return this.headers.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 877 */     return this.headers.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 882 */     return this.headers.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 887 */     return this.headers.containsValue(value);
/*     */   }
/*     */ 
/*     */   public List<String> get(Object key)
/*     */   {
/* 892 */     return (List)this.headers.get(key);
/*     */   }
/*     */ 
/*     */   public List<String> put(String key, List<String> value)
/*     */   {
/* 897 */     return (List)this.headers.put(key, value);
/*     */   }
/*     */ 
/*     */   public List<String> remove(Object key)
/*     */   {
/* 902 */     return (List)this.headers.remove(key);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends List<String>> map)
/*     */   {
/* 907 */     this.headers.putAll(map);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 912 */     this.headers.clear();
/*     */   }
/*     */ 
/*     */   public Set<String> keySet()
/*     */   {
/* 917 */     return this.headers.keySet();
/*     */   }
/*     */ 
/*     */   public Collection<List<String>> values()
/*     */   {
/* 922 */     return this.headers.values();
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<String, List<String>>> entrySet()
/*     */   {
/* 927 */     return this.headers.entrySet();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 933 */     if (this == other) {
/* 934 */       return true;
/*     */     }
/* 936 */     if (!(other instanceof HttpHeaders)) {
/* 937 */       return false;
/*     */     }
/* 939 */     HttpHeaders otherHeaders = (HttpHeaders)other;
/* 940 */     return this.headers.equals(otherHeaders.headers);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 945 */     return this.headers.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 950 */     return this.headers.toString();
/*     */   }
/*     */ 
/*     */   public static HttpHeaders readOnlyHttpHeaders(HttpHeaders headers)
/*     */   {
/* 958 */     return new HttpHeaders(headers, true);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpHeaders
 * JD-Core Version:    0.6.2
 */