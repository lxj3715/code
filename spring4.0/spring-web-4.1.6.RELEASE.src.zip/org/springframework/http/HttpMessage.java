package org.springframework.http;

public abstract interface HttpMessage
{
  public abstract HttpHeaders getHeaders();
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpMessage
 * JD-Core Version:    0.6.2
 */