/*    */ package org.springframework.http;
/*    */ 
/*    */ public enum HttpMethod
/*    */ {
/* 29 */   GET, POST, HEAD, OPTIONS, PUT, PATCH, DELETE, TRACE;
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpMethod
 * JD-Core Version:    0.6.2
 */