/*     */ package org.springframework.http;
/*     */ 
/*     */ public enum HttpStatus
/*     */ {
/*  38 */   CONTINUE(100, "Continue"), 
/*     */ 
/*  43 */   SWITCHING_PROTOCOLS(101, "Switching Protocols"), 
/*     */ 
/*  48 */   PROCESSING(102, "Processing"), 
/*     */ 
/*  54 */   CHECKPOINT(103, "Checkpoint"), 
/*     */ 
/*  62 */   OK(200, "OK"), 
/*     */ 
/*  67 */   CREATED(201, "Created"), 
/*     */ 
/*  72 */   ACCEPTED(202, "Accepted"), 
/*     */ 
/*  77 */   NON_AUTHORITATIVE_INFORMATION(203, "Non-Authoritative Information"), 
/*     */ 
/*  82 */   NO_CONTENT(204, "No Content"), 
/*     */ 
/*  87 */   RESET_CONTENT(205, "Reset Content"), 
/*     */ 
/*  92 */   PARTIAL_CONTENT(206, "Partial Content"), 
/*     */ 
/*  97 */   MULTI_STATUS(207, "Multi-Status"), 
/*     */ 
/* 102 */   ALREADY_REPORTED(208, "Already Reported"), 
/*     */ 
/* 107 */   IM_USED(226, "IM Used"), 
/*     */ 
/* 115 */   MULTIPLE_CHOICES(300, "Multiple Choices"), 
/*     */ 
/* 120 */   MOVED_PERMANENTLY(301, "Moved Permanently"), 
/*     */ 
/* 125 */   FOUND(302, "Found"), 
/*     */ 
/* 131 */   MOVED_TEMPORARILY(302, "Moved Temporarily"), 
/*     */ 
/* 137 */   SEE_OTHER(303, "See Other"), 
/*     */ 
/* 142 */   NOT_MODIFIED(304, "Not Modified"), 
/*     */ 
/* 148 */   USE_PROXY(305, "Use Proxy"), 
/*     */ 
/* 154 */   TEMPORARY_REDIRECT(307, "Temporary Redirect"), 
/*     */ 
/* 159 */   PERMANENT_REDIRECT(308, "Permanent Redirect"), 
/*     */ 
/* 167 */   BAD_REQUEST(400, "Bad Request"), 
/*     */ 
/* 172 */   UNAUTHORIZED(401, "Unauthorized"), 
/*     */ 
/* 177 */   PAYMENT_REQUIRED(402, "Payment Required"), 
/*     */ 
/* 182 */   FORBIDDEN(403, "Forbidden"), 
/*     */ 
/* 187 */   NOT_FOUND(404, "Not Found"), 
/*     */ 
/* 192 */   METHOD_NOT_ALLOWED(405, "Method Not Allowed"), 
/*     */ 
/* 197 */   NOT_ACCEPTABLE(406, "Not Acceptable"), 
/*     */ 
/* 202 */   PROXY_AUTHENTICATION_REQUIRED(407, "Proxy Authentication Required"), 
/*     */ 
/* 207 */   REQUEST_TIMEOUT(408, "Request Timeout"), 
/*     */ 
/* 212 */   CONFLICT(409, "Conflict"), 
/*     */ 
/* 217 */   GONE(410, "Gone"), 
/*     */ 
/* 222 */   LENGTH_REQUIRED(411, "Length Required"), 
/*     */ 
/* 227 */   PRECONDITION_FAILED(412, "Precondition Failed"), 
/*     */ 
/* 233 */   PAYLOAD_TOO_LARGE(413, "Payload Too Large"), 
/*     */ 
/* 239 */   REQUEST_ENTITY_TOO_LARGE(413, "Request Entity Too Large"), 
/*     */ 
/* 246 */   URI_TOO_LONG(414, "URI Too Long"), 
/*     */ 
/* 252 */   REQUEST_URI_TOO_LONG(414, "Request-URI Too Long"), 
/*     */ 
/* 258 */   UNSUPPORTED_MEDIA_TYPE(415, "Unsupported Media Type"), 
/*     */ 
/* 263 */   REQUESTED_RANGE_NOT_SATISFIABLE(416, "Requested range not satisfiable"), 
/*     */ 
/* 268 */   EXPECTATION_FAILED(417, "Expectation Failed"), 
/*     */ 
/* 273 */   I_AM_A_TEAPOT(418, "I'm a teapot"), 
/*     */ 
/* 277 */   INSUFFICIENT_SPACE_ON_RESOURCE(419, "Insufficient Space On Resource"), 
/*     */ 
/* 282 */   METHOD_FAILURE(420, "Method Failure"), 
/*     */ 
/* 287 */   DESTINATION_LOCKED(421, "Destination Locked"), 
/*     */ 
/* 293 */   UNPROCESSABLE_ENTITY(422, "Unprocessable Entity"), 
/*     */ 
/* 298 */   LOCKED(423, "Locked"), 
/*     */ 
/* 303 */   FAILED_DEPENDENCY(424, "Failed Dependency"), 
/*     */ 
/* 308 */   UPGRADE_REQUIRED(426, "Upgrade Required"), 
/*     */ 
/* 313 */   PRECONDITION_REQUIRED(428, "Precondition Required"), 
/*     */ 
/* 318 */   TOO_MANY_REQUESTS(429, "Too Many Requests"), 
/*     */ 
/* 323 */   REQUEST_HEADER_FIELDS_TOO_LARGE(431, "Request Header Fields Too Large"), 
/*     */ 
/* 331 */   INTERNAL_SERVER_ERROR(500, "Internal Server Error"), 
/*     */ 
/* 336 */   NOT_IMPLEMENTED(501, "Not Implemented"), 
/*     */ 
/* 341 */   BAD_GATEWAY(502, "Bad Gateway"), 
/*     */ 
/* 346 */   SERVICE_UNAVAILABLE(503, "Service Unavailable"), 
/*     */ 
/* 351 */   GATEWAY_TIMEOUT(504, "Gateway Timeout"), 
/*     */ 
/* 356 */   HTTP_VERSION_NOT_SUPPORTED(505, "HTTP Version not supported"), 
/*     */ 
/* 361 */   VARIANT_ALSO_NEGOTIATES(506, "Variant Also Negotiates"), 
/*     */ 
/* 366 */   INSUFFICIENT_STORAGE(507, "Insufficient Storage"), 
/*     */ 
/* 371 */   LOOP_DETECTED(508, "Loop Detected"), 
/*     */ 
/* 375 */   BANDWIDTH_LIMIT_EXCEEDED(509, "Bandwidth Limit Exceeded"), 
/*     */ 
/* 380 */   NOT_EXTENDED(510, "Not Extended"), 
/*     */ 
/* 385 */   NETWORK_AUTHENTICATION_REQUIRED(511, "Network Authentication Required");
/*     */ 
/*     */   private final int value;
/*     */   private final String reasonPhrase;
/*     */ 
/*     */   private HttpStatus(int value, String reasonPhrase)
/*     */   {
/* 395 */     this.value = value;
/* 396 */     this.reasonPhrase = reasonPhrase;
/*     */   }
/*     */ 
/*     */   public int value()
/*     */   {
/* 403 */     return this.value;
/*     */   }
/*     */ 
/*     */   public String getReasonPhrase()
/*     */   {
/* 410 */     return this.reasonPhrase;
/*     */   }
/*     */ 
/*     */   public boolean is1xxInformational()
/*     */   {
/* 419 */     return Series.INFORMATIONAL.equals(series());
/*     */   }
/*     */ 
/*     */   public boolean is2xxSuccessful()
/*     */   {
/* 428 */     return Series.SUCCESSFUL.equals(series());
/*     */   }
/*     */ 
/*     */   public boolean is3xxRedirection()
/*     */   {
/* 437 */     return Series.REDIRECTION.equals(series());
/*     */   }
/*     */ 
/*     */   public boolean is4xxClientError()
/*     */   {
/* 447 */     return Series.CLIENT_ERROR.equals(series());
/*     */   }
/*     */ 
/*     */   public boolean is5xxServerError()
/*     */   {
/* 456 */     return Series.SERVER_ERROR.equals(series());
/*     */   }
/*     */ 
/*     */   public Series series()
/*     */   {
/* 464 */     return Series.valueOf(this);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 472 */     return Integer.toString(this.value);
/*     */   }
/*     */ 
/*     */   public static HttpStatus valueOf(int statusCode)
/*     */   {
/* 483 */     for (HttpStatus status : values()) {
/* 484 */       if (status.value == statusCode) {
/* 485 */         return status;
/*     */       }
/*     */     }
/* 488 */     throw new IllegalArgumentException("No matching constant for [" + statusCode + "]");
/*     */   }
/*     */ 
/*     */   public static enum Series
/*     */   {
/* 498 */     INFORMATIONAL(1), 
/* 499 */     SUCCESSFUL(2), 
/* 500 */     REDIRECTION(3), 
/* 501 */     CLIENT_ERROR(4), 
/* 502 */     SERVER_ERROR(5);
/*     */ 
/*     */     private final int value;
/*     */ 
/*     */     private Series(int value) {
/* 507 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public int value()
/*     */     {
/* 514 */       return this.value;
/*     */     }
/*     */ 
/*     */     public static Series valueOf(int status) {
/* 518 */       int seriesCode = status / 100;
/* 519 */       for (Series series : values()) {
/* 520 */         if (series.value == seriesCode) {
/* 521 */           return series;
/*     */         }
/*     */       }
/* 524 */       throw new IllegalArgumentException("No matching constant for [" + status + "]");
/*     */     }
/*     */ 
/*     */     public static Series valueOf(HttpStatus status) {
/* 528 */       return valueOf(status.value);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpStatus
 * JD-Core Version:    0.6.2
 */