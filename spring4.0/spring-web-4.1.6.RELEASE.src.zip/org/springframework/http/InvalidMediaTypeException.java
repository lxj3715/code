/*    */ package org.springframework.http;
/*    */ 
/*    */ import org.springframework.util.InvalidMimeTypeException;
/*    */ 
/*    */ public class InvalidMediaTypeException extends IllegalArgumentException
/*    */ {
/*    */   private String mediaType;
/*    */ 
/*    */   public InvalidMediaTypeException(String mediaType, String message)
/*    */   {
/* 40 */     super("Invalid media type \"" + mediaType + "\": " + message);
/* 41 */     this.mediaType = mediaType;
/*    */   }
/*    */ 
/*    */   InvalidMediaTypeException(InvalidMimeTypeException ex)
/*    */   {
/* 48 */     super(ex.getMessage(), ex);
/* 49 */     this.mediaType = ex.getMimeType();
/*    */   }
/*    */ 
/*    */   public String getMediaType()
/*    */   {
/* 57 */     return this.mediaType;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.InvalidMediaTypeException
 * JD-Core Version:    0.6.2
 */