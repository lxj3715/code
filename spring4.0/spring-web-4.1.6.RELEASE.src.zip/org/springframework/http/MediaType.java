/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.InvalidMimeTypeException;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeType.SpecificityComparator;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.comparator.CompoundComparator;
/*     */ 
/*     */ public class MediaType extends MimeType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2069937152339670231L;
/* 196 */   public static final MediaType ALL = valueOf("*/*");
/*     */   public static final String ALL_VALUE = "*/*";
/* 197 */   public static final MediaType APPLICATION_ATOM_XML = valueOf("application/atom+xml");
/*     */   public static final String APPLICATION_ATOM_XML_VALUE = "application/atom+xml";
/* 198 */   public static final MediaType APPLICATION_FORM_URLENCODED = valueOf("application/x-www-form-urlencoded");
/*     */   public static final String APPLICATION_FORM_URLENCODED_VALUE = "application/x-www-form-urlencoded";
/* 199 */   public static final MediaType APPLICATION_JSON = valueOf("application/json");
/*     */   public static final String APPLICATION_JSON_VALUE = "application/json";
/* 200 */   public static final MediaType APPLICATION_OCTET_STREAM = valueOf("application/octet-stream");
/*     */   public static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream";
/* 201 */   public static final MediaType APPLICATION_XHTML_XML = valueOf("application/xhtml+xml");
/*     */   public static final String APPLICATION_XHTML_XML_VALUE = "application/xhtml+xml";
/* 202 */   public static final MediaType APPLICATION_XML = valueOf("application/xml");
/*     */   public static final String APPLICATION_XML_VALUE = "application/xml";
/* 203 */   public static final MediaType IMAGE_GIF = valueOf("image/gif");
/*     */   public static final String IMAGE_GIF_VALUE = "image/gif";
/* 204 */   public static final MediaType IMAGE_JPEG = valueOf("image/jpeg");
/*     */   public static final String IMAGE_JPEG_VALUE = "image/jpeg";
/* 205 */   public static final MediaType IMAGE_PNG = valueOf("image/png");
/*     */   public static final String IMAGE_PNG_VALUE = "image/png";
/* 206 */   public static final MediaType MULTIPART_FORM_DATA = valueOf("multipart/form-data");
/*     */   public static final String MULTIPART_FORM_DATA_VALUE = "multipart/form-data";
/* 207 */   public static final MediaType TEXT_HTML = valueOf("text/html");
/*     */   public static final String TEXT_HTML_VALUE = "text/html";
/* 208 */   public static final MediaType TEXT_PLAIN = valueOf("text/plain");
/*     */   public static final String TEXT_PLAIN_VALUE = "text/plain";
/* 209 */   public static final MediaType TEXT_XML = valueOf("text/xml");
/*     */   public static final String TEXT_XML_VALUE = "text/xml";
/*     */   private static final String PARAM_QUALITY_FACTOR = "q";
/* 490 */   public static final Comparator<MediaType> QUALITY_VALUE_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(MediaType mediaType1, MediaType mediaType2)
/*     */     {
/* 494 */       double quality1 = mediaType1.getQualityValue();
/* 495 */       double quality2 = mediaType2.getQualityValue();
/* 496 */       int qualityComparison = Double.compare(quality2, quality1);
/* 497 */       if (qualityComparison != 0) {
/* 498 */         return qualityComparison;
/*     */       }
/* 500 */       if ((mediaType1.isWildcardType()) && (!mediaType2.isWildcardType())) {
/* 501 */         return 1;
/*     */       }
/* 503 */       if ((mediaType2.isWildcardType()) && (!mediaType1.isWildcardType())) {
/* 504 */         return -1;
/*     */       }
/* 506 */       if (!mediaType1.getType().equals(mediaType2.getType())) {
/* 507 */         return 0;
/*     */       }
/*     */ 
/* 510 */       if ((mediaType1.isWildcardSubtype()) && (!mediaType2.isWildcardSubtype())) {
/* 511 */         return 1;
/*     */       }
/* 513 */       if ((mediaType2.isWildcardSubtype()) && (!mediaType1.isWildcardSubtype())) {
/* 514 */         return -1;
/*     */       }
/* 516 */       if (!mediaType1.getSubtype().equals(mediaType2.getSubtype())) {
/* 517 */         return 0;
/*     */       }
/*     */ 
/* 520 */       int paramsSize1 = mediaType1.getParameters().size();
/* 521 */       int paramsSize2 = mediaType2.getParameters().size();
/* 522 */       return paramsSize2 == paramsSize1 ? 0 : paramsSize2 < paramsSize1 ? -1 : 1;
/*     */     }
/* 490 */   };
/*     */ 
/* 532 */   public static final Comparator<MediaType> SPECIFICITY_COMPARATOR = new MimeType.SpecificityComparator()
/*     */   {
/*     */     protected int compareParameters(MediaType mediaType1, MediaType mediaType2)
/*     */     {
/* 536 */       double quality1 = mediaType1.getQualityValue();
/* 537 */       double quality2 = mediaType2.getQualityValue();
/* 538 */       int qualityComparison = Double.compare(quality2, quality1);
/* 539 */       if (qualityComparison != 0) {
/* 540 */         return qualityComparison;
/*     */       }
/* 542 */       return super.compareParameters(mediaType1, mediaType2);
/*     */     }
/* 532 */   };
/*     */ 
/*     */   public MediaType(String type)
/*     */   {
/* 220 */     super(type);
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype)
/*     */   {
/* 231 */     super(type, subtype, Collections.emptyMap());
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, Charset charset)
/*     */   {
/* 242 */     super(type, subtype, charset);
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, double qualityValue)
/*     */   {
/* 253 */     this(type, subtype, Collections.singletonMap("q", Double.toString(qualityValue)));
/*     */   }
/*     */ 
/*     */   public MediaType(MediaType other, Map<String, String> parameters)
/*     */   {
/* 264 */     super(other.getType(), other.getSubtype(), parameters);
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, Map<String, String> parameters)
/*     */   {
/* 275 */     super(type, subtype, parameters);
/*     */   }
/*     */ 
/*     */   protected void checkParameters(String attribute, String value)
/*     */   {
/* 280 */     super.checkParameters(attribute, value);
/* 281 */     if ("q".equals(attribute)) {
/* 282 */       value = unquote(value);
/* 283 */       double d = Double.parseDouble(value);
/* 284 */       Assert.isTrue((d >= 0.0D) && (d <= 1.0D), "Invalid quality value \"" + value + "\": should be between 0.0 and 1.0");
/*     */     }
/*     */   }
/*     */ 
/*     */   public double getQualityValue()
/*     */   {
/* 295 */     String qualityFactory = getParameter("q");
/* 296 */     return qualityFactory != null ? Double.parseDouble(unquote(qualityFactory)) : 1.0D;
/*     */   }
/*     */ 
/*     */   public boolean includes(MediaType other)
/*     */   {
/* 307 */     return super.includes(other);
/*     */   }
/*     */ 
/*     */   public boolean isCompatibleWith(MediaType other)
/*     */   {
/* 318 */     return super.isCompatibleWith(other);
/*     */   }
/*     */ 
/*     */   public MediaType copyQualityValue(MediaType mediaType)
/*     */   {
/* 326 */     if (!mediaType.getParameters().containsKey("q")) {
/* 327 */       return this;
/*     */     }
/* 329 */     Map params = new LinkedHashMap(getParameters());
/* 330 */     params.put("q", mediaType.getParameters().get("q"));
/* 331 */     return new MediaType(this, params);
/*     */   }
/*     */ 
/*     */   public MediaType removeQualityValue()
/*     */   {
/* 339 */     if (!getParameters().containsKey("q")) {
/* 340 */       return this;
/*     */     }
/* 342 */     Map params = new LinkedHashMap(getParameters());
/* 343 */     params.remove("q");
/* 344 */     return new MediaType(this, params);
/*     */   }
/*     */ 
/*     */   public static MediaType valueOf(String value)
/*     */   {
/* 355 */     return parseMediaType(value);
/*     */   }
/*     */ 
/*     */   public static MediaType parseMediaType(String mediaType)
/*     */   {
/*     */     try
/*     */     {
/* 367 */       type = MimeTypeUtils.parseMimeType(mediaType);
/*     */     }
/*     */     catch (InvalidMimeTypeException ex)
/*     */     {
/*     */       MimeType type;
/* 370 */       throw new InvalidMediaTypeException(ex);
/*     */     }
/*     */     try
/*     */     {
/*     */       MimeType type;
/* 373 */       return new MediaType(type.getType(), type.getSubtype(), type.getParameters());
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 376 */       throw new InvalidMediaTypeException(mediaType, ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static List<MediaType> parseMediaTypes(String mediaTypes)
/*     */   {
/* 389 */     if (!StringUtils.hasLength(mediaTypes)) {
/* 390 */       return Collections.emptyList();
/*     */     }
/* 392 */     String[] tokens = mediaTypes.split(",\\s*");
/* 393 */     List result = new ArrayList(tokens.length);
/* 394 */     for (String token : tokens) {
/* 395 */       result.add(parseMediaType(token));
/*     */     }
/* 397 */     return result;
/*     */   }
/*     */ 
/*     */   public static String toString(Collection<MediaType> mediaTypes)
/*     */   {
/* 408 */     return MimeTypeUtils.toString(mediaTypes);
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificity(List<MediaType> mediaTypes)
/*     */   {
/* 439 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 440 */     if (mediaTypes.size() > 1)
/* 441 */       Collections.sort(mediaTypes, SPECIFICITY_COMPARATOR);
/*     */   }
/*     */ 
/*     */   public static void sortByQualityValue(List<MediaType> mediaTypes)
/*     */   {
/* 466 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 467 */     if (mediaTypes.size() > 1)
/* 468 */       Collections.sort(mediaTypes, QUALITY_VALUE_COMPARATOR);
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificityAndQuality(List<MediaType> mediaTypes)
/*     */   {
/* 479 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 480 */     if (mediaTypes.size() > 1)
/* 481 */       Collections.sort(mediaTypes, new CompoundComparator(new Comparator[] { SPECIFICITY_COMPARATOR, QUALITY_VALUE_COMPARATOR }));
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.MediaType
 * JD-Core Version:    0.6.2
 */