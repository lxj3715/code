/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class RequestEntity<T> extends HttpEntity<T>
/*     */ {
/*     */   private final HttpMethod method;
/*     */   private final URI url;
/*     */ 
/*     */   public RequestEntity(HttpMethod method, URI url)
/*     */   {
/*  75 */     this(null, null, method, url);
/*     */   }
/*     */ 
/*     */   public RequestEntity(T body, HttpMethod method, URI url)
/*     */   {
/*  85 */     this(body, null, method, url);
/*     */   }
/*     */ 
/*     */   public RequestEntity(MultiValueMap<String, String> headers, HttpMethod method, URI url)
/*     */   {
/*  95 */     this(null, headers, method, url);
/*     */   }
/*     */ 
/*     */   public RequestEntity(T body, MultiValueMap<String, String> headers, HttpMethod method, URI url)
/*     */   {
/* 106 */     super(body, headers);
/* 107 */     Assert.notNull(method, "'method' is required");
/* 108 */     Assert.notNull(url, "'url' is required");
/* 109 */     this.method = method;
/* 110 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/* 119 */     return this.method;
/*     */   }
/*     */ 
/*     */   public URI getUrl()
/*     */   {
/* 127 */     return this.url;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 133 */     if (this == other) {
/* 134 */       return true;
/*     */     }
/* 136 */     if ((!(other instanceof RequestEntity)) || (!super.equals(other))) {
/* 137 */       return false;
/*     */     }
/* 139 */     RequestEntity otherEntity = (RequestEntity)other;
/*     */ 
/* 141 */     return (ObjectUtils.nullSafeEquals(this.method, otherEntity.method)) && 
/* 141 */       (ObjectUtils.nullSafeEquals(this.url, otherEntity.url));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 146 */     int hashCode = super.hashCode();
/* 147 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.method);
/* 148 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.url);
/* 149 */     return hashCode;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 154 */     StringBuilder builder = new StringBuilder("<");
/* 155 */     builder.append(this.method);
/* 156 */     builder.append(' ');
/* 157 */     builder.append(this.url);
/* 158 */     builder.append(',');
/* 159 */     Object body = getBody();
/* 160 */     HttpHeaders headers = getHeaders();
/* 161 */     if (body != null) {
/* 162 */       builder.append(body);
/* 163 */       if (headers != null) {
/* 164 */         builder.append(',');
/*     */       }
/*     */     }
/* 167 */     if (headers != null) {
/* 168 */       builder.append(headers);
/*     */     }
/* 170 */     builder.append('>');
/* 171 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public static BodyBuilder method(HttpMethod method, URI url)
/*     */   {
/* 184 */     return new DefaultBodyBuilder(method, url);
/*     */   }
/*     */ 
/*     */   public static HeadersBuilder<?> get(URI url)
/*     */   {
/* 193 */     return method(HttpMethod.GET, url);
/*     */   }
/*     */ 
/*     */   public static HeadersBuilder<?> head(URI url)
/*     */   {
/* 202 */     return method(HttpMethod.HEAD, url);
/*     */   }
/*     */ 
/*     */   public static BodyBuilder post(URI url)
/*     */   {
/* 211 */     return method(HttpMethod.POST, url);
/*     */   }
/*     */ 
/*     */   public static BodyBuilder put(URI url)
/*     */   {
/* 220 */     return method(HttpMethod.PUT, url);
/*     */   }
/*     */ 
/*     */   public static BodyBuilder patch(URI url)
/*     */   {
/* 229 */     return method(HttpMethod.PATCH, url);
/*     */   }
/*     */ 
/*     */   public static HeadersBuilder<?> delete(URI url)
/*     */   {
/* 238 */     return method(HttpMethod.DELETE, url);
/*     */   }
/*     */ 
/*     */   public static HeadersBuilder<?> options(URI url)
/*     */   {
/* 247 */     return method(HttpMethod.OPTIONS, url);
/*     */   }
/*     */ 
/*     */   private static class DefaultBodyBuilder
/*     */     implements RequestEntity.BodyBuilder
/*     */   {
/*     */     private final HttpMethod method;
/*     */     private final URI url;
/* 342 */     private final HttpHeaders headers = new HttpHeaders();
/*     */ 
/*     */     public DefaultBodyBuilder(HttpMethod method, URI url) {
/* 345 */       this.method = method;
/* 346 */       this.url = url;
/*     */     }
/*     */ 
/*     */     public RequestEntity.BodyBuilder header(String headerName, String[] headerValues)
/*     */     {
/* 351 */       for (String headerValue : headerValues) {
/* 352 */         this.headers.add(headerName, headerValue);
/*     */       }
/* 354 */       return this;
/*     */     }
/*     */ 
/*     */     public RequestEntity.BodyBuilder accept(MediaType[] acceptableMediaTypes)
/*     */     {
/* 359 */       this.headers.setAccept(Arrays.asList(acceptableMediaTypes));
/* 360 */       return this;
/*     */     }
/*     */ 
/*     */     public RequestEntity.BodyBuilder acceptCharset(Charset[] acceptableCharsets)
/*     */     {
/* 365 */       this.headers.setAcceptCharset(Arrays.asList(acceptableCharsets));
/* 366 */       return this;
/*     */     }
/*     */ 
/*     */     public RequestEntity.BodyBuilder contentLength(long contentLength)
/*     */     {
/* 371 */       this.headers.setContentLength(contentLength);
/* 372 */       return this;
/*     */     }
/*     */ 
/*     */     public RequestEntity.BodyBuilder contentType(MediaType contentType)
/*     */     {
/* 377 */       this.headers.setContentType(contentType);
/* 378 */       return this;
/*     */     }
/*     */ 
/*     */     public RequestEntity.BodyBuilder ifModifiedSince(long ifModifiedSince)
/*     */     {
/* 383 */       this.headers.setIfModifiedSince(ifModifiedSince);
/* 384 */       return this;
/*     */     }
/*     */ 
/*     */     public RequestEntity.BodyBuilder ifNoneMatch(String[] ifNoneMatches)
/*     */     {
/* 389 */       this.headers.setIfNoneMatch(Arrays.asList(ifNoneMatches));
/* 390 */       return this;
/*     */     }
/*     */ 
/*     */     public RequestEntity<Void> build()
/*     */     {
/* 395 */       return new RequestEntity(this.headers, this.method, this.url);
/*     */     }
/*     */ 
/*     */     public <T> RequestEntity<T> body(T body)
/*     */     {
/* 400 */       return new RequestEntity(body, this.headers, this.method, this.url);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface BodyBuilder extends RequestEntity.HeadersBuilder<BodyBuilder>
/*     */   {
/*     */     public abstract BodyBuilder contentLength(long paramLong);
/*     */ 
/*     */     public abstract BodyBuilder contentType(MediaType paramMediaType);
/*     */ 
/*     */     public abstract <T> RequestEntity<T> body(T paramT);
/*     */   }
/*     */ 
/*     */   public static abstract interface HeadersBuilder<B extends HeadersBuilder<B>>
/*     */   {
/*     */     public abstract B header(String paramString, String[] paramArrayOfString);
/*     */ 
/*     */     public abstract B accept(MediaType[] paramArrayOfMediaType);
/*     */ 
/*     */     public abstract B acceptCharset(Charset[] paramArrayOfCharset);
/*     */ 
/*     */     public abstract B ifModifiedSince(long paramLong);
/*     */ 
/*     */     public abstract B ifNoneMatch(String[] paramArrayOfString);
/*     */ 
/*     */     public abstract RequestEntity<Void> build();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.RequestEntity
 * JD-Core Version:    0.6.2
 */