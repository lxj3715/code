/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class ResponseEntity<T> extends HttpEntity<T>
/*     */ {
/*     */   private final HttpStatus statusCode;
/*     */ 
/*     */   public ResponseEntity(HttpStatus statusCode)
/*     */   {
/*  76 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(T body, HttpStatus statusCode)
/*     */   {
/*  85 */     super(body);
/*  86 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(MultiValueMap<String, String> headers, HttpStatus statusCode)
/*     */   {
/*  95 */     super(headers);
/*  96 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(T body, MultiValueMap<String, String> headers, HttpStatus statusCode)
/*     */   {
/* 106 */     super(body, headers);
/* 107 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public HttpStatus getStatusCode()
/*     */   {
/* 116 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 121 */     if (this == other) {
/* 122 */       return true;
/*     */     }
/* 124 */     if ((!(other instanceof ResponseEntity)) || (!super.equals(other))) {
/* 125 */       return false;
/*     */     }
/* 127 */     ResponseEntity otherEntity = (ResponseEntity)other;
/* 128 */     return ObjectUtils.nullSafeEquals(this.statusCode, otherEntity.statusCode);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 133 */     return super.hashCode() * 29 + ObjectUtils.nullSafeHashCode(this.statusCode);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 138 */     StringBuilder builder = new StringBuilder("<");
/* 139 */     builder.append(this.statusCode.toString());
/* 140 */     builder.append(' ');
/* 141 */     builder.append(this.statusCode.getReasonPhrase());
/* 142 */     builder.append(',');
/* 143 */     Object body = getBody();
/* 144 */     HttpHeaders headers = getHeaders();
/* 145 */     if (body != null) {
/* 146 */       builder.append(body);
/* 147 */       if (headers != null) {
/* 148 */         builder.append(',');
/*     */       }
/*     */     }
/* 151 */     if (headers != null) {
/* 152 */       builder.append(headers);
/*     */     }
/* 154 */     builder.append('>');
/* 155 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public static BodyBuilder status(HttpStatus status)
/*     */   {
/* 168 */     return new DefaultBuilder(status);
/*     */   }
/*     */ 
/*     */   public static BodyBuilder status(int status)
/*     */   {
/* 178 */     return status(HttpStatus.valueOf(status));
/*     */   }
/*     */ 
/*     */   public static BodyBuilder ok()
/*     */   {
/* 187 */     return status(HttpStatus.OK);
/*     */   }
/*     */ 
/*     */   public static <T> ResponseEntity<T> ok(T body)
/*     */   {
/* 197 */     BodyBuilder builder = ok();
/* 198 */     return builder.body(body);
/*     */   }
/*     */ 
/*     */   public static BodyBuilder created(URI location)
/*     */   {
/* 209 */     BodyBuilder builder = status(HttpStatus.CREATED);
/* 210 */     return (BodyBuilder)builder.location(location);
/*     */   }
/*     */ 
/*     */   public static BodyBuilder accepted()
/*     */   {
/* 219 */     return status(HttpStatus.ACCEPTED);
/*     */   }
/*     */ 
/*     */   public static HeadersBuilder<?> noContent()
/*     */   {
/* 228 */     return status(HttpStatus.NO_CONTENT);
/*     */   }
/*     */ 
/*     */   public static BodyBuilder badRequest()
/*     */   {
/* 237 */     return status(HttpStatus.BAD_REQUEST);
/*     */   }
/*     */ 
/*     */   public static HeadersBuilder<?> notFound()
/*     */   {
/* 246 */     return status(HttpStatus.NOT_FOUND);
/*     */   }
/*     */ 
/*     */   public static BodyBuilder unprocessableEntity()
/*     */   {
/* 256 */     return status(HttpStatus.UNPROCESSABLE_ENTITY);
/*     */   }
/*     */ 
/*     */   private static class DefaultBuilder
/*     */     implements ResponseEntity.BodyBuilder
/*     */   {
/*     */     private final HttpStatus status;
/* 368 */     private final HttpHeaders headers = new HttpHeaders();
/*     */ 
/*     */     public DefaultBuilder(HttpStatus status) {
/* 371 */       this.status = status;
/*     */     }
/*     */ 
/*     */     public ResponseEntity.BodyBuilder header(String headerName, String[] headerValues)
/*     */     {
/* 376 */       for (String headerValue : headerValues) {
/* 377 */         this.headers.add(headerName, headerValue);
/*     */       }
/* 379 */       return this;
/*     */     }
/*     */ 
/*     */     public ResponseEntity.BodyBuilder headers(HttpHeaders headers)
/*     */     {
/* 384 */       if (headers != null) {
/* 385 */         this.headers.putAll(headers);
/*     */       }
/* 387 */       return this;
/*     */     }
/*     */ 
/*     */     public ResponseEntity.BodyBuilder allow(HttpMethod[] allowedMethods)
/*     */     {
/* 392 */       this.headers.setAllow(new LinkedHashSet(Arrays.asList(allowedMethods)));
/* 393 */       return this;
/*     */     }
/*     */ 
/*     */     public ResponseEntity.BodyBuilder contentLength(long contentLength)
/*     */     {
/* 398 */       this.headers.setContentLength(contentLength);
/* 399 */       return this;
/*     */     }
/*     */ 
/*     */     public ResponseEntity.BodyBuilder contentType(MediaType contentType)
/*     */     {
/* 404 */       this.headers.setContentType(contentType);
/* 405 */       return this;
/*     */     }
/*     */ 
/*     */     public ResponseEntity.BodyBuilder eTag(String eTag)
/*     */     {
/* 410 */       this.headers.setETag(eTag);
/* 411 */       return this;
/*     */     }
/*     */ 
/*     */     public ResponseEntity.BodyBuilder lastModified(long date)
/*     */     {
/* 416 */       this.headers.setLastModified(date);
/* 417 */       return this;
/*     */     }
/*     */ 
/*     */     public ResponseEntity.BodyBuilder location(URI location)
/*     */     {
/* 422 */       this.headers.setLocation(location);
/* 423 */       return this;
/*     */     }
/*     */ 
/*     */     public ResponseEntity<Void> build()
/*     */     {
/* 428 */       return new ResponseEntity(null, this.headers, this.status);
/*     */     }
/*     */ 
/*     */     public <T> ResponseEntity<T> body(T body)
/*     */     {
/* 433 */       return new ResponseEntity(body, this.headers, this.status);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface BodyBuilder extends ResponseEntity.HeadersBuilder<BodyBuilder>
/*     */   {
/*     */     public abstract BodyBuilder contentLength(long paramLong);
/*     */ 
/*     */     public abstract BodyBuilder contentType(MediaType paramMediaType);
/*     */ 
/*     */     public abstract <T> ResponseEntity<T> body(T paramT);
/*     */   }
/*     */ 
/*     */   public static abstract interface HeadersBuilder<B extends HeadersBuilder<B>>
/*     */   {
/*     */     public abstract B header(String paramString, String[] paramArrayOfString);
/*     */ 
/*     */     public abstract B headers(HttpHeaders paramHttpHeaders);
/*     */ 
/*     */     public abstract B allow(HttpMethod[] paramArrayOfHttpMethod);
/*     */ 
/*     */     public abstract B eTag(String paramString);
/*     */ 
/*     */     public abstract B lastModified(long paramLong);
/*     */ 
/*     */     public abstract B location(URI paramURI);
/*     */ 
/*     */     public abstract ResponseEntity<Void> build();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.ResponseEntity
 * JD-Core Version:    0.6.2
 */