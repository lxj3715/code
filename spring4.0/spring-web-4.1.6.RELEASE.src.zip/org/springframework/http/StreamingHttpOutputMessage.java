package org.springframework.http;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface StreamingHttpOutputMessage extends HttpOutputMessage
{
  public abstract void setBody(Body paramBody);

  public static abstract interface Body
  {
    public abstract void writeTo(OutputStream paramOutputStream)
      throws IOException;
  }
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.StreamingHttpOutputMessage
 * JD-Core Version:    0.6.2
 */