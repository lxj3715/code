/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ abstract class AbstractBufferingClientHttpRequest extends AbstractClientHttpRequest
/*    */ {
/* 34 */   private ByteArrayOutputStream bufferedOutput = new ByteArrayOutputStream(1024);
/*    */ 
/*    */   protected OutputStream getBodyInternal(HttpHeaders headers)
/*    */     throws IOException
/*    */   {
/* 39 */     return this.bufferedOutput;
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers) throws IOException
/*    */   {
/* 44 */     byte[] bytes = this.bufferedOutput.toByteArray();
/* 45 */     if (headers.getContentLength() == -1L) {
/* 46 */       headers.setContentLength(bytes.length);
/*    */     }
/* 48 */     ClientHttpResponse result = executeInternal(headers, bytes);
/* 49 */     this.bufferedOutput = null;
/* 50 */     return result;
/*    */   }
/*    */ 
/*    */   protected abstract ClientHttpResponse executeInternal(HttpHeaders paramHttpHeaders, byte[] paramArrayOfByte)
/*    */     throws IOException;
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AbstractBufferingClientHttpRequest
 * JD-Core Version:    0.6.2
 */