package org.springframework.http.client;

import java.io.IOException;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.HttpRequest;
import org.springframework.util.concurrent.ListenableFuture;

public abstract interface AsyncClientHttpRequest extends HttpRequest, HttpOutputMessage
{
  public abstract ListenableFuture<ClientHttpResponse> executeAsync()
    throws IOException;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AsyncClientHttpRequest
 * JD-Core Version:    0.6.2
 */