package org.springframework.http.client;

import java.io.IOException;
import java.net.URI;
import org.springframework.http.HttpMethod;

public abstract interface AsyncClientHttpRequestFactory
{
  public abstract AsyncClientHttpRequest createAsyncRequest(URI paramURI, HttpMethod paramHttpMethod)
    throws IOException;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AsyncClientHttpRequestFactory
 * JD-Core Version:    0.6.2
 */