package org.springframework.http.client;

import java.io.IOException;
import org.springframework.http.HttpRequest;

public abstract interface ClientHttpRequestExecution
{
  public abstract ClientHttpResponse execute(HttpRequest paramHttpRequest, byte[] paramArrayOfByte)
    throws IOException;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.ClientHttpRequestExecution
 * JD-Core Version:    0.6.2
 */