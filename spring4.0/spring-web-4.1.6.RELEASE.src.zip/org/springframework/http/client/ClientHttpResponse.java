package org.springframework.http.client;

import java.io.Closeable;
import java.io.IOException;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpStatus;

public abstract interface ClientHttpResponse extends HttpInputMessage, Closeable
{
  public abstract HttpStatus getStatusCode()
    throws IOException;

  public abstract int getRawStatusCode()
    throws IOException;

  public abstract String getStatusText()
    throws IOException;

  public abstract void close();
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.ClientHttpResponse
 * JD-Core Version:    0.6.2
 */