/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpEntityEnclosingRequest;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.concurrent.FutureCallback;
/*     */ import org.apache.http.nio.client.HttpAsyncClient;
/*     */ import org.apache.http.nio.entity.NByteArrayEntity;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.concurrent.FailureCallback;
/*     */ import org.springframework.util.concurrent.FutureAdapter;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallback;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallbackRegistry;
/*     */ import org.springframework.util.concurrent.SuccessCallback;
/*     */ 
/*     */ final class HttpComponentsAsyncClientHttpRequest extends AbstractBufferingAsyncClientHttpRequest
/*     */ {
/*     */   private final HttpAsyncClient httpClient;
/*     */   private final HttpUriRequest httpRequest;
/*     */   private final HttpContext httpContext;
/*     */ 
/*     */   HttpComponentsAsyncClientHttpRequest(HttpAsyncClient httpClient, HttpUriRequest httpRequest, HttpContext httpContext)
/*     */   {
/*  63 */     this.httpClient = httpClient;
/*  64 */     this.httpRequest = httpRequest;
/*  65 */     this.httpContext = httpContext;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  71 */     return HttpMethod.valueOf(this.httpRequest.getMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*  76 */     return this.httpRequest.getURI();
/*     */   }
/*     */ 
/*     */   protected ListenableFuture<ClientHttpResponse> executeInternal(HttpHeaders headers, byte[] bufferedOutput)
/*     */     throws IOException
/*     */   {
/*  83 */     HttpComponentsClientHttpRequest.addHeaders(this.httpRequest, headers);
/*     */ 
/*  85 */     if ((this.httpRequest instanceof HttpEntityEnclosingRequest)) {
/*  86 */       HttpEntityEnclosingRequest entityEnclosingRequest = (HttpEntityEnclosingRequest)this.httpRequest;
/*  87 */       HttpEntity requestEntity = new NByteArrayEntity(bufferedOutput);
/*  88 */       entityEnclosingRequest.setEntity(requestEntity);
/*     */     }
/*     */ 
/*  91 */     HttpResponseFutureCallback callback = new HttpResponseFutureCallback(null);
/*     */ 
/*  93 */     Future futureResponse = this.httpClient
/*  93 */       .execute(this.httpRequest, this.httpContext, callback);
/*     */ 
/*  94 */     return new ClientHttpResponseFuture(futureResponse, callback);
/*     */   }
/*     */ 
/*     */   private static class ClientHttpResponseFuture extends FutureAdapter<ClientHttpResponse, HttpResponse>
/*     */     implements ListenableFuture<ClientHttpResponse>
/*     */   {
/*     */     private final HttpComponentsAsyncClientHttpRequest.HttpResponseFutureCallback callback;
/*     */ 
/*     */     public ClientHttpResponseFuture(Future<HttpResponse> futureResponse, HttpComponentsAsyncClientHttpRequest.HttpResponseFutureCallback callback)
/*     */     {
/* 137 */       super();
/* 138 */       this.callback = callback;
/*     */     }
/*     */ 
/*     */     protected ClientHttpResponse adapt(HttpResponse response)
/*     */     {
/* 143 */       return new HttpComponentsAsyncClientHttpResponse(response);
/*     */     }
/*     */ 
/*     */     public void addCallback(ListenableFutureCallback<? super ClientHttpResponse> callback)
/*     */     {
/* 148 */       this.callback.addCallback(callback);
/*     */     }
/*     */ 
/*     */     public void addCallback(SuccessCallback<? super ClientHttpResponse> successCallback, FailureCallback failureCallback)
/*     */     {
/* 153 */       this.callback.addSuccessCallback(successCallback);
/* 154 */       this.callback.addFailureCallback(failureCallback);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class HttpResponseFutureCallback
/*     */     implements FutureCallback<HttpResponse>
/*     */   {
/* 100 */     private final ListenableFutureCallbackRegistry<ClientHttpResponse> callbacks = new ListenableFutureCallbackRegistry();
/*     */ 
/*     */     public void addCallback(ListenableFutureCallback<? super ClientHttpResponse> callback)
/*     */     {
/* 104 */       this.callbacks.addCallback(callback);
/*     */     }
/*     */ 
/*     */     public void addSuccessCallback(SuccessCallback<? super ClientHttpResponse> callback) {
/* 108 */       this.callbacks.addSuccessCallback(callback);
/*     */     }
/*     */ 
/*     */     public void addFailureCallback(FailureCallback callback) {
/* 112 */       this.callbacks.addFailureCallback(callback);
/*     */     }
/*     */ 
/*     */     public void completed(HttpResponse result)
/*     */     {
/* 117 */       this.callbacks.success(new HttpComponentsAsyncClientHttpResponse(result));
/*     */     }
/*     */ 
/*     */     public void failed(Exception ex)
/*     */     {
/* 122 */       this.callbacks.failure(ex);
/*     */     }
/*     */ 
/*     */     public void cancelled()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsAsyncClientHttpRequest
 * JD-Core Version:    0.6.2
 */