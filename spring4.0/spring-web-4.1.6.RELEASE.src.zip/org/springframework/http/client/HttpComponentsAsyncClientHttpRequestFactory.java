/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.client.methods.Configurable;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.client.protocol.HttpClientContext;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
/*     */ import org.apache.http.impl.nio.client.HttpAsyncClients;
/*     */ import org.apache.http.nio.client.HttpAsyncClient;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class HttpComponentsAsyncClientHttpRequestFactory extends HttpComponentsClientHttpRequestFactory
/*     */   implements AsyncClientHttpRequestFactory, InitializingBean
/*     */ {
/*     */   private CloseableHttpAsyncClient httpAsyncClient;
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequestFactory()
/*     */   {
/*  57 */     this(HttpAsyncClients.createSystem());
/*     */   }
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequestFactory(CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  67 */     Assert.notNull(httpAsyncClient, "'httpAsyncClient' must not be null");
/*  68 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */ 
/*     */   public HttpComponentsAsyncClientHttpRequestFactory(CloseableHttpClient httpClient, CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  80 */     super(httpClient);
/*  81 */     Assert.notNull(httpAsyncClient, "'httpAsyncClient' must not be null");
/*  82 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */ 
/*     */   public void setHttpAsyncClient(CloseableHttpAsyncClient httpAsyncClient)
/*     */   {
/*  91 */     this.httpAsyncClient = httpAsyncClient;
/*     */   }
/*     */ 
/*     */   public CloseableHttpAsyncClient getHttpAsyncClient()
/*     */   {
/*  99 */     return this.httpAsyncClient;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 105 */     startAsyncClient();
/*     */   }
/*     */ 
/*     */   private void startAsyncClient() {
/* 109 */     CloseableHttpAsyncClient asyncClient = getHttpAsyncClient();
/* 110 */     if (!asyncClient.isRunning())
/* 111 */       asyncClient.start();
/*     */   }
/*     */ 
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 117 */     HttpAsyncClient asyncClient = getHttpAsyncClient();
/* 118 */     startAsyncClient();
/* 119 */     HttpUriRequest httpRequest = createHttpUriRequest(httpMethod, uri);
/* 120 */     postProcessHttpRequest(httpRequest);
/* 121 */     HttpContext context = createHttpContext(httpMethod, uri);
/* 122 */     if (context == null) {
/* 123 */       context = HttpClientContext.create();
/*     */     }
/*     */ 
/* 126 */     if (context.getAttribute("http.request-config") == null)
/*     */     {
/* 128 */       RequestConfig config = null;
/* 129 */       if ((httpRequest instanceof Configurable)) {
/* 130 */         config = ((Configurable)httpRequest).getConfig();
/*     */       }
/* 132 */       if (config == null) {
/* 133 */         config = RequestConfig.DEFAULT;
/*     */       }
/* 135 */       context.setAttribute("http.request-config", config);
/*     */     }
/* 137 */     return new HttpComponentsAsyncClientHttpRequest(asyncClient, httpRequest, context);
/*     */   }
/*     */ 
/*     */   public void destroy() throws Exception
/*     */   {
/*     */     try {
/* 143 */       super.destroy();
/*     */ 
/* 146 */       getHttpAsyncClient().close(); } finally { getHttpAsyncClient().close(); }
/*     */ 
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsAsyncClientHttpRequestFactory
 * JD-Core Version:    0.6.2
 */