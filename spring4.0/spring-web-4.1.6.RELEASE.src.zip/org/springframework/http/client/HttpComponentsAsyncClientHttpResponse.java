/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.http.Header;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.HttpResponse;
/*    */ import org.apache.http.StatusLine;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ final class HttpComponentsAsyncClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final HttpResponse httpResponse;
/*    */   private HttpHeaders headers;
/*    */ 
/*    */   HttpComponentsAsyncClientHttpResponse(HttpResponse httpResponse)
/*    */   {
/* 47 */     this.httpResponse = httpResponse;
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode()
/*    */     throws IOException
/*    */   {
/* 53 */     return this.httpResponse.getStatusLine().getStatusCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException
/*    */   {
/* 58 */     return this.httpResponse.getStatusLine().getReasonPhrase();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 63 */     if (this.headers == null) {
/* 64 */       this.headers = new HttpHeaders();
/* 65 */       for (Header header : this.httpResponse.getAllHeaders()) {
/* 66 */         this.headers.add(header.getName(), header.getValue());
/*    */       }
/*    */     }
/* 69 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 74 */     HttpEntity entity = this.httpResponse.getEntity();
/* 75 */     return entity != null ? entity.getContent() : null;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsAsyncClientHttpResponse
 * JD-Core Version:    0.6.2
 */