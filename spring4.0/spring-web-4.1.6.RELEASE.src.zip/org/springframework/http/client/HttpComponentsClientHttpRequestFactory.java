/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.client.config.RequestConfig.Builder;
/*     */ import org.apache.http.client.methods.Configurable;
/*     */ import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
/*     */ import org.apache.http.client.methods.HttpGet;
/*     */ import org.apache.http.client.methods.HttpHead;
/*     */ import org.apache.http.client.methods.HttpOptions;
/*     */ import org.apache.http.client.methods.HttpPatch;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpPut;
/*     */ import org.apache.http.client.methods.HttpTrace;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.client.protocol.HttpClientContext;
/*     */ import org.apache.http.impl.client.AbstractHttpClient;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.HttpClients;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class HttpComponentsClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, DisposableBean
/*     */ {
/*     */   private CloseableHttpClient httpClient;
/*     */   private RequestConfig requestConfig;
/*  64 */   private boolean bufferRequestBody = true;
/*     */ 
/*     */   public HttpComponentsClientHttpRequestFactory()
/*     */   {
/*  72 */     this(HttpClients.createSystem());
/*     */   }
/*     */ 
/*     */   public HttpComponentsClientHttpRequestFactory(HttpClient httpClient)
/*     */   {
/*  83 */     Assert.notNull(httpClient, "'httpClient' must not be null");
/*  84 */     Assert.isInstanceOf(CloseableHttpClient.class, httpClient, "'httpClient' is not of type CloseableHttpClient");
/*  85 */     this.httpClient = ((CloseableHttpClient)httpClient);
/*     */   }
/*     */ 
/*     */   public void setHttpClient(HttpClient httpClient)
/*     */   {
/*  95 */     Assert.isInstanceOf(CloseableHttpClient.class, httpClient, "'httpClient' is not of type CloseableHttpClient");
/*  96 */     this.httpClient = ((CloseableHttpClient)httpClient);
/*     */   }
/*     */ 
/*     */   public HttpClient getHttpClient()
/*     */   {
/* 104 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int timeout)
/*     */   {
/* 116 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 117 */     this.requestConfig = cloneRequestConfig()
/* 118 */       .setConnectTimeout(timeout)
/* 118 */       .build();
/* 119 */     setLegacyConnectionTimeout(getHttpClient(), timeout);
/*     */   }
/*     */ 
/*     */   private void setLegacyConnectionTimeout(HttpClient client, int timeout)
/*     */   {
/* 138 */     if (AbstractHttpClient.class.isInstance(client))
/* 139 */       client.getParams().setIntParameter("http.connection.timeout", timeout);
/*     */   }
/*     */ 
/*     */   public void setConnectionRequestTimeout(int connectionRequestTimeout)
/*     */   {
/* 154 */     this.requestConfig = cloneRequestConfig()
/* 155 */       .setConnectionRequestTimeout(connectionRequestTimeout)
/* 155 */       .build();
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int timeout)
/*     */   {
/* 167 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 168 */     this.requestConfig = cloneRequestConfig()
/* 169 */       .setSocketTimeout(timeout)
/* 169 */       .build();
/* 170 */     setLegacySocketTimeout(getHttpClient(), timeout);
/*     */   }
/*     */ 
/*     */   private void setLegacySocketTimeout(HttpClient client, int timeout)
/*     */   {
/* 182 */     if (AbstractHttpClient.class.isInstance(client))
/* 183 */       client.getParams().setIntParameter("http.socket.timeout", timeout);
/*     */   }
/*     */ 
/*     */   private RequestConfig.Builder cloneRequestConfig()
/*     */   {
/* 189 */     return this.requestConfig != null ? RequestConfig.copy(this.requestConfig) : RequestConfig.custom();
/*     */   }
/*     */ 
/*     */   public void setBufferRequestBody(boolean bufferRequestBody)
/*     */   {
/* 198 */     this.bufferRequestBody = bufferRequestBody;
/*     */   }
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 204 */     CloseableHttpClient client = (CloseableHttpClient)getHttpClient();
/* 205 */     Assert.state(client != null, "Synchronous execution requires an HttpClient to be set");
/* 206 */     HttpUriRequest httpRequest = createHttpUriRequest(httpMethod, uri);
/* 207 */     postProcessHttpRequest(httpRequest);
/* 208 */     HttpContext context = createHttpContext(httpMethod, uri);
/* 209 */     if (context == null) {
/* 210 */       context = HttpClientContext.create();
/*     */     }
/*     */ 
/* 213 */     if (context.getAttribute("http.request-config") == null)
/*     */     {
/* 215 */       RequestConfig config = null;
/* 216 */       if ((httpRequest instanceof Configurable)) {
/* 217 */         config = ((Configurable)httpRequest).getConfig();
/*     */       }
/* 219 */       if (config == null) {
/* 220 */         config = this.requestConfig;
/*     */       }
/* 222 */       if (config != null) {
/* 223 */         context.setAttribute("http.request-config", config);
/*     */       }
/*     */     }
/* 226 */     if (this.bufferRequestBody) {
/* 227 */       return new HttpComponentsClientHttpRequest(client, httpRequest, context);
/*     */     }
/*     */ 
/* 230 */     return new HttpComponentsStreamingClientHttpRequest(client, httpRequest, context);
/*     */   }
/*     */ 
/*     */   protected HttpUriRequest createHttpUriRequest(HttpMethod httpMethod, URI uri)
/*     */   {
/* 241 */     switch (1.$SwitchMap$org$springframework$http$HttpMethod[httpMethod.ordinal()]) {
/*     */     case 1:
/* 243 */       return new HttpGet(uri);
/*     */     case 2:
/* 245 */       return new HttpDelete(uri);
/*     */     case 3:
/* 247 */       return new HttpHead(uri);
/*     */     case 4:
/* 249 */       return new HttpOptions(uri);
/*     */     case 5:
/* 251 */       return new HttpPost(uri);
/*     */     case 6:
/* 253 */       return new HttpPut(uri);
/*     */     case 7:
/* 255 */       return new HttpTrace(uri);
/*     */     case 8:
/* 257 */       return new HttpPatch(uri);
/*     */     }
/* 259 */     throw new IllegalArgumentException("Invalid HTTP method: " + httpMethod);
/*     */   }
/*     */ 
/*     */   protected void postProcessHttpRequest(HttpUriRequest request)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected HttpContext createHttpContext(HttpMethod httpMethod, URI uri)
/*     */   {
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws Exception
/*     */   {
/* 291 */     this.httpClient.close();
/*     */   }
/*     */ 
/*     */   private static class HttpDelete extends HttpEntityEnclosingRequestBase
/*     */   {
/*     */     public HttpDelete(URI uri)
/*     */     {
/* 307 */       setURI(uri);
/*     */     }
/*     */ 
/*     */     public String getMethod()
/*     */     {
/* 312 */       return "DELETE";
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsClientHttpRequestFactory
 * JD-Core Version:    0.6.2
 */