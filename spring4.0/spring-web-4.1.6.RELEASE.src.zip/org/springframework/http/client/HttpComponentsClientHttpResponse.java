/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.http.Header;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.StatusLine;
/*    */ import org.apache.http.client.methods.CloseableHttpResponse;
/*    */ import org.apache.http.util.EntityUtils;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ final class HttpComponentsClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final CloseableHttpResponse httpResponse;
/*    */   private HttpHeaders headers;
/*    */ 
/*    */   HttpComponentsClientHttpResponse(CloseableHttpResponse httpResponse)
/*    */   {
/* 50 */     this.httpResponse = httpResponse;
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode()
/*    */     throws IOException
/*    */   {
/* 56 */     return this.httpResponse.getStatusLine().getStatusCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException
/*    */   {
/* 61 */     return this.httpResponse.getStatusLine().getReasonPhrase();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 66 */     if (this.headers == null) {
/* 67 */       this.headers = new HttpHeaders();
/* 68 */       for (Header header : this.httpResponse.getAllHeaders()) {
/* 69 */         this.headers.add(header.getName(), header.getValue());
/*    */       }
/*    */     }
/* 72 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 77 */     HttpEntity entity = this.httpResponse.getEntity();
/* 78 */     return entity != null ? entity.getContent() : null;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/*    */     try
/*    */     {
/*    */       try
/*    */       {
/* 87 */         EntityUtils.consume(this.httpResponse.getEntity());
/*    */ 
/* 90 */         this.httpResponse.close(); } finally { this.httpResponse.close(); }
/*    */ 
/*    */     }
/*    */     catch (IOException localIOException1)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsClientHttpResponse
 * JD-Core Version:    0.6.2
 */