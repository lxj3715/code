/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpEntityEnclosingRequest;
/*     */ import org.apache.http.client.methods.CloseableHttpResponse;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.message.BasicHeader;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.http.StreamingHttpOutputMessage.Body;
/*     */ 
/*     */ final class HttpComponentsStreamingClientHttpRequest extends AbstractClientHttpRequest
/*     */   implements StreamingHttpOutputMessage
/*     */ {
/*     */   private final CloseableHttpClient httpClient;
/*     */   private final HttpUriRequest httpRequest;
/*     */   private final HttpContext httpContext;
/*     */   private StreamingHttpOutputMessage.Body body;
/*     */ 
/*     */   HttpComponentsStreamingClientHttpRequest(CloseableHttpClient httpClient, HttpUriRequest httpRequest, HttpContext httpContext)
/*     */   {
/*  60 */     this.httpClient = httpClient;
/*  61 */     this.httpRequest = httpRequest;
/*  62 */     this.httpContext = httpContext;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  68 */     return HttpMethod.valueOf(this.httpRequest.getMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*  73 */     return this.httpRequest.getURI();
/*     */   }
/*     */ 
/*     */   public void setBody(StreamingHttpOutputMessage.Body body)
/*     */   {
/*  78 */     assertNotExecuted();
/*  79 */     this.body = body;
/*     */   }
/*     */ 
/*     */   protected OutputStream getBodyInternal(HttpHeaders headers) throws IOException
/*     */   {
/*  84 */     throw new UnsupportedOperationException("getBody not supported");
/*     */   }
/*     */ 
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers) throws IOException
/*     */   {
/*  89 */     HttpComponentsClientHttpRequest.addHeaders(this.httpRequest, headers);
/*     */ 
/*  91 */     if (((this.httpRequest instanceof HttpEntityEnclosingRequest)) && (this.body != null)) {
/*  92 */       HttpEntityEnclosingRequest entityEnclosingRequest = (HttpEntityEnclosingRequest)this.httpRequest;
/*  93 */       HttpEntity requestEntity = new StreamingHttpEntity(getHeaders(), this.body);
/*  94 */       entityEnclosingRequest.setEntity(requestEntity);
/*     */     }
/*     */ 
/*  97 */     CloseableHttpResponse httpResponse = this.httpClient.execute(this.httpRequest, this.httpContext);
/*  98 */     return new HttpComponentsClientHttpResponse(httpResponse);
/*     */   }
/*     */ 
/*     */   private static class StreamingHttpEntity implements HttpEntity
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */     private final StreamingHttpOutputMessage.Body body;
/*     */ 
/*     */     public StreamingHttpEntity(HttpHeaders headers, StreamingHttpOutputMessage.Body body)
/*     */     {
/* 109 */       this.headers = headers;
/* 110 */       this.body = body;
/*     */     }
/*     */ 
/*     */     public boolean isRepeatable()
/*     */     {
/* 115 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean isChunked()
/*     */     {
/* 120 */       return false;
/*     */     }
/*     */ 
/*     */     public long getContentLength()
/*     */     {
/* 125 */       return this.headers.getContentLength();
/*     */     }
/*     */ 
/*     */     public Header getContentType()
/*     */     {
/* 130 */       MediaType contentType = this.headers.getContentType();
/* 131 */       return contentType != null ? new BasicHeader("Content-Type", contentType.toString()) : null;
/*     */     }
/*     */ 
/*     */     public Header getContentEncoding()
/*     */     {
/* 136 */       String contentEncoding = this.headers.getFirst("Content-Encoding");
/* 137 */       return contentEncoding != null ? new BasicHeader("Content-Encoding", contentEncoding) : null;
/*     */     }
/*     */ 
/*     */     public InputStream getContent()
/*     */       throws IOException, IllegalStateException
/*     */     {
/* 143 */       throw new IllegalStateException("No content available");
/*     */     }
/*     */ 
/*     */     public void writeTo(OutputStream outputStream) throws IOException
/*     */     {
/* 148 */       this.body.writeTo(outputStream);
/*     */     }
/*     */ 
/*     */     public boolean isStreaming()
/*     */     {
/* 153 */       return true;
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public void consumeContent() throws IOException
/*     */     {
/* 159 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsStreamingClientHttpRequest
 * JD-Core Version:    0.6.2
 */