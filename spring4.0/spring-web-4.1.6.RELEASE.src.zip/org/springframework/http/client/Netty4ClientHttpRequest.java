/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import io.netty.bootstrap.Bootstrap;
/*     */ import io.netty.buffer.ByteBufOutputStream;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.SimpleChannelInboundHandler;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpRequest;
/*     */ import io.netty.handler.codec.http.FullHttpRequest;
/*     */ import io.netty.handler.codec.http.FullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.SettableListenableFuture;
/*     */ 
/*     */ class Netty4ClientHttpRequest extends AbstractAsyncClientHttpRequest
/*     */   implements ClientHttpRequest
/*     */ {
/*     */   private final Bootstrap bootstrap;
/*     */   private final URI uri;
/*     */   private final org.springframework.http.HttpMethod method;
/*     */   private final ByteBufOutputStream body;
/*     */ 
/*     */   public Netty4ClientHttpRequest(Bootstrap bootstrap, URI uri, org.springframework.http.HttpMethod method, int maxRequestSize)
/*     */   {
/*  65 */     this.bootstrap = bootstrap;
/*  66 */     this.uri = uri;
/*  67 */     this.method = method;
/*  68 */     this.body = new ByteBufOutputStream(Unpooled.buffer(1024, maxRequestSize));
/*     */   }
/*     */ 
/*     */   public org.springframework.http.HttpMethod getMethod()
/*     */   {
/*  74 */     return this.method;
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*  79 */     return this.uri;
/*     */   }
/*     */ 
/*     */   protected OutputStream getBodyInternal(org.springframework.http.HttpHeaders headers) throws IOException
/*     */   {
/*  84 */     return this.body;
/*     */   }
/*     */ 
/*     */   protected ListenableFuture<ClientHttpResponse> executeInternal(final org.springframework.http.HttpHeaders headers) throws IOException
/*     */   {
/*  89 */     final SettableListenableFuture responseFuture = new SettableListenableFuture();
/*     */ 
/*  92 */     ChannelFutureListener connectionListener = new ChannelFutureListener()
/*     */     {
/*     */       public void operationComplete(ChannelFuture future) throws Exception {
/*  95 */         if (future.isSuccess()) {
/*  96 */           Channel channel = future.channel();
/*  97 */           channel.pipeline().addLast(new ChannelHandler[] { new Netty4ClientHttpRequest.RequestExecuteHandler(responseFuture) });
/*  98 */           FullHttpRequest nettyRequest = Netty4ClientHttpRequest.this.createFullHttpRequest(headers);
/*  99 */           channel.writeAndFlush(nettyRequest);
/*     */         }
/*     */         else {
/* 102 */           responseFuture.setException(future.cause());
/*     */         }
/*     */       }
/*     */     };
/* 107 */     this.bootstrap.connect(this.uri.getHost(), getPort(this.uri)).addListener(connectionListener);
/*     */ 
/* 109 */     return responseFuture;
/*     */   }
/*     */ 
/*     */   public ClientHttpResponse execute() throws IOException
/*     */   {
/*     */     try {
/* 115 */       return (ClientHttpResponse)executeAsync().get();
/*     */     }
/*     */     catch (InterruptedException ex) {
/* 118 */       throw new IOException(ex.getMessage(), ex);
/*     */     }
/*     */     catch (ExecutionException ex) {
/* 121 */       if ((ex.getCause() instanceof IOException)) {
/* 122 */         throw ((IOException)ex.getCause());
/*     */       }
/*     */ 
/* 125 */       throw new IOException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static int getPort(URI uri)
/*     */   {
/* 131 */     int port = uri.getPort();
/* 132 */     if (port == -1) {
/* 133 */       if ("http".equalsIgnoreCase(uri.getScheme())) {
/* 134 */         port = 80;
/*     */       }
/* 136 */       else if ("https".equalsIgnoreCase(uri.getScheme())) {
/* 137 */         port = 443;
/*     */       }
/*     */     }
/* 140 */     return port;
/*     */   }
/*     */ 
/*     */   private FullHttpRequest createFullHttpRequest(org.springframework.http.HttpHeaders headers)
/*     */   {
/* 145 */     io.netty.handler.codec.http.HttpMethod nettyMethod = io.netty.handler.codec.http.HttpMethod.valueOf(this.method
/* 145 */       .name());
/*     */ 
/* 148 */     FullHttpRequest nettyRequest = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, nettyMethod, this.uri
/* 148 */       .getRawPath(), this.body.buffer());
/*     */ 
/* 150 */     nettyRequest.headers().set("Host", this.uri.getHost());
/* 151 */     nettyRequest.headers().set("Connection", "close");
/*     */ 
/* 153 */     for (Map.Entry entry : headers.entrySet()) {
/* 154 */       nettyRequest.headers().add((String)entry.getKey(), (Iterable)entry.getValue());
/*     */     }
/*     */ 
/* 157 */     return nettyRequest;
/*     */   }
/*     */ 
/*     */   private static class RequestExecuteHandler extends SimpleChannelInboundHandler<FullHttpResponse>
/*     */   {
/*     */     private final SettableListenableFuture<ClientHttpResponse> responseFuture;
/*     */ 
/*     */     public RequestExecuteHandler(SettableListenableFuture<ClientHttpResponse> responseFuture)
/*     */     {
/* 169 */       this.responseFuture = responseFuture;
/*     */     }
/*     */ 
/*     */     protected void channelRead0(ChannelHandlerContext context, FullHttpResponse response) throws Exception
/*     */     {
/* 174 */       this.responseFuture.set(new Netty4ClientHttpResponse(context, response));
/*     */     }
/*     */ 
/*     */     public void exceptionCaught(ChannelHandlerContext context, Throwable cause) throws Exception
/*     */     {
/* 179 */       this.responseFuture.setException(cause);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.Netty4ClientHttpRequest
 * JD-Core Version:    0.6.2
 */