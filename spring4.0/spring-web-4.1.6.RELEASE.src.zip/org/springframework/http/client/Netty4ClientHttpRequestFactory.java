/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import io.netty.bootstrap.Bootstrap;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.nio.NioEventLoopGroup;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.channel.socket.nio.NioSocketChannel;
/*     */ import io.netty.handler.codec.http.HttpClientCodec;
/*     */ import io.netty.handler.codec.http.HttpObjectAggregator;
/*     */ import io.netty.handler.ssl.SslContext;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class Netty4ClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, AsyncClientHttpRequestFactory, InitializingBean, DisposableBean
/*     */ {
/*     */ 
/*     */   @Deprecated
/*     */   public static final int DEFAULT_MAX_REQUEST_SIZE = 10485760;
/*     */   public static final int DEFAULT_MAX_RESPONSE_SIZE = 10485760;
/*     */   private final EventLoopGroup eventLoopGroup;
/*     */   private final boolean defaultEventLoopGroup;
/*  71 */   private int maxRequestSize = 10485760;
/*     */ 
/*  73 */   private int maxResponseSize = 10485760;
/*     */   private SslContext sslContext;
/*     */   private volatile Bootstrap bootstrap;
/*     */ 
/*     */   public Netty4ClientHttpRequestFactory()
/*     */   {
/*  85 */     int ioWorkerCount = Runtime.getRuntime().availableProcessors() * 2;
/*  86 */     this.eventLoopGroup = new NioEventLoopGroup(ioWorkerCount);
/*  87 */     this.defaultEventLoopGroup = true;
/*     */   }
/*     */ 
/*     */   public Netty4ClientHttpRequestFactory(EventLoopGroup eventLoopGroup)
/*     */   {
/*  98 */     Assert.notNull(eventLoopGroup, "EventLoopGroup must not be null");
/*  99 */     this.eventLoopGroup = eventLoopGroup;
/* 100 */     this.defaultEventLoopGroup = false;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setMaxRequestSize(int maxRequestSize)
/*     */   {
/* 113 */     this.maxRequestSize = maxRequestSize;
/*     */   }
/*     */ 
/*     */   public void setMaxResponseSize(int maxResponseSize)
/*     */   {
/* 123 */     this.maxResponseSize = maxResponseSize;
/*     */   }
/*     */ 
/*     */   public void setSslContext(SslContext sslContext)
/*     */   {
/* 133 */     this.sslContext = sslContext;
/*     */   }
/*     */ 
/*     */   private Bootstrap getBootstrap() {
/* 137 */     if (this.bootstrap == null) {
/* 138 */       Bootstrap bootstrap = new Bootstrap();
/* 139 */       ((Bootstrap)((Bootstrap)bootstrap.group(this.eventLoopGroup)).channel(NioSocketChannel.class))
/* 140 */         .handler(new ChannelInitializer()
/*     */       {
/*     */         protected void initChannel(SocketChannel channel) throws Exception
/*     */         {
/* 143 */           ChannelPipeline pipeline = channel.pipeline();
/* 144 */           if (Netty4ClientHttpRequestFactory.this.sslContext != null) {
/* 145 */             pipeline.addLast(new ChannelHandler[] { Netty4ClientHttpRequestFactory.this.sslContext.newHandler(channel.alloc()) });
/*     */           }
/* 147 */           pipeline.addLast(new ChannelHandler[] { new HttpClientCodec() });
/* 148 */           pipeline.addLast(new ChannelHandler[] { new HttpObjectAggregator(Netty4ClientHttpRequestFactory.this.maxResponseSize) });
/*     */         }
/*     */       });
/* 151 */       this.bootstrap = bootstrap;
/*     */     }
/* 153 */     return this.bootstrap;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 158 */     getBootstrap();
/*     */   }
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 164 */     return createRequestInternal(uri, httpMethod);
/*     */   }
/*     */ 
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod) throws IOException
/*     */   {
/* 169 */     return createRequestInternal(uri, httpMethod);
/*     */   }
/*     */ 
/*     */   private Netty4ClientHttpRequest createRequestInternal(URI uri, HttpMethod httpMethod) {
/* 173 */     return new Netty4ClientHttpRequest(getBootstrap(), uri, httpMethod, this.maxRequestSize);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws InterruptedException
/*     */   {
/* 179 */     if (this.defaultEventLoopGroup)
/*     */     {
/* 181 */       this.eventLoopGroup.shutdownGracefully().sync();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.Netty4ClientHttpRequestFactory
 * JD-Core Version:    0.6.2
 */