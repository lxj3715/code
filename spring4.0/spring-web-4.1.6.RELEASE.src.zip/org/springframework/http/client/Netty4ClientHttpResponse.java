/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import io.netty.buffer.ByteBufInputStream;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.http.FullHttpResponse;
/*    */ import io.netty.handler.codec.http.HttpResponseStatus;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ class Netty4ClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final ChannelHandlerContext context;
/*    */   private final FullHttpResponse nettyResponse;
/*    */   private final ByteBufInputStream body;
/*    */   private volatile HttpHeaders headers;
/*    */ 
/*    */   public Netty4ClientHttpResponse(ChannelHandlerContext context, FullHttpResponse nettyResponse)
/*    */   {
/* 49 */     Assert.notNull(context, "ChannelHandlerContext must not be null");
/* 50 */     Assert.notNull(nettyResponse, "FullHttpResponse must not be null");
/* 51 */     this.context = context;
/* 52 */     this.nettyResponse = nettyResponse;
/* 53 */     this.body = new ByteBufInputStream(this.nettyResponse.content());
/* 54 */     this.nettyResponse.retain();
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode()
/*    */     throws IOException
/*    */   {
/* 60 */     return this.nettyResponse.getStatus().code();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException
/*    */   {
/* 65 */     return this.nettyResponse.getStatus().reasonPhrase();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 70 */     if (this.headers == null) {
/* 71 */       HttpHeaders headers = new HttpHeaders();
/* 72 */       for (Map.Entry entry : this.nettyResponse.headers()) {
/* 73 */         headers.add((String)entry.getKey(), (String)entry.getValue());
/*    */       }
/* 75 */       this.headers = headers;
/*    */     }
/* 77 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 82 */     return this.body;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/* 87 */     this.nettyResponse.release();
/* 88 */     this.context.close();
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.Netty4ClientHttpResponse
 * JD-Core Version:    0.6.2
 */