/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.Proxy;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.springframework.core.task.AsyncListenableTaskExecutor;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SimpleClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, AsyncClientHttpRequestFactory
/*     */ {
/*     */   private static final int DEFAULT_CHUNK_SIZE = 4096;
/*     */   private Proxy proxy;
/*  46 */   private boolean bufferRequestBody = true;
/*     */ 
/*  48 */   private int chunkSize = 4096;
/*     */ 
/*  50 */   private int connectTimeout = -1;
/*     */ 
/*  52 */   private int readTimeout = -1;
/*     */ 
/*  54 */   private boolean outputStreaming = true;
/*     */   private AsyncListenableTaskExecutor taskExecutor;
/*     */ 
/*     */   public void setProxy(Proxy proxy)
/*     */   {
/*  63 */     this.proxy = proxy;
/*     */   }
/*     */ 
/*     */   public void setBufferRequestBody(boolean bufferRequestBody)
/*     */   {
/*  78 */     this.bufferRequestBody = bufferRequestBody;
/*     */   }
/*     */ 
/*     */   public void setChunkSize(int chunkSize)
/*     */   {
/*  89 */     this.chunkSize = chunkSize;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int connectTimeout)
/*     */   {
/*  99 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int readTimeout)
/*     */   {
/* 109 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */   public void setOutputStreaming(boolean outputStreaming)
/*     */   {
/* 122 */     this.outputStreaming = outputStreaming;
/*     */   }
/*     */ 
/*     */   public void setTaskExecutor(AsyncListenableTaskExecutor taskExecutor)
/*     */   {
/* 131 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 137 */     HttpURLConnection connection = openConnection(uri.toURL(), this.proxy);
/* 138 */     prepareConnection(connection, httpMethod.name());
/* 139 */     if (this.bufferRequestBody) {
/* 140 */       return new SimpleBufferingClientHttpRequest(connection, this.outputStreaming);
/*     */     }
/*     */ 
/* 143 */     return new SimpleStreamingClientHttpRequest(connection, this.chunkSize, this.outputStreaming);
/*     */   }
/*     */ 
/*     */   public AsyncClientHttpRequest createAsyncRequest(URI uri, HttpMethod httpMethod)
/*     */     throws IOException
/*     */   {
/* 154 */     Assert.state(this.taskExecutor != null, "Asynchronous execution requires an AsyncTaskExecutor to be set");
/* 155 */     HttpURLConnection connection = openConnection(uri.toURL(), this.proxy);
/* 156 */     prepareConnection(connection, httpMethod.name());
/* 157 */     if (this.bufferRequestBody) {
/* 158 */       return new SimpleBufferingAsyncClientHttpRequest(connection, this.outputStreaming, this.taskExecutor);
/*     */     }
/*     */ 
/* 161 */     return new SimpleStreamingAsyncClientHttpRequest(connection, this.chunkSize, this.outputStreaming, this.taskExecutor);
/*     */   }
/*     */ 
/*     */   protected HttpURLConnection openConnection(URL url, Proxy proxy)
/*     */     throws IOException
/*     */   {
/* 176 */     URLConnection urlConnection = proxy != null ? url.openConnection(proxy) : url.openConnection();
/* 177 */     Assert.isInstanceOf(HttpURLConnection.class, urlConnection);
/* 178 */     return (HttpURLConnection)urlConnection;
/*     */   }
/*     */ 
/*     */   protected void prepareConnection(HttpURLConnection connection, String httpMethod)
/*     */     throws IOException
/*     */   {
/* 189 */     if (this.connectTimeout >= 0) {
/* 190 */       connection.setConnectTimeout(this.connectTimeout);
/*     */     }
/* 192 */     if (this.readTimeout >= 0) {
/* 193 */       connection.setReadTimeout(this.readTimeout);
/*     */     }
/* 195 */     connection.setDoInput(true);
/* 196 */     if ("GET".equals(httpMethod)) {
/* 197 */       connection.setInstanceFollowRedirects(true);
/*     */     }
/*     */     else {
/* 200 */       connection.setInstanceFollowRedirects(false);
/*     */     }
/* 202 */     if (("PUT".equals(httpMethod)) || ("POST".equals(httpMethod)) || 
/* 203 */       ("PATCH"
/* 203 */       .equals(httpMethod)) || 
/* 203 */       ("DELETE".equals(httpMethod))) {
/* 204 */       connection.setDoOutput(true);
/*     */     }
/*     */     else {
/* 207 */       connection.setDoOutput(false);
/*     */     }
/* 209 */     connection.setRequestMethod(httpMethod);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleClientHttpRequestFactory
 * JD-Core Version:    0.6.2
 */