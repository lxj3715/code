/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.HttpURLConnection;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ final class SimpleClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final HttpURLConnection connection;
/*    */   private HttpHeaders headers;
/*    */ 
/*    */   SimpleClientHttpResponse(HttpURLConnection connection)
/*    */   {
/* 42 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode()
/*    */     throws IOException
/*    */   {
/* 48 */     return this.connection.getResponseCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException
/*    */   {
/* 53 */     return this.connection.getResponseMessage();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 58 */     if (this.headers == null) {
/* 59 */       this.headers = new HttpHeaders();
/*    */ 
/* 61 */       String name = this.connection.getHeaderFieldKey(0);
/* 62 */       if (StringUtils.hasLength(name)) {
/* 63 */         this.headers.add(name, this.connection.getHeaderField(0));
/*    */       }
/* 65 */       int i = 1;
/*    */       while (true) {
/* 67 */         name = this.connection.getHeaderFieldKey(i);
/* 68 */         if (!StringUtils.hasLength(name)) {
/*    */           break;
/*    */         }
/* 71 */         this.headers.add(name, this.connection.getHeaderField(i));
/* 72 */         i++;
/*    */       }
/*    */     }
/* 75 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException
/*    */   {
/* 80 */     InputStream errorStream = this.connection.getErrorStream();
/* 81 */     return errorStream != null ? errorStream : this.connection.getInputStream();
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/* 86 */     this.connection.disconnect();
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleClientHttpResponse
 * JD-Core Version:    0.6.2
 */