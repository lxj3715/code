/*    */ package org.springframework.http.client.support;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.client.AsyncClientHttpRequest;
/*    */ import org.springframework.http.client.AsyncClientHttpRequestFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AsyncHttpAccessor
/*    */ {
/* 45 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   private AsyncClientHttpRequestFactory asyncRequestFactory;
/*    */ 
/*    */   public void setAsyncRequestFactory(AsyncClientHttpRequestFactory asyncRequestFactory)
/*    */   {
/* 54 */     Assert.notNull(asyncRequestFactory, "'asyncRequestFactory' must not be null");
/* 55 */     this.asyncRequestFactory = asyncRequestFactory;
/*    */   }
/*    */ 
/*    */   public AsyncClientHttpRequestFactory getAsyncRequestFactory()
/*    */   {
/* 63 */     return this.asyncRequestFactory;
/*    */   }
/*    */ 
/*    */   protected AsyncClientHttpRequest createAsyncRequest(URI url, HttpMethod method)
/*    */     throws IOException
/*    */   {
/* 76 */     AsyncClientHttpRequest request = getAsyncRequestFactory().createAsyncRequest(url, method);
/* 77 */     if (this.logger.isDebugEnabled()) {
/* 78 */       this.logger.debug("Created asynchronous " + method.name() + " request for \"" + url + "\"");
/*    */     }
/* 80 */     return request;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.support.AsyncHttpAccessor
 * JD-Core Version:    0.6.2
 */