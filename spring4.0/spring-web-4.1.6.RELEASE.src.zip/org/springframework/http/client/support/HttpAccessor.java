/*    */ package org.springframework.http.client.support;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.client.ClientHttpRequest;
/*    */ import org.springframework.http.client.ClientHttpRequestFactory;
/*    */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class HttpAccessor
/*    */ {
/* 47 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/* 49 */   private ClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
/*    */ 
/*    */   public void setRequestFactory(ClientHttpRequestFactory requestFactory)
/*    */   {
/* 56 */     Assert.notNull(requestFactory, "'requestFactory' must not be null");
/* 57 */     this.requestFactory = requestFactory;
/*    */   }
/*    */ 
/*    */   public ClientHttpRequestFactory getRequestFactory()
/*    */   {
/* 64 */     return this.requestFactory;
/*    */   }
/*    */ 
/*    */   protected ClientHttpRequest createRequest(URI url, HttpMethod method)
/*    */     throws IOException
/*    */   {
/* 76 */     ClientHttpRequest request = getRequestFactory().createRequest(url, method);
/* 77 */     if (this.logger.isDebugEnabled()) {
/* 78 */       this.logger.debug("Created " + method.name() + " request for \"" + url + "\"");
/*    */     }
/* 80 */     return request;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.support.HttpAccessor
 * JD-Core Version:    0.6.2
 */