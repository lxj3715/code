/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.http.StreamingHttpOutputMessage.Body;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractHttpMessageConverter<T>
/*     */   implements HttpMessageConverter<T>
/*     */ {
/*  50 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  52 */   private List<MediaType> supportedMediaTypes = Collections.emptyList();
/*     */ 
/*     */   protected AbstractHttpMessageConverter()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected AbstractHttpMessageConverter(MediaType supportedMediaType)
/*     */   {
/*  67 */     setSupportedMediaTypes(Collections.singletonList(supportedMediaType));
/*     */   }
/*     */ 
/*     */   protected AbstractHttpMessageConverter(MediaType[] supportedMediaTypes)
/*     */   {
/*  75 */     setSupportedMediaTypes(Arrays.asList(supportedMediaTypes));
/*     */   }
/*     */ 
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes)
/*     */   {
/*  83 */     Assert.notEmpty(supportedMediaTypes, "'supportedMediaTypes' must not be empty");
/*  84 */     this.supportedMediaTypes = new ArrayList(supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes()
/*     */   {
/*  89 */     return Collections.unmodifiableList(this.supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 100 */     return (supports(clazz)) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean canRead(MediaType mediaType)
/*     */   {
/* 112 */     if (mediaType == null) {
/* 113 */       return true;
/*     */     }
/* 115 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 116 */       if (supportedMediaType.includes(mediaType)) {
/* 117 */         return true;
/*     */       }
/*     */     }
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 130 */     return (supports(clazz)) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean canWrite(MediaType mediaType)
/*     */   {
/* 142 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 143 */       return true;
/*     */     }
/* 145 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 146 */       if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 147 */         return true;
/*     */       }
/*     */     }
/* 150 */     return false;
/*     */   }
/*     */ 
/*     */   public final T read(Class<? extends T> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException
/*     */   {
/* 159 */     return readInternal(clazz, inputMessage);
/*     */   }
/*     */ 
/*     */   public final void write(final T t, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 171 */     final HttpHeaders headers = outputMessage.getHeaders();
/* 172 */     if (headers.getContentType() == null) {
/* 173 */       MediaType contentTypeToUse = contentType;
/* 174 */       if ((contentType == null) || (contentType.isWildcardType()) || (contentType.isWildcardSubtype())) {
/* 175 */         contentTypeToUse = getDefaultContentType(t);
/*     */       }
/* 177 */       if (contentTypeToUse != null) {
/* 178 */         headers.setContentType(contentTypeToUse);
/*     */       }
/*     */     }
/* 181 */     if (headers.getContentLength() == -1L) {
/* 182 */       Long contentLength = getContentLength(t, headers.getContentType());
/* 183 */       if (contentLength != null) {
/* 184 */         headers.setContentLength(contentLength.longValue());
/*     */       }
/*     */     }
/*     */ 
/* 188 */     if ((outputMessage instanceof StreamingHttpOutputMessage)) {
/* 189 */       StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)outputMessage;
/*     */ 
/* 191 */       streamingOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*     */       {
/*     */         public void writeTo(final OutputStream outputStream) throws IOException {
/* 194 */           AbstractHttpMessageConverter.this.writeInternal(t, new HttpOutputMessage()
/*     */           {
/*     */             public OutputStream getBody() throws IOException {
/* 197 */               return outputStream;
/*     */             }
/*     */ 
/*     */             public HttpHeaders getHeaders() {
/* 201 */               return AbstractHttpMessageConverter.1.this.val$headers;
/*     */             }
/*     */           });
/*     */         }
/*     */       });
/*     */     }
/*     */     else {
/* 208 */       writeInternal(t, outputMessage);
/* 209 */       outputMessage.getBody().flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected MediaType getDefaultContentType(T t)
/*     */     throws IOException
/*     */   {
/* 223 */     List mediaTypes = getSupportedMediaTypes();
/* 224 */     return !mediaTypes.isEmpty() ? (MediaType)mediaTypes.get(0) : null;
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(T t, MediaType contentType)
/*     */     throws IOException
/*     */   {
/* 235 */     return null;
/*     */   }
/*     */ 
/*     */   protected abstract boolean supports(Class<?> paramClass);
/*     */ 
/*     */   protected abstract T readInternal(Class<? extends T> paramClass, HttpInputMessage paramHttpInputMessage)
/*     */     throws IOException, HttpMessageNotReadableException;
/*     */ 
/*     */   protected abstract void writeInternal(T paramT, HttpOutputMessage paramHttpOutputMessage)
/*     */     throws IOException, HttpMessageNotWritableException;
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.AbstractHttpMessageConverter
 * JD-Core Version:    0.6.2
 */