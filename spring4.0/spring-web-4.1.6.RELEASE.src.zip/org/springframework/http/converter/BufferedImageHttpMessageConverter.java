/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.stream.FileCacheImageInputStream;
/*     */ import javax.imageio.stream.FileCacheImageOutputStream;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageOutputStream;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class BufferedImageHttpMessageConverter
/*     */   implements HttpMessageConverter<BufferedImage>
/*     */ {
/*  69 */   private final List<MediaType> readableMediaTypes = new ArrayList();
/*     */   private MediaType defaultContentType;
/*     */   private File cacheDir;
/*     */ 
/*     */   public BufferedImageHttpMessageConverter()
/*     */   {
/*  77 */     String[] readerMediaTypes = ImageIO.getReaderMIMETypes();
/*  78 */     String[] arrayOfString1 = readerMediaTypes; int i = arrayOfString1.length; for (String str1 = 0; str1 < i; str1++) { mediaType = arrayOfString1[str1];
/*  79 */       if (StringUtils.hasText(mediaType)) {
/*  80 */         this.readableMediaTypes.add(MediaType.parseMediaType(mediaType));
/*     */       }
/*     */     }
/*     */ 
/*  84 */     String[] writerMediaTypes = ImageIO.getWriterMIMETypes();
/*  85 */     String[] arrayOfString2 = writerMediaTypes; str1 = arrayOfString2.length; for (String mediaType = 0; mediaType < str1; mediaType++) { String mediaType = arrayOfString2[mediaType];
/*  86 */       if (StringUtils.hasText(mediaType)) {
/*  87 */         this.defaultContentType = MediaType.parseMediaType(mediaType);
/*  88 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDefaultContentType(MediaType defaultContentType)
/*     */   {
/*  99 */     Assert.notNull(defaultContentType, "'contentType' must not be null");
/* 100 */     Iterator imageWriters = ImageIO.getImageWritersByMIMEType(defaultContentType.toString());
/* 101 */     if (!imageWriters.hasNext()) {
/* 102 */       throw new IllegalArgumentException("Content-Type [" + defaultContentType + "] is not supported by the Java Image I/O API");
/*     */     }
/*     */ 
/* 106 */     this.defaultContentType = defaultContentType;
/*     */   }
/*     */ 
/*     */   public MediaType getDefaultContentType()
/*     */   {
/* 114 */     return this.defaultContentType;
/*     */   }
/*     */ 
/*     */   public void setCacheDir(File cacheDir)
/*     */   {
/* 122 */     Assert.notNull(cacheDir, "'cacheDir' must not be null");
/* 123 */     Assert.isTrue(cacheDir.isDirectory(), "'cacheDir' is not a directory");
/* 124 */     this.cacheDir = cacheDir;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 130 */     return (BufferedImage.class.equals(clazz)) && (isReadable(mediaType));
/*     */   }
/*     */ 
/*     */   private boolean isReadable(MediaType mediaType) {
/* 134 */     if (mediaType == null) {
/* 135 */       return true;
/*     */     }
/* 137 */     Iterator imageReaders = ImageIO.getImageReadersByMIMEType(mediaType.toString());
/* 138 */     return imageReaders.hasNext();
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 143 */     return (BufferedImage.class.equals(clazz)) && (isWritable(mediaType));
/*     */   }
/*     */ 
/*     */   private boolean isWritable(MediaType mediaType) {
/* 147 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 148 */       return true;
/*     */     }
/* 150 */     Iterator imageWriters = ImageIO.getImageWritersByMIMEType(mediaType.toString());
/* 151 */     return imageWriters.hasNext();
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes()
/*     */   {
/* 156 */     return Collections.unmodifiableList(this.readableMediaTypes);
/*     */   }
/*     */ 
/*     */   public BufferedImage read(Class<? extends BufferedImage> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 163 */     ImageInputStream imageInputStream = null;
/* 164 */     ImageReader imageReader = null;
/*     */     try {
/* 166 */       imageInputStream = createImageInputStream(inputMessage.getBody());
/* 167 */       MediaType contentType = inputMessage.getHeaders().getContentType();
/* 168 */       Iterator imageReaders = ImageIO.getImageReadersByMIMEType(contentType.toString());
/* 169 */       if (imageReaders.hasNext()) {
/* 170 */         imageReader = (ImageReader)imageReaders.next();
/* 171 */         ImageReadParam irp = imageReader.getDefaultReadParam();
/* 172 */         process(irp);
/* 173 */         imageReader.setInput(imageInputStream, true);
/* 174 */         return imageReader.read(0, irp);
/*     */       }
/*     */ 
/* 177 */       throw new HttpMessageNotReadableException("Could not find javax.imageio.ImageReader for Content-Type [" + contentType + "]");
/*     */     }
/*     */     finally
/*     */     {
/* 182 */       if (imageReader != null) {
/* 183 */         imageReader.dispose();
/*     */       }
/* 185 */       if (imageInputStream != null)
/*     */         try {
/* 187 */           imageInputStream.close();
/*     */         }
/*     */         catch (IOException localIOException1)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private ImageInputStream createImageInputStream(InputStream is) throws IOException
/*     */   {
/* 197 */     if (this.cacheDir != null) {
/* 198 */       return new FileCacheImageInputStream(is, this.cacheDir);
/*     */     }
/*     */ 
/* 201 */     return new MemoryCacheImageInputStream(is);
/*     */   }
/*     */ 
/*     */   public void write(BufferedImage image, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 209 */     if ((contentType == null) || (contentType.isWildcardType()) || (contentType.isWildcardSubtype())) {
/* 210 */       contentType = getDefaultContentType();
/*     */     }
/* 212 */     Assert.notNull(contentType, "Count not determine Content-Type, set one using the 'defaultContentType' property");
/*     */ 
/* 214 */     outputMessage.getHeaders().setContentType(contentType);
/* 215 */     ImageOutputStream imageOutputStream = null;
/* 216 */     ImageWriter imageWriter = null;
/*     */     try {
/* 218 */       imageOutputStream = createImageOutputStream(outputMessage.getBody());
/* 219 */       Iterator imageWriters = ImageIO.getImageWritersByMIMEType(contentType.toString());
/* 220 */       if (imageWriters.hasNext()) {
/* 221 */         imageWriter = (ImageWriter)imageWriters.next();
/* 222 */         ImageWriteParam iwp = imageWriter.getDefaultWriteParam();
/* 223 */         process(iwp);
/* 224 */         imageWriter.setOutput(imageOutputStream);
/* 225 */         imageWriter.write(null, new IIOImage(image, null, null), iwp);
/*     */       }
/*     */       else {
/* 228 */         throw new HttpMessageNotWritableException("Could not find javax.imageio.ImageWriter for Content-Type [" + contentType + "]");
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 233 */       if (imageWriter != null) {
/* 234 */         imageWriter.dispose();
/*     */       }
/* 236 */       if (imageOutputStream != null)
/*     */         try {
/* 238 */           imageOutputStream.close();
/*     */         }
/*     */         catch (IOException localIOException1)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private ImageOutputStream createImageOutputStream(OutputStream os) throws IOException
/*     */   {
/* 248 */     if (this.cacheDir != null) {
/* 249 */       return new FileCacheImageOutputStream(os, this.cacheDir);
/*     */     }
/*     */ 
/* 252 */     return new MemoryCacheImageOutputStream(os);
/*     */   }
/*     */ 
/*     */   protected void process(ImageReadParam irp)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void process(ImageWriteParam iwp)
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.BufferedImageHttpMessageConverter
 * JD-Core Version:    0.6.2
 */