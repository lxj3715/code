/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class FormHttpMessageConverter
/*     */   implements HttpMessageConverter<MultiValueMap<String, ?>>
/*     */ {
/*  89 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */ 
/*  91 */   private static final byte[] BOUNDARY_CHARS = { 45, 95, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90 };
/*     */ 
/*  98 */   private Charset charset = DEFAULT_CHARSET;
/*     */   private Charset multipartCharset;
/* 102 */   private List<MediaType> supportedMediaTypes = new ArrayList();
/*     */ 
/* 104 */   private List<HttpMessageConverter<?>> partConverters = new ArrayList();
/*     */ 
/* 106 */   private final Random random = new Random();
/*     */ 
/*     */   public FormHttpMessageConverter()
/*     */   {
/* 110 */     this.supportedMediaTypes.add(MediaType.APPLICATION_FORM_URLENCODED);
/* 111 */     this.supportedMediaTypes.add(MediaType.MULTIPART_FORM_DATA);
/*     */ 
/* 113 */     this.partConverters.add(new ByteArrayHttpMessageConverter());
/* 114 */     StringHttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter();
/* 115 */     stringHttpMessageConverter.setWriteAcceptCharset(false);
/* 116 */     this.partConverters.add(stringHttpMessageConverter);
/* 117 */     this.partConverters.add(new ResourceHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public void setCharset(Charset charset)
/*     */   {
/* 127 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   public void setMultipartCharset(Charset multipartCharset)
/*     */   {
/* 140 */     this.multipartCharset = multipartCharset;
/*     */   }
/*     */ 
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes)
/*     */   {
/* 147 */     this.supportedMediaTypes = supportedMediaTypes;
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes()
/*     */   {
/* 152 */     return Collections.unmodifiableList(this.supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public void setPartConverters(List<HttpMessageConverter<?>> partConverters)
/*     */   {
/* 160 */     Assert.notEmpty(partConverters, "'partConverters' must not be empty");
/* 161 */     this.partConverters = partConverters;
/*     */   }
/*     */ 
/*     */   public void addPartConverter(HttpMessageConverter<?> partConverter)
/*     */   {
/* 169 */     Assert.notNull(partConverter, "'partConverter' must not be null");
/* 170 */     this.partConverters.add(partConverter);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 176 */     if (!MultiValueMap.class.isAssignableFrom(clazz)) {
/* 177 */       return false;
/*     */     }
/* 179 */     if (mediaType == null) {
/* 180 */       return true;
/*     */     }
/* 182 */     for (MediaType supportedMediaType : getSupportedMediaTypes())
/*     */     {
/* 184 */       if ((!supportedMediaType.equals(MediaType.MULTIPART_FORM_DATA)) && (supportedMediaType.includes(mediaType))) {
/* 185 */         return true;
/*     */       }
/*     */     }
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 193 */     if (!MultiValueMap.class.isAssignableFrom(clazz)) {
/* 194 */       return false;
/*     */     }
/* 196 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 197 */       return true;
/*     */     }
/* 199 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 200 */       if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 201 */         return true;
/*     */       }
/*     */     }
/* 204 */     return false;
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, String> read(Class<? extends MultiValueMap<String, ?>> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 211 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/* 212 */     Charset charset = contentType.getCharSet() != null ? contentType.getCharSet() : this.charset;
/* 213 */     String body = StreamUtils.copyToString(inputMessage.getBody(), charset);
/*     */ 
/* 215 */     String[] pairs = StringUtils.tokenizeToStringArray(body, "&");
/* 216 */     MultiValueMap result = new LinkedMultiValueMap(pairs.length);
/* 217 */     for (String pair : pairs) {
/* 218 */       int idx = pair.indexOf(61);
/* 219 */       if (idx == -1) {
/* 220 */         result.add(URLDecoder.decode(pair, charset.name()), null);
/*     */       }
/*     */       else {
/* 223 */         String name = URLDecoder.decode(pair.substring(0, idx), charset.name());
/* 224 */         String value = URLDecoder.decode(pair.substring(idx + 1), charset.name());
/* 225 */         result.add(name, value);
/*     */       }
/*     */     }
/* 228 */     return result;
/*     */   }
/*     */ 
/*     */   public void write(MultiValueMap<String, ?> map, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 236 */     if (!isMultipart(map, contentType)) {
/* 237 */       writeForm(map, contentType, outputMessage);
/*     */     }
/*     */     else
/* 240 */       writeMultipart(map, outputMessage);
/*     */   }
/*     */ 
/*     */   private boolean isMultipart(MultiValueMap<String, ?> map, MediaType contentType)
/*     */   {
/* 246 */     if (contentType != null) {
/* 247 */       return MediaType.MULTIPART_FORM_DATA.includes(contentType);
/*     */     }
/* 249 */     for (String name : map.keySet())
/* 250 */       for (localIterator2 = ((List)map.get(name)).iterator(); localIterator2.hasNext(); ) { Object value = localIterator2.next();
/* 251 */         if ((value != null) && (!(value instanceof String)))
/* 252 */           return true;
/*     */       }
/*     */     Iterator localIterator2;
/* 256 */     return false;
/*     */   }
/*     */ 
/*     */   private void writeForm(MultiValueMap<String, String> form, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException
/*     */   {
/*     */     Charset charset;
/*     */     Charset charset;
/* 263 */     if (contentType != null) {
/* 264 */       outputMessage.getHeaders().setContentType(contentType);
/* 265 */       charset = contentType.getCharSet() != null ? contentType.getCharSet() : this.charset;
/*     */     }
/*     */     else {
/* 268 */       outputMessage.getHeaders().setContentType(MediaType.APPLICATION_FORM_URLENCODED);
/* 269 */       charset = this.charset;
/*     */     }
/* 271 */     StringBuilder builder = new StringBuilder();
/* 272 */     for (Iterator nameIterator = form.keySet().iterator(); nameIterator.hasNext(); ) {
/* 273 */       String name = (String)nameIterator.next();
/* 274 */       for (Iterator valueIterator = ((List)form.get(name)).iterator(); valueIterator.hasNext(); ) {
/* 275 */         String value = (String)valueIterator.next();
/* 276 */         builder.append(URLEncoder.encode(name, charset.name()));
/* 277 */         if (value != null) {
/* 278 */           builder.append('=');
/* 279 */           builder.append(URLEncoder.encode(value, charset.name()));
/* 280 */           if (valueIterator.hasNext()) {
/* 281 */             builder.append('&');
/*     */           }
/*     */         }
/*     */       }
/* 285 */       if (nameIterator.hasNext()) {
/* 286 */         builder.append('&');
/*     */       }
/*     */     }
/* 289 */     byte[] bytes = builder.toString().getBytes(charset.name());
/* 290 */     outputMessage.getHeaders().setContentLength(bytes.length);
/* 291 */     StreamUtils.copy(bytes, outputMessage.getBody());
/*     */   }
/*     */ 
/*     */   private void writeMultipart(MultiValueMap<String, Object> parts, HttpOutputMessage outputMessage) throws IOException {
/* 295 */     byte[] boundary = generateMultipartBoundary();
/* 296 */     Map parameters = Collections.singletonMap("boundary", new String(boundary, "US-ASCII"));
/*     */ 
/* 298 */     MediaType contentType = new MediaType(MediaType.MULTIPART_FORM_DATA, parameters);
/* 299 */     outputMessage.getHeaders().setContentType(contentType);
/*     */ 
/* 301 */     writeParts(outputMessage.getBody(), parts, boundary);
/* 302 */     writeEnd(outputMessage.getBody(), boundary);
/*     */   }
/*     */ 
/*     */   private void writeParts(OutputStream os, MultiValueMap<String, Object> parts, byte[] boundary) throws IOException {
/* 306 */     for (Map.Entry entry : parts.entrySet()) {
/* 307 */       name = (String)entry.getKey();
/* 308 */       for (localIterator2 = ((List)entry.getValue()).iterator(); localIterator2.hasNext(); ) { Object part = localIterator2.next();
/* 309 */         if (part != null) {
/* 310 */           writeBoundary(os, boundary);
/* 311 */           writePart(name, getHttpEntity(part), os);
/* 312 */           writeNewLine(os);
/*     */         } } 
/*     */     }
/*     */     String name;
/*     */     Iterator localIterator2;
/*     */   }
/*     */ 
/*     */   private void writePart(String name, HttpEntity<?> partEntity, OutputStream os) throws IOException {
/* 320 */     Object partBody = partEntity.getBody();
/* 321 */     Class partType = partBody.getClass();
/* 322 */     HttpHeaders partHeaders = partEntity.getHeaders();
/* 323 */     MediaType partContentType = partHeaders.getContentType();
/* 324 */     for (HttpMessageConverter messageConverter : this.partConverters) {
/* 325 */       if (messageConverter.canWrite(partType, partContentType)) {
/* 326 */         HttpOutputMessage multipartMessage = new MultipartHttpOutputMessage(os);
/* 327 */         multipartMessage.getHeaders().setContentDispositionFormData(name, getFilename(partBody));
/* 328 */         if (!partHeaders.isEmpty()) {
/* 329 */           multipartMessage.getHeaders().putAll(partHeaders);
/*     */         }
/* 331 */         messageConverter.write(partBody, partContentType, multipartMessage);
/* 332 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 336 */     throw new HttpMessageNotWritableException(new StringBuilder().append("Could not write request: no suitable HttpMessageConverter found for request type [")
/* 336 */       .append(partType
/* 336 */       .getName()).append("]").toString());
/*     */   }
/*     */ 
/*     */   protected byte[] generateMultipartBoundary()
/*     */   {
/* 346 */     byte[] boundary = new byte[this.random.nextInt(11) + 30];
/* 347 */     for (int i = 0; i < boundary.length; i++) {
/* 348 */       boundary[i] = BOUNDARY_CHARS[this.random.nextInt(BOUNDARY_CHARS.length)];
/*     */     }
/* 350 */     return boundary;
/*     */   }
/*     */ 
/*     */   protected HttpEntity<?> getHttpEntity(Object part)
/*     */   {
/* 360 */     if ((part instanceof HttpEntity)) {
/* 361 */       return (HttpEntity)part;
/*     */     }
/*     */ 
/* 364 */     return new HttpEntity(part);
/*     */   }
/*     */ 
/*     */   protected String getFilename(Object part)
/*     */   {
/* 377 */     if ((part instanceof Resource)) {
/* 378 */       Resource resource = (Resource)part;
/* 379 */       String filename = resource.getFilename();
/* 380 */       if (this.multipartCharset != null) {
/* 381 */         filename = MimeDelegate.encode(filename, this.multipartCharset.name());
/*     */       }
/* 383 */       return filename;
/*     */     }
/*     */ 
/* 386 */     return null;
/*     */   }
/*     */ 
/*     */   private void writeBoundary(OutputStream os, byte[] boundary)
/*     */     throws IOException
/*     */   {
/* 392 */     os.write(45);
/* 393 */     os.write(45);
/* 394 */     os.write(boundary);
/* 395 */     writeNewLine(os);
/*     */   }
/*     */ 
/*     */   private static void writeEnd(OutputStream os, byte[] boundary) throws IOException {
/* 399 */     os.write(45);
/* 400 */     os.write(45);
/* 401 */     os.write(boundary);
/* 402 */     os.write(45);
/* 403 */     os.write(45);
/* 404 */     writeNewLine(os);
/*     */   }
/*     */ 
/*     */   private static void writeNewLine(OutputStream os) throws IOException {
/* 408 */     os.write(13);
/* 409 */     os.write(10);
/*     */   }
/*     */ 
/*     */   private static class MimeDelegate
/*     */   {
/*     */     public static String encode(String value, String charset)
/*     */     {
/*     */       try
/*     */       {
/* 477 */         return MimeUtility.encodeText(value, charset, null);
/*     */       }
/*     */       catch (UnsupportedEncodingException ex) {
/* 480 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MultipartHttpOutputMessage
/*     */     implements HttpOutputMessage
/*     */   {
/*     */     private final OutputStream outputStream;
/* 421 */     private final HttpHeaders headers = new HttpHeaders();
/*     */ 
/* 423 */     private boolean headersWritten = false;
/*     */ 
/*     */     public MultipartHttpOutputMessage(OutputStream outputStream) {
/* 426 */       this.outputStream = outputStream;
/*     */     }
/*     */ 
/*     */     public HttpHeaders getHeaders()
/*     */     {
/* 431 */       return this.headersWritten ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*     */     }
/*     */ 
/*     */     public OutputStream getBody() throws IOException
/*     */     {
/* 436 */       writeHeaders();
/* 437 */       return this.outputStream;
/*     */     }
/*     */ 
/*     */     private void writeHeaders() throws IOException {
/* 441 */       if (!this.headersWritten) {
/* 442 */         for (Map.Entry entry : this.headers.entrySet()) {
/* 443 */           headerName = getAsciiBytes((String)entry.getKey());
/* 444 */           for (String headerValueString : (List)entry.getValue()) {
/* 445 */             byte[] headerValue = getAsciiBytes(headerValueString);
/* 446 */             this.outputStream.write(headerName);
/* 447 */             this.outputStream.write(58);
/* 448 */             this.outputStream.write(32);
/* 449 */             this.outputStream.write(headerValue);
/* 450 */             FormHttpMessageConverter.writeNewLine(this.outputStream);
/*     */           }
/*     */         }
/*     */         byte[] headerName;
/* 453 */         FormHttpMessageConverter.writeNewLine(this.outputStream);
/* 454 */         this.headersWritten = true;
/*     */       }
/*     */     }
/*     */ 
/*     */     private byte[] getAsciiBytes(String name) {
/*     */       try {
/* 460 */         return name.getBytes("US-ASCII");
/*     */       }
/*     */       catch (UnsupportedEncodingException ex)
/*     */       {
/* 464 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.FormHttpMessageConverter
 * JD-Core Version:    0.6.2
 */