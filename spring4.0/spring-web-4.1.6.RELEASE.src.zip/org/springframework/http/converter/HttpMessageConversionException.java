/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class HttpMessageConversionException extends NestedRuntimeException
/*    */ {
/*    */   public HttpMessageConversionException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ 
/*    */   public HttpMessageConversionException(String msg, Throwable cause)
/*    */   {
/* 44 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.HttpMessageConversionException
 * JD-Core Version:    0.6.2
 */