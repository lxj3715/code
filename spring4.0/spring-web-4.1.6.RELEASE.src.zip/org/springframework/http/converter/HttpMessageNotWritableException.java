/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ public class HttpMessageNotWritableException extends HttpMessageConversionException
/*    */ {
/*    */   public HttpMessageNotWritableException(String msg)
/*    */   {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */   public HttpMessageNotWritableException(String msg, Throwable cause)
/*    */   {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.HttpMessageNotWritableException
 * JD-Core Version:    0.6.2
 */