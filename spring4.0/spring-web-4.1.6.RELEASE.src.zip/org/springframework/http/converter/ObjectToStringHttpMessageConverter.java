/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ObjectToStringHttpMessageConverter extends AbstractHttpMessageConverter<Object>
/*     */ {
/*     */   private ConversionService conversionService;
/*     */   private StringHttpMessageConverter stringHttpMessageConverter;
/*     */ 
/*     */   public ObjectToStringHttpMessageConverter(ConversionService conversionService)
/*     */   {
/*  66 */     this(conversionService, StringHttpMessageConverter.DEFAULT_CHARSET);
/*     */   }
/*     */ 
/*     */   public ObjectToStringHttpMessageConverter(ConversionService conversionService, Charset defaultCharset)
/*     */   {
/*  77 */     super(new MediaType("text", "plain", defaultCharset));
/*     */ 
/*  79 */     Assert.notNull(conversionService, "conversionService is required");
/*  80 */     this.conversionService = conversionService;
/*  81 */     this.stringHttpMessageConverter = new StringHttpMessageConverter(defaultCharset);
/*     */   }
/*     */ 
/*     */   public void setWriteAcceptCharset(boolean writeAcceptCharset)
/*     */   {
/*  89 */     this.stringHttpMessageConverter.setWriteAcceptCharset(writeAcceptCharset);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  94 */     return (this.conversionService.canConvert(String.class, clazz)) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  99 */     return (this.conversionService.canConvert(clazz, String.class)) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 105 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readInternal(Class<? extends Object> clazz, HttpInputMessage inputMessage) throws IOException
/*     */   {
/* 110 */     String value = this.stringHttpMessageConverter.readInternal(String.class, inputMessage);
/* 111 */     return this.conversionService.convert(value, clazz);
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Object obj, HttpOutputMessage outputMessage) throws IOException
/*     */   {
/* 116 */     String s = (String)this.conversionService.convert(obj, String.class);
/* 117 */     this.stringHttpMessageConverter.writeInternal(s, outputMessage);
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(Object obj, MediaType contentType)
/*     */   {
/* 122 */     String value = (String)this.conversionService.convert(obj, String.class);
/* 123 */     return this.stringHttpMessageConverter.getContentLength(value, contentType);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.ObjectToStringHttpMessageConverter
 * JD-Core Version:    0.6.2
 */