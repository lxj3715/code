/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.SortedMap;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ public class StringHttpMessageConverter extends AbstractHttpMessageConverter<String>
/*     */ {
/*  42 */   public static final Charset DEFAULT_CHARSET = Charset.forName("ISO-8859-1");
/*     */   private final Charset defaultCharset;
/*     */   private final List<Charset> availableCharsets;
/*  49 */   private boolean writeAcceptCharset = true;
/*     */ 
/*     */   public StringHttpMessageConverter()
/*     */   {
/*  57 */     this(DEFAULT_CHARSET);
/*     */   }
/*     */ 
/*     */   public StringHttpMessageConverter(Charset defaultCharset)
/*     */   {
/*  65 */     super(new MediaType[] { new MediaType("text", "plain", defaultCharset), MediaType.ALL });
/*  66 */     this.defaultCharset = defaultCharset;
/*  67 */     this.availableCharsets = new ArrayList(Charset.availableCharsets().values());
/*     */   }
/*     */ 
/*     */   public void setWriteAcceptCharset(boolean writeAcceptCharset)
/*     */   {
/*  76 */     this.writeAcceptCharset = writeAcceptCharset;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/*  82 */     return String.class.equals(clazz);
/*     */   }
/*     */ 
/*     */   protected String readInternal(Class<? extends String> clazz, HttpInputMessage inputMessage) throws IOException
/*     */   {
/*  87 */     Charset charset = getContentTypeCharset(inputMessage.getHeaders().getContentType());
/*  88 */     return StreamUtils.copyToString(inputMessage.getBody(), charset);
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(String str, MediaType contentType)
/*     */   {
/*  93 */     Charset charset = getContentTypeCharset(contentType);
/*     */     try {
/*  95 */       return Long.valueOf(str.getBytes(charset.name()).length);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/*  99 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeInternal(String str, HttpOutputMessage outputMessage) throws IOException
/*     */   {
/* 105 */     if (this.writeAcceptCharset) {
/* 106 */       outputMessage.getHeaders().setAcceptCharset(getAcceptedCharsets());
/*     */     }
/* 108 */     Charset charset = getContentTypeCharset(outputMessage.getHeaders().getContentType());
/* 109 */     StreamUtils.copy(str, charset, outputMessage.getBody());
/*     */   }
/*     */ 
/*     */   protected List<Charset> getAcceptedCharsets()
/*     */   {
/* 120 */     return this.availableCharsets;
/*     */   }
/*     */ 
/*     */   private Charset getContentTypeCharset(MediaType contentType) {
/* 124 */     if ((contentType != null) && (contentType.getCharSet() != null)) {
/* 125 */       return contentType.getCharSet();
/*     */     }
/*     */ 
/* 128 */     return this.defaultCharset;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.StringHttpMessageConverter
 * JD-Core Version:    0.6.2
 */