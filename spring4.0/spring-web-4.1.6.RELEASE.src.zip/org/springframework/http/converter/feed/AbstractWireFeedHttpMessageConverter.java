/*    */ package org.springframework.http.converter.feed;
/*    */ 
/*    */ import com.rometools.rome.feed.WireFeed;
/*    */ import com.rometools.rome.io.FeedException;
/*    */ import com.rometools.rome.io.WireFeedInput;
/*    */ import com.rometools.rome.io.WireFeedOutput;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.Writer;
/*    */ import java.nio.charset.Charset;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpInputMessage;
/*    */ import org.springframework.http.HttpOutputMessage;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*    */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*    */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public abstract class AbstractWireFeedHttpMessageConverter<T extends WireFeed> extends AbstractHttpMessageConverter<T>
/*    */ {
/* 53 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*    */ 
/*    */   protected AbstractWireFeedHttpMessageConverter(MediaType supportedMediaType)
/*    */   {
/* 57 */     super(supportedMediaType);
/*    */   }
/*    */ 
/*    */   protected T readInternal(Class<? extends T> clazz, HttpInputMessage inputMessage)
/*    */     throws IOException, HttpMessageNotReadableException
/*    */   {
/* 66 */     WireFeedInput feedInput = new WireFeedInput();
/* 67 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/*    */ 
/* 69 */     Charset charset = (contentType != null) && 
/* 69 */       (contentType
/* 69 */       .getCharSet() != null) ? contentType.getCharSet() : DEFAULT_CHARSET;
/*    */     try {
/* 71 */       Reader reader = new InputStreamReader(inputMessage.getBody(), charset);
/* 72 */       return feedInput.build(reader);
/*    */     }
/*    */     catch (FeedException ex) {
/* 75 */       throw new HttpMessageNotReadableException("Could not read WireFeed: " + ex.getMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void writeInternal(T wireFeed, HttpOutputMessage outputMessage)
/*    */     throws IOException, HttpMessageNotWritableException
/*    */   {
/* 83 */     String wireFeedEncoding = wireFeed.getEncoding();
/* 84 */     if (!StringUtils.hasLength(wireFeedEncoding)) {
/* 85 */       wireFeedEncoding = DEFAULT_CHARSET.name();
/*    */     }
/* 87 */     MediaType contentType = outputMessage.getHeaders().getContentType();
/* 88 */     if (contentType != null) {
/* 89 */       Charset wireFeedCharset = Charset.forName(wireFeedEncoding);
/* 90 */       contentType = new MediaType(contentType.getType(), contentType.getSubtype(), wireFeedCharset);
/* 91 */       outputMessage.getHeaders().setContentType(contentType);
/*    */     }
/*    */ 
/* 94 */     WireFeedOutput feedOutput = new WireFeedOutput();
/*    */     try {
/* 96 */       Writer writer = new OutputStreamWriter(outputMessage.getBody(), wireFeedEncoding);
/* 97 */       feedOutput.output(wireFeed, writer);
/*    */     }
/*    */     catch (FeedException ex) {
/* 100 */       throw new HttpMessageNotWritableException("Could not write WireFeed: " + ex.getMessage(), ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.feed.AbstractWireFeedHttpMessageConverter
 * JD-Core Version:    0.6.2
 */