/*    */ package org.springframework.http.converter.feed;
/*    */ 
/*    */ import com.rometools.rome.feed.atom.Feed;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ public class AtomFeedHttpMessageConverter extends AbstractWireFeedHttpMessageConverter<Feed>
/*    */ {
/*    */   public AtomFeedHttpMessageConverter()
/*    */   {
/* 41 */     super(new MediaType("application", "atom+xml"));
/*    */   }
/*    */ 
/*    */   protected boolean supports(Class<?> clazz)
/*    */   {
/* 46 */     return Feed.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.feed.AtomFeedHttpMessageConverter
 * JD-Core Version:    0.6.2
 */