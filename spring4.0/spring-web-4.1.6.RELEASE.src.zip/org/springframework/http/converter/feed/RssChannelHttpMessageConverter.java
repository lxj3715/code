/*    */ package org.springframework.http.converter.feed;
/*    */ 
/*    */ import com.rometools.rome.feed.rss.Channel;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ public class RssChannelHttpMessageConverter extends AbstractWireFeedHttpMessageConverter<Channel>
/*    */ {
/*    */   public RssChannelHttpMessageConverter()
/*    */   {
/* 41 */     super(new MediaType("application", "rss+xml"));
/*    */   }
/*    */ 
/*    */   protected boolean supports(Class<?> clazz)
/*    */   {
/* 46 */     return Channel.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.feed.RssChannelHttpMessageConverter
 * JD-Core Version:    0.6.2
 */