/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public abstract class AbstractJackson2HttpMessageConverter extends AbstractHttpMessageConverter<Object>
/*     */   implements GenericHttpMessageConverter<Object>
/*     */ {
/*  59 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */ 
/*  62 */   private static final boolean jackson23Available = ClassUtils.hasMethod(ObjectMapper.class, "canDeserialize", new Class[] { JavaType.class, AtomicReference.class });
/*     */   protected ObjectMapper objectMapper;
/*     */   private Boolean prettyPrint;
/*     */ 
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper)
/*     */   {
/*  72 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper, MediaType supportedMediaType) {
/*  76 */     super(supportedMediaType);
/*  77 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper, MediaType[] supportedMediaTypes) {
/*  81 */     super(supportedMediaTypes);
/*  82 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/*  98 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/*  99 */     this.objectMapper = objectMapper;
/* 100 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObjectMapper()
/*     */   {
/* 107 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 120 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 121 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   private void configurePrettyPrint() {
/* 125 */     if (this.prettyPrint != null)
/* 126 */       this.objectMapper.configure(SerializationFeature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 133 */     return canRead(clazz, null, mediaType);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/* 138 */     JavaType javaType = getJavaType(type, contextClass);
/* 139 */     if ((!jackson23Available) || (!this.logger.isWarnEnabled())) {
/* 140 */       return (this.objectMapper.canDeserialize(javaType)) && (canRead(mediaType));
/*     */     }
/* 142 */     AtomicReference causeRef = new AtomicReference();
/* 143 */     if ((this.objectMapper.canDeserialize(javaType, causeRef)) && (canRead(mediaType))) {
/* 144 */       return true;
/*     */     }
/* 146 */     Throwable cause = (Throwable)causeRef.get();
/* 147 */     if (cause != null) {
/* 148 */       String msg = "Failed to evaluate deserialization for type " + javaType;
/* 149 */       if (this.logger.isDebugEnabled()) {
/* 150 */         this.logger.warn(msg, cause);
/*     */       }
/*     */       else {
/* 153 */         this.logger.warn(msg + ": " + cause);
/*     */       }
/*     */     }
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 161 */     if ((!jackson23Available) || (!this.logger.isWarnEnabled())) {
/* 162 */       return (this.objectMapper.canSerialize(clazz)) && (canWrite(mediaType));
/*     */     }
/* 164 */     AtomicReference causeRef = new AtomicReference();
/* 165 */     if ((this.objectMapper.canSerialize(clazz, causeRef)) && (canWrite(mediaType))) {
/* 166 */       return true;
/*     */     }
/* 168 */     Throwable cause = (Throwable)causeRef.get();
/* 169 */     if (cause != null) {
/* 170 */       String msg = "Failed to evaluate serialization for type [" + clazz + "]";
/* 171 */       if (this.logger.isDebugEnabled()) {
/* 172 */         this.logger.warn(msg, cause);
/*     */       }
/*     */       else {
/* 175 */         this.logger.warn(msg + ": " + cause);
/*     */       }
/*     */     }
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 184 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 191 */     JavaType javaType = getJavaType(clazz, null);
/* 192 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 199 */     JavaType javaType = getJavaType(type, contextClass);
/* 200 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   private Object readJavaType(JavaType javaType, HttpInputMessage inputMessage) {
/*     */     try {
/* 205 */       return this.objectMapper.readValue(inputMessage.getBody(), javaType);
/*     */     }
/*     */     catch (IOException ex) {
/* 208 */       throw new HttpMessageNotReadableException("Could not read JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Object object, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 216 */     JsonEncoding encoding = getJsonEncoding(outputMessage.getHeaders().getContentType());
/* 217 */     JsonGenerator generator = this.objectMapper.getFactory().createGenerator(outputMessage.getBody(), encoding);
/*     */     try {
/* 219 */       writePrefix(generator, object);
/* 220 */       Class serializationView = null;
/* 221 */       Object value = object;
/* 222 */       if ((value instanceof MappingJacksonValue)) {
/* 223 */         MappingJacksonValue container = (MappingJacksonValue)object;
/* 224 */         value = container.getValue();
/* 225 */         serializationView = container.getSerializationView();
/*     */       }
/* 227 */       if (serializationView != null) {
/* 228 */         this.objectMapper.writerWithView(serializationView).writeValue(generator, value);
/*     */       }
/*     */       else {
/* 231 */         this.objectMapper.writeValue(generator, value);
/*     */       }
/* 233 */       writeSuffix(generator, object);
/* 234 */       generator.flush();
/*     */     }
/*     */     catch (JsonProcessingException ex)
/*     */     {
/* 238 */       throw new HttpMessageNotWritableException("Could not write content: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writePrefix(JsonGenerator generator, Object object)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void writeSuffix(JsonGenerator generator, Object object)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   protected JavaType getJavaType(Type type, Class<?> contextClass)
/*     */   {
/* 281 */     return this.objectMapper.getTypeFactory().constructType(type, contextClass);
/*     */   }
/*     */ 
/*     */   protected JsonEncoding getJsonEncoding(MediaType contentType)
/*     */   {
/* 290 */     if ((contentType != null) && (contentType.getCharSet() != null)) {
/* 291 */       Charset charset = contentType.getCharSet();
/* 292 */       for (JsonEncoding encoding : JsonEncoding.values()) {
/* 293 */         if (charset.name().equals(encoding.getJavaName())) {
/* 294 */           return encoding;
/*     */         }
/*     */       }
/*     */     }
/* 298 */     return JsonEncoding.UTF8;
/*     */   }
/*     */ 
/*     */   protected MediaType getDefaultContentType(Object object) throws IOException
/*     */   {
/* 303 */     if ((object instanceof MappingJacksonValue)) {
/* 304 */       object = ((MappingJacksonValue)object).getValue();
/*     */     }
/* 306 */     return super.getDefaultContentType(object);
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(Object object, MediaType contentType) throws IOException
/*     */   {
/* 311 */     if ((object instanceof MappingJacksonValue)) {
/* 312 */       object = ((MappingJacksonValue)object).getValue();
/*     */     }
/* 314 */     return super.getContentLength(object, contentType);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter
 * JD-Core Version:    0.6.2
 */