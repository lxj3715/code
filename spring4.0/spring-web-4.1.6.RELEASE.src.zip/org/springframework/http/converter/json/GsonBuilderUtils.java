/*    */ package org.springframework.http.converter.json;
/*    */ 
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonDeserializer;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonPrimitive;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import com.google.gson.JsonSerializer;
/*    */ import java.lang.reflect.Type;
/*    */ import org.springframework.util.Base64Utils;
/*    */ 
/*    */ public abstract class GsonBuilderUtils
/*    */ {
/*    */   public static GsonBuilder gsonBuilderWithBase64EncodedByteArrays()
/*    */   {
/* 56 */     Base64Utils.encode(null);
/*    */ 
/* 59 */     GsonBuilder builder = new GsonBuilder();
/* 60 */     builder.registerTypeHierarchyAdapter([B.class, new Base64TypeAdapter(null));
/* 61 */     return builder;
/*    */   }
/*    */ 
/*    */   private static class Base64TypeAdapter
/*    */     implements JsonSerializer<byte[]>, JsonDeserializer<byte[]>
/*    */   {
/*    */     public JsonElement serialize(byte[] src, Type typeOfSrc, JsonSerializationContext context)
/*    */     {
/* 69 */       return new JsonPrimitive(Base64Utils.encodeToString(src));
/*    */     }
/*    */ 
/*    */     public byte[] deserialize(JsonElement json, Type type, JsonDeserializationContext cxt)
/*    */     {
/* 74 */       return Base64Utils.decodeFromString(json.getAsString());
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.GsonBuilderUtils
 * JD-Core Version:    0.6.2
 */