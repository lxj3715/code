/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonIOException;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class GsonHttpMessageConverter extends AbstractHttpMessageConverter<Object>
/*     */   implements GenericHttpMessageConverter<Object>
/*     */ {
/*  60 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */ 
/*  63 */   private Gson gson = new Gson();
/*     */   private String jsonPrefix;
/*     */ 
/*     */   public GsonHttpMessageConverter()
/*     */   {
/*  72 */     super(new MediaType[] { new MediaType("application", "json", DEFAULT_CHARSET), new MediaType("application", "*+json", DEFAULT_CHARSET) });
/*     */   }
/*     */ 
/*     */   public void setGson(Gson gson)
/*     */   {
/*  84 */     Assert.notNull(gson, "'gson' is required");
/*  85 */     this.gson = gson;
/*     */   }
/*     */ 
/*     */   public Gson getGson()
/*     */   {
/*  92 */     return this.gson;
/*     */   }
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/* 100 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/* 114 */     this.jsonPrefix = (prefixJson ? "{} && " : null);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 120 */     return canRead(mediaType);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/* 125 */     return canRead(mediaType);
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 130 */     return canWrite(mediaType);
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 136 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 143 */     TypeToken token = getTypeToken(clazz);
/* 144 */     return readTypeToken(token, inputMessage);
/*     */   }
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 151 */     TypeToken token = getTypeToken(type);
/* 152 */     return readTypeToken(token, inputMessage);
/*     */   }
/*     */ 
/*     */   protected TypeToken<?> getTypeToken(Type type)
/*     */   {
/* 174 */     return TypeToken.get(type);
/*     */   }
/*     */ 
/*     */   private Object readTypeToken(TypeToken<?> token, HttpInputMessage inputMessage) throws IOException {
/* 178 */     Reader json = new InputStreamReader(inputMessage.getBody(), getCharset(inputMessage.getHeaders()));
/*     */     try {
/* 180 */       return this.gson.fromJson(json, token.getType());
/*     */     }
/*     */     catch (JsonParseException ex) {
/* 183 */       throw new HttpMessageNotReadableException("Could not read JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Charset getCharset(HttpHeaders headers) {
/* 188 */     if ((headers == null) || (headers.getContentType() == null) || (headers.getContentType().getCharSet() == null)) {
/* 189 */       return DEFAULT_CHARSET;
/*     */     }
/* 191 */     return headers.getContentType().getCharSet();
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Object o, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 198 */     Charset charset = getCharset(outputMessage.getHeaders());
/* 199 */     OutputStreamWriter writer = new OutputStreamWriter(outputMessage.getBody(), charset);
/*     */     try {
/* 201 */       if (this.jsonPrefix != null) {
/* 202 */         writer.append(this.jsonPrefix);
/*     */       }
/* 204 */       this.gson.toJson(o, writer);
/* 205 */       writer.close();
/*     */     }
/*     */     catch (JsonIOException ex) {
/* 208 */       throw new HttpMessageNotWritableException("Could not write JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.GsonHttpMessageConverter
 * JD-Core Version:    0.6.2
 */