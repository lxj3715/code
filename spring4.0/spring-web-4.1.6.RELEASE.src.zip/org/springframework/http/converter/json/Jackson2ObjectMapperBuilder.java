/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude.Include;
/*     */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*     */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class Jackson2ObjectMapperBuilder
/*     */ {
/*  78 */   private boolean createXmlMapper = false;
/*     */   private DateFormat dateFormat;
/*     */   private Locale locale;
/*     */   private TimeZone timeZone;
/*     */   private AnnotationIntrospector annotationIntrospector;
/*     */   private PropertyNamingStrategy propertyNamingStrategy;
/*     */   private JsonInclude.Include serializationInclusion;
/*  92 */   private final Map<Class<?>, JsonSerializer<?>> serializers = new LinkedHashMap();
/*     */ 
/*  94 */   private final Map<Class<?>, JsonDeserializer<?>> deserializers = new LinkedHashMap();
/*     */ 
/*  96 */   private final Map<Class<?>, Class<?>> mixIns = new HashMap();
/*     */ 
/*  98 */   private final Map<Object, Boolean> features = new HashMap();
/*     */   private List<Module> modules;
/*     */   private Class<? extends Module>[] moduleClasses;
/* 104 */   private boolean findModulesViaServiceLoader = false;
/*     */ 
/* 106 */   private boolean findWellKnownModules = true;
/*     */ 
/* 108 */   private ClassLoader moduleClassLoader = getClass().getClassLoader();
/*     */   private HandlerInstantiator handlerInstantiator;
/*     */   private ApplicationContext applicationContext;
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder createXmlMapper(boolean createXmlMapper)
/*     */   {
/* 121 */     this.createXmlMapper = createXmlMapper;
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder dateFormat(DateFormat dateFormat)
/*     */   {
/* 132 */     this.dateFormat = dateFormat;
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder simpleDateFormat(String format)
/*     */   {
/* 143 */     this.dateFormat = new SimpleDateFormat(format);
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder locale(Locale locale)
/*     */   {
/* 153 */     this.locale = locale;
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder locale(String localeString)
/*     */   {
/* 164 */     this.locale = StringUtils.parseLocaleString(localeString);
/* 165 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder timeZone(TimeZone timeZone)
/*     */   {
/* 174 */     this.timeZone = timeZone;
/* 175 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder timeZone(String timeZoneString)
/*     */   {
/* 185 */     this.timeZone = StringUtils.parseTimeZoneString(timeZoneString);
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder annotationIntrospector(AnnotationIntrospector annotationIntrospector)
/*     */   {
/* 193 */     this.annotationIntrospector = annotationIntrospector;
/* 194 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder propertyNamingStrategy(PropertyNamingStrategy propertyNamingStrategy)
/*     */   {
/* 202 */     this.propertyNamingStrategy = propertyNamingStrategy;
/* 203 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder serializationInclusion(JsonInclude.Include serializationInclusion)
/*     */   {
/* 211 */     this.serializationInclusion = serializationInclusion;
/* 212 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder serializers(JsonSerializer<?>[] serializers)
/*     */   {
/* 222 */     if (serializers != null) {
/* 223 */       for (JsonSerializer serializer : serializers) {
/* 224 */         Class handledType = serializer.handledType();
/* 225 */         if ((handledType == null) || (handledType == Object.class)) {
/* 226 */           throw new IllegalArgumentException("Unknown handled type in " + serializer.getClass().getName());
/*     */         }
/* 228 */         this.serializers.put(serializer.handledType(), serializer);
/*     */       }
/*     */     }
/* 231 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder serializerByType(Class<?> type, JsonSerializer<?> serializer)
/*     */   {
/* 240 */     if (this.serializers != null) {
/* 241 */       this.serializers.put(type, serializer);
/*     */     }
/* 243 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder serializersByType(Map<Class<?>, JsonSerializer<?>> serializers)
/*     */   {
/* 251 */     if (serializers != null) {
/* 252 */       this.serializers.putAll(serializers);
/*     */     }
/* 254 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder deserializerByType(Class<?> type, JsonDeserializer<?> deserializer)
/*     */   {
/* 262 */     if (this.deserializers != null) {
/* 263 */       this.deserializers.put(type, deserializer);
/*     */     }
/* 265 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder deserializersByType(Map<Class<?>, JsonDeserializer<?>> deserializers)
/*     */   {
/* 272 */     if (deserializers != null) {
/* 273 */       this.deserializers.putAll(deserializers);
/*     */     }
/* 275 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder mixIn(Class<?> target, Class<?> mixinSource)
/*     */   {
/* 287 */     if (mixinSource != null) {
/* 288 */       this.mixIns.put(target, mixinSource);
/*     */     }
/* 290 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder mixIns(Map<Class<?>, Class<?>> mixIns)
/*     */   {
/* 302 */     if (mixIns != null) {
/* 303 */       this.mixIns.putAll(mixIns);
/*     */     }
/* 305 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder autoDetectFields(boolean autoDetectFields)
/*     */   {
/* 312 */     this.features.put(MapperFeature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/* 313 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder autoDetectGettersSetters(boolean autoDetectGettersSetters)
/*     */   {
/* 321 */     this.features.put(MapperFeature.AUTO_DETECT_GETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 322 */     this.features.put(MapperFeature.AUTO_DETECT_SETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 323 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder defaultViewInclusion(boolean defaultViewInclusion)
/*     */   {
/* 330 */     this.features.put(MapperFeature.DEFAULT_VIEW_INCLUSION, Boolean.valueOf(defaultViewInclusion));
/* 331 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder failOnUnknownProperties(boolean failOnUnknownProperties)
/*     */   {
/* 338 */     this.features.put(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, Boolean.valueOf(failOnUnknownProperties));
/* 339 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder failOnEmptyBeans(boolean failOnEmptyBeans)
/*     */   {
/* 346 */     this.features.put(SerializationFeature.FAIL_ON_EMPTY_BEANS, Boolean.valueOf(failOnEmptyBeans));
/* 347 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder indentOutput(boolean indentOutput)
/*     */   {
/* 354 */     this.features.put(SerializationFeature.INDENT_OUTPUT, Boolean.valueOf(indentOutput));
/* 355 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder featuresToEnable(Object[] featuresToEnable)
/*     */   {
/* 367 */     if (featuresToEnable != null) {
/* 368 */       for (Object feature : featuresToEnable) {
/* 369 */         this.features.put(feature, Boolean.TRUE);
/*     */       }
/*     */     }
/* 372 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder featuresToDisable(Object[] featuresToDisable)
/*     */   {
/* 384 */     if (featuresToDisable != null) {
/* 385 */       for (Object feature : featuresToDisable) {
/* 386 */         this.features.put(feature, Boolean.FALSE);
/*     */       }
/*     */     }
/* 389 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder modules(Module[] modules)
/*     */   {
/* 404 */     return modules(Arrays.asList(modules));
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder modules(List<Module> modules)
/*     */   {
/* 418 */     this.modules = new LinkedList(modules);
/* 419 */     this.findModulesViaServiceLoader = false;
/* 420 */     this.findWellKnownModules = false;
/* 421 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder modulesToInstall(Module[] modules)
/*     */   {
/* 435 */     this.modules = Arrays.asList(modules);
/* 436 */     this.findWellKnownModules = true;
/* 437 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder modulesToInstall(Class<? extends Module>[] modules)
/*     */   {
/* 452 */     this.moduleClasses = modules;
/* 453 */     this.findWellKnownModules = true;
/* 454 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder findModulesViaServiceLoader(boolean findModules)
/*     */   {
/* 466 */     this.findModulesViaServiceLoader = findModules;
/* 467 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder moduleClassLoader(ClassLoader moduleClassLoader)
/*     */   {
/* 474 */     this.moduleClassLoader = moduleClassLoader;
/* 475 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder handlerInstantiator(HandlerInstantiator handlerInstantiator)
/*     */   {
/* 485 */     this.handlerInstantiator = handlerInstantiator;
/* 486 */     return this;
/*     */   }
/*     */ 
/*     */   public Jackson2ObjectMapperBuilder applicationContext(ApplicationContext applicationContext)
/*     */   {
/* 496 */     this.applicationContext = applicationContext;
/* 497 */     return this;
/*     */   }
/*     */ 
/*     */   public <T extends ObjectMapper> T build()
/*     */   {
/*     */     ObjectMapper objectMapper;
/* 510 */     if (this.createXmlMapper) {
/*     */       try
/*     */       {
/* 513 */         Class xmlMapper = ClassUtils.forName("com.fasterxml.jackson.dataformat.xml.XmlMapper", this.moduleClassLoader);
/*     */ 
/* 514 */         objectMapper = (ObjectMapper)BeanUtils.instantiate(xmlMapper);
/*     */       }
/*     */       catch (ClassNotFoundException ex)
/*     */       {
/*     */         ObjectMapper objectMapper;
/* 517 */         throw new IllegalStateException("Could not instantiate XmlMapper - not found on classpath");
/*     */       }
/*     */     }
/*     */     else {
/* 521 */       objectMapper = new ObjectMapper();
/*     */     }
/* 523 */     configure(objectMapper);
/* 524 */     return objectMapper;
/*     */   }
/*     */ 
/*     */   public void configure(ObjectMapper objectMapper)
/*     */   {
/* 534 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/*     */ 
/* 536 */     if (this.findModulesViaServiceLoader)
/*     */     {
/* 538 */       objectMapper.registerModules(ObjectMapper.findModules(this.moduleClassLoader));
/*     */     }
/* 540 */     else if (this.findWellKnownModules)
/* 541 */       registerWellKnownModulesIfAvailable(objectMapper);
/*     */     Object localObject1;
/* 544 */     if (this.modules != null)
/* 545 */       for (localObject1 = this.modules.iterator(); ((Iterator)localObject1).hasNext(); ) { module = (Module)((Iterator)localObject1).next();
/*     */ 
/* 547 */         objectMapper.registerModule(module);
/*     */       }
/*     */     Module module;
/* 550 */     if (this.moduleClasses != null) {
/* 551 */       localObject1 = this.moduleClasses; module = localObject1.length; for (Module localModule1 = 0; localModule1 < module; localModule1++) { Class module = localObject1[localModule1];
/* 552 */         objectMapper.registerModule((Module)BeanUtils.instantiate(module));
/*     */       }
/*     */     }
/*     */ 
/* 556 */     if (this.dateFormat != null) {
/* 557 */       objectMapper.setDateFormat(this.dateFormat);
/*     */     }
/* 559 */     if (this.locale != null) {
/* 560 */       objectMapper.setLocale(this.locale);
/*     */     }
/* 562 */     if (this.timeZone != null) {
/* 563 */       objectMapper.setTimeZone(this.timeZone);
/*     */     }
/*     */ 
/* 566 */     if (this.annotationIntrospector != null) {
/* 567 */       objectMapper.setAnnotationIntrospector(this.annotationIntrospector);
/*     */     }
/*     */ 
/* 570 */     if (this.serializationInclusion != null) {
/* 571 */       objectMapper.setSerializationInclusion(this.serializationInclusion);
/*     */     }
/*     */ 
/* 574 */     if ((!this.serializers.isEmpty()) || (!this.deserializers.isEmpty())) {
/* 575 */       module = new SimpleModule();
/* 576 */       addSerializers((SimpleModule)module);
/* 577 */       addDeserializers((SimpleModule)module);
/* 578 */       objectMapper.registerModule((Module)module);
/*     */     }
/*     */ 
/* 581 */     customizeDefaultFeatures(objectMapper);
/* 582 */     for (Object module = this.features.keySet().iterator(); ((Iterator)module).hasNext(); ) { Object feature = ((Iterator)module).next();
/* 583 */       configureFeature(objectMapper, feature, ((Boolean)this.features.get(feature)).booleanValue());
/*     */     }
/*     */ 
/* 586 */     if (this.propertyNamingStrategy != null) {
/* 587 */       objectMapper.setPropertyNamingStrategy(this.propertyNamingStrategy);
/*     */     }
/* 589 */     for (module = this.mixIns.keySet().iterator(); ((Iterator)module).hasNext(); ) { Class target = (Class)((Iterator)module).next();
/*     */ 
/* 591 */       objectMapper.addMixInAnnotations(target, (Class)this.mixIns.get(target));
/*     */     }
/* 593 */     if (this.handlerInstantiator != null) {
/* 594 */       objectMapper.setHandlerInstantiator(this.handlerInstantiator);
/*     */     }
/* 596 */     else if (this.applicationContext != null)
/* 597 */       objectMapper.setHandlerInstantiator(new SpringHandlerInstantiator(this.applicationContext
/* 598 */         .getAutowireCapableBeanFactory()));
/*     */   }
/*     */ 
/*     */   private void customizeDefaultFeatures(ObjectMapper objectMapper)
/*     */   {
/* 605 */     if (!this.features.containsKey(MapperFeature.DEFAULT_VIEW_INCLUSION)) {
/* 606 */       configureFeature(objectMapper, MapperFeature.DEFAULT_VIEW_INCLUSION, false);
/*     */     }
/* 608 */     if (!this.features.containsKey(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES))
/* 609 */       configureFeature(objectMapper, DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
/*     */   }
/*     */ 
/*     */   private <T> void addSerializers(SimpleModule module)
/*     */   {
/* 615 */     for (Class type : this.serializers.keySet())
/* 616 */       module.addSerializer(type, (JsonSerializer)this.serializers.get(type));
/*     */   }
/*     */ 
/*     */   private <T> void addDeserializers(SimpleModule module)
/*     */   {
/* 622 */     for (Class type : this.deserializers.keySet())
/* 623 */       module.addDeserializer(type, (JsonDeserializer)this.deserializers.get(type));
/*     */   }
/*     */ 
/*     */   private void configureFeature(ObjectMapper objectMapper, Object feature, boolean enabled)
/*     */   {
/* 628 */     if ((feature instanceof JsonParser.Feature)) {
/* 629 */       objectMapper.configure((JsonParser.Feature)feature, enabled);
/*     */     }
/* 631 */     else if ((feature instanceof JsonGenerator.Feature)) {
/* 632 */       objectMapper.configure((JsonGenerator.Feature)feature, enabled);
/*     */     }
/* 634 */     else if ((feature instanceof SerializationFeature)) {
/* 635 */       objectMapper.configure((SerializationFeature)feature, enabled);
/*     */     }
/* 637 */     else if ((feature instanceof DeserializationFeature)) {
/* 638 */       objectMapper.configure((DeserializationFeature)feature, enabled);
/*     */     }
/* 640 */     else if ((feature instanceof MapperFeature)) {
/* 641 */       objectMapper.configure((MapperFeature)feature, enabled);
/*     */     }
/*     */     else
/* 644 */       throw new FatalBeanException("Unknown feature class: " + feature.getClass().getName());
/*     */   }
/*     */ 
/*     */   private void registerWellKnownModulesIfAvailable(ObjectMapper objectMapper)
/*     */   {
/* 651 */     if (ClassUtils.isPresent("java.time.LocalDate", this.moduleClassLoader)) {
/*     */       try
/*     */       {
/* 654 */         Class jsr310Module = ClassUtils.forName("com.fasterxml.jackson.datatype.jsr310.JSR310Module", this.moduleClassLoader);
/*     */ 
/* 655 */         objectMapper.registerModule((Module)BeanUtils.instantiate(jsr310Module));
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/* 662 */     if (ClassUtils.isPresent("org.joda.time.LocalDate", this.moduleClassLoader))
/*     */       try
/*     */       {
/* 665 */         Class jodaModule = ClassUtils.forName("com.fasterxml.jackson.datatype.joda.JodaModule", this.moduleClassLoader);
/*     */ 
/* 666 */         objectMapper.registerModule((Module)BeanUtils.instantiate(jodaModule));
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException1)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   public static Jackson2ObjectMapperBuilder json()
/*     */   {
/* 682 */     return new Jackson2ObjectMapperBuilder();
/*     */   }
/*     */ 
/*     */   public static Jackson2ObjectMapperBuilder xml()
/*     */   {
/* 691 */     return new Jackson2ObjectMapperBuilder().createXmlMapper(true);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.Jackson2ObjectMapperBuilder
 * JD-Core Version:    0.6.2
 */