/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude.Include;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import java.text.DateFormat;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class Jackson2ObjectMapperFactoryBean
/*     */   implements FactoryBean<ObjectMapper>, BeanClassLoaderAware, ApplicationContextAware, InitializingBean
/*     */ {
/* 134 */   private final Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
/*     */   private ObjectMapper objectMapper;
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/* 144 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   public void setCreateXmlMapper(boolean createXmlMapper)
/*     */   {
/* 153 */     this.builder.createXmlMapper(createXmlMapper);
/*     */   }
/*     */ 
/*     */   public void setDateFormat(DateFormat dateFormat)
/*     */   {
/* 163 */     this.builder.dateFormat(dateFormat);
/*     */   }
/*     */ 
/*     */   public void setSimpleDateFormat(String format)
/*     */   {
/* 173 */     this.builder.simpleDateFormat(format);
/*     */   }
/*     */ 
/*     */   public void setLocale(Locale locale)
/*     */   {
/* 182 */     this.builder.locale(locale);
/*     */   }
/*     */ 
/*     */   public void setTimeZone(TimeZone timeZone)
/*     */   {
/* 191 */     this.builder.timeZone(timeZone);
/*     */   }
/*     */ 
/*     */   public void setAnnotationIntrospector(AnnotationIntrospector annotationIntrospector)
/*     */   {
/* 198 */     this.builder.annotationIntrospector(annotationIntrospector);
/*     */   }
/*     */ 
/*     */   public void setPropertyNamingStrategy(PropertyNamingStrategy propertyNamingStrategy)
/*     */   {
/* 207 */     this.builder.propertyNamingStrategy(propertyNamingStrategy);
/*     */   }
/*     */ 
/*     */   public void setSerializationInclusion(JsonInclude.Include serializationInclusion)
/*     */   {
/* 215 */     this.builder.serializationInclusion(serializationInclusion);
/*     */   }
/*     */ 
/*     */   public void setSerializers(JsonSerializer<?>[] serializers)
/*     */   {
/* 225 */     this.builder.serializers(serializers);
/*     */   }
/*     */ 
/*     */   public void setSerializersByType(Map<Class<?>, JsonSerializer<?>> serializers)
/*     */   {
/* 233 */     this.builder.serializersByType(serializers);
/*     */   }
/*     */ 
/*     */   public void setDeserializersByType(Map<Class<?>, JsonDeserializer<?>> deserializers)
/*     */   {
/* 240 */     this.builder.deserializersByType(deserializers);
/*     */   }
/*     */ 
/*     */   public void setMixIns(Map<Class<?>, Class<?>> mixIns)
/*     */   {
/* 252 */     this.builder.mixIns(mixIns);
/*     */   }
/*     */ 
/*     */   public void setAutoDetectFields(boolean autoDetectFields)
/*     */   {
/* 259 */     this.builder.autoDetectFields(autoDetectFields);
/*     */   }
/*     */ 
/*     */   public void setAutoDetectGettersSetters(boolean autoDetectGettersSetters)
/*     */   {
/* 267 */     this.builder.autoDetectGettersSetters(autoDetectGettersSetters);
/*     */   }
/*     */ 
/*     */   public void setDefaultViewInclusion(boolean defaultViewInclusion)
/*     */   {
/* 275 */     this.builder.defaultViewInclusion(defaultViewInclusion);
/*     */   }
/*     */ 
/*     */   public void setFailOnUnknownProperties(boolean failOnUnknownProperties)
/*     */   {
/* 283 */     this.builder.failOnUnknownProperties(failOnUnknownProperties);
/*     */   }
/*     */ 
/*     */   public void setFailOnEmptyBeans(boolean failOnEmptyBeans)
/*     */   {
/* 290 */     this.builder.failOnEmptyBeans(failOnEmptyBeans);
/*     */   }
/*     */ 
/*     */   public void setIndentOutput(boolean indentOutput)
/*     */   {
/* 297 */     this.builder.indentOutput(indentOutput);
/*     */   }
/*     */ 
/*     */   public void setFeaturesToEnable(Object[] featuresToEnable)
/*     */   {
/* 309 */     this.builder.featuresToEnable(featuresToEnable);
/*     */   }
/*     */ 
/*     */   public void setFeaturesToDisable(Object[] featuresToDisable)
/*     */   {
/* 321 */     this.builder.featuresToDisable(featuresToDisable);
/*     */   }
/*     */ 
/*     */   public void setModules(List<Module> modules)
/*     */   {
/* 335 */     this.builder.modules(modules);
/*     */   }
/*     */ 
/*     */   public void setModulesToInstall(Class<? extends Module>[] modules)
/*     */   {
/* 350 */     this.builder.modulesToInstall(modules);
/*     */   }
/*     */ 
/*     */   public void setFindModulesViaServiceLoader(boolean findModules)
/*     */   {
/* 363 */     this.builder.findModulesViaServiceLoader(findModules);
/*     */   }
/*     */ 
/*     */   public void setHandlerInstantiator(HandlerInstantiator handlerInstantiator)
/*     */   {
/* 373 */     this.builder.handlerInstantiator(handlerInstantiator);
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/* 378 */     this.builder.moduleClassLoader(beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 385 */     if (this.objectMapper != null) {
/* 386 */       this.builder.configure(this.objectMapper);
/*     */     }
/*     */     else
/* 389 */       this.objectMapper = this.builder.build();
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 402 */     this.builder.applicationContext(applicationContext);
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObject()
/*     */   {
/* 410 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 415 */     return this.objectMapper != null ? this.objectMapper.getClass() : null;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 420 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean
 * JD-Core Version:    0.6.2
 */