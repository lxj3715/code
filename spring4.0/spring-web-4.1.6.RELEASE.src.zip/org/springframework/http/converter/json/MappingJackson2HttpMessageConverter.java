/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import java.io.IOException;
/*     */ import org.springframework.http.MediaType;
/*     */ 
/*     */ public class MappingJackson2HttpMessageConverter extends AbstractJackson2HttpMessageConverter
/*     */ {
/*     */   private String jsonPrefix;
/*     */ 
/*     */   public MappingJackson2HttpMessageConverter()
/*     */   {
/*  56 */     this(Jackson2ObjectMapperBuilder.json().build());
/*     */   }
/*     */ 
/*     */   public MappingJackson2HttpMessageConverter(ObjectMapper objectMapper)
/*     */   {
/*  65 */     super(objectMapper, new MediaType[] { new MediaType("application", "json", DEFAULT_CHARSET), new MediaType("application", "*+json", DEFAULT_CHARSET) });
/*     */   }
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/*  75 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/*  87 */     this.jsonPrefix = (prefixJson ? "{} && " : null);
/*     */   }
/*     */ 
/*     */   protected void writePrefix(JsonGenerator generator, Object object)
/*     */     throws IOException
/*     */   {
/*  93 */     if (this.jsonPrefix != null) {
/*  94 */       generator.writeRaw(this.jsonPrefix);
/*     */     }
/*     */ 
/*  97 */     String jsonpFunction = (object instanceof MappingJacksonValue) ? ((MappingJacksonValue)object)
/*  97 */       .getJsonpFunction() : null;
/*  98 */     if (jsonpFunction != null)
/*  99 */       generator.writeRaw(jsonpFunction + "(");
/*     */   }
/*     */ 
/*     */   protected void writeSuffix(JsonGenerator generator, Object object)
/*     */     throws IOException
/*     */   {
/* 106 */     String jsonpFunction = (object instanceof MappingJacksonValue) ? ((MappingJacksonValue)object)
/* 106 */       .getJsonpFunction() : null;
/* 107 */     if (jsonpFunction != null)
/* 108 */       generator.writeRaw(");");
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
 * JD-Core Version:    0.6.2
 */