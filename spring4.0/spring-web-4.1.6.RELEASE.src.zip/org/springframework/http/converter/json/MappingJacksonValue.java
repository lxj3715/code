/*    */ package org.springframework.http.converter.json;
/*    */ 
/*    */ public class MappingJacksonValue
/*    */ {
/*    */   private Object value;
/*    */   private Class<?> serializationView;
/*    */   private String jsonpFunction;
/*    */ 
/*    */   public MappingJacksonValue(Object value)
/*    */   {
/* 48 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public void setValue(Object value)
/*    */   {
/* 56 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Object getValue()
/*    */   {
/* 63 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setSerializationView(Class<?> serializationView)
/*    */   {
/* 72 */     this.serializationView = serializationView;
/*    */   }
/*    */ 
/*    */   public Class<?> getSerializationView()
/*    */   {
/* 81 */     return this.serializationView;
/*    */   }
/*    */ 
/*    */   public void setJsonpFunction(String functionName)
/*    */   {
/* 88 */     this.jsonpFunction = functionName;
/*    */   }
/*    */ 
/*    */   public String getJsonpFunction()
/*    */   {
/* 95 */     return this.jsonpFunction;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.MappingJacksonValue
 * JD-Core Version:    0.6.2
 */