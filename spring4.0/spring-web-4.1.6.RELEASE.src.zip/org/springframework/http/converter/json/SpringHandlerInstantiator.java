/*    */ package org.springframework.http.converter.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*    */ import com.fasterxml.jackson.databind.SerializationConfig;
/*    */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*    */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*    */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*    */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SpringHandlerInstantiator extends HandlerInstantiator
/*    */ {
/*    */   private final AutowireCapableBeanFactory beanFactory;
/*    */ 
/*    */   public SpringHandlerInstantiator(AutowireCapableBeanFactory beanFactory)
/*    */   {
/* 55 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 56 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */   public JsonSerializer<?> serializerInstance(SerializationConfig config, Annotated annotated, Class<?> keyDeserClass)
/*    */   {
/* 62 */     return (JsonSerializer)this.beanFactory.createBean(keyDeserClass);
/*    */   }
/*    */ 
/*    */   public JsonDeserializer<?> deserializerInstance(DeserializationConfig config, Annotated annotated, Class<?> deserClass)
/*    */   {
/* 68 */     return (JsonDeserializer)this.beanFactory.createBean(deserClass);
/*    */   }
/*    */ 
/*    */   public KeyDeserializer keyDeserializerInstance(DeserializationConfig config, Annotated annotated, Class<?> serClass)
/*    */   {
/* 74 */     return (KeyDeserializer)this.beanFactory.createBean(serClass);
/*    */   }
/*    */ 
/*    */   public TypeResolverBuilder<?> typeResolverBuilderInstance(MapperConfig<?> config, Annotated annotated, Class<?> resolverClass)
/*    */   {
/* 80 */     return (TypeResolverBuilder)this.beanFactory.createBean(resolverClass);
/*    */   }
/*    */ 
/*    */   public TypeIdResolver typeIdResolverInstance(MapperConfig<?> config, Annotated annotated, Class<?> resolverClass)
/*    */   {
/* 86 */     return (TypeIdResolver)this.beanFactory.createBean(resolverClass);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.SpringHandlerInstantiator
 * JD-Core Version:    0.6.2
 */