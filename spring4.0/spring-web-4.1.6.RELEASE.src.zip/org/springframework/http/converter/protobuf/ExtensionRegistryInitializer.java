package org.springframework.http.converter.protobuf;

import com.google.protobuf.ExtensionRegistry;

public abstract interface ExtensionRegistryInitializer
{
  public abstract void initializeExtensionRegistry(ExtensionRegistry paramExtensionRegistry);
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.protobuf.ExtensionRegistryInitializer
 * JD-Core Version:    0.6.2
 */