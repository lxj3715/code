/*     */ package org.springframework.http.converter.protobuf;
/*     */ 
/*     */ import com.google.protobuf.Descriptors.Descriptor;
/*     */ import com.google.protobuf.Descriptors.FileDescriptor;
/*     */ import com.google.protobuf.ExtensionRegistry;
/*     */ import com.google.protobuf.Message;
/*     */ import com.google.protobuf.Message.Builder;
/*     */ import com.google.protobuf.TextFormat;
/*     */ import com.googlecode.protobuf.format.HtmlFormat;
/*     */ import com.googlecode.protobuf.format.JsonFormat;
/*     */ import com.googlecode.protobuf.format.XmlFormat;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ public class ProtobufHttpMessageConverter extends AbstractHttpMessageConverter<Message>
/*     */ {
/*  62 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */ 
/*  64 */   public static final MediaType PROTOBUF = new MediaType("application", "x-protobuf", DEFAULT_CHARSET);
/*     */   public static final String X_PROTOBUF_SCHEMA_HEADER = "X-Protobuf-Schema";
/*     */   public static final String X_PROTOBUF_MESSAGE_HEADER = "X-Protobuf-Message";
/*  70 */   private static final ConcurrentHashMap<Class<?>, Method> methodCache = new ConcurrentHashMap();
/*     */ 
/*  73 */   private ExtensionRegistry extensionRegistry = ExtensionRegistry.newInstance();
/*     */ 
/*     */   public ProtobufHttpMessageConverter()
/*     */   {
/*  80 */     this(null);
/*     */   }
/*     */ 
/*     */   public ProtobufHttpMessageConverter(ExtensionRegistryInitializer registryInitializer)
/*     */   {
/*  88 */     super(new MediaType[] { PROTOBUF, MediaType.TEXT_PLAIN, MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON });
/*  89 */     if (registryInitializer != null)
/*  90 */       registryInitializer.initializeExtensionRegistry(this.extensionRegistry);
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/*  97 */     return Message.class.isAssignableFrom(clazz);
/*     */   }
/*     */ 
/*     */   protected Message readInternal(Class<? extends Message> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 104 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/* 105 */     contentType = contentType != null ? contentType : PROTOBUF;
/*     */ 
/* 107 */     Charset charset = getCharset(inputMessage.getHeaders());
/* 108 */     InputStreamReader reader = new InputStreamReader(inputMessage.getBody(), charset);
/*     */     try
/*     */     {
/* 111 */       Message.Builder builder = getMessageBuilder(clazz);
/*     */ 
/* 113 */       if (MediaType.APPLICATION_JSON.isCompatibleWith(contentType)) {
/* 114 */         JsonFormat.merge(reader, this.extensionRegistry, builder);
/*     */       }
/* 116 */       else if (MediaType.TEXT_PLAIN.isCompatibleWith(contentType)) {
/* 117 */         TextFormat.merge(reader, this.extensionRegistry, builder);
/*     */       }
/* 119 */       else if (MediaType.APPLICATION_XML.isCompatibleWith(contentType)) {
/* 120 */         XmlFormat.merge(reader, this.extensionRegistry, builder);
/*     */       }
/*     */       else {
/* 123 */         builder.mergeFrom(inputMessage.getBody(), this.extensionRegistry);
/*     */       }
/* 125 */       return builder.build();
/*     */     }
/*     */     catch (Exception e) {
/* 128 */       throw new HttpMessageNotReadableException("Could not read Protobuf message: " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Charset getCharset(HttpHeaders headers) {
/* 133 */     if ((headers == null) || (headers.getContentType() == null) || (headers.getContentType().getCharSet() == null)) {
/* 134 */       return DEFAULT_CHARSET;
/*     */     }
/* 136 */     return headers.getContentType().getCharSet();
/*     */   }
/*     */ 
/*     */   private Message.Builder getMessageBuilder(Class<? extends Message> clazz)
/*     */     throws Exception
/*     */   {
/* 144 */     Method method = (Method)methodCache.get(clazz);
/* 145 */     if (method == null) {
/* 146 */       method = clazz.getMethod("newBuilder", new Class[0]);
/* 147 */       methodCache.put(clazz, method);
/*     */     }
/* 149 */     return (Message.Builder)method.invoke(clazz, new Object[0]);
/*     */   }
/*     */ 
/*     */   protected boolean canWrite(MediaType mediaType)
/*     */   {
/* 158 */     return (super.canWrite(mediaType)) || (MediaType.TEXT_HTML.isCompatibleWith(mediaType));
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Message message, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 165 */     MediaType contentType = outputMessage.getHeaders().getContentType();
/* 166 */     Charset charset = getCharset(contentType);
/*     */ 
/* 168 */     if (MediaType.TEXT_HTML.isCompatibleWith(contentType)) {
/* 169 */       OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputMessage.getBody(), charset);
/* 170 */       HtmlFormat.print(message, outputStreamWriter);
/* 171 */       outputStreamWriter.flush();
/*     */     }
/* 173 */     else if (MediaType.APPLICATION_JSON.isCompatibleWith(contentType)) {
/* 174 */       OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputMessage.getBody(), charset);
/* 175 */       JsonFormat.print(message, outputStreamWriter);
/* 176 */       outputStreamWriter.flush();
/*     */     }
/* 178 */     else if (MediaType.TEXT_PLAIN.isCompatibleWith(contentType)) {
/* 179 */       OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputMessage.getBody(), charset);
/* 180 */       TextFormat.print(message, outputStreamWriter);
/* 181 */       outputStreamWriter.flush();
/*     */     }
/* 183 */     else if (MediaType.APPLICATION_XML.isCompatibleWith(contentType)) {
/* 184 */       OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputMessage.getBody(), charset);
/* 185 */       XmlFormat.print(message, outputStreamWriter);
/* 186 */       outputStreamWriter.flush();
/*     */     }
/* 188 */     else if (PROTOBUF.isCompatibleWith(contentType)) {
/* 189 */       setProtoHeader(outputMessage, message);
/* 190 */       FileCopyUtils.copy(message.toByteArray(), outputMessage.getBody());
/*     */     }
/*     */   }
/*     */ 
/*     */   private Charset getCharset(MediaType contentType) {
/* 195 */     return contentType.getCharSet() != null ? contentType.getCharSet() : DEFAULT_CHARSET;
/*     */   }
/*     */ 
/*     */   private void setProtoHeader(HttpOutputMessage response, Message message)
/*     */   {
/* 205 */     response.getHeaders().set("X-Protobuf-Schema", message.getDescriptorForType().getFile().getName());
/* 206 */     response.getHeaders().set("X-Protobuf-Message", message.getDescriptorForType().getFullName());
/*     */   }
/*     */ 
/*     */   protected MediaType getDefaultContentType(Message message)
/*     */   {
/* 211 */     return PROTOBUF;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.protobuf.ProtobufHttpMessageConverter
 * JD-Core Version:    0.6.2
 */