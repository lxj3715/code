/*    */ package org.springframework.http.converter.support;
/*    */ 
/*    */ import org.springframework.http.converter.FormHttpMessageConverter;
/*    */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class AllEncompassingFormHttpMessageConverter extends FormHttpMessageConverter
/*    */ {
/* 37 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", AllEncompassingFormHttpMessageConverter.class
/* 37 */     .getClassLoader());
/*    */ 
/* 40 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", AllEncompassingFormHttpMessageConverter.class
/* 40 */     .getClassLoader())) && 
/* 41 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", AllEncompassingFormHttpMessageConverter.class
/* 41 */     .getClassLoader()));
/*    */ 
/*    */   public AllEncompassingFormHttpMessageConverter()
/*    */   {
/* 45 */     addPartConverter(new SourceHttpMessageConverter());
/* 46 */     if (jaxb2Present) {
/* 47 */       addPartConverter(new Jaxb2RootElementHttpMessageConverter());
/*    */     }
/* 49 */     if (jackson2Present)
/* 50 */       addPartConverter(new MappingJackson2HttpMessageConverter());
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter
 * JD-Core Version:    0.6.2
 */