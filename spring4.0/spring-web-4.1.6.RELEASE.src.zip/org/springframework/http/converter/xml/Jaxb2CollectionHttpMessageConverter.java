/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ 
/*     */ public class Jaxb2CollectionHttpMessageConverter<T extends Collection> extends AbstractJaxb2HttpMessageConverter<T>
/*     */   implements GenericHttpMessageConverter<T>
/*     */ {
/*  63 */   private final XMLInputFactory inputFactory = createXmlInputFactory();
/*     */ 
/* 238 */   private static final XMLResolver NO_OP_XML_RESOLVER = new XMLResolver()
/*     */   {
/*     */     public Object resolveEntity(String publicID, String systemID, String base, String ns) {
/* 241 */       return new ByteArrayInputStream(new byte[0]);
/*     */     }
/* 238 */   };
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  72 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/*  83 */     if (!(type instanceof ParameterizedType)) {
/*  84 */       return false;
/*     */     }
/*  86 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/*  87 */     if (!(parameterizedType.getRawType() instanceof Class)) {
/*  88 */       return false;
/*     */     }
/*  90 */     Class rawType = (Class)parameterizedType.getRawType();
/*  91 */     if (!Collection.class.isAssignableFrom(rawType)) {
/*  92 */       return false;
/*     */     }
/*  94 */     if (parameterizedType.getActualTypeArguments().length != 1) {
/*  95 */       return false;
/*     */     }
/*  97 */     Type typeArgument = parameterizedType.getActualTypeArguments()[0];
/*  98 */     if (!(typeArgument instanceof Class)) {
/*  99 */       return false;
/*     */     }
/* 101 */     Class typeArgumentClass = (Class)typeArgument;
/*     */ 
/* 103 */     return ((typeArgumentClass.isAnnotationPresent(XmlRootElement.class)) || 
/* 103 */       (typeArgumentClass
/* 103 */       .isAnnotationPresent(XmlType.class))) && 
/* 103 */       (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 118 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected T readFromSource(Class<? extends T> clazz, HttpHeaders headers, Source source)
/*     */     throws IOException
/*     */   {
/* 124 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public T read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 132 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/* 133 */     Collection result = createCollection((Class)parameterizedType.getRawType());
/* 134 */     Class elementClass = (Class)parameterizedType.getActualTypeArguments()[0];
/*     */     try
/*     */     {
/* 137 */       Unmarshaller unmarshaller = createUnmarshaller(elementClass);
/* 138 */       XMLStreamReader streamReader = this.inputFactory.createXMLStreamReader(inputMessage.getBody());
/* 139 */       int event = moveToFirstChildOfRootElement(streamReader);
/*     */ 
/* 141 */       while (event != 8) {
/* 142 */         if (elementClass.isAnnotationPresent(XmlRootElement.class)) {
/* 143 */           result.add(unmarshaller.unmarshal(streamReader));
/*     */         }
/* 145 */         else if (elementClass.isAnnotationPresent(XmlType.class)) {
/* 146 */           result.add(unmarshaller.unmarshal(streamReader, elementClass).getValue());
/*     */         }
/*     */         else
/*     */         {
/* 150 */           throw new HttpMessageConversionException("Could not unmarshal to [" + elementClass + "]");
/*     */         }
/* 152 */         event = moveToNextElement(streamReader);
/*     */       }
/* 154 */       return result;
/*     */     }
/*     */     catch (UnmarshalException ex) {
/* 157 */       throw new HttpMessageNotReadableException("Could not unmarshal to [" + elementClass + "]: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (JAXBException ex) {
/* 160 */       throw new HttpMessageConversionException("Could not instantiate JAXBContext: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 163 */       throw new HttpMessageConversionException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected T createCollection(Class<?> collectionClass)
/*     */   {
/* 175 */     if (!collectionClass.isInterface()) {
/*     */       try {
/* 177 */         return (Collection)collectionClass.newInstance();
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 182 */         throw new IllegalArgumentException("Could not instantiate collection class [" + collectionClass
/* 182 */           .getName() + "]: " + ex.getMessage());
/*     */       }
/*     */     }
/* 185 */     if (List.class.equals(collectionClass)) {
/* 186 */       return new ArrayList();
/*     */     }
/* 188 */     if (SortedSet.class.equals(collectionClass)) {
/* 189 */       return new TreeSet();
/*     */     }
/*     */ 
/* 192 */     return new LinkedHashSet();
/*     */   }
/*     */ 
/*     */   private int moveToFirstChildOfRootElement(XMLStreamReader streamReader)
/*     */     throws XMLStreamException
/*     */   {
/* 198 */     int event = streamReader.next();
/* 199 */     while (event != 1) {
/* 200 */       event = streamReader.next();
/*     */     }
/*     */ 
/* 204 */     event = streamReader.next();
/* 205 */     while ((event != 1) && (event != 8)) {
/* 206 */       event = streamReader.next();
/*     */     }
/* 208 */     return event;
/*     */   }
/*     */ 
/*     */   private int moveToNextElement(XMLStreamReader streamReader) throws XMLStreamException {
/* 212 */     int event = streamReader.getEventType();
/* 213 */     while ((event != 1) && (event != 8)) {
/* 214 */       event = streamReader.next();
/*     */     }
/* 216 */     return event;
/*     */   }
/*     */ 
/*     */   protected void writeToResult(T t, HttpHeaders headers, Result result) throws IOException
/*     */   {
/* 221 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected XMLInputFactory createXmlInputFactory()
/*     */   {
/* 231 */     XMLInputFactory inputFactory = XMLInputFactory.newInstance();
/* 232 */     inputFactory.setProperty("javax.xml.stream.isSupportingExternalEntities", Boolean.valueOf(false));
/* 233 */     inputFactory.setXMLResolver(NO_OP_XML_RESOLVER);
/* 234 */     return inputFactory;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.Jaxb2CollectionHttpMessageConverter
 * JD-Core Version:    0.6.2
 */