/*    */ package org.springframework.http.converter.xml;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.dataformat.xml.XmlMapper;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class MappingJackson2XmlHttpMessageConverter extends AbstractJackson2HttpMessageConverter
/*    */ {
/*    */   public MappingJackson2XmlHttpMessageConverter()
/*    */   {
/* 49 */     this(Jackson2ObjectMapperBuilder.xml().build());
/*    */   }
/*    */ 
/*    */   public MappingJackson2XmlHttpMessageConverter(ObjectMapper objectMapper)
/*    */   {
/* 59 */     super(objectMapper, new MediaType[] { new MediaType("application", "xml", DEFAULT_CHARSET), new MediaType("text", "xml", DEFAULT_CHARSET), new MediaType("application", "*+xml", DEFAULT_CHARSET) });
/*    */ 
/* 62 */     Assert.isAssignable(XmlMapper.class, objectMapper.getClass());
/*    */   }
/*    */ 
/*    */   public void setObjectMapper(ObjectMapper objectMapper)
/*    */   {
/* 71 */     Assert.isAssignable(XmlMapper.class, objectMapper.getClass());
/* 72 */     super.setObjectMapper(objectMapper);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter
 * JD-Core Version:    0.6.2
 */