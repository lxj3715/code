/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.oxm.Marshaller;
/*     */ import org.springframework.oxm.MarshallingFailureException;
/*     */ import org.springframework.oxm.Unmarshaller;
/*     */ import org.springframework.oxm.UnmarshallingFailureException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MarshallingHttpMessageConverter extends AbstractXmlHttpMessageConverter<Object>
/*     */ {
/*     */   private Marshaller marshaller;
/*     */   private Unmarshaller unmarshaller;
/*     */ 
/*     */   public MarshallingHttpMessageConverter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MarshallingHttpMessageConverter(Marshaller marshaller)
/*     */   {
/*  72 */     Assert.notNull(marshaller, "Marshaller must not be null");
/*  73 */     this.marshaller = marshaller;
/*  74 */     if ((marshaller instanceof Unmarshaller))
/*  75 */       this.unmarshaller = ((Unmarshaller)marshaller);
/*     */   }
/*     */ 
/*     */   public MarshallingHttpMessageConverter(Marshaller marshaller, Unmarshaller unmarshaller)
/*     */   {
/*  86 */     Assert.notNull(marshaller, "Marshaller must not be null");
/*  87 */     Assert.notNull(unmarshaller, "Unmarshaller must not be null");
/*  88 */     this.marshaller = marshaller;
/*  89 */     this.unmarshaller = unmarshaller;
/*     */   }
/*     */ 
/*     */   public void setMarshaller(Marshaller marshaller)
/*     */   {
/*  97 */     this.marshaller = marshaller;
/*     */   }
/*     */ 
/*     */   public void setUnmarshaller(Unmarshaller unmarshaller)
/*     */   {
/* 104 */     this.unmarshaller = unmarshaller;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 109 */     return (canRead(mediaType)) && (this.unmarshaller != null) && (this.unmarshaller.supports(clazz));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 114 */     return (canWrite(mediaType)) && (this.marshaller != null) && (this.marshaller.supports(clazz));
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 120 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readFromSource(Class<?> clazz, HttpHeaders headers, Source source) throws IOException
/*     */   {
/* 125 */     Assert.notNull(this.unmarshaller, "Property 'unmarshaller' is required");
/*     */     try {
/* 127 */       Object result = this.unmarshaller.unmarshal(source);
/* 128 */       if (!clazz.isInstance(result)) {
/* 129 */         throw new TypeMismatchException(result, clazz);
/*     */       }
/* 131 */       return result;
/*     */     }
/*     */     catch (UnmarshallingFailureException ex) {
/* 134 */       throw new HttpMessageNotReadableException("Could not read [" + clazz + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeToResult(Object o, HttpHeaders headers, Result result) throws IOException
/*     */   {
/* 140 */     Assert.notNull(this.marshaller, "Property 'marshaller' is required");
/*     */     try {
/* 142 */       this.marshaller.marshal(o, result);
/*     */     }
/*     */     catch (MarshallingFailureException ex) {
/* 145 */       throw new HttpMessageNotWritableException("Could not write [" + o + "]", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.MarshallingHttpMessageConverter
 * JD-Core Version:    0.6.2
 */