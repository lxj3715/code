/*    */ package org.springframework.http.converter.xml;
/*    */ 
/*    */ import org.springframework.http.converter.FormHttpMessageConverter;
/*    */ 
/*    */ @Deprecated
/*    */ public class XmlAwareFormHttpMessageConverter extends FormHttpMessageConverter
/*    */ {
/*    */   public XmlAwareFormHttpMessageConverter()
/*    */   {
/* 37 */     addPartConverter(new SourceHttpMessageConverter());
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.XmlAwareFormHttpMessageConverter
 * JD-Core Version:    0.6.2
 */