package org.springframework.http.server;

public abstract interface ServerHttpAsyncRequestControl
{
  public abstract void start();

  public abstract void start(long paramLong);

  public abstract boolean isStarted();

  public abstract void complete();

  public abstract boolean isCompleted();
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServerHttpAsyncRequestControl
 * JD-Core Version:    0.6.2
 */