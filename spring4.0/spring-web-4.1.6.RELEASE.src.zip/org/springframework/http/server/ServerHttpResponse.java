package org.springframework.http.server;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.HttpStatus;

public abstract interface ServerHttpResponse extends HttpOutputMessage, Flushable, Closeable
{
  public abstract void setStatusCode(HttpStatus paramHttpStatus);

  public abstract void flush()
    throws IOException;

  public abstract void close();
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServerHttpResponse
 * JD-Core Version:    0.6.2
 */