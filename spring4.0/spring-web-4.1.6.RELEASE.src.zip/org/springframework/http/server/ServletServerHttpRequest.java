/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ServletServerHttpRequest
/*     */   implements ServerHttpRequest
/*     */ {
/*     */   protected static final String FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
/*     */   protected static final String FORM_CHARSET = "UTF-8";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private final HttpServletRequest servletRequest;
/*     */   private HttpHeaders headers;
/*     */   private ServerHttpAsyncRequestControl asyncRequestControl;
/*     */ 
/*     */   public ServletServerHttpRequest(HttpServletRequest servletRequest)
/*     */   {
/*  73 */     Assert.notNull(servletRequest, "HttpServletRequest must not be null");
/*  74 */     this.servletRequest = servletRequest;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getServletRequest()
/*     */   {
/*  82 */     return this.servletRequest;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  87 */     return HttpMethod.valueOf(this.servletRequest.getMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI()
/*     */   {
/*     */     try
/*     */     {
/*  95 */       return new URI(this.servletRequest.getScheme(), null, this.servletRequest.getServerName(), this.servletRequest
/*  94 */         .getServerPort(), this.servletRequest.getRequestURI(), this.servletRequest
/*  95 */         .getQueryString(), null);
/*     */     }
/*     */     catch (URISyntaxException ex) {
/*  98 */       throw new IllegalStateException("Could not get HttpServletRequest URI: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders getHeaders()
/*     */   {
/* 104 */     if (this.headers == null) {
/* 105 */       this.headers = new HttpHeaders();
/* 106 */       for (Enumeration headerNames = this.servletRequest.getHeaderNames(); headerNames.hasMoreElements(); ) {
/* 107 */         String headerName = (String)headerNames.nextElement();
/* 108 */         Enumeration headerValues = this.servletRequest.getHeaders(headerName);
/* 109 */         while (headerValues.hasMoreElements()) {
/* 110 */           String headerValue = (String)headerValues.nextElement();
/* 111 */           this.headers.add(headerName, headerValue);
/*     */         }
/*     */       }
/*     */ 
/* 115 */       MediaType contentType = this.headers.getContentType();
/* 116 */       if (contentType == null) {
/* 117 */         String requestContentType = this.servletRequest.getContentType();
/* 118 */         if (StringUtils.hasLength(requestContentType)) {
/* 119 */           contentType = MediaType.parseMediaType(requestContentType);
/* 120 */           this.headers.setContentType(contentType);
/*     */         }
/*     */       }
/* 123 */       if ((contentType != null) && (contentType.getCharSet() == null)) {
/* 124 */         String requestEncoding = this.servletRequest.getCharacterEncoding();
/* 125 */         if (StringUtils.hasLength(requestEncoding)) {
/* 126 */           Charset charSet = Charset.forName(requestEncoding);
/* 127 */           Map params = new LinkedCaseInsensitiveMap();
/* 128 */           params.putAll(contentType.getParameters());
/* 129 */           params.put("charset", charSet.toString());
/* 130 */           MediaType newContentType = new MediaType(contentType.getType(), contentType.getSubtype(), params);
/* 131 */           this.headers.setContentType(newContentType);
/*     */         }
/*     */       }
/* 134 */       if (this.headers.getContentLength() == -1L) {
/* 135 */         int requestContentLength = this.servletRequest.getContentLength();
/* 136 */         if (requestContentLength != -1) {
/* 137 */           this.headers.setContentLength(requestContentLength);
/*     */         }
/*     */       }
/*     */     }
/* 141 */     return this.headers;
/*     */   }
/*     */ 
/*     */   public Principal getPrincipal()
/*     */   {
/* 146 */     return this.servletRequest.getUserPrincipal();
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getLocalAddress()
/*     */   {
/* 151 */     return new InetSocketAddress(this.servletRequest.getLocalName(), this.servletRequest.getLocalPort());
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getRemoteAddress()
/*     */   {
/* 156 */     return new InetSocketAddress(this.servletRequest.getRemoteHost(), this.servletRequest.getRemotePort());
/*     */   }
/*     */ 
/*     */   public InputStream getBody() throws IOException
/*     */   {
/* 161 */     if (isFormPost(this.servletRequest)) {
/* 162 */       return getBodyFromServletRequestParameters(this.servletRequest);
/*     */     }
/*     */ 
/* 165 */     return this.servletRequest.getInputStream();
/*     */   }
/*     */ 
/*     */   private boolean isFormPost(HttpServletRequest request)
/*     */   {
/* 171 */     return (request.getContentType() != null) && (request.getContentType().contains("application/x-www-form-urlencoded")) && 
/* 171 */       ("POST"
/* 171 */       .equalsIgnoreCase(request
/* 171 */       .getMethod()));
/*     */   }
/*     */ 
/*     */   private InputStream getBodyFromServletRequestParameters(HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/* 181 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(1024);
/* 182 */     Writer writer = new OutputStreamWriter(bos, "UTF-8");
/*     */ 
/* 184 */     Map form = request.getParameterMap();
/* 185 */     for (Iterator nameIterator = form.keySet().iterator(); nameIterator.hasNext(); ) {
/* 186 */       String name = (String)nameIterator.next();
/* 187 */       List values = Arrays.asList((Object[])form.get(name));
/* 188 */       for (Iterator valueIterator = values.iterator(); valueIterator.hasNext(); ) {
/* 189 */         String value = (String)valueIterator.next();
/* 190 */         writer.write(URLEncoder.encode(name, "UTF-8"));
/* 191 */         if (value != null) {
/* 192 */           writer.write(61);
/* 193 */           writer.write(URLEncoder.encode(value, "UTF-8"));
/* 194 */           if (valueIterator.hasNext()) {
/* 195 */             writer.write(38);
/*     */           }
/*     */         }
/*     */       }
/* 199 */       if (nameIterator.hasNext()) {
/* 200 */         writer.append('&');
/*     */       }
/*     */     }
/* 203 */     writer.flush();
/*     */ 
/* 205 */     return new ByteArrayInputStream(bos.toByteArray());
/*     */   }
/*     */ 
/*     */   public ServerHttpAsyncRequestControl getAsyncRequestControl(ServerHttpResponse response)
/*     */   {
/* 210 */     if (this.asyncRequestControl == null) {
/* 211 */       Assert.isInstanceOf(ServletServerHttpResponse.class, response);
/* 212 */       ServletServerHttpResponse servletServerResponse = (ServletServerHttpResponse)response;
/* 213 */       this.asyncRequestControl = new ServletServerHttpAsyncRequestControl(this, servletServerResponse);
/*     */     }
/* 215 */     return this.asyncRequestControl;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServletServerHttpRequest
 * JD-Core Version:    0.6.2
 */