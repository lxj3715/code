/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class ServletServerHttpResponse
/*     */   implements ServerHttpResponse
/*     */ {
/*  43 */   private static final boolean servlet3Present = ClassUtils.hasMethod(HttpServletResponse.class, "getHeader", new Class[] { String.class })
/*  43 */     ;
/*     */   private final HttpServletResponse servletResponse;
/*     */   private final HttpHeaders headers;
/*  50 */   private boolean headersWritten = false;
/*     */ 
/*     */   public ServletServerHttpResponse(HttpServletResponse servletResponse)
/*     */   {
/*  58 */     Assert.notNull(servletResponse, "'servletResponse' must not be null");
/*  59 */     this.servletResponse = servletResponse;
/*  60 */     this.headers = (servlet3Present ? new ServletResponseHttpHeaders(null) : new HttpHeaders());
/*     */   }
/*     */ 
/*     */   public HttpServletResponse getServletResponse()
/*     */   {
/*  68 */     return this.servletResponse;
/*     */   }
/*     */ 
/*     */   public void setStatusCode(HttpStatus status)
/*     */   {
/*  73 */     this.servletResponse.setStatus(status.value());
/*     */   }
/*     */ 
/*     */   public HttpHeaders getHeaders()
/*     */   {
/*  78 */     return this.headersWritten ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*     */   }
/*     */ 
/*     */   public OutputStream getBody() throws IOException
/*     */   {
/*  83 */     writeHeaders();
/*  84 */     return this.servletResponse.getOutputStream();
/*     */   }
/*     */ 
/*     */   public void flush() throws IOException
/*     */   {
/*  89 */     writeHeaders();
/*  90 */     this.servletResponse.flushBuffer();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*  95 */     writeHeaders();
/*     */   }
/*     */ 
/*     */   private void writeHeaders() {
/*  99 */     if (!this.headersWritten) {
/* 100 */       for (Map.Entry entry : this.headers.entrySet()) {
/* 101 */         headerName = (String)entry.getKey();
/* 102 */         for (String headerValue : (List)entry.getValue())
/* 103 */           this.servletResponse.addHeader(headerName, headerValue);
/*     */       }
/*     */       String headerName;
/* 107 */       if ((this.servletResponse.getContentType() == null) && (this.headers.getContentType() != null)) {
/* 108 */         this.servletResponse.setContentType(this.headers.getContentType().toString());
/*     */       }
/* 110 */       if ((this.servletResponse.getCharacterEncoding() == null) && (this.headers.getContentType() != null) && 
/* 111 */         (this.headers
/* 111 */         .getContentType().getCharSet() != null)) {
/* 112 */         this.servletResponse.setCharacterEncoding(this.headers.getContentType().getCharSet().name());
/*     */       }
/* 114 */       this.headersWritten = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ServletResponseHttpHeaders extends HttpHeaders
/*     */   {
/*     */     private static final long serialVersionUID = 3410708522401046302L;
/*     */ 
/*     */     private ServletResponseHttpHeaders()
/*     */     {
/*     */     }
/*     */ 
/*     */     public String getFirst(String headerName)
/*     */     {
/* 136 */       String value = ServletServerHttpResponse.this.servletResponse.getHeader(headerName);
/* 137 */       if (value != null) {
/* 138 */         return value;
/*     */       }
/*     */ 
/* 141 */       return super.getFirst(headerName);
/*     */     }
/*     */ 
/*     */     public List<String> get(Object key)
/*     */     {
/* 147 */       Assert.isInstanceOf(String.class, key, "Key must be a String-based header name");
/*     */ 
/* 149 */       Collection values1 = ServletServerHttpResponse.this.servletResponse.getHeaders((String)key);
/* 150 */       boolean isEmpty1 = CollectionUtils.isEmpty(values1);
/*     */ 
/* 152 */       List values2 = super.get(key);
/* 153 */       boolean isEmpty2 = CollectionUtils.isEmpty(values2);
/*     */ 
/* 155 */       if ((isEmpty1) && (isEmpty2)) {
/* 156 */         return null;
/*     */       }
/*     */ 
/* 159 */       List values = new ArrayList();
/* 160 */       if (!isEmpty1) {
/* 161 */         values.addAll(values1);
/*     */       }
/* 163 */       if (!isEmpty2) {
/* 164 */         values.addAll(values2);
/*     */       }
/* 166 */       return values;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServletServerHttpResponse
 * JD-Core Version:    0.6.2
 */