/*    */ package org.springframework.remoting.caucho;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.web.HttpRequestHandler;
/*    */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*    */ import org.springframework.web.util.NestedServletException;
/*    */ 
/*    */ @Deprecated
/*    */ public class BurlapServiceExporter extends BurlapExporter
/*    */   implements HttpRequestHandler
/*    */ {
/*    */   public void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 63 */     if (!"POST".equals(request.getMethod())) {
/* 64 */       throw new HttpRequestMethodNotSupportedException(request.getMethod(), new String[] { "POST" }, "BurlapServiceExporter only supports POST requests");
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 69 */       invoke(request.getInputStream(), response.getOutputStream());
/*    */     }
/*    */     catch (Throwable ex) {
/* 72 */       throw new NestedServletException("Burlap skeleton invocation failed", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.BurlapServiceExporter
 * JD-Core Version:    0.6.2
 */