/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Locale;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.NoHttpResponseException;
/*     */ import org.apache.http.StatusLine;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.client.config.RequestConfig.Builder;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.config.Registry;
/*     */ import org.apache.http.config.RegistryBuilder;
/*     */ import org.apache.http.conn.socket.PlainConnectionSocketFactory;
/*     */ import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
/*     */ import org.apache.http.entity.ByteArrayEntity;
/*     */ import org.apache.http.impl.client.AbstractHttpClient;
/*     */ import org.apache.http.impl.client.HttpClientBuilder;
/*     */ import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class HttpComponentsHttpInvokerRequestExecutor extends AbstractHttpInvokerRequestExecutor
/*     */ {
/*     */   private static final int DEFAULT_MAX_TOTAL_CONNECTIONS = 100;
/*     */   private static final int DEFAULT_MAX_CONNECTIONS_PER_ROUTE = 5;
/*     */   private static final int DEFAULT_READ_TIMEOUT_MILLISECONDS = 60000;
/*     */   private HttpClient httpClient;
/*     */   private RequestConfig requestConfig;
/*     */ 
/*     */   public HttpComponentsHttpInvokerRequestExecutor()
/*     */   {
/*  80 */     this(createDefaultHttpClient(), RequestConfig.custom()
/*  81 */       .setSocketTimeout(60000)
/*  81 */       .build());
/*     */   }
/*     */ 
/*     */   private static HttpClient createDefaultHttpClient()
/*     */   {
/*  88 */     Registry schemeRegistry = RegistryBuilder.create()
/*  86 */       .register("http", 
/*  86 */       PlainConnectionSocketFactory.getSocketFactory())
/*  87 */       .register("https", 
/*  87 */       SSLConnectionSocketFactory.getSocketFactory())
/*  88 */       .build();
/*     */ 
/*  90 */     PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(schemeRegistry);
/*     */ 
/*  92 */     connectionManager.setMaxTotal(100);
/*  93 */     connectionManager.setDefaultMaxPerRoute(5);
/*     */ 
/*  95 */     return HttpClientBuilder.create().setConnectionManager(connectionManager).build();
/*     */   }
/*     */ 
/*     */   public HttpComponentsHttpInvokerRequestExecutor(HttpClient httpClient)
/*     */   {
/* 104 */     this(httpClient, null);
/*     */   }
/*     */ 
/*     */   private HttpComponentsHttpInvokerRequestExecutor(HttpClient httpClient, RequestConfig requestConfig) {
/* 108 */     this.httpClient = httpClient;
/* 109 */     this.requestConfig = requestConfig;
/*     */   }
/*     */ 
/*     */   public void setHttpClient(HttpClient httpClient)
/*     */   {
/* 116 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public HttpClient getHttpClient()
/*     */   {
/* 123 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int timeout)
/*     */   {
/* 135 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 136 */     this.requestConfig = cloneRequestConfig()
/* 137 */       .setConnectTimeout(timeout)
/* 137 */       .build();
/* 138 */     setLegacyConnectionTimeout(getHttpClient(), timeout);
/*     */   }
/*     */ 
/*     */   private void setLegacyConnectionTimeout(HttpClient client, int timeout)
/*     */   {
/* 157 */     if (AbstractHttpClient.class.isInstance(client))
/* 158 */       client.getParams().setIntParameter("http.connection.timeout", timeout);
/*     */   }
/*     */ 
/*     */   public void setConnectionRequestTimeout(int connectionRequestTimeout)
/*     */   {
/* 173 */     this.requestConfig = cloneRequestConfig()
/* 174 */       .setConnectionRequestTimeout(connectionRequestTimeout)
/* 174 */       .build();
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int timeout)
/*     */   {
/* 187 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 188 */     this.requestConfig = cloneRequestConfig()
/* 189 */       .setSocketTimeout(timeout)
/* 189 */       .build();
/* 190 */     setLegacySocketTimeout(getHttpClient(), timeout);
/*     */   }
/*     */ 
/*     */   private void setLegacySocketTimeout(HttpClient client, int timeout)
/*     */   {
/* 202 */     if (AbstractHttpClient.class.isInstance(client))
/* 203 */       client.getParams().setIntParameter("http.socket.timeout", timeout);
/*     */   }
/*     */ 
/*     */   private RequestConfig.Builder cloneRequestConfig()
/*     */   {
/* 209 */     return this.requestConfig != null ? RequestConfig.copy(this.requestConfig) : RequestConfig.custom();
/*     */   }
/*     */ 
/*     */   protected RemoteInvocationResult doExecuteRequest(HttpInvokerClientConfiguration config, ByteArrayOutputStream baos)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 227 */     HttpPost postMethod = createHttpPost(config);
/* 228 */     setRequestBody(config, postMethod, baos);
/*     */     try {
/* 230 */       HttpResponse response = executeHttpPost(config, getHttpClient(), postMethod);
/* 231 */       validateResponse(config, response);
/* 232 */       InputStream responseBody = getResponseBody(config, response);
/* 233 */       return readRemoteInvocationResult(responseBody, config.getCodebaseUrl());
/*     */     }
/*     */     finally {
/* 236 */       postMethod.releaseConnection();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected HttpPost createHttpPost(HttpInvokerClientConfiguration config)
/*     */     throws IOException
/*     */   {
/* 250 */     HttpPost httpPost = new HttpPost(config.getServiceUrl());
/* 251 */     RequestConfig requestConfig = createRequestConfig(config);
/* 252 */     if (requestConfig != null) {
/* 253 */       httpPost.setConfig(requestConfig);
/*     */     }
/* 255 */     LocaleContext localeContext = LocaleContextHolder.getLocaleContext();
/* 256 */     if (localeContext != null) {
/* 257 */       Locale locale = localeContext.getLocale();
/* 258 */       if (locale != null) {
/* 259 */         httpPost.addHeader("Accept-Language", StringUtils.toLanguageTag(locale));
/*     */       }
/*     */     }
/* 262 */     if (isAcceptGzipEncoding()) {
/* 263 */       httpPost.addHeader("Accept-Encoding", "gzip");
/*     */     }
/* 265 */     return httpPost;
/*     */   }
/*     */ 
/*     */   protected RequestConfig createRequestConfig(HttpInvokerClientConfiguration config)
/*     */   {
/* 277 */     return this.requestConfig != null ? this.requestConfig : null;
/*     */   }
/*     */ 
/*     */   protected void setRequestBody(HttpInvokerClientConfiguration config, HttpPost httpPost, ByteArrayOutputStream baos)
/*     */     throws IOException
/*     */   {
/* 295 */     ByteArrayEntity entity = new ByteArrayEntity(baos.toByteArray());
/* 296 */     entity.setContentType(getContentType());
/* 297 */     httpPost.setEntity(entity);
/*     */   }
/*     */ 
/*     */   protected HttpResponse executeHttpPost(HttpInvokerClientConfiguration config, HttpClient httpClient, HttpPost httpPost)
/*     */     throws IOException
/*     */   {
/* 312 */     return httpClient.execute(httpPost);
/*     */   }
/*     */ 
/*     */   protected void validateResponse(HttpInvokerClientConfiguration config, HttpResponse response)
/*     */     throws IOException
/*     */   {
/* 327 */     StatusLine status = response.getStatusLine();
/* 328 */     if (status.getStatusCode() >= 300)
/*     */     {
/* 331 */       throw new NoHttpResponseException("Did not receive successful HTTP response: status code = " + status
/* 330 */         .getStatusCode() + ", status message = [" + status
/* 331 */         .getReasonPhrase() + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected InputStream getResponseBody(HttpInvokerClientConfiguration config, HttpResponse httpResponse)
/*     */     throws IOException
/*     */   {
/* 350 */     if (isGzipResponse(httpResponse)) {
/* 351 */       return new GZIPInputStream(httpResponse.getEntity().getContent());
/*     */     }
/*     */ 
/* 354 */     return httpResponse.getEntity().getContent();
/*     */   }
/*     */ 
/*     */   protected boolean isGzipResponse(HttpResponse httpResponse)
/*     */   {
/* 366 */     Header encodingHeader = httpResponse.getFirstHeader("Content-Encoding");
/*     */ 
/* 368 */     return (encodingHeader != null) && (encodingHeader.getValue() != null) && 
/* 368 */       (encodingHeader
/* 368 */       .getValue().toLowerCase().contains("gzip"));
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpComponentsHttpInvokerRequestExecutor
 * JD-Core Version:    0.6.2
 */