package org.springframework.remoting.httpinvoker;

public abstract interface HttpInvokerClientConfiguration
{
  public abstract String getServiceUrl();

  public abstract String getCodebaseUrl();
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpInvokerClientConfiguration
 * JD-Core Version:    0.6.2
 */