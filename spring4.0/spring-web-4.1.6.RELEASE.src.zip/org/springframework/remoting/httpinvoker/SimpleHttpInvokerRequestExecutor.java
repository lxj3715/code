/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Locale;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class SimpleHttpInvokerRequestExecutor extends AbstractHttpInvokerRequestExecutor
/*     */ {
/*  49 */   private int connectTimeout = -1;
/*     */ 
/*  51 */   private int readTimeout = -1;
/*     */ 
/*     */   public void setConnectTimeout(int connectTimeout)
/*     */   {
/*  61 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int readTimeout)
/*     */   {
/*  71 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */   protected RemoteInvocationResult doExecuteRequest(HttpInvokerClientConfiguration config, ByteArrayOutputStream baos)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  90 */     HttpURLConnection con = openConnection(config);
/*  91 */     prepareConnection(con, baos.size());
/*  92 */     writeRequestBody(config, con, baos);
/*  93 */     validateResponse(config, con);
/*  94 */     InputStream responseBody = readResponseBody(config, con);
/*     */ 
/*  96 */     return readRemoteInvocationResult(responseBody, config.getCodebaseUrl());
/*     */   }
/*     */ 
/*     */   protected HttpURLConnection openConnection(HttpInvokerClientConfiguration config)
/*     */     throws IOException
/*     */   {
/* 108 */     URLConnection con = new URL(config.getServiceUrl()).openConnection();
/* 109 */     if (!(con instanceof HttpURLConnection)) {
/* 110 */       throw new IOException("Service URL [" + config.getServiceUrl() + "] is not an HTTP URL");
/*     */     }
/* 112 */     return (HttpURLConnection)con;
/*     */   }
/*     */ 
/*     */   protected void prepareConnection(HttpURLConnection connection, int contentLength)
/*     */     throws IOException
/*     */   {
/* 127 */     if (this.connectTimeout >= 0) {
/* 128 */       connection.setConnectTimeout(this.connectTimeout);
/*     */     }
/* 130 */     if (this.readTimeout >= 0) {
/* 131 */       connection.setReadTimeout(this.readTimeout);
/*     */     }
/* 133 */     connection.setDoOutput(true);
/* 134 */     connection.setRequestMethod("POST");
/* 135 */     connection.setRequestProperty("Content-Type", getContentType());
/* 136 */     connection.setRequestProperty("Content-Length", Integer.toString(contentLength));
/*     */ 
/* 138 */     LocaleContext localeContext = LocaleContextHolder.getLocaleContext();
/* 139 */     if (localeContext != null) {
/* 140 */       Locale locale = localeContext.getLocale();
/* 141 */       if (locale != null) {
/* 142 */         connection.setRequestProperty("Accept-Language", StringUtils.toLanguageTag(locale));
/*     */       }
/*     */     }
/* 145 */     if (isAcceptGzipEncoding())
/* 146 */       connection.setRequestProperty("Accept-Encoding", "gzip");
/*     */   }
/*     */ 
/*     */   protected void writeRequestBody(HttpInvokerClientConfiguration config, HttpURLConnection con, ByteArrayOutputStream baos)
/*     */     throws IOException
/*     */   {
/* 167 */     baos.writeTo(con.getOutputStream());
/*     */   }
/*     */ 
/*     */   protected void validateResponse(HttpInvokerClientConfiguration config, HttpURLConnection con)
/*     */     throws IOException
/*     */   {
/* 183 */     if (con.getResponseCode() >= 300)
/*     */     {
/* 186 */       throw new IOException("Did not receive successful HTTP response: status code = " + con
/* 185 */         .getResponseCode() + ", status message = [" + con
/* 186 */         .getResponseMessage() + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected InputStream readResponseBody(HttpInvokerClientConfiguration config, HttpURLConnection con)
/*     */     throws IOException
/*     */   {
/* 209 */     if (isGzipResponse(con))
/*     */     {
/* 211 */       return new GZIPInputStream(con.getInputStream());
/*     */     }
/*     */ 
/* 215 */     return con.getInputStream();
/*     */   }
/*     */ 
/*     */   protected boolean isGzipResponse(HttpURLConnection con)
/*     */   {
/* 226 */     String encodingHeader = con.getHeaderField("Content-Encoding");
/* 227 */     return (encodingHeader != null) && (encodingHeader.toLowerCase().contains("gzip"));
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.SimpleHttpInvokerRequestExecutor
 * JD-Core Version:    0.6.2
 */