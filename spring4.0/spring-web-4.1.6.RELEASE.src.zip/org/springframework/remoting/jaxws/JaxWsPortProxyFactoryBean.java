/*    */ package org.springframework.remoting.jaxws;
/*    */ 
/*    */ import javax.xml.ws.BindingProvider;
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ 
/*    */ public class JaxWsPortProxyFactoryBean extends JaxWsPortClientInterceptor
/*    */   implements FactoryBean<Object>
/*    */ {
/*    */   private Object serviceProxy;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 42 */     super.afterPropertiesSet();
/*    */ 
/* 45 */     ProxyFactory pf = new ProxyFactory();
/* 46 */     pf.addInterface(getServiceInterface());
/* 47 */     pf.addInterface(BindingProvider.class);
/* 48 */     pf.addAdvice(this);
/* 49 */     this.serviceProxy = pf.getProxy(getBeanClassLoader());
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 55 */     return this.serviceProxy;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType()
/*    */   {
/* 60 */     return getServiceInterface();
/*    */   }
/*    */ 
/*    */   public boolean isSingleton()
/*    */   {
/* 65 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.JaxWsPortProxyFactoryBean
 * JD-Core Version:    0.6.2
 */