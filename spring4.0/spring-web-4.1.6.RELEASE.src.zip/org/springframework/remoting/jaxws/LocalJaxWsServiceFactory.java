/*     */ package org.springframework.remoting.jaxws;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.concurrent.Executor;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ import javax.xml.ws.handler.HandlerResolver;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.UsesJava7;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class LocalJaxWsServiceFactory
/*     */ {
/*     */   private URL wsdlDocumentUrl;
/*     */   private String namespaceUri;
/*     */   private String serviceName;
/*     */   private WebServiceFeature[] serviceFeatures;
/*     */   private Executor executor;
/*     */   private HandlerResolver handlerResolver;
/*     */ 
/*     */   public void setWsdlDocumentUrl(URL wsdlDocumentUrl)
/*     */   {
/*  65 */     this.wsdlDocumentUrl = wsdlDocumentUrl;
/*     */   }
/*     */ 
/*     */   public void setWsdlDocumentResource(Resource wsdlDocumentResource)
/*     */     throws IOException
/*     */   {
/*  74 */     Assert.notNull(wsdlDocumentResource, "WSDL Resource must not be null.");
/*  75 */     this.wsdlDocumentUrl = wsdlDocumentResource.getURL();
/*     */   }
/*     */ 
/*     */   public URL getWsdlDocumentUrl()
/*     */   {
/*  82 */     return this.wsdlDocumentUrl;
/*     */   }
/*     */ 
/*     */   public void setNamespaceUri(String namespaceUri)
/*     */   {
/*  90 */     this.namespaceUri = (namespaceUri != null ? namespaceUri.trim() : null);
/*     */   }
/*     */ 
/*     */   public String getNamespaceUri()
/*     */   {
/*  97 */     return this.namespaceUri;
/*     */   }
/*     */ 
/*     */   public void setServiceName(String serviceName)
/*     */   {
/* 105 */     this.serviceName = serviceName;
/*     */   }
/*     */ 
/*     */   public String getServiceName()
/*     */   {
/* 112 */     return this.serviceName;
/*     */   }
/*     */ 
/*     */   public void setServiceFeatures(WebServiceFeature[] serviceFeatures)
/*     */   {
/* 123 */     this.serviceFeatures = serviceFeatures;
/*     */   }
/*     */ 
/*     */   public void setExecutor(Executor executor)
/*     */   {
/* 132 */     this.executor = executor;
/*     */   }
/*     */ 
/*     */   public void setHandlerResolver(HandlerResolver handlerResolver)
/*     */   {
/* 141 */     this.handlerResolver = handlerResolver;
/*     */   }
/*     */ 
/*     */   @UsesJava7
/*     */   public Service createJaxWsService()
/*     */   {
/* 152 */     Assert.notNull(this.serviceName, "No service name specified");
/*     */     Service service;
/*     */     Service service;
/* 155 */     if (this.serviceFeatures != null)
/*     */     {
/* 158 */       service = this.wsdlDocumentUrl != null ? 
/* 157 */         Service.create(this.wsdlDocumentUrl, 
/* 157 */         getQName(this.serviceName), 
/* 157 */         this.serviceFeatures) : 
/* 158 */         Service.create(getQName(this.serviceName), 
/* 158 */         this.serviceFeatures);
/*     */     }
/*     */     else
/*     */     {
/* 163 */       service = this.wsdlDocumentUrl != null ? 
/* 162 */         Service.create(this.wsdlDocumentUrl, 
/* 162 */         getQName(this.serviceName)) : 
/* 163 */         Service.create(getQName(this.serviceName));
/*     */     }
/*     */ 
/* 166 */     if (this.executor != null) {
/* 167 */       service.setExecutor(this.executor);
/*     */     }
/* 169 */     if (this.handlerResolver != null) {
/* 170 */       service.setHandlerResolver(this.handlerResolver);
/*     */     }
/*     */ 
/* 173 */     return service;
/*     */   }
/*     */ 
/*     */   protected QName getQName(String name)
/*     */   {
/* 182 */     return getNamespaceUri() != null ? new QName(getNamespaceUri(), name) : new QName(name);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.LocalJaxWsServiceFactory
 * JD-Core Version:    0.6.2
 */