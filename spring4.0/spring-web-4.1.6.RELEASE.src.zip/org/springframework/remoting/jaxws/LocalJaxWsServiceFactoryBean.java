/*    */ package org.springframework.remoting.jaxws;
/*    */ 
/*    */ import javax.xml.ws.Service;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public class LocalJaxWsServiceFactoryBean extends LocalJaxWsServiceFactory
/*    */   implements FactoryBean<Service>, InitializingBean
/*    */ {
/*    */   private Service service;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 46 */     this.service = createJaxWsService();
/*    */   }
/*    */ 
/*    */   public Service getObject()
/*    */   {
/* 51 */     return this.service;
/*    */   }
/*    */ 
/*    */   public Class<? extends Service> getObjectType()
/*    */   {
/* 56 */     return this.service != null ? this.service.getClass() : Service.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton()
/*    */   {
/* 61 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.LocalJaxWsServiceFactoryBean
 * JD-Core Version:    0.6.2
 */