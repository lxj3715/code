/*    */ package org.springframework.web;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.servlet.ServletException;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ public abstract class HttpMediaTypeException extends ServletException
/*    */ {
/*    */   private final List<MediaType> supportedMediaTypes;
/*    */ 
/*    */   protected HttpMediaTypeException(String message)
/*    */   {
/* 42 */     super(message);
/* 43 */     this.supportedMediaTypes = Collections.emptyList();
/*    */   }
/*    */ 
/*    */   protected HttpMediaTypeException(String message, List<MediaType> supportedMediaTypes)
/*    */   {
/* 51 */     super(message);
/* 52 */     this.supportedMediaTypes = Collections.unmodifiableList(supportedMediaTypes);
/*    */   }
/*    */ 
/*    */   public List<MediaType> getSupportedMediaTypes()
/*    */   {
/* 60 */     return this.supportedMediaTypes;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.HttpMediaTypeException
 * JD-Core Version:    0.6.2
 */