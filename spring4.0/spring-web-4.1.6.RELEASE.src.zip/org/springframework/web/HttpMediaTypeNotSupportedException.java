/*    */ package org.springframework.web;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ public class HttpMediaTypeNotSupportedException extends HttpMediaTypeException
/*    */ {
/*    */   private final MediaType contentType;
/*    */ 
/*    */   public HttpMediaTypeNotSupportedException(String message)
/*    */   {
/* 41 */     super(message);
/* 42 */     this.contentType = null;
/*    */   }
/*    */ 
/*    */   public HttpMediaTypeNotSupportedException(MediaType contentType, List<MediaType> supportedMediaTypes)
/*    */   {
/* 51 */     this(contentType, supportedMediaTypes, "Content type '" + contentType + "' not supported");
/*    */   }
/*    */ 
/*    */   public HttpMediaTypeNotSupportedException(MediaType contentType, List<MediaType> supportedMediaTypes, String msg)
/*    */   {
/* 61 */     super(msg, supportedMediaTypes);
/* 62 */     this.contentType = contentType;
/*    */   }
/*    */ 
/*    */   public MediaType getContentType()
/*    */   {
/* 70 */     return this.contentType;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.HttpMediaTypeNotSupportedException
 * JD-Core Version:    0.6.2
 */