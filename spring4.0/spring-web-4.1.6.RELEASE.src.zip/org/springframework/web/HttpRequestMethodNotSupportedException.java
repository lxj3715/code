/*     */ package org.springframework.web;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.http.HttpMethod;
/*     */ 
/*     */ public class HttpRequestMethodNotSupportedException extends ServletException
/*     */ {
/*     */   private String method;
/*     */   private String[] supportedMethods;
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method)
/*     */   {
/*  47 */     this(method, (String[])null);
/*     */   }
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method, String[] supportedMethods)
/*     */   {
/*  56 */     this(method, supportedMethods, "Request method '" + method + "' not supported");
/*     */   }
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method, Collection<String> supportedMethods)
/*     */   {
/*  65 */     this(method, (String[])supportedMethods.toArray(new String[supportedMethods.size()]));
/*     */   }
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method, String msg)
/*     */   {
/*  74 */     this(method, null, msg);
/*     */   }
/*     */ 
/*     */   public HttpRequestMethodNotSupportedException(String method, String[] supportedMethods, String msg)
/*     */   {
/*  84 */     super(msg);
/*  85 */     this.method = method;
/*  86 */     this.supportedMethods = supportedMethods;
/*     */   }
/*     */ 
/*     */   public String getMethod()
/*     */   {
/*  94 */     return this.method;
/*     */   }
/*     */ 
/*     */   public String[] getSupportedMethods()
/*     */   {
/* 101 */     return this.supportedMethods;
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> getSupportedHttpMethods()
/*     */   {
/* 108 */     Set supportedMethods = new LinkedHashSet();
/* 109 */     for (String value : this.supportedMethods) {
/* 110 */       supportedMethods.add(HttpMethod.valueOf(value));
/*     */     }
/* 112 */     return Collections.unmodifiableSet(supportedMethods);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.HttpRequestMethodNotSupportedException
 * JD-Core Version:    0.6.2
 */