/*     */ package org.springframework.web;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.annotation.HandlesTypes;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ 
/*     */ @HandlesTypes({WebApplicationInitializer.class})
/*     */ public class SpringServletContainerInitializer
/*     */   implements ServletContainerInitializer
/*     */ {
/*     */   public void onStartup(Set<Class<?>> webAppInitializerClasses, ServletContext servletContext)
/*     */     throws ServletException
/*     */   {
/* 148 */     List initializers = new LinkedList();
/*     */ 
/* 150 */     if (webAppInitializerClasses != null) {
/* 151 */       for (Class waiClass : webAppInitializerClasses)
/*     */       {
/* 154 */         if ((!waiClass.isInterface()) && (!Modifier.isAbstract(waiClass.getModifiers())) && 
/* 155 */           (WebApplicationInitializer.class
/* 155 */           .isAssignableFrom(waiClass))) {
/*     */           try
/*     */           {
/* 157 */             initializers.add((WebApplicationInitializer)waiClass.newInstance());
/*     */           }
/*     */           catch (Throwable ex) {
/* 160 */             throw new ServletException("Failed to instantiate WebApplicationInitializer class", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 166 */     if (initializers.isEmpty()) {
/* 167 */       servletContext.log("No Spring WebApplicationInitializer types detected on classpath");
/* 168 */       return;
/*     */     }
/*     */ 
/* 171 */     AnnotationAwareOrderComparator.sort(initializers);
/* 172 */     servletContext.log("Spring WebApplicationInitializers detected on classpath: " + initializers);
/*     */ 
/* 174 */     for (WebApplicationInitializer initializer : initializers)
/* 175 */       initializer.onStartup(servletContext);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.SpringServletContainerInitializer
 * JD-Core Version:    0.6.2
 */