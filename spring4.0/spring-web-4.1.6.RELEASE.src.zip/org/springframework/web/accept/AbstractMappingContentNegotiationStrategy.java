/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public abstract class AbstractMappingContentNegotiationStrategy extends MappingMediaTypeFileExtensionResolver
/*    */   implements ContentNegotiationStrategy, MediaTypeFileExtensionResolver
/*    */ {
/*    */   public AbstractMappingContentNegotiationStrategy(Map<String, MediaType> mediaTypes)
/*    */   {
/* 44 */     super(mediaTypes);
/*    */   }
/*    */ 
/*    */   public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest)
/*    */     throws HttpMediaTypeNotAcceptableException
/*    */   {
/* 50 */     String key = getMediaTypeKey(webRequest);
/* 51 */     if (StringUtils.hasText(key)) {
/* 52 */       MediaType mediaType = lookupMediaType(key);
/* 53 */       if (mediaType != null) {
/* 54 */         handleMatch(key, mediaType);
/* 55 */         return Collections.singletonList(mediaType);
/*    */       }
/* 57 */       mediaType = handleNoMatch(webRequest, key);
/* 58 */       if (mediaType != null) {
/* 59 */         addMapping(key, mediaType);
/* 60 */         return Collections.singletonList(mediaType);
/*    */       }
/*    */     }
/* 63 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   protected abstract String getMediaTypeKey(NativeWebRequest paramNativeWebRequest);
/*    */ 
/*    */   protected void handleMatch(String mappingKey, MediaType mediaType)
/*    */   {
/*    */   }
/*    */ 
/*    */   protected MediaType handleNoMatch(NativeWebRequest request, String key)
/*    */     throws HttpMediaTypeNotAcceptableException
/*    */   {
/* 83 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.AbstractMappingContentNegotiationStrategy
 * JD-Core Version:    0.6.2
 */