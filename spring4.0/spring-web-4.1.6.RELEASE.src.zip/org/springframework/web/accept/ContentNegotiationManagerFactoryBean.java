/*     */ package org.springframework.web.accept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public class ContentNegotiationManagerFactoryBean
/*     */   implements FactoryBean<ContentNegotiationManager>, ServletContextAware, InitializingBean
/*     */ {
/*  50 */   private boolean favorPathExtension = true;
/*     */ 
/*  52 */   private boolean favorParameter = false;
/*     */ 
/*  54 */   private boolean ignoreAcceptHeader = false;
/*     */ 
/*  56 */   private Map<String, MediaType> mediaTypes = new HashMap();
/*     */ 
/*  58 */   private boolean ignoreUnknownPathExtensions = true;
/*     */   private Boolean useJaf;
/*  62 */   private String parameterName = "format";
/*     */   private ContentNegotiationStrategy defaultNegotiationStrategy;
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public void setFavorPathExtension(boolean favorPathExtension)
/*     */   {
/*  79 */     this.favorPathExtension = favorPathExtension;
/*     */   }
/*     */ 
/*     */   public void setMediaTypes(Properties mediaTypes)
/*     */   {
/*  91 */     if (!CollectionUtils.isEmpty(mediaTypes))
/*  92 */       for (Map.Entry entry : mediaTypes.entrySet()) {
/*  93 */         String extension = ((String)entry.getKey()).toLowerCase(Locale.ENGLISH);
/*  94 */         this.mediaTypes.put(extension, MediaType.valueOf((String)entry.getValue()));
/*     */       }
/*     */   }
/*     */ 
/*     */   public void addMediaType(String fileExtension, MediaType mediaType)
/*     */   {
/* 106 */     this.mediaTypes.put(fileExtension, mediaType);
/*     */   }
/*     */ 
/*     */   public void addMediaTypes(Map<String, MediaType> mediaTypes)
/*     */   {
/* 116 */     if (mediaTypes != null)
/* 117 */       this.mediaTypes.putAll(mediaTypes);
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnknownPathExtensions(boolean ignoreUnknownPathExtensions)
/*     */   {
/* 129 */     this.ignoreUnknownPathExtensions = ignoreUnknownPathExtensions;
/*     */   }
/*     */ 
/*     */   public void setUseJaf(boolean useJaf)
/*     */   {
/* 141 */     this.useJaf = Boolean.valueOf(useJaf);
/*     */   }
/*     */ 
/*     */   public void setFavorParameter(boolean favorParameter)
/*     */   {
/* 156 */     this.favorParameter = favorParameter;
/*     */   }
/*     */ 
/*     */   public void setParameterName(String parameterName)
/*     */   {
/* 165 */     Assert.notNull(parameterName, "parameterName is required");
/* 166 */     this.parameterName = parameterName;
/*     */   }
/*     */ 
/*     */   public void setIgnoreAcceptHeader(boolean ignoreAcceptHeader)
/*     */   {
/* 177 */     this.ignoreAcceptHeader = ignoreAcceptHeader;
/*     */   }
/*     */ 
/*     */   public void setDefaultContentType(MediaType defaultContentType)
/*     */   {
/* 188 */     this.defaultNegotiationStrategy = new FixedContentNegotiationStrategy(defaultContentType);
/*     */   }
/*     */ 
/*     */   public void setDefaultContentTypeStrategy(ContentNegotiationStrategy defaultStrategy)
/*     */   {
/* 199 */     this.defaultNegotiationStrategy = defaultStrategy;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 204 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 210 */     List strategies = new ArrayList();
/*     */ 
/* 212 */     if (this.favorPathExtension)
/*     */     {
/*     */       PathExtensionContentNegotiationStrategy strategy;
/*     */       PathExtensionContentNegotiationStrategy strategy;
/* 214 */       if (this.servletContext != null) {
/* 215 */         strategy = new ServletPathExtensionContentNegotiationStrategy(this.servletContext, this.mediaTypes);
/*     */       }
/*     */       else {
/* 218 */         strategy = new PathExtensionContentNegotiationStrategy(this.mediaTypes);
/*     */       }
/* 220 */       strategy.setIgnoreUnknownExtensions(this.ignoreUnknownPathExtensions);
/* 221 */       if (this.useJaf != null) {
/* 222 */         strategy.setUseJaf(this.useJaf.booleanValue());
/*     */       }
/* 224 */       strategies.add(strategy);
/*     */     }
/*     */ 
/* 227 */     if (this.favorParameter) {
/* 228 */       ParameterContentNegotiationStrategy strategy = new ParameterContentNegotiationStrategy(this.mediaTypes);
/* 229 */       strategy.setParameterName(this.parameterName);
/* 230 */       strategies.add(strategy);
/*     */     }
/*     */ 
/* 233 */     if (!this.ignoreAcceptHeader) {
/* 234 */       strategies.add(new HeaderContentNegotiationStrategy());
/*     */     }
/*     */ 
/* 237 */     if (this.defaultNegotiationStrategy != null) {
/* 238 */       strategies.add(this.defaultNegotiationStrategy);
/*     */     }
/*     */ 
/* 241 */     this.contentNegotiationManager = new ContentNegotiationManager(strategies);
/*     */   }
/*     */ 
/*     */   public ContentNegotiationManager getObject()
/*     */   {
/* 247 */     return this.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 252 */     return ContentNegotiationManager.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 257 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ContentNegotiationManagerFactoryBean
 * JD-Core Version:    0.6.2
 */