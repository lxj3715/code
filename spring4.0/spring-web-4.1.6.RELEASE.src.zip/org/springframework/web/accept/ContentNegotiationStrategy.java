package org.springframework.web.accept;

import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.context.request.NativeWebRequest;

public abstract interface ContentNegotiationStrategy
{
  public abstract List<MediaType> resolveMediaTypes(NativeWebRequest paramNativeWebRequest)
    throws HttpMediaTypeNotAcceptableException;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ContentNegotiationStrategy
 * JD-Core Version:    0.6.2
 */