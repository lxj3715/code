/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class FixedContentNegotiationStrategy
/*    */   implements ContentNegotiationStrategy
/*    */ {
/* 36 */   private static final Log logger = LogFactory.getLog(FixedContentNegotiationStrategy.class);
/*    */   private final MediaType defaultContentType;
/*    */ 
/*    */   public FixedContentNegotiationStrategy(MediaType defaultContentType)
/*    */   {
/* 44 */     this.defaultContentType = defaultContentType;
/*    */   }
/*    */ 
/*    */   public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest)
/*    */   {
/* 49 */     if (logger.isDebugEnabled()) {
/* 50 */       logger.debug("Requested media types is " + this.defaultContentType + " (based on default MediaType)");
/*    */     }
/* 52 */     return Collections.singletonList(this.defaultContentType);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.FixedContentNegotiationStrategy
 * JD-Core Version:    0.6.2
 */