/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.http.InvalidMediaTypeException;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class HeaderContentNegotiationStrategy
/*    */   implements ContentNegotiationStrategy
/*    */ {
/*    */   private static final String ACCEPT_HEADER = "Accept";
/*    */ 
/*    */   public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest)
/*    */     throws HttpMediaTypeNotAcceptableException
/*    */   {
/* 44 */     String acceptHeader = webRequest.getHeader("Accept");
/*    */     try {
/* 46 */       if (StringUtils.hasText(acceptHeader)) {
/* 47 */         List mediaTypes = MediaType.parseMediaTypes(acceptHeader);
/* 48 */         MediaType.sortBySpecificityAndQuality(mediaTypes);
/* 49 */         return mediaTypes;
/*    */       }
/*    */     }
/*    */     catch (InvalidMediaTypeException ex)
/*    */     {
/* 54 */       throw new HttpMediaTypeNotAcceptableException("Could not parse accept header [" + acceptHeader + "]: " + ex
/* 54 */         .getMessage());
/*    */     }
/* 56 */     return Collections.emptyList();
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.HeaderContentNegotiationStrategy
 * JD-Core Version:    0.6.2
 */