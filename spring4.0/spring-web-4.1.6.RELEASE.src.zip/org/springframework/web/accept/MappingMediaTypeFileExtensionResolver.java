/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ public class MappingMediaTypeFileExtensionResolver
/*    */   implements MediaTypeFileExtensionResolver
/*    */ {
/* 42 */   private final ConcurrentMap<String, MediaType> mediaTypes = new ConcurrentHashMap(64);
/*    */ 
/* 44 */   private final MultiValueMap<MediaType, String> fileExtensions = new LinkedMultiValueMap();
/*    */ 
/* 46 */   private final List<String> allFileExtensions = new LinkedList();
/*    */ 
/*    */   public MappingMediaTypeFileExtensionResolver(Map<String, MediaType> mediaTypes)
/*    */   {
/* 54 */     if (mediaTypes != null)
/* 55 */       for (Map.Entry entries : mediaTypes.entrySet()) {
/* 56 */         String extension = ((String)entries.getKey()).toLowerCase(Locale.ENGLISH);
/* 57 */         MediaType mediaType = (MediaType)entries.getValue();
/* 58 */         addMapping(extension, mediaType);
/*    */       }
/*    */   }
/*    */ 
/*    */   public List<String> resolveFileExtensions(MediaType mediaType)
/*    */   {
/* 70 */     List fileExtensions = (List)this.fileExtensions.get(mediaType);
/* 71 */     return fileExtensions != null ? fileExtensions : Collections.emptyList();
/*    */   }
/*    */ 
/*    */   public List<String> getAllFileExtensions()
/*    */   {
/* 76 */     return Collections.unmodifiableList(this.allFileExtensions);
/*    */   }
/*    */ 
/*    */   protected List<MediaType> getAllMediaTypes() {
/* 80 */     return new ArrayList(this.mediaTypes.values());
/*    */   }
/*    */ 
/*    */   protected MediaType lookupMediaType(String extension)
/*    */   {
/* 88 */     return (MediaType)this.mediaTypes.get(extension);
/*    */   }
/*    */ 
/*    */   protected void addMapping(String extension, MediaType mediaType)
/*    */   {
/* 95 */     MediaType previous = (MediaType)this.mediaTypes.putIfAbsent(extension, mediaType);
/* 96 */     if (previous == null) {
/* 97 */       this.fileExtensions.add(mediaType, extension);
/* 98 */       this.allFileExtensions.add(extension);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.MappingMediaTypeFileExtensionResolver
 * JD-Core Version:    0.6.2
 */