package org.springframework.web.accept;

import java.util.List;
import org.springframework.http.MediaType;

public abstract interface MediaTypeFileExtensionResolver
{
  public abstract List<String> resolveFileExtensions(MediaType paramMediaType);

  public abstract List<String> getAllFileExtensions();
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.MediaTypeFileExtensionResolver
 * JD-Core Version:    0.6.2
 */