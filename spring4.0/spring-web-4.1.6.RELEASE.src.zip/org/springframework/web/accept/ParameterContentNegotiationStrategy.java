/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class ParameterContentNegotiationStrategy extends AbstractMappingContentNegotiationStrategy
/*    */ {
/* 39 */   private static final Log logger = LogFactory.getLog(ParameterContentNegotiationStrategy.class);
/*    */ 
/* 41 */   private String parameterName = "format";
/*    */ 
/*    */   public ParameterContentNegotiationStrategy(Map<String, MediaType> mediaTypes)
/*    */   {
/* 48 */     super(mediaTypes);
/*    */   }
/*    */ 
/*    */   public void setParameterName(String parameterName)
/*    */   {
/* 56 */     Assert.notNull(parameterName, "parameterName is required");
/* 57 */     this.parameterName = parameterName;
/*    */   }
/*    */ 
/*    */   protected String getMediaTypeKey(NativeWebRequest webRequest)
/*    */   {
/* 62 */     return webRequest.getParameter(this.parameterName);
/*    */   }
/*    */ 
/*    */   protected void handleMatch(String mediaTypeKey, MediaType mediaType)
/*    */   {
/* 67 */     if (logger.isDebugEnabled())
/* 68 */       logger.debug("Requested media type is '" + mediaType + "' (based on parameter '" + this.parameterName + "'='" + mediaTypeKey + "')");
/*    */   }
/*    */ 
/*    */   protected MediaType handleNoMatch(NativeWebRequest request, String key)
/*    */     throws HttpMediaTypeNotAcceptableException
/*    */   {
/* 75 */     throw new HttpMediaTypeNotAcceptableException(getAllMediaTypes());
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ParameterContentNegotiationStrategy
 * JD-Core Version:    0.6.2
 */