/*     */ package org.springframework.web.accept;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.activation.FileTypeMap;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class PathExtensionContentNegotiationStrategy extends AbstractMappingContentNegotiationStrategy
/*     */ {
/*  56 */   private static final boolean JAF_PRESENT = ClassUtils.isPresent("javax.activation.FileTypeMap", PathExtensionContentNegotiationStrategy.class
/*  57 */     .getClassLoader());
/*     */ 
/*  59 */   private static final Log logger = LogFactory.getLog(PathExtensionContentNegotiationStrategy.class);
/*     */ 
/*  61 */   private static final UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  67 */   private boolean useJaf = JAF_PRESENT;
/*     */ 
/*  69 */   private boolean ignoreUnknownExtensions = true;
/*     */ 
/*     */   public PathExtensionContentNegotiationStrategy(Map<String, MediaType> mediaTypes)
/*     */   {
/*  77 */     super(mediaTypes);
/*     */   }
/*     */ 
/*     */   public PathExtensionContentNegotiationStrategy()
/*     */   {
/*  85 */     super(null);
/*     */   }
/*     */ 
/*     */   public void setUseJaf(boolean useJaf)
/*     */   {
/*  97 */     this.useJaf = useJaf;
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnknownExtensions(boolean ignoreUnknownExtensions)
/*     */   {
/* 108 */     this.ignoreUnknownExtensions = ignoreUnknownExtensions;
/*     */   }
/*     */ 
/*     */   protected String getMediaTypeKey(NativeWebRequest webRequest)
/*     */   {
/* 114 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 115 */     if (servletRequest == null) {
/* 116 */       logger.warn("An HttpServletRequest is required to determine the media type key");
/* 117 */       return null;
/*     */     }
/* 119 */     String path = urlPathHelper.getLookupPathForRequest(servletRequest);
/* 120 */     String filename = WebUtils.extractFullFilenameFromUrlPath(path);
/* 121 */     String extension = StringUtils.getFilenameExtension(filename);
/* 122 */     return StringUtils.hasText(extension) ? extension.toLowerCase(Locale.ENGLISH) : null;
/*     */   }
/*     */ 
/*     */   protected void handleMatch(String extension, MediaType mediaType)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected MediaType handleNoMatch(NativeWebRequest webRequest, String extension)
/*     */     throws HttpMediaTypeNotAcceptableException
/*     */   {
/* 133 */     if (this.useJaf) {
/* 134 */       MediaType jafMediaType = JafMediaTypeFactory.getMediaType("file." + extension);
/* 135 */       if ((jafMediaType != null) && (!MediaType.APPLICATION_OCTET_STREAM.equals(jafMediaType))) {
/* 136 */         return jafMediaType;
/*     */       }
/*     */     }
/* 139 */     if (!this.ignoreUnknownExtensions) {
/* 140 */       throw new HttpMediaTypeNotAcceptableException(getAllMediaTypes());
/*     */     }
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  64 */     urlPathHelper.setUrlDecode(false);
/*     */   }
/*     */ 
/*     */   private static class JafMediaTypeFactory
/*     */   {
/* 154 */     private static final FileTypeMap fileTypeMap = initFileTypeMap();
/*     */ 
/*     */     private static FileTypeMap initFileTypeMap()
/*     */     {
/* 161 */       Resource resource = new ClassPathResource("org/springframework/mail/javamail/mime.types");
/* 162 */       if (resource.exists()) {
/* 163 */         if (PathExtensionContentNegotiationStrategy.logger.isTraceEnabled()) {
/* 164 */           PathExtensionContentNegotiationStrategy.logger.trace("Loading Java Activation Framework FileTypeMap from " + resource);
/*     */         }
/* 166 */         InputStream inputStream = null;
/*     */         try {
/* 168 */           inputStream = resource.getInputStream();
/* 169 */           return new MimetypesFileTypeMap(inputStream);
/*     */         }
/*     */         catch (IOException localIOException4)
/*     */         {
/*     */         }
/*     */         finally {
/* 175 */           if (inputStream != null) {
/*     */             try {
/* 177 */               inputStream.close();
/*     */             }
/*     */             catch (IOException localIOException3)
/*     */             {
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 185 */       if (PathExtensionContentNegotiationStrategy.logger.isTraceEnabled()) {
/* 186 */         PathExtensionContentNegotiationStrategy.logger.trace("Loading default Java Activation Framework FileTypeMap");
/*     */       }
/* 188 */       return FileTypeMap.getDefaultFileTypeMap();
/*     */     }
/*     */ 
/*     */     public static MediaType getMediaType(String filename) {
/* 192 */       String mediaType = fileTypeMap.getContentType(filename);
/* 193 */       return StringUtils.hasText(mediaType) ? MediaType.parseMediaType(mediaType) : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.PathExtensionContentNegotiationStrategy
 * JD-Core Version:    0.6.2
 */