/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class ServletPathExtensionContentNegotiationStrategy extends PathExtensionContentNegotiationStrategy
/*    */ {
/*    */   private final ServletContext servletContext;
/*    */ 
/*    */   public ServletPathExtensionContentNegotiationStrategy(ServletContext servletContext, Map<String, MediaType> mediaTypes)
/*    */   {
/* 47 */     super(mediaTypes);
/* 48 */     Assert.notNull(servletContext, "ServletContext is required!");
/* 49 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */   public ServletPathExtensionContentNegotiationStrategy(ServletContext servletContext)
/*    */   {
/* 59 */     this(servletContext, null);
/*    */   }
/*    */ 
/*    */   protected MediaType handleNoMatch(NativeWebRequest webRequest, String extension)
/*    */     throws HttpMediaTypeNotAcceptableException
/*    */   {
/* 70 */     MediaType mediaType = null;
/* 71 */     if (this.servletContext != null) {
/* 72 */       String mimeType = this.servletContext.getMimeType("file." + extension);
/* 73 */       if (StringUtils.hasText(mimeType)) {
/* 74 */         mediaType = MediaType.parseMediaType(mimeType);
/*    */       }
/*    */     }
/* 77 */     if ((mediaType == null) || (MediaType.APPLICATION_OCTET_STREAM.equals(mediaType))) {
/* 78 */       MediaType superMediaType = super.handleNoMatch(webRequest, extension);
/* 79 */       if (superMediaType != null) {
/* 80 */         mediaType = superMediaType;
/*    */       }
/*    */     }
/* 83 */     return mediaType;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ServletPathExtensionContentNegotiationStrategy
 * JD-Core Version:    0.6.2
 */