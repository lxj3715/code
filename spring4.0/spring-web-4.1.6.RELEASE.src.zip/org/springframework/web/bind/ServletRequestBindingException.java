/*    */ package org.springframework.web.bind;
/*    */ 
/*    */ import org.springframework.web.util.NestedServletException;
/*    */ 
/*    */ public class ServletRequestBindingException extends NestedServletException
/*    */ {
/*    */   public ServletRequestBindingException(String msg)
/*    */   {
/* 40 */     super(msg);
/*    */   }
/*    */ 
/*    */   public ServletRequestBindingException(String msg, Throwable cause)
/*    */   {
/* 49 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.ServletRequestBindingException
 * JD-Core Version:    0.6.2
 */