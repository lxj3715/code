/*     */ package org.springframework.web.bind;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.beans.ConfigurablePropertyAccessor;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.validation.DataBinder;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class WebDataBinder extends DataBinder
/*     */ {
/*     */   public static final String DEFAULT_FIELD_MARKER_PREFIX = "_";
/*     */   public static final String DEFAULT_FIELD_DEFAULT_PREFIX = "!";
/*  74 */   private String fieldMarkerPrefix = "_";
/*     */ 
/*  76 */   private String fieldDefaultPrefix = "!";
/*     */ 
/*  78 */   private boolean bindEmptyMultipartFiles = true;
/*     */ 
/*     */   public WebDataBinder(Object target)
/*     */   {
/*  88 */     super(target);
/*     */   }
/*     */ 
/*     */   public WebDataBinder(Object target, String objectName)
/*     */   {
/*  98 */     super(target, objectName);
/*     */   }
/*     */ 
/*     */   public void setFieldMarkerPrefix(String fieldMarkerPrefix)
/*     */   {
/* 124 */     this.fieldMarkerPrefix = fieldMarkerPrefix;
/*     */   }
/*     */ 
/*     */   public String getFieldMarkerPrefix()
/*     */   {
/* 131 */     return this.fieldMarkerPrefix;
/*     */   }
/*     */ 
/*     */   public void setFieldDefaultPrefix(String fieldDefaultPrefix)
/*     */   {
/* 149 */     this.fieldDefaultPrefix = fieldDefaultPrefix;
/*     */   }
/*     */ 
/*     */   public String getFieldDefaultPrefix()
/*     */   {
/* 156 */     return this.fieldDefaultPrefix;
/*     */   }
/*     */ 
/*     */   public void setBindEmptyMultipartFiles(boolean bindEmptyMultipartFiles)
/*     */   {
/* 168 */     this.bindEmptyMultipartFiles = bindEmptyMultipartFiles;
/*     */   }
/*     */ 
/*     */   public boolean isBindEmptyMultipartFiles()
/*     */   {
/* 175 */     return this.bindEmptyMultipartFiles;
/*     */   }
/*     */ 
/*     */   protected void doBind(MutablePropertyValues mpvs)
/*     */   {
/* 187 */     checkFieldDefaults(mpvs);
/* 188 */     checkFieldMarkers(mpvs);
/* 189 */     super.doBind(mpvs);
/*     */   }
/*     */ 
/*     */   protected void checkFieldDefaults(MutablePropertyValues mpvs)
/*     */   {
/* 201 */     if (getFieldDefaultPrefix() != null) {
/* 202 */       String fieldDefaultPrefix = getFieldDefaultPrefix();
/* 203 */       PropertyValue[] pvArray = mpvs.getPropertyValues();
/* 204 */       for (PropertyValue pv : pvArray)
/* 205 */         if (pv.getName().startsWith(fieldDefaultPrefix)) {
/* 206 */           String field = pv.getName().substring(fieldDefaultPrefix.length());
/* 207 */           if ((getPropertyAccessor().isWritableProperty(field)) && (!mpvs.contains(field))) {
/* 208 */             mpvs.add(field, pv.getValue());
/*     */           }
/* 210 */           mpvs.removePropertyValue(pv);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void checkFieldMarkers(MutablePropertyValues mpvs)
/*     */   {
/* 228 */     if (getFieldMarkerPrefix() != null) {
/* 229 */       String fieldMarkerPrefix = getFieldMarkerPrefix();
/* 230 */       PropertyValue[] pvArray = mpvs.getPropertyValues();
/* 231 */       for (PropertyValue pv : pvArray)
/* 232 */         if (pv.getName().startsWith(fieldMarkerPrefix)) {
/* 233 */           String field = pv.getName().substring(fieldMarkerPrefix.length());
/* 234 */           if ((getPropertyAccessor().isWritableProperty(field)) && (!mpvs.contains(field))) {
/* 235 */             Class fieldType = getPropertyAccessor().getPropertyType(field);
/* 236 */             mpvs.add(field, getEmptyValue(field, fieldType));
/*     */           }
/* 238 */           mpvs.removePropertyValue(pv);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object getEmptyValue(String field, Class<?> fieldType)
/*     */   {
/* 254 */     if (((fieldType != null) && (Boolean.TYPE.equals(fieldType))) || (Boolean.class.equals(fieldType)))
/*     */     {
/* 256 */       return Boolean.FALSE;
/*     */     }
/* 258 */     if ((fieldType != null) && (fieldType.isArray()))
/*     */     {
/* 260 */       return Array.newInstance(fieldType.getComponentType(), 0);
/*     */     }
/*     */ 
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */   protected void bindMultipart(Map<String, List<MultipartFile>> multipartFiles, MutablePropertyValues mpvs)
/*     */   {
/* 279 */     for (Map.Entry entry : multipartFiles.entrySet()) {
/* 280 */       String key = (String)entry.getKey();
/* 281 */       List values = (List)entry.getValue();
/* 282 */       if (values.size() == 1) {
/* 283 */         MultipartFile value = (MultipartFile)values.get(0);
/* 284 */         if ((isBindEmptyMultipartFiles()) || (!value.isEmpty()))
/* 285 */           mpvs.add(key, value);
/*     */       }
/*     */       else
/*     */       {
/* 289 */         mpvs.add(key, values);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.WebDataBinder
 * JD-Core Version:    0.6.2
 */