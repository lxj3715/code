/*    */ package org.springframework.web.bind.annotation;
/*    */ 
/*    */ public enum RequestMethod
/*    */ {
/* 39 */   GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE;
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.RequestMethod
 * JD-Core Version:    0.6.2
 */