/*    */ package org.springframework.web.bind.annotation.support;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class HandlerMethodInvocationException extends NestedRuntimeException
/*    */ {
/*    */   public HandlerMethodInvocationException(Method handlerMethod, Throwable cause)
/*    */   {
/* 39 */     super("Failed to invoke handler method [" + handlerMethod + "]", cause);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.support.HandlerMethodInvocationException
 * JD-Core Version:    0.6.2
 */