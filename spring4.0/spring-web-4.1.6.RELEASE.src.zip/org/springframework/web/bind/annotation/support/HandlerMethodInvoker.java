/*     */ package org.springframework.web.bind.annotation.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.ui.ExtendedModelMap;
/*     */ import org.springframework.ui.Model;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.CookieValue;
/*     */ import org.springframework.web.bind.annotation.InitBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestHeader;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.support.DefaultSessionAttributeStore;
/*     */ import org.springframework.web.bind.support.SessionAttributeStore;
/*     */ import org.springframework.web.bind.support.SessionStatus;
/*     */ import org.springframework.web.bind.support.SimpleSessionStatus;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.bind.support.WebBindingInitializer;
/*     */ import org.springframework.web.bind.support.WebRequestDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ 
/*     */ public class HandlerMethodInvoker
/*     */ {
/*  99 */   private static final String MODEL_KEY_PREFIX_STALE = new StringBuilder().append(SessionAttributeStore.class.getName()).append(".STALE.").toString();
/*     */ 
/* 102 */   private static final Log logger = LogFactory.getLog(HandlerMethodInvoker.class);
/*     */   private final HandlerMethodResolver methodResolver;
/*     */   private final WebBindingInitializer bindingInitializer;
/*     */   private final SessionAttributeStore sessionAttributeStore;
/*     */   private final ParameterNameDiscoverer parameterNameDiscoverer;
/*     */   private final WebArgumentResolver[] customArgumentResolvers;
/*     */   private final HttpMessageConverter<?>[] messageConverters;
/* 116 */   private final SimpleSessionStatus sessionStatus = new SimpleSessionStatus();
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver)
/*     */   {
/* 120 */     this(methodResolver, null);
/*     */   }
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver, WebBindingInitializer bindingInitializer) {
/* 124 */     this(methodResolver, bindingInitializer, new DefaultSessionAttributeStore(), null, null, null);
/*     */   }
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver, WebBindingInitializer bindingInitializer, SessionAttributeStore sessionAttributeStore, ParameterNameDiscoverer parameterNameDiscoverer, WebArgumentResolver[] customArgumentResolvers, HttpMessageConverter<?>[] messageConverters)
/*     */   {
/* 131 */     this.methodResolver = methodResolver;
/* 132 */     this.bindingInitializer = bindingInitializer;
/* 133 */     this.sessionAttributeStore = sessionAttributeStore;
/* 134 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/* 135 */     this.customArgumentResolvers = customArgumentResolvers;
/* 136 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   public final Object invokeHandlerMethod(Method handlerMethod, Object handler, NativeWebRequest webRequest, ExtendedModelMap implicitModel)
/*     */     throws Exception
/*     */   {
/* 143 */     Method handlerMethodToInvoke = BridgeMethodResolver.findBridgedMethod(handlerMethod);
/*     */     try {
/* 145 */       boolean debug = logger.isDebugEnabled();
/* 146 */       for (String attrName : this.methodResolver.getActualSessionAttributeNames()) {
/* 147 */         Object attrValue = this.sessionAttributeStore.retrieveAttribute(webRequest, attrName);
/* 148 */         if (attrValue != null) {
/* 149 */           implicitModel.addAttribute(attrName, attrValue);
/*     */         }
/*     */       }
/* 152 */       for (Method attributeMethod : this.methodResolver.getModelAttributeMethods()) {
/* 153 */         Method attributeMethodToInvoke = BridgeMethodResolver.findBridgedMethod(attributeMethod);
/* 154 */         Object[] args = resolveHandlerArguments(attributeMethodToInvoke, handler, webRequest, implicitModel);
/* 155 */         if (debug) {
/* 156 */           logger.debug(new StringBuilder().append("Invoking model attribute method: ").append(attributeMethodToInvoke).toString());
/*     */         }
/* 158 */         String attrName = ((ModelAttribute)AnnotationUtils.findAnnotation(attributeMethod, ModelAttribute.class)).value();
/* 159 */         if (("".equals(attrName)) || (!implicitModel.containsAttribute(attrName)))
/*     */         {
/* 162 */           ReflectionUtils.makeAccessible(attributeMethodToInvoke);
/* 163 */           Object attrValue = attributeMethodToInvoke.invoke(handler, args);
/* 164 */           if ("".equals(attrName)) {
/* 165 */             Class resolvedType = GenericTypeResolver.resolveReturnType(attributeMethodToInvoke, handler.getClass());
/* 166 */             attrName = Conventions.getVariableNameForReturnType(attributeMethodToInvoke, resolvedType, attrValue);
/*     */           }
/* 168 */           if (!implicitModel.containsAttribute(attrName))
/* 169 */             implicitModel.addAttribute(attrName, attrValue);
/*     */         }
/*     */       }
/* 172 */       Object[] args = resolveHandlerArguments(handlerMethodToInvoke, handler, webRequest, implicitModel);
/* 173 */       if (debug) {
/* 174 */         logger.debug(new StringBuilder().append("Invoking request handler method: ").append(handlerMethodToInvoke).toString());
/*     */       }
/* 176 */       ReflectionUtils.makeAccessible(handlerMethodToInvoke);
/* 177 */       return handlerMethodToInvoke.invoke(handler, args);
/*     */     }
/*     */     catch (IllegalStateException ex)
/*     */     {
/* 182 */       throw new HandlerMethodInvocationException(handlerMethodToInvoke, ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 186 */       ReflectionUtils.rethrowException(ex.getTargetException());
/* 187 */     }return null;
/*     */   }
/*     */ 
/*     */   public final void updateModelAttributes(Object handler, Map<String, Object> mavModel, ExtendedModelMap implicitModel, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 194 */     if ((this.methodResolver.hasSessionAttributes()) && (this.sessionStatus.isComplete())) {
/* 195 */       for (String attrName : this.methodResolver.getActualSessionAttributeNames()) {
/* 196 */         this.sessionAttributeStore.cleanupAttribute(webRequest, attrName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 202 */     Object model = mavModel != null ? mavModel : implicitModel;
/* 203 */     if (model != null)
/*     */       try {
/* 205 */         String[] originalAttrNames = (String[])((Map)model).keySet().toArray(new String[((Map)model).size()]);
/* 206 */         for (String attrName : originalAttrNames) {
/* 207 */           Object attrValue = ((Map)model).get(attrName);
/* 208 */           boolean isSessionAttr = this.methodResolver.isSessionAttribute(attrName, attrValue != null ? attrValue
/* 209 */             .getClass() : null);
/* 210 */           if (isSessionAttr) {
/* 211 */             if (this.sessionStatus.isComplete()) {
/* 212 */               implicitModel.put(new StringBuilder().append(MODEL_KEY_PREFIX_STALE).append(attrName).toString(), Boolean.TRUE);
/*     */             }
/* 214 */             else if (!implicitModel.containsKey(new StringBuilder().append(MODEL_KEY_PREFIX_STALE).append(attrName).toString())) {
/* 215 */               this.sessionAttributeStore.storeAttribute(webRequest, attrName, attrValue);
/*     */             }
/*     */           }
/* 218 */           if ((!attrName.startsWith(BindingResult.MODEL_KEY_PREFIX)) && ((isSessionAttr) || 
/* 219 */             (isBindingCandidate(attrValue))))
/*     */           {
/* 220 */             String bindingResultKey = new StringBuilder().append(BindingResult.MODEL_KEY_PREFIX).append(attrName).toString();
/* 221 */             if ((mavModel != null) && (!((Map)model).containsKey(bindingResultKey))) {
/* 222 */               WebDataBinder binder = createBinder(webRequest, attrValue, attrName);
/* 223 */               initBinder(handler, attrName, binder, webRequest);
/* 224 */               mavModel.put(bindingResultKey, binder.getBindingResult());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException ex)
/*     */       {
/* 231 */         ReflectionUtils.rethrowException(ex.getTargetException());
/*     */       }
/*     */   }
/*     */ 
/*     */   private Object[] resolveHandlerArguments(Method handlerMethod, Object handler, NativeWebRequest webRequest, ExtendedModelMap implicitModel)
/*     */     throws Exception
/*     */   {
/* 240 */     Class[] paramTypes = handlerMethod.getParameterTypes();
/* 241 */     Object[] args = new Object[paramTypes.length];
/*     */ 
/* 243 */     for (int i = 0; i < args.length; i++) {
/* 244 */       MethodParameter methodParam = new MethodParameter(handlerMethod, i);
/* 245 */       methodParam.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 246 */       GenericTypeResolver.resolveParameterType(methodParam, handler.getClass());
/* 247 */       String paramName = null;
/* 248 */       String headerName = null;
/* 249 */       boolean requestBodyFound = false;
/* 250 */       String cookieName = null;
/* 251 */       String pathVarName = null;
/* 252 */       String attrName = null;
/* 253 */       boolean required = false;
/* 254 */       String defaultValue = null;
/* 255 */       boolean validate = false;
/* 256 */       Object[] validationHints = null;
/* 257 */       int annotationsFound = 0;
/* 258 */       Annotation[] paramAnns = methodParam.getParameterAnnotations();
/*     */ 
/* 260 */       for (Annotation paramAnn : paramAnns) {
/* 261 */         if (RequestParam.class.isInstance(paramAnn)) {
/* 262 */           RequestParam requestParam = (RequestParam)paramAnn;
/* 263 */           paramName = requestParam.value();
/* 264 */           required = requestParam.required();
/* 265 */           defaultValue = parseDefaultValueAttribute(requestParam.defaultValue());
/* 266 */           annotationsFound++;
/*     */         }
/* 268 */         else if (RequestHeader.class.isInstance(paramAnn)) {
/* 269 */           RequestHeader requestHeader = (RequestHeader)paramAnn;
/* 270 */           headerName = requestHeader.value();
/* 271 */           required = requestHeader.required();
/* 272 */           defaultValue = parseDefaultValueAttribute(requestHeader.defaultValue());
/* 273 */           annotationsFound++;
/*     */         }
/* 275 */         else if (RequestBody.class.isInstance(paramAnn)) {
/* 276 */           requestBodyFound = true;
/* 277 */           annotationsFound++;
/*     */         }
/* 279 */         else if (CookieValue.class.isInstance(paramAnn)) {
/* 280 */           CookieValue cookieValue = (CookieValue)paramAnn;
/* 281 */           cookieName = cookieValue.value();
/* 282 */           required = cookieValue.required();
/* 283 */           defaultValue = parseDefaultValueAttribute(cookieValue.defaultValue());
/* 284 */           annotationsFound++;
/*     */         }
/* 286 */         else if (PathVariable.class.isInstance(paramAnn)) {
/* 287 */           PathVariable pathVar = (PathVariable)paramAnn;
/* 288 */           pathVarName = pathVar.value();
/* 289 */           annotationsFound++;
/*     */         }
/* 291 */         else if (ModelAttribute.class.isInstance(paramAnn)) {
/* 292 */           ModelAttribute attr = (ModelAttribute)paramAnn;
/* 293 */           attrName = attr.value();
/* 294 */           annotationsFound++;
/*     */         }
/* 296 */         else if (Value.class.isInstance(paramAnn)) {
/* 297 */           defaultValue = ((Value)paramAnn).value();
/*     */         }
/*     */         else {
/* 300 */           Validated validatedAnn = (Validated)AnnotationUtils.getAnnotation(paramAnn, Validated.class);
/* 301 */           if ((validatedAnn != null) || (paramAnn.annotationType().getSimpleName().startsWith("Valid"))) {
/* 302 */             validate = true;
/* 303 */             Object hints = validatedAnn != null ? validatedAnn.value() : AnnotationUtils.getValue(paramAnn);
/* 304 */             validationHints = new Object[] { (hints instanceof Object[]) ? (Object[])hints : hints };
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 309 */       if (annotationsFound > 1) {
/* 310 */         throw new IllegalStateException(new StringBuilder().append("Handler parameter annotations are exclusive choices - do not specify more than one such annotation on the same parameter: ").append(handlerMethod).toString());
/*     */       }
/*     */ 
/* 314 */       if (annotationsFound == 0) {
/* 315 */         Object argValue = resolveCommonArgument(methodParam, webRequest);
/* 316 */         if (argValue != WebArgumentResolver.UNRESOLVED) {
/* 317 */           args[i] = argValue;
/*     */         }
/* 319 */         else if (defaultValue != null) {
/* 320 */           args[i] = resolveDefaultValue(defaultValue);
/*     */         }
/*     */         else {
/* 323 */           Class paramType = methodParam.getParameterType();
/* 324 */           if ((Model.class.isAssignableFrom(paramType)) || (Map.class.isAssignableFrom(paramType))) {
/* 325 */             if (!paramType.isAssignableFrom(implicitModel.getClass())) {
/* 326 */               throw new IllegalStateException(new StringBuilder().append("Argument [").append(paramType.getSimpleName()).append("] is of type ").append("Model or Map but is not assignable from the actual model. You may need to switch ").append("newer MVC infrastructure classes to use this argument.").toString());
/*     */             }
/*     */ 
/* 330 */             args[i] = implicitModel;
/*     */           }
/* 332 */           else if (SessionStatus.class.isAssignableFrom(paramType)) {
/* 333 */             args[i] = this.sessionStatus;
/*     */           }
/* 335 */           else if (HttpEntity.class.isAssignableFrom(paramType)) {
/* 336 */             args[i] = resolveHttpEntityRequest(methodParam, webRequest);
/*     */           } else {
/* 338 */             if (Errors.class.isAssignableFrom(paramType)) {
/* 339 */               throw new IllegalStateException("Errors/BindingResult argument declared without preceding model attribute. Check your handler method signature!");
/*     */             }
/*     */ 
/* 342 */             if (BeanUtils.isSimpleProperty(paramType)) {
/* 343 */               paramName = "";
/*     */             }
/*     */             else {
/* 346 */               attrName = "";
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 351 */       if (paramName != null) {
/* 352 */         args[i] = resolveRequestParam(paramName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 354 */       else if (headerName != null) {
/* 355 */         args[i] = resolveRequestHeader(headerName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 357 */       else if (requestBodyFound) {
/* 358 */         args[i] = resolveRequestBody(methodParam, webRequest, handler);
/*     */       }
/* 360 */       else if (cookieName != null) {
/* 361 */         args[i] = resolveCookieValue(cookieName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 363 */       else if (pathVarName != null) {
/* 364 */         args[i] = resolvePathVariable(pathVarName, methodParam, webRequest, handler);
/*     */       }
/* 366 */       else if (attrName != null)
/*     */       {
/* 368 */         WebDataBinder binder = resolveModelAttribute(attrName, methodParam, implicitModel, webRequest, handler);
/*     */ 
/* 369 */         boolean assignBindingResult = (args.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/* 370 */         if (binder.getTarget() != null) {
/* 371 */           doBind(binder, webRequest, validate, validationHints, !assignBindingResult);
/*     */         }
/* 373 */         args[i] = binder.getTarget();
/* 374 */         if (assignBindingResult) {
/* 375 */           args[(i + 1)] = binder.getBindingResult();
/* 376 */           i++;
/*     */         }
/* 378 */         implicitModel.putAll(binder.getBindingResult().getModel());
/*     */       }
/*     */     }
/*     */ 
/* 382 */     return args;
/*     */   }
/*     */ 
/*     */   protected void initBinder(Object handler, String attrName, WebDataBinder binder, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 388 */     if (this.bindingInitializer != null)
/* 389 */       this.bindingInitializer.initBinder(binder, webRequest);
/*     */     boolean debug;
/* 391 */     if (handler != null) {
/* 392 */       Set initBinderMethods = this.methodResolver.getInitBinderMethods();
/* 393 */       if (!initBinderMethods.isEmpty()) {
/* 394 */         debug = logger.isDebugEnabled();
/* 395 */         for (Method initBinderMethod : initBinderMethods) {
/* 396 */           Method methodToInvoke = BridgeMethodResolver.findBridgedMethod(initBinderMethod);
/* 397 */           String[] targetNames = ((InitBinder)AnnotationUtils.findAnnotation(initBinderMethod, InitBinder.class)).value();
/* 398 */           if ((targetNames.length == 0) || (Arrays.asList(targetNames).contains(attrName)))
/*     */           {
/* 400 */             Object[] initBinderArgs = resolveInitBinderArguments(handler, methodToInvoke, binder, webRequest);
/*     */ 
/* 401 */             if (debug) {
/* 402 */               logger.debug(new StringBuilder().append("Invoking init-binder method: ").append(methodToInvoke).toString());
/*     */             }
/* 404 */             ReflectionUtils.makeAccessible(methodToInvoke);
/* 405 */             Object returnValue = methodToInvoke.invoke(handler, initBinderArgs);
/* 406 */             if (returnValue != null)
/* 407 */               throw new IllegalStateException(new StringBuilder().append("InitBinder methods must not have a return value: ").append(methodToInvoke).toString());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object[] resolveInitBinderArguments(Object handler, Method initBinderMethod, WebDataBinder binder, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 419 */     Class[] initBinderParams = initBinderMethod.getParameterTypes();
/* 420 */     Object[] initBinderArgs = new Object[initBinderParams.length];
/*     */ 
/* 422 */     for (int i = 0; i < initBinderArgs.length; i++) {
/* 423 */       MethodParameter methodParam = new MethodParameter(initBinderMethod, i);
/* 424 */       methodParam.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 425 */       GenericTypeResolver.resolveParameterType(methodParam, handler.getClass());
/* 426 */       String paramName = null;
/* 427 */       boolean paramRequired = false;
/* 428 */       String paramDefaultValue = null;
/* 429 */       String pathVarName = null;
/* 430 */       Annotation[] paramAnns = methodParam.getParameterAnnotations();
/*     */ 
/* 432 */       for (Annotation paramAnn : paramAnns) {
/* 433 */         if (RequestParam.class.isInstance(paramAnn)) {
/* 434 */           RequestParam requestParam = (RequestParam)paramAnn;
/* 435 */           paramName = requestParam.value();
/* 436 */           paramRequired = requestParam.required();
/* 437 */           paramDefaultValue = parseDefaultValueAttribute(requestParam.defaultValue());
/* 438 */           break;
/*     */         }
/* 440 */         if (ModelAttribute.class.isInstance(paramAnn)) {
/* 441 */           throw new IllegalStateException(new StringBuilder().append("@ModelAttribute is not supported on @InitBinder methods: ").append(initBinderMethod).toString());
/*     */         }
/*     */ 
/* 444 */         if (PathVariable.class.isInstance(paramAnn)) {
/* 445 */           PathVariable pathVar = (PathVariable)paramAnn;
/* 446 */           pathVarName = pathVar.value();
/*     */         }
/*     */       }
/*     */ 
/* 450 */       if ((paramName == null) && (pathVarName == null)) {
/* 451 */         Object argValue = resolveCommonArgument(methodParam, webRequest);
/* 452 */         if (argValue != WebArgumentResolver.UNRESOLVED) {
/* 453 */           initBinderArgs[i] = argValue;
/*     */         }
/*     */         else {
/* 456 */           Class paramType = initBinderParams[i];
/* 457 */           if (paramType.isInstance(binder)) {
/* 458 */             initBinderArgs[i] = binder;
/*     */           }
/* 460 */           else if (BeanUtils.isSimpleProperty(paramType)) {
/* 461 */             paramName = "";
/*     */           }
/*     */           else {
/* 464 */             throw new IllegalStateException(new StringBuilder().append("Unsupported argument [").append(paramType.getName()).append("] for @InitBinder method: ").append(initBinderMethod).toString());
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 470 */       if (paramName != null) {
/* 471 */         initBinderArgs[i] = 
/* 472 */           resolveRequestParam(paramName, paramRequired, paramDefaultValue, methodParam, webRequest, null);
/*     */       }
/* 474 */       else if (pathVarName != null) {
/* 475 */         initBinderArgs[i] = resolvePathVariable(pathVarName, methodParam, webRequest, null);
/*     */       }
/*     */     }
/*     */ 
/* 479 */     return initBinderArgs;
/*     */   }
/*     */ 
/*     */   private Object resolveRequestParam(String paramName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 487 */     Class paramType = methodParam.getParameterType();
/* 488 */     if ((Map.class.isAssignableFrom(paramType)) && (paramName.length() == 0)) {
/* 489 */       return resolveRequestParamMap(paramType, webRequest);
/*     */     }
/* 491 */     if (paramName.length() == 0) {
/* 492 */       paramName = getRequiredParameterName(methodParam);
/*     */     }
/* 494 */     Object paramValue = null;
/* 495 */     MultipartRequest multipartRequest = (MultipartRequest)webRequest.getNativeRequest(MultipartRequest.class);
/* 496 */     if (multipartRequest != null) {
/* 497 */       List files = multipartRequest.getFiles(paramName);
/* 498 */       if (!files.isEmpty()) {
/* 499 */         paramValue = files.size() == 1 ? files.get(0) : files;
/*     */       }
/*     */     }
/* 502 */     if (paramValue == null) {
/* 503 */       String[] paramValues = webRequest.getParameterValues(paramName);
/* 504 */       if (paramValues != null) {
/* 505 */         paramValue = paramValues.length == 1 ? paramValues[0] : paramValues;
/*     */       }
/*     */     }
/* 508 */     if (paramValue == null) {
/* 509 */       if (defaultValue != null) {
/* 510 */         paramValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 512 */       else if (required) {
/* 513 */         raiseMissingParameterException(paramName, paramType);
/*     */       }
/* 515 */       paramValue = checkValue(paramName, paramValue, paramType);
/*     */     }
/* 517 */     WebDataBinder binder = createBinder(webRequest, null, paramName);
/* 518 */     initBinder(handlerForInitBinderCall, paramName, binder, webRequest);
/* 519 */     return binder.convertIfNecessary(paramValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   private Map<String, ?> resolveRequestParamMap(Class<? extends Map<?, ?>> mapType, NativeWebRequest webRequest) {
/* 523 */     Map parameterMap = webRequest.getParameterMap();
/* 524 */     if (MultiValueMap.class.isAssignableFrom(mapType)) {
/* 525 */       MultiValueMap result = new LinkedMultiValueMap(parameterMap.size());
/* 526 */       for (Map.Entry entry : parameterMap.entrySet()) {
/* 527 */         for (String value : (String[])entry.getValue()) {
/* 528 */           result.add(entry.getKey(), value);
/*     */         }
/*     */       }
/* 531 */       return result;
/*     */     }
/*     */ 
/* 534 */     Map result = new LinkedHashMap(parameterMap.size());
/* 535 */     for (Map.Entry entry : parameterMap.entrySet()) {
/* 536 */       if (((String[])entry.getValue()).length > 0) {
/* 537 */         result.put(entry.getKey(), ((String[])entry.getValue())[0]);
/*     */       }
/*     */     }
/* 540 */     return result;
/*     */   }
/*     */ 
/*     */   private Object resolveRequestHeader(String headerName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 549 */     Class paramType = methodParam.getParameterType();
/* 550 */     if (Map.class.isAssignableFrom(paramType)) {
/* 551 */       return resolveRequestHeaderMap(paramType, webRequest);
/*     */     }
/* 553 */     if (headerName.length() == 0) {
/* 554 */       headerName = getRequiredParameterName(methodParam);
/*     */     }
/* 556 */     Object headerValue = null;
/* 557 */     String[] headerValues = webRequest.getHeaderValues(headerName);
/* 558 */     if (headerValues != null) {
/* 559 */       headerValue = headerValues.length == 1 ? headerValues[0] : headerValues;
/*     */     }
/* 561 */     if (headerValue == null) {
/* 562 */       if (defaultValue != null) {
/* 563 */         headerValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 565 */       else if (required) {
/* 566 */         raiseMissingHeaderException(headerName, paramType);
/*     */       }
/* 568 */       headerValue = checkValue(headerName, headerValue, paramType);
/*     */     }
/* 570 */     WebDataBinder binder = createBinder(webRequest, null, headerName);
/* 571 */     initBinder(handlerForInitBinderCall, headerName, binder, webRequest);
/* 572 */     return binder.convertIfNecessary(headerValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   private Map<String, ?> resolveRequestHeaderMap(Class<? extends Map<?, ?>> mapType, NativeWebRequest webRequest) {
/* 576 */     if (MultiValueMap.class.isAssignableFrom(mapType))
/*     */     {
/*     */       MultiValueMap result;
/*     */       MultiValueMap result;
/* 578 */       if (HttpHeaders.class.isAssignableFrom(mapType)) {
/* 579 */         result = new HttpHeaders();
/*     */       }
/*     */       else {
/* 582 */         result = new LinkedMultiValueMap();
/*     */       }
/* 584 */       for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 585 */         String headerName = (String)iterator.next();
/* 586 */         for (String headerValue : webRequest.getHeaderValues(headerName)) {
/* 587 */           result.add(headerName, headerValue);
/*     */         }
/*     */       }
/* 590 */       return result;
/*     */     }
/*     */ 
/* 593 */     Map result = new LinkedHashMap();
/* 594 */     for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 595 */       String headerName = (String)iterator.next();
/* 596 */       String headerValue = webRequest.getHeader(headerName);
/* 597 */       result.put(headerName, headerValue);
/*     */     }
/* 599 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object resolveRequestBody(MethodParameter methodParam, NativeWebRequest webRequest, Object handler)
/*     */     throws Exception
/*     */   {
/* 609 */     return readWithMessageConverters(methodParam, createHttpInputMessage(webRequest), methodParam.getParameterType());
/*     */   }
/*     */ 
/*     */   private HttpEntity<?> resolveHttpEntityRequest(MethodParameter methodParam, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 615 */     HttpInputMessage inputMessage = createHttpInputMessage(webRequest);
/* 616 */     Class paramType = getHttpEntityType(methodParam);
/* 617 */     Object body = readWithMessageConverters(methodParam, inputMessage, paramType);
/* 618 */     return new HttpEntity(body, inputMessage.getHeaders());
/*     */   }
/*     */ 
/*     */   private Object readWithMessageConverters(MethodParameter methodParam, HttpInputMessage inputMessage, Class<?> paramType)
/*     */     throws Exception
/*     */   {
/* 625 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/*     */     String paramName;
/* 626 */     if (contentType == null) {
/* 627 */       StringBuilder builder = new StringBuilder(ClassUtils.getShortName(methodParam.getParameterType()));
/* 628 */       paramName = methodParam.getParameterName();
/* 629 */       if (paramName != null) {
/* 630 */         builder.append(' ');
/* 631 */         builder.append(paramName);
/*     */       }
/*     */ 
/* 634 */       throw new HttpMediaTypeNotSupportedException(new StringBuilder().append("Cannot extract parameter (")
/* 634 */         .append(builder
/* 634 */         .toString()).append("): no Content-Type found").toString());
/*     */     }
/*     */ 
/* 637 */     List allSupportedMediaTypes = new ArrayList();
/* 638 */     if (this.messageConverters != null) {
/* 639 */       for (HttpMessageConverter messageConverter : this.messageConverters) {
/* 640 */         allSupportedMediaTypes.addAll(messageConverter.getSupportedMediaTypes());
/* 641 */         if (messageConverter.canRead(paramType, contentType)) {
/* 642 */           if (logger.isDebugEnabled()) {
/* 643 */             logger.debug(new StringBuilder().append("Reading [").append(paramType.getName()).append("] as \"").append(contentType).append("\" using [").append(messageConverter).append("]").toString());
/*     */           }
/*     */ 
/* 646 */           return messageConverter.read(paramType, inputMessage);
/*     */         }
/*     */       }
/*     */     }
/* 650 */     throw new HttpMediaTypeNotSupportedException(contentType, allSupportedMediaTypes);
/*     */   }
/*     */ 
/*     */   private Class<?> getHttpEntityType(MethodParameter methodParam) {
/* 654 */     Assert.isAssignable(HttpEntity.class, methodParam.getParameterType());
/* 655 */     ParameterizedType type = (ParameterizedType)methodParam.getGenericParameterType();
/* 656 */     if (type.getActualTypeArguments().length == 1) {
/* 657 */       Type typeArgument = type.getActualTypeArguments()[0];
/* 658 */       if ((typeArgument instanceof Class)) {
/* 659 */         return (Class)typeArgument;
/*     */       }
/* 661 */       if ((typeArgument instanceof GenericArrayType)) {
/* 662 */         Type componentType = ((GenericArrayType)typeArgument).getGenericComponentType();
/* 663 */         if ((componentType instanceof Class))
/*     */         {
/* 665 */           Object array = Array.newInstance((Class)componentType, 0);
/* 666 */           return array.getClass();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 671 */     throw new IllegalArgumentException(new StringBuilder().append("HttpEntity parameter (")
/* 671 */       .append(methodParam
/* 671 */       .getParameterName()).append(") is not parameterized").toString());
/*     */   }
/*     */ 
/*     */   private Object resolveCookieValue(String cookieName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 679 */     Class paramType = methodParam.getParameterType();
/* 680 */     if (cookieName.length() == 0) {
/* 681 */       cookieName = getRequiredParameterName(methodParam);
/*     */     }
/* 683 */     Object cookieValue = resolveCookieValue(cookieName, paramType, webRequest);
/* 684 */     if (cookieValue == null) {
/* 685 */       if (defaultValue != null) {
/* 686 */         cookieValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 688 */       else if (required) {
/* 689 */         raiseMissingCookieException(cookieName, paramType);
/*     */       }
/* 691 */       cookieValue = checkValue(cookieName, cookieValue, paramType);
/*     */     }
/* 693 */     WebDataBinder binder = createBinder(webRequest, null, cookieName);
/* 694 */     initBinder(handlerForInitBinderCall, cookieName, binder, webRequest);
/* 695 */     return binder.convertIfNecessary(cookieValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   protected Object resolveCookieValue(String cookieName, Class<?> paramType, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 705 */     throw new UnsupportedOperationException("@CookieValue not supported");
/*     */   }
/*     */ 
/*     */   private Object resolvePathVariable(String pathVarName, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 711 */     Class paramType = methodParam.getParameterType();
/* 712 */     if (pathVarName.length() == 0) {
/* 713 */       pathVarName = getRequiredParameterName(methodParam);
/*     */     }
/* 715 */     String pathVarValue = resolvePathVariable(pathVarName, paramType, webRequest);
/* 716 */     WebDataBinder binder = createBinder(webRequest, null, pathVarName);
/* 717 */     initBinder(handlerForInitBinderCall, pathVarName, binder, webRequest);
/* 718 */     return binder.convertIfNecessary(pathVarValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   protected String resolvePathVariable(String pathVarName, Class<?> paramType, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 728 */     throw new UnsupportedOperationException("@PathVariable not supported");
/*     */   }
/*     */ 
/*     */   private String getRequiredParameterName(MethodParameter methodParam) {
/* 732 */     String name = methodParam.getParameterName();
/* 733 */     if (name == null)
/*     */     {
/* 735 */       throw new IllegalStateException(new StringBuilder().append("No parameter name specified for argument of type [")
/* 735 */         .append(methodParam
/* 735 */         .getParameterType().getName()).append("], and no parameter name information found in class file either.").toString());
/*     */     }
/*     */ 
/* 738 */     return name;
/*     */   }
/*     */ 
/*     */   private Object checkValue(String name, Object value, Class<?> paramType) {
/* 742 */     if (value == null) {
/* 743 */       if (Boolean.TYPE.equals(paramType)) {
/* 744 */         return Boolean.FALSE;
/*     */       }
/* 746 */       if (paramType.isPrimitive()) {
/* 747 */         throw new IllegalStateException(new StringBuilder().append("Optional ").append(paramType).append(" parameter '").append(name).append("' is not present but cannot be translated into a null value due to being declared as a ").append("primitive type. Consider declaring it as object wrapper for the corresponding primitive type.").toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 752 */     return value;
/*     */   }
/*     */ 
/*     */   private WebDataBinder resolveModelAttribute(String attrName, MethodParameter methodParam, ExtendedModelMap implicitModel, NativeWebRequest webRequest, Object handler)
/*     */     throws Exception
/*     */   {
/* 759 */     String name = attrName;
/* 760 */     if ("".equals(name)) {
/* 761 */       name = Conventions.getVariableNameForParameter(methodParam);
/*     */     }
/* 763 */     Class paramType = methodParam.getParameterType();
/*     */     Object bindObject;
/*     */     Object bindObject;
/* 765 */     if (implicitModel.containsKey(name)) {
/* 766 */       bindObject = implicitModel.get(name);
/*     */     }
/* 768 */     else if (this.methodResolver.isSessionAttribute(name, paramType)) {
/* 769 */       Object bindObject = this.sessionAttributeStore.retrieveAttribute(webRequest, name);
/* 770 */       if (bindObject == null)
/* 771 */         raiseSessionRequiredException(new StringBuilder().append("Session attribute '").append(name).append("' required - not found in session").toString());
/*     */     }
/*     */     else
/*     */     {
/* 775 */       bindObject = BeanUtils.instantiateClass(paramType);
/*     */     }
/* 777 */     WebDataBinder binder = createBinder(webRequest, bindObject, name);
/* 778 */     initBinder(handler, name, binder, webRequest);
/* 779 */     return binder;
/*     */   }
/*     */ 
/*     */   protected boolean isBindingCandidate(Object value)
/*     */   {
/* 789 */     return (value != null) && (!value.getClass().isArray()) && (!(value instanceof Collection)) && (!(value instanceof Map)) && 
/* 789 */       (!BeanUtils.isSimpleValueType(value
/* 789 */       .getClass()));
/*     */   }
/*     */ 
/*     */   protected void raiseMissingParameterException(String paramName, Class<?> paramType) throws Exception {
/* 793 */     throw new IllegalStateException(new StringBuilder().append("Missing parameter '").append(paramName).append("' of type [").append(paramType.getName()).append("]").toString());
/*     */   }
/*     */ 
/*     */   protected void raiseMissingHeaderException(String headerName, Class<?> paramType) throws Exception {
/* 797 */     throw new IllegalStateException(new StringBuilder().append("Missing header '").append(headerName).append("' of type [").append(paramType.getName()).append("]").toString());
/*     */   }
/*     */ 
/*     */   protected void raiseMissingCookieException(String cookieName, Class<?> paramType) throws Exception
/*     */   {
/* 802 */     throw new IllegalStateException(new StringBuilder().append("Missing cookie value '").append(cookieName).append("' of type [")
/* 802 */       .append(paramType
/* 802 */       .getName()).append("]").toString());
/*     */   }
/*     */ 
/*     */   protected void raiseSessionRequiredException(String message) throws Exception {
/* 806 */     throw new IllegalStateException(message);
/*     */   }
/*     */ 
/*     */   protected WebDataBinder createBinder(NativeWebRequest webRequest, Object target, String objectName)
/*     */     throws Exception
/*     */   {
/* 812 */     return new WebRequestDataBinder(target, objectName);
/*     */   }
/*     */ 
/*     */   private void doBind(WebDataBinder binder, NativeWebRequest webRequest, boolean validate, Object[] validationHints, boolean failOnErrors)
/*     */     throws Exception
/*     */   {
/* 818 */     doBind(binder, webRequest);
/* 819 */     if (validate) {
/* 820 */       binder.validate(validationHints);
/*     */     }
/* 822 */     if ((failOnErrors) && (binder.getBindingResult().hasErrors()))
/* 823 */       throw new BindException(binder.getBindingResult());
/*     */   }
/*     */ 
/*     */   protected void doBind(WebDataBinder binder, NativeWebRequest webRequest) throws Exception
/*     */   {
/* 828 */     ((WebRequestDataBinder)binder).bind(webRequest);
/*     */   }
/*     */ 
/*     */   protected HttpInputMessage createHttpInputMessage(NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 836 */     throw new UnsupportedOperationException("@RequestBody not supported");
/*     */   }
/*     */ 
/*     */   protected HttpOutputMessage createHttpOutputMessage(NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 844 */     throw new UnsupportedOperationException("@Body not supported");
/*     */   }
/*     */ 
/*     */   protected String parseDefaultValueAttribute(String value) {
/* 848 */     return "\n\t\t\n\t\t\n\n\t\t\t\t\n".equals(value) ? null : value;
/*     */   }
/*     */ 
/*     */   protected Object resolveDefaultValue(String value) {
/* 852 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object resolveCommonArgument(MethodParameter methodParameter, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 859 */     if (this.customArgumentResolvers != null) {
/* 860 */       for (WebArgumentResolver argumentResolver : this.customArgumentResolvers) {
/* 861 */         Object value = argumentResolver.resolveArgument(methodParameter, webRequest);
/* 862 */         if (value != WebArgumentResolver.UNRESOLVED) {
/* 863 */           return value;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 869 */     Class paramType = methodParameter.getParameterType();
/* 870 */     Object value = resolveStandardArgument(paramType, webRequest);
/* 871 */     if ((value != WebArgumentResolver.UNRESOLVED) && (!ClassUtils.isAssignableValue(paramType, value)))
/*     */     {
/* 873 */       throw new IllegalStateException(new StringBuilder().append("Standard argument type [").append(paramType.getName()).append("] resolved to incompatible value of type [")
/* 873 */         .append(value != null ? value
/* 873 */         .getClass() : null).append("]. Consider declaring the argument type in a less specific fashion.").toString());
/*     */     }
/*     */ 
/* 876 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object resolveStandardArgument(Class<?> parameterType, NativeWebRequest webRequest) throws Exception {
/* 880 */     if (WebRequest.class.isAssignableFrom(parameterType)) {
/* 881 */       return webRequest;
/*     */     }
/* 883 */     return WebArgumentResolver.UNRESOLVED;
/*     */   }
/*     */ 
/*     */   protected final void addReturnValueAsModelAttribute(Method handlerMethod, Class<?> handlerType, Object returnValue, ExtendedModelMap implicitModel)
/*     */   {
/* 889 */     ModelAttribute attr = (ModelAttribute)AnnotationUtils.findAnnotation(handlerMethod, ModelAttribute.class);
/* 890 */     String attrName = attr != null ? attr.value() : "";
/* 891 */     if ("".equals(attrName)) {
/* 892 */       Class resolvedType = GenericTypeResolver.resolveReturnType(handlerMethod, handlerType);
/* 893 */       attrName = Conventions.getVariableNameForReturnType(handlerMethod, resolvedType, returnValue);
/*     */     }
/* 895 */     implicitModel.addAttribute(attrName, returnValue);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.support.HandlerMethodInvoker
 * JD-Core Version:    0.6.2
 */