/*     */ package org.springframework.web.bind.annotation.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.web.bind.annotation.InitBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.SessionAttributes;
/*     */ 
/*     */ public class HandlerMethodResolver
/*     */ {
/*     */   private final Set<Method> handlerMethods;
/*     */   private final Set<Method> initBinderMethods;
/*     */   private final Set<Method> modelAttributeMethods;
/*     */   private RequestMapping typeLevelMapping;
/*     */   private boolean sessionAttributesFound;
/*     */   private final Set<String> sessionAttributeNames;
/*     */   private final Set<Class<?>> sessionAttributeTypes;
/*  69 */   private final Set<String> actualSessionAttributeNames = Collections.newSetFromMap(new ConcurrentHashMap(4))
/*  69 */     ;
/*     */ 
/*     */   public HandlerMethodResolver()
/*     */   {
/*  54 */     this.handlerMethods = new LinkedHashSet();
/*     */ 
/*  56 */     this.initBinderMethods = new LinkedHashSet();
/*     */ 
/*  58 */     this.modelAttributeMethods = new LinkedHashSet();
/*     */ 
/*  64 */     this.sessionAttributeNames = new HashSet();
/*     */ 
/*  66 */     this.sessionAttributeTypes = new HashSet();
/*     */   }
/*     */ 
/*     */   public void init(Class<?> handlerType)
/*     */   {
/*  77 */     Set handlerTypes = new LinkedHashSet();
/*  78 */     Class specificHandlerType = null;
/*  79 */     if (!Proxy.isProxyClass(handlerType)) {
/*  80 */       handlerTypes.add(handlerType);
/*  81 */       specificHandlerType = handlerType;
/*     */     }
/*  83 */     handlerTypes.addAll(Arrays.asList(handlerType.getInterfaces()));
/*  84 */     for (Class currentHandlerType : handlerTypes) {
/*  85 */       final Class targetClass = specificHandlerType != null ? specificHandlerType : currentHandlerType;
/*  86 */       ReflectionUtils.doWithMethods(currentHandlerType, new ReflectionUtils.MethodCallback()
/*     */       {
/*     */         public void doWith(Method method) {
/*  89 */           Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/*  90 */           Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/*  91 */           if ((HandlerMethodResolver.this.isHandlerMethod(specificMethod)) && ((bridgedMethod == specificMethod) || 
/*  92 */             (!HandlerMethodResolver.this
/*  92 */             .isHandlerMethod(bridgedMethod))))
/*     */           {
/*  93 */             HandlerMethodResolver.this.handlerMethods.add(specificMethod);
/*     */           }
/*  95 */           else if ((HandlerMethodResolver.this.isInitBinderMethod(specificMethod)) && ((bridgedMethod == specificMethod) || 
/*  96 */             (!HandlerMethodResolver.this
/*  96 */             .isInitBinderMethod(bridgedMethod))))
/*     */           {
/*  97 */             HandlerMethodResolver.this.initBinderMethods.add(specificMethod);
/*     */           }
/*  99 */           else if ((HandlerMethodResolver.this.isModelAttributeMethod(specificMethod)) && ((bridgedMethod == specificMethod) || 
/* 100 */             (!HandlerMethodResolver.this
/* 100 */             .isModelAttributeMethod(bridgedMethod))))
/*     */           {
/* 101 */             HandlerMethodResolver.this.modelAttributeMethods.add(specificMethod);
/*     */           }
/*     */         }
/*     */       }
/*     */       , ReflectionUtils.USER_DECLARED_METHODS);
/*     */     }
/*     */ 
/* 106 */     this.typeLevelMapping = ((RequestMapping)AnnotationUtils.findAnnotation(handlerType, RequestMapping.class));
/* 107 */     SessionAttributes sessionAttributes = (SessionAttributes)AnnotationUtils.findAnnotation(handlerType, SessionAttributes.class);
/* 108 */     this.sessionAttributesFound = (sessionAttributes != null);
/* 109 */     if (this.sessionAttributesFound) {
/* 110 */       this.sessionAttributeNames.addAll(Arrays.asList(sessionAttributes.value()));
/* 111 */       this.sessionAttributeTypes.addAll(Arrays.asList(sessionAttributes.types()));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isHandlerMethod(Method method) {
/* 116 */     return AnnotationUtils.findAnnotation(method, RequestMapping.class) != null;
/*     */   }
/*     */ 
/*     */   protected boolean isInitBinderMethod(Method method) {
/* 120 */     return AnnotationUtils.findAnnotation(method, InitBinder.class) != null;
/*     */   }
/*     */ 
/*     */   protected boolean isModelAttributeMethod(Method method) {
/* 124 */     return AnnotationUtils.findAnnotation(method, ModelAttribute.class) != null;
/*     */   }
/*     */ 
/*     */   public final boolean hasHandlerMethods()
/*     */   {
/* 129 */     return !this.handlerMethods.isEmpty();
/*     */   }
/*     */ 
/*     */   public final Set<Method> getHandlerMethods() {
/* 133 */     return this.handlerMethods;
/*     */   }
/*     */ 
/*     */   public final Set<Method> getInitBinderMethods() {
/* 137 */     return this.initBinderMethods;
/*     */   }
/*     */ 
/*     */   public final Set<Method> getModelAttributeMethods() {
/* 141 */     return this.modelAttributeMethods;
/*     */   }
/*     */ 
/*     */   public boolean hasTypeLevelMapping() {
/* 145 */     return this.typeLevelMapping != null;
/*     */   }
/*     */ 
/*     */   public RequestMapping getTypeLevelMapping() {
/* 149 */     return this.typeLevelMapping;
/*     */   }
/*     */ 
/*     */   public boolean hasSessionAttributes() {
/* 153 */     return this.sessionAttributesFound;
/*     */   }
/*     */ 
/*     */   public boolean isSessionAttribute(String attrName, Class<?> attrType) {
/* 157 */     if ((this.sessionAttributeNames.contains(attrName)) || (this.sessionAttributeTypes.contains(attrType))) {
/* 158 */       this.actualSessionAttributeNames.add(attrName);
/* 159 */       return true;
/*     */     }
/*     */ 
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */   public Set<String> getActualSessionAttributeNames()
/*     */   {
/* 167 */     return this.actualSessionAttributeNames;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.support.HandlerMethodResolver
 * JD-Core Version:    0.6.2
 */