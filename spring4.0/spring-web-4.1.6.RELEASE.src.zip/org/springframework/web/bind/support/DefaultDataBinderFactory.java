/*    */ package org.springframework.web.bind.support;
/*    */ 
/*    */ import org.springframework.web.bind.WebDataBinder;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class DefaultDataBinderFactory
/*    */   implements WebDataBinderFactory
/*    */ {
/*    */   private final WebBindingInitializer initializer;
/*    */ 
/*    */   public DefaultDataBinderFactory(WebBindingInitializer initializer)
/*    */   {
/* 38 */     this.initializer = initializer;
/*    */   }
/*    */ 
/*    */   public final WebDataBinder createBinder(NativeWebRequest webRequest, Object target, String objectName)
/*    */     throws Exception
/*    */   {
/* 49 */     WebDataBinder dataBinder = createBinderInstance(target, objectName, webRequest);
/* 50 */     if (this.initializer != null) {
/* 51 */       this.initializer.initBinder(dataBinder, webRequest);
/*    */     }
/* 53 */     initBinder(dataBinder, webRequest);
/* 54 */     return dataBinder;
/*    */   }
/*    */ 
/*    */   protected WebDataBinder createBinderInstance(Object target, String objectName, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 67 */     return new WebRequestDataBinder(target, objectName);
/*    */   }
/*    */ 
/*    */   protected void initBinder(WebDataBinder dataBinder, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.DefaultDataBinderFactory
 * JD-Core Version:    0.6.2
 */