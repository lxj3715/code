package org.springframework.web.bind.support;

public abstract interface SessionStatus
{
  public abstract void setComplete();

  public abstract boolean isComplete();
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.SessionStatus
 * JD-Core Version:    0.6.2
 */