/*    */ package org.springframework.web.bind.support;
/*    */ 
/*    */ public class SimpleSessionStatus
/*    */   implements SessionStatus
/*    */ {
/* 28 */   private boolean complete = false;
/*    */ 
/*    */   public void setComplete()
/*    */   {
/* 33 */     this.complete = true;
/*    */   }
/*    */ 
/*    */   public boolean isComplete()
/*    */   {
/* 38 */     return this.complete;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.SimpleSessionStatus
 * JD-Core Version:    0.6.2
 */