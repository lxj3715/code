package org.springframework.web.bind.support;

import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.context.request.WebRequest;

public abstract interface WebBindingInitializer
{
  public abstract void initBinder(WebDataBinder paramWebDataBinder, WebRequest paramWebRequest);
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebBindingInitializer
 * JD-Core Version:    0.6.2
 */