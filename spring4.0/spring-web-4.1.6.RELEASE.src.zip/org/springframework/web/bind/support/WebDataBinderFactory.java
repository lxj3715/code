package org.springframework.web.bind.support;

import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.context.request.NativeWebRequest;

public abstract interface WebDataBinderFactory
{
  public abstract WebDataBinder createBinder(NativeWebRequest paramNativeWebRequest, Object paramObject, String paramString)
    throws Exception;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebDataBinderFactory
 * JD-Core Version:    0.6.2
 */