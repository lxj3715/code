/*     */ package org.springframework.web.bind.support;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ 
/*     */ public class WebRequestDataBinder extends WebDataBinder
/*     */ {
/*     */   public WebRequestDataBinder(Object target)
/*     */   {
/*  80 */     super(target);
/*     */   }
/*     */ 
/*     */   public WebRequestDataBinder(Object target, String objectName)
/*     */   {
/*  90 */     super(target, objectName);
/*     */   }
/*     */ 
/*     */   public void bind(WebRequest request)
/*     */   {
/* 113 */     MutablePropertyValues mpvs = new MutablePropertyValues(request.getParameterMap());
/* 114 */     if ((isMultipartRequest(request)) && ((request instanceof NativeWebRequest))) {
/* 115 */       MultipartRequest multipartRequest = (MultipartRequest)((NativeWebRequest)request).getNativeRequest(MultipartRequest.class);
/* 116 */       if (multipartRequest != null) {
/* 117 */         bindMultipart(multipartRequest.getMultiFileMap(), mpvs);
/*     */       }
/* 119 */       else if (ClassUtils.hasMethod(HttpServletRequest.class, "getParts", new Class[0])) {
/* 120 */         HttpServletRequest serlvetRequest = (HttpServletRequest)((NativeWebRequest)request).getNativeRequest(HttpServletRequest.class);
/* 121 */         new Servlet3MultipartHelper(isBindEmptyMultipartFiles()).bindParts(serlvetRequest, mpvs);
/*     */       }
/*     */     }
/* 124 */     doBind(mpvs);
/*     */   }
/*     */ 
/*     */   private boolean isMultipartRequest(WebRequest request)
/*     */   {
/* 132 */     String contentType = request.getHeader("Content-Type");
/* 133 */     return (contentType != null) && (StringUtils.startsWithIgnoreCase(contentType, "multipart"));
/*     */   }
/*     */ 
/*     */   public void closeNoCatch()
/*     */     throws BindException
/*     */   {
/* 143 */     if (getBindingResult().hasErrors())
/* 144 */       throw new BindException(getBindingResult());
/*     */   }
/*     */ 
/*     */   private static class Servlet3MultipartHelper
/*     */   {
/*     */     private final boolean bindEmptyMultipartFiles;
/*     */ 
/*     */     public Servlet3MultipartHelper(boolean bindEmptyMultipartFiles)
/*     */     {
/* 158 */       this.bindEmptyMultipartFiles = bindEmptyMultipartFiles;
/*     */     }
/*     */ 
/*     */     public void bindParts(HttpServletRequest request, MutablePropertyValues mpvs) {
/*     */       try {
/* 163 */         MultiValueMap map = new LinkedMultiValueMap();
/* 164 */         for (Part part : request.getParts()) {
/* 165 */           map.add(part.getName(), part);
/*     */         }
/* 167 */         for (Map.Entry entry : map.entrySet())
/* 168 */           if (((List)entry.getValue()).size() == 1) {
/* 169 */             Part part = (Part)((List)entry.getValue()).get(0);
/* 170 */             if ((this.bindEmptyMultipartFiles) || (part.getSize() > 0L))
/* 171 */               mpvs.add((String)entry.getKey(), part);
/*     */           }
/*     */           else
/*     */           {
/* 175 */             mpvs.add((String)entry.getKey(), entry.getValue());
/*     */           }
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 180 */         throw new MultipartException("Failed to get request parts", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebRequestDataBinder
 * JD-Core Version:    0.6.2
 */