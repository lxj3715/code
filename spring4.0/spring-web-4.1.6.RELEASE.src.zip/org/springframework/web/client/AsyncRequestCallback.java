package org.springframework.web.client;

import java.io.IOException;
import org.springframework.http.client.AsyncClientHttpRequest;

public abstract interface AsyncRequestCallback
{
  public abstract void doWithRequest(AsyncClientHttpRequest paramAsyncClientHttpRequest)
    throws IOException;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.AsyncRequestCallback
 * JD-Core Version:    0.6.2
 */