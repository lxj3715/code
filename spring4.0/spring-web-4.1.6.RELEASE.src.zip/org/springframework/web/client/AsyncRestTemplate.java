/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.core.task.AsyncListenableTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.AsyncClientHttpRequest;
/*     */ import org.springframework.http.client.AsyncClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.client.SimpleClientHttpRequestFactory;
/*     */ import org.springframework.http.client.support.AsyncHttpAccessor;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.concurrent.FailureCallback;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.concurrent.ListenableFutureAdapter;
/*     */ import org.springframework.util.concurrent.ListenableFutureCallback;
/*     */ import org.springframework.util.concurrent.SuccessCallback;
/*     */ import org.springframework.web.util.UriTemplate;
/*     */ 
/*     */ public class AsyncRestTemplate extends AsyncHttpAccessor
/*     */   implements AsyncRestOperations
/*     */ {
/*     */   private final RestTemplate syncTemplate;
/*     */ 
/*     */   public AsyncRestTemplate()
/*     */   {
/*  82 */     this(new SimpleAsyncTaskExecutor());
/*     */   }
/*     */ 
/*     */   public AsyncRestTemplate(AsyncListenableTaskExecutor taskExecutor)
/*     */   {
/*  92 */     Assert.notNull(taskExecutor, "AsyncTaskExecutor must not be null");
/*  93 */     SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
/*  94 */     requestFactory.setTaskExecutor(taskExecutor);
/*  95 */     this.syncTemplate = new RestTemplate(requestFactory);
/*  96 */     setAsyncRequestFactory(requestFactory);
/*     */   }
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory asyncRequestFactory)
/*     */   {
/* 109 */     this(asyncRequestFactory, (ClientHttpRequestFactory)asyncRequestFactory);
/*     */   }
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory asyncRequestFactory, ClientHttpRequestFactory syncRequestFactory)
/*     */   {
/* 119 */     this(asyncRequestFactory, new RestTemplate(syncRequestFactory));
/*     */   }
/*     */ 
/*     */   public AsyncRestTemplate(AsyncClientHttpRequestFactory requestFactory, RestTemplate restTemplate)
/*     */   {
/* 129 */     Assert.notNull(restTemplate, "'restTemplate' must not be null");
/* 130 */     this.syncTemplate = restTemplate;
/* 131 */     setAsyncRequestFactory(requestFactory);
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 141 */     this.syncTemplate.setErrorHandler(errorHandler);
/*     */   }
/*     */ 
/*     */   public ResponseErrorHandler getErrorHandler()
/*     */   {
/* 146 */     return this.syncTemplate.getErrorHandler();
/*     */   }
/*     */ 
/*     */   public RestOperations getRestOperations()
/*     */   {
/* 151 */     return this.syncTemplate;
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 159 */     this.syncTemplate.setMessageConverters(messageConverters);
/*     */   }
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 166 */     return this.syncTemplate.getMessageConverters();
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(String url, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 176 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 177 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 178 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(String url, Class<T> responseType, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 185 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 186 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 187 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> getForEntity(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 192 */     AsyncRequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 193 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 194 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(String url, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 202 */     ResponseExtractor headersExtractor = headersExtractor();
/* 203 */     return execute(url, HttpMethod.HEAD, null, headersExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(String url, Map<String, ?> uriVariables) throws RestClientException
/*     */   {
/* 208 */     ResponseExtractor headersExtractor = headersExtractor();
/* 209 */     return execute(url, HttpMethod.HEAD, null, headersExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<HttpHeaders> headForHeaders(URI url) throws RestClientException
/*     */   {
/* 214 */     ResponseExtractor headersExtractor = headersExtractor();
/* 215 */     return execute(url, HttpMethod.HEAD, null, headersExtractor);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<URI> postForLocation(String url, HttpEntity<?> request, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 224 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 225 */     ResponseExtractor headersExtractor = headersExtractor();
/*     */ 
/* 227 */     ListenableFuture headersFuture = execute(url, HttpMethod.POST, requestCallback, headersExtractor, uriVariables);
/*     */ 
/* 228 */     return extractLocationHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<URI> postForLocation(String url, HttpEntity<?> request, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 235 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 236 */     ResponseExtractor headersExtractor = headersExtractor();
/*     */ 
/* 238 */     ListenableFuture headersFuture = execute(url, HttpMethod.POST, requestCallback, headersExtractor, uriVariables);
/*     */ 
/* 239 */     return extractLocationHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<URI> postForLocation(URI url, HttpEntity<?> request) throws RestClientException
/*     */   {
/* 244 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 245 */     ResponseExtractor headersExtractor = headersExtractor();
/*     */ 
/* 247 */     ListenableFuture headersFuture = execute(url, HttpMethod.POST, requestCallback, headersExtractor);
/*     */ 
/* 248 */     return extractLocationHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   private static ListenableFuture<URI> extractLocationHeader(ListenableFuture<HttpHeaders> headersFuture) {
/* 252 */     return new ListenableFuture()
/*     */     {
/*     */       public void addCallback(ListenableFutureCallback<? super URI> callback) {
/* 255 */         addCallback(callback, callback);
/*     */       }
/*     */ 
/*     */       public void addCallback(final SuccessCallback<? super URI> successCallback, final FailureCallback failureCallback) {
/* 259 */         this.val$headersFuture.addCallback(new ListenableFutureCallback()
/*     */         {
/*     */           public void onSuccess(HttpHeaders result) {
/* 262 */             successCallback.onSuccess(result.getLocation());
/*     */           }
/*     */ 
/*     */           public void onFailure(Throwable ex) {
/* 266 */             failureCallback.onFailure(ex);
/*     */           }
/*     */         });
/*     */       }
/*     */ 
/*     */       public boolean cancel(boolean mayInterruptIfRunning) {
/* 272 */         return this.val$headersFuture.cancel(mayInterruptIfRunning);
/*     */       }
/*     */ 
/*     */       public boolean isCancelled() {
/* 276 */         return this.val$headersFuture.isCancelled();
/*     */       }
/*     */ 
/*     */       public boolean isDone() {
/* 280 */         return this.val$headersFuture.isDone();
/*     */       }
/*     */ 
/*     */       public URI get() throws InterruptedException, ExecutionException {
/* 284 */         HttpHeaders headers = (HttpHeaders)this.val$headersFuture.get();
/* 285 */         return headers.getLocation();
/*     */       }
/*     */ 
/*     */       public URI get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 289 */         HttpHeaders headers = (HttpHeaders)this.val$headersFuture.get(timeout, unit);
/* 290 */         return headers.getLocation();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(String url, HttpEntity<?> request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 299 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 300 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 301 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(String url, HttpEntity<?> request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 308 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 309 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 310 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> postForEntity(URI url, HttpEntity<?> request, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 317 */     AsyncRequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 318 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 319 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> put(String url, HttpEntity<?> request, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 327 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 328 */     return execute(url, HttpMethod.PUT, requestCallback, null, uriVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> put(String url, HttpEntity<?> request, Map<String, ?> uriVariables) throws RestClientException
/*     */   {
/* 333 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 334 */     return execute(url, HttpMethod.PUT, requestCallback, null, uriVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> put(URI url, HttpEntity<?> request) throws RestClientException
/*     */   {
/* 339 */     AsyncRequestCallback requestCallback = httpEntityCallback(request);
/* 340 */     return execute(url, HttpMethod.PUT, requestCallback, null);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> delete(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 348 */     return execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> delete(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 353 */     return execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<?> delete(URI url) throws RestClientException
/*     */   {
/* 358 */     return execute(url, HttpMethod.DELETE, null, null);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(String url, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 366 */     ResponseExtractor headersExtractor = headersExtractor();
/* 367 */     ListenableFuture headersFuture = execute(url, HttpMethod.OPTIONS, null, headersExtractor, uriVariables);
/* 368 */     return extractAllowHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(String url, Map<String, ?> uriVariables) throws RestClientException
/*     */   {
/* 373 */     ResponseExtractor headersExtractor = headersExtractor();
/* 374 */     ListenableFuture headersFuture = execute(url, HttpMethod.OPTIONS, null, headersExtractor, uriVariables);
/* 375 */     return extractAllowHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   public ListenableFuture<Set<HttpMethod>> optionsForAllow(URI url) throws RestClientException
/*     */   {
/* 380 */     ResponseExtractor headersExtractor = headersExtractor();
/* 381 */     ListenableFuture headersFuture = execute(url, HttpMethod.OPTIONS, null, headersExtractor);
/* 382 */     return extractAllowHeader(headersFuture);
/*     */   }
/*     */ 
/*     */   private static ListenableFuture<Set<HttpMethod>> extractAllowHeader(ListenableFuture<HttpHeaders> headersFuture) {
/* 386 */     return new ListenableFuture()
/*     */     {
/*     */       public void addCallback(ListenableFutureCallback<? super Set<HttpMethod>> callback) {
/* 389 */         addCallback(callback, callback);
/*     */       }
/*     */ 
/*     */       public void addCallback(final SuccessCallback<? super Set<HttpMethod>> successCallback, final FailureCallback failureCallback) {
/* 393 */         this.val$headersFuture.addCallback(new ListenableFutureCallback()
/*     */         {
/*     */           public void onSuccess(HttpHeaders result) {
/* 396 */             successCallback.onSuccess(result.getAllow());
/*     */           }
/*     */ 
/*     */           public void onFailure(Throwable ex) {
/* 400 */             failureCallback.onFailure(ex);
/*     */           }
/*     */         });
/*     */       }
/*     */ 
/*     */       public boolean cancel(boolean mayInterruptIfRunning) {
/* 406 */         return this.val$headersFuture.cancel(mayInterruptIfRunning);
/*     */       }
/*     */ 
/*     */       public boolean isCancelled() {
/* 410 */         return this.val$headersFuture.isCancelled();
/*     */       }
/*     */ 
/*     */       public boolean isDone() {
/* 414 */         return this.val$headersFuture.isDone();
/*     */       }
/*     */ 
/*     */       public Set<HttpMethod> get() throws InterruptedException, ExecutionException {
/* 418 */         HttpHeaders headers = (HttpHeaders)this.val$headersFuture.get();
/* 419 */         return headers.getAllow();
/*     */       }
/*     */ 
/*     */       public Set<HttpMethod> get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 423 */         HttpHeaders headers = (HttpHeaders)this.val$headersFuture.get(timeout, unit);
/* 424 */         return headers.getAllow();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 436 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 437 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 438 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 445 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 446 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 447 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 454 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 455 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 456 */     return execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 463 */     Type type = responseType.getType();
/* 464 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 465 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 466 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 473 */     Type type = responseType.getType();
/* 474 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 475 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 476 */     return execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<ResponseEntity<T>> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 483 */     Type type = responseType.getType();
/* 484 */     AsyncRequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 485 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 486 */     return execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(String url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 496 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 497 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(String url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 504 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 505 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ListenableFuture<T> execute(URI url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 512 */     return doExecute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   protected <T> ListenableFuture<T> doExecute(URI url, HttpMethod method, AsyncRequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 530 */     Assert.notNull(url, "'url' must not be null");
/* 531 */     Assert.notNull(method, "'method' must not be null");
/*     */     try {
/* 533 */       AsyncClientHttpRequest request = createAsyncRequest(url, method);
/* 534 */       if (requestCallback != null) {
/* 535 */         requestCallback.doWithRequest(request);
/*     */       }
/* 537 */       ListenableFuture responseFuture = request.executeAsync();
/* 538 */       return new ResponseExtractorFuture(method, url, responseFuture, responseExtractor);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 542 */       throw new ResourceAccessException("I/O error on " + method.name() + " request for \"" + url + "\":" + ex
/* 542 */         .getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void logResponseStatus(HttpMethod method, URI url, ClientHttpResponse response) {
/* 547 */     if (this.logger.isDebugEnabled())
/*     */       try {
/* 549 */         this.logger.debug("Async " + method.name() + " request for \"" + url + "\" resulted in " + response
/* 550 */           .getStatusCode() + " (" + response.getStatusText() + ")");
/*     */       }
/*     */       catch (IOException localIOException)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   private void handleResponseError(HttpMethod method, URI url, ClientHttpResponse response) throws IOException
/*     */   {
/* 559 */     if (this.logger.isWarnEnabled()) {
/*     */       try {
/* 561 */         this.logger.warn("Async " + method.name() + " request for \"" + url + "\" resulted in " + response
/* 562 */           .getStatusCode() + " (" + response.getStatusText() + "); invoking error handler");
/*     */       }
/*     */       catch (IOException localIOException)
/*     */       {
/*     */       }
/*     */     }
/* 568 */     getErrorHandler().handleError(response);
/*     */   }
/*     */ 
/*     */   protected <T> AsyncRequestCallback acceptHeaderRequestCallback(Class<T> responseType)
/*     */   {
/* 577 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.acceptHeaderRequestCallback(responseType));
/*     */   }
/*     */ 
/*     */   protected <T> AsyncRequestCallback httpEntityCallback(HttpEntity<T> requestBody)
/*     */   {
/* 585 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.httpEntityCallback(requestBody));
/*     */   }
/*     */ 
/*     */   protected <T> AsyncRequestCallback httpEntityCallback(HttpEntity<T> request, Type responseType)
/*     */   {
/* 593 */     return new AsyncRequestCallbackAdapter(this.syncTemplate.httpEntityCallback(request, responseType));
/*     */   }
/*     */ 
/*     */   protected <T> ResponseExtractor<ResponseEntity<T>> responseEntityExtractor(Type responseType)
/*     */   {
/* 600 */     return this.syncTemplate.responseEntityExtractor(responseType);
/*     */   }
/*     */ 
/*     */   protected ResponseExtractor<HttpHeaders> headersExtractor()
/*     */   {
/* 607 */     return this.syncTemplate.headersExtractor();
/*     */   }
/*     */ 
/*     */   private static class AsyncRequestCallbackAdapter
/*     */     implements AsyncRequestCallback
/*     */   {
/*     */     private final RequestCallback adaptee;
/*     */ 
/*     */     public AsyncRequestCallbackAdapter(RequestCallback requestCallback)
/*     */     {
/* 671 */       this.adaptee = requestCallback;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(final AsyncClientHttpRequest request) throws IOException
/*     */     {
/* 676 */       if (this.adaptee != null)
/* 677 */         this.adaptee.doWithRequest(new ClientHttpRequest()
/*     */         {
/*     */           public ClientHttpResponse execute() throws IOException {
/* 680 */             throw new UnsupportedOperationException("execute not supported");
/*     */           }
/*     */ 
/*     */           public OutputStream getBody() throws IOException {
/* 684 */             return request.getBody();
/*     */           }
/*     */ 
/*     */           public HttpMethod getMethod() {
/* 688 */             return request.getMethod();
/*     */           }
/*     */ 
/*     */           public URI getURI() {
/* 692 */             return request.getURI();
/*     */           }
/*     */ 
/*     */           public HttpHeaders getHeaders() {
/* 696 */             return request.getHeaders();
/*     */           }
/*     */         });
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResponseExtractorFuture<T> extends ListenableFutureAdapter<T, ClientHttpResponse>
/*     */   {
/*     */     private final HttpMethod method;
/*     */     private final URI url;
/*     */     private final ResponseExtractor<T> responseExtractor;
/*     */ 
/*     */     public ResponseExtractorFuture(URI method, ListenableFuture<ClientHttpResponse> url, ResponseExtractor<T> clientHttpResponseFuture)
/*     */     {
/* 625 */       super();
/* 626 */       this.method = method;
/* 627 */       this.url = url;
/* 628 */       this.responseExtractor = responseExtractor;
/*     */     }
/*     */ 
/*     */     protected final T adapt(ClientHttpResponse response) throws ExecutionException
/*     */     {
/*     */       try {
/* 634 */         if (!AsyncRestTemplate.this.getErrorHandler().hasError(response)) {
/* 635 */           AsyncRestTemplate.this.logResponseStatus(this.method, this.url, response);
/*     */         }
/*     */         else {
/* 638 */           AsyncRestTemplate.this.handleResponseError(this.method, this.url, response);
/*     */         }
/* 640 */         return convertResponse(response);
/*     */       }
/*     */       catch (IOException ex) {
/* 643 */         throw new ExecutionException(ex);
/*     */       }
/*     */       finally {
/* 646 */         if (response != null)
/* 647 */           response.close();
/*     */       }
/*     */     }
/*     */ 
/*     */     protected T convertResponse(ClientHttpResponse response) throws IOException
/*     */     {
/* 653 */       return this.responseExtractor != null ? this.responseExtractor.extractData(response) : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.AsyncRestTemplate
 * JD-Core Version:    0.6.2
 */