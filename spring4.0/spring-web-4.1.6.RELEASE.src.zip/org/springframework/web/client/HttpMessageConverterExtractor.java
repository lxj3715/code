/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class HttpMessageConverterExtractor<T>
/*     */   implements ResponseExtractor<T>
/*     */ {
/*     */   private final Type responseType;
/*     */   private final Class<T> responseClass;
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   private final Log logger;
/*     */ 
/*     */   public HttpMessageConverterExtractor(Class<T> responseType, List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  57 */     this(responseType, messageConverters);
/*     */   }
/*     */ 
/*     */   public HttpMessageConverterExtractor(Type responseType, List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  66 */     this(responseType, messageConverters, LogFactory.getLog(HttpMessageConverterExtractor.class));
/*     */   }
/*     */ 
/*     */   HttpMessageConverterExtractor(Type responseType, List<HttpMessageConverter<?>> messageConverters, Log logger)
/*     */   {
/*  71 */     Assert.notNull(responseType, "'responseType' must not be null");
/*  72 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/*  73 */     this.responseType = responseType;
/*  74 */     this.responseClass = ((responseType instanceof Class) ? (Class)responseType : null);
/*  75 */     this.messageConverters = messageConverters;
/*  76 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   public T extractData(ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/*  83 */     MessageBodyClientHttpResponseWrapper responseWrapper = new MessageBodyClientHttpResponseWrapper(response);
/*  84 */     if ((!responseWrapper.hasMessageBody()) || (responseWrapper.hasEmptyMessageBody())) {
/*  85 */       return null;
/*     */     }
/*  87 */     MediaType contentType = getContentType(responseWrapper);
/*     */ 
/*  89 */     for (HttpMessageConverter messageConverter : this.messageConverters) {
/*  90 */       if ((messageConverter instanceof GenericHttpMessageConverter)) {
/*  91 */         GenericHttpMessageConverter genericMessageConverter = (GenericHttpMessageConverter)messageConverter;
/*  92 */         if (genericMessageConverter.canRead(this.responseType, null, contentType)) {
/*  93 */           if (this.logger.isDebugEnabled()) {
/*  94 */             this.logger.debug("Reading [" + this.responseType + "] as \"" + contentType + "\" using [" + messageConverter + "]");
/*     */           }
/*     */ 
/*  97 */           return genericMessageConverter.read(this.responseType, null, responseWrapper);
/*     */         }
/*     */       }
/* 100 */       if ((this.responseClass != null) && 
/* 101 */         (messageConverter.canRead(this.responseClass, contentType))) {
/* 102 */         if (this.logger.isDebugEnabled()) {
/* 103 */           this.logger.debug("Reading [" + this.responseClass.getName() + "] as \"" + contentType + "\" using [" + messageConverter + "]");
/*     */         }
/*     */ 
/* 106 */         return messageConverter.read(this.responseClass, responseWrapper);
/*     */       }
/*     */     }
/*     */ 
/* 110 */     throw new RestClientException("Could not extract response: no suitable HttpMessageConverter found for response type [" + this.responseType + "] and content type [" + contentType + "]");
/*     */   }
/*     */ 
/*     */   private MediaType getContentType(ClientHttpResponse response)
/*     */   {
/* 116 */     MediaType contentType = response.getHeaders().getContentType();
/* 117 */     if (contentType == null) {
/* 118 */       if (this.logger.isTraceEnabled()) {
/* 119 */         this.logger.trace("No Content-Type header found, defaulting to application/octet-stream");
/*     */       }
/* 121 */       contentType = MediaType.APPLICATION_OCTET_STREAM;
/*     */     }
/* 123 */     return contentType;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.HttpMessageConverterExtractor
 * JD-Core Version:    0.6.2
 */