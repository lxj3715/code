package org.springframework.web.client;

import java.io.IOException;
import org.springframework.http.client.ClientHttpRequest;

public abstract interface RequestCallback
{
  public abstract void doWithRequest(ClientHttpRequest paramClientHttpRequest)
    throws IOException;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.RequestCallback
 * JD-Core Version:    0.6.2
 */