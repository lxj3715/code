package org.springframework.web.client;

import java.io.IOException;
import org.springframework.http.client.ClientHttpResponse;

public abstract interface ResponseExtractor<T>
{
  public abstract T extractData(ClientHttpResponse paramClientHttpResponse)
    throws IOException;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.ResponseExtractor
 * JD-Core Version:    0.6.2
 */