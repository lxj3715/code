/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.RequestEntity;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.client.support.InterceptingHttpAccessor;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.util.UriTemplate;
/*     */ 
/*     */ public class RestTemplate extends InterceptingHttpAccessor
/*     */   implements RestOperations
/*     */ {
/* 118 */   private static boolean romePresent = ClassUtils.isPresent("com.rometools.rome.feed.WireFeed", RestTemplate.class
/* 118 */     .getClassLoader());
/*     */ 
/* 121 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", RestTemplate.class
/* 121 */     .getClassLoader());
/*     */ 
/* 124 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", RestTemplate.class
/* 124 */     .getClassLoader())) && 
/* 125 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", RestTemplate.class
/* 125 */     .getClassLoader()));
/*     */ 
/* 128 */   private static final boolean jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", RestTemplate.class
/* 128 */     .getClassLoader());
/*     */ 
/* 131 */   private static final boolean gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", RestTemplate.class
/* 131 */     .getClassLoader());
/*     */ 
/* 134 */   private final List<HttpMessageConverter<?>> messageConverters = new ArrayList();
/*     */ 
/* 136 */   private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();
/*     */ 
/* 138 */   private final ResponseExtractor<HttpHeaders> headersExtractor = new HeadersExtractor(null);
/*     */ 
/*     */   public RestTemplate()
/*     */   {
/* 146 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 147 */     this.messageConverters.add(new StringHttpMessageConverter());
/* 148 */     this.messageConverters.add(new ResourceHttpMessageConverter());
/* 149 */     this.messageConverters.add(new SourceHttpMessageConverter());
/* 150 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */ 
/* 152 */     if (romePresent) {
/* 153 */       this.messageConverters.add(new AtomFeedHttpMessageConverter());
/* 154 */       this.messageConverters.add(new RssChannelHttpMessageConverter());
/*     */     }
/* 156 */     if (jackson2XmlPresent) {
/* 157 */       this.messageConverters.add(new MappingJackson2XmlHttpMessageConverter());
/*     */     }
/* 159 */     else if (jaxb2Present) {
/* 160 */       this.messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*     */     }
/* 162 */     if (jackson2Present) {
/* 163 */       this.messageConverters.add(new MappingJackson2HttpMessageConverter());
/*     */     }
/* 165 */     else if (gsonPresent)
/* 166 */       this.messageConverters.add(new GsonHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public RestTemplate(ClientHttpRequestFactory requestFactory)
/*     */   {
/* 177 */     this();
/* 178 */     setRequestFactory(requestFactory);
/*     */   }
/*     */ 
/*     */   public RestTemplate(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 188 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/* 189 */     this.messageConverters.addAll(messageConverters);
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 198 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/*     */ 
/* 200 */     if (this.messageConverters != messageConverters) {
/* 201 */       this.messageConverters.clear();
/* 202 */       this.messageConverters.addAll(messageConverters);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 210 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 218 */     Assert.notNull(errorHandler, "'errorHandler' must not be null");
/* 219 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   public ResponseErrorHandler getErrorHandler()
/*     */   {
/* 226 */     return this.errorHandler;
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 234 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */ 
/* 236 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 236 */       getMessageConverters(), this.logger);
/* 237 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 242 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */ 
/* 244 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 244 */       getMessageConverters(), this.logger);
/* 245 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 250 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/*     */ 
/* 252 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 252 */       getMessageConverters(), this.logger);
/* 253 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 260 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 261 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 262 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 269 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 270 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 271 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(URI url, Class<T> responseType) throws RestClientException
/*     */   {
/* 276 */     RequestCallback requestCallback = acceptHeaderRequestCallback(responseType);
/* 277 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 278 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 286 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor(), urlVariables);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 291 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor(), urlVariables);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(URI url) throws RestClientException
/*     */   {
/* 296 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, headersExtractor());
/*     */   }
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 304 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 305 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, headersExtractor(), urlVariables);
/* 306 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 311 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 312 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, headersExtractor(), urlVariables);
/* 313 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public URI postForLocation(URI url, Object request) throws RestClientException
/*     */   {
/* 318 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 319 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, headersExtractor());
/* 320 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 327 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 329 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 329 */       getMessageConverters(), this.logger);
/* 330 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 337 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 339 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 339 */       getMessageConverters(), this.logger);
/* 340 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(URI url, Object request, Class<T> responseType) throws RestClientException
/*     */   {
/* 345 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/*     */ 
/* 347 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, 
/* 347 */       getMessageConverters());
/* 348 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 355 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 356 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 357 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 364 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 365 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 366 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(URI url, Object request, Class<T> responseType) throws RestClientException
/*     */   {
/* 371 */     RequestCallback requestCallback = httpEntityCallback(request, responseType);
/* 372 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 373 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public void put(String url, Object request, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 381 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 382 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void put(String url, Object request, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 387 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 388 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void put(URI url, Object request) throws RestClientException
/*     */   {
/* 393 */     RequestCallback requestCallback = httpEntityCallback(request);
/* 394 */     execute(url, HttpMethod.PUT, requestCallback, null);
/*     */   }
/*     */ 
/*     */   public void delete(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 402 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void delete(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 407 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void delete(URI url) throws RestClientException
/*     */   {
/* 412 */     execute(url, HttpMethod.DELETE, null, null);
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 420 */     ResponseExtractor headersExtractor = headersExtractor();
/* 421 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor, urlVariables);
/* 422 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 427 */     ResponseExtractor headersExtractor = headersExtractor();
/* 428 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor, urlVariables);
/* 429 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(URI url) throws RestClientException
/*     */   {
/* 434 */     ResponseExtractor headersExtractor = headersExtractor();
/* 435 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, headersExtractor);
/* 436 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 446 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 447 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 448 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 455 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 456 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 457 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 464 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 465 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 466 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 473 */     Type type = responseType.getType();
/* 474 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 475 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 476 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 483 */     Type type = responseType.getType();
/* 484 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 485 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 486 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 493 */     Type type = responseType.getType();
/* 494 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 495 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 496 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(RequestEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 503 */     Assert.notNull(requestEntity, "'requestEntity' must not be null");
/*     */ 
/* 505 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
/* 506 */     ResponseExtractor responseExtractor = responseEntityExtractor(responseType);
/* 507 */     return (ResponseEntity)execute(requestEntity.getUrl(), requestEntity.getMethod(), requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(RequestEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 514 */     Assert.notNull(requestEntity, "'requestEntity' must not be null");
/*     */ 
/* 516 */     Type type = responseType.getType();
/* 517 */     RequestCallback requestCallback = httpEntityCallback(requestEntity, type);
/* 518 */     ResponseExtractor responseExtractor = responseEntityExtractor(type);
/* 519 */     return (ResponseEntity)execute(requestEntity.getUrl(), requestEntity.getMethod(), requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 529 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 530 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 537 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 538 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 545 */     return doExecute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 561 */     Assert.notNull(url, "'url' must not be null");
/* 562 */     Assert.notNull(method, "'method' must not be null");
/* 563 */     ClientHttpResponse response = null;
/*     */     try {
/* 565 */       ClientHttpRequest request = createRequest(url, method);
/* 566 */       if (requestCallback != null) {
/* 567 */         requestCallback.doWithRequest(request);
/*     */       }
/* 569 */       response = request.execute();
/* 570 */       handleResponse(url, method, response);
/*     */       Object localObject1;
/* 571 */       if (responseExtractor != null) {
/* 572 */         return responseExtractor.extractData(response);
/*     */       }
/*     */ 
/* 575 */       return null;
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 580 */       throw new ResourceAccessException(new StringBuilder().append("I/O error on ").append(method.name()).append(" request for \"").append(url).append("\":")
/* 580 */         .append(ex
/* 580 */         .getMessage()).toString(), ex);
/*     */     }
/*     */     finally {
/* 583 */       if (response != null)
/* 584 */         response.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void handleResponse(URI url, HttpMethod method, ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/* 601 */     ResponseErrorHandler errorHandler = getErrorHandler();
/* 602 */     boolean hasError = errorHandler.hasError(response);
/* 603 */     if (this.logger.isDebugEnabled()) {
/*     */       try {
/* 605 */         this.logger.debug(new StringBuilder().append(method.name()).append(" request for \"").append(url).append("\" resulted in ")
/* 606 */           .append(response
/* 606 */           .getRawStatusCode()).append(" (").append(response.getStatusText()).append(")").append(hasError ? "; invoking error handler" : "").toString());
/*     */       }
/*     */       catch (IOException localIOException)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/* 613 */     if (hasError)
/* 614 */       errorHandler.handleError(response);
/*     */   }
/*     */ 
/*     */   protected <T> RequestCallback acceptHeaderRequestCallback(Class<T> responseType)
/*     */   {
/* 624 */     return new AcceptHeaderRequestCallback(responseType, null);
/*     */   }
/*     */ 
/*     */   protected <T> RequestCallback httpEntityCallback(Object requestBody)
/*     */   {
/* 632 */     return new HttpEntityRequestCallback(requestBody, null);
/*     */   }
/*     */ 
/*     */   protected <T> RequestCallback httpEntityCallback(Object requestBody, Type responseType)
/*     */   {
/* 640 */     return new HttpEntityRequestCallback(requestBody, responseType, null);
/*     */   }
/*     */ 
/*     */   protected <T> ResponseExtractor<ResponseEntity<T>> responseEntityExtractor(Type responseType)
/*     */   {
/* 647 */     return new ResponseEntityResponseExtractor(responseType);
/*     */   }
/*     */ 
/*     */   protected ResponseExtractor<HttpHeaders> headersExtractor()
/*     */   {
/* 654 */     return this.headersExtractor;
/*     */   }
/*     */ 
/*     */   private static class HeadersExtractor
/*     */     implements ResponseExtractor<HttpHeaders>
/*     */   {
/*     */     public HttpHeaders extractData(ClientHttpResponse response)
/*     */       throws IOException
/*     */     {
/* 826 */       return response.getHeaders();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResponseEntityResponseExtractor<T>
/*     */     implements ResponseExtractor<ResponseEntity<T>>
/*     */   {
/*     */     private final HttpMessageConverterExtractor<T> delegate;
/*     */ 
/*     */     public ResponseEntityResponseExtractor(Type responseType)
/*     */     {
/* 798 */       if ((responseType != null) && (!Void.class.equals(responseType))) {
/* 799 */         this.delegate = new HttpMessageConverterExtractor(responseType, RestTemplate.this.getMessageConverters(), RestTemplate.this.logger);
/*     */       }
/*     */       else
/* 802 */         this.delegate = null;
/*     */     }
/*     */ 
/*     */     public ResponseEntity<T> extractData(ClientHttpResponse response)
/*     */       throws IOException
/*     */     {
/* 808 */       if (this.delegate != null) {
/* 809 */         Object body = this.delegate.extractData(response);
/* 810 */         return new ResponseEntity(body, response.getHeaders(), response.getStatusCode());
/*     */       }
/*     */ 
/* 813 */       return new ResponseEntity(response.getHeaders(), response.getStatusCode());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class HttpEntityRequestCallback extends RestTemplate.AcceptHeaderRequestCallback
/*     */   {
/*     */     private final HttpEntity<?> requestEntity;
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody)
/*     */     {
/* 724 */       this(requestBody, null);
/*     */     }
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody, Type responseType) {
/* 728 */       super(responseType, null);
/* 729 */       if ((requestBody instanceof HttpEntity)) {
/* 730 */         this.requestEntity = ((HttpEntity)requestBody);
/*     */       }
/* 732 */       else if (requestBody != null) {
/* 733 */         this.requestEntity = new HttpEntity(requestBody);
/*     */       }
/*     */       else
/* 736 */         this.requestEntity = HttpEntity.EMPTY;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(ClientHttpRequest httpRequest)
/*     */       throws IOException
/*     */     {
/* 743 */       super.doWithRequest(httpRequest);
/* 744 */       if (!this.requestEntity.hasBody()) {
/* 745 */         HttpHeaders httpHeaders = httpRequest.getHeaders();
/* 746 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 747 */         if (!requestHeaders.isEmpty()) {
/* 748 */           httpHeaders.putAll(requestHeaders);
/*     */         }
/* 750 */         if (httpHeaders.getContentLength() == -1L)
/* 751 */           httpHeaders.setContentLength(0L);
/*     */       }
/*     */       else
/*     */       {
/* 755 */         Object requestBody = this.requestEntity.getBody();
/* 756 */         Class requestType = requestBody.getClass();
/* 757 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 758 */         MediaType requestContentType = requestHeaders.getContentType();
/* 759 */         for (HttpMessageConverter messageConverter : RestTemplate.this.getMessageConverters()) {
/* 760 */           if (messageConverter.canWrite(requestType, requestContentType)) {
/* 761 */             if (!requestHeaders.isEmpty()) {
/* 762 */               httpRequest.getHeaders().putAll(requestHeaders);
/*     */             }
/* 764 */             if (RestTemplate.this.logger.isDebugEnabled()) {
/* 765 */               if (requestContentType != null) {
/* 766 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] as \"" + requestContentType + "\" using [" + messageConverter + "]");
/*     */               }
/*     */               else
/*     */               {
/* 770 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] using [" + messageConverter + "]");
/*     */               }
/*     */             }
/*     */ 
/* 774 */             messageConverter.write(requestBody, requestContentType, httpRequest);
/*     */ 
/* 776 */             return;
/*     */           }
/*     */         }
/*     */ 
/* 780 */         String message = "Could not write request: no suitable HttpMessageConverter found for request type [" + requestType
/* 780 */           .getName() + "]";
/* 781 */         if (requestContentType != null) {
/* 782 */           message = message + " and content type [" + requestContentType + "]";
/*     */         }
/* 784 */         throw new RestClientException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AcceptHeaderRequestCallback
/*     */     implements RequestCallback
/*     */   {
/*     */     private final Type responseType;
/*     */ 
/*     */     private AcceptHeaderRequestCallback(Type responseType)
/*     */     {
/* 666 */       this.responseType = responseType;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(ClientHttpRequest request) throws IOException
/*     */     {
/* 671 */       if (this.responseType != null) {
/* 672 */         Class responseClass = null;
/* 673 */         if ((this.responseType instanceof Class)) {
/* 674 */           responseClass = (Class)this.responseType;
/*     */         }
/* 676 */         List allSupportedMediaTypes = new ArrayList();
/* 677 */         for (HttpMessageConverter converter : RestTemplate.this.getMessageConverters()) {
/* 678 */           if (responseClass != null) {
/* 679 */             if (converter.canRead(responseClass, null)) {
/* 680 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/* 683 */           else if ((converter instanceof GenericHttpMessageConverter)) {
/* 684 */             GenericHttpMessageConverter genericConverter = (GenericHttpMessageConverter)converter;
/* 685 */             if (genericConverter.canRead(this.responseType, null, null)) {
/* 686 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/*     */         }
/* 690 */         if (!allSupportedMediaTypes.isEmpty()) {
/* 691 */           MediaType.sortBySpecificity(allSupportedMediaTypes);
/* 692 */           if (RestTemplate.this.logger.isDebugEnabled()) {
/* 693 */             RestTemplate.this.logger.debug("Setting request Accept header to " + allSupportedMediaTypes);
/*     */           }
/*     */ 
/* 696 */           request.getHeaders().setAccept(allSupportedMediaTypes);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private List<MediaType> getSupportedMediaTypes(HttpMessageConverter<?> messageConverter) {
/* 702 */       List supportedMediaTypes = messageConverter.getSupportedMediaTypes();
/* 703 */       List result = new ArrayList(supportedMediaTypes.size());
/* 704 */       for (MediaType supportedMediaType : supportedMediaTypes) {
/* 705 */         if (supportedMediaType.getCharSet() != null)
/*     */         {
/* 707 */           supportedMediaType = new MediaType(supportedMediaType
/* 707 */             .getType(), supportedMediaType.getSubtype());
/*     */         }
/* 709 */         result.add(supportedMediaType);
/*     */       }
/* 711 */       return result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.RestTemplate
 * JD-Core Version:    0.6.2
 */