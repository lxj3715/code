/*     */ package org.springframework.web.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*     */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.access.ContextSingletonBeanFactoryLocator;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ContextLoader
/*     */ {
/*     */   public static final String CONTEXT_ID_PARAM = "contextId";
/*     */   public static final String CONFIG_LOCATION_PARAM = "contextConfigLocation";
/*     */   public static final String CONTEXT_CLASS_PARAM = "contextClass";
/*     */   public static final String CONTEXT_INITIALIZER_CLASSES_PARAM = "contextInitializerClasses";
/*     */   public static final String GLOBAL_INITIALIZER_CLASSES_PARAM = "globalInitializerClasses";
/*     */   public static final String LOCATOR_FACTORY_SELECTOR_PARAM = "locatorFactorySelector";
/*     */   public static final String LOCATOR_FACTORY_KEY_PARAM = "parentContextKey";
/*     */   private static final String INIT_PARAM_DELIMITERS = ",; \t\n";
/*     */   private static final String DEFAULT_STRATEGIES_PATH = "ContextLoader.properties";
/*     */   private static final Properties defaultStrategies;
/* 188 */   private static final Map<ClassLoader, WebApplicationContext> currentContextPerThread = new ConcurrentHashMap(1);
/*     */   private static volatile WebApplicationContext currentContext;
/*     */   private WebApplicationContext context;
/*     */   private BeanFactoryReference parentContextRef;
/*     */ 
/*     */   public ContextLoader()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContextLoader(WebApplicationContext context)
/*     */   {
/* 261 */     this.context = context;
/*     */   }
/*     */ 
/*     */   public WebApplicationContext initWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 276 */     if (servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE) != null) {
/* 277 */       throw new IllegalStateException("Cannot initialize context because there is already a root application context present - check whether you have multiple ContextLoader* definitions in your web.xml!");
/*     */     }
/*     */ 
/* 282 */     Log logger = LogFactory.getLog(ContextLoader.class);
/* 283 */     servletContext.log("Initializing Spring root WebApplicationContext");
/* 284 */     if (logger.isInfoEnabled()) {
/* 285 */       logger.info("Root WebApplicationContext: initialization started");
/*     */     }
/* 287 */     long startTime = System.currentTimeMillis();
/*     */     try
/*     */     {
/* 292 */       if (this.context == null) {
/* 293 */         this.context = createWebApplicationContext(servletContext);
/*     */       }
/* 295 */       if ((this.context instanceof ConfigurableWebApplicationContext)) {
/* 296 */         ConfigurableWebApplicationContext cwac = (ConfigurableWebApplicationContext)this.context;
/* 297 */         if (!cwac.isActive())
/*     */         {
/* 300 */           if (cwac.getParent() == null)
/*     */           {
/* 303 */             ApplicationContext parent = loadParentContext(servletContext);
/* 304 */             cwac.setParent(parent);
/*     */           }
/* 306 */           configureAndRefreshWebApplicationContext(cwac, servletContext);
/*     */         }
/*     */       }
/* 309 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, this.context);
/*     */ 
/* 311 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 312 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 313 */         currentContext = this.context;
/*     */       }
/* 315 */       else if (ccl != null) {
/* 316 */         currentContextPerThread.put(ccl, this.context);
/*     */       }
/*     */ 
/* 319 */       if (logger.isDebugEnabled()) {
/* 320 */         logger.debug("Published root WebApplicationContext as ServletContext attribute with name [" + WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE + "]");
/*     */       }
/*     */ 
/* 323 */       if (logger.isInfoEnabled()) {
/* 324 */         long elapsedTime = System.currentTimeMillis() - startTime;
/* 325 */         logger.info("Root WebApplicationContext: initialization completed in " + elapsedTime + " ms");
/*     */       }
/*     */ 
/* 328 */       return this.context;
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 331 */       logger.error("Context initialization failed", ex);
/* 332 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, ex);
/* 333 */       throw ex;
/*     */     }
/*     */     catch (Error err) {
/* 336 */       logger.error("Context initialization failed", err);
/* 337 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, err);
/* 338 */       throw err;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc)
/*     */   {
/* 355 */     Class contextClass = determineContextClass(sc);
/* 356 */     if (!ConfigurableWebApplicationContext.class.isAssignableFrom(contextClass))
/*     */     {
/* 358 */       throw new ApplicationContextException("Custom context class [" + contextClass.getName() + "] is not of type [" + ConfigurableWebApplicationContext.class
/* 358 */         .getName() + "]");
/*     */     }
/* 360 */     return (ConfigurableWebApplicationContext)BeanUtils.instantiateClass(contextClass);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc, ApplicationContext parent)
/*     */   {
/* 370 */     return createWebApplicationContext(sc);
/*     */   }
/*     */ 
/*     */   protected void configureAndRefreshWebApplicationContext(ConfigurableWebApplicationContext wac, ServletContext sc) {
/* 374 */     if (ObjectUtils.identityToString(wac).equals(wac.getId()))
/*     */     {
/* 377 */       String idParam = sc.getInitParameter("contextId");
/* 378 */       if (idParam != null) {
/* 379 */         wac.setId(idParam);
/*     */       }
/*     */       else
/*     */       {
/* 383 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + 
/* 384 */           ObjectUtils.getDisplayString(sc
/* 384 */           .getContextPath()));
/*     */       }
/*     */     }
/*     */ 
/* 388 */     wac.setServletContext(sc);
/* 389 */     String configLocationParam = sc.getInitParameter("contextConfigLocation");
/* 390 */     if (configLocationParam != null) {
/* 391 */       wac.setConfigLocation(configLocationParam);
/*     */     }
/*     */ 
/* 397 */     ConfigurableEnvironment env = wac.getEnvironment();
/* 398 */     if ((env instanceof ConfigurableWebEnvironment)) {
/* 399 */       ((ConfigurableWebEnvironment)env).initPropertySources(sc, null);
/*     */     }
/*     */ 
/* 402 */     customizeContext(sc, wac);
/* 403 */     wac.refresh();
/*     */   }
/*     */ 
/*     */   protected void customizeContext(ServletContext sc, ConfigurableWebApplicationContext wac)
/*     */   {
/* 426 */     List initializerClasses = determineContextInitializerClasses(sc);
/*     */ 
/* 427 */     if (initializerClasses.isEmpty())
/*     */     {
/* 429 */       return;
/*     */     }
/*     */ 
/* 432 */     ArrayList initializerInstances = new ArrayList();
/*     */ 
/* 435 */     for (Class initializerClass : initializerClasses)
/*     */     {
/* 437 */       Class initializerContextClass = GenericTypeResolver.resolveTypeArgument(initializerClass, ApplicationContextInitializer.class);
/*     */ 
/* 438 */       if (initializerContextClass != null) {
/* 439 */         Assert.isAssignable(initializerContextClass, wac.getClass(), String.format("Could not add context initializer [%s] since its generic parameter [%s] is not assignable from the type of application context used by this context loader [%s]: ", new Object[] { initializerClass
/* 442 */           .getName(), initializerContextClass.getName(), wac
/* 443 */           .getClass().getName() }));
/*     */       }
/* 445 */       initializerInstances.add(BeanUtils.instantiateClass(initializerClass));
/*     */     }
/*     */ 
/* 448 */     AnnotationAwareOrderComparator.sort(initializerInstances);
/* 449 */     for (ApplicationContextInitializer initializer : initializerInstances)
/* 450 */       initializer.initialize(wac);
/*     */   }
/*     */ 
/*     */   protected Class<?> determineContextClass(ServletContext servletContext)
/*     */   {
/* 463 */     String contextClassName = servletContext.getInitParameter("contextClass");
/* 464 */     if (contextClassName != null) {
/*     */       try {
/* 466 */         return ClassUtils.forName(contextClassName, ClassUtils.getDefaultClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 469 */         throw new ApplicationContextException("Failed to load custom context class [" + contextClassName + "]", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 474 */     contextClassName = defaultStrategies.getProperty(WebApplicationContext.class.getName());
/*     */     try {
/* 476 */       return ClassUtils.forName(contextClassName, ContextLoader.class.getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 479 */       throw new ApplicationContextException("Failed to load default context class [" + contextClassName + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> determineContextInitializerClasses(ServletContext servletContext)
/*     */   {
/* 494 */     List classes = new ArrayList();
/*     */ 
/* 497 */     String globalClassNames = servletContext.getInitParameter("globalInitializerClasses");
/*     */     String str1;
/*     */     String className;
/* 498 */     if (globalClassNames != null) {
/* 499 */       String[] arrayOfString1 = StringUtils.tokenizeToStringArray(globalClassNames, ",; \t\n"); int i = arrayOfString1.length; for (str1 = 0; str1 < i; str1++) { className = arrayOfString1[str1];
/* 500 */         classes.add(loadInitializerClass(className));
/*     */       }
/*     */     }
/*     */ 
/* 504 */     String localClassNames = servletContext.getInitParameter("contextInitializerClasses");
/* 505 */     if (localClassNames != null) {
/* 506 */       String[] arrayOfString2 = StringUtils.tokenizeToStringArray(localClassNames, ",; \t\n"); str1 = arrayOfString2.length; for (className = 0; className < str1; className++) { String className = arrayOfString2[className];
/* 507 */         classes.add(loadInitializerClass(className));
/*     */       }
/*     */     }
/*     */ 
/* 511 */     return classes;
/*     */   }
/*     */ 
/*     */   private Class<ApplicationContextInitializer<ConfigurableApplicationContext>> loadInitializerClass(String className)
/*     */   {
/*     */     try {
/* 517 */       Class clazz = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/* 518 */       Assert.isAssignable(ApplicationContextInitializer.class, clazz);
/* 519 */       return clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 522 */       throw new ApplicationContextException("Failed to load context initializer class [" + className + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ApplicationContext loadParentContext(ServletContext servletContext)
/*     */   {
/* 547 */     ApplicationContext parentContext = null;
/* 548 */     String locatorFactorySelector = servletContext.getInitParameter("locatorFactorySelector");
/* 549 */     String parentContextKey = servletContext.getInitParameter("parentContextKey");
/*     */ 
/* 551 */     if (parentContextKey != null)
/*     */     {
/* 553 */       BeanFactoryLocator locator = ContextSingletonBeanFactoryLocator.getInstance(locatorFactorySelector);
/* 554 */       Log logger = LogFactory.getLog(ContextLoader.class);
/* 555 */       if (logger.isDebugEnabled()) {
/* 556 */         logger.debug("Getting parent context definition: using parent context key of '" + parentContextKey + "' with BeanFactoryLocator");
/*     */       }
/*     */ 
/* 559 */       this.parentContextRef = locator.useBeanFactory(parentContextKey);
/* 560 */       parentContext = (ApplicationContext)this.parentContextRef.getFactory();
/*     */     }
/*     */ 
/* 563 */     return parentContext;
/*     */   }
/*     */ 
/*     */   public void closeWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 576 */     servletContext.log("Closing Spring root WebApplicationContext");
/*     */     try {
/* 578 */       if ((this.context instanceof ConfigurableWebApplicationContext)) {
/* 579 */         ((ConfigurableWebApplicationContext)this.context).close();
/*     */       }
/*     */ 
/* 583 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 584 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 585 */         currentContext = null;
/*     */       }
/* 587 */       else if (ccl != null) {
/* 588 */         currentContextPerThread.remove(ccl);
/*     */       }
/* 590 */       servletContext.removeAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 591 */       if (this.parentContextRef != null)
/* 592 */         this.parentContextRef.release();
/*     */     }
/*     */     finally
/*     */     {
/* 583 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 584 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 585 */         currentContext = null;
/*     */       }
/* 587 */       else if (ccl != null) {
/* 588 */         currentContextPerThread.remove(ccl);
/*     */       }
/* 590 */       servletContext.removeAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 591 */       if (this.parentContextRef != null)
/* 592 */         this.parentContextRef.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getCurrentWebApplicationContext()
/*     */   {
/* 607 */     ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 608 */     if (ccl != null) {
/* 609 */       WebApplicationContext ccpt = (WebApplicationContext)currentContextPerThread.get(ccl);
/* 610 */       if (ccpt != null) {
/* 611 */         return ccpt;
/*     */       }
/*     */     }
/* 614 */     return currentContext;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 176 */       ClassPathResource resource = new ClassPathResource("ContextLoader.properties", ContextLoader.class);
/* 177 */       defaultStrategies = PropertiesLoaderUtils.loadProperties(resource);
/*     */     }
/*     */     catch (IOException ex) {
/* 180 */       throw new IllegalStateException("Could not load 'ContextLoader.properties': " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ContextLoader
 * JD-Core Version:    0.6.2
 */