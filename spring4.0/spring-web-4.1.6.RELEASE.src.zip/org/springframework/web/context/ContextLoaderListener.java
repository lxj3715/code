/*     */ package org.springframework.web.context;
/*     */ 
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import javax.servlet.ServletContextListener;
/*     */ 
/*     */ public class ContextLoaderListener extends ContextLoader
/*     */   implements ServletContextListener
/*     */ {
/*     */   public ContextLoaderListener()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContextLoaderListener(WebApplicationContext context)
/*     */   {
/*  98 */     super(context);
/*     */   }
/*     */ 
/*     */   public void contextInitialized(ServletContextEvent event)
/*     */   {
/* 106 */     initWebApplicationContext(event.getServletContext());
/*     */   }
/*     */ 
/*     */   public void contextDestroyed(ServletContextEvent event)
/*     */   {
/* 115 */     closeWebApplicationContext(event.getServletContext());
/* 116 */     ContextCleanupListener.cleanupAttributes(event.getServletContext());
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ContextLoaderListener
 * JD-Core Version:    0.6.2
 */