package org.springframework.web.context;

import javax.servlet.ServletConfig;
import org.springframework.beans.factory.Aware;

public abstract interface ServletConfigAware extends Aware
{
  public abstract void setServletConfig(ServletConfig paramServletConfig);
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ServletConfigAware
 * JD-Core Version:    0.6.2
 */