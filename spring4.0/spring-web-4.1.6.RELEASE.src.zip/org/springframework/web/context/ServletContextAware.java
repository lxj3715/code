package org.springframework.web.context;

import javax.servlet.ServletContext;
import org.springframework.beans.factory.Aware;

public abstract interface ServletContextAware extends Aware
{
  public abstract void setServletContext(ServletContext paramServletContext);
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ServletContextAware
 * JD-Core Version:    0.6.2
 */