package org.springframework.web.context.request;

public abstract interface AsyncWebRequestInterceptor extends WebRequestInterceptor
{
  public abstract void afterConcurrentHandlingStarted(WebRequest paramWebRequest);
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.AsyncWebRequestInterceptor
 * JD-Core Version:    0.6.2
 */