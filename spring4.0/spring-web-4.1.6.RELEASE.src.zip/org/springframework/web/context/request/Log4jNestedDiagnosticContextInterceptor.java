/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.NDC;
/*     */ import org.springframework.ui.ModelMap;
/*     */ 
/*     */ public class Log4jNestedDiagnosticContextInterceptor
/*     */   implements AsyncWebRequestInterceptor
/*     */ {
/*  37 */   protected final Logger log4jLogger = Logger.getLogger(getClass());
/*     */ 
/*  39 */   private boolean includeClientInfo = false;
/*     */ 
/*     */   public void setIncludeClientInfo(boolean includeClientInfo)
/*     */   {
/*  47 */     this.includeClientInfo = includeClientInfo;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeClientInfo()
/*     */   {
/*  55 */     return this.includeClientInfo;
/*     */   }
/*     */ 
/*     */   public void preHandle(WebRequest request)
/*     */     throws Exception
/*     */   {
/*  64 */     NDC.push(getNestedDiagnosticContextMessage(request));
/*     */   }
/*     */ 
/*     */   protected String getNestedDiagnosticContextMessage(WebRequest request)
/*     */   {
/*  76 */     return request.getDescription(isIncludeClientInfo());
/*     */   }
/*     */ 
/*     */   public void postHandle(WebRequest request, ModelMap model)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void afterCompletion(WebRequest request, Exception ex)
/*     */     throws Exception
/*     */   {
/*  88 */     NDC.pop();
/*  89 */     if (NDC.getDepth() == 0)
/*  90 */       NDC.remove();
/*     */   }
/*     */ 
/*     */   public void afterConcurrentHandlingStarted(WebRequest request)
/*     */   {
/* 100 */     NDC.pop();
/* 101 */     if (NDC.getDepth() == 0)
/* 102 */       NDC.remove();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.Log4jNestedDiagnosticContextInterceptor
 * JD-Core Version:    0.6.2
 */