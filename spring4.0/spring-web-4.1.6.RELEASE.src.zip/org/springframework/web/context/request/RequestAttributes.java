package org.springframework.web.context.request;

public abstract interface RequestAttributes
{
  public static final int SCOPE_REQUEST = 0;
  public static final int SCOPE_SESSION = 1;
  public static final int SCOPE_GLOBAL_SESSION = 2;
  public static final String REFERENCE_REQUEST = "request";
  public static final String REFERENCE_SESSION = "session";

  public abstract Object getAttribute(String paramString, int paramInt);

  public abstract void setAttribute(String paramString, Object paramObject, int paramInt);

  public abstract void removeAttribute(String paramString, int paramInt);

  public abstract String[] getAttributeNames(int paramInt);

  public abstract void registerDestructionCallback(String paramString, Runnable paramRunnable, int paramInt);

  public abstract Object resolveReference(String paramString);

  public abstract String getSessionId();

  public abstract Object getSessionMutex();
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.RequestAttributes
 * JD-Core Version:    0.6.2
 */