/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ public class RequestScope extends AbstractRequestAttributesScope
/*    */ {
/*    */   protected int getScope()
/*    */   {
/* 48 */     return 0;
/*    */   }
/*    */ 
/*    */   public String getConversationId()
/*    */   {
/* 57 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.RequestScope
 * JD-Core Version:    0.6.2
 */