/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.NumberUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletRequestAttributes extends AbstractRequestAttributes
/*     */ {
/*  50 */   public static final String DESTRUCTION_CALLBACK_NAME_PREFIX = ServletRequestAttributes.class
/*  50 */     .getName() + ".DESTRUCTION_CALLBACK.";
/*     */ 
/*  52 */   protected static final Set<Class<?>> immutableValueTypes = new HashSet(16);
/*     */   private final HttpServletRequest request;
/*     */   private HttpServletResponse response;
/*     */   private volatile HttpSession session;
/*  68 */   private final Map<String, Object> sessionAttributesToUpdate = new ConcurrentHashMap(1);
/*     */ 
/*     */   public ServletRequestAttributes(HttpServletRequest request)
/*     */   {
/*  76 */     Assert.notNull(request, "Request must not be null");
/*  77 */     this.request = request;
/*     */   }
/*     */ 
/*     */   public ServletRequestAttributes(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  86 */     this(request);
/*  87 */     this.response = response;
/*     */   }
/*     */ 
/*     */   public final HttpServletRequest getRequest()
/*     */   {
/*  95 */     return this.request;
/*     */   }
/*     */ 
/*     */   public final HttpServletResponse getResponse()
/*     */   {
/* 102 */     return this.response;
/*     */   }
/*     */ 
/*     */   protected final HttpSession getSession(boolean allowCreate)
/*     */   {
/* 110 */     if (isRequestActive()) {
/* 111 */       return this.request.getSession(allowCreate);
/*     */     }
/*     */ 
/* 115 */     if ((this.session == null) && (allowCreate)) {
/* 116 */       throw new IllegalStateException("No session found and request already completed - cannot create new session!");
/*     */     }
/*     */ 
/* 119 */     return this.session;
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String name, int scope)
/*     */   {
/* 126 */     if (scope == 0) {
/* 127 */       if (!isRequestActive()) {
/* 128 */         throw new IllegalStateException("Cannot ask for request attribute - request is not active anymore!");
/*     */       }
/*     */ 
/* 131 */       return this.request.getAttribute(name);
/*     */     }
/*     */ 
/* 134 */     HttpSession session = getSession(false);
/* 135 */     if (session != null) {
/*     */       try {
/* 137 */         Object value = session.getAttribute(name);
/* 138 */         if (value != null) {
/* 139 */           this.sessionAttributesToUpdate.put(name, value);
/*     */         }
/* 141 */         return value;
/*     */       }
/*     */       catch (IllegalStateException localIllegalStateException)
/*     */       {
/*     */       }
/*     */     }
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */   public void setAttribute(String name, Object value, int scope)
/*     */   {
/* 153 */     if (scope == 0) {
/* 154 */       if (!isRequestActive()) {
/* 155 */         throw new IllegalStateException("Cannot set request attribute - request is not active anymore!");
/*     */       }
/*     */ 
/* 158 */       this.request.setAttribute(name, value);
/*     */     }
/*     */     else {
/* 161 */       HttpSession session = getSession(true);
/* 162 */       this.sessionAttributesToUpdate.remove(name);
/* 163 */       session.setAttribute(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String name, int scope)
/*     */   {
/* 169 */     if (scope == 0) {
/* 170 */       if (isRequestActive()) {
/* 171 */         this.request.removeAttribute(name);
/* 172 */         removeRequestDestructionCallback(name);
/*     */       }
/*     */     }
/*     */     else {
/* 176 */       HttpSession session = getSession(false);
/* 177 */       if (session != null) {
/* 178 */         this.sessionAttributesToUpdate.remove(name);
/*     */         try {
/* 180 */           session.removeAttribute(name);
/*     */ 
/* 182 */           session.removeAttribute(DESTRUCTION_CALLBACK_NAME_PREFIX + name);
/*     */         }
/*     */         catch (IllegalStateException localIllegalStateException)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getAttributeNames(int scope)
/*     */   {
/* 193 */     if (scope == 0) {
/* 194 */       if (!isRequestActive()) {
/* 195 */         throw new IllegalStateException("Cannot ask for request attributes - request is not active anymore!");
/*     */       }
/*     */ 
/* 198 */       return StringUtils.toStringArray(this.request.getAttributeNames());
/*     */     }
/*     */ 
/* 201 */     HttpSession session = getSession(false);
/* 202 */     if (session != null) {
/*     */       try {
/* 204 */         return StringUtils.toStringArray(session.getAttributeNames());
/*     */       }
/*     */       catch (IllegalStateException localIllegalStateException)
/*     */       {
/*     */       }
/*     */     }
/* 210 */     return new String[0];
/*     */   }
/*     */ 
/*     */   public void registerDestructionCallback(String name, Runnable callback, int scope)
/*     */   {
/* 216 */     if (scope == 0) {
/* 217 */       registerRequestDestructionCallback(name, callback);
/*     */     }
/*     */     else
/* 220 */       registerSessionDestructionCallback(name, callback);
/*     */   }
/*     */ 
/*     */   public Object resolveReference(String key)
/*     */   {
/* 226 */     if ("request".equals(key)) {
/* 227 */       return this.request;
/*     */     }
/* 229 */     if ("session".equals(key)) {
/* 230 */       return getSession(true);
/*     */     }
/*     */ 
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */   public String getSessionId()
/*     */   {
/* 239 */     return getSession(true).getId();
/*     */   }
/*     */ 
/*     */   public Object getSessionMutex()
/*     */   {
/* 244 */     return WebUtils.getSessionMutex(getSession(true));
/*     */   }
/*     */ 
/*     */   protected void updateAccessedSessionAttributes()
/*     */   {
/* 255 */     this.session = this.request.getSession(false);
/*     */ 
/* 257 */     if (this.session != null) {
/*     */       try {
/* 259 */         for (Map.Entry entry : this.sessionAttributesToUpdate.entrySet()) {
/* 260 */           String name = (String)entry.getKey();
/* 261 */           Object newValue = entry.getValue();
/* 262 */           Object oldValue = this.session.getAttribute(name);
/* 263 */           if ((oldValue == newValue) && (!isImmutableSessionAttribute(name, newValue))) {
/* 264 */             this.session.setAttribute(name, newValue);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IllegalStateException localIllegalStateException1)
/*     */       {
/*     */       }
/*     */     }
/* 272 */     this.sessionAttributesToUpdate.clear();
/*     */   }
/*     */ 
/*     */   protected boolean isImmutableSessionAttribute(String name, Object value)
/*     */   {
/* 288 */     return (value == null) || (immutableValueTypes.contains(value.getClass()));
/*     */   }
/*     */ 
/*     */   protected void registerSessionDestructionCallback(String name, Runnable callback)
/*     */   {
/* 299 */     HttpSession session = getSession(true);
/* 300 */     session.setAttribute(DESTRUCTION_CALLBACK_NAME_PREFIX + name, new DestructionCallbackBindingListener(callback));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 307 */     return this.request.toString();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  55 */     immutableValueTypes.addAll(NumberUtils.STANDARD_NUMBER_TYPES);
/*  56 */     immutableValueTypes.add(Boolean.class);
/*  57 */     immutableValueTypes.add(Character.class);
/*  58 */     immutableValueTypes.add(String.class);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.ServletRequestAttributes
 * JD-Core Version:    0.6.2
 */