/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletWebRequest extends ServletRequestAttributes
/*     */   implements NativeWebRequest
/*     */ {
/*     */   private static final String HEADER_ETAG = "ETag";
/*     */   private static final String HEADER_IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*     */   private static final String METHOD_GET = "GET";
/*     */   private static final String METHOD_HEAD = "HEAD";
/*  55 */   private boolean notModified = false;
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request)
/*     */   {
/*  63 */     super(request);
/*     */   }
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  72 */     super(request, response);
/*     */   }
/*     */ 
/*     */   public Object getNativeRequest()
/*     */   {
/*  78 */     return getRequest();
/*     */   }
/*     */ 
/*     */   public Object getNativeResponse()
/*     */   {
/*  83 */     return getResponse();
/*     */   }
/*     */ 
/*     */   public <T> T getNativeRequest(Class<T> requiredType)
/*     */   {
/*  88 */     return WebUtils.getNativeRequest(getRequest(), requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T getNativeResponse(Class<T> requiredType)
/*     */   {
/*  93 */     return WebUtils.getNativeResponse(getResponse(), requiredType);
/*     */   }
/*     */ 
/*     */   public HttpMethod getHttpMethod()
/*     */   {
/* 102 */     return HttpMethod.valueOf(getRequest().getMethod().trim().toUpperCase());
/*     */   }
/*     */ 
/*     */   public String getHeader(String headerName)
/*     */   {
/* 107 */     return getRequest().getHeader(headerName);
/*     */   }
/*     */ 
/*     */   public String[] getHeaderValues(String headerName)
/*     */   {
/* 112 */     String[] headerValues = StringUtils.toStringArray(getRequest().getHeaders(headerName));
/* 113 */     return !ObjectUtils.isEmpty(headerValues) ? headerValues : null;
/*     */   }
/*     */ 
/*     */   public Iterator<String> getHeaderNames()
/*     */   {
/* 118 */     return CollectionUtils.toIterator(getRequest().getHeaderNames());
/*     */   }
/*     */ 
/*     */   public String getParameter(String paramName)
/*     */   {
/* 123 */     return getRequest().getParameter(paramName);
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String paramName)
/*     */   {
/* 128 */     return getRequest().getParameterValues(paramName);
/*     */   }
/*     */ 
/*     */   public Iterator<String> getParameterNames()
/*     */   {
/* 133 */     return CollectionUtils.toIterator(getRequest().getParameterNames());
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 138 */     return getRequest().getParameterMap();
/*     */   }
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/* 143 */     return getRequest().getLocale();
/*     */   }
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 148 */     return getRequest().getContextPath();
/*     */   }
/*     */ 
/*     */   public String getRemoteUser()
/*     */   {
/* 153 */     return getRequest().getRemoteUser();
/*     */   }
/*     */ 
/*     */   public Principal getUserPrincipal()
/*     */   {
/* 158 */     return getRequest().getUserPrincipal();
/*     */   }
/*     */ 
/*     */   public boolean isUserInRole(String role)
/*     */   {
/* 163 */     return getRequest().isUserInRole(role);
/*     */   }
/*     */ 
/*     */   public boolean isSecure()
/*     */   {
/* 168 */     return getRequest().isSecure();
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(long lastModifiedTimestamp)
/*     */   {
/* 174 */     HttpServletResponse response = getResponse();
/* 175 */     if ((lastModifiedTimestamp >= 0L) && (!this.notModified) && ((response == null) || 
/* 176 */       (!response
/* 176 */       .containsHeader("Last-Modified"))))
/*     */     {
/* 177 */       long ifModifiedSince = -1L;
/*     */       try {
/* 179 */         ifModifiedSince = getRequest().getDateHeader("If-Modified-Since");
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 182 */         String headerValue = getRequest().getHeader("If-Modified-Since");
/*     */ 
/* 184 */         int separatorIndex = headerValue.indexOf(';');
/* 185 */         if (separatorIndex != -1) {
/* 186 */           String datePart = headerValue.substring(0, separatorIndex);
/*     */           try {
/* 188 */             ifModifiedSince = Date.parse(datePart);
/*     */           }
/*     */           catch (IllegalArgumentException localIllegalArgumentException1)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/* 195 */       this.notModified = (ifModifiedSince >= lastModifiedTimestamp / 1000L * 1000L);
/* 196 */       if (response != null) {
/* 197 */         if ((this.notModified) && (supportsNotModifiedStatus())) {
/* 198 */           response.setStatus(304);
/*     */         }
/*     */         else {
/* 201 */           response.setDateHeader("Last-Modified", lastModifiedTimestamp);
/*     */         }
/*     */       }
/*     */     }
/* 205 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(String etag)
/*     */   {
/* 210 */     HttpServletResponse response = getResponse();
/* 211 */     if ((StringUtils.hasLength(etag)) && (!this.notModified) && ((response == null) || 
/* 212 */       (!response
/* 212 */       .containsHeader("ETag"))))
/*     */     {
/* 213 */       String ifNoneMatch = getRequest().getHeader("If-None-Match");
/* 214 */       this.notModified = etag.equals(ifNoneMatch);
/* 215 */       if (response != null) {
/* 216 */         if ((this.notModified) && (supportsNotModifiedStatus())) {
/* 217 */           response.setStatus(304);
/*     */         }
/*     */         else {
/* 220 */           response.setHeader("ETag", etag);
/*     */         }
/*     */       }
/*     */     }
/* 224 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   private boolean supportsNotModifiedStatus() {
/* 228 */     String method = getRequest().getMethod();
/* 229 */     return ("GET".equals(method)) || ("HEAD".equals(method));
/*     */   }
/*     */ 
/*     */   public boolean isNotModified() {
/* 233 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public String getDescription(boolean includeClientInfo)
/*     */   {
/* 238 */     HttpServletRequest request = getRequest();
/* 239 */     StringBuilder sb = new StringBuilder();
/* 240 */     sb.append("uri=").append(request.getRequestURI());
/* 241 */     if (includeClientInfo) {
/* 242 */       String client = request.getRemoteAddr();
/* 243 */       if (StringUtils.hasLength(client)) {
/* 244 */         sb.append(";client=").append(client);
/*     */       }
/* 246 */       HttpSession session = request.getSession(false);
/* 247 */       if (session != null) {
/* 248 */         sb.append(";session=").append(session.getId());
/*     */       }
/* 250 */       String user = request.getRemoteUser();
/* 251 */       if (StringUtils.hasLength(user)) {
/* 252 */         sb.append(";user=").append(user);
/*     */       }
/*     */     }
/* 255 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 261 */     return new StringBuilder().append("ServletWebRequest: ").append(getDescription(true)).toString();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.ServletWebRequest
 * JD-Core Version:    0.6.2
 */