package org.springframework.web.context.request;

import org.springframework.ui.ModelMap;

public abstract interface WebRequestInterceptor
{
  public abstract void preHandle(WebRequest paramWebRequest)
    throws Exception;

  public abstract void postHandle(WebRequest paramWebRequest, ModelMap paramModelMap)
    throws Exception;

  public abstract void afterCompletion(WebRequest paramWebRequest, Exception paramException)
    throws Exception;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.WebRequestInterceptor
 * JD-Core Version:    0.6.2
 */