/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class DeferredResult<T>
/*     */ {
/*  52 */   private static final Log logger = LogFactory.getLog(DeferredResult.class);
/*     */ 
/*  54 */   private static final Object RESULT_NONE = new Object();
/*     */   private final Long timeout;
/*     */   private final Object timeoutResult;
/*     */   private Runnable timeoutCallback;
/*     */   private Runnable completionCallback;
/*     */   private DeferredResultHandler resultHandler;
/*  67 */   private Object result = RESULT_NONE;
/*     */   private boolean expired;
/*     */ 
/*     */   public DeferredResult()
/*     */   {
/*  76 */     this(null, RESULT_NONE);
/*     */   }
/*     */ 
/*     */   public DeferredResult(long timeout)
/*     */   {
/*  84 */     this(Long.valueOf(timeout), RESULT_NONE);
/*     */   }
/*     */ 
/*     */   public DeferredResult(Long timeout, Object timeoutResult)
/*     */   {
/*  94 */     this.timeoutResult = timeoutResult;
/*  95 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public final boolean isSetOrExpired()
/*     */   {
/* 108 */     return (this.result != RESULT_NONE) || (this.expired);
/*     */   }
/*     */ 
/*     */   public boolean hasResult()
/*     */   {
/* 115 */     return this.result != RESULT_NONE;
/*     */   }
/*     */ 
/*     */   public Object getResult()
/*     */   {
/* 124 */     return hasResult() ? this.result : null;
/*     */   }
/*     */ 
/*     */   final Long getTimeoutValue()
/*     */   {
/* 131 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void onTimeout(Runnable callback)
/*     */   {
/* 143 */     this.timeoutCallback = callback;
/*     */   }
/*     */ 
/*     */   public void onCompletion(Runnable callback)
/*     */   {
/* 153 */     this.completionCallback = callback;
/*     */   }
/*     */ 
/*     */   public final void setResultHandler(DeferredResultHandler resultHandler)
/*     */   {
/* 162 */     Assert.notNull(resultHandler, "DeferredResultHandler is required");
/* 163 */     synchronized (this) {
/* 164 */       this.resultHandler = resultHandler;
/* 165 */       if ((this.result != RESULT_NONE) && (!this.expired))
/*     */         try {
/* 167 */           this.resultHandler.handleResult(this.result);
/*     */         }
/*     */         catch (Throwable t) {
/* 170 */           logger.trace("DeferredResult not handled", t);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean setResult(T result)
/*     */   {
/* 184 */     return setResultInternal(result);
/*     */   }
/*     */ 
/*     */   private boolean setResultInternal(Object result) {
/* 188 */     synchronized (this) {
/* 189 */       if (isSetOrExpired()) {
/* 190 */         return false;
/*     */       }
/* 192 */       this.result = result;
/*     */     }
/* 194 */     if (this.resultHandler != null) {
/* 195 */       this.resultHandler.handleResult(this.result);
/*     */     }
/* 197 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean setErrorResult(Object result)
/*     */   {
/* 211 */     return setResultInternal(result);
/*     */   }
/*     */ 
/*     */   final DeferredResultProcessingInterceptor getInterceptor() {
/* 215 */     return new DeferredResultProcessingInterceptorAdapter()
/*     */     {
/*     */       public <S> boolean handleTimeout(NativeWebRequest request, DeferredResult<S> deferredResult)
/*     */       {
/* 219 */         if (DeferredResult.this.timeoutCallback != null) {
/* 220 */           DeferredResult.this.timeoutCallback.run();
/*     */         }
/* 222 */         if (DeferredResult.this.timeoutResult != DeferredResult.RESULT_NONE) {
/* 223 */           DeferredResult.this.setResultInternal(DeferredResult.this.timeoutResult);
/*     */         }
/* 225 */         return true;
/*     */       }
/*     */ 
/*     */       public <S> void afterCompletion(NativeWebRequest request, DeferredResult<S> deferredResult)
/*     */       {
/* 230 */         synchronized (DeferredResult.this) {
/* 231 */           DeferredResult.this.expired = true;
/*     */         }
/* 233 */         if (DeferredResult.this.completionCallback != null)
/* 234 */           DeferredResult.this.completionCallback.run();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static abstract interface DeferredResultHandler
/*     */   {
/*     */     public abstract void handleResult(Object paramObject);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.DeferredResult
 * JD-Core Version:    0.6.2
 */