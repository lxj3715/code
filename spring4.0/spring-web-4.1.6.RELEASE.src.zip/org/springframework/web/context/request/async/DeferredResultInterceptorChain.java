/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ class DeferredResultInterceptorChain
/*    */ {
/* 33 */   private static final Log logger = LogFactory.getLog(DeferredResultInterceptorChain.class);
/*    */   private final List<DeferredResultProcessingInterceptor> interceptors;
/* 37 */   private int preProcessingIndex = -1;
/*    */ 
/*    */   public DeferredResultInterceptorChain(List<DeferredResultProcessingInterceptor> interceptors)
/*    */   {
/* 41 */     this.interceptors = interceptors;
/*    */   }
/*    */ 
/*    */   public void applyBeforeConcurrentHandling(NativeWebRequest request, DeferredResult<?> deferredResult) throws Exception {
/* 45 */     for (DeferredResultProcessingInterceptor interceptor : this.interceptors)
/* 46 */       interceptor.beforeConcurrentHandling(request, deferredResult);
/*    */   }
/*    */ 
/*    */   public void applyPreProcess(NativeWebRequest request, DeferredResult<?> deferredResult) throws Exception
/*    */   {
/* 51 */     for (DeferredResultProcessingInterceptor interceptor : this.interceptors) {
/* 52 */       interceptor.preProcess(request, deferredResult);
/* 53 */       this.preProcessingIndex += 1;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object applyPostProcess(NativeWebRequest request, DeferredResult<?> deferredResult, Object concurrentResult) {
/*    */     try {
/* 59 */       for (int i = this.preProcessingIndex; i >= 0; i--)
/* 60 */         ((DeferredResultProcessingInterceptor)this.interceptors.get(i)).postProcess(request, deferredResult, concurrentResult);
/*    */     }
/*    */     catch (Throwable t)
/*    */     {
/* 64 */       return t;
/*    */     }
/* 66 */     return concurrentResult;
/*    */   }
/*    */ 
/*    */   public void triggerAfterTimeout(NativeWebRequest request, DeferredResult<?> deferredResult) throws Exception {
/* 70 */     for (DeferredResultProcessingInterceptor interceptor : this.interceptors) {
/* 71 */       if (deferredResult.isSetOrExpired()) {
/* 72 */         return;
/*    */       }
/* 74 */       if (!interceptor.handleTimeout(request, deferredResult))
/*    */         break;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void triggerAfterCompletion(NativeWebRequest request, DeferredResult<?> deferredResult)
/*    */   {
/* 81 */     for (int i = this.preProcessingIndex; i >= 0; i--)
/*    */       try {
/* 83 */         ((DeferredResultProcessingInterceptor)this.interceptors.get(i)).afterCompletion(request, deferredResult);
/*    */       }
/*    */       catch (Throwable t) {
/* 86 */         logger.error("afterCompletion error", t);
/*    */       }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.DeferredResultInterceptorChain
 * JD-Core Version:    0.6.2
 */