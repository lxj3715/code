/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public abstract class DeferredResultProcessingInterceptorAdapter
/*    */   implements DeferredResultProcessingInterceptor
/*    */ {
/*    */   public <T> void beforeConcurrentHandling(NativeWebRequest request, DeferredResult<T> deferredResult)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public <T> void preProcess(NativeWebRequest request, DeferredResult<T> deferredResult)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public <T> void postProcess(NativeWebRequest request, DeferredResult<T> deferredResult, Object concurrentResult)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public <T> boolean handleTimeout(NativeWebRequest request, DeferredResult<T> deferredResult)
/*    */     throws Exception
/*    */   {
/* 59 */     return true;
/*    */   }
/*    */ 
/*    */   public <T> void afterCompletion(NativeWebRequest request, DeferredResult<T> deferredResult)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.DeferredResultProcessingInterceptorAdapter
 * JD-Core Version:    0.6.2
 */