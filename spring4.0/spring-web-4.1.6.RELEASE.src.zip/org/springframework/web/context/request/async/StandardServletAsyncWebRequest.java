/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.servlet.AsyncContext;
/*     */ import javax.servlet.AsyncEvent;
/*     */ import javax.servlet.AsyncListener;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ 
/*     */ public class StandardServletAsyncWebRequest extends ServletWebRequest
/*     */   implements AsyncWebRequest, AsyncListener
/*     */ {
/*     */   private Long timeout;
/*     */   private AsyncContext asyncContext;
/*  49 */   private AtomicBoolean asyncCompleted = new AtomicBoolean(false);
/*     */ 
/*  51 */   private final List<Runnable> timeoutHandlers = new ArrayList();
/*     */ 
/*  53 */   private final List<Runnable> completionHandlers = new ArrayList();
/*     */ 
/*     */   public StandardServletAsyncWebRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  62 */     super(request, response);
/*     */   }
/*     */ 
/*     */   public void setTimeout(Long timeout)
/*     */   {
/*  72 */     Assert.state(!isAsyncStarted(), "Cannot change the timeout with concurrent handling in progress");
/*  73 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public void addTimeoutHandler(Runnable timeoutHandler)
/*     */   {
/*  78 */     this.timeoutHandlers.add(timeoutHandler);
/*     */   }
/*     */ 
/*     */   public void addCompletionHandler(Runnable runnable)
/*     */   {
/*  83 */     this.completionHandlers.add(runnable);
/*     */   }
/*     */ 
/*     */   public boolean isAsyncStarted()
/*     */   {
/*  88 */     return (this.asyncContext != null) && (getRequest().isAsyncStarted());
/*     */   }
/*     */ 
/*     */   public boolean isAsyncComplete()
/*     */   {
/*  98 */     return this.asyncCompleted.get();
/*     */   }
/*     */ 
/*     */   public void startAsync()
/*     */   {
/* 103 */     Assert.state(getRequest().isAsyncSupported(), "Async support must be enabled on a servlet and for all filters involved in async request processing. This is done in Java code using the Servlet API or by adding \"<async-supported>true</async-supported>\" to servlet and filter declarations in web.xml.");
/*     */ 
/* 108 */     Assert.state(!isAsyncComplete(), "Async processing has already completed");
/* 109 */     if (isAsyncStarted()) {
/* 110 */       return;
/*     */     }
/* 112 */     this.asyncContext = getRequest().startAsync(getRequest(), getResponse());
/* 113 */     this.asyncContext.addListener(this);
/* 114 */     if (this.timeout != null)
/* 115 */       this.asyncContext.setTimeout(this.timeout.longValue());
/*     */   }
/*     */ 
/*     */   public void dispatch()
/*     */   {
/* 121 */     Assert.notNull(this.asyncContext, "Cannot dispatch without an AsyncContext");
/* 122 */     this.asyncContext.dispatch();
/*     */   }
/*     */ 
/*     */   public void onStartAsync(AsyncEvent event)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void onError(AsyncEvent event)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void onTimeout(AsyncEvent event)
/*     */     throws IOException
/*     */   {
/* 139 */     for (Runnable handler : this.timeoutHandlers)
/* 140 */       handler.run();
/*     */   }
/*     */ 
/*     */   public void onComplete(AsyncEvent event)
/*     */     throws IOException
/*     */   {
/* 146 */     for (Runnable handler : this.completionHandlers) {
/* 147 */       handler.run();
/*     */     }
/* 149 */     this.asyncContext = null;
/* 150 */     this.asyncCompleted.set(true);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.StandardServletAsyncWebRequest
 * JD-Core Version:    0.6.2
 */