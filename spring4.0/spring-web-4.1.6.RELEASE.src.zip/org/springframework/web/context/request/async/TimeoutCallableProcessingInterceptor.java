/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class TimeoutCallableProcessingInterceptor extends CallableProcessingInterceptorAdapter
/*    */ {
/*    */   public <T> Object handleTimeout(NativeWebRequest request, Callable<T> task)
/*    */     throws Exception
/*    */   {
/* 41 */     HttpServletResponse servletResponse = (HttpServletResponse)request.getNativeResponse(HttpServletResponse.class);
/* 42 */     if (!servletResponse.isCommitted()) {
/* 43 */       servletResponse.sendError(HttpStatus.SERVICE_UNAVAILABLE.value());
/*    */     }
/* 45 */     return CallableProcessingInterceptor.RESPONSE_HANDLED;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.TimeoutCallableProcessingInterceptor
 * JD-Core Version:    0.6.2
 */