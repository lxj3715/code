/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class TimeoutDeferredResultProcessingInterceptor extends DeferredResultProcessingInterceptorAdapter
/*    */ {
/*    */   public <T> boolean handleTimeout(NativeWebRequest request, DeferredResult<T> deferredResult)
/*    */     throws Exception
/*    */   {
/* 40 */     HttpServletResponse servletResponse = (HttpServletResponse)request.getNativeResponse(HttpServletResponse.class);
/* 41 */     if (!servletResponse.isCommitted()) {
/* 42 */       servletResponse.sendError(HttpStatus.SERVICE_UNAVAILABLE.value());
/*    */     }
/* 44 */     return false;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.TimeoutDeferredResultProcessingInterceptor
 * JD-Core Version:    0.6.2
 */