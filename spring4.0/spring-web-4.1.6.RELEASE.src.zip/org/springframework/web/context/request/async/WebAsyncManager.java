/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public final class WebAsyncManager
/*     */ {
/*  59 */   private static final Object RESULT_NONE = new Object();
/*     */ 
/*  61 */   private static final Log logger = LogFactory.getLog(WebAsyncManager.class);
/*     */ 
/*  63 */   private static final UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  65 */   private static final CallableProcessingInterceptor timeoutCallableInterceptor = new TimeoutCallableProcessingInterceptor();
/*     */ 
/*  68 */   private static final DeferredResultProcessingInterceptor timeoutDeferredResultInterceptor = new TimeoutDeferredResultProcessingInterceptor();
/*     */   private AsyncWebRequest asyncWebRequest;
/*  74 */   private AsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor(getClass().getSimpleName());
/*     */ 
/*  76 */   private Object concurrentResult = RESULT_NONE;
/*     */   private Object[] concurrentResultContext;
/*  80 */   private final Map<Object, CallableProcessingInterceptor> callableInterceptors = new LinkedHashMap();
/*     */ 
/*  83 */   private final Map<Object, DeferredResultProcessingInterceptor> deferredResultInterceptors = new LinkedHashMap();
/*     */ 
/*     */   public void setAsyncWebRequest(final AsyncWebRequest asyncWebRequest)
/*     */   {
/* 106 */     Assert.notNull(asyncWebRequest, "AsyncWebRequest must not be null");
/* 107 */     Assert.state(!isConcurrentHandlingStarted(), "Can't set AsyncWebRequest with concurrent handling in progress");
/* 108 */     this.asyncWebRequest = asyncWebRequest;
/* 109 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 112 */         asyncWebRequest.removeAttribute(WebAsyncUtils.WEB_ASYNC_MANAGER_ATTRIBUTE, 0);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void setTaskExecutor(AsyncTaskExecutor taskExecutor)
/*     */   {
/* 123 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */   public boolean isConcurrentHandlingStarted()
/*     */   {
/* 135 */     return (this.asyncWebRequest != null) && (this.asyncWebRequest.isAsyncStarted());
/*     */   }
/*     */ 
/*     */   public boolean hasConcurrentResult()
/*     */   {
/* 142 */     return this.concurrentResult != RESULT_NONE;
/*     */   }
/*     */ 
/*     */   public Object getConcurrentResult()
/*     */   {
/* 152 */     return this.concurrentResult;
/*     */   }
/*     */ 
/*     */   public Object[] getConcurrentResultContext()
/*     */   {
/* 161 */     return this.concurrentResultContext;
/*     */   }
/*     */ 
/*     */   public CallableProcessingInterceptor getCallableInterceptor(Object key)
/*     */   {
/* 170 */     return (CallableProcessingInterceptor)this.callableInterceptors.get(key);
/*     */   }
/*     */ 
/*     */   public DeferredResultProcessingInterceptor getDeferredResultInterceptor(Object key)
/*     */   {
/* 179 */     return (DeferredResultProcessingInterceptor)this.deferredResultInterceptors.get(key);
/*     */   }
/*     */ 
/*     */   public void registerCallableInterceptor(Object key, CallableProcessingInterceptor interceptor)
/*     */   {
/* 188 */     Assert.notNull(key, "Key is required");
/* 189 */     Assert.notNull(interceptor, "CallableProcessingInterceptor  is required");
/* 190 */     this.callableInterceptors.put(key, interceptor);
/*     */   }
/*     */ 
/*     */   public void registerCallableInterceptors(CallableProcessingInterceptor[] interceptors)
/*     */   {
/* 199 */     Assert.notNull(interceptors, "A CallableProcessingInterceptor is required");
/* 200 */     for (CallableProcessingInterceptor interceptor : interceptors) {
/* 201 */       String key = interceptor.getClass().getName() + ":" + interceptor.hashCode();
/* 202 */       this.callableInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerDeferredResultInterceptor(Object key, DeferredResultProcessingInterceptor interceptor)
/*     */   {
/* 212 */     Assert.notNull(key, "Key is required");
/* 213 */     Assert.notNull(interceptor, "DeferredResultProcessingInterceptor is required");
/* 214 */     this.deferredResultInterceptors.put(key, interceptor);
/*     */   }
/*     */ 
/*     */   public void registerDeferredResultInterceptors(DeferredResultProcessingInterceptor[] interceptors)
/*     */   {
/* 223 */     Assert.notNull(interceptors, "A DeferredResultProcessingInterceptor is required");
/* 224 */     for (DeferredResultProcessingInterceptor interceptor : interceptors) {
/* 225 */       String key = interceptor.getClass().getName() + ":" + interceptor.hashCode();
/* 226 */       this.deferredResultInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearConcurrentResult()
/*     */   {
/* 235 */     this.concurrentResult = RESULT_NONE;
/* 236 */     this.concurrentResultContext = null;
/*     */   }
/*     */ 
/*     */   public void startCallableProcessing(Callable<?> callable, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 254 */     Assert.notNull(callable, "Callable must not be null");
/* 255 */     startCallableProcessing(new WebAsyncTask(callable), processingContext);
/*     */   }
/*     */ 
/*     */   public void startCallableProcessing(WebAsyncTask<?> webAsyncTask, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 268 */     Assert.notNull(webAsyncTask, "WebAsyncTask must not be null");
/* 269 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */ 
/* 271 */     Long timeout = webAsyncTask.getTimeout();
/* 272 */     if (timeout != null) {
/* 273 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */ 
/* 276 */     AsyncTaskExecutor executor = webAsyncTask.getExecutor();
/* 277 */     if (executor != null) {
/* 278 */       this.taskExecutor = executor;
/*     */     }
/*     */ 
/* 281 */     List interceptors = new ArrayList();
/* 282 */     interceptors.add(webAsyncTask.getInterceptor());
/* 283 */     interceptors.addAll(this.callableInterceptors.values());
/* 284 */     interceptors.add(timeoutCallableInterceptor);
/*     */ 
/* 286 */     final Callable callable = webAsyncTask.getCallable();
/* 287 */     final CallableInterceptorChain interceptorChain = new CallableInterceptorChain(interceptors);
/*     */ 
/* 289 */     this.asyncWebRequest.addTimeoutHandler(new Object()
/*     */     {
/*     */       public void run() {
/* 292 */         WebAsyncManager.logger.debug("Processing timeout");
/* 293 */         Object result = interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, callable);
/* 294 */         if (result != CallableProcessingInterceptor.RESULT_NONE)
/* 295 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */       }
/*     */     });
/* 300 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 303 */         interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, callable);
/*     */       }
/*     */     });
/* 307 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, callable);
/* 308 */     startAsyncProcessing(processingContext);
/*     */ 
/* 310 */     this.taskExecutor.submit(new Object()
/*     */     {
/*     */       public void run() {
/* 313 */         Object result = null;
/*     */         try {
/* 315 */           interceptorChain.applyPreProcess(WebAsyncManager.this.asyncWebRequest, callable);
/* 316 */           result = callable.call();
/*     */         }
/*     */         catch (Throwable ex) {
/* 319 */           result = ex;
/*     */         }
/*     */         finally {
/* 322 */           result = interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, callable, result);
/*     */         }
/* 324 */         WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private void setConcurrentResultAndDispatch(Object result) {
/* 330 */     synchronized (this) {
/* 331 */       if (hasConcurrentResult()) {
/* 332 */         return;
/*     */       }
/* 334 */       this.concurrentResult = result;
/*     */     }
/*     */ 
/* 337 */     if (this.asyncWebRequest.isAsyncComplete()) {
/* 338 */       logger.error("Could not complete async processing due to timeout or network error");
/* 339 */       return;
/*     */     }
/*     */ 
/* 342 */     if (logger.isDebugEnabled()) {
/* 343 */       logger.debug("Concurrent result value [" + this.concurrentResult + "] - dispatching request to resume processing");
/*     */     }
/*     */ 
/* 347 */     this.asyncWebRequest.dispatch();
/*     */   }
/*     */ 
/*     */   public void startDeferredResultProcessing(final DeferredResult<?> deferredResult, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 367 */     Assert.notNull(deferredResult, "DeferredResult must not be null");
/* 368 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */ 
/* 370 */     Long timeout = deferredResult.getTimeoutValue();
/* 371 */     if (timeout != null) {
/* 372 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */ 
/* 375 */     List interceptors = new ArrayList();
/* 376 */     interceptors.add(deferredResult.getInterceptor());
/* 377 */     interceptors.addAll(this.deferredResultInterceptors.values());
/* 378 */     interceptors.add(timeoutDeferredResultInterceptor);
/*     */ 
/* 380 */     final DeferredResultInterceptorChain interceptorChain = new DeferredResultInterceptorChain(interceptors);
/*     */ 
/* 382 */     this.asyncWebRequest.addTimeoutHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/* 386 */           interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, deferredResult);
/*     */         }
/*     */         catch (Throwable ex) {
/* 389 */           WebAsyncManager.this.setConcurrentResultAndDispatch(ex);
/*     */         }
/*     */       }
/*     */     });
/* 394 */     this.asyncWebRequest.addCompletionHandler(new Runnable()
/*     */     {
/*     */       public void run() {
/* 397 */         interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, deferredResult);
/*     */       }
/*     */     });
/* 401 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, deferredResult);
/* 402 */     startAsyncProcessing(processingContext);
/*     */     try
/*     */     {
/* 405 */       interceptorChain.applyPreProcess(this.asyncWebRequest, deferredResult);
/* 406 */       deferredResult.setResultHandler(new DeferredResult.DeferredResultHandler()
/*     */       {
/*     */         public void handleResult(Object result) {
/* 409 */           result = interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, deferredResult, result);
/* 410 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (Throwable ex) {
/* 415 */       setConcurrentResultAndDispatch(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void startAsyncProcessing(Object[] processingContext) {
/* 420 */     clearConcurrentResult();
/* 421 */     this.concurrentResultContext = processingContext;
/* 422 */     this.asyncWebRequest.startAsync();
/*     */ 
/* 424 */     if (logger.isDebugEnabled()) {
/* 425 */       HttpServletRequest request = (HttpServletRequest)this.asyncWebRequest.getNativeRequest(HttpServletRequest.class);
/* 426 */       String requestUri = urlPathHelper.getRequestUri(request);
/* 427 */       logger.debug("Concurrent handling starting for " + request.getMethod() + " [" + requestUri + "]");
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.WebAsyncManager
 * JD-Core Version:    0.6.2
 */