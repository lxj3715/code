/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.web.context.request.WebRequest;
/*    */ 
/*    */ public abstract class WebAsyncUtils
/*    */ {
/* 36 */   public static final String WEB_ASYNC_MANAGER_ATTRIBUTE = WebAsyncManager.class.getName() + ".WEB_ASYNC_MANAGER";
/*    */   private static Constructor<?> standardAsyncRequestConstructor;
/*    */ 
/*    */   public static WebAsyncManager getAsyncManager(ServletRequest servletRequest)
/*    */   {
/* 46 */     WebAsyncManager asyncManager = (WebAsyncManager)servletRequest.getAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE);
/* 47 */     if (asyncManager == null) {
/* 48 */       asyncManager = new WebAsyncManager();
/* 49 */       servletRequest.setAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, asyncManager);
/*    */     }
/* 51 */     return asyncManager;
/*    */   }
/*    */ 
/*    */   public static WebAsyncManager getAsyncManager(WebRequest webRequest)
/*    */   {
/* 59 */     int scope = 0;
/* 60 */     WebAsyncManager asyncManager = (WebAsyncManager)webRequest.getAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, scope);
/* 61 */     if (asyncManager == null) {
/* 62 */       asyncManager = new WebAsyncManager();
/* 63 */       webRequest.setAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, asyncManager, scope);
/*    */     }
/* 65 */     return asyncManager;
/*    */   }
/*    */ 
/*    */   public static AsyncWebRequest createAsyncWebRequest(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 80 */     return ClassUtils.hasMethod(ServletRequest.class, "startAsync", new Class[0]) ? 
/* 80 */       createStandardServletAsyncWebRequest(request, response) : 
/* 80 */       new NoSupportAsyncWebRequest(request, response);
/*    */   }
/*    */ 
/*    */   private static AsyncWebRequest createStandardServletAsyncWebRequest(HttpServletRequest request, HttpServletResponse response) {
/*    */     try {
/* 85 */       if (standardAsyncRequestConstructor == null) {
/* 86 */         String className = "org.springframework.web.context.request.async.StandardServletAsyncWebRequest";
/* 87 */         Class clazz = ClassUtils.forName(className, WebAsyncUtils.class.getClassLoader());
/* 88 */         standardAsyncRequestConstructor = clazz.getConstructor(new Class[] { HttpServletRequest.class, HttpServletResponse.class });
/*    */       }
/* 90 */       return (AsyncWebRequest)BeanUtils.instantiateClass(standardAsyncRequestConstructor, new Object[] { request, response });
/*    */     }
/*    */     catch (Throwable t) {
/* 93 */       throw new IllegalStateException("Failed to instantiate StandardServletAsyncWebRequest", t);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.WebAsyncUtils
 * JD-Core Version:    0.6.2
 */