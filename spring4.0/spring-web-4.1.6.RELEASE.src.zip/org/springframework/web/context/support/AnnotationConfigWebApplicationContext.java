/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.AnnotationConfigRegistry;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AnnotationConfigWebApplicationContext extends AbstractRefreshableWebApplicationContext
/*     */   implements AnnotationConfigRegistry
/*     */ {
/*     */   private BeanNameGenerator beanNameGenerator;
/*     */   private ScopeMetadataResolver scopeMetadataResolver;
/*  89 */   private final Set<Class<?>> annotatedClasses = new LinkedHashSet();
/*     */ 
/*  91 */   private final Set<String> basePackages = new LinkedHashSet();
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 102 */     this.beanNameGenerator = beanNameGenerator;
/*     */   }
/*     */ 
/*     */   protected BeanNameGenerator getBeanNameGenerator()
/*     */   {
/* 110 */     return this.beanNameGenerator;
/*     */   }
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 121 */     this.scopeMetadataResolver = scopeMetadataResolver;
/*     */   }
/*     */ 
/*     */   protected ScopeMetadataResolver getScopeMetadataResolver()
/*     */   {
/* 129 */     return this.scopeMetadataResolver;
/*     */   }
/*     */ 
/*     */   public void register(Class<?>[] annotatedClasses)
/*     */   {
/* 145 */     Assert.notEmpty(annotatedClasses, "At least one annotated class must be specified");
/* 146 */     this.annotatedClasses.addAll(Arrays.asList(annotatedClasses));
/*     */   }
/*     */ 
/*     */   public void scan(String[] basePackages)
/*     */   {
/* 160 */     Assert.notEmpty(basePackages, "At least one base package must be specified");
/* 161 */     this.basePackages.addAll(Arrays.asList(basePackages));
/*     */   }
/*     */ 
/*     */   protected void loadBeanDefinitions(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 188 */     AnnotatedBeanDefinitionReader reader = new AnnotatedBeanDefinitionReader(beanFactory);
/* 189 */     reader.setEnvironment(getEnvironment());
/*     */ 
/* 191 */     ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(beanFactory);
/* 192 */     scanner.setEnvironment(getEnvironment());
/*     */ 
/* 194 */     BeanNameGenerator beanNameGenerator = getBeanNameGenerator();
/* 195 */     ScopeMetadataResolver scopeMetadataResolver = getScopeMetadataResolver();
/* 196 */     if (beanNameGenerator != null) {
/* 197 */       reader.setBeanNameGenerator(beanNameGenerator);
/* 198 */       scanner.setBeanNameGenerator(beanNameGenerator);
/* 199 */       beanFactory.registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */     }
/* 201 */     if (scopeMetadataResolver != null) {
/* 202 */       reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 203 */       scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */     }
/*     */ 
/* 206 */     if (!this.annotatedClasses.isEmpty()) {
/* 207 */       if (this.logger.isInfoEnabled()) {
/* 208 */         this.logger.info("Registering annotated classes: [" + 
/* 209 */           StringUtils.collectionToCommaDelimitedString(this.annotatedClasses) + 
/* 209 */           "]");
/*     */       }
/* 211 */       reader.register((Class[])this.annotatedClasses.toArray(new Class[this.annotatedClasses.size()]));
/*     */     }
/*     */ 
/* 214 */     if (!this.basePackages.isEmpty()) {
/* 215 */       if (this.logger.isInfoEnabled()) {
/* 216 */         this.logger.info("Scanning base packages: [" + 
/* 217 */           StringUtils.collectionToCommaDelimitedString(this.basePackages) + 
/* 217 */           "]");
/*     */       }
/* 219 */       scanner.scan((String[])this.basePackages.toArray(new String[this.basePackages.size()]));
/*     */     }
/*     */ 
/* 222 */     String[] configLocations = getConfigLocations();
/* 223 */     if (configLocations != null)
/* 224 */       for (String configLocation : configLocations)
/*     */         try {
/* 226 */           Class clazz = getClassLoader().loadClass(configLocation);
/* 227 */           if (this.logger.isInfoEnabled()) {
/* 228 */             this.logger.info("Successfully resolved class for [" + configLocation + "]");
/*     */           }
/* 230 */           reader.register(new Class[] { clazz });
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 233 */           if (this.logger.isDebugEnabled()) {
/* 234 */             this.logger.debug("Could not load class for config location [" + configLocation + "] - trying package scan. " + ex);
/*     */           }
/*     */ 
/* 237 */           int count = scanner.scan(new String[] { configLocation });
/* 238 */           if (this.logger.isInfoEnabled())
/* 239 */             if (count == 0) {
/* 240 */               this.logger.info("No annotated classes found for specified class/package [" + configLocation + "]");
/*     */             }
/*     */             else
/* 243 */               this.logger.info("Found " + count + " annotated classes in package [" + configLocation + "]");
/*     */         }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.AnnotationConfigWebApplicationContext
 * JD-Core Version:    0.6.2
 */