/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.support.LiveBeansView;
/*    */ 
/*    */ public class LiveBeansViewServlet extends HttpServlet
/*    */ {
/*    */   private LiveBeansView liveBeansView;
/*    */ 
/*    */   public void init()
/*    */     throws ServletException
/*    */   {
/* 44 */     this.liveBeansView = buildLiveBeansView();
/*    */   }
/*    */ 
/*    */   protected LiveBeansView buildLiveBeansView() {
/* 48 */     return new ServletContextLiveBeansView(getServletContext());
/*    */   }
/*    */ 
/*    */   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*    */   {
/* 53 */     String content = this.liveBeansView.getSnapshotAsJson();
/* 54 */     response.setContentType("application/json");
/* 55 */     response.setContentLength(content.length());
/* 56 */     response.getWriter().write(content);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.LiveBeansViewServlet
 * JD-Core Version:    0.6.2
 */