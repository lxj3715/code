/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.context.ServletContextAware;
/*    */ 
/*    */ public class ServletContextAttributeExporter
/*    */   implements ServletContextAware
/*    */ {
/* 49 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   private Map<String, Object> attributes;
/*    */ 
/*    */   public void setAttributes(Map<String, Object> attributes)
/*    */   {
/* 63 */     this.attributes = attributes;
/*    */   }
/*    */ 
/*    */   public void setServletContext(ServletContext servletContext)
/*    */   {
/* 68 */     for (Map.Entry entry : this.attributes.entrySet()) {
/* 69 */       String attributeName = (String)entry.getKey();
/* 70 */       if ((this.logger.isWarnEnabled()) && 
/* 71 */         (servletContext.getAttribute(attributeName) != null)) {
/* 72 */         this.logger.warn("Replacing existing ServletContext attribute with name '" + attributeName + "'");
/*    */       }
/*    */ 
/* 75 */       servletContext.setAttribute(attributeName, entry.getValue());
/* 76 */       if (this.logger.isInfoEnabled())
/* 77 */         this.logger.info("Exported ServletContext attribute with name '" + attributeName + "'");
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextAttributeExporter
 * JD-Core Version:    0.6.2
 */