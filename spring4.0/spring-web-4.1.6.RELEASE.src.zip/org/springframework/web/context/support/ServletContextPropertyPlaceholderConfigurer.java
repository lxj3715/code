/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ @Deprecated
/*     */ public class ServletContextPropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer
/*     */   implements ServletContextAware
/*     */ {
/*  66 */   private boolean contextOverride = false;
/*     */ 
/*  68 */   private boolean searchContextAttributes = false;
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public void setContextOverride(boolean contextOverride)
/*     */   {
/*  84 */     this.contextOverride = contextOverride;
/*     */   }
/*     */ 
/*     */   public void setSearchContextAttributes(boolean searchContextAttributes)
/*     */   {
/* 100 */     this.searchContextAttributes = searchContextAttributes;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 112 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   protected String resolvePlaceholder(String placeholder, Properties props)
/*     */   {
/* 118 */     String value = null;
/* 119 */     if ((this.contextOverride) && (this.servletContext != null)) {
/* 120 */       value = resolvePlaceholder(placeholder, this.servletContext, this.searchContextAttributes);
/*     */     }
/* 122 */     if (value == null) {
/* 123 */       value = super.resolvePlaceholder(placeholder, props);
/*     */     }
/* 125 */     if ((value == null) && (this.servletContext != null)) {
/* 126 */       value = resolvePlaceholder(placeholder, this.servletContext, this.searchContextAttributes);
/*     */     }
/* 128 */     return value;
/*     */   }
/*     */ 
/*     */   protected String resolvePlaceholder(String placeholder, ServletContext servletContext, boolean searchContextAttributes)
/*     */   {
/* 149 */     String value = null;
/* 150 */     if (searchContextAttributes) {
/* 151 */       Object attrValue = servletContext.getAttribute(placeholder);
/* 152 */       if (attrValue != null) {
/* 153 */         value = attrValue.toString();
/*     */       }
/*     */     }
/* 156 */     if (value == null) {
/* 157 */       value = servletContext.getInitParameter(placeholder);
/*     */     }
/* 159 */     return value;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextPropertyPlaceholderConfigurer
 * JD-Core Version:    0.6.2
 */