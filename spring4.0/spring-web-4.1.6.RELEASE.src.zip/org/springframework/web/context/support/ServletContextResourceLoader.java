/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.core.io.DefaultResourceLoader;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ public class ServletContextResourceLoader extends DefaultResourceLoader
/*    */ {
/*    */   private final ServletContext servletContext;
/*    */ 
/*    */   public ServletContextResourceLoader(ServletContext servletContext)
/*    */   {
/* 50 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */   protected Resource getResourceByPath(String path)
/*    */   {
/* 59 */     return new ServletContextResource(this.servletContext, path);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextResourceLoader
 * JD-Core Version:    0.6.2
 */