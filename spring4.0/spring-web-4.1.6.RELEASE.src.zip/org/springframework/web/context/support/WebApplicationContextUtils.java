/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource.StubPropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.RequestScope;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.SessionScope;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ 
/*     */ public abstract class WebApplicationContextUtils
/*     */ {
/*  67 */   private static final boolean jsfPresent = ClassUtils.isPresent("javax.faces.context.FacesContext", RequestContextHolder.class
/*  67 */     .getClassLoader());
/*     */ 
/*     */   public static WebApplicationContext getRequiredWebApplicationContext(ServletContext sc)
/*     */     throws IllegalStateException
/*     */   {
/*  81 */     WebApplicationContext wac = getWebApplicationContext(sc);
/*  82 */     if (wac == null) {
/*  83 */       throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*     */     }
/*  85 */     return wac;
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletContext sc)
/*     */   {
/*  98 */     return getWebApplicationContext(sc, WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletContext sc, String attrName)
/*     */   {
/* 108 */     Assert.notNull(sc, "ServletContext must not be null");
/* 109 */     Object attr = sc.getAttribute(attrName);
/* 110 */     if (attr == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     if ((attr instanceof RuntimeException)) {
/* 114 */       throw ((RuntimeException)attr);
/*     */     }
/* 116 */     if ((attr instanceof Error)) {
/* 117 */       throw ((Error)attr);
/*     */     }
/* 119 */     if ((attr instanceof Exception)) {
/* 120 */       throw new IllegalStateException((Exception)attr);
/*     */     }
/* 122 */     if (!(attr instanceof WebApplicationContext)) {
/* 123 */       throw new IllegalStateException("Context attribute is not of type WebApplicationContext: " + attr);
/*     */     }
/* 125 */     return (WebApplicationContext)attr;
/*     */   }
/*     */ 
/*     */   public static void registerWebApplicationScopes(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 135 */     registerWebApplicationScopes(beanFactory, null);
/*     */   }
/*     */ 
/*     */   public static void registerWebApplicationScopes(ConfigurableListableBeanFactory beanFactory, ServletContext sc)
/*     */   {
/* 145 */     beanFactory.registerScope("request", new RequestScope());
/* 146 */     beanFactory.registerScope("session", new SessionScope(false));
/* 147 */     beanFactory.registerScope("globalSession", new SessionScope(true));
/* 148 */     if (sc != null) {
/* 149 */       ServletContextScope appScope = new ServletContextScope(sc);
/* 150 */       beanFactory.registerScope("application", appScope);
/*     */ 
/* 152 */       sc.setAttribute(ServletContextScope.class.getName(), appScope);
/*     */     }
/*     */ 
/* 155 */     beanFactory.registerResolvableDependency(ServletRequest.class, new RequestObjectFactory(null));
/* 156 */     beanFactory.registerResolvableDependency(ServletResponse.class, new ResponseObjectFactory(null));
/* 157 */     beanFactory.registerResolvableDependency(HttpSession.class, new SessionObjectFactory(null));
/* 158 */     beanFactory.registerResolvableDependency(WebRequest.class, new WebRequestObjectFactory(null));
/* 159 */     if (jsfPresent)
/* 160 */       FacesDependencyRegistrar.registerFacesDependencies(beanFactory);
/*     */   }
/*     */ 
/*     */   public static void registerEnvironmentBeans(ConfigurableListableBeanFactory bf, ServletContext sc)
/*     */   {
/* 171 */     registerEnvironmentBeans(bf, sc, null);
/*     */   }
/*     */ 
/*     */   public static void registerEnvironmentBeans(ConfigurableListableBeanFactory bf, ServletContext servletContext, ServletConfig servletConfig)
/*     */   {
/* 184 */     if ((servletContext != null) && (!bf.containsBean("servletContext"))) {
/* 185 */       bf.registerSingleton("servletContext", servletContext);
/*     */     }
/*     */ 
/* 188 */     if ((servletConfig != null) && (!bf.containsBean("servletConfig"))) {
/* 189 */       bf.registerSingleton("servletConfig", servletConfig);
/*     */     }
/*     */ 
/* 192 */     if (!bf.containsBean("contextParameters")) {
/* 193 */       Map parameterMap = new HashMap();
/* 194 */       if (servletContext != null) {
/* 195 */         Enumeration paramNameEnum = servletContext.getInitParameterNames();
/* 196 */         while (paramNameEnum.hasMoreElements()) {
/* 197 */           String paramName = (String)paramNameEnum.nextElement();
/* 198 */           parameterMap.put(paramName, servletContext.getInitParameter(paramName));
/*     */         }
/*     */       }
/* 201 */       if (servletConfig != null) {
/* 202 */         Enumeration paramNameEnum = servletConfig.getInitParameterNames();
/* 203 */         while (paramNameEnum.hasMoreElements()) {
/* 204 */           String paramName = (String)paramNameEnum.nextElement();
/* 205 */           parameterMap.put(paramName, servletConfig.getInitParameter(paramName));
/*     */         }
/*     */       }
/* 208 */       bf.registerSingleton("contextParameters", 
/* 209 */         Collections.unmodifiableMap(parameterMap));
/*     */     }
/*     */ 
/* 212 */     if (!bf.containsBean("contextAttributes")) {
/* 213 */       Map attributeMap = new HashMap();
/* 214 */       if (servletContext != null) {
/* 215 */         Enumeration attrNameEnum = servletContext.getAttributeNames();
/* 216 */         while (attrNameEnum.hasMoreElements()) {
/* 217 */           String attrName = (String)attrNameEnum.nextElement();
/* 218 */           attributeMap.put(attrName, servletContext.getAttribute(attrName));
/*     */         }
/*     */       }
/* 221 */       bf.registerSingleton("contextAttributes", 
/* 222 */         Collections.unmodifiableMap(attributeMap));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initServletPropertySources(MutablePropertySources propertySources, ServletContext servletContext)
/*     */   {
/* 233 */     initServletPropertySources(propertySources, servletContext, null);
/*     */   }
/*     */ 
/*     */   public static void initServletPropertySources(MutablePropertySources propertySources, ServletContext servletContext, ServletConfig servletConfig)
/*     */   {
/* 257 */     Assert.notNull(propertySources, "propertySources must not be null");
/* 258 */     if ((servletContext != null) && (propertySources.contains("servletContextInitParams")) && 
/* 259 */       ((propertySources
/* 259 */       .get("servletContextInitParams") instanceof PropertySource.StubPropertySource)))
/*     */     {
/* 260 */       propertySources.replace("servletContextInitParams", new ServletContextPropertySource("servletContextInitParams", servletContext));
/*     */     }
/*     */ 
/* 263 */     if ((servletConfig != null) && (propertySources.contains("servletConfigInitParams")) && 
/* 264 */       ((propertySources
/* 264 */       .get("servletConfigInitParams") instanceof PropertySource.StubPropertySource)))
/*     */     {
/* 265 */       propertySources.replace("servletConfigInitParams", new ServletConfigPropertySource("servletConfigInitParams", servletConfig));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static ServletRequestAttributes currentRequestAttributes()
/*     */   {
/* 275 */     RequestAttributes requestAttr = RequestContextHolder.currentRequestAttributes();
/* 276 */     if (!(requestAttr instanceof ServletRequestAttributes)) {
/* 277 */       throw new IllegalStateException("Current request is not a servlet request");
/*     */     }
/* 279 */     return (ServletRequestAttributes)requestAttr;
/*     */   }
/*     */ 
/*     */   private static class FacesDependencyRegistrar
/*     */   {
/*     */     public static void registerFacesDependencies(ConfigurableListableBeanFactory beanFactory)
/*     */     {
/* 367 */       beanFactory.registerResolvableDependency(FacesContext.class, new ObjectFactory()
/*     */       {
/*     */         public FacesContext getObject() {
/* 370 */           return FacesContext.getCurrentInstance();
/*     */         }
/*     */ 
/*     */         public String toString() {
/* 374 */           return "Current JSF FacesContext";
/*     */         }
/*     */       });
/* 377 */       beanFactory.registerResolvableDependency(ExternalContext.class, new ObjectFactory()
/*     */       {
/*     */         public ExternalContext getObject() {
/* 380 */           return FacesContext.getCurrentInstance().getExternalContext();
/*     */         }
/*     */ 
/*     */         public String toString() {
/* 384 */           return "Current JSF ExternalContext";
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class WebRequestObjectFactory
/*     */     implements ObjectFactory<WebRequest>, Serializable
/*     */   {
/*     */     public WebRequest getObject()
/*     */     {
/* 350 */       ServletRequestAttributes requestAttr = WebApplicationContextUtils.access$400();
/* 351 */       return new ServletWebRequest(requestAttr.getRequest(), requestAttr.getResponse());
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 356 */       return "Current ServletWebRequest";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SessionObjectFactory
/*     */     implements ObjectFactory<HttpSession>, Serializable
/*     */   {
/*     */     public HttpSession getObject()
/*     */     {
/* 332 */       return WebApplicationContextUtils.access$400().getRequest().getSession();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 337 */       return "Current HttpSession";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ResponseObjectFactory
/*     */     implements ObjectFactory<ServletResponse>, Serializable
/*     */   {
/*     */     public ServletResponse getObject()
/*     */     {
/* 309 */       ServletResponse response = WebApplicationContextUtils.access$400().getResponse();
/* 310 */       if (response == null) {
/* 311 */         throw new IllegalStateException("Current servlet response not available - consider using RequestContextFilter instead of RequestContextListener");
/*     */       }
/*     */ 
/* 314 */       return response;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 319 */       return "Current HttpServletResponse";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RequestObjectFactory
/*     */     implements ObjectFactory<ServletRequest>, Serializable
/*     */   {
/*     */     public ServletRequest getObject()
/*     */     {
/* 291 */       return WebApplicationContextUtils.access$400().getRequest();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 296 */       return "Current HttpServletRequest";
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.WebApplicationContextUtils
 * JD-Core Version:    0.6.2
 */