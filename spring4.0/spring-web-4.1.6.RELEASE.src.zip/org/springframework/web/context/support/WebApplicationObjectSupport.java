/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.support.ApplicationObjectSupport;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public abstract class WebApplicationObjectSupport extends ApplicationObjectSupport
/*     */   implements ServletContextAware
/*     */ {
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public final void setServletContext(ServletContext servletContext)
/*     */   {
/*  48 */     if (servletContext != this.servletContext) {
/*  49 */       this.servletContext = servletContext;
/*  50 */       if (servletContext != null)
/*  51 */         initServletContext(servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isContextRequired()
/*     */   {
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext(ApplicationContext context)
/*     */   {
/*  76 */     super.initApplicationContext(context);
/*  77 */     if ((this.servletContext == null) && ((context instanceof WebApplicationContext))) {
/*  78 */       this.servletContext = ((WebApplicationContext)context).getServletContext();
/*  79 */       if (this.servletContext != null)
/*  80 */         initServletContext(this.servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final WebApplicationContext getWebApplicationContext()
/*     */     throws IllegalStateException
/*     */   {
/* 107 */     ApplicationContext ctx = getApplicationContext();
/* 108 */     if ((ctx instanceof WebApplicationContext)) {
/* 109 */       return (WebApplicationContext)getApplicationContext();
/*     */     }
/* 111 */     if (isContextRequired()) {
/* 112 */       throw new IllegalStateException("WebApplicationObjectSupport instance [" + this + "] does not run in a WebApplicationContext but in: " + ctx);
/*     */     }
/*     */ 
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */     throws IllegalStateException
/*     */   {
/* 125 */     if (this.servletContext != null) {
/* 126 */       return this.servletContext;
/*     */     }
/* 128 */     ServletContext servletContext = getWebApplicationContext().getServletContext();
/* 129 */     if ((servletContext == null) && (isContextRequired())) {
/* 130 */       throw new IllegalStateException("WebApplicationObjectSupport instance [" + this + "] does not run within a ServletContext. Make sure the object is fully configured!");
/*     */     }
/*     */ 
/* 133 */     return servletContext;
/*     */   }
/*     */ 
/*     */   protected final File getTempDir()
/*     */     throws IllegalStateException
/*     */   {
/* 144 */     return WebUtils.getTempDir(getServletContext());
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.WebApplicationObjectSupport
 * JD-Core Version:    0.6.2
 */