/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.ContentCachingRequestWrapper;
/*     */ 
/*     */ public abstract class AbstractRequestLoggingFilter extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_BEFORE_MESSAGE_PREFIX = "Before request [";
/*     */   public static final String DEFAULT_BEFORE_MESSAGE_SUFFIX = "]";
/*     */   public static final String DEFAULT_AFTER_MESSAGE_PREFIX = "After request [";
/*     */   public static final String DEFAULT_AFTER_MESSAGE_SUFFIX = "]";
/*     */   private static final int DEFAULT_MAX_PAYLOAD_LENGTH = 50;
/*  70 */   private boolean includeQueryString = false;
/*     */ 
/*  72 */   private boolean includeClientInfo = false;
/*     */ 
/*  74 */   private boolean includePayload = false;
/*     */ 
/*  76 */   private int maxPayloadLength = 50;
/*     */ 
/*  78 */   private String beforeMessagePrefix = "Before request [";
/*     */ 
/*  80 */   private String beforeMessageSuffix = "]";
/*     */ 
/*  82 */   private String afterMessagePrefix = "After request [";
/*     */ 
/*  84 */   private String afterMessageSuffix = "]";
/*     */ 
/*     */   public void setIncludeQueryString(boolean includeQueryString)
/*     */   {
/*  93 */     this.includeQueryString = includeQueryString;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeQueryString()
/*     */   {
/* 100 */     return this.includeQueryString;
/*     */   }
/*     */ 
/*     */   public void setIncludeClientInfo(boolean includeClientInfo)
/*     */   {
/* 110 */     this.includeClientInfo = includeClientInfo;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeClientInfo()
/*     */   {
/* 118 */     return this.includeClientInfo;
/*     */   }
/*     */ 
/*     */   public void setIncludePayload(boolean includePayload)
/*     */   {
/* 128 */     this.includePayload = includePayload;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludePayload()
/*     */   {
/* 135 */     return this.includePayload;
/*     */   }
/*     */ 
/*     */   public void setMaxPayloadLength(int maxPayloadLength)
/*     */   {
/* 143 */     Assert.isTrue(maxPayloadLength >= 0, "'maxPayloadLength' should be larger than or equal to 0");
/* 144 */     this.maxPayloadLength = maxPayloadLength;
/*     */   }
/*     */ 
/*     */   protected int getMaxPayloadLength()
/*     */   {
/* 151 */     return this.maxPayloadLength;
/*     */   }
/*     */ 
/*     */   public void setBeforeMessagePrefix(String beforeMessagePrefix)
/*     */   {
/* 159 */     this.beforeMessagePrefix = beforeMessagePrefix;
/*     */   }
/*     */ 
/*     */   public void setBeforeMessageSuffix(String beforeMessageSuffix)
/*     */   {
/* 167 */     this.beforeMessageSuffix = beforeMessageSuffix;
/*     */   }
/*     */ 
/*     */   public void setAfterMessagePrefix(String afterMessagePrefix)
/*     */   {
/* 175 */     this.afterMessagePrefix = afterMessagePrefix;
/*     */   }
/*     */ 
/*     */   public void setAfterMessageSuffix(String afterMessageSuffix)
/*     */   {
/* 183 */     this.afterMessageSuffix = afterMessageSuffix;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/* 194 */     return false;
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 207 */     boolean isFirstRequest = !isAsyncDispatch(request);
/* 208 */     HttpServletRequest requestToUse = request;
/*     */ 
/* 210 */     if ((isIncludePayload()) && (isFirstRequest) && (!(request instanceof ContentCachingRequestWrapper))) {
/* 211 */       requestToUse = new ContentCachingRequestWrapper(request);
/*     */     }
/*     */ 
/* 214 */     boolean shouldLog = shouldLog(requestToUse);
/* 215 */     if ((shouldLog) && (isFirstRequest))
/* 216 */       beforeRequest(requestToUse, getBeforeMessage(requestToUse));
/*     */     try
/*     */     {
/* 219 */       filterChain.doFilter(requestToUse, response);
/*     */     }
/*     */     finally {
/* 222 */       if ((shouldLog) && (!isAsyncStarted(requestToUse)))
/* 223 */         afterRequest(requestToUse, getAfterMessage(requestToUse));
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getBeforeMessage(HttpServletRequest request)
/*     */   {
/* 233 */     return createMessage(request, this.beforeMessagePrefix, this.beforeMessageSuffix);
/*     */   }
/*     */ 
/*     */   private String getAfterMessage(HttpServletRequest request)
/*     */   {
/* 241 */     return createMessage(request, this.afterMessagePrefix, this.afterMessageSuffix);
/*     */   }
/*     */ 
/*     */   protected String createMessage(HttpServletRequest request, String prefix, String suffix)
/*     */   {
/* 253 */     StringBuilder msg = new StringBuilder();
/* 254 */     msg.append(prefix);
/* 255 */     msg.append("uri=").append(request.getRequestURI());
/* 256 */     if (isIncludeQueryString()) {
/* 257 */       msg.append('?').append(request.getQueryString());
/*     */     }
/* 259 */     if (isIncludeClientInfo()) {
/* 260 */       String client = request.getRemoteAddr();
/* 261 */       if (StringUtils.hasLength(client)) {
/* 262 */         msg.append(";client=").append(client);
/*     */       }
/* 264 */       HttpSession session = request.getSession(false);
/* 265 */       if (session != null) {
/* 266 */         msg.append(";session=").append(session.getId());
/*     */       }
/* 268 */       String user = request.getRemoteUser();
/* 269 */       if (user != null) {
/* 270 */         msg.append(";user=").append(user);
/*     */       }
/*     */     }
/* 273 */     if ((isIncludePayload()) && ((request instanceof ContentCachingRequestWrapper))) {
/* 274 */       ContentCachingRequestWrapper wrapper = (ContentCachingRequestWrapper)request;
/* 275 */       byte[] buf = wrapper.getContentAsByteArray();
/* 276 */       if (buf.length > 0) { int length = Math.min(buf.length, getMaxPayloadLength());
/*     */         String payload;
/*     */         try {
/* 280 */           payload = new String(buf, 0, length, wrapper.getCharacterEncoding());
/*     */         }
/*     */         catch (UnsupportedEncodingException e)
/*     */         {
/*     */           String payload;
/* 283 */           payload = "[unknown]";
/*     */         }
/* 285 */         msg.append(";payload=").append(payload);
/*     */       }
/*     */     }
/*     */ 
/* 289 */     msg.append(suffix);
/* 290 */     return msg.toString();
/*     */   }
/*     */ 
/*     */   protected boolean shouldLog(HttpServletRequest request)
/*     */   {
/* 306 */     return true;
/*     */   }
/*     */ 
/*     */   protected abstract void beforeRequest(HttpServletRequest paramHttpServletRequest, String paramString);
/*     */ 
/*     */   protected abstract void afterRequest(HttpServletRequest paramHttpServletRequest, String paramString);
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.AbstractRequestLoggingFilter
 * JD-Core Version:    0.6.2
 */