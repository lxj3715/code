/*    */ package org.springframework.web.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class CharacterEncodingFilter extends OncePerRequestFilter
/*    */ {
/*    */   private String encoding;
/* 47 */   private boolean forceEncoding = false;
/*    */ 
/*    */   public void setEncoding(String encoding)
/*    */   {
/* 58 */     this.encoding = encoding;
/*    */   }
/*    */ 
/*    */   public void setForceEncoding(boolean forceEncoding)
/*    */   {
/* 70 */     this.forceEncoding = forceEncoding;
/*    */   }
/*    */ 
/*    */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*    */     throws ServletException, IOException
/*    */   {
/* 79 */     if ((this.encoding != null) && ((this.forceEncoding) || (request.getCharacterEncoding() == null))) {
/* 80 */       request.setCharacterEncoding(this.encoding);
/* 81 */       if (this.forceEncoding) {
/* 82 */         response.setCharacterEncoding(this.encoding);
/*    */       }
/*    */     }
/* 85 */     filterChain.doFilter(request, response);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.CharacterEncodingFilter
 * JD-Core Version:    0.6.2
 */