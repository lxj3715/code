/*    */ package org.springframework.web.filter;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ public class CommonsRequestLoggingFilter extends AbstractRequestLoggingFilter
/*    */ {
/*    */   protected boolean shouldLog(HttpServletRequest request)
/*    */   {
/* 39 */     return this.logger.isDebugEnabled();
/*    */   }
/*    */ 
/*    */   protected void beforeRequest(HttpServletRequest request, String message)
/*    */   {
/* 47 */     this.logger.debug(message);
/*    */   }
/*    */ 
/*    */   protected void afterRequest(HttpServletRequest request, String message)
/*    */   {
/* 55 */     this.logger.debug(message);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.CommonsRequestLoggingFilter
 * JD-Core Version:    0.6.2
 */