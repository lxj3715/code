/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.DigestUtils;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.web.util.ContentCachingResponseWrapper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ShallowEtagHeaderFilter extends OncePerRequestFilter
/*     */ {
/*     */   private static final String HEADER_ETAG = "ETag";
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*     */   private static final String DIRECTIVE_NO_STORE = "no-store";
/*  61 */   private static final boolean responseGetHeaderAvailable = ClassUtils.hasMethod(HttpServletResponse.class, "getHeader", new Class[] { String.class })
/*  61 */     ;
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  77 */     HttpServletResponse responseToUse = response;
/*  78 */     if ((!isAsyncDispatch(request)) && (!(response instanceof ContentCachingResponseWrapper))) {
/*  79 */       responseToUse = new ContentCachingResponseWrapper(response);
/*     */     }
/*     */ 
/*  82 */     filterChain.doFilter(request, responseToUse);
/*     */ 
/*  84 */     if (!isAsyncStarted(request))
/*  85 */       updateResponse(request, responseToUse);
/*     */   }
/*     */ 
/*     */   private void updateResponse(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/*  91 */     ContentCachingResponseWrapper responseWrapper = (ContentCachingResponseWrapper)WebUtils.getNativeResponse(response, ContentCachingResponseWrapper.class);
/*     */ 
/*  92 */     Assert.notNull(responseWrapper, "ShallowEtagResponseWrapper not found");
/*     */ 
/*  94 */     HttpServletResponse rawResponse = (HttpServletResponse)responseWrapper.getResponse();
/*  95 */     int statusCode = responseWrapper.getStatusCode();
/*  96 */     byte[] body = responseWrapper.getContentAsByteArray();
/*     */ 
/*  98 */     if (rawResponse.isCommitted()) {
/*  99 */       if (body.length > 0) {
/* 100 */         StreamUtils.copy(body, rawResponse.getOutputStream());
/*     */       }
/*     */     }
/* 103 */     else if (isEligibleForEtag(request, responseWrapper, statusCode, body)) {
/* 104 */       String responseETag = generateETagHeaderValue(body);
/* 105 */       rawResponse.setHeader("ETag", responseETag);
/* 106 */       String requestETag = request.getHeader("If-None-Match");
/* 107 */       if (responseETag.equals(requestETag)) {
/* 108 */         if (this.logger.isTraceEnabled()) {
/* 109 */           this.logger.trace("ETag [" + responseETag + "] equal to If-None-Match, sending 304");
/*     */         }
/* 111 */         rawResponse.setStatus(304);
/*     */       }
/*     */       else {
/* 114 */         if (this.logger.isTraceEnabled()) {
/* 115 */           this.logger.trace("ETag [" + responseETag + "] not equal to If-None-Match [" + requestETag + "], sending normal response");
/*     */         }
/*     */ 
/* 118 */         if (body.length > 0) {
/* 119 */           rawResponse.setContentLength(body.length);
/* 120 */           StreamUtils.copy(body, rawResponse.getOutputStream());
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 125 */       if (this.logger.isTraceEnabled()) {
/* 126 */         this.logger.trace("Response with status code [" + statusCode + "] not eligible for ETag");
/*     */       }
/* 128 */       if (body.length > 0) {
/* 129 */         rawResponse.setContentLength(body.length);
/* 130 */         StreamUtils.copy(body, rawResponse.getOutputStream());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleForEtag(HttpServletRequest request, HttpServletResponse response, int responseStatusCode, byte[] responseBody)
/*     */   {
/* 152 */     if ((responseStatusCode >= 200) && (responseStatusCode < 300) && 
/* 153 */       (HttpMethod.GET
/* 153 */       .name().equals(request.getMethod()))) {
/* 154 */       String cacheControl = responseGetHeaderAvailable ? response.getHeader("Cache-Control") : null;
/* 155 */       if ((cacheControl == null) || (!cacheControl.contains("no-store"))) {
/* 156 */         return true;
/*     */       }
/*     */     }
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */   protected String generateETagHeaderValue(byte[] bytes)
/*     */   {
/* 170 */     StringBuilder builder = new StringBuilder("\"0");
/* 171 */     DigestUtils.appendMd5DigestAsHex(bytes, builder);
/* 172 */     builder.append('"');
/* 173 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.ShallowEtagHeaderFilter
 * JD-Core Version:    0.6.2
 */