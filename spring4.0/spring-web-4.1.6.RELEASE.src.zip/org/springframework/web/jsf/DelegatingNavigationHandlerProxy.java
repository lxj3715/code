/*     */ package org.springframework.web.jsf;
/*     */ 
/*     */ import javax.faces.application.NavigationHandler;
/*     */ import javax.faces.context.FacesContext;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ public class DelegatingNavigationHandlerProxy extends NavigationHandler
/*     */ {
/*     */   public static final String DEFAULT_TARGET_BEAN_NAME = "jsfNavigationHandler";
/*     */   private NavigationHandler originalNavigationHandler;
/*     */ 
/*     */   public DelegatingNavigationHandlerProxy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DelegatingNavigationHandlerProxy(NavigationHandler originalNavigationHandler)
/*     */   {
/*  95 */     this.originalNavigationHandler = originalNavigationHandler;
/*     */   }
/*     */ 
/*     */   public void handleNavigation(FacesContext facesContext, String fromAction, String outcome)
/*     */   {
/* 110 */     NavigationHandler handler = getDelegate(facesContext);
/* 111 */     if ((handler instanceof DecoratingNavigationHandler)) {
/* 112 */       ((DecoratingNavigationHandler)handler).handleNavigation(facesContext, fromAction, outcome, this.originalNavigationHandler);
/*     */     }
/*     */     else
/*     */     {
/* 116 */       handler.handleNavigation(facesContext, fromAction, outcome);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected NavigationHandler getDelegate(FacesContext facesContext)
/*     */   {
/* 130 */     String targetBeanName = getTargetBeanName(facesContext);
/* 131 */     return (NavigationHandler)getBeanFactory(facesContext).getBean(targetBeanName, NavigationHandler.class);
/*     */   }
/*     */ 
/*     */   protected String getTargetBeanName(FacesContext facesContext)
/*     */   {
/* 141 */     return "jsfNavigationHandler";
/*     */   }
/*     */ 
/*     */   protected BeanFactory getBeanFactory(FacesContext facesContext)
/*     */   {
/* 154 */     return getWebApplicationContext(facesContext);
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext getWebApplicationContext(FacesContext facesContext)
/*     */   {
/* 165 */     return FacesContextUtils.getRequiredWebApplicationContext(facesContext);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.DelegatingNavigationHandlerProxy
 * JD-Core Version:    0.6.2
 */