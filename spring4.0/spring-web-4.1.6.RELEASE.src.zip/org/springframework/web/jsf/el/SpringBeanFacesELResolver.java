/*    */ package org.springframework.web.jsf.el;
/*    */ 
/*    */ import javax.el.ELContext;
/*    */ import javax.faces.context.FacesContext;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.access.el.SpringBeanELResolver;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ import org.springframework.web.jsf.FacesContextUtils;
/*    */ 
/*    */ public class SpringBeanFacesELResolver extends SpringBeanELResolver
/*    */ {
/*    */   protected BeanFactory getBeanFactory(ELContext elContext)
/*    */   {
/* 78 */     return getWebApplicationContext(elContext);
/*    */   }
/*    */ 
/*    */   protected WebApplicationContext getWebApplicationContext(ELContext elContext)
/*    */   {
/* 89 */     FacesContext facesContext = FacesContext.getCurrentInstance();
/* 90 */     return FacesContextUtils.getRequiredWebApplicationContext(facesContext);
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.el.SpringBeanFacesELResolver
 * JD-Core Version:    0.6.2
 */