/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.OrderUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.ControllerAdvice;
/*     */ 
/*     */ public class ControllerAdviceBean
/*     */   implements Ordered
/*     */ {
/*     */   private final Object bean;
/*     */   private final BeanFactory beanFactory;
/*     */   private final int order;
/*     */   private final Set<String> basePackages;
/*     */   private final List<Class<?>> assignableTypes;
/*     */   private final List<Class<? extends Annotation>> annotations;
/*     */ 
/*     */   public ControllerAdviceBean(Object bean)
/*     */   {
/*  70 */     this(bean, null);
/*     */   }
/*     */ 
/*     */   public ControllerAdviceBean(String beanName, BeanFactory beanFactory)
/*     */   {
/*  79 */     this(beanName, beanFactory);
/*     */   }
/*     */ 
/*     */   private ControllerAdviceBean(Object bean, BeanFactory beanFactory) {
/*  83 */     this.bean = bean;
/*  84 */     this.beanFactory = beanFactory;
/*     */     Class beanType;
/*  87 */     if ((bean instanceof String)) {
/*  88 */       String beanName = (String)bean;
/*  89 */       Assert.hasText(beanName, "Bean name must not be null");
/*  90 */       Assert.notNull(beanFactory, "BeanFactory must not be null");
/*  91 */       if (!beanFactory.containsBean(beanName)) {
/*  92 */         throw new IllegalArgumentException("BeanFactory [" + beanFactory + "] does not contain specified controller advice bean '" + beanName + "'");
/*     */       }
/*     */ 
/*  95 */       Class beanType = this.beanFactory.getType(beanName);
/*  96 */       this.order = initOrderFromBeanType(beanType);
/*     */     }
/*     */     else {
/*  99 */       Assert.notNull(bean, "Bean must not be null");
/* 100 */       beanType = bean.getClass();
/* 101 */       this.order = initOrderFromBean(bean);
/*     */     }
/*     */ 
/* 104 */     ControllerAdvice annotation = (ControllerAdvice)AnnotationUtils.findAnnotation(beanType, ControllerAdvice.class);
/* 105 */     if (annotation == null)
/*     */     {
/* 107 */       throw new IllegalArgumentException("Bean type [" + beanType
/* 107 */         .getName() + "] is not annotated as @ControllerAdvice");
/*     */     }
/* 109 */     this.basePackages = initBasePackages(annotation);
/* 110 */     this.assignableTypes = Arrays.asList(annotation.assignableTypes());
/* 111 */     this.annotations = Arrays.asList(annotation.annotations());
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 121 */     return this.order;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 131 */     Class clazz = (this.bean instanceof String) ? this.beanFactory
/* 131 */       .getType((String)this.bean) : 
/* 131 */       this.bean.getClass();
/* 132 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */ 
/*     */   public Object resolveBean()
/*     */   {
/* 139 */     return (this.bean instanceof String) ? this.beanFactory.getBean((String)this.bean) : this.bean;
/*     */   }
/*     */ 
/*     */   public boolean isApplicableToBeanType(Class<?> beanType)
/*     */   {
/* 150 */     if (!hasSelectors()) {
/* 151 */       return true;
/*     */     }
/* 153 */     if (beanType != null) {
/* 154 */       for (String basePackage : this.basePackages) {
/* 155 */         if (beanType.getName().startsWith(basePackage)) {
/* 156 */           return true;
/*     */         }
/*     */       }
/* 159 */       for (Class clazz : this.assignableTypes) {
/* 160 */         if (ClassUtils.isAssignable(clazz, beanType)) {
/* 161 */           return true;
/*     */         }
/*     */       }
/* 164 */       for (Class annotationClass : this.annotations) {
/* 165 */         if (AnnotationUtils.findAnnotation(beanType, annotationClass) != null) {
/* 166 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 170 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean hasSelectors() {
/* 174 */     return (!this.basePackages.isEmpty()) || (!this.assignableTypes.isEmpty()) || (!this.annotations.isEmpty());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 180 */     if (this == other) {
/* 181 */       return true;
/*     */     }
/* 183 */     if (!(other instanceof ControllerAdviceBean)) {
/* 184 */       return false;
/*     */     }
/* 186 */     ControllerAdviceBean otherAdvice = (ControllerAdviceBean)other;
/* 187 */     return (this.bean.equals(otherAdvice.bean)) && (this.beanFactory == otherAdvice.beanFactory);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 192 */     return this.bean.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 197 */     return this.bean.toString();
/*     */   }
/*     */ 
/*     */   public static List<ControllerAdviceBean> findAnnotatedBeans(ApplicationContext applicationContext)
/*     */   {
/* 207 */     List beans = new ArrayList();
/* 208 */     for (String name : BeanFactoryUtils.beanNamesForTypeIncludingAncestors(applicationContext, Object.class)) {
/* 209 */       if (applicationContext.findAnnotationOnBean(name, ControllerAdvice.class) != null) {
/* 210 */         beans.add(new ControllerAdviceBean(name, applicationContext));
/*     */       }
/*     */     }
/* 213 */     return beans;
/*     */   }
/*     */ 
/*     */   private static int initOrderFromBean(Object bean) {
/* 217 */     return (bean instanceof Ordered) ? ((Ordered)bean).getOrder() : initOrderFromBeanType(bean.getClass());
/*     */   }
/*     */ 
/*     */   private static int initOrderFromBeanType(Class<?> beanType) {
/* 221 */     return OrderUtils.getOrder(beanType, Integer.valueOf(2147483647)).intValue();
/*     */   }
/*     */ 
/*     */   private static Set<String> initBasePackages(ControllerAdvice annotation) {
/* 225 */     Set basePackages = new LinkedHashSet();
/* 226 */     for (String basePackage : annotation.value()) {
/* 227 */       if (StringUtils.hasText(basePackage)) {
/* 228 */         basePackages.add(adaptBasePackage(basePackage));
/*     */       }
/*     */     }
/* 231 */     for (String basePackage : annotation.basePackages()) {
/* 232 */       if (StringUtils.hasText(basePackage)) {
/* 233 */         basePackages.add(adaptBasePackage(basePackage));
/*     */       }
/*     */     }
/* 236 */     for (Class markerClass : annotation.basePackageClasses()) {
/* 237 */       basePackages.add(adaptBasePackage(ClassUtils.getPackageName(markerClass)));
/*     */     }
/* 239 */     return basePackages;
/*     */   }
/*     */ 
/*     */   private static String adaptBasePackage(String basePackage) {
/* 243 */     return basePackage + ".";
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.ControllerAdviceBean
 * JD-Core Version:    0.6.2
 */