/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class HandlerMethod
/*     */ {
/*  49 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final Object bean;
/*     */   private final BeanFactory beanFactory;
/*     */   private final Class<?> beanType;
/*     */   private final Method method;
/*     */   private final Method bridgedMethod;
/*     */   private final MethodParameter[] parameters;
/*     */ 
/*     */   public HandlerMethod(Object bean, Method method)
/*     */   {
/*  68 */     Assert.notNull(bean, "Bean is required");
/*  69 */     Assert.notNull(method, "Method is required");
/*  70 */     this.bean = bean;
/*  71 */     this.beanFactory = null;
/*  72 */     this.beanType = ClassUtils.getUserClass(bean);
/*  73 */     this.method = method;
/*  74 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  75 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   public HandlerMethod(Object bean, String methodName, Class<?>[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  83 */     Assert.notNull(bean, "Bean is required");
/*  84 */     Assert.notNull(methodName, "Method name is required");
/*  85 */     this.bean = bean;
/*  86 */     this.beanFactory = null;
/*  87 */     this.beanType = ClassUtils.getUserClass(bean);
/*  88 */     this.method = bean.getClass().getMethod(methodName, parameterTypes);
/*  89 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(this.method);
/*  90 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   public HandlerMethod(String beanName, BeanFactory beanFactory, Method method)
/*     */   {
/*  99 */     Assert.hasText(beanName, "Bean name is required");
/* 100 */     Assert.notNull(beanFactory, "BeanFactory is required");
/* 101 */     Assert.notNull(method, "Method is required");
/* 102 */     this.bean = beanName;
/* 103 */     this.beanFactory = beanFactory;
/* 104 */     this.beanType = ClassUtils.getUserClass(beanFactory.getType(beanName));
/* 105 */     this.method = method;
/* 106 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 107 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   protected HandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/* 114 */     Assert.notNull(handlerMethod, "HandlerMethod is required");
/* 115 */     this.bean = handlerMethod.bean;
/* 116 */     this.beanFactory = handlerMethod.beanFactory;
/* 117 */     this.beanType = handlerMethod.beanType;
/* 118 */     this.method = handlerMethod.method;
/* 119 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 120 */     this.parameters = handlerMethod.parameters;
/*     */   }
/*     */ 
/*     */   private HandlerMethod(HandlerMethod handlerMethod, Object handler)
/*     */   {
/* 127 */     Assert.notNull(handlerMethod, "HandlerMethod is required");
/* 128 */     Assert.notNull(handler, "Handler object is required");
/* 129 */     this.bean = handler;
/* 130 */     this.beanFactory = handlerMethod.beanFactory;
/* 131 */     this.beanType = handlerMethod.beanType;
/* 132 */     this.method = handlerMethod.method;
/* 133 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 134 */     this.parameters = handlerMethod.parameters;
/*     */   }
/*     */ 
/*     */   private MethodParameter[] initMethodParameters()
/*     */   {
/* 139 */     int count = this.bridgedMethod.getParameterTypes().length;
/* 140 */     MethodParameter[] result = new MethodParameter[count];
/* 141 */     for (int i = 0; i < count; i++) {
/* 142 */       result[i] = new HandlerMethodParameter(i);
/*     */     }
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */   public Object getBean()
/*     */   {
/* 151 */     return this.bean;
/*     */   }
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/* 158 */     return this.method;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 167 */     return this.beanType;
/*     */   }
/*     */ 
/*     */   protected Method getBridgedMethod()
/*     */   {
/* 175 */     return this.bridgedMethod;
/*     */   }
/*     */ 
/*     */   public MethodParameter[] getMethodParameters()
/*     */   {
/* 182 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public MethodParameter getReturnType()
/*     */   {
/* 189 */     return new HandlerMethodParameter(-1);
/*     */   }
/*     */ 
/*     */   public MethodParameter getReturnValueType(Object returnValue)
/*     */   {
/* 196 */     return new ReturnValueMethodParameter(returnValue);
/*     */   }
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 203 */     return Void.TYPE.equals(getReturnType().getParameterType());
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType)
/*     */   {
/* 213 */     return AnnotationUtils.findAnnotation(this.method, annotationType);
/*     */   }
/*     */ 
/*     */   public HandlerMethod createWithResolvedBean()
/*     */   {
/* 221 */     Object handler = this.bean;
/* 222 */     if ((this.bean instanceof String)) {
/* 223 */       String beanName = (String)this.bean;
/* 224 */       handler = this.beanFactory.getBean(beanName);
/*     */     }
/* 226 */     return new HandlerMethod(this, handler);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 232 */     if (this == other) {
/* 233 */       return true;
/*     */     }
/* 235 */     if (!(other instanceof HandlerMethod)) {
/* 236 */       return false;
/*     */     }
/* 238 */     HandlerMethod otherMethod = (HandlerMethod)other;
/* 239 */     return (this.bean.equals(otherMethod.bean)) && (this.method.equals(otherMethod.method));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 244 */     return this.bean.hashCode() * 31 + this.method.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 249 */     return this.method.toGenericString();
/*     */   }
/*     */ 
/*     */   private class ReturnValueMethodParameter extends HandlerMethod.HandlerMethodParameter
/*     */   {
/*     */     private final Object returnValue;
/*     */ 
/*     */     public ReturnValueMethodParameter(Object returnValue)
/*     */     {
/* 282 */       super(-1);
/* 283 */       this.returnValue = returnValue;
/*     */     }
/*     */ 
/*     */     public Class<?> getParameterType()
/*     */     {
/* 288 */       return this.returnValue != null ? this.returnValue.getClass() : super.getParameterType();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class HandlerMethodParameter extends MethodParameter
/*     */   {
/*     */     public HandlerMethodParameter(int index)
/*     */     {
/* 259 */       super(index);
/*     */     }
/*     */ 
/*     */     public Class<?> getContainingClass()
/*     */     {
/* 264 */       return HandlerMethod.this.getBeanType();
/*     */     }
/*     */ 
/*     */     public <T extends Annotation> T getMethodAnnotation(Class<T> annotationType)
/*     */     {
/* 269 */       return HandlerMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.HandlerMethod
 * JD-Core Version:    0.6.2
 */