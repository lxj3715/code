/*    */ package org.springframework.web.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.Arrays;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.BridgeMethodResolver;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*    */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*    */ 
/*    */ public abstract class HandlerMethodSelector
/*    */ {
/*    */   public static Set<Method> selectMethods(Class<?> handlerType, final ReflectionUtils.MethodFilter handlerMethodFilter)
/*    */   {
/* 47 */     final Set handlerMethods = new LinkedHashSet();
/* 48 */     Set handlerTypes = new LinkedHashSet();
/* 49 */     Class specificHandlerType = null;
/* 50 */     if (!Proxy.isProxyClass(handlerType)) {
/* 51 */       handlerTypes.add(handlerType);
/* 52 */       specificHandlerType = handlerType;
/*    */     }
/* 54 */     handlerTypes.addAll(Arrays.asList(handlerType.getInterfaces()));
/* 55 */     for (Class currentHandlerType : handlerTypes) {
/* 56 */       Class targetClass = specificHandlerType != null ? specificHandlerType : currentHandlerType;
/* 57 */       ReflectionUtils.doWithMethods(currentHandlerType, new ReflectionUtils.MethodCallback()
/*    */       {
/*    */         public void doWith(Method method) {
/* 60 */           Method specificMethod = ClassUtils.getMostSpecificMethod(method, this.val$targetClass);
/* 61 */           Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/* 62 */           if ((handlerMethodFilter.matches(specificMethod)) && ((bridgedMethod == specificMethod) || 
/* 63 */             (!handlerMethodFilter
/* 63 */             .matches(bridgedMethod))))
/*    */           {
/* 64 */             handlerMethods.add(specificMethod);
/*    */           }
/*    */         }
/*    */       }
/*    */       , ReflectionUtils.USER_DECLARED_METHODS);
/*    */     }
/*    */ 
/* 69 */     return handlerMethods;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.HandlerMethodSelector
 * JD-Core Version:    0.6.2
 */