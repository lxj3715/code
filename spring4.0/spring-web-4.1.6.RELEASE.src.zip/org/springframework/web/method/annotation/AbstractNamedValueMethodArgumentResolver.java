/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*     */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.RequestScope;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public abstract class AbstractNamedValueMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   private final ConfigurableBeanFactory configurableBeanFactory;
/*     */   private final BeanExpressionContext expressionContext;
/*  62 */   private Map<MethodParameter, NamedValueInfo> namedValueInfoCache = new ConcurrentHashMap(256);
/*     */ 
/*     */   public AbstractNamedValueMethodArgumentResolver()
/*     */   {
/*  66 */     this.configurableBeanFactory = null;
/*  67 */     this.expressionContext = null;
/*     */   }
/*     */ 
/*     */   public AbstractNamedValueMethodArgumentResolver(ConfigurableBeanFactory beanFactory)
/*     */   {
/*  76 */     this.configurableBeanFactory = beanFactory;
/*  77 */     this.expressionContext = (beanFactory != null ? new BeanExpressionContext(beanFactory, new RequestScope()) : null);
/*     */   }
/*     */ 
/*     */   public final Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/*  85 */     Class paramType = parameter.getParameterType();
/*  86 */     NamedValueInfo namedValueInfo = getNamedValueInfo(parameter);
/*     */ 
/*  88 */     Object arg = resolveName(namedValueInfo.name, parameter, webRequest);
/*  89 */     if (arg == null) {
/*  90 */       if (namedValueInfo.defaultValue != null) {
/*  91 */         arg = resolveDefaultValue(namedValueInfo.defaultValue);
/*     */       }
/*  93 */       else if ((namedValueInfo.required) && (!parameter.getParameterType().getName().equals("java.util.Optional"))) {
/*  94 */         handleMissingValue(namedValueInfo.name, parameter);
/*     */       }
/*  96 */       arg = handleNullValue(namedValueInfo.name, arg, paramType);
/*     */     }
/*  98 */     else if (("".equals(arg)) && (namedValueInfo.defaultValue != null)) {
/*  99 */       arg = resolveDefaultValue(namedValueInfo.defaultValue);
/*     */     }
/*     */ 
/* 102 */     if (binderFactory != null) {
/* 103 */       WebDataBinder binder = binderFactory.createBinder(webRequest, null, namedValueInfo.name);
/* 104 */       arg = binder.convertIfNecessary(arg, paramType, parameter);
/*     */     }
/*     */ 
/* 107 */     handleResolvedValue(arg, namedValueInfo.name, parameter, mavContainer, webRequest);
/*     */ 
/* 109 */     return arg;
/*     */   }
/*     */ 
/*     */   private NamedValueInfo getNamedValueInfo(MethodParameter parameter)
/*     */   {
/* 116 */     NamedValueInfo namedValueInfo = (NamedValueInfo)this.namedValueInfoCache.get(parameter);
/* 117 */     if (namedValueInfo == null) {
/* 118 */       namedValueInfo = createNamedValueInfo(parameter);
/* 119 */       namedValueInfo = updateNamedValueInfo(parameter, namedValueInfo);
/* 120 */       this.namedValueInfoCache.put(parameter, namedValueInfo);
/*     */     }
/* 122 */     return namedValueInfo;
/*     */   }
/*     */ 
/*     */   protected abstract NamedValueInfo createNamedValueInfo(MethodParameter paramMethodParameter);
/*     */ 
/*     */   private NamedValueInfo updateNamedValueInfo(MethodParameter parameter, NamedValueInfo info)
/*     */   {
/* 137 */     String name = info.name;
/* 138 */     if (info.name.length() == 0) {
/* 139 */       name = parameter.getParameterName();
/* 140 */       if (name == null) {
/* 141 */         throw new IllegalArgumentException("Name for argument type [" + parameter.getParameterType().getName() + "] not available, and parameter name information not found in class file either.");
/*     */       }
/*     */     }
/*     */ 
/* 145 */     String defaultValue = "\n\t\t\n\t\t\n\n\t\t\t\t\n".equals(info.defaultValue) ? null : info.defaultValue;
/* 146 */     return new NamedValueInfo(name, info.required, defaultValue);
/*     */   }
/*     */ 
/*     */   protected abstract Object resolveName(String paramString, MethodParameter paramMethodParameter, NativeWebRequest paramNativeWebRequest)
/*     */     throws Exception;
/*     */ 
/*     */   private Object resolveDefaultValue(String defaultValue)
/*     */   {
/* 164 */     if (this.configurableBeanFactory == null) {
/* 165 */       return defaultValue;
/*     */     }
/* 167 */     String placeholdersResolved = this.configurableBeanFactory.resolveEmbeddedValue(defaultValue);
/* 168 */     BeanExpressionResolver exprResolver = this.configurableBeanFactory.getBeanExpressionResolver();
/* 169 */     if (exprResolver == null) {
/* 170 */       return defaultValue;
/*     */     }
/* 172 */     return exprResolver.evaluate(placeholdersResolved, this.expressionContext);
/*     */   }
/*     */ 
/*     */   protected abstract void handleMissingValue(String paramString, MethodParameter paramMethodParameter)
/*     */     throws ServletException;
/*     */ 
/*     */   private Object handleNullValue(String name, Object value, Class<?> paramType)
/*     */   {
/* 187 */     if (value == null) {
/* 188 */       if (Boolean.TYPE.equals(paramType)) {
/* 189 */         return Boolean.FALSE;
/*     */       }
/* 191 */       if (paramType.isPrimitive()) {
/* 192 */         throw new IllegalStateException("Optional " + paramType + " parameter '" + name + "' is present but cannot be translated into a null value due to being declared as a " + "primitive type. Consider declaring it as object wrapper for the corresponding primitive type.");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 197 */     return value;
/*     */   }
/*     */ 
/*     */   protected void handleResolvedValue(Object arg, String name, MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected static class NamedValueInfo
/*     */   {
/*     */     private final String name;
/*     */     private final boolean required;
/*     */     private final String defaultValue;
/*     */ 
/*     */     public NamedValueInfo(String name, boolean required, String defaultValue)
/*     */     {
/* 225 */       this.name = name;
/* 226 */       this.required = required;
/* 227 */       this.defaultValue = defaultValue;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.AbstractNamedValueMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */