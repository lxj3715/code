/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.bind.support.WebRequestDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public class ModelAttributeMethodProcessor
/*     */   implements HandlerMethodArgumentResolver, HandlerMethodReturnValueHandler
/*     */ {
/*  59 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final boolean annotationNotRequired;
/*     */ 
/*     */   public ModelAttributeMethodProcessor(boolean annotationNotRequired)
/*     */   {
/*  70 */     this.annotationNotRequired = annotationNotRequired;
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  80 */     if (parameter.hasParameterAnnotation(ModelAttribute.class)) {
/*  81 */       return true;
/*     */     }
/*  83 */     if (this.annotationNotRequired) {
/*  84 */       return !BeanUtils.isSimpleProperty(parameter.getParameterType());
/*     */     }
/*     */ 
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   public final Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 104 */     String name = ModelFactory.getNameForParameter(parameter);
/*     */ 
/* 106 */     Object attribute = mavContainer.containsAttribute(name) ? mavContainer
/* 106 */       .getModel().get(name) : createAttribute(name, parameter, binderFactory, webRequest);
/*     */ 
/* 108 */     WebDataBinder binder = binderFactory.createBinder(webRequest, attribute, name);
/* 109 */     if (binder.getTarget() != null) {
/* 110 */       bindRequestParameters(binder, webRequest);
/* 111 */       validateIfApplicable(binder, parameter);
/* 112 */       if ((binder.getBindingResult().hasErrors()) && (isBindExceptionRequired(binder, parameter))) {
/* 113 */         throw new BindException(binder.getBindingResult());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 118 */     Map bindingResultModel = binder.getBindingResult().getModel();
/* 119 */     mavContainer.removeAttributes(bindingResultModel);
/* 120 */     mavContainer.addAllAttributes(bindingResultModel);
/*     */ 
/* 122 */     return binder.convertIfNecessary(binder.getTarget(), parameter.getParameterType(), parameter);
/*     */   }
/*     */ 
/*     */   protected Object createAttribute(String attributeName, MethodParameter methodParam, WebDataBinderFactory binderFactory, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/* 137 */     return BeanUtils.instantiateClass(methodParam.getParameterType());
/*     */   }
/*     */ 
/*     */   protected void bindRequestParameters(WebDataBinder binder, NativeWebRequest request)
/*     */   {
/* 146 */     ((WebRequestDataBinder)binder).bind(request);
/*     */   }
/*     */ 
/*     */   protected void validateIfApplicable(WebDataBinder binder, MethodParameter methodParam)
/*     */   {
/* 158 */     Annotation[] annotations = methodParam.getParameterAnnotations();
/* 159 */     for (Annotation ann : annotations) {
/* 160 */       Validated validatedAnn = (Validated)AnnotationUtils.getAnnotation(ann, Validated.class);
/* 161 */       if ((validatedAnn != null) || (ann.annotationType().getSimpleName().startsWith("Valid"))) {
/* 162 */         Object hints = validatedAnn != null ? validatedAnn.value() : AnnotationUtils.getValue(ann);
/* 163 */         Object[] validationHints = { (hints instanceof Object[]) ? (Object[])hints : hints };
/* 164 */         binder.validate(validationHints);
/* 165 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isBindExceptionRequired(WebDataBinder binder, MethodParameter methodParam)
/*     */   {
/* 177 */     int i = methodParam.getParameterIndex();
/* 178 */     Class[] paramTypes = methodParam.getMethod().getParameterTypes();
/* 179 */     boolean hasBindingResult = (paramTypes.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/* 180 */     return !hasBindingResult;
/*     */   }
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/* 189 */     if (returnType.getMethodAnnotation(ModelAttribute.class) != null) {
/* 190 */       return true;
/*     */     }
/* 192 */     if (this.annotationNotRequired) {
/* 193 */       return !BeanUtils.isSimpleProperty(returnType.getParameterType());
/*     */     }
/*     */ 
/* 196 */     return false;
/*     */   }
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 207 */     if (returnValue != null) {
/* 208 */       String name = ModelFactory.getNameForReturnValue(returnValue, returnType);
/* 209 */       mavContainer.addAttribute(name, returnValue);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ModelAttributeMethodProcessor
 * JD-Core Version:    0.6.2
 */