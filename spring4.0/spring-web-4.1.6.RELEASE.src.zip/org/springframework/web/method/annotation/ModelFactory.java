/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.HttpSessionRequiredException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.support.SessionStatus;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.support.InvocableHandlerMethod;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public final class ModelFactory
/*     */ {
/*  62 */   private static final Log logger = LogFactory.getLog(ModelFactory.class);
/*     */ 
/*  64 */   private final List<ModelMethod> modelMethods = new ArrayList();
/*     */   private final WebDataBinderFactory dataBinderFactory;
/*     */   private final SessionAttributesHandler sessionAttributesHandler;
/*     */ 
/*     */   public ModelFactory(List<InvocableHandlerMethod> invocableMethods, WebDataBinderFactory dataBinderFactory, SessionAttributesHandler sessionAttributesHandler)
/*     */   {
/*  80 */     if (invocableMethods != null) {
/*  81 */       for (InvocableHandlerMethod method : invocableMethods) {
/*  82 */         this.modelMethods.add(new ModelMethod(method, null));
/*     */       }
/*     */     }
/*  85 */     this.dataBinderFactory = dataBinderFactory;
/*  86 */     this.sessionAttributesHandler = sessionAttributesHandler;
/*     */   }
/*     */ 
/*     */   public void initModel(NativeWebRequest request, ModelAndViewContainer mavContainer, HandlerMethod handlerMethod)
/*     */     throws Exception
/*     */   {
/* 106 */     Map sessionAttributes = this.sessionAttributesHandler.retrieveAttributes(request);
/* 107 */     mavContainer.mergeAttributes(sessionAttributes);
/*     */ 
/* 109 */     invokeModelAttributeMethods(request, mavContainer);
/*     */ 
/* 111 */     for (String name : findSessionAttributeArguments(handlerMethod))
/* 112 */       if (!mavContainer.containsAttribute(name)) {
/* 113 */         Object value = this.sessionAttributesHandler.retrieveAttribute(request, name);
/* 114 */         if (value == null) {
/* 115 */           throw new HttpSessionRequiredException("Expected session attribute '" + name + "'");
/*     */         }
/* 117 */         mavContainer.addAttribute(name, value);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void invokeModelAttributeMethods(NativeWebRequest request, ModelAndViewContainer mavContainer)
/*     */     throws Exception
/*     */   {
/* 129 */     while (!this.modelMethods.isEmpty()) {
/* 130 */       InvocableHandlerMethod attrMethod = getNextModelMethod(mavContainer).getHandlerMethod();
/* 131 */       String modelName = ((ModelAttribute)attrMethod.getMethodAnnotation(ModelAttribute.class)).value();
/* 132 */       if (!mavContainer.containsAttribute(modelName))
/*     */       {
/* 136 */         Object returnValue = attrMethod.invokeForRequest(request, mavContainer, new Object[0]);
/*     */ 
/* 138 */         if (!attrMethod.isVoid()) {
/* 139 */           String returnValueName = getNameForReturnValue(returnValue, attrMethod.getReturnType());
/* 140 */           if (!mavContainer.containsAttribute(returnValueName))
/* 141 */             mavContainer.addAttribute(returnValueName, returnValue);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private ModelMethod getNextModelMethod(ModelAndViewContainer mavContainer) {
/* 148 */     for (ModelMethod modelMethod : this.modelMethods) {
/* 149 */       if (modelMethod.checkDependencies(mavContainer)) {
/* 150 */         if (logger.isTraceEnabled()) {
/* 151 */           logger.trace("Selected @ModelAttribute method " + modelMethod);
/*     */         }
/* 153 */         this.modelMethods.remove(modelMethod);
/* 154 */         return modelMethod;
/*     */       }
/*     */     }
/* 157 */     ModelMethod modelMethod = (ModelMethod)this.modelMethods.get(0);
/* 158 */     if (logger.isTraceEnabled()) {
/* 159 */       logger.trace("Selected @ModelAttribute method (not present: " + modelMethod
/* 160 */         .getUnresolvedDependencies(mavContainer) + 
/* 160 */         ") " + modelMethod);
/*     */     }
/* 162 */     this.modelMethods.remove(modelMethod);
/* 163 */     return modelMethod;
/*     */   }
/*     */ 
/*     */   private List<String> findSessionAttributeArguments(HandlerMethod handlerMethod)
/*     */   {
/* 170 */     List result = new ArrayList();
/* 171 */     for (MethodParameter parameter : handlerMethod.getMethodParameters()) {
/* 172 */       if (parameter.hasParameterAnnotation(ModelAttribute.class)) {
/* 173 */         String name = getNameForParameter(parameter);
/* 174 */         if (this.sessionAttributesHandler.isHandlerSessionAttribute(name, parameter.getParameterType())) {
/* 175 */           result.add(name);
/*     */         }
/*     */       }
/*     */     }
/* 179 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getNameForParameter(MethodParameter parameter)
/*     */   {
/* 191 */     ModelAttribute annot = (ModelAttribute)parameter.getParameterAnnotation(ModelAttribute.class);
/* 192 */     String attrName = annot != null ? annot.value() : null;
/* 193 */     return StringUtils.hasText(attrName) ? attrName : Conventions.getVariableNameForParameter(parameter);
/*     */   }
/*     */ 
/*     */   public static String getNameForReturnValue(Object returnValue, MethodParameter returnType)
/*     */   {
/* 208 */     ModelAttribute annotation = (ModelAttribute)returnType.getMethodAnnotation(ModelAttribute.class);
/* 209 */     if ((annotation != null) && (StringUtils.hasText(annotation.value()))) {
/* 210 */       return annotation.value();
/*     */     }
/*     */ 
/* 213 */     Method method = returnType.getMethod();
/* 214 */     Class resolvedType = GenericTypeResolver.resolveReturnType(method, returnType.getContainingClass());
/* 215 */     return Conventions.getVariableNameForReturnType(method, resolvedType, returnValue);
/*     */   }
/*     */ 
/*     */   public void updateModel(NativeWebRequest request, ModelAndViewContainer mavContainer)
/*     */     throws Exception
/*     */   {
/* 227 */     ModelMap defaultModel = mavContainer.getDefaultModel();
/* 228 */     if (mavContainer.getSessionStatus().isComplete()) {
/* 229 */       this.sessionAttributesHandler.cleanupAttributes(request);
/*     */     }
/*     */     else {
/* 232 */       this.sessionAttributesHandler.storeAttributes(request, defaultModel);
/*     */     }
/* 234 */     if ((!mavContainer.isRequestHandled()) && (mavContainer.getModel() == defaultModel))
/* 235 */       updateBindingResult(request, defaultModel);
/*     */   }
/*     */ 
/*     */   private void updateBindingResult(NativeWebRequest request, ModelMap model)
/*     */     throws Exception
/*     */   {
/* 243 */     List keyNames = new ArrayList(model.keySet());
/* 244 */     for (String name : keyNames) {
/* 245 */       Object value = model.get(name);
/*     */ 
/* 247 */       if (isBindingCandidate(name, value)) {
/* 248 */         String bindingResultKey = BindingResult.MODEL_KEY_PREFIX + name;
/*     */ 
/* 250 */         if (!model.containsAttribute(bindingResultKey)) {
/* 251 */           WebDataBinder dataBinder = this.dataBinderFactory.createBinder(request, value, name);
/* 252 */           model.put(bindingResultKey, dataBinder.getBindingResult());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isBindingCandidate(String attributeName, Object value)
/*     */   {
/* 262 */     if (attributeName.startsWith(BindingResult.MODEL_KEY_PREFIX)) {
/* 263 */       return false;
/*     */     }
/*     */ 
/* 266 */     Class attrType = value != null ? value.getClass() : null;
/* 267 */     if (this.sessionAttributesHandler.isHandlerSessionAttribute(attributeName, attrType)) {
/* 268 */       return true;
/*     */     }
/*     */ 
/* 272 */     return (value != null) && (!value.getClass().isArray()) && (!(value instanceof Collection)) && (!(value instanceof Map)) && 
/* 272 */       (!BeanUtils.isSimpleValueType(value
/* 272 */       .getClass()));
/*     */   }
/*     */ 
/*     */   private static class ModelMethod
/*     */   {
/*     */     private final InvocableHandlerMethod handlerMethod;
/* 280 */     private final Set<String> dependencies = new HashSet();
/*     */ 
/*     */     private ModelMethod(InvocableHandlerMethod handlerMethod)
/*     */     {
/* 284 */       this.handlerMethod = handlerMethod;
/* 285 */       for (MethodParameter parameter : handlerMethod.getMethodParameters())
/* 286 */         if (parameter.hasParameterAnnotation(ModelAttribute.class))
/* 287 */           this.dependencies.add(ModelFactory.getNameForParameter(parameter));
/*     */     }
/*     */ 
/*     */     public InvocableHandlerMethod getHandlerMethod()
/*     */     {
/* 293 */       return this.handlerMethod;
/*     */     }
/*     */ 
/*     */     public boolean checkDependencies(ModelAndViewContainer mavContainer) {
/* 297 */       for (String name : this.dependencies) {
/* 298 */         if (!mavContainer.containsAttribute(name)) {
/* 299 */           return false;
/*     */         }
/*     */       }
/* 302 */       return true;
/*     */     }
/*     */ 
/*     */     public List<String> getUnresolvedDependencies(ModelAndViewContainer mavContainer) {
/* 306 */       List result = new ArrayList(this.dependencies.size());
/* 307 */       for (String name : this.dependencies) {
/* 308 */         if (!mavContainer.containsAttribute(name)) {
/* 309 */           result.add(name);
/*     */         }
/*     */       }
/* 312 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 317 */       return this.handlerMethod.getMethod().toGenericString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ModelFactory
 * JD-Core Version:    0.6.2
 */