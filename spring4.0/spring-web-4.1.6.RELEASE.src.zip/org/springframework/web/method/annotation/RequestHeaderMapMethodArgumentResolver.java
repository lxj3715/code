/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.bind.annotation.RequestHeader;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class RequestHeaderMapMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 51 */     return (parameter.hasParameterAnnotation(RequestHeader.class)) && 
/* 51 */       (Map.class
/* 51 */       .isAssignableFrom(parameter
/* 51 */       .getParameterType()));
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 58 */     Class paramType = parameter.getParameterType();
/* 59 */     if (MultiValueMap.class.isAssignableFrom(paramType))
/*    */     {
/*    */       MultiValueMap result;
/*    */       MultiValueMap result;
/* 61 */       if (HttpHeaders.class.isAssignableFrom(paramType)) {
/* 62 */         result = new HttpHeaders();
/*    */       }
/*    */       else {
/* 65 */         result = new LinkedMultiValueMap();
/*    */       }
/* 67 */       for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 68 */         String headerName = (String)iterator.next();
/* 69 */         for (String headerValue : webRequest.getHeaderValues(headerName)) {
/* 70 */           result.add(headerName, headerValue);
/*    */         }
/*    */       }
/* 73 */       return result;
/*    */     }
/*    */ 
/* 76 */     Map result = new LinkedHashMap();
/* 77 */     for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 78 */       String headerName = (String)iterator.next();
/* 79 */       String headerValue = webRequest.getHeader(headerName);
/* 80 */       result.put(headerName, headerValue);
/*    */     }
/* 82 */     return result;
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestHeaderMapMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */