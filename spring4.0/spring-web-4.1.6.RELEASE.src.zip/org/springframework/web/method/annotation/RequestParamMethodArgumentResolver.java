/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.GenericCollectionTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.annotation.RequestPart;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.UriComponentsContributor;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class RequestParamMethodArgumentResolver extends AbstractNamedValueMethodArgumentResolver
/*     */   implements UriComponentsContributor
/*     */ {
/*  80 */   private static final TypeDescriptor STRING_TYPE_DESCRIPTOR = TypeDescriptor.valueOf(String.class);
/*     */   private final boolean useDefaultResolution;
/*     */ 
/*     */   public RequestParamMethodArgumentResolver(boolean useDefaultResolution)
/*     */   {
/*  92 */     this.useDefaultResolution = useDefaultResolution;
/*     */   }
/*     */ 
/*     */   public RequestParamMethodArgumentResolver(ConfigurableBeanFactory beanFactory, boolean useDefaultResolution)
/*     */   {
/* 105 */     super(beanFactory);
/* 106 */     this.useDefaultResolution = useDefaultResolution;
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/* 127 */     Class paramType = parameter.getParameterType();
/* 128 */     if (parameter.hasParameterAnnotation(RequestParam.class)) {
/* 129 */       if (Map.class.isAssignableFrom(paramType)) {
/* 130 */         String paramName = ((RequestParam)parameter.getParameterAnnotation(RequestParam.class)).value();
/* 131 */         return StringUtils.hasText(paramName);
/*     */       }
/*     */ 
/* 134 */       return true;
/*     */     }
/*     */ 
/* 138 */     if (parameter.hasParameterAnnotation(RequestPart.class)) {
/* 139 */       return false;
/*     */     }
/* 141 */     if ((MultipartFile.class.equals(paramType)) || ("javax.servlet.http.Part".equals(paramType.getName()))) {
/* 142 */       return true;
/*     */     }
/* 144 */     if (this.useDefaultResolution) {
/* 145 */       return BeanUtils.isSimpleProperty(paramType);
/*     */     }
/*     */ 
/* 148 */     return false;
/*     */   }
/*     */ 
/*     */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*     */   {
/* 155 */     RequestParam ann = (RequestParam)parameter.getParameterAnnotation(RequestParam.class);
/* 156 */     return ann != null ? new RequestParamNamedValueInfo(ann) : new RequestParamNamedValueInfo();
/*     */   }
/*     */ 
/*     */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest webRequest) throws Exception
/*     */   {
/* 161 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*     */ 
/* 163 */     MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)WebUtils.getNativeRequest(servletRequest, MultipartHttpServletRequest.class);
/*     */     Object arg;
/*     */     Object arg;
/* 166 */     if (MultipartFile.class.equals(parameter.getParameterType())) {
/* 167 */       assertIsMultipartRequest(servletRequest);
/* 168 */       Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 169 */       arg = multipartRequest.getFile(name);
/*     */     }
/*     */     else
/*     */     {
/*     */       Object arg;
/* 171 */       if (isMultipartFileCollection(parameter)) {
/* 172 */         assertIsMultipartRequest(servletRequest);
/* 173 */         Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 174 */         arg = multipartRequest.getFiles(name);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object arg;
/* 176 */         if (isMultipartFileArray(parameter)) {
/* 177 */           assertIsMultipartRequest(servletRequest);
/* 178 */           Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 179 */           List multipartFiles = multipartRequest.getFiles(name);
/* 180 */           arg = multipartFiles.toArray(new MultipartFile[multipartFiles.size()]);
/*     */         }
/*     */         else
/*     */         {
/*     */           Object arg;
/* 182 */           if ("javax.servlet.http.Part".equals(parameter.getParameterType().getName())) {
/* 183 */             assertIsMultipartRequest(servletRequest);
/* 184 */             arg = servletRequest.getPart(name);
/*     */           }
/*     */           else
/*     */           {
/*     */             Object arg;
/* 186 */             if (isPartCollection(parameter)) {
/* 187 */               assertIsMultipartRequest(servletRequest);
/* 188 */               arg = new ArrayList(servletRequest.getParts());
/*     */             }
/*     */             else
/*     */             {
/*     */               Object arg;
/* 190 */               if (isPartArray(parameter)) {
/* 191 */                 assertIsMultipartRequest(servletRequest);
/* 192 */                 arg = RequestPartResolver.resolvePart(servletRequest);
/*     */               }
/*     */               else {
/* 195 */                 arg = null;
/* 196 */                 if (multipartRequest != null) {
/* 197 */                   List files = multipartRequest.getFiles(name);
/* 198 */                   if (!files.isEmpty()) {
/* 199 */                     arg = files.size() == 1 ? files.get(0) : files;
/*     */                   }
/*     */                 }
/* 202 */                 if (arg == null) {
/* 203 */                   String[] paramValues = webRequest.getParameterValues(name);
/* 204 */                   if (paramValues != null)
/* 205 */                     arg = paramValues.length == 1 ? paramValues[0] : paramValues; 
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 210 */     return arg;
/*     */   }
/*     */ 
/*     */   private void assertIsMultipartRequest(HttpServletRequest request) {
/* 214 */     String contentType = request.getContentType();
/* 215 */     if ((contentType == null) || (!contentType.toLowerCase().startsWith("multipart/")))
/* 216 */       throw new MultipartException("The current request is not a multipart request");
/*     */   }
/*     */ 
/*     */   private boolean isMultipartFileCollection(MethodParameter parameter)
/*     */   {
/* 221 */     Class collectionType = getCollectionParameterType(parameter);
/* 222 */     return (collectionType != null) && (collectionType.equals(MultipartFile.class));
/*     */   }
/*     */ 
/*     */   private boolean isPartCollection(MethodParameter parameter) {
/* 226 */     Class collectionType = getCollectionParameterType(parameter);
/* 227 */     return (collectionType != null) && ("javax.servlet.http.Part".equals(collectionType.getName()));
/*     */   }
/*     */ 
/*     */   private boolean isPartArray(MethodParameter parameter) {
/* 231 */     Class paramType = parameter.getParameterType().getComponentType();
/* 232 */     return (paramType != null) && ("javax.servlet.http.Part".equals(paramType.getName()));
/*     */   }
/*     */ 
/*     */   private boolean isMultipartFileArray(MethodParameter parameter) {
/* 236 */     Class paramType = parameter.getParameterType().getComponentType();
/* 237 */     return (paramType != null) && (MultipartFile.class.equals(paramType));
/*     */   }
/*     */ 
/*     */   private Class<?> getCollectionParameterType(MethodParameter parameter) {
/* 241 */     Class paramType = parameter.getParameterType();
/* 242 */     if ((Collection.class.equals(paramType)) || (List.class.isAssignableFrom(paramType))) {
/* 243 */       Class valueType = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 244 */       if (valueType != null) {
/* 245 */         return valueType;
/*     */       }
/*     */     }
/* 248 */     return null;
/*     */   }
/*     */ 
/*     */   protected void handleMissingValue(String name, MethodParameter parameter) throws ServletException
/*     */   {
/* 253 */     throw new MissingServletRequestParameterException(name, parameter.getParameterType().getSimpleName());
/*     */   }
/*     */ 
/*     */   public void contributeMethodArgument(MethodParameter parameter, Object value, UriComponentsBuilder builder, Map<String, Object> uriVariables, ConversionService conversionService)
/*     */   {
/* 260 */     Class paramType = parameter.getParameterType();
/* 261 */     if ((Map.class.isAssignableFrom(paramType)) || (MultipartFile.class.equals(paramType)) || 
/* 262 */       ("javax.servlet.http.Part"
/* 262 */       .equals(paramType
/* 262 */       .getName()))) {
/* 263 */       return;
/*     */     }
/*     */ 
/* 266 */     RequestParam ann = (RequestParam)parameter.getParameterAnnotation(RequestParam.class);
/* 267 */     String name = (ann == null) || (StringUtils.isEmpty(ann.value())) ? parameter.getParameterName() : ann.value();
/*     */ 
/* 269 */     if (value == null) {
/* 270 */       builder.queryParam(name, new Object[0]);
/*     */     }
/*     */     else
/*     */     {
/*     */       Iterator localIterator;
/* 272 */       if ((value instanceof Collection)) {
/* 273 */         for (localIterator = ((Collection)value).iterator(); localIterator.hasNext(); ) { Object element = localIterator.next();
/* 274 */           element = formatUriValue(conversionService, TypeDescriptor.nested(parameter, 1), element);
/* 275 */           builder.queryParam(name, new Object[] { element });
/*     */         }
/*     */       }
/*     */       else
/* 279 */         builder.queryParam(name, new Object[] { formatUriValue(conversionService, new TypeDescriptor(parameter), value) });
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String formatUriValue(ConversionService cs, TypeDescriptor sourceType, Object value) {
/* 284 */     if (value == null) {
/* 285 */       return null;
/*     */     }
/* 287 */     if ((value instanceof String)) {
/* 288 */       return (String)value;
/*     */     }
/* 290 */     if (cs != null) {
/* 291 */       return (String)cs.convert(value, sourceType, STRING_TYPE_DESCRIPTOR);
/*     */     }
/*     */ 
/* 294 */     return value.toString();
/*     */   }
/*     */ 
/*     */   private static class RequestPartResolver
/*     */   {
/*     */     public static Object resolvePart(HttpServletRequest servletRequest)
/*     */       throws Exception
/*     */     {
/* 314 */       return servletRequest.getParts().toArray(new Part[servletRequest.getParts().size()]);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RequestParamNamedValueInfo extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*     */   {
/*     */     public RequestParamNamedValueInfo()
/*     */     {
/* 302 */       super(false, "\n\t\t\n\t\t\n\n\t\t\t\t\n");
/*     */     }
/*     */ 
/*     */     public RequestParamNamedValueInfo(RequestParam annotation) {
/* 306 */       super(annotation.required(), annotation.defaultValue());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestParamMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */