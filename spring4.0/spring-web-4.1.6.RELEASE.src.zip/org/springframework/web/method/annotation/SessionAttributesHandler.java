/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.bind.annotation.SessionAttributes;
/*     */ import org.springframework.web.bind.support.SessionAttributeStore;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ 
/*     */ public class SessionAttributesHandler
/*     */ {
/*  50 */   private final Set<String> attributeNames = new HashSet();
/*     */ 
/*  52 */   private final Set<Class<?>> attributeTypes = new HashSet();
/*     */ 
/*  55 */   private final Set<String> knownAttributeNames = Collections.newSetFromMap(new ConcurrentHashMap(4))
/*  55 */     ;
/*     */   private final SessionAttributeStore sessionAttributeStore;
/*     */ 
/*     */   public SessionAttributesHandler(Class<?> handlerType, SessionAttributeStore sessionAttributeStore)
/*     */   {
/*  68 */     Assert.notNull(sessionAttributeStore, "SessionAttributeStore may not be null.");
/*  69 */     this.sessionAttributeStore = sessionAttributeStore;
/*     */ 
/*  71 */     SessionAttributes annotation = (SessionAttributes)AnnotationUtils.findAnnotation(handlerType, SessionAttributes.class);
/*  72 */     if (annotation != null) {
/*  73 */       this.attributeNames.addAll(Arrays.asList(annotation.value()));
/*  74 */       this.attributeTypes.addAll(Arrays.asList(annotation.types()));
/*     */     }
/*     */ 
/*  77 */     for (String attributeName : this.attributeNames)
/*  78 */       this.knownAttributeNames.add(attributeName);
/*     */   }
/*     */ 
/*     */   public boolean hasSessionAttributes()
/*     */   {
/*  87 */     return (this.attributeNames.size() > 0) || (this.attributeTypes.size() > 0);
/*     */   }
/*     */ 
/*     */   public boolean isHandlerSessionAttribute(String attributeName, Class<?> attributeType)
/*     */   {
/* 102 */     Assert.notNull(attributeName, "Attribute name must not be null");
/* 103 */     if ((this.attributeNames.contains(attributeName)) || (this.attributeTypes.contains(attributeType))) {
/* 104 */       this.knownAttributeNames.add(attributeName);
/* 105 */       return true;
/*     */     }
/*     */ 
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   public void storeAttributes(WebRequest request, Map<String, ?> attributes)
/*     */   {
/* 119 */     for (String name : attributes.keySet()) {
/* 120 */       Object value = attributes.get(name);
/* 121 */       Class attrType = value != null ? value.getClass() : null;
/*     */ 
/* 123 */       if (isHandlerSessionAttribute(name, attrType))
/* 124 */         this.sessionAttributeStore.storeAttribute(request, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map<String, Object> retrieveAttributes(WebRequest request)
/*     */   {
/* 137 */     Map attributes = new HashMap();
/* 138 */     for (String name : this.knownAttributeNames) {
/* 139 */       Object value = this.sessionAttributeStore.retrieveAttribute(request, name);
/* 140 */       if (value != null) {
/* 141 */         attributes.put(name, value);
/*     */       }
/*     */     }
/* 144 */     return attributes;
/*     */   }
/*     */ 
/*     */   public void cleanupAttributes(WebRequest request)
/*     */   {
/* 154 */     for (String attributeName : this.knownAttributeNames)
/* 155 */       this.sessionAttributeStore.cleanupAttribute(request, attributeName);
/*     */   }
/*     */ 
/*     */   Object retrieveAttribute(WebRequest request, String attributeName)
/*     */   {
/* 166 */     return this.sessionAttributeStore.retrieveAttribute(request, attributeName);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.SessionAttributesHandler
 * JD-Core Version:    0.6.2
 */