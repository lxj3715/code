/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class HandlerMethodArgumentResolverComposite
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  42 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  44 */   private final List<HandlerMethodArgumentResolver> argumentResolvers = new LinkedList();
/*     */ 
/*  47 */   private final Map<MethodParameter, HandlerMethodArgumentResolver> argumentResolverCache = new ConcurrentHashMap(256);
/*     */ 
/*     */   public List<HandlerMethodArgumentResolver> getResolvers()
/*     */   {
/*  55 */     return Collections.unmodifiableList(this.argumentResolvers);
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  64 */     return getArgumentResolver(parameter) != null;
/*     */   }
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/*  75 */     HandlerMethodArgumentResolver resolver = getArgumentResolver(parameter);
/*  76 */     Assert.notNull(resolver, "Unknown parameter type [" + parameter.getParameterType().getName() + "]");
/*  77 */     return resolver.resolveArgument(parameter, mavContainer, webRequest, binderFactory);
/*     */   }
/*     */ 
/*     */   private HandlerMethodArgumentResolver getArgumentResolver(MethodParameter parameter)
/*     */   {
/*  84 */     HandlerMethodArgumentResolver result = (HandlerMethodArgumentResolver)this.argumentResolverCache.get(parameter);
/*  85 */     if (result == null) {
/*  86 */       for (HandlerMethodArgumentResolver methodArgumentResolver : this.argumentResolvers) {
/*  87 */         if (this.logger.isTraceEnabled()) {
/*  88 */           this.logger.trace("Testing if argument resolver [" + methodArgumentResolver + "] supports [" + parameter
/*  89 */             .getGenericParameterType() + "]");
/*     */         }
/*  91 */         if (methodArgumentResolver.supportsParameter(parameter)) {
/*  92 */           result = methodArgumentResolver;
/*  93 */           this.argumentResolverCache.put(parameter, result);
/*  94 */           break;
/*     */         }
/*     */       }
/*     */     }
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */   public HandlerMethodArgumentResolverComposite addResolver(HandlerMethodArgumentResolver resolver)
/*     */   {
/* 105 */     this.argumentResolvers.add(resolver);
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   public HandlerMethodArgumentResolverComposite addResolvers(List<? extends HandlerMethodArgumentResolver> resolvers)
/*     */   {
/* 113 */     if (resolvers != null) {
/* 114 */       for (HandlerMethodArgumentResolver resolver : resolvers) {
/* 115 */         this.argumentResolvers.add(resolver);
/*     */       }
/*     */     }
/* 118 */     return this;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.HandlerMethodArgumentResolverComposite
 * JD-Core Version:    0.6.2
 */