package org.springframework.web.method.support;

import org.springframework.core.MethodParameter;
import org.springframework.web.context.request.NativeWebRequest;

public abstract interface HandlerMethodReturnValueHandler
{
  public abstract boolean supportsReturnType(MethodParameter paramMethodParameter);

  public abstract void handleReturnValue(Object paramObject, MethodParameter paramMethodParameter, ModelAndViewContainer paramModelAndViewContainer, NativeWebRequest paramNativeWebRequest)
    throws Exception;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.HandlerMethodReturnValueHandler
 * JD-Core Version:    0.6.2
 */