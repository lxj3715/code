/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ 
/*     */ public class InvocableHandlerMethod extends HandlerMethod
/*     */ {
/*     */   private WebDataBinderFactory dataBinderFactory;
/*  53 */   private HandlerMethodArgumentResolverComposite argumentResolvers = new HandlerMethodArgumentResolverComposite();
/*     */ 
/*  55 */   private ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, Method method)
/*     */   {
/*  62 */     super(bean, method);
/*     */   }
/*     */ 
/*     */   public InvocableHandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/*  69 */     super(handlerMethod);
/*     */   }
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, String methodName, Class<?>[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  82 */     super(bean, methodName, parameterTypes);
/*     */   }
/*     */ 
/*     */   public void setDataBinderFactory(WebDataBinderFactory dataBinderFactory)
/*     */   {
/*  92 */     this.dataBinderFactory = dataBinderFactory;
/*     */   }
/*     */ 
/*     */   public void setHandlerMethodArgumentResolvers(HandlerMethodArgumentResolverComposite argumentResolvers)
/*     */   {
/*  99 */     this.argumentResolvers = argumentResolvers;
/*     */   }
/*     */ 
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 108 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */   public Object invokeForRequest(NativeWebRequest request, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 129 */     Object[] args = getMethodArgumentValues(request, mavContainer, providedArgs);
/* 130 */     if (this.logger.isTraceEnabled()) {
/* 131 */       StringBuilder sb = new StringBuilder("Invoking [");
/* 132 */       sb.append(getBeanType().getSimpleName()).append(".");
/* 133 */       sb.append(getMethod().getName()).append("] method with arguments ");
/* 134 */       sb.append(Arrays.asList(args));
/* 135 */       this.logger.trace(sb.toString());
/*     */     }
/* 137 */     Object returnValue = doInvoke(args);
/* 138 */     if (this.logger.isTraceEnabled()) {
/* 139 */       this.logger.trace(new StringBuilder().append("Method [").append(getMethod().getName()).append("] returned [").append(returnValue).append("]").toString());
/*     */     }
/* 141 */     return returnValue;
/*     */   }
/*     */ 
/*     */   private Object[] getMethodArgumentValues(NativeWebRequest request, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 150 */     MethodParameter[] parameters = getMethodParameters();
/* 151 */     Object[] args = new Object[parameters.length];
/* 152 */     for (int i = 0; i < parameters.length; i++) {
/* 153 */       MethodParameter parameter = parameters[i];
/* 154 */       parameter.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 155 */       GenericTypeResolver.resolveParameterType(parameter, getBean().getClass());
/* 156 */       args[i] = resolveProvidedArgument(parameter, providedArgs);
/* 157 */       if (args[i] == null)
/*     */       {
/* 160 */         if (this.argumentResolvers.supportsParameter(parameter)) {
/*     */           try {
/* 162 */             args[i] = this.argumentResolvers.resolveArgument(parameter, mavContainer, request, this.dataBinderFactory);
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/* 167 */             if (this.logger.isTraceEnabled()) {
/* 168 */               this.logger.trace(getArgumentResolutionErrorMessage("Error resolving argument", i), ex);
/*     */             }
/* 170 */             throw ex;
/*     */           }
/*     */         }
/* 173 */         else if (args[i] == null) {
/* 174 */           String msg = getArgumentResolutionErrorMessage("No suitable resolver for argument", i);
/* 175 */           throw new IllegalStateException(msg);
/*     */         }
/*     */       }
/*     */     }
/* 178 */     return args;
/*     */   }
/*     */ 
/*     */   private String getArgumentResolutionErrorMessage(String message, int index) {
/* 182 */     MethodParameter param = getMethodParameters()[index];
/* 183 */     message = new StringBuilder().append(message).append(" [").append(index).append("] [type=").append(param.getParameterType().getName()).append("]").toString();
/* 184 */     return getDetailedErrorMessage(message);
/*     */   }
/*     */ 
/*     */   protected String getDetailedErrorMessage(String message)
/*     */   {
/* 192 */     StringBuilder sb = new StringBuilder(message).append("\n");
/* 193 */     sb.append("HandlerMethod details: \n");
/* 194 */     sb.append("Controller [").append(getBeanType().getName()).append("]\n");
/* 195 */     sb.append("Method [").append(getBridgedMethod().toGenericString()).append("]\n");
/* 196 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private Object resolveProvidedArgument(MethodParameter parameter, Object[] providedArgs)
/*     */   {
/* 203 */     if (providedArgs == null) {
/* 204 */       return null;
/*     */     }
/* 206 */     for (Object providedArg : providedArgs) {
/* 207 */       if (parameter.getParameterType().isInstance(providedArg)) {
/* 208 */         return providedArg;
/*     */       }
/*     */     }
/* 211 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(Object[] args)
/*     */     throws Exception
/*     */   {
/* 219 */     ReflectionUtils.makeAccessible(getBridgedMethod());
/*     */     try {
/* 221 */       return getBridgedMethod().invoke(getBean(), args);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 224 */       assertTargetBean(getBridgedMethod(), getBean(), args);
/* 225 */       throw new IllegalStateException(getInvocationErrorMessage(ex.getMessage(), args), ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 229 */       Throwable targetException = ex.getTargetException();
/* 230 */       if ((targetException instanceof RuntimeException)) {
/* 231 */         throw ((RuntimeException)targetException);
/*     */       }
/* 233 */       if ((targetException instanceof Error)) {
/* 234 */         throw ((Error)targetException);
/*     */       }
/* 236 */       if ((targetException instanceof Exception)) {
/* 237 */         throw ((Exception)targetException);
/*     */       }
/*     */ 
/* 240 */       String msg = getInvocationErrorMessage("Failed to invoke controller method", args);
/* 241 */       throw new IllegalStateException(msg, targetException);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void assertTargetBean(Method method, Object targetBean, Object[] args)
/*     */   {
/* 254 */     Class methodDeclaringClass = method.getDeclaringClass();
/* 255 */     Class targetBeanClass = targetBean.getClass();
/* 256 */     if (!methodDeclaringClass.isAssignableFrom(targetBeanClass))
/*     */     {
/* 259 */       String msg = new StringBuilder().append("The mapped controller method class '").append(methodDeclaringClass.getName()).append("' is not an instance of the actual controller bean instance '")
/* 259 */         .append(targetBeanClass
/* 259 */         .getName()).append("'. If the controller requires proxying ").append("(e.g. due to @Transactional), please use class-based proxying.").toString();
/*     */ 
/* 261 */       throw new IllegalStateException(getInvocationErrorMessage(msg, args));
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getInvocationErrorMessage(String message, Object[] resolvedArgs) {
/* 266 */     StringBuilder sb = new StringBuilder(getDetailedErrorMessage(message));
/* 267 */     sb.append("Resolved arguments: \n");
/* 268 */     for (int i = 0; i < resolvedArgs.length; i++) {
/* 269 */       sb.append("[").append(i).append("] ");
/* 270 */       if (resolvedArgs[i] == null) {
/* 271 */         sb.append("[null] \n");
/*     */       }
/*     */       else {
/* 274 */         sb.append("[type=").append(resolvedArgs[i].getClass().getName()).append("] ");
/* 275 */         sb.append("[value=").append(resolvedArgs[i]).append("]\n");
/*     */       }
/*     */     }
/* 278 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.InvocableHandlerMethod
 * JD-Core Version:    0.6.2
 */