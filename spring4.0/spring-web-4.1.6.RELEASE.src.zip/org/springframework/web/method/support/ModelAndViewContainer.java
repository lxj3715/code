/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.support.BindingAwareModelMap;
/*     */ import org.springframework.web.bind.support.SessionStatus;
/*     */ import org.springframework.web.bind.support.SimpleSessionStatus;
/*     */ 
/*     */ public class ModelAndViewContainer
/*     */ {
/*  47 */   private boolean ignoreDefaultModelOnRedirect = false;
/*     */   private Object view;
/*  51 */   private final ModelMap defaultModel = new BindingAwareModelMap();
/*     */   private ModelMap redirectModel;
/*  55 */   private boolean redirectModelScenario = false;
/*     */ 
/*  57 */   private final SessionStatus sessionStatus = new SimpleSessionStatus();
/*     */ 
/*  59 */   private boolean requestHandled = false;
/*     */ 
/*     */   public void setIgnoreDefaultModelOnRedirect(boolean ignoreDefaultModelOnRedirect)
/*     */   {
/*  75 */     this.ignoreDefaultModelOnRedirect = ignoreDefaultModelOnRedirect;
/*     */   }
/*     */ 
/*     */   public void setViewName(String viewName)
/*     */   {
/*  83 */     this.view = viewName;
/*     */   }
/*     */ 
/*     */   public String getViewName()
/*     */   {
/*  91 */     return (this.view instanceof String) ? (String)this.view : null;
/*     */   }
/*     */ 
/*     */   public void setView(Object view)
/*     */   {
/*  99 */     this.view = view;
/*     */   }
/*     */ 
/*     */   public Object getView()
/*     */   {
/* 107 */     return this.view;
/*     */   }
/*     */ 
/*     */   public boolean isViewReference()
/*     */   {
/* 115 */     return this.view instanceof String;
/*     */   }
/*     */ 
/*     */   public ModelMap getModel()
/*     */   {
/* 125 */     if (useDefaultModel()) {
/* 126 */       return this.defaultModel;
/*     */     }
/*     */ 
/* 129 */     return this.redirectModel != null ? this.redirectModel : new ModelMap();
/*     */   }
/*     */ 
/*     */   private boolean useDefaultModel()
/*     */   {
/* 137 */     return (!this.redirectModelScenario) || ((this.redirectModel == null) && (!this.ignoreDefaultModelOnRedirect));
/*     */   }
/*     */ 
/*     */   public ModelMap getDefaultModel()
/*     */   {
/* 150 */     return this.defaultModel;
/*     */   }
/*     */ 
/*     */   public void setRedirectModel(ModelMap redirectModel)
/*     */   {
/* 160 */     this.redirectModel = redirectModel;
/*     */   }
/*     */ 
/*     */   public void setRedirectModelScenario(boolean redirectModelScenario)
/*     */   {
/* 168 */     this.redirectModelScenario = redirectModelScenario;
/*     */   }
/*     */ 
/*     */   public SessionStatus getSessionStatus()
/*     */   {
/* 176 */     return this.sessionStatus;
/*     */   }
/*     */ 
/*     */   public void setRequestHandled(boolean requestHandled)
/*     */   {
/* 187 */     this.requestHandled = requestHandled;
/*     */   }
/*     */ 
/*     */   public boolean isRequestHandled()
/*     */   {
/* 194 */     return this.requestHandled;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer addAttribute(String name, Object value)
/*     */   {
/* 202 */     getModel().addAttribute(name, value);
/* 203 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer addAttribute(Object value)
/*     */   {
/* 211 */     getModel().addAttribute(value);
/* 212 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer addAllAttributes(Map<String, ?> attributes)
/*     */   {
/* 220 */     getModel().addAllAttributes(attributes);
/* 221 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer mergeAttributes(Map<String, ?> attributes)
/*     */   {
/* 230 */     getModel().mergeAttributes(attributes);
/* 231 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndViewContainer removeAttributes(Map<String, ?> attributes)
/*     */   {
/* 238 */     if (attributes != null) {
/* 239 */       for (String key : attributes.keySet()) {
/* 240 */         getModel().remove(key);
/*     */       }
/*     */     }
/* 243 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean containsAttribute(String name)
/*     */   {
/* 251 */     return getModel().containsAttribute(name);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 260 */     StringBuilder sb = new StringBuilder("ModelAndViewContainer: ");
/* 261 */     if (!isRequestHandled()) {
/* 262 */       if (isViewReference()) {
/* 263 */         sb.append("reference to view with name '").append(this.view).append("'");
/*     */       }
/*     */       else {
/* 266 */         sb.append("View is [").append(this.view).append(']');
/*     */       }
/* 268 */       if (useDefaultModel()) {
/* 269 */         sb.append("; default model ");
/*     */       }
/*     */       else {
/* 272 */         sb.append("; redirect model ");
/*     */       }
/* 274 */       sb.append(getModel());
/*     */     }
/*     */     else {
/* 277 */       sb.append("Request handled directly");
/*     */     }
/* 279 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.ModelAndViewContainer
 * JD-Core Version:    0.6.2
 */