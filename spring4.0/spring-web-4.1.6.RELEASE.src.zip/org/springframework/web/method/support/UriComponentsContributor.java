package org.springframework.web.method.support;

import java.util.Map;
import org.springframework.core.MethodParameter;
import org.springframework.core.convert.ConversionService;
import org.springframework.web.util.UriComponentsBuilder;

public abstract interface UriComponentsContributor
{
  public abstract boolean supportsParameter(MethodParameter paramMethodParameter);

  public abstract void contributeMethodArgument(MethodParameter paramMethodParameter, Object paramObject, UriComponentsBuilder paramUriComponentsBuilder, Map<String, Object> paramMap, ConversionService paramConversionService);
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.UriComponentsContributor
 * JD-Core Version:    0.6.2
 */