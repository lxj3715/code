package org.springframework.web.multipart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public abstract interface MultipartFile
{
  public abstract String getName();

  public abstract String getOriginalFilename();

  public abstract String getContentType();

  public abstract boolean isEmpty();

  public abstract long getSize();

  public abstract byte[] getBytes()
    throws IOException;

  public abstract InputStream getInputStream()
    throws IOException;

  public abstract void transferTo(File paramFile)
    throws IOException, IllegalStateException;
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.MultipartFile
 * JD-Core Version:    0.6.2
 */