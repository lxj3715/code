package org.springframework.web.multipart;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

public abstract interface MultipartHttpServletRequest extends HttpServletRequest, MultipartRequest
{
  public abstract HttpMethod getRequestMethod();

  public abstract HttpHeaders getRequestHeaders();

  public abstract HttpHeaders getMultipartHeaders(String paramString);
}

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.MultipartHttpServletRequest
 * JD-Core Version:    0.6.2
 */