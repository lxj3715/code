/*     */ package org.springframework.web.multipart.commons;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileItemFactory;
/*     */ import org.apache.commons.fileupload.FileUpload;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public abstract class CommonsFileUploadSupport
/*     */ {
/*  63 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final DiskFileItemFactory fileItemFactory;
/*     */   private final FileUpload fileUpload;
/*  69 */   private boolean uploadTempDirSpecified = false;
/*     */ 
/*     */   public CommonsFileUploadSupport()
/*     */   {
/*  79 */     this.fileItemFactory = newFileItemFactory();
/*  80 */     this.fileUpload = newFileUpload(getFileItemFactory());
/*     */   }
/*     */ 
/*     */   public DiskFileItemFactory getFileItemFactory()
/*     */   {
/*  90 */     return this.fileItemFactory;
/*     */   }
/*     */ 
/*     */   public FileUpload getFileUpload()
/*     */   {
/*  99 */     return this.fileUpload;
/*     */   }
/*     */ 
/*     */   public void setMaxUploadSize(long maxUploadSize)
/*     */   {
/* 109 */     this.fileUpload.setSizeMax(maxUploadSize);
/*     */   }
/*     */ 
/*     */   public void setMaxInMemorySize(int maxInMemorySize)
/*     */   {
/* 120 */     this.fileItemFactory.setSizeThreshold(maxInMemorySize);
/*     */   }
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 138 */     this.fileUpload.setHeaderEncoding(defaultEncoding);
/*     */   }
/*     */ 
/*     */   protected String getDefaultEncoding() {
/* 142 */     String encoding = getFileUpload().getHeaderEncoding();
/* 143 */     if (encoding == null) {
/* 144 */       encoding = "ISO-8859-1";
/*     */     }
/* 146 */     return encoding;
/*     */   }
/*     */ 
/*     */   public void setUploadTempDir(Resource uploadTempDir)
/*     */     throws IOException
/*     */   {
/* 155 */     if ((!uploadTempDir.exists()) && (!uploadTempDir.getFile().mkdirs())) {
/* 156 */       throw new IllegalArgumentException("Given uploadTempDir [" + uploadTempDir + "] could not be created");
/*     */     }
/* 158 */     this.fileItemFactory.setRepository(uploadTempDir.getFile());
/* 159 */     this.uploadTempDirSpecified = true;
/*     */   }
/*     */ 
/*     */   protected boolean isUploadTempDirSpecified() {
/* 163 */     return this.uploadTempDirSpecified;
/*     */   }
/*     */ 
/*     */   protected DiskFileItemFactory newFileItemFactory()
/*     */   {
/* 174 */     return new DiskFileItemFactory();
/*     */   }
/*     */ 
/*     */   protected abstract FileUpload newFileUpload(FileItemFactory paramFileItemFactory);
/*     */ 
/*     */   protected FileUpload prepareFileUpload(String encoding)
/*     */   {
/* 195 */     FileUpload fileUpload = getFileUpload();
/* 196 */     FileUpload actualFileUpload = fileUpload;
/*     */ 
/* 200 */     if ((encoding != null) && (!encoding.equals(fileUpload.getHeaderEncoding()))) {
/* 201 */       actualFileUpload = newFileUpload(getFileItemFactory());
/* 202 */       actualFileUpload.setSizeMax(fileUpload.getSizeMax());
/* 203 */       actualFileUpload.setHeaderEncoding(encoding);
/*     */     }
/*     */ 
/* 206 */     return actualFileUpload;
/*     */   }
/*     */ 
/*     */   protected MultipartParsingResult parseFileItems(List<FileItem> fileItems, String encoding)
/*     */   {
/* 218 */     MultiValueMap multipartFiles = new LinkedMultiValueMap();
/* 219 */     Map multipartParameters = new HashMap();
/* 220 */     Map multipartParameterContentTypes = new HashMap();
/*     */ 
/* 223 */     for (FileItem fileItem : fileItems) {
/* 224 */       if (fileItem.isFormField())
/*     */       {
/* 226 */         String partEncoding = determineEncoding(fileItem.getContentType(), encoding);
/*     */         String value;
/* 227 */         if (partEncoding != null) {
/*     */           String value;
/*     */           try { value = fileItem.getString(partEncoding); }
/*     */           catch (UnsupportedEncodingException ex)
/*     */           {
/*     */             String value;
/* 232 */             if (this.logger.isWarnEnabled()) {
/* 233 */               this.logger.warn("Could not decode multipart item '" + fileItem.getFieldName() + "' with encoding '" + partEncoding + "': using platform default");
/*     */             }
/*     */ 
/* 236 */             value = fileItem.getString();
/*     */           }
/*     */         }
/*     */         else {
/* 240 */           value = fileItem.getString();
/*     */         }
/* 242 */         String[] curParam = (String[])multipartParameters.get(fileItem.getFieldName());
/* 243 */         if (curParam == null)
/*     */         {
/* 245 */           multipartParameters.put(fileItem.getFieldName(), new String[] { value });
/*     */         }
/*     */         else
/*     */         {
/* 249 */           String[] newParam = StringUtils.addStringToArray(curParam, value);
/* 250 */           multipartParameters.put(fileItem.getFieldName(), newParam);
/*     */         }
/* 252 */         multipartParameterContentTypes.put(fileItem.getFieldName(), fileItem.getContentType());
/*     */       }
/*     */       else
/*     */       {
/* 256 */         CommonsMultipartFile file = new CommonsMultipartFile(fileItem);
/* 257 */         multipartFiles.add(file.getName(), file);
/* 258 */         if (this.logger.isDebugEnabled()) {
/* 259 */           this.logger.debug("Found multipart file [" + file.getName() + "] of size " + file.getSize() + " bytes with original filename [" + file
/* 260 */             .getOriginalFilename() + "], stored " + file
/* 261 */             .getStorageDescription());
/*     */         }
/*     */       }
/*     */     }
/* 265 */     return new MultipartParsingResult(multipartFiles, multipartParameters, multipartParameterContentTypes);
/*     */   }
/*     */ 
/*     */   protected void cleanupFileItems(MultiValueMap<String, MultipartFile> multipartFiles)
/*     */   {
/* 276 */     for (List files : multipartFiles.values())
/* 277 */       for (MultipartFile file : files)
/* 278 */         if ((file instanceof CommonsMultipartFile)) {
/* 279 */           CommonsMultipartFile cmf = (CommonsMultipartFile)file;
/* 280 */           cmf.getFileItem().delete();
/* 281 */           if (this.logger.isDebugEnabled())
/* 282 */             this.logger.debug("Cleaning up multipart file [" + cmf.getName() + "] with original filename [" + cmf
/* 283 */               .getOriginalFilename() + "], stored " + cmf.getStorageDescription());
/*     */         }
/*     */   }
/*     */ 
/*     */   private String determineEncoding(String contentTypeHeader, String defaultEncoding)
/*     */   {
/* 291 */     if (!StringUtils.hasText(contentTypeHeader)) {
/* 292 */       return defaultEncoding;
/*     */     }
/* 294 */     MediaType contentType = MediaType.parseMediaType(contentTypeHeader);
/* 295 */     Charset charset = contentType.getCharSet();
/* 296 */     return charset != null ? charset.name() : defaultEncoding;
/*     */   }
/*     */ 
/*     */   protected static class MultipartParsingResult
/*     */   {
/*     */     private final MultiValueMap<String, MultipartFile> multipartFiles;
/*     */     private final Map<String, String[]> multipartParameters;
/*     */     private final Map<String, String> multipartParameterContentTypes;
/*     */ 
/*     */     public MultipartParsingResult(MultiValueMap<String, MultipartFile> mpFiles, Map<String, String[]> mpParams, Map<String, String> mpParamContentTypes)
/*     */     {
/* 314 */       this.multipartFiles = mpFiles;
/* 315 */       this.multipartParameters = mpParams;
/* 316 */       this.multipartParameterContentTypes = mpParamContentTypes;
/*     */     }
/*     */ 
/*     */     public MultiValueMap<String, MultipartFile> getMultipartFiles() {
/* 320 */       return this.multipartFiles;
/*     */     }
/*     */ 
/*     */     public Map<String, String[]> getMultipartParameters() {
/* 324 */       return this.multipartParameters;
/*     */     }
/*     */ 
/*     */     public Map<String, String> getMultipartParameterContentTypes() {
/* 328 */       return this.multipartParameterContentTypes;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.commons.CommonsFileUploadSupport
 * JD-Core Version:    0.6.2
 */