/*     */ package org.springframework.web.multipart.commons;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItem;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class CommonsMultipartFile
/*     */   implements MultipartFile, Serializable
/*     */ {
/*  44 */   protected static final Log logger = LogFactory.getLog(CommonsMultipartFile.class);
/*     */   private final FileItem fileItem;
/*     */   private final long size;
/*     */ 
/*     */   public CommonsMultipartFile(FileItem fileItem)
/*     */   {
/*  56 */     this.fileItem = fileItem;
/*  57 */     this.size = this.fileItem.getSize();
/*     */   }
/*     */ 
/*     */   public final FileItem getFileItem()
/*     */   {
/*  65 */     return this.fileItem;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  71 */     return this.fileItem.getFieldName();
/*     */   }
/*     */ 
/*     */   public String getOriginalFilename()
/*     */   {
/*  76 */     String filename = this.fileItem.getName();
/*  77 */     if (filename == null)
/*     */     {
/*  79 */       return "";
/*     */     }
/*     */ 
/*  82 */     int pos = filename.lastIndexOf("/");
/*  83 */     if (pos == -1)
/*     */     {
/*  85 */       pos = filename.lastIndexOf("\\");
/*     */     }
/*  87 */     if (pos != -1)
/*     */     {
/*  89 */       return filename.substring(pos + 1);
/*     */     }
/*     */ 
/*  93 */     return filename;
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  99 */     return this.fileItem.getContentType();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 104 */     return this.size == 0L;
/*     */   }
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 109 */     return this.size;
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 114 */     if (!isAvailable()) {
/* 115 */       throw new IllegalStateException("File has been moved - cannot be read again");
/*     */     }
/* 117 */     byte[] bytes = this.fileItem.get();
/* 118 */     return bytes != null ? bytes : new byte[0];
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream() throws IOException
/*     */   {
/* 123 */     if (!isAvailable()) {
/* 124 */       throw new IllegalStateException("File has been moved - cannot be read again");
/*     */     }
/* 126 */     InputStream inputStream = this.fileItem.getInputStream();
/* 127 */     return inputStream != null ? inputStream : new ByteArrayInputStream(new byte[0]);
/*     */   }
/*     */ 
/*     */   public void transferTo(File dest) throws IOException, IllegalStateException
/*     */   {
/* 132 */     if (!isAvailable()) {
/* 133 */       throw new IllegalStateException("File has already been moved - cannot be transferred again");
/*     */     }
/*     */ 
/* 136 */     if ((dest.exists()) && (!dest.delete()))
/*     */     {
/* 138 */       throw new IOException("Destination file [" + dest
/* 138 */         .getAbsolutePath() + "] already exists and could not be deleted");
/*     */     }
/*     */     try
/*     */     {
/* 142 */       this.fileItem.write(dest);
/* 143 */       if (logger.isDebugEnabled()) {
/* 144 */         String action = "transferred";
/* 145 */         if (!this.fileItem.isInMemory()) {
/* 146 */           action = isAvailable() ? "copied" : "moved";
/*     */         }
/* 148 */         logger.debug("Multipart file '" + getName() + "' with original filename [" + 
/* 149 */           getOriginalFilename() + "], stored " + getStorageDescription() + ": " + action + " to [" + dest
/* 150 */           .getAbsolutePath() + "]");
/*     */       }
/*     */     }
/*     */     catch (FileUploadException ex) {
/* 154 */       throw new IllegalStateException(ex.getMessage());
/*     */     }
/*     */     catch (IOException ex) {
/* 157 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/* 160 */       logger.error("Could not transfer to file", ex);
/* 161 */       throw new IOException("Could not transfer to file: " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isAvailable()
/*     */   {
/* 171 */     if (this.fileItem.isInMemory()) {
/* 172 */       return true;
/*     */     }
/*     */ 
/* 175 */     if ((this.fileItem instanceof DiskFileItem)) {
/* 176 */       return ((DiskFileItem)this.fileItem).getStoreLocation().exists();
/*     */     }
/*     */ 
/* 179 */     return this.fileItem.getSize() == this.size;
/*     */   }
/*     */ 
/*     */   public String getStorageDescription()
/*     */   {
/* 188 */     if (this.fileItem.isInMemory()) {
/* 189 */       return "in memory";
/*     */     }
/* 191 */     if ((this.fileItem instanceof DiskFileItem)) {
/* 192 */       return "at [" + ((DiskFileItem)this.fileItem).getStoreLocation().getAbsolutePath() + "]";
/*     */     }
/*     */ 
/* 195 */     return "on disk";
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.commons.CommonsMultipartFile
 * JD-Core Version:    0.6.2
 */