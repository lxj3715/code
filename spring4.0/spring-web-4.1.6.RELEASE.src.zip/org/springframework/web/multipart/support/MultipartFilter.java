/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.multipart.MultipartResolver;
/*     */ 
/*     */ public class MultipartFilter extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_MULTIPART_RESOLVER_BEAN_NAME = "filterMultipartResolver";
/*  66 */   private final MultipartResolver defaultMultipartResolver = new StandardServletMultipartResolver();
/*     */ 
/*  68 */   private String multipartResolverBeanName = "filterMultipartResolver";
/*     */ 
/*     */   public void setMultipartResolverBeanName(String multipartResolverBeanName)
/*     */   {
/*  76 */     this.multipartResolverBeanName = multipartResolverBeanName;
/*     */   }
/*     */ 
/*     */   protected String getMultipartResolverBeanName()
/*     */   {
/*  84 */     return this.multipartResolverBeanName;
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 100 */     MultipartResolver multipartResolver = lookupMultipartResolver(request);
/*     */ 
/* 102 */     HttpServletRequest processedRequest = request;
/* 103 */     if (multipartResolver.isMultipart(processedRequest)) {
/* 104 */       if (this.logger.isDebugEnabled()) {
/* 105 */         this.logger.debug("Resolving multipart request [" + processedRequest.getRequestURI() + "] with MultipartFilter");
/*     */       }
/*     */ 
/* 108 */       processedRequest = multipartResolver.resolveMultipart(processedRequest);
/*     */     }
/* 112 */     else if (this.logger.isDebugEnabled()) {
/* 113 */       this.logger.debug("Request [" + processedRequest.getRequestURI() + "] is not a multipart request");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 118 */       filterChain.doFilter(processedRequest, response);
/*     */     }
/*     */     finally {
/* 121 */       if ((processedRequest instanceof MultipartHttpServletRequest))
/* 122 */         multipartResolver.cleanupMultipart((MultipartHttpServletRequest)processedRequest);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected MultipartResolver lookupMultipartResolver(HttpServletRequest request)
/*     */   {
/* 136 */     return lookupMultipartResolver();
/*     */   }
/*     */ 
/*     */   protected MultipartResolver lookupMultipartResolver()
/*     */   {
/* 148 */     WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
/* 149 */     String beanName = getMultipartResolverBeanName();
/* 150 */     if ((wac != null) && (wac.containsBean(beanName))) {
/* 151 */       if (this.logger.isDebugEnabled()) {
/* 152 */         this.logger.debug("Using MultipartResolver '" + beanName + "' for MultipartFilter");
/*     */       }
/* 154 */       return (MultipartResolver)wac.getBean(beanName, MultipartResolver.class);
/*     */     }
/*     */ 
/* 157 */     return this.defaultMultipartResolver;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.MultipartFilter
 * JD-Core Version:    0.6.2
 */