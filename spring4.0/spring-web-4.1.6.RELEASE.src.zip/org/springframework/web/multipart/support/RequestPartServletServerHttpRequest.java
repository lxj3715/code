/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ 
/*     */ public class RequestPartServletServerHttpRequest extends ServletServerHttpRequest
/*     */ {
/*     */   private final MultipartHttpServletRequest multipartRequest;
/*     */   private final String partName;
/*     */   private final HttpHeaders headers;
/*     */ 
/*     */   public RequestPartServletServerHttpRequest(HttpServletRequest request, String partName)
/*     */     throws MissingServletRequestPartException
/*     */   {
/*  62 */     super(request);
/*     */ 
/*  64 */     this.multipartRequest = asMultipartRequest(request);
/*  65 */     this.partName = partName;
/*     */ 
/*  67 */     this.headers = this.multipartRequest.getMultipartHeaders(this.partName);
/*  68 */     if (this.headers == null) {
/*  69 */       if ((request instanceof MultipartHttpServletRequest)) {
/*  70 */         throw new MissingServletRequestPartException(partName);
/*     */       }
/*     */ 
/*  73 */       throw new IllegalArgumentException("Failed to obtain request part: " + partName + ". " + "The part is missing or multipart processing is not configured. " + "Check for a MultipartResolver bean or if Servlet 3.0 multipart processing is enabled.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static MultipartHttpServletRequest asMultipartRequest(HttpServletRequest request)
/*     */   {
/*  82 */     if ((request instanceof MultipartHttpServletRequest)) {
/*  83 */       return (MultipartHttpServletRequest)request;
/*     */     }
/*  85 */     if (ClassUtils.hasMethod(HttpServletRequest.class, "getParts", new Class[0]))
/*     */     {
/*  87 */       return new StandardMultipartHttpServletRequest(request);
/*     */     }
/*  89 */     throw new IllegalArgumentException("Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/*     */   }
/*     */ 
/*     */   public HttpHeaders getHeaders()
/*     */   {
/*  94 */     return this.headers;
/*     */   }
/*     */ 
/*     */   public InputStream getBody() throws IOException
/*     */   {
/*  99 */     if ((this.multipartRequest instanceof StandardMultipartHttpServletRequest)) {
/*     */       try {
/* 101 */         return this.multipartRequest.getPart(this.partName).getInputStream();
/*     */       }
/*     */       catch (Exception ex) {
/* 104 */         throw new MultipartException("Could not parse multipart servlet request", ex);
/*     */       }
/*     */     }
/*     */ 
/* 108 */     MultipartFile file = this.multipartRequest.getFile(this.partName);
/* 109 */     if (file != null) {
/* 110 */       return file.getInputStream();
/*     */     }
/*     */ 
/* 113 */     String paramValue = this.multipartRequest.getParameter(this.partName);
/* 114 */     return new ByteArrayInputStream(paramValue.getBytes("UTF-8"));
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.RequestPartServletServerHttpRequest
 * JD-Core Version:    0.6.2
 */