/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class StandardMultipartHttpServletRequest extends AbstractMultipartHttpServletRequest
/*     */ {
/*     */   private static final String CONTENT_DISPOSITION = "content-disposition";
/*     */   private static final String FILENAME_KEY = "filename=";
/*     */   private Set<String> multipartParameterNames;
/*     */ 
/*     */   public StandardMultipartHttpServletRequest(HttpServletRequest request)
/*     */     throws MultipartException
/*     */   {
/*  65 */     this(request, false);
/*     */   }
/*     */ 
/*     */   public StandardMultipartHttpServletRequest(HttpServletRequest request, boolean lazyParsing)
/*     */     throws MultipartException
/*     */   {
/*  76 */     super(request);
/*  77 */     if (!lazyParsing)
/*  78 */       parseRequest(request);
/*     */   }
/*     */ 
/*     */   private void parseRequest(HttpServletRequest request)
/*     */   {
/*     */     try
/*     */     {
/*  85 */       Collection parts = request.getParts();
/*  86 */       this.multipartParameterNames = new LinkedHashSet(parts.size());
/*  87 */       MultiValueMap files = new LinkedMultiValueMap(parts.size());
/*  88 */       for (Part part : parts) {
/*  89 */         String filename = extractFilename(part.getHeader("content-disposition"));
/*  90 */         if (filename != null) {
/*  91 */           files.add(part.getName(), new StandardMultipartFile(part, filename));
/*     */         }
/*     */         else {
/*  94 */           this.multipartParameterNames.add(part.getName());
/*     */         }
/*     */       }
/*  97 */       setMultipartFiles(files);
/*     */     }
/*     */     catch (Exception ex) {
/* 100 */       throw new MultipartException("Could not parse multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String extractFilename(String contentDisposition) {
/* 105 */     if (contentDisposition == null) {
/* 106 */       return null;
/*     */     }
/*     */ 
/* 109 */     int startIndex = contentDisposition.indexOf("filename=");
/* 110 */     if (startIndex == -1) {
/* 111 */       return null;
/*     */     }
/* 113 */     String filename = contentDisposition.substring(startIndex + "filename=".length());
/* 114 */     if (filename.startsWith("\"")) {
/* 115 */       int endIndex = filename.indexOf("\"", 1);
/* 116 */       if (endIndex != -1)
/* 117 */         return filename.substring(1, endIndex);
/*     */     }
/*     */     else
/*     */     {
/* 121 */       int endIndex = filename.indexOf(";");
/* 122 */       if (endIndex != -1) {
/* 123 */         return filename.substring(0, endIndex);
/*     */       }
/*     */     }
/* 126 */     return filename;
/*     */   }
/*     */ 
/*     */   protected void initializeMultipart()
/*     */   {
/* 132 */     parseRequest(getRequest());
/*     */   }
/*     */ 
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/* 137 */     if (this.multipartParameterNames == null) {
/* 138 */       initializeMultipart();
/*     */     }
/* 140 */     if (this.multipartParameterNames.isEmpty()) {
/* 141 */       return super.getParameterNames();
/*     */     }
/*     */ 
/* 146 */     Set paramNames = new LinkedHashSet();
/* 147 */     Enumeration paramEnum = super.getParameterNames();
/* 148 */     while (paramEnum.hasMoreElements()) {
/* 149 */       paramNames.add(paramEnum.nextElement());
/*     */     }
/* 151 */     paramNames.addAll(this.multipartParameterNames);
/* 152 */     return Collections.enumeration(paramNames);
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 157 */     if (this.multipartParameterNames == null) {
/* 158 */       initializeMultipart();
/*     */     }
/* 160 */     if (this.multipartParameterNames.isEmpty()) {
/* 161 */       return super.getParameterMap();
/*     */     }
/*     */ 
/* 166 */     Map paramMap = new LinkedHashMap();
/* 167 */     paramMap.putAll(super.getParameterMap());
/* 168 */     for (String paramName : this.multipartParameterNames) {
/* 169 */       if (!paramMap.containsKey(paramName)) {
/* 170 */         paramMap.put(paramName, getParameterValues(paramName));
/*     */       }
/*     */     }
/* 173 */     return paramMap;
/*     */   }
/*     */ 
/*     */   public String getMultipartContentType(String paramOrFileName)
/*     */   {
/*     */     try {
/* 179 */       Part part = getPart(paramOrFileName);
/* 180 */       return part != null ? part.getContentType() : null;
/*     */     }
/*     */     catch (Exception ex) {
/* 183 */       throw new MultipartException("Could not access multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders getMultipartHeaders(String paramOrFileName)
/*     */   {
/*     */     try {
/* 190 */       Part part = getPart(paramOrFileName);
/* 191 */       if (part != null) {
/* 192 */         HttpHeaders headers = new HttpHeaders();
/* 193 */         for (String headerName : part.getHeaderNames()) {
/* 194 */           headers.put(headerName, new ArrayList(part.getHeaders(headerName)));
/*     */         }
/* 196 */         return headers;
/*     */       }
/*     */ 
/* 199 */       return null;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 203 */       throw new MultipartException("Could not access multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class StandardMultipartFile
/*     */     implements MultipartFile, Serializable
/*     */   {
/*     */     private final Part part;
/*     */     private final String filename;
/*     */ 
/*     */     public StandardMultipartFile(Part part, String filename)
/*     */     {
/* 219 */       this.part = part;
/* 220 */       this.filename = filename;
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/* 225 */       return this.part.getName();
/*     */     }
/*     */ 
/*     */     public String getOriginalFilename()
/*     */     {
/* 230 */       return this.filename;
/*     */     }
/*     */ 
/*     */     public String getContentType()
/*     */     {
/* 235 */       return this.part.getContentType();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty()
/*     */     {
/* 240 */       return this.part.getSize() == 0L;
/*     */     }
/*     */ 
/*     */     public long getSize()
/*     */     {
/* 245 */       return this.part.getSize();
/*     */     }
/*     */ 
/*     */     public byte[] getBytes() throws IOException
/*     */     {
/* 250 */       return FileCopyUtils.copyToByteArray(this.part.getInputStream());
/*     */     }
/*     */ 
/*     */     public InputStream getInputStream() throws IOException
/*     */     {
/* 255 */       return this.part.getInputStream();
/*     */     }
/*     */ 
/*     */     public void transferTo(File dest) throws IOException, IllegalStateException
/*     */     {
/* 260 */       this.part.write(dest.getPath());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.StandardMultipartHttpServletRequest
 * JD-Core Version:    0.6.2
 */