/*    */ package org.springframework.web.multipart.support;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.Part;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.multipart.MultipartException;
/*    */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*    */ import org.springframework.web.multipart.MultipartResolver;
/*    */ 
/*    */ public class StandardServletMultipartResolver
/*    */   implements MultipartResolver
/*    */ {
/* 48 */   private boolean resolveLazily = false;
/*    */ 
/*    */   public void setResolveLazily(boolean resolveLazily)
/*    */   {
/* 60 */     this.resolveLazily = resolveLazily;
/*    */   }
/*    */ 
/*    */   public boolean isMultipart(HttpServletRequest request)
/*    */   {
/* 67 */     if (!"post".equals(request.getMethod().toLowerCase())) {
/* 68 */       return false;
/*    */     }
/* 70 */     String contentType = request.getContentType();
/* 71 */     return (contentType != null) && (contentType.toLowerCase().startsWith("multipart/"));
/*    */   }
/*    */ 
/*    */   public MultipartHttpServletRequest resolveMultipart(HttpServletRequest request) throws MultipartException
/*    */   {
/* 76 */     return new StandardMultipartHttpServletRequest(request, this.resolveLazily);
/*    */   }
/*    */ 
/*    */   public void cleanupMultipart(MultipartHttpServletRequest request)
/*    */   {
/*    */     try
/*    */     {
/* 84 */       for (Part part : request.getParts()) {
/* 85 */         if (request.getFile(part.getName()) != null)
/* 86 */           part.delete();
/*    */       }
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 91 */       LogFactory.getLog(getClass()).warn("Failed to perform cleanup of multipart items", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.StandardServletMultipartResolver
 * JD-Core Version:    0.6.2
 */