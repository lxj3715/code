/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ 
/*     */ public class ContentCachingRequestWrapper extends HttpServletRequestWrapper
/*     */ {
/*     */   private static final String FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private final ByteArrayOutputStream cachedContent;
/*     */   private ServletInputStream inputStream;
/*     */   private BufferedReader reader;
/*     */ 
/*     */   public ContentCachingRequestWrapper(HttpServletRequest request)
/*     */   {
/*  63 */     super(request);
/*  64 */     int contentLength = request.getContentLength();
/*  65 */     this.cachedContent = new ByteArrayOutputStream(contentLength >= 0 ? contentLength : 1024);
/*     */   }
/*     */ 
/*     */   public ServletInputStream getInputStream()
/*     */     throws IOException
/*     */   {
/*  71 */     if (this.inputStream == null) {
/*  72 */       this.inputStream = new ContentCachingInputStream(getRequest().getInputStream());
/*     */     }
/*  74 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */   public String getCharacterEncoding()
/*     */   {
/*  79 */     String enc = super.getCharacterEncoding();
/*  80 */     return enc != null ? enc : "ISO-8859-1";
/*     */   }
/*     */ 
/*     */   public BufferedReader getReader() throws IOException
/*     */   {
/*  85 */     if (this.reader == null) {
/*  86 */       this.reader = new BufferedReader(new InputStreamReader(getInputStream(), getCharacterEncoding()));
/*     */     }
/*  88 */     return this.reader;
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/*  93 */     if ((this.cachedContent.size() == 0) && (isFormPost())) {
/*  94 */       writeRequestParametersToCachedContent();
/*     */     }
/*  96 */     return super.getParameter(name);
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 101 */     if ((this.cachedContent.size() == 0) && (isFormPost())) {
/* 102 */       writeRequestParametersToCachedContent();
/*     */     }
/* 104 */     return super.getParameterMap();
/*     */   }
/*     */ 
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/* 109 */     if ((this.cachedContent.size() == 0) && (isFormPost())) {
/* 110 */       writeRequestParametersToCachedContent();
/*     */     }
/* 112 */     return super.getParameterNames();
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String name)
/*     */   {
/* 117 */     if ((this.cachedContent.size() == 0) && (isFormPost())) {
/* 118 */       writeRequestParametersToCachedContent();
/*     */     }
/* 120 */     return super.getParameterValues(name);
/*     */   }
/*     */ 
/*     */   private boolean isFormPost()
/*     */   {
/* 125 */     String contentType = getContentType();
/*     */ 
/* 127 */     return (contentType != null) && (contentType.contains("application/x-www-form-urlencoded")) && 
/* 127 */       ("POST"
/* 127 */       .equalsIgnoreCase(getMethod()));
/*     */   }
/*     */ 
/*     */   private void writeRequestParametersToCachedContent() {
/*     */     try {
/* 132 */       if (this.cachedContent.size() == 0) {
/* 133 */         requestEncoding = getCharacterEncoding();
/* 134 */         form = super.getParameterMap();
/* 135 */         for (nameIterator = form.keySet().iterator(); nameIterator.hasNext(); ) {
/* 136 */           String name = (String)nameIterator.next();
/* 137 */           List values = Arrays.asList((Object[])form.get(name));
/* 138 */           for (Iterator valueIterator = values.iterator(); valueIterator.hasNext(); ) {
/* 139 */             String value = (String)valueIterator.next();
/* 140 */             this.cachedContent.write(URLEncoder.encode(name, requestEncoding).getBytes());
/* 141 */             if (value != null) {
/* 142 */               this.cachedContent.write(61);
/* 143 */               this.cachedContent.write(URLEncoder.encode(value, requestEncoding).getBytes());
/* 144 */               if (valueIterator.hasNext()) {
/* 145 */                 this.cachedContent.write(38);
/*     */               }
/*     */             }
/*     */           }
/* 149 */           if (nameIterator.hasNext())
/* 150 */             this.cachedContent.write(38);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */       String requestEncoding;
/*     */       Map form;
/*     */       Iterator nameIterator;
/* 156 */       throw new IllegalStateException("Failed to write request parameters to cached content", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] getContentAsByteArray()
/*     */   {
/* 164 */     return this.cachedContent.toByteArray();
/*     */   }
/*     */ 
/*     */   private class ContentCachingInputStream extends ServletInputStream
/*     */   {
/*     */     private final ServletInputStream is;
/*     */ 
/*     */     public ContentCachingInputStream(ServletInputStream is)
/*     */     {
/* 173 */       this.is = is;
/*     */     }
/*     */ 
/*     */     public int read() throws IOException
/*     */     {
/* 178 */       int ch = this.is.read();
/* 179 */       if (ch != -1) {
/* 180 */         ContentCachingRequestWrapper.this.cachedContent.write(ch);
/*     */       }
/* 182 */       return ch;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.ContentCachingRequestWrapper
 * JD-Core Version:    0.6.2
 */