/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.springframework.util.ResizableByteArrayOutputStream;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ public class ContentCachingResponseWrapper extends HttpServletResponseWrapper
/*     */ {
/*  42 */   private final ResizableByteArrayOutputStream content = new ResizableByteArrayOutputStream(1024);
/*     */ 
/*  44 */   private final ServletOutputStream outputStream = new ResponseServletOutputStream(null);
/*     */   private PrintWriter writer;
/*  48 */   private int statusCode = 200;
/*     */ 
/*     */   public ContentCachingResponseWrapper(HttpServletResponse response)
/*     */   {
/*  56 */     super(response);
/*     */   }
/*     */ 
/*     */   public void setStatus(int sc)
/*     */   {
/*  62 */     super.setStatus(sc);
/*  63 */     this.statusCode = sc;
/*     */   }
/*     */ 
/*     */   public void setStatus(int sc, String sm)
/*     */   {
/*  69 */     super.setStatus(sc, sm);
/*  70 */     this.statusCode = sc;
/*     */   }
/*     */ 
/*     */   public void sendError(int sc) throws IOException
/*     */   {
/*  75 */     copyBodyToResponse();
/*  76 */     super.sendError(sc);
/*  77 */     this.statusCode = sc;
/*     */   }
/*     */ 
/*     */   public void sendError(int sc, String msg) throws IOException
/*     */   {
/*  82 */     copyBodyToResponse();
/*  83 */     super.sendError(sc, msg);
/*  84 */     this.statusCode = sc;
/*     */   }
/*     */ 
/*     */   public void sendRedirect(String location) throws IOException
/*     */   {
/*  89 */     copyBodyToResponse();
/*  90 */     super.sendRedirect(location);
/*     */   }
/*     */ 
/*     */   public ServletOutputStream getOutputStream()
/*     */   {
/*  95 */     return this.outputStream;
/*     */   }
/*     */ 
/*     */   public PrintWriter getWriter() throws IOException
/*     */   {
/* 100 */     if (this.writer == null) {
/* 101 */       String characterEncoding = getCharacterEncoding();
/* 102 */       this.writer = (characterEncoding != null ? new ResponsePrintWriter(characterEncoding) : new ResponsePrintWriter("ISO-8859-1"));
/*     */     }
/*     */ 
/* 105 */     return this.writer;
/*     */   }
/*     */ 
/*     */   public void setContentLength(int len)
/*     */   {
/* 110 */     if (len > this.content.capacity())
/* 111 */       this.content.resize(len);
/*     */   }
/*     */ 
/*     */   public void setContentLengthLong(long len)
/*     */   {
/* 117 */     if (len > 2147483647L) {
/* 118 */       throw new IllegalArgumentException("Content-Length exceeds ShallowEtagHeaderFilter's maximum (2147483647): " + len);
/*     */     }
/*     */ 
/* 121 */     if (len > this.content.capacity())
/* 122 */       this.content.resize((int)len);
/*     */   }
/*     */ 
/*     */   public void setBufferSize(int size)
/*     */   {
/* 128 */     if (size > this.content.capacity())
/* 129 */       this.content.resize(size);
/*     */   }
/*     */ 
/*     */   public void resetBuffer()
/*     */   {
/* 135 */     this.content.reset();
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/* 140 */     super.reset();
/* 141 */     this.content.reset();
/*     */   }
/*     */ 
/*     */   public int getStatusCode()
/*     */   {
/* 148 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   public byte[] getContentAsByteArray()
/*     */   {
/* 155 */     return this.content.toByteArray();
/*     */   }
/*     */ 
/*     */   private void copyBodyToResponse() throws IOException {
/* 159 */     if (this.content.size() > 0) {
/* 160 */       getResponse().setContentLength(this.content.size());
/* 161 */       StreamUtils.copy(this.content.toByteArray(), getResponse().getOutputStream());
/* 162 */       this.content.reset();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResponsePrintWriter extends PrintWriter
/*     */   {
/*     */     public ResponsePrintWriter(String characterEncoding)
/*     */       throws UnsupportedEncodingException
/*     */     {
/* 184 */       super();
/*     */     }
/*     */ 
/*     */     public void write(char[] buf, int off, int len)
/*     */     {
/* 189 */       super.write(buf, off, len);
/* 190 */       super.flush();
/*     */     }
/*     */ 
/*     */     public void write(String s, int off, int len)
/*     */     {
/* 195 */       super.write(s, off, len);
/* 196 */       super.flush();
/*     */     }
/*     */ 
/*     */     public void write(int c)
/*     */     {
/* 201 */       super.write(c);
/* 202 */       super.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResponseServletOutputStream extends ServletOutputStream
/*     */   {
/*     */     private ResponseServletOutputStream()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void write(int b)
/*     */       throws IOException
/*     */     {
/* 171 */       ContentCachingResponseWrapper.this.content.write(b);
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 176 */       ContentCachingResponseWrapper.this.content.write(b, off, len);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.ContentCachingResponseWrapper
 * JD-Core Version:    0.6.2
 */