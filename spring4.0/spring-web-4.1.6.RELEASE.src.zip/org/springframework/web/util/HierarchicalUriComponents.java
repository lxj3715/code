/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ final class HierarchicalUriComponents extends UriComponents
/*     */ {
/*     */   private static final char PATH_DELIMITER = '/';
/*     */   private final String userInfo;
/*     */   private final String host;
/*     */   private final String port;
/*     */   private final PathComponent path;
/*     */   private final MultiValueMap<String, String> queryParams;
/*     */   private final boolean encoded;
/* 798 */   static final PathComponent NULL_PATH_COMPONENT = new PathComponent()
/*     */   {
/*     */     public String getPath() {
/* 801 */       return null;
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments() {
/* 805 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException {
/* 809 */       return this;
/*     */     }
/*     */ 
/*     */     public void verify() {
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables) {
/* 816 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 820 */       return this == obj;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 824 */       return 42;
/*     */     }
/* 798 */   };
/*     */ 
/*     */   HierarchicalUriComponents(String scheme, String userInfo, String host, String port, PathComponent path, MultiValueMap<String, String> queryParams, String fragment, boolean encoded, boolean verify)
/*     */   {
/*  79 */     super(scheme, fragment);
/*  80 */     this.userInfo = userInfo;
/*  81 */     this.host = host;
/*  82 */     this.port = port;
/*  83 */     this.path = (path != null ? path : NULL_PATH_COMPONENT);
/*  84 */     this.queryParams = CollectionUtils.unmodifiableMultiValueMap(queryParams != null ? queryParams : new LinkedMultiValueMap(0));
/*     */ 
/*  86 */     this.encoded = encoded;
/*  87 */     if (verify)
/*  88 */       verify();
/*     */   }
/*     */ 
/*     */   public String getSchemeSpecificPart()
/*     */   {
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUserInfo()
/*     */   {
/* 102 */     return this.userInfo;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 107 */     return this.host;
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 112 */     if (this.port == null) {
/* 113 */       return -1;
/*     */     }
/* 115 */     if (this.port.contains("{")) {
/* 116 */       throw new IllegalStateException(new StringBuilder().append("The port contains a URI variable but has not been expanded yet: ").append(this.port).toString());
/*     */     }
/*     */ 
/* 119 */     return Integer.parseInt(this.port);
/*     */   }
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 124 */     return this.path.getPath();
/*     */   }
/*     */ 
/*     */   public List<String> getPathSegments()
/*     */   {
/* 129 */     return this.path.getPathSegments();
/*     */   }
/*     */ 
/*     */   public String getQuery()
/*     */   {
/* 134 */     if (!this.queryParams.isEmpty()) {
/* 135 */       StringBuilder queryBuilder = new StringBuilder();
/* 136 */       for (Map.Entry entry : this.queryParams.entrySet()) {
/* 137 */         name = (String)entry.getKey();
/* 138 */         List values = (List)entry.getValue();
/* 139 */         if (CollectionUtils.isEmpty(values)) {
/* 140 */           if (queryBuilder.length() != 0) {
/* 141 */             queryBuilder.append('&');
/*     */           }
/* 143 */           queryBuilder.append(name);
/*     */         }
/*     */         else {
/* 146 */           for (localIterator2 = values.iterator(); localIterator2.hasNext(); ) { Object value = localIterator2.next();
/* 147 */             if (queryBuilder.length() != 0) {
/* 148 */               queryBuilder.append('&');
/*     */             }
/* 150 */             queryBuilder.append(name);
/*     */ 
/* 152 */             if (value != null) {
/* 153 */               queryBuilder.append('=');
/* 154 */               queryBuilder.append(value.toString());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       String name;
/*     */       Iterator localIterator2;
/* 159 */       return queryBuilder.toString();
/*     */     }
/*     */ 
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, String> getQueryParams()
/*     */   {
/* 171 */     return this.queryParams;
/*     */   }
/*     */ 
/*     */   public HierarchicalUriComponents encode(String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 186 */     Assert.hasLength(encoding, "Encoding must not be empty");
/* 187 */     if (this.encoded) {
/* 188 */       return this;
/*     */     }
/* 190 */     String encodedScheme = encodeUriComponent(getScheme(), encoding, Type.SCHEME);
/* 191 */     String encodedUserInfo = encodeUriComponent(this.userInfo, encoding, Type.USER_INFO);
/* 192 */     String encodedHost = encodeUriComponent(this.host, encoding, getHostType());
/*     */ 
/* 194 */     PathComponent encodedPath = this.path.encode(encoding);
/*     */ 
/* 196 */     MultiValueMap encodedQueryParams = new LinkedMultiValueMap(this.queryParams
/* 196 */       .size());
/* 197 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 198 */       String encodedName = encodeUriComponent((String)entry.getKey(), encoding, Type.QUERY_PARAM);
/* 199 */       List encodedValues = new ArrayList(((List)entry.getValue()).size());
/* 200 */       for (String value : (List)entry.getValue()) {
/* 201 */         String encodedValue = encodeUriComponent(value, encoding, Type.QUERY_PARAM);
/* 202 */         encodedValues.add(encodedValue);
/*     */       }
/* 204 */       encodedQueryParams.put(encodedName, encodedValues);
/*     */     }
/* 206 */     String encodedFragment = encodeUriComponent(getFragment(), encoding, Type.FRAGMENT);
/* 207 */     return new HierarchicalUriComponents(encodedScheme, encodedUserInfo, encodedHost, this.port, encodedPath, encodedQueryParams, encodedFragment, true, false);
/*     */   }
/*     */ 
/*     */   static String encodeUriComponent(String source, String encoding, Type type)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 221 */     if (source == null) {
/* 222 */       return null;
/*     */     }
/* 224 */     Assert.hasLength(encoding, "Encoding must not be empty");
/* 225 */     byte[] bytes = encodeBytes(source.getBytes(encoding), type);
/* 226 */     return new String(bytes, "US-ASCII");
/*     */   }
/*     */ 
/*     */   private static byte[] encodeBytes(byte[] source, Type type) {
/* 230 */     Assert.notNull(source, "Source must not be null");
/* 231 */     Assert.notNull(type, "Type must not be null");
/* 232 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(source.length);
/* 233 */     for (byte b : source) {
/* 234 */       if (b < 0) {
/* 235 */         b = (byte)(b + 256);
/*     */       }
/* 237 */       if (type.isAllowed(b)) {
/* 238 */         bos.write(b);
/*     */       }
/*     */       else {
/* 241 */         bos.write(37);
/* 242 */         char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 0xF, 16));
/* 243 */         char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, 16));
/* 244 */         bos.write(hex1);
/* 245 */         bos.write(hex2);
/*     */       }
/*     */     }
/* 248 */     return bos.toByteArray();
/*     */   }
/*     */ 
/*     */   private Type getHostType() {
/* 252 */     return (this.host != null) && (this.host.startsWith("[")) ? Type.HOST_IPV6 : Type.HOST_IPV4;
/*     */   }
/*     */ 
/*     */   private void verify()
/*     */   {
/* 264 */     if (!this.encoded) {
/* 265 */       return;
/*     */     }
/* 267 */     verifyUriComponent(getScheme(), Type.SCHEME);
/* 268 */     verifyUriComponent(this.userInfo, Type.USER_INFO);
/* 269 */     verifyUriComponent(this.host, getHostType());
/* 270 */     this.path.verify();
/* 271 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 272 */       verifyUriComponent((String)entry.getKey(), Type.QUERY_PARAM);
/* 273 */       for (String value : (List)entry.getValue()) {
/* 274 */         verifyUriComponent(value, Type.QUERY_PARAM);
/*     */       }
/*     */     }
/* 277 */     verifyUriComponent(getFragment(), Type.FRAGMENT);
/*     */   }
/*     */ 
/*     */   private static void verifyUriComponent(String source, Type type) {
/* 281 */     if (source == null) {
/* 282 */       return;
/*     */     }
/* 284 */     int length = source.length();
/* 285 */     for (int i = 0; i < length; i++) {
/* 286 */       char ch = source.charAt(i);
/* 287 */       if (ch == '%') {
/* 288 */         if (i + 2 < length) {
/* 289 */           char hex1 = source.charAt(i + 1);
/* 290 */           char hex2 = source.charAt(i + 2);
/* 291 */           int u = Character.digit(hex1, 16);
/* 292 */           int l = Character.digit(hex2, 16);
/* 293 */           if ((u == -1) || (l == -1)) {
/* 294 */             throw new IllegalArgumentException(new StringBuilder().append("Invalid encoded sequence \"").append(source.substring(i)).append("\"").toString());
/*     */           }
/* 296 */           i += 2;
/*     */         }
/*     */         else {
/* 299 */           throw new IllegalArgumentException(new StringBuilder().append("Invalid encoded sequence \"").append(source.substring(i)).append("\"").toString());
/*     */         }
/*     */       }
/* 302 */       else if (!type.isAllowed(ch))
/*     */       {
/* 304 */         throw new IllegalArgumentException(new StringBuilder().append("Invalid character '").append(ch).append("' for ")
/* 304 */           .append(type
/* 304 */           .name()).append(" in \"").append(source).append("\"").toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected HierarchicalUriComponents expandInternal(UriComponents.UriTemplateVariables uriVariables)
/*     */   {
/* 314 */     Assert.state(!this.encoded, "Cannot expand an already encoded UriComponents object");
/* 315 */     String expandedScheme = expandUriComponent(getScheme(), uriVariables);
/* 316 */     String expandedUserInfo = expandUriComponent(this.userInfo, uriVariables);
/* 317 */     String expandedHost = expandUriComponent(this.host, uriVariables);
/* 318 */     String expandedPort = expandUriComponent(this.port, uriVariables);
/* 319 */     PathComponent expandedPath = this.path.expand(uriVariables);
/*     */ 
/* 321 */     MultiValueMap expandedQueryParams = new LinkedMultiValueMap(this.queryParams
/* 321 */       .size());
/* 322 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 323 */       String expandedName = expandUriComponent((String)entry.getKey(), uriVariables);
/* 324 */       List expandedValues = new ArrayList(((List)entry.getValue()).size());
/* 325 */       for (String value : (List)entry.getValue()) {
/* 326 */         String expandedValue = expandUriComponent(value, uriVariables);
/* 327 */         expandedValues.add(expandedValue);
/*     */       }
/* 329 */       expandedQueryParams.put(expandedName, expandedValues);
/*     */     }
/* 331 */     String expandedFragment = expandUriComponent(getFragment(), uriVariables);
/* 332 */     return new HierarchicalUriComponents(expandedScheme, expandedUserInfo, expandedHost, expandedPort, expandedPath, expandedQueryParams, expandedFragment, false, false);
/*     */   }
/*     */ 
/*     */   public UriComponents normalize()
/*     */   {
/* 342 */     String normalizedPath = StringUtils.cleanPath(getPath());
/*     */ 
/* 345 */     return new HierarchicalUriComponents(getScheme(), this.userInfo, this.host, this.port, new FullPathComponent(normalizedPath), this.queryParams, 
/* 345 */       getFragment(), this.encoded, false);
/*     */   }
/*     */ 
/*     */   public String toUriString()
/*     */   {
/* 356 */     StringBuilder uriBuilder = new StringBuilder();
/* 357 */     if (getScheme() != null) {
/* 358 */       uriBuilder.append(getScheme());
/* 359 */       uriBuilder.append(':');
/*     */     }
/* 361 */     if ((this.userInfo != null) || (this.host != null)) {
/* 362 */       uriBuilder.append("//");
/* 363 */       if (this.userInfo != null) {
/* 364 */         uriBuilder.append(this.userInfo);
/* 365 */         uriBuilder.append('@');
/*     */       }
/* 367 */       if (this.host != null) {
/* 368 */         uriBuilder.append(this.host);
/*     */       }
/* 370 */       if (getPort() != -1) {
/* 371 */         uriBuilder.append(':');
/* 372 */         uriBuilder.append(this.port);
/*     */       }
/*     */     }
/* 375 */     String path = getPath();
/* 376 */     if (StringUtils.hasLength(path)) {
/* 377 */       if ((uriBuilder.length() != 0) && (path.charAt(0) != '/')) {
/* 378 */         uriBuilder.append('/');
/*     */       }
/* 380 */       uriBuilder.append(path);
/*     */     }
/* 382 */     String query = getQuery();
/* 383 */     if (query != null) {
/* 384 */       uriBuilder.append('?');
/* 385 */       uriBuilder.append(query);
/*     */     }
/* 387 */     if (getFragment() != null) {
/* 388 */       uriBuilder.append('#');
/* 389 */       uriBuilder.append(getFragment());
/*     */     }
/* 391 */     return uriBuilder.toString();
/*     */   }
/*     */ 
/*     */   public URI toUri()
/*     */   {
/*     */     try
/*     */     {
/* 400 */       if (this.encoded) {
/* 401 */         return new URI(toString());
/*     */       }
/*     */ 
/* 404 */       String path = getPath();
/* 405 */       if ((StringUtils.hasLength(path)) && (path.charAt(0) != '/'))
/*     */       {
/* 407 */         if ((getScheme() != null) || (getUserInfo() != null) || (getHost() != null) || (getPort() != -1)) {
/* 408 */           path = new StringBuilder().append('/').append(path).toString();
/*     */         }
/*     */       }
/*     */ 
/* 412 */       return new URI(getScheme(), getUserInfo(), getHost(), getPort(), path, getQuery(), 
/* 412 */         getFragment());
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/* 416 */       throw new IllegalStateException(new StringBuilder().append("Could not create URI object: ").append(ex.getMessage()).toString(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 422 */     if (this == obj) {
/* 423 */       return true;
/*     */     }
/* 425 */     if (!(obj instanceof HierarchicalUriComponents)) {
/* 426 */       return false;
/*     */     }
/* 428 */     HierarchicalUriComponents other = (HierarchicalUriComponents)obj;
/*     */ 
/* 435 */     return (ObjectUtils.nullSafeEquals(getScheme(), other.getScheme())) && 
/* 430 */       (ObjectUtils.nullSafeEquals(getUserInfo(), other.getUserInfo())) && 
/* 431 */       (ObjectUtils.nullSafeEquals(getHost(), other.getHost())) && 
/* 432 */       (getPort() == other.getPort()) && 
/* 433 */       (this.path
/* 433 */       .equals(other.path)) && 
/* 434 */       (this.queryParams
/* 434 */       .equals(other.queryParams)) && 
/* 435 */       (ObjectUtils.nullSafeEquals(getFragment(), other.getFragment()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 440 */     int result = ObjectUtils.nullSafeHashCode(getScheme());
/* 441 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.userInfo);
/* 442 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.host);
/* 443 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.port);
/* 444 */     result = 31 * result + this.path.hashCode();
/* 445 */     result = 31 * result + this.queryParams.hashCode();
/* 446 */     result = 31 * result + ObjectUtils.nullSafeHashCode(getFragment());
/* 447 */     return result;
/*     */   }
/*     */ 
/*     */   static final class PathComponentComposite
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final List<HierarchicalUriComponents.PathComponent> pathComponents;
/*     */ 
/*     */     public PathComponentComposite(List<HierarchicalUriComponents.PathComponent> pathComponents)
/*     */     {
/* 747 */       this.pathComponents = pathComponents;
/*     */     }
/*     */ 
/*     */     public String getPath()
/*     */     {
/* 752 */       StringBuilder pathBuilder = new StringBuilder();
/* 753 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 754 */         pathBuilder.append(pathComponent.getPath());
/*     */       }
/* 756 */       return pathBuilder.toString();
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments()
/*     */     {
/* 761 */       List result = new ArrayList();
/* 762 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 763 */         result.addAll(pathComponent.getPathSegments());
/*     */       }
/* 765 */       return result;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 770 */       List encodedComponents = new ArrayList(this.pathComponents.size());
/* 771 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 772 */         encodedComponents.add(pathComponent.encode(encoding));
/*     */       }
/* 774 */       return new PathComponentComposite(encodedComponents);
/*     */     }
/*     */ 
/*     */     public void verify()
/*     */     {
/* 779 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents)
/* 780 */         pathComponent.verify();
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 786 */       List expandedComponents = new ArrayList(this.pathComponents.size());
/* 787 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 788 */         expandedComponents.add(pathComponent.expand(uriVariables));
/*     */       }
/* 790 */       return new PathComponentComposite(expandedComponents);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class PathSegmentComponent
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final List<String> pathSegments;
/*     */ 
/*     */     public PathSegmentComponent(List<String> pathSegments)
/*     */     {
/* 675 */       this.pathSegments = Collections.unmodifiableList(new ArrayList(pathSegments));
/*     */     }
/*     */ 
/*     */     public String getPath()
/*     */     {
/* 680 */       StringBuilder pathBuilder = new StringBuilder();
/* 681 */       pathBuilder.append('/');
/* 682 */       for (Iterator iterator = this.pathSegments.iterator(); iterator.hasNext(); ) {
/* 683 */         String pathSegment = (String)iterator.next();
/* 684 */         pathBuilder.append(pathSegment);
/* 685 */         if (iterator.hasNext()) {
/* 686 */           pathBuilder.append('/');
/*     */         }
/*     */       }
/* 689 */       return pathBuilder.toString();
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments()
/*     */     {
/* 694 */       return this.pathSegments;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 699 */       List pathSegments = getPathSegments();
/* 700 */       List encodedPathSegments = new ArrayList(pathSegments.size());
/* 701 */       for (String pathSegment : pathSegments) {
/* 702 */         String encodedPathSegment = HierarchicalUriComponents.encodeUriComponent(pathSegment, encoding, HierarchicalUriComponents.Type.PATH_SEGMENT);
/* 703 */         encodedPathSegments.add(encodedPathSegment);
/*     */       }
/* 705 */       return new PathSegmentComponent(encodedPathSegments);
/*     */     }
/*     */ 
/*     */     public void verify()
/*     */     {
/* 710 */       for (String pathSegment : getPathSegments())
/* 711 */         HierarchicalUriComponents.verifyUriComponent(pathSegment, HierarchicalUriComponents.Type.PATH_SEGMENT);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 717 */       List pathSegments = getPathSegments();
/* 718 */       List expandedPathSegments = new ArrayList(pathSegments.size());
/* 719 */       for (String pathSegment : pathSegments) {
/* 720 */         String expandedPathSegment = UriComponents.expandUriComponent(pathSegment, uriVariables);
/* 721 */         expandedPathSegments.add(expandedPathSegment);
/*     */       }
/* 723 */       return new PathSegmentComponent(expandedPathSegments);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 729 */       return (this == obj) || (((obj instanceof PathSegmentComponent)) && 
/* 729 */         (getPathSegments().equals(((PathSegmentComponent)obj).getPathSegments())));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 734 */       return getPathSegments().hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class FullPathComponent
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final String path;
/*     */ 
/*     */     public FullPathComponent(String path)
/*     */     {
/* 622 */       this.path = path;
/*     */     }
/*     */ 
/*     */     public String getPath()
/*     */     {
/* 627 */       return this.path;
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments()
/*     */     {
/* 632 */       String delimiter = new String(new char[] { '/' });
/* 633 */       String[] pathSegments = StringUtils.tokenizeToStringArray(this.path, delimiter);
/* 634 */       return Collections.unmodifiableList(Arrays.asList(pathSegments));
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException
/*     */     {
/* 639 */       String encodedPath = HierarchicalUriComponents.encodeUriComponent(getPath(), encoding, HierarchicalUriComponents.Type.PATH);
/* 640 */       return new FullPathComponent(encodedPath);
/*     */     }
/*     */ 
/*     */     public void verify()
/*     */     {
/* 645 */       HierarchicalUriComponents.verifyUriComponent(this.path, HierarchicalUriComponents.Type.PATH);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 650 */       String expandedPath = UriComponents.expandUriComponent(getPath(), uriVariables);
/* 651 */       return new FullPathComponent(expandedPath);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 657 */       return (this == obj) || (((obj instanceof FullPathComponent)) && 
/* 657 */         (getPath().equals(((FullPathComponent)obj).getPath())));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 662 */       return getPath().hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface PathComponent extends Serializable
/*     */   {
/*     */     public abstract String getPath();
/*     */ 
/*     */     public abstract List<String> getPathSegments();
/*     */ 
/*     */     public abstract PathComponent encode(String paramString)
/*     */       throws UnsupportedEncodingException;
/*     */ 
/*     */     public abstract void verify();
/*     */ 
/*     */     public abstract PathComponent expand(UriComponents.UriTemplateVariables paramUriTemplateVariables);
/*     */   }
/*     */ 
/*     */   static abstract enum Type
/*     */   {
/* 460 */     SCHEME, 
/*     */ 
/* 466 */     AUTHORITY, 
/*     */ 
/* 472 */     USER_INFO, 
/*     */ 
/* 478 */     HOST_IPV4, 
/*     */ 
/* 484 */     HOST_IPV6, 
/*     */ 
/* 490 */     PORT, 
/*     */ 
/* 496 */     PATH, 
/*     */ 
/* 502 */     PATH_SEGMENT, 
/*     */ 
/* 508 */     QUERY, 
/*     */ 
/* 514 */     QUERY_PARAM, 
/*     */ 
/* 525 */     FRAGMENT;
/*     */ 
/*     */     public abstract boolean isAllowed(int paramInt);
/*     */ 
/*     */     protected boolean isAlpha(int c)
/*     */     {
/* 543 */       return ((c >= 97) && (c <= 122)) || ((c >= 65) && (c <= 90));
/*     */     }
/*     */ 
/*     */     protected boolean isDigit(int c)
/*     */     {
/* 551 */       return (c >= 48) && (c <= 57);
/*     */     }
/*     */ 
/*     */     protected boolean isGenericDelimiter(int c)
/*     */     {
/* 559 */       return (58 == c) || (47 == c) || (63 == c) || (35 == c) || (91 == c) || (93 == c) || (64 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isSubDelimiter(int c)
/*     */     {
/* 567 */       return (33 == c) || (36 == c) || (38 == c) || (39 == c) || (40 == c) || (41 == c) || (42 == c) || (43 == c) || (44 == c) || (59 == c) || (61 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isReserved(char c)
/*     */     {
/* 576 */       return (isGenericDelimiter(c)) || (isReserved(c));
/*     */     }
/*     */ 
/*     */     protected boolean isUnreserved(int c)
/*     */     {
/* 584 */       return (isAlpha(c)) || (isDigit(c)) || (45 == c) || (46 == c) || (95 == c) || (126 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isPchar(int c)
/*     */     {
/* 592 */       return (isUnreserved(c)) || (isSubDelimiter(c)) || (58 == c) || (64 == c);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.HierarchicalUriComponents
 * JD-Core Version:    0.6.2
 */