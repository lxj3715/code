/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ class HtmlCharacterEntityReferences
/*     */ {
/*     */   private static final String PROPERTIES_FILE = "HtmlCharacterEntityReferences.properties";
/*     */   static final char REFERENCE_START = '&';
/*     */   static final String DECIMAL_REFERENCE_START = "&#";
/*     */   static final String HEX_REFERENCE_START = "&#x";
/*     */   static final char REFERENCE_END = ';';
/*     */   static final char CHAR_NULL = '����';
/*  55 */   private final String[] characterToEntityReferenceMap = new String[3000];
/*     */ 
/*  57 */   private final Map<String, Character> entityReferenceToCharacterMap = new HashMap(252);
/*     */ 
/*     */   public HtmlCharacterEntityReferences()
/*     */   {
/*  64 */     Properties entityReferences = new Properties();
/*     */ 
/*  67 */     InputStream is = HtmlCharacterEntityReferences.class.getResourceAsStream("HtmlCharacterEntityReferences.properties");
/*  68 */     if (is == null)
/*  69 */       throw new IllegalStateException("Cannot find reference definition file [HtmlCharacterEntityReferences.properties] as class path resource");
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  74 */         entityReferences.load(is);
/*     */ 
/*  77 */         is.close(); } finally { is.close(); }
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*  82 */       throw new IllegalStateException("Failed to parse reference definition file [HtmlCharacterEntityReferences.properties]: " + ex
/*  82 */         .getMessage());
/*     */     }
/*     */ 
/*  86 */     Enumeration keys = entityReferences.propertyNames();
/*  87 */     while (keys.hasMoreElements()) {
/*  88 */       String key = (String)keys.nextElement();
/*  89 */       int referredChar = Integer.parseInt(key);
/*  90 */       Assert.isTrue((referredChar < 1000) || ((referredChar >= 8000) && (referredChar < 10000)), "Invalid reference to special HTML entity: " + referredChar);
/*     */ 
/*  92 */       int index = referredChar < 1000 ? referredChar : referredChar - 7000;
/*  93 */       String reference = entityReferences.getProperty(key);
/*  94 */       this.characterToEntityReferenceMap[index] = ('&' + reference + ';');
/*  95 */       this.entityReferenceToCharacterMap.put(reference, Character.valueOf((char)referredChar));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getSupportedReferenceCount()
/*     */   {
/* 104 */     return this.entityReferenceToCharacterMap.size();
/*     */   }
/*     */ 
/*     */   public boolean isMappedToReference(char character)
/*     */   {
/* 111 */     return isMappedToReference(character, "ISO-8859-1");
/*     */   }
/*     */ 
/*     */   public boolean isMappedToReference(char character, String encoding)
/*     */   {
/* 118 */     return convertToReference(character, encoding) != null;
/*     */   }
/*     */ 
/*     */   public String convertToReference(char character)
/*     */   {
/* 125 */     return convertToReference(character, "ISO-8859-1");
/*     */   }
/*     */ 
/*     */   public String convertToReference(char character, String encoding)
/*     */   {
/* 133 */     if (encoding.startsWith("UTF-")) {
/* 134 */       switch (character) {
/*     */       case '<':
/* 136 */         return "&lt;";
/*     */       case '>':
/* 138 */         return "&gt;";
/*     */       case '"':
/* 140 */         return "&quot;";
/*     */       case '&':
/* 142 */         return "&amp;";
/*     */       case '\'':
/* 144 */         return "&#39;";
/*     */       }
/*     */     }
/* 147 */     else if ((character < 'Ϩ') || ((character >= 'ὀ') && (character < '✐'))) {
/* 148 */       int index = character < 'Ϩ' ? character : character - '᭘';
/* 149 */       String entityReference = this.characterToEntityReferenceMap[index];
/* 150 */       if (entityReference != null) {
/* 151 */         return entityReference;
/*     */       }
/*     */     }
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   public char convertToCharacter(String entityReference)
/*     */   {
/* 161 */     Character referredCharacter = (Character)this.entityReferenceToCharacterMap.get(entityReference);
/* 162 */     if (referredCharacter != null) {
/* 163 */       return referredCharacter.charValue();
/*     */     }
/* 165 */     return 65535;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.HtmlCharacterEntityReferences
 * JD-Core Version:    0.6.2
 */