/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class HtmlUtils
/*     */ {
/*  46 */   private static final HtmlCharacterEntityReferences characterEntityReferences = new HtmlCharacterEntityReferences();
/*     */ 
/*     */   public static String htmlEscape(String input)
/*     */   {
/*  63 */     return htmlEscape(input, "ISO-8859-1");
/*     */   }
/*     */ 
/*     */   public static String htmlEscape(String input, String encoding)
/*     */   {
/*  83 */     Assert.notNull(encoding, "Encoding is required");
/*  84 */     if (input == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     StringBuilder escaped = new StringBuilder(input.length() * 2);
/*  88 */     for (int i = 0; i < input.length(); i++) {
/*  89 */       char character = input.charAt(i);
/*  90 */       String reference = characterEntityReferences.convertToReference(character, encoding);
/*  91 */       if (reference != null) {
/*  92 */         escaped.append(reference);
/*     */       }
/*     */       else {
/*  95 */         escaped.append(character);
/*     */       }
/*     */     }
/*  98 */     return escaped.toString();
/*     */   }
/*     */ 
/*     */   public static String htmlEscapeDecimal(String input)
/*     */   {
/* 114 */     return htmlEscapeDecimal(input, "ISO-8859-1");
/*     */   }
/*     */ 
/*     */   public static String htmlEscapeDecimal(String input, String encoding)
/*     */   {
/* 134 */     Assert.notNull(encoding, "Encoding is required");
/* 135 */     if (input == null) {
/* 136 */       return null;
/*     */     }
/* 138 */     StringBuilder escaped = new StringBuilder(input.length() * 2);
/* 139 */     for (int i = 0; i < input.length(); i++) {
/* 140 */       char character = input.charAt(i);
/* 141 */       if (characterEntityReferences.isMappedToReference(character, encoding)) {
/* 142 */         escaped.append("&#");
/* 143 */         escaped.append(character);
/* 144 */         escaped.append(';');
/*     */       }
/*     */       else {
/* 147 */         escaped.append(character);
/*     */       }
/*     */     }
/* 150 */     return escaped.toString();
/*     */   }
/*     */ 
/*     */   public static String htmlEscapeHex(String input)
/*     */   {
/* 166 */     return htmlEscapeHex(input, "ISO-8859-1");
/*     */   }
/*     */ 
/*     */   public static String htmlEscapeHex(String input, String encoding)
/*     */   {
/* 186 */     Assert.notNull(encoding, "Encoding is required");
/* 187 */     if (input == null) {
/* 188 */       return null;
/*     */     }
/* 190 */     StringBuilder escaped = new StringBuilder(input.length() * 2);
/* 191 */     for (int i = 0; i < input.length(); i++) {
/* 192 */       char character = input.charAt(i);
/* 193 */       if (characterEntityReferences.isMappedToReference(character, encoding)) {
/* 194 */         escaped.append("&#x");
/* 195 */         escaped.append(Integer.toString(character, 16));
/* 196 */         escaped.append(';');
/*     */       }
/*     */       else {
/* 199 */         escaped.append(character);
/*     */       }
/*     */     }
/* 202 */     return escaped.toString();
/*     */   }
/*     */ 
/*     */   public static String htmlUnescape(String input)
/*     */   {
/* 225 */     if (input == null) {
/* 226 */       return null;
/*     */     }
/* 228 */     return new HtmlCharacterEntityDecoder(characterEntityReferences, input).decode();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.HtmlUtils
 * JD-Core Version:    0.6.2
 */