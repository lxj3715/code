/*    */ package org.springframework.web.util;
/*    */ 
/*    */ import javax.servlet.ServletException;
/*    */ import org.springframework.core.NestedExceptionUtils;
/*    */ 
/*    */ public class NestedServletException extends ServletException
/*    */ {
/*    */   private static final long serialVersionUID = -5292377985529381145L;
/*    */ 
/*    */   public NestedServletException(String msg)
/*    */   {
/* 60 */     super(msg);
/*    */   }
/*    */ 
/*    */   public NestedServletException(String msg, Throwable cause)
/*    */   {
/* 70 */     super(msg, cause);
/*    */ 
/* 73 */     if ((getCause() == null) && (cause != null))
/* 74 */       initCause(cause);
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 85 */     return NestedExceptionUtils.buildMessage(super.getMessage(), getCause());
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 51 */     NestedExceptionUtils.class.getName();
/*    */   }
/*    */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.NestedServletException
 * JD-Core Version:    0.6.2
 */