/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public abstract class UriComponents
/*     */   implements Serializable
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*  48 */   private static final Pattern NAMES_PATTERN = Pattern.compile("\\{([^/]+?)\\}");
/*     */   private final String scheme;
/*     */   private final String fragment;
/*     */ 
/*     */   protected UriComponents(String scheme, String fragment)
/*     */   {
/*  57 */     this.scheme = scheme;
/*  58 */     this.fragment = fragment;
/*     */   }
/*     */ 
/*     */   public final String getScheme()
/*     */   {
/*  68 */     return this.scheme;
/*     */   }
/*     */ 
/*     */   public abstract String getSchemeSpecificPart();
/*     */ 
/*     */   public abstract String getUserInfo();
/*     */ 
/*     */   public abstract String getHost();
/*     */ 
/*     */   public abstract int getPort();
/*     */ 
/*     */   public abstract String getPath();
/*     */ 
/*     */   public abstract List<String> getPathSegments();
/*     */ 
/*     */   public abstract String getQuery();
/*     */ 
/*     */   public abstract MultiValueMap<String, String> getQueryParams();
/*     */ 
/*     */   public final String getFragment()
/*     */   {
/* 115 */     return this.fragment;
/*     */   }
/*     */ 
/*     */   public final UriComponents encode()
/*     */   {
/*     */     try
/*     */     {
/* 126 */       return encode("UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 130 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public abstract UriComponents encode(String paramString)
/*     */     throws UnsupportedEncodingException;
/*     */ 
/*     */   public final UriComponents expand(Map<String, ?> uriVariables)
/*     */   {
/* 151 */     Assert.notNull(uriVariables, "'uriVariables' must not be null");
/* 152 */     return expandInternal(new MapTemplateVariables(uriVariables));
/*     */   }
/*     */ 
/*     */   public final UriComponents expand(Object[] uriVariableValues)
/*     */   {
/* 162 */     Assert.notNull(uriVariableValues, "'uriVariableValues' must not be null");
/* 163 */     return expandInternal(new VarArgsTemplateVariables(uriVariableValues));
/*     */   }
/*     */ 
/*     */   public final UriComponents expand(UriTemplateVariables uriVariables)
/*     */   {
/* 173 */     Assert.notNull(uriVariables, "'uriVariables' must not be null");
/* 174 */     return expandInternal(uriVariables);
/*     */   }
/*     */ 
/*     */   abstract UriComponents expandInternal(UriTemplateVariables paramUriTemplateVariables);
/*     */ 
/*     */   public abstract UriComponents normalize();
/*     */ 
/*     */   public abstract String toUriString();
/*     */ 
/*     */   public abstract URI toUri();
/*     */ 
/*     */   public final String toString()
/*     */   {
/* 203 */     return toUriString();
/*     */   }
/*     */ 
/*     */   static String expandUriComponent(String source, UriTemplateVariables uriVariables)
/*     */   {
/* 210 */     if (source == null) {
/* 211 */       return null;
/*     */     }
/* 213 */     if (source.indexOf('{') == -1) {
/* 214 */       return source;
/*     */     }
/* 216 */     Matcher matcher = NAMES_PATTERN.matcher(source);
/* 217 */     StringBuffer sb = new StringBuffer();
/* 218 */     while (matcher.find()) {
/* 219 */       String match = matcher.group(1);
/* 220 */       String variableName = getVariableName(match);
/* 221 */       Object variableValue = uriVariables.getValue(variableName);
/* 222 */       if (!UriTemplateVariables.SKIP_VALUE.equals(variableValue))
/*     */       {
/* 225 */         String variableValueString = getVariableValueAsString(variableValue);
/* 226 */         String replacement = Matcher.quoteReplacement(variableValueString);
/* 227 */         matcher.appendReplacement(sb, replacement);
/*     */       }
/*     */     }
/* 229 */     matcher.appendTail(sb);
/* 230 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static String getVariableName(String match) {
/* 234 */     int colonIdx = match.indexOf(':');
/* 235 */     return colonIdx != -1 ? match.substring(0, colonIdx) : match;
/*     */   }
/*     */ 
/*     */   private static String getVariableValueAsString(Object variableValue) {
/* 239 */     return variableValue != null ? variableValue.toString() : "";
/*     */   }
/*     */ 
/*     */   private static class VarArgsTemplateVariables
/*     */     implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final Iterator<Object> valueIterator;
/*     */ 
/*     */     public VarArgsTemplateVariables(Object[] uriVariableValues)
/*     */     {
/* 291 */       this.valueIterator = Arrays.asList(uriVariableValues).iterator();
/*     */     }
/*     */ 
/*     */     public Object getValue(String name)
/*     */     {
/* 296 */       if (!this.valueIterator.hasNext()) {
/* 297 */         throw new IllegalArgumentException("Not enough variable values available to expand '" + name + "'");
/*     */       }
/* 299 */       return this.valueIterator.next();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MapTemplateVariables
/*     */     implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final Map<String, ?> uriVariables;
/*     */ 
/*     */     public MapTemplateVariables(Map<String, ?> uriVariables)
/*     */     {
/* 270 */       this.uriVariables = uriVariables;
/*     */     }
/*     */ 
/*     */     public Object getValue(String name)
/*     */     {
/* 275 */       if (!this.uriVariables.containsKey(name)) {
/* 276 */         throw new IllegalArgumentException("Map has no value for '" + name + "'");
/*     */       }
/* 278 */       return this.uriVariables.get(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface UriTemplateVariables
/*     */   {
/* 249 */     public static final Object SKIP_VALUE = UriTemplateVariables.class;
/*     */ 
/*     */     public abstract Object getValue(String paramString);
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriComponents
 * JD-Core Version:    0.6.2
 */