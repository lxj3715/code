/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class UriComponentsBuilder
/*     */   implements Cloneable
/*     */ {
/*  60 */   private static final Pattern QUERY_PARAM_PATTERN = Pattern.compile("([^&=]+)(=?)([^&]+)?");
/*     */   private static final String SCHEME_PATTERN = "([^:/?#]+):";
/*     */   private static final String HTTP_PATTERN = "(?i)(http|https):";
/*     */   private static final String USERINFO_PATTERN = "([^@\\[/?#]*)";
/*     */   private static final String HOST_IPV4_PATTERN = "[^\\[/?#:]*";
/*     */   private static final String HOST_IPV6_PATTERN = "\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]";
/*     */   private static final String HOST_PATTERN = "(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)";
/*     */   private static final String PORT_PATTERN = "(\\d*(?:\\{[^/]+?\\})?)";
/*     */   private static final String PATH_PATTERN = "([^?#]*)";
/*     */   private static final String QUERY_PATTERN = "([^#]*)";
/*     */   private static final String LAST_PATTERN = "(.*)";
/*  83 */   private static final Pattern URI_PATTERN = Pattern.compile("^(([^:/?#]+):)?(//(([^@\\[/?#]*)@)?(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)(:(\\d*(?:\\{[^/]+?\\})?))?)?([^?#]*)(\\?([^#]*))?(#(.*))?");
/*     */ 
/*  87 */   private static final Pattern HTTP_URL_PATTERN = Pattern.compile("^(?i)(http|https):(//(([^@\\[/?#]*)@)?(\\[[\\p{XDigit}\\:\\.]*[%\\p{Alnum}]*\\]|[^\\[/?#:]*)(:(\\d*(?:\\{[^/]+?\\})?))?)?([^?#]*)(\\?(.*))?");
/*     */   private String scheme;
/*     */   private String ssp;
/*     */   private String userInfo;
/*     */   private String host;
/*     */   private String port;
/*     */   private CompositePathComponentBuilder pathBuilder;
/* 104 */   private final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap();
/*     */   private String fragment;
/*     */ 
/*     */   protected UriComponentsBuilder()
/*     */   {
/* 116 */     this.pathBuilder = new CompositePathComponentBuilder();
/*     */   }
/*     */ 
/*     */   protected UriComponentsBuilder(UriComponentsBuilder other)
/*     */   {
/* 124 */     this.scheme = other.scheme;
/* 125 */     this.ssp = other.ssp;
/* 126 */     this.userInfo = other.userInfo;
/* 127 */     this.host = other.host;
/* 128 */     this.port = other.port;
/* 129 */     this.pathBuilder = ((CompositePathComponentBuilder)other.pathBuilder.clone());
/* 130 */     this.queryParams.putAll(other.queryParams);
/* 131 */     this.fragment = other.fragment;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder newInstance()
/*     */   {
/* 142 */     return new UriComponentsBuilder();
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromPath(String path)
/*     */   {
/* 151 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 152 */     builder.path(path);
/* 153 */     return builder;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromUri(URI uri)
/*     */   {
/* 162 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 163 */     builder.uri(uri);
/* 164 */     return builder;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromUriString(String uri)
/*     */   {
/* 182 */     Assert.hasLength(uri, "'uri' must not be empty");
/* 183 */     Matcher matcher = URI_PATTERN.matcher(uri);
/* 184 */     if (matcher.matches()) {
/* 185 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 186 */       String scheme = matcher.group(2);
/* 187 */       String userInfo = matcher.group(5);
/* 188 */       String host = matcher.group(6);
/* 189 */       String port = matcher.group(8);
/* 190 */       String path = matcher.group(9);
/* 191 */       String query = matcher.group(11);
/* 192 */       String fragment = matcher.group(13);
/* 193 */       boolean opaque = false;
/* 194 */       if (StringUtils.hasLength(scheme)) {
/* 195 */         String rest = uri.substring(scheme.length());
/* 196 */         if (!rest.startsWith(":/")) {
/* 197 */           opaque = true;
/*     */         }
/*     */       }
/* 200 */       builder.scheme(scheme);
/* 201 */       if (opaque) {
/* 202 */         String ssp = uri.substring(scheme.length()).substring(1);
/* 203 */         if (StringUtils.hasLength(fragment)) {
/* 204 */           ssp = ssp.substring(0, ssp.length() - (fragment.length() + 1));
/*     */         }
/* 206 */         builder.schemeSpecificPart(ssp);
/*     */       }
/*     */       else {
/* 209 */         builder.userInfo(userInfo);
/* 210 */         builder.host(host);
/* 211 */         if (StringUtils.hasLength(port)) {
/* 212 */           builder.port(port);
/*     */         }
/* 214 */         builder.path(path);
/* 215 */         builder.query(query);
/*     */       }
/* 217 */       if (StringUtils.hasText(fragment)) {
/* 218 */         builder.fragment(fragment);
/*     */       }
/* 220 */       return builder;
/*     */     }
/*     */ 
/* 223 */     throw new IllegalArgumentException("[" + uri + "] is not a valid URI");
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromHttpUrl(String httpUrl)
/*     */   {
/* 242 */     Assert.notNull(httpUrl, "'httpUrl' must not be null");
/* 243 */     Matcher matcher = HTTP_URL_PATTERN.matcher(httpUrl);
/* 244 */     if (matcher.matches()) {
/* 245 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 246 */       String scheme = matcher.group(1);
/* 247 */       builder.scheme(scheme != null ? scheme.toLowerCase() : null);
/* 248 */       builder.userInfo(matcher.group(4));
/* 249 */       String host = matcher.group(5);
/* 250 */       if ((StringUtils.hasLength(scheme)) && (!StringUtils.hasLength(host))) {
/* 251 */         throw new IllegalArgumentException("[" + httpUrl + "] is not a valid HTTP URL");
/*     */       }
/* 253 */       builder.host(host);
/* 254 */       String port = matcher.group(7);
/* 255 */       if (StringUtils.hasLength(port)) {
/* 256 */         builder.port(port);
/*     */       }
/* 258 */       builder.path(matcher.group(8));
/* 259 */       builder.query(matcher.group(10));
/* 260 */       return builder;
/*     */     }
/*     */ 
/* 263 */     throw new IllegalArgumentException("[" + httpUrl + "] is not a valid HTTP URL");
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromHttpRequest(HttpRequest request)
/*     */   {
/* 276 */     URI uri = request.getURI();
/* 277 */     UriComponentsBuilder builder = fromUri(uri);
/*     */ 
/* 279 */     String scheme = uri.getScheme();
/* 280 */     String host = uri.getHost();
/* 281 */     int port = uri.getPort();
/*     */ 
/* 283 */     String hostHeader = request.getHeaders().getFirst("X-Forwarded-Host");
/* 284 */     if (StringUtils.hasText(hostHeader)) {
/* 285 */       String[] hosts = StringUtils.commaDelimitedListToStringArray(hostHeader);
/* 286 */       String hostToUse = hosts[0];
/* 287 */       if (hostToUse.contains(":")) {
/* 288 */         String[] hostAndPort = StringUtils.split(hostToUse, ":");
/* 289 */         host = hostAndPort[0];
/* 290 */         port = Integer.parseInt(hostAndPort[1]);
/*     */       }
/*     */       else {
/* 293 */         host = hostToUse;
/* 294 */         port = -1;
/*     */       }
/*     */     }
/*     */ 
/* 298 */     String portHeader = request.getHeaders().getFirst("X-Forwarded-Port");
/* 299 */     if (StringUtils.hasText(portHeader)) {
/* 300 */       String[] ports = StringUtils.commaDelimitedListToStringArray(portHeader);
/* 301 */       port = Integer.parseInt(ports[0]);
/*     */     }
/*     */ 
/* 304 */     String protocolHeader = request.getHeaders().getFirst("X-Forwarded-Proto");
/* 305 */     if (StringUtils.hasText(protocolHeader)) {
/* 306 */       String[] protocols = StringUtils.commaDelimitedListToStringArray(protocolHeader);
/* 307 */       scheme = protocols[0];
/*     */     }
/*     */ 
/* 310 */     builder.scheme(scheme);
/* 311 */     builder.host(host);
/* 312 */     builder.port(null);
/* 313 */     if (((scheme.equals("http")) && (port != 80)) || ((scheme.equals("https")) && (port != 443))) {
/* 314 */       builder.port(port);
/*     */     }
/* 316 */     return builder;
/*     */   }
/*     */ 
/*     */   public UriComponents build()
/*     */   {
/* 327 */     return build(false);
/*     */   }
/*     */ 
/*     */   public UriComponents build(boolean encoded)
/*     */   {
/* 338 */     if (this.ssp != null) {
/* 339 */       return new OpaqueUriComponents(this.scheme, this.ssp, this.fragment);
/*     */     }
/*     */ 
/* 343 */     return new HierarchicalUriComponents(this.scheme, this.userInfo, this.host, this.port, this.pathBuilder
/* 343 */       .build(), this.queryParams, this.fragment, encoded, true);
/*     */   }
/*     */ 
/*     */   public UriComponents buildAndExpand(Map<String, ?> uriVariables)
/*     */   {
/* 355 */     return build(false).expand(uriVariables);
/*     */   }
/*     */ 
/*     */   public UriComponents buildAndExpand(Object[] uriVariableValues)
/*     */   {
/* 366 */     return build(false).expand(uriVariableValues);
/*     */   }
/*     */ 
/*     */   public String toUriString()
/*     */   {
/* 377 */     return build(false).encode().toUriString();
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder uri(URI uri)
/*     */   {
/* 389 */     Assert.notNull(uri, "'uri' must not be null");
/* 390 */     this.scheme = uri.getScheme();
/* 391 */     if (uri.isOpaque()) {
/* 392 */       this.ssp = uri.getRawSchemeSpecificPart();
/* 393 */       resetHierarchicalComponents();
/*     */     }
/*     */     else {
/* 396 */       if (uri.getRawUserInfo() != null) {
/* 397 */         this.userInfo = uri.getRawUserInfo();
/*     */       }
/* 399 */       if (uri.getHost() != null) {
/* 400 */         this.host = uri.getHost();
/*     */       }
/* 402 */       if (uri.getPort() != -1) {
/* 403 */         this.port = String.valueOf(uri.getPort());
/*     */       }
/* 405 */       if (StringUtils.hasLength(uri.getRawPath())) {
/* 406 */         this.pathBuilder = new CompositePathComponentBuilder(uri.getRawPath());
/*     */       }
/* 408 */       if (StringUtils.hasLength(uri.getRawQuery())) {
/* 409 */         this.queryParams.clear();
/* 410 */         query(uri.getRawQuery());
/*     */       }
/* 412 */       resetSchemeSpecificPart();
/*     */     }
/* 414 */     if (uri.getRawFragment() != null) {
/* 415 */       this.fragment = uri.getRawFragment();
/*     */     }
/* 417 */     return this;
/*     */   }
/*     */ 
/*     */   private void resetHierarchicalComponents() {
/* 421 */     this.userInfo = null;
/* 422 */     this.host = null;
/* 423 */     this.port = null;
/* 424 */     this.pathBuilder = new CompositePathComponentBuilder();
/* 425 */     this.queryParams.clear();
/*     */   }
/*     */ 
/*     */   private void resetSchemeSpecificPart() {
/* 429 */     this.ssp = null;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder scheme(String scheme)
/*     */   {
/* 439 */     this.scheme = scheme;
/* 440 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder uriComponents(UriComponents uriComponents)
/*     */   {
/* 449 */     Assert.notNull(uriComponents, "'uriComponents' must not be null");
/* 450 */     this.scheme = uriComponents.getScheme();
/* 451 */     if ((uriComponents instanceof OpaqueUriComponents)) {
/* 452 */       this.ssp = uriComponents.getSchemeSpecificPart();
/* 453 */       resetHierarchicalComponents();
/*     */     }
/*     */     else {
/* 456 */       if (uriComponents.getUserInfo() != null) {
/* 457 */         this.userInfo = uriComponents.getUserInfo();
/*     */       }
/* 459 */       if (uriComponents.getHost() != null) {
/* 460 */         this.host = uriComponents.getHost();
/*     */       }
/* 462 */       if (uriComponents.getPort() != -1) {
/* 463 */         this.port = String.valueOf(uriComponents.getPort());
/*     */       }
/* 465 */       if (StringUtils.hasLength(uriComponents.getPath())) {
/* 466 */         List segments = uriComponents.getPathSegments();
/* 467 */         if (segments.isEmpty())
/*     */         {
/* 469 */           this.pathBuilder.addPath(uriComponents.getPath());
/*     */         }
/*     */         else {
/* 472 */           this.pathBuilder.addPathSegments((String[])segments.toArray(new String[segments.size()]));
/*     */         }
/*     */       }
/* 475 */       if (!uriComponents.getQueryParams().isEmpty()) {
/* 476 */         this.queryParams.clear();
/* 477 */         this.queryParams.putAll(uriComponents.getQueryParams());
/*     */       }
/* 479 */       resetSchemeSpecificPart();
/*     */     }
/* 481 */     if (uriComponents.getFragment() != null) {
/* 482 */       this.fragment = uriComponents.getFragment();
/*     */     }
/* 484 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder schemeSpecificPart(String ssp)
/*     */   {
/* 496 */     this.ssp = ssp;
/* 497 */     resetHierarchicalComponents();
/* 498 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder userInfo(String userInfo)
/*     */   {
/* 508 */     this.userInfo = userInfo;
/* 509 */     resetSchemeSpecificPart();
/* 510 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder host(String host)
/*     */   {
/* 520 */     this.host = host;
/* 521 */     resetSchemeSpecificPart();
/* 522 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder port(int port)
/*     */   {
/* 531 */     Assert.isTrue(port >= -1, "'port' must not be < -1");
/* 532 */     this.port = String.valueOf(port);
/* 533 */     resetSchemeSpecificPart();
/* 534 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder port(String port)
/*     */   {
/* 545 */     this.port = port;
/* 546 */     resetSchemeSpecificPart();
/* 547 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder path(String path)
/*     */   {
/* 557 */     this.pathBuilder.addPath(path);
/* 558 */     resetSchemeSpecificPart();
/* 559 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replacePath(String path)
/*     */   {
/* 568 */     this.pathBuilder = new CompositePathComponentBuilder(path);
/* 569 */     resetSchemeSpecificPart();
/* 570 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder pathSegment(String[] pathSegments)
/*     */     throws IllegalArgumentException
/*     */   {
/* 580 */     Assert.notNull(pathSegments, "'segments' must not be null");
/* 581 */     this.pathBuilder.addPathSegments(pathSegments);
/* 582 */     resetSchemeSpecificPart();
/* 583 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder query(String query)
/*     */   {
/* 602 */     if (query != null) {
/* 603 */       Matcher matcher = QUERY_PARAM_PATTERN.matcher(query);
/* 604 */       while (matcher.find()) {
/* 605 */         String name = matcher.group(1);
/* 606 */         String eq = matcher.group(2);
/* 607 */         String value = matcher.group(3);
/* 608 */         queryParam(name, new Object[] { StringUtils.hasLength(eq) ? "" : value != null ? value : null });
/*     */       }
/*     */     }
/*     */     else {
/* 612 */       this.queryParams.clear();
/*     */     }
/* 614 */     resetSchemeSpecificPart();
/* 615 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replaceQuery(String query)
/*     */   {
/* 624 */     this.queryParams.clear();
/* 625 */     query(query);
/* 626 */     resetSchemeSpecificPart();
/* 627 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder queryParam(String name, Object[] values)
/*     */   {
/* 640 */     Assert.notNull(name, "'name' must not be null");
/* 641 */     if (!ObjectUtils.isEmpty(values)) {
/* 642 */       for (Object value : values) {
/* 643 */         String valueAsString = value != null ? value.toString() : null;
/* 644 */         this.queryParams.add(name, valueAsString);
/*     */       }
/*     */     }
/*     */     else {
/* 648 */       this.queryParams.add(name, null);
/*     */     }
/* 650 */     resetSchemeSpecificPart();
/* 651 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder queryParams(MultiValueMap<String, String> params)
/*     */   {
/* 660 */     Assert.notNull(params, "'params' must not be null");
/* 661 */     this.queryParams.putAll(params);
/* 662 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replaceQueryParam(String name, Object[] values)
/*     */   {
/* 673 */     Assert.notNull(name, "'name' must not be null");
/* 674 */     this.queryParams.remove(name);
/* 675 */     if (!ObjectUtils.isEmpty(values)) {
/* 676 */       queryParam(name, values);
/*     */     }
/* 678 */     resetSchemeSpecificPart();
/* 679 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder fragment(String fragment)
/*     */   {
/* 689 */     if (fragment != null) {
/* 690 */       Assert.hasLength(fragment, "'fragment' must not be empty");
/* 691 */       this.fragment = fragment;
/*     */     }
/*     */     else {
/* 694 */       this.fragment = null;
/*     */     }
/* 696 */     return this;
/*     */   }
/*     */ 
/*     */   protected Object clone()
/*     */   {
/* 701 */     return new UriComponentsBuilder(this);
/*     */   }
/*     */ 
/*     */   private static class PathSegmentComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 837 */     private final List<String> pathSegments = new LinkedList();
/*     */ 
/*     */     public void append(String[] pathSegments) {
/* 840 */       for (String pathSegment : pathSegments)
/* 841 */         if (StringUtils.hasText(pathSegment))
/* 842 */           this.pathSegments.add(pathSegment);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 849 */       return this.pathSegments.isEmpty() ? null : new HierarchicalUriComponents.PathSegmentComponent(this.pathSegments);
/*     */     }
/*     */ 
/*     */     public Object clone()
/*     */     {
/* 855 */       PathSegmentComponentBuilder builder = new PathSegmentComponentBuilder();
/* 856 */       builder.pathSegments.addAll(this.pathSegments);
/* 857 */       return builder;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class FullPathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 797 */     private final StringBuilder path = new StringBuilder();
/*     */ 
/*     */     public void append(String path) {
/* 800 */       this.path.append(path);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 805 */       if (this.path.length() == 0) {
/* 806 */         return null;
/*     */       }
/* 808 */       String path = this.path.toString();
/*     */       while (true) {
/* 810 */         int index = path.indexOf("//");
/* 811 */         if (index == -1) {
/*     */           break;
/*     */         }
/* 814 */         path = path.substring(0, index) + path.substring(index + 1);
/*     */       }
/* 816 */       return new HierarchicalUriComponents.FullPathComponent(path);
/*     */     }
/*     */ 
/*     */     public void removeTrailingSlash() {
/* 820 */       int index = this.path.length() - 1;
/* 821 */       if (this.path.charAt(index) == '/')
/* 822 */         this.path.deleteCharAt(index);
/*     */     }
/*     */ 
/*     */     public Object clone()
/*     */     {
/* 828 */       FullPathComponentBuilder builder = new FullPathComponentBuilder();
/* 829 */       builder.append(this.path.toString());
/* 830 */       return builder;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CompositePathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 715 */     private final LinkedList<UriComponentsBuilder.PathComponentBuilder> builders = new LinkedList();
/*     */ 
/*     */     public CompositePathComponentBuilder() {
/*     */     }
/*     */ 
/*     */     public CompositePathComponentBuilder(String path) {
/* 721 */       addPath(path);
/*     */     }
/*     */ 
/*     */     public void addPathSegments(String[] pathSegments) {
/* 725 */       if (!ObjectUtils.isEmpty(pathSegments)) {
/* 726 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 727 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 728 */         if (psBuilder == null) {
/* 729 */           psBuilder = new UriComponentsBuilder.PathSegmentComponentBuilder(null);
/* 730 */           this.builders.add(psBuilder);
/* 731 */           if (fpBuilder != null) {
/* 732 */             fpBuilder.removeTrailingSlash();
/*     */           }
/*     */         }
/* 735 */         psBuilder.append(pathSegments);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void addPath(String path) {
/* 740 */       if (StringUtils.hasText(path)) {
/* 741 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 742 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 743 */         if (psBuilder != null) {
/* 744 */           path = "/" + path;
/*     */         }
/* 746 */         if (fpBuilder == null) {
/* 747 */           fpBuilder = new UriComponentsBuilder.FullPathComponentBuilder(null);
/* 748 */           this.builders.add(fpBuilder);
/*     */         }
/* 750 */         fpBuilder.append(path);
/*     */       }
/*     */     }
/*     */ 
/*     */     private <T> T getLastBuilder(Class<T> builderClass)
/*     */     {
/* 756 */       if (!this.builders.isEmpty()) {
/* 757 */         UriComponentsBuilder.PathComponentBuilder last = (UriComponentsBuilder.PathComponentBuilder)this.builders.getLast();
/* 758 */         if (builderClass.isInstance(last)) {
/* 759 */           return last;
/*     */         }
/*     */       }
/* 762 */       return null;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 767 */       int size = this.builders.size();
/* 768 */       List components = new ArrayList(size);
/* 769 */       for (UriComponentsBuilder.PathComponentBuilder componentBuilder : this.builders) {
/* 770 */         HierarchicalUriComponents.PathComponent pathComponent = componentBuilder.build();
/* 771 */         if (pathComponent != null) {
/* 772 */           components.add(pathComponent);
/*     */         }
/*     */       }
/* 775 */       if (components.isEmpty()) {
/* 776 */         return HierarchicalUriComponents.NULL_PATH_COMPONENT;
/*     */       }
/* 778 */       if (components.size() == 1) {
/* 779 */         return (HierarchicalUriComponents.PathComponent)components.get(0);
/*     */       }
/* 781 */       return new HierarchicalUriComponents.PathComponentComposite(components);
/*     */     }
/*     */ 
/*     */     public Object clone()
/*     */     {
/* 786 */       CompositePathComponentBuilder compositeBuilder = new CompositePathComponentBuilder();
/* 787 */       for (UriComponentsBuilder.PathComponentBuilder builder : this.builders) {
/* 788 */         compositeBuilder.builders.add((UriComponentsBuilder.PathComponentBuilder)builder.clone());
/*     */       }
/* 790 */       return compositeBuilder;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract interface PathComponentBuilder extends Cloneable
/*     */   {
/*     */     public abstract HierarchicalUriComponents.PathComponent build();
/*     */ 
/*     */     public abstract Object clone();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriComponentsBuilder
 * JD-Core Version:    0.6.2
 */