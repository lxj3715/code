/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.URI;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class UriTemplate
/*     */   implements Serializable
/*     */ {
/*  46 */   private static final Pattern NAMES_PATTERN = Pattern.compile("\\{([^/]+?)\\}");
/*     */   private static final String DEFAULT_VARIABLE_PATTERN = "(.*)";
/*     */   private final UriComponents uriComponents;
/*     */   private final List<String> variableNames;
/*     */   private final Pattern matchPattern;
/*     */   private final String uriTemplate;
/*     */ 
/*     */   public UriTemplate(String uriTemplate)
/*     */   {
/*  65 */     Parser parser = new Parser(uriTemplate, null);
/*  66 */     this.uriTemplate = uriTemplate;
/*  67 */     this.variableNames = parser.getVariableNames();
/*  68 */     this.matchPattern = parser.getMatchPattern();
/*  69 */     this.uriComponents = UriComponentsBuilder.fromUriString(uriTemplate).build();
/*     */   }
/*     */ 
/*     */   public List<String> getVariableNames()
/*     */   {
/*  78 */     return this.variableNames;
/*     */   }
/*     */ 
/*     */   public URI expand(Map<String, ?> uriVariables)
/*     */   {
/*  99 */     UriComponents expandedComponents = this.uriComponents.expand(uriVariables);
/* 100 */     UriComponents encodedComponents = expandedComponents.encode();
/* 101 */     return encodedComponents.toUri();
/*     */   }
/*     */ 
/*     */   public URI expand(Object[] uriVariableValues)
/*     */   {
/* 119 */     UriComponents expandedComponents = this.uriComponents.expand(uriVariableValues);
/* 120 */     UriComponents encodedComponents = expandedComponents.encode();
/* 121 */     return encodedComponents.toUri();
/*     */   }
/*     */ 
/*     */   public boolean matches(String uri)
/*     */   {
/* 130 */     if (uri == null) {
/* 131 */       return false;
/*     */     }
/* 133 */     Matcher matcher = this.matchPattern.matcher(uri);
/* 134 */     return matcher.matches();
/*     */   }
/*     */ 
/*     */   public Map<String, String> match(String uri)
/*     */   {
/* 150 */     Assert.notNull(uri, "'uri' must not be null");
/* 151 */     Map result = new LinkedHashMap(this.variableNames.size());
/* 152 */     Matcher matcher = this.matchPattern.matcher(uri);
/* 153 */     if (matcher.find()) {
/* 154 */       for (int i = 1; i <= matcher.groupCount(); i++) {
/* 155 */         String name = (String)this.variableNames.get(i - 1);
/* 156 */         String value = matcher.group(i);
/* 157 */         result.put(name, value);
/*     */       }
/*     */     }
/* 160 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 165 */     return this.uriTemplate;
/*     */   }
/*     */ 
/*     */   private static class Parser
/*     */   {
/* 174 */     private final List<String> variableNames = new LinkedList();
/*     */ 
/* 176 */     private final StringBuilder patternBuilder = new StringBuilder();
/*     */ 
/*     */     private Parser(String uriTemplate) {
/* 179 */       Assert.hasText(uriTemplate, "'uriTemplate' must not be null");
/* 180 */       Matcher matcher = UriTemplate.NAMES_PATTERN.matcher(uriTemplate);
/* 181 */       int end = 0;
/* 182 */       while (matcher.find()) {
/* 183 */         this.patternBuilder.append(quote(uriTemplate, end, matcher.start()));
/* 184 */         String match = matcher.group(1);
/* 185 */         int colonIdx = match.indexOf(':');
/* 186 */         if (colonIdx == -1) {
/* 187 */           this.patternBuilder.append("(.*)");
/* 188 */           this.variableNames.add(match);
/*     */         }
/*     */         else {
/* 191 */           if (colonIdx + 1 == match.length()) {
/* 192 */             throw new IllegalArgumentException("No custom regular expression specified after ':' in \"" + match + "\"");
/*     */           }
/*     */ 
/* 195 */           String variablePattern = match.substring(colonIdx + 1, match.length());
/* 196 */           this.patternBuilder.append('(');
/* 197 */           this.patternBuilder.append(variablePattern);
/* 198 */           this.patternBuilder.append(')');
/* 199 */           String variableName = match.substring(0, colonIdx);
/* 200 */           this.variableNames.add(variableName);
/*     */         }
/* 202 */         end = matcher.end();
/*     */       }
/* 204 */       this.patternBuilder.append(quote(uriTemplate, end, uriTemplate.length()));
/* 205 */       int lastIdx = this.patternBuilder.length() - 1;
/* 206 */       if ((lastIdx >= 0) && (this.patternBuilder.charAt(lastIdx) == '/'))
/* 207 */         this.patternBuilder.deleteCharAt(lastIdx);
/*     */     }
/*     */ 
/*     */     private String quote(String fullPath, int start, int end)
/*     */     {
/* 212 */       if (start == end) {
/* 213 */         return "";
/*     */       }
/* 215 */       return Pattern.quote(fullPath.substring(start, end));
/*     */     }
/*     */ 
/*     */     private List<String> getVariableNames() {
/* 219 */       return Collections.unmodifiableList(this.variableNames);
/*     */     }
/*     */ 
/*     */     private Pattern getMatchPattern() {
/* 223 */       return Pattern.compile(this.patternBuilder.toString());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriTemplate
 * JD-Core Version:    0.6.2
 */