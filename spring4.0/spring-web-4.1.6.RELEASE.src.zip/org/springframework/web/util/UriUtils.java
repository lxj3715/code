/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class UriUtils
/*     */ {
/*     */   private static final String SCHEME_PATTERN = "([^:/?#]+):";
/*     */   private static final String HTTP_PATTERN = "(http|https):";
/*     */   private static final String USERINFO_PATTERN = "([^@/]*)";
/*     */   private static final String HOST_PATTERN = "([^/?#:]*)";
/*     */   private static final String PORT_PATTERN = "(\\d*)";
/*     */   private static final String PATH_PATTERN = "([^?#]*)";
/*     */   private static final String QUERY_PATTERN = "([^#]*)";
/*     */   private static final String LAST_PATTERN = "(.*)";
/*  61 */   private static final Pattern URI_PATTERN = Pattern.compile("^(([^:/?#]+):)?(//(([^@/]*)@)?([^/?#:]*)(:(\\d*))?)?([^?#]*)(\\?([^#]*))?(#(.*))?");
/*     */ 
/*  65 */   private static final Pattern HTTP_URL_PATTERN = Pattern.compile("^(http|https):(//(([^@/]*)@)?([^/?#:]*)(:(\\d*))?)?([^?#]*)(\\?(.*))?");
/*     */ 
/*     */   @Deprecated
/*     */   public static String encodeUri(String uri, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  91 */     Assert.notNull(uri, "URI must not be null");
/*  92 */     Assert.hasLength(encoding, "Encoding must not be empty");
/*  93 */     Matcher matcher = URI_PATTERN.matcher(uri);
/*  94 */     if (matcher.matches()) {
/*  95 */       String scheme = matcher.group(2);
/*  96 */       String authority = matcher.group(3);
/*  97 */       String userinfo = matcher.group(5);
/*  98 */       String host = matcher.group(6);
/*  99 */       String port = matcher.group(8);
/* 100 */       String path = matcher.group(9);
/* 101 */       String query = matcher.group(11);
/* 102 */       String fragment = matcher.group(13);
/* 103 */       return encodeUriComponents(scheme, authority, userinfo, host, port, path, query, fragment, encoding);
/*     */     }
/*     */ 
/* 106 */     throw new IllegalArgumentException(new StringBuilder().append("[").append(uri).append("] is not a valid URI").toString());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static String encodeHttpUrl(String httpUrl, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 131 */     Assert.notNull(httpUrl, "HTTP URL must not be null");
/* 132 */     Assert.hasLength(encoding, "Encoding must not be empty");
/* 133 */     Matcher matcher = HTTP_URL_PATTERN.matcher(httpUrl);
/* 134 */     if (matcher.matches()) {
/* 135 */       String scheme = matcher.group(1);
/* 136 */       String authority = matcher.group(2);
/* 137 */       String userinfo = matcher.group(4);
/* 138 */       String host = matcher.group(5);
/* 139 */       String portString = matcher.group(7);
/* 140 */       String path = matcher.group(8);
/* 141 */       String query = matcher.group(10);
/* 142 */       return encodeUriComponents(scheme, authority, userinfo, host, portString, path, query, null, encoding);
/*     */     }
/*     */ 
/* 145 */     throw new IllegalArgumentException(new StringBuilder().append("[").append(httpUrl).append("] is not a valid HTTP URL").toString());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static String encodeUriComponents(String scheme, String authority, String userInfo, String host, String port, String path, String query, String fragment, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 171 */     Assert.hasLength(encoding, "Encoding must not be empty");
/* 172 */     StringBuilder sb = new StringBuilder();
/*     */ 
/* 174 */     if (scheme != null) {
/* 175 */       sb.append(encodeScheme(scheme, encoding));
/* 176 */       sb.append(':');
/*     */     }
/*     */ 
/* 179 */     if (authority != null) {
/* 180 */       sb.append("//");
/* 181 */       if (userInfo != null) {
/* 182 */         sb.append(encodeUserInfo(userInfo, encoding));
/* 183 */         sb.append('@');
/*     */       }
/* 185 */       if (host != null) {
/* 186 */         sb.append(encodeHost(host, encoding));
/*     */       }
/* 188 */       if (port != null) {
/* 189 */         sb.append(':');
/* 190 */         sb.append(encodePort(port, encoding));
/*     */       }
/*     */     }
/*     */ 
/* 194 */     sb.append(encodePath(path, encoding));
/*     */ 
/* 196 */     if (query != null) {
/* 197 */       sb.append('?');
/* 198 */       sb.append(encodeQuery(query, encoding));
/*     */     }
/*     */ 
/* 201 */     if (fragment != null) {
/* 202 */       sb.append('#');
/* 203 */       sb.append(encodeFragment(fragment, encoding));
/*     */     }
/*     */ 
/* 206 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String encodeScheme(String scheme, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 220 */     return HierarchicalUriComponents.encodeUriComponent(scheme, encoding, HierarchicalUriComponents.Type.SCHEME);
/*     */   }
/*     */ 
/*     */   public static String encodeAuthority(String authority, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 231 */     return HierarchicalUriComponents.encodeUriComponent(authority, encoding, HierarchicalUriComponents.Type.AUTHORITY);
/*     */   }
/*     */ 
/*     */   public static String encodeUserInfo(String userInfo, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 242 */     return HierarchicalUriComponents.encodeUriComponent(userInfo, encoding, HierarchicalUriComponents.Type.USER_INFO);
/*     */   }
/*     */ 
/*     */   public static String encodeHost(String host, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 253 */     return HierarchicalUriComponents.encodeUriComponent(host, encoding, HierarchicalUriComponents.Type.HOST_IPV4);
/*     */   }
/*     */ 
/*     */   public static String encodePort(String port, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 264 */     return HierarchicalUriComponents.encodeUriComponent(port, encoding, HierarchicalUriComponents.Type.PORT);
/*     */   }
/*     */ 
/*     */   public static String encodePath(String path, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 275 */     return HierarchicalUriComponents.encodeUriComponent(path, encoding, HierarchicalUriComponents.Type.PATH);
/*     */   }
/*     */ 
/*     */   public static String encodePathSegment(String segment, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 286 */     return HierarchicalUriComponents.encodeUriComponent(segment, encoding, HierarchicalUriComponents.Type.PATH_SEGMENT);
/*     */   }
/*     */ 
/*     */   public static String encodeQuery(String query, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 297 */     return HierarchicalUriComponents.encodeUriComponent(query, encoding, HierarchicalUriComponents.Type.QUERY);
/*     */   }
/*     */ 
/*     */   public static String encodeQueryParam(String queryParam, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 308 */     return HierarchicalUriComponents.encodeUriComponent(queryParam, encoding, HierarchicalUriComponents.Type.QUERY_PARAM);
/*     */   }
/*     */ 
/*     */   public static String encodeFragment(String fragment, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 319 */     return HierarchicalUriComponents.encodeUriComponent(fragment, encoding, HierarchicalUriComponents.Type.FRAGMENT);
/*     */   }
/*     */ 
/*     */   public static String decode(String source, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 341 */     Assert.notNull(source, "Source must not be null");
/* 342 */     Assert.hasLength(encoding, "Encoding must not be empty");
/* 343 */     int length = source.length();
/* 344 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(length);
/* 345 */     boolean changed = false;
/* 346 */     for (int i = 0; i < length; i++) {
/* 347 */       int ch = source.charAt(i);
/* 348 */       if (ch == 37) {
/* 349 */         if (i + 2 < length) {
/* 350 */           char hex1 = source.charAt(i + 1);
/* 351 */           char hex2 = source.charAt(i + 2);
/* 352 */           int u = Character.digit(hex1, 16);
/* 353 */           int l = Character.digit(hex2, 16);
/* 354 */           if ((u == -1) || (l == -1)) {
/* 355 */             throw new IllegalArgumentException(new StringBuilder().append("Invalid encoded sequence \"").append(source.substring(i)).append("\"").toString());
/*     */           }
/* 357 */           bos.write((char)((u << 4) + l));
/* 358 */           i += 2;
/* 359 */           changed = true;
/*     */         }
/*     */         else {
/* 362 */           throw new IllegalArgumentException(new StringBuilder().append("Invalid encoded sequence \"").append(source.substring(i)).append("\"").toString());
/*     */         }
/*     */       }
/*     */       else {
/* 366 */         bos.write(ch);
/*     */       }
/*     */     }
/* 369 */     return changed ? new String(bos.toByteArray(), encoding) : source;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriUtils
 * JD-Core Version:    0.6.2
 */