/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class UrlPathHelper
/*     */ {
/*     */   private static final String WEBSPHERE_URI_ATTRIBUTE = "com.ibm.websphere.servlet.uri_non_decoded";
/*  57 */   private static final Log logger = LogFactory.getLog(UrlPathHelper.class);
/*     */   static volatile Boolean websphereComplianceFlag;
/*  62 */   private boolean alwaysUseFullPath = false;
/*     */ 
/*  64 */   private boolean urlDecode = true;
/*     */ 
/*  66 */   private boolean removeSemicolonContent = true;
/*     */ 
/*  68 */   private String defaultEncoding = "ISO-8859-1";
/*     */ 
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath)
/*     */   {
/*  78 */     this.alwaysUseFullPath = alwaysUseFullPath;
/*     */   }
/*     */ 
/*     */   public void setUrlDecode(boolean urlDecode)
/*     */   {
/*  96 */     this.urlDecode = urlDecode;
/*     */   }
/*     */ 
/*     */   public void setRemoveSemicolonContent(boolean removeSemicolonContent)
/*     */   {
/* 104 */     this.removeSemicolonContent = removeSemicolonContent;
/*     */   }
/*     */ 
/*     */   public boolean shouldRemoveSemicolonContent()
/*     */   {
/* 111 */     return this.removeSemicolonContent;
/*     */   }
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 128 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */ 
/*     */   protected String getDefaultEncoding()
/*     */   {
/* 135 */     return this.defaultEncoding;
/*     */   }
/*     */ 
/*     */   public String getLookupPathForRequest(HttpServletRequest request)
/*     */   {
/* 150 */     if (this.alwaysUseFullPath) {
/* 151 */       return getPathWithinApplication(request);
/*     */     }
/*     */ 
/* 154 */     String rest = getPathWithinServletMapping(request);
/* 155 */     if (!"".equals(rest)) {
/* 156 */       return rest;
/*     */     }
/*     */ 
/* 159 */     return getPathWithinApplication(request);
/*     */   }
/*     */ 
/*     */   public String getPathWithinServletMapping(HttpServletRequest request)
/*     */   {
/* 175 */     String pathWithinApp = getPathWithinApplication(request);
/* 176 */     String servletPath = getServletPath(request);
/* 177 */     String path = getRemainingPath(pathWithinApp, servletPath, false);
/* 178 */     if (path != null)
/*     */     {
/* 180 */       return path;
/*     */     }
/*     */ 
/* 184 */     String pathInfo = request.getPathInfo();
/* 185 */     if (pathInfo != null)
/*     */     {
/* 188 */       return pathInfo;
/*     */     }
/* 190 */     if (!this.urlDecode)
/*     */     {
/* 195 */       path = getRemainingPath(decodeInternal(request, pathWithinApp), servletPath, false);
/* 196 */       if (path != null) {
/* 197 */         return pathWithinApp;
/*     */       }
/*     */     }
/*     */ 
/* 201 */     return servletPath;
/*     */   }
/*     */ 
/*     */   public String getPathWithinApplication(HttpServletRequest request)
/*     */   {
/* 212 */     String contextPath = getContextPath(request);
/* 213 */     String requestUri = getRequestUri(request);
/* 214 */     String path = getRemainingPath(requestUri, contextPath, true);
/* 215 */     if (path != null)
/*     */     {
/* 217 */       return StringUtils.hasText(path) ? path : "/";
/*     */     }
/*     */ 
/* 220 */     return requestUri;
/*     */   }
/*     */ 
/*     */   private String getRemainingPath(String requestUri, String mapping, boolean ignoreCase)
/*     */   {
/* 231 */     int index1 = 0;
/* 232 */     for (int index2 = 0; 
/* 233 */       (index1 < requestUri.length()) && (index2 < mapping.length()); index2++) {
/* 234 */       char c1 = requestUri.charAt(index1);
/* 235 */       char c2 = mapping.charAt(index2);
/* 236 */       if (c1 == ';') {
/* 237 */         index1 = requestUri.indexOf(47, index1);
/* 238 */         if (index1 == -1) {
/* 239 */           return null;
/*     */         }
/* 241 */         c1 = requestUri.charAt(index1);
/*     */       }
/* 243 */       if (c1 != c2)
/*     */       {
/* 246 */         if ((!ignoreCase) || (Character.toLowerCase(c1) != Character.toLowerCase(c2)))
/*     */         {
/* 249 */           return null;
/*     */         }
/*     */       }
/* 233 */       index1++;
/*     */     }
/*     */ 
/* 251 */     if (index2 != mapping.length()) {
/* 252 */       return null;
/*     */     }
/* 254 */     if (index1 == requestUri.length()) {
/* 255 */       return "";
/*     */     }
/* 257 */     if (requestUri.charAt(index1) == ';') {
/* 258 */       index1 = requestUri.indexOf(47, index1);
/*     */     }
/* 260 */     return index1 != -1 ? requestUri.substring(index1) : "";
/*     */   }
/*     */ 
/*     */   public String getRequestUri(HttpServletRequest request)
/*     */   {
/* 275 */     String uri = (String)request.getAttribute("javax.servlet.include.request_uri");
/* 276 */     if (uri == null) {
/* 277 */       uri = request.getRequestURI();
/*     */     }
/* 279 */     return decodeAndCleanUriString(request, uri);
/*     */   }
/*     */ 
/*     */   public String getContextPath(HttpServletRequest request)
/*     */   {
/* 291 */     String contextPath = (String)request.getAttribute("javax.servlet.include.context_path");
/* 292 */     if (contextPath == null) {
/* 293 */       contextPath = request.getContextPath();
/*     */     }
/* 295 */     if ("/".equals(contextPath))
/*     */     {
/* 297 */       contextPath = "";
/*     */     }
/* 299 */     return decodeRequestString(request, contextPath);
/*     */   }
/*     */ 
/*     */   public String getServletPath(HttpServletRequest request)
/*     */   {
/* 311 */     String servletPath = (String)request.getAttribute("javax.servlet.include.servlet_path");
/* 312 */     if (servletPath == null) {
/* 313 */       servletPath = request.getServletPath();
/*     */     }
/* 315 */     if ((servletPath.length() > 1) && (servletPath.endsWith("/")) && (shouldRemoveTrailingServletPathSlash(request)))
/*     */     {
/* 319 */       servletPath = servletPath.substring(0, servletPath.length() - 1);
/*     */     }
/* 321 */     return servletPath;
/*     */   }
/*     */ 
/*     */   public String getOriginatingRequestUri(HttpServletRequest request)
/*     */   {
/* 330 */     String uri = (String)request.getAttribute("com.ibm.websphere.servlet.uri_non_decoded");
/* 331 */     if (uri == null) {
/* 332 */       uri = (String)request.getAttribute("javax.servlet.forward.request_uri");
/* 333 */       if (uri == null) {
/* 334 */         uri = request.getRequestURI();
/*     */       }
/*     */     }
/* 337 */     return decodeAndCleanUriString(request, uri);
/*     */   }
/*     */ 
/*     */   public String getOriginatingContextPath(HttpServletRequest request)
/*     */   {
/* 349 */     String contextPath = (String)request.getAttribute("javax.servlet.forward.context_path");
/* 350 */     if (contextPath == null) {
/* 351 */       contextPath = request.getContextPath();
/*     */     }
/* 353 */     return decodeRequestString(request, contextPath);
/*     */   }
/*     */ 
/*     */   public String getOriginatingServletPath(HttpServletRequest request)
/*     */   {
/* 363 */     String servletPath = (String)request.getAttribute("javax.servlet.forward.servlet_path");
/* 364 */     if (servletPath == null) {
/* 365 */       servletPath = request.getServletPath();
/*     */     }
/* 367 */     return servletPath;
/*     */   }
/*     */ 
/*     */   public String getOriginatingQueryString(HttpServletRequest request)
/*     */   {
/* 377 */     if ((request.getAttribute("javax.servlet.forward.request_uri") != null) || 
/* 378 */       (request
/* 378 */       .getAttribute("javax.servlet.error.request_uri") != null))
/*     */     {
/* 379 */       return (String)request.getAttribute("javax.servlet.forward.query_string");
/*     */     }
/*     */ 
/* 382 */     return request.getQueryString();
/*     */   }
/*     */ 
/*     */   private String decodeAndCleanUriString(HttpServletRequest request, String uri)
/*     */   {
/* 390 */     uri = removeSemicolonContent(uri);
/* 391 */     uri = decodeRequestString(request, uri);
/* 392 */     return uri;
/*     */   }
/*     */ 
/*     */   public String decodeRequestString(HttpServletRequest request, String source)
/*     */   {
/* 408 */     if (this.urlDecode) {
/* 409 */       return decodeInternal(request, source);
/*     */     }
/* 411 */     return source;
/*     */   }
/*     */ 
/*     */   private String decodeInternal(HttpServletRequest request, String source)
/*     */   {
/* 416 */     String enc = determineEncoding(request);
/*     */     try {
/* 418 */       return UriUtils.decode(source, enc);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex) {
/* 421 */       if (logger.isWarnEnabled())
/* 422 */         logger.warn("Could not decode request string [" + source + "] with encoding '" + enc + "': falling back to platform default encoding; exception message: " + ex
/* 423 */           .getMessage());
/*     */     }
/* 425 */     return URLDecoder.decode(source);
/*     */   }
/*     */ 
/*     */   protected String determineEncoding(HttpServletRequest request)
/*     */   {
/* 440 */     String enc = request.getCharacterEncoding();
/* 441 */     if (enc == null) {
/* 442 */       enc = getDefaultEncoding();
/*     */     }
/* 444 */     return enc;
/*     */   }
/*     */ 
/*     */   public String removeSemicolonContent(String requestUri)
/*     */   {
/* 456 */     return this.removeSemicolonContent ? 
/* 456 */       removeSemicolonContentInternal(requestUri) : 
/* 456 */       removeJsessionid(requestUri);
/*     */   }
/*     */ 
/*     */   private String removeSemicolonContentInternal(String requestUri) {
/* 460 */     int semicolonIndex = requestUri.indexOf(59);
/* 461 */     while (semicolonIndex != -1) {
/* 462 */       int slashIndex = requestUri.indexOf(47, semicolonIndex);
/* 463 */       String start = requestUri.substring(0, semicolonIndex);
/* 464 */       requestUri = slashIndex != -1 ? start + requestUri.substring(slashIndex) : start;
/* 465 */       semicolonIndex = requestUri.indexOf(59, semicolonIndex);
/*     */     }
/* 467 */     return requestUri;
/*     */   }
/*     */ 
/*     */   private String removeJsessionid(String requestUri) {
/* 471 */     int startIndex = requestUri.toLowerCase().indexOf(";jsessionid=");
/* 472 */     if (startIndex != -1) {
/* 473 */       int endIndex = requestUri.indexOf(59, startIndex + 12);
/* 474 */       String start = requestUri.substring(0, startIndex);
/* 475 */       requestUri = endIndex != -1 ? start + requestUri.substring(endIndex) : start;
/*     */     }
/* 477 */     return requestUri;
/*     */   }
/*     */ 
/*     */   public Map<String, String> decodePathVariables(HttpServletRequest request, Map<String, String> vars)
/*     */   {
/* 492 */     if (this.urlDecode) {
/* 493 */       return vars;
/*     */     }
/*     */ 
/* 496 */     Map decodedVars = new LinkedHashMap(vars.size());
/* 497 */     for (Map.Entry entry : vars.entrySet()) {
/* 498 */       decodedVars.put(entry.getKey(), decodeInternal(request, (String)entry.getValue()));
/*     */     }
/* 500 */     return decodedVars;
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, String> decodeMatrixVariables(HttpServletRequest request, MultiValueMap<String, String> vars)
/*     */   {
/* 516 */     if (this.urlDecode) {
/* 517 */       return vars;
/*     */     }
/*     */ 
/* 520 */     MultiValueMap decodedVars = new LinkedMultiValueMap(vars.size());
/* 521 */     for (Iterator localIterator1 = vars.keySet().iterator(); localIterator1.hasNext(); ) { key = (String)localIterator1.next();
/* 522 */       for (String value : (List)vars.get(key))
/* 523 */         decodedVars.add(key, decodeInternal(request, value));
/*     */     }
/*     */     String key;
/* 526 */     return decodedVars;
/*     */   }
/*     */ 
/*     */   private boolean shouldRemoveTrailingServletPathSlash(HttpServletRequest request)
/*     */   {
/* 531 */     if (request.getAttribute("com.ibm.websphere.servlet.uri_non_decoded") == null)
/*     */     {
/* 535 */       return false;
/*     */     }
/* 537 */     if (websphereComplianceFlag == null) {
/* 538 */       ClassLoader classLoader = UrlPathHelper.class.getClassLoader();
/* 539 */       String className = "com.ibm.ws.webcontainer.WebContainer";
/* 540 */       String methodName = "getWebContainerProperties";
/* 541 */       String propName = "com.ibm.ws.webcontainer.removetrailingservletpathslash";
/* 542 */       boolean flag = false;
/*     */       try {
/* 544 */         Class cl = classLoader.loadClass(className);
/* 545 */         Properties prop = (Properties)cl.getMethod(methodName, new Class[0]).invoke(null, new Object[0]);
/* 546 */         flag = Boolean.parseBoolean(prop.getProperty(propName));
/*     */       }
/*     */       catch (Throwable ex) {
/* 549 */         if (logger.isDebugEnabled()) {
/* 550 */           logger.debug("Could not introspect WebSphere web container properties: " + ex);
/*     */         }
/*     */       }
/* 553 */       websphereComplianceFlag = Boolean.valueOf(flag);
/*     */     }
/*     */ 
/* 557 */     return !websphereComplianceFlag.booleanValue();
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UrlPathHelper
 * JD-Core Version:    0.6.2
 */