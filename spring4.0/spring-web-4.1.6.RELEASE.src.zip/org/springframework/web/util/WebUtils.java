/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletRequestWrapper;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.ServletResponseWrapper;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class WebUtils
/*     */ {
/*     */   public static final String INCLUDE_REQUEST_URI_ATTRIBUTE = "javax.servlet.include.request_uri";
/*     */   public static final String INCLUDE_CONTEXT_PATH_ATTRIBUTE = "javax.servlet.include.context_path";
/*     */   public static final String INCLUDE_SERVLET_PATH_ATTRIBUTE = "javax.servlet.include.servlet_path";
/*     */   public static final String INCLUDE_PATH_INFO_ATTRIBUTE = "javax.servlet.include.path_info";
/*     */   public static final String INCLUDE_QUERY_STRING_ATTRIBUTE = "javax.servlet.include.query_string";
/*     */   public static final String FORWARD_REQUEST_URI_ATTRIBUTE = "javax.servlet.forward.request_uri";
/*     */   public static final String FORWARD_CONTEXT_PATH_ATTRIBUTE = "javax.servlet.forward.context_path";
/*     */   public static final String FORWARD_SERVLET_PATH_ATTRIBUTE = "javax.servlet.forward.servlet_path";
/*     */   public static final String FORWARD_PATH_INFO_ATTRIBUTE = "javax.servlet.forward.path_info";
/*     */   public static final String FORWARD_QUERY_STRING_ATTRIBUTE = "javax.servlet.forward.query_string";
/*     */   public static final String ERROR_STATUS_CODE_ATTRIBUTE = "javax.servlet.error.status_code";
/*     */   public static final String ERROR_EXCEPTION_TYPE_ATTRIBUTE = "javax.servlet.error.exception_type";
/*     */   public static final String ERROR_MESSAGE_ATTRIBUTE = "javax.servlet.error.message";
/*     */   public static final String ERROR_EXCEPTION_ATTRIBUTE = "javax.servlet.error.exception";
/*     */   public static final String ERROR_REQUEST_URI_ATTRIBUTE = "javax.servlet.error.request_uri";
/*     */   public static final String ERROR_SERVLET_NAME_ATTRIBUTE = "javax.servlet.error.servlet_name";
/*     */   public static final String CONTENT_TYPE_CHARSET_PREFIX = ";charset=";
/*     */   public static final String DEFAULT_CHARACTER_ENCODING = "ISO-8859-1";
/*     */   public static final String TEMP_DIR_CONTEXT_ATTRIBUTE = "javax.servlet.context.tempdir";
/*     */   public static final String HTML_ESCAPE_CONTEXT_PARAM = "defaultHtmlEscape";
/*     */   public static final String RESPONSE_ENCODED_HTML_ESCAPE_CONTEXT_PARAM = "responseEncodedHtmlEscape";
/*     */   public static final String WEB_APP_ROOT_KEY_PARAM = "webAppRootKey";
/*     */   public static final String DEFAULT_WEB_APP_ROOT_KEY = "webapp.root";
/* 132 */   public static final String[] SUBMIT_IMAGE_SUFFIXES = { ".x", ".y" };
/*     */ 
/* 135 */   public static final String SESSION_MUTEX_ATTRIBUTE = WebUtils.class.getName() + ".MUTEX";
/*     */ 
/* 137 */   private static final Log logger = LogFactory.getLog(WebUtils.class);
/*     */ 
/*     */   public static void setWebAppRootSystemProperty(ServletContext servletContext)
/*     */     throws IllegalStateException
/*     */   {
/* 155 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 156 */     String root = servletContext.getRealPath("/");
/* 157 */     if (root == null) {
/* 158 */       throw new IllegalStateException("Cannot set web app root system property when WAR file is not expanded");
/*     */     }
/*     */ 
/* 161 */     String param = servletContext.getInitParameter("webAppRootKey");
/* 162 */     String key = param != null ? param : "webapp.root";
/* 163 */     String oldValue = System.getProperty(key);
/* 164 */     if ((oldValue != null) && (!StringUtils.pathEquals(oldValue, root))) {
/* 165 */       throw new IllegalStateException("Web app root system property already set to different value: '" + key + "' = [" + oldValue + "] instead of [" + root + "] - " + "Choose unique values for the 'webAppRootKey' context-param in your web.xml files!");
/*     */     }
/*     */ 
/* 170 */     System.setProperty(key, root);
/* 171 */     servletContext.log("Set web app root system property: '" + key + "' = [" + root + "]");
/*     */   }
/*     */ 
/*     */   public static void removeWebAppRootSystemProperty(ServletContext servletContext)
/*     */   {
/* 181 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 182 */     String param = servletContext.getInitParameter("webAppRootKey");
/* 183 */     String key = param != null ? param : "webapp.root";
/* 184 */     System.getProperties().remove(key);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static boolean isDefaultHtmlEscape(ServletContext servletContext)
/*     */   {
/* 197 */     if (servletContext == null) {
/* 198 */       return false;
/*     */     }
/* 200 */     String param = servletContext.getInitParameter("defaultHtmlEscape");
/* 201 */     return Boolean.valueOf(param).booleanValue();
/*     */   }
/*     */ 
/*     */   public static Boolean getDefaultHtmlEscape(ServletContext servletContext)
/*     */   {
/* 215 */     if (servletContext == null) {
/* 216 */       return null;
/*     */     }
/* 218 */     String param = servletContext.getInitParameter("defaultHtmlEscape");
/* 219 */     return StringUtils.hasText(param) ? Boolean.valueOf(param) : null;
/*     */   }
/*     */ 
/*     */   public static Boolean getResponseEncodedHtmlEscape(ServletContext servletContext)
/*     */   {
/* 236 */     if (servletContext == null) {
/* 237 */       return null;
/*     */     }
/* 239 */     String param = servletContext.getInitParameter("responseEncodedHtmlEscape");
/* 240 */     return StringUtils.hasText(param) ? Boolean.valueOf(param) : null;
/*     */   }
/*     */ 
/*     */   public static File getTempDir(ServletContext servletContext)
/*     */   {
/* 250 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 251 */     return (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/*     */   }
/*     */ 
/*     */   public static String getRealPath(ServletContext servletContext, String path)
/*     */     throws FileNotFoundException
/*     */   {
/* 268 */     Assert.notNull(servletContext, "ServletContext must not be null");
/*     */ 
/* 270 */     if (!path.startsWith("/")) {
/* 271 */       path = "/" + path;
/*     */     }
/* 273 */     String realPath = servletContext.getRealPath(path);
/* 274 */     if (realPath == null) {
/* 275 */       throw new FileNotFoundException("ServletContext resource [" + path + "] cannot be resolved to absolute file path - " + "web application archive not expanded?");
/*     */     }
/*     */ 
/* 279 */     return realPath;
/*     */   }
/*     */ 
/*     */   public static String getSessionId(HttpServletRequest request)
/*     */   {
/* 289 */     Assert.notNull(request, "Request must not be null");
/* 290 */     HttpSession session = request.getSession(false);
/* 291 */     return session != null ? session.getId() : null;
/*     */   }
/*     */ 
/*     */   public static Object getSessionAttribute(HttpServletRequest request, String name)
/*     */   {
/* 303 */     Assert.notNull(request, "Request must not be null");
/* 304 */     HttpSession session = request.getSession(false);
/* 305 */     return session != null ? session.getAttribute(name) : null;
/*     */   }
/*     */ 
/*     */   public static Object getRequiredSessionAttribute(HttpServletRequest request, String name)
/*     */     throws IllegalStateException
/*     */   {
/* 320 */     Object attr = getSessionAttribute(request, name);
/* 321 */     if (attr == null) {
/* 322 */       throw new IllegalStateException("No session attribute '" + name + "' found");
/*     */     }
/* 324 */     return attr;
/*     */   }
/*     */ 
/*     */   public static void setSessionAttribute(HttpServletRequest request, String name, Object value)
/*     */   {
/* 336 */     Assert.notNull(request, "Request must not be null");
/* 337 */     if (value != null) {
/* 338 */       request.getSession().setAttribute(name, value);
/*     */     }
/*     */     else {
/* 341 */       HttpSession session = request.getSession(false);
/* 342 */       if (session != null)
/* 343 */         session.removeAttribute(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object getOrCreateSessionAttribute(HttpSession session, String name, Class<?> clazz)
/*     */     throws IllegalArgumentException
/*     */   {
/* 361 */     Assert.notNull(session, "Session must not be null");
/* 362 */     Object sessionObject = session.getAttribute(name);
/* 363 */     if (sessionObject == null) {
/*     */       try {
/* 365 */         sessionObject = clazz.newInstance();
/*     */       }
/*     */       catch (InstantiationException ex)
/*     */       {
/* 370 */         throw new IllegalArgumentException("Could not instantiate class [" + clazz
/* 369 */           .getName() + "] for session attribute '" + name + "': " + ex
/* 370 */           .getMessage());
/*     */       }
/*     */       catch (IllegalAccessException ex)
/*     */       {
/* 375 */         throw new IllegalArgumentException("Could not access default constructor of class [" + clazz
/* 374 */           .getName() + "] for session attribute '" + name + "': " + ex
/* 375 */           .getMessage());
/*     */       }
/* 377 */       session.setAttribute(name, sessionObject);
/*     */     }
/* 379 */     return sessionObject;
/*     */   }
/*     */ 
/*     */   public static Object getSessionMutex(HttpSession session)
/*     */   {
/* 403 */     Assert.notNull(session, "Session must not be null");
/* 404 */     Object mutex = session.getAttribute(SESSION_MUTEX_ATTRIBUTE);
/* 405 */     if (mutex == null) {
/* 406 */       mutex = session;
/*     */     }
/* 408 */     return mutex;
/*     */   }
/*     */ 
/*     */   public static <T> T getNativeRequest(ServletRequest request, Class<T> requiredType)
/*     */   {
/* 422 */     if (requiredType != null) {
/* 423 */       if (requiredType.isInstance(request)) {
/* 424 */         return request;
/*     */       }
/* 426 */       if ((request instanceof ServletRequestWrapper)) {
/* 427 */         return getNativeRequest(((ServletRequestWrapper)request).getRequest(), requiredType);
/*     */       }
/*     */     }
/* 430 */     return null;
/*     */   }
/*     */ 
/*     */   public static <T> T getNativeResponse(ServletResponse response, Class<T> requiredType)
/*     */   {
/* 443 */     if (requiredType != null) {
/* 444 */       if (requiredType.isInstance(response)) {
/* 445 */         return response;
/*     */       }
/* 447 */       if ((response instanceof ServletResponseWrapper)) {
/* 448 */         return getNativeResponse(((ServletResponseWrapper)response).getResponse(), requiredType);
/*     */       }
/*     */     }
/* 451 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean isIncludeRequest(ServletRequest request)
/*     */   {
/* 464 */     return request.getAttribute("javax.servlet.include.request_uri") != null;
/*     */   }
/*     */ 
/*     */   public static void exposeErrorRequestAttributes(HttpServletRequest request, Throwable ex, String servletName)
/*     */   {
/* 486 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.status_code", Integer.valueOf(200));
/* 487 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.exception_type", ex.getClass());
/* 488 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.message", ex.getMessage());
/* 489 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.exception", ex);
/* 490 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.request_uri", request.getRequestURI());
/* 491 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.servlet_name", servletName);
/*     */   }
/*     */ 
/*     */   private static void exposeRequestAttributeIfNotPresent(ServletRequest request, String name, Object value)
/*     */   {
/* 501 */     if (request.getAttribute(name) == null)
/* 502 */       request.setAttribute(name, value);
/*     */   }
/*     */ 
/*     */   public static void clearErrorRequestAttributes(HttpServletRequest request)
/*     */   {
/* 518 */     request.removeAttribute("javax.servlet.error.status_code");
/* 519 */     request.removeAttribute("javax.servlet.error.exception_type");
/* 520 */     request.removeAttribute("javax.servlet.error.message");
/* 521 */     request.removeAttribute("javax.servlet.error.exception");
/* 522 */     request.removeAttribute("javax.servlet.error.request_uri");
/* 523 */     request.removeAttribute("javax.servlet.error.servlet_name");
/*     */   }
/*     */ 
/*     */   public static void exposeRequestAttributes(ServletRequest request, Map<String, ?> attributes)
/*     */   {
/* 533 */     Assert.notNull(request, "Request must not be null");
/* 534 */     Assert.notNull(attributes, "Attributes Map must not be null");
/* 535 */     for (Map.Entry entry : attributes.entrySet())
/* 536 */       request.setAttribute((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public static Cookie getCookie(HttpServletRequest request, String name)
/*     */   {
/* 548 */     Assert.notNull(request, "Request must not be null");
/* 549 */     Cookie[] cookies = request.getCookies();
/* 550 */     if (cookies != null) {
/* 551 */       for (Cookie cookie : cookies) {
/* 552 */         if (name.equals(cookie.getName())) {
/* 553 */           return cookie;
/*     */         }
/*     */       }
/*     */     }
/* 557 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean hasSubmitParameter(ServletRequest request, String name)
/*     */   {
/* 570 */     Assert.notNull(request, "Request must not be null");
/* 571 */     if (request.getParameter(name) != null) {
/* 572 */       return true;
/*     */     }
/* 574 */     for (String suffix : SUBMIT_IMAGE_SUFFIXES) {
/* 575 */       if (request.getParameter(name + suffix) != null) {
/* 576 */         return true;
/*     */       }
/*     */     }
/* 579 */     return false;
/*     */   }
/*     */ 
/*     */   public static String findParameterValue(ServletRequest request, String name)
/*     */   {
/* 592 */     return findParameterValue(request.getParameterMap(), name);
/*     */   }
/*     */ 
/*     */   public static String findParameterValue(Map<String, ?> parameters, String name)
/*     */   {
/* 620 */     Object value = parameters.get(name);
/* 621 */     if ((value instanceof String[])) {
/* 622 */       String[] values = (String[])value;
/* 623 */       return values.length > 0 ? values[0] : null;
/*     */     }
/* 625 */     if (value != null) {
/* 626 */       return value.toString();
/*     */     }
/*     */ 
/* 629 */     String prefix = name + "_";
/* 630 */     for (String paramName : parameters.keySet()) {
/* 631 */       if (paramName.startsWith(prefix))
/*     */       {
/* 633 */         for (String suffix : SUBMIT_IMAGE_SUFFIXES) {
/* 634 */           if (paramName.endsWith(suffix)) {
/* 635 */             return paramName.substring(prefix.length(), paramName.length() - suffix.length());
/*     */           }
/*     */         }
/* 638 */         return paramName.substring(prefix.length());
/*     */       }
/*     */     }
/*     */ 
/* 642 */     return null;
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> getParametersStartingWith(ServletRequest request, String prefix)
/*     */   {
/* 660 */     Assert.notNull(request, "Request must not be null");
/* 661 */     Enumeration paramNames = request.getParameterNames();
/* 662 */     Map params = new TreeMap();
/* 663 */     if (prefix == null) {
/* 664 */       prefix = "";
/*     */     }
/* 666 */     while ((paramNames != null) && (paramNames.hasMoreElements())) {
/* 667 */       String paramName = (String)paramNames.nextElement();
/* 668 */       if (("".equals(prefix)) || (paramName.startsWith(prefix))) {
/* 669 */         String unprefixed = paramName.substring(prefix.length());
/* 670 */         String[] values = request.getParameterValues(paramName);
/* 671 */         if ((values != null) && (values.length != 0))
/*     */         {
/* 674 */           if (values.length > 1) {
/* 675 */             params.put(unprefixed, values);
/*     */           }
/*     */           else
/* 678 */             params.put(unprefixed, values[0]);
/*     */         }
/*     */       }
/*     */     }
/* 682 */     return params;
/*     */   }
/*     */ 
/*     */   public static int getTargetPage(ServletRequest request, String paramPrefix, int currentPage)
/*     */   {
/* 695 */     Enumeration paramNames = request.getParameterNames();
/* 696 */     while (paramNames.hasMoreElements()) {
/* 697 */       String paramName = (String)paramNames.nextElement();
/* 698 */       if (paramName.startsWith(paramPrefix)) {
/* 699 */         for (int i = 0; i < SUBMIT_IMAGE_SUFFIXES.length; i++) {
/* 700 */           String suffix = SUBMIT_IMAGE_SUFFIXES[i];
/* 701 */           if (paramName.endsWith(suffix)) {
/* 702 */             paramName = paramName.substring(0, paramName.length() - suffix.length());
/*     */           }
/*     */         }
/* 705 */         return Integer.parseInt(paramName.substring(paramPrefix.length()));
/*     */       }
/*     */     }
/* 708 */     return currentPage;
/*     */   }
/*     */ 
/*     */   public static String extractFilenameFromUrlPath(String urlPath)
/*     */   {
/* 719 */     String filename = extractFullFilenameFromUrlPath(urlPath);
/* 720 */     int dotIndex = filename.lastIndexOf(46);
/* 721 */     if (dotIndex != -1) {
/* 722 */       filename = filename.substring(0, dotIndex);
/*     */     }
/* 724 */     return filename;
/*     */   }
/*     */ 
/*     */   public static String extractFullFilenameFromUrlPath(String urlPath)
/*     */   {
/* 734 */     int end = urlPath.indexOf(59);
/* 735 */     if (end == -1) {
/* 736 */       end = urlPath.indexOf(63);
/* 737 */       if (end == -1) {
/* 738 */         end = urlPath.length();
/*     */       }
/*     */     }
/* 741 */     int begin = urlPath.lastIndexOf(47, end) + 1;
/* 742 */     return urlPath.substring(begin, end);
/*     */   }
/*     */ 
/*     */   public static MultiValueMap<String, String> parseMatrixVariables(String matrixVariables)
/*     */   {
/* 755 */     MultiValueMap result = new LinkedMultiValueMap();
/* 756 */     if (!StringUtils.hasText(matrixVariables)) {
/* 757 */       return result;
/*     */     }
/* 759 */     StringTokenizer pairs = new StringTokenizer(matrixVariables, ";");
/* 760 */     while (pairs.hasMoreTokens()) {
/* 761 */       String pair = pairs.nextToken();
/* 762 */       int index = pair.indexOf(61);
/* 763 */       if (index != -1) {
/* 764 */         String name = pair.substring(0, index);
/* 765 */         String rawValue = pair.substring(index + 1);
/* 766 */         for (String value : StringUtils.commaDelimitedListToStringArray(rawValue))
/* 767 */           result.add(name, value);
/*     */       }
/*     */       else
/*     */       {
/* 771 */         result.add(pair, "");
/*     */       }
/*     */     }
/* 774 */     return result;
/*     */   }
/*     */ 
/*     */   public static boolean isValidOrigin(HttpRequest request, Collection<String> allowedOrigins)
/*     */   {
/* 786 */     Assert.notNull(request, "Request must not be null");
/* 787 */     Assert.notNull(allowedOrigins, "Allowed origins must not be null");
/*     */ 
/* 789 */     String origin = request.getHeaders().getOrigin();
/* 790 */     if ((origin == null) || (allowedOrigins.contains("*"))) {
/* 791 */       return true;
/*     */     }
/* 793 */     if (allowedOrigins.isEmpty())
/*     */     {
/*     */       try {
/* 796 */         originComponents = UriComponentsBuilder.fromHttpUrl(origin).build();
/*     */       }
/*     */       catch (IllegalArgumentException ex)
/*     */       {
/*     */         UriComponents originComponents;
/* 799 */         if (logger.isWarnEnabled()) {
/* 800 */           logger.warn("Failed to parse Origin header value [" + origin + "]");
/*     */         }
/* 802 */         return false;
/*     */       }
/*     */       UriComponents originComponents;
/* 804 */       UriComponents requestComponents = UriComponentsBuilder.fromHttpRequest(request).build();
/* 805 */       int originPort = getPort(originComponents);
/* 806 */       int requestPort = getPort(requestComponents);
/* 807 */       return (originComponents.getHost().equals(requestComponents.getHost())) && (originPort == requestPort);
/*     */     }
/*     */ 
/* 810 */     return allowedOrigins.contains(origin);
/*     */   }
/*     */ 
/*     */   private static int getPort(UriComponents component)
/*     */   {
/* 815 */     int port = component.getPort();
/* 816 */     if (port == -1) {
/* 817 */       if ("http".equals(component.getScheme())) {
/* 818 */         port = 80;
/*     */       }
/* 820 */       else if ("https".equals(component.getScheme())) {
/* 821 */         port = 443;
/*     */       }
/*     */     }
/* 824 */     return port;
/*     */   }
/*     */ }

/* Location:           E:\kuaisuchudan\maven_libs\org\springframework\spring-web\4.1.6.RELEASE\spring-web-4.1.6.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.WebUtils
 * JD-Core Version:    0.6.2
 */