/*      */ package org.springframework.web.servlet;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.BeanInitializationException;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.i18n.LocaleContext;
/*      */ import org.springframework.core.OrderComparator;
/*      */ import org.springframework.core.io.ClassPathResource;
/*      */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*      */ import org.springframework.http.HttpMethod;
/*      */ import org.springframework.http.server.ServletServerHttpRequest;
/*      */ import org.springframework.ui.context.ThemeSource;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.web.context.WebApplicationContext;
/*      */ import org.springframework.web.context.request.ServletWebRequest;
/*      */ import org.springframework.web.context.request.async.WebAsyncManager;
/*      */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*      */ import org.springframework.web.multipart.MultipartException;
/*      */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*      */ import org.springframework.web.multipart.MultipartResolver;
/*      */ import org.springframework.web.util.NestedServletException;
/*      */ import org.springframework.web.util.UrlPathHelper;
/*      */ import org.springframework.web.util.WebUtils;
/*      */ 
/*      */ public class DispatcherServlet extends FrameworkServlet
/*      */ {
/*      */   public static final String MULTIPART_RESOLVER_BEAN_NAME = "multipartResolver";
/*      */   public static final String LOCALE_RESOLVER_BEAN_NAME = "localeResolver";
/*      */   public static final String THEME_RESOLVER_BEAN_NAME = "themeResolver";
/*      */   public static final String HANDLER_MAPPING_BEAN_NAME = "handlerMapping";
/*      */   public static final String HANDLER_ADAPTER_BEAN_NAME = "handlerAdapter";
/*      */   public static final String HANDLER_EXCEPTION_RESOLVER_BEAN_NAME = "handlerExceptionResolver";
/*      */   public static final String REQUEST_TO_VIEW_NAME_TRANSLATOR_BEAN_NAME = "viewNameTranslator";
/*      */   public static final String VIEW_RESOLVER_BEAN_NAME = "viewResolver";
/*      */   public static final String FLASH_MAP_MANAGER_BEAN_NAME = "flashMapManager";
/*  196 */   public static final String WEB_APPLICATION_CONTEXT_ATTRIBUTE = DispatcherServlet.class.getName() + ".CONTEXT";
/*      */ 
/*  202 */   public static final String LOCALE_RESOLVER_ATTRIBUTE = DispatcherServlet.class.getName() + ".LOCALE_RESOLVER";
/*      */ 
/*  208 */   public static final String THEME_RESOLVER_ATTRIBUTE = DispatcherServlet.class.getName() + ".THEME_RESOLVER";
/*      */ 
/*  214 */   public static final String THEME_SOURCE_ATTRIBUTE = DispatcherServlet.class.getName() + ".THEME_SOURCE";
/*      */ 
/*  221 */   public static final String INPUT_FLASH_MAP_ATTRIBUTE = DispatcherServlet.class.getName() + ".INPUT_FLASH_MAP";
/*      */ 
/*  228 */   public static final String OUTPUT_FLASH_MAP_ATTRIBUTE = DispatcherServlet.class.getName() + ".OUTPUT_FLASH_MAP";
/*      */ 
/*  234 */   public static final String FLASH_MAP_MANAGER_ATTRIBUTE = DispatcherServlet.class.getName() + ".FLASH_MAP_MANAGER";
/*      */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*      */   private static final String DEFAULT_STRATEGIES_PATH = "DispatcherServlet.properties";
/*  247 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*      */ 
/*  249 */   private static final UrlPathHelper urlPathHelper = new UrlPathHelper();
/*      */   private static final Properties defaultStrategies;
/*  267 */   private boolean detectAllHandlerMappings = true;
/*      */ 
/*  270 */   private boolean detectAllHandlerAdapters = true;
/*      */ 
/*  273 */   private boolean detectAllHandlerExceptionResolvers = true;
/*      */ 
/*  276 */   private boolean detectAllViewResolvers = true;
/*      */ 
/*  279 */   private boolean cleanupAfterInclude = true;
/*      */ 
/*  282 */   private boolean throwExceptionIfNoHandlerFound = false;
/*      */   private MultipartResolver multipartResolver;
/*      */   private LocaleResolver localeResolver;
/*      */   private ThemeResolver themeResolver;
/*      */   private List<HandlerMapping> handlerMappings;
/*      */   private List<HandlerAdapter> handlerAdapters;
/*      */   private List<HandlerExceptionResolver> handlerExceptionResolvers;
/*      */   private RequestToViewNameTranslator viewNameTranslator;
/*      */   private FlashMapManager flashMapManager;
/*      */   private List<ViewResolver> viewResolvers;
/*      */ 
/*      */   public DispatcherServlet()
/*      */   {
/*      */   }
/*      */ 
/*      */   public DispatcherServlet(WebApplicationContext webApplicationContext)
/*      */   {
/*  372 */     super(webApplicationContext);
/*      */   }
/*      */ 
/*      */   public void setDetectAllHandlerMappings(boolean detectAllHandlerMappings)
/*      */   {
/*  382 */     this.detectAllHandlerMappings = detectAllHandlerMappings;
/*      */   }
/*      */ 
/*      */   public void setDetectAllHandlerAdapters(boolean detectAllHandlerAdapters)
/*      */   {
/*  392 */     this.detectAllHandlerAdapters = detectAllHandlerAdapters;
/*      */   }
/*      */ 
/*      */   public void setDetectAllHandlerExceptionResolvers(boolean detectAllHandlerExceptionResolvers)
/*      */   {
/*  402 */     this.detectAllHandlerExceptionResolvers = detectAllHandlerExceptionResolvers;
/*      */   }
/*      */ 
/*      */   public void setDetectAllViewResolvers(boolean detectAllViewResolvers)
/*      */   {
/*  412 */     this.detectAllViewResolvers = detectAllViewResolvers;
/*      */   }
/*      */ 
/*      */   public void setThrowExceptionIfNoHandlerFound(boolean throwExceptionIfNoHandlerFound)
/*      */   {
/*  428 */     this.throwExceptionIfNoHandlerFound = throwExceptionIfNoHandlerFound;
/*      */   }
/*      */ 
/*      */   public void setCleanupAfterInclude(boolean cleanupAfterInclude)
/*      */   {
/*  444 */     this.cleanupAfterInclude = cleanupAfterInclude;
/*      */   }
/*      */ 
/*      */   protected void onRefresh(ApplicationContext context)
/*      */   {
/*  452 */     initStrategies(context);
/*      */   }
/*      */ 
/*      */   protected void initStrategies(ApplicationContext context)
/*      */   {
/*  460 */     initMultipartResolver(context);
/*  461 */     initLocaleResolver(context);
/*  462 */     initThemeResolver(context);
/*  463 */     initHandlerMappings(context);
/*  464 */     initHandlerAdapters(context);
/*  465 */     initHandlerExceptionResolvers(context);
/*  466 */     initRequestToViewNameTranslator(context);
/*  467 */     initViewResolvers(context);
/*  468 */     initFlashMapManager(context);
/*      */   }
/*      */ 
/*      */   private void initMultipartResolver(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  478 */       this.multipartResolver = ((MultipartResolver)context.getBean("multipartResolver", MultipartResolver.class));
/*  479 */       if (this.logger.isDebugEnabled()) {
/*  480 */         this.logger.debug("Using MultipartResolver [" + this.multipartResolver + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  485 */       this.multipartResolver = null;
/*  486 */       if (this.logger.isDebugEnabled())
/*  487 */         this.logger.debug("Unable to locate MultipartResolver with name 'multipartResolver': no multipart request handling provided");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initLocaleResolver(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  500 */       this.localeResolver = ((LocaleResolver)context.getBean("localeResolver", LocaleResolver.class));
/*  501 */       if (this.logger.isDebugEnabled()) {
/*  502 */         this.logger.debug("Using LocaleResolver [" + this.localeResolver + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  507 */       this.localeResolver = ((LocaleResolver)getDefaultStrategy(context, LocaleResolver.class));
/*  508 */       if (this.logger.isDebugEnabled())
/*  509 */         this.logger.debug("Unable to locate LocaleResolver with name 'localeResolver': using default [" + this.localeResolver + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initThemeResolver(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  522 */       this.themeResolver = ((ThemeResolver)context.getBean("themeResolver", ThemeResolver.class));
/*  523 */       if (this.logger.isDebugEnabled()) {
/*  524 */         this.logger.debug("Using ThemeResolver [" + this.themeResolver + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  529 */       this.themeResolver = ((ThemeResolver)getDefaultStrategy(context, ThemeResolver.class));
/*  530 */       if (this.logger.isDebugEnabled())
/*  531 */         this.logger.debug("Unable to locate ThemeResolver with name 'themeResolver': using default [" + this.themeResolver + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initHandlerMappings(ApplicationContext context)
/*      */   {
/*  544 */     this.handlerMappings = null;
/*      */ 
/*  546 */     if (this.detectAllHandlerMappings)
/*      */     {
/*  549 */       Map matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, HandlerMapping.class, true, false);
/*      */ 
/*  550 */       if (!matchingBeans.isEmpty()) {
/*  551 */         this.handlerMappings = new ArrayList(matchingBeans.values());
/*      */ 
/*  553 */         OrderComparator.sort(this.handlerMappings);
/*      */       }
/*      */     }
/*      */     else {
/*      */       try {
/*  558 */         HandlerMapping hm = (HandlerMapping)context.getBean("handlerMapping", HandlerMapping.class);
/*  559 */         this.handlerMappings = Collections.singletonList(hm);
/*      */       }
/*      */       catch (NoSuchBeanDefinitionException ex)
/*      */       {
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  568 */     if (this.handlerMappings == null) {
/*  569 */       this.handlerMappings = getDefaultStrategies(context, HandlerMapping.class);
/*  570 */       if (this.logger.isDebugEnabled())
/*  571 */         this.logger.debug("No HandlerMappings found in servlet '" + getServletName() + "': using default");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initHandlerAdapters(ApplicationContext context)
/*      */   {
/*  582 */     this.handlerAdapters = null;
/*      */ 
/*  584 */     if (this.detectAllHandlerAdapters)
/*      */     {
/*  587 */       Map matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, HandlerAdapter.class, true, false);
/*      */ 
/*  588 */       if (!matchingBeans.isEmpty()) {
/*  589 */         this.handlerAdapters = new ArrayList(matchingBeans.values());
/*      */ 
/*  591 */         OrderComparator.sort(this.handlerAdapters);
/*      */       }
/*      */     }
/*      */     else {
/*      */       try {
/*  596 */         HandlerAdapter ha = (HandlerAdapter)context.getBean("handlerAdapter", HandlerAdapter.class);
/*  597 */         this.handlerAdapters = Collections.singletonList(ha);
/*      */       }
/*      */       catch (NoSuchBeanDefinitionException ex)
/*      */       {
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  606 */     if (this.handlerAdapters == null) {
/*  607 */       this.handlerAdapters = getDefaultStrategies(context, HandlerAdapter.class);
/*  608 */       if (this.logger.isDebugEnabled())
/*  609 */         this.logger.debug("No HandlerAdapters found in servlet '" + getServletName() + "': using default");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initHandlerExceptionResolvers(ApplicationContext context)
/*      */   {
/*  620 */     this.handlerExceptionResolvers = null;
/*      */ 
/*  622 */     if (this.detectAllHandlerExceptionResolvers)
/*      */     {
/*  625 */       Map matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, HandlerExceptionResolver.class, true, false);
/*      */ 
/*  626 */       if (!matchingBeans.isEmpty()) {
/*  627 */         this.handlerExceptionResolvers = new ArrayList(matchingBeans.values());
/*      */ 
/*  629 */         OrderComparator.sort(this.handlerExceptionResolvers);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*      */       try {
/*  635 */         HandlerExceptionResolver her = (HandlerExceptionResolver)context
/*  635 */           .getBean("handlerExceptionResolver", HandlerExceptionResolver.class);
/*      */ 
/*  636 */         this.handlerExceptionResolvers = Collections.singletonList(her);
/*      */       }
/*      */       catch (NoSuchBeanDefinitionException ex)
/*      */       {
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  645 */     if (this.handlerExceptionResolvers == null) {
/*  646 */       this.handlerExceptionResolvers = getDefaultStrategies(context, HandlerExceptionResolver.class);
/*  647 */       if (this.logger.isDebugEnabled())
/*  648 */         this.logger.debug("No HandlerExceptionResolvers found in servlet '" + getServletName() + "': using default");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initRequestToViewNameTranslator(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  659 */       this.viewNameTranslator = 
/*  660 */         ((RequestToViewNameTranslator)context
/*  660 */         .getBean("viewNameTranslator", RequestToViewNameTranslator.class));
/*      */ 
/*  661 */       if (this.logger.isDebugEnabled()) {
/*  662 */         this.logger.debug("Using RequestToViewNameTranslator [" + this.viewNameTranslator + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  667 */       this.viewNameTranslator = ((RequestToViewNameTranslator)getDefaultStrategy(context, RequestToViewNameTranslator.class));
/*  668 */       if (this.logger.isDebugEnabled())
/*  669 */         this.logger.debug("Unable to locate RequestToViewNameTranslator with name 'viewNameTranslator': using default [" + this.viewNameTranslator + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initViewResolvers(ApplicationContext context)
/*      */   {
/*  682 */     this.viewResolvers = null;
/*      */ 
/*  684 */     if (this.detectAllViewResolvers)
/*      */     {
/*  687 */       Map matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(context, ViewResolver.class, true, false);
/*      */ 
/*  688 */       if (!matchingBeans.isEmpty()) {
/*  689 */         this.viewResolvers = new ArrayList(matchingBeans.values());
/*      */ 
/*  691 */         OrderComparator.sort(this.viewResolvers);
/*      */       }
/*      */     }
/*      */     else {
/*      */       try {
/*  696 */         ViewResolver vr = (ViewResolver)context.getBean("viewResolver", ViewResolver.class);
/*  697 */         this.viewResolvers = Collections.singletonList(vr);
/*      */       }
/*      */       catch (NoSuchBeanDefinitionException ex)
/*      */       {
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  706 */     if (this.viewResolvers == null) {
/*  707 */       this.viewResolvers = getDefaultStrategies(context, ViewResolver.class);
/*  708 */       if (this.logger.isDebugEnabled())
/*  709 */         this.logger.debug("No ViewResolvers found in servlet '" + getServletName() + "': using default");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initFlashMapManager(ApplicationContext context)
/*      */   {
/*      */     try
/*      */     {
/*  721 */       this.flashMapManager = 
/*  722 */         ((FlashMapManager)context
/*  722 */         .getBean("flashMapManager", FlashMapManager.class));
/*      */ 
/*  723 */       if (this.logger.isDebugEnabled()) {
/*  724 */         this.logger.debug("Using FlashMapManager [" + this.flashMapManager + "]");
/*      */       }
/*      */     }
/*      */     catch (NoSuchBeanDefinitionException ex)
/*      */     {
/*  729 */       this.flashMapManager = ((FlashMapManager)getDefaultStrategy(context, FlashMapManager.class));
/*  730 */       if (this.logger.isDebugEnabled())
/*  731 */         this.logger.debug("Unable to locate FlashMapManager with name 'flashMapManager': using default [" + this.flashMapManager + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   public final ThemeSource getThemeSource()
/*      */   {
/*  745 */     if ((getWebApplicationContext() instanceof ThemeSource)) {
/*  746 */       return (ThemeSource)getWebApplicationContext();
/*      */     }
/*      */ 
/*  749 */     return null;
/*      */   }
/*      */ 
/*      */   public final MultipartResolver getMultipartResolver()
/*      */   {
/*  759 */     return this.multipartResolver;
/*      */   }
/*      */ 
/*      */   protected <T> T getDefaultStrategy(ApplicationContext context, Class<T> strategyInterface)
/*      */   {
/*  772 */     List strategies = getDefaultStrategies(context, strategyInterface);
/*  773 */     if (strategies.size() != 1)
/*      */     {
/*  775 */       throw new BeanInitializationException("DispatcherServlet needs exactly 1 strategy for interface [" + strategyInterface
/*  775 */         .getName() + "]");
/*      */     }
/*  777 */     return strategies.get(0);
/*      */   }
/*      */ 
/*      */   protected <T> List<T> getDefaultStrategies(ApplicationContext context, Class<T> strategyInterface)
/*      */   {
/*  791 */     String key = strategyInterface.getName();
/*  792 */     String value = defaultStrategies.getProperty(key);
/*  793 */     if (value != null) {
/*  794 */       String[] classNames = StringUtils.commaDelimitedListToStringArray(value);
/*  795 */       List strategies = new ArrayList(classNames.length);
/*  796 */       for (String className : classNames) {
/*      */         try {
/*  798 */           Class clazz = ClassUtils.forName(className, DispatcherServlet.class.getClassLoader());
/*  799 */           Object strategy = createDefaultStrategy(context, clazz);
/*  800 */           strategies.add(strategy);
/*      */         }
/*      */         catch (ClassNotFoundException ex) {
/*  803 */           throw new BeanInitializationException("Could not find DispatcherServlet's default strategy class [" + className + "] for interface [" + key + "]", ex);
/*      */         }
/*      */         catch (LinkageError err)
/*      */         {
/*  808 */           throw new BeanInitializationException("Error loading DispatcherServlet's default strategy class [" + className + "] for interface [" + key + "]: problem with class file or dependent class", err);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  813 */       return strategies;
/*      */     }
/*      */ 
/*  816 */     return new LinkedList();
/*      */   }
/*      */ 
/*      */   protected Object createDefaultStrategy(ApplicationContext context, Class<?> clazz)
/*      */   {
/*  830 */     return context.getAutowireCapableBeanFactory().createBean(clazz);
/*      */   }
/*      */ 
/*      */   protected void doService(HttpServletRequest request, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/*  840 */     if (this.logger.isDebugEnabled()) {
/*  841 */       String requestUri = urlPathHelper.getRequestUri(request);
/*  842 */       String resumed = WebAsyncUtils.getAsyncManager(request).hasConcurrentResult() ? " resumed" : "";
/*  843 */       this.logger.debug("DispatcherServlet with name '" + getServletName() + "'" + resumed + " processing " + request
/*  844 */         .getMethod() + " request for [" + requestUri + "]");
/*      */     }
/*      */ 
/*  849 */     Map attributesSnapshot = null;
/*  850 */     if (WebUtils.isIncludeRequest(request)) {
/*  851 */       this.logger.debug("Taking snapshot of request attributes before include");
/*  852 */       attributesSnapshot = new HashMap();
/*  853 */       Enumeration attrNames = request.getAttributeNames();
/*  854 */       while (attrNames.hasMoreElements()) {
/*  855 */         String attrName = (String)attrNames.nextElement();
/*  856 */         if ((this.cleanupAfterInclude) || (attrName.startsWith("org.springframework.web.servlet"))) {
/*  857 */           attributesSnapshot.put(attrName, request.getAttribute(attrName));
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  863 */     request.setAttribute(WEB_APPLICATION_CONTEXT_ATTRIBUTE, getWebApplicationContext());
/*  864 */     request.setAttribute(LOCALE_RESOLVER_ATTRIBUTE, this.localeResolver);
/*  865 */     request.setAttribute(THEME_RESOLVER_ATTRIBUTE, this.themeResolver);
/*  866 */     request.setAttribute(THEME_SOURCE_ATTRIBUTE, getThemeSource());
/*      */ 
/*  868 */     FlashMap inputFlashMap = this.flashMapManager.retrieveAndUpdate(request, response);
/*  869 */     if (inputFlashMap != null) {
/*  870 */       request.setAttribute(INPUT_FLASH_MAP_ATTRIBUTE, Collections.unmodifiableMap(inputFlashMap));
/*      */     }
/*  872 */     request.setAttribute(OUTPUT_FLASH_MAP_ATTRIBUTE, new FlashMap());
/*  873 */     request.setAttribute(FLASH_MAP_MANAGER_ATTRIBUTE, this.flashMapManager);
/*      */     try
/*      */     {
/*  876 */       doDispatch(request, response);
/*      */     }
/*      */     finally {
/*  879 */       if (WebAsyncUtils.getAsyncManager(request).isConcurrentHandlingStarted()) {
/*  880 */         return;
/*      */       }
/*      */ 
/*  883 */       if (attributesSnapshot != null)
/*  884 */         restoreAttributesAfterInclude(request, attributesSnapshot);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void doDispatch(HttpServletRequest request, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/*  901 */     HttpServletRequest processedRequest = request;
/*  902 */     HandlerExecutionChain mappedHandler = null;
/*  903 */     boolean multipartRequestParsed = false;
/*      */ 
/*  905 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager(request);
/*      */     try
/*      */     {
/*  908 */       ModelAndView mv = null;
/*  909 */       Exception dispatchException = null;
/*      */       try
/*      */       {
/*  912 */         processedRequest = checkMultipart(request);
/*  913 */         multipartRequestParsed = processedRequest != request;
/*      */ 
/*  916 */         mappedHandler = getHandler(processedRequest);
/*  917 */         if ((mappedHandler == null) || (mappedHandler.getHandler() == null)) {
/*  918 */           noHandlerFound(processedRequest, response);
/*  919 */           return;
/*      */         }
/*      */ 
/*  923 */         HandlerAdapter ha = getHandlerAdapter(mappedHandler.getHandler());
/*      */ 
/*  926 */         String method = request.getMethod();
/*  927 */         boolean isGet = "GET".equals(method);
/*  928 */         if ((isGet) || ("HEAD".equals(method))) {
/*  929 */           long lastModified = ha.getLastModified(request, mappedHandler.getHandler());
/*  930 */           if (this.logger.isDebugEnabled()) {
/*  931 */             String requestUri = urlPathHelper.getRequestUri(request);
/*  932 */             this.logger.debug("Last-Modified value for [" + requestUri + "] is: " + lastModified);
/*      */           }
/*  934 */           if ((new ServletWebRequest(request, response).checkNotModified(lastModified)) && (isGet)) {
/*  935 */             return;
/*      */           }
/*      */         }
/*      */ 
/*  939 */         if (!mappedHandler.applyPreHandle(processedRequest, response)) {
/*  940 */           return;
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/*  945 */           mv = ha.handle(processedRequest, response, mappedHandler.getHandler());
/*      */         }
/*      */         finally {
/*  948 */           if (asyncManager.isConcurrentHandlingStarted()) {
/*  949 */             return;
/*      */           }
/*      */         }
/*      */ 
/*  953 */         applyDefaultViewName(request, mv);
/*  954 */         mappedHandler.applyPostHandle(processedRequest, response, mv);
/*      */       }
/*      */       catch (Exception ex) {
/*  957 */         dispatchException = ex;
/*      */       }
/*  959 */       processDispatchResult(processedRequest, response, mappedHandler, mv, dispatchException);
/*      */     }
/*      */     catch (Exception ex) {
/*  962 */       triggerAfterCompletion(processedRequest, response, mappedHandler, ex);
/*      */     }
/*      */     catch (Error err) {
/*  965 */       triggerAfterCompletionWithError(processedRequest, response, mappedHandler, err);
/*      */     }
/*      */     finally {
/*  968 */       if (asyncManager.isConcurrentHandlingStarted())
/*      */       {
/*  970 */         mappedHandler.applyAfterConcurrentHandlingStarted(processedRequest, response);
/*  971 */         return;
/*      */       }
/*      */ 
/*  974 */       if (multipartRequestParsed)
/*  975 */         cleanupMultipart(processedRequest);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void applyDefaultViewName(HttpServletRequest request, ModelAndView mv)
/*      */     throws Exception
/*      */   {
/*  984 */     if ((mv != null) && (!mv.hasView()))
/*  985 */       mv.setViewName(getDefaultViewName(request));
/*      */   }
/*      */ 
/*      */   private void processDispatchResult(HttpServletRequest request, HttpServletResponse response, HandlerExecutionChain mappedHandler, ModelAndView mv, Exception exception)
/*      */     throws Exception
/*      */   {
/*  996 */     boolean errorView = false;
/*      */ 
/*  998 */     if (exception != null) {
/*  999 */       if ((exception instanceof ModelAndViewDefiningException)) {
/* 1000 */         this.logger.debug("ModelAndViewDefiningException encountered", exception);
/* 1001 */         mv = ((ModelAndViewDefiningException)exception).getModelAndView();
/*      */       }
/*      */       else {
/* 1004 */         Object handler = mappedHandler != null ? mappedHandler.getHandler() : null;
/* 1005 */         mv = processHandlerException(request, response, handler, exception);
/* 1006 */         errorView = mv != null;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1011 */     if ((mv != null) && (!mv.wasCleared())) {
/* 1012 */       render(mv, request, response);
/* 1013 */       if (errorView) {
/* 1014 */         WebUtils.clearErrorRequestAttributes(request);
/*      */       }
/*      */ 
/*      */     }
/* 1018 */     else if (this.logger.isDebugEnabled()) {
/* 1019 */       this.logger.debug("Null ModelAndView returned to DispatcherServlet with name '" + getServletName() + "': assuming HandlerAdapter completed request handling");
/*      */     }
/*      */ 
/* 1024 */     if (WebAsyncUtils.getAsyncManager(request).isConcurrentHandlingStarted())
/*      */     {
/* 1026 */       return;
/*      */     }
/*      */ 
/* 1029 */     if (mappedHandler != null)
/* 1030 */       mappedHandler.triggerAfterCompletion(request, response, null);
/*      */   }
/*      */ 
/*      */   protected LocaleContext buildLocaleContext(final HttpServletRequest request)
/*      */   {
/* 1043 */     if ((this.localeResolver instanceof LocaleContextResolver)) {
/* 1044 */       return ((LocaleContextResolver)this.localeResolver).resolveLocaleContext(request);
/*      */     }
/*      */ 
/* 1047 */     return new LocaleContext()
/*      */     {
/*      */       public Locale getLocale() {
/* 1050 */         return DispatcherServlet.this.localeResolver.resolveLocale(request);
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   protected HttpServletRequest checkMultipart(HttpServletRequest request)
/*      */     throws MultipartException
/*      */   {
/* 1064 */     if ((this.multipartResolver != null) && (this.multipartResolver.isMultipart(request))) {
/* 1065 */       if ((request instanceof MultipartHttpServletRequest)) {
/* 1066 */         this.logger.debug("Request is already a MultipartHttpServletRequest - if not in a forward, this typically results from an additional MultipartFilter in web.xml");
/*      */       }
/*      */       else
/*      */       {
/* 1070 */         return this.multipartResolver.resolveMultipart(request);
/*      */       }
/*      */     }
/*      */ 
/* 1074 */     return request;
/*      */   }
/*      */ 
/*      */   protected void cleanupMultipart(HttpServletRequest servletRequest)
/*      */   {
/* 1083 */     MultipartHttpServletRequest req = (MultipartHttpServletRequest)WebUtils.getNativeRequest(servletRequest, MultipartHttpServletRequest.class);
/* 1084 */     if (req != null)
/* 1085 */       this.multipartResolver.cleanupMultipart(req);
/*      */   }
/*      */ 
/*      */   protected HandlerExecutionChain getHandler(HttpServletRequest request)
/*      */     throws Exception
/*      */   {
/* 1096 */     for (HandlerMapping hm : this.handlerMappings) {
/* 1097 */       if (this.logger.isTraceEnabled()) {
/* 1098 */         this.logger.trace("Testing handler map [" + hm + "] in DispatcherServlet with name '" + 
/* 1099 */           getServletName() + "'");
/*      */       }
/* 1101 */       HandlerExecutionChain handler = hm.getHandler(request);
/* 1102 */       if (handler != null) {
/* 1103 */         return handler;
/*      */       }
/*      */     }
/* 1106 */     return null;
/*      */   }
/*      */ 
/*      */   protected void noHandlerFound(HttpServletRequest request, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/* 1116 */     if (pageNotFoundLogger.isWarnEnabled()) {
/* 1117 */       String requestUri = urlPathHelper.getRequestUri(request);
/* 1118 */       pageNotFoundLogger.warn("No mapping found for HTTP request with URI [" + requestUri + "] in DispatcherServlet with name '" + 
/* 1119 */         getServletName() + "'");
/*      */     }
/* 1121 */     if (this.throwExceptionIfNoHandlerFound) {
/* 1122 */       ServletServerHttpRequest req = new ServletServerHttpRequest(request);
/*      */ 
/* 1124 */       throw new NoHandlerFoundException(req.getMethod().name(), req
/* 1124 */         .getServletRequest().getRequestURI(), req.getHeaders());
/*      */     }
/* 1126 */     response.sendError(404);
/*      */   }
/*      */ 
/*      */   protected HandlerAdapter getHandlerAdapter(Object handler)
/*      */     throws ServletException
/*      */   {
/* 1136 */     for (HandlerAdapter ha : this.handlerAdapters) {
/* 1137 */       if (this.logger.isTraceEnabled()) {
/* 1138 */         this.logger.trace("Testing handler adapter [" + ha + "]");
/*      */       }
/* 1140 */       if (ha.supports(handler)) {
/* 1141 */         return ha;
/*      */       }
/*      */     }
/* 1144 */     throw new ServletException("No adapter for handler [" + handler + "]: The DispatcherServlet configuration needs to include a HandlerAdapter that supports this handler");
/*      */   }
/*      */ 
/*      */   protected ModelAndView processHandlerException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*      */     throws Exception
/*      */   {
/* 1162 */     ModelAndView exMv = null;
/* 1163 */     for (HandlerExceptionResolver handlerExceptionResolver : this.handlerExceptionResolvers) {
/* 1164 */       exMv = handlerExceptionResolver.resolveException(request, response, handler, ex);
/* 1165 */       if (exMv != null) {
/*      */         break;
/*      */       }
/*      */     }
/* 1169 */     if (exMv != null) {
/* 1170 */       if (exMv.isEmpty()) {
/* 1171 */         return null;
/*      */       }
/*      */ 
/* 1174 */       if (!exMv.hasView()) {
/* 1175 */         exMv.setViewName(getDefaultViewName(request));
/*      */       }
/* 1177 */       if (this.logger.isDebugEnabled()) {
/* 1178 */         this.logger.debug("Handler execution resulted in exception - forwarding to resolved error view: " + exMv, ex);
/*      */       }
/* 1180 */       WebUtils.exposeErrorRequestAttributes(request, ex, getServletName());
/* 1181 */       return exMv;
/*      */     }
/*      */ 
/* 1184 */     throw ex;
/*      */   }
/*      */ 
/*      */   protected void render(ModelAndView mv, HttpServletRequest request, HttpServletResponse response)
/*      */     throws Exception
/*      */   {
/* 1198 */     Locale locale = this.localeResolver.resolveLocale(request);
/* 1199 */     response.setLocale(locale);
/*      */     View view;
/* 1202 */     if (mv.isReference())
/*      */     {
/* 1204 */       View view = resolveViewName(mv.getViewName(), mv.getModelInternal(), locale, request);
/* 1205 */       if (view == null)
/*      */       {
/* 1208 */         throw new ServletException("Could not resolve view with name '" + mv
/* 1207 */           .getViewName() + "' in servlet with name '" + 
/* 1208 */           getServletName() + "'");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1213 */       view = mv.getView();
/* 1214 */       if (view == null)
/*      */       {
/* 1216 */         throw new ServletException("ModelAndView [" + mv + "] neither contains a view name nor a " + "View object in servlet with name '" + 
/* 1216 */           getServletName() + "'");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1221 */     if (this.logger.isDebugEnabled())
/* 1222 */       this.logger.debug("Rendering view [" + view + "] in DispatcherServlet with name '" + getServletName() + "'");
/*      */     try
/*      */     {
/* 1225 */       view.render(mv.getModelInternal(), request, response);
/*      */     }
/*      */     catch (Exception ex) {
/* 1228 */       if (this.logger.isDebugEnabled()) {
/* 1229 */         this.logger.debug("Error rendering view [" + view + "] in DispatcherServlet with name '" + 
/* 1230 */           getServletName() + "'", ex);
/*      */       }
/* 1232 */       throw ex;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected String getDefaultViewName(HttpServletRequest request)
/*      */     throws Exception
/*      */   {
/* 1243 */     return this.viewNameTranslator.getViewName(request);
/*      */   }
/*      */ 
/*      */   protected View resolveViewName(String viewName, Map<String, Object> model, Locale locale, HttpServletRequest request)
/*      */     throws Exception
/*      */   {
/* 1263 */     for (ViewResolver viewResolver : this.viewResolvers) {
/* 1264 */       View view = viewResolver.resolveViewName(viewName, locale);
/* 1265 */       if (view != null) {
/* 1266 */         return view;
/*      */       }
/*      */     }
/* 1269 */     return null;
/*      */   }
/*      */ 
/*      */   private void triggerAfterCompletion(HttpServletRequest request, HttpServletResponse response, HandlerExecutionChain mappedHandler, Exception ex)
/*      */     throws Exception
/*      */   {
/* 1275 */     if (mappedHandler != null) {
/* 1276 */       mappedHandler.triggerAfterCompletion(request, response, ex);
/*      */     }
/* 1278 */     throw ex;
/*      */   }
/*      */ 
/*      */   private void triggerAfterCompletionWithError(HttpServletRequest request, HttpServletResponse response, HandlerExecutionChain mappedHandler, Error error)
/*      */     throws Exception, ServletException
/*      */   {
/* 1284 */     ServletException ex = new NestedServletException("Handler processing failed", error);
/* 1285 */     if (mappedHandler != null) {
/* 1286 */       mappedHandler.triggerAfterCompletion(request, response, ex);
/*      */     }
/* 1288 */     throw ex;
/*      */   }
/*      */ 
/*      */   private void restoreAttributesAfterInclude(HttpServletRequest request, Map<?, ?> attributesSnapshot)
/*      */   {
/* 1298 */     this.logger.debug("Restoring snapshot of request attributes after include");
/*      */ 
/* 1302 */     Set attrsToCheck = new HashSet();
/* 1303 */     Enumeration attrNames = request.getAttributeNames();
/*      */     String attrName;
/* 1304 */     while (attrNames.hasMoreElements()) {
/* 1305 */       attrName = (String)attrNames.nextElement();
/* 1306 */       if ((this.cleanupAfterInclude) || (attrName.startsWith("org.springframework.web.servlet"))) {
/* 1307 */         attrsToCheck.add(attrName);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1312 */     attrsToCheck.addAll(attributesSnapshot.keySet());
/*      */ 
/* 1316 */     for (String attrName : attrsToCheck) {
/* 1317 */       Object attrValue = attributesSnapshot.get(attrName);
/* 1318 */       if (attrValue == null) {
/* 1319 */         if (this.logger.isDebugEnabled()) {
/* 1320 */           this.logger.debug("Removing attribute [" + attrName + "] after include");
/*      */         }
/* 1322 */         request.removeAttribute(attrName);
/*      */       }
/* 1324 */       else if (attrValue != request.getAttribute(attrName)) {
/* 1325 */         if (this.logger.isDebugEnabled()) {
/* 1326 */           this.logger.debug("Restoring original value of attribute [" + attrName + "] after include");
/*      */         }
/* 1328 */         request.setAttribute(attrName, attrValue);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*  258 */       ClassPathResource resource = new ClassPathResource("DispatcherServlet.properties", DispatcherServlet.class);
/*  259 */       defaultStrategies = PropertiesLoaderUtils.loadProperties(resource);
/*      */     }
/*      */     catch (IOException ex) {
/*  262 */       throw new IllegalStateException("Could not load 'DispatcherServlet.properties': " + ex.getMessage());
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.DispatcherServlet
 * JD-Core Version:    0.6.2
 */