/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public final class FlashMap extends HashMap<String, Object>
/*     */   implements Comparable<FlashMap>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String targetRequestPath;
/*  54 */   private final MultiValueMap<String, String> targetRequestParams = new LinkedMultiValueMap();
/*     */   private long expirationStartTime;
/*     */   private int timeToLive;
/*     */ 
/*     */   public void setTargetRequestPath(String path)
/*     */   {
/*  67 */     this.targetRequestPath = path;
/*     */   }
/*     */ 
/*     */   public String getTargetRequestPath()
/*     */   {
/*  74 */     return this.targetRequestPath;
/*     */   }
/*     */ 
/*     */   public FlashMap addTargetRequestParams(MultiValueMap<String, String> params)
/*     */   {
/*     */     Iterator localIterator1;
/*  82 */     if (params != null)
/*  83 */       for (localIterator1 = params.keySet().iterator(); localIterator1.hasNext(); ) { key = (String)localIterator1.next();
/*  84 */         for (String value : (List)params.get(key))
/*  85 */           addTargetRequestParam(key, value);
/*     */       }
/*     */     String key;
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   public FlashMap addTargetRequestParam(String name, String value)
/*     */   {
/*  98 */     if ((StringUtils.hasText(name)) && (StringUtils.hasText(value))) {
/*  99 */       this.targetRequestParams.add(name, value);
/*     */     }
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, String> getTargetRequestParams()
/*     */   {
/* 108 */     return this.targetRequestParams;
/*     */   }
/*     */ 
/*     */   public void startExpirationPeriod(int timeToLive)
/*     */   {
/* 116 */     this.expirationStartTime = System.currentTimeMillis();
/* 117 */     this.timeToLive = timeToLive;
/*     */   }
/*     */ 
/*     */   public boolean isExpired()
/*     */   {
/* 125 */     if (this.expirationStartTime != 0L) {
/* 126 */       return System.currentTimeMillis() - this.expirationStartTime > this.timeToLive * 1000;
/*     */     }
/*     */ 
/* 129 */     return false;
/*     */   }
/*     */ 
/*     */   public int compareTo(FlashMap other)
/*     */   {
/* 140 */     int thisUrlPath = this.targetRequestPath != null ? 1 : 0;
/* 141 */     int otherUrlPath = other.targetRequestPath != null ? 1 : 0;
/* 142 */     if (thisUrlPath != otherUrlPath) {
/* 143 */       return otherUrlPath - thisUrlPath;
/*     */     }
/*     */ 
/* 146 */     return other.targetRequestParams.size() - this.targetRequestParams.size();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 152 */     StringBuilder sb = new StringBuilder();
/* 153 */     sb.append("[Attributes=").append(super.toString());
/* 154 */     sb.append(", targetRequestPath=").append(this.targetRequestPath);
/* 155 */     sb.append(", targetRequestParams=").append(this.targetRequestParams).append("]");
/* 156 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.FlashMap
 * JD-Core Version:    0.6.2
 */