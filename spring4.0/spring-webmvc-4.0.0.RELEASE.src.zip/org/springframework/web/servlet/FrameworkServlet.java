/*      */ package org.springframework.web.servlet;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.security.Principal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.concurrent.Callable;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpServletResponseWrapper;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.context.ApplicationContextException;
/*      */ import org.springframework.context.ApplicationContextInitializer;
/*      */ import org.springframework.context.ApplicationListener;
/*      */ import org.springframework.context.ConfigurableApplicationContext;
/*      */ import org.springframework.context.event.ContextRefreshedEvent;
/*      */ import org.springframework.context.event.SourceFilteringListener;
/*      */ import org.springframework.context.i18n.LocaleContext;
/*      */ import org.springframework.context.i18n.LocaleContextHolder;
/*      */ import org.springframework.context.i18n.SimpleLocaleContext;
/*      */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*      */ import org.springframework.core.env.ConfigurableEnvironment;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.web.bind.annotation.RequestMethod;
/*      */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*      */ import org.springframework.web.context.ConfigurableWebEnvironment;
/*      */ import org.springframework.web.context.WebApplicationContext;
/*      */ import org.springframework.web.context.request.NativeWebRequest;
/*      */ import org.springframework.web.context.request.RequestAttributes;
/*      */ import org.springframework.web.context.request.RequestContextHolder;
/*      */ import org.springframework.web.context.request.ServletRequestAttributes;
/*      */ import org.springframework.web.context.request.async.CallableProcessingInterceptorAdapter;
/*      */ import org.springframework.web.context.request.async.WebAsyncManager;
/*      */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*      */ import org.springframework.web.context.support.ServletRequestHandledEvent;
/*      */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*      */ import org.springframework.web.context.support.XmlWebApplicationContext;
/*      */ import org.springframework.web.util.NestedServletException;
/*      */ import org.springframework.web.util.WebUtils;
/*      */ 
/*      */ public abstract class FrameworkServlet extends HttpServletBean
/*      */   implements ApplicationContextAware
/*      */ {
/*      */   public static final String DEFAULT_NAMESPACE_SUFFIX = "-servlet";
/*  148 */   public static final Class<?> DEFAULT_CONTEXT_CLASS = XmlWebApplicationContext.class;
/*      */ 
/*  154 */   public static final String SERVLET_CONTEXT_PREFIX = FrameworkServlet.class.getName() + ".CONTEXT.";
/*      */   private static final String INIT_PARAM_DELIMITERS = ",; \t\n";
/*      */   private String contextAttribute;
/*  167 */   private Class<?> contextClass = DEFAULT_CONTEXT_CLASS;
/*      */   private String contextId;
/*      */   private String namespace;
/*      */   private String contextConfigLocation;
/*  179 */   private boolean publishContext = true;
/*      */ 
/*  182 */   private boolean publishEvents = true;
/*      */ 
/*  185 */   private boolean threadContextInheritable = false;
/*      */ 
/*  188 */   private boolean dispatchOptionsRequest = false;
/*      */ 
/*  191 */   private boolean dispatchTraceRequest = false;
/*      */   private WebApplicationContext webApplicationContext;
/*  197 */   private boolean webApplicationContextInjected = false;
/*      */ 
/*  200 */   private boolean refreshEventReceived = false;
/*      */   private String contextInitializerClasses;
/*  206 */   private ArrayList<ApplicationContextInitializer<ConfigurableApplicationContext>> contextInitializers = new ArrayList();
/*      */ 
/*      */   public FrameworkServlet()
/*      */   {
/*      */   }
/*      */ 
/*      */   public FrameworkServlet(WebApplicationContext webApplicationContext)
/*      */   {
/*  271 */     this.webApplicationContext = webApplicationContext;
/*      */   }
/*      */ 
/*      */   public void setContextAttribute(String contextAttribute)
/*      */   {
/*  280 */     this.contextAttribute = contextAttribute;
/*      */   }
/*      */ 
/*      */   public String getContextAttribute()
/*      */   {
/*  288 */     return this.contextAttribute;
/*      */   }
/*      */ 
/*      */   public void setContextClass(Class<?> contextClass)
/*      */   {
/*  301 */     this.contextClass = contextClass;
/*      */   }
/*      */ 
/*      */   public Class<?> getContextClass()
/*      */   {
/*  308 */     return this.contextClass;
/*      */   }
/*      */ 
/*      */   public void setContextId(String contextId)
/*      */   {
/*  316 */     this.contextId = contextId;
/*      */   }
/*      */ 
/*      */   public String getContextId()
/*      */   {
/*  323 */     return this.contextId;
/*      */   }
/*      */ 
/*      */   public void setNamespace(String namespace)
/*      */   {
/*  331 */     this.namespace = namespace;
/*      */   }
/*      */ 
/*      */   public String getNamespace()
/*      */   {
/*  339 */     return getServletName() + "-servlet";
/*      */   }
/*      */ 
/*      */   public void setContextInitializerClasses(String contextInitializerClasses)
/*      */   {
/*  349 */     this.contextInitializerClasses = contextInitializerClasses;
/*      */   }
/*      */ 
/*      */   public void setContextInitializers(ApplicationContextInitializer<ConfigurableApplicationContext>[] contextInitializers)
/*      */   {
/*  360 */     for (ApplicationContextInitializer initializer : contextInitializers)
/*  361 */       this.contextInitializers.add(initializer);
/*      */   }
/*      */ 
/*      */   public void setContextConfigLocation(String contextConfigLocation)
/*      */   {
/*  371 */     this.contextConfigLocation = contextConfigLocation;
/*      */   }
/*      */ 
/*      */   public String getContextConfigLocation()
/*      */   {
/*  378 */     return this.contextConfigLocation;
/*      */   }
/*      */ 
/*      */   public void setPublishContext(boolean publishContext)
/*      */   {
/*  388 */     this.publishContext = publishContext;
/*      */   }
/*      */ 
/*      */   public void setPublishEvents(boolean publishEvents)
/*      */   {
/*  398 */     this.publishEvents = publishEvents;
/*      */   }
/*      */ 
/*      */   public void setThreadContextInheritable(boolean threadContextInheritable)
/*      */   {
/*  414 */     this.threadContextInheritable = threadContextInheritable;
/*      */   }
/*      */ 
/*      */   public void setDispatchOptionsRequest(boolean dispatchOptionsRequest)
/*      */   {
/*  432 */     this.dispatchOptionsRequest = dispatchOptionsRequest;
/*      */   }
/*      */ 
/*      */   public void setDispatchTraceRequest(boolean dispatchTraceRequest)
/*      */   {
/*  449 */     this.dispatchTraceRequest = dispatchTraceRequest;
/*      */   }
/*      */ 
/*      */   protected final void initServletBean()
/*      */     throws ServletException
/*      */   {
/*  459 */     getServletContext().log("Initializing Spring FrameworkServlet '" + getServletName() + "'");
/*  460 */     if (this.logger.isInfoEnabled()) {
/*  461 */       this.logger.info("FrameworkServlet '" + getServletName() + "': initialization started");
/*      */     }
/*  463 */     long startTime = System.currentTimeMillis();
/*      */     try
/*      */     {
/*  466 */       this.webApplicationContext = initWebApplicationContext();
/*  467 */       initFrameworkServlet();
/*      */     }
/*      */     catch (ServletException ex) {
/*  470 */       this.logger.error("Context initialization failed", ex);
/*  471 */       throw ex;
/*      */     }
/*      */     catch (RuntimeException ex) {
/*  474 */       this.logger.error("Context initialization failed", ex);
/*  475 */       throw ex;
/*      */     }
/*      */ 
/*  478 */     if (this.logger.isInfoEnabled()) {
/*  479 */       long elapsedTime = System.currentTimeMillis() - startTime;
/*  480 */       this.logger.info("FrameworkServlet '" + getServletName() + "': initialization completed in " + elapsedTime + " ms");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected WebApplicationContext initWebApplicationContext()
/*      */   {
/*  496 */     WebApplicationContext rootContext = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
/*  497 */     WebApplicationContext wac = null;
/*      */ 
/*  499 */     if (this.webApplicationContext != null)
/*      */     {
/*  501 */       wac = this.webApplicationContext;
/*  502 */       if ((wac instanceof ConfigurableWebApplicationContext)) {
/*  503 */         ConfigurableWebApplicationContext cwac = (ConfigurableWebApplicationContext)wac;
/*  504 */         if (!cwac.isActive())
/*      */         {
/*  507 */           if (cwac.getParent() == null)
/*      */           {
/*  510 */             cwac.setParent(rootContext);
/*      */           }
/*  512 */           configureAndRefreshWebApplicationContext(cwac);
/*      */         }
/*      */       }
/*      */     }
/*  516 */     if (wac == null)
/*      */     {
/*  521 */       wac = findWebApplicationContext();
/*      */     }
/*  523 */     if (wac == null)
/*      */     {
/*  525 */       wac = createWebApplicationContext(rootContext);
/*      */     }
/*      */ 
/*  528 */     if (!this.refreshEventReceived)
/*      */     {
/*  532 */       onRefresh(wac);
/*      */     }
/*      */ 
/*  535 */     if (this.publishContext)
/*      */     {
/*  537 */       String attrName = getServletContextAttributeName();
/*  538 */       getServletContext().setAttribute(attrName, wac);
/*  539 */       if (this.logger.isDebugEnabled()) {
/*  540 */         this.logger.debug("Published WebApplicationContext of servlet '" + getServletName() + "' as ServletContext attribute with name [" + attrName + "]");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  545 */     return wac;
/*      */   }
/*      */ 
/*      */   protected WebApplicationContext findWebApplicationContext()
/*      */   {
/*  559 */     String attrName = getContextAttribute();
/*  560 */     if (attrName == null) {
/*  561 */       return null;
/*      */     }
/*      */ 
/*  564 */     WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(getServletContext(), attrName);
/*  565 */     if (wac == null) {
/*  566 */       throw new IllegalStateException("No WebApplicationContext found: initializer not registered?");
/*      */     }
/*  568 */     return wac;
/*      */   }
/*      */ 
/*      */   protected WebApplicationContext createWebApplicationContext(ApplicationContext parent)
/*      */   {
/*  587 */     Class contextClass = getContextClass();
/*  588 */     if (this.logger.isDebugEnabled()) {
/*  589 */       this.logger.debug("Servlet with name '" + getServletName() + "' will try to create custom WebApplicationContext context of class '" + contextClass
/*  591 */         .getName() + "'" + ", using parent context [" + parent + "]");
/*      */     }
/*  593 */     if (!ConfigurableWebApplicationContext.class.isAssignableFrom(contextClass))
/*      */     {
/*  596 */       throw new ApplicationContextException("Fatal initialization error in servlet with name '" + 
/*  595 */         getServletName() + "': custom WebApplicationContext class [" + contextClass
/*  596 */         .getName() + "] is not of type ConfigurableWebApplicationContext");
/*      */     }
/*      */ 
/*  600 */     ConfigurableWebApplicationContext wac = (ConfigurableWebApplicationContext)BeanUtils.instantiateClass(contextClass);
/*      */ 
/*  602 */     wac.setEnvironment(getEnvironment());
/*  603 */     wac.setParent(parent);
/*  604 */     wac.setConfigLocation(getContextConfigLocation());
/*      */ 
/*  606 */     configureAndRefreshWebApplicationContext(wac);
/*      */ 
/*  608 */     return wac;
/*      */   }
/*      */ 
/*      */   protected void configureAndRefreshWebApplicationContext(ConfigurableWebApplicationContext wac) {
/*  612 */     if (ObjectUtils.identityToString(wac).equals(wac.getId()))
/*      */     {
/*  615 */       if (this.contextId != null) {
/*  616 */         wac.setId(this.contextId);
/*      */       }
/*      */       else
/*      */       {
/*  620 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + 
/*  621 */           ObjectUtils.getDisplayString(getServletContext().getContextPath()) + "/" + getServletName());
/*      */       }
/*      */     }
/*      */ 
/*  625 */     wac.setServletContext(getServletContext());
/*  626 */     wac.setServletConfig(getServletConfig());
/*  627 */     wac.setNamespace(getNamespace());
/*  628 */     wac.addApplicationListener(new SourceFilteringListener(wac, new ContextRefreshListener(null)));
/*      */ 
/*  634 */     ConfigurableEnvironment env = wac.getEnvironment();
/*  635 */     if ((env instanceof ConfigurableWebEnvironment)) {
/*  636 */       ((ConfigurableWebEnvironment)env).initPropertySources(getServletContext(), getServletConfig());
/*      */     }
/*      */ 
/*  639 */     postProcessWebApplicationContext(wac);
/*      */ 
/*  641 */     applyInitializers(wac);
/*      */ 
/*  643 */     wac.refresh();
/*      */   }
/*      */ 
/*      */   protected WebApplicationContext createWebApplicationContext(WebApplicationContext parent)
/*      */   {
/*  657 */     return createWebApplicationContext(parent);
/*      */   }
/*      */ 
/*      */   protected void applyInitializers(ConfigurableApplicationContext wac)
/*      */   {
/*      */     String[] initializerClassNames;
/*  674 */     if (this.contextInitializerClasses != null)
/*      */     {
/*  676 */       initializerClassNames = StringUtils.tokenizeToStringArray(this.contextInitializerClasses, ",; \t\n");
/*      */ 
/*  677 */       for (String initializerClassName : initializerClassNames)
/*      */       {
/*      */         try {
/*  680 */           Class initializerClass = ClassUtils.forName(initializerClassName, wac.getClassLoader());
/*  681 */           initializer = (ApplicationContextInitializer)BeanUtils.instantiateClass(initializerClass, ApplicationContextInitializer.class);
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */           ApplicationContextInitializer initializer;
/*  685 */           throw new IllegalArgumentException(
/*  685 */             String.format("Could not instantiate class [%s] specified via 'contextInitializerClasses' init-param", new Object[] { initializerClassName }), 
/*  685 */             ex);
/*      */         }
/*      */         ApplicationContextInitializer initializer;
/*  688 */         this.contextInitializers.add(initializer);
/*      */       }
/*      */     }
/*  691 */     AnnotationAwareOrderComparator.sort(this.contextInitializers);
/*  692 */     for (ApplicationContextInitializer initializer : this.contextInitializers)
/*  693 */       initializer.initialize(wac);
/*      */   }
/*      */ 
/*      */   protected void postProcessWebApplicationContext(ConfigurableWebApplicationContext wac)
/*      */   {
/*      */   }
/*      */ 
/*      */   public String getServletContextAttributeName()
/*      */   {
/*  722 */     return SERVLET_CONTEXT_PREFIX + getServletName();
/*      */   }
/*      */ 
/*      */   public final WebApplicationContext getWebApplicationContext()
/*      */   {
/*  729 */     return this.webApplicationContext;
/*      */   }
/*      */ 
/*      */   protected void initFrameworkServlet()
/*      */     throws ServletException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void refresh()
/*      */   {
/*  749 */     WebApplicationContext wac = getWebApplicationContext();
/*  750 */     if (!(wac instanceof ConfigurableApplicationContext)) {
/*  751 */       throw new IllegalStateException("WebApplicationContext does not support refresh: " + wac);
/*      */     }
/*  753 */     ((ConfigurableApplicationContext)wac).refresh();
/*      */   }
/*      */ 
/*      */   public void onApplicationEvent(ContextRefreshedEvent event)
/*      */   {
/*  763 */     this.refreshEventReceived = true;
/*  764 */     onRefresh(event.getApplicationContext());
/*      */   }
/*      */ 
/*      */   protected void onRefresh(ApplicationContext context)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void destroy()
/*      */   {
/*  784 */     if (this.webApplicationContextInjected) {
/*  785 */       return;
/*      */     }
/*  787 */     getServletContext().log("Destroying Spring FrameworkServlet '" + getServletName() + "'");
/*  788 */     if ((this.webApplicationContext instanceof ConfigurableApplicationContext))
/*  789 */       ((ConfigurableApplicationContext)this.webApplicationContext).close();
/*      */   }
/*      */ 
/*      */   protected void service(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  802 */     String method = request.getMethod();
/*  803 */     if (method.equalsIgnoreCase(RequestMethod.PATCH.name())) {
/*  804 */       processRequest(request, response);
/*      */     }
/*      */     else
/*  807 */       super.service(request, response);
/*      */   }
/*      */ 
/*      */   protected final void doGet(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  822 */     processRequest(request, response);
/*      */   }
/*      */ 
/*      */   protected final void doPost(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  833 */     processRequest(request, response);
/*      */   }
/*      */ 
/*      */   protected final void doPut(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  844 */     processRequest(request, response);
/*      */   }
/*      */ 
/*      */   protected final void doDelete(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  855 */     processRequest(request, response);
/*      */   }
/*      */ 
/*      */   protected void doOptions(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  868 */     if (this.dispatchOptionsRequest) {
/*  869 */       processRequest(request, response);
/*  870 */       if (response.containsHeader("Allow"))
/*      */       {
/*  872 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  878 */     super.doOptions(request, new HttpServletResponseWrapper(response)
/*      */     {
/*      */       public void setHeader(String name, String value) {
/*  881 */         if ("Allow".equals(name)) {
/*  882 */           value = new StringBuilder().append(StringUtils.hasLength(value) ? new StringBuilder().append(value).append(", ").toString() : "").append(RequestMethod.PATCH.name()).toString();
/*      */         }
/*  884 */         super.setHeader(name, value);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   protected void doTrace(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  898 */     if (this.dispatchTraceRequest) {
/*  899 */       processRequest(request, response);
/*  900 */       if ("message/http".equals(response.getContentType()))
/*      */       {
/*  902 */         return;
/*      */       }
/*      */     }
/*  905 */     super.doTrace(request, response);
/*      */   }
/*      */ 
/*      */   protected final void processRequest(HttpServletRequest request, HttpServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  916 */     long startTime = System.currentTimeMillis();
/*  917 */     Throwable failureCause = null;
/*      */ 
/*  919 */     LocaleContext previousLocaleContext = LocaleContextHolder.getLocaleContext();
/*  920 */     LocaleContext localeContext = buildLocaleContext(request);
/*      */ 
/*  922 */     RequestAttributes previousAttributes = RequestContextHolder.getRequestAttributes();
/*  923 */     ServletRequestAttributes requestAttributes = buildRequestAttributes(request, response, previousAttributes);
/*      */ 
/*  925 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager(request);
/*  926 */     asyncManager.registerCallableInterceptor(FrameworkServlet.class.getName(), new RequestBindingInterceptor(null));
/*      */ 
/*  928 */     initContextHolders(request, localeContext, requestAttributes);
/*      */     try
/*      */     {
/*  931 */       doService(request, response);
/*      */     }
/*      */     catch (ServletException ex) {
/*  934 */       failureCause = ex;
/*  935 */       throw ex;
/*      */     }
/*      */     catch (IOException ex) {
/*  938 */       failureCause = ex;
/*  939 */       throw ex;
/*      */     }
/*      */     catch (Throwable ex) {
/*  942 */       failureCause = ex;
/*  943 */       throw new NestedServletException("Request processing failed", ex);
/*      */     }
/*      */     finally
/*      */     {
/*  947 */       resetContextHolders(request, previousLocaleContext, previousAttributes);
/*  948 */       if (requestAttributes != null) {
/*  949 */         requestAttributes.requestCompleted();
/*      */       }
/*      */ 
/*  952 */       if (this.logger.isDebugEnabled()) {
/*  953 */         if (failureCause != null) {
/*  954 */           this.logger.debug("Could not complete request", failureCause);
/*      */         }
/*  957 */         else if (asyncManager.isConcurrentHandlingStarted()) {
/*  958 */           this.logger.debug("Leaving response open for concurrent processing");
/*      */         }
/*      */         else {
/*  961 */           this.logger.debug("Successfully completed request");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  966 */       publishRequestHandledEvent(request, startTime, failureCause);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected LocaleContext buildLocaleContext(HttpServletRequest request)
/*      */   {
/*  978 */     return new SimpleLocaleContext(request.getLocale());
/*      */   }
/*      */ 
/*      */   protected ServletRequestAttributes buildRequestAttributes(HttpServletRequest request, HttpServletResponse response, RequestAttributes previousAttributes)
/*      */   {
/*  995 */     if ((previousAttributes == null) || ((previousAttributes instanceof ServletRequestAttributes))) {
/*  996 */       return new ServletRequestAttributes(request);
/*      */     }
/*      */ 
/*  999 */     return null;
/*      */   }
/*      */ 
/*      */   private void initContextHolders(HttpServletRequest request, LocaleContext localeContext, RequestAttributes requestAttributes)
/*      */   {
/* 1006 */     if (localeContext != null) {
/* 1007 */       LocaleContextHolder.setLocaleContext(localeContext, this.threadContextInheritable);
/*      */     }
/* 1009 */     if (requestAttributes != null) {
/* 1010 */       RequestContextHolder.setRequestAttributes(requestAttributes, this.threadContextInheritable);
/*      */     }
/* 1012 */     if (this.logger.isTraceEnabled())
/* 1013 */       this.logger.trace("Bound request context to thread: " + request);
/*      */   }
/*      */ 
/*      */   private void resetContextHolders(HttpServletRequest request, LocaleContext prevLocaleContext, RequestAttributes previousAttributes)
/*      */   {
/* 1020 */     LocaleContextHolder.setLocaleContext(prevLocaleContext, this.threadContextInheritable);
/* 1021 */     RequestContextHolder.setRequestAttributes(previousAttributes, this.threadContextInheritable);
/* 1022 */     if (this.logger.isTraceEnabled())
/* 1023 */       this.logger.trace("Cleared thread-bound request context: " + request);
/*      */   }
/*      */ 
/*      */   private void publishRequestHandledEvent(HttpServletRequest request, long startTime, Throwable failureCause)
/*      */   {
/* 1028 */     if (this.publishEvents)
/*      */     {
/* 1030 */       long processingTime = System.currentTimeMillis() - startTime;
/* 1031 */       this.webApplicationContext.publishEvent(new ServletRequestHandledEvent(this, request
/* 1033 */         .getRequestURI(), request.getRemoteAddr(), request
/* 1034 */         .getMethod(), getServletConfig().getServletName(), 
/* 1035 */         WebUtils.getSessionId(request), 
/* 1035 */         getUsernameForRequest(request), processingTime, failureCause));
/*      */     }
/*      */   }
/*      */ 
/*      */   protected String getUsernameForRequest(HttpServletRequest request)
/*      */   {
/* 1049 */     Principal userPrincipal = request.getUserPrincipal();
/* 1050 */     return userPrincipal != null ? userPrincipal.getName() : null;
/*      */   }
/*      */ 
/*      */   public void setApplicationContext(ApplicationContext applicationContext)
/*      */     throws BeansException
/*      */   {
/* 1066 */     if ((this.webApplicationContext == null) && ((applicationContext instanceof WebApplicationContext)))
/*      */     {
/* 1068 */       if (this.logger.isDebugEnabled()) {
/* 1069 */         this.logger.debug("Using existing application context for " + 
/* 1070 */           ClassUtils.getShortName(getClass()));
/*      */       }
/* 1072 */       this.webApplicationContext = ((WebApplicationContext)applicationContext);
/* 1073 */       this.webApplicationContextInjected = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected abstract void doService(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*      */     throws Exception;
/*      */ 
/*      */   private class RequestBindingInterceptor extends CallableProcessingInterceptorAdapter
/*      */   {
/*      */     private RequestBindingInterceptor()
/*      */     {
/*      */     }
/*      */ 
/*      */     public <T> void preProcess(NativeWebRequest webRequest, Callable<T> task)
/*      */     {
/* 1115 */       HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 1116 */       if (request != null) {
/* 1117 */         HttpServletResponse response = (HttpServletResponse)webRequest.getNativeRequest(HttpServletResponse.class);
/* 1118 */         FrameworkServlet.this.initContextHolders(request, FrameworkServlet.this.buildLocaleContext(request), FrameworkServlet.this.buildRequestAttributes(request, response, null));
/*      */       }
/*      */     }
/*      */ 
/*      */     public <T> void postProcess(NativeWebRequest webRequest, Callable<T> task, Object concurrentResult) {
/* 1123 */       HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 1124 */       if (request != null)
/* 1125 */         FrameworkServlet.this.resetContextHolders(request, null, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ContextRefreshListener
/*      */     implements ApplicationListener<ContextRefreshedEvent>
/*      */   {
/*      */     private ContextRefreshListener()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void onApplicationEvent(ContextRefreshedEvent event)
/*      */     {
/* 1102 */       FrameworkServlet.this.onApplicationEvent(event);
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.FrameworkServlet
 * JD-Core Version:    0.6.2
 */