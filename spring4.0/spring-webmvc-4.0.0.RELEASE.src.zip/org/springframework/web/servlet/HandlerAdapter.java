package org.springframework.web.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract interface HandlerAdapter
{
  public abstract boolean supports(Object paramObject);

  public abstract ModelAndView handle(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Object paramObject)
    throws Exception;

  public abstract long getLastModified(HttpServletRequest paramHttpServletRequest, Object paramObject);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.HandlerAdapter
 * JD-Core Version:    0.6.2
 */