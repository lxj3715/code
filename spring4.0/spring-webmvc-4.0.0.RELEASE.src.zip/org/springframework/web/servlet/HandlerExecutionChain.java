/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class HandlerExecutionChain
/*     */ {
/*  40 */   private static final Log logger = LogFactory.getLog(HandlerExecutionChain.class);
/*     */   private final Object handler;
/*     */   private HandlerInterceptor[] interceptors;
/*     */   private List<HandlerInterceptor> interceptorList;
/*  48 */   private int interceptorIndex = -1;
/*     */ 
/*     */   public HandlerExecutionChain(Object handler)
/*     */   {
/*  56 */     this(handler, null);
/*     */   }
/*     */ 
/*     */   public HandlerExecutionChain(Object handler, HandlerInterceptor[] interceptors)
/*     */   {
/*  66 */     if ((handler instanceof HandlerExecutionChain)) {
/*  67 */       HandlerExecutionChain originalChain = (HandlerExecutionChain)handler;
/*  68 */       this.handler = originalChain.getHandler();
/*  69 */       this.interceptorList = new ArrayList();
/*  70 */       CollectionUtils.mergeArrayIntoCollection(originalChain.getInterceptors(), this.interceptorList);
/*  71 */       CollectionUtils.mergeArrayIntoCollection(interceptors, this.interceptorList);
/*     */     }
/*     */     else {
/*  74 */       this.handler = handler;
/*  75 */       this.interceptors = interceptors;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getHandler()
/*     */   {
/*  84 */     return this.handler;
/*     */   }
/*     */ 
/*     */   public void addInterceptor(HandlerInterceptor interceptor) {
/*  88 */     initInterceptorList();
/*  89 */     this.interceptorList.add(interceptor);
/*     */   }
/*     */ 
/*     */   public void addInterceptors(HandlerInterceptor[] interceptors) {
/*  93 */     if (interceptors != null) {
/*  94 */       initInterceptorList();
/*  95 */       this.interceptorList.addAll(Arrays.asList(interceptors));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initInterceptorList() {
/* 100 */     if (this.interceptorList == null) {
/* 101 */       this.interceptorList = new ArrayList();
/*     */     }
/* 103 */     if (this.interceptors != null) {
/* 104 */       this.interceptorList.addAll(Arrays.asList(this.interceptors));
/* 105 */       this.interceptors = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public HandlerInterceptor[] getInterceptors()
/*     */   {
/* 114 */     if ((this.interceptors == null) && (this.interceptorList != null)) {
/* 115 */       this.interceptors = ((HandlerInterceptor[])this.interceptorList.toArray(new HandlerInterceptor[this.interceptorList.size()]));
/*     */     }
/* 117 */     return this.interceptors;
/*     */   }
/*     */ 
/*     */   boolean applyPreHandle(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 127 */     if (getInterceptors() != null) {
/* 128 */       for (int i = 0; i < getInterceptors().length; i++) {
/* 129 */         HandlerInterceptor interceptor = getInterceptors()[i];
/* 130 */         if (!interceptor.preHandle(request, response, this.handler)) {
/* 131 */           triggerAfterCompletion(request, response, null);
/* 132 */           return false;
/*     */         }
/* 134 */         this.interceptorIndex = i;
/*     */       }
/*     */     }
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   void applyPostHandle(HttpServletRequest request, HttpServletResponse response, ModelAndView mv)
/*     */     throws Exception
/*     */   {
/* 144 */     if (getInterceptors() == null) {
/* 145 */       return;
/*     */     }
/* 147 */     for (int i = getInterceptors().length - 1; i >= 0; i--) {
/* 148 */       HandlerInterceptor interceptor = getInterceptors()[i];
/* 149 */       interceptor.postHandle(request, response, this.handler, mv);
/*     */     }
/*     */   }
/*     */ 
/*     */   void triggerAfterCompletion(HttpServletRequest request, HttpServletResponse response, Exception ex)
/*     */     throws Exception
/*     */   {
/* 161 */     if (getInterceptors() == null) {
/* 162 */       return;
/*     */     }
/* 164 */     for (int i = this.interceptorIndex; i >= 0; i--) {
/* 165 */       HandlerInterceptor interceptor = getInterceptors()[i];
/*     */       try {
/* 167 */         interceptor.afterCompletion(request, response, this.handler, ex);
/*     */       }
/*     */       catch (Throwable ex2) {
/* 170 */         logger.error("HandlerInterceptor.afterCompletion threw exception", ex2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   void applyAfterConcurrentHandlingStarted(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 179 */     if (getInterceptors() == null) {
/* 180 */       return;
/*     */     }
/* 182 */     for (int i = getInterceptors().length - 1; i >= 0; i--)
/* 183 */       if ((this.interceptors[i] instanceof AsyncHandlerInterceptor))
/*     */         try {
/* 185 */           AsyncHandlerInterceptor asyncInterceptor = (AsyncHandlerInterceptor)this.interceptors[i];
/* 186 */           asyncInterceptor.afterConcurrentHandlingStarted(request, response, this.handler);
/*     */         }
/*     */         catch (Throwable ex) {
/* 189 */           logger.error(new StringBuilder().append("Interceptor [").append(this.interceptors[i]).append("] failed in afterConcurrentHandlingStarted").toString(), ex);
/*     */         }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 200 */     if (this.handler == null) {
/* 201 */       return "HandlerExecutionChain with no handler";
/*     */     }
/* 203 */     StringBuilder sb = new StringBuilder();
/* 204 */     sb.append("HandlerExecutionChain with handler [").append(this.handler).append("]");
/* 205 */     if (!CollectionUtils.isEmpty(this.interceptorList)) {
/* 206 */       sb.append(" and ").append(this.interceptorList.size()).append(" interceptor");
/* 207 */       if (this.interceptorList.size() > 1) {
/* 208 */         sb.append("s");
/*     */       }
/*     */     }
/* 211 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.HandlerExecutionChain
 * JD-Core Version:    0.6.2
 */