/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceEditor;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.support.ServletContextResourceLoader;
/*     */ import org.springframework.web.context.support.StandardServletEnvironment;
/*     */ 
/*     */ public abstract class HttpServletBean extends HttpServlet
/*     */   implements EnvironmentCapable, EnvironmentAware
/*     */ {
/*     */   protected final Log logger;
/*     */   private final Set<String> requiredProperties;
/*     */   private ConfigurableEnvironment environment;
/*     */ 
/*     */   public HttpServletBean()
/*     */   {
/*  85 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  91 */     this.requiredProperties = new HashSet();
/*     */   }
/*     */ 
/*     */   protected final void addRequiredProperty(String property)
/*     */   {
/* 106 */     this.requiredProperties.add(property);
/*     */   }
/*     */ 
/*     */   public final void init()
/*     */     throws ServletException
/*     */   {
/* 117 */     if (this.logger.isDebugEnabled()) {
/* 118 */       this.logger.debug("Initializing servlet '" + getServletName() + "'");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 123 */       PropertyValues pvs = new ServletConfigPropertyValues(getServletConfig(), this.requiredProperties);
/* 124 */       BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(this);
/* 125 */       ResourceLoader resourceLoader = new ServletContextResourceLoader(getServletContext());
/* 126 */       bw.registerCustomEditor(Resource.class, new ResourceEditor(resourceLoader, getEnvironment()));
/* 127 */       initBeanWrapper(bw);
/* 128 */       bw.setPropertyValues(pvs, true);
/*     */     }
/*     */     catch (BeansException ex) {
/* 131 */       this.logger.error("Failed to set bean properties on servlet '" + getServletName() + "'", ex);
/* 132 */       throw ex;
/*     */     }
/*     */ 
/* 136 */     initServletBean();
/*     */ 
/* 138 */     if (this.logger.isDebugEnabled())
/* 139 */       this.logger.debug("Servlet '" + getServletName() + "' configured successfully");
/*     */   }
/*     */ 
/*     */   protected void initBeanWrapper(BeanWrapper bw)
/*     */     throws BeansException
/*     */   {
/*     */   }
/*     */ 
/*     */   public final String getServletName()
/*     */   {
/* 162 */     return getServletConfig() != null ? getServletConfig().getServletName() : null;
/*     */   }
/*     */ 
/*     */   public final ServletContext getServletContext()
/*     */   {
/* 172 */     return getServletConfig() != null ? getServletConfig().getServletContext() : null;
/*     */   }
/*     */ 
/*     */   protected void initServletBean()
/*     */     throws ServletException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 193 */     Assert.isInstanceOf(ConfigurableEnvironment.class, environment);
/* 194 */     this.environment = ((ConfigurableEnvironment)environment);
/*     */   }
/*     */ 
/*     */   public ConfigurableEnvironment getEnvironment()
/*     */   {
/* 204 */     if (this.environment == null) {
/* 205 */       this.environment = createEnvironment();
/*     */     }
/* 207 */     return this.environment;
/*     */   }
/*     */ 
/*     */   protected ConfigurableEnvironment createEnvironment()
/*     */   {
/* 215 */     return new StandardServletEnvironment();
/*     */   }
/*     */ 
/*     */   private static class ServletConfigPropertyValues extends MutablePropertyValues
/*     */   {
/*     */     public ServletConfigPropertyValues(ServletConfig config, Set<String> requiredProperties)
/*     */       throws ServletException
/*     */     {
/* 234 */       Set missingProps = (requiredProperties != null) && (!requiredProperties.isEmpty()) ? new HashSet(requiredProperties) : null;
/*     */ 
/* 237 */       Enumeration en = config.getInitParameterNames();
/* 238 */       while (en.hasMoreElements()) {
/* 239 */         String property = (String)en.nextElement();
/* 240 */         Object value = config.getInitParameter(property);
/* 241 */         addPropertyValue(new PropertyValue(property, value));
/* 242 */         if (missingProps != null) {
/* 243 */           missingProps.remove(property);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 248 */       if ((missingProps != null) && (missingProps.size() > 0))
/*     */       {
/* 252 */         throw new ServletException("Initialization from ServletConfig for servlet '" + config
/* 250 */           .getServletName() + "' failed; the following required properties were missing: " + 
/* 252 */           StringUtils.collectionToDelimitedString(missingProps, ", "));
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.HttpServletBean
 * JD-Core Version:    0.6.2
 */