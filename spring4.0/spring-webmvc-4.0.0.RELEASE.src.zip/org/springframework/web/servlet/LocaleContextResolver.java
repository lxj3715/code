package org.springframework.web.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.context.i18n.LocaleContext;

public abstract interface LocaleContextResolver extends LocaleResolver
{
  public abstract LocaleContext resolveLocaleContext(HttpServletRequest paramHttpServletRequest);

  public abstract void setLocaleContext(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, LocaleContext paramLocaleContext);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.LocaleContextResolver
 * JD-Core Version:    0.6.2
 */