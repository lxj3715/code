package org.springframework.web.servlet;

import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract interface LocaleResolver
{
  public abstract Locale resolveLocale(HttpServletRequest paramHttpServletRequest);

  public abstract void setLocale(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Locale paramLocale);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.LocaleResolver
 * JD-Core Version:    0.6.2
 */