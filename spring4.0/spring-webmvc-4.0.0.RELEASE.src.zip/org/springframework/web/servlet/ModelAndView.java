/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class ModelAndView
/*     */ {
/*     */   private Object view;
/*     */   private ModelMap model;
/*  53 */   private boolean cleared = false;
/*     */ 
/*     */   public ModelAndView()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ModelAndView(String viewName)
/*     */   {
/*  73 */     this.view = viewName;
/*     */   }
/*     */ 
/*     */   public ModelAndView(View view)
/*     */   {
/*  83 */     this.view = view;
/*     */   }
/*     */ 
/*     */   public ModelAndView(String viewName, Map<String, ?> model)
/*     */   {
/*  95 */     this.view = viewName;
/*  96 */     if (model != null)
/*  97 */       getModelMap().addAllAttributes(model);
/*     */   }
/*     */ 
/*     */   public ModelAndView(View view, Map<String, ?> model)
/*     */   {
/* 112 */     this.view = view;
/* 113 */     if (model != null)
/* 114 */       getModelMap().addAllAttributes(model);
/*     */   }
/*     */ 
/*     */   public ModelAndView(String viewName, String modelName, Object modelObject)
/*     */   {
/* 126 */     this.view = viewName;
/* 127 */     addObject(modelName, modelObject);
/*     */   }
/*     */ 
/*     */   public ModelAndView(View view, String modelName, Object modelObject)
/*     */   {
/* 137 */     this.view = view;
/* 138 */     addObject(modelName, modelObject);
/*     */   }
/*     */ 
/*     */   public void setViewName(String viewName)
/*     */   {
/* 148 */     this.view = viewName;
/*     */   }
/*     */ 
/*     */   public String getViewName()
/*     */   {
/* 156 */     return (this.view instanceof String) ? (String)this.view : null;
/*     */   }
/*     */ 
/*     */   public void setView(View view)
/*     */   {
/* 164 */     this.view = view;
/*     */   }
/*     */ 
/*     */   public View getView()
/*     */   {
/* 172 */     return (this.view instanceof View) ? (View)this.view : null;
/*     */   }
/*     */ 
/*     */   public boolean hasView()
/*     */   {
/* 180 */     return this.view != null;
/*     */   }
/*     */ 
/*     */   public boolean isReference()
/*     */   {
/* 189 */     return this.view instanceof String;
/*     */   }
/*     */ 
/*     */   protected Map<String, Object> getModelInternal()
/*     */   {
/* 197 */     return this.model;
/*     */   }
/*     */ 
/*     */   public ModelMap getModelMap()
/*     */   {
/* 204 */     if (this.model == null) {
/* 205 */       this.model = new ModelMap();
/*     */     }
/* 207 */     return this.model;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getModel()
/*     */   {
/* 215 */     return getModelMap();
/*     */   }
/*     */ 
/*     */   public ModelAndView addObject(String attributeName, Object attributeValue)
/*     */   {
/* 227 */     getModelMap().addAttribute(attributeName, attributeValue);
/* 228 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndView addObject(Object attributeValue)
/*     */   {
/* 238 */     getModelMap().addAttribute(attributeValue);
/* 239 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelAndView addAllObjects(Map<String, ?> modelMap)
/*     */   {
/* 249 */     getModelMap().addAllAttributes(modelMap);
/* 250 */     return this;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 263 */     this.view = null;
/* 264 */     this.model = null;
/* 265 */     this.cleared = true;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 273 */     return (this.view == null) && (CollectionUtils.isEmpty(this.model));
/*     */   }
/*     */ 
/*     */   public boolean wasCleared()
/*     */   {
/* 284 */     return (this.cleared) && (isEmpty());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 293 */     StringBuilder sb = new StringBuilder("ModelAndView: ");
/* 294 */     if (isReference()) {
/* 295 */       sb.append("reference to view with name '").append(this.view).append("'");
/*     */     }
/*     */     else {
/* 298 */       sb.append("materialized View is [").append(this.view).append(']');
/*     */     }
/* 300 */     sb.append("; model is ").append(this.model);
/* 301 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.ModelAndView
 * JD-Core Version:    0.6.2
 */