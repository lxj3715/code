/*    */ package org.springframework.web.servlet;
/*    */ 
/*    */ import javax.servlet.ServletException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ModelAndViewDefiningException extends ServletException
/*    */ {
/*    */   private ModelAndView modelAndView;
/*    */ 
/*    */   public ModelAndViewDefiningException(ModelAndView modelAndView)
/*    */   {
/* 47 */     Assert.notNull(modelAndView, "ModelAndView must not be null in ModelAndViewDefiningException");
/* 48 */     this.modelAndView = modelAndView;
/*    */   }
/*    */ 
/*    */   public ModelAndView getModelAndView()
/*    */   {
/* 55 */     return this.modelAndView;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.ModelAndViewDefiningException
 * JD-Core Version:    0.6.2
 */