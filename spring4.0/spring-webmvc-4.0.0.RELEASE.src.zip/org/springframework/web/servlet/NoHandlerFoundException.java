/*    */ package org.springframework.web.servlet;
/*    */ 
/*    */ import javax.servlet.ServletException;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ public class NoHandlerFoundException extends ServletException
/*    */ {
/*    */   private final String httpMethod;
/*    */   private final String requestURL;
/*    */   private final HttpHeaders headers;
/*    */ 
/*    */   public NoHandlerFoundException(String httpMethod, String requestURL, HttpHeaders headers)
/*    */   {
/* 48 */     super("No handler found for " + httpMethod + " " + requestURL + ", headers=" + headers);
/* 49 */     this.httpMethod = httpMethod;
/* 50 */     this.requestURL = requestURL;
/* 51 */     this.headers = headers;
/*    */   }
/*    */ 
/*    */   public String getHttpMethod() {
/* 55 */     return this.httpMethod;
/*    */   }
/*    */ 
/*    */   public String getRequestURL() {
/* 59 */     return this.requestURL;
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders() {
/* 63 */     return this.headers;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.NoHandlerFoundException
 * JD-Core Version:    0.6.2
 */