package org.springframework.web.servlet;

import javax.servlet.http.HttpServletRequest;

public abstract interface RequestToViewNameTranslator
{
  public abstract String getViewName(HttpServletRequest paramHttpServletRequest)
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.RequestToViewNameTranslator
 * JD-Core Version:    0.6.2
 */