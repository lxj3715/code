/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.support.ServletContextResource;
/*     */ 
/*     */ public class ResourceServlet extends HttpServletBean
/*     */ {
/*     */   public static final String RESOURCE_URL_DELIMITERS = ",; \t\n";
/*     */   public static final String RESOURCE_PARAM_NAME = "resource";
/*     */   private String defaultUrl;
/*     */   private String allowedResources;
/*     */   private String contentType;
/* 112 */   private boolean applyLastModified = false;
/*     */   private PathMatcher pathMatcher;
/*     */   private long startupTime;
/*     */ 
/*     */   public void setDefaultUrl(String defaultUrl)
/*     */   {
/* 129 */     this.defaultUrl = defaultUrl;
/*     */   }
/*     */ 
/*     */   public void setAllowedResources(String allowedResources)
/*     */   {
/* 138 */     this.allowedResources = allowedResources;
/*     */   }
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/* 150 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */   public void setApplyLastModified(boolean applyLastModified)
/*     */   {
/* 165 */     this.applyLastModified = applyLastModified;
/*     */   }
/*     */ 
/*     */   protected void initServletBean()
/*     */   {
/* 174 */     this.pathMatcher = getPathMatcher();
/* 175 */     this.startupTime = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   protected PathMatcher getPathMatcher()
/*     */   {
/* 185 */     return new AntPathMatcher();
/*     */   }
/*     */ 
/*     */   protected final void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 198 */     String resourceUrl = determineResourceUrl(request);
/*     */ 
/* 200 */     if (resourceUrl != null) {
/*     */       try {
/* 202 */         doInclude(request, response, resourceUrl);
/*     */       }
/*     */       catch (ServletException ex) {
/* 205 */         if (this.logger.isWarnEnabled()) {
/* 206 */           this.logger.warn("Failed to include content of resource [" + resourceUrl + "]", ex);
/*     */         }
/*     */ 
/* 209 */         if (!includeDefaultUrl(request, response))
/* 210 */           throw ex;
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 214 */         if (this.logger.isWarnEnabled()) {
/* 215 */           this.logger.warn("Failed to include content of resource [" + resourceUrl + "]", ex);
/*     */         }
/*     */ 
/* 218 */         if (!includeDefaultUrl(request, response)) {
/* 219 */           throw ex;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/* 225 */     else if (!includeDefaultUrl(request, response))
/* 226 */       throw new ServletException("No target resource URL found for request");
/*     */   }
/*     */ 
/*     */   protected String determineResourceUrl(HttpServletRequest request)
/*     */   {
/* 239 */     return request.getParameter("resource");
/*     */   }
/*     */ 
/*     */   private boolean includeDefaultUrl(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 253 */     if (this.defaultUrl == null) {
/* 254 */       return false;
/*     */     }
/* 256 */     doInclude(request, response, this.defaultUrl);
/* 257 */     return true;
/*     */   }
/*     */ 
/*     */   private void doInclude(HttpServletRequest request, HttpServletResponse response, String resourceUrl)
/*     */     throws ServletException, IOException
/*     */   {
/* 271 */     if (this.contentType != null) {
/* 272 */       response.setContentType(this.contentType);
/*     */     }
/*     */ 
/* 275 */     String[] resourceUrls = StringUtils.tokenizeToStringArray(resourceUrl, ",; \t\n");
/*     */ 
/* 276 */     for (int i = 0; i < resourceUrls.length; i++)
/*     */     {
/* 278 */       if ((this.allowedResources != null) && (!this.pathMatcher.match(this.allowedResources, resourceUrls[i]))) {
/* 279 */         throw new ServletException("Resource [" + resourceUrls[i] + "] does not match allowed pattern [" + this.allowedResources + "]");
/*     */       }
/*     */ 
/* 282 */       if (this.logger.isDebugEnabled()) {
/* 283 */         this.logger.debug("Including resource [" + resourceUrls[i] + "]");
/*     */       }
/* 285 */       RequestDispatcher rd = request.getRequestDispatcher(resourceUrls[i]);
/* 286 */       rd.include(request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final long getLastModified(HttpServletRequest request)
/*     */   {
/* 305 */     if (this.applyLastModified) {
/* 306 */       String resourceUrl = determineResourceUrl(request);
/* 307 */       if (resourceUrl == null) {
/* 308 */         resourceUrl = this.defaultUrl;
/*     */       }
/* 310 */       if (resourceUrl != null) {
/* 311 */         String[] resourceUrls = StringUtils.tokenizeToStringArray(resourceUrl, ",; \t\n");
/* 312 */         long latestTimestamp = -1L;
/* 313 */         for (int i = 0; i < resourceUrls.length; i++) {
/* 314 */           long timestamp = getFileTimestamp(resourceUrls[i]);
/* 315 */           if (timestamp > latestTimestamp) {
/* 316 */             latestTimestamp = timestamp;
/*     */           }
/*     */         }
/* 319 */         return latestTimestamp > this.startupTime ? latestTimestamp : this.startupTime;
/*     */       }
/*     */     }
/* 322 */     return -1L;
/*     */   }
/*     */ 
/*     */   protected long getFileTimestamp(String resourceUrl)
/*     */   {
/* 331 */     ServletContextResource resource = new ServletContextResource(getServletContext(), resourceUrl);
/*     */     try {
/* 333 */       long lastModifiedTime = resource.lastModified();
/* 334 */       if (this.logger.isDebugEnabled()) {
/* 335 */         this.logger.debug("Last-modified timestamp of " + resource + " is " + lastModifiedTime);
/*     */       }
/* 337 */       return lastModifiedTime;
/*     */     }
/*     */     catch (IOException ex) {
/* 340 */       this.logger.warn("Couldn't retrieve last-modified timestamp of [" + resource + "] - using ResourceServlet startup time");
/*     */     }
/* 342 */     return -1L;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.ResourceServlet
 * JD-Core Version:    0.6.2
 */