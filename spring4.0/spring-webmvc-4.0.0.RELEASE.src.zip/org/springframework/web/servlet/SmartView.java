package org.springframework.web.servlet;

public abstract interface SmartView extends View
{
  public abstract boolean isRedirectView();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.SmartView
 * JD-Core Version:    0.6.2
 */