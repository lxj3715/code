/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ public class ViewRendererServlet extends HttpServlet
/*     */ {
/*  54 */   public static final String WEB_APPLICATION_CONTEXT_ATTRIBUTE = DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE;
/*     */ 
/*  57 */   public static final String VIEW_ATTRIBUTE = ViewRendererServlet.class.getName() + ".VIEW";
/*     */ 
/*  60 */   public static final String MODEL_ATTRIBUTE = ViewRendererServlet.class.getName() + ".MODEL";
/*     */ 
/*     */   protected final void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  67 */     processRequest(request, response);
/*     */   }
/*     */ 
/*     */   protected final void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  74 */     processRequest(request, response);
/*     */   }
/*     */ 
/*     */   protected final void processRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*     */     try
/*     */     {
/*  87 */       renderView(request, response);
/*     */     }
/*     */     catch (ServletException ex) {
/*  90 */       throw ex;
/*     */     }
/*     */     catch (IOException ex) {
/*  93 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/*  96 */       throw new NestedServletException("View rendering failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void renderView(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 110 */     View view = (View)request.getAttribute(VIEW_ATTRIBUTE);
/* 111 */     if (view == null) {
/* 112 */       throw new ServletException("Could not complete render request: View is null");
/*     */     }
/* 114 */     Map model = (Map)request.getAttribute(MODEL_ATTRIBUTE);
/* 115 */     view.render(model, request, response);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.ViewRendererServlet
 * JD-Core Version:    0.6.2
 */