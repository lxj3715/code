package org.springframework.web.servlet;

import java.util.Locale;

public abstract interface ViewResolver
{
  public abstract View resolveViewName(String paramString, Locale paramLocale)
    throws Exception;
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.ViewResolver
 * JD-Core Version:    0.6.2
 */