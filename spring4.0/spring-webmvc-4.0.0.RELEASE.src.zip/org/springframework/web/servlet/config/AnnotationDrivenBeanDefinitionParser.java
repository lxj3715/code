/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.format.support.FormattingConversionServiceFactoryBean;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*     */ import org.springframework.web.servlet.handler.ConversionServiceExposingInterceptor;
/*     */ import org.springframework.web.servlet.handler.MappedInterceptor;
/*     */ import org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ServletWebArgumentResolverAdapter;
/*     */ import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class AnnotationDrivenBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/* 132 */   private static final boolean jsr303Present = ClassUtils.isPresent("javax.validation.Validator", AnnotationDrivenBeanDefinitionParser.class
/* 133 */     .getClassLoader());
/*     */ 
/* 136 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", AnnotationDrivenBeanDefinitionParser.class
/* 136 */     .getClassLoader());
/*     */ 
/* 139 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", AnnotationDrivenBeanDefinitionParser.class
/* 139 */     .getClassLoader())) && 
/* 140 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", AnnotationDrivenBeanDefinitionParser.class
/* 140 */     .getClassLoader()));
/*     */ 
/* 143 */   private static final boolean jacksonPresent = (ClassUtils.isPresent("org.codehaus.jackson.map.ObjectMapper", AnnotationDrivenBeanDefinitionParser.class
/* 143 */     .getClassLoader())) && 
/* 144 */     (ClassUtils.isPresent("org.codehaus.jackson.JsonGenerator", AnnotationDrivenBeanDefinitionParser.class
/* 144 */     .getClassLoader()));
/*     */ 
/* 147 */   private static boolean romePresent = ClassUtils.isPresent("com.sun.syndication.feed.WireFeed", AnnotationDrivenBeanDefinitionParser.class
/* 147 */     .getClassLoader());
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/* 151 */     Object source = parserContext.extractSource(element);
/*     */ 
/* 153 */     CompositeComponentDefinition compDefinition = new CompositeComponentDefinition(element.getTagName(), source);
/* 154 */     parserContext.pushContainingComponent(compDefinition);
/*     */ 
/* 156 */     RuntimeBeanReference contentNegotiationManager = getContentNegotiationManager(element, source, parserContext);
/*     */ 
/* 158 */     RootBeanDefinition handlerMappingDef = new RootBeanDefinition(RequestMappingHandlerMapping.class);
/* 159 */     handlerMappingDef.setSource(source);
/* 160 */     handlerMappingDef.setRole(2);
/* 161 */     handlerMappingDef.getPropertyValues().add("order", Integer.valueOf(0));
/* 162 */     handlerMappingDef.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/* 163 */     String methodMappingName = parserContext.getReaderContext().registerWithGeneratedName(handlerMappingDef);
/* 164 */     if ((element.hasAttribute("enable-matrix-variables")) || (element.hasAttribute("enableMatrixVariables"))) {
/* 165 */       Boolean enableMatrixVariables = Boolean.valueOf(element.getAttribute(element
/* 166 */         .hasAttribute("enable-matrix-variables") ? 
/* 166 */         "enable-matrix-variables" : "enableMatrixVariables"));
/* 167 */       handlerMappingDef.getPropertyValues().add("removeSemicolonContent", Boolean.valueOf(!enableMatrixVariables.booleanValue()));
/*     */     }
/*     */ 
/* 170 */     RuntimeBeanReference conversionService = getConversionService(element, source, parserContext);
/* 171 */     RuntimeBeanReference validator = getValidator(element, source, parserContext);
/* 172 */     RuntimeBeanReference messageCodesResolver = getMessageCodesResolver(element, source, parserContext);
/*     */ 
/* 174 */     RootBeanDefinition bindingDef = new RootBeanDefinition(ConfigurableWebBindingInitializer.class);
/* 175 */     bindingDef.setSource(source);
/* 176 */     bindingDef.setRole(2);
/* 177 */     bindingDef.getPropertyValues().add("conversionService", conversionService);
/* 178 */     bindingDef.getPropertyValues().add("validator", validator);
/* 179 */     bindingDef.getPropertyValues().add("messageCodesResolver", messageCodesResolver);
/*     */ 
/* 181 */     ManagedList messageConverters = getMessageConverters(element, source, parserContext);
/* 182 */     ManagedList argumentResolvers = getArgumentResolvers(element, source, parserContext);
/* 183 */     ManagedList returnValueHandlers = getReturnValueHandlers(element, source, parserContext);
/* 184 */     String asyncTimeout = getAsyncTimeout(element, source, parserContext);
/* 185 */     RuntimeBeanReference asyncExecutor = getAsyncExecutor(element, source, parserContext);
/* 186 */     ManagedList callableInterceptors = getCallableInterceptors(element, source, parserContext);
/* 187 */     ManagedList deferredResultInterceptors = getDeferredResultInterceptors(element, source, parserContext);
/*     */ 
/* 189 */     RootBeanDefinition handlerAdapterDef = new RootBeanDefinition(RequestMappingHandlerAdapter.class);
/* 190 */     handlerAdapterDef.setSource(source);
/* 191 */     handlerAdapterDef.setRole(2);
/* 192 */     handlerAdapterDef.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/* 193 */     handlerAdapterDef.getPropertyValues().add("webBindingInitializer", bindingDef);
/* 194 */     handlerAdapterDef.getPropertyValues().add("messageConverters", messageConverters);
/* 195 */     if ((element.hasAttribute("ignore-default-model-on-redirect")) || (element.hasAttribute("ignoreDefaultModelOnRedirect"))) {
/* 196 */       Boolean ignoreDefaultModel = Boolean.valueOf(element.getAttribute(element
/* 197 */         .hasAttribute("ignore-default-model-on-redirect") ? 
/* 197 */         "ignore-default-model-on-redirect" : "ignoreDefaultModelOnRedirect"));
/* 198 */       handlerAdapterDef.getPropertyValues().add("ignoreDefaultModelOnRedirect", ignoreDefaultModel);
/*     */     }
/* 200 */     if (argumentResolvers != null) {
/* 201 */       handlerAdapterDef.getPropertyValues().add("customArgumentResolvers", argumentResolvers);
/*     */     }
/* 203 */     if (returnValueHandlers != null) {
/* 204 */       handlerAdapterDef.getPropertyValues().add("customReturnValueHandlers", returnValueHandlers);
/*     */     }
/* 206 */     if (asyncTimeout != null) {
/* 207 */       handlerAdapterDef.getPropertyValues().add("asyncRequestTimeout", asyncTimeout);
/*     */     }
/* 209 */     if (asyncExecutor != null) {
/* 210 */       handlerAdapterDef.getPropertyValues().add("taskExecutor", asyncExecutor);
/*     */     }
/* 212 */     handlerAdapterDef.getPropertyValues().add("callableInterceptors", callableInterceptors);
/* 213 */     handlerAdapterDef.getPropertyValues().add("deferredResultInterceptors", deferredResultInterceptors);
/* 214 */     String handlerAdapterName = parserContext.getReaderContext().registerWithGeneratedName(handlerAdapterDef);
/*     */ 
/* 216 */     String uriCompContribName = "mvcUriComponentsContributor";
/* 217 */     RootBeanDefinition uriCompContribDef = new RootBeanDefinition(CompositeUriComponentsContributorFactoryBean.class);
/* 218 */     uriCompContribDef.setSource(source);
/* 219 */     uriCompContribDef.getPropertyValues().addPropertyValue("handlerAdapter", handlerAdapterDef);
/* 220 */     uriCompContribDef.getPropertyValues().addPropertyValue("conversionService", conversionService);
/* 221 */     parserContext.getReaderContext().getRegistry().registerBeanDefinition(uriCompContribName, uriCompContribDef);
/*     */ 
/* 223 */     RootBeanDefinition csInterceptorDef = new RootBeanDefinition(ConversionServiceExposingInterceptor.class);
/* 224 */     csInterceptorDef.setSource(source);
/* 225 */     csInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(0, conversionService);
/* 226 */     RootBeanDefinition mappedCsInterceptorDef = new RootBeanDefinition(MappedInterceptor.class);
/* 227 */     mappedCsInterceptorDef.setSource(source);
/* 228 */     mappedCsInterceptorDef.setRole(2);
/* 229 */     mappedCsInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(0, (Object)null);
/* 230 */     mappedCsInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(1, csInterceptorDef);
/* 231 */     String mappedInterceptorName = parserContext.getReaderContext().registerWithGeneratedName(mappedCsInterceptorDef);
/*     */ 
/* 233 */     RootBeanDefinition exceptionHandlerExceptionResolver = new RootBeanDefinition(ExceptionHandlerExceptionResolver.class);
/* 234 */     exceptionHandlerExceptionResolver.setSource(source);
/* 235 */     exceptionHandlerExceptionResolver.setRole(2);
/* 236 */     exceptionHandlerExceptionResolver.getPropertyValues().add("contentNegotiationManager", contentNegotiationManager);
/* 237 */     exceptionHandlerExceptionResolver.getPropertyValues().add("messageConverters", messageConverters);
/* 238 */     exceptionHandlerExceptionResolver.getPropertyValues().add("order", Integer.valueOf(0));
/*     */ 
/* 240 */     String methodExceptionResolverName = parserContext
/* 240 */       .getReaderContext().registerWithGeneratedName(exceptionHandlerExceptionResolver);
/*     */ 
/* 242 */     RootBeanDefinition responseStatusExceptionResolver = new RootBeanDefinition(ResponseStatusExceptionResolver.class);
/* 243 */     responseStatusExceptionResolver.setSource(source);
/* 244 */     responseStatusExceptionResolver.setRole(2);
/* 245 */     responseStatusExceptionResolver.getPropertyValues().add("order", Integer.valueOf(1));
/*     */ 
/* 247 */     String responseStatusExceptionResolverName = parserContext
/* 247 */       .getReaderContext().registerWithGeneratedName(responseStatusExceptionResolver);
/*     */ 
/* 249 */     RootBeanDefinition defaultExceptionResolver = new RootBeanDefinition(DefaultHandlerExceptionResolver.class);
/* 250 */     defaultExceptionResolver.setSource(source);
/* 251 */     defaultExceptionResolver.setRole(2);
/* 252 */     defaultExceptionResolver.getPropertyValues().add("order", Integer.valueOf(2));
/*     */ 
/* 254 */     String defaultExceptionResolverName = parserContext
/* 254 */       .getReaderContext().registerWithGeneratedName(defaultExceptionResolver);
/*     */ 
/* 256 */     parserContext.registerComponent(new BeanComponentDefinition(handlerMappingDef, methodMappingName));
/* 257 */     parserContext.registerComponent(new BeanComponentDefinition(handlerAdapterDef, handlerAdapterName));
/* 258 */     parserContext.registerComponent(new BeanComponentDefinition(uriCompContribDef, uriCompContribName));
/* 259 */     parserContext.registerComponent(new BeanComponentDefinition(exceptionHandlerExceptionResolver, methodExceptionResolverName));
/* 260 */     parserContext.registerComponent(new BeanComponentDefinition(responseStatusExceptionResolver, responseStatusExceptionResolverName));
/* 261 */     parserContext.registerComponent(new BeanComponentDefinition(defaultExceptionResolver, defaultExceptionResolverName));
/* 262 */     parserContext.registerComponent(new BeanComponentDefinition(mappedCsInterceptorDef, mappedInterceptorName));
/*     */ 
/* 265 */     MvcNamespaceUtils.registerDefaultComponents(parserContext, source);
/*     */ 
/* 267 */     parserContext.popAndRegisterContainingComponent();
/*     */ 
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */   private RuntimeBeanReference getConversionService(Element element, Object source, ParserContext parserContext)
/*     */   {
/*     */     RuntimeBeanReference conversionServiceRef;
/*     */     RuntimeBeanReference conversionServiceRef;
/* 274 */     if (element.hasAttribute("conversion-service")) {
/* 275 */       conversionServiceRef = new RuntimeBeanReference(element.getAttribute("conversion-service"));
/*     */     }
/*     */     else {
/* 278 */       RootBeanDefinition conversionDef = new RootBeanDefinition(FormattingConversionServiceFactoryBean.class);
/* 279 */       conversionDef.setSource(source);
/* 280 */       conversionDef.setRole(2);
/* 281 */       String conversionName = parserContext.getReaderContext().registerWithGeneratedName(conversionDef);
/* 282 */       parserContext.registerComponent(new BeanComponentDefinition(conversionDef, conversionName));
/* 283 */       conversionServiceRef = new RuntimeBeanReference(conversionName);
/*     */     }
/* 285 */     return conversionServiceRef;
/*     */   }
/*     */ 
/*     */   private RuntimeBeanReference getValidator(Element element, Object source, ParserContext parserContext) {
/* 289 */     if (element.hasAttribute("validator")) {
/* 290 */       return new RuntimeBeanReference(element.getAttribute("validator"));
/*     */     }
/* 292 */     if (jsr303Present) {
/* 293 */       RootBeanDefinition validatorDef = new RootBeanDefinition(LocalValidatorFactoryBean.class);
/* 294 */       validatorDef.setSource(source);
/* 295 */       validatorDef.setRole(2);
/* 296 */       String validatorName = parserContext.getReaderContext().registerWithGeneratedName(validatorDef);
/* 297 */       parserContext.registerComponent(new BeanComponentDefinition(validatorDef, validatorName));
/* 298 */       return new RuntimeBeanReference(validatorName);
/*     */     }
/*     */ 
/* 301 */     return null;
/*     */   }
/*     */ 
/*     */   private RuntimeBeanReference getContentNegotiationManager(Element element, Object source, ParserContext parserContext)
/*     */   {
/*     */     RuntimeBeanReference contentNegotiationManagerRef;
/*     */     RuntimeBeanReference contentNegotiationManagerRef;
/* 307 */     if (element.hasAttribute("content-negotiation-manager")) {
/* 308 */       contentNegotiationManagerRef = new RuntimeBeanReference(element.getAttribute("content-negotiation-manager"));
/*     */     }
/*     */     else {
/* 311 */       RootBeanDefinition factoryBeanDef = new RootBeanDefinition(ContentNegotiationManagerFactoryBean.class);
/* 312 */       factoryBeanDef.setSource(source);
/* 313 */       factoryBeanDef.setRole(2);
/* 314 */       factoryBeanDef.getPropertyValues().add("mediaTypes", getDefaultMediaTypes());
/*     */ 
/* 316 */       String beanName = "mvcContentNegotiationManager";
/* 317 */       parserContext.getReaderContext().getRegistry().registerBeanDefinition(beanName, factoryBeanDef);
/* 318 */       parserContext.registerComponent(new BeanComponentDefinition(factoryBeanDef, beanName));
/* 319 */       contentNegotiationManagerRef = new RuntimeBeanReference(beanName);
/*     */     }
/* 321 */     return contentNegotiationManagerRef;
/*     */   }
/*     */ 
/*     */   private Properties getDefaultMediaTypes() {
/* 325 */     Properties props = new Properties();
/* 326 */     if (romePresent) {
/* 327 */       props.put("atom", "application/atom+xml");
/* 328 */       props.put("rss", "application/rss+xml");
/*     */     }
/* 330 */     if ((jackson2Present) || (jacksonPresent)) {
/* 331 */       props.put("json", "application/json");
/*     */     }
/* 333 */     if (jaxb2Present) {
/* 334 */       props.put("xml", "application/xml");
/*     */     }
/* 336 */     return props;
/*     */   }
/*     */ 
/*     */   private RuntimeBeanReference getMessageCodesResolver(Element element, Object source, ParserContext parserContext) {
/* 340 */     if (element.hasAttribute("message-codes-resolver")) {
/* 341 */       return new RuntimeBeanReference(element.getAttribute("message-codes-resolver"));
/*     */     }
/* 343 */     return null;
/*     */   }
/*     */ 
/*     */   private String getAsyncTimeout(Element element, Object source, ParserContext parserContext)
/*     */   {
/* 348 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 349 */     return asyncElement != null ? asyncElement.getAttribute("default-timeout") : null;
/*     */   }
/*     */ 
/*     */   private RuntimeBeanReference getAsyncExecutor(Element element, Object source, ParserContext parserContext) {
/* 353 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 354 */     if ((asyncElement != null) && 
/* 355 */       (asyncElement.hasAttribute("task-executor"))) {
/* 356 */       return new RuntimeBeanReference(asyncElement.getAttribute("task-executor"));
/*     */     }
/*     */ 
/* 359 */     return null;
/*     */   }
/*     */ 
/*     */   private ManagedList<?> getCallableInterceptors(Element element, Object source, ParserContext parserContext) {
/* 363 */     ManagedList interceptors = new ManagedList();
/* 364 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 365 */     if (asyncElement != null) {
/* 366 */       Element interceptorsElement = DomUtils.getChildElementByTagName(asyncElement, "callable-interceptors");
/* 367 */       if (interceptorsElement != null) {
/* 368 */         interceptors.setSource(source);
/* 369 */         for (Element converter : DomUtils.getChildElementsByTagName(interceptorsElement, "bean")) {
/* 370 */           BeanDefinitionHolder beanDef = parserContext.getDelegate().parseBeanDefinitionElement(converter);
/* 371 */           beanDef = parserContext.getDelegate().decorateBeanDefinitionIfRequired(converter, beanDef);
/* 372 */           interceptors.add(beanDef);
/*     */         }
/*     */       }
/*     */     }
/* 376 */     return interceptors;
/*     */   }
/*     */ 
/*     */   private ManagedList<?> getDeferredResultInterceptors(Element element, Object source, ParserContext parserContext) {
/* 380 */     ManagedList interceptors = new ManagedList();
/* 381 */     Element asyncElement = DomUtils.getChildElementByTagName(element, "async-support");
/* 382 */     if (asyncElement != null) {
/* 383 */       Element interceptorsElement = DomUtils.getChildElementByTagName(asyncElement, "deferred-result-interceptors");
/* 384 */       if (interceptorsElement != null) {
/* 385 */         interceptors.setSource(source);
/* 386 */         for (Element converter : DomUtils.getChildElementsByTagName(interceptorsElement, "bean")) {
/* 387 */           BeanDefinitionHolder beanDef = parserContext.getDelegate().parseBeanDefinitionElement(converter);
/* 388 */           beanDef = parserContext.getDelegate().decorateBeanDefinitionIfRequired(converter, beanDef);
/* 389 */           interceptors.add(beanDef);
/*     */         }
/*     */       }
/*     */     }
/* 393 */     return interceptors;
/*     */   }
/*     */ 
/*     */   private ManagedList<?> getArgumentResolvers(Element element, Object source, ParserContext parserContext) {
/* 397 */     Element resolversElement = DomUtils.getChildElementByTagName(element, "argument-resolvers");
/* 398 */     if (resolversElement != null) {
/* 399 */       ManagedList argumentResolvers = extractBeanSubElements(resolversElement, parserContext);
/* 400 */       return wrapWebArgumentResolverBeanDefs(argumentResolvers);
/*     */     }
/* 402 */     return null;
/*     */   }
/*     */ 
/*     */   private ManagedList<?> getReturnValueHandlers(Element element, Object source, ParserContext parserContext) {
/* 406 */     Element handlersElement = DomUtils.getChildElementByTagName(element, "return-value-handlers");
/* 407 */     if (handlersElement != null) {
/* 408 */       return extractBeanSubElements(handlersElement, parserContext);
/*     */     }
/* 410 */     return null;
/*     */   }
/*     */ 
/*     */   private ManagedList<?> getMessageConverters(Element element, Object source, ParserContext parserContext)
/*     */   {
/* 415 */     Element convertersElement = DomUtils.getChildElementByTagName(element, "message-converters");
/* 416 */     ManagedList messageConverters = new ManagedList();
/* 417 */     if (convertersElement != null) {
/* 418 */       messageConverters.setSource(source);
/* 419 */       for (Element beanElement : DomUtils.getChildElementsByTagName(convertersElement, new String[] { "bean", "ref" })) {
/* 420 */         Object object = parserContext.getDelegate().parsePropertySubElement(beanElement, null);
/* 421 */         messageConverters.add(object);
/*     */       }
/*     */     }
/*     */ 
/* 425 */     if ((convertersElement == null) || (Boolean.valueOf(convertersElement.getAttribute("register-defaults")).booleanValue())) {
/* 426 */       messageConverters.setSource(source);
/* 427 */       messageConverters.add(createConverterBeanDefinition(ByteArrayHttpMessageConverter.class, source));
/*     */ 
/* 429 */       RootBeanDefinition stringConverterDef = createConverterBeanDefinition(StringHttpMessageConverter.class, source);
/* 430 */       stringConverterDef.getPropertyValues().add("writeAcceptCharset", Boolean.valueOf(false));
/* 431 */       messageConverters.add(stringConverterDef);
/*     */ 
/* 433 */       messageConverters.add(createConverterBeanDefinition(ResourceHttpMessageConverter.class, source));
/* 434 */       messageConverters.add(createConverterBeanDefinition(SourceHttpMessageConverter.class, source));
/* 435 */       messageConverters.add(createConverterBeanDefinition(AllEncompassingFormHttpMessageConverter.class, source));
/* 436 */       if (romePresent) {
/* 437 */         messageConverters.add(createConverterBeanDefinition(AtomFeedHttpMessageConverter.class, source));
/* 438 */         messageConverters.add(createConverterBeanDefinition(RssChannelHttpMessageConverter.class, source));
/*     */       }
/* 440 */       if (jaxb2Present) {
/* 441 */         messageConverters
/* 442 */           .add(createConverterBeanDefinition(Jaxb2RootElementHttpMessageConverter.class, source));
/*     */       }
/*     */ 
/* 444 */       if (jackson2Present) {
/* 445 */         messageConverters.add(createConverterBeanDefinition(MappingJackson2HttpMessageConverter.class, source));
/*     */       }
/* 447 */       else if (jacksonPresent) {
/* 448 */         messageConverters.add(createConverterBeanDefinition(MappingJacksonHttpMessageConverter.class, source));
/*     */       }
/*     */     }
/* 451 */     return messageConverters;
/*     */   }
/*     */ 
/*     */   private RootBeanDefinition createConverterBeanDefinition(Class<? extends HttpMessageConverter> converterClass, Object source)
/*     */   {
/* 458 */     RootBeanDefinition beanDefinition = new RootBeanDefinition(converterClass);
/* 459 */     beanDefinition.setSource(source);
/* 460 */     beanDefinition.setRole(2);
/*     */ 
/* 462 */     return beanDefinition;
/*     */   }
/*     */ 
/*     */   private ManagedList<BeanDefinitionHolder> extractBeanSubElements(Element parentElement, ParserContext parserContext) {
/* 466 */     ManagedList list = new ManagedList();
/* 467 */     list.setSource(parserContext.extractSource(parentElement));
/* 468 */     for (Element beanElement : DomUtils.getChildElementsByTagName(parentElement, "bean")) {
/* 469 */       BeanDefinitionHolder beanDef = parserContext.getDelegate().parseBeanDefinitionElement(beanElement);
/* 470 */       beanDef = parserContext.getDelegate().decorateBeanDefinitionIfRequired(beanElement, beanDef);
/* 471 */       list.add(beanDef);
/*     */     }
/* 473 */     return list;
/*     */   }
/*     */ 
/*     */   private ManagedList<BeanDefinitionHolder> wrapWebArgumentResolverBeanDefs(List<BeanDefinitionHolder> beanDefs) {
/* 477 */     ManagedList result = new ManagedList();
/*     */ 
/* 479 */     for (BeanDefinitionHolder beanDef : beanDefs) {
/* 480 */       String className = beanDef.getBeanDefinition().getBeanClassName();
/* 481 */       Class clazz = ClassUtils.resolveClassName(className, ClassUtils.getDefaultClassLoader());
/*     */ 
/* 483 */       if (WebArgumentResolver.class.isAssignableFrom(clazz)) {
/* 484 */         RootBeanDefinition adapter = new RootBeanDefinition(ServletWebArgumentResolverAdapter.class);
/* 485 */         adapter.getConstructorArgumentValues().addIndexedArgumentValue(0, beanDef);
/* 486 */         result.add(new BeanDefinitionHolder(adapter, beanDef.getBeanName() + "Adapter"));
/*     */       } else {
/* 488 */         result.add(beanDef);
/*     */       }
/*     */     }
/*     */ 
/* 492 */     return result;
/*     */   }
/*     */ 
/*     */   private static class CompositeUriComponentsContributorFactoryBean
/*     */     implements InitializingBean, FactoryBean<CompositeUriComponentsContributor>
/*     */   {
/*     */     private RequestMappingHandlerAdapter handlerAdapter;
/*     */     private ConversionService conversionService;
/*     */     private CompositeUriComponentsContributor uriComponentsContributor;
/*     */ 
/*     */     public void setHandlerAdapter(RequestMappingHandlerAdapter handlerAdapter)
/*     */     {
/* 513 */       this.handlerAdapter = handlerAdapter;
/*     */     }
/*     */ 
/*     */     public void setConversionService(ConversionService conversionService) {
/* 517 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */     public void afterPropertiesSet() throws Exception
/*     */     {
/* 522 */       this.uriComponentsContributor = new CompositeUriComponentsContributor(this.handlerAdapter
/* 523 */         .getArgumentResolvers(), this.conversionService);
/*     */     }
/*     */ 
/*     */     public CompositeUriComponentsContributor getObject() throws Exception
/*     */     {
/* 528 */       return this.uriComponentsContributor;
/*     */     }
/*     */ 
/*     */     public Class<?> getObjectType()
/*     */     {
/* 533 */       return CompositeUriComponentsContributor.class;
/*     */     }
/*     */ 
/*     */     public boolean isSingleton()
/*     */     {
/* 538 */       return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.AnnotationDrivenBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */