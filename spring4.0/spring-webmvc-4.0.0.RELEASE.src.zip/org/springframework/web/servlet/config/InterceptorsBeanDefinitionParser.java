/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*    */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*    */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*    */ import org.springframework.beans.factory.support.ManagedList;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.springframework.web.servlet.handler.MappedInterceptor;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class InterceptorsBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*    */   {
/* 43 */     CompositeComponentDefinition compDefinition = new CompositeComponentDefinition(element.getTagName(), parserContext.extractSource(element));
/* 44 */     parserContext.pushContainingComponent(compDefinition);
/*    */ 
/* 46 */     List interceptors = DomUtils.getChildElementsByTagName(element, new String[] { "bean", "ref", "interceptor" });
/* 47 */     for (Element interceptor : interceptors) {
/* 48 */       RootBeanDefinition mappedInterceptorDef = new RootBeanDefinition(MappedInterceptor.class);
/* 49 */       mappedInterceptorDef.setSource(parserContext.extractSource(interceptor));
/* 50 */       mappedInterceptorDef.setRole(2);
/*    */ 
/* 52 */       ManagedList includePatterns = null;
/* 53 */       ManagedList excludePatterns = null;
/*    */       Object interceptorBean;
/*    */       Object interceptorBean;
/* 55 */       if ("interceptor".equals(interceptor.getLocalName())) {
/* 56 */         includePatterns = getIncludePatterns(interceptor, "mapping");
/* 57 */         excludePatterns = getIncludePatterns(interceptor, "exclude-mapping");
/* 58 */         Element beanElem = (Element)DomUtils.getChildElementsByTagName(interceptor, new String[] { "bean", "ref" }).get(0);
/* 59 */         interceptorBean = parserContext.getDelegate().parsePropertySubElement(beanElem, null);
/*    */       }
/*    */       else {
/* 62 */         interceptorBean = parserContext.getDelegate().parsePropertySubElement(interceptor, null);
/*    */       }
/* 64 */       mappedInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(0, includePatterns);
/* 65 */       mappedInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(1, excludePatterns);
/* 66 */       mappedInterceptorDef.getConstructorArgumentValues().addIndexedArgumentValue(2, interceptorBean);
/*    */ 
/* 68 */       String beanName = parserContext.getReaderContext().registerWithGeneratedName(mappedInterceptorDef);
/* 69 */       parserContext.registerComponent(new BeanComponentDefinition(mappedInterceptorDef, beanName));
/*    */     }
/*    */ 
/* 72 */     parserContext.popAndRegisterContainingComponent();
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */   private ManagedList<String> getIncludePatterns(Element interceptor, String elementName) {
/* 77 */     List paths = DomUtils.getChildElementsByTagName(interceptor, elementName);
/* 78 */     ManagedList patterns = new ManagedList(paths.size());
/* 79 */     for (int i = 0; i < paths.size(); i++) {
/* 80 */       patterns.add(((Element)paths.get(i)).getAttribute("path"));
/*    */     }
/* 82 */     return patterns;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.InterceptorsBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */