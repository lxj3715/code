/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class MvcNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 33 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
/* 34 */     registerBeanDefinitionParser("default-servlet-handler", new DefaultServletHandlerBeanDefinitionParser());
/* 35 */     registerBeanDefinitionParser("interceptors", new InterceptorsBeanDefinitionParser());
/* 36 */     registerBeanDefinitionParser("resources", new ResourcesBeanDefinitionParser());
/* 37 */     registerBeanDefinitionParser("view-controller", new ViewControllerBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.MvcNamespaceHandler
 * JD-Core Version:    0.6.2
 */