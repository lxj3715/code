/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;
/*    */ import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;
/*    */ import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
/*    */ 
/*    */ abstract class MvcNamespaceUtils
/*    */ {
/* 36 */   private static final String BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME = BeanNameUrlHandlerMapping.class
/* 36 */     .getName();
/*    */ 
/* 39 */   private static final String SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME = SimpleControllerHandlerAdapter.class
/* 39 */     .getName();
/*    */ 
/* 42 */   private static final String HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME = HttpRequestHandlerAdapter.class
/* 42 */     .getName();
/*    */ 
/*    */   public static void registerDefaultComponents(ParserContext parserContext, Object source) {
/* 45 */     registerBeanNameUrlHandlerMapping(parserContext, source);
/* 46 */     registerHttpRequestHandlerAdapter(parserContext, source);
/* 47 */     registerSimpleControllerHandlerAdapter(parserContext, source);
/*    */   }
/*    */ 
/*    */   private static void registerBeanNameUrlHandlerMapping(ParserContext parserContext, Object source)
/*    */   {
/* 55 */     if (!parserContext.getRegistry().containsBeanDefinition(BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME)) {
/* 56 */       RootBeanDefinition beanNameMappingDef = new RootBeanDefinition(BeanNameUrlHandlerMapping.class);
/* 57 */       beanNameMappingDef.setSource(source);
/* 58 */       beanNameMappingDef.setRole(2);
/* 59 */       beanNameMappingDef.getPropertyValues().add("order", Integer.valueOf(2));
/* 60 */       parserContext.getRegistry().registerBeanDefinition(BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME, beanNameMappingDef);
/* 61 */       parserContext.registerComponent(new BeanComponentDefinition(beanNameMappingDef, BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME));
/*    */     }
/*    */   }
/*    */ 
/*    */   private static void registerHttpRequestHandlerAdapter(ParserContext parserContext, Object source)
/*    */   {
/* 70 */     if (!parserContext.getRegistry().containsBeanDefinition(HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME)) {
/* 71 */       RootBeanDefinition handlerAdapterDef = new RootBeanDefinition(HttpRequestHandlerAdapter.class);
/* 72 */       handlerAdapterDef.setSource(source);
/* 73 */       handlerAdapterDef.setRole(2);
/* 74 */       parserContext.getRegistry().registerBeanDefinition(HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME, handlerAdapterDef);
/* 75 */       parserContext.registerComponent(new BeanComponentDefinition(handlerAdapterDef, HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME));
/*    */     }
/*    */   }
/*    */ 
/*    */   private static void registerSimpleControllerHandlerAdapter(ParserContext parserContext, Object source)
/*    */   {
/* 84 */     if (!parserContext.getRegistry().containsBeanDefinition(SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME)) {
/* 85 */       RootBeanDefinition handlerAdapterDef = new RootBeanDefinition(SimpleControllerHandlerAdapter.class);
/* 86 */       handlerAdapterDef.setSource(source);
/* 87 */       handlerAdapterDef.setRole(2);
/* 88 */       parserContext.getRegistry().registerBeanDefinition(SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME, handlerAdapterDef);
/* 89 */       parserContext.registerComponent(new BeanComponentDefinition(handlerAdapterDef, SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.MvcNamespaceUtils
 * JD-Core Version:    0.6.2
 */