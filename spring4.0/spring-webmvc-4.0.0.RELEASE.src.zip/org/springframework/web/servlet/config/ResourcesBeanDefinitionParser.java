/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class ResourcesBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  51 */     Object source = parserContext.extractSource(element);
/*     */ 
/*  53 */     String resourceHandlerName = registerResourceHandler(parserContext, element, source);
/*  54 */     if (resourceHandlerName == null) {
/*  55 */       return null;
/*     */     }
/*     */ 
/*  58 */     Map urlMap = new ManagedMap();
/*  59 */     String resourceRequestPath = element.getAttribute("mapping");
/*  60 */     if (!StringUtils.hasText(resourceRequestPath)) {
/*  61 */       parserContext.getReaderContext().error("The 'mapping' attribute is required.", parserContext.extractSource(element));
/*  62 */       return null;
/*     */     }
/*  64 */     urlMap.put(resourceRequestPath, resourceHandlerName);
/*     */ 
/*  66 */     RootBeanDefinition handlerMappingDef = new RootBeanDefinition(SimpleUrlHandlerMapping.class);
/*  67 */     handlerMappingDef.setSource(source);
/*  68 */     handlerMappingDef.setRole(2);
/*  69 */     handlerMappingDef.getPropertyValues().add("urlMap", urlMap);
/*     */ 
/*  71 */     String order = element.getAttribute("order");
/*     */ 
/*  73 */     handlerMappingDef.getPropertyValues().add("order", StringUtils.hasText(order) ? order : Integer.valueOf(2147483646));
/*     */ 
/*  75 */     String beanName = parserContext.getReaderContext().generateBeanName(handlerMappingDef);
/*  76 */     parserContext.getRegistry().registerBeanDefinition(beanName, handlerMappingDef);
/*  77 */     parserContext.registerComponent(new BeanComponentDefinition(handlerMappingDef, beanName));
/*     */ 
/*  81 */     MvcNamespaceUtils.registerDefaultComponents(parserContext, source);
/*     */ 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   private String registerResourceHandler(ParserContext parserContext, Element element, Object source) {
/*  87 */     String locationAttr = element.getAttribute("location");
/*  88 */     if (!StringUtils.hasText(locationAttr)) {
/*  89 */       parserContext.getReaderContext().error("The 'location' attribute is required.", parserContext.extractSource(element));
/*  90 */       return null;
/*     */     }
/*     */ 
/*  93 */     ManagedList locations = new ManagedList();
/*  94 */     locations.addAll(Arrays.asList(StringUtils.commaDelimitedListToStringArray(locationAttr)));
/*     */ 
/*  96 */     RootBeanDefinition resourceHandlerDef = new RootBeanDefinition(ResourceHttpRequestHandler.class);
/*  97 */     resourceHandlerDef.setSource(source);
/*  98 */     resourceHandlerDef.setRole(2);
/*  99 */     resourceHandlerDef.getPropertyValues().add("locations", locations);
/*     */ 
/* 101 */     String cacheSeconds = element.getAttribute("cache-period");
/* 102 */     if (StringUtils.hasText(cacheSeconds)) {
/* 103 */       resourceHandlerDef.getPropertyValues().add("cacheSeconds", cacheSeconds);
/*     */     }
/*     */ 
/* 106 */     String beanName = parserContext.getReaderContext().generateBeanName(resourceHandlerDef);
/* 107 */     parserContext.getRegistry().registerBeanDefinition(beanName, resourceHandlerDef);
/* 108 */     parserContext.registerComponent(new BeanComponentDefinition(resourceHandlerDef, beanName));
/* 109 */     return beanName;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.ResourcesBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */