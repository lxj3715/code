/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.PropertyValue;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.ManagedMap;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*    */ import org.springframework.web.servlet.mvc.ParameterizableViewController;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class ViewControllerBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   private static final String HANDLER_MAPPING_BEAN_NAME = "org.springframework.web.servlet.config.viewControllerHandlerMapping";
/*    */ 
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*    */   {
/* 49 */     Object source = parserContext.extractSource(element);
/*    */ 
/* 52 */     BeanDefinition handlerMappingDef = registerHandlerMapping(parserContext, source);
/*    */ 
/* 55 */     MvcNamespaceUtils.registerDefaultComponents(parserContext, source);
/*    */ 
/* 58 */     RootBeanDefinition viewControllerDef = new RootBeanDefinition(ParameterizableViewController.class);
/* 59 */     viewControllerDef.setSource(source);
/* 60 */     if (element.hasAttribute("view-name"))
/* 61 */       viewControllerDef.getPropertyValues().add("viewName", element.getAttribute("view-name"));
/*    */     Map urlMap;
/*    */     Map urlMap;
/* 64 */     if (handlerMappingDef.getPropertyValues().contains("urlMap")) {
/* 65 */       urlMap = (Map)handlerMappingDef.getPropertyValues().getPropertyValue("urlMap").getValue();
/*    */     }
/*    */     else {
/* 68 */       urlMap = new ManagedMap();
/* 69 */       handlerMappingDef.getPropertyValues().add("urlMap", urlMap);
/*    */     }
/* 71 */     urlMap.put(element.getAttribute("path"), viewControllerDef);
/*    */ 
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */   private BeanDefinition registerHandlerMapping(ParserContext parserContext, Object source) {
/* 77 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping")) {
/* 78 */       RootBeanDefinition handlerMappingDef = new RootBeanDefinition(SimpleUrlHandlerMapping.class);
/* 79 */       handlerMappingDef.setSource(source);
/* 80 */       handlerMappingDef.getPropertyValues().add("order", "1");
/* 81 */       handlerMappingDef.setRole(2);
/* 82 */       parserContext.getRegistry().registerBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping", handlerMappingDef);
/* 83 */       parserContext.registerComponent(new BeanComponentDefinition(handlerMappingDef, "org.springframework.web.servlet.config.viewControllerHandlerMapping"));
/* 84 */       return handlerMappingDef;
/*    */     }
/*    */ 
/* 87 */     return parserContext.getRegistry().getBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.ViewControllerBeanDefinitionParser
 * JD-Core Version:    0.6.2
 */