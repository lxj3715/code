/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.DeferredResultProcessingInterceptor;
/*     */ 
/*     */ public class AsyncSupportConfigurer
/*     */ {
/*     */   private AsyncTaskExecutor taskExecutor;
/*     */   private Long timeout;
/*  43 */   private final List<CallableProcessingInterceptor> callableInterceptors = new ArrayList();
/*     */ 
/*  46 */   private final List<DeferredResultProcessingInterceptor> deferredResultInterceptors = new ArrayList();
/*     */ 
/*     */   public AsyncSupportConfigurer setTaskExecutor(AsyncTaskExecutor taskExecutor)
/*     */   {
/*  62 */     this.taskExecutor = taskExecutor;
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */   public AsyncSupportConfigurer setDefaultTimeout(long timeout)
/*     */   {
/*  77 */     this.timeout = Long.valueOf(timeout);
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */   public AsyncSupportConfigurer registerCallableInterceptors(CallableProcessingInterceptor[] interceptors)
/*     */   {
/*  89 */     Assert.notNull(interceptors, "Interceptors are required");
/*  90 */     this.callableInterceptors.addAll(Arrays.asList(interceptors));
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   public AsyncSupportConfigurer registerDeferredResultInterceptors(DeferredResultProcessingInterceptor[] interceptors)
/*     */   {
/* 101 */     Assert.notNull(interceptors, "Interceptors are required");
/* 102 */     this.deferredResultInterceptors.addAll(Arrays.asList(interceptors));
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   protected AsyncTaskExecutor getTaskExecutor() {
/* 107 */     return this.taskExecutor;
/*     */   }
/*     */ 
/*     */   protected Long getTimeout() {
/* 111 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   protected List<CallableProcessingInterceptor> getCallableInterceptors() {
/* 115 */     return this.callableInterceptors;
/*     */   }
/*     */ 
/*     */   protected List<DeferredResultProcessingInterceptor> getDeferredResultInterceptors() {
/* 119 */     return this.deferredResultInterceptors;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer
 * JD-Core Version:    0.6.2
 */