/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ 
/*     */ public class ContentNegotiationConfigurer
/*     */ {
/*  40 */   private final ContentNegotiationManagerFactoryBean factoryBean = new ContentNegotiationManagerFactoryBean();
/*     */ 
/*  42 */   private final Map<String, MediaType> mediaTypes = new HashMap();
/*     */ 
/*     */   public ContentNegotiationConfigurer(ServletContext servletContext)
/*     */   {
/*  49 */     this.factoryBean.setServletContext(servletContext);
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer favorPathExtension(boolean favorPathExtension)
/*     */   {
/*  60 */     this.factoryBean.setFavorPathExtension(favorPathExtension);
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer mediaType(String extension, MediaType mediaType)
/*     */   {
/*  70 */     this.mediaTypes.put(extension, mediaType);
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer mediaTypes(Map<String, MediaType> mediaTypes)
/*     */   {
/*  80 */     if (mediaTypes != null) {
/*  81 */       this.mediaTypes.putAll(mediaTypes);
/*     */     }
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer replaceMediaTypes(Map<String, MediaType> mediaTypes)
/*     */   {
/*  92 */     this.mediaTypes.clear();
/*  93 */     mediaTypes(mediaTypes);
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer useJaf(boolean useJaf)
/*     */   {
/* 106 */     this.factoryBean.setUseJaf(useJaf);
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer favorParameter(boolean favorParameter)
/*     */   {
/* 122 */     this.factoryBean.setFavorParameter(favorParameter);
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer parameterName(String parameterName)
/*     */   {
/* 132 */     this.factoryBean.setParameterName(parameterName);
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer ignoreAcceptHeader(boolean ignoreAcceptHeader)
/*     */   {
/* 144 */     this.factoryBean.setIgnoreAcceptHeader(ignoreAcceptHeader);
/* 145 */     return this;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationConfigurer defaultContentType(MediaType defaultContentType)
/*     */   {
/* 155 */     this.factoryBean.setDefaultContentType(defaultContentType);
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */   protected ContentNegotiationManager getContentNegotiationManager()
/*     */     throws Exception
/*     */   {
/* 163 */     if (!this.mediaTypes.isEmpty()) {
/* 164 */       this.factoryBean.addMediaTypes(this.mediaTypes);
/*     */     }
/* 166 */     this.factoryBean.afterPropertiesSet();
/* 167 */     return this.factoryBean.getObject();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer
 * JD-Core Version:    0.6.2
 */