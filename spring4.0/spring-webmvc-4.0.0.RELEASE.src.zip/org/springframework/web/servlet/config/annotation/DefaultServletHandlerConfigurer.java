/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*    */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*    */ import org.springframework.web.servlet.resource.DefaultServletHttpRequestHandler;
/*    */ 
/*    */ public class DefaultServletHandlerConfigurer
/*    */ {
/*    */   private final ServletContext servletContext;
/*    */   private DefaultServletHttpRequestHandler handler;
/*    */ 
/*    */   public DefaultServletHandlerConfigurer(ServletContext servletContext)
/*    */   {
/* 54 */     Assert.notNull(servletContext, "A ServletContext is required to configure default servlet handling");
/* 55 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */   public void enable()
/*    */   {
/* 65 */     enable(null);
/*    */   }
/*    */ 
/*    */   public void enable(String defaultServletName)
/*    */   {
/* 74 */     this.handler = new DefaultServletHttpRequestHandler();
/* 75 */     this.handler.setDefaultServletName(defaultServletName);
/* 76 */     this.handler.setServletContext(this.servletContext);
/*    */   }
/*    */ 
/*    */   protected AbstractHandlerMapping getHandlerMapping()
/*    */   {
/* 85 */     if (this.handler == null) {
/* 86 */       return null;
/*    */     }
/*    */ 
/* 89 */     Map urlMap = new HashMap();
/* 90 */     urlMap.put("/**", this.handler);
/*    */ 
/* 92 */     SimpleUrlHandlerMapping handlerMapping = new SimpleUrlHandlerMapping();
/* 93 */     handlerMapping.setOrder(2147483647);
/* 94 */     handlerMapping.setUrlMap(urlMap);
/* 95 */     return handlerMapping;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer
 * JD-Core Version:    0.6.2
 */