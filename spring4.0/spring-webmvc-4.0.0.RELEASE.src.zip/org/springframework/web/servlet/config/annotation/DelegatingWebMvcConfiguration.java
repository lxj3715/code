/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ 
/*     */ @Configuration
/*     */ public class DelegatingWebMvcConfiguration extends WebMvcConfigurationSupport
/*     */ {
/*  43 */   private final WebMvcConfigurerComposite configurers = new WebMvcConfigurerComposite();
/*     */ 
/*     */   @Autowired(required=false)
/*     */   public void setConfigurers(List<WebMvcConfigurer> configurers) {
/*  47 */     if ((configurers == null) || (configurers.isEmpty())) {
/*  48 */       return;
/*     */     }
/*  50 */     this.configurers.addWebMvcConfigurers(configurers);
/*     */   }
/*     */ 
/*     */   protected void addInterceptors(InterceptorRegistry registry)
/*     */   {
/*  55 */     this.configurers.addInterceptors(registry);
/*     */   }
/*     */ 
/*     */   protected void configureContentNegotiation(ContentNegotiationConfigurer configurer)
/*     */   {
/*  60 */     this.configurers.configureContentNegotiation(configurer);
/*     */   }
/*     */ 
/*     */   public void configureAsyncSupport(AsyncSupportConfigurer configurer)
/*     */   {
/*  65 */     this.configurers.configureAsyncSupport(configurer);
/*     */   }
/*     */ 
/*     */   protected void addViewControllers(ViewControllerRegistry registry)
/*     */   {
/*  70 */     this.configurers.addViewControllers(registry);
/*     */   }
/*     */ 
/*     */   protected void addResourceHandlers(ResourceHandlerRegistry registry)
/*     */   {
/*  75 */     this.configurers.addResourceHandlers(registry);
/*     */   }
/*     */ 
/*     */   protected void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer)
/*     */   {
/*  80 */     this.configurers.configureDefaultServletHandling(configurer);
/*     */   }
/*     */ 
/*     */   protected void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/*  85 */     this.configurers.addArgumentResolvers(argumentResolvers);
/*     */   }
/*     */ 
/*     */   protected void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/*  90 */     this.configurers.addReturnValueHandlers(returnValueHandlers);
/*     */   }
/*     */ 
/*     */   protected void configureMessageConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/*  95 */     this.configurers.configureMessageConverters(converters);
/*     */   }
/*     */ 
/*     */   protected void addFormatters(FormatterRegistry registry)
/*     */   {
/* 100 */     this.configurers.addFormatters(registry);
/*     */   }
/*     */ 
/*     */   protected Validator getValidator()
/*     */   {
/* 105 */     return this.configurers.getValidator();
/*     */   }
/*     */ 
/*     */   protected MessageCodesResolver getMessageCodesResolver()
/*     */   {
/* 110 */     return this.configurers.getMessageCodesResolver();
/*     */   }
/*     */ 
/*     */   protected void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */   {
/* 115 */     this.configurers.configureHandlerExceptionResolvers(exceptionResolvers);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.DelegatingWebMvcConfiguration
 * JD-Core Version:    0.6.2
 */