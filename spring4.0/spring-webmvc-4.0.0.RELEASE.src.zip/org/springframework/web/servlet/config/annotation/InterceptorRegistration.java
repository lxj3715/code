/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.web.servlet.HandlerInterceptor;
/*    */ import org.springframework.web.servlet.handler.MappedInterceptor;
/*    */ 
/*    */ public class InterceptorRegistration
/*    */ {
/*    */   private final HandlerInterceptor interceptor;
/* 39 */   private final List<String> includePatterns = new ArrayList();
/*    */ 
/* 41 */   private final List<String> excludePatterns = new ArrayList();
/*    */ 
/*    */   public InterceptorRegistration(HandlerInterceptor interceptor)
/*    */   {
/* 47 */     Assert.notNull(interceptor, "Interceptor is required");
/* 48 */     this.interceptor = interceptor;
/*    */   }
/*    */ 
/*    */   public InterceptorRegistration addPathPatterns(String[] patterns)
/*    */   {
/* 55 */     this.includePatterns.addAll(Arrays.asList(patterns));
/* 56 */     return this;
/*    */   }
/*    */ 
/*    */   public InterceptorRegistration excludePathPatterns(String[] patterns)
/*    */   {
/* 63 */     this.excludePatterns.addAll(Arrays.asList(patterns));
/* 64 */     return this;
/*    */   }
/*    */ 
/*    */   protected Object getInterceptor()
/*    */   {
/* 72 */     if (this.includePatterns.isEmpty()) {
/* 73 */       return this.interceptor;
/*    */     }
/* 75 */     return new MappedInterceptor(toArray(this.includePatterns), toArray(this.excludePatterns), this.interceptor);
/*    */   }
/*    */ 
/*    */   private static String[] toArray(List<String> list) {
/* 79 */     if (CollectionUtils.isEmpty(list)) {
/* 80 */       return null;
/*    */     }
/*    */ 
/* 83 */     return (String[])list.toArray(new String[list.size()]);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.InterceptorRegistration
 * JD-Core Version:    0.6.2
 */