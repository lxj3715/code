/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ 
/*     */ public class ResourceHandlerRegistration
/*     */ {
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final String[] pathPatterns;
/*  42 */   private final List<Resource> locations = new ArrayList();
/*     */   private Integer cachePeriod;
/*     */ 
/*     */   public ResourceHandlerRegistration(ResourceLoader resourceLoader, String[] pathPatterns)
/*     */   {
/*  52 */     Assert.notEmpty(pathPatterns, "At least one path pattern is required for resource handling.");
/*  53 */     this.resourceLoader = resourceLoader;
/*  54 */     this.pathPatterns = pathPatterns;
/*     */   }
/*     */ 
/*     */   public ResourceHandlerRegistration addResourceLocations(String[] resourceLocations)
/*     */   {
/*  67 */     for (String location : resourceLocations) {
/*  68 */       this.locations.add(this.resourceLoader.getResource(location));
/*     */     }
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */   public ResourceHandlerRegistration setCachePeriod(Integer cachePeriod)
/*     */   {
/*  81 */     this.cachePeriod = cachePeriod;
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */   protected String[] getPathPatterns()
/*     */   {
/*  89 */     return this.pathPatterns;
/*     */   }
/*     */ 
/*     */   protected ResourceHttpRequestHandler getRequestHandler()
/*     */   {
/*  96 */     Assert.isTrue(!CollectionUtils.isEmpty(this.locations), "At least one location is required for resource handling.");
/*  97 */     ResourceHttpRequestHandler requestHandler = new ResourceHttpRequestHandler();
/*  98 */     requestHandler.setLocations(this.locations);
/*  99 */     if (this.cachePeriod != null) {
/* 100 */       requestHandler.setCacheSeconds(this.cachePeriod.intValue());
/*     */     }
/* 102 */     return requestHandler;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.ResourceHandlerRegistration
 * JD-Core Version:    0.6.2
 */