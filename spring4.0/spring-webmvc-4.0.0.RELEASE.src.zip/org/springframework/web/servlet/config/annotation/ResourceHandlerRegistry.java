/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ 
/*     */ public class ResourceHandlerRegistry
/*     */ {
/*     */   private final ServletContext servletContext;
/*     */   private final ApplicationContext applicationContext;
/*  58 */   private final List<ResourceHandlerRegistration> registrations = new ArrayList();
/*     */ 
/*  60 */   private int order = 2147483646;
/*     */ 
/*     */   public ResourceHandlerRegistry(ApplicationContext applicationContext, ServletContext servletContext) {
/*  63 */     Assert.notNull(applicationContext, "ApplicationContext is required");
/*  64 */     this.applicationContext = applicationContext;
/*  65 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public ResourceHandlerRegistration addResourceHandler(String[] pathPatterns)
/*     */   {
/*  75 */     ResourceHandlerRegistration registration = new ResourceHandlerRegistration(this.applicationContext, pathPatterns);
/*  76 */     this.registrations.add(registration);
/*  77 */     return registration;
/*     */   }
/*     */ 
/*     */   public boolean hasMappingForPattern(String pathPattern)
/*     */   {
/*  84 */     for (ResourceHandlerRegistration registration : this.registrations) {
/*  85 */       if (Arrays.asList(registration.getPathPatterns()).contains(pathPattern)) {
/*  86 */         return true;
/*     */       }
/*     */     }
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */   public ResourceHandlerRegistry setOrder(int order)
/*     */   {
/*  97 */     this.order = order;
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   protected AbstractHandlerMapping getHandlerMapping()
/*     */   {
/* 105 */     if (this.registrations.isEmpty()) {
/* 106 */       return null;
/*     */     }
/*     */ 
/* 109 */     Map urlMap = new LinkedHashMap();
/* 110 */     for (ResourceHandlerRegistration registration : this.registrations) {
/* 111 */       for (String pathPattern : registration.getPathPatterns()) {
/* 112 */         ResourceHttpRequestHandler requestHandler = registration.getRequestHandler();
/* 113 */         requestHandler.setServletContext(this.servletContext);
/* 114 */         requestHandler.setApplicationContext(this.applicationContext);
/* 115 */         urlMap.put(pathPattern, requestHandler);
/*     */       }
/*     */     }
/*     */ 
/* 119 */     SimpleUrlHandlerMapping handlerMapping = new SimpleUrlHandlerMapping();
/* 120 */     handlerMapping.setOrder(this.order);
/* 121 */     handlerMapping.setUrlMap(urlMap);
/* 122 */     return handlerMapping;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry
 * JD-Core Version:    0.6.2
 */