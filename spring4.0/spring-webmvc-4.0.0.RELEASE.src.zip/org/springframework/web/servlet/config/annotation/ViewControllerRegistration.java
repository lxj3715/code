/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.servlet.mvc.ParameterizableViewController;
/*    */ 
/*    */ public class ViewControllerRegistration
/*    */ {
/*    */   private final String urlPath;
/*    */   private String viewName;
/*    */ 
/*    */   public ViewControllerRegistration(String urlPath)
/*    */   {
/* 41 */     Assert.notNull(urlPath, "A URL path is required to create a view controller.");
/* 42 */     this.urlPath = urlPath;
/*    */   }
/*    */ 
/*    */   public void setViewName(String viewName)
/*    */   {
/* 51 */     this.viewName = viewName;
/*    */   }
/*    */ 
/*    */   protected String getUrlPath()
/*    */   {
/* 58 */     return this.urlPath;
/*    */   }
/*    */ 
/*    */   protected Object getViewController()
/*    */   {
/* 65 */     ParameterizableViewController controller = new ParameterizableViewController();
/* 66 */     controller.setViewName(this.viewName);
/* 67 */     return controller;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.ViewControllerRegistration
 * JD-Core Version:    0.6.2
 */