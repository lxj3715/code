/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*    */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*    */ 
/*    */ public class ViewControllerRegistry
/*    */ {
/* 39 */   private final List<ViewControllerRegistration> registrations = new ArrayList();
/*    */ 
/* 41 */   private int order = 1;
/*    */ 
/*    */   public ViewControllerRegistration addViewController(String urlPath) {
/* 44 */     ViewControllerRegistration registration = new ViewControllerRegistration(urlPath);
/* 45 */     this.registrations.add(registration);
/* 46 */     return registration;
/*    */   }
/*    */ 
/*    */   public void setOrder(int order)
/*    */   {
/* 55 */     this.order = order;
/*    */   }
/*    */ 
/*    */   protected AbstractHandlerMapping getHandlerMapping()
/*    */   {
/* 62 */     if (this.registrations.isEmpty()) {
/* 63 */       return null;
/*    */     }
/*    */ 
/* 66 */     Map urlMap = new LinkedHashMap();
/* 67 */     for (ViewControllerRegistration registration : this.registrations) {
/* 68 */       urlMap.put(registration.getUrlPath(), registration.getViewController());
/*    */     }
/*    */ 
/* 71 */     SimpleUrlHandlerMapping handlerMapping = new SimpleUrlHandlerMapping();
/* 72 */     handlerMapping.setOrder(this.order);
/* 73 */     handlerMapping.setUrlMap(urlMap);
/* 74 */     return handlerMapping;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.ViewControllerRegistry
 * JD-Core Version:    0.6.2
 */