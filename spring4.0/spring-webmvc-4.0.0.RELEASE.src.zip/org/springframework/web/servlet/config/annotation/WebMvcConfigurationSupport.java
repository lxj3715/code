/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.format.support.FormattingConversionService;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.ConversionServiceExposingInterceptor;
/*     */ import org.springframework.web.servlet.handler.HandlerExceptionResolverComposite;
/*     */ import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;
/*     */ 
/*     */ public class WebMvcConfigurationSupport
/*     */   implements ApplicationContextAware, ServletContextAware
/*     */ {
/* 148 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", WebMvcConfigurationSupport.class
/* 148 */     .getClassLoader());
/*     */ 
/* 151 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", WebMvcConfigurationSupport.class
/* 151 */     .getClassLoader())) && 
/* 152 */     (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", WebMvcConfigurationSupport.class
/* 152 */     .getClassLoader()));
/*     */ 
/* 155 */   private static final boolean jacksonPresent = (ClassUtils.isPresent("org.codehaus.jackson.map.ObjectMapper", WebMvcConfigurationSupport.class
/* 155 */     .getClassLoader())) && 
/* 156 */     (ClassUtils.isPresent("org.codehaus.jackson.JsonGenerator", WebMvcConfigurationSupport.class
/* 156 */     .getClassLoader()));
/*     */ 
/* 159 */   private static boolean romePresent = ClassUtils.isPresent("com.sun.syndication.feed.WireFeed", WebMvcConfigurationSupport.class
/* 159 */     .getClassLoader());
/*     */   private ServletContext servletContext;
/*     */   private ApplicationContext applicationContext;
/*     */   private List<Object> interceptors;
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*     */   private List<HttpMessageConverter<?>> messageConverters;
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 178 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */     throws BeansException
/*     */   {
/* 186 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public RequestMappingHandlerMapping requestMappingHandlerMapping()
/*     */   {
/* 195 */     RequestMappingHandlerMapping handlerMapping = new RequestMappingHandlerMapping();
/* 196 */     handlerMapping.setOrder(0);
/* 197 */     handlerMapping.setInterceptors(getInterceptors());
/* 198 */     handlerMapping.setContentNegotiationManager(mvcContentNegotiationManager());
/* 199 */     return handlerMapping;
/*     */   }
/*     */ 
/*     */   protected final Object[] getInterceptors()
/*     */   {
/* 208 */     if (this.interceptors == null) {
/* 209 */       InterceptorRegistry registry = new InterceptorRegistry();
/* 210 */       addInterceptors(registry);
/* 211 */       registry.addInterceptor(new ConversionServiceExposingInterceptor(mvcConversionService()));
/* 212 */       this.interceptors = registry.getInterceptors();
/*     */     }
/* 214 */     return this.interceptors.toArray();
/*     */   }
/*     */ 
/*     */   protected void addInterceptors(InterceptorRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public ContentNegotiationManager mvcContentNegotiationManager()
/*     */   {
/* 231 */     if (this.contentNegotiationManager == null) {
/* 232 */       ContentNegotiationConfigurer configurer = new ContentNegotiationConfigurer(this.servletContext);
/* 233 */       configurer.mediaTypes(getDefaultMediaTypes());
/* 234 */       configureContentNegotiation(configurer);
/*     */       try {
/* 236 */         this.contentNegotiationManager = configurer.getContentNegotiationManager();
/*     */       }
/*     */       catch (Exception e) {
/* 239 */         throw new BeanInitializationException("Could not create ContentNegotiationManager", e);
/*     */       }
/*     */     }
/* 242 */     return this.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   protected Map<String, MediaType> getDefaultMediaTypes() {
/* 246 */     Map map = new HashMap();
/* 247 */     if (romePresent) {
/* 248 */       map.put("atom", MediaType.APPLICATION_ATOM_XML);
/* 249 */       map.put("rss", MediaType.valueOf("application/rss+xml"));
/*     */     }
/* 251 */     if ((jackson2Present) || (jacksonPresent)) {
/* 252 */       map.put("json", MediaType.APPLICATION_JSON);
/*     */     }
/* 254 */     if (jaxb2Present) {
/* 255 */       map.put("xml", MediaType.APPLICATION_XML);
/*     */     }
/* 257 */     return map;
/*     */   }
/*     */ 
/*     */   protected void configureContentNegotiation(ContentNegotiationConfigurer configurer)
/*     */   {
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public HandlerMapping viewControllerHandlerMapping()
/*     */   {
/* 274 */     ViewControllerRegistry registry = new ViewControllerRegistry();
/* 275 */     addViewControllers(registry);
/*     */ 
/* 277 */     AbstractHandlerMapping handlerMapping = registry.getHandlerMapping();
/* 278 */     handlerMapping = handlerMapping != null ? handlerMapping : new EmptyHandlerMapping(null);
/* 279 */     handlerMapping.setInterceptors(getInterceptors());
/* 280 */     return handlerMapping;
/*     */   }
/*     */ 
/*     */   protected void addViewControllers(ViewControllerRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public BeanNameUrlHandlerMapping beanNameHandlerMapping()
/*     */   {
/* 296 */     BeanNameUrlHandlerMapping mapping = new BeanNameUrlHandlerMapping();
/* 297 */     mapping.setOrder(2);
/* 298 */     mapping.setInterceptors(getInterceptors());
/* 299 */     return mapping;
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public HandlerMapping resourceHandlerMapping()
/*     */   {
/* 309 */     ResourceHandlerRegistry registry = new ResourceHandlerRegistry(this.applicationContext, this.servletContext);
/* 310 */     addResourceHandlers(registry);
/* 311 */     AbstractHandlerMapping handlerMapping = registry.getHandlerMapping();
/* 312 */     handlerMapping = handlerMapping != null ? handlerMapping : new EmptyHandlerMapping(null);
/* 313 */     return handlerMapping;
/*     */   }
/*     */ 
/*     */   protected void addResourceHandlers(ResourceHandlerRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public HandlerMapping defaultServletHandlerMapping()
/*     */   {
/* 330 */     DefaultServletHandlerConfigurer configurer = new DefaultServletHandlerConfigurer(this.servletContext);
/* 331 */     configureDefaultServletHandling(configurer);
/* 332 */     AbstractHandlerMapping handlerMapping = configurer.getHandlerMapping();
/* 333 */     handlerMapping = handlerMapping != null ? handlerMapping : new EmptyHandlerMapping(null);
/* 334 */     return handlerMapping;
/*     */   }
/*     */ 
/*     */   protected void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer)
/*     */   {
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public RequestMappingHandlerAdapter requestMappingHandlerAdapter()
/*     */   {
/* 356 */     List argumentResolvers = new ArrayList();
/* 357 */     addArgumentResolvers(argumentResolvers);
/*     */ 
/* 359 */     List returnValueHandlers = new ArrayList();
/* 360 */     addReturnValueHandlers(returnValueHandlers);
/*     */ 
/* 362 */     RequestMappingHandlerAdapter adapter = new RequestMappingHandlerAdapter();
/* 363 */     adapter.setContentNegotiationManager(mvcContentNegotiationManager());
/* 364 */     adapter.setMessageConverters(getMessageConverters());
/* 365 */     adapter.setWebBindingInitializer(getConfigurableWebBindingInitializer());
/* 366 */     adapter.setCustomArgumentResolvers(argumentResolvers);
/* 367 */     adapter.setCustomReturnValueHandlers(returnValueHandlers);
/*     */ 
/* 369 */     AsyncSupportConfigurer configurer = new AsyncSupportConfigurer();
/* 370 */     configureAsyncSupport(configurer);
/*     */ 
/* 372 */     if (configurer.getTaskExecutor() != null) {
/* 373 */       adapter.setTaskExecutor(configurer.getTaskExecutor());
/*     */     }
/* 375 */     if (configurer.getTimeout() != null) {
/* 376 */       adapter.setAsyncRequestTimeout(configurer.getTimeout().longValue());
/*     */     }
/* 378 */     adapter.setCallableInterceptors(configurer.getCallableInterceptors());
/* 379 */     adapter.setDeferredResultInterceptors(configurer.getDeferredResultInterceptors());
/*     */ 
/* 381 */     return adapter;
/*     */   }
/*     */ 
/*     */   protected ConfigurableWebBindingInitializer getConfigurableWebBindingInitializer()
/*     */   {
/* 389 */     ConfigurableWebBindingInitializer initializer = new ConfigurableWebBindingInitializer();
/* 390 */     initializer.setConversionService(mvcConversionService());
/* 391 */     initializer.setValidator(mvcValidator());
/* 392 */     initializer.setMessageCodesResolver(getMessageCodesResolver());
/* 393 */     return initializer;
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public FormattingConversionService mvcConversionService()
/*     */   {
/* 403 */     FormattingConversionService conversionService = new DefaultFormattingConversionService();
/* 404 */     addFormatters(conversionService);
/* 405 */     return conversionService;
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public Validator mvcValidator()
/*     */   {
/* 418 */     Validator validator = getValidator();
/* 419 */     if (validator == null)
/* 420 */       if (ClassUtils.isPresent("javax.validation.Validator", getClass().getClassLoader()))
/*     */       {
/*     */         try {
/* 423 */           String className = "org.springframework.validation.beanvalidation.LocalValidatorFactoryBean";
/* 424 */           clazz = ClassUtils.forName(className, WebMvcConfigurationSupport.class.getClassLoader());
/*     */         }
/*     */         catch (ClassNotFoundException e)
/*     */         {
/*     */           Class clazz;
/* 427 */           throw new BeanInitializationException("Could not find default validator", e);
/*     */         }
/*     */         catch (LinkageError e) {
/* 430 */           throw new BeanInitializationException("Could not find default validator", e);
/*     */         }
/*     */         Class clazz;
/* 432 */         validator = (Validator)BeanUtils.instantiate(clazz);
/*     */       }
/*     */       else {
/* 435 */         validator = new Validator()
/*     */         {
/*     */           public boolean supports(Class<?> clazz) {
/* 438 */             return false;
/*     */           }
/*     */ 
/*     */           public void validate(Object target, Errors errors)
/*     */           {
/*     */           }
/*     */         };
/*     */       }
/* 446 */     return validator;
/*     */   }
/*     */ 
/*     */   protected Validator getValidator()
/*     */   {
/* 453 */     return null;
/*     */   }
/*     */ 
/*     */   protected MessageCodesResolver getMessageCodesResolver()
/*     */   {
/* 460 */     return null;
/*     */   }
/*     */ 
/*     */   protected void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 501 */     if (this.messageConverters == null) {
/* 502 */       this.messageConverters = new ArrayList();
/* 503 */       configureMessageConverters(this.messageConverters);
/* 504 */       if (this.messageConverters.isEmpty()) {
/* 505 */         addDefaultHttpMessageConverters(this.messageConverters);
/*     */       }
/*     */     }
/* 508 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   protected void configureMessageConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final void addDefaultHttpMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 531 */     StringHttpMessageConverter stringConverter = new StringHttpMessageConverter();
/* 532 */     stringConverter.setWriteAcceptCharset(false);
/*     */ 
/* 534 */     messageConverters.add(new ByteArrayHttpMessageConverter());
/* 535 */     messageConverters.add(stringConverter);
/* 536 */     messageConverters.add(new ResourceHttpMessageConverter());
/* 537 */     messageConverters.add(new SourceHttpMessageConverter());
/* 538 */     messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/* 539 */     if (romePresent) {
/* 540 */       messageConverters.add(new AtomFeedHttpMessageConverter());
/* 541 */       messageConverters.add(new RssChannelHttpMessageConverter());
/*     */     }
/* 543 */     if (jaxb2Present) {
/* 544 */       messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*     */     }
/* 546 */     if (jackson2Present) {
/* 547 */       messageConverters.add(new MappingJackson2HttpMessageConverter());
/*     */     }
/* 549 */     else if (jacksonPresent)
/* 550 */       messageConverters.add(new MappingJacksonHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   protected void addFormatters(FormatterRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void configureAsyncSupport(AsyncSupportConfigurer configurer)
/*     */   {
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public CompositeUriComponentsContributor mvcUriComponentsContributor()
/*     */   {
/* 574 */     return new CompositeUriComponentsContributor(
/* 574 */       requestMappingHandlerAdapter().getArgumentResolvers(), mvcConversionService());
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public HttpRequestHandlerAdapter httpRequestHandlerAdapter()
/*     */   {
/* 583 */     return new HttpRequestHandlerAdapter();
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public SimpleControllerHandlerAdapter simpleControllerHandlerAdapter()
/*     */   {
/* 592 */     return new SimpleControllerHandlerAdapter();
/*     */   }
/*     */ 
/*     */   @Bean
/*     */   public HandlerExceptionResolver handlerExceptionResolver()
/*     */   {
/* 607 */     List exceptionResolvers = new ArrayList();
/* 608 */     configureHandlerExceptionResolvers(exceptionResolvers);
/*     */ 
/* 610 */     if (exceptionResolvers.isEmpty()) {
/* 611 */       addDefaultHandlerExceptionResolvers(exceptionResolvers);
/*     */     }
/*     */ 
/* 614 */     HandlerExceptionResolverComposite composite = new HandlerExceptionResolverComposite();
/* 615 */     composite.setOrder(0);
/* 616 */     composite.setExceptionResolvers(exceptionResolvers);
/* 617 */     return composite;
/*     */   }
/*     */ 
/*     */   protected void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final void addDefaultHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */   {
/* 645 */     ExceptionHandlerExceptionResolver exceptionHandlerExceptionResolver = new ExceptionHandlerExceptionResolver();
/* 646 */     exceptionHandlerExceptionResolver.setApplicationContext(this.applicationContext);
/* 647 */     exceptionHandlerExceptionResolver.setContentNegotiationManager(mvcContentNegotiationManager());
/* 648 */     exceptionHandlerExceptionResolver.setMessageConverters(getMessageConverters());
/* 649 */     exceptionHandlerExceptionResolver.afterPropertiesSet();
/*     */ 
/* 651 */     exceptionResolvers.add(exceptionHandlerExceptionResolver);
/* 652 */     exceptionResolvers.add(new ResponseStatusExceptionResolver());
/* 653 */     exceptionResolvers.add(new DefaultHandlerExceptionResolver());
/*     */   }
/*     */ 
/*     */   private static final class EmptyHandlerMapping extends AbstractHandlerMapping
/*     */   {
/*     */     protected Object getHandlerInternal(HttpServletRequest request) throws Exception
/*     */     {
/* 660 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport
 * JD-Core Version:    0.6.2
 */