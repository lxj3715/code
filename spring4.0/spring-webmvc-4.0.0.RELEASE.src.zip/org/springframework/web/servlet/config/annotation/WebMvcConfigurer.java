package org.springframework.web.servlet.config.annotation;

import java.util.List;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.validation.MessageCodesResolver;
import org.springframework.validation.Validator;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.servlet.HandlerExceptionResolver;

public abstract interface WebMvcConfigurer
{
  public abstract void addFormatters(FormatterRegistry paramFormatterRegistry);

  public abstract void configureMessageConverters(List<HttpMessageConverter<?>> paramList);

  public abstract Validator getValidator();

  public abstract void configureContentNegotiation(ContentNegotiationConfigurer paramContentNegotiationConfigurer);

  public abstract void configureAsyncSupport(AsyncSupportConfigurer paramAsyncSupportConfigurer);

  public abstract void addArgumentResolvers(List<HandlerMethodArgumentResolver> paramList);

  public abstract void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> paramList);

  public abstract void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> paramList);

  public abstract void addInterceptors(InterceptorRegistry paramInterceptorRegistry);

  public abstract MessageCodesResolver getMessageCodesResolver();

  public abstract void addViewControllers(ViewControllerRegistry paramViewControllerRegistry);

  public abstract void addResourceHandlers(ResourceHandlerRegistry paramResourceHandlerRegistry);

  public abstract void configureDefaultServletHandling(DefaultServletHandlerConfigurer paramDefaultServletHandlerConfigurer);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.WebMvcConfigurer
 * JD-Core Version:    0.6.2
 */