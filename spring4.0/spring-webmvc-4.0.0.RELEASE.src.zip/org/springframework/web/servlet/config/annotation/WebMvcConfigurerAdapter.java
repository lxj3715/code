/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.validation.MessageCodesResolver;
/*     */ import org.springframework.validation.Validator;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ 
/*     */ public abstract class WebMvcConfigurerAdapter
/*     */   implements WebMvcConfigurer
/*     */ {
/*     */   public void addFormatters(FormatterRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void configureMessageConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/*     */   }
/*     */ 
/*     */   public Validator getValidator()
/*     */   {
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */   public void configureContentNegotiation(ContentNegotiationConfigurer configurer)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void configureAsyncSupport(AsyncSupportConfigurer configurer)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*     */   {
/*     */   }
/*     */ 
/*     */   public MessageCodesResolver getMessageCodesResolver()
/*     */   {
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   public void addInterceptors(InterceptorRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void addViewControllers(ViewControllerRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void addResourceHandlers(ResourceHandlerRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter
 * JD-Core Version:    0.6.2
 */