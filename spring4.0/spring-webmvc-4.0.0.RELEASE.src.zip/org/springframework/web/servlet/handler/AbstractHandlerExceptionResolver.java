/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ public abstract class AbstractHandlerExceptionResolver
/*     */   implements HandlerExceptionResolver, Ordered
/*     */ {
/*     */   private static final String HEADER_PRAGMA = "Pragma";
/*     */   private static final String HEADER_EXPIRES = "Expires";
/*     */   private static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*  50 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  52 */   private int order = 2147483647;
/*     */   private Set<?> mappedHandlers;
/*     */   private Class<?>[] mappedHandlerClasses;
/*     */   private Log warnLogger;
/*  60 */   private boolean preventResponseCaching = false;
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/*  64 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/*  69 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void setMappedHandlers(Set<?> mappedHandlers)
/*     */   {
/*  81 */     this.mappedHandlers = mappedHandlers;
/*     */   }
/*     */ 
/*     */   public void setMappedHandlerClasses(Class<?>[] mappedHandlerClasses)
/*     */   {
/*  94 */     this.mappedHandlerClasses = mappedHandlerClasses;
/*     */   }
/*     */ 
/*     */   public void setWarnLogCategory(String loggerName)
/*     */   {
/* 108 */     this.warnLogger = LogFactory.getLog(loggerName);
/*     */   }
/*     */ 
/*     */   public void setPreventResponseCaching(boolean preventResponseCaching)
/*     */   {
/* 118 */     this.preventResponseCaching = preventResponseCaching;
/*     */   }
/*     */ 
/*     */   public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*     */   {
/* 131 */     if (shouldApplyTo(request, handler))
/*     */     {
/* 133 */       if (this.logger.isDebugEnabled()) {
/* 134 */         this.logger.debug("Resolving exception from handler [" + handler + "]: " + ex);
/*     */       }
/* 136 */       logException(ex, request);
/* 137 */       prepareResponse(ex, response);
/* 138 */       return doResolveException(request, response, handler, ex);
/*     */     }
/*     */ 
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean shouldApplyTo(HttpServletRequest request, Object handler)
/*     */   {
/* 158 */     if (handler != null) {
/* 159 */       if ((this.mappedHandlers != null) && (this.mappedHandlers.contains(handler))) {
/* 160 */         return true;
/*     */       }
/* 162 */       if (this.mappedHandlerClasses != null) {
/* 163 */         for (Class handlerClass : this.mappedHandlerClasses) {
/* 164 */           if (handlerClass.isInstance(handler)) {
/* 165 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 171 */     return (this.mappedHandlers == null) && (this.mappedHandlerClasses == null);
/*     */   }
/*     */ 
/*     */   protected void logException(Exception ex, HttpServletRequest request)
/*     */   {
/* 186 */     if ((this.warnLogger != null) && (this.warnLogger.isWarnEnabled()))
/* 187 */       this.warnLogger.warn(buildLogMessage(ex, request), ex);
/*     */   }
/*     */ 
/*     */   protected String buildLogMessage(Exception ex, HttpServletRequest request)
/*     */   {
/* 198 */     return "Handler execution resulted in exception";
/*     */   }
/*     */ 
/*     */   protected void prepareResponse(Exception ex, HttpServletResponse response)
/*     */   {
/* 211 */     if (this.preventResponseCaching)
/* 212 */       preventCaching(response);
/*     */   }
/*     */ 
/*     */   protected void preventCaching(HttpServletResponse response)
/*     */   {
/* 222 */     response.setHeader("Pragma", "no-cache");
/* 223 */     response.setDateHeader("Expires", 1L);
/* 224 */     response.setHeader("Cache-Control", "no-cache");
/* 225 */     response.addHeader("Cache-Control", "no-store");
/*     */   }
/*     */ 
/*     */   protected abstract ModelAndView doResolveException(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Object paramObject, Exception paramException);
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver
 * JD-Core Version:    0.6.2
 */