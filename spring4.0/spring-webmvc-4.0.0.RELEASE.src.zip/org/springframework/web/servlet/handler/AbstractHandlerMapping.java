/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.context.request.WebRequestInterceptor;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public abstract class AbstractHandlerMapping extends WebApplicationObjectSupport
/*     */   implements HandlerMapping, Ordered
/*     */ {
/*  61 */   private int order = 2147483647;
/*     */   private Object defaultHandler;
/*  65 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  67 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */ 
/*  69 */   private final List<Object> interceptors = new ArrayList();
/*     */ 
/*  71 */   private final List<HandlerInterceptor> adaptedInterceptors = new ArrayList();
/*     */ 
/*  73 */   private final List<MappedInterceptor> mappedInterceptors = new ArrayList();
/*     */ 
/*     */   public final void setOrder(int order)
/*     */   {
/*  82 */     this.order = order;
/*     */   }
/*     */ 
/*     */   public final int getOrder()
/*     */   {
/*  87 */     return this.order;
/*     */   }
/*     */ 
/*     */   public void setDefaultHandler(Object defaultHandler)
/*     */   {
/*  96 */     this.defaultHandler = defaultHandler;
/*     */   }
/*     */ 
/*     */   public Object getDefaultHandler()
/*     */   {
/* 104 */     return this.defaultHandler;
/*     */   }
/*     */ 
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath)
/*     */   {
/* 115 */     this.urlPathHelper.setAlwaysUseFullPath(alwaysUseFullPath);
/*     */   }
/*     */ 
/*     */   public void setUrlDecode(boolean urlDecode)
/*     */   {
/* 126 */     this.urlPathHelper.setUrlDecode(urlDecode);
/*     */   }
/*     */ 
/*     */   public void setRemoveSemicolonContent(boolean removeSemicolonContent)
/*     */   {
/* 135 */     this.urlPathHelper.setRemoveSemicolonContent(removeSemicolonContent);
/*     */   }
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/* 145 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/* 146 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/* 153 */     return this.urlPathHelper;
/*     */   }
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 162 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 163 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */ 
/*     */   public PathMatcher getPathMatcher()
/*     */   {
/* 171 */     return this.pathMatcher;
/*     */   }
/*     */ 
/*     */   public void setInterceptors(Object[] interceptors)
/*     */   {
/* 185 */     this.interceptors.addAll(Arrays.asList(interceptors));
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext()
/*     */     throws BeansException
/*     */   {
/* 196 */     extendInterceptors(this.interceptors);
/* 197 */     detectMappedInterceptors(this.mappedInterceptors);
/* 198 */     initInterceptors();
/*     */   }
/*     */ 
/*     */   protected void extendInterceptors(List<Object> interceptors)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void detectMappedInterceptors(List<MappedInterceptor> mappedInterceptors)
/*     */   {
/* 222 */     mappedInterceptors.addAll(
/* 223 */       BeanFactoryUtils.beansOfTypeIncludingAncestors(
/* 224 */       getApplicationContext(), MappedInterceptor.class, true, false).values());
/*     */   }
/*     */ 
/*     */   protected void initInterceptors()
/*     */   {
/* 234 */     if (!this.interceptors.isEmpty())
/* 235 */       for (int i = 0; i < this.interceptors.size(); i++) {
/* 236 */         Object interceptor = this.interceptors.get(i);
/* 237 */         if (interceptor == null) {
/* 238 */           throw new IllegalArgumentException("Entry number " + i + " in interceptors array is null");
/*     */         }
/* 240 */         if ((interceptor instanceof MappedInterceptor)) {
/* 241 */           this.mappedInterceptors.add((MappedInterceptor)interceptor);
/*     */         }
/*     */         else
/* 244 */           this.adaptedInterceptors.add(adaptInterceptor(interceptor));
/*     */       }
/*     */   }
/*     */ 
/*     */   protected HandlerInterceptor adaptInterceptor(Object interceptor)
/*     */   {
/* 262 */     if ((interceptor instanceof HandlerInterceptor)) {
/* 263 */       return (HandlerInterceptor)interceptor;
/*     */     }
/* 265 */     if ((interceptor instanceof WebRequestInterceptor)) {
/* 266 */       return new WebRequestHandlerInterceptorAdapter((WebRequestInterceptor)interceptor);
/*     */     }
/*     */ 
/* 269 */     throw new IllegalArgumentException("Interceptor type not supported: " + interceptor.getClass().getName());
/*     */   }
/*     */ 
/*     */   protected final HandlerInterceptor[] getAdaptedInterceptors()
/*     */   {
/* 278 */     int count = this.adaptedInterceptors.size();
/* 279 */     return count > 0 ? (HandlerInterceptor[])this.adaptedInterceptors.toArray(new HandlerInterceptor[count]) : null;
/*     */   }
/*     */ 
/*     */   protected final MappedInterceptor[] getMappedInterceptors()
/*     */   {
/* 287 */     int count = this.mappedInterceptors.size();
/* 288 */     return count > 0 ? (MappedInterceptor[])this.mappedInterceptors.toArray(new MappedInterceptor[count]) : null;
/*     */   }
/*     */ 
/*     */   public final HandlerExecutionChain getHandler(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 300 */     Object handler = getHandlerInternal(request);
/* 301 */     if (handler == null) {
/* 302 */       handler = getDefaultHandler();
/*     */     }
/* 304 */     if (handler == null) {
/* 305 */       return null;
/*     */     }
/*     */ 
/* 308 */     if ((handler instanceof String)) {
/* 309 */       String handlerName = (String)handler;
/* 310 */       handler = getApplicationContext().getBean(handlerName);
/*     */     }
/* 312 */     return getHandlerExecutionChain(handler, request);
/*     */   }
/*     */ 
/*     */   protected abstract Object getHandlerInternal(HttpServletRequest paramHttpServletRequest)
/*     */     throws Exception;
/*     */ 
/*     */   protected HandlerExecutionChain getHandlerExecutionChain(Object handler, HttpServletRequest request)
/*     */   {
/* 345 */     HandlerExecutionChain chain = (handler instanceof HandlerExecutionChain) ? (HandlerExecutionChain)handler : new HandlerExecutionChain(handler);
/*     */ 
/* 349 */     chain.addInterceptors(getAdaptedInterceptors());
/*     */ 
/* 351 */     String lookupPath = this.urlPathHelper.getLookupPathForRequest(request);
/* 352 */     for (MappedInterceptor mappedInterceptor : this.mappedInterceptors) {
/* 353 */       if (mappedInterceptor.matches(lookupPath, this.pathMatcher)) {
/* 354 */         chain.addInterceptor(mappedInterceptor.getInterceptor());
/*     */       }
/*     */     }
/*     */ 
/* 358 */     return chain;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.AbstractHandlerMapping
 * JD-Core Version:    0.6.2
 */