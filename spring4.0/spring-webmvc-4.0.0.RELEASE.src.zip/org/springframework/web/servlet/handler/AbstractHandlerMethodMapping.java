/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.HandlerMethodSelector;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public abstract class AbstractHandlerMethodMapping<T> extends AbstractHandlerMapping
/*     */   implements InitializingBean
/*     */ {
/*     */   private boolean detectHandlerMethodsInAncestorContexts;
/*     */   private final Map<T, HandlerMethod> handlerMethods;
/*     */   private final MultiValueMap<String, T> urlMap;
/*     */ 
/*     */   public AbstractHandlerMethodMapping()
/*     */   {
/*  58 */     this.detectHandlerMethodsInAncestorContexts = false;
/*     */ 
/*  60 */     this.handlerMethods = new LinkedHashMap();
/*     */ 
/*  62 */     this.urlMap = new LinkedMultiValueMap();
/*     */   }
/*     */ 
/*     */   public void setDetectHandlerMethodsInAncestorContexts(boolean detectHandlerMethodsInAncestorContexts)
/*     */   {
/*  74 */     this.detectHandlerMethodsInAncestorContexts = detectHandlerMethodsInAncestorContexts;
/*     */   }
/*     */ 
/*     */   public Map<T, HandlerMethod> getHandlerMethods()
/*     */   {
/*  81 */     return Collections.unmodifiableMap(this.handlerMethods);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/*  89 */     initHandlerMethods();
/*     */   }
/*     */ 
/*     */   protected void initHandlerMethods()
/*     */   {
/*  99 */     if (this.logger.isDebugEnabled()) {
/* 100 */       this.logger.debug("Looking for request mappings in application context: " + getApplicationContext());
/*     */     }
/*     */ 
/* 105 */     String[] beanNames = this.detectHandlerMethodsInAncestorContexts ? 
/* 104 */       BeanFactoryUtils.beanNamesForTypeIncludingAncestors(getApplicationContext(), Object.class) : 
/* 105 */       getApplicationContext().getBeanNamesForType(Object.class);
/*     */ 
/* 107 */     for (String beanName : beanNames) {
/* 108 */       if (isHandler(getApplicationContext().getType(beanName))) {
/* 109 */         detectHandlerMethods(beanName);
/*     */       }
/*     */     }
/* 112 */     handlerMethodsInitialized(getHandlerMethods());
/*     */   }
/*     */ 
/*     */   protected abstract boolean isHandler(Class<?> paramClass);
/*     */ 
/*     */   protected void handlerMethodsInitialized(Map<T, HandlerMethod> handlerMethods)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void detectHandlerMethods(Object handler)
/*     */   {
/* 135 */     Class handlerType = (handler instanceof String) ? 
/* 135 */       getApplicationContext().getType((String)handler) : handler.getClass();
/*     */ 
/* 137 */     final Class userType = ClassUtils.getUserClass(handlerType);
/*     */ 
/* 139 */     Set methods = HandlerMethodSelector.selectMethods(userType, new ReflectionUtils.MethodFilter()
/*     */     {
/*     */       public boolean matches(Method method) {
/* 142 */         return AbstractHandlerMethodMapping.this.getMappingForMethod(method, userType) != null;
/*     */       }
/*     */     });
/* 146 */     for (Method method : methods) {
/* 147 */       Object mapping = getMappingForMethod(method, userType);
/* 148 */       registerHandlerMethod(handler, method, mapping);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract T getMappingForMethod(Method paramMethod, Class<?> paramClass);
/*     */ 
/*     */   protected void registerHandlerMethod(Object handler, Method method, T mapping)
/*     */   {
/* 171 */     HandlerMethod newHandlerMethod = createHandlerMethod(handler, method);
/* 172 */     HandlerMethod oldHandlerMethod = (HandlerMethod)this.handlerMethods.get(mapping);
/* 173 */     if ((oldHandlerMethod != null) && (!oldHandlerMethod.equals(newHandlerMethod)))
/*     */     {
/* 176 */       throw new IllegalStateException("Ambiguous mapping found. Cannot map '" + newHandlerMethod.getBean() + "' bean method \n" + newHandlerMethod + "\nto " + mapping + ": There is already '" + oldHandlerMethod
/* 176 */         .getBean() + "' bean method\n" + oldHandlerMethod + " mapped.");
/*     */     }
/*     */ 
/* 179 */     this.handlerMethods.put(mapping, newHandlerMethod);
/* 180 */     if (this.logger.isInfoEnabled()) {
/* 181 */       this.logger.info("Mapped \"" + mapping + "\" onto " + newHandlerMethod);
/*     */     }
/*     */ 
/* 184 */     Set patterns = getMappingPathPatterns(mapping);
/* 185 */     for (String pattern : patterns)
/* 186 */       if (!getPathMatcher().isPattern(pattern))
/* 187 */         this.urlMap.add(pattern, mapping);
/*     */   }
/*     */ 
/*     */   protected HandlerMethod createHandlerMethod(Object handler, Method method)
/*     */   {
/*     */     HandlerMethod handlerMethod;
/*     */     HandlerMethod handlerMethod;
/* 200 */     if ((handler instanceof String)) {
/* 201 */       String beanName = (String)handler;
/* 202 */       handlerMethod = new HandlerMethod(beanName, getApplicationContext(), method);
/*     */     }
/*     */     else {
/* 205 */       handlerMethod = new HandlerMethod(handler, method);
/*     */     }
/* 207 */     return handlerMethod;
/*     */   }
/*     */ 
/*     */   protected abstract Set<String> getMappingPathPatterns(T paramT);
/*     */ 
/*     */   protected HandlerMethod getHandlerInternal(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 220 */     String lookupPath = getUrlPathHelper().getLookupPathForRequest(request);
/* 221 */     if (this.logger.isDebugEnabled()) {
/* 222 */       this.logger.debug("Looking up handler method for path " + lookupPath);
/*     */     }
/*     */ 
/* 225 */     HandlerMethod handlerMethod = lookupHandlerMethod(lookupPath, request);
/*     */ 
/* 227 */     if (this.logger.isDebugEnabled()) {
/* 228 */       if (handlerMethod != null) {
/* 229 */         this.logger.debug("Returning handler method [" + handlerMethod + "]");
/*     */       }
/*     */       else {
/* 232 */         this.logger.debug("Did not find handler method for [" + lookupPath + "]");
/*     */       }
/*     */     }
/*     */ 
/* 236 */     return handlerMethod != null ? handlerMethod.createWithResolvedBean() : null;
/*     */   }
/*     */ 
/*     */   protected HandlerMethod lookupHandlerMethod(String lookupPath, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 249 */     List matches = new ArrayList();
/*     */ 
/* 251 */     List directPathMatches = (List)this.urlMap.get(lookupPath);
/* 252 */     if (directPathMatches != null) {
/* 253 */       addMatchingMappings(directPathMatches, matches, request);
/*     */     }
/*     */ 
/* 256 */     if (matches.isEmpty())
/*     */     {
/* 258 */       addMatchingMappings(this.handlerMethods.keySet(), matches, request);
/*     */     }
/*     */ 
/* 261 */     if (!matches.isEmpty()) {
/* 262 */       Comparator comparator = new MatchComparator(getMappingComparator(request));
/* 263 */       Collections.sort(matches, comparator);
/*     */ 
/* 265 */       if (this.logger.isTraceEnabled()) {
/* 266 */         this.logger.trace("Found " + matches.size() + " matching mapping(s) for [" + lookupPath + "] : " + matches);
/*     */       }
/*     */ 
/* 269 */       Match bestMatch = (Match)matches.get(0);
/* 270 */       if (matches.size() > 1) {
/* 271 */         Match secondBestMatch = (Match)matches.get(1);
/* 272 */         if (comparator.compare(bestMatch, secondBestMatch) == 0) {
/* 273 */           Method m1 = bestMatch.handlerMethod.getMethod();
/* 274 */           Method m2 = secondBestMatch.handlerMethod.getMethod();
/*     */ 
/* 276 */           throw new IllegalStateException("Ambiguous handler methods mapped for HTTP path '" + request
/* 276 */             .getRequestURL() + "': {" + m1 + ", " + m2 + "}");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 281 */       handleMatch(bestMatch.mapping, lookupPath, request);
/* 282 */       return bestMatch.handlerMethod;
/*     */     }
/*     */ 
/* 285 */     return handleNoMatch(this.handlerMethods.keySet(), lookupPath, request);
/*     */   }
/*     */ 
/*     */   private void addMatchingMappings(Collection<T> mappings, List<AbstractHandlerMethodMapping<T>.Match> matches, HttpServletRequest request)
/*     */   {
/* 290 */     for (Iterator localIterator = mappings.iterator(); localIterator.hasNext(); ) { Object mapping = localIterator.next();
/* 291 */       Object match = getMatchingMapping(mapping, request);
/* 292 */       if (match != null)
/* 293 */         matches.add(new Match(match, (HandlerMethod)this.handlerMethods.get(mapping), null));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract T getMatchingMapping(T paramT, HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */   protected abstract Comparator<T> getMappingComparator(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */   protected void handleMatch(T mapping, String lookupPath, HttpServletRequest request)
/*     */   {
/* 322 */     request.setAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, lookupPath);
/*     */   }
/*     */ 
/*     */   protected HandlerMethod handleNoMatch(Set<T> mappings, String lookupPath, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 335 */     return null;
/*     */   }
/*     */ 
/*     */   private class MatchComparator
/*     */     implements Comparator<AbstractHandlerMethodMapping<T>.Match>
/*     */   {
/*     */     private final Comparator<T> comparator;
/*     */ 
/*     */     public MatchComparator()
/*     */     {
/* 367 */       this.comparator = comparator;
/*     */     }
/*     */ 
/*     */     public int compare(AbstractHandlerMethodMapping<T>.Match match1, AbstractHandlerMethodMapping<T>.Match match2)
/*     */     {
/* 372 */       return this.comparator.compare(AbstractHandlerMethodMapping.Match.access$100(match1), AbstractHandlerMethodMapping.Match.access$100(match2));
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Match
/*     */   {
/*     */     private final T mapping;
/*     */     private final HandlerMethod handlerMethod;
/*     */ 
/*     */     private Match(HandlerMethod mapping)
/*     */     {
/* 351 */       this.mapping = mapping;
/* 352 */       this.handlerMethod = handlerMethod;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 357 */       return this.mapping.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.AbstractHandlerMethodMapping
 * JD-Core Version:    0.6.2
 */