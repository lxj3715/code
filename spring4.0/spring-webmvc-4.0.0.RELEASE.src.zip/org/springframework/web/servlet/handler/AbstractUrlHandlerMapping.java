/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public abstract class AbstractUrlHandlerMapping extends AbstractHandlerMapping
/*     */ {
/*     */   private Object rootHandler;
/*     */   private boolean lazyInitHandlers;
/*     */   private final Map<String, Object> handlerMap;
/*     */ 
/*     */   public AbstractUrlHandlerMapping()
/*     */   {
/*  58 */     this.lazyInitHandlers = false;
/*     */ 
/*  60 */     this.handlerMap = new LinkedHashMap();
/*     */   }
/*     */ 
/*     */   public void setRootHandler(Object rootHandler)
/*     */   {
/*  69 */     this.rootHandler = rootHandler;
/*     */   }
/*     */ 
/*     */   public Object getRootHandler()
/*     */   {
/*  77 */     return this.rootHandler;
/*     */   }
/*     */ 
/*     */   public void setLazyInitHandlers(boolean lazyInitHandlers)
/*     */   {
/*  91 */     this.lazyInitHandlers = lazyInitHandlers;
/*     */   }
/*     */ 
/*     */   protected Object getHandlerInternal(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 101 */     String lookupPath = getUrlPathHelper().getLookupPathForRequest(request);
/* 102 */     Object handler = lookupHandler(lookupPath, request);
/* 103 */     if (handler == null)
/*     */     {
/* 106 */       Object rawHandler = null;
/* 107 */       if ("/".equals(lookupPath)) {
/* 108 */         rawHandler = getRootHandler();
/*     */       }
/* 110 */       if (rawHandler == null) {
/* 111 */         rawHandler = getDefaultHandler();
/*     */       }
/* 113 */       if (rawHandler != null)
/*     */       {
/* 115 */         if ((rawHandler instanceof String)) {
/* 116 */           String handlerName = (String)rawHandler;
/* 117 */           rawHandler = getApplicationContext().getBean(handlerName);
/*     */         }
/* 119 */         validateHandler(rawHandler, request);
/* 120 */         handler = buildPathExposingHandler(rawHandler, lookupPath, lookupPath, null);
/*     */       }
/*     */     }
/* 123 */     if ((handler != null) && (this.logger.isDebugEnabled())) {
/* 124 */       this.logger.debug(new StringBuilder().append("Mapping [").append(lookupPath).append("] to ").append(handler).toString());
/*     */     }
/* 126 */     else if ((handler == null) && (this.logger.isTraceEnabled())) {
/* 127 */       this.logger.trace(new StringBuilder().append("No handler mapping found for [").append(lookupPath).append("]").toString());
/*     */     }
/* 129 */     return handler;
/*     */   }
/*     */ 
/*     */   protected Object lookupHandler(String urlPath, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 147 */     Object handler = this.handlerMap.get(urlPath);
/* 148 */     if (handler != null)
/*     */     {
/* 150 */       if ((handler instanceof String)) {
/* 151 */         String handlerName = (String)handler;
/* 152 */         handler = getApplicationContext().getBean(handlerName);
/*     */       }
/* 154 */       validateHandler(handler, request);
/* 155 */       return buildPathExposingHandler(handler, urlPath, urlPath, null);
/*     */     }
/*     */ 
/* 158 */     List matchingPatterns = new ArrayList();
/* 159 */     for (String registeredPattern : this.handlerMap.keySet()) {
/* 160 */       if (getPathMatcher().match(registeredPattern, urlPath)) {
/* 161 */         matchingPatterns.add(registeredPattern);
/*     */       }
/*     */     }
/* 164 */     String bestPatternMatch = null;
/* 165 */     Comparator patternComparator = getPathMatcher().getPatternComparator(urlPath);
/* 166 */     if (!matchingPatterns.isEmpty()) {
/* 167 */       Collections.sort(matchingPatterns, patternComparator);
/* 168 */       if (this.logger.isDebugEnabled()) {
/* 169 */         this.logger.debug(new StringBuilder().append("Matching patterns for request [").append(urlPath).append("] are ").append(matchingPatterns).toString());
/*     */       }
/* 171 */       bestPatternMatch = (String)matchingPatterns.get(0);
/*     */     }
/* 173 */     if (bestPatternMatch != null) {
/* 174 */       handler = this.handlerMap.get(bestPatternMatch);
/*     */ 
/* 176 */       if ((handler instanceof String)) {
/* 177 */         String handlerName = (String)handler;
/* 178 */         handler = getApplicationContext().getBean(handlerName);
/*     */       }
/* 180 */       validateHandler(handler, request);
/* 181 */       String pathWithinMapping = getPathMatcher().extractPathWithinPattern(bestPatternMatch, urlPath);
/*     */ 
/* 185 */       Map uriTemplateVariables = new LinkedHashMap();
/* 186 */       for (String matchingPattern : matchingPatterns) {
/* 187 */         if (patternComparator.compare(bestPatternMatch, matchingPattern) == 0) {
/* 188 */           Map vars = getPathMatcher().extractUriTemplateVariables(matchingPattern, urlPath);
/* 189 */           Map decodedVars = getUrlPathHelper().decodePathVariables(request, vars);
/* 190 */           uriTemplateVariables.putAll(decodedVars);
/*     */         }
/*     */       }
/* 193 */       if (this.logger.isDebugEnabled()) {
/* 194 */         this.logger.debug(new StringBuilder().append("URI Template variables for request [").append(urlPath).append("] are ").append(uriTemplateVariables).toString());
/*     */       }
/* 196 */       return buildPathExposingHandler(handler, bestPatternMatch, pathWithinMapping, uriTemplateVariables);
/*     */     }
/*     */ 
/* 199 */     return null;
/*     */   }
/*     */ 
/*     */   protected void validateHandler(Object handler, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Object buildPathExposingHandler(Object rawHandler, String bestMatchingPattern, String pathWithinMapping, Map<String, String> uriTemplateVariables)
/*     */   {
/* 227 */     HandlerExecutionChain chain = new HandlerExecutionChain(rawHandler);
/* 228 */     chain.addInterceptor(new PathExposingHandlerInterceptor(bestMatchingPattern, pathWithinMapping));
/* 229 */     if (!CollectionUtils.isEmpty(uriTemplateVariables)) {
/* 230 */       chain.addInterceptor(new UriTemplateVariablesHandlerInterceptor(uriTemplateVariables));
/*     */     }
/* 232 */     return chain;
/*     */   }
/*     */ 
/*     */   protected void exposePathWithinMapping(String bestMatchingPattern, String pathWithinMapping, HttpServletRequest request)
/*     */   {
/* 242 */     request.setAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE, bestMatchingPattern);
/* 243 */     request.setAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, pathWithinMapping);
/*     */   }
/*     */ 
/*     */   protected void exposeUriTemplateVariables(Map<String, String> uriTemplateVariables, HttpServletRequest request)
/*     */   {
/* 253 */     request.setAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, uriTemplateVariables);
/*     */   }
/*     */ 
/*     */   protected void registerHandler(String[] urlPaths, String beanName)
/*     */     throws BeansException, IllegalStateException
/*     */   {
/* 264 */     Assert.notNull(urlPaths, "URL path array must not be null");
/* 265 */     for (String urlPath : urlPaths)
/* 266 */       registerHandler(urlPath, beanName);
/*     */   }
/*     */ 
/*     */   protected void registerHandler(String urlPath, Object handler)
/*     */     throws BeansException, IllegalStateException
/*     */   {
/* 279 */     Assert.notNull(urlPath, "URL path must not be null");
/* 280 */     Assert.notNull(handler, "Handler object must not be null");
/* 281 */     Object resolvedHandler = handler;
/*     */ 
/* 284 */     if ((!this.lazyInitHandlers) && ((handler instanceof String))) {
/* 285 */       String handlerName = (String)handler;
/* 286 */       if (getApplicationContext().isSingleton(handlerName)) {
/* 287 */         resolvedHandler = getApplicationContext().getBean(handlerName);
/*     */       }
/*     */     }
/*     */ 
/* 291 */     Object mappedHandler = this.handlerMap.get(urlPath);
/* 292 */     if (mappedHandler != null) {
/* 293 */       if (mappedHandler != resolvedHandler)
/*     */       {
/* 296 */         throw new IllegalStateException(new StringBuilder().append("Cannot map ")
/* 295 */           .append(getHandlerDescription(handler))
/* 295 */           .append(" to URL path [").append(urlPath).append("]: There is already ")
/* 296 */           .append(getHandlerDescription(mappedHandler))
/* 296 */           .append(" mapped.").toString());
/*     */       }
/*     */ 
/*     */     }
/* 300 */     else if (urlPath.equals("/")) {
/* 301 */       if (this.logger.isInfoEnabled()) {
/* 302 */         this.logger.info(new StringBuilder().append("Root mapping to ").append(getHandlerDescription(handler)).toString());
/*     */       }
/* 304 */       setRootHandler(resolvedHandler);
/*     */     }
/* 306 */     else if (urlPath.equals("/*")) {
/* 307 */       if (this.logger.isInfoEnabled()) {
/* 308 */         this.logger.info(new StringBuilder().append("Default mapping to ").append(getHandlerDescription(handler)).toString());
/*     */       }
/* 310 */       setDefaultHandler(resolvedHandler);
/*     */     }
/*     */     else {
/* 313 */       this.handlerMap.put(urlPath, resolvedHandler);
/* 314 */       if (this.logger.isInfoEnabled())
/* 315 */         this.logger.info(new StringBuilder().append("Mapped URL path [").append(urlPath).append("] onto ").append(getHandlerDescription(handler)).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getHandlerDescription(Object handler)
/*     */   {
/* 322 */     return new StringBuilder().append("handler ").append((handler instanceof String) ? new StringBuilder().append("'").append(handler).append("'").toString() : new StringBuilder().append("of type [").append(handler.getClass()).append("]").toString()).toString();
/*     */   }
/*     */ 
/*     */   public final Map<String, Object> getHandlerMap()
/*     */   {
/* 333 */     return Collections.unmodifiableMap(this.handlerMap);
/*     */   }
/*     */ 
/*     */   protected boolean supportsTypeLevelMappings()
/*     */   {
/* 340 */     return false;
/*     */   }
/*     */ 
/*     */   private class UriTemplateVariablesHandlerInterceptor extends HandlerInterceptorAdapter
/*     */   {
/*     */     private final Map<String, String> uriTemplateVariables;
/*     */ 
/*     */     public UriTemplateVariablesHandlerInterceptor()
/*     */     {
/* 379 */       this.uriTemplateVariables = uriTemplateVariables;
/*     */     }
/*     */ 
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     {
/* 384 */       AbstractUrlHandlerMapping.this.exposeUriTemplateVariables(this.uriTemplateVariables, request);
/* 385 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class PathExposingHandlerInterceptor extends HandlerInterceptorAdapter
/*     */   {
/*     */     private final String bestMatchingPattern;
/*     */     private final String pathWithinMapping;
/*     */ 
/*     */     public PathExposingHandlerInterceptor(String bestMatchingPattern, String pathWithinMapping)
/*     */     {
/* 356 */       this.bestMatchingPattern = bestMatchingPattern;
/* 357 */       this.pathWithinMapping = pathWithinMapping;
/*     */     }
/*     */ 
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     {
/* 362 */       AbstractUrlHandlerMapping.this.exposePathWithinMapping(this.bestMatchingPattern, this.pathWithinMapping, request);
/* 363 */       request.setAttribute(HandlerMapping.INTROSPECT_TYPE_LEVEL_MAPPING, Boolean.valueOf(AbstractUrlHandlerMapping.this.supportsTypeLevelMappings()));
/* 364 */       return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.AbstractUrlHandlerMapping
 * JD-Core Version:    0.6.2
 */