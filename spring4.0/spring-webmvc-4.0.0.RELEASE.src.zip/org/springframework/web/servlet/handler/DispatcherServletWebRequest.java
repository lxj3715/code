/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.web.context.request.ServletWebRequest;
/*    */ import org.springframework.web.servlet.support.RequestContextUtils;
/*    */ 
/*    */ public class DispatcherServletWebRequest extends ServletWebRequest
/*    */ {
/*    */   public DispatcherServletWebRequest(HttpServletRequest request)
/*    */   {
/* 44 */     super(request);
/*    */   }
/*    */ 
/*    */   public DispatcherServletWebRequest(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 53 */     super(request, response);
/*    */   }
/*    */ 
/*    */   public Locale getLocale()
/*    */   {
/* 58 */     return RequestContextUtils.getLocale(getRequest());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.DispatcherServletWebRequest
 * JD-Core Version:    0.6.2
 */