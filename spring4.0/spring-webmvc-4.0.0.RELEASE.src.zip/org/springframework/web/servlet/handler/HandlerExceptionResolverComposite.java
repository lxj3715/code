/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ 
/*    */ public class HandlerExceptionResolverComposite
/*    */   implements HandlerExceptionResolver, Ordered
/*    */ {
/*    */   private List<HandlerExceptionResolver> resolvers;
/* 39 */   private int order = 2147483647;
/*    */ 
/*    */   public void setOrder(int order) {
/* 42 */     this.order = order;
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 47 */     return this.order;
/*    */   }
/*    */ 
/*    */   public void setExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers)
/*    */   {
/* 54 */     this.resolvers = exceptionResolvers;
/*    */   }
/*    */ 
/*    */   public List<HandlerExceptionResolver> getExceptionResolvers()
/*    */   {
/* 61 */     return Collections.unmodifiableList(this.resolvers);
/*    */   }
/*    */ 
/*    */   public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*    */   {
/* 73 */     if (this.resolvers != null) {
/* 74 */       for (HandlerExceptionResolver handlerExceptionResolver : this.resolvers) {
/* 75 */         ModelAndView mav = handlerExceptionResolver.resolveException(request, response, handler, ex);
/* 76 */         if (mav != null) {
/* 77 */           return mav;
/*    */         }
/*    */       }
/*    */     }
/* 81 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.HandlerExceptionResolverComposite
 * JD-Core Version:    0.6.2
 */