/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.context.request.WebRequestInterceptor;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ 
/*     */ public final class MappedInterceptor
/*     */ {
/*     */   private final String[] includePatterns;
/*     */   private final String[] excludePatterns;
/*     */   private final HandlerInterceptor interceptor;
/*     */ 
/*     */   public MappedInterceptor(String[] includePatterns, HandlerInterceptor interceptor)
/*     */   {
/*  46 */     this(includePatterns, null, interceptor);
/*     */   }
/*     */ 
/*     */   public MappedInterceptor(String[] includePatterns, String[] excludePatterns, HandlerInterceptor interceptor)
/*     */   {
/*  56 */     this.includePatterns = includePatterns;
/*  57 */     this.excludePatterns = excludePatterns;
/*  58 */     this.interceptor = interceptor;
/*     */   }
/*     */ 
/*     */   public MappedInterceptor(String[] includePatterns, WebRequestInterceptor interceptor)
/*     */   {
/*  67 */     this(includePatterns, null, interceptor);
/*     */   }
/*     */ 
/*     */   public MappedInterceptor(String[] includePatterns, String[] excludePatterns, WebRequestInterceptor interceptor)
/*     */   {
/*  76 */     this(includePatterns, excludePatterns, new WebRequestHandlerInterceptorAdapter(interceptor));
/*     */   }
/*     */ 
/*     */   public String[] getPathPatterns()
/*     */   {
/*  84 */     return this.includePatterns;
/*     */   }
/*     */ 
/*     */   public HandlerInterceptor getInterceptor()
/*     */   {
/*  91 */     return this.interceptor;
/*     */   }
/*     */ 
/*     */   public boolean matches(String lookupPath, PathMatcher pathMatcher)
/*     */   {
/* 100 */     if (this.excludePatterns != null) {
/* 101 */       for (String pattern : this.excludePatterns) {
/* 102 */         if (pathMatcher.match(pattern, lookupPath)) {
/* 103 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 107 */     if (this.includePatterns == null) {
/* 108 */       return true;
/*     */     }
/*     */ 
/* 111 */     for (String pattern : this.includePatterns) {
/* 112 */       if (pathMatcher.match(pattern, lookupPath)) {
/* 113 */         return true;
/*     */       }
/*     */     }
/* 116 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.MappedInterceptor
 * JD-Core Version:    0.6.2
 */