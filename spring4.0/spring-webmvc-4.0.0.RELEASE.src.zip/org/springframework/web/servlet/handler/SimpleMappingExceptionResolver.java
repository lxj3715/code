/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class SimpleMappingExceptionResolver extends AbstractHandlerExceptionResolver
/*     */ {
/*     */   public static final String DEFAULT_EXCEPTION_ATTRIBUTE = "exception";
/*     */   private Properties exceptionMappings;
/*     */   private Class<?>[] excludedExceptions;
/*     */   private String defaultErrorView;
/*     */   private Integer defaultStatusCode;
/*  57 */   private Map<String, Integer> statusCodes = new HashMap();
/*     */ 
/*  59 */   private String exceptionAttribute = "exception";
/*     */ 
/*     */   public void setExceptionMappings(Properties mappings)
/*     */   {
/*  77 */     this.exceptionMappings = mappings;
/*     */   }
/*     */ 
/*     */   public void setExcludedExceptions(Class<?>[] excludedExceptions)
/*     */   {
/*  87 */     this.excludedExceptions = excludedExceptions;
/*     */   }
/*     */ 
/*     */   public void setDefaultErrorView(String defaultErrorView)
/*     */   {
/*  96 */     this.defaultErrorView = defaultErrorView;
/*     */   }
/*     */ 
/*     */   public void setStatusCodes(Properties statusCodes)
/*     */   {
/* 109 */     for (Enumeration enumeration = statusCodes.propertyNames(); enumeration.hasMoreElements(); ) {
/* 110 */       String viewName = (String)enumeration.nextElement();
/* 111 */       Integer statusCode = new Integer(statusCodes.getProperty(viewName));
/* 112 */       this.statusCodes.put(viewName, statusCode);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addStatusCode(String viewName, int statusCode)
/*     */   {
/* 121 */     this.statusCodes.put(viewName, Integer.valueOf(statusCode));
/*     */   }
/*     */ 
/*     */   public Map<String, Integer> getStatusCodesAsMap()
/*     */   {
/* 129 */     return Collections.unmodifiableMap(this.statusCodes);
/*     */   }
/*     */ 
/*     */   public void setDefaultStatusCode(int defaultStatusCode)
/*     */   {
/* 145 */     this.defaultStatusCode = Integer.valueOf(defaultStatusCode);
/*     */   }
/*     */ 
/*     */   public void setExceptionAttribute(String exceptionAttribute)
/*     */   {
/* 156 */     this.exceptionAttribute = exceptionAttribute;
/*     */   }
/*     */ 
/*     */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*     */   {
/* 179 */     String viewName = determineViewName(ex, request);
/* 180 */     if (viewName != null)
/*     */     {
/* 183 */       Integer statusCode = determineStatusCode(request, viewName);
/* 184 */       if (statusCode != null) {
/* 185 */         applyStatusCodeIfPossible(request, response, statusCode.intValue());
/*     */       }
/* 187 */       return getModelAndView(viewName, ex, request);
/*     */     }
/*     */ 
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */   protected String determineViewName(Exception ex, HttpServletRequest request)
/*     */   {
/* 204 */     String viewName = null;
/* 205 */     if (this.excludedExceptions != null) {
/* 206 */       for (Class excludedEx : this.excludedExceptions) {
/* 207 */         if (excludedEx.equals(ex.getClass())) {
/* 208 */           return null;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 213 */     if (this.exceptionMappings != null) {
/* 214 */       viewName = findMatchingViewName(this.exceptionMappings, ex);
/*     */     }
/*     */ 
/* 217 */     if ((viewName == null) && (this.defaultErrorView != null)) {
/* 218 */       if (this.logger.isDebugEnabled()) {
/* 219 */         this.logger.debug("Resolving to default view '" + this.defaultErrorView + "' for exception of type [" + ex
/* 220 */           .getClass().getName() + "]");
/*     */       }
/* 222 */       viewName = this.defaultErrorView;
/*     */     }
/* 224 */     return viewName;
/*     */   }
/*     */ 
/*     */   protected String findMatchingViewName(Properties exceptionMappings, Exception ex)
/*     */   {
/* 235 */     String viewName = null;
/* 236 */     String dominantMapping = null;
/* 237 */     int deepest = 2147483647;
/* 238 */     for (Enumeration names = exceptionMappings.propertyNames(); names.hasMoreElements(); ) {
/* 239 */       String exceptionMapping = (String)names.nextElement();
/* 240 */       int depth = getDepth(exceptionMapping, ex);
/* 241 */       if ((depth >= 0) && ((depth < deepest) || ((depth == deepest) && (dominantMapping != null) && 
/* 242 */         (exceptionMapping
/* 242 */         .length() > dominantMapping.length())))) {
/* 243 */         deepest = depth;
/* 244 */         dominantMapping = exceptionMapping;
/* 245 */         viewName = exceptionMappings.getProperty(exceptionMapping);
/*     */       }
/*     */     }
/* 248 */     if ((viewName != null) && (this.logger.isDebugEnabled())) {
/* 249 */       this.logger.debug("Resolving to view '" + viewName + "' for exception of type [" + ex.getClass().getName() + "], based on exception mapping [" + dominantMapping + "]");
/*     */     }
/*     */ 
/* 252 */     return viewName;
/*     */   }
/*     */ 
/*     */   protected int getDepth(String exceptionMapping, Exception ex)
/*     */   {
/* 261 */     return getDepth(exceptionMapping, ex.getClass(), 0);
/*     */   }
/*     */ 
/*     */   private int getDepth(String exceptionMapping, Class<?> exceptionClass, int depth) {
/* 265 */     if (exceptionClass.getName().contains(exceptionMapping))
/*     */     {
/* 267 */       return depth;
/*     */     }
/*     */ 
/* 270 */     if (exceptionClass.equals(Throwable.class)) {
/* 271 */       return -1;
/*     */     }
/* 273 */     return getDepth(exceptionMapping, exceptionClass.getSuperclass(), depth + 1);
/*     */   }
/*     */ 
/*     */   protected Integer determineStatusCode(HttpServletRequest request, String viewName)
/*     */   {
/* 290 */     if (this.statusCodes.containsKey(viewName)) {
/* 291 */       return (Integer)this.statusCodes.get(viewName);
/*     */     }
/* 293 */     return this.defaultStatusCode;
/*     */   }
/*     */ 
/*     */   protected void applyStatusCodeIfPossible(HttpServletRequest request, HttpServletResponse response, int statusCode)
/*     */   {
/* 307 */     if (!WebUtils.isIncludeRequest(request)) {
/* 308 */       if (this.logger.isDebugEnabled()) {
/* 309 */         this.logger.debug("Applying HTTP status code " + statusCode);
/*     */       }
/* 311 */       response.setStatus(statusCode);
/* 312 */       request.setAttribute("javax.servlet.error.status_code", Integer.valueOf(statusCode));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ModelAndView getModelAndView(String viewName, Exception ex, HttpServletRequest request)
/*     */   {
/* 325 */     return getModelAndView(viewName, ex);
/*     */   }
/*     */ 
/*     */   protected ModelAndView getModelAndView(String viewName, Exception ex)
/*     */   {
/* 338 */     ModelAndView mv = new ModelAndView(viewName);
/* 339 */     if (this.exceptionAttribute != null) {
/* 340 */       if (this.logger.isDebugEnabled()) {
/* 341 */         this.logger.debug("Exposing Exception as model attribute '" + this.exceptionAttribute + "'");
/*     */       }
/* 343 */       mv.addObject(this.exceptionAttribute, ex);
/*     */     }
/* 345 */     return mv;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.SimpleMappingExceptionResolver
 * JD-Core Version:    0.6.2
 */