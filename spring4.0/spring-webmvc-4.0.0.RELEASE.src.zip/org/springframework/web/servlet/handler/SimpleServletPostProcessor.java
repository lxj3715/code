/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.web.context.ServletConfigAware;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public class SimpleServletPostProcessor
/*     */   implements DestructionAwareBeanPostProcessor, ServletContextAware, ServletConfigAware
/*     */ {
/*     */   private boolean useSharedServletConfig;
/*     */   private ServletContext servletContext;
/*     */   private ServletConfig servletConfig;
/*     */ 
/*     */   public SimpleServletPostProcessor()
/*     */   {
/*  70 */     this.useSharedServletConfig = true;
/*     */   }
/*     */ 
/*     */   public void setUseSharedServletConfig(boolean useSharedServletConfig)
/*     */   {
/*  86 */     this.useSharedServletConfig = useSharedServletConfig;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/*  91 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void setServletConfig(ServletConfig servletConfig)
/*     */   {
/*  96 */     this.servletConfig = servletConfig;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 102 */     return bean;
/*     */   }
/*     */ 
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException
/*     */   {
/* 107 */     if ((bean instanceof Servlet)) {
/* 108 */       ServletConfig config = this.servletConfig;
/* 109 */       if ((config == null) || (!this.useSharedServletConfig))
/* 110 */         config = new DelegatingServletConfig(beanName, this.servletContext);
/*     */       try
/*     */       {
/* 113 */         ((Servlet)bean).init(config);
/*     */       }
/*     */       catch (ServletException ex) {
/* 116 */         throw new BeanInitializationException("Servlet.init threw exception", ex);
/*     */       }
/*     */     }
/* 119 */     return bean;
/*     */   }
/*     */ 
/*     */   public void postProcessBeforeDestruction(Object bean, String beanName) throws BeansException
/*     */   {
/* 124 */     if ((bean instanceof Servlet))
/* 125 */       ((Servlet)bean).destroy();
/*     */   }
/*     */ 
/*     */   private static class DelegatingServletConfig
/*     */     implements ServletConfig
/*     */   {
/*     */     private final String servletName;
/*     */     private final ServletContext servletContext;
/*     */ 
/*     */     public DelegatingServletConfig(String servletName, ServletContext servletContext)
/*     */     {
/* 141 */       this.servletName = servletName;
/* 142 */       this.servletContext = servletContext;
/*     */     }
/*     */ 
/*     */     public String getServletName()
/*     */     {
/* 147 */       return this.servletName;
/*     */     }
/*     */ 
/*     */     public ServletContext getServletContext()
/*     */     {
/* 152 */       return this.servletContext;
/*     */     }
/*     */ 
/*     */     public String getInitParameter(String paramName)
/*     */     {
/* 157 */       return null;
/*     */     }
/*     */ 
/*     */     public Enumeration<String> getInitParameterNames()
/*     */     {
/* 162 */       return Collections.enumeration(new HashSet());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.SimpleServletPostProcessor
 * JD-Core Version:    0.6.2
 */