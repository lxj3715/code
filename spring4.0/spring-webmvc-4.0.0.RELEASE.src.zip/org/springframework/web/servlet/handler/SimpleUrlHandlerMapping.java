/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class SimpleUrlHandlerMapping extends AbstractUrlHandlerMapping
/*     */ {
/*  58 */   private final Map<String, Object> urlMap = new HashMap();
/*     */ 
/*     */   public void setMappings(Properties mappings)
/*     */   {
/*  70 */     CollectionUtils.mergePropertiesIntoMap(mappings, this.urlMap);
/*     */   }
/*     */ 
/*     */   public void setUrlMap(Map<String, ?> urlMap)
/*     */   {
/*  82 */     this.urlMap.putAll(urlMap);
/*     */   }
/*     */ 
/*     */   public Map<String, ?> getUrlMap()
/*     */   {
/*  93 */     return this.urlMap;
/*     */   }
/*     */ 
/*     */   public void initApplicationContext()
/*     */     throws BeansException
/*     */   {
/* 103 */     super.initApplicationContext();
/* 104 */     registerHandlers(this.urlMap);
/*     */   }
/*     */ 
/*     */   protected void registerHandlers(Map<String, Object> urlMap)
/*     */     throws BeansException
/*     */   {
/* 114 */     if (urlMap.isEmpty()) {
/* 115 */       this.logger.warn("Neither 'urlMap' nor 'mappings' set on SimpleUrlHandlerMapping");
/*     */     }
/*     */     else
/* 118 */       for (Map.Entry entry : urlMap.entrySet()) {
/* 119 */         String url = (String)entry.getKey();
/* 120 */         Object handler = entry.getValue();
/*     */ 
/* 122 */         if (!url.startsWith("/")) {
/* 123 */           url = "/" + url;
/*     */         }
/*     */ 
/* 126 */         if ((handler instanceof String)) {
/* 127 */           handler = ((String)handler).trim();
/*     */         }
/* 129 */         registerHandler(url, handler);
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.SimpleUrlHandlerMapping
 * JD-Core Version:    0.6.2
 */