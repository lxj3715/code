/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class UserRoleAuthorizationInterceptor extends HandlerInterceptorAdapter
/*    */ {
/*    */   private String[] authorizedRoles;
/*    */ 
/*    */   public final void setAuthorizedRoles(String[] authorizedRoles)
/*    */   {
/* 42 */     this.authorizedRoles = authorizedRoles;
/*    */   }
/*    */ 
/*    */   public final boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*    */     throws ServletException, IOException
/*    */   {
/* 50 */     if (this.authorizedRoles != null) {
/* 51 */       for (String role : this.authorizedRoles) {
/* 52 */         if (request.isUserInRole(role)) {
/* 53 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 57 */     handleNotAuthorized(request, response, handler);
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */   protected void handleNotAuthorized(HttpServletRequest request, HttpServletResponse response, Object handler)
/*    */     throws ServletException, IOException
/*    */   {
/* 75 */     response.sendError(403);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.handler.UserRoleAuthorizationInterceptor
 * JD-Core Version:    0.6.2
 */