/*    */ package org.springframework.web.servlet.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.web.servlet.LocaleResolver;
/*    */ 
/*    */ public abstract class AbstractLocaleResolver
/*    */   implements LocaleResolver
/*    */ {
/*    */   private Locale defaultLocale;
/*    */ 
/*    */   public void setDefaultLocale(Locale defaultLocale)
/*    */   {
/* 40 */     this.defaultLocale = defaultLocale;
/*    */   }
/*    */ 
/*    */   protected Locale getDefaultLocale()
/*    */   {
/* 47 */     return this.defaultLocale;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.i18n.AbstractLocaleResolver
 * JD-Core Version:    0.6.2
 */