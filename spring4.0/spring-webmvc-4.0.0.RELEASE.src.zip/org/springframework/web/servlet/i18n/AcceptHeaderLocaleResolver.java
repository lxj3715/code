/*    */ package org.springframework.web.servlet.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.web.servlet.LocaleResolver;
/*    */ 
/*    */ public class AcceptHeaderLocaleResolver
/*    */   implements LocaleResolver
/*    */ {
/*    */   public Locale resolveLocale(HttpServletRequest request)
/*    */   {
/* 42 */     return request.getLocale();
/*    */   }
/*    */ 
/*    */   public void setLocale(HttpServletRequest request, HttpServletResponse response, Locale locale)
/*    */   {
/* 47 */     throw new UnsupportedOperationException("Cannot change HTTP accept header - use a different locale resolution strategy");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver
 * JD-Core Version:    0.6.2
 */