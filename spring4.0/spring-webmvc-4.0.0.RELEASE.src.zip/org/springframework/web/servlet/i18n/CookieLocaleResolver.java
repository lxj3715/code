/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.SimpleLocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.LocaleContextResolver;
/*     */ import org.springframework.web.util.CookieGenerator;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class CookieLocaleResolver extends CookieGenerator
/*     */   implements LocaleContextResolver
/*     */ {
/*  65 */   public static final String LOCALE_REQUEST_ATTRIBUTE_NAME = new StringBuilder().append(CookieLocaleResolver.class.getName()).append(".LOCALE").toString();
/*     */ 
/*  76 */   public static final String TIME_ZONE_REQUEST_ATTRIBUTE_NAME = new StringBuilder().append(CookieLocaleResolver.class.getName()).append(".TIME_ZONE").toString();
/*     */ 
/*  81 */   public static final String DEFAULT_COOKIE_NAME = new StringBuilder().append(CookieLocaleResolver.class.getName()).append(".LOCALE").toString();
/*     */   private Locale defaultLocale;
/*     */   private TimeZone defaultTimeZone;
/*     */ 
/*     */   public CookieLocaleResolver()
/*     */   {
/*  94 */     setCookieName(DEFAULT_COOKIE_NAME);
/*     */   }
/*     */ 
/*     */   public void setDefaultLocale(Locale defaultLocale)
/*     */   {
/* 101 */     this.defaultLocale = defaultLocale;
/*     */   }
/*     */ 
/*     */   protected Locale getDefaultLocale()
/*     */   {
/* 109 */     return this.defaultLocale;
/*     */   }
/*     */ 
/*     */   public void setDefaultTimeZone(TimeZone defaultTimeZone)
/*     */   {
/* 116 */     this.defaultTimeZone = defaultTimeZone;
/*     */   }
/*     */ 
/*     */   protected TimeZone getDefaultTimeZone()
/*     */   {
/* 124 */     return this.defaultTimeZone;
/*     */   }
/*     */ 
/*     */   public Locale resolveLocale(HttpServletRequest request)
/*     */   {
/* 130 */     parseLocaleCookieIfNecessary(request);
/* 131 */     return (Locale)request.getAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME);
/*     */   }
/*     */ 
/*     */   public LocaleContext resolveLocaleContext(final HttpServletRequest request)
/*     */   {
/* 136 */     parseLocaleCookieIfNecessary(request);
/* 137 */     return new TimeZoneAwareLocaleContext()
/*     */     {
/*     */       public Locale getLocale() {
/* 140 */         return (Locale)request.getAttribute(CookieLocaleResolver.LOCALE_REQUEST_ATTRIBUTE_NAME);
/*     */       }
/*     */ 
/*     */       public TimeZone getTimeZone() {
/* 144 */         return (TimeZone)request.getAttribute(CookieLocaleResolver.TIME_ZONE_REQUEST_ATTRIBUTE_NAME);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private void parseLocaleCookieIfNecessary(HttpServletRequest request) {
/* 150 */     if (request.getAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME) == null)
/*     */     {
/* 152 */       Cookie cookie = WebUtils.getCookie(request, getCookieName());
/* 153 */       Locale locale = null;
/* 154 */       TimeZone timeZone = null;
/* 155 */       if (cookie != null) {
/* 156 */         String value = cookie.getValue();
/* 157 */         String localePart = value;
/* 158 */         String timeZonePart = null;
/* 159 */         int spaceIndex = localePart.indexOf(' ');
/* 160 */         if (spaceIndex != -1) {
/* 161 */           localePart = value.substring(0, spaceIndex);
/* 162 */           timeZonePart = value.substring(spaceIndex + 1);
/*     */         }
/* 164 */         locale = !"-".equals(localePart) ? StringUtils.parseLocaleString(localePart) : null;
/* 165 */         if (timeZonePart != null) {
/* 166 */           timeZone = StringUtils.parseTimeZoneString(timeZonePart);
/*     */         }
/* 168 */         if (this.logger.isDebugEnabled()) {
/* 169 */           this.logger.debug(new StringBuilder().append("Parsed cookie value [").append(cookie.getValue()).append("] into locale '").append(locale).append("'")
/* 170 */             .append(timeZone != null ? new StringBuilder().append(" and time zone '")
/* 170 */             .append(timeZone
/* 170 */             .getID()).append("'").toString() : "").toString());
/*     */         }
/*     */       }
/* 173 */       request.setAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME, locale != null ? locale : 
/* 174 */         determineDefaultLocale(request));
/*     */ 
/* 175 */       request.setAttribute(TIME_ZONE_REQUEST_ATTRIBUTE_NAME, timeZone != null ? timeZone : 
/* 176 */         determineDefaultTimeZone(request));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setLocale(HttpServletRequest request, HttpServletResponse response, Locale locale)
/*     */   {
/* 182 */     setLocaleContext(request, response, locale != null ? new SimpleLocaleContext(locale) : null);
/*     */   }
/*     */ 
/*     */   public void setLocaleContext(HttpServletRequest request, HttpServletResponse response, LocaleContext localeContext)
/*     */   {
/* 187 */     Locale locale = null;
/* 188 */     TimeZone timeZone = null;
/* 189 */     if (localeContext != null) {
/* 190 */       locale = localeContext.getLocale();
/* 191 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 192 */         timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*     */       }
/* 194 */       addCookie(response, new StringBuilder().append(locale != null ? locale : "-").append(timeZone != null ? new StringBuilder().append(' ').append(timeZone.getID()).toString() : "").toString());
/*     */     }
/*     */     else {
/* 197 */       removeCookie(response);
/*     */     }
/* 199 */     request.setAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME, locale != null ? locale : 
/* 200 */       determineDefaultLocale(request));
/*     */ 
/* 201 */     request.setAttribute(TIME_ZONE_REQUEST_ATTRIBUTE_NAME, timeZone != null ? timeZone : 
/* 202 */       determineDefaultTimeZone(request));
/*     */   }
/*     */ 
/*     */   protected Locale determineDefaultLocale(HttpServletRequest request)
/*     */   {
/* 217 */     Locale defaultLocale = getDefaultLocale();
/* 218 */     if (defaultLocale == null) {
/* 219 */       defaultLocale = request.getLocale();
/*     */     }
/* 221 */     return defaultLocale;
/*     */   }
/*     */ 
/*     */   protected TimeZone determineDefaultTimeZone(HttpServletRequest request)
/*     */   {
/* 234 */     return getDefaultTimeZone();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.i18n.CookieLocaleResolver
 * JD-Core Version:    0.6.2
 */