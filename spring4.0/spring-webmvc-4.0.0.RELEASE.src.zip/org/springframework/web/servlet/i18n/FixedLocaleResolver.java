/*    */ package org.springframework.web.servlet.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.TimeZone;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.i18n.LocaleContext;
/*    */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*    */ 
/*    */ public class FixedLocaleResolver extends AbstractLocaleContextResolver
/*    */ {
/*    */   public FixedLocaleResolver()
/*    */   {
/* 49 */     setDefaultLocale(Locale.getDefault());
/*    */   }
/*    */ 
/*    */   public FixedLocaleResolver(Locale locale)
/*    */   {
/* 57 */     setDefaultLocale(locale);
/*    */   }
/*    */ 
/*    */   public FixedLocaleResolver(Locale locale, TimeZone timeZone)
/*    */   {
/* 66 */     setDefaultLocale(locale);
/* 67 */     setDefaultTimeZone(timeZone);
/*    */   }
/*    */ 
/*    */   public Locale resolveLocale(HttpServletRequest request)
/*    */   {
/* 73 */     Locale locale = getDefaultLocale();
/* 74 */     if (locale == null) {
/* 75 */       locale = Locale.getDefault();
/*    */     }
/* 77 */     return locale;
/*    */   }
/*    */ 
/*    */   public LocaleContext resolveLocaleContext(HttpServletRequest request)
/*    */   {
/* 82 */     return new TimeZoneAwareLocaleContext()
/*    */     {
/*    */       public Locale getLocale() {
/* 85 */         return FixedLocaleResolver.this.getDefaultLocale();
/*    */       }
/*    */ 
/*    */       public TimeZone getTimeZone() {
/* 89 */         return FixedLocaleResolver.this.getDefaultTimeZone();
/*    */       }
/*    */     };
/*    */   }
/*    */ 
/*    */   public void setLocaleContext(HttpServletRequest request, HttpServletResponse response, LocaleContext localeContext)
/*    */   {
/* 96 */     throw new UnsupportedOperationException("Cannot change fixed locale - use a different locale resolution strategy");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.i18n.FixedLocaleResolver
 * JD-Core Version:    0.6.2
 */