/*    */ package org.springframework.web.servlet.i18n;
/*    */ 
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.servlet.LocaleResolver;
/*    */ import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
/*    */ import org.springframework.web.servlet.support.RequestContextUtils;
/*    */ 
/*    */ public class LocaleChangeInterceptor extends HandlerInterceptorAdapter
/*    */ {
/*    */   public static final String DEFAULT_PARAM_NAME = "locale";
/* 43 */   private String paramName = "locale";
/*    */ 
/*    */   public void setParamName(String paramName)
/*    */   {
/* 51 */     this.paramName = paramName;
/*    */   }
/*    */ 
/*    */   public String getParamName()
/*    */   {
/* 59 */     return this.paramName;
/*    */   }
/*    */ 
/*    */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*    */     throws ServletException
/*    */   {
/* 67 */     String newLocale = request.getParameter(this.paramName);
/* 68 */     if (newLocale != null) {
/* 69 */       LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
/* 70 */       if (localeResolver == null) {
/* 71 */         throw new IllegalStateException("No LocaleResolver found: not in a DispatcherServlet request?");
/*    */       }
/* 73 */       localeResolver.setLocale(request, response, StringUtils.parseLocaleString(newLocale));
/*    */     }
/*    */ 
/* 76 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.i18n.LocaleChangeInterceptor
 * JD-Core Version:    0.6.2
 */