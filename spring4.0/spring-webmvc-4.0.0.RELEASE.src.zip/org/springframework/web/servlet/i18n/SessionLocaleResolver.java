/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class SessionLocaleResolver extends AbstractLocaleContextResolver
/*     */ {
/*  58 */   public static final String LOCALE_SESSION_ATTRIBUTE_NAME = SessionLocaleResolver.class.getName() + ".LOCALE";
/*     */ 
/*  68 */   public static final String TIME_ZONE_SESSION_ATTRIBUTE_NAME = SessionLocaleResolver.class.getName() + ".TIME_ZONE";
/*     */ 
/*     */   public Locale resolveLocale(HttpServletRequest request)
/*     */   {
/*  73 */     Locale locale = (Locale)WebUtils.getSessionAttribute(request, LOCALE_SESSION_ATTRIBUTE_NAME);
/*  74 */     if (locale == null) {
/*  75 */       locale = determineDefaultLocale(request);
/*     */     }
/*  77 */     return locale;
/*     */   }
/*     */ 
/*     */   public LocaleContext resolveLocaleContext(final HttpServletRequest request)
/*     */   {
/*  82 */     return new TimeZoneAwareLocaleContext()
/*     */     {
/*     */       public Locale getLocale() {
/*  85 */         Locale locale = (Locale)WebUtils.getSessionAttribute(request, SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME);
/*  86 */         if (locale == null) {
/*  87 */           locale = SessionLocaleResolver.this.determineDefaultLocale(request);
/*     */         }
/*  89 */         return locale;
/*     */       }
/*     */ 
/*     */       public TimeZone getTimeZone() {
/*  93 */         TimeZone timeZone = (TimeZone)WebUtils.getSessionAttribute(request, SessionLocaleResolver.TIME_ZONE_SESSION_ATTRIBUTE_NAME);
/*  94 */         if (timeZone == null) {
/*  95 */           timeZone = SessionLocaleResolver.this.determineDefaultTimeZone(request);
/*     */         }
/*  97 */         return timeZone;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public void setLocaleContext(HttpServletRequest request, HttpServletResponse response, LocaleContext localeContext)
/*     */   {
/* 104 */     Locale locale = null;
/* 105 */     TimeZone timeZone = null;
/* 106 */     if (localeContext != null) {
/* 107 */       locale = localeContext.getLocale();
/* 108 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 109 */         timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*     */       }
/*     */     }
/* 112 */     WebUtils.setSessionAttribute(request, LOCALE_SESSION_ATTRIBUTE_NAME, locale);
/* 113 */     WebUtils.setSessionAttribute(request, TIME_ZONE_SESSION_ATTRIBUTE_NAME, timeZone);
/*     */   }
/*     */ 
/*     */   protected Locale determineDefaultLocale(HttpServletRequest request)
/*     */   {
/* 128 */     Locale defaultLocale = getDefaultLocale();
/* 129 */     if (defaultLocale == null) {
/* 130 */       defaultLocale = request.getLocale();
/*     */     }
/* 132 */     return defaultLocale;
/*     */   }
/*     */ 
/*     */   protected TimeZone determineDefaultTimeZone(HttpServletRequest request)
/*     */   {
/* 145 */     return getDefaultTimeZone();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.i18n.SessionLocaleResolver
 * JD-Core Version:    0.6.2
 */