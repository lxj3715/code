/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.support.WebContentGenerator;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public abstract class AbstractController extends WebContentGenerator
/*     */   implements Controller
/*     */ {
/* 102 */   private boolean synchronizeOnSession = false;
/*     */ 
/*     */   public final void setSynchronizeOnSession(boolean synchronizeOnSession)
/*     */   {
/* 125 */     this.synchronizeOnSession = synchronizeOnSession;
/*     */   }
/*     */ 
/*     */   public final boolean isSynchronizeOnSession()
/*     */   {
/* 132 */     return this.synchronizeOnSession;
/*     */   }
/*     */ 
/*     */   public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 141 */     checkAndPrepare(request, response, this instanceof LastModified);
/*     */ 
/* 144 */     if (this.synchronizeOnSession) {
/* 145 */       HttpSession session = request.getSession(false);
/* 146 */       if (session != null) {
/* 147 */         Object mutex = WebUtils.getSessionMutex(session);
/* 148 */         synchronized (mutex) {
/* 149 */           return handleRequestInternal(request, response);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 154 */     return handleRequestInternal(request, response);
/*     */   }
/*     */ 
/*     */   protected abstract ModelAndView handleRequestInternal(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*     */     throws Exception;
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.AbstractController
 * JD-Core Version:    0.6.2
 */