package org.springframework.web.servlet.mvc;

import javax.servlet.http.HttpServletRequest;

public abstract interface LastModified
{
  public abstract long getLastModified(HttpServletRequest paramHttpServletRequest);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.LastModified
 * JD-Core Version:    0.6.2
 */