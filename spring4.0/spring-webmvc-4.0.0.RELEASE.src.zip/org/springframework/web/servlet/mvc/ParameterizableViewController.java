/*    */ package org.springframework.web.servlet.mvc;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ import org.springframework.web.servlet.support.RequestContextUtils;
/*    */ 
/*    */ public class ParameterizableViewController extends AbstractController
/*    */ {
/*    */   private String viewName;
/*    */ 
/*    */   public void setViewName(String viewName)
/*    */   {
/* 79 */     this.viewName = viewName;
/*    */   }
/*    */ 
/*    */   public String getViewName()
/*    */   {
/* 86 */     return this.viewName;
/*    */   }
/*    */ 
/*    */   protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
/*    */     throws Exception
/*    */   {
/* 97 */     return new ModelAndView(getViewName(), RequestContextUtils.getInputFlashMap(request));
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.ParameterizableViewController
 * JD-Core Version:    0.6.2
 */