/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletForwardingController extends AbstractController
/*     */   implements BeanNameAware
/*     */ {
/*     */   private String servletName;
/*     */   private String beanName;
/*     */ 
/*     */   public void setServletName(String servletName)
/*     */   {
/* 101 */     this.servletName = servletName;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String name)
/*     */   {
/* 106 */     this.beanName = name;
/* 107 */     if (this.servletName == null)
/* 108 */       this.servletName = name;
/*     */   }
/*     */ 
/*     */   protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 117 */     RequestDispatcher rd = getServletContext().getNamedDispatcher(this.servletName);
/* 118 */     if (rd == null) {
/* 119 */       throw new ServletException("No servlet with name '" + this.servletName + "' defined in web.xml");
/*     */     }
/*     */ 
/* 122 */     if (useInclude(request, response)) {
/* 123 */       rd.include(request, response);
/* 124 */       if (this.logger.isDebugEnabled()) {
/* 125 */         this.logger.debug("Included servlet [" + this.servletName + "] in ServletForwardingController '" + this.beanName + "'");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 130 */       rd.forward(request, response);
/* 131 */       if (this.logger.isDebugEnabled()) {
/* 132 */         this.logger.debug("Forwarded to servlet [" + this.servletName + "] in ServletForwardingController '" + this.beanName + "'");
/*     */       }
/*     */     }
/*     */ 
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean useInclude(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 154 */     return (WebUtils.isIncludeRequest(request)) || (response.isCommitted());
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.ServletForwardingController
 * JD-Core Version:    0.6.2
 */