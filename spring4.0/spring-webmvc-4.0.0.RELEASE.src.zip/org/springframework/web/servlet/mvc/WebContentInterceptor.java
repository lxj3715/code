/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.support.WebContentGenerator;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public class WebContentInterceptor extends WebContentGenerator
/*     */   implements HandlerInterceptor
/*     */ {
/*  50 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  52 */   private Map<String, Integer> cacheMappings = new HashMap();
/*     */ 
/*  54 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */ 
/*     */   public WebContentInterceptor()
/*     */   {
/*  60 */     super(false);
/*     */   }
/*     */ 
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath)
/*     */   {
/*  74 */     this.urlPathHelper.setAlwaysUseFullPath(alwaysUseFullPath);
/*     */   }
/*     */ 
/*     */   public void setUrlDecode(boolean urlDecode)
/*     */   {
/*  88 */     this.urlPathHelper.setUrlDecode(urlDecode);
/*     */   }
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/* 102 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/* 103 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */ 
/*     */   public void setCacheMappings(Properties cacheMappings)
/*     */   {
/* 119 */     this.cacheMappings.clear();
/* 120 */     Enumeration propNames = cacheMappings.propertyNames();
/* 121 */     while (propNames.hasMoreElements()) {
/* 122 */       String path = (String)propNames.nextElement();
/* 123 */       this.cacheMappings.put(path, Integer.valueOf(cacheMappings.getProperty(path)));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 135 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/* 136 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */ 
/*     */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws ServletException
/*     */   {
/* 144 */     String lookupPath = this.urlPathHelper.getLookupPathForRequest(request);
/* 145 */     if (this.logger.isDebugEnabled()) {
/* 146 */       this.logger.debug("Looking up cache seconds for [" + lookupPath + "]");
/*     */     }
/*     */ 
/* 149 */     Integer cacheSeconds = lookupCacheSeconds(lookupPath);
/* 150 */     if (cacheSeconds != null) {
/* 151 */       if (this.logger.isDebugEnabled()) {
/* 152 */         this.logger.debug("Applying " + cacheSeconds + " cache seconds to [" + lookupPath + "]");
/*     */       }
/* 154 */       checkAndPrepare(request, response, cacheSeconds.intValue(), handler instanceof LastModified);
/*     */     }
/*     */     else {
/* 157 */       if (this.logger.isDebugEnabled()) {
/* 158 */         this.logger.debug("Applying default cache seconds to [" + lookupPath + "]");
/*     */       }
/* 160 */       checkAndPrepare(request, response, handler instanceof LastModified);
/*     */     }
/*     */ 
/* 163 */     return true;
/*     */   }
/*     */ 
/*     */   protected Integer lookupCacheSeconds(String urlPath)
/*     */   {
/* 177 */     Integer cacheSeconds = (Integer)this.cacheMappings.get(urlPath);
/* 178 */     if (cacheSeconds == null)
/*     */     {
/* 180 */       for (String registeredPath : this.cacheMappings.keySet()) {
/* 181 */         if (this.pathMatcher.match(registeredPath, urlPath)) {
/* 182 */           cacheSeconds = (Integer)this.cacheMappings.get(registeredPath);
/*     */         }
/*     */       }
/*     */     }
/* 186 */     return cacheSeconds;
/*     */   }
/*     */ 
/*     */   public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.WebContentInterceptor
 * JD-Core Version:    0.6.2
 */