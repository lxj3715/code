/*      */ package org.springframework.web.servlet.mvc.annotation;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Method;
/*      */ import java.security.Principal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*      */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*      */ import org.springframework.core.Ordered;
/*      */ import org.springframework.core.ParameterNameDiscoverer;
/*      */ import org.springframework.core.annotation.AnnotationUtils;
/*      */ import org.springframework.http.HttpEntity;
/*      */ import org.springframework.http.HttpHeaders;
/*      */ import org.springframework.http.HttpInputMessage;
/*      */ import org.springframework.http.HttpOutputMessage;
/*      */ import org.springframework.http.HttpStatus;
/*      */ import org.springframework.http.MediaType;
/*      */ import org.springframework.http.ResponseEntity;
/*      */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*      */ import org.springframework.http.converter.HttpMessageConverter;
/*      */ import org.springframework.http.converter.StringHttpMessageConverter;
/*      */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*      */ import org.springframework.http.converter.xml.XmlAwareFormHttpMessageConverter;
/*      */ import org.springframework.http.server.ServerHttpRequest;
/*      */ import org.springframework.http.server.ServerHttpResponse;
/*      */ import org.springframework.http.server.ServletServerHttpRequest;
/*      */ import org.springframework.http.server.ServletServerHttpResponse;
/*      */ import org.springframework.ui.ExtendedModelMap;
/*      */ import org.springframework.ui.Model;
/*      */ import org.springframework.ui.ModelMap;
/*      */ import org.springframework.util.AntPathMatcher;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.PathMatcher;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.validation.support.BindingAwareModelMap;
/*      */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*      */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*      */ import org.springframework.web.HttpSessionRequiredException;
/*      */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*      */ import org.springframework.web.bind.ServletRequestDataBinder;
/*      */ import org.springframework.web.bind.WebDataBinder;
/*      */ import org.springframework.web.bind.annotation.ModelAttribute;
/*      */ import org.springframework.web.bind.annotation.RequestMapping;
/*      */ import org.springframework.web.bind.annotation.RequestMethod;
/*      */ import org.springframework.web.bind.annotation.ResponseBody;
/*      */ import org.springframework.web.bind.annotation.ResponseStatus;
/*      */ import org.springframework.web.bind.annotation.SessionAttributes;
/*      */ import org.springframework.web.bind.annotation.support.HandlerMethodInvoker;
/*      */ import org.springframework.web.bind.annotation.support.HandlerMethodResolver;
/*      */ import org.springframework.web.bind.support.DefaultSessionAttributeStore;
/*      */ import org.springframework.web.bind.support.SessionAttributeStore;
/*      */ import org.springframework.web.bind.support.WebArgumentResolver;
/*      */ import org.springframework.web.bind.support.WebBindingInitializer;
/*      */ import org.springframework.web.context.request.NativeWebRequest;
/*      */ import org.springframework.web.context.request.RequestScope;
/*      */ import org.springframework.web.context.request.ServletWebRequest;
/*      */ import org.springframework.web.multipart.MultipartRequest;
/*      */ import org.springframework.web.servlet.HandlerAdapter;
/*      */ import org.springframework.web.servlet.HandlerMapping;
/*      */ import org.springframework.web.servlet.ModelAndView;
/*      */ import org.springframework.web.servlet.View;
/*      */ import org.springframework.web.servlet.mvc.multiaction.InternalPathMethodNameResolver;
/*      */ import org.springframework.web.servlet.mvc.multiaction.MethodNameResolver;
/*      */ import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;
/*      */ import org.springframework.web.servlet.support.RequestContextUtils;
/*      */ import org.springframework.web.servlet.support.WebContentGenerator;
/*      */ import org.springframework.web.util.UrlPathHelper;
/*      */ import org.springframework.web.util.WebUtils;
/*      */ 
/*      */ @Deprecated
/*      */ public class AnnotationMethodHandlerAdapter extends WebContentGenerator
/*      */   implements HandlerAdapter, Ordered, BeanFactoryAware
/*      */ {
/*      */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*  159 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*      */ 
/*  162 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*      */ 
/*  164 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*      */ 
/*  166 */   private MethodNameResolver methodNameResolver = new InternalPathMethodNameResolver();
/*      */   private WebBindingInitializer webBindingInitializer;
/*  170 */   private SessionAttributeStore sessionAttributeStore = new DefaultSessionAttributeStore();
/*      */ 
/*  172 */   private int cacheSecondsForSessionAttributeHandlers = 0;
/*      */ 
/*  174 */   private boolean synchronizeOnSession = false;
/*      */ 
/*  176 */   private ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*      */   private WebArgumentResolver[] customArgumentResolvers;
/*      */   private ModelAndViewResolver[] customModelAndViewResolvers;
/*      */   private HttpMessageConverter<?>[] messageConverters;
/*  184 */   private int order = 2147483647;
/*      */   private ConfigurableBeanFactory beanFactory;
/*      */   private BeanExpressionContext expressionContext;
/*  190 */   private final Map<Class<?>, ServletHandlerMethodResolver> methodResolverCache = new ConcurrentHashMap(64);
/*      */ 
/*  193 */   private final Map<Class<?>, Boolean> sessionAnnotatedClassesCache = new ConcurrentHashMap(64);
/*      */ 
/*      */   public AnnotationMethodHandlerAdapter()
/*      */   {
/*  198 */     super(false);
/*      */ 
/*  201 */     StringHttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter();
/*  202 */     stringHttpMessageConverter.setWriteAcceptCharset(false);
/*  203 */     this.messageConverters = new HttpMessageConverter[] { new ByteArrayHttpMessageConverter(), stringHttpMessageConverter, new SourceHttpMessageConverter(), new XmlAwareFormHttpMessageConverter() };
/*      */   }
/*      */ 
/*      */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath)
/*      */   {
/*  218 */     this.urlPathHelper.setAlwaysUseFullPath(alwaysUseFullPath);
/*      */   }
/*      */ 
/*      */   public void setUrlDecode(boolean urlDecode)
/*      */   {
/*  229 */     this.urlPathHelper.setUrlDecode(urlDecode);
/*      */   }
/*      */ 
/*      */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*      */   {
/*  238 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/*  239 */     this.urlPathHelper = urlPathHelper;
/*      */   }
/*      */ 
/*      */   public void setPathMatcher(PathMatcher pathMatcher)
/*      */   {
/*  247 */     Assert.notNull(pathMatcher, "PathMatcher must not be null");
/*  248 */     this.pathMatcher = pathMatcher;
/*      */   }
/*      */ 
/*      */   public void setMethodNameResolver(MethodNameResolver methodNameResolver)
/*      */   {
/*  258 */     this.methodNameResolver = methodNameResolver;
/*      */   }
/*      */ 
/*      */   public void setWebBindingInitializer(WebBindingInitializer webBindingInitializer)
/*      */   {
/*  266 */     this.webBindingInitializer = webBindingInitializer;
/*      */   }
/*      */ 
/*      */   public void setSessionAttributeStore(SessionAttributeStore sessionAttributeStore)
/*      */   {
/*  275 */     Assert.notNull(sessionAttributeStore, "SessionAttributeStore must not be null");
/*  276 */     this.sessionAttributeStore = sessionAttributeStore;
/*      */   }
/*      */ 
/*      */   public void setCacheSecondsForSessionAttributeHandlers(int cacheSecondsForSessionAttributeHandlers)
/*      */   {
/*  289 */     this.cacheSecondsForSessionAttributeHandlers = cacheSecondsForSessionAttributeHandlers;
/*      */   }
/*      */ 
/*      */   public void setSynchronizeOnSession(boolean synchronizeOnSession)
/*      */   {
/*  311 */     this.synchronizeOnSession = synchronizeOnSession;
/*      */   }
/*      */ 
/*      */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*      */   {
/*  320 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*      */   }
/*      */ 
/*      */   public void setCustomArgumentResolver(WebArgumentResolver argumentResolver)
/*      */   {
/*  329 */     this.customArgumentResolvers = new WebArgumentResolver[] { argumentResolver };
/*      */   }
/*      */ 
/*      */   public void setCustomArgumentResolvers(WebArgumentResolver[] argumentResolvers)
/*      */   {
/*  338 */     this.customArgumentResolvers = argumentResolvers;
/*      */   }
/*      */ 
/*      */   public void setCustomModelAndViewResolver(ModelAndViewResolver customModelAndViewResolver)
/*      */   {
/*  347 */     this.customModelAndViewResolvers = new ModelAndViewResolver[] { customModelAndViewResolver };
/*      */   }
/*      */ 
/*      */   public void setCustomModelAndViewResolvers(ModelAndViewResolver[] customModelAndViewResolvers)
/*      */   {
/*  356 */     this.customModelAndViewResolvers = customModelAndViewResolvers;
/*      */   }
/*      */ 
/*      */   public void setMessageConverters(HttpMessageConverter<?>[] messageConverters)
/*      */   {
/*  364 */     this.messageConverters = messageConverters;
/*      */   }
/*      */ 
/*      */   public HttpMessageConverter<?>[] getMessageConverters()
/*      */   {
/*  371 */     return this.messageConverters;
/*      */   }
/*      */ 
/*      */   public void setOrder(int order)
/*      */   {
/*  380 */     this.order = order;
/*      */   }
/*      */ 
/*      */   public int getOrder()
/*      */   {
/*  385 */     return this.order;
/*      */   }
/*      */ 
/*      */   public void setBeanFactory(BeanFactory beanFactory)
/*      */   {
/*  390 */     if ((beanFactory instanceof ConfigurableBeanFactory)) {
/*  391 */       this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*  392 */       this.expressionContext = new BeanExpressionContext(this.beanFactory, new RequestScope());
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean supports(Object handler)
/*      */   {
/*  399 */     return getMethodResolver(handler).hasHandlerMethods();
/*      */   }
/*      */ 
/*      */   public ModelAndView handle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*      */     throws Exception
/*      */   {
/*  406 */     Class clazz = ClassUtils.getUserClass(handler);
/*  407 */     Boolean annotatedWithSessionAttributes = (Boolean)this.sessionAnnotatedClassesCache.get(clazz);
/*  408 */     if (annotatedWithSessionAttributes == null) {
/*  409 */       annotatedWithSessionAttributes = Boolean.valueOf(AnnotationUtils.findAnnotation(clazz, SessionAttributes.class) != null);
/*  410 */       this.sessionAnnotatedClassesCache.put(clazz, annotatedWithSessionAttributes);
/*      */     }
/*      */ 
/*  413 */     if (annotatedWithSessionAttributes.booleanValue())
/*      */     {
/*  415 */       checkAndPrepare(request, response, this.cacheSecondsForSessionAttributeHandlers, true);
/*      */     }
/*      */     else
/*      */     {
/*  420 */       checkAndPrepare(request, response, true);
/*      */     }
/*      */ 
/*  424 */     if (this.synchronizeOnSession) {
/*  425 */       HttpSession session = request.getSession(false);
/*  426 */       if (session != null) {
/*  427 */         Object mutex = WebUtils.getSessionMutex(session);
/*  428 */         synchronized (mutex) {
/*  429 */           return invokeHandlerMethod(request, response, handler);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  434 */     return invokeHandlerMethod(request, response, handler);
/*      */   }
/*      */ 
/*      */   protected ModelAndView invokeHandlerMethod(HttpServletRequest request, HttpServletResponse response, Object handler)
/*      */     throws Exception
/*      */   {
/*  440 */     ServletHandlerMethodResolver methodResolver = getMethodResolver(handler);
/*  441 */     Method handlerMethod = methodResolver.resolveHandlerMethod(request);
/*  442 */     ServletHandlerMethodInvoker methodInvoker = new ServletHandlerMethodInvoker(methodResolver, null);
/*  443 */     ServletWebRequest webRequest = new ServletWebRequest(request, response);
/*  444 */     ExtendedModelMap implicitModel = new BindingAwareModelMap();
/*      */ 
/*  446 */     Object result = methodInvoker.invokeHandlerMethod(handlerMethod, handler, webRequest, implicitModel);
/*      */ 
/*  448 */     ModelAndView mav = methodInvoker
/*  448 */       .getModelAndView(handlerMethod, handler
/*  448 */       .getClass(), result, implicitModel, webRequest);
/*  449 */     methodInvoker.updateModelAttributes(handler, mav != null ? mav.getModel() : null, implicitModel, webRequest);
/*  450 */     return mav;
/*      */   }
/*      */ 
/*      */   public long getLastModified(HttpServletRequest request, Object handler)
/*      */   {
/*  463 */     return -1L;
/*      */   }
/*      */ 
/*      */   private ServletHandlerMethodResolver getMethodResolver(Object handler)
/*      */   {
/*  471 */     Class handlerClass = ClassUtils.getUserClass(handler);
/*  472 */     ServletHandlerMethodResolver resolver = (ServletHandlerMethodResolver)this.methodResolverCache.get(handlerClass);
/*  473 */     if (resolver == null) {
/*  474 */       synchronized (this.methodResolverCache) {
/*  475 */         resolver = (ServletHandlerMethodResolver)this.methodResolverCache.get(handlerClass);
/*  476 */         if (resolver == null) {
/*  477 */           resolver = new ServletHandlerMethodResolver(handlerClass, null);
/*  478 */           this.methodResolverCache.put(handlerClass, resolver);
/*      */         }
/*      */       }
/*      */     }
/*  482 */     return resolver;
/*      */   }
/*      */ 
/*      */   protected ServletRequestDataBinder createBinder(HttpServletRequest request, Object target, String objectName)
/*      */     throws Exception
/*      */   {
/*  500 */     return new ServletRequestDataBinder(target, objectName);
/*      */   }
/*      */ 
/*      */   protected HttpInputMessage createHttpInputMessage(HttpServletRequest servletRequest)
/*      */     throws Exception
/*      */   {
/*  512 */     return new ServletServerHttpRequest(servletRequest);
/*      */   }
/*      */ 
/*      */   protected HttpOutputMessage createHttpOutputMessage(HttpServletResponse servletResponse)
/*      */     throws Exception
/*      */   {
/*  524 */     return new ServletServerHttpResponse(servletResponse);
/*      */   }
/*      */ 
/*      */   static class RequestSpecificMappingInfoComparator
/*      */     implements Comparator<AnnotationMethodHandlerAdapter.RequestSpecificMappingInfo>
/*      */   {
/*      */     private final Comparator<String> pathComparator;
/*      */     private final ServerHttpRequest request;
/*      */ 
/*      */     RequestSpecificMappingInfoComparator(Comparator<String> pathComparator, HttpServletRequest request)
/*      */     {
/* 1216 */       this.pathComparator = pathComparator;
/* 1217 */       this.request = new ServletServerHttpRequest(request);
/*      */     }
/*      */ 
/*      */     public int compare(AnnotationMethodHandlerAdapter.RequestSpecificMappingInfo info1, AnnotationMethodHandlerAdapter.RequestSpecificMappingInfo info2)
/*      */     {
/* 1222 */       int pathComparison = this.pathComparator.compare(info1.bestMatchedPattern(), info2.bestMatchedPattern());
/* 1223 */       if (pathComparison != 0) {
/* 1224 */         return pathComparison;
/*      */       }
/* 1226 */       int info1ParamCount = info1.getParamCount();
/* 1227 */       int info2ParamCount = info2.getParamCount();
/* 1228 */       if (info1ParamCount != info2ParamCount) {
/* 1229 */         return info2ParamCount - info1ParamCount;
/*      */       }
/* 1231 */       int info1HeaderCount = info1.getHeaderCount();
/* 1232 */       int info2HeaderCount = info2.getHeaderCount();
/* 1233 */       if (info1HeaderCount != info2HeaderCount) {
/* 1234 */         return info2HeaderCount - info1HeaderCount;
/*      */       }
/* 1236 */       int acceptComparison = compareAcceptHeaders(info1, info2);
/* 1237 */       if (acceptComparison != 0) {
/* 1238 */         return acceptComparison;
/*      */       }
/* 1240 */       int info1MethodCount = info1.getMethodCount();
/* 1241 */       int info2MethodCount = info2.getMethodCount();
/* 1242 */       if ((info1MethodCount == 0) && (info2MethodCount > 0)) {
/* 1243 */         return 1;
/*      */       }
/* 1245 */       if ((info2MethodCount == 0) && (info1MethodCount > 0)) {
/* 1246 */         return -1;
/*      */       }
/* 1248 */       if (((info1MethodCount == 1 ? 1 : 0) & (info2MethodCount > 1 ? 1 : 0)) != 0) {
/* 1249 */         return -1;
/*      */       }
/* 1251 */       if (((info2MethodCount == 1 ? 1 : 0) & (info1MethodCount > 1 ? 1 : 0)) != 0) {
/* 1252 */         return 1;
/*      */       }
/* 1254 */       return 0;
/*      */     }
/*      */ 
/*      */     private int compareAcceptHeaders(AnnotationMethodHandlerAdapter.RequestMappingInfo info1, AnnotationMethodHandlerAdapter.RequestMappingInfo info2) {
/* 1258 */       List requestAccepts = this.request.getHeaders().getAccept();
/* 1259 */       MediaType.sortByQualityValue(requestAccepts);
/*      */ 
/* 1261 */       List info1Accepts = getAcceptHeaderValue(info1);
/* 1262 */       List info2Accepts = getAcceptHeaderValue(info2);
/*      */ 
/* 1264 */       for (MediaType requestAccept : requestAccepts) {
/* 1265 */         int pos1 = indexOfIncluded(info1Accepts, requestAccept);
/* 1266 */         int pos2 = indexOfIncluded(info2Accepts, requestAccept);
/* 1267 */         if (pos1 != pos2) {
/* 1268 */           return pos2 - pos1;
/*      */         }
/*      */       }
/* 1271 */       return 0;
/*      */     }
/*      */ 
/*      */     private int indexOfIncluded(List<MediaType> infoAccepts, MediaType requestAccept) {
/* 1275 */       for (int i = 0; i < infoAccepts.size(); i++) {
/* 1276 */         MediaType info1Accept = (MediaType)infoAccepts.get(i);
/* 1277 */         if (requestAccept.includes(info1Accept)) {
/* 1278 */           return i;
/*      */         }
/*      */       }
/* 1281 */       return -1;
/*      */     }
/*      */ 
/*      */     private List<MediaType> getAcceptHeaderValue(AnnotationMethodHandlerAdapter.RequestMappingInfo info) {
/* 1285 */       for (String header : AnnotationMethodHandlerAdapter.RequestMappingInfo.access$1800(info)) {
/* 1286 */         int separator = header.indexOf('=');
/* 1287 */         if (separator != -1) {
/* 1288 */           String key = header.substring(0, separator);
/* 1289 */           String value = header.substring(separator + 1);
/* 1290 */           if ("Accept".equalsIgnoreCase(key)) {
/* 1291 */             return MediaType.parseMediaTypes(value);
/*      */           }
/*      */         }
/*      */       }
/* 1295 */       return Collections.emptyList();
/*      */     }
/*      */   }
/*      */ 
/*      */   static class RequestSpecificMappingInfo extends AnnotationMethodHandlerAdapter.RequestMappingInfo
/*      */   {
/* 1171 */     private final List<String> matchedPatterns = new ArrayList();
/*      */ 
/*      */     RequestSpecificMappingInfo(String[] patterns, RequestMethod[] methods, String[] params, String[] headers) {
/* 1174 */       super(methods, params, headers);
/*      */     }
/*      */ 
/*      */     RequestSpecificMappingInfo(AnnotationMethodHandlerAdapter.RequestMappingInfo other) {
/* 1178 */       super(AnnotationMethodHandlerAdapter.RequestMappingInfo.access$1600(other), AnnotationMethodHandlerAdapter.RequestMappingInfo.access$1700(other), AnnotationMethodHandlerAdapter.RequestMappingInfo.access$1800(other));
/*      */     }
/*      */ 
/*      */     public void addMatchedPattern(String matchedPattern) {
/* 1182 */       this.matchedPatterns.add(matchedPattern);
/*      */     }
/*      */ 
/*      */     public void sortMatchedPatterns(Comparator<String> pathComparator) {
/* 1186 */       Collections.sort(this.matchedPatterns, pathComparator);
/*      */     }
/*      */ 
/*      */     public String bestMatchedPattern() {
/* 1190 */       return !this.matchedPatterns.isEmpty() ? (String)this.matchedPatterns.get(0) : null;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class RequestMappingInfo
/*      */   {
/*      */     private final String[] patterns;
/*      */     private final RequestMethod[] methods;
/*      */     private final String[] params;
/*      */     private final String[] headers;
/*      */ 
/*      */     RequestMappingInfo(String[] patterns, RequestMethod[] methods, String[] params, String[] headers)
/*      */     {
/* 1082 */       this.patterns = (patterns != null ? patterns : new String[0]);
/* 1083 */       this.methods = (methods != null ? methods : new RequestMethod[0]);
/* 1084 */       this.params = (params != null ? params : new String[0]);
/* 1085 */       this.headers = (headers != null ? headers : new String[0]);
/*      */     }
/*      */ 
/*      */     public boolean hasPatterns() {
/* 1089 */       return this.patterns.length > 0;
/*      */     }
/*      */ 
/*      */     public String[] getPatterns() {
/* 1093 */       return this.patterns;
/*      */     }
/*      */ 
/*      */     public int getMethodCount() {
/* 1097 */       return this.methods.length;
/*      */     }
/*      */ 
/*      */     public int getParamCount() {
/* 1101 */       return this.params.length;
/*      */     }
/*      */ 
/*      */     public int getHeaderCount() {
/* 1105 */       return this.headers.length;
/*      */     }
/*      */ 
/*      */     public boolean matches(HttpServletRequest request) {
/* 1109 */       return (matchesRequestMethod(request)) && (matchesParameters(request)) && (matchesHeaders(request));
/*      */     }
/*      */ 
/*      */     public boolean matchesHeaders(HttpServletRequest request) {
/* 1113 */       return ServletAnnotationMappingUtils.checkHeaders(this.headers, request);
/*      */     }
/*      */ 
/*      */     public boolean matchesParameters(HttpServletRequest request) {
/* 1117 */       return ServletAnnotationMappingUtils.checkParameters(this.params, request);
/*      */     }
/*      */ 
/*      */     public boolean matchesRequestMethod(HttpServletRequest request) {
/* 1121 */       return ServletAnnotationMappingUtils.checkRequestMethod(this.methods, request);
/*      */     }
/*      */ 
/*      */     public Set<String> methodNames() {
/* 1125 */       Set methodNames = new LinkedHashSet(this.methods.length);
/* 1126 */       for (RequestMethod method : this.methods) {
/* 1127 */         methodNames.add(method.name());
/*      */       }
/* 1129 */       return methodNames;
/*      */     }
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/* 1134 */       RequestMappingInfo other = (RequestMappingInfo)obj;
/*      */ 
/* 1136 */       return (Arrays.equals(this.patterns, other.patterns)) && (Arrays.equals(this.methods, other.methods)) && 
/* 1136 */         (Arrays.equals(this.params, other.params)) && 
/* 1136 */         (Arrays.equals(this.headers, other.headers));
/*      */     }
/*      */ 
/*      */     public int hashCode()
/*      */     {
/* 1142 */       return Arrays.hashCode(this.patterns) * 23 + Arrays.hashCode(this.methods) * 29 + 
/* 1142 */         Arrays.hashCode(this.params) * 
/* 1142 */         31 + Arrays.hashCode(this.headers);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1147 */       StringBuilder builder = new StringBuilder();
/* 1148 */       builder.append(Arrays.asList(this.patterns));
/* 1149 */       if (this.methods.length > 0) {
/* 1150 */         builder.append(',');
/* 1151 */         builder.append(Arrays.asList(this.methods));
/*      */       }
/* 1153 */       if (this.headers.length > 0) {
/* 1154 */         builder.append(',');
/* 1155 */         builder.append(Arrays.asList(this.headers));
/*      */       }
/* 1157 */       if (this.params.length > 0) {
/* 1158 */         builder.append(',');
/* 1159 */         builder.append(Arrays.asList(this.params));
/*      */       }
/* 1161 */       return builder.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ServletHandlerMethodInvoker extends HandlerMethodInvoker
/*      */   {
/*  777 */     private boolean responseArgumentUsed = false;
/*      */ 
/*      */     private ServletHandlerMethodInvoker(HandlerMethodResolver resolver) {
/*  780 */       super(AnnotationMethodHandlerAdapter.this.webBindingInitializer, AnnotationMethodHandlerAdapter.this.sessionAttributeStore, AnnotationMethodHandlerAdapter.this.parameterNameDiscoverer, AnnotationMethodHandlerAdapter.this.customArgumentResolvers, 
/*  781 */         AnnotationMethodHandlerAdapter.this.messageConverters);
/*      */     }
/*      */ 
/*      */     protected void raiseMissingParameterException(String paramName, Class<?> paramType) throws Exception
/*      */     {
/*  786 */       throw new MissingServletRequestParameterException(paramName, paramType.getSimpleName());
/*      */     }
/*      */ 
/*      */     protected void raiseSessionRequiredException(String message) throws Exception
/*      */     {
/*  791 */       throw new HttpSessionRequiredException(message);
/*      */     }
/*      */ 
/*      */     protected WebDataBinder createBinder(NativeWebRequest webRequest, Object target, String objectName)
/*      */       throws Exception
/*      */     {
/*  798 */       return AnnotationMethodHandlerAdapter.this.createBinder(
/*  799 */         (HttpServletRequest)webRequest
/*  799 */         .getNativeRequest(HttpServletRequest.class), 
/*  799 */         target, objectName);
/*      */     }
/*      */ 
/*      */     protected void doBind(WebDataBinder binder, NativeWebRequest webRequest) throws Exception
/*      */     {
/*  804 */       ServletRequestDataBinder servletBinder = (ServletRequestDataBinder)binder;
/*  805 */       servletBinder.bind((ServletRequest)webRequest.getNativeRequest(ServletRequest.class));
/*      */     }
/*      */ 
/*      */     protected HttpInputMessage createHttpInputMessage(NativeWebRequest webRequest) throws Exception
/*      */     {
/*  810 */       HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*  811 */       return AnnotationMethodHandlerAdapter.this.createHttpInputMessage(servletRequest);
/*      */     }
/*      */ 
/*      */     protected HttpOutputMessage createHttpOutputMessage(NativeWebRequest webRequest) throws Exception
/*      */     {
/*  816 */       HttpServletResponse servletResponse = (HttpServletResponse)webRequest.getNativeResponse();
/*  817 */       return AnnotationMethodHandlerAdapter.this.createHttpOutputMessage(servletResponse);
/*      */     }
/*      */ 
/*      */     protected Object resolveDefaultValue(String value)
/*      */     {
/*  822 */       if (AnnotationMethodHandlerAdapter.this.beanFactory == null) {
/*  823 */         return value;
/*      */       }
/*  825 */       String placeholdersResolved = AnnotationMethodHandlerAdapter.this.beanFactory.resolveEmbeddedValue(value);
/*  826 */       BeanExpressionResolver exprResolver = AnnotationMethodHandlerAdapter.this.beanFactory.getBeanExpressionResolver();
/*  827 */       if (exprResolver == null) {
/*  828 */         return value;
/*      */       }
/*  830 */       return exprResolver.evaluate(placeholdersResolved, AnnotationMethodHandlerAdapter.this.expressionContext);
/*      */     }
/*      */ 
/*      */     protected Object resolveCookieValue(String cookieName, Class<?> paramType, NativeWebRequest webRequest)
/*      */       throws Exception
/*      */     {
/*  837 */       HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*  838 */       Cookie cookieValue = WebUtils.getCookie(servletRequest, cookieName);
/*  839 */       if (Cookie.class.isAssignableFrom(paramType)) {
/*  840 */         return cookieValue;
/*      */       }
/*  842 */       if (cookieValue != null) {
/*  843 */         return AnnotationMethodHandlerAdapter.this.urlPathHelper.decodeRequestString(servletRequest, cookieValue.getValue());
/*      */       }
/*      */ 
/*  846 */       return null;
/*      */     }
/*      */ 
/*      */     protected String resolvePathVariable(String pathVarName, Class<?> paramType, NativeWebRequest webRequest)
/*      */       throws Exception
/*      */     {
/*  855 */       HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*      */ 
/*  857 */       Map uriTemplateVariables = (Map)servletRequest
/*  857 */         .getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/*      */ 
/*  858 */       if ((uriTemplateVariables == null) || (!uriTemplateVariables.containsKey(pathVarName))) {
/*  859 */         throw new IllegalStateException("Could not find @PathVariable [" + pathVarName + "] in @RequestMapping");
/*      */       }
/*      */ 
/*  862 */       return (String)uriTemplateVariables.get(pathVarName);
/*      */     }
/*      */ 
/*      */     protected Object resolveStandardArgument(Class<?> parameterType, NativeWebRequest webRequest) throws Exception
/*      */     {
/*  867 */       HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*  868 */       HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/*      */ 
/*  870 */       if ((ServletRequest.class.isAssignableFrom(parameterType)) || 
/*  871 */         (MultipartRequest.class
/*  871 */         .isAssignableFrom(parameterType)))
/*      */       {
/*  872 */         Object nativeRequest = webRequest.getNativeRequest(parameterType);
/*  873 */         if (nativeRequest == null)
/*      */         {
/*  875 */           throw new IllegalStateException("Current request is not of type [" + parameterType
/*  875 */             .getName() + "]: " + request);
/*      */         }
/*  877 */         return nativeRequest;
/*      */       }
/*  879 */       if (ServletResponse.class.isAssignableFrom(parameterType)) {
/*  880 */         this.responseArgumentUsed = true;
/*  881 */         Object nativeResponse = webRequest.getNativeResponse(parameterType);
/*  882 */         if (nativeResponse == null)
/*      */         {
/*  884 */           throw new IllegalStateException("Current response is not of type [" + parameterType
/*  884 */             .getName() + "]: " + response);
/*      */         }
/*  886 */         return nativeResponse;
/*      */       }
/*  888 */       if (HttpSession.class.isAssignableFrom(parameterType)) {
/*  889 */         return request.getSession();
/*      */       }
/*  891 */       if (Principal.class.isAssignableFrom(parameterType)) {
/*  892 */         return request.getUserPrincipal();
/*      */       }
/*  894 */       if (Locale.class.equals(parameterType)) {
/*  895 */         return RequestContextUtils.getLocale(request);
/*      */       }
/*  897 */       if (InputStream.class.isAssignableFrom(parameterType)) {
/*  898 */         return request.getInputStream();
/*      */       }
/*  900 */       if (Reader.class.isAssignableFrom(parameterType)) {
/*  901 */         return request.getReader();
/*      */       }
/*  903 */       if (OutputStream.class.isAssignableFrom(parameterType)) {
/*  904 */         this.responseArgumentUsed = true;
/*  905 */         return response.getOutputStream();
/*      */       }
/*  907 */       if (Writer.class.isAssignableFrom(parameterType)) {
/*  908 */         this.responseArgumentUsed = true;
/*  909 */         return response.getWriter();
/*      */       }
/*  911 */       return super.resolveStandardArgument(parameterType, webRequest);
/*      */     }
/*      */ 
/*      */     public ModelAndView getModelAndView(Method handlerMethod, Class<?> handlerType, Object returnValue, ExtendedModelMap implicitModel, ServletWebRequest webRequest)
/*      */       throws Exception
/*      */     {
/*  918 */       ResponseStatus responseStatusAnn = (ResponseStatus)AnnotationUtils.findAnnotation(handlerMethod, ResponseStatus.class);
/*      */       HttpStatus responseStatus;
/*      */       String reason;
/*  919 */       if (responseStatusAnn != null) {
/*  920 */         responseStatus = responseStatusAnn.value();
/*  921 */         reason = responseStatusAnn.reason();
/*  922 */         if (!StringUtils.hasText(reason)) {
/*  923 */           webRequest.getResponse().setStatus(responseStatus.value());
/*      */         }
/*      */         else {
/*  926 */           webRequest.getResponse().sendError(responseStatus.value(), reason);
/*      */         }
/*      */ 
/*  930 */         webRequest.getRequest().setAttribute(View.RESPONSE_STATUS_ATTRIBUTE, responseStatus);
/*      */ 
/*  932 */         this.responseArgumentUsed = true;
/*      */       }
/*      */ 
/*  936 */       if (AnnotationMethodHandlerAdapter.this.customModelAndViewResolvers != null) {
/*  937 */         responseStatus = AnnotationMethodHandlerAdapter.this.customModelAndViewResolvers; reason = responseStatus.length; for (String str1 = 0; str1 < reason; str1++) { ModelAndViewResolver mavResolver = responseStatus[str1];
/*  938 */           ModelAndView mav = mavResolver.resolveModelAndView(handlerMethod, handlerType, returnValue, implicitModel, webRequest);
/*      */ 
/*  940 */           if (mav != ModelAndViewResolver.UNRESOLVED) {
/*  941 */             return mav;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  946 */       if ((returnValue instanceof HttpEntity)) {
/*  947 */         handleHttpEntityResponse((HttpEntity)returnValue, webRequest);
/*  948 */         return null;
/*      */       }
/*  950 */       if (AnnotationUtils.findAnnotation(handlerMethod, ResponseBody.class) != null) {
/*  951 */         handleResponseBody(returnValue, webRequest);
/*  952 */         return null;
/*      */       }
/*  954 */       if ((returnValue instanceof ModelAndView)) {
/*  955 */         ModelAndView mav = (ModelAndView)returnValue;
/*  956 */         mav.getModelMap().mergeAttributes(implicitModel);
/*  957 */         return mav;
/*      */       }
/*  959 */       if ((returnValue instanceof Model)) {
/*  960 */         return new ModelAndView().addAllObjects(implicitModel).addAllObjects(((Model)returnValue).asMap());
/*      */       }
/*  962 */       if ((returnValue instanceof View)) {
/*  963 */         return new ModelAndView((View)returnValue).addAllObjects(implicitModel);
/*      */       }
/*  965 */       if (AnnotationUtils.findAnnotation(handlerMethod, ModelAttribute.class) != null) {
/*  966 */         addReturnValueAsModelAttribute(handlerMethod, handlerType, returnValue, implicitModel);
/*  967 */         return new ModelAndView().addAllObjects(implicitModel);
/*      */       }
/*  969 */       if ((returnValue instanceof Map)) {
/*  970 */         return new ModelAndView().addAllObjects(implicitModel).addAllObjects((Map)returnValue);
/*      */       }
/*  972 */       if ((returnValue instanceof String)) {
/*  973 */         return new ModelAndView((String)returnValue).addAllObjects(implicitModel);
/*      */       }
/*  975 */       if (returnValue == null)
/*      */       {
/*  977 */         if ((this.responseArgumentUsed) || (webRequest.isNotModified())) {
/*  978 */           return null;
/*      */         }
/*      */ 
/*  982 */         return new ModelAndView().addAllObjects(implicitModel);
/*      */       }
/*      */ 
/*  985 */       if (!BeanUtils.isSimpleProperty(returnValue.getClass()))
/*      */       {
/*  987 */         addReturnValueAsModelAttribute(handlerMethod, handlerType, returnValue, implicitModel);
/*  988 */         return new ModelAndView().addAllObjects(implicitModel);
/*      */       }
/*      */ 
/*  991 */       throw new IllegalArgumentException("Invalid handler method return value: " + returnValue);
/*      */     }
/*      */ 
/*      */     private void handleResponseBody(Object returnValue, ServletWebRequest webRequest)
/*      */       throws Exception
/*      */     {
/*  997 */       if (returnValue == null) {
/*  998 */         return;
/*      */       }
/* 1000 */       HttpInputMessage inputMessage = createHttpInputMessage(webRequest);
/* 1001 */       HttpOutputMessage outputMessage = createHttpOutputMessage(webRequest);
/* 1002 */       writeWithMessageConverters(returnValue, inputMessage, outputMessage);
/*      */     }
/*      */ 
/*      */     private void handleHttpEntityResponse(HttpEntity<?> responseEntity, ServletWebRequest webRequest) throws Exception
/*      */     {
/* 1007 */       if (responseEntity == null) {
/* 1008 */         return;
/*      */       }
/* 1010 */       HttpInputMessage inputMessage = createHttpInputMessage(webRequest);
/* 1011 */       HttpOutputMessage outputMessage = createHttpOutputMessage(webRequest);
/* 1012 */       if (((responseEntity instanceof ResponseEntity)) && ((outputMessage instanceof ServerHttpResponse))) {
/* 1013 */         ((ServerHttpResponse)outputMessage).setStatusCode(((ResponseEntity)responseEntity).getStatusCode());
/*      */       }
/* 1015 */       HttpHeaders entityHeaders = responseEntity.getHeaders();
/* 1016 */       if (!entityHeaders.isEmpty()) {
/* 1017 */         outputMessage.getHeaders().putAll(entityHeaders);
/*      */       }
/* 1019 */       Object body = responseEntity.getBody();
/* 1020 */       if (body != null) {
/* 1021 */         writeWithMessageConverters(body, inputMessage, outputMessage);
/*      */       }
/*      */       else
/*      */       {
/* 1025 */         outputMessage.getBody();
/*      */       }
/*      */     }
/*      */ 
/*      */     private void writeWithMessageConverters(Object returnValue, HttpInputMessage inputMessage, HttpOutputMessage outputMessage)
/*      */       throws IOException, HttpMediaTypeNotAcceptableException
/*      */     {
/* 1033 */       List acceptedMediaTypes = inputMessage.getHeaders().getAccept();
/* 1034 */       if (acceptedMediaTypes.isEmpty()) {
/* 1035 */         acceptedMediaTypes = Collections.singletonList(MediaType.ALL);
/*      */       }
/* 1037 */       MediaType.sortByQualityValue(acceptedMediaTypes);
/* 1038 */       Class returnValueType = returnValue.getClass();
/* 1039 */       List allSupportedMediaTypes = new ArrayList();
/* 1040 */       if (AnnotationMethodHandlerAdapter.this.getMessageConverters() != null) {
/* 1041 */         for (Object localObject = acceptedMediaTypes.iterator(); ((Iterator)localObject).hasNext(); ) { acceptedMediaType = (MediaType)((Iterator)localObject).next();
/* 1042 */           for (HttpMessageConverter messageConverter : AnnotationMethodHandlerAdapter.this.getMessageConverters()) {
/* 1043 */             if (messageConverter.canWrite(returnValueType, acceptedMediaType)) {
/* 1044 */               messageConverter.write(returnValue, acceptedMediaType, outputMessage);
/* 1045 */               if (AnnotationMethodHandlerAdapter.this.logger.isDebugEnabled()) {
/* 1046 */                 MediaType contentType = outputMessage.getHeaders().getContentType();
/* 1047 */                 if (contentType == null) {
/* 1048 */                   contentType = acceptedMediaType;
/*      */                 }
/* 1050 */                 AnnotationMethodHandlerAdapter.this.logger.debug("Written [" + returnValue + "] as \"" + contentType + "\" using [" + messageConverter + "]");
/*      */               }
/*      */ 
/* 1053 */               this.responseArgumentUsed = true;
/* 1054 */               return;
/*      */             }
/*      */           }
/*      */         }
/* 1058 */         localObject = AnnotationMethodHandlerAdapter.this.messageConverters; MediaType acceptedMediaType = localObject.length; for (MediaType localMediaType1 = 0; localMediaType1 < acceptedMediaType; localMediaType1++) { HttpMessageConverter messageConverter = localObject[localMediaType1];
/* 1059 */           allSupportedMediaTypes.addAll(messageConverter.getSupportedMediaTypes());
/*      */         }
/*      */       }
/* 1062 */       throw new HttpMediaTypeNotAcceptableException(allSupportedMediaTypes);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ServletHandlerMethodResolver extends HandlerMethodResolver
/*      */   {
/*  533 */     private final Map<Method, AnnotationMethodHandlerAdapter.RequestMappingInfo> mappings = new HashMap();
/*      */ 
/*      */     private ServletHandlerMethodResolver() {
/*  536 */       init(handlerType);
/*      */     }
/*      */ 
/*      */     protected boolean isHandlerMethod(Method method)
/*      */     {
/*  541 */       if (this.mappings.containsKey(method)) {
/*  542 */         return true;
/*      */       }
/*  544 */       RequestMapping mapping = (RequestMapping)AnnotationUtils.findAnnotation(method, RequestMapping.class);
/*  545 */       if (mapping != null) {
/*  546 */         String[] patterns = mapping.value();
/*  547 */         RequestMethod[] methods = new RequestMethod[0];
/*  548 */         String[] params = new String[0];
/*  549 */         String[] headers = new String[0];
/*  550 */         if ((!hasTypeLevelMapping()) || (!Arrays.equals(mapping.method(), getTypeLevelMapping().method()))) {
/*  551 */           methods = mapping.method();
/*      */         }
/*  553 */         if ((!hasTypeLevelMapping()) || (!Arrays.equals(mapping.params(), getTypeLevelMapping().params()))) {
/*  554 */           params = mapping.params();
/*      */         }
/*  556 */         if ((!hasTypeLevelMapping()) || (!Arrays.equals(mapping.headers(), getTypeLevelMapping().headers()))) {
/*  557 */           headers = mapping.headers();
/*      */         }
/*  559 */         AnnotationMethodHandlerAdapter.RequestMappingInfo mappingInfo = new AnnotationMethodHandlerAdapter.RequestMappingInfo(patterns, methods, params, headers);
/*  560 */         this.mappings.put(method, mappingInfo);
/*  561 */         return true;
/*      */       }
/*  563 */       return false;
/*      */     }
/*      */ 
/*      */     public Method resolveHandlerMethod(HttpServletRequest request) throws ServletException {
/*  567 */       String lookupPath = AnnotationMethodHandlerAdapter.this.urlPathHelper.getLookupPathForRequest(request);
/*  568 */       Comparator pathComparator = AnnotationMethodHandlerAdapter.this.pathMatcher.getPatternComparator(lookupPath);
/*  569 */       Map targetHandlerMethods = new LinkedHashMap();
/*  570 */       Set allowedMethods = new LinkedHashSet(7);
/*  571 */       String resolvedMethodName = null;
/*  572 */       for (Method handlerMethod : getHandlerMethods()) {
/*  573 */         AnnotationMethodHandlerAdapter.RequestSpecificMappingInfo mappingInfo = new AnnotationMethodHandlerAdapter.RequestSpecificMappingInfo((AnnotationMethodHandlerAdapter.RequestMappingInfo)this.mappings.get(handlerMethod));
/*  574 */         boolean match = false;
/*      */         String str1;
/*      */         String pattern;
/*  575 */         if (mappingInfo.hasPatterns()) {
/*  576 */           String[] arrayOfString1 = mappingInfo.getPatterns(); int i = arrayOfString1.length; for (str1 = 0; str1 < i; str1++) { pattern = arrayOfString1[str1];
/*  577 */             if ((!hasTypeLevelMapping()) && (!pattern.startsWith("/"))) {
/*  578 */               pattern = "/" + pattern;
/*      */             }
/*  580 */             String combinedPattern = getCombinedPattern(pattern, lookupPath, request);
/*  581 */             if (combinedPattern != null) {
/*  582 */               if (mappingInfo.matches(request)) {
/*  583 */                 match = true;
/*  584 */                 mappingInfo.addMatchedPattern(combinedPattern);
/*      */               }
/*      */               else {
/*  587 */                 if (mappingInfo.matchesRequestMethod(request)) break;
/*  588 */                 allowedMethods.addAll(mappingInfo.methodNames()); break;
/*      */               }
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  594 */           mappingInfo.sortMatchedPatterns(pathComparator);
/*      */         }
/*  596 */         else if (useTypeLevelMapping(request)) {
/*  597 */           String[] typeLevelPatterns = getTypeLevelMapping().value();
/*  598 */           String[] arrayOfString2 = typeLevelPatterns; str1 = arrayOfString2.length; for (pattern = 0; pattern < str1; pattern++) { String typeLevelPattern = arrayOfString2[pattern];
/*  599 */             if (!typeLevelPattern.startsWith("/")) {
/*  600 */               typeLevelPattern = "/" + typeLevelPattern;
/*      */             }
/*  602 */             boolean useSuffixPattern = useSuffixPattern(request);
/*  603 */             if (getMatchingPattern(typeLevelPattern, lookupPath, useSuffixPattern) != null) {
/*  604 */               if (mappingInfo.matches(request)) {
/*  605 */                 match = true;
/*  606 */                 mappingInfo.addMatchedPattern(typeLevelPattern);
/*      */               }
/*      */               else {
/*  609 */                 if (mappingInfo.matchesRequestMethod(request)) break;
/*  610 */                 allowedMethods.addAll(mappingInfo.methodNames()); break;
/*      */               }
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  616 */           mappingInfo.sortMatchedPatterns(pathComparator);
/*      */         }
/*      */         else
/*      */         {
/*  620 */           match = mappingInfo.matches(request);
/*  621 */           if ((match) && (mappingInfo.getMethodCount() == 0) && (mappingInfo.getParamCount() == 0) && (resolvedMethodName != null) && 
/*  622 */             (!resolvedMethodName
/*  622 */             .equals(handlerMethod
/*  622 */             .getName()))) {
/*  623 */             match = false;
/*      */           }
/*  626 */           else if (!mappingInfo.matchesRequestMethod(request)) {
/*  627 */             allowedMethods.addAll(mappingInfo.methodNames());
/*      */           }
/*      */         }
/*      */ 
/*  631 */         if (match) {
/*  632 */           Method oldMappedMethod = (Method)targetHandlerMethods.put(mappingInfo, handlerMethod);
/*  633 */           if ((oldMappedMethod != null) && (oldMappedMethod != handlerMethod)) {
/*  634 */             if ((AnnotationMethodHandlerAdapter.this.methodNameResolver != null) && (!mappingInfo.hasPatterns()) && 
/*  635 */               (!oldMappedMethod.getName().equals(handlerMethod.getName()))) {
/*  636 */               if (resolvedMethodName == null) {
/*  637 */                 resolvedMethodName = AnnotationMethodHandlerAdapter.this.methodNameResolver.getHandlerMethodName(request);
/*      */               }
/*  639 */               if (!resolvedMethodName.equals(oldMappedMethod.getName())) {
/*  640 */                 oldMappedMethod = null;
/*      */               }
/*  642 */               if (!resolvedMethodName.equals(handlerMethod.getName())) {
/*  643 */                 if (oldMappedMethod != null) {
/*  644 */                   targetHandlerMethods.put(mappingInfo, oldMappedMethod);
/*  645 */                   oldMappedMethod = null;
/*      */                 }
/*      */                 else {
/*  648 */                   targetHandlerMethods.remove(mappingInfo);
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/*  653 */             if (oldMappedMethod != null) {
/*  654 */               throw new IllegalStateException("Ambiguous handler methods mapped for HTTP path '" + lookupPath + "': {" + oldMappedMethod + ", " + handlerMethod + "}. If you intend to handle the same path in multiple methods, then factor " + "them out into a dedicated handler class with that path mapped at the type level!");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  663 */       if (!targetHandlerMethods.isEmpty()) {
/*  664 */         Object matches = new ArrayList(targetHandlerMethods.keySet());
/*  665 */         AnnotationMethodHandlerAdapter.RequestSpecificMappingInfoComparator requestMappingInfoComparator = new AnnotationMethodHandlerAdapter.RequestSpecificMappingInfoComparator(pathComparator, request);
/*      */ 
/*  667 */         Collections.sort((List)matches, requestMappingInfoComparator);
/*  668 */         AnnotationMethodHandlerAdapter.RequestSpecificMappingInfo bestMappingMatch = (AnnotationMethodHandlerAdapter.RequestSpecificMappingInfo)((List)matches).get(0);
/*  669 */         String bestMatchedPath = bestMappingMatch.bestMatchedPattern();
/*  670 */         if (bestMatchedPath != null) {
/*  671 */           extractHandlerMethodUriTemplates(bestMatchedPath, lookupPath, request);
/*      */         }
/*  673 */         return (Method)targetHandlerMethods.get(bestMappingMatch);
/*      */       }
/*      */ 
/*  676 */       if (!allowedMethods.isEmpty()) {
/*  677 */         throw new HttpRequestMethodNotSupportedException(request.getMethod(), StringUtils.toStringArray(allowedMethods));
/*      */       }
/*  679 */       throw new NoSuchRequestHandlingMethodException(lookupPath, request.getMethod(), request.getParameterMap());
/*      */     }
/*      */ 
/*      */     private boolean useTypeLevelMapping(HttpServletRequest request)
/*      */     {
/*  684 */       if ((!hasTypeLevelMapping()) || (ObjectUtils.isEmpty(getTypeLevelMapping().value()))) {
/*  685 */         return false;
/*      */       }
/*  687 */       Object value = request.getAttribute(HandlerMapping.INTROSPECT_TYPE_LEVEL_MAPPING);
/*  688 */       return (value != null ? (Boolean)value : Boolean.TRUE).booleanValue();
/*      */     }
/*      */ 
/*      */     private boolean useSuffixPattern(HttpServletRequest request) {
/*  692 */       Object value = request.getAttribute(DefaultAnnotationHandlerMapping.USE_DEFAULT_SUFFIX_PATTERN);
/*  693 */       return (value != null ? (Boolean)value : Boolean.TRUE).booleanValue();
/*      */     }
/*      */ 
/*      */     private String getCombinedPattern(String methodLevelPattern, String lookupPath, HttpServletRequest request)
/*      */     {
/*  708 */       boolean useSuffixPattern = useSuffixPattern(request);
/*  709 */       if (useTypeLevelMapping(request)) {
/*  710 */         String[] typeLevelPatterns = getTypeLevelMapping().value();
/*  711 */         for (String typeLevelPattern : typeLevelPatterns) {
/*  712 */           if (!typeLevelPattern.startsWith("/")) {
/*  713 */             typeLevelPattern = "/" + typeLevelPattern;
/*      */           }
/*  715 */           String combinedPattern = AnnotationMethodHandlerAdapter.this.pathMatcher.combine(typeLevelPattern, methodLevelPattern);
/*  716 */           String matchingPattern = getMatchingPattern(combinedPattern, lookupPath, useSuffixPattern);
/*  717 */           if (matchingPattern != null) {
/*  718 */             return matchingPattern;
/*      */           }
/*      */         }
/*  721 */         return null;
/*      */       }
/*  723 */       String bestMatchingPattern = (String)request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
/*  724 */       if ((StringUtils.hasText(bestMatchingPattern)) && (bestMatchingPattern.endsWith("*"))) {
/*  725 */         String combinedPattern = AnnotationMethodHandlerAdapter.this.pathMatcher.combine(bestMatchingPattern, methodLevelPattern);
/*  726 */         String matchingPattern = getMatchingPattern(combinedPattern, lookupPath, useSuffixPattern);
/*  727 */         if ((matchingPattern != null) && (!matchingPattern.equals(bestMatchingPattern))) {
/*  728 */           return matchingPattern;
/*      */         }
/*      */       }
/*  731 */       return getMatchingPattern(methodLevelPattern, lookupPath, useSuffixPattern);
/*      */     }
/*      */ 
/*      */     private String getMatchingPattern(String pattern, String lookupPath, boolean useSuffixPattern) {
/*  735 */       if (pattern.equals(lookupPath)) {
/*  736 */         return pattern;
/*      */       }
/*  738 */       boolean hasSuffix = pattern.indexOf(46) != -1;
/*  739 */       if ((useSuffixPattern) && (!hasSuffix)) {
/*  740 */         String patternWithSuffix = pattern + ".*";
/*  741 */         if (AnnotationMethodHandlerAdapter.this.pathMatcher.match(patternWithSuffix, lookupPath)) {
/*  742 */           return patternWithSuffix;
/*      */         }
/*      */       }
/*  745 */       if (AnnotationMethodHandlerAdapter.this.pathMatcher.match(pattern, lookupPath)) {
/*  746 */         return pattern;
/*      */       }
/*  748 */       boolean endsWithSlash = pattern.endsWith("/");
/*  749 */       if ((useSuffixPattern) && (!endsWithSlash)) {
/*  750 */         String patternWithSlash = pattern + "/";
/*  751 */         if (AnnotationMethodHandlerAdapter.this.pathMatcher.match(patternWithSlash, lookupPath)) {
/*  752 */           return patternWithSlash;
/*      */         }
/*      */       }
/*  755 */       return null;
/*      */     }
/*      */ 
/*      */     private void extractHandlerMethodUriTemplates(String mappedPattern, String lookupPath, HttpServletRequest request)
/*      */     {
/*  761 */       Map variables = (Map)request
/*  761 */         .getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/*      */ 
/*  762 */       int patternVariableCount = StringUtils.countOccurrencesOf(mappedPattern, "{");
/*  763 */       if (((variables == null) || (patternVariableCount != variables.size())) && (AnnotationMethodHandlerAdapter.this.pathMatcher.match(mappedPattern, lookupPath))) {
/*  764 */         variables = AnnotationMethodHandlerAdapter.this.pathMatcher.extractUriTemplateVariables(mappedPattern, lookupPath);
/*  765 */         Map decodedVariables = AnnotationMethodHandlerAdapter.this.urlPathHelper.decodePathVariables(request, variables);
/*  766 */         request.setAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, decodedVariables);
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.annotation.AnnotationMethodHandlerAdapter
 * JD-Core Version:    0.6.2
 */