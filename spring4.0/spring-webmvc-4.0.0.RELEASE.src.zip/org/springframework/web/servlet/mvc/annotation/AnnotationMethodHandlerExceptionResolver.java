/*     */ package org.springframework.web.servlet.mvc.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ExceptionDepthComparator;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.XmlAwareFormHttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.ui.Model;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import org.springframework.web.bind.annotation.ResponseStatus;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public class AnnotationMethodHandlerExceptionResolver extends AbstractHandlerExceptionResolver
/*     */ {
/*  92 */   private static final Method NO_METHOD_FOUND = ClassUtils.getMethodIfAvailable(System.class, "currentTimeMillis", (Class[])null);
/*     */ 
/*  94 */   private final Map<Class<?>, Map<Class<? extends Throwable>, Method>> exceptionHandlerCache = new ConcurrentHashMap(64);
/*     */   private WebArgumentResolver[] customArgumentResolvers;
/*  99 */   private HttpMessageConverter<?>[] messageConverters = { new ByteArrayHttpMessageConverter(), new StringHttpMessageConverter(), new SourceHttpMessageConverter(), new XmlAwareFormHttpMessageConverter() };
/*     */ 
/*     */   public void setCustomArgumentResolver(WebArgumentResolver argumentResolver)
/*     */   {
/* 111 */     this.customArgumentResolvers = new WebArgumentResolver[] { argumentResolver };
/*     */   }
/*     */ 
/*     */   public void setCustomArgumentResolvers(WebArgumentResolver[] argumentResolvers)
/*     */   {
/* 120 */     this.customArgumentResolvers = argumentResolvers;
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(HttpMessageConverter<?>[] messageConverters)
/*     */   {
/* 128 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*     */   {
/* 136 */     if (handler != null) {
/* 137 */       Method handlerMethod = findBestExceptionHandlerMethod(handler, ex);
/* 138 */       if (handlerMethod != null) {
/* 139 */         ServletWebRequest webRequest = new ServletWebRequest(request, response);
/*     */         try {
/* 141 */           Object[] args = resolveHandlerArguments(handlerMethod, handler, webRequest, ex);
/* 142 */           if (this.logger.isDebugEnabled()) {
/* 143 */             this.logger.debug(new StringBuilder().append("Invoking request handler method: ").append(handlerMethod).toString());
/*     */           }
/* 145 */           Object retVal = doInvokeMethod(handlerMethod, handler, args);
/* 146 */           return getModelAndView(handlerMethod, retVal, webRequest);
/*     */         }
/*     */         catch (Exception invocationEx) {
/* 149 */           this.logger.error(new StringBuilder().append("Invoking request method resulted in exception : ").append(handlerMethod).toString(), invocationEx);
/*     */         }
/*     */       }
/*     */     }
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   private Method findBestExceptionHandlerMethod(Object handler, Exception thrownException)
/*     */   {
/* 163 */     final Class handlerType = ClassUtils.getUserClass(handler);
/* 164 */     final Class thrownExceptionType = thrownException.getClass();
/* 165 */     Method handlerMethod = null;
/*     */ 
/* 167 */     Map handlers = (Map)this.exceptionHandlerCache.get(handlerType);
/* 168 */     if (handlers != null) {
/* 169 */       handlerMethod = (Method)handlers.get(thrownExceptionType);
/* 170 */       if (handlerMethod != null)
/* 171 */         return handlerMethod == NO_METHOD_FOUND ? null : handlerMethod;
/*     */     }
/*     */     else
/*     */     {
/* 175 */       handlers = new ConcurrentHashMap(16);
/* 176 */       this.exceptionHandlerCache.put(handlerType, handlers);
/*     */     }
/*     */ 
/* 179 */     final Map matchedHandlers = new HashMap();
/*     */ 
/* 181 */     ReflectionUtils.doWithMethods(handlerType, new ReflectionUtils.MethodCallback()
/*     */     {
/*     */       public void doWith(Method method) {
/* 184 */         method = ClassUtils.getMostSpecificMethod(method, handlerType);
/* 185 */         List handledExceptions = AnnotationMethodHandlerExceptionResolver.this.getHandledExceptions(method);
/* 186 */         for (Class handledException : handledExceptions)
/* 187 */           if (handledException.isAssignableFrom(thrownExceptionType))
/* 188 */             if (!matchedHandlers.containsKey(handledException)) {
/* 189 */               matchedHandlers.put(handledException, method);
/*     */             }
/*     */             else {
/* 192 */               Method oldMappedMethod = (Method)matchedHandlers.get(handledException);
/* 193 */               if (!oldMappedMethod.equals(method))
/* 194 */                 throw new IllegalStateException("Ambiguous exception handler mapped for " + handledException + "]: {" + oldMappedMethod + ", " + method + "}.");
/*     */             }
/*     */       }
/*     */     });
/* 204 */     handlerMethod = getBestMatchingMethod(matchedHandlers, thrownException);
/* 205 */     handlers.put(thrownExceptionType, handlerMethod == null ? NO_METHOD_FOUND : handlerMethod);
/* 206 */     return handlerMethod;
/*     */   }
/*     */ 
/*     */   protected List<Class<? extends Throwable>> getHandledExceptions(Method method)
/*     */   {
/* 219 */     List result = new ArrayList();
/* 220 */     ExceptionHandler exceptionHandler = (ExceptionHandler)AnnotationUtils.findAnnotation(method, ExceptionHandler.class);
/* 221 */     if (exceptionHandler != null) {
/* 222 */       if (!ObjectUtils.isEmpty(exceptionHandler.value())) {
/* 223 */         result.addAll(Arrays.asList(exceptionHandler.value()));
/*     */       }
/*     */       else {
/* 226 */         for (Class param : method.getParameterTypes()) {
/* 227 */           if (Throwable.class.isAssignableFrom(param)) {
/* 228 */             result.add(param);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 233 */     return result;
/*     */   }
/*     */ 
/*     */   private Method getBestMatchingMethod(Map<Class<? extends Throwable>, Method> resolverMethods, Exception thrownException)
/*     */   {
/* 243 */     if (resolverMethods.isEmpty()) {
/* 244 */       return null;
/*     */     }
/*     */ 
/* 247 */     Class closestMatch = ExceptionDepthComparator.findClosestMatch(resolverMethods
/* 247 */       .keySet(), thrownException);
/* 248 */     Method method = (Method)resolverMethods.get(closestMatch);
/* 249 */     return (method == null) || (NO_METHOD_FOUND == method) ? null : method;
/*     */   }
/*     */ 
/*     */   private Object[] resolveHandlerArguments(Method handlerMethod, Object handler, NativeWebRequest webRequest, Exception thrownException)
/*     */     throws Exception
/*     */   {
/* 258 */     Class[] paramTypes = handlerMethod.getParameterTypes();
/* 259 */     Object[] args = new Object[paramTypes.length];
/* 260 */     Class handlerType = handler.getClass();
/* 261 */     for (int i = 0; i < args.length; i++) {
/* 262 */       MethodParameter methodParam = new MethodParameter(handlerMethod, i);
/* 263 */       GenericTypeResolver.resolveParameterType(methodParam, handlerType);
/* 264 */       Class paramType = methodParam.getParameterType();
/* 265 */       Object argValue = resolveCommonArgument(methodParam, webRequest, thrownException);
/* 266 */       if (argValue != WebArgumentResolver.UNRESOLVED) {
/* 267 */         args[i] = argValue;
/*     */       }
/*     */       else {
/* 270 */         throw new IllegalStateException(new StringBuilder().append("Unsupported argument [").append(paramType.getName()).append("] for @ExceptionHandler method: ").append(handlerMethod).toString());
/*     */       }
/*     */     }
/*     */ 
/* 274 */     return args;
/*     */   }
/*     */ 
/*     */   protected Object resolveCommonArgument(MethodParameter methodParameter, NativeWebRequest webRequest, Exception thrownException)
/*     */     throws Exception
/*     */   {
/* 289 */     if (this.customArgumentResolvers != null) {
/* 290 */       for (WebArgumentResolver argumentResolver : this.customArgumentResolvers) {
/* 291 */         Object value = argumentResolver.resolveArgument(methodParameter, webRequest);
/* 292 */         if (value != WebArgumentResolver.UNRESOLVED) {
/* 293 */           return value;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 299 */     Class paramType = methodParameter.getParameterType();
/* 300 */     Object value = resolveStandardArgument(paramType, webRequest, thrownException);
/* 301 */     if ((value != WebArgumentResolver.UNRESOLVED) && (!ClassUtils.isAssignableValue(paramType, value)))
/*     */     {
/* 304 */       throw new IllegalStateException(new StringBuilder().append("Standard argument type [")
/* 303 */         .append(paramType
/* 303 */         .getName()).append("] resolved to incompatible value of type [")
/* 304 */         .append(value != null ? value
/* 304 */         .getClass() : null).append("]. Consider declaring the argument type in a less specific fashion.").toString());
/*     */     }
/*     */ 
/* 307 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object resolveStandardArgument(Class<?> parameterType, NativeWebRequest webRequest, Exception thrownException)
/*     */     throws Exception
/*     */   {
/* 323 */     if (parameterType.isInstance(thrownException)) {
/* 324 */       return thrownException;
/*     */     }
/* 326 */     if (WebRequest.class.isAssignableFrom(parameterType)) {
/* 327 */       return webRequest;
/*     */     }
/*     */ 
/* 330 */     HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 331 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/*     */ 
/* 333 */     if (ServletRequest.class.isAssignableFrom(parameterType)) {
/* 334 */       return request;
/*     */     }
/* 336 */     if (ServletResponse.class.isAssignableFrom(parameterType)) {
/* 337 */       return response;
/*     */     }
/* 339 */     if (HttpSession.class.isAssignableFrom(parameterType)) {
/* 340 */       return request.getSession();
/*     */     }
/* 342 */     if (Principal.class.isAssignableFrom(parameterType)) {
/* 343 */       return request.getUserPrincipal();
/*     */     }
/* 345 */     if (Locale.class.equals(parameterType)) {
/* 346 */       return RequestContextUtils.getLocale(request);
/*     */     }
/* 348 */     if (InputStream.class.isAssignableFrom(parameterType)) {
/* 349 */       return request.getInputStream();
/*     */     }
/* 351 */     if (Reader.class.isAssignableFrom(parameterType)) {
/* 352 */       return request.getReader();
/*     */     }
/* 354 */     if (OutputStream.class.isAssignableFrom(parameterType)) {
/* 355 */       return response.getOutputStream();
/*     */     }
/* 357 */     if (Writer.class.isAssignableFrom(parameterType)) {
/* 358 */       return response.getWriter();
/*     */     }
/*     */ 
/* 361 */     return WebArgumentResolver.UNRESOLVED;
/*     */   }
/*     */ 
/*     */   private Object doInvokeMethod(Method method, Object target, Object[] args)
/*     */     throws Exception
/*     */   {
/* 367 */     ReflectionUtils.makeAccessible(method);
/*     */     try {
/* 369 */       return method.invoke(target, args);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 372 */       ReflectionUtils.rethrowException(ex.getTargetException());
/*     */     }
/* 374 */     throw new IllegalStateException("Should never get here");
/*     */   }
/*     */ 
/*     */   private ModelAndView getModelAndView(Method handlerMethod, Object returnValue, ServletWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 381 */     ResponseStatus responseStatusAnn = (ResponseStatus)AnnotationUtils.findAnnotation(handlerMethod, ResponseStatus.class);
/* 382 */     if (responseStatusAnn != null) {
/* 383 */       HttpStatus responseStatus = responseStatusAnn.value();
/* 384 */       String reason = responseStatusAnn.reason();
/* 385 */       if (!StringUtils.hasText(reason)) {
/* 386 */         webRequest.getResponse().setStatus(responseStatus.value());
/*     */       }
/*     */       else {
/* 389 */         webRequest.getResponse().sendError(responseStatus.value(), reason);
/*     */       }
/*     */     }
/*     */ 
/* 393 */     if ((returnValue != null) && (AnnotationUtils.findAnnotation(handlerMethod, ResponseBody.class) != null)) {
/* 394 */       return handleResponseBody(returnValue, webRequest);
/*     */     }
/*     */ 
/* 397 */     if ((returnValue instanceof ModelAndView)) {
/* 398 */       return (ModelAndView)returnValue;
/*     */     }
/* 400 */     if ((returnValue instanceof Model)) {
/* 401 */       return new ModelAndView().addAllObjects(((Model)returnValue).asMap());
/*     */     }
/* 403 */     if ((returnValue instanceof Map)) {
/* 404 */       return new ModelAndView().addAllObjects((Map)returnValue);
/*     */     }
/* 406 */     if ((returnValue instanceof View)) {
/* 407 */       return new ModelAndView((View)returnValue);
/*     */     }
/* 409 */     if ((returnValue instanceof String)) {
/* 410 */       return new ModelAndView((String)returnValue);
/*     */     }
/* 412 */     if (returnValue == null) {
/* 413 */       return new ModelAndView();
/*     */     }
/*     */ 
/* 416 */     throw new IllegalArgumentException(new StringBuilder().append("Invalid handler method return value: ").append(returnValue).toString());
/*     */   }
/*     */ 
/*     */   private ModelAndView handleResponseBody(Object returnValue, ServletWebRequest webRequest)
/*     */     throws ServletException, IOException
/*     */   {
/* 424 */     HttpInputMessage inputMessage = new ServletServerHttpRequest(webRequest.getRequest());
/* 425 */     List acceptedMediaTypes = inputMessage.getHeaders().getAccept();
/* 426 */     if (acceptedMediaTypes.isEmpty()) {
/* 427 */       acceptedMediaTypes = Collections.singletonList(MediaType.ALL);
/*     */     }
/* 429 */     MediaType.sortByQualityValue(acceptedMediaTypes);
/* 430 */     HttpOutputMessage outputMessage = new ServletServerHttpResponse(webRequest.getResponse());
/* 431 */     Class returnValueType = returnValue.getClass();
/* 432 */     if (this.messageConverters != null) {
/* 433 */       for (MediaType acceptedMediaType : acceptedMediaTypes) {
/* 434 */         for (HttpMessageConverter messageConverter : this.messageConverters) {
/* 435 */           if (messageConverter.canWrite(returnValueType, acceptedMediaType)) {
/* 436 */             messageConverter.write(returnValue, acceptedMediaType, outputMessage);
/* 437 */             return new ModelAndView();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 442 */     if (this.logger.isWarnEnabled()) {
/* 443 */       this.logger.warn(new StringBuilder().append("Could not find HttpMessageConverter that supports return type [").append(returnValueType).append("] and ").append(acceptedMediaTypes).toString());
/*     */     }
/*     */ 
/* 446 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.annotation.AnnotationMethodHandlerExceptionResolver
 * JD-Core Version:    0.6.2
 */