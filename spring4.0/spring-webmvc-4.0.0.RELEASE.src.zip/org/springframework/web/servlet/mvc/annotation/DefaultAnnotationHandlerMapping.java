/*     */ package org.springframework.web.servlet.mvc.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.bind.UnsatisfiedServletRequestParameterException;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.servlet.handler.AbstractDetectingUrlHandlerMapping;
/*     */ 
/*     */ @Deprecated
/*     */ public class DefaultAnnotationHandlerMapping extends AbstractDetectingUrlHandlerMapping
/*     */ {
/*  89 */   static final String USE_DEFAULT_SUFFIX_PATTERN = DefaultAnnotationHandlerMapping.class.getName() + ".useDefaultSuffixPattern";
/*     */ 
/*  91 */   private boolean useDefaultSuffixPattern = true;
/*     */ 
/*  93 */   private final Map<Class<?>, RequestMapping> cachedMappings = new HashMap();
/*     */ 
/*     */   public void setUseDefaultSuffixPattern(boolean useDefaultSuffixPattern)
/*     */   {
/* 105 */     this.useDefaultSuffixPattern = useDefaultSuffixPattern;
/*     */   }
/*     */ 
/*     */   protected String[] determineUrlsForHandler(String beanName)
/*     */   {
/* 115 */     ApplicationContext context = getApplicationContext();
/* 116 */     Class handlerType = context.getType(beanName);
/* 117 */     RequestMapping mapping = (RequestMapping)context.findAnnotationOnBean(beanName, RequestMapping.class);
/* 118 */     if (mapping != null)
/*     */     {
/* 120 */       this.cachedMappings.put(handlerType, mapping);
/* 121 */       Set urls = new LinkedHashSet();
/* 122 */       String[] typeLevelPatterns = mapping.value();
/* 123 */       if (typeLevelPatterns.length > 0)
/*     */       {
/* 125 */         String[] methodLevelPatterns = determineUrlsForHandlerMethods(handlerType, true);
/* 126 */         for (String typeLevelPattern : typeLevelPatterns) {
/* 127 */           if (!typeLevelPattern.startsWith("/")) {
/* 128 */             typeLevelPattern = "/" + typeLevelPattern;
/*     */           }
/* 130 */           boolean hasEmptyMethodLevelMappings = false;
/* 131 */           for (String methodLevelPattern : methodLevelPatterns) {
/* 132 */             if (methodLevelPattern == null) {
/* 133 */               hasEmptyMethodLevelMappings = true;
/*     */             }
/*     */             else {
/* 136 */               String combinedPattern = getPathMatcher().combine(typeLevelPattern, methodLevelPattern);
/* 137 */               addUrlsForPath(urls, combinedPattern);
/*     */             }
/*     */           }
/* 140 */           if ((hasEmptyMethodLevelMappings) || 
/* 141 */             (org.springframework.web.servlet.mvc.Controller.class
/* 141 */             .isAssignableFrom(handlerType)))
/*     */           {
/* 142 */             addUrlsForPath(urls, typeLevelPattern);
/*     */           }
/*     */         }
/* 145 */         return StringUtils.toStringArray(urls);
/*     */       }
/*     */ 
/* 149 */       return determineUrlsForHandlerMethods(handlerType, false);
/*     */     }
/*     */ 
/* 152 */     if (AnnotationUtils.findAnnotation(handlerType, org.springframework.stereotype.Controller.class) != null)
/*     */     {
/* 154 */       return determineUrlsForHandlerMethods(handlerType, false);
/*     */     }
/*     */ 
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   protected String[] determineUrlsForHandlerMethods(Class<?> handlerType, final boolean hasTypeLevelMapping)
/*     */   {
/* 169 */     String[] subclassResult = determineUrlsForHandlerMethods(handlerType);
/* 170 */     if (subclassResult != null) {
/* 171 */       return subclassResult;
/*     */     }
/*     */ 
/* 174 */     final Set urls = new LinkedHashSet();
/* 175 */     Set handlerTypes = new LinkedHashSet();
/* 176 */     handlerTypes.add(handlerType);
/* 177 */     handlerTypes.addAll(Arrays.asList(handlerType.getInterfaces()));
/* 178 */     for (Class currentHandlerType : handlerTypes) {
/* 179 */       ReflectionUtils.doWithMethods(currentHandlerType, new ReflectionUtils.MethodCallback()
/*     */       {
/*     */         public void doWith(Method method) {
/* 182 */           RequestMapping mapping = (RequestMapping)AnnotationUtils.findAnnotation(method, RequestMapping.class);
/* 183 */           if (mapping != null) {
/* 184 */             String[] mappedPatterns = mapping.value();
/* 185 */             if (mappedPatterns.length > 0) {
/* 186 */               for (String mappedPattern : mappedPatterns) {
/* 187 */                 if ((!hasTypeLevelMapping) && (!mappedPattern.startsWith("/"))) {
/* 188 */                   mappedPattern = "/" + mappedPattern;
/*     */                 }
/* 190 */                 DefaultAnnotationHandlerMapping.this.addUrlsForPath(urls, mappedPattern);
/*     */               }
/*     */             }
/* 193 */             else if (hasTypeLevelMapping)
/*     */             {
/* 195 */               urls.add(null);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       , ReflectionUtils.USER_DECLARED_METHODS);
/*     */     }
/*     */ 
/* 201 */     return StringUtils.toStringArray(urls);
/*     */   }
/*     */ 
/*     */   protected String[] determineUrlsForHandlerMethods(Class<?> handlerType)
/*     */   {
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */   protected void addUrlsForPath(Set<String> urls, String path)
/*     */   {
/* 219 */     urls.add(path);
/* 220 */     if ((this.useDefaultSuffixPattern) && (path.indexOf(46) == -1) && (!path.endsWith("/"))) {
/* 221 */       urls.add(path + ".*");
/* 222 */       urls.add(path + "/");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void validateHandler(Object handler, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 233 */     RequestMapping mapping = (RequestMapping)this.cachedMappings.get(handler.getClass());
/* 234 */     if (mapping == null) {
/* 235 */       mapping = (RequestMapping)AnnotationUtils.findAnnotation(handler.getClass(), RequestMapping.class);
/*     */     }
/* 237 */     if (mapping != null) {
/* 238 */       validateMapping(mapping, request);
/*     */     }
/* 240 */     request.setAttribute(USE_DEFAULT_SUFFIX_PATTERN, Boolean.valueOf(this.useDefaultSuffixPattern));
/*     */   }
/*     */ 
/*     */   protected void validateMapping(RequestMapping mapping, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 251 */     RequestMethod[] mappedMethods = mapping.method();
/* 252 */     if (!ServletAnnotationMappingUtils.checkRequestMethod(mappedMethods, request)) {
/* 253 */       String[] supportedMethods = new String[mappedMethods.length];
/* 254 */       for (int i = 0; i < mappedMethods.length; i++) {
/* 255 */         supportedMethods[i] = mappedMethods[i].name();
/*     */       }
/* 257 */       throw new HttpRequestMethodNotSupportedException(request.getMethod(), supportedMethods);
/*     */     }
/*     */ 
/* 260 */     String[] mappedParams = mapping.params();
/* 261 */     if (!ServletAnnotationMappingUtils.checkParameters(mappedParams, request)) {
/* 262 */       throw new UnsatisfiedServletRequestParameterException(mappedParams, request.getParameterMap());
/*     */     }
/*     */ 
/* 265 */     String[] mappedHeaders = mapping.headers();
/* 266 */     if (!ServletAnnotationMappingUtils.checkHeaders(mappedHeaders, request))
/*     */     {
/* 268 */       throw new ServletRequestBindingException("Header conditions \"" + 
/* 268 */         StringUtils.arrayToDelimitedString(mappedHeaders, ", ") + 
/* 268 */         "\" not met for actual request");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean supportsTypeLevelMappings()
/*     */   {
/* 275 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.annotation.DefaultAnnotationHandlerMapping
 * JD-Core Version:    0.6.2
 */