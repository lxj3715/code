/*    */ package org.springframework.web.servlet.mvc.annotation;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.ui.ExtendedModelMap;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ 
/*    */ public abstract interface ModelAndViewResolver
/*    */ {
/* 54 */   public static final ModelAndView UNRESOLVED = new ModelAndView();
/*    */ 
/*    */   public abstract ModelAndView resolveModelAndView(Method paramMethod, Class<?> paramClass, Object paramObject, ExtendedModelMap paramExtendedModelMap, NativeWebRequest paramNativeWebRequest);
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver
 * JD-Core Version:    0.6.2
 */