/*    */ package org.springframework.web.servlet.mvc.annotation;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.i18n.LocaleContextHolder;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.bind.annotation.ResponseStatus;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;
/*    */ 
/*    */ public class ResponseStatusExceptionResolver extends AbstractHandlerExceptionResolver
/*    */   implements MessageSourceAware
/*    */ {
/*    */   private MessageSource messageSource;
/*    */ 
/*    */   public void setMessageSource(MessageSource messageSource)
/*    */   {
/* 48 */     this.messageSource = messageSource;
/*    */   }
/*    */ 
/*    */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*    */   {
/* 55 */     ResponseStatus responseStatus = (ResponseStatus)AnnotationUtils.findAnnotation(ex.getClass(), ResponseStatus.class);
/* 56 */     if (responseStatus != null) {
/*    */       try {
/* 58 */         return resolveResponseStatus(responseStatus, request, response, handler, ex);
/*    */       }
/*    */       catch (Exception resolveEx) {
/* 61 */         this.logger.warn("Handling of @ResponseStatus resulted in Exception", resolveEx);
/*    */       }
/*    */     }
/* 64 */     return null;
/*    */   }
/*    */ 
/*    */   protected ModelAndView resolveResponseStatus(ResponseStatus responseStatus, HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*    */     throws Exception
/*    */   {
/* 82 */     int statusCode = responseStatus.value().value();
/* 83 */     String reason = responseStatus.reason();
/* 84 */     if (this.messageSource != null) {
/* 85 */       reason = this.messageSource.getMessage(reason, null, reason, LocaleContextHolder.getLocale());
/*    */     }
/* 87 */     if (!StringUtils.hasLength(reason)) {
/* 88 */       response.sendError(statusCode);
/*    */     }
/*    */     else {
/* 91 */       response.sendError(statusCode, reason);
/*    */     }
/* 93 */     return new ModelAndView();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver
 * JD-Core Version:    0.6.2
 */