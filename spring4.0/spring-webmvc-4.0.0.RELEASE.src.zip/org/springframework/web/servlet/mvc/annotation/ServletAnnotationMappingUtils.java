/*     */ package org.springframework.web.servlet.mvc.annotation;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ @Deprecated
/*     */ abstract class ServletAnnotationMappingUtils
/*     */ {
/*     */   public static boolean checkRequestMethod(RequestMethod[] methods, HttpServletRequest request)
/*     */   {
/*  47 */     if (ObjectUtils.isEmpty(methods)) {
/*  48 */       return true;
/*     */     }
/*  50 */     for (RequestMethod method : methods) {
/*  51 */       if (method.name().equals(request.getMethod())) {
/*  52 */         return true;
/*     */       }
/*     */     }
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean checkParameters(String[] params, HttpServletRequest request)
/*     */   {
/*  65 */     if (!ObjectUtils.isEmpty(params)) {
/*  66 */       for (String param : params) {
/*  67 */         int separator = param.indexOf('=');
/*  68 */         if (separator == -1) {
/*  69 */           if (param.startsWith("!")) {
/*  70 */             if (WebUtils.hasSubmitParameter(request, param.substring(1))) {
/*  71 */               return false;
/*     */             }
/*     */           }
/*  74 */           else if (!WebUtils.hasSubmitParameter(request, param))
/*  75 */             return false;
/*     */         }
/*     */         else
/*     */         {
/*  79 */           boolean negated = (separator > 0) && (param.charAt(separator - 1) == '!');
/*  80 */           String key = !negated ? param.substring(0, separator) : param.substring(0, separator - 1);
/*  81 */           String value = param.substring(separator + 1);
/*  82 */           boolean match = value.equals(request.getParameter(key));
/*  83 */           if (negated) {
/*  84 */             match = !match;
/*     */           }
/*  86 */           if (!match) {
/*  87 */             return false;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  92 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean checkHeaders(String[] headers, HttpServletRequest request)
/*     */   {
/* 102 */     if (!ObjectUtils.isEmpty(headers)) {
/* 103 */       for (String header : headers) {
/* 104 */         int separator = header.indexOf('=');
/* 105 */         if (separator == -1) {
/* 106 */           if (header.startsWith("!")) {
/* 107 */             if (request.getHeader(header.substring(1)) != null) {
/* 108 */               return false;
/*     */             }
/*     */           }
/* 111 */           else if (request.getHeader(header) == null)
/* 112 */             return false;
/*     */         }
/*     */         else
/*     */         {
/* 116 */           boolean negated = (separator > 0) && (header.charAt(separator - 1) == '!');
/* 117 */           String key = !negated ? header.substring(0, separator) : header.substring(0, separator - 1);
/* 118 */           String value = header.substring(separator + 1);
/* 119 */           if (isMediaTypeHeader(key)) {
/* 120 */             List requestMediaTypes = MediaType.parseMediaTypes(request.getHeader(key));
/* 121 */             List valueMediaTypes = MediaType.parseMediaTypes(value);
/* 122 */             boolean found = false;
/* 123 */             for (Iterator valIter = valueMediaTypes.iterator(); (valIter.hasNext()) && (!found); ) {
/* 124 */               MediaType valueMediaType = (MediaType)valIter.next();
/* 125 */               Iterator reqIter = requestMediaTypes.iterator();
/* 126 */               while ((reqIter.hasNext()) && (!found)) {
/* 127 */                 MediaType requestMediaType = (MediaType)reqIter.next();
/* 128 */                 if (valueMediaType.includes(requestMediaType)) {
/* 129 */                   found = true;
/*     */                 }
/*     */               }
/*     */             }
/*     */ 
/* 134 */             if (negated) {
/* 135 */               found = !found;
/*     */             }
/* 137 */             if (!found)
/* 138 */               return false;
/*     */           }
/*     */           else
/*     */           {
/* 142 */             boolean match = value.equals(request.getHeader(key));
/* 143 */             if (negated) {
/* 144 */               match = !match;
/*     */             }
/* 146 */             if (!match) {
/* 147 */               return false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 153 */     return true;
/*     */   }
/*     */ 
/*     */   private static boolean isMediaTypeHeader(String headerName) {
/* 157 */     return ("Accept".equalsIgnoreCase(headerName)) || ("Content-Type".equalsIgnoreCase(headerName));
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.annotation.ServletAnnotationMappingUtils
 * JD-Core Version:    0.6.2
 */