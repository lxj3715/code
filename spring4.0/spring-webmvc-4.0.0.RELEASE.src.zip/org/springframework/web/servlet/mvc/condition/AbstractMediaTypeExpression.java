/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.HttpMediaTypeException;
/*     */ 
/*     */ abstract class AbstractMediaTypeExpression
/*     */   implements Comparable<AbstractMediaTypeExpression>, MediaTypeExpression
/*     */ {
/*  37 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final MediaType mediaType;
/*     */   private final boolean isNegated;
/*     */ 
/*     */   AbstractMediaTypeExpression(String expression)
/*     */   {
/*  44 */     if (expression.startsWith("!")) {
/*  45 */       this.isNegated = true;
/*  46 */       expression = expression.substring(1);
/*     */     }
/*     */     else {
/*  49 */       this.isNegated = false;
/*     */     }
/*  51 */     this.mediaType = MediaType.parseMediaType(expression);
/*     */   }
/*     */ 
/*     */   AbstractMediaTypeExpression(MediaType mediaType, boolean negated) {
/*  55 */     this.mediaType = mediaType;
/*  56 */     this.isNegated = negated;
/*     */   }
/*     */ 
/*     */   public MediaType getMediaType()
/*     */   {
/*  61 */     return this.mediaType;
/*     */   }
/*     */ 
/*     */   public boolean isNegated()
/*     */   {
/*  66 */     return this.isNegated;
/*     */   }
/*     */ 
/*     */   public final boolean match(HttpServletRequest request) {
/*     */     try {
/*  71 */       boolean match = matchMediaType(request);
/*  72 */       return !match ? true : !this.isNegated ? match : false;
/*     */     } catch (HttpMediaTypeException ex) {
/*     */     }
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */   protected abstract boolean matchMediaType(HttpServletRequest paramHttpServletRequest)
/*     */     throws HttpMediaTypeException;
/*     */ 
/*     */   public int compareTo(AbstractMediaTypeExpression other)
/*     */   {
/*  83 */     return MediaType.SPECIFICITY_COMPARATOR.compare(getMediaType(), other.getMediaType());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  88 */     if (this == obj) {
/*  89 */       return true;
/*     */     }
/*  91 */     if ((obj != null) && (getClass().equals(obj.getClass()))) {
/*  92 */       AbstractMediaTypeExpression other = (AbstractMediaTypeExpression)obj;
/*  93 */       return (this.mediaType.equals(other.mediaType)) && (this.isNegated == other.isNegated);
/*     */     }
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 100 */     return this.mediaType.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 105 */     StringBuilder builder = new StringBuilder();
/* 106 */     if (this.isNegated) {
/* 107 */       builder.append('!');
/*     */     }
/* 109 */     builder.append(this.mediaType.toString());
/* 110 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.AbstractMediaTypeExpression
 * JD-Core Version:    0.6.2
 */