/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ abstract class AbstractNameValueExpression<T>
/*     */   implements NameValueExpression<T>
/*     */ {
/*     */   protected final String name;
/*     */   protected final T value;
/*     */   protected final boolean isNegated;
/*     */ 
/*     */   AbstractNameValueExpression(String expression)
/*     */   {
/*  39 */     int separator = expression.indexOf('=');
/*  40 */     if (separator == -1) {
/*  41 */       this.isNegated = expression.startsWith("!");
/*  42 */       this.name = (this.isNegated ? expression.substring(1) : expression);
/*  43 */       this.value = null;
/*     */     }
/*     */     else {
/*  46 */       this.isNegated = ((separator > 0) && (expression.charAt(separator - 1) == '!'));
/*  47 */       this.name = (this.isNegated ? expression.substring(0, separator - 1) : expression.substring(0, separator));
/*  48 */       this.value = parseValue(expression.substring(separator + 1));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  54 */     return this.name;
/*     */   }
/*     */ 
/*     */   public T getValue()
/*     */   {
/*  59 */     return this.value;
/*     */   }
/*     */ 
/*     */   public boolean isNegated()
/*     */   {
/*  64 */     return this.isNegated;
/*     */   }
/*     */ 
/*     */   protected abstract T parseValue(String paramString);
/*     */ 
/*     */   public final boolean match(HttpServletRequest request)
/*     */   {
/*     */     boolean isMatch;
/*     */     boolean isMatch;
/*  71 */     if (this.value != null) {
/*  72 */       isMatch = matchValue(request);
/*     */     }
/*     */     else {
/*  75 */       isMatch = matchName(request);
/*     */     }
/*  77 */     return this.isNegated ? false : !isMatch ? true : isMatch;
/*     */   }
/*     */ 
/*     */   protected abstract boolean matchName(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */   protected abstract boolean matchValue(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  86 */     if (this == obj) {
/*  87 */       return true;
/*     */     }
/*  89 */     if ((obj != null) && ((obj instanceof AbstractNameValueExpression))) {
/*  90 */       AbstractNameValueExpression other = (AbstractNameValueExpression)obj;
/*     */ 
/*  92 */       return (this.name.equalsIgnoreCase(other.name)) && (this.value != null ? this.value
/*  92 */         .equals(other.value) : 
/*  92 */         other.value == null) && (this.isNegated == other.isNegated);
/*     */     }
/*     */ 
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 100 */     int result = this.name.hashCode();
/* 101 */     result = 31 * result + (this.value != null ? this.value.hashCode() : 0);
/* 102 */     result = 31 * result + (this.isNegated ? 1 : 0);
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 108 */     StringBuilder builder = new StringBuilder();
/* 109 */     if (this.value != null) {
/* 110 */       builder.append(this.name);
/* 111 */       if (this.isNegated) {
/* 112 */         builder.append('!');
/*     */       }
/* 114 */       builder.append('=');
/* 115 */       builder.append(this.value);
/*     */     }
/*     */     else {
/* 118 */       if (this.isNegated) {
/* 119 */         builder.append('!');
/*     */       }
/* 121 */       builder.append(this.name);
/*     */     }
/* 123 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.AbstractNameValueExpression
 * JD-Core Version:    0.6.2
 */