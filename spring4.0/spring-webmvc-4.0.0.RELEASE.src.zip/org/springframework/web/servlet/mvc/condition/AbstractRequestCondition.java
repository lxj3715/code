/*    */ package org.springframework.web.servlet.mvc.condition;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public abstract class AbstractRequestCondition<T extends AbstractRequestCondition<T>>
/*    */   implements RequestCondition<T>
/*    */ {
/*    */   protected abstract Collection<?> getContent();
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 40 */     if (this == o) {
/* 41 */       return true;
/*    */     }
/* 43 */     if ((o != null) && (getClass().equals(o.getClass()))) {
/* 44 */       AbstractRequestCondition other = (AbstractRequestCondition)o;
/* 45 */       return getContent().equals(other.getContent());
/*    */     }
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 52 */     return getContent().hashCode();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 57 */     StringBuilder builder = new StringBuilder("[");
/* 58 */     for (Iterator iterator = getContent().iterator(); iterator.hasNext(); ) {
/* 59 */       Object expression = iterator.next();
/* 60 */       builder.append(expression.toString());
/* 61 */       if (iterator.hasNext()) {
/* 62 */         builder.append(getToStringInfix());
/*    */       }
/*    */     }
/* 65 */     builder.append("]");
/* 66 */     return builder.toString();
/*    */   }
/*    */ 
/*    */   protected abstract String getToStringInfix();
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.AbstractRequestCondition
 * JD-Core Version:    0.6.2
 */