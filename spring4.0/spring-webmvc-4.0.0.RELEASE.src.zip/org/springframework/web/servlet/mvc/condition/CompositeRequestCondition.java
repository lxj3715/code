/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class CompositeRequestCondition extends AbstractRequestCondition<CompositeRequestCondition>
/*     */ {
/*     */   private final RequestConditionHolder[] requestConditions;
/*     */ 
/*     */   public CompositeRequestCondition(RequestCondition<?>[] requestConditions)
/*     */   {
/*  53 */     this.requestConditions = wrap(requestConditions);
/*     */   }
/*     */ 
/*     */   private RequestConditionHolder[] wrap(RequestCondition<?>[] rawConditions) {
/*  57 */     RequestConditionHolder[] wrappedConditions = new RequestConditionHolder[rawConditions.length];
/*  58 */     for (int i = 0; i < rawConditions.length; i++) {
/*  59 */       wrappedConditions[i] = new RequestConditionHolder(rawConditions[i]);
/*     */     }
/*  61 */     return wrappedConditions;
/*     */   }
/*     */ 
/*     */   private CompositeRequestCondition(RequestConditionHolder[] requestConditions) {
/*  65 */     this.requestConditions = requestConditions;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  72 */     return ObjectUtils.isEmpty(this.requestConditions);
/*     */   }
/*     */ 
/*     */   public List<RequestCondition<?>> getConditions()
/*     */   {
/*  79 */     return unwrap();
/*     */   }
/*     */ 
/*     */   private List<RequestCondition<?>> unwrap() {
/*  83 */     List result = new ArrayList();
/*  84 */     for (RequestConditionHolder holder : this.requestConditions) {
/*  85 */       result.add(holder.getCondition());
/*     */     }
/*  87 */     return result;
/*     */   }
/*     */ 
/*     */   protected Collection<?> getContent()
/*     */   {
/*  92 */     return isEmpty() ? Collections.emptyList() : getConditions();
/*     */   }
/*     */ 
/*     */   protected String getToStringInfix()
/*     */   {
/*  97 */     return " && ";
/*     */   }
/*     */ 
/*     */   private int getLength() {
/* 101 */     return this.requestConditions.length;
/*     */   }
/*     */ 
/*     */   public CompositeRequestCondition combine(CompositeRequestCondition other)
/*     */   {
/* 111 */     if ((isEmpty()) && (other.isEmpty())) {
/* 112 */       return this;
/*     */     }
/* 114 */     if (other.isEmpty()) {
/* 115 */       return this;
/*     */     }
/* 117 */     if (isEmpty()) {
/* 118 */       return other;
/*     */     }
/*     */ 
/* 121 */     assertNumberOfConditions(other);
/* 122 */     RequestConditionHolder[] combinedConditions = new RequestConditionHolder[getLength()];
/* 123 */     for (int i = 0; i < getLength(); i++) {
/* 124 */       combinedConditions[i] = this.requestConditions[i].combine(other.requestConditions[i]);
/*     */     }
/* 126 */     return new CompositeRequestCondition(combinedConditions);
/*     */   }
/*     */ 
/*     */   private void assertNumberOfConditions(CompositeRequestCondition other)
/*     */   {
/* 131 */     Assert.isTrue(getLength() == other.getLength(), "Cannot combine CompositeRequestConditions with a different number of conditions. " + this.requestConditions + " and  " + other.requestConditions);
/*     */   }
/*     */ 
/*     */   public CompositeRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 143 */     if (isEmpty()) {
/* 144 */       return this;
/*     */     }
/* 146 */     RequestConditionHolder[] matchingConditions = new RequestConditionHolder[getLength()];
/* 147 */     for (int i = 0; i < getLength(); i++) {
/* 148 */       matchingConditions[i] = this.requestConditions[i].getMatchingCondition(request);
/* 149 */       if (matchingConditions[i] == null) {
/* 150 */         return null;
/*     */       }
/*     */     }
/* 153 */     return new CompositeRequestCondition(matchingConditions);
/*     */   }
/*     */ 
/*     */   public int compareTo(CompositeRequestCondition other, HttpServletRequest request)
/*     */   {
/* 162 */     if ((isEmpty()) && (other.isEmpty())) {
/* 163 */       return 0;
/*     */     }
/* 165 */     if (isEmpty()) {
/* 166 */       return 1;
/*     */     }
/* 168 */     if (other.isEmpty()) {
/* 169 */       return -1;
/*     */     }
/*     */ 
/* 172 */     assertNumberOfConditions(other);
/* 173 */     for (int i = 0; i < getLength(); i++) {
/* 174 */       int result = this.requestConditions[i].compareTo(other.requestConditions[i], request);
/* 175 */       if (result != 0) {
/* 176 */         return result;
/*     */       }
/*     */     }
/* 179 */     return 0;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.CompositeRequestCondition
 * JD-Core Version:    0.6.2
 */