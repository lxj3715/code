/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ 
/*     */ public final class ConsumesRequestCondition extends AbstractRequestCondition<ConsumesRequestCondition>
/*     */ {
/*     */   private final List<ConsumeMediaTypeExpression> expressions;
/*     */ 
/*     */   public ConsumesRequestCondition(String[] consumes)
/*     */   {
/*  59 */     this(consumes, null);
/*     */   }
/*     */ 
/*     */   public ConsumesRequestCondition(String[] consumes, String[] headers)
/*     */   {
/*  71 */     this(parseExpressions(consumes, headers));
/*     */   }
/*     */ 
/*     */   private ConsumesRequestCondition(Collection<ConsumeMediaTypeExpression> expressions)
/*     */   {
/*  78 */     this.expressions = new ArrayList(expressions);
/*  79 */     Collections.sort(this.expressions);
/*     */   }
/*     */ 
/*     */   private static Set<ConsumeMediaTypeExpression> parseExpressions(String[] consumes, String[] headers) {
/*  83 */     Set result = new LinkedHashSet();
/*  84 */     if (headers != null)
/*     */     {
/*     */       HeadersRequestCondition.HeaderExpression expr;
/*  85 */       for (String header : headers) {
/*  86 */         expr = new HeadersRequestCondition.HeaderExpression(header);
/*  87 */         if ("Content-Type".equalsIgnoreCase(expr.name)) {
/*  88 */           for (MediaType mediaType : MediaType.parseMediaTypes((String)expr.value)) {
/*  89 */             result.add(new ConsumeMediaTypeExpression(mediaType, expr.isNegated));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  94 */     if (consumes != null) {
/*  95 */       for (String consume : consumes) {
/*  96 */         result.add(new ConsumeMediaTypeExpression(consume));
/*     */       }
/*     */     }
/*  99 */     return result;
/*     */   }
/*     */ 
/*     */   public Set<MediaTypeExpression> getExpressions()
/*     */   {
/* 106 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */ 
/*     */   public Set<MediaType> getConsumableMediaTypes()
/*     */   {
/* 113 */     Set result = new LinkedHashSet();
/* 114 */     for (ConsumeMediaTypeExpression expression : this.expressions) {
/* 115 */       if (!expression.isNegated()) {
/* 116 */         result.add(expression.getMediaType());
/*     */       }
/*     */     }
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 126 */     return this.expressions.isEmpty();
/*     */   }
/*     */ 
/*     */   protected Collection<ConsumeMediaTypeExpression> getContent()
/*     */   {
/* 131 */     return this.expressions;
/*     */   }
/*     */ 
/*     */   protected String getToStringInfix()
/*     */   {
/* 136 */     return " || ";
/*     */   }
/*     */ 
/*     */   public ConsumesRequestCondition combine(ConsumesRequestCondition other)
/*     */   {
/* 146 */     return !other.expressions.isEmpty() ? other : this;
/*     */   }
/*     */ 
/*     */   public ConsumesRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 163 */     if (isEmpty()) {
/* 164 */       return this;
/*     */     }
/* 166 */     Set result = new LinkedHashSet(this.expressions);
/* 167 */     for (Iterator iterator = result.iterator(); iterator.hasNext(); ) {
/* 168 */       ConsumeMediaTypeExpression expression = (ConsumeMediaTypeExpression)iterator.next();
/* 169 */       if (!expression.match(request)) {
/* 170 */         iterator.remove();
/*     */       }
/*     */     }
/* 173 */     return result.isEmpty() ? null : new ConsumesRequestCondition(result);
/*     */   }
/*     */ 
/*     */   public int compareTo(ConsumesRequestCondition other, HttpServletRequest request)
/*     */   {
/* 190 */     if ((this.expressions.isEmpty()) && (other.expressions.isEmpty())) {
/* 191 */       return 0;
/*     */     }
/* 193 */     if (this.expressions.isEmpty()) {
/* 194 */       return 1;
/*     */     }
/* 196 */     if (other.expressions.isEmpty()) {
/* 197 */       return -1;
/*     */     }
/*     */ 
/* 200 */     return ((ConsumeMediaTypeExpression)this.expressions.get(0)).compareTo((AbstractMediaTypeExpression)other.expressions.get(0));
/*     */   }
/*     */ 
/*     */   static class ConsumeMediaTypeExpression extends AbstractMediaTypeExpression
/*     */   {
/*     */     ConsumeMediaTypeExpression(String expression)
/*     */     {
/* 210 */       super();
/*     */     }
/*     */ 
/*     */     ConsumeMediaTypeExpression(MediaType mediaType, boolean negated) {
/* 214 */       super(negated);
/*     */     }
/*     */ 
/*     */     protected boolean matchMediaType(HttpServletRequest request) throws HttpMediaTypeNotSupportedException
/*     */     {
/*     */       try
/*     */       {
/* 221 */         MediaType contentType = StringUtils.hasLength(request.getContentType()) ? 
/* 221 */           MediaType.parseMediaType(request
/* 221 */           .getContentType()) : MediaType.APPLICATION_OCTET_STREAM;
/*     */ 
/* 223 */         return getMediaType().includes(contentType);
/*     */       }
/*     */       catch (InvalidMediaTypeException ex)
/*     */       {
/* 227 */         throw new HttpMediaTypeNotSupportedException("Can't parse Content-Type [" + request
/* 227 */           .getContentType() + "]: " + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition
 * JD-Core Version:    0.6.2
 */