/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public final class HeadersRequestCondition extends AbstractRequestCondition<HeadersRequestCondition>
/*     */ {
/*     */   private final Set<HeaderExpression> expressions;
/*     */ 
/*     */   public HeadersRequestCondition(String[] headers)
/*     */   {
/*  52 */     this(parseExpressions(headers));
/*     */   }
/*     */ 
/*     */   private HeadersRequestCondition(Collection<HeaderExpression> conditions) {
/*  56 */     this.expressions = Collections.unmodifiableSet(new LinkedHashSet(conditions));
/*     */   }
/*     */ 
/*     */   private static Collection<HeaderExpression> parseExpressions(String[] headers) {
/*  60 */     Set expressions = new LinkedHashSet();
/*  61 */     if (headers != null)
/*  62 */       for (String header : headers) {
/*  63 */         HeaderExpression expr = new HeaderExpression(header);
/*  64 */         if ((!"Accept".equalsIgnoreCase(expr.name)) && (!"Content-Type".equalsIgnoreCase(expr.name)))
/*     */         {
/*  67 */           expressions.add(expr);
/*     */         }
/*     */       }
/*  70 */     return expressions;
/*     */   }
/*     */ 
/*     */   public Set<NameValueExpression<String>> getExpressions()
/*     */   {
/*  77 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */ 
/*     */   protected Collection<HeaderExpression> getContent()
/*     */   {
/*  82 */     return this.expressions;
/*     */   }
/*     */ 
/*     */   protected String getToStringInfix()
/*     */   {
/*  87 */     return " && ";
/*     */   }
/*     */ 
/*     */   public HeadersRequestCondition combine(HeadersRequestCondition other)
/*     */   {
/*  96 */     Set set = new LinkedHashSet(this.expressions);
/*  97 */     set.addAll(other.expressions);
/*  98 */     return new HeadersRequestCondition(set);
/*     */   }
/*     */ 
/*     */   public HeadersRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 107 */     for (HeaderExpression expression : this.expressions) {
/* 108 */       if (!expression.match(request)) {
/* 109 */         return null;
/*     */       }
/*     */     }
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   public int compareTo(HeadersRequestCondition other, HttpServletRequest request)
/*     */   {
/* 129 */     return other.expressions.size() - this.expressions.size();
/*     */   }
/*     */ 
/*     */   static class HeaderExpression extends AbstractNameValueExpression<String>
/*     */   {
/*     */     public HeaderExpression(String expression)
/*     */     {
/* 138 */       super();
/*     */     }
/*     */ 
/*     */     protected String parseValue(String valueExpression)
/*     */     {
/* 143 */       return valueExpression;
/*     */     }
/*     */ 
/*     */     protected boolean matchName(HttpServletRequest request)
/*     */     {
/* 148 */       return request.getHeader(this.name) != null;
/*     */     }
/*     */ 
/*     */     protected boolean matchValue(HttpServletRequest request)
/*     */     {
/* 153 */       return ((String)this.value).equals(request.getHeader(this.name));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 158 */       int result = this.name.toLowerCase().hashCode();
/* 159 */       result = 31 * result + (this.value != null ? ((String)this.value).hashCode() : 0);
/* 160 */       result = 31 * result + (this.isNegated ? 1 : 0);
/* 161 */       return result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.HeadersRequestCondition
 * JD-Core Version:    0.6.2
 */