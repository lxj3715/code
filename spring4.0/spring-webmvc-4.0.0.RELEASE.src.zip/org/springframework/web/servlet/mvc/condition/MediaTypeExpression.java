package org.springframework.web.servlet.mvc.condition;

import org.springframework.http.MediaType;

public abstract interface MediaTypeExpression
{
  public abstract MediaType getMediaType();

  public abstract boolean isNegated();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.MediaTypeExpression
 * JD-Core Version:    0.6.2
 */