package org.springframework.web.servlet.mvc.condition;

public abstract interface NameValueExpression<T>
{
  public abstract String getName();

  public abstract T getValue();

  public abstract boolean isNegated();
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.NameValueExpression
 * JD-Core Version:    0.6.2
 */