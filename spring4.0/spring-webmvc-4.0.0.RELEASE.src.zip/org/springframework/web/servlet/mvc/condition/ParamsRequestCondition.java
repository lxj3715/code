/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public final class ParamsRequestCondition extends AbstractRequestCondition<ParamsRequestCondition>
/*     */ {
/*     */   private final Set<ParamExpression> expressions;
/*     */ 
/*     */   public ParamsRequestCondition(String[] params)
/*     */   {
/*  47 */     this(parseExpressions(params));
/*     */   }
/*     */ 
/*     */   private ParamsRequestCondition(Collection<ParamExpression> conditions) {
/*  51 */     this.expressions = Collections.unmodifiableSet(new LinkedHashSet(conditions));
/*     */   }
/*     */ 
/*     */   private static Collection<ParamExpression> parseExpressions(String[] params) {
/*  55 */     Set expressions = new LinkedHashSet();
/*  56 */     if (params != null) {
/*  57 */       for (String param : params) {
/*  58 */         expressions.add(new ParamExpression(param));
/*     */       }
/*     */     }
/*  61 */     return expressions;
/*     */   }
/*     */ 
/*     */   public Set<NameValueExpression<String>> getExpressions()
/*     */   {
/*  68 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */ 
/*     */   protected Collection<ParamExpression> getContent()
/*     */   {
/*  73 */     return this.expressions;
/*     */   }
/*     */ 
/*     */   protected String getToStringInfix()
/*     */   {
/*  78 */     return " && ";
/*     */   }
/*     */ 
/*     */   public ParamsRequestCondition combine(ParamsRequestCondition other)
/*     */   {
/*  87 */     Set set = new LinkedHashSet(this.expressions);
/*  88 */     set.addAll(other.expressions);
/*  89 */     return new ParamsRequestCondition(set);
/*     */   }
/*     */ 
/*     */   public ParamsRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/*  98 */     for (ParamExpression expression : this.expressions) {
/*  99 */       if (!expression.match(request)) {
/* 100 */         return null;
/*     */       }
/*     */     }
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   public int compareTo(ParamsRequestCondition other, HttpServletRequest request)
/*     */   {
/* 120 */     return other.expressions.size() - this.expressions.size();
/*     */   }
/*     */ 
/*     */   static class ParamExpression extends AbstractNameValueExpression<String>
/*     */   {
/*     */     ParamExpression(String expression)
/*     */     {
/* 129 */       super();
/*     */     }
/*     */ 
/*     */     protected String parseValue(String valueExpression)
/*     */     {
/* 134 */       return valueExpression;
/*     */     }
/*     */ 
/*     */     protected boolean matchName(HttpServletRequest request)
/*     */     {
/* 139 */       return WebUtils.hasSubmitParameter(request, this.name);
/*     */     }
/*     */ 
/*     */     protected boolean matchValue(HttpServletRequest request)
/*     */     {
/* 144 */       return ((String)this.value).equals(request.getParameter(this.name));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.ParamsRequestCondition
 * JD-Core Version:    0.6.2
 */