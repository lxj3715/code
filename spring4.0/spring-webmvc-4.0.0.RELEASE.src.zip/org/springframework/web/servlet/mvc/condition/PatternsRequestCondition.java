/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public final class PatternsRequestCondition extends AbstractRequestCondition<PatternsRequestCondition>
/*     */ {
/*     */   private final Set<String> patterns;
/*     */   private final UrlPathHelper pathHelper;
/*     */   private final PathMatcher pathMatcher;
/*     */   private final boolean useSuffixPatternMatch;
/*     */   private final boolean useTrailingSlashMatch;
/*  54 */   private final List<String> fileExtensions = new ArrayList();
/*     */ 
/*     */   public PatternsRequestCondition(String[] patterns)
/*     */   {
/*  63 */     this(asList(patterns), null, null, true, true, null);
/*     */   }
/*     */ 
/*     */   public PatternsRequestCondition(String[] patterns, UrlPathHelper urlPathHelper, PathMatcher pathMatcher, boolean useSuffixPatternMatch, boolean useTrailingSlashMatch)
/*     */   {
/*  78 */     this(asList(patterns), urlPathHelper, pathMatcher, useSuffixPatternMatch, useTrailingSlashMatch, null);
/*     */   }
/*     */ 
/*     */   public PatternsRequestCondition(String[] patterns, UrlPathHelper urlPathHelper, PathMatcher pathMatcher, boolean useSuffixPatternMatch, boolean useTrailingSlashMatch, List<String> fileExtensions)
/*     */   {
/*  95 */     this(asList(patterns), urlPathHelper, pathMatcher, useSuffixPatternMatch, useTrailingSlashMatch, fileExtensions);
/*     */   }
/*     */ 
/*     */   private PatternsRequestCondition(Collection<String> patterns, UrlPathHelper urlPathHelper, PathMatcher pathMatcher, boolean useSuffixPatternMatch, boolean useTrailingSlashMatch, List<String> fileExtensions)
/*     */   {
/* 105 */     this.patterns = Collections.unmodifiableSet(prependLeadingSlash(patterns));
/* 106 */     this.pathHelper = (urlPathHelper != null ? urlPathHelper : new UrlPathHelper());
/* 107 */     this.pathMatcher = (pathMatcher != null ? pathMatcher : new AntPathMatcher());
/* 108 */     this.useSuffixPatternMatch = useSuffixPatternMatch;
/* 109 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/* 110 */     if (fileExtensions != null)
/* 111 */       for (String fileExtension : fileExtensions) {
/* 112 */         if (fileExtension.charAt(0) != '.') {
/* 113 */           fileExtension = "." + fileExtension;
/*     */         }
/* 115 */         this.fileExtensions.add(fileExtension);
/*     */       }
/*     */   }
/*     */ 
/*     */   private static List<String> asList(String[] patterns)
/*     */   {
/* 122 */     return patterns != null ? Arrays.asList(patterns) : Collections.emptyList();
/*     */   }
/*     */ 
/*     */   private static Set<String> prependLeadingSlash(Collection<String> patterns) {
/* 126 */     if (patterns == null) {
/* 127 */       return Collections.emptySet();
/*     */     }
/* 129 */     Set result = new LinkedHashSet(patterns.size());
/* 130 */     for (String pattern : patterns) {
/* 131 */       if ((StringUtils.hasLength(pattern)) && (!pattern.startsWith("/"))) {
/* 132 */         pattern = "/" + pattern;
/*     */       }
/* 134 */       result.add(pattern);
/*     */     }
/* 136 */     return result;
/*     */   }
/*     */ 
/*     */   public Set<String> getPatterns() {
/* 140 */     return this.patterns;
/*     */   }
/*     */ 
/*     */   protected Collection<String> getContent()
/*     */   {
/* 145 */     return this.patterns;
/*     */   }
/*     */ 
/*     */   protected String getToStringInfix()
/*     */   {
/* 150 */     return " || ";
/*     */   }
/*     */ 
/*     */   public PatternsRequestCondition combine(PatternsRequestCondition other)
/*     */   {
/* 165 */     Set result = new LinkedHashSet();
/*     */     Iterator localIterator1;
/*     */     String pattern1;
/* 166 */     if ((!this.patterns.isEmpty()) && (!other.patterns.isEmpty())) {
/* 167 */       for (localIterator1 = this.patterns.iterator(); localIterator1.hasNext(); ) { pattern1 = (String)localIterator1.next();
/* 168 */         for (String pattern2 : other.patterns) {
/* 169 */           result.add(this.pathMatcher.combine(pattern1, pattern2));
/*     */         }
/*     */       }
/*     */     }
/* 173 */     else if (!this.patterns.isEmpty()) {
/* 174 */       result.addAll(this.patterns);
/*     */     }
/* 176 */     else if (!other.patterns.isEmpty()) {
/* 177 */       result.addAll(other.patterns);
/*     */     }
/*     */     else {
/* 180 */       result.add("");
/*     */     }
/* 182 */     return new PatternsRequestCondition(result, this.pathHelper, this.pathMatcher, this.useSuffixPatternMatch, this.useTrailingSlashMatch, this.fileExtensions);
/*     */   }
/*     */ 
/*     */   public PatternsRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 204 */     if (this.patterns.isEmpty()) {
/* 205 */       return this;
/*     */     }
/*     */ 
/* 208 */     String lookupPath = this.pathHelper.getLookupPathForRequest(request);
/* 209 */     List matches = new ArrayList();
/* 210 */     for (String pattern : this.patterns) {
/* 211 */       String match = getMatchingPattern(pattern, lookupPath);
/* 212 */       if (match != null) {
/* 213 */         matches.add(match);
/*     */       }
/*     */     }
/* 216 */     Collections.sort(matches, this.pathMatcher.getPatternComparator(lookupPath));
/* 217 */     return matches.isEmpty() ? null : new PatternsRequestCondition(matches, this.pathHelper, this.pathMatcher, this.useSuffixPatternMatch, this.useTrailingSlashMatch, this.fileExtensions);
/*     */   }
/*     */ 
/*     */   private String getMatchingPattern(String pattern, String lookupPath)
/*     */   {
/* 223 */     if (pattern.equals(lookupPath)) {
/* 224 */       return pattern;
/*     */     }
/* 226 */     if (this.useSuffixPatternMatch) {
/* 227 */       if ((!this.fileExtensions.isEmpty()) && (lookupPath.indexOf(46) != -1)) {
/* 228 */         for (String extension : this.fileExtensions) {
/* 229 */           if (this.pathMatcher.match(pattern + extension, lookupPath))
/* 230 */             return pattern + extension;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 235 */         boolean hasSuffix = pattern.indexOf(46) != -1;
/* 236 */         if ((!hasSuffix) && (this.pathMatcher.match(pattern + ".*", lookupPath))) {
/* 237 */           return pattern + ".*";
/*     */         }
/*     */       }
/*     */     }
/* 241 */     if (this.pathMatcher.match(pattern, lookupPath)) {
/* 242 */       return pattern;
/*     */     }
/* 244 */     if ((this.useTrailingSlashMatch) && 
/* 245 */       (!pattern.endsWith("/")) && (this.pathMatcher.match(pattern + "/", lookupPath))) {
/* 246 */       return pattern + "/";
/*     */     }
/*     */ 
/* 249 */     return null;
/*     */   }
/*     */ 
/*     */   public int compareTo(PatternsRequestCondition other, HttpServletRequest request)
/*     */   {
/* 265 */     String lookupPath = this.pathHelper.getLookupPathForRequest(request);
/* 266 */     Comparator patternComparator = this.pathMatcher.getPatternComparator(lookupPath);
/*     */ 
/* 268 */     Iterator iterator = this.patterns.iterator();
/* 269 */     Iterator iteratorOther = other.patterns.iterator();
/* 270 */     while ((iterator.hasNext()) && (iteratorOther.hasNext())) {
/* 271 */       int result = patternComparator.compare(iterator.next(), iteratorOther.next());
/* 272 */       if (result != 0) {
/* 273 */         return result;
/*     */       }
/*     */     }
/* 276 */     if (iterator.hasNext()) {
/* 277 */       return -1;
/*     */     }
/* 279 */     if (iteratorOther.hasNext()) {
/* 280 */       return 1;
/*     */     }
/*     */ 
/* 283 */     return 0;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.PatternsRequestCondition
 * JD-Core Version:    0.6.2
 */