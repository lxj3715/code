/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ 
/*     */ public final class ProducesRequestCondition extends AbstractRequestCondition<ProducesRequestCondition>
/*     */ {
/*     */   private final List<ProduceMediaTypeExpression> expressions;
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/* 290 */   private final List<ProduceMediaTypeExpression> MEDIA_TYPE_ALL_LIST = Collections.singletonList(new ProduceMediaTypeExpression("*/*"))
/* 290 */     ;
/*     */ 
/*     */   public ProducesRequestCondition(String[] produces)
/*     */   {
/*  59 */     this(produces, (String[])null);
/*     */   }
/*     */ 
/*     */   public ProducesRequestCondition(String[] produces, String[] headers)
/*     */   {
/*  71 */     this(produces, headers, null);
/*     */   }
/*     */ 
/*     */   public ProducesRequestCondition(String[] produces, String[] headers, ContentNegotiationManager manager)
/*     */   {
/*  84 */     this.expressions = new ArrayList(parseExpressions(produces, headers));
/*  85 */     Collections.sort(this.expressions);
/*  86 */     this.contentNegotiationManager = (manager != null ? manager : new ContentNegotiationManager());
/*     */   }
/*     */ 
/*     */   private Set<ProduceMediaTypeExpression> parseExpressions(String[] produces, String[] headers) {
/*  90 */     Set result = new LinkedHashSet();
/*  91 */     if (headers != null)
/*     */     {
/*     */       HeadersRequestCondition.HeaderExpression expr;
/*  92 */       for (String header : headers) {
/*  93 */         expr = new HeadersRequestCondition.HeaderExpression(header);
/*  94 */         if ("Accept".equalsIgnoreCase(expr.name)) {
/*  95 */           for (MediaType mediaType : MediaType.parseMediaTypes((String)expr.value)) {
/*  96 */             result.add(new ProduceMediaTypeExpression(mediaType, expr.isNegated));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 101 */     if (produces != null) {
/* 102 */       for (String produce : produces) {
/* 103 */         result.add(new ProduceMediaTypeExpression(produce));
/*     */       }
/*     */     }
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */   private ProducesRequestCondition(Collection<ProduceMediaTypeExpression> expressions, ContentNegotiationManager manager)
/*     */   {
/* 115 */     this.expressions = new ArrayList(expressions);
/* 116 */     Collections.sort(this.expressions);
/* 117 */     this.contentNegotiationManager = (manager != null ? manager : new ContentNegotiationManager());
/*     */   }
/*     */ 
/*     */   public Set<MediaTypeExpression> getExpressions()
/*     */   {
/* 124 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */ 
/*     */   public Set<MediaType> getProducibleMediaTypes()
/*     */   {
/* 131 */     Set result = new LinkedHashSet();
/* 132 */     for (ProduceMediaTypeExpression expression : this.expressions) {
/* 133 */       if (!expression.isNegated()) {
/* 134 */         result.add(expression.getMediaType());
/*     */       }
/*     */     }
/* 137 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 144 */     return this.expressions.isEmpty();
/*     */   }
/*     */ 
/*     */   protected List<ProduceMediaTypeExpression> getContent()
/*     */   {
/* 149 */     return this.expressions;
/*     */   }
/*     */ 
/*     */   protected String getToStringInfix()
/*     */   {
/* 154 */     return " || ";
/*     */   }
/*     */ 
/*     */   public ProducesRequestCondition combine(ProducesRequestCondition other)
/*     */   {
/* 164 */     return !other.expressions.isEmpty() ? other : this;
/*     */   }
/*     */ 
/*     */   public ProducesRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 181 */     if (isEmpty()) {
/* 182 */       return this;
/*     */     }
/* 184 */     Set result = new LinkedHashSet(this.expressions);
/* 185 */     for (Iterator iterator = result.iterator(); iterator.hasNext(); ) {
/* 186 */       ProduceMediaTypeExpression expression = (ProduceMediaTypeExpression)iterator.next();
/* 187 */       if (!expression.match(request)) {
/* 188 */         iterator.remove();
/*     */       }
/*     */     }
/* 191 */     return result.isEmpty() ? null : new ProducesRequestCondition(result, this.contentNegotiationManager);
/*     */   }
/*     */ 
/*     */   public int compareTo(ProducesRequestCondition other, HttpServletRequest request)
/*     */   {
/*     */     try
/*     */     {
/* 216 */       List acceptedMediaTypes = getAcceptedMediaTypes(request);
/*     */ 
/* 218 */       for (MediaType acceptedMediaType : acceptedMediaTypes) {
/* 219 */         int thisIndex = indexOfEqualMediaType(acceptedMediaType);
/* 220 */         int otherIndex = other.indexOfEqualMediaType(acceptedMediaType);
/* 221 */         int result = compareMatchingMediaTypes(this, thisIndex, other, otherIndex);
/* 222 */         if (result != 0) {
/* 223 */           return result;
/*     */         }
/* 225 */         thisIndex = indexOfIncludedMediaType(acceptedMediaType);
/* 226 */         otherIndex = other.indexOfIncludedMediaType(acceptedMediaType);
/* 227 */         result = compareMatchingMediaTypes(this, thisIndex, other, otherIndex);
/* 228 */         if (result != 0) {
/* 229 */           return result;
/*     */         }
/*     */       }
/* 232 */       return 0;
/*     */     }
/*     */     catch (HttpMediaTypeNotAcceptableException e) {
/*     */     }
/* 236 */     throw new IllegalStateException("Cannot compare without having any requested media types");
/*     */   }
/*     */ 
/*     */   private List<MediaType> getAcceptedMediaTypes(HttpServletRequest request) throws HttpMediaTypeNotAcceptableException
/*     */   {
/* 241 */     List mediaTypes = this.contentNegotiationManager.resolveMediaTypes(new ServletWebRequest(request));
/* 242 */     return mediaTypes.isEmpty() ? Collections.singletonList(MediaType.ALL) : mediaTypes;
/*     */   }
/*     */ 
/*     */   private int indexOfEqualMediaType(MediaType mediaType) {
/* 246 */     for (int i = 0; i < getExpressionsToCompare().size(); i++) {
/* 247 */       MediaType currentMediaType = ((ProduceMediaTypeExpression)getExpressionsToCompare().get(i)).getMediaType();
/* 248 */       if ((mediaType.getType().equalsIgnoreCase(currentMediaType.getType())) && 
/* 249 */         (mediaType
/* 249 */         .getSubtype().equalsIgnoreCase(currentMediaType.getSubtype()))) {
/* 250 */         return i;
/*     */       }
/*     */     }
/* 253 */     return -1;
/*     */   }
/*     */ 
/*     */   private int indexOfIncludedMediaType(MediaType mediaType) {
/* 257 */     for (int i = 0; i < getExpressionsToCompare().size(); i++) {
/* 258 */       if (mediaType.includes(((ProduceMediaTypeExpression)getExpressionsToCompare().get(i)).getMediaType())) {
/* 259 */         return i;
/*     */       }
/*     */     }
/* 262 */     return -1;
/*     */   }
/*     */ 
/*     */   private int compareMatchingMediaTypes(ProducesRequestCondition condition1, int index1, ProducesRequestCondition condition2, int index2)
/*     */   {
/* 268 */     int result = 0;
/* 269 */     if (index1 != index2) {
/* 270 */       result = index2 - index1;
/*     */     }
/* 272 */     else if ((index1 != -1) && (index2 != -1)) {
/* 273 */       ProduceMediaTypeExpression expr1 = (ProduceMediaTypeExpression)condition1.getExpressionsToCompare().get(index1);
/* 274 */       ProduceMediaTypeExpression expr2 = (ProduceMediaTypeExpression)condition2.getExpressionsToCompare().get(index2);
/* 275 */       result = expr1.compareTo(expr2);
/* 276 */       result = result != 0 ? result : expr1.getMediaType().compareTo(expr2.getMediaType());
/*     */     }
/* 278 */     return result;
/*     */   }
/*     */ 
/*     */   private List<ProduceMediaTypeExpression> getExpressionsToCompare()
/*     */   {
/* 286 */     return this.expressions.isEmpty() ? this.MEDIA_TYPE_ALL_LIST : this.expressions;
/*     */   }
/*     */ 
/*     */   class ProduceMediaTypeExpression extends AbstractMediaTypeExpression
/*     */   {
/*     */     ProduceMediaTypeExpression(MediaType mediaType, boolean negated)
/*     */     {
/* 299 */       super(negated);
/*     */     }
/*     */ 
/*     */     ProduceMediaTypeExpression(String expression) {
/* 303 */       super();
/*     */     }
/*     */ 
/*     */     protected boolean matchMediaType(HttpServletRequest request) throws HttpMediaTypeNotAcceptableException
/*     */     {
/* 308 */       List acceptedMediaTypes = ProducesRequestCondition.this.getAcceptedMediaTypes(request);
/* 309 */       for (MediaType acceptedMediaType : acceptedMediaTypes) {
/* 310 */         if (getMediaType().isCompatibleWith(acceptedMediaType)) {
/* 311 */           return true;
/*     */         }
/*     */       }
/* 314 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.ProducesRequestCondition
 * JD-Core Version:    0.6.2
 */