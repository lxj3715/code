package org.springframework.web.servlet.mvc.condition;

import javax.servlet.http.HttpServletRequest;

public abstract interface RequestCondition<T>
{
  public abstract T combine(T paramT);

  public abstract T getMatchingCondition(HttpServletRequest paramHttpServletRequest);

  public abstract int compareTo(T paramT, HttpServletRequest paramHttpServletRequest);
}

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.RequestCondition
 * JD-Core Version:    0.6.2
 */