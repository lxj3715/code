/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public final class RequestConditionHolder extends AbstractRequestCondition<RequestConditionHolder>
/*     */ {
/*     */   private final RequestCondition<Object> condition;
/*     */ 
/*     */   public RequestConditionHolder(RequestCondition<?> requestCondition)
/*     */   {
/*  48 */     this.condition = requestCondition;
/*     */   }
/*     */ 
/*     */   public RequestCondition<?> getCondition()
/*     */   {
/*  55 */     return this.condition;
/*     */   }
/*     */ 
/*     */   protected Collection<?> getContent()
/*     */   {
/*  60 */     return this.condition != null ? Collections.singleton(this.condition) : Collections.emptyList();
/*     */   }
/*     */ 
/*     */   protected String getToStringInfix()
/*     */   {
/*  65 */     return " ";
/*     */   }
/*     */ 
/*     */   public RequestConditionHolder combine(RequestConditionHolder other)
/*     */   {
/*  75 */     if ((this.condition == null) && (other.condition == null)) {
/*  76 */       return this;
/*     */     }
/*  78 */     if (this.condition == null) {
/*  79 */       return other;
/*     */     }
/*  81 */     if (other.condition == null) {
/*  82 */       return this;
/*     */     }
/*     */ 
/*  85 */     assertEqualConditionTypes(other);
/*  86 */     RequestCondition combined = (RequestCondition)this.condition.combine(other.condition);
/*  87 */     return new RequestConditionHolder(combined);
/*     */   }
/*     */ 
/*     */   private void assertEqualConditionTypes(RequestConditionHolder other)
/*     */   {
/*  95 */     Class clazz = this.condition.getClass();
/*  96 */     Class otherClazz = other.condition.getClass();
/*  97 */     if (!clazz.equals(otherClazz))
/*  98 */       throw new ClassCastException("Incompatible request conditions: " + clazz + " and " + otherClazz);
/*     */   }
/*     */ 
/*     */   public RequestConditionHolder getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 109 */     if (this.condition == null) {
/* 110 */       return this;
/*     */     }
/* 112 */     RequestCondition match = (RequestCondition)this.condition.getMatchingCondition(request);
/* 113 */     return match != null ? new RequestConditionHolder(match) : null;
/*     */   }
/*     */ 
/*     */   public int compareTo(RequestConditionHolder other, HttpServletRequest request)
/*     */   {
/* 123 */     if ((this.condition == null) && (other.condition == null)) {
/* 124 */       return 0;
/*     */     }
/* 126 */     if (this.condition == null) {
/* 127 */       return 1;
/*     */     }
/* 129 */     if (other.condition == null) {
/* 130 */       return -1;
/*     */     }
/*     */ 
/* 133 */     assertEqualConditionTypes(other);
/* 134 */     return this.condition.compareTo(other.condition, request);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.RequestConditionHolder
 * JD-Core Version:    0.6.2
 */