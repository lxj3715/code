/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ 
/*     */ public final class RequestMethodsRequestCondition extends AbstractRequestCondition<RequestMethodsRequestCondition>
/*     */ {
/*     */   private final Set<RequestMethod> methods;
/*     */ 
/*     */   public RequestMethodsRequestCondition(RequestMethod[] requestMethods)
/*     */   {
/*  48 */     this(asList(requestMethods));
/*     */   }
/*     */ 
/*     */   private static List<RequestMethod> asList(RequestMethod[] requestMethods) {
/*  52 */     return requestMethods != null ? Arrays.asList(requestMethods) : Collections.emptyList();
/*     */   }
/*     */ 
/*     */   private RequestMethodsRequestCondition(Collection<RequestMethod> requestMethods)
/*     */   {
/*  59 */     this.methods = Collections.unmodifiableSet(new LinkedHashSet(requestMethods));
/*     */   }
/*     */ 
/*     */   public Set<RequestMethod> getMethods()
/*     */   {
/*  66 */     return this.methods;
/*     */   }
/*     */ 
/*     */   protected Collection<RequestMethod> getContent()
/*     */   {
/*  71 */     return this.methods;
/*     */   }
/*     */ 
/*     */   protected String getToStringInfix()
/*     */   {
/*  76 */     return " || ";
/*     */   }
/*     */ 
/*     */   public RequestMethodsRequestCondition combine(RequestMethodsRequestCondition other)
/*     */   {
/*  85 */     Set set = new LinkedHashSet(this.methods);
/*  86 */     set.addAll(other.methods);
/*  87 */     return new RequestMethodsRequestCondition(set);
/*     */   }
/*     */ 
/*     */   public RequestMethodsRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 100 */     if (this.methods.isEmpty()) {
/* 101 */       return this;
/*     */     }
/* 103 */     RequestMethod incomingRequestMethod = getRequestMethod(request);
/* 104 */     if (incomingRequestMethod != null) {
/* 105 */       for (RequestMethod method : this.methods) {
/* 106 */         if (method.equals(incomingRequestMethod)) {
/* 107 */           return new RequestMethodsRequestCondition(new RequestMethod[] { method });
/*     */         }
/*     */       }
/*     */     }
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */   private RequestMethod getRequestMethod(HttpServletRequest request) {
/*     */     try {
/* 116 */       return RequestMethod.valueOf(request.getMethod());
/*     */     } catch (IllegalArgumentException e) {
/*     */     }
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   public int compareTo(RequestMethodsRequestCondition other, HttpServletRequest request)
/*     */   {
/* 137 */     return other.methods.size() - this.methods.size();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition
 * JD-Core Version:    0.6.2
 */