/*     */ package org.springframework.web.servlet.mvc.method;
/*     */ 
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.HeadersRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.ParamsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.ProducesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestConditionHolder;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
/*     */ 
/*     */ public final class RequestMappingInfo
/*     */   implements RequestCondition<RequestMappingInfo>
/*     */ {
/*     */   private final PatternsRequestCondition patternsCondition;
/*     */   private final RequestMethodsRequestCondition methodsCondition;
/*     */   private final ParamsRequestCondition paramsCondition;
/*     */   private final HeadersRequestCondition headersCondition;
/*     */   private final ConsumesRequestCondition consumesCondition;
/*     */   private final ProducesRequestCondition producesCondition;
/*     */   private final RequestConditionHolder customConditionHolder;
/*     */   private int hash;
/*     */ 
/*     */   public RequestMappingInfo(PatternsRequestCondition patterns, RequestMethodsRequestCondition methods, ParamsRequestCondition params, HeadersRequestCondition headers, ConsumesRequestCondition consumes, ProducesRequestCondition produces, RequestCondition<?> custom)
/*     */   {
/*  74 */     this.patternsCondition = (patterns != null ? patterns : new PatternsRequestCondition(new String[0]));
/*  75 */     this.methodsCondition = (methods != null ? methods : new RequestMethodsRequestCondition(new RequestMethod[0]));
/*  76 */     this.paramsCondition = (params != null ? params : new ParamsRequestCondition(new String[0]));
/*  77 */     this.headersCondition = (headers != null ? headers : new HeadersRequestCondition(new String[0]));
/*  78 */     this.consumesCondition = (consumes != null ? consumes : new ConsumesRequestCondition(new String[0]));
/*  79 */     this.producesCondition = (produces != null ? produces : new ProducesRequestCondition(new String[0]));
/*  80 */     this.customConditionHolder = new RequestConditionHolder(custom);
/*     */   }
/*     */ 
/*     */   public RequestMappingInfo(RequestMappingInfo info, RequestCondition<?> customRequestCondition)
/*     */   {
/*  87 */     this(info.patternsCondition, info.methodsCondition, info.paramsCondition, info.headersCondition, info.consumesCondition, info.producesCondition, customRequestCondition);
/*     */   }
/*     */ 
/*     */   public PatternsRequestCondition getPatternsCondition()
/*     */   {
/*  96 */     return this.patternsCondition;
/*     */   }
/*     */ 
/*     */   public RequestMethodsRequestCondition getMethodsCondition()
/*     */   {
/* 104 */     return this.methodsCondition;
/*     */   }
/*     */ 
/*     */   public ParamsRequestCondition getParamsCondition()
/*     */   {
/* 112 */     return this.paramsCondition;
/*     */   }
/*     */ 
/*     */   public HeadersRequestCondition getHeadersCondition()
/*     */   {
/* 120 */     return this.headersCondition;
/*     */   }
/*     */ 
/*     */   public ConsumesRequestCondition getConsumesCondition()
/*     */   {
/* 128 */     return this.consumesCondition;
/*     */   }
/*     */ 
/*     */   public ProducesRequestCondition getProducesCondition()
/*     */   {
/* 136 */     return this.producesCondition;
/*     */   }
/*     */ 
/*     */   public RequestCondition<?> getCustomCondition()
/*     */   {
/* 143 */     return this.customConditionHolder.getCondition();
/*     */   }
/*     */ 
/*     */   public RequestMappingInfo combine(RequestMappingInfo other)
/*     */   {
/* 153 */     PatternsRequestCondition patterns = this.patternsCondition.combine(other.patternsCondition);
/* 154 */     RequestMethodsRequestCondition methods = this.methodsCondition.combine(other.methodsCondition);
/* 155 */     ParamsRequestCondition params = this.paramsCondition.combine(other.paramsCondition);
/* 156 */     HeadersRequestCondition headers = this.headersCondition.combine(other.headersCondition);
/* 157 */     ConsumesRequestCondition consumes = this.consumesCondition.combine(other.consumesCondition);
/* 158 */     ProducesRequestCondition produces = this.producesCondition.combine(other.producesCondition);
/* 159 */     RequestConditionHolder custom = this.customConditionHolder.combine(other.customConditionHolder);
/*     */ 
/* 161 */     return new RequestMappingInfo(patterns, methods, params, headers, consumes, produces, custom.getCondition());
/*     */   }
/*     */ 
/*     */   public RequestMappingInfo getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 173 */     RequestMethodsRequestCondition methods = this.methodsCondition.getMatchingCondition(request);
/* 174 */     ParamsRequestCondition params = this.paramsCondition.getMatchingCondition(request);
/* 175 */     HeadersRequestCondition headers = this.headersCondition.getMatchingCondition(request);
/* 176 */     ConsumesRequestCondition consumes = this.consumesCondition.getMatchingCondition(request);
/* 177 */     ProducesRequestCondition produces = this.producesCondition.getMatchingCondition(request);
/*     */ 
/* 179 */     if ((methods == null) || (params == null) || (headers == null) || (consumes == null) || (produces == null)) {
/* 180 */       return null;
/*     */     }
/*     */ 
/* 183 */     PatternsRequestCondition patterns = this.patternsCondition.getMatchingCondition(request);
/* 184 */     if (patterns == null) {
/* 185 */       return null;
/*     */     }
/*     */ 
/* 188 */     RequestConditionHolder custom = this.customConditionHolder.getMatchingCondition(request);
/* 189 */     if (custom == null) {
/* 190 */       return null;
/*     */     }
/*     */ 
/* 193 */     return new RequestMappingInfo(patterns, methods, params, headers, consumes, produces, custom.getCondition());
/*     */   }
/*     */ 
/*     */   public int compareTo(RequestMappingInfo other, HttpServletRequest request)
/*     */   {
/* 204 */     int result = this.patternsCondition.compareTo(other.getPatternsCondition(), request);
/* 205 */     if (result != 0) {
/* 206 */       return result;
/*     */     }
/* 208 */     result = this.paramsCondition.compareTo(other.getParamsCondition(), request);
/* 209 */     if (result != 0) {
/* 210 */       return result;
/*     */     }
/* 212 */     result = this.headersCondition.compareTo(other.getHeadersCondition(), request);
/* 213 */     if (result != 0) {
/* 214 */       return result;
/*     */     }
/* 216 */     result = this.consumesCondition.compareTo(other.getConsumesCondition(), request);
/* 217 */     if (result != 0) {
/* 218 */       return result;
/*     */     }
/* 220 */     result = this.producesCondition.compareTo(other.getProducesCondition(), request);
/* 221 */     if (result != 0) {
/* 222 */       return result;
/*     */     }
/* 224 */     result = this.methodsCondition.compareTo(other.getMethodsCondition(), request);
/* 225 */     if (result != 0) {
/* 226 */       return result;
/*     */     }
/* 228 */     result = this.customConditionHolder.compareTo(other.customConditionHolder, request);
/* 229 */     if (result != 0) {
/* 230 */       return result;
/*     */     }
/* 232 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 237 */     if (this == obj) {
/* 238 */       return true;
/*     */     }
/* 240 */     if ((obj != null) && ((obj instanceof RequestMappingInfo))) {
/* 241 */       RequestMappingInfo other = (RequestMappingInfo)obj;
/*     */ 
/* 248 */       return (this.patternsCondition.equals(other.patternsCondition)) && 
/* 243 */         (this.methodsCondition
/* 243 */         .equals(other.methodsCondition)) && 
/* 244 */         (this.paramsCondition
/* 244 */         .equals(other.paramsCondition)) && 
/* 245 */         (this.headersCondition
/* 245 */         .equals(other.headersCondition)) && 
/* 246 */         (this.consumesCondition
/* 246 */         .equals(other.consumesCondition)) && 
/* 247 */         (this.producesCondition
/* 247 */         .equals(other.producesCondition)) && 
/* 248 */         (this.customConditionHolder
/* 248 */         .equals(other.customConditionHolder));
/*     */     }
/*     */ 
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 255 */     int result = this.hash;
/* 256 */     if (result == 0) {
/* 257 */       result = this.patternsCondition.hashCode();
/* 258 */       result = 31 * result + this.methodsCondition.hashCode();
/* 259 */       result = 31 * result + this.paramsCondition.hashCode();
/* 260 */       result = 31 * result + this.headersCondition.hashCode();
/* 261 */       result = 31 * result + this.consumesCondition.hashCode();
/* 262 */       result = 31 * result + this.producesCondition.hashCode();
/* 263 */       result = 31 * result + this.customConditionHolder.hashCode();
/* 264 */       this.hash = result;
/*     */     }
/* 266 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 271 */     StringBuilder builder = new StringBuilder("{");
/* 272 */     builder.append(this.patternsCondition);
/* 273 */     builder.append(",methods=").append(this.methodsCondition);
/* 274 */     builder.append(",params=").append(this.paramsCondition);
/* 275 */     builder.append(",headers=").append(this.headersCondition);
/* 276 */     builder.append(",consumes=").append(this.consumesCondition);
/* 277 */     builder.append(",produces=").append(this.producesCondition);
/* 278 */     builder.append(",custom=").append(this.customConditionHolder);
/* 279 */     builder.append('}');
/* 280 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.RequestMappingInfo
 * JD-Core Version:    0.6.2
 */