/*     */ package org.springframework.web.servlet.mvc.method;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.UnsatisfiedServletRequestParameterException;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMethodMapping;
/*     */ import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.NameValueExpression;
/*     */ import org.springframework.web.servlet.mvc.condition.ParamsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.ProducesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public abstract class RequestMappingInfoHandlerMapping extends AbstractHandlerMethodMapping<RequestMappingInfo>
/*     */ {
/*     */   protected Set<String> getMappingPathPatterns(RequestMappingInfo info)
/*     */   {
/*  57 */     return info.getPatternsCondition().getPatterns();
/*     */   }
/*     */ 
/*     */   protected RequestMappingInfo getMatchingMapping(RequestMappingInfo info, HttpServletRequest request)
/*     */   {
/*  68 */     return info.getMatchingCondition(request);
/*     */   }
/*     */ 
/*     */   protected Comparator<RequestMappingInfo> getMappingComparator(final HttpServletRequest request)
/*     */   {
/*  76 */     return new Comparator()
/*     */     {
/*     */       public int compare(RequestMappingInfo info1, RequestMappingInfo info2) {
/*  79 */         return info1.compareTo(info2, request);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   protected void handleMatch(RequestMappingInfo info, String lookupPath, HttpServletRequest request)
/*     */   {
/*  92 */     super.handleMatch(info, lookupPath, request);
/*     */ 
/*  98 */     Set patterns = info.getPatternsCondition().getPatterns();
/*     */     Map decodedUriVariables;
/*     */     String bestPattern;
/*     */     Map uriVariables;
/*     */     Map decodedUriVariables;
/*  99 */     if (patterns.isEmpty()) {
/* 100 */       String bestPattern = lookupPath;
/* 101 */       Map uriVariables = Collections.emptyMap();
/* 102 */       decodedUriVariables = Collections.emptyMap();
/*     */     }
/*     */     else {
/* 105 */       bestPattern = (String)patterns.iterator().next();
/* 106 */       uriVariables = getPathMatcher().extractUriTemplateVariables(bestPattern, lookupPath);
/* 107 */       decodedUriVariables = getUrlPathHelper().decodePathVariables(request, uriVariables);
/*     */     }
/*     */ 
/* 110 */     request.setAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE, bestPattern);
/* 111 */     request.setAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, decodedUriVariables);
/*     */ 
/* 113 */     if (isMatrixVariableContentAvailable()) {
/* 114 */       Map matrixVars = extractMatrixVariables(request, uriVariables);
/* 115 */       request.setAttribute(HandlerMapping.MATRIX_VARIABLES_ATTRIBUTE, matrixVars);
/*     */     }
/*     */ 
/* 118 */     if (!info.getProducesCondition().getProducibleMediaTypes().isEmpty()) {
/* 119 */       Set mediaTypes = info.getProducesCondition().getProducibleMediaTypes();
/* 120 */       request.setAttribute(PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, mediaTypes);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isMatrixVariableContentAvailable() {
/* 125 */     return !getUrlPathHelper().shouldRemoveSemicolonContent();
/*     */   }
/*     */ 
/*     */   private Map<String, MultiValueMap<String, String>> extractMatrixVariables(HttpServletRequest request, Map<String, String> uriVariables)
/*     */   {
/* 131 */     Map result = new LinkedHashMap();
/* 132 */     for (Map.Entry uriVar : uriVariables.entrySet()) {
/* 133 */       String uriVarValue = (String)uriVar.getValue();
/*     */ 
/* 135 */       int equalsIndex = uriVarValue.indexOf(61);
/* 136 */       if (equalsIndex != -1)
/*     */       {
/* 142 */         int semicolonIndex = uriVarValue.indexOf(59);
/*     */         String matrixVariables;
/*     */         String matrixVariables;
/* 143 */         if ((semicolonIndex == -1) || (semicolonIndex == 0) || (equalsIndex < semicolonIndex)) {
/* 144 */           matrixVariables = uriVarValue;
/*     */         }
/*     */         else {
/* 147 */           matrixVariables = uriVarValue.substring(semicolonIndex + 1);
/* 148 */           uriVariables.put(uriVar.getKey(), uriVarValue.substring(0, semicolonIndex));
/*     */         }
/*     */ 
/* 151 */         MultiValueMap vars = WebUtils.parseMatrixVariables(matrixVariables);
/* 152 */         result.put(uriVar.getKey(), getUrlPathHelper().decodeMatrixVariables(request, vars));
/*     */       }
/*     */     }
/* 154 */     return result;
/*     */   }
/*     */ 
/*     */   protected HandlerMethod handleNoMatch(Set<RequestMappingInfo> requestMappingInfos, String lookupPath, HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/* 169 */     Set allowedMethods = new LinkedHashSet(4);
/*     */ 
/* 171 */     Set patternMatches = new HashSet();
/* 172 */     Set patternAndMethodMatches = new HashSet();
/*     */ 
/* 174 */     for (RequestMappingInfo info : requestMappingInfos) {
/* 175 */       if (info.getPatternsCondition().getMatchingCondition(request) != null) {
/* 176 */         patternMatches.add(info);
/* 177 */         if (info.getMethodsCondition().getMatchingCondition(request) != null) {
/* 178 */           patternAndMethodMatches.add(info);
/*     */         }
/*     */         else {
/* 181 */           for (RequestMethod method : info.getMethodsCondition().getMethods()) {
/* 182 */             allowedMethods.add(method.name());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 188 */     if (patternMatches.isEmpty()) {
/* 189 */       return null;
/*     */     }
/* 191 */     if ((patternAndMethodMatches.isEmpty()) && (!allowedMethods.isEmpty()))
/* 192 */       throw new HttpRequestMethodNotSupportedException(request.getMethod(), allowedMethods);
/*     */     Set paramConditions;
/*     */     Set consumableMediaTypes;
/*     */     Set producibleMediaTypes;
/*     */     Set paramConditions;
/* 199 */     if (patternAndMethodMatches.isEmpty()) {
/* 200 */       Set consumableMediaTypes = getConsumableMediaTypes(request, patternMatches);
/* 201 */       Set producibleMediaTypes = getProducibleMediaTypes(request, patternMatches);
/* 202 */       paramConditions = getRequestParams(request, patternMatches);
/*     */     }
/*     */     else {
/* 205 */       consumableMediaTypes = getConsumableMediaTypes(request, patternAndMethodMatches);
/* 206 */       producibleMediaTypes = getProducibleMediaTypes(request, patternAndMethodMatches);
/* 207 */       paramConditions = getRequestParams(request, patternAndMethodMatches);
/*     */     }
/*     */ 
/* 210 */     if (!consumableMediaTypes.isEmpty()) {
/* 211 */       MediaType contentType = null;
/* 212 */       if (StringUtils.hasLength(request.getContentType())) {
/*     */         try {
/* 214 */           contentType = MediaType.parseMediaType(request.getContentType());
/*     */         }
/*     */         catch (InvalidMediaTypeException ex) {
/* 217 */           throw new HttpMediaTypeNotSupportedException(ex.getMessage());
/*     */         }
/*     */       }
/* 220 */       throw new HttpMediaTypeNotSupportedException(contentType, new ArrayList(consumableMediaTypes));
/*     */     }
/* 222 */     if (!producibleMediaTypes.isEmpty()) {
/* 223 */       throw new HttpMediaTypeNotAcceptableException(new ArrayList(producibleMediaTypes));
/*     */     }
/* 225 */     if (!CollectionUtils.isEmpty(paramConditions)) {
/* 226 */       String[] params = (String[])paramConditions.toArray(new String[paramConditions.size()]);
/* 227 */       throw new UnsatisfiedServletRequestParameterException(params, request.getParameterMap());
/*     */     }
/*     */ 
/* 230 */     return null;
/*     */   }
/*     */ 
/*     */   private Set<MediaType> getConsumableMediaTypes(HttpServletRequest request, Set<RequestMappingInfo> partialMatches)
/*     */   {
/* 235 */     Set result = new HashSet();
/* 236 */     for (RequestMappingInfo partialMatch : partialMatches) {
/* 237 */       if (partialMatch.getConsumesCondition().getMatchingCondition(request) == null) {
/* 238 */         result.addAll(partialMatch.getConsumesCondition().getConsumableMediaTypes());
/*     */       }
/*     */     }
/* 241 */     return result;
/*     */   }
/*     */ 
/*     */   private Set<MediaType> getProducibleMediaTypes(HttpServletRequest request, Set<RequestMappingInfo> partialMatches) {
/* 245 */     Set result = new HashSet();
/* 246 */     for (RequestMappingInfo partialMatch : partialMatches) {
/* 247 */       if (partialMatch.getProducesCondition().getMatchingCondition(request) == null) {
/* 248 */         result.addAll(partialMatch.getProducesCondition().getProducibleMediaTypes());
/*     */       }
/*     */     }
/* 251 */     return result;
/*     */   }
/*     */ 
/*     */   private Set<String> getRequestParams(HttpServletRequest request, Set<RequestMappingInfo> partialMatches) {
/* 255 */     for (RequestMappingInfo partialMatch : partialMatches) {
/* 256 */       ParamsRequestCondition condition = partialMatch.getParamsCondition();
/* 257 */       if ((!CollectionUtils.isEmpty(condition.getExpressions())) && (condition.getMatchingCondition(request) == null)) {
/* 258 */         Set expressions = new HashSet();
/* 259 */         for (NameValueExpression expr : condition.getExpressions()) {
/* 260 */           expressions.add(expr.toString());
/*     */         }
/* 262 */         return expressions;
/*     */       }
/*     */     }
/* 265 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.RequestMappingInfoHandlerMapping
 * JD-Core Version:    0.6.2
 */