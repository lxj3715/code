/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ 
/*     */ public abstract class AbstractMessageConverterMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  54 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   protected final List<HttpMessageConverter<?>> messageConverters;
/*     */   protected final List<MediaType> allSupportedMediaTypes;
/*     */ 
/*     */   public AbstractMessageConverterMethodArgumentResolver(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  62 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/*  63 */     this.messageConverters = messageConverters;
/*  64 */     this.allSupportedMediaTypes = getAllSupportedMediaTypes(messageConverters);
/*     */   }
/*     */ 
/*     */   private static List<MediaType> getAllSupportedMediaTypes(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  73 */     Set allSupportedMediaTypes = new LinkedHashSet();
/*  74 */     for (HttpMessageConverter messageConverter : messageConverters) {
/*  75 */       allSupportedMediaTypes.addAll(messageConverter.getSupportedMediaTypes());
/*     */     }
/*  77 */     Object result = new ArrayList(allSupportedMediaTypes);
/*  78 */     MediaType.sortBySpecificity((List)result);
/*  79 */     return Collections.unmodifiableList((List)result);
/*     */   }
/*     */ 
/*     */   protected <T> Object readWithMessageConverters(NativeWebRequest webRequest, MethodParameter methodParam, Type paramType)
/*     */     throws IOException, HttpMediaTypeNotSupportedException
/*     */   {
/*  96 */     HttpInputMessage inputMessage = createInputMessage(webRequest);
/*  97 */     return readWithMessageConverters(inputMessage, methodParam, paramType);
/*     */   }
/*     */ 
/*     */   protected <T> Object readWithMessageConverters(HttpInputMessage inputMessage, MethodParameter methodParam, Type targetType)
/*     */     throws IOException, HttpMediaTypeNotSupportedException
/*     */   {
/*     */     try
/*     */     {
/* 119 */       contentType = inputMessage.getHeaders().getContentType();
/*     */     }
/*     */     catch (InvalidMediaTypeException ex)
/*     */     {
/*     */       MediaType contentType;
/* 122 */       throw new HttpMediaTypeNotSupportedException(ex.getMessage());
/*     */     }
/*     */     MediaType contentType;
/* 125 */     if (contentType == null) {
/* 126 */       contentType = MediaType.APPLICATION_OCTET_STREAM;
/*     */     }
/*     */ 
/* 129 */     Class contextClass = methodParam.getContainingClass();
/*     */ 
/* 131 */     Class targetClass = ResolvableType.forType(targetType, 
/* 131 */       ResolvableType.forMethodParameter(methodParam))
/* 131 */       .resolve();
/*     */ 
/* 133 */     for (HttpMessageConverter converter : this.messageConverters) {
/* 134 */       if ((converter instanceof GenericHttpMessageConverter)) {
/* 135 */         GenericHttpMessageConverter genericConverter = (GenericHttpMessageConverter)converter;
/* 136 */         if (genericConverter.canRead(targetType, contextClass, contentType)) {
/* 137 */           if (this.logger.isDebugEnabled()) {
/* 138 */             this.logger.debug("Reading [" + targetType + "] as \"" + contentType + "\" using [" + converter + "]");
/*     */           }
/*     */ 
/* 141 */           return genericConverter.read(targetType, contextClass, inputMessage);
/*     */         }
/*     */       }
/* 144 */       if ((targetClass != null) && 
/* 145 */         (converter.canRead(targetClass, contentType))) {
/* 146 */         if (this.logger.isDebugEnabled()) {
/* 147 */           this.logger.debug("Reading [" + targetClass.getName() + "] as \"" + contentType + "\" using [" + converter + "]");
/*     */         }
/*     */ 
/* 150 */         return converter.read(targetClass, inputMessage);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 155 */     throw new HttpMediaTypeNotSupportedException(contentType, this.allSupportedMediaTypes);
/*     */   }
/*     */ 
/*     */   protected ServletServerHttpRequest createInputMessage(NativeWebRequest webRequest)
/*     */   {
/* 164 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 165 */     return new ServletServerHttpRequest(servletRequest);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.AbstractMessageConverterMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */