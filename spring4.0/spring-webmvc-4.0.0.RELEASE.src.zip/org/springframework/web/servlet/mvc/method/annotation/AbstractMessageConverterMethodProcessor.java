/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ 
/*     */ public abstract class AbstractMessageConverterMethodProcessor extends AbstractMessageConverterMethodArgumentResolver
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*  54 */   private static final MediaType MEDIA_TYPE_APPLICATION = new MediaType("application");
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*     */ 
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  59 */     this(messageConverters, null);
/*     */   }
/*     */ 
/*     */   protected AbstractMessageConverterMethodProcessor(List<HttpMessageConverter<?>> messageConverters, ContentNegotiationManager manager)
/*     */   {
/*  65 */     super(messageConverters);
/*  66 */     this.contentNegotiationManager = (manager != null ? manager : new ContentNegotiationManager());
/*     */   }
/*     */ 
/*     */   protected ServletServerHttpResponse createOutputMessage(NativeWebRequest webRequest)
/*     */   {
/*  76 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/*  77 */     return new ServletServerHttpResponse(response);
/*     */   }
/*     */ 
/*     */   protected <T> void writeWithMessageConverters(T returnValue, MethodParameter returnType, NativeWebRequest webRequest)
/*     */     throws IOException, HttpMediaTypeNotAcceptableException
/*     */   {
/*  88 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/*  89 */     ServletServerHttpResponse outputMessage = createOutputMessage(webRequest);
/*  90 */     writeWithMessageConverters(returnValue, returnType, inputMessage, outputMessage);
/*     */   }
/*     */ 
/*     */   protected <T> void writeWithMessageConverters(T returnValue, MethodParameter returnType, ServletServerHttpRequest inputMessage, ServletServerHttpResponse outputMessage)
/*     */     throws IOException, HttpMediaTypeNotAcceptableException
/*     */   {
/* 111 */     Class returnValueClass = returnValue.getClass();
/*     */ 
/* 113 */     HttpServletRequest servletRequest = inputMessage.getServletRequest();
/* 114 */     List requestedMediaTypes = getAcceptableMediaTypes(servletRequest);
/* 115 */     List producibleMediaTypes = getProducibleMediaTypes(servletRequest, returnValueClass);
/*     */ 
/* 117 */     Set compatibleMediaTypes = new LinkedHashSet();
/* 118 */     for (Iterator localIterator1 = requestedMediaTypes.iterator(); localIterator1.hasNext(); ) { r = (MediaType)localIterator1.next();
/* 119 */       for (MediaType p : producibleMediaTypes)
/* 120 */         if (r.isCompatibleWith(p))
/* 121 */           compatibleMediaTypes.add(getMostSpecificMediaType(r, p));
/*     */     }
/*     */     MediaType r;
/* 125 */     if (compatibleMediaTypes.isEmpty()) {
/* 126 */       throw new HttpMediaTypeNotAcceptableException(producibleMediaTypes);
/*     */     }
/*     */ 
/* 129 */     Object mediaTypes = new ArrayList(compatibleMediaTypes);
/* 130 */     MediaType.sortBySpecificityAndQuality((List)mediaTypes);
/*     */ 
/* 132 */     MediaType selectedMediaType = null;
/* 133 */     for (MediaType mediaType : (List)mediaTypes) {
/* 134 */       if (mediaType.isConcrete()) {
/* 135 */         selectedMediaType = mediaType;
/* 136 */         break;
/*     */       }
/* 138 */       if ((mediaType.equals(MediaType.ALL)) || (mediaType.equals(MEDIA_TYPE_APPLICATION))) {
/* 139 */         selectedMediaType = MediaType.APPLICATION_OCTET_STREAM;
/* 140 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 144 */     if (selectedMediaType != null) {
/* 145 */       selectedMediaType = selectedMediaType.removeQualityValue();
/* 146 */       for (HttpMessageConverter messageConverter : this.messageConverters) {
/* 147 */         if (messageConverter.canWrite(returnValueClass, selectedMediaType)) {
/* 148 */           messageConverter.write(returnValue, selectedMediaType, outputMessage);
/* 149 */           if (this.logger.isDebugEnabled()) {
/* 150 */             this.logger.debug("Written [" + returnValue + "] as \"" + selectedMediaType + "\" using [" + messageConverter + "]");
/*     */           }
/*     */ 
/* 153 */           return;
/*     */         }
/*     */       }
/*     */     }
/* 157 */     throw new HttpMediaTypeNotAcceptableException(this.allSupportedMediaTypes);
/*     */   }
/*     */ 
/*     */   protected List<MediaType> getProducibleMediaTypes(HttpServletRequest request, Class<?> returnValueClass)
/*     */   {
/* 170 */     Set mediaTypes = (Set)request.getAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE);
/* 171 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 172 */       return new ArrayList(mediaTypes);
/*     */     }
/* 174 */     if (!this.allSupportedMediaTypes.isEmpty()) {
/* 175 */       List result = new ArrayList();
/* 176 */       for (HttpMessageConverter converter : this.messageConverters) {
/* 177 */         if (converter.canWrite(returnValueClass, null)) {
/* 178 */           result.addAll(converter.getSupportedMediaTypes());
/*     */         }
/*     */       }
/* 181 */       return result;
/*     */     }
/*     */ 
/* 184 */     return Collections.singletonList(MediaType.ALL);
/*     */   }
/*     */ 
/*     */   private List<MediaType> getAcceptableMediaTypes(HttpServletRequest request) throws HttpMediaTypeNotAcceptableException
/*     */   {
/* 189 */     List mediaTypes = this.contentNegotiationManager.resolveMediaTypes(new ServletWebRequest(request));
/* 190 */     return mediaTypes.isEmpty() ? Collections.singletonList(MediaType.ALL) : mediaTypes;
/*     */   }
/*     */ 
/*     */   private MediaType getMostSpecificMediaType(MediaType acceptType, MediaType produceType)
/*     */   {
/* 198 */     produceType = produceType.copyQualityValue(acceptType);
/* 199 */     return MediaType.SPECIFICITY_COMPARATOR.compare(acceptType, produceType) <= 0 ? acceptType : produceType;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.AbstractMessageConverterMethodProcessor
 * JD-Core Version:    0.6.2
 */