/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.context.request.async.WebAsyncManager;
/*    */ import org.springframework.web.context.request.async.WebAsyncTask;
/*    */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*    */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class AsyncTaskMethodReturnValueHandler
/*    */   implements HandlerMethodReturnValueHandler
/*    */ {
/*    */   private final BeanFactory beanFactory;
/*    */ 
/*    */   public AsyncTaskMethodReturnValueHandler(BeanFactory beanFactory)
/*    */   {
/* 39 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */   public boolean supportsReturnType(MethodParameter returnType)
/*    */   {
/* 44 */     Class paramType = returnType.getParameterType();
/* 45 */     return WebAsyncTask.class.isAssignableFrom(paramType);
/*    */   }
/*    */ 
/*    */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 53 */     if (returnValue == null) {
/* 54 */       mavContainer.setRequestHandled(true);
/* 55 */       return;
/*    */     }
/*    */ 
/* 58 */     WebAsyncTask webAsyncTask = (WebAsyncTask)returnValue;
/* 59 */     webAsyncTask.setBeanFactory(this.beanFactory);
/* 60 */     WebAsyncUtils.getAsyncManager(webRequest).startCallableProcessing(webAsyncTask, new Object[] { mavContainer });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.AsyncTaskMethodReturnValueHandler
 * JD-Core Version:    0.6.2
 */