/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.context.request.async.WebAsyncManager;
/*    */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*    */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class CallableMethodReturnValueHandler
/*    */   implements HandlerMethodReturnValueHandler
/*    */ {
/*    */   public boolean supportsReturnType(MethodParameter returnType)
/*    */   {
/* 37 */     Class paramType = returnType.getParameterType();
/* 38 */     return Callable.class.isAssignableFrom(paramType);
/*    */   }
/*    */ 
/*    */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 46 */     if (returnValue == null) {
/* 47 */       mavContainer.setRequestHandled(true);
/* 48 */       return;
/*    */     }
/*    */ 
/* 51 */     Callable callable = (Callable)returnValue;
/* 52 */     WebAsyncUtils.getAsyncManager(webRequest).startCallableProcessing(callable, new Object[] { mavContainer });
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.CallableMethodReturnValueHandler
 * JD-Core Version:    0.6.2
 */