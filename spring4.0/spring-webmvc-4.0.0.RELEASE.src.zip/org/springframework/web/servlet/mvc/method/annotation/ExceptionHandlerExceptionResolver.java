/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.ControllerAdviceBean;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.annotation.ExceptionHandlerMethodResolver;
/*     */ import org.springframework.web.method.annotation.MapMethodProcessor;
/*     */ import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
/*     */ import org.springframework.web.method.annotation.ModelMethodProcessor;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolverComposite;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMethodExceptionResolver;
/*     */ 
/*     */ public class ExceptionHandlerExceptionResolver extends AbstractHandlerMethodExceptionResolver
/*     */   implements InitializingBean, ApplicationContextAware
/*     */ {
/*     */   private List<HandlerMethodArgumentResolver> customArgumentResolvers;
/*     */   private List<HandlerMethodReturnValueHandler> customReturnValueHandlers;
/*     */   private List<HttpMessageConverter<?>> messageConverters;
/*  80 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*     */ 
/*  82 */   private final Map<Class<?>, ExceptionHandlerMethodResolver> exceptionHandlerCache = new ConcurrentHashMap(64);
/*     */ 
/*  85 */   private final Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> exceptionHandlerAdviceCache = new LinkedHashMap();
/*     */   private HandlerMethodArgumentResolverComposite argumentResolvers;
/*     */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*     */   private ApplicationContext applicationContext;
/*     */ 
/*     */   public ExceptionHandlerExceptionResolver()
/*     */   {
/*  99 */     StringHttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter();
/* 100 */     stringHttpMessageConverter.setWriteAcceptCharset(false);
/*     */ 
/* 102 */     this.messageConverters = new ArrayList();
/* 103 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 104 */     this.messageConverters.add(stringHttpMessageConverter);
/* 105 */     this.messageConverters.add(new SourceHttpMessageConverter());
/* 106 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public void setCustomArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 115 */     this.customArgumentResolvers = argumentResolvers;
/*     */   }
/*     */ 
/*     */   public List<HandlerMethodArgumentResolver> getCustomArgumentResolvers()
/*     */   {
/* 122 */     return this.customArgumentResolvers;
/*     */   }
/*     */ 
/*     */   public void setArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 130 */     if (argumentResolvers == null) {
/* 131 */       this.argumentResolvers = null;
/*     */     }
/*     */     else {
/* 134 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite();
/* 135 */       this.argumentResolvers.addResolvers(argumentResolvers);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HandlerMethodArgumentResolverComposite getArgumentResolvers()
/*     */   {
/* 144 */     return this.argumentResolvers;
/*     */   }
/*     */ 
/*     */   public void setCustomReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 153 */     this.customReturnValueHandlers = returnValueHandlers;
/*     */   }
/*     */ 
/*     */   public List<HandlerMethodReturnValueHandler> getCustomReturnValueHandlers()
/*     */   {
/* 160 */     return this.customReturnValueHandlers;
/*     */   }
/*     */ 
/*     */   public void setReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 168 */     if (returnValueHandlers == null) {
/* 169 */       this.returnValueHandlers = null;
/*     */     }
/*     */     else {
/* 172 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite();
/* 173 */       this.returnValueHandlers.addHandlers(returnValueHandlers);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HandlerMethodReturnValueHandlerComposite getReturnValueHandlers()
/*     */   {
/* 182 */     return this.returnValueHandlers;
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 190 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 197 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 205 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationManager getContentNegotiationManager()
/*     */   {
/* 212 */     return this.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   public Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> getExceptionHandlerAdviceCache()
/*     */   {
/* 222 */     return Collections.unmodifiableMap(this.exceptionHandlerAdviceCache);
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException
/*     */   {
/* 227 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public ApplicationContext getApplicationContext() {
/* 231 */     return this.applicationContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 236 */     if (this.argumentResolvers == null) {
/* 237 */       List resolvers = getDefaultArgumentResolvers();
/* 238 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite().addResolvers(resolvers);
/*     */     }
/* 240 */     if (this.returnValueHandlers == null) {
/* 241 */       List handlers = getDefaultReturnValueHandlers();
/* 242 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite().addHandlers(handlers);
/*     */     }
/* 244 */     initExceptionHandlerAdviceCache();
/*     */   }
/*     */ 
/*     */   protected List<HandlerMethodArgumentResolver> getDefaultArgumentResolvers()
/*     */   {
/* 252 */     List resolvers = new ArrayList();
/*     */ 
/* 255 */     resolvers.add(new ServletRequestMethodArgumentResolver());
/* 256 */     resolvers.add(new ServletResponseMethodArgumentResolver());
/*     */ 
/* 259 */     if (getCustomArgumentResolvers() != null) {
/* 260 */       resolvers.addAll(getCustomArgumentResolvers());
/*     */     }
/*     */ 
/* 263 */     return resolvers;
/*     */   }
/*     */ 
/*     */   protected List<HandlerMethodReturnValueHandler> getDefaultReturnValueHandlers()
/*     */   {
/* 271 */     List handlers = new ArrayList();
/*     */ 
/* 274 */     handlers.add(new ModelAndViewMethodReturnValueHandler());
/* 275 */     handlers.add(new ModelMethodProcessor());
/* 276 */     handlers.add(new ViewMethodReturnValueHandler());
/* 277 */     handlers.add(new HttpEntityMethodProcessor(getMessageConverters(), this.contentNegotiationManager));
/*     */ 
/* 280 */     handlers.add(new ModelAttributeMethodProcessor(false));
/* 281 */     handlers.add(new RequestResponseBodyMethodProcessor(getMessageConverters(), this.contentNegotiationManager));
/*     */ 
/* 284 */     handlers.add(new ViewNameMethodReturnValueHandler());
/* 285 */     handlers.add(new MapMethodProcessor());
/*     */ 
/* 288 */     if (getCustomReturnValueHandlers() != null) {
/* 289 */       handlers.addAll(getCustomReturnValueHandlers());
/*     */     }
/*     */ 
/* 293 */     handlers.add(new ModelAttributeMethodProcessor(true));
/*     */ 
/* 295 */     return handlers;
/*     */   }
/*     */ 
/*     */   private void initExceptionHandlerAdviceCache() {
/* 299 */     if (getApplicationContext() == null) {
/* 300 */       return;
/*     */     }
/* 302 */     if (this.logger.isDebugEnabled()) {
/* 303 */       this.logger.debug("Looking for exception mappings: " + getApplicationContext());
/*     */     }
/*     */ 
/* 306 */     List beans = ControllerAdviceBean.findAnnotatedBeans(getApplicationContext());
/* 307 */     Collections.sort(beans, new OrderComparator());
/*     */ 
/* 309 */     for (ControllerAdviceBean bean : beans) {
/* 310 */       ExceptionHandlerMethodResolver resolver = new ExceptionHandlerMethodResolver(bean.getBeanType());
/* 311 */       if (resolver.hasExceptionMappings()) {
/* 312 */         this.exceptionHandlerAdviceCache.put(bean, resolver);
/* 313 */         this.logger.info("Detected @ExceptionHandler methods in " + bean);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ModelAndView doResolveHandlerMethodException(HttpServletRequest request, HttpServletResponse response, HandlerMethod handlerMethod, Exception exception)
/*     */   {
/* 325 */     ServletInvocableHandlerMethod exceptionHandlerMethod = getExceptionHandlerMethod(handlerMethod, exception);
/* 326 */     if (exceptionHandlerMethod == null) {
/* 327 */       return null;
/*     */     }
/*     */ 
/* 330 */     exceptionHandlerMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
/* 331 */     exceptionHandlerMethod.setHandlerMethodReturnValueHandlers(this.returnValueHandlers);
/*     */ 
/* 333 */     ServletWebRequest webRequest = new ServletWebRequest(request, response);
/* 334 */     ModelAndViewContainer mavContainer = new ModelAndViewContainer();
/*     */     try
/*     */     {
/* 337 */       if (this.logger.isDebugEnabled()) {
/* 338 */         this.logger.debug("Invoking @ExceptionHandler method: " + exceptionHandlerMethod);
/*     */       }
/* 340 */       exceptionHandlerMethod.invokeAndHandle(webRequest, mavContainer, new Object[] { exception });
/*     */     }
/*     */     catch (Exception invocationEx) {
/* 343 */       this.logger.error("Failed to invoke @ExceptionHandler method: " + exceptionHandlerMethod, invocationEx);
/* 344 */       return null;
/*     */     }
/*     */ 
/* 347 */     if (mavContainer.isRequestHandled()) {
/* 348 */       return new ModelAndView();
/*     */     }
/*     */ 
/* 351 */     ModelAndView mav = new ModelAndView().addAllObjects(mavContainer.getModel());
/* 352 */     mav.setViewName(mavContainer.getViewName());
/* 353 */     if (!mavContainer.isViewReference()) {
/* 354 */       mav.setView((View)mavContainer.getView());
/*     */     }
/* 356 */     return mav;
/*     */   }
/*     */ 
/*     */   protected ServletInvocableHandlerMethod getExceptionHandlerMethod(HandlerMethod handlerMethod, Exception exception)
/*     */   {
/* 371 */     Class handlerType = handlerMethod != null ? handlerMethod.getBeanType() : null;
/*     */     ExceptionHandlerMethodResolver resolver;
/* 372 */     if (handlerMethod != null) {
/* 373 */       resolver = (ExceptionHandlerMethodResolver)this.exceptionHandlerCache.get(handlerType);
/* 374 */       if (resolver == null) {
/* 375 */         resolver = new ExceptionHandlerMethodResolver(handlerType);
/* 376 */         this.exceptionHandlerCache.put(handlerType, resolver);
/*     */       }
/* 378 */       Method method = resolver.resolveMethod(exception);
/* 379 */       if (method != null) {
/* 380 */         return new ServletInvocableHandlerMethod(handlerMethod.getBean(), method);
/*     */       }
/*     */     }
/* 383 */     for (Map.Entry entry : this.exceptionHandlerAdviceCache.entrySet()) {
/* 384 */       if (((ControllerAdviceBean)entry.getKey()).isApplicableToBeanType(handlerType)) {
/* 385 */         ExceptionHandlerMethodResolver resolver = (ExceptionHandlerMethodResolver)entry.getValue();
/* 386 */         Method method = resolver.resolveMethod(exception);
/* 387 */         if (method != null) {
/* 388 */           return new ServletInvocableHandlerMethod(((ControllerAdviceBean)entry.getKey()).resolveBean(), method);
/*     */         }
/*     */       }
/*     */     }
/* 392 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver
 * JD-Core Version:    0.6.2
 */