/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public class HttpEntityMethodProcessor extends AbstractMessageConverterMethodProcessor
/*     */ {
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  55 */     super(messageConverters);
/*     */   }
/*     */ 
/*     */   public HttpEntityMethodProcessor(List<HttpMessageConverter<?>> messageConverters, ContentNegotiationManager contentNegotiationManager)
/*     */   {
/*  61 */     super(messageConverters, contentNegotiationManager);
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  66 */     Class parameterType = parameter.getParameterType();
/*  67 */     return HttpEntity.class.equals(parameterType);
/*     */   }
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*  72 */     Class parameterType = returnType.getParameterType();
/*  73 */     return (HttpEntity.class.isAssignableFrom(parameterType)) || (ResponseEntity.class.isAssignableFrom(parameterType));
/*     */   }
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws IOException, HttpMediaTypeNotSupportedException
/*     */   {
/*  82 */     HttpInputMessage inputMessage = createInputMessage(webRequest);
/*  83 */     Type paramType = getHttpEntityType(parameter);
/*     */ 
/*  85 */     Object body = readWithMessageConverters(webRequest, parameter, paramType);
/*  86 */     return new HttpEntity(body, inputMessage.getHeaders());
/*     */   }
/*     */ 
/*     */   private Type getHttpEntityType(MethodParameter parameter) {
/*  90 */     Assert.isAssignable(HttpEntity.class, parameter.getParameterType());
/*  91 */     ParameterizedType type = (ParameterizedType)parameter.getGenericParameterType();
/*  92 */     if (type.getActualTypeArguments().length == 1) {
/*  93 */       return type.getActualTypeArguments()[0];
/*     */     }
/*     */ 
/*  96 */     throw new IllegalArgumentException("HttpEntity parameter (" + parameter
/*  96 */       .getParameterName() + ") in method " + parameter.getMethod() + " is not parameterized or has more than one parameter");
/*     */   }
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 106 */     mavContainer.setRequestHandled(true);
/*     */ 
/* 108 */     if (returnValue == null) {
/* 109 */       return;
/*     */     }
/*     */ 
/* 112 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 113 */     ServletServerHttpResponse outputMessage = createOutputMessage(webRequest);
/*     */ 
/* 115 */     Assert.isInstanceOf(HttpEntity.class, returnValue);
/* 116 */     HttpEntity responseEntity = (HttpEntity)returnValue;
/* 117 */     if ((responseEntity instanceof ResponseEntity)) {
/* 118 */       outputMessage.setStatusCode(((ResponseEntity)responseEntity).getStatusCode());
/*     */     }
/*     */ 
/* 121 */     HttpHeaders entityHeaders = responseEntity.getHeaders();
/* 122 */     if (!entityHeaders.isEmpty()) {
/* 123 */       outputMessage.getHeaders().putAll(entityHeaders);
/*     */     }
/*     */ 
/* 126 */     Object body = responseEntity.getBody();
/* 127 */     if (body != null) {
/* 128 */       writeWithMessageConverters(body, returnType, inputMessage, outputMessage);
/*     */     }
/*     */     else
/*     */     {
/* 132 */       outputMessage.getBody();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.HttpEntityMethodProcessor
 * JD-Core Version:    0.6.2
 */