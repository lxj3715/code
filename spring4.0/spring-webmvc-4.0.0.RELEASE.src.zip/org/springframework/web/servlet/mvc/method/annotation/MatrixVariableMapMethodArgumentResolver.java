/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.bind.annotation.MatrixVariable;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ import org.springframework.web.servlet.HandlerMapping;
/*    */ 
/*    */ public class MatrixVariableMapMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 49 */     MatrixVariable paramAnnot = (MatrixVariable)parameter.getParameterAnnotation(MatrixVariable.class);
/* 50 */     if ((paramAnnot != null) && 
/* 51 */       (Map.class.isAssignableFrom(parameter.getParameterType()))) {
/* 52 */       return !StringUtils.hasText(paramAnnot.value());
/*    */     }
/*    */ 
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest request, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 64 */     Map matrixVariables = (Map)request
/* 64 */       .getAttribute(HandlerMapping.MATRIX_VARIABLES_ATTRIBUTE, 0);
/*    */ 
/* 67 */     if (CollectionUtils.isEmpty(matrixVariables)) {
/* 68 */       return Collections.emptyMap();
/*    */     }
/*    */ 
/* 71 */     String pathVariable = ((MatrixVariable)parameter.getParameterAnnotation(MatrixVariable.class)).pathVar();
/*    */ 
/* 73 */     if (!pathVariable.equals("\n\t\t\n\t\t\n\n\t\t\t\t\n")) {
/* 74 */       MultiValueMap map = (MultiValueMap)matrixVariables.get(pathVariable);
/* 75 */       return map != null ? map : Collections.emptyMap();
/*    */     }
/*    */ 
/* 78 */     MultiValueMap map = new LinkedMultiValueMap();
/* 79 */     for (Iterator localIterator1 = matrixVariables.values().iterator(); localIterator1.hasNext(); ) { vars = (MultiValueMap)localIterator1.next();
/* 80 */       for (localIterator2 = vars.keySet().iterator(); localIterator2.hasNext(); ) { name = (String)localIterator2.next();
/* 81 */         for (String value : (List)vars.get(name))
/* 82 */           map.add(name, value);
/*    */       }
/*    */     }
/*    */     MultiValueMap vars;
/*    */     Iterator localIterator2;
/*    */     String name;
/* 87 */     return map;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.MatrixVariableMapMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */