/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ import org.springframework.web.servlet.SmartView;
/*    */ import org.springframework.web.servlet.View;
/*    */ 
/*    */ public class ModelAndViewMethodReturnValueHandler
/*    */   implements HandlerMethodReturnValueHandler
/*    */ {
/*    */   public boolean supportsReturnType(MethodParameter returnType)
/*    */   {
/* 47 */     return ModelAndView.class.isAssignableFrom(returnType.getParameterType());
/*    */   }
/*    */ 
/*    */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 56 */     if (returnValue == null) {
/* 57 */       mavContainer.setRequestHandled(true);
/* 58 */       return;
/*    */     }
/*    */ 
/* 61 */     ModelAndView mav = (ModelAndView)returnValue;
/* 62 */     if (mav.isReference()) {
/* 63 */       String viewName = mav.getViewName();
/* 64 */       mavContainer.setViewName(viewName);
/* 65 */       if ((viewName != null) && (viewName.startsWith("redirect:")))
/* 66 */         mavContainer.setRedirectModelScenario(true);
/*    */     }
/*    */     else
/*    */     {
/* 70 */       View view = mav.getView();
/* 71 */       mavContainer.setView(view);
/* 72 */       if (((view instanceof SmartView)) && 
/* 73 */         (((SmartView)view).isRedirectView())) {
/* 74 */         mavContainer.setRedirectModelScenario(true);
/*    */       }
/*    */     }
/*    */ 
/* 78 */     mavContainer.addAllAttributes(mav.getModel());
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ModelAndViewMethodReturnValueHandler
 * JD-Core Version:    0.6.2
 */