/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.target.EmptyTargetSource;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.objenesis.ObjenesisStd;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.method.annotation.RequestParamMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ public class MvcUriComponentsBuilder extends UriComponentsBuilder
/*     */ {
/*     */   public static final String MVC_URI_COMPONENTS_CONTRIBUTOR_BEAN_NAME = "mvcUriComponentsContributor";
/*  80 */   private static final CompositeUriComponentsContributor defaultUriComponentsContributor = new CompositeUriComponentsContributor(
/*  81 */     Arrays.asList(new Object[] { new PathVariableMethodArgumentResolver(), new RequestParamMethodArgumentResolver(null, false) }));
/*     */ 
/*  70 */   private static final PathMatcher pathMatcher = new AntPathMatcher();
/*     */ 
/*  72 */   private static final ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */ 
/*  74 */   private static final ObjenesisStd objenesis = new ObjenesisStd(true);
/*     */ 
/*  76 */   private static Log logger = LogFactory.getLog(MvcUriComponentsBuilder.class);
/*     */ 
/*     */   public static UriComponentsBuilder fromController(Class<?> controllerType)
/*     */   {
/*  96 */     String mapping = getTypeRequestMapping(controllerType);
/*  97 */     return ServletUriComponentsBuilder.fromCurrentServletMapping().path(mapping);
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromMethodName(Class<?> controllerType, String methodName, Object[] argumentValues)
/*     */   {
/* 119 */     Method match = null;
/* 120 */     for (Method method : controllerType.getDeclaredMethods()) {
/* 121 */       if ((method.getParameterCount() == argumentValues.length) && (method.getName().equals(methodName))) {
/* 122 */         if (match != null)
/*     */         {
/* 125 */           throw new IllegalStateException("Found two methods named '" + methodName + "' having " + argumentValues + " arguments, controller " + controllerType
/* 125 */             .getName());
/*     */         }
/* 127 */         match = method;
/*     */       }
/*     */     }
/* 130 */     if (match == null)
/*     */     {
/* 132 */       throw new IllegalArgumentException("No method '" + methodName + "' with " + argumentValues.length + " parameters found in " + controllerType
/* 132 */         .getName());
/*     */     }
/* 134 */     return fromMethod(match, argumentValues);
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromMethod(Method method, Object[] argumentValues)
/*     */   {
/* 151 */     UriComponentsBuilder builder = ServletUriComponentsBuilder.newInstance().path(getMethodRequestMapping(method));
/* 152 */     UriComponents uriComponents = applyContributors(builder, method, argumentValues);
/*     */ 
/* 154 */     String typePath = getTypeRequestMapping(method.getDeclaringClass());
/* 155 */     String methodPath = uriComponents.getPath();
/* 156 */     String path = pathMatcher.combine(typePath, methodPath);
/*     */ 
/* 159 */     return ServletUriComponentsBuilder.fromCurrentServletMapping().path(path)
/* 159 */       .queryParams(uriComponents
/* 159 */       .getQueryParams());
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromMethodCall(Object methodInvocationInfo)
/*     */   {
/* 207 */     Assert.isInstanceOf(MethodInvocationInfo.class, methodInvocationInfo);
/* 208 */     MethodInvocationInfo info = (MethodInvocationInfo)methodInvocationInfo;
/*     */ 
/* 210 */     Method method = info.getControllerMethod();
/* 211 */     Object[] argumentValues = info.getArgumentValues();
/*     */ 
/* 213 */     UriComponentsBuilder builder = ServletUriComponentsBuilder.newInstance().path(getMethodRequestMapping(method));
/* 214 */     UriComponents uriComponents = applyContributors(builder, method, argumentValues);
/*     */ 
/* 216 */     String typeMapping = getTypeRequestMapping(method.getDeclaringClass());
/* 217 */     String methodMapping = uriComponents.getPath();
/* 218 */     String path = pathMatcher.combine(typeMapping, methodMapping);
/*     */ 
/* 221 */     return ServletUriComponentsBuilder.fromCurrentServletMapping().path(path)
/* 221 */       .queryParams(uriComponents
/* 221 */       .getQueryParams());
/*     */   }
/*     */ 
/*     */   private static String getTypeRequestMapping(Class<?> controllerType)
/*     */   {
/* 226 */     Assert.notNull(controllerType, "'controllerType' must not be null");
/* 227 */     RequestMapping annot = (RequestMapping)AnnotationUtils.findAnnotation(controllerType, RequestMapping.class);
/* 228 */     if ((annot == null) || (ObjectUtils.isEmpty(annot.value())) || (StringUtils.isEmpty(annot.value()[0]))) {
/* 229 */       return "/";
/*     */     }
/* 231 */     if (annot.value().length > 1) {
/* 232 */       logger.warn("Multiple mappings on controller " + controllerType.getName() + ", using the first one");
/*     */     }
/* 234 */     return annot.value()[0];
/*     */   }
/*     */ 
/*     */   private static String getMethodRequestMapping(Method method) {
/* 238 */     RequestMapping annot = (RequestMapping)AnnotationUtils.findAnnotation(method, RequestMapping.class);
/* 239 */     Assert.notNull(annot, "No @RequestMapping on: " + method.toGenericString());
/* 240 */     if ((ObjectUtils.isEmpty(annot.value())) || (StringUtils.isEmpty(annot.value()[0]))) {
/* 241 */       return "/";
/*     */     }
/* 243 */     if (annot.value().length > 1) {
/* 244 */       logger.debug("Multiple mappings on method " + method.toGenericString() + ", using first one");
/*     */     }
/* 246 */     return annot.value()[0];
/*     */   }
/*     */ 
/*     */   private static UriComponents applyContributors(UriComponentsBuilder builder, Method method, Object[] args)
/*     */   {
/* 251 */     CompositeUriComponentsContributor contributor = getConfiguredUriComponentsContributor();
/* 252 */     if (contributor == null) {
/* 253 */       logger.debug("Using default CompositeUriComponentsContributor");
/* 254 */       contributor = defaultUriComponentsContributor;
/*     */     }
/*     */ 
/* 257 */     int paramCount = method.getParameterTypes().length;
/* 258 */     int argCount = args.length;
/*     */ 
/* 260 */     Assert.isTrue(paramCount == argCount, "Number of method parameters " + paramCount + " does not match number of argument values " + argCount);
/*     */ 
/* 263 */     Map uriVars = new HashMap();
/*     */ 
/* 265 */     for (int i = 0; i < paramCount; i++) {
/* 266 */       MethodParameter param = new MethodParameter(method, i);
/* 267 */       param.initParameterNameDiscovery(parameterNameDiscoverer);
/* 268 */       contributor.contributeMethodArgument(param, args[i], builder, uriVars);
/*     */     }
/*     */ 
/* 271 */     return builder.buildAndExpand(uriVars);
/*     */   }
/*     */ 
/*     */   protected static CompositeUriComponentsContributor getConfiguredUriComponentsContributor() {
/* 275 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 276 */     if (requestAttributes == null) {
/* 277 */       logger.debug("No request bound to the current thread: is DispatcherSerlvet used?");
/* 278 */       return null;
/*     */     }
/* 280 */     HttpServletRequest request = ((ServletRequestAttributes)requestAttributes).getRequest();
/* 281 */     if (request == null) {
/* 282 */       logger.debug("Request bound to current thread is not an HttpServletRequest");
/* 283 */       return null;
/*     */     }
/* 285 */     WebApplicationContext wac = (WebApplicationContext)request.getAttribute(DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */ 
/* 287 */     if (wac == null) {
/* 288 */       logger.debug("No WebApplicationContext found: not in a DispatcherServlet request?");
/* 289 */       return null;
/*     */     }
/*     */     try {
/* 292 */       String beanName = "mvcUriComponentsContributor";
/* 293 */       return (CompositeUriComponentsContributor)wac.getBean(beanName, CompositeUriComponentsContributor.class);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/* 296 */       if (logger.isDebugEnabled()) {
/* 297 */         logger.debug("No CompositeUriComponentsContributor bean with name 'mvcUriComponentsContributor'");
/*     */       }
/*     */     }
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */   public static <T> T on(Class<T> controllerType)
/*     */   {
/* 318 */     return controller(controllerType);
/*     */   }
/*     */ 
/*     */   public static <T> T controller(Class<T> controllerType)
/*     */   {
/* 340 */     Assert.notNull(controllerType, "'controllerType' must not be null");
/* 341 */     return initProxy(controllerType, new ControllerMethodInvocationInterceptor(null));
/*     */   }
/*     */ 
/*     */   private static <T> T initProxy(Class<?> type, ControllerMethodInvocationInterceptor interceptor)
/*     */   {
/* 347 */     if (type.isInterface()) {
/* 348 */       ProxyFactory factory = new ProxyFactory(EmptyTargetSource.INSTANCE);
/* 349 */       factory.addInterface(type);
/* 350 */       factory.addInterface(MethodInvocationInfo.class);
/* 351 */       factory.addAdvice(interceptor);
/* 352 */       return factory.getProxy();
/*     */     }
/*     */ 
/* 355 */     Enhancer enhancer = new Enhancer();
/* 356 */     enhancer.setSuperclass(type);
/* 357 */     enhancer.setInterfaces(new Class[] { MethodInvocationInfo.class });
/* 358 */     enhancer.setCallbackType(org.springframework.cglib.proxy.MethodInterceptor.class);
/*     */ 
/* 360 */     Factory factory = (Factory)objenesis.newInstance(enhancer.createClass());
/* 361 */     factory.setCallbacks(new Callback[] { interceptor });
/* 362 */     return factory;
/*     */   }
/*     */   public static abstract interface MethodInvocationInfo {
/*     */     public abstract Method getControllerMethod();
/*     */ 
/*     */     public abstract Object[] getArgumentValues();
/*     */   }
/*     */ 
/*     */   private static class ControllerMethodInvocationInterceptor implements org.springframework.cglib.proxy.MethodInterceptor, org.aopalliance.intercept.MethodInterceptor {
/* 371 */     private static final Method getControllerMethod = ReflectionUtils.findMethod(MvcUriComponentsBuilder.MethodInvocationInfo.class, "getControllerMethod")
/* 371 */       ;
/*     */ 
/* 374 */     private static final Method getArgumentValues = ReflectionUtils.findMethod(MvcUriComponentsBuilder.MethodInvocationInfo.class, "getArgumentValues")
/* 374 */       ;
/*     */     private Method controllerMethod;
/*     */     private Object[] argumentValues;
/*     */ 
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy)
/*     */     {
/* 385 */       if (getControllerMethod.equals(method)) {
/* 386 */         return this.controllerMethod;
/*     */       }
/* 388 */       if (getArgumentValues.equals(method)) {
/* 389 */         return this.argumentValues;
/*     */       }
/* 391 */       if (ReflectionUtils.isObjectMethod(method)) {
/* 392 */         return ReflectionUtils.invokeMethod(method, obj, args);
/*     */       }
/*     */ 
/* 395 */       this.controllerMethod = method;
/* 396 */       this.argumentValues = args;
/*     */ 
/* 398 */       Class returnType = method.getReturnType();
/* 399 */       return Void.TYPE.equals(returnType) ? null : returnType.cast(MvcUriComponentsBuilder.initProxy(returnType, this));
/*     */     }
/*     */ 
/*     */     public Object invoke(MethodInvocation inv)
/*     */       throws Throwable
/*     */     {
/* 405 */       return intercept(inv.getThis(), inv.getMethod(), inv.getArguments(), null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder
 * JD-Core Version:    0.6.2
 */