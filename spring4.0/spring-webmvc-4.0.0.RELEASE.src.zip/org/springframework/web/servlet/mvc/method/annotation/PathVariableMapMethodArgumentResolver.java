/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.bind.annotation.PathVariable;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ import org.springframework.web.servlet.HandlerMapping;
/*    */ 
/*    */ public class PathVariableMapMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 47 */     PathVariable annot = (PathVariable)parameter.getParameterAnnotation(PathVariable.class);
/*    */ 
/* 49 */     return (annot != null) && (Map.class.isAssignableFrom(parameter.getParameterType())) && 
/* 49 */       (!StringUtils.hasText(annot
/* 49 */       .value()));
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 61 */     Map uriTemplateVars = (Map)webRequest
/* 61 */       .getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, 0);
/*    */ 
/* 64 */     if (!CollectionUtils.isEmpty(uriTemplateVars)) {
/* 65 */       return new LinkedHashMap(uriTemplateVars);
/*    */     }
/*    */ 
/* 68 */     return Collections.emptyMap();
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.PathVariableMapMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */