/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.annotation.AbstractNamedValueMethodArgumentResolver;
/*     */ import org.springframework.web.method.annotation.AbstractNamedValueMethodArgumentResolver.NamedValueInfo;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.method.support.UriComponentsContributor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ public class PathVariableMethodArgumentResolver extends AbstractNamedValueMethodArgumentResolver
/*     */   implements UriComponentsContributor
/*     */ {
/*  69 */   private static final TypeDescriptor STRING_TYPE_DESCRIPTOR = TypeDescriptor.valueOf(String.class);
/*     */ 
/*     */   public PathVariableMethodArgumentResolver()
/*     */   {
/*  73 */     super(null);
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  78 */     if (!parameter.hasParameterAnnotation(PathVariable.class)) {
/*  79 */       return false;
/*     */     }
/*  81 */     if (Map.class.isAssignableFrom(parameter.getParameterType())) {
/*  82 */       String paramName = ((PathVariable)parameter.getParameterAnnotation(PathVariable.class)).value();
/*  83 */       return StringUtils.hasText(paramName);
/*     */     }
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*     */   {
/*  90 */     PathVariable annotation = (PathVariable)parameter.getParameterAnnotation(PathVariable.class);
/*  91 */     return new PathVariableNamedValueInfo(annotation, null);
/*     */   }
/*     */ 
/*     */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/*  98 */     Map uriTemplateVars = (Map)request
/*  98 */       .getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, 0);
/*     */ 
/* 100 */     return uriTemplateVars != null ? (String)uriTemplateVars.get(name) : null;
/*     */   }
/*     */ 
/*     */   protected void handleMissingValue(String name, MethodParameter param) throws ServletRequestBindingException
/*     */   {
/* 105 */     String paramType = param.getParameterType().getName();
/* 106 */     throw new ServletRequestBindingException("Missing URI template variable '" + name + "' for method parameter type [" + paramType + "]");
/*     */   }
/*     */ 
/*     */   protected void handleResolvedValue(Object arg, String name, MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest request)
/*     */   {
/* 115 */     String key = View.PATH_VARIABLES;
/* 116 */     int scope = 0;
/* 117 */     Map pathVars = (Map)request.getAttribute(key, scope);
/* 118 */     if (pathVars == null) {
/* 119 */       pathVars = new HashMap();
/* 120 */       request.setAttribute(key, pathVars, scope);
/*     */     }
/* 122 */     pathVars.put(name, arg);
/*     */   }
/*     */ 
/*     */   public void contributeMethodArgument(MethodParameter parameter, Object value, UriComponentsBuilder builder, Map<String, Object> uriVariables, ConversionService conversionService)
/*     */   {
/* 129 */     if (Map.class.isAssignableFrom(parameter.getParameterType())) {
/* 130 */       return;
/*     */     }
/*     */ 
/* 133 */     PathVariable annot = (PathVariable)parameter.getParameterAnnotation(PathVariable.class);
/* 134 */     String name = StringUtils.isEmpty(annot.value()) ? parameter.getParameterName() : annot.value();
/*     */ 
/* 136 */     if (conversionService != null) {
/* 137 */       value = conversionService.convert(value, new TypeDescriptor(parameter), STRING_TYPE_DESCRIPTOR);
/*     */     }
/*     */ 
/* 140 */     uriVariables.put(name, value);
/*     */   }
/*     */ 
/*     */   private static class PathVariableNamedValueInfo extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*     */   {
/*     */     private PathVariableNamedValueInfo(PathVariable annotation)
/*     */     {
/* 147 */       super(true, "\n\t\t\n\t\t\n\n\t\t\t\t\n");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.PathVariableMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */