/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.ui.ModelMap;
/*    */ import org.springframework.validation.DataBinder;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/*    */ import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;
/*    */ 
/*    */ public class RedirectAttributesMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 47 */     return RedirectAttributes.class.isAssignableFrom(parameter.getParameterType());
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 56 */     DataBinder dataBinder = binderFactory.createBinder(webRequest, null, null);
/* 57 */     ModelMap redirectAttributes = new RedirectAttributesModelMap(dataBinder);
/* 58 */     mavContainer.setRedirectModel(redirectAttributes);
/* 59 */     return redirectAttributes;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.RedirectAttributesMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */