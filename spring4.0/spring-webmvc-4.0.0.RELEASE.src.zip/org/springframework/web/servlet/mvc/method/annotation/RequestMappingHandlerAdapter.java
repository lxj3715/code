/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.annotation.InitBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.support.DefaultDataBinderFactory;
/*     */ import org.springframework.web.bind.support.DefaultSessionAttributeStore;
/*     */ import org.springframework.web.bind.support.SessionAttributeStore;
/*     */ import org.springframework.web.bind.support.WebBindingInitializer;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.async.AsyncWebRequest;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.DeferredResultProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.method.ControllerAdviceBean;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.HandlerMethodSelector;
/*     */ import org.springframework.web.method.annotation.ErrorsMethodArgumentResolver;
/*     */ import org.springframework.web.method.annotation.ExpressionValueMethodArgumentResolver;
/*     */ import org.springframework.web.method.annotation.InitBinderDataBinderFactory;
/*     */ import org.springframework.web.method.annotation.MapMethodProcessor;
/*     */ import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
/*     */ import org.springframework.web.method.annotation.ModelFactory;
/*     */ import org.springframework.web.method.annotation.ModelMethodProcessor;
/*     */ import org.springframework.web.method.annotation.RequestHeaderMapMethodArgumentResolver;
/*     */ import org.springframework.web.method.annotation.RequestHeaderMethodArgumentResolver;
/*     */ import org.springframework.web.method.annotation.RequestParamMapMethodArgumentResolver;
/*     */ import org.springframework.web.method.annotation.RequestParamMethodArgumentResolver;
/*     */ import org.springframework.web.method.annotation.SessionAttributesHandler;
/*     */ import org.springframework.web.method.annotation.SessionStatusMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolverComposite;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*     */ import org.springframework.web.method.support.InvocableHandlerMethod;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver;
/*     */ import org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter;
/*     */ import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class RequestMappingHandlerAdapter extends AbstractHandlerMethodAdapter
/*     */   implements BeanFactoryAware, InitializingBean
/*     */ {
/*     */   private List<HandlerMethodArgumentResolver> customArgumentResolvers;
/*     */   private HandlerMethodArgumentResolverComposite argumentResolvers;
/*     */   private HandlerMethodArgumentResolverComposite initBinderArgumentResolvers;
/*     */   private List<HandlerMethodReturnValueHandler> customReturnValueHandlers;
/*     */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*     */   private List<ModelAndViewResolver> modelAndViewResolvers;
/* 132 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*     */   private List<HttpMessageConverter<?>> messageConverters;
/*     */   private WebBindingInitializer webBindingInitializer;
/* 138 */   private AsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor("MvcAsync");
/*     */   private Long asyncRequestTimeout;
/* 142 */   private CallableProcessingInterceptor[] callableInterceptors = new CallableProcessingInterceptor[0];
/*     */ 
/* 144 */   private DeferredResultProcessingInterceptor[] deferredResultInterceptors = new DeferredResultProcessingInterceptor[0];
/*     */ 
/* 146 */   private boolean ignoreDefaultModelOnRedirect = false;
/*     */ 
/* 148 */   private int cacheSecondsForSessionAttributeHandlers = 0;
/*     */ 
/* 150 */   private boolean synchronizeOnSession = false;
/*     */ 
/* 152 */   private SessionAttributeStore sessionAttributeStore = new DefaultSessionAttributeStore();
/*     */ 
/* 154 */   private ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */   private ConfigurableBeanFactory beanFactory;
/* 159 */   private final Map<Class<?>, SessionAttributesHandler> sessionAttributesHandlerCache = new ConcurrentHashMap(64);
/*     */ 
/* 162 */   private final Map<Class<?>, Set<Method>> initBinderCache = new ConcurrentHashMap(64);
/*     */ 
/* 164 */   private final Map<ControllerAdviceBean, Set<Method>> initBinderAdviceCache = new LinkedHashMap();
/*     */ 
/* 167 */   private final Map<Class<?>, Set<Method>> modelAttributeCache = new ConcurrentHashMap(64);
/*     */ 
/* 169 */   private final Map<ControllerAdviceBean, Set<Method>> modelAttributeAdviceCache = new LinkedHashMap();
/*     */ 
/* 873 */   public static final ReflectionUtils.MethodFilter INIT_BINDER_METHODS = new ReflectionUtils.MethodFilter()
/*     */   {
/*     */     public boolean matches(Method method)
/*     */     {
/* 877 */       return AnnotationUtils.findAnnotation(method, InitBinder.class) != null;
/*     */     }
/* 873 */   };
/*     */ 
/* 884 */   public static final ReflectionUtils.MethodFilter MODEL_ATTRIBUTE_METHODS = new ReflectionUtils.MethodFilter()
/*     */   {
/*     */     public boolean matches(Method method)
/*     */     {
/* 889 */       return (AnnotationUtils.findAnnotation(method, RequestMapping.class) == null) && 
/* 889 */         (AnnotationUtils.findAnnotation(method, ModelAttribute.class) != null);
/*     */     }
/* 884 */   };
/*     */ 
/*     */   public RequestMappingHandlerAdapter()
/*     */   {
/* 178 */     StringHttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter();
/* 179 */     stringHttpMessageConverter.setWriteAcceptCharset(false);
/*     */ 
/* 181 */     this.messageConverters = new ArrayList();
/* 182 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 183 */     this.messageConverters.add(stringHttpMessageConverter);
/* 184 */     this.messageConverters.add(new SourceHttpMessageConverter());
/* 185 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public void setCustomArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 194 */     this.customArgumentResolvers = argumentResolvers;
/*     */   }
/*     */ 
/*     */   public List<HandlerMethodArgumentResolver> getCustomArgumentResolvers()
/*     */   {
/* 201 */     return this.customArgumentResolvers;
/*     */   }
/*     */ 
/*     */   public void setArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 209 */     if (argumentResolvers == null) {
/* 210 */       this.argumentResolvers = null;
/*     */     }
/*     */     else {
/* 213 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite();
/* 214 */       this.argumentResolvers.addResolvers(argumentResolvers);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<HandlerMethodArgumentResolver> getArgumentResolvers()
/*     */   {
/* 223 */     return this.argumentResolvers != null ? this.argumentResolvers.getResolvers() : null;
/*     */   }
/*     */ 
/*     */   public void setInitBinderArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 230 */     if (argumentResolvers == null) {
/* 231 */       this.initBinderArgumentResolvers = null;
/*     */     }
/*     */     else {
/* 234 */       this.initBinderArgumentResolvers = new HandlerMethodArgumentResolverComposite();
/* 235 */       this.initBinderArgumentResolvers.addResolvers(argumentResolvers);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<HandlerMethodArgumentResolver> getInitBinderArgumentResolvers()
/*     */   {
/* 244 */     return this.initBinderArgumentResolvers != null ? this.initBinderArgumentResolvers.getResolvers() : null;
/*     */   }
/*     */ 
/*     */   public void setCustomReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 253 */     this.customReturnValueHandlers = returnValueHandlers;
/*     */   }
/*     */ 
/*     */   public List<HandlerMethodReturnValueHandler> getCustomReturnValueHandlers()
/*     */   {
/* 260 */     return this.customReturnValueHandlers;
/*     */   }
/*     */ 
/*     */   public void setReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 268 */     if (returnValueHandlers == null) {
/* 269 */       this.returnValueHandlers = null;
/*     */     }
/*     */     else {
/* 272 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite();
/* 273 */       this.returnValueHandlers.addHandlers(returnValueHandlers);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<HandlerMethodReturnValueHandler> getReturnValueHandlers()
/*     */   {
/* 282 */     return this.returnValueHandlers.getHandlers();
/*     */   }
/*     */ 
/*     */   public void setModelAndViewResolvers(List<ModelAndViewResolver> modelAndViewResolvers)
/*     */   {
/* 300 */     this.modelAndViewResolvers = modelAndViewResolvers;
/*     */   }
/*     */ 
/*     */   public List<ModelAndViewResolver> getModelAndViewResolvers()
/*     */   {
/* 307 */     return this.modelAndViewResolvers;
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 316 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 324 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 331 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   public void setWebBindingInitializer(WebBindingInitializer webBindingInitializer)
/*     */   {
/* 339 */     this.webBindingInitializer = webBindingInitializer;
/*     */   }
/*     */ 
/*     */   public WebBindingInitializer getWebBindingInitializer()
/*     */   {
/* 346 */     return this.webBindingInitializer;
/*     */   }
/*     */ 
/*     */   public void setTaskExecutor(AsyncTaskExecutor taskExecutor)
/*     */   {
/* 358 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */   public void setAsyncRequestTimeout(long timeout)
/*     */   {
/* 371 */     this.asyncRequestTimeout = Long.valueOf(timeout);
/*     */   }
/*     */ 
/*     */   public void setCallableInterceptors(List<CallableProcessingInterceptor> interceptors)
/*     */   {
/* 379 */     Assert.notNull(interceptors);
/* 380 */     this.callableInterceptors = ((CallableProcessingInterceptor[])interceptors.toArray(new CallableProcessingInterceptor[interceptors.size()]));
/*     */   }
/*     */ 
/*     */   public void setDeferredResultInterceptors(List<DeferredResultProcessingInterceptor> interceptors)
/*     */   {
/* 388 */     Assert.notNull(interceptors);
/* 389 */     this.deferredResultInterceptors = ((DeferredResultProcessingInterceptor[])interceptors.toArray(new DeferredResultProcessingInterceptor[interceptors.size()]));
/*     */   }
/*     */ 
/*     */   public void setIgnoreDefaultModelOnRedirect(boolean ignoreDefaultModelOnRedirect)
/*     */   {
/* 407 */     this.ignoreDefaultModelOnRedirect = ignoreDefaultModelOnRedirect;
/*     */   }
/*     */ 
/*     */   public void setSessionAttributeStore(SessionAttributeStore sessionAttributeStore)
/*     */   {
/* 417 */     this.sessionAttributeStore = sessionAttributeStore;
/*     */   }
/*     */ 
/*     */   public void setCacheSecondsForSessionAttributeHandlers(int cacheSecondsForSessionAttributeHandlers)
/*     */   {
/* 430 */     this.cacheSecondsForSessionAttributeHandlers = cacheSecondsForSessionAttributeHandlers;
/*     */   }
/*     */ 
/*     */   public void setSynchronizeOnSession(boolean synchronizeOnSession)
/*     */   {
/* 452 */     this.synchronizeOnSession = synchronizeOnSession;
/*     */   }
/*     */ 
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 461 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 471 */     if ((beanFactory instanceof ConfigurableBeanFactory))
/* 472 */       this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*     */   }
/*     */ 
/*     */   protected ConfigurableBeanFactory getBeanFactory()
/*     */   {
/* 480 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 485 */     if (this.argumentResolvers == null) {
/* 486 */       List resolvers = getDefaultArgumentResolvers();
/* 487 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite().addResolvers(resolvers);
/*     */     }
/* 489 */     if (this.initBinderArgumentResolvers == null) {
/* 490 */       List resolvers = getDefaultInitBinderArgumentResolvers();
/* 491 */       this.initBinderArgumentResolvers = new HandlerMethodArgumentResolverComposite().addResolvers(resolvers);
/*     */     }
/* 493 */     if (this.returnValueHandlers == null) {
/* 494 */       List handlers = getDefaultReturnValueHandlers();
/* 495 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite().addHandlers(handlers);
/*     */     }
/* 497 */     initControllerAdviceCache();
/*     */   }
/*     */ 
/*     */   private List<HandlerMethodArgumentResolver> getDefaultArgumentResolvers()
/*     */   {
/* 505 */     List resolvers = new ArrayList();
/*     */ 
/* 508 */     resolvers.add(new RequestParamMethodArgumentResolver(getBeanFactory(), false));
/* 509 */     resolvers.add(new RequestParamMapMethodArgumentResolver());
/* 510 */     resolvers.add(new PathVariableMethodArgumentResolver());
/* 511 */     resolvers.add(new PathVariableMapMethodArgumentResolver());
/* 512 */     resolvers.add(new MatrixVariableMethodArgumentResolver());
/* 513 */     resolvers.add(new MatrixVariableMapMethodArgumentResolver());
/* 514 */     resolvers.add(new ServletModelAttributeMethodProcessor(false));
/* 515 */     resolvers.add(new RequestResponseBodyMethodProcessor(getMessageConverters()));
/* 516 */     resolvers.add(new RequestPartMethodArgumentResolver(getMessageConverters()));
/* 517 */     resolvers.add(new RequestHeaderMethodArgumentResolver(getBeanFactory()));
/* 518 */     resolvers.add(new RequestHeaderMapMethodArgumentResolver());
/* 519 */     resolvers.add(new ServletCookieValueMethodArgumentResolver(getBeanFactory()));
/* 520 */     resolvers.add(new ExpressionValueMethodArgumentResolver(getBeanFactory()));
/*     */ 
/* 523 */     resolvers.add(new ServletRequestMethodArgumentResolver());
/* 524 */     resolvers.add(new ServletResponseMethodArgumentResolver());
/* 525 */     resolvers.add(new HttpEntityMethodProcessor(getMessageConverters()));
/* 526 */     resolvers.add(new RedirectAttributesMethodArgumentResolver());
/* 527 */     resolvers.add(new ModelMethodProcessor());
/* 528 */     resolvers.add(new MapMethodProcessor());
/* 529 */     resolvers.add(new ErrorsMethodArgumentResolver());
/* 530 */     resolvers.add(new SessionStatusMethodArgumentResolver());
/* 531 */     resolvers.add(new UriComponentsBuilderMethodArgumentResolver());
/*     */ 
/* 534 */     if (getCustomArgumentResolvers() != null) {
/* 535 */       resolvers.addAll(getCustomArgumentResolvers());
/*     */     }
/*     */ 
/* 539 */     resolvers.add(new RequestParamMethodArgumentResolver(getBeanFactory(), true));
/* 540 */     resolvers.add(new ServletModelAttributeMethodProcessor(true));
/*     */ 
/* 542 */     return resolvers;
/*     */   }
/*     */ 
/*     */   private List<HandlerMethodArgumentResolver> getDefaultInitBinderArgumentResolvers()
/*     */   {
/* 550 */     List resolvers = new ArrayList();
/*     */ 
/* 553 */     resolvers.add(new RequestParamMethodArgumentResolver(getBeanFactory(), false));
/* 554 */     resolvers.add(new RequestParamMapMethodArgumentResolver());
/* 555 */     resolvers.add(new PathVariableMethodArgumentResolver());
/* 556 */     resolvers.add(new PathVariableMapMethodArgumentResolver());
/* 557 */     resolvers.add(new MatrixVariableMethodArgumentResolver());
/* 558 */     resolvers.add(new MatrixVariableMapMethodArgumentResolver());
/* 559 */     resolvers.add(new ExpressionValueMethodArgumentResolver(getBeanFactory()));
/*     */ 
/* 562 */     resolvers.add(new ServletRequestMethodArgumentResolver());
/* 563 */     resolvers.add(new ServletResponseMethodArgumentResolver());
/*     */ 
/* 566 */     if (getCustomArgumentResolvers() != null) {
/* 567 */       resolvers.addAll(getCustomArgumentResolvers());
/*     */     }
/*     */ 
/* 571 */     resolvers.add(new RequestParamMethodArgumentResolver(getBeanFactory(), true));
/*     */ 
/* 573 */     return resolvers;
/*     */   }
/*     */ 
/*     */   private List<HandlerMethodReturnValueHandler> getDefaultReturnValueHandlers()
/*     */   {
/* 581 */     List handlers = new ArrayList();
/*     */ 
/* 584 */     handlers.add(new ModelAndViewMethodReturnValueHandler());
/* 585 */     handlers.add(new ModelMethodProcessor());
/* 586 */     handlers.add(new ViewMethodReturnValueHandler());
/* 587 */     handlers.add(new HttpEntityMethodProcessor(getMessageConverters(), this.contentNegotiationManager));
/* 588 */     handlers.add(new CallableMethodReturnValueHandler());
/* 589 */     handlers.add(new DeferredResultMethodReturnValueHandler());
/* 590 */     handlers.add(new AsyncTaskMethodReturnValueHandler(this.beanFactory));
/*     */ 
/* 593 */     handlers.add(new ModelAttributeMethodProcessor(false));
/* 594 */     handlers.add(new RequestResponseBodyMethodProcessor(getMessageConverters(), this.contentNegotiationManager));
/*     */ 
/* 597 */     handlers.add(new ViewNameMethodReturnValueHandler());
/* 598 */     handlers.add(new MapMethodProcessor());
/*     */ 
/* 601 */     if (getCustomReturnValueHandlers() != null) {
/* 602 */       handlers.addAll(getCustomReturnValueHandlers());
/*     */     }
/*     */ 
/* 606 */     if (!CollectionUtils.isEmpty(getModelAndViewResolvers())) {
/* 607 */       handlers.add(new ModelAndViewResolverMethodReturnValueHandler(getModelAndViewResolvers()));
/*     */     }
/*     */     else {
/* 610 */       handlers.add(new ModelAttributeMethodProcessor(true));
/*     */     }
/*     */ 
/* 613 */     return handlers;
/*     */   }
/*     */ 
/*     */   private void initControllerAdviceCache() {
/* 617 */     if (getApplicationContext() == null) {
/* 618 */       return;
/*     */     }
/* 620 */     if (this.logger.isDebugEnabled()) {
/* 621 */       this.logger.debug("Looking for controller advice: " + getApplicationContext());
/*     */     }
/*     */ 
/* 624 */     List beans = ControllerAdviceBean.findAnnotatedBeans(getApplicationContext());
/* 625 */     Collections.sort(beans, new OrderComparator());
/*     */ 
/* 627 */     for (ControllerAdviceBean bean : beans) {
/* 628 */       Set attrMethods = HandlerMethodSelector.selectMethods(bean.getBeanType(), MODEL_ATTRIBUTE_METHODS);
/* 629 */       if (!attrMethods.isEmpty()) {
/* 630 */         this.modelAttributeAdviceCache.put(bean, attrMethods);
/* 631 */         this.logger.info("Detected @ModelAttribute methods in " + bean);
/*     */       }
/* 633 */       Set binderMethods = HandlerMethodSelector.selectMethods(bean.getBeanType(), INIT_BINDER_METHODS);
/* 634 */       if (!binderMethods.isEmpty()) {
/* 635 */         this.initBinderAdviceCache.put(bean, binderMethods);
/* 636 */         this.logger.info("Detected @InitBinder methods in " + bean);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean supportsInternal(HandlerMethod handlerMethod)
/*     */   {
/* 651 */     return true;
/*     */   }
/*     */ 
/*     */   protected long getLastModifiedInternal(HttpServletRequest request, HandlerMethod handlerMethod)
/*     */   {
/* 662 */     return -1L;
/*     */   }
/*     */ 
/*     */   protected final ModelAndView handleInternal(HttpServletRequest request, HttpServletResponse response, HandlerMethod handlerMethod)
/*     */     throws Exception
/*     */   {
/* 669 */     if (getSessionAttributesHandler(handlerMethod).hasSessionAttributes())
/*     */     {
/* 671 */       checkAndPrepare(request, response, this.cacheSecondsForSessionAttributeHandlers, true);
/*     */     }
/*     */     else
/*     */     {
/* 675 */       checkAndPrepare(request, response, true);
/*     */     }
/*     */ 
/* 679 */     if (this.synchronizeOnSession) {
/* 680 */       HttpSession session = request.getSession(false);
/* 681 */       if (session != null) {
/* 682 */         Object mutex = WebUtils.getSessionMutex(session);
/* 683 */         synchronized (mutex) {
/* 684 */           return invokeHandleMethod(request, response, handlerMethod);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 689 */     return invokeHandleMethod(request, response, handlerMethod);
/*     */   }
/*     */ 
/*     */   private SessionAttributesHandler getSessionAttributesHandler(HandlerMethod handlerMethod)
/*     */   {
/* 697 */     Class handlerType = handlerMethod.getBeanType();
/* 698 */     SessionAttributesHandler sessionAttrHandler = (SessionAttributesHandler)this.sessionAttributesHandlerCache.get(handlerType);
/* 699 */     if (sessionAttrHandler == null) {
/* 700 */       synchronized (this.sessionAttributesHandlerCache) {
/* 701 */         sessionAttrHandler = (SessionAttributesHandler)this.sessionAttributesHandlerCache.get(handlerType);
/* 702 */         if (sessionAttrHandler == null) {
/* 703 */           sessionAttrHandler = new SessionAttributesHandler(handlerType, this.sessionAttributeStore);
/* 704 */           this.sessionAttributesHandlerCache.put(handlerType, sessionAttrHandler);
/*     */         }
/*     */       }
/*     */     }
/* 708 */     return sessionAttrHandler;
/*     */   }
/*     */ 
/*     */   private ModelAndView invokeHandleMethod(HttpServletRequest request, HttpServletResponse response, HandlerMethod handlerMethod)
/*     */     throws Exception
/*     */   {
/* 717 */     ServletWebRequest webRequest = new ServletWebRequest(request, response);
/*     */ 
/* 719 */     WebDataBinderFactory binderFactory = getDataBinderFactory(handlerMethod);
/* 720 */     ModelFactory modelFactory = getModelFactory(handlerMethod, binderFactory);
/* 721 */     ServletInvocableHandlerMethod requestMappingMethod = createRequestMappingMethod(handlerMethod, binderFactory);
/*     */ 
/* 723 */     ModelAndViewContainer mavContainer = new ModelAndViewContainer();
/* 724 */     mavContainer.addAllAttributes(RequestContextUtils.getInputFlashMap(request));
/* 725 */     modelFactory.initModel(webRequest, mavContainer, requestMappingMethod);
/* 726 */     mavContainer.setIgnoreDefaultModelOnRedirect(this.ignoreDefaultModelOnRedirect);
/*     */ 
/* 728 */     AsyncWebRequest asyncWebRequest = WebAsyncUtils.createAsyncWebRequest(request, response);
/* 729 */     asyncWebRequest.setTimeout(this.asyncRequestTimeout);
/*     */ 
/* 731 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager(request);
/* 732 */     asyncManager.setTaskExecutor(this.taskExecutor);
/* 733 */     asyncManager.setAsyncWebRequest(asyncWebRequest);
/* 734 */     asyncManager.registerCallableInterceptors(this.callableInterceptors);
/* 735 */     asyncManager.registerDeferredResultInterceptors(this.deferredResultInterceptors);
/*     */ 
/* 737 */     if (asyncManager.hasConcurrentResult()) {
/* 738 */       Object result = asyncManager.getConcurrentResult();
/* 739 */       mavContainer = (ModelAndViewContainer)asyncManager.getConcurrentResultContext()[0];
/* 740 */       asyncManager.clearConcurrentResult();
/*     */ 
/* 742 */       if (this.logger.isDebugEnabled()) {
/* 743 */         this.logger.debug("Found concurrent result value [" + result + "]");
/*     */       }
/* 745 */       requestMappingMethod = requestMappingMethod.wrapConcurrentResult(result);
/*     */     }
/*     */ 
/* 748 */     requestMappingMethod.invokeAndHandle(webRequest, mavContainer, new Object[0]);
/*     */ 
/* 750 */     if (asyncManager.isConcurrentHandlingStarted()) {
/* 751 */       return null;
/*     */     }
/*     */ 
/* 754 */     return getModelAndView(mavContainer, modelFactory, webRequest);
/*     */   }
/*     */ 
/*     */   private ServletInvocableHandlerMethod createRequestMappingMethod(HandlerMethod handlerMethod, WebDataBinderFactory binderFactory)
/*     */   {
/* 761 */     ServletInvocableHandlerMethod requestMethod = new ServletInvocableHandlerMethod(handlerMethod);
/* 762 */     requestMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
/* 763 */     requestMethod.setHandlerMethodReturnValueHandlers(this.returnValueHandlers);
/* 764 */     requestMethod.setDataBinderFactory(binderFactory);
/* 765 */     requestMethod.setParameterNameDiscoverer(this.parameterNameDiscoverer);
/* 766 */     return requestMethod;
/*     */   }
/*     */ 
/*     */   private ModelFactory getModelFactory(HandlerMethod handlerMethod, WebDataBinderFactory binderFactory) {
/* 770 */     SessionAttributesHandler sessionAttrHandler = getSessionAttributesHandler(handlerMethod);
/* 771 */     Class handlerType = handlerMethod.getBeanType();
/* 772 */     Set methods = (Set)this.modelAttributeCache.get(handlerType);
/* 773 */     if (methods == null) {
/* 774 */       methods = HandlerMethodSelector.selectMethods(handlerType, MODEL_ATTRIBUTE_METHODS);
/* 775 */       this.modelAttributeCache.put(handlerType, methods);
/*     */     }
/* 777 */     List attrMethods = new ArrayList();
/*     */ 
/* 779 */     for (Map.Entry entry : this.modelAttributeAdviceCache.entrySet())
/* 780 */       if (((ControllerAdviceBean)entry.getKey()).isApplicableToBeanType(handlerType)) {
/* 781 */         bean = ((ControllerAdviceBean)entry.getKey()).resolveBean();
/* 782 */         for (Method method : (Set)entry.getValue())
/* 783 */           attrMethods.add(createModelAttributeMethod(binderFactory, bean, method));
/*     */       }
/*     */     Object bean;
/* 787 */     for (Method method : methods) {
/* 788 */       Object bean = handlerMethod.getBean();
/* 789 */       attrMethods.add(createModelAttributeMethod(binderFactory, bean, method));
/*     */     }
/* 791 */     return new ModelFactory(attrMethods, binderFactory, sessionAttrHandler);
/*     */   }
/*     */ 
/*     */   private InvocableHandlerMethod createModelAttributeMethod(WebDataBinderFactory factory, Object bean, Method method) {
/* 795 */     InvocableHandlerMethod attrMethod = new InvocableHandlerMethod(bean, method);
/* 796 */     attrMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
/* 797 */     attrMethod.setParameterNameDiscoverer(this.parameterNameDiscoverer);
/* 798 */     attrMethod.setDataBinderFactory(factory);
/* 799 */     return attrMethod;
/*     */   }
/*     */ 
/*     */   private WebDataBinderFactory getDataBinderFactory(HandlerMethod handlerMethod) throws Exception {
/* 803 */     Class handlerType = handlerMethod.getBeanType();
/* 804 */     Set methods = (Set)this.initBinderCache.get(handlerType);
/* 805 */     if (methods == null) {
/* 806 */       methods = HandlerMethodSelector.selectMethods(handlerType, INIT_BINDER_METHODS);
/* 807 */       this.initBinderCache.put(handlerType, methods);
/*     */     }
/* 809 */     List initBinderMethods = new ArrayList();
/*     */ 
/* 811 */     for (Map.Entry entry : this.initBinderAdviceCache.entrySet())
/* 812 */       if (((ControllerAdviceBean)entry.getKey()).isApplicableToBeanType(handlerType)) {
/* 813 */         bean = ((ControllerAdviceBean)entry.getKey()).resolveBean();
/* 814 */         for (Method method : (Set)entry.getValue())
/* 815 */           initBinderMethods.add(createInitBinderMethod(bean, method));
/*     */       }
/*     */     Object bean;
/* 819 */     for (Method method : methods) {
/* 820 */       Object bean = handlerMethod.getBean();
/* 821 */       initBinderMethods.add(createInitBinderMethod(bean, method));
/*     */     }
/* 823 */     return createDataBinderFactory(initBinderMethods);
/*     */   }
/*     */ 
/*     */   private InvocableHandlerMethod createInitBinderMethod(Object bean, Method method) {
/* 827 */     InvocableHandlerMethod binderMethod = new InvocableHandlerMethod(bean, method);
/* 828 */     binderMethod.setHandlerMethodArgumentResolvers(this.initBinderArgumentResolvers);
/* 829 */     binderMethod.setDataBinderFactory(new DefaultDataBinderFactory(this.webBindingInitializer));
/* 830 */     binderMethod.setParameterNameDiscoverer(this.parameterNameDiscoverer);
/* 831 */     return binderMethod;
/*     */   }
/*     */ 
/*     */   protected InitBinderDataBinderFactory createDataBinderFactory(List<InvocableHandlerMethod> binderMethods)
/*     */     throws Exception
/*     */   {
/* 845 */     return new ServletRequestDataBinderFactory(binderMethods, getWebBindingInitializer());
/*     */   }
/*     */ 
/*     */   private ModelAndView getModelAndView(ModelAndViewContainer mavContainer, ModelFactory modelFactory, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 851 */     modelFactory.updateModel(webRequest, mavContainer);
/*     */ 
/* 853 */     if (mavContainer.isRequestHandled()) {
/* 854 */       return null;
/*     */     }
/* 856 */     ModelMap model = mavContainer.getModel();
/* 857 */     ModelAndView mav = new ModelAndView(mavContainer.getViewName(), model);
/* 858 */     if (!mavContainer.isViewReference()) {
/* 859 */       mav.setView((View)mavContainer.getView());
/*     */     }
/* 861 */     if ((model instanceof RedirectAttributes)) {
/* 862 */       Map flashAttributes = ((RedirectAttributes)model).getFlashAttributes();
/* 863 */       HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 864 */       RequestContextUtils.getOutputFlashMap(request).putAll(flashAttributes);
/*     */     }
/* 866 */     return mav;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter
 * JD-Core Version:    0.6.2
 */