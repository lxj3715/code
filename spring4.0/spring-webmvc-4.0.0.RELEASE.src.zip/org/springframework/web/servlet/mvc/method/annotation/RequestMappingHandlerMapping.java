/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.HeadersRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.ParamsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.ProducesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfoHandlerMapping;
/*     */ 
/*     */ public class RequestMappingHandlerMapping extends RequestMappingInfoHandlerMapping
/*     */   implements EmbeddedValueResolverAware
/*     */ {
/*  54 */   private boolean useSuffixPatternMatch = true;
/*     */ 
/*  56 */   private boolean useRegisteredSuffixPatternMatch = false;
/*     */ 
/*  58 */   private boolean useTrailingSlashMatch = true;
/*     */ 
/*  60 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*     */ 
/*  62 */   private final List<String> fileExtensions = new ArrayList();
/*     */   private StringValueResolver embeddedValueResolver;
/*     */ 
/*     */   public void setUseSuffixPatternMatch(boolean useSuffixPatternMatch)
/*     */   {
/*  75 */     this.useSuffixPatternMatch = useSuffixPatternMatch;
/*     */   }
/*     */ 
/*     */   public void setUseRegisteredSuffixPatternMatch(boolean useRegsiteredSuffixPatternMatch)
/*     */   {
/*  96 */     this.useRegisteredSuffixPatternMatch = useRegsiteredSuffixPatternMatch;
/*  97 */     this.useSuffixPatternMatch = (useRegsiteredSuffixPatternMatch ? true : this.useSuffixPatternMatch);
/*     */   }
/*     */ 
/*     */   public void setUseTrailingSlashMatch(boolean useTrailingSlashMatch)
/*     */   {
/* 106 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/*     */   }
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/* 111 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 119 */     Assert.notNull(contentNegotiationManager);
/* 120 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   public boolean useSuffixPatternMatch()
/*     */   {
/* 127 */     return this.useSuffixPatternMatch;
/*     */   }
/*     */ 
/*     */   public boolean useRegisteredSuffixPatternMatch()
/*     */   {
/* 134 */     return this.useRegisteredSuffixPatternMatch;
/*     */   }
/*     */ 
/*     */   public boolean useTrailingSlashMatch()
/*     */   {
/* 141 */     return this.useTrailingSlashMatch;
/*     */   }
/*     */ 
/*     */   public ContentNegotiationManager getContentNegotiationManager()
/*     */   {
/* 148 */     return this.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   public List<String> getFileExtensions()
/*     */   {
/* 155 */     return this.fileExtensions;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 160 */     if (this.useRegisteredSuffixPatternMatch) {
/* 161 */       this.fileExtensions.addAll(this.contentNegotiationManager.getAllFileExtensions());
/*     */     }
/* 163 */     super.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   protected boolean isHandler(Class<?> beanType)
/*     */   {
/* 173 */     return (AnnotationUtils.findAnnotation(beanType, Controller.class) != null) || 
/* 173 */       (AnnotationUtils.findAnnotation(beanType, RequestMapping.class) != null);
/*     */   }
/*     */ 
/*     */   protected RequestMappingInfo getMappingForMethod(Method method, Class<?> handlerType)
/*     */   {
/* 188 */     RequestMappingInfo info = null;
/* 189 */     RequestMapping methodAnnotation = (RequestMapping)AnnotationUtils.findAnnotation(method, RequestMapping.class);
/* 190 */     if (methodAnnotation != null) {
/* 191 */       RequestCondition methodCondition = getCustomMethodCondition(method);
/* 192 */       info = createRequestMappingInfo(methodAnnotation, methodCondition);
/* 193 */       RequestMapping typeAnnotation = (RequestMapping)AnnotationUtils.findAnnotation(handlerType, RequestMapping.class);
/* 194 */       if (typeAnnotation != null) {
/* 195 */         RequestCondition typeCondition = getCustomTypeCondition(handlerType);
/* 196 */         info = createRequestMappingInfo(typeAnnotation, typeCondition).combine(info);
/*     */       }
/*     */     }
/* 199 */     return info;
/*     */   }
/*     */ 
/*     */   protected RequestCondition<?> getCustomTypeCondition(Class<?> handlerType)
/*     */   {
/* 216 */     return null;
/*     */   }
/*     */ 
/*     */   protected RequestCondition<?> getCustomMethodCondition(Method method)
/*     */   {
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */   protected RequestMappingInfo createRequestMappingInfo(RequestMapping annotation, RequestCondition<?> customCondition)
/*     */   {
/* 242 */     String[] patterns = resolveEmbeddedValuesInPatterns(annotation.value());
/*     */ 
/* 250 */     return new RequestMappingInfo(new PatternsRequestCondition(patterns, 
/* 244 */       getUrlPathHelper(), getPathMatcher(), this.useSuffixPatternMatch, this.useTrailingSlashMatch, this.fileExtensions), new RequestMethodsRequestCondition(annotation
/* 246 */       .method()), new ParamsRequestCondition(annotation
/* 247 */       .params()), new HeadersRequestCondition(annotation
/* 248 */       .headers()), new ConsumesRequestCondition(annotation
/* 249 */       .consumes(), annotation.headers()), new ProducesRequestCondition(annotation
/* 250 */       .produces(), annotation.headers(), getContentNegotiationManager()), customCondition);
/*     */   }
/*     */ 
/*     */   protected String[] resolveEmbeddedValuesInPatterns(String[] patterns)
/*     */   {
/* 259 */     if (this.embeddedValueResolver == null) {
/* 260 */       return patterns;
/*     */     }
/*     */ 
/* 263 */     String[] resolvedPatterns = new String[patterns.length];
/* 264 */     for (int i = 0; i < patterns.length; i++) {
/* 265 */       resolvedPatterns[i] = this.embeddedValueResolver.resolveStringValue(patterns[i]);
/*     */     }
/* 267 */     return resolvedPatterns;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping
 * JD-Core Version:    0.6.2
 */