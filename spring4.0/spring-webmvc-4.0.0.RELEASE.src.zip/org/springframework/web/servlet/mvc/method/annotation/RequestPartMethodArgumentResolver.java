/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.core.GenericCollectionTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.annotation.RequestPart;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.multipart.support.RequestPartServletServerHttpRequest;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class RequestPartMethodArgumentResolver extends AbstractMessageConverterMethodArgumentResolver
/*     */ {
/*     */   public RequestPartMethodArgumentResolver(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  81 */     super(messageConverters);
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  94 */     if (parameter.hasParameterAnnotation(RequestPart.class)) {
/*  95 */       return true;
/*     */     }
/*     */ 
/*  98 */     if (parameter.hasParameterAnnotation(RequestParam.class)) {
/*  99 */       return false;
/*     */     }
/* 101 */     if (MultipartFile.class.equals(parameter.getParameterType())) {
/* 102 */       return true;
/*     */     }
/* 104 */     if ("javax.servlet.http.Part".equals(parameter.getParameterType().getName())) {
/* 105 */       return true;
/*     */     }
/*     */ 
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest request, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 117 */     HttpServletRequest servletRequest = (HttpServletRequest)request.getNativeRequest(HttpServletRequest.class);
/* 118 */     assertIsMultipartRequest(servletRequest);
/*     */ 
/* 121 */     MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)WebUtils.getNativeRequest(servletRequest, MultipartHttpServletRequest.class);
/*     */ 
/* 123 */     String partName = getPartName(parameter);
/*     */     Object arg;
/*     */     Object arg;
/* 126 */     if (MultipartFile.class.equals(parameter.getParameterType())) {
/* 127 */       Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 128 */       arg = multipartRequest.getFile(partName);
/*     */     }
/*     */     else
/*     */     {
/*     */       Object arg;
/* 130 */       if (isMultipartFileCollection(parameter)) {
/* 131 */         Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 132 */         arg = multipartRequest.getFiles(partName);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object arg;
/* 134 */         if ("javax.servlet.http.Part".equals(parameter.getParameterType().getName())) {
/* 135 */           assertIsMultipartRequest(servletRequest);
/* 136 */           arg = servletRequest.getPart(partName);
/*     */         }
/*     */         else
/*     */         {
/*     */           Object arg;
/* 138 */           if (isPartCollection(parameter)) {
/* 139 */             assertIsMultipartRequest(servletRequest);
/* 140 */             arg = new ArrayList(servletRequest.getParts());
/*     */           }
/*     */           else {
/*     */             try {
/* 144 */               HttpInputMessage inputMessage = new RequestPartServletServerHttpRequest(servletRequest, partName);
/* 145 */               Object arg = readWithMessageConverters(inputMessage, parameter, parameter.getParameterType());
/* 146 */               WebDataBinder binder = binderFactory.createBinder(request, arg, partName);
/* 147 */               if (arg != null) {
/* 148 */                 validate(binder, parameter);
/*     */               }
/* 150 */               mavContainer.addAttribute(BindingResult.MODEL_KEY_PREFIX + partName, binder.getBindingResult());
/*     */             }
/*     */             catch (MissingServletRequestPartException ex)
/*     */             {
/* 154 */               arg = null;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 158 */     RequestPart annot = (RequestPart)parameter.getParameterAnnotation(RequestPart.class);
/* 159 */     boolean isRequired = (annot == null) || (annot.required());
/*     */ 
/* 161 */     if ((arg == null) && (isRequired)) {
/* 162 */       throw new MissingServletRequestPartException(partName);
/*     */     }
/*     */ 
/* 165 */     return arg;
/*     */   }
/*     */ 
/*     */   private static void assertIsMultipartRequest(HttpServletRequest request) {
/* 169 */     String contentType = request.getContentType();
/* 170 */     if ((contentType == null) || (!contentType.toLowerCase().startsWith("multipart/")))
/* 171 */       throw new MultipartException("The current request is not a multipart request");
/*     */   }
/*     */ 
/*     */   private String getPartName(MethodParameter parameter)
/*     */   {
/* 176 */     RequestPart annot = (RequestPart)parameter.getParameterAnnotation(RequestPart.class);
/* 177 */     String partName = annot != null ? annot.value() : "";
/* 178 */     if (partName.length() == 0) {
/* 179 */       partName = parameter.getParameterName();
/* 180 */       Assert.notNull(partName, "Request part name for argument type [" + parameter.getParameterType().getName() + "] not available, and parameter name information not found in class file either.");
/*     */     }
/*     */ 
/* 183 */     return partName;
/*     */   }
/*     */ 
/*     */   private boolean isMultipartFileCollection(MethodParameter parameter) {
/* 187 */     Class collectionType = getCollectionParameterType(parameter);
/* 188 */     return (collectionType != null) && (collectionType.equals(MultipartFile.class));
/*     */   }
/*     */ 
/*     */   private boolean isPartCollection(MethodParameter parameter) {
/* 192 */     Class collectionType = getCollectionParameterType(parameter);
/* 193 */     return (collectionType != null) && ("javax.servlet.http.Part".equals(collectionType.getName()));
/*     */   }
/*     */ 
/*     */   private Class<?> getCollectionParameterType(MethodParameter parameter) {
/* 197 */     Class paramType = parameter.getParameterType();
/* 198 */     if ((Collection.class.equals(paramType)) || (List.class.isAssignableFrom(paramType))) {
/* 199 */       Class valueType = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 200 */       if (valueType != null) {
/* 201 */         return valueType;
/*     */       }
/*     */     }
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */   private void validate(WebDataBinder binder, MethodParameter parameter) throws MethodArgumentNotValidException
/*     */   {
/* 209 */     Annotation[] annotations = parameter.getParameterAnnotations();
/* 210 */     for (Annotation annot : annotations)
/* 211 */       if (annot.annotationType().getSimpleName().startsWith("Valid")) {
/* 212 */         Object hints = AnnotationUtils.getValue(annot);
/* 213 */         binder.validate(new Object[] { (hints instanceof Object[]) ? (Object[])hints : hints });
/* 214 */         BindingResult bindingResult = binder.getBindingResult();
/* 215 */         if ((bindingResult.hasErrors()) && 
/* 216 */           (isBindExceptionRequired(binder, parameter)))
/* 217 */           throw new MethodArgumentNotValidException(parameter, bindingResult);
/*     */       }
/*     */   }
/*     */ 
/*     */   private boolean isBindExceptionRequired(WebDataBinder binder, MethodParameter parameter)
/*     */   {
/* 231 */     int i = parameter.getParameterIndex();
/* 232 */     Class[] paramTypes = parameter.getMethod().getParameterTypes();
/* 233 */     boolean hasBindingResult = (paramTypes.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/*     */ 
/* 235 */     return !hasBindingResult;
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.RequestPartMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */