/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public class RequestResponseBodyMethodProcessor extends AbstractMessageConverterMethodProcessor
/*     */ {
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  67 */     super(messageConverters);
/*     */   }
/*     */ 
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> messageConverters, ContentNegotiationManager contentNegotiationManager)
/*     */   {
/*  73 */     super(messageConverters, contentNegotiationManager);
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  78 */     return parameter.hasParameterAnnotation(RequestBody.class);
/*     */   }
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*  84 */     return (AnnotationUtils.findAnnotation(returnType.getContainingClass(), ResponseBody.class) != null) || 
/*  84 */       (returnType
/*  84 */       .getMethodAnnotation(ResponseBody.class) != null);
/*     */   }
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/*  98 */     Object argument = readWithMessageConverters(webRequest, parameter, parameter.getGenericParameterType());
/*     */ 
/* 100 */     String name = Conventions.getVariableNameForParameter(parameter);
/* 101 */     WebDataBinder binder = binderFactory.createBinder(webRequest, argument, name);
/*     */ 
/* 103 */     if (argument != null) {
/* 104 */       validate(binder, parameter);
/*     */     }
/*     */ 
/* 107 */     mavContainer.addAttribute(BindingResult.MODEL_KEY_PREFIX + name, binder.getBindingResult());
/*     */ 
/* 109 */     return argument;
/*     */   }
/*     */ 
/*     */   private void validate(WebDataBinder binder, MethodParameter parameter) throws Exception, MethodArgumentNotValidException
/*     */   {
/* 114 */     Annotation[] annotations = parameter.getParameterAnnotations();
/* 115 */     for (Annotation annot : annotations)
/* 116 */       if (annot.annotationType().getSimpleName().startsWith("Valid")) {
/* 117 */         Object hints = AnnotationUtils.getValue(annot);
/* 118 */         binder.validate(new Object[] { (hints instanceof Object[]) ? (Object[])hints : hints });
/* 119 */         BindingResult bindingResult = binder.getBindingResult();
/* 120 */         if ((!bindingResult.hasErrors()) || 
/* 121 */           (!isBindExceptionRequired(binder, parameter))) break;
/* 122 */         throw new MethodArgumentNotValidException(parameter, bindingResult);
/*     */       }
/*     */   }
/*     */ 
/*     */   private boolean isBindExceptionRequired(WebDataBinder binder, MethodParameter parameter)
/*     */   {
/* 137 */     int i = parameter.getParameterIndex();
/* 138 */     Class[] paramTypes = parameter.getMethod().getParameterTypes();
/* 139 */     boolean hasBindingResult = (paramTypes.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/*     */ 
/* 141 */     return !hasBindingResult;
/*     */   }
/*     */ 
/*     */   protected <T> Object readWithMessageConverters(NativeWebRequest webRequest, MethodParameter methodParam, Type paramType)
/*     */     throws IOException, HttpMediaTypeNotSupportedException
/*     */   {
/* 148 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 149 */     HttpInputMessage inputMessage = new ServletServerHttpRequest(servletRequest);
/*     */ 
/* 151 */     RequestBody annot = (RequestBody)methodParam.getParameterAnnotation(RequestBody.class);
/* 152 */     if (!annot.required()) {
/* 153 */       InputStream inputStream = inputMessage.getBody();
/* 154 */       if (inputStream == null) {
/* 155 */         return null;
/*     */       }
/* 157 */       if (inputStream.markSupported()) {
/* 158 */         inputStream.mark(1);
/* 159 */         if (inputStream.read() == -1) {
/* 160 */           return null;
/*     */         }
/* 162 */         inputStream.reset();
/*     */       }
/*     */       else {
/* 165 */         final PushbackInputStream pushbackInputStream = new PushbackInputStream(inputStream);
/* 166 */         int b = pushbackInputStream.read();
/* 167 */         if (b == -1) {
/* 168 */           return null;
/*     */         }
/*     */ 
/* 171 */         pushbackInputStream.unread(b);
/*     */ 
/* 173 */         inputMessage = new ServletServerHttpRequest(servletRequest)
/*     */         {
/*     */           public InputStream getBody() throws IOException
/*     */           {
/* 177 */             return pushbackInputStream;
/*     */           }
/*     */         };
/*     */       }
/*     */     }
/*     */ 
/* 183 */     return super.readWithMessageConverters(inputMessage, methodParam, paramType);
/*     */   }
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws IOException, HttpMediaTypeNotAcceptableException
/*     */   {
/* 191 */     mavContainer.setRequestHandled(true);
/* 192 */     if (returnValue != null)
/* 193 */       writeWithMessageConverters(returnValue, returnType, webRequest);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor
 * JD-Core Version:    0.6.2
 */