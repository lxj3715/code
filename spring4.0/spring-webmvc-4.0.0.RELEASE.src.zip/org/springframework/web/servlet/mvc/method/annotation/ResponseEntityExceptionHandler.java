/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConversionNotSupportedException;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.servlet.NoHandlerFoundException;
/*     */ import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;
/*     */ 
/*     */ public abstract class ResponseEntityExceptionHandler
/*     */ {
/*  73 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*  85 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*     */ 
/*     */   @ExceptionHandler({NoSuchRequestHandlingMethodException.class, HttpRequestMethodNotSupportedException.class, HttpMediaTypeNotSupportedException.class, HttpMediaTypeNotAcceptableException.class, MissingServletRequestParameterException.class, ServletRequestBindingException.class, ConversionNotSupportedException.class, TypeMismatchException.class, HttpMessageNotReadableException.class, HttpMessageNotWritableException.class, MethodArgumentNotValidException.class, MissingServletRequestPartException.class, BindException.class, NoHandlerFoundException.class})
/*     */   public final ResponseEntity<Object> handleException(Exception ex, WebRequest request)
/*     */   {
/* 111 */     HttpHeaders headers = new HttpHeaders();
/*     */ 
/* 113 */     if ((ex instanceof NoSuchRequestHandlingMethodException)) {
/* 114 */       HttpStatus status = HttpStatus.NOT_FOUND;
/* 115 */       return handleNoSuchRequestHandlingMethod((NoSuchRequestHandlingMethodException)ex, headers, status, request);
/*     */     }
/* 117 */     if ((ex instanceof HttpRequestMethodNotSupportedException)) {
/* 118 */       HttpStatus status = HttpStatus.METHOD_NOT_ALLOWED;
/* 119 */       return handleHttpRequestMethodNotSupported((HttpRequestMethodNotSupportedException)ex, headers, status, request);
/*     */     }
/* 121 */     if ((ex instanceof HttpMediaTypeNotSupportedException)) {
/* 122 */       HttpStatus status = HttpStatus.UNSUPPORTED_MEDIA_TYPE;
/* 123 */       return handleHttpMediaTypeNotSupported((HttpMediaTypeNotSupportedException)ex, headers, status, request);
/*     */     }
/* 125 */     if ((ex instanceof HttpMediaTypeNotAcceptableException)) {
/* 126 */       HttpStatus status = HttpStatus.NOT_ACCEPTABLE;
/* 127 */       return handleHttpMediaTypeNotAcceptable((HttpMediaTypeNotAcceptableException)ex, headers, status, request);
/*     */     }
/* 129 */     if ((ex instanceof MissingServletRequestParameterException)) {
/* 130 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 131 */       return handleMissingServletRequestParameter((MissingServletRequestParameterException)ex, headers, status, request);
/*     */     }
/* 133 */     if ((ex instanceof ServletRequestBindingException)) {
/* 134 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 135 */       return handleServletRequestBindingException((ServletRequestBindingException)ex, headers, status, request);
/*     */     }
/* 137 */     if ((ex instanceof ConversionNotSupportedException)) {
/* 138 */       HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 139 */       return handleConversionNotSupported((ConversionNotSupportedException)ex, headers, status, request);
/*     */     }
/* 141 */     if ((ex instanceof TypeMismatchException)) {
/* 142 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 143 */       return handleTypeMismatch((TypeMismatchException)ex, headers, status, request);
/*     */     }
/* 145 */     if ((ex instanceof HttpMessageNotReadableException)) {
/* 146 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 147 */       return handleHttpMessageNotReadable((HttpMessageNotReadableException)ex, headers, status, request);
/*     */     }
/* 149 */     if ((ex instanceof HttpMessageNotWritableException)) {
/* 150 */       HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 151 */       return handleHttpMessageNotWritable((HttpMessageNotWritableException)ex, headers, status, request);
/*     */     }
/* 153 */     if ((ex instanceof MethodArgumentNotValidException)) {
/* 154 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 155 */       return handleMethodArgumentNotValid((MethodArgumentNotValidException)ex, headers, status, request);
/*     */     }
/* 157 */     if ((ex instanceof MissingServletRequestPartException)) {
/* 158 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 159 */       return handleMissingServletRequestPart((MissingServletRequestPartException)ex, headers, status, request);
/*     */     }
/* 161 */     if ((ex instanceof BindException)) {
/* 162 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 163 */       return handleBindException((BindException)ex, headers, status, request);
/*     */     }
/* 165 */     if ((ex instanceof NoHandlerFoundException)) {
/* 166 */       HttpStatus status = HttpStatus.NOT_FOUND;
/* 167 */       return handleNoHandlerFoundException((NoHandlerFoundException)ex, headers, status, request);
/*     */     }
/*     */ 
/* 170 */     this.logger.warn("Unknown exception type: " + ex.getClass().getName());
/* 171 */     HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 172 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 188 */     if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
/* 189 */       request.setAttribute("javax.servlet.error.exception", ex, 0);
/*     */     }
/*     */ 
/* 192 */     return new ResponseEntity(body, headers, status);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleNoSuchRequestHandlingMethod(NoSuchRequestHandlingMethodException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 208 */     pageNotFoundLogger.warn(ex.getMessage());
/*     */ 
/* 210 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 226 */     pageNotFoundLogger.warn(ex.getMessage());
/*     */ 
/* 228 */     Set supportedMethods = ex.getSupportedHttpMethods();
/* 229 */     if (!supportedMethods.isEmpty()) {
/* 230 */       headers.setAllow(supportedMethods);
/*     */     }
/*     */ 
/* 233 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 249 */     List mediaTypes = ex.getSupportedMediaTypes();
/* 250 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 251 */       headers.setAccept(mediaTypes);
/*     */     }
/*     */ 
/* 254 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 269 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 284 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 299 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleConversionNotSupported(ConversionNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 314 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleTypeMismatch(TypeMismatchException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 329 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 344 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 359 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 374 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleMissingServletRequestPart(MissingServletRequestPartException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 389 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 404 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ 
/*     */   protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 420 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler
 * JD-Core Version:    0.6.2
 */