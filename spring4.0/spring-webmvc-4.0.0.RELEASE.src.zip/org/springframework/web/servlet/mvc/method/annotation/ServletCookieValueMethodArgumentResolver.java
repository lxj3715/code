/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import javax.servlet.http.Cookie;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.annotation.AbstractCookieValueMethodArgumentResolver;
/*    */ import org.springframework.web.util.UrlPathHelper;
/*    */ import org.springframework.web.util.WebUtils;
/*    */ 
/*    */ public class ServletCookieValueMethodArgumentResolver extends AbstractCookieValueMethodArgumentResolver
/*    */ {
/* 38 */   private UrlPathHelper urlPathHelper = new UrlPathHelper();
/*    */ 
/*    */   public ServletCookieValueMethodArgumentResolver(ConfigurableBeanFactory beanFactory) {
/* 41 */     super(beanFactory);
/*    */   }
/*    */ 
/*    */   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {
/* 45 */     this.urlPathHelper = urlPathHelper;
/*    */   }
/*    */ 
/*    */   protected Object resolveName(String cookieName, MethodParameter parameter, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 51 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 52 */     Cookie cookieValue = WebUtils.getCookie(servletRequest, cookieName);
/* 53 */     if (Cookie.class.isAssignableFrom(parameter.getParameterType())) {
/* 54 */       return cookieValue;
/*    */     }
/* 56 */     if (cookieValue != null) {
/* 57 */       return this.urlPathHelper.decodeRequestString(servletRequest, cookieValue.getValue());
/*    */     }
/*    */ 
/* 60 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ServletCookieValueMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */