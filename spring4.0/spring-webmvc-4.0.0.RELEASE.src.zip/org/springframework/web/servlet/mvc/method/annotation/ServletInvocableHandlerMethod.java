/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.Callable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.annotation.ResponseStatus;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*     */ import org.springframework.web.method.support.InvocableHandlerMethod;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ public class ServletInvocableHandlerMethod extends InvocableHandlerMethod
/*     */ {
/*     */   private HttpStatus responseStatus;
/*     */   private String responseReason;
/*     */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*     */ 
/*     */   public ServletInvocableHandlerMethod(Object handler, Method method)
/*     */   {
/*  65 */     super(handler, method);
/*  66 */     initResponseStatus();
/*     */   }
/*     */ 
/*     */   public ServletInvocableHandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/*  73 */     super(handlerMethod);
/*  74 */     initResponseStatus();
/*     */   }
/*     */ 
/*     */   private void initResponseStatus() {
/*  78 */     ResponseStatus annot = (ResponseStatus)getMethodAnnotation(ResponseStatus.class);
/*  79 */     if (annot != null) {
/*  80 */       this.responseStatus = annot.value();
/*  81 */       this.responseReason = annot.reason();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHandlerMethodReturnValueHandlers(HandlerMethodReturnValueHandlerComposite returnValueHandlers)
/*     */   {
/*  90 */     this.returnValueHandlers = returnValueHandlers;
/*     */   }
/*     */ 
/*     */   public final void invokeAndHandle(ServletWebRequest webRequest, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 104 */     Object returnValue = invokeForRequest(webRequest, mavContainer, providedArgs);
/*     */ 
/* 106 */     setResponseStatus(webRequest);
/*     */ 
/* 108 */     if (returnValue == null) {
/* 109 */       if ((isRequestNotModified(webRequest)) || (hasResponseStatus()) || (mavContainer.isRequestHandled())) {
/* 110 */         mavContainer.setRequestHandled(true);
/*     */       }
/*     */ 
/*     */     }
/* 114 */     else if (StringUtils.hasText(this.responseReason)) {
/* 115 */       mavContainer.setRequestHandled(true);
/* 116 */       return;
/*     */     }
/*     */ 
/* 119 */     mavContainer.setRequestHandled(false);
/*     */     try
/*     */     {
/* 122 */       this.returnValueHandlers.handleReturnValue(returnValue, getReturnValueType(returnValue), mavContainer, webRequest);
/*     */     }
/*     */     catch (Exception ex) {
/* 125 */       if (this.logger.isTraceEnabled()) {
/* 126 */         this.logger.trace(getReturnValueHandlingErrorMessage("Error handling return value", returnValue), ex);
/*     */       }
/* 128 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setResponseStatus(ServletWebRequest webRequest)
/*     */     throws IOException
/*     */   {
/* 136 */     if (this.responseStatus == null) {
/* 137 */       return;
/*     */     }
/*     */ 
/* 140 */     if (StringUtils.hasText(this.responseReason)) {
/* 141 */       webRequest.getResponse().sendError(this.responseStatus.value(), this.responseReason);
/*     */     }
/*     */     else {
/* 144 */       webRequest.getResponse().setStatus(this.responseStatus.value());
/*     */     }
/*     */ 
/* 148 */     webRequest.getRequest().setAttribute(View.RESPONSE_STATUS_ATTRIBUTE, this.responseStatus);
/*     */   }
/*     */ 
/*     */   private boolean isRequestNotModified(ServletWebRequest webRequest)
/*     */   {
/* 157 */     return webRequest.isNotModified();
/*     */   }
/*     */ 
/*     */   private boolean hasResponseStatus()
/*     */   {
/* 164 */     return this.responseStatus != null;
/*     */   }
/*     */ 
/*     */   private String getReturnValueHandlingErrorMessage(String message, Object returnValue) {
/* 168 */     StringBuilder sb = new StringBuilder(message);
/* 169 */     if (returnValue != null) {
/* 170 */       sb.append(new StringBuilder().append(" [type=").append(returnValue.getClass().getName()).append("] ").toString());
/*     */     }
/* 172 */     sb.append(new StringBuilder().append("[value=").append(returnValue).append("]").toString());
/* 173 */     return getDetailedErrorMessage(sb.toString());
/*     */   }
/*     */ 
/*     */   ServletInvocableHandlerMethod wrapConcurrentResult(final Object result)
/*     */   {
/* 184 */     return new CallableHandlerMethod(new Callable()
/*     */     {
/*     */       public Object call() throws Exception
/*     */       {
/* 188 */         if ((result instanceof Exception)) {
/* 189 */           throw ((Exception)result);
/*     */         }
/* 191 */         if ((result instanceof Throwable)) {
/* 192 */           throw new NestedServletException("Async processing failed", (Throwable)result);
/*     */         }
/* 194 */         return result;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private class CallableHandlerMethod extends ServletInvocableHandlerMethod
/*     */   {
/*     */     public CallableHandlerMethod()
/*     */     {
/* 211 */       super(ClassUtils.getMethod(callable.getClass(), "call", new Class[0]));
/* 212 */       setHandlerMethodReturnValueHandlers(ServletInvocableHandlerMethod.this.returnValueHandlers);
/*     */     }
/*     */ 
/*     */     public Class<?> getBeanType()
/*     */     {
/* 220 */       return ServletInvocableHandlerMethod.this.getBeanType();
/*     */     }
/*     */ 
/*     */     public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType)
/*     */     {
/* 228 */       return ServletInvocableHandlerMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod
 * JD-Core Version:    0.6.2
 */