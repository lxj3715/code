/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.Principal;
/*     */ import java.time.ZoneId;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ public class ServletRequestMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  64 */     Class paramType = parameter.getParameterType();
/*     */ 
/*  74 */     return (WebRequest.class.isAssignableFrom(paramType)) || 
/*  66 */       (ServletRequest.class
/*  66 */       .isAssignableFrom(paramType)) || 
/*  67 */       (MultipartRequest.class
/*  67 */       .isAssignableFrom(paramType)) || 
/*  68 */       (HttpSession.class
/*  68 */       .isAssignableFrom(paramType)) || 
/*  69 */       (Principal.class
/*  69 */       .isAssignableFrom(paramType)) || 
/*  70 */       (Locale.class
/*  70 */       .equals(paramType)) || 
/*  71 */       (TimeZone.class
/*  71 */       .equals(paramType)) || 
/*  72 */       ("java.time.ZoneId"
/*  72 */       .equals(paramType
/*  72 */       .getName())) || 
/*  73 */       (InputStream.class
/*  73 */       .isAssignableFrom(paramType)) || 
/*  74 */       (Reader.class
/*  74 */       .isAssignableFrom(paramType));
/*     */   }
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws IOException
/*     */   {
/*  83 */     Class paramType = parameter.getParameterType();
/*  84 */     if (WebRequest.class.isAssignableFrom(paramType)) {
/*  85 */       return webRequest;
/*     */     }
/*     */ 
/*  88 */     HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*  89 */     if ((ServletRequest.class.isAssignableFrom(paramType)) || (MultipartRequest.class.isAssignableFrom(paramType))) {
/*  90 */       Object nativeRequest = webRequest.getNativeRequest(paramType);
/*  91 */       if (nativeRequest == null)
/*     */       {
/*  93 */         throw new IllegalStateException("Current request is not of type [" + paramType
/*  93 */           .getName() + "]: " + request);
/*     */       }
/*  95 */       return nativeRequest;
/*     */     }
/*  97 */     if (HttpSession.class.isAssignableFrom(paramType)) {
/*  98 */       return request.getSession();
/*     */     }
/* 100 */     if (Principal.class.isAssignableFrom(paramType)) {
/* 101 */       return request.getUserPrincipal();
/*     */     }
/* 103 */     if (Locale.class.equals(paramType)) {
/* 104 */       return RequestContextUtils.getLocale(request);
/*     */     }
/* 106 */     if (TimeZone.class.equals(paramType)) {
/* 107 */       TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/* 108 */       return timeZone != null ? timeZone : TimeZone.getDefault();
/*     */     }
/* 110 */     if ("java.time.ZoneId".equals(paramType.getName())) {
/* 111 */       return ZoneIdResolver.resolveZoneId(request);
/*     */     }
/* 113 */     if (InputStream.class.isAssignableFrom(paramType)) {
/* 114 */       return request.getInputStream();
/*     */     }
/* 116 */     if (Reader.class.isAssignableFrom(paramType)) {
/* 117 */       return request.getReader();
/*     */     }
/*     */ 
/* 121 */     Method method = parameter.getMethod();
/* 122 */     throw new UnsupportedOperationException("Unknown parameter type: " + paramType + " in method: " + method);
/*     */   }
/*     */ 
/*     */   private static class ZoneIdResolver
/*     */   {
/*     */     public static Object resolveZoneId(HttpServletRequest request)
/*     */     {
/* 133 */       TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/* 134 */       return timeZone != null ? timeZone.toZoneId() : ZoneId.systemDefault();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ServletRequestMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */