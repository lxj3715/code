/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Writer;
/*    */ import java.lang.reflect.Method;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class ServletResponseMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 49 */     Class paramType = parameter.getParameterType();
/*    */ 
/* 52 */     return (ServletResponse.class.isAssignableFrom(paramType)) || 
/* 51 */       (OutputStream.class
/* 51 */       .isAssignableFrom(paramType)) || 
/* 52 */       (Writer.class
/* 52 */       .isAssignableFrom(paramType));
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws IOException
/*    */   {
/* 67 */     if (mavContainer != null) {
/* 68 */       mavContainer.setRequestHandled(true);
/*    */     }
/*    */ 
/* 71 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/* 72 */     Class paramType = parameter.getParameterType();
/*    */ 
/* 74 */     if (ServletResponse.class.isAssignableFrom(paramType)) {
/* 75 */       Object nativeResponse = webRequest.getNativeResponse(paramType);
/* 76 */       if (nativeResponse == null)
/*    */       {
/* 78 */         throw new IllegalStateException("Current response is not of type [" + paramType
/* 78 */           .getName() + "]: " + response);
/*    */       }
/* 80 */       return nativeResponse;
/*    */     }
/* 82 */     if (OutputStream.class.isAssignableFrom(paramType)) {
/* 83 */       return response.getOutputStream();
/*    */     }
/* 85 */     if (Writer.class.isAssignableFrom(paramType)) {
/* 86 */       return response.getWriter();
/*    */     }
/*    */ 
/* 90 */     Method method = parameter.getMethod();
/* 91 */     throw new UnsupportedOperationException("Unknown parameter type: " + paramType + " in method: " + method);
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ServletResponseMethodArgumentResolver
 * JD-Core Version:    0.6.2
 */