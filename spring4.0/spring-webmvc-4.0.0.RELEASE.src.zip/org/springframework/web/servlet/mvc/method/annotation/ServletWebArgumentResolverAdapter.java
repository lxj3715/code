/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import org.springframework.web.bind.support.WebArgumentResolver;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.context.request.RequestAttributes;
/*    */ import org.springframework.web.context.request.RequestContextHolder;
/*    */ import org.springframework.web.context.request.ServletRequestAttributes;
/*    */ import org.springframework.web.context.request.ServletWebRequest;
/*    */ import org.springframework.web.method.annotation.AbstractWebArgumentResolverAdapter;
/*    */ 
/*    */ public class ServletWebArgumentResolverAdapter extends AbstractWebArgumentResolverAdapter
/*    */ {
/*    */   public ServletWebArgumentResolverAdapter(WebArgumentResolver adaptee)
/*    */   {
/* 42 */     super(adaptee);
/*    */   }
/*    */ 
/*    */   protected NativeWebRequest getWebRequest()
/*    */   {
/* 47 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 48 */     if ((requestAttributes instanceof ServletRequestAttributes)) {
/* 49 */       ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)requestAttributes;
/* 50 */       return new ServletWebRequest(servletRequestAttributes.getRequest());
/*    */     }
/* 52 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ServletWebArgumentResolverAdapter
 * JD-Core Version:    0.6.2
 */