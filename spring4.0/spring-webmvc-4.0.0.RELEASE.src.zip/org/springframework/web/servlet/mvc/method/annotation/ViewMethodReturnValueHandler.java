/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ import org.springframework.web.servlet.SmartView;
/*    */ import org.springframework.web.servlet.View;
/*    */ 
/*    */ public class ViewMethodReturnValueHandler
/*    */   implements HandlerMethodReturnValueHandler
/*    */ {
/*    */   public boolean supportsReturnType(MethodParameter returnType)
/*    */   {
/* 45 */     return View.class.isAssignableFrom(returnType.getParameterType());
/*    */   }
/*    */ 
/*    */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 54 */     if (returnValue == null) {
/* 55 */       return;
/*    */     }
/* 57 */     if ((returnValue instanceof View)) {
/* 58 */       View view = (View)returnValue;
/* 59 */       mavContainer.setView(view);
/* 60 */       if (((view instanceof SmartView)) && 
/* 61 */         (((SmartView)view).isRedirectView())) {
/* 62 */         mavContainer.setRedirectModelScenario(true);
/*    */       }
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/* 69 */       throw new UnsupportedOperationException("Unexpected return type: " + returnType
/* 69 */         .getParameterType().getName() + " in method: " + returnType.getMethod());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ViewMethodReturnValueHandler
 * JD-Core Version:    0.6.2
 */