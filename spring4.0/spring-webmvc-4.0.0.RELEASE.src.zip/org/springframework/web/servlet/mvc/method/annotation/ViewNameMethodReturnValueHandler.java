/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class ViewNameMethodReturnValueHandler
/*    */   implements HandlerMethodReturnValueHandler
/*    */ {
/*    */   public boolean supportsReturnType(MethodParameter returnType)
/*    */   {
/* 45 */     Class paramType = returnType.getParameterType();
/* 46 */     return (Void.TYPE.equals(paramType)) || (String.class.equals(paramType));
/*    */   }
/*    */ 
/*    */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 55 */     if (returnValue == null) {
/* 56 */       return;
/*    */     }
/* 58 */     if ((returnValue instanceof String)) {
/* 59 */       String viewName = (String)returnValue;
/* 60 */       mavContainer.setViewName(viewName);
/* 61 */       if (isRedirectViewName(viewName)) {
/* 62 */         mavContainer.setRedirectModelScenario(true);
/*    */       }
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/* 68 */       throw new UnsupportedOperationException("Unexpected return type: " + returnType
/* 68 */         .getParameterType().getName() + " in method: " + returnType.getMethod());
/*    */     }
/*    */   }
/*    */ 
/*    */   protected boolean isRedirectViewName(String viewName)
/*    */   {
/* 79 */     return viewName.startsWith("redirect:");
/*    */   }
/*    */ }

/* Location:           D:\crm4月19\WebContent\WEB-INF\lib\spring-webmvc-4.0.0.RELEASE.jar
 * Qualified Name:     org.springframework.web.servlet.mvc.method.annotation.ViewNameMethodReturnValueHandler
 * JD-Core Version:    0.6.2
 */